#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
ssize_t readlink(const char *path,char *buf,size_t size){
 static ssize_t (*orig)(const char*,char*,size_t)=NULL;
 if(!orig)orig=dlsym(RTLD_NEXT,"readlink");
 if(!strcmp(path,"/proc/self/exe") || (!strncmp(path,"/proc/",6) && strstr(path,"/exe"))){
  FILE *f=fopen("/proc/self/cmdline","rb");char arg[PATH_MAX],resolved[PATH_MAX];size_t k=0;
  if(f){int c;while(k+1<sizeof(arg)&&(c=fgetc(f))!=EOF&&c!=0)arg[k++]=c;arg[k]=0;fclose(f);
   int found=realpath(arg,resolved)!=NULL;
   if(!found && !strchr(arg,'/')){char *paths=strdup(getenv("PATH")?getenv("PATH"):"");char *save=NULL;for(char *p=strtok_r(paths,":",&save);p;p=strtok_r(NULL,":",&save)){char candidate[PATH_MAX];snprintf(candidate,sizeof(candidate),"%s/%s",p,arg);if(access(candidate,X_OK)==0 && realpath(candidate,resolved)){found=1;break;}}free(paths);}
   if(found){size_t n=strlen(resolved);if(n>size)n=size;memcpy(buf,resolved,n);return n;}}
 }
 return orig(path,buf,size);
}
