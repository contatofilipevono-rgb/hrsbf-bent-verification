from itertools import combinations
import json

def truth(n,supports):
 return [sum((x&s)==s for s in supports)%2 for x in range(1<<n)]
def mobius(a):
 a=a[:];n=(len(a)-1).bit_length()
 for i in range(n):
  for x in range(len(a)):
   if x>>i&1:a[x]^=a[x^(1<<i)]
 return a

def walsh(f):
 return [sum(1-2*(f[x]^((b&x).bit_count()%2)) for x in range(len(f))) for b in range(len(f))]
def bent(f):return all(w*w==len(f) for w in walsh(f))
def pol(f,a,b):return f[a^b]^f[a]^f[b]^f[0]
def sym(n,blocks):
 def S(x):
  y=x
  for i,j in blocks:
   a=(x>>i)&1;b=(x>>j)&1
   y&=~((1<<i)|(1<<j));y|=(b<<i)|((a^b)<<j)
  return y
 return S
out=[]
for n in range(5):
 ms=[s for s in range(1<<n) if s.bit_count()<=2]
 cases=1<<len(ms);gauss=0;transfers=0;fixedfree=0
 actions=[sym(n,[])]+([sym(n,[(0,1)])] if n>=2 else [])+([sym(n,[(0,1),(2,3)])] if n>=4 else [])
 for code in range(cases):
  supports=[s for j,s in enumerate(ms) if code>>j&1];f=truth(n,supports)
  assert [s for s,c in enumerate(mobius(f)) if c]==supports
  R=[r for r in range(1<<n) if all(pol(f,r,1<<i)==0 for i in range(n))]
  total=sum(1-2*v for v in f)
  assert total*total==(1<<n)*sum(1-2*(f[r]^f[0]) for r in R);gauss+=1
  for S in actions:
   assert all(S(S(S(x)))==x for x in range(1<<n))
   if any(f[S(x)]!=f[x] for x in range(1<<n)):continue
   fix=[x for x in range(1<<n) if S(x)==x]
   assert (total==0)==(sum(1-2*f[x] for x in fix)==0);transfers+=1
   if fix==[0]:assert total!=0;fixedfree+=1
 out.append(dict(n=n,quadratic_anfs=cases,gauss=gauss,odd_linear_invariant_checks=transfers,fixed_free_checks=fixedfree))
# All degree<=3 functions on four coordinates, including linear non-permutation order-three actions.
n=4;ms=[s for s in range(16) if s.bit_count()<=3];stats=[]
for blocks in [[(0,1)],[(0,1),(2,3)]]:
 S=sym(4,blocks);invariant=nb=0;fix=[x for x in range(16) if S(x)==x]
 # choose canonical linear basis for fixed points
 basis=[];span={0}
 for x in fix:
  if x not in span:basis.append(x);span|={z^x for z in list(span)}
 for code in range(1<<len(ms)):
  f=truth(n,[s for j,s in enumerate(ms) if code>>j&1])
  if any(f[S(x)]!=f[x] for x in range(16)):continue
  invariant+=1
  if not bent(f):continue
  nb+=1;g=[]
  for y in range(1<<len(basis)):
   x=0
   for j,b in enumerate(basis):
    if y>>j&1:x^=b
   g.append(f[x])
  assert bent(g)
 stats.append(dict(blocks=blocks,examined=1<<len(ms),invariant=invariant,bent=nb,fixed_dimension=len(basis)))
print(json.dumps(dict(quadratics=out,cubic_GL_order3=stats),indent=2))
