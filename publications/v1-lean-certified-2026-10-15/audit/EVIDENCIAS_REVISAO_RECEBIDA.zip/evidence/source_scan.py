from pathlib import Path
import re,json,hashlib
root=Path('/workspace/scratch/ed4e44fb786d/audit-repo/formalization')
def strip(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif string:
   if s[i]=='\\':i+=2
   elif s[i]=='"':string=False;i+=1
   else:i+=1
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s) if j<0 else j
  elif s.startswith('/-',i):depth=1;i+=2
  elif s[i]=='"':string=True;i+=1
  else:out.append(s[i]);i+=1
 return ''.join(out)
paths=sorted((root/'Antipodal').glob('*.lean'))+[root/'Antipodal.lean',root/'CheckGlobal.lean'];bad=[];hashes={}
for p in paths:
 s=p.read_text();hashes[str(p.relative_to(root))]=hashlib.sha256(s.encode()).hexdigest()
 for m in re.finditer(r'\b(sorry|admit|sorryAx|axiom|unsafe|native_decide|implemented_by|extern)\b|Lean\.ofReduceBool',strip(s)):bad.append([str(p),m.group()])
print(json.dumps(dict(files=len(paths),forbidden=bad,sha256=hashes),indent=2));assert not bad
