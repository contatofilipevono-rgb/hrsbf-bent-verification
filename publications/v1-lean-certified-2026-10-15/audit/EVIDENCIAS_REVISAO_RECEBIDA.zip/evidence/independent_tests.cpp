#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int rot(int x,int n,int k=1){if(!n)return 0;k%=n;return ((x>>k)|(x<<(n-k)))&((1<<n)-1);}
vector<vector<int>> orbits(int n,int d){set<int> seen;vector<vector<int>> o;for(int s=0;s<(1<<n);s++)if(__builtin_popcount((unsigned)s)<=d&&!seen.count(s)){vector<int> a;int t=s;do{a.push_back(t);seen.insert(t);t=rot(t,n);}while(t!=s);o.push_back(a);}return o;}
vector<int> fwht(vector<int> a){for(int h=1;h<(int)a.size();h*=2)for(int i=0;i<(int)a.size();i+=2*h)for(int j=0;j<h;j++){int u=a[i+j],v=a[i+j+h];a[i+j]=u+v;a[i+j+h]=u-v;}return a;}
bool bent(const vector<int>& f){vector<int>a;for(int b:f)a.push_back(1-2*b);a=fwht(a);for(int w:a)if(w*w!=(int)f.size())return false;return true;}
int polar(const vector<int>& f,int a,int b){return f[a^b]^f[a]^f[b]^f[0];}
int main(){
for(int n:{2,4,6,8,10}){auto o=orbits(n,3);int M=1<<n,K=o.size();vector<vector<int>> tables(K,vector<int>(M));int ai=-1;for(int j=0;j<K;j++){for(int s:o[j]){if(s==(1|(1<<(n/2))))ai=j;for(int x=0;x<M;x++)if((x&s)==s)tables[j][x]^=1;}}
vector<int>f(M);uint64_t total=1ULL<<K,nb=0,hom=0,zero=0,folds=0,rigid=0;uint64_t prev=0;
for(uint64_t z=0;z<total;z++){uint64_t g=z^(z>>1);if(z){int j=__builtin_ctzll(g^prev);for(int x=0;x<M;x++)f[x]^=tables[j][x];}prev=g;
bool hasanti=(g>>ai)&1;bool cubic=false,homo=true,quadratic=true;for(int j=0;j<K;j++)if((g>>j)&1){int d=__builtin_popcount((unsigned)o[j][0]);if(d!=3)homo=false;if(d==3)cubic=true,quadratic=false;}
if(!hasanti){zero++;for(int u=0;u<(1<<(n/2));u++)assert(f[u|(u<<(n/2))]==f[0]);}
if(quadratic&&(n==2||n==4||n==8)){int sum=0;for(int b:f)sum+=1-2*b;if(sum==0){rigid++;for(int a=0;a<n;a++)for(int b=0;b<n;b++)assert(polar(f,1<<a,1<<b)==0);}}
if(homo&&cubic){hom++;assert(!bent(f));}
int w0=0;for(int b:f)w0+=1-2*b;if(w0*w0!=M)continue;if(!bent(f))continue;nb++;assert(hasanti);assert(!(homo&&cubic));
int t=n,m=1;while(t%2==0)t/=2,m*=2;swap(t,m); // n=t*m, t power of two, m odd
vector<int> q(1<<t);for(int y=0;y<(1<<t);y++){int x=0;for(int i=0;i<n;i++)x|=((y>>(i%t))&1)<<i;q[y]=f[x];}assert(bent(q));folds++;
}
cout<<"RS degree<=3 n="<<n<<" orbits="<<K<<" exhaustive="<<total<<" bent="<<nb<<" homogeneous_exact3="<<hom<<" zero_antipodal_fixed_tests="<<zero<<" bent_folds="<<folds<<" balanced_quadratic_rigidity="<<rigid<<endl;
}
// Arbitrary quadratic ANFs, including affine terms, invariant under rotation by t.
for(auto [n,t]:vector<pair<int,int>>{{0,1},{3,1},{6,2},{9,3}}){auto o=orbits(n,2); // build orbits under S=rotation by t afresh
vector<vector<int>> os;set<int>seen;for(int s=0;s<(1<<n);s++)if(__builtin_popcount((unsigned)s)<=2&&!seen.count(s)){vector<int>a;int u=s;do{a.push_back(u);seen.insert(u);u=rot(u,n,t);}while(u!=s);os.push_back(a);}
uint64_t total=1ULL<<os.size(),proper=0;vector<vector<int>> tab(os.size(),vector<int>(1<<n));for(int j=0;j<(int)os.size();j++)for(int s:os[j])for(int x=0;x<(1<<n);x++)if((s&x)==s)tab[j][x]^=1;vector<int>q(1<<n);uint64_t prev=0;for(uint64_t z=0;z<total;z++){auto g=z^(z>>1);if(z){int j=__builtin_ctzll(g^prev);for(int x=0;x<(1<<n);x++)q[x]^=tab[j][x];}prev=g;int full=0,fix=0;for(int x=0;x<(1<<n);x++){full+=1-2*q[x];if(rot(x,n,t)==x)fix+=1-2*q[x];}assert((full==0)==(fix==0));proper+=(full==0);}cout<<"quadratic odd action n="<<n<<" shift="<<t<<" exhaustive="<<total<<" balanced="<<proper<<endl;}
}
