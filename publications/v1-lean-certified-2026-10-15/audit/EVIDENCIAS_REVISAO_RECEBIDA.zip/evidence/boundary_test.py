from itertools import combinations
import json

def truth(n,supports):
 return [sum((x&s)==s for s in supports)%2 for x in range(1<<n)]
def mobius(a):
 a=a[:];n=(len(a)-1).bit_length()
 for i in range(n):
  for x in range(len(a)):
   if x>>i&1:a[x]^=a[x^(1<<i)]
 return a

def walsh(f):
 return [sum(1-2*(f[x]^((b&x).bit_count()%2)) for x in range(len(f))) for b in range(len(f))]
def bent(f):return all(w*w==len(f) for w in walsh(f))
def pol(f,a,b):return f[a^b]^f[a]^f[b]^f[0]
def sym(n,blocks):
 def S(x):
  y=x
  for i,j in blocks:
   a=(x>>i)&1;b=(x>>j)&1
   y&=~((1<<i)|(1<<j));y|=(b<<i)|((a^b)<<j)
  return y
 return S

count=rs=0
for table in range(16):
 f=[(table>>x)&1 for x in range(4)];c=mobius(f)
 if bent(f):
  count+=1;assert c[3]==1
  if f[1]==f[2]:rs+=1
print('All 16 two-variable truth tables:',count,'bent;',rs,'RS bent; all have x0*x1 coefficient 1')
