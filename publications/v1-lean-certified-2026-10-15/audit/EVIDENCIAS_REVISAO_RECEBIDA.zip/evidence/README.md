# Evidências da revisão independente de 15/10/2026

O relatório em português está no arquivo `REVISAO_ADVERSARIA_ANTIPODAL_2026-10-15.md` da pasta superior do pacote. Não há patches dos fontes auditados.

## Testes próprios

```sh
g++ -O3 -std=c++17 independent_tests.cpp -o independent_tests
./independent_tests
python3 quadratic_tests.py
python3 boundary_test.py
```

Não use `-DNDEBUG`: as verificações C++ usam assert. A enumeração está limitada às classes e dimensões especificadas no relatório. Walsh e somas de sinais usam inteiros exatos. `tests.log`, `quadratic_tests.json` e `boundary_test.log` são saídas efetivamente obtidas.

## Reprodução Lean

`run_repro.py` documenta os caminhos absolutos da sessão em que foi executado; ajuste a variável root e o caminho da distribuição ao reproduzir em outra máquina. `reproduction.json` registra comandos, códigos e duração. Em um host Linux convencional, não use o shim: faça checkout do SHA indicado, confirme o manifesto e execute os comandos Lean usuais.

Nesta sessão foi necessário `path_shim.c`/`path_shim.so` para localizar o executável. O código intercepta readlink de /proc/.../exe, sem editar os binários ou o kernel. Não foi usado como implementação de cálculo de prova. Logs de tentativas de preparação malsucedidas foram retidos para transparência. Os nomes `cache*.log` distinguem essas tentativas; o cache com caminhos explícitos terminou com sucesso.

`AuditSignatures.lean` é um verificador novo, externo ao checkout auditado. Inclui inspeção explícita de axiomas de `_2h`, omitida em CheckGlobal. Os módulos finais foram reconstruídos antes de usá-lo.

`source_scan.py/json` registra o scanner próprio e SHA-256 dos fontes examinados. `report_commit_diff.txt` registra os únicos arquivos alterados pelo commit posterior dos relatórios. `checkout_status.txt` registra ausência de mudanças versionadas.

## CI

`ci_116248619552.log` e `ci_116249898348.log` são o texto integral recuperado diretamente dos jobs GitHub. Os `.json` correspondentes preservam a resposta recebida da API. O primeiro run testa o SHA 9f186bc..., o segundo o SHA 6dd1836.... Estes não são logs produzidos pela recompilação local; os logs locais têm nomes separados.

## Integridade

O arquivo SHA256SUMS.txt cobre os arquivos de evidência entregues e o relatório. Ele é um registro de integridade, não um certificado matemático autônomo.
