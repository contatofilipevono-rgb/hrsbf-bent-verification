from pathlib import Path
import os,subprocess,json,time,shutil
root=Path('/workspace/scratch/ed4e44fb786d'); cwd=root/'audit-repo/formalization';e=root/'evidence'
env=os.environ.copy();env['LD_PRELOAD']=str(e/'path_shim.so');env['PATH']='/root/.elan/toolchains/leanprover--lean4---v4.15.0/bin:'+env['PATH']
# Delete project products only. Pinned dependency caches are retained.
pre=list((cwd/'.lake/build').rglob('*.olean')) if (cwd/'.lake/build').exists() else []
shutil.rmtree(cwd/'.lake/build',ignore_errors=True)
records=[]
for name,cmd in [('lean_version',['lean','--version']),('lake_version',['lake','--version']),('mathlib_sha',['git','-C','.lake/packages/mathlib','rev-parse','HEAD']),('lake_build',['lake','build']),('global_standalone',['lake','env','lean','Antipodal/GlobalAntipodal.lean']),('walsh_standalone',['lake','env','lean','Antipodal/WalshNormalization.lean']),('CheckGlobal',['lake','env','lean','CheckGlobal.lean']),('AuditSignatures',['lake','env','lean',str(e/'AuditSignatures.lean')])]:
 if cmd[0] in ('lean','lake'):cmd[0]='/root/.elan/toolchains/leanprover--lean4---v4.15.0/bin/'+cmd[0]
 t=time.time()
 with (e/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=round(time.time()-t,2)))
 (e/'reproduction.json').write_text(json.dumps(dict(project_oleans_before_cleanup=len(pre),project_build_deleted=True,records=records),indent=2))
 print(name,r.returncode,flush=True)
 if r.returncode and name=='lake_build':break
