# Pacote de Auditoria Completa — Stănică–Maitra Grau 4 (v3: Avanços Estruturais + Pacote Auditado n=12)

Este pacote reúne tanto os **31 arquivos originais auditados de $n=12$** (com estrutura e hashes idênticos a `SHA256SUMS.txt`) quanto os **novos avanços teóricos, estruturais e de verificação em CPU/GPU (`v3`)** para funções bent rotacionalmente simétricas homogêneas de grau 4 ($\mathcal{H}_n$).

---

## 1. Estrutura do Pacote

### A. Avanços Estruturais v3 (Novos arquivos na raiz e em `formal/` e `results/`)
- `DEG4_STRUCTURAL_ADVANCES_2026_10_16.md`: Relatório técnico completo com todas as demonstrações algébricas, tabelas de postos, sizígias e certificados de eliminação.
- `verify_deg4_structural_advances.py` (também em `code/verify_deg4_structural_advances.py`): Verificador autônomo em CPU (aritmética inteira exata `int64`, sem pontos flutuantes, tempo de execução ~40 s) que valida:
  1. **Família infinita $n = 4p^r$ ($h = 2p^r$) — Teorema da Dicotomia Espectral Bi-Antipodal**: Linearização na variável $x$ sob $(x, x \oplus v) \in \mathbb{F}_2^{p^r} \times \mathbb{F}_2^{p^r}$, verificada exaustivamente para $p^r \in \{3, 5, 7, 9, 11\}$ ($n = 12, 20, 28, 36, 44$).
  2. **Certificado mínimo e ordem ótima de matroide em $n = 12$**: Demonstra que 20 dos 24 subespaços de Poisson são redundantes (apenas `V2_21`, `V1_9`, `V3`, `V4` nos estágios 1–4 bastam para reproduzir exatamente os 13 contadores da CPU) e que a troca $O_5 \leftrightarrow O_3$ (`[1, 11, 13, 31, 5, 3, 15, 23]`) reduz o pico de sobreviventes em 57,3% (`349.680 -> 149.448`).
  3. **Restrições e eliminação de setores em $n = 20$ ($h = 10, \dim\mathcal{H}_{20} = 245$)**:
     - Postos exatos: $\operatorname{rk}(g_0)=5$, $\operatorname{rk}(g_{1023})=13$ (39 sizígias), $\operatorname{rk}(g_{341})=22$, e posto conjunto em $V_2 = \{0, 341, 682, 1023\}$ igual a $32$ (8 sizígias lineares cruzadas entre fibras).
     - Divisibilidade $32 \mid A_z, W_z(1023)$ nas 6 órbitas de período 5 ($z \in \{33, 99, 165, 231, 363, 495\}$).
     - Identidade de Parseval em $b = 1023 \pmod{2560}$: força $W_0(1023)^2 \equiv 1536 \pmod{2560} \iff c_{244} = 0 \land c_{186} \oplus c_{242} = 1$, **eliminando 24 dos 32 setores de $g_0$ (75% de $2^{245}$, incluindo todos os 16 setores com o monômio de 4 ciclos $c_{244}=1$)** e forçando $A_0 = W_0(341) = 0$ e $160 \mid A_{341}$.
     - Na fibra $z = 341$, a identidade universal $K + v_a + v_b \equiv 0 \pmod 4$ combinada com $160 \mid A_{341}$ e $W_{341}(682)^2 \equiv 256 \pmod{1280}$ força o **hiperplano $\mathbb{F}_2$-linear explícito $v_a \oplus v_b = 1$** (152 geradores ímpares) e $K \equiv 3 \pmod 8$, reduzindo $4.194.304 \to 1.114.112$ classes (73,44% eliminadas). Em $V_1(1023)$, reduz $262.144 \to 65.536$ classes (75% eliminadas).
  4. **Restrições e eliminação de setores em $n = 16$ ($h = 8, \dim\mathcal{H}_{16} = 116$)**:
     - Postos exatos: $\operatorname{rk}(g_0)=4, \operatorname{rk}(g_{255})=8, \operatorname{rk}(g_{85})=14$, posto conjunto em $V_2$ igual a $21$ (5 sizígias cruzadas).
     - Parseval módulo $4096$ exige $64 \mid A_0, W_0(255)$, forçando $c_{115} = 0 \land c_{57} \oplus c_{113} = 0$ (**eliminando 12 dos 16 setores, 75% de $2^{116}$**).
     - Peneira conjunta reduz $V_1(255)$ de $4.096 \to 864$ classes (78,91% eliminadas) e $V_2$ de $2.097.152 \to 228.444$ classes (89,11% eliminadas).
- `results/deg4_structural_advances.json`: Certificado JSON gerado por `verify_deg4_structural_advances.py` com todos os contadores, postos, sizígias e hashes.
- `formal/StanicaMaitraDeg4_v3_extensions.lean`: Extensões formais em Lean 4 (`native_decide`, zero `sorry`) para os teoremas aritméticos e de Parseval em $n=16$, $n=20$ e $n=4p^r$.
- `a100_deg4_mission.py` e `RUN_A100_DEG4_MISSION.ipynb`: Script e notebook prontos para validação cruzada CPU vs GPU (A100) em aritmética inteira exata (`int32`/`int64`), medindo separadamente tempos de transferência H2D/D2H e kernels GPU.

### B. Pacote Base Auditado de $n=12$ (Preservado integralmente)
Todos os 31 arquivos originais do pacote auditado de $n=12$ estão preservados nos seus caminhos exatos (`code/`, `formal/`, `paper/`, `results/`, `logs/`, `diffs/`, `SHA256SUMS.txt`), com 31/31 hashes SHA-256 intactos.

---

## 2. Como Reproduzir a Auditoria

```bash
# 1. Conferir integridade SHA-256 dos 31 arquivos v2 originais e do manifesto completo v3
sha256sum -c SHA256SUMS.txt
sha256sum -c SHA256SUMS_V3_COMPLETE.txt

# 2. Executar o verificador estrutural v3 em CPU (~40 segundos)
python3 verify_deg4_structural_advances.py --out results/deg4_structural_advances.json

# 3. Executar a missão completa (CPU ou GPU A100 quando disponível)
python3 a100_deg4_mission.py --out results/a100_deg4_mission_report.json
```

---

## 3. Escopo Matemático e Honestidade Científica

- **Provado incondicionalmente para toda a família infinita $n = 4p^r$ ($p$ ímpar)**: Teorema da Dicotomia Espectral Bi-Antipodal na fibra $z = 0$ (fórmulas exatas para $A_0, W_0(1_h), W_0(z_2)$ via soma linear em $x \in \mathbb{F}_2^{p^r}$).
- **Provado exaustivamente para $n = 12$ ($\dim\mathcal{H}_{12} = 43$)**: Inexistência total de funções bent ($0$ sobreviventes), agora com certificado mínimo de apenas 4 subespaços de Poisson e ordem ótima de matroide.
- **Provado incondicionalmente para $n = 16$ ($\dim\mathcal{H}_{16} = 116$) e $n = 20$ ($\dim\mathcal{H}_{20} = 245$)**: Eliminação analítica e computacional exata de **75% do espaço total** ($12/16$ setores em $n=16$; $24/32$ setores em $n=20$, incluindo todos os setores com o monômio de 4 ciclos), hiperplano invariante $v_a \oplus v_b = 1$ em $z=341$ ($n=20$), e redução drástica de sobreviventes nos subespaços invariantes $V_1$ e $V_2$. A eliminação dos 25% restantes em $n=16, 20$ requer estender o acoplamento de Parseval para as órbitas de período 4/5 e 8/10.
