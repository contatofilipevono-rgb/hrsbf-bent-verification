# Pacote mínimo para auditoria de H(12,4)

Após extrair, execute com Python 3.10 ou posterior, sem bibliotecas adicionais:

    python verify_manifest.py
    python verify_linear_laws.py
    python verify_periodic_reduction.py
    python cpu_replay/verify_certificate.py

O último comando confere uma cobertura simbólica dos quatro espaços afins
necessários e todos os 164.288 testemunhos de Walsh, sem GPU ou varredura de 2^38
candidatos. Leia MATHEMATICAL_EXPLANATION.md para as condições necessárias.

Este pacote não contém uma prova Lean global. As reduções Lean compiladas e o
acervo completo estão no repositório hrsbf-bent-verification, diretório
quartic_audit_2026_10_17. A árvore de cobertura é conferida aqui por Python.
