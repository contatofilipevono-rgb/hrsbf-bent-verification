from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
scripts=['pareto_exact.py','verify_pareto_gray.py','classify_pareto.py','walsh_cover.py','optimize_walsh_cover.py','certify_walsh_cover.py','parity_probe.py','quintic_compact.py','fiber_code_certificate.py','fiber_normalizer_table.py']
for name in scripts:
    print('RUN',name,flush=True)
    subprocess.run([sys.executable,str(root/'work'/name)],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'outputs'/'VERIFICAR_DUAS_LEIS_T20.py')],cwd=root,check=True)
for validator in ['VERIFICAR_QUARTA_CONDICAO.py','VERIFICAR_QUINTA_CONDICAO.py','VERIFICAR_SEXTA_CONDICAO.py','VERIFICAR_REFINAMENTO_T29.py','VERIFICAR_LIMITE_QUOCIENTE_T30.py','VERIFICAR_SETIMA_CONDICAO_T31.py','VERIFICAR_COMBINACAO_T32.py','VERIFICAR_DESCIDA_T33.py','VERIFICAR_FORMA_NORMAL_T34.py','VERIFICAR_POLINOMIOS_T35.py','VERIFICAR_LIMITE_CONJUNTO_T35.py','VERIFICAR_INTERVALO_T36.py','VERIFICAR_NOVA_CONDICAO_T37.py','VERIFICAR_MODELOS_T38.py','VERIFICAR_RESTRICOES_T39.py','VERIFICAR_SIMETRIA_T40.py','VERIFICAR_MODELOS_T40.py','VERIFICAR_LIMITE_T40.py','VERIFICAR_IDENTIDADE_WALSH_T41.py','VERIFICAR_NOVA_CONDICAO_T45.py','VERIFICAR_MODELOS_T46.py','VERIFICAR_DERIVADAS_T43.py','VERIFICAR_DERIVADAS_T44.py']:
    subprocess.run([sys.executable,str(root/'outputs'/validator)],cwd=root,check=True)
print('Reproduction completed. Full metrics and certificates are in work/.')
