import json,time
from pathlib import Path
from fractions import Fraction
data=json.load(open('work/T38_joint_radicals.json'));reports=[];start=time.perf_counter()
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def bias(P):
 P=set(P);pairs=0
 while any(m.bit_count()==2 for m in P):
  edge=next(m for m in P if m.bit_count()==2);i=edge&-edge;j=edge^i
  A={m^i for m in P if m&i and not m&j};B={m^j for m in P if m&j and not m&i};R={m for m in P if not m&(i|j)}
  assert all(m.bit_count()<=1 for m in A|B)
  for a in A:
   for b in B:toggle(R,a|b)
  P=R;pairs+=1
 if any(m.bit_count()==1 for m in P):return Fraction(0)
 return Fraction(-1 if 0 in P else 1,2**pairs)
def restrict(P,coordinates,value):
 selected=sum(1<<j for j in coordinates);ones=sum(((value>>i)&1)<<j for i,j in enumerate(coordinates));zeros=selected^ones;out=set()
 for m in P:
  if not m&zeros:toggle(out,m&~selected)
 assert all(m.bit_count()<=2 for m in out)
 return out
total=Fraction(0)
for branch in data:
 terms=[];upper=Fraction(1)
 for rec in branch['combinations']:
  D=[{int(m,16) for m in row} for row in rec['polynomials_hex']];k=len(D);condition=rec['conditioning_coordinates'];summation=Fraction(0);records=[]
  restricted=[[restrict(row,condition,value) for row in D] for value in range(1<<len(condition))]
  for choice in range(1<<k):
   evaluations=[]
   for rows in restricted:
    P=set()
    for j,row in enumerate(rows):
     if choice>>j&1:P^=row
    value=bias(P);evaluations.append([value.numerator,value.denominator]);summation+=value
   records.append({'radical_combination':choice,'conditioned_quadratic_biases':evaluations})
  Z=summation/Fraction((1<<k)*(1<<len(condition)));amplitude=Z/Fraction(2**(rec['polar_rank']//2));upper+=amplitude
  result={'combination':rec['combination'],'polar_rank':rec['polar_rank'],'radical_dimension':k,'conditioning_coordinates':condition,'radical_zero_fraction':[Z.numerator,Z.denominator],'average_absolute_slice_bias':[amplitude.numerator,amplitude.denominator],'quadratic_bias_records':records};terms.append(result)
  print('branch',branch['branch'],'combo',rec['combination'],'Z',str(Z),'amplitude',float(amplitude),'seconds',round(time.perf_counter()-start,2),flush=True)
 upper/=16;total+=upper/Fraction(64 if branch['branch']==0 else 128)
 reports.append({'branch':branch['branch'],'supports':branch['supports'],'coordinates':branch['coordinates'],'conditional_joint_pass_upper_bound':[upper.numerator,upper.denominator],'combinations':terms})
 print('BRANCH BOUND',branch['branch'],str(upper),float(upper),flush=True)
report={'branches':reports,'global_pass_upper_bound':[total.numerator,total.denominator],'global_excluded_lower_bound':[(1-total).numerator,(1-total).denominator],'excluded_percent_lower_bound':float(100*(1-total)),'seconds':time.perf_counter()-start,'scope':'Rigorous vector-Fourier upper bound for the three periodic second bits after first five and seventh conditions. Exact radical-zero densities; not exact survivor density.'};Path('work/T38_joint_exact_bound.json').write_text(json.dumps(report,indent=2));print('GLOBAL',str(total),report['excluded_percent_lower_bound'],flush=True)
