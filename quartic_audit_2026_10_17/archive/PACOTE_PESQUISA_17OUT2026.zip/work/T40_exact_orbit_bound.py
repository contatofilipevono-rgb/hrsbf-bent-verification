from pathlib import Path
import subprocess,sys
src=Path('work/T39_characterwise_exact.py').read_text(encoding='utf-8').replace('work/T39_characterwise_restrictions.json','work/T40_characterwise_restrictions.json').replace('work/T39_partial_bounds.json','work/T40_partial_bounds.json').replace('work/T39_characterwise_exact_bound.json','work/T40_exact_orbit_bound.json')
src=src.replace("data=json.load(open('work/T40_characterwise_restrictions.json'));start=", "action=json.load(open('work/T40_normalizer_action.json'));previous=json.load(open('work/T39_characterwise_exact_bound.json'));data=json.load(open('work/T40_characterwise_restrictions.json'));start=")
src=src.replace("D=[{int(m,16) for m in row} for row in option['polynomials_hex']];condition=", """D=[{int(m,16) for m in row} for row in option['polynomials_hex']]
   prebasis,precombos,inconsistent=reduce_rows(D)
   if inconsistent is not None:
    D=[{0}];preselection=[inconsistent]
   else:
    D=prebasis[:8];preselection=precombos[:8]
   condition=""")
src=src.replace("outcome={**option,'option_index'", "outcome={**option,'selected_radical_equation_combinations':[hex(c) for c in preselection],'radical_density_is_upper_bound':True,'option_index'")
src=src.replace(' upper=(1+amplitudes)/16;lower=(1-amplitudes)/16;total+=upper/Fraction(64 if branch[\'branch\']==0 else 128)', ''' selected.extend(r for r in previous['branches'][branch['branch']]['characters'] if r['combination'] in [min(o) for o in action['character_orbits']])
 selected.sort(key=lambda r:r['combination']);amplitudes=Fraction(0)
 assert [r['combination'] for r in selected]==[min(o) for o in action['character_orbits']]
 for r in selected:
  orbit=next(o for o in action['character_orbits'] if r['combination'] in o);r['symmetry_orbit']=orbit;amplitudes+=len(orbit)*Fraction(*r['average_absolute_slice_bias'])
 upper=(1+amplitudes)/128;lower=max(Fraction(0),(1-amplitudes)/128);total+=upper/Fraction(64 if branch['branch']==0 else 128)''')
src=src.replace('Character-specific quadratic restrictions for the ten necessary conditions','Symmetry-orbit character restrictions for the thirteen necessary conditions')
Path('work/T40_compute_orbit_bound.py').write_text(src,encoding='utf-8');subprocess.run([sys.executable,'work/T40_compute_orbit_bound.py'],check=True)
