"""Independent original-ANF checks of the reduced sixth condition; standard Python."""
import json,random,time
from pathlib import Path
from itertools import combinations
start=time.perf_counter();seen=set();orbits=[]
def rotate(m):return ((m<<1)&65535)|(m>>15)
for subset in combinations(range(16),4):
 m=sum(1<<j for j in subset)
 if m in seen:continue
 orb=[];r=m
 while r not in orb:orb.append(r);r=rotate(r)
 seen.update(orb);orbits.append(orb)
assert len(orbits)==116
points=[v|(w<<8) for v in range(64) for w in range(64)]
words=[]
for orb in orbits:
 word=0
 for k,x in enumerate(points):
  if sum((x&m)==m for m in orb)%2:word|=1<<k
 words.append(word)
signword=sum((x.bit_count()%2)<<k for k,x in enumerate(points))
L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
factor=json.load(open('work/post_T20_quadratic_factored.json'))
K=[j for j in json.load(open('work/fifth_quadratic.json'))['I'] if j!=57]
data=json.load(open('work/T28_after_all_five.json'));reports=[]
def parity(c,indices):return sum((c>>j)&1 for j in indices)%2
def q4(c):return (parity(c,factor['linear'])+sum(parity(c,p['I'])*parity(c,p['J']) for p in factor['products']))%2
for rec in data['branches']:
 b=rec['branch'];excluded={0,23,99,113,115}|({57} if b else set());free=sorted(set(range(116))-excluded)
 poly=[int(m,16) for m in rec['polynomial_hex']];assert len(poly)==len(set(poly))
 assert max(m.bit_count() for m in poly)==4 and poly
 assert all(not any(m>>j&1 for j in excluded) for m in poly)
 rng=random.Random(128376+b);hist=[0,0];examples=[]
 for sample in range(256):
  z=rng.getrandbits(116)&sum(1<<j for j in free);c=z
  if b:c|=1<<99;c|=parity(c,K)<<57
  c|=(b^parity(c,L))<<0;c|=((c>>57)&1)<<113
  c|=q4(c)<<23
  assert ((c>>99)&1)==parity(c,L) and q4(c)==0
  assert not b or (parity(c,K)^((c>>57)&1))==0
  word=signword
  for j in range(116):
   if c>>j&1:word^=words[j]
  h=4096-2*word.bit_count();assert h%16==0
  value=sum((z&m)==m for m in poly)%2
  assert value==(h//16)%2
  hist[value]+=1
  if len(examples)<4:examples.append({'coefficient_hex':hex(c),'h_u':h,'next_bit':value})
 reports.append({'branch_c99':b,'free_dimension':len(free),'degree':4,'monomials':len(poly),'direct_original_ANF_checks':256,'random_histogram_not_global_density':hist,'examples':examples})
report={'branches':reports,'total_original_ANF_checks':512,'method':'independently reconstructed cyclic quartic orbits and direct signed sum over all 4096 points in support 0x3f3f; no branch coefficient basis or orbit-pair identity used','rigorous_global_candidate_fraction_upper_bound':'45/1024','rigorous_global_excluded_fraction_lower_bound':'979/1024','scope':'degree-four minimum-weight bound; no exact sixth-condition density or nonexistence claim','seconds':time.perf_counter()-start}
Path('work/T28_independent_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
