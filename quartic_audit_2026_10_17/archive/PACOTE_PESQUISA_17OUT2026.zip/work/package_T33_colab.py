from pathlib import Path
import json,subprocess,sys
import numpy as np
out=Path('outputs');p=dict(np.load('outputs/T33_parameterization.npz'));counts=json.load(open('work/T33_joint_domain_report.json'));forms=json.load(open('work/T33_quotient_counts.json'))['forms_masks33_hex']
certificate={'section_coefficients_hex':[hex(sum(int(bit)<<j for j,bit in enumerate(row))) for row in p['P']],'forms_masks33_hex':forms}
(out/'T33_DESCIDA_CERTIFICADO.json').write_text(json.dumps(certificate,indent=2))
(out/'T33_exact_domain_report.json').write_text(json.dumps(counts,indent=2))
result=subprocess.run([sys.executable,str(out/'VERIFICAR_DESCIDA_T33.py')],capture_output=True,text=True,check=True)
(out/'T33_DESCIDA_VERIFICACAO.json').write_text(result.stdout);print(result.stdout)
src=Path('work/package_T27_colab.py').read_text().replace('T27','T33').replace('325.074.944','162.537.472').replace('133.380','111.876').replace('duas condições quadráticas','três condições quadráticas').replace('nova condição quadrática','sétima condição quadrática').replace('as duas condições quadráticas','as três condições quadráticas')
src=src.replace("'T33_MAPPING_CPU_VALIDATION.json']", "'T33_MAPPING_CPU_VALIDATION.json','T33_DESCIDA_CERTIFICADO.json','T33_DESCIDA_VERIFICACAO.json','VERIFICAR_DESCIDA_T33.py','T31_SETIMA_CERTIFICADO.json']")
src=src.replace('gradientes dos 111.876 pais retidos','sistemas afins dos 111.876 pais retidos')
Path('work/T33_package_builder.py').write_text(src);subprocess.run([sys.executable,'work/T33_package_builder.py'],check=True)
