"""A cubic necessary condition after the three T20 linear laws."""
import sys,json,random,time
from itertools import combinations
from collections import Counter
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();cert=json.load(open('work/global_orbit_certificate.json'));words=[int(v,16) for v in cert['generator_words_full_orbits_hex']];L=cert['A255_over64_linear_indices'];poly=set()
def toggle(m):
 if m in poly:poly.remove(m)
 else:poly.add(m)
toggle(1<<57)
for j,w in enumerate(words):
 if (w.bit_count()//4+w.bit_count()//2)%2:toggle(1<<j)
for j,k in combinations(L+[99],2):toggle((1<<j)|(1<<k))
for j,k in combinations(range(116),2):
 v=words[j]&words[k];assert v.bit_count()%2==0
 if v.bit_count()//2%2:toggle((1<<j)|(1<<k))
for j,k,l in combinations(range(116),3):
 if (words[j]&words[k]&words[l]).bit_count()%2:toggle((1<<j)|(1<<k)|(1<<l))
raw=sorted(poly);reduced=set()
for m in poly:
 if m>>115&1:continue
 if m>>113&1:m=(m^(1<<113))|(1<<57)
 terms=[m]
 if m>>99&1:terms=[(m^(1<<99))|(1<<j) for j in L]
 for v in terms:
  if v in reduced:reduced.remove(v)
  else:reduced.add(v)
linear=[m.bit_length()-1 for m in reduced if m.bit_count()==1]
nonlinear_union=0
for m in reduced:
 if m.bit_count()>1:nonlinear_union|=m
isolated=[j for j in linear if not(nonlinear_union>>j&1)]
arr=np.array([[m&((1<<64)-1),m>>64] for m in sorted(reduced)],dtype=np.uint64).reshape(-1,2)
np.savez_compressed('work/post_T20_cubic.npz',monomials=arr)
gs,_,_=setup(16);rng=random.Random(20261017202);examples={};hist=[0,0]
for it in range(1024):
 c=rng.getrandbits(116)&~((1<<115)|(1<<113)|(1<<99));c|=((c>>57)&1)<<113;c|=(sum((c>>j)&1 for j in L)%2)<<99
 tt=0
 for j,(_,w) in enumerate(gs):
  if c>>j&1:tt^=w
 W0=65536-2*tt.bit_count();assert W0%128==0
 lo=np.uint64(c&((1<<64)-1));hi=np.uint64(c>>64)
 value=int(np.count_nonzero(((arr[:,0]&lo)==arr[:,0])&((arr[:,1]&hi)==arr[:,1])))%2
 assert value==(W0//128)%2,(hex(c),value,W0)
 hist[value]+=1;examples.setdefault(str(value),{'coefficient_hex':hex(c),'W0':W0,'cubic_value':value})
report={'condition':'W_f(0)/128 mod2 after all three T20 linear laws; bentness requires zero','raw_terms':len(raw),'reduced_terms':len(reduced),'degree_histogram':dict(sorted(Counter(m.bit_count() for m in reduced).items())),'linear_indices':linear,'isolated_linear_indices':isolated,'independent_truth_table_checks':1024,'random_sample_histogram':hist,'random_seed':20261017202,'examples':examples,'monomials_hex':[hex(m) for m in sorted(reduced)],'seconds':time.perf_counter()-start}
open('work/post_T20_cubic.json','w').write(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='monomials_hex'})
