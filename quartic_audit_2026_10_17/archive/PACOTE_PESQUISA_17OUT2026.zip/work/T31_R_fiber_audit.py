import sys,json,time
from pathlib import Path
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();gs,_,_=setup(16)
def span_add(B,v):
 while v:
  j=v.bit_length()-1
  if j in B:v^=B[j]
  else:B[j]=v;return True
 return False
rows={}
for z in [0,85,170,255,51]:
 for u in range(256):
  x=u|((u^z)<<8);span_add(rows,sum(((word>>x)&1)<<j for j,(_,word) in enumerate(gs)))
assert len(rows)==33
kernel=[]
for j in range(116):
 if j in rows:continue
 v=1<<j
 for pivot in sorted(rows):
  if (v&rows[pivot]).bit_count()%2:v^=1<<pivot
 assert all((v&r).bit_count()%2==0 for r in rows.values());kernel.append(v)
factor=json.load(open('work/post_T20_quadratic_factored.json'));fifth=json.load(open('work/fifth_quadratic.json'));L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
forms={'law115':1<<115,'law57_113':(1<<57)|(1<<113),'law99_L':(1<<99)^sum(1<<j for j in L),'a':1<<57,'b':1<<99,'K':sum(1<<j for j in fifth['I'] if j!=57),'Qlinear':sum(1<<j for j in factor['linear'])}
for i,p in enumerate(factor['products']):
 for side in ['I','J']:forms[f'Q{i}_{side}']=sum(1<<j for j in p[side])
determined={name:not span_add(dict(rows),mask) for name,mask in forms.items()}
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   t=m^sub
   if t in out:out.remove(t)
   else:out.add(t)
   sub=(sub-1)&(m&d)
 return out

R=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'))['R']; print('R determined',not span_add(dict(rows),sum(1<<j for j in R))); print('nonzero kernel R',[(hex(d),[j for j in range(116) if d>>j&1]) for d in kernel if (d&sum(1<<j for j in R)).bit_count()%2][:3])
