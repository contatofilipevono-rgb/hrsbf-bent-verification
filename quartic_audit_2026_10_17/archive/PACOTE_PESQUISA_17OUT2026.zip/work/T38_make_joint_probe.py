from pathlib import Path
import subprocess,sys
src=Path('work/joint_periodic_restrictions.py').read_text(encoding='utf-8').replace('work/T32_combined_models.json','work/T38_all_four_models.json')
src=src.replace(" for supports in [['0x3f3f','0x5f5f'],['0x3f3f','0x6f6f'],['0x3f3f','0x5f5f','0x6f6f']]:", " for supports in [['0x3f3f','0x5f5f','0x6f6f','0x33ff']]:").replace('work/T35_joint_restrictions.json','work/T38_joint_restrictions.json')
Path('work/T38_find_joint_restrictions.py').write_text(src,encoding='utf-8');subprocess.run([sys.executable,'work/T38_find_joint_restrictions.py'],check=True)
src=Path('work/T35_joint_radical_probe.py').read_text(encoding='utf-8').replace('work/T32_combined_models.json','work/T38_all_four_models.json').replace('work/T35_joint_restrictions.json','work/T38_joint_restrictions.json').replace("if len(rec['supports'])!=3", "if len(rec['supports'])!=4").replace('range(1,8)','range(1,16)').replace('work/T35_joint_radicals.json','work/T38_joint_radicals.json')
Path('work/T38_joint_radical_probe.py').write_text(src,encoding='utf-8');subprocess.run([sys.executable,'work/T38_joint_radical_probe.py'],check=True)
