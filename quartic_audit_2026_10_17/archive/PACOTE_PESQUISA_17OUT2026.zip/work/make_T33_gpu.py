from pathlib import Path
import shutil,ast
src=Path('outputs/GRAU4_T27_A100.py').read_text().replace('T27','T33')
src=src.replace('three proved linear laws and two proved quadratic laws','three proved linear laws and three proved quadratic laws')
kernel='''
extern "C" __global__ void ids10(unsigned long long start,int count,
 const unsigned int* parents,const unsigned short* ga,const unsigned short* gb,
 const unsigned char* ca,const unsigned char* cb,const unsigned char* pa,const unsigned char* pb,
 unsigned long long* output){
 int i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=count)return;
 unsigned long long ordinal=start+i;unsigned int row=ordinal>>10,z=ordinal&1023U;
 unsigned int p=pa[row],q=pb[row],extension=0,k=0;
 for(unsigned int j=0;j<12;j++)if(j!=p&&j!=q){extension|=((z>>k)&1U)<<j;k++;}
 extension|=((__popc(extension&ga[row])^ca[row])&1U)<<p;
 extension|=((__popc(extension&gb[row])^cb[row])&1U)<<q;
 output[i]=(unsigned long long)parents[row]|((unsigned long long)extension<<21);
}
'''
src=src.replace("CUDA=r'''", "CUDA=r'''"+kernel)
cpu='''def cpu_ids10(ordinals,parameters):
 ordinals=np.asarray(ordinals,dtype=np.uint64);rows=(ordinals>>np.uint64(10)).astype(np.int64);z=(ordinals&np.uint64(1023)).astype(np.uint32)
 pa=parameters['pivot_a'][rows];pb=parameters['pivot_b'][rows];extension=np.zeros(len(z),dtype=np.uint32);k=np.zeros(len(z),dtype=np.uint32)
 for j in range(12):
  use=(pa!=j)&(pb!=j);extension|=np.where(use,((z>>k)&1)<<j,0).astype(np.uint32);k+=use.astype(np.uint32)
 for suffix,pivot in [('a',pa),('b',pb)]:
  bit=(np.bitwise_count(extension&parameters['gradient_'+suffix][rows])^parameters['constant_'+suffix][rows])&1
  extension|=bit.astype(np.uint32)<<pivot
 return parameters['parents_10'][rows].astype(np.uint64)|(extension.astype(np.uint64)<<np.uint64(21))

'''
src=src.replace('def cpu_ids11(',cpu+'def cpu_ids11(')
condition='''SEVENTH_MASKS=[0xfccfe72,0x16f88,0x8540,0x1,0x2]
def seventh(ids):
 ids=np.asarray(ids,dtype=np.uint64);R,M,K,a,b=[np.bitwise_count(ids&np.uint64(m))%2 for m in SEVENTH_MASKS]
 return R^M^K^(b&M)^(a&K)

'''
src=src.replace('def quadratic(',condition+'def quadratic(')
src=src.replace("assert not np.any(fifth(p['parents_11'])) and not np.any(fifth(p['parents_12']))", "assert not np.any(fifth(p['parents_10'])) and not np.any(fifth(p['parents_11']))")
src=src.replace("target11=len(p['parents_11'])*2048;target12=len(p['parents_12'])*4096;target=target11+target12", "target10=len(p['parents_10'])*1024;target11=len(p['parents_11'])*2048;target=target10+target11")
src=src.replace("assert (len(p['parents_11']),len(p['parents_12']),target)==(108032,25348,325074944)", "assert (len(p['parents_10']),len(p['parents_11']),target)==(65024,46852,162537472)")
src=src.replace("['parents_11','gradient_11','constant_11','parents_12']", "['parents_10','gradient_a','gradient_b','constant_a','constant_b','pivot_a','pivot_b','parents_11','gradient_11','constant_11']")
src=src.replace("mapper11=cp.RawKernel(CUDA,'ids11');mapper12=cp.RawKernel(CUDA,'ids12')", "mapper10=cp.RawKernel(CUDA,'ids10');mapper11=cp.RawKernel(CUDA,'ids11')")
old="""  if group==11:mapper11(((count+255)//256,),(256,),(np.uint64(start),np.int32(count),dev['parents_11'],dev['gradient_11'],dev['constant_11'],output))
  else:mapper12(((count+255)//256,),(256,),(np.uint64(start),np.int32(count),dev['parents_12'],output))"""
new="""  if group==10:mapper10(((count+255)//256,),(256,),(np.uint64(start),np.int32(count),dev['parents_10'],dev['gradient_a'],dev['gradient_b'],dev['constant_a'],dev['constant_b'],dev['pivot_a'],dev['pivot_b'],output))
  else:mapper11(((count+255)//256,),(256,),(np.uint64(start),np.int32(count),dev['parents_11'],dev['gradient_11'],dev['constant_11'],output))"""
assert old in src;src=src.replace(old,new)
src=src.replace('[(11,target11,cpu_ids11),(12,target12,cpu_ids12)]','[(10,target10,cpu_ids10),(11,target11,cpu_ids11)]')
src=src.replace("and not np.any(fifth(ids))", "and not np.any(fifth(ids)) and not np.any(seventh(ids))")
src=src.replace("group=11 if done<target11 else 12;boundary=target11 if group==11 else target;end=min(stop,done+batch,boundary);local=done if group==11 else done-target11", "group=10 if done<target10 else 11;boundary=target10 if group==10 else target;end=min(stop,done+batch,boundary);local=done if group==10 else done-target10")
src=src.replace("assert not np.any(fifth(examples));", "assert not np.any(fifth(examples));assert not np.any(seventh(examples));")
src=src.replace("'three_linear_laws_and_two_quadratics'", "'three_linear_laws_and_three_quadratics'")
src=src.replace("Necessary filters on the complete T33 domain", "First five conditions and seventh condition, plus energy/Poisson filters on the complete T33 domain")
ast.parse(src);Path('outputs/GRAU4_T33_A100.py').write_text(src,encoding='utf-8');shutil.copyfile('work/T33_parameterization.npz','outputs/T33_parameterization.npz')
print('Generated T33 source and parameters; CUDA execution remains unverified.')
