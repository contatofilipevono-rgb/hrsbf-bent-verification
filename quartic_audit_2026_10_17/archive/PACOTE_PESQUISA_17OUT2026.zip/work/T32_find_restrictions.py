import json,time
from pathlib import Path
from itertools import combinations
data={'branches':[r for r in json.load(open('work/T32_combined_models.json')) if r['support_mask']=='0x3f3f']};reports=[]
def rank(rows):
 basis={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in basis:v^=basis[j]
   else:basis[j]=v;break
 return len(basis)
for rec in data['branches']:
 start=time.perf_counter();P={int(m,16) for m in rec['polynomial_hex']};used=sorted(set(j for m in P for j in range(116) if m>>j&1));bad={j:set() for j in used};edges=set()
 for m in P:
  ids=[j for j in used if m>>j&1]
  if len(ids)>2:
   for i,j in combinations(ids,2):bad[i].add(j);bad[j].add(i)
  elif len(ids)==2:edges.add(tuple(ids))
 allowed={j:set(used)-bad[j]-{j} for j in used};best=[];best_rank=0;cliques=0;hist={}
 def polar(S):return [sum((tuple(sorted((i,j))) in edges)<<k for k,j in enumerate(S) if j!=i) for i in S]
 def visit(R,C,X):
  global best,best_rank,cliques
  if not C and not X:
   cliques+=1;r=rank(polar(R));hist[r]=hist.get(r,0)+1
   if r>best_rank or (r==best_rank and len(R)>len(best)):best=R;best_rank=r
   return
  u=max(C|X,key=lambda u:len(C&allowed[u]))
  for v in list(C-allowed[u]):visit(R+[v],C&allowed[v],X&allowed[v]);C.remove(v);X.add(v)
 visit([],set(used),set());S=sorted(best);den=2**(best_rank//2+1);num=den//2-1
 assert all((m&sum(1<<j for j in S)).bit_count()<=1 for m in P if m.bit_count()>2)
 out={'branch_c99':rec['branch'],'coordinates':S,'coordinate_dimension':len(S),'polar_rank':best_rank,'violation_fraction_lower_bound':[num,den],'pass_fraction_upper_bound':[den-num,den],'polar_rows_hex':[hex(v) for v in polar(S)],'maximal_allowed_cliques_examined':cliques,'rank_histogram':hist,'seconds':time.perf_counter()-start,'scope':'Complete maximal-coordinate-subspace enumeration; optimality is only among coordinate restrictions with no higher-degree term containing two selected variables.'};reports.append(out);print(out,flush=True)
Path('work/T32_exact_restriction_rank.json').write_text(json.dumps(reports,indent=2))
