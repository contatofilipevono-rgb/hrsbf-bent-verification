"""Complete PC2 test in the 28-dimensional quadratic-edge-matching family.
The 256 affine slices are disjoint and exhaust the family. No bent-only filters.
"""
import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks
from VERIFICAR_CANDIDATO_C16 import verify
start=time.perf_counter();family=json.load(open('work/quadratic_product_family.json'));coefficients=[int(family['generators'][j]['coefficient_hex'],16) for j in family['independent_generator_indices']];assert len(coefficients)==28
gs,even,masks=setup(16);words=[]
for c in coefficients:
 tt=0
 for j,(_,w) in enumerate(gs):
  if c>>j&1:tt^=w
 words.append(tt)
truth=np.stack([np.unpackbits(np.frombuffer(w.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little') for w in words]);x=np.arange(65536,dtype=np.uint32);half=x[x%2==0];directions=[1]+[1|(1<<d) for d in range(1,9)];signatures=[]
for a in directions:
 derivative=truth[:,half]^truth[:,half^a];fixed=np.zeros(32768,dtype=np.uint8);free=np.zeros(32768,dtype=np.uint32)
 for j in range(8):fixed|=derivative[j]<<j
 for j in range(20):free|=derivative[8+j].astype(np.uint32)<<j
 signatures.append((fixed,free))
records=[];hist=np.zeros(10,dtype=np.int64);minC1=65537;min_example=None;counterexamples=[]
def lift(block,z):
 c=0
 for j in range(8):
  if block>>j&1:c^=coefficients[j]
 for j in range(20):
  if int(z)>>j&1:c^=coefficients[8+j]
 return c
for block in range(256):
 alive=np.ones(1<<20,dtype=bool);counts=[];previous=1<<20
 for d,(fixed,free) in enumerate(signatures):
  weights=2-4*(np.bitwise_count(fixed&np.uint8(block))%2).astype(np.int32)
  values=np.bincount(free,weights=weights,minlength=1<<20).astype(np.int32)
  for j in range(20):
   v=values.reshape(-1,2,1<<j);a=v[:,0,:].copy();b=v[:,1,:].copy();v[:,0,:]=a+b;v[:,1,:]=a-b
  if d==0:
   local=int(values.min())
   if local<minC1:
    minC1=local;z=int(np.argmin(values));c=lift(block,z);min_example={'coefficient_hex':hex(c),'C_e0':local,'family_block':block,'free_word':z}
  alive&=values==0;current=int(alive.sum());hist[d]+=previous-current;previous=current;counts.append(current)
  if current==0:break
 for z in np.flatnonzero(alive)[:4]:
  c=lift(block,int(z));result=verify(c);assert result['refutes_C16'];counterexamples.append(result)
 hist[-1]+=int(alive.sum());records.append({'block':block,'functions':1<<20,'survivors_after_each_direction':counts,'PC2_survivors':int(alive.sum())})
 report={'dimension':28,'full_family_functions':1<<28,'slices_completed':len(records),'functions_examined':len(records)*(1<<20),'exhaustive_completed':len(records)==256,'disjoint_slices':True,'counterexamples_found':len(counterexamples),'counterexamples':counterexamples,'first_nonzero_direction_histogram':hist.tolist(),'minimum_C_e0_over_examined_functions':minC1,'minimum_example':min_example,'records':records,'seconds':time.perf_counter()-start,'scope':'Complete or explicitly partial enumeration of the two-edge-matching quartic RS family. No filters necessary only for bentness were imposed.'}
 Path('work/quadratic_product_PC2_exhaustion.json').write_text(json.dumps(report,indent=2))
 if block%16==15 or counterexamples:print('PROGRESS',block+1,'min C1',minC1,'PC2',len(counterexamples),'seconds',round(report['seconds'],2),flush=True)
 if counterexamples:break
assert int(hist.sum())==len(records)*(1<<20)
minimum_validation=verify(int(min_example['coefficient_hex'],16));assert minimum_validation['autocorrelations'][0]==minC1
report['minimum_example_independent_validation']=minimum_validation
Path('work/quadratic_product_PC2_exhaustion.json').write_text(json.dumps(report,indent=2));print('DONE',{k:v for k,v in report.items() if k not in ['records','counterexamples','minimum_example_independent_validation']},flush=True)
