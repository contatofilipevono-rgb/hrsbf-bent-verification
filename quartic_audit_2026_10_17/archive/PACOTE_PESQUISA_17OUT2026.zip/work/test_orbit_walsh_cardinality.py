import os,sys,json,time
from pathlib import Path
sys.path.insert(0,'work/deps_local');sys.path.insert(0,'work');sys.path.insert(0,'work/recovered')
handles=[os.add_dll_directory(str(p.parent.resolve())) for p in Path('work/deps_local/pycryptosat-5.17.0.data').rglob('*.dll')]
import pycryptosat
from test_short_witness import setup
from orbit_walsh_cardinality import full_orbit_representatives,folded_signatures,add_walsh_constraint
start=time.perf_counter();gs,_,_=setup(16);reps=full_orbit_representatives();pilot=json.load(open('work/T37_new_obstruction_pilot.json'));controls=[];counts_by_branch={b:folded_signatures(gs,reps,b) for b in [0,1]}
selected={}
for rec in pilot['records']:
 c=int(rec['coefficient_hex'],16);tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 W0=65536-2*tt.bit_count();branch=c>>99&1;good=W0 in [-256,256];key=(branch,good)
 selected.setdefault(key,(c,W0))
 if len(selected)==4:break
assert len(selected)==4
models={}
for (branch,good),(c,W0) in selected.items():
 s=pycryptosat.Solver(time_limit=10,threads=1);last,model=add_walsh_constraint(s,116,counts_by_branch[branch],branch);models[branch]=model
 for j in range(116):s.add_clause([j+1 if c>>j&1 else -(j+1)])
 answer,_=s.solve();assert answer is good
 controls.append({'coefficient_hex':hex(c),'branch':branch,'W0':W0,'expected':good,'solver_answer':answer});print('control',branch,W0,answer,flush=True)
report={'verification':'PASS','controls':controls,'encoding_by_branch':models,'seconds':time.perf_counter()-start,'scope':'Positive and negative fixed original-function controls for the exact Walsh-zero-frequency constraint. This validates an encoding component, not a nonexistence claim.'}
Path('work/T41_Walsh_cardinality_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
