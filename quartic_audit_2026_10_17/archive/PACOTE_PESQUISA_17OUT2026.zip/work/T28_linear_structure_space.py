"""Exact affine-derivative space of the quartic reduced polynomials."""
import json,time
from pathlib import Path
from itertools import combinations
data=json.load(open('work/T28_after_all_five.json'));reports=[]
def nullspace(rows,variables):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in variables:
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
def combine(v,basis):
 out=0
 for i,d in enumerate(basis):
  if v>>i&1:out^=d
 return out
for rec in data['branches']:
 start=time.perf_counter();P=set(int(m,16) for m in rec['polynomial_hex']);excluded={0,23,99,113,115}|({57} if rec['branch'] else set());free=sorted(set(range(116))-excluded)
 contractions={}
 for m in P:
  if m.bit_count()==4:
   bits=[1<<j for j in free if m>>j&1]
   for bit in bits:contractions[m^bit]=contractions.get(m^bit,0)^bit
 R4=nullspace(contractions.values(),free);D4=[derivative(P,d) for d in R4];assert all(all(m.bit_count()<=2 for m in D) for D in D4)
 quadratic_forms={}
 for i,D in enumerate(D4):
  for m in D:
   if m.bit_count()==2:quadratic_forms[m]=quadratic_forms.get(m,0)^(1<<i)
 R3=[combine(v,R4) for v in nullspace(quadratic_forms.values(),list(range(len(R4))))]
 D3=[derivative(P,d) for d in R3];assert all(all(m.bit_count()<=1 for m in D) for D in D3)
 linear=[sum(m for m in D if m.bit_count()==1) for D in D3]
 polar_rows=[sum(((d&l).bit_count()%2)<<j for j,d in enumerate(R3)) for l in linear]
 assert all((row>>i&1)==0 for i,row in enumerate(polar_rows))
 for i in range(len(R3)):
  for j in range(len(R3)):assert (polar_rows[i]>>j&1)==(polar_rows[j]>>i&1)
 polar_rank=len(R3)-len(nullspace(polar_rows,list(range(len(R3)))))
 # Directions with globally constant derivative; a constant-one direction proves exact balance.
 linear_rows=[sum(((l>>j)&1)<<i for i,l in enumerate(linear)) for j in free]
 constant_dirs=[combine(v,R3) for v in nullspace(linear_rows,list(range(len(R3))))]
 constant_one=[d for d in constant_dirs if derivative(P,d)=={0}]
 report={'branch':rec['branch'],'degree_four_contraction_radical_dimension':len(R4),'affine_derivative_space_dimension':len(R3),'fixed_quadratic_polar_rank':polar_rank,'constant_derivative_space_dimension':len(constant_dirs),'constant_one_direction_hex':hex(constant_one[0]) if constant_one else None,'affine_derivative_directions_hex':[hex(d) for d in R3],'affine_derivatives_hex':[[hex(m) for m in sorted(D)] for D in D3],'polar_rows_hex':[hex(v) for v in polar_rows],'seconds':time.perf_counter()-start};reports.append(report);print({k:v for k,v in report.items() if k not in ['affine_derivative_directions_hex','affine_derivatives_hex','polar_rows_hex']},flush=True)
Path('work/T28_linear_structure_space.json').write_text(json.dumps(reports,indent=2))
