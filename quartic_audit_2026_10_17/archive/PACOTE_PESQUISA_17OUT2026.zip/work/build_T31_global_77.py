"""Exact small quadratic condition at support 0x7777, after only three T20 laws."""
import sys,json,time
from pathlib import Path
from itertools import combinations
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16);small=[v for v in range(256) if v&0x77==v];points=[v|(w<<8) for v in small for w in small if v<w];assert len(points)==2016
words=[sum((sum((x&m)==m for m in orb)%2)<<k for k,x in enumerate(points)) for orb,_ in gs];O=sum((x.bit_count()%2)<<k for k,x in enumerate(points));L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
free=sorted(set(range(116))-{99,113,115});cb=[];basis=[]
for j in free:
 c=(1<<j)^((1<<113) if j==57 else 0)^((1<<99) if j in L else 0);cb.append(c);word=0
 for k in range(116):
  if c>>k&1:word^=words[k]
 basis.append(word)
assert O.bit_count()%4==0
assert all(w.bit_count()%2==0 and (w.bit_count()-2*(w&O).bit_count())%4==0 for w in basis)
assert all((v&w).bit_count()%2==0 for v,w in combinations(basis,2))
P=set()
def toggle(m):
 if m in P:P.remove(m)
 else:P.add(m)
if O.bit_count()//4%2:toggle(0)
for i,w in enumerate(basis):
 if (w.bit_count()-2*(w&O).bit_count())//4%2:toggle(1<<free[i])
for i,j in combinations(range(len(free)),2):
 inter=basis[i]&basis[j]
 if (inter.bit_count()//2+(inter&O).bit_count())%2:toggle((1<<free[i])|(1<<free[j]))
for i,j,k in combinations(range(len(free)),3):
 if (basis[i]&basis[j]&basis[k]).bit_count()%2:toggle((1<<free[i])|(1<<free[j])|(1<<free[k]))
factor=json.load(open('work/post_T20_quadratic_factored.json'));K=[j for j in json.load(open('work/fifth_quadratic.json'))['I'] if j!=57];M=factor['products'][2]['I']+factor['products'][2]['J'];R=[5,6,7,16,17,19,43,44,49,50,51,58,59,62,63,66,82,84,87,95,100,102,105,108]
expected=set(1<<j for j in R+M+K)
for A,B in [(L,M),([57],K)]:
 for i in A:
  for j in B:
   m=(1<<i)|(1<<j)
   if m in expected:expected.remove(m)
   else:expected.add(m)
assert P==expected
print('PASS',len(P),'degree',max(m.bit_count() for m in P))
report={'support_mask':'0x7777','after_three_T20_laws':True,'R':R,'M':M,'K':K,'L':L,'factorization':'R + (1+c99)*M + (1+c57)*K','monomials_hex':[hex(m) for m in sorted(P)],'terms':len(P),'degree':max(m.bit_count() for m in P),'isolated_free_coordinate':5,'exact_pass_fraction_after_first_five':'3/128','combined_pass_upper_bound_using_T30':'9/512','scope':'Complete coefficient reconstruction. Full independent verifier and publication update still pending.'}
Path('work/T31_global_77.json').write_text(json.dumps(report,indent=2))
