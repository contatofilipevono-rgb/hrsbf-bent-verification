"""Exact compact W_f(0)=+/-256 constraint on a fixed T20 c99 branch."""
from collections import Counter
L={0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106}
def full_orbit_representatives():
 seen=set();reps=[]
 for x in range(65536):
  if x in seen:continue
  orbit=set();r=x
  for _ in range(16):orbit.add(r);r=((r<<1)&65535)|(r>>15)
  seen|=orbit
  if len(orbit)==16:reps.append(x)
 assert len(reps)==4080
 return reps
def folded_signatures(gs,reps,branch):
 free=sorted(set(range(116))-{0,99,113,115});rows=[]
 for x in reps:
  bits=[(word>>x)&1 for _,word in gs];signature=sum((bits[j]^(bits[0] if j in L else 0)^(bits[113] if j==57 else 0))<<j for j in free);origin=branch*(bits[0]^bits[99]);rows.append((signature,origin))
 return Counter(rows)
def add_walsh_constraint(solver,start_variable,counts,branch):
 variable=start_variable;clauses=0;xors=0;constant=0;numbers=[]
 def fresh():
  nonlocal variable
  variable+=1;return variable
 def clause(row):
  nonlocal clauses
  solver.add_clause(row);clauses+=1
 def xor(row,rhs=False):
  nonlocal xors
  solver.add_xor_clause(row,bool(rhs));xors+=1
 for (signature,origin),weight in counts.items():
  if not signature:
   constant+=origin*weight;continue
  y=fresh();xor([y]+[j+1 for j in range(116) if signature>>j&1],origin)
  numbers.append([y if weight>>k&1 else None for k in range(weight.bit_length())])
 def add(A,B):
  out=[];carry=None
  for k in range(max(len(A),len(B))):
   inputs=[v for v in [A[k] if k<len(A) else None,B[k] if k<len(B) else None,carry] if v is not None]
   if len(inputs)<2:out.append(inputs[0] if inputs else None);carry=None;continue
   z=fresh();xor([z]+inputs);out.append(z);carry=fresh()
   if len(inputs)==2:
    a,b=inputs;clause([-carry,a]);clause([-carry,b]);clause([carry,-a,-b])
   else:
    a,b,c=inputs
    for p,q in [(a,b),(a,c),(b,c)]:clause([-p,-q,carry]);clause([p,q,-carry])
  if carry is not None:out.append(carry)
  return out
 while len(numbers)>1:numbers=[add(numbers[i],numbers[i+1]) if i+1<len(numbers) else numbers[i] for i in range(0,len(numbers),2)]
 bits=numbers[0];sign=fresh();targets=[]
 for a in range(2):
  for sigma in range(2):
   target=2040-4*a-6*branch+16*sigma-constant;assert target>=0 and target<1<<len(bits);targets.append({'a':a,'sign':sigma,'weight_after_constant':target})
   guard=[-58 if a else 58,-sign if sigma else sign]
   for k,bit in enumerate(bits):
    value=target>>k&1
    if bit is None:
     if value:clause(guard)
    else:clause(guard+[bit if value else -bit])
 return variable,{'first_variable':start_variable+1,'last_variable':variable,'new_variables':variable-start_variable,'clauses':clauses,'xor_equations':xors,'distinct_folded_signatures':len(counts),'fixed_one_orbits':constant,'sum_output_bits':len(bits),'targets':targets,'identity':'W0=65536-128*a-192*b-32*weight_full_orbits','scope':'Exact necessary W0=+/-256 constraint under the three T20 laws and fixed b=c99. Balanced binary addition with native XOR and CNF carry gates.'}
