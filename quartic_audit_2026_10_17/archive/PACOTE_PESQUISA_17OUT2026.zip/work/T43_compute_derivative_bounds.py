import json,random,time,math
from pathlib import Path
from fractions import Fraction
from collections import Counter
data=json.load(open('work/T40_all_seven_models.json'));base=json.load(open('work/T40_exact_orbit_bound.json'));start=time.perf_counter();supports=base['branches'][0]['supports'];records=json.loads(Path('work/T43_derivative_bound_cases.json').read_text()) if Path('work/T43_derivative_bound_cases.json').exists() else [];dimension=16
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def restrict(P,C,value):
 selected=sum(1<<j for j in C);ones=sum(((value>>i)&1)<<j for i,j in enumerate(C));zeros=selected^ones;out=set()
 for m in P:
  if not m&zeros:toggle(out,m&~selected)
 return out
def rank(rows):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 return len(B)
def nullspace(rows,variables):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in variables:
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:toggle(out,m^sub);sub=(sub-1)&(m&d)
 return out
for branch in range(2):
 polys=[{int(m,16) for m in next(r for r in data if r['branch']==branch and r['support_mask']==s)['polynomial_hex']} for s in supports]
 for character in [11,14,15,59,62,63]:
  original=set()
  for i,P in enumerate(polys):
   if character>>i&1:original^=P
  condition=[57] if any(m.bit_count()>4 for m in original) else []
  assert branch==0 or not condition
  for value in range(1<<len(condition)):
   if any(r['branch']==branch and r['character']==character and r['condition_value']==value for r in records):continue
   P=restrict(original,condition,value);assert all(m.bit_count()<=4 for m in P);free=sorted(set(range(116))-{0,5,23,99,113,115}-({57} if branch else set())-set(condition));contractions={}
   for m in P:
    if m.bit_count()==4:
     for j in free:
      if m>>j&1:contractions[m^(1<<j)]=contractions.get(m^(1<<j),0)^(1<<j)
   radical=nullspace(contractions.values(),free)
   if len(radical)<dimension:
    print('SKIP',branch,character,value,'radical dimension',len(radical),flush=True);continue
   directions=[];matrices=[];rng=random.Random(2026101743+branch*10000+character*10+value);index={j:i for i,j in enumerate(free)}
   while len(directions)<dimension:
    d=0
    for h in radical:
     if rng.randrange(2):d^=h
    if rank(directions+[d])==len(directions):continue
    D=derivative(P,d);assert all(m.bit_count()<=2 for m in D);rows=[0]*len(free)
    for m in D:
     if m.bit_count()==2:
      a=m&-m;b=m^a;i=index[a.bit_length()-1];j=index[b.bit_length()-1];rows[i]^=1<<j;rows[j]^=1<<i
    directions.append(d);matrices.append(rows)
   current=[0]*len(free);previous=0;hist=Counter()
   for ordinal in range(1,1<<dimension):
    gray=ordinal^(ordinal>>1);changed=(gray^previous).bit_length()-1;current=[a^b for a,b in zip(current,matrices[changed])];r=rank(current);assert r%2==0;hist[r]+=1;previous=gray
   square=(1+sum(Fraction(count,2**(r//2)) for r,count in hist.items()))/Fraction(1<<dimension);scale=1<<40;upper=math.isqrt((square.numerator*scale*scale)//square.denominator)
   while upper*upper*square.denominator<square.numerator*scale*scale:upper+=1
   beta=Fraction(upper,scale);record={'branch':branch,'character':character,'conditioning_coordinates':condition,'condition_value':value,'free_indices':free,'direction_space_dimension':len(radical),'subspace_dimension':dimension,'directions_hex':[hex(d) for d in directions],'matrices_hex':[[hex(v) for v in row] for row in matrices],'rank_histogram':dict(hist),'squared_bias_upper_bound':[square.numerator,square.denominator],'bias_upper_bound':[beta.numerator,beta.denominator]};records.append(record);Path('work/T43_derivative_bound_cases.json').write_text(json.dumps(records,indent=2));print('CASE',branch,character,value,'min rank',min(hist),'bound',float(beta),'sec',round(time.perf_counter()-start,1),flush=True)
total=Fraction(0);branches=[]
for original_branch in base['branches']:
 selected=[];amplitudes=Fraction(0)
 for character in original_branch['characters']:
  old=Fraction(*character['average_absolute_slice_bias']);cases=[r for r in records if r['branch']==original_branch['branch'] and r['character']==character['combination']]
  if cases:
   assert len(cases)==1<<len(cases[0]['conditioning_coordinates']);new=sum(Fraction(*r['bias_upper_bound']) for r in cases)/len(cases);best=min(old,new)
  else:new=None;best=old
  selected.append({'combination':character['combination'],'symmetry_orbit':character['symmetry_orbit'],'old_amplitude':[old.numerator,old.denominator],'new_amplitude':None if new is None else [new.numerator,new.denominator],'selected_amplitude':[best.numerator,best.denominator]});amplitudes+=len(character['symmetry_orbit'])*best
 upper=(1+amplitudes)/128;total+=upper/Fraction(64 if original_branch['branch']==0 else 128);branches.append({'branch':original_branch['branch'],'conditional_pass_upper_bound':[upper.numerator,upper.denominator],'characters':selected})
report={'branches':branches,'global_pass_upper_bound':[total.numerator,total.denominator],'global_excluded_lower_bound':[(1-total).numerator,(1-total).denominator],'excluded_percent_lower_bound':float(100*(1-total)),'seconds':time.perf_counter()-start,'scope':'Finite-difference rank refinement for the same thirteen conditions; independent verification pending.'};Path('work/T43_derivative_refinement_bound.json').write_text(json.dumps(report,indent=2));print('GLOBAL',str(total),report['excluded_percent_lower_bound'],flush=True)
