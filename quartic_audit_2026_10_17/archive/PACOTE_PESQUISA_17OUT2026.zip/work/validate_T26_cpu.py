import sys,json,ast,random
from pathlib import Path
sys.dont_write_bytecode=True;sys.path.insert(0,'outputs');sys.path.insert(0,'work/recovered')
import numpy as np
import GRAU4_T26_A100 as t26
from test_short_witness import setup
for file in ['outputs/GRAU4_T26_A100.py','outputs/GRAU4_T16_A100.py']:ast.parse(Path(file).read_text())
p=dict(np.load('outputs/T26_parameterization.npz'));rng=np.random.default_rng(20261017207);tested=0
for group,mapper,width in [(11,t26.cpu_ids11,11),(12,t26.cpu_ids12,12)]:
 count=len(p[f'parents_{group}']);chosen=rng.integers(0,count,16)
 for row in chosen:
  ordinals=np.arange(int(row)*(1<<width),(int(row)+1)*(1<<width),dtype=np.uint64);ids=mapper(ordinals,p)
  assert len(np.unique(ids))==1<<width and not np.any(t26.quadratic(ids))
  assert np.all((ids&np.uint64((1<<21)-1))==p[f'parents_{group}'][row])
  tested+=len(ids)
# Check the affine extension gradients on every retained parent, not a sample.
for group in [11,12]:
 parents=p[f'parents_{group}'].astype(np.uint64);constant=t26.quadratic(parents);gradient=np.zeros(len(parents),dtype=np.uint16)
 for k in range(12):gradient|=((t26.quadratic(parents|(np.uint64(1)<<np.uint64(21+k)))^constant).astype(np.uint16)<<k)
 if group==11:assert np.array_equal(gradient,p['gradient_11']) and np.array_equal(constant,p['constant_11'])
 else:assert not np.any(gradient) and not np.any(constant)
gs,_,_=setup(16);P=p['P'].astype(np.uint8);L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
direct=0
for group,mapper,width in [(11,t26.cpu_ids11,11),(12,t26.cpu_ids12,12)]:
 total=len(p[f'parents_{group}'])*(1<<width);ids=mapper(rng.integers(0,total,64,dtype=np.uint64),p)
 for state in ids:
  c=(np.array([int(state)>>j&1 for j in range(33)],dtype=np.uint8)@P)&1
  assert c[115]==0 and c[57]==c[113] and (sum(int(c[j]) for j in L)+c[99])%2==0
  tt=0
  for j,(_,word) in enumerate(gs):
   if c[j]:tt^=word
  W0=65536-2*tt.bit_count();assert W0%256==0
  direct+=1
report={'CPU_mapped_states_checked':tested,'all_states_unique_within_parent':True,'all_retained_parent_gradients_checked':len(p['parents_11'])+len(p['parents_12']),'direct_original_ANF_and_Walsh_checks':direct,'all_three_laws_and_quadratic_verified':True,'complete_domain_size':458244096,'GPU_executed':False,'scope':'Host logic, complete retained-parent gradients and exact ANF witnesses validated. CUDA mapper and T26 GPU execution still require the included CPU/GPU crosschecks on an A100.'}
Path('outputs/T26_MAPPING_CPU_VALIDATION.json').write_text(json.dumps(report,indent=2));print(report)
