import sys,json,math,csv
from pathlib import Path
from collections import Counter
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
report=[]
for n in [8,10]:
 gs,_,_=setup(n);index={m:j for j,(orb,_) in enumerate(gs) for m in orb};units=[k for k in range(n) if math.gcd(k,n)==1]
 permutations=[]
 for k in units:
  perm=[]
  for orb,_ in gs:
   mask=sum(1<<((k*i)%n) for i in range(n) if orb[0]>>i&1);perm.append(index[mask])
  permutations.append(perm)
 def action(c,perm):return sum(((c>>j)&1)<<l for j,l in enumerate(perm))
 data=np.load(f'work/pareto_n{n}.npz');nl=data['nonlinearity'];q=data['Q2'];m=data['M2'];previous=json.load(open(f'work/pareto_n{n}.json'));groups=[]
 strata=[('max_NL',int(nl.max()),None)] + [('pareto',r['nonlinearity'],r['min_Q2']) for r in previous['pareto_frontier_Q2_vs_NL']]
 for label,value,energy in strata:
  ix=np.flatnonzero((nl==value)&(True if energy is None else q==energy));remaining=set(map(int,ix));classes=[]
  while remaining:
   c=min(remaining);orb=sorted({action(c,p) for p in permutations});assert set(orb)<=set(map(int,ix))
   remaining-=set(orb)
   supports=[[i for i in range(n) if gs[j][0][0]>>i&1] for j in range(len(gs)) if c>>j&1]
   classes.append({'representative':hex(c),'members':[hex(v) for v in orb],'orbit_size':len(orb),'stabilizer_order':len(units)//len(orb),'selected_orbit_supports':supports,'NL':int(nl[c]),'Q2':int(q[c]),'M2':int(m[c])})
  groups.append({'stratum':label,'NL':value,'Q2':energy,'functions':len(ix),'classes_under_multiplicative_units':len(classes),'classes':classes})
 record={'n':n,'group_units':units,'scope':'Classification under x_i -> x_(k*i mod n), gcd(k,n)=1, plus cyclic rotations which act trivially on RS functions. Not classification under all affine equivalences.','strata':groups};report.append(record)
 print(n,[(g['stratum'],g['NL'],g['Q2'],g['classes_under_multiplicative_units']) for g in groups])
Path('work/pareto_classes.json').write_text(json.dumps(report,indent=2))
with open('outputs/FRONTEIRAS_EXATAS.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['n','NL','Q2_min','Q2_attainers','M2_min','M2_attainers'])
 for n in [8,10]:
  r=json.load(open(f'work/pareto_n{n}.json'))
  for a in r['pareto_frontier_Q2_vs_NL']:w.writerow([n,a['nonlinearity'],a['min_Q2'],a['Q2_attainers'],a['min_M2'],a['M2_attainers']])
