"""Find coordinate subcubes on which sixth-condition polynomials are quadratic with constant polar rank."""
import json,random,time
from pathlib import Path
from itertools import combinations
data=json.load(open('work/T28_after_all_five.json'));reports=[]
def rank(rows):
 basis={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in basis:v^=basis[j]
   else:basis[j]=v;break
 return len(basis)
for rec in data['branches']:
 P={int(m,16) for m in rec['polynomial_hex']};used=sorted(set(j for m in P for j in range(116) if m>>j&1));bad={j:set() for j in used};edges=set()
 for m in P:
  ids=[j for j in used if m>>j&1]
  if len(ids)>2:
   for i,j in combinations(ids,2):bad[i].add(j);bad[j].add(i)
  elif len(ids)==2:edges.add(tuple(ids))
 allowed={j:set(used)-bad[j]-{j} for j in used}
 def polar(S):return [sum((tuple(sorted((i,j))) in edges)<<k for k,j in enumerate(S) if j!=i) for i in S]
 rng=random.Random(44678+rec['branch']);best=[];best_rank=0
 for trial in range(4000):
  candidates=set(used);S=[]
  while candidates:
   scores={j:len(candidates&allowed[j]) for j in candidates};order=sorted(candidates,key=lambda j:(scores[j],rng.random()),reverse=True)
   j=order[0] if trial%3==0 else rng.choice(order[:min(6,len(order))]);S.append(j);candidates&=allowed[j]
  r=rank(polar(S))
  if r>best_rank or (r==best_rank and len(S)>len(best)):best=S;best_rank=r
 assert all((m&sum(1<<j for j in best)).bit_count()<=1 for m in P if m.bit_count()>2)
 assert best_rank%2==0
 den=2**(best_rank//2+1);num=den//2-1
 out={'branch_c99':rec['branch'],'coordinates':sorted(best),'coordinate_dimension':len(best),'polar_rank':best_rank,'violation_fraction_lower_bound':[num,den],'pass_fraction_upper_bound':[den-num,den],'polar_rows_hex':[hex(v) for v in polar(sorted(best))],'scope':'For every assignment to all other free coordinates, this restriction has only a constant plus linear terms plus a quadratic form of the stated fixed polar rank. Standard quadratic Gauss-sum bound gives the certified minimum weight.'}
 reports.append(out);print(out,flush=True)
Path('work/T28_quadratic_restrictions.json').write_text(json.dumps(reports,indent=2))
