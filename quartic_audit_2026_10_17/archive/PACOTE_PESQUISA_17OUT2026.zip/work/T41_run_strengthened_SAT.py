from pathlib import Path
import subprocess,sys
src=Path('work/SAT_periodic_refinement.py').read_text(encoding='utf-8')
src=src.replace('start=time.perf_counter();s=pycryptosat.Solver(time_limit=45,threads=1)', 'branch=int(sys.argv[1]);start=time.perf_counter();s=pycryptosat.Solver(time_limit=60,threads=1)')
src=src.replace("equation([1<<j for j in L],True);equation([1<<j for j in K+[57]])", "equation([1<<j for j in L],bool(branch))\nif branch:equation([1<<j for j in K+[57]])")
src=src.replace("['branches'][1]", "['branches'][branch]")
src=src.replace("equation([1<<j for j in json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'))['R']])", """seven=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));P7={1<<j for j in seven['R']}
if not branch:
 for j in seven['M']+seven['K']:
  m=1<<j
  if m in P7:P7.remove(m)
  else:P7.add(m)
 for j in seven['K']:
  m=(1<<57)|(1<<j)
  if m in P7:P7.remove(m)
  else:P7.add(m)
equation(P7)""")
src=src.replace('s.add_clause([100]);','s.add_clause([100 if branch else -100]);')
src=src.replace("print('SYSTEM',", "from orbit_walsh_cardinality import full_orbit_representatives,folded_signatures,add_walsh_constraint\nsys.path.insert(0,'work/recovered')\nfrom test_short_witness import setup\ngs,_,_=setup(16);counts=folded_signatures(gs,full_orbit_representatives(),branch);nextvar,walsh_encoding=add_walsh_constraint(s,nextvar,counts,branch)\nprint('WALSH ENCODING',walsh_encoding,flush=True)\nprint('SYSTEM',")
src=src.replace("'branch_c99':1", "'branch_c99':branch").replace("'branch_c99': 1", "'branch_c99':branch").replace("'time_limit_seconds':45", "'time_limit_seconds':60").replace("'time_limit_seconds': 45", "'time_limit_seconds':60")
src=src.replace("'scope':'389", "'walsh_encoding':walsh_encoding,'scope':'Exact W0=+/-256, plus 389")
src=src.replace(" report['all_389_polynomials_verified']=True", """ report['all_389_polynomials_verified']=True
 tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 W0=65536-2*tt.bit_count();assert W0 in [-256,256];report['independent_original_W0']=W0""")
src=src.replace("pathlib.Path('work/SAT_periodic_refinement_report.json')", "pathlib.Path(f'work/T41_SAT_Walsh_branch{branch}.json')")
Path('work/T41_strengthened_SAT.py').write_text(src,encoding='utf-8')
for branch in [0,1]:subprocess.run([sys.executable,'work/T41_strengthened_SAT.py',str(branch)],check=True)
