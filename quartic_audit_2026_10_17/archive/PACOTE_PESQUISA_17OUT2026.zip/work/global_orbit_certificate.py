import sys,json
from itertools import combinations
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16);x=np.arange(65536,dtype=np.uint32);can=x.copy();r=x.copy()
for _ in range(15):r=((r<<1)&65535)|(r>>15);can=np.minimum(can,r)
lengths=np.bincount(can,minlength=65536);reps=np.flatnonzero(lengths==16)
words=[]
for orb,_ in gs:
 vals=np.zeros(len(reps),dtype=np.uint8)
 for m in orb:vals^=((reps&m)==m)
 words.append(sum(int(v)<<j for j,v in enumerate(vals)))
comp=json.load(open('work/fiber_code_certificate.json'))[0];cw=[int(v,16) for v in comp['generator_words_hex']]
assert len(reps)==4080
assert all(w.bit_count()%2==0 for w in words)
assert all((a&b).bit_count()%2==0 for a,b in combinations(words,2))
assert all((a&b).bit_count()%2==0 for a,b in combinations(cw,2))
assert all((a.bit_count()-b.bit_count())%4==0 for a,b in zip(words,cw))
L=[j for j,w in enumerate(cw) if w.bit_count()//2%2]
report={'n':16,'full_input_orbit_representatives':reps.tolist(),'generator_words_full_orbits_hex':[hex(w) for w in words],'generator_weights_full_orbits':[w.bit_count() for w in words],'generator_weights_complementary_orbits':[w.bit_count() for w in cw],'both_codes_self_orthogonal':True,'generator_weights_match_mod4':True,'A255_over64_linear_indices':L,'universal_congruence':'W_f(0) == A0 + A255 modulo128 for every homogeneous quartic RS f in16 variables','T20_third_law_after_first_two':[j for j in sorted(L+[99])],'all_three_original_law_rank':3}
open('work/global_orbit_certificate.json','w').write(json.dumps(report,indent=2))
print({k:v for k,v in report.items() if 'representatives' not in k and 'weights' not in k and 'words' not in k})
