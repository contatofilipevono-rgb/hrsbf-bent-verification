import sys,json,time
from pathlib import Path
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();gs,_,_=setup(16)
def span_add(B,v):
 while v:
  j=v.bit_length()-1
  if j in B:v^=B[j]
  else:B[j]=v;return True
 return False
rows={}
for z in [0,85,170,255,51]:
 for u in range(256):
  x=u|((u^z)<<8);span_add(rows,sum(((word>>x)&1)<<j for j,(_,word) in enumerate(gs)))
assert len(rows)==33
kernel=[]
for j in range(116):
 if j in rows:continue
 v=1<<j
 for pivot in sorted(rows):
  if (v&rows[pivot]).bit_count()%2:v^=1<<pivot
 assert all((v&r).bit_count()%2==0 for r in rows.values());kernel.append(v)
factor=json.load(open('work/post_T20_quadratic_factored.json'));fifth=json.load(open('work/fifth_quadratic.json'));L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
forms={'law115':1<<115,'law57_113':(1<<57)|(1<<113),'law99_L':(1<<99)^sum(1<<j for j in L),'a':1<<57,'b':1<<99,'K':sum(1<<j for j in fifth['I'] if j!=57),'Qlinear':sum(1<<j for j in factor['linear'])}
for i,p in enumerate(factor['products']):
 for side in ['I','J']:forms[f'Q{i}_{side}']=sum(1<<j for j in p[side])
determined={name:not span_add(dict(rows),mask) for name,mask in forms.items()}
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   t=m^sub
   if t in out:out.remove(t)
   else:out.add(t)
   sub=(sub-1)&(m&d)
 return out
reports=[]
for rec in json.load(open('work/T28_after_all_five.json'))['branches']:
 P={int(m,16) for m in rec['polynomial_hex']};b=rec['branch'];excluded={0,23,99,113,115}|({57} if b else set());mask=sum(1<<j for j in range(116) if j not in excluded);nonzero=[]
 for d in kernel:
  D=derivative(P,d&mask)
  if D:nonzero.append({'kernel_direction_hex':hex(d),'derivative_monomials':len(D),'degree':max(m.bit_count() for m in D)})
 reports.append({'branch':b,'kernel_directions_checked':len(kernel),'nonzero_derivatives':nonzero,'descends_to_T16_fibers':not nonzero});print('branch',b,'nonconstant kernel derivatives',len(nonzero),flush=True)
report={'fiber_rank':33,'kernel_dimension':len(kernel),'earlier_linear_forms_determined_by_fibers':determined,'branches':reports,'seconds':time.perf_counter()-start,'scope':'Exact symbolic translation derivatives on all 83 kernel basis directions of the T16 restriction map. T28 can be a direct quotient filter only if both reduced polynomials are invariant.'};Path('work/T28_fiber_descent_audit.json').write_text(json.dumps(report,indent=2));print(determined,flush=True)
