from pathlib import Path
import json,sys,subprocess
import numpy as np
out=Path('outputs');pilot=json.load(open('work/T37_new_obstruction_pilot.json'));data=np.load('work/anf_cubic_obstructions.npz');i=int(np.flatnonzero(data['supports']==0x33ff)[0]);bits=np.unpackbits(data['polynomial_bitsets'][i],bitorder='little')[:len(data['feature_masks'])]
features=data['feature_masks']
monomials=[int(features[j,0])|(int(features[j,1])<<64) for j in np.flatnonzero(bits)]
certificate={'support_hex':'0x33ff','witness_coefficient_hex':pilot['selected_conditions'][1]['witness']['coefficient_hex'],'polynomial_after_three_laws_hex':[hex(m) for m in sorted(monomials)],'scope':'Tenth necessary condition selected for smaller polynomial and explicit non-implication witness; criterion is classical.'}
(out/'T37_NOVA_CONDICAO_CERTIFICADO.json').write_text(json.dumps(certificate,indent=2))
(out/'T37_TESTE_APOS_NOVE.json').write_text(json.dumps(pilot,indent=2))
result=subprocess.run([sys.executable,str(out/'VERIFICAR_NOVA_CONDICAO_T37.py')],capture_output=True,text=True,check=True)
(out/'T37_NOVA_CONDICAO_VERIFICACAO.json').write_text(result.stdout);print(result.stdout)
