import json
from pathlib import Path
from collections import Counter
from itertools import combinations
data={'branches':[r for r in json.load(open('work/T32_combined_models.json')) if r['support_mask']=='0x3f3f']};certs=json.load(open('work/T32_exact_restriction_rank.json'));reports=[]
def nullspace(rows,n):
 basis={}
 for v in rows:
  while v:
   p=v.bit_length()-1
   if p in basis:v^=basis[p]
   else:basis[p]=v;break
 vectors=[]
 for j in range(n):
  if j in basis:continue
  v=1<<j
  for pivot in sorted(basis):
   if (basis[pivot]&v).bit_count()%2:v^=1<<pivot
  assert all((v&r).bit_count()%2==0 for r in rows);vectors.append(v)
 return vectors
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:toggle(out,m^sub);sub=(sub-1)&(m&d)
 return out
for rec,cert in zip(data['branches'],certs):
 P=set(int(m,16) for m in rec['polynomial_hex']);S=cert['coordinates'];mask=sum(1<<j for j in S);rows=[int(v,16) for v in cert['polar_rows_hex']];radical=nullspace(rows,len(S));derivs=[];directions=[]
 for r in radical:
  d=sum(((r>>i)&1)<<j for i,j in enumerate(S));directions.append(d);D=derivative(P,d);assert all(not m&mask for m in D);derivs.append(D)
 nonlinear=0
 for D in derivs:
  for m in D:
   if m.bit_count()>1:nonlinear|=m
 variables=sorted(set(j for D in derivs for m in D if m.bit_count()==1 for j in [m.bit_length()-1] if not m&nonlinear))
 columns=[sum(((1<<j) in D)<<i for i,D in enumerate(derivs)) for j in variables];basis={}
 for c in columns:
  while c:
   j=c.bit_length()-1
   if j in basis:c^=basis[j]
   else:basis[j]=c;break
 combos=[]
 for choice in range(1,1<<len(derivs)):
  D=set()
  for i,D0 in enumerate(derivs):
   if choice>>i&1:D^=D0
  combos.append({'combination':choice,'terms':len(D),'degree_histogram':dict(Counter(m.bit_count() for m in D)),'isolated_linear':[m.bit_length()-1 for m in D if m.bit_count()==1 and not any(n&m for n in D if n.bit_count()>1)]})
 report={'branch':rec['branch'],'radical_dimension':len(radical),'directions_hex':[hex(d) for d in directions],'polynomials_hex':[[hex(m) for m in sorted(D)] for D in derivs],'global_isolated_linear_variables':variables,'global_isolated_linear_rank':len(basis),'combinations':combos}
 reports.append(report);print({k:v for k,v in report.items() if k not in ['polynomials_hex','combinations']});print('best combinations',sorted(combos,key=lambda r:(max([0]+[int(k) for k in r['degree_histogram']]),r['terms']))[:5])
Path('work/T32_radical_polynomials.json').write_text(json.dumps(reports,indent=2))
