import json,time
from pathlib import Path
from itertools import combinations
data=json.load(open('work/T40_all_seven_models.json'));reports=[];start=time.perf_counter()
def rank(rows):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 return len(B)
def nullspace(rows,n):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in range(n):
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
def polynomial_rank(rows):
 B={}
 for row in rows:
  v=set(row)
  while v:
   p=max(v)
   if p in B:v^=B[p]
   else:B[p]=v;break
 return len(B),any(v=={0} for v in B.values())
action=json.load(open('work/T40_normalizer_action.json'));supports=action['supports'];representatives=[min(o) for o in action['character_orbits'] if min(o)>15]
for branch in range(2):
 source=[{int(m,16) for m in next(r for r in data if r['branch']==branch and r['support_mask']==s)['polynomial_hex']} for s in supports];results=[]
 for choice in representatives:
  P=set()
  for j,poly in enumerate(source):
   if choice>>j&1:P^=poly
  used=sorted({j for m in P for j in range(116) if m>>j&1});bad={j:set() for j in used};edge=set()
  for m in P:
   ids=[j for j in used if m>>j&1]
   if len(ids)>2:
    for i,j in combinations(ids,2):bad[i].add(j);bad[j].add(i)
   elif len(ids)==2:edge.add(tuple(ids))
  allowed={j:set(used)-bad[j]-{j} for j in used};candidates=[];cliques=0
  def polar(S):return [sum((tuple(sorted((i,j))) in edge)<<k for k,j in enumerate(S) if i!=j) for i in S]
  def visit(R,C,X):
   global cliques
   if not C and not X:
    cliques+=1;r=rank(polar(R));candidates.append((len(R)-r//2,len(R),sorted(R),r));return
   u=max(C|X,key=lambda u:len(C&allowed[u]))
   for v in list(C-allowed[u]):visit(R+[v],C&allowed[v],X&allowed[v]);C.remove(v);X.add(v)
  visit([],set(used),set());candidates.sort(reverse=True);options=[]
  for _,_,S,r in candidates[:24]:
   R=nullspace(polar(S),len(S));directions=[sum(((v>>i)&1)<<j for i,j in enumerate(S)) for v in R];D=[derivative(P,d) for d in directions];prank,constant_one=polynomial_rank(D);higher={m for row in D for m in row if m.bit_count()>2};conditioning=[];remaining=higher
   while remaining and len(conditioning)<5:
    counts={j:sum(bool(m>>j&1) for m in remaining) for j in used};j=max(counts,key=counts.get);conditioning.append(j);selected=sum(1<<j for j in conditioning);remaining={m&~selected for m in higher if (m&~selected).bit_count()>2}
   if remaining or len(conditioning)>3:continue
   score=(1000 if constant_one else prank+r/2,-len(conditioning),len(S))
   option={'coordinates':S,'polar_rank':r,'radical_dimension':len(R),'radical_polynomial_rank':prank,'constant_one_in_derivative_span':constant_one,'conditioning_coordinates':conditioning,'directions_hex':[hex(d) for d in directions],'polynomials_hex':[[hex(m) for m in sorted(row)] for row in D],'score':score};options.append(option)
  options.sort(key=lambda r:r['score'],reverse=True);selected=options[:3]
  result={'combination':choice,'maximal_coordinate_cliques':cliques,'candidate_options':selected};results.append(result)
  print('branch',branch,'character',choice,'options',[(o['coordinates'],o['polar_rank'],o['radical_polynomial_rank'],o['conditioning_coordinates']) for o in selected], 'sec',round(time.perf_counter()-start,1),flush=True)
 reports.append({'branch':branch,'supports':supports,'characters':results});Path('work/T40_characterwise_restrictions.json').write_text(json.dumps(reports,indent=2))
