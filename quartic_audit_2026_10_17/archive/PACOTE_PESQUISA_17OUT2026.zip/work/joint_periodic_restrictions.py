import json,time
from pathlib import Path
from itertools import combinations
from fractions import Fraction
data=json.load(open('work/T32_combined_models.json'));reports=[]
def rank(rows):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 return len(B)
for branch in range(2):
 for supports in [['0x3f3f','0x5f5f'],['0x3f3f','0x6f6f'],['0x3f3f','0x5f5f','0x6f6f']]:
  start=time.perf_counter();polys=[{int(m,16) for m in next(r for r in data if r['branch']==branch and r['support_mask']==s)['polynomial_hex']} for s in supports];used=sorted({j for P in polys for m in P for j in range(116) if m>>j&1});bad={j:set() for j in used};edges=[]
  for P in polys:
   edge=set()
   for m in P:
    ids=[j for j in used if m>>j&1]
    if len(ids)>2:
     for i,j in combinations(ids,2):bad[i].add(j);bad[j].add(i)
    elif len(ids)==2:edge.add(tuple(ids))
   edges.append(edge)
  allowed={j:set(used)-bad[j]-{j} for j in used};best=None;bestscore=None;cliques=0
  def assess(S):
   global best,bestscore,cliques
   cliques+=1;rows=[[sum((tuple(sorted((i,j))) in E)<<k for k,j in enumerate(S) if i!=j) for i in S] for E in edges];ranks=[];upper=Fraction(1)
   for choice in range(1,1<<len(polys)):
    comb=[0]*len(S)
    for i,row in enumerate(rows):
     if choice>>i&1:comb=[a^b for a,b in zip(comb,row)]
    r=rank(comb);ranks.append(r);upper+=Fraction(1,2**(r//2))
   upper/=2**len(polys);score=(upper,-len(S))
   if bestscore is None or score<bestscore:bestscore=score;best={'coordinates':sorted(S),'polar_ranks':ranks,'uniform_pass_upper_bound':[upper.numerator,upper.denominator]}
  def visit(R,C,X):
   if not C and not X:assess(R);return
   u=max(C|X,key=lambda u:len(C&allowed[u]))
   for v in list(C-allowed[u]):visit(R+[v],C&allowed[v],X&allowed[v]);C.remove(v);X.add(v)
  visit([],set(used),set());report={'branch':branch,'supports':supports,**best,'maximal_cliques':cliques,'seconds':time.perf_counter()-start};reports.append(report);print(report,flush=True)
Path('work/T35_joint_restrictions.json').write_text(json.dumps(reports,indent=2))
