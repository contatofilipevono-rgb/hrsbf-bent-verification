from pathlib import Path
import subprocess,sys,json
src=Path('work/build_T31_global_77.py').read_text()
src=src.replace("sys.path.insert(0,'work/recovered')\nfrom test_short_witness import setup",'''base=Path(__file__).resolve().parent
certificate=json.loads((base/'T28_SEXTA_CERTIFICADO.json').read_text())
def setup(n):
 seen=set();gs=[]
 for t in combinations(range(n),4):
  m=sum(1<<j for j in t)
  if m in seen:continue
  orb=set();r=m
  for _ in range(n):orb.add(r);r=((r<<1)&65535)|(r>>15)
  seen|=orb;gs.append((orb,0))
 return gs,None,None''')
src=src.replace("json.load(open('work/post_T20_quadratic_factored.json'))", "certificate['fourth_factorization']").replace("json.load(open('work/fifth_quadratic.json'))", "certificate['fifth_factorization']")
src=src.replace("Path('work/T31_global_77.json').write_text(json.dumps(report,indent=2))",'''# Verify the diagonal identity on every independent basis direction.
diagonal=[sum((sum((v|(v<<8))&m==m for m in orb)%2)<<i for i,v in enumerate(small)) for orb,_ in gs]
for j in range(116):
 if j not in [57,99,113,115]:assert diagonal[j]==0
Da=diagonal[57]^diagonal[113];Db=diagonal[99]
assert [64-2*((Da if a else 0)^(Db if b else 0)).bit_count() for a,b in [(0,0),(0,1),(1,0),(1,1)]]==[64,32,32,0]
assert all(5 not in p[side] for p in factor['products'] for side in ['I','J'])
assert 5 not in factor['linear']+L+K+M+[57,99,113,115] and 5 in R
def derivative(poly,d):
 out=set()
 for m in poly:
  sub=m&d
  while sub:
   t=m^sub
   if t in out:out.remove(t)
   else:out.add(t)
   sub=(sub-1)&(m&d)
 return out
assert derivative(P,1<<75)==set()
assert derivative(P,sum(1<<j for j in [42,81,94,106]))==set()
import random
rng=random.Random(2026101731);truth_words=[]
allpoints=[v|(w<<8) for v in small for w in small]
for orb,_ in gs:truth_words.append(sum((sum((x&m)==m for m in orb)%2)<<k for k,x in enumerate(allpoints)))
chi=sum((x.bit_count()%2)<<k for k,x in enumerate(allpoints))
for sample in range(256):
 z=rng.getrandbits(116)&sum(1<<j for j in free);c=0
 for j,coef in zip(free,cb):
  if z>>j&1:c^=coef
 word=chi
 for j in range(116):
  if c>>j&1:word^=truth_words[j]
 h=4096-2*word.bit_count();assert h%16==0
 assert (h//16)%2==sum((z&m)==m for m in P)%2
report['original_ANF_checks']=256
report['verification']='PASS'
report['scope']='Complete polynomial reconstruction, diagonal and divisibility checks, exact halving by c5, and preservation of the two T30 directions. T30 supplies the combined seven-condition bound.'
print(json.dumps(report,indent=2))''')
Path('outputs/VERIFICAR_SETIMA_CONDICAO_T31.py').write_text(src,encoding='utf-8')
result=subprocess.run([sys.executable,'outputs/VERIFICAR_SETIMA_CONDICAO_T31.py'],capture_output=True,text=True,check=True)
report=json.loads(result.stdout[result.stdout.index('{'):]);Path('outputs/T31_SETIMA_CERTIFICADO.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print({k:v for k,v in report.items() if k!='monomials_hex'})
