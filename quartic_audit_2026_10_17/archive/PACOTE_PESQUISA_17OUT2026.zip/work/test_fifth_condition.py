import json
from pathlib import Path
import numpy as np
p=np.load('work/T26_parameterization.npz');P=p['P'];fifth=json.load(open('work/fifth_quadratic.json'));maps=[]
for group in [fifth['I'],fifth['J']]:
 bits=np.bitwise_xor.reduce(P[:,group],axis=1);maps.append(sum(int(b)<<j for j,b in enumerate(bits)))
a=np.load('work/T19_new_quadratic_flags.npz');parents=a['parents'];counts=a['counts'];q=a['quadratic_value'];f=(np.bitwise_count(parents&np.uint64(maps[0]))%2)&(np.bitwise_count(parents&np.uint64(maps[1]))%2)
retained11=p['parents_11'];retained12=p['parents_12'];assert all(m<(1<<21) for m in maps)
def passes(parents):return ((np.bitwise_count(parents&np.uint32(maps[0]))%2)&(np.bitwise_count(parents&np.uint32(maps[1]))%2))==0
keep11=passes(retained11);keep12=passes(retained12)
report={'fifth_coordinate_masks_hex':[hex(m) for m in maps],'depends_only_on_rank21_prefix':True,'T19_parents_failing_fifth':int(np.count_nonzero(f)),'T19_surviving_extensions_failing_fifth_alone':int(counts[f!=0].sum()),'T19_surviving_extensions_after_four_and_fifth':int(counts[(q==0)&(f==0)].sum()),'T19_additional_surviving_extensions_excluded_after_fourth':int(counts[(q==0)&(f!=0)].sum()),'T26_parents11_retained':int(keep11.sum()),'T26_parents12_retained':int(keep12.sum()),'T27_exact_domain':int(keep11.sum())*2048+int(keep12.sum())*4096,'scope':'The new condition is necessary by the separate integer-ANF certificate. T19 rates are sample-specific; the T27 domain is exact before final energy/Poisson tests.'}
np.savez_compressed('work/T27_parameterization.npz',P=P,parents_11=retained11[keep11],gradient_11=p['gradient_11'][keep11],constant_11=p['constant_11'][keep11],parents_12=retained12[keep12])
Path('work/T27_fifth_condition_report.json').write_text(json.dumps(report,indent=2));print(report)
