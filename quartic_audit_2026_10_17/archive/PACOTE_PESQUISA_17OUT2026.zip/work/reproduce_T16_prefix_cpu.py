"""Independent CPU reproduction of the rank21 prefix and exact T26 domains."""
import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work')
import GRAU4_T16_SOURCE as t16
start=time.perf_counter();d=t16.setup();tables=[]
def fwht_last(a):
 n=a.shape[-1]
 for k in range(n.bit_length()-1):
  v=a.reshape(-1,2,1<<k);left=v[:,0,:].copy();right=v[:,1,:].copy();v[:,0,:]=left+right;v[:,1,:]=left-right
 return a
b=np.arange(256,dtype=np.uint16);u=b.copy();characters=1-2*(np.bitwise_count(b[:,None]&u[None,:])%2).astype(np.int32)
for zi in range(4):
 basis=d['bases'][zi];rank=len(basis);sig=np.zeros(256,dtype=np.uint16)
 for j,row in enumerate(basis):sig|=row.astype(np.uint16)<<j
 tab=np.zeros((256,1<<rank),dtype=np.int32)
 for point in range(256):tab[:,sig[point]]+=characters[:,point]
 fwht_last(tab);tables.append(tab.astype(np.int16));print('TABLE',zi,rank,flush=True)
N=1<<21;ids=np.arange(N,dtype=np.uint32);local=[]
for zi in range(4):
 loc=np.zeros(N,dtype=np.uint16)
 for j in range(int(d['ranks'][zi])):
  mask=int(d['masks'][zi,j]);assert mask<(1<<21)
  loc|=(np.bitwise_count(ids&np.uint32(mask))%2).astype(np.uint16)<<j
 local.append(loc)
alive=np.ones(N,dtype=bool);hist=[]
for qi,freq in enumerate(d['order']):
 idx=np.flatnonzero(alive);w=np.stack([tables[zi][freq,local[zi][idx]].astype(np.int32) for zi in range(4)])
 good=np.sum(w*w,axis=0)<=65536
 for signs,table,cols in [(d['s1'],d['t1'],[0,3]),(d['s2'],d['t2'],[0,1,2,3])]:
  sums=signs@w[cols]
  for gi,row in enumerate(sums):good&=(np.abs(row)<=256)&(table[freq,gi,np.clip(row+256,0,512)]!=0)
 alive[idx[~good]]=False;hist.append(int(np.count_nonzero(~good)))
 if qi%32==0:print('FREQUENCY',qi,'alive',int(alive.sum()),'seconds',round(time.perf_counter()-start,2),flush=True)
parents=ids[alive];assert len(parents)==391804
sample=parents[np.linspace(0,len(parents)-1,256,dtype=int)];assert np.all(t16.cpu_oracle(d,sample,False))
law3=np.uint32(73330);law3_value=np.bitwise_count(parents&law3)%2
assert int(np.count_nonzero(law3_value))==169200
parents=parents[law3_value==0];assert len(parents)==222604
poly=json.load(open('work/new_quadratic_33_poly.json'));monomials=[int(m,16) for m in poly['monomials']]
constant=np.zeros(len(parents),dtype=np.uint8)
for m in monomials:
 if m<(1<<21):constant^=((parents&np.uint32(m))==m).astype(np.uint8)
gradient=np.zeros(len(parents),dtype=np.uint16)
gradient_masks=[]
for k in range(12):
 j=21+k;mask=0;lin=0
 for m in monomials:
  if m>>j&1:
   rest=m^(1<<j)
   if rest==0:lin^=1
   else:assert rest.bit_count()==1 and rest<(1<<21);mask^=rest
 bit=(np.bitwise_count(parents&np.uint32(mask))%2).astype(np.uint16)^lin
 gradient|=bit<<k;gradient_masks.append({'base_mask':hex(mask),'constant':lin})
nonzero=gradient!=0;always=(gradient==0)&(constant==0);never=(gradient==0)&(constant!=0)
report={'prefix_states':N,'prefix_survivors':391804,'prefix_CPU_validation':'PASS','parents_excluded_by_third_linear_law':169200,'parents_after_three_linear_laws':len(parents),'parents_with_2048_quadratic_valid_extensions':int(nonzero.sum()),'parents_with_4096_quadratic_valid_extensions':int(always.sum()),'parents_with_no_quadratic_valid_extensions':int(never.sum()),'original_extensions_after_three_laws':len(parents)*4096,'extensions_after_four_conditions':int(nonzero.sum())*2048+int(always.sum())*4096,'extension_gradient_base_masks':gradient_masks,'first_rejection_counts':hist,'seconds':time.perf_counter()-start,'scope':'Exact domain sizes before the final cube energy and Poisson tests. They are not counts of bent functions or of T16 final survivors.'}
np.savez_compressed('work/T26_parameterization.npz',P=d['P'],parents_11=parents[nonzero],gradient_11=gradient[nonzero],constant_11=constant[nonzero],parents_12=parents[always])
Path('work/T26_exact_domain_report.json').write_text(json.dumps(report,indent=2));print('DONE',{k:v for k,v in report.items() if k not in ['first_rejection_counts','extension_gradient_base_masks']},flush=True)
