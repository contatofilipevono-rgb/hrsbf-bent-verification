"""Discovery/validation pilot on functions passing all nine certified conditions."""
import sys,json,random,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();gs,_,_=setup(16);rng=random.Random(2026101737)
factor=json.load(open('work/post_T20_quadratic_factored.json'));seven=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));L=seven['L'];K=seven['K'];M=seven['M'];R=seven['R']
data=np.load('work/anf_cubic_obstructions.npz');supports=data['supports'];N=len(supports);info=json.load(open('work/anf_cubic_obstructions_report.json'))['per_polynomial']
x=np.arange(65536,dtype=np.uint32);chi=int.from_bytes(np.packbits(np.bitwise_count(x)%2,bitorder='little').tobytes(),'little');special=[0x3f3f,0x5f5f,0x6f6f,0x7777]
masks={u:int.from_bytes(np.packbits((x&np.uint32(u))==x,bitorder='little').tobytes(),'little') for u in special}
def parity(c,indices):return sum((c>>j)&1 for j in indices)%2
def core(branch):
 free=set(range(116))-{0,5,23,99,113,115}-({57} if branch else set());c=rng.getrandbits(116)&sum(1<<j for j in free)
 if branch:c|=parity(c,K)<<57;c|=1<<99
 c|=(branch^parity(c,L))<<0;c|=((c>>57)&1)<<113
 a=(c>>57)&1
 c|=(a^parity(c,[31,39,112])^sum(parity(c,p['I'])*parity(c,p['J']) for p in factor['products'])%2)<<23
 c|=(parity(c,R)^((1^branch)&parity(c,M))^((1^a)&parity(c,K)))<<5
 return c
counts=np.zeros((2,N),dtype=np.int32);records=[];attempts=0;patterns=[]
while len(records)<512:
 attempts+=1;branch=int(rng.randrange(3)==2);c=core(branch);tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 signed=tt^chi;h_special={u:4096-2*(signed&masks[u]).bit_count() for u in special}
 assert all(v%16==0 for v in h_special.values())
 if any(h_special[u]%32 for u in special[:3]):continue
 assert h_special[0x7777]%32==0 and (65536-2*tt.bit_count())%256==0
 assert c>>115&1==0 and (c>>57&1)==(c>>113&1) and (c>>99&1)==parity(c,L)
 assert not branch or ((c>>57&1)==parity(c,K))
 truth=np.unpackbits(np.frombuffer(tt.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little');h=1-2*truth.astype(np.int32)
 for k in range(16):v=h.reshape(-1,2,1<<k);v[:,1,:]-=v[:,0,:]
 assert np.all(h[supports]%8==0)
 bits=((h[supports]//8)%2).astype(np.uint8);counts[int(len(records)>=256)]+=bits;patterns.append(bits)
 records.append({'coefficient_hex':hex(c),'branch_c99':branch,'four_periodic_h_values':{hex(u):v for u,v in h_special.items()},'violating_cubic_equations':int(bits.sum()),'violation_pattern_hex':hex(int.from_bytes(np.packbits(bits,bitorder='little').tobytes(),'little'))})
 if len(records)%128==0:print('accepted',len(records),'attempted',attempts,'seconds',round(time.perf_counter()-start,2),flush=True)
valid_indices=[i for i,r in enumerate(info) if r['terms_after_linear_laws']>0 and int(supports[i]) not in [0x3f3f,0x6f6f]]
best=max(valid_indices,key=lambda i:(int(counts[0,i]),-info[i]['terms_after_linear_laws']))
small=min([i for i in valid_indices if counts[0,i]>0],key=lambda i:info[i]['terms_after_linear_laws'])
selected=[]
for label,i in [('highest_discovery_rejection',best),('smallest_nonredundant_polynomial',small)]:
 witness=next(j for j,bits in enumerate(patterns) if bits[i]);rec=records[witness];c=int(rec['coefficient_hex'],16);tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 u=int(supports[i]);positions=[z for z in range(65536) if z&u==z];h_direct=sum((1-2*((tt>>z)&1))*(-1 if (u.bit_count()-z.bit_count())%2 else 1) for z in positions)
 assert h_direct%8==0 and h_direct//8%2==1
 selected.append({'label':label,'polynomial_index':i,'support_hex':hex(u),'support_weight':u.bit_count(),'monomials_after_three_laws':info[i]['terms_after_linear_laws'],'discovery_rejected_of_256':int(counts[0,i]),'validation_rejected_of_256':int(counts[1,i]),'witness':{**rec,'additional_support_h_direct':h_direct,'additional_required_divisor':1<<(u.bit_count()-7)}})
report={'accepted_nine_condition_functions':512,'attempted_core_functions':attempts,'discovery_count':256,'validation_count':256,'all_389_rejected_at_least_one':sum(r['violating_cubic_equations']>0 for r in records),'selected_conditions':selected,'all_polynomial_counts':[{'support_hex':hex(int(u)),'weight':int(u).bit_count(),'discovery_rejections':int(counts[0,i]),'validation_rejections':int(counts[1,i]),'terms':info[i]['terms_after_linear_laws']} for i,u in enumerate(supports)],'records':records,'seconds':time.perf_counter()-start,'scope':'Finite discovery/validation pilot, not a global rejection rate. Explicit witnesses prove selected necessary conditions are not implied by the nine existing tests.'}
Path('work/T37_new_obstruction_pilot.json').write_text(json.dumps(report,indent=2));np.savez_compressed('work/T37_obstruction_patterns.npz',supports=supports,patterns=np.array(patterns,dtype=np.uint8),counts=counts)
print({k:v for k,v in report.items() if k not in ['records','all_polynomial_counts']},flush=True)
