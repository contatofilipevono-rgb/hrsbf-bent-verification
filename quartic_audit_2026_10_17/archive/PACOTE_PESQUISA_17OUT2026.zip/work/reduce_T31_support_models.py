import json
from pathlib import Path
from collections import Counter
directions=json.load(open('work/T28_balancing_translations.json'));reports=[]
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
for support in ['5f','6f','77']:
 data=json.load(open(f'work/T31_{support}_branch_reports.json'))
 for rec,dr in zip(data['branches'],directions):
  Q={int(m,16) for m in dr['branch_fourth_polynomial_hex']};Q.remove(1<<23);P={int(m,16) for m in rec['monomials_hex']};R=set()
  for m in P:
   if m>>23&1:
    for n in Q:toggle(R,(m^(1<<23))|n)
   else:toggle(R,m)
  nonlinear=0
  for m in R:
   if m.bit_count()>1:nonlinear|=m
  isolated=[m.bit_length()-1 for m in R if m.bit_count()==1 and not m&nonlinear]
  out={'support_mask':hex(int(support,16)*257),'branch':rec['branch_c99'],'terms':len(R),'degree_histogram':dict(Counter(m.bit_count() for m in R)),'isolated_linear_variables':sorted(isolated),'polynomial_hex':[hex(m) for m in sorted(R)]};reports.append(out);print({k:v for k,v in out.items() if k!='polynomial_hex'},flush=True)
Path('work/T31_after_all_five.json').write_text(json.dumps(reports,indent=2))
