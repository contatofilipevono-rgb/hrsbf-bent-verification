from pathlib import Path
import subprocess,sys
src=Path('work/build_T31_global_77.py').read_text();src=src[:src.index('factor=json.load')];src=src.replace('0x77','0x5f')
src+='''
for j in L:toggle(1<<j)  # The diagonal term B0/16 has parity b=L at this support.
from collections import Counter
contractions={}
for m in P:
 if m.bit_count()==3:
  for j in free:
   if m>>j&1:contractions[m^(1<<j)]=contractions.get(m^(1<<j),0)^(1<<j)
B={}
for row in contractions.values():
 while row:
  j=row.bit_length()-1
  if j in B:row^=B[j]
  else:B[j]=row;break
report={'support_mask':'0x5f5f','after_three_laws':True,'monomials':len(P),'degree_histogram':dict(Counter(m.bit_count() for m in P)),'cubic_essential_dimension':len(B),'cubic_polar_radical_dimension':len(free)-len(B),'polynomial_hex':[hex(m) for m in sorted(P)]}
Path('work/T35_global_5f.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='polynomial_hex'})
'''
Path('work/T35_global_5f.py').write_text(src);subprocess.run([sys.executable,'work/T35_global_5f.py'],check=True)
