import sys,json,random,time
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks
gs,even,masks=setup(16)
rng=random.Random(20261016101)
hist=[0]*512; examples={};basis={};start=time.perf_counter()
for it in range(4096):
 c=rng.getrandbits(116);tt=0
 for j,(_,w) in enumerate(gs):
  if c>>j&1:tt^=w
 vals=list(checks(tt,16,even,masks))
 assert all(v%64==0 for v in vals)
 p=sum(((v//64)&1)<<j for j,v in enumerate(vals));hist[p]+=1
 examples.setdefault(str(p),{'c':hex(c),'correlations':vals})
 v=p
 while v:
  j=v.bit_length()-1
  if j not in basis:basis[j]=v;break
  v^=basis[j]
r={'samples':4096,'parity_rank':len(basis),'patterns_seen':sum(v>0 for v in hist),'histogram':hist,'basis':basis,'examples':examples,'seconds':time.perf_counter()-start}
open('work/parity_probe.json','w').write(json.dumps(r,indent=2))
print({k:v for k,v in r.items() if k not in ['histogram','examples']})
