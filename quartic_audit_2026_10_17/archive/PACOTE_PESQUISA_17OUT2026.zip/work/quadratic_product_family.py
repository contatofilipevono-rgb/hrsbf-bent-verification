"""Structured quartic RS family from two-edge matchings of cyclic distance graphs."""
import sys,json
from itertools import combinations
from pathlib import Path
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,rotations
gs,_,_=setup(16);edges={}
for d in range(1,9):edges[d]=sorted({(1<<i)|(1<<((i+d)%16)) for i in range(16)})
generators=[];basis={};chosen=[]
for a in range(1,9):
 for b in range(a,9):
  terms=set()
  pairs=combinations(edges[a],2) if a==b else ((x,y) for x in edges[a] for y in edges[b])
  for x,y in pairs:
   if x&y:continue
   m=x|y
   if m in terms:terms.remove(m)
   else:terms.add(m)
  for orb,_ in gs:assert len(set(orb)&terms) in [0,len(orb)]
  coefficient=sum((int(orb[0] in terms))<<j for j,(orb,_) in enumerate(gs));generators.append({'distances':[a,b],'coefficient_hex':hex(coefficient),'quartic_terms':len(terms)})
  v=coefficient
  while v:
   pivot=v.bit_length()-1
   if pivot in basis:v^=basis[pivot]
   else:basis[pivot]=v;chosen.append(len(generators)-1);break
total=0
for record in generators:total^=int(record['coefficient_hex'],16)
assert total==(1<<116)-1,'Every quartet has three perfect matchings, hence the sum is the symmetric e4.'
report={'n':16,'construction':'For distances a<=b, sum disjoint edge-pair quartic monomials in cyclic distance graphs; identical edge colors use unordered pairs. This is the homogeneous degree4 part of a quadratic-product/divided-square construction.','generators':generators,'dimension':len(basis),'independent_generator_indices':chosen,'full_family_functions':str(1<<len(basis)),'contains_symmetric_e4':True,'scope':'A structured subspace of H(16,4), constructed without imposing conditions necessary only for bentness. PC2 has not yet been tested exhaustively in this family.'}
Path('work/quadratic_product_family.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='generators'})
