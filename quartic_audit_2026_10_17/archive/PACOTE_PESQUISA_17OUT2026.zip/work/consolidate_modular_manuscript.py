from pathlib import Path
import json
out=Path('outputs');normal=json.load(open(out/'T34_FORMA_NORMAL_VERIFICACAO.json'));table='\n'.join('| '+name+' | '+','.join(map(str,indices))+' |' for name,indices in zip(normal['form_order'],normal['forms']))
text='''# Certified periodic integer-ANF obstructions for homogeneous rotation-symmetric quartics in sixteen variables

Consolidated working draft, 17 October 2026. Bibliographic novelty remains unestablished. This text reorganizes the modular results; the separate finite Pareto and spectral-cover results remain in MANUSCRITO_RASCUNHO.md.

## Abstract

We give explicit necessary conditions for bentness in the 116-dimensional space of homogeneous rotation-symmetric quartic Boolean functions on sixteen variables. Six conditions have a normal form in eleven aggregate parities and admit exactly 384 of 512 aggregate patterns, yielding an exact original-space fraction of 3/128. Three further periodic integer-ANF bits are treated jointly through a common quadratic restriction. A vector-character estimate, together with exact radical-zero densities, bounds the remaining fraction by 2097035386883/562949953421312. Thus the nine conditions exclude at least 99.6274916848046% of the original coefficient space. All polynomial coefficients and 4,800 quadratic sums are independently verified. A quotient-compatible subset halves a prepared finite GPU domain to 162,537,472 states; no GPU execution is claimed. The general nonexistence problem remains open.

## 1. Setting and necessary divisibility

Let G_j be the sum of the distinct monomials in a cyclic orbit of squarefree quartic monomials. Order the 116 orbits by the first unseen quartet in lexicographic combination order. Write f=Σ_j c_jG_j. Short orbits are summed once, without repetition.

Let h_f(u) be the coefficient at the squarefree support u in the integer multilinear representation of (−1)^f. The classical integer-ANF criterion for a sixteen-variable bent function implies v₂(h_f(u))>|u|−8 when u is not the full support. In particular, weight-twelve supports require h_f(u) divisible by 32. We use this known criterion, not a new characterization of bentness; see Zhang and Gao [1, Lemma 2.4].

The preceding orbit-code certificates establish three linear laws and the factored conditions summarized below. Their full derivations are in T20_TRES_LEIS_PROVA.md, T26_QUARTA_CONDICAO_QUADRATICA.md, T27_QUINTA_CONDICAO.md, and T31_SETIMA_CONDICAO.md.

## 2. An eleven-parity normal form

Define the following parity forms on the original coefficients. Entries are index sets, and all equations are over F₂.

| form | coefficient indices |
|---|---|
'''+table+'''

Put b=u1+v1, K=u2+v2+u4+v4, M=u3+v3. The six-condition core is

`c115=0, c113=a, c99=b`,

`t=a+Σ_(i=1)^4 u_i v_i`,

`b(a+K)=0`,

`R=(1+b)M+(1+a)K`.

The three laws together with these eleven forms have rank fourteen. Choose the eight u_i,v_i and a; exclude only b=1,a≠K; reconstruct t,R. There are 256 admissible patterns with b=0 and 128 with b=1. Each pattern has 2^102 original coefficient words, hence the exact fraction is 384·2^102/2^116=3/128. This is a count of necessary-condition candidates, not of bent functions.

## 3. Three further periodic bits

At supports 0x3f3f, 0x5f5f, and 0x6f6f, the core conditions ensure divisibility by 16. Bentness requires the next bit P_s=h_f(s)/16 mod2 to vanish. On each affine chart b=0 or b=1, evaluate f plus the parity character on the 2,016 nonfixed pairs of the block swap. Its weight gives the identity

`h_f(s)=B0+4032−4 wt(t_f)`.

The diagonal contribution is 64,16,32,−16 in the four cases (a,b)=(0,0),(0,1),(1,0),(1,1). On the charts, all needed weight and pair-intersection congruences hold. The integer XOR-weight expansion therefore reconstructs the next bit as a cubic polynomial before the core substitutions. All terms of higher order vanish modulo two after division by four. Reconstructing c23 through the fourth condition and c5 through the condition at 0x7777 gives six complete chart polynomials. Their coefficients are fully certified, rather than inferred from random evaluations.

## 4. One vector-character lemma

Let P=(P₁,…,P_m), and let S be a common coordinate set such that no monomial of degree greater than two in any P_i involves two coordinates of S. Every nonzero character combination P_λ is quadratic on S, with a constant polar rank r_λ. Let Z_λ be the density, over the external coordinates, where all radical-direction derivatives of this quadratic slice vanish. Then

`Pr(P=0) ≤ 2^(−m) [1+Σ_(λ≠0) 2^(−r_λ/2) Z_λ]`.

Indeed, expand the indicator of P=0 in characters. A normalized quadratic sum on S vanishes when some radical derivative is one; otherwise its modulus is 2^(−r_λ/2). Bound each character expectation by its average modulus. No logical independence of the derivative equations is assumed.

For m=1 this includes the earlier scalar estimates. Here take m=3 and S={27,64,73,77,88,92,112}. All seven character ranks and all radical derivatives are checked symbolically. The densities Z_λ are computed by character expansion of their common-zero indicator. Conditioning on at most {57,35,61} in the zero chart and {35,61} in the one chart makes every remaining polynomial quadratic.

The certified conditional pass bounds are 1375476686851/8796093022208 and 172033/1048576. The chart measures in the original coefficient space are 1/64 and 1/128. Consequently the overall pass fraction is at most

`2097035386883/562949953421312`.

The exact joint survivor density is not claimed.

## 5. Verification and quotient limitation

VERIFICAR_FORMA_NORMAL_T34.py checks rank fourteen and all 512 aggregate cases. VERIFICAR_POLINOMIOS_T35.py reconstructs 226,930 coefficient terms and checks 192 direct original-ANF evaluations. VERIFICAR_LIMITE_CONJUNTO_T35.py verifies all common restrictions, polar ranks, radical bases, and 4,800 quadratic sums. The generating calculation eliminates pairs in the exponential sum; the independent verifier uses symplectic Gram-Schmidt. The checkers use standard Python.

The prepared GPU quotient records five fibers and has rank thirty-three. The condition from support 0x7777 descends to this quotient and halves its prior finite domain, giving 162,537,472 states. All 111,876 retained parent affine systems were checked on CPU. In contrast, the bit at 0x3f3f alone cannot remove any quotient state: two explicit kernel directions preserve the core and have constant-one mixed derivative on that bit, supplying both values within every state. The additional joint bits have not yet been incorporated into the quotient. CUDA and GPU scanning remain pending.

## 6. Scope and next questions

The quantitative exclusion is a corollary of explicit identities and complete finite certificates. It does not establish nonexistence, and a high exclusion percentage alone is not a publication novelty claim. The next mathematical questions are the exact joint density, further simplification of the periodic code, and whether a suitable enlarged quotient makes the joint filters effective. The complete recent literature must be compared before a submission claim is made.

## Reference

[1] X. Zhang and G. Gao, On the conjecture about the nonexistence of rotation symmetric bent functions, arXiv:1303.2282 (2013). https://arxiv.org/abs/1303.2282
'''
(out/'MANUSCRITO_MODULAR_CONSOLIDADO.md').write_text(text,encoding='utf-8')
(out/'ESTRATEGIA_PUBLICACAO.md').write_text('''# Estratégia de publicação — estado consolidado

A novidade bibliográfica ainda não foi estabelecida. A contribuição deve ser avaliada pelas identidades, pela forma normal, pelo lema de combinação e pelos certificados completos. O percentual de exclusão, isoladamente, não demonstra relevância editorial.

## Linha modular em dezesseis variáveis

O texto principal atual é **MANUSCRITO_MODULAR_CONSOLIDADO.md**. Ele reúne a forma normal em 11 paridades, a contagem de 384 padrões, a reconstrução dos três bits periódicos e um único lema vetorial que contém as estimativas escalares anteriores. A consequência é exclusão rigorosa de pelo menos 99,6274%, com 4.800 somas verificadas por método independente.

O efeito computacional demonstrado é a redução do domínio preparado para A100 a 162.537.472 estados. A limitação também é explícita: a sexta condição sozinha não reduz o quociente, apesar de excluir funções completas. CUDA ainda não foi executada.

Prioridades: confrontar a literatura integral recente; simplificar os códigos periódicos e as densidades radicais; determinar o efeito conjunto no quociente; obter a densidade exata ou um resultado estrutural além de um percentual. A execução A100 é uma aplicação da teoria e não fundamenta as identidades já certificadas.

## Linha finita de fronteiras e certificados

Os resultados exatos em oito e dez variáveis podem formar um trabalho separado: fronteiras de Pareto, igualdades sob um grupo explícito e tamanho mínimo de conjuntos fixos de frequências. O número 17 em dez variáveis tem certificado inferior independente. O rascunho amplo e os dados permanecem preservados.

Prioridades: explicar estruturalmente a cobertura mínima e simplificar o conjunto de testemunhas. A ausência de bent nesses tamanhos não é nova; a novidade a verificar são as fronteiras, as igualdades e a complexidade dos certificados fixos.

## Problemas abertos preservados

C16 global e a inexistência bent global em dezesseis variáveis não foram resolvidas. A enumeração de 268.435.456 funções prova a obstrução PC(2) somente na família estruturada de dimensão 28. Os pilotos SAT e de programação inteira terminaram sem conclusão e não excluíram candidatos.
''',encoding='utf-8')
print('Consolidated modular draft and publication strategy written.')
