import sys,json,math
from collections import Counter
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16)
def rot(u):return ((u<<1)&255)|(u>>7)
def representatives(z,step):
 def action(u):
  zz=z
  for _ in range(step):u=rot(u)^(zz>>7);zz=rot(zz)
  assert zz==z
  return u
 seen=set();out=[];lengths=[]
 for u in range(256):
  if u in seen:continue
  out.append(u);v=u;length=0
  while v not in seen:seen.add(v);length+=1;v=action(v)
  assert v==u;lengths.append(length)
 return out,lengths
report=[]
for z,step in [(255,1),(85,2)]:
 reps,lengths=representatives(z,step);points=np.array([u|((u^z)<<8) for u in reps],dtype=np.uint32);words=[]
 for orb,_ in gs:
  v=np.zeros(len(reps),dtype=np.uint8)
  for monomial in orb:v^=((points&monomial)==monomial)
  words.append(sum(int(b)<<i for i,b in enumerate(v)))
 basis={}
 for word in words:
  v=word
  while v:
   p=v.bit_length()-1
   if p in basis:v^=basis[p]
   else:basis[p]=v;break
 Bs=list(basis.values());weights=Counter();w=0
 for i in range(1<<len(Bs)):
  if i:w^=Bs[(i&-i).bit_length()-1]
  weights[w.bit_count()]+=1
 gcd=0
 for wt in weights:gcd=math.gcd(gcd,wt)
 rec={'z':z,'rotation_step':step,'representatives':reps,'orbit_lengths':lengths,'generator_words_hex':[hex(w) for w in words],'generator_weights':[w.bit_count() for w in words],'all_generator_weights_even':all(w.bit_count()%2==0 for w in words),'image_rank':len(Bs),'image_weight_enumerator':dict(sorted(weights.items())),'all_code_weights_divisor':gcd,'guaranteed_A_divisor':math.gcd(256,2*lengths[0]*gcd)}
 report.append(rec);print({k:v for k,v in rec.items() if k not in ['representatives','orbit_lengths','generator_words_hex','generator_weights']},flush=True)
open('work/fiber_code_certificate.json','w').write(json.dumps(report,indent=2))
