"""Test simultaneous Poisson and low-weight homogeneity equations.
Only integer-checked witnesses are classified feasible. Solver infeasibility
without an independently checked certificate remains an unproved indication.
"""
import sys,json,time
from pathlib import Path
sys.path.insert(0,'work/deps_local')
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import csc_array
data=np.load('work/dual_model.npz');M=data['poisson_matrix'].astype(np.int64);A=data['low_weight_matrix'].astype(np.int64)
B=np.vstack([M,A]);sums=B.sum(axis=1);sparse=csc_array(B.astype(float));N=B.shape[1]
def solve(label,rhs,limit,fixed=None):
 start=time.perf_counter();rhs=np.asarray(rhs,dtype=np.int64)
 assert np.all((sums-rhs)%2==0)
 target=(sums-rhs)//2
 bounds=Bounds(np.zeros(N),np.ones(N)) if fixed is None else Bounds(fixed,fixed)
 result=milp(np.zeros(N),integrality=np.ones(N),bounds=bounds,constraints=LinearConstraint(sparse,target,target),options={'time_limit':limit,'mip_rel_gap':0.0})
 record={'label':label,'status':int(result.status),'message':result.message,'seconds':time.perf_counter()-start,'integer_solution_verified':False}
 if result.x is not None:
  rounded=np.rint(result.x).astype(np.int64)
  if np.all((rounded==0)|(rounded==1)) and np.array_equal(B@rounded,target):
   signs=1-2*rounded;assert np.array_equal(B@signs,rhs)
   record['integer_solution_verified']=True;record['classification']='FEASIBLE_NECESSARY_CONDITIONS_ONLY'
   np.savez_compressed(f'work/dual_solution_{label}.npz',signs=signs,rhs=rhs,target=target)
  else:record['classification']='UNVERIFIED_NUMERICAL_SOLUTION'
 else:record['classification']='INFEASIBILITY_INDICATION_WITHOUT_CERTIFICATE' if result.status==2 else 'INCONCLUSIVE'
 print(record,flush=True)
 return record
records=[]
control_rhs=np.r_[data['control_poisson_rhs'],data['control_low_weight_rhs']]
control_signs=data['control_dual_signs'].astype(np.int64);assert np.array_equal(B@control_signs,control_rhs)
records.append(solve('positive_control_fixed',control_rhs,10,(1-control_signs)//2))
for j in [0,1,2,3,16,64,128,255]:
 rhs=np.r_[data['sample_poisson_rhs'][j],data['low_weight_rhs']]
 rec=solve(f'sample_{j}',rhs,30)
 rec['extension_id']=int(data['sample_extension_ids'][j]);records.append(rec)
 report={'poisson_rows':len(M),'new_homogeneity_rows':len(A),'sign_variables':N,'sampled_extensions':len(records)-1,'distinct_sampled_parents':1,'records':records,'scope':'Simultaneous necessary conditions on the saved sample from one parent. Feasibility does not certify bentness; timeouts do not exclude candidates; numerical infeasibility is not a proof.'}
 Path('work/dual_homogeneity_milp_report.json').write_text(json.dumps(report,indent=2))
