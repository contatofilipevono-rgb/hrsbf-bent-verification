"""Exact Walsh/autocorrelation trade-offs on the entire quartic RS space."""
import sys,json,time,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks,rotations
def fwht(v):
 for k in range(v.size.bit_length()-1):
  vv=v.reshape(-1,2,1<<k);a=vv[:,0,:].copy();b=vv[:,1,:].copy()
  vv[:,0,:]=a+b;vv[:,1,:]=a-b
 return v
def run(n):
 start=time.perf_counter();gs,even,masks=setup(n);N=1<<len(gs)
 x=np.arange(1<<n,dtype=np.uint32);sig=np.zeros(1<<n,dtype=np.uint32)
 for j,(_,word) in enumerate(gs):
  sig|=np.unpackbits(np.frombuffer(word.to_bytes((1<<n)//8,'little'),dtype=np.uint8),bitorder='little').astype(np.uint32)<<j
 dirs=[1]+[1|(1<<d) for d in range(1,n//2+1)]
 weights=np.array([n]* (n//2)+[n//2],dtype=np.int64)
 C=np.stack([fwht(np.bincount(sig^sig[x^a],minlength=N).astype(np.int32)) for a in dirs])
 Q=np.sum(C.astype(np.int64)**2*weights[:,None],axis=0)
 M=np.abs(C).max(axis=0);maxwalsh=np.zeros(N,dtype=np.int32);parseval=np.zeros(N,dtype=np.int64)
 seen=set();frequencies=[]
 for s in range(1<<n):
  if s in seen:continue
  orb=rotations(s,n);seen.update(orb);frequencies.append((s,len(orb)))
 for j,(s,multiplicity) in enumerate(frequencies):
  sign=1-2*(np.bitwise_count(x&np.uint32(s))%2).astype(np.int32)
  v=np.zeros(N,dtype=np.int32);np.add.at(v,sig,sign);fwht(v)
  np.maximum(maxwalsh,np.abs(v),out=maxwalsh)
  parseval+=multiplicity*v.astype(np.int64)**2
  if j%16==0:print('WALSH',n,j,'of',len(frequencies),flush=True)
 assert np.all(parseval==(1<<(2*n)))
 nl=(1<<(n-1))-maxwalsh//2
 rows=[];direct_checks=[0]
 def example(c):
  direct_checks[0]+=1
  c=int(c);truth=np.zeros(1<<n,dtype=np.uint8)
  for j,(orb,_) in enumerate(gs):
   if c>>j&1:
    for monomial in orb:truth^=((x&monomial)==monomial)
  ac=[int(np.sum(1-2*(truth^truth[x^a]).astype(np.int32))) for a in dirs]
  w=fwht(1-2*truth.astype(np.int32));mx=int(np.abs(w).max())
  assert ac==C[:,c].tolist();assert mx==int(maxwalsh[c])
  return {'coefficients_hex':hex(c),'correlations':ac,'nonlinearity':int(nl[c]),'max_abs_walsh':mx}
 for value in np.unique(nl):
  ix=np.flatnonzero(nl==value);qm=int(Q[ix].min());mm=int(M[ix].min())
  qi=ix[Q[ix]==qm];mi=ix[M[ix]==mm]
  rows.append({'nonlinearity':int(value),'functions':len(ix),'min_Q2':qm,'Q2_attainers':len(qi),'Q2_examples':[example(c) for c in qi[:4]],'min_M2':mm,'M2_attainers':len(mi),'M2_examples':[example(c) for c in mi[:4]]})
 frontier=[];best=10**30
 for r in sorted(rows,key=lambda r:r['nonlinearity'],reverse=True):
  if r['min_Q2']<best:frontier.append(r);best=r['min_Q2']
 rng=np.random.default_rng(20261016103+n)
 for c in rng.integers(0,N,size=64):example(c)
 report={'n':n,'orbit_dimension':len(gs),'complete_functions':N,'walsh_frequency_orbits':len(frequencies),'directions':dirs,'direction_multiplicities':weights.tolist(),'max_nonlinearity':int(nl.max()),'max_nonlinearity_count':int(np.count_nonzero(nl==nl.max())),'min_Q2':int(Q.min()),'rows':rows,'pareto_frontier_Q2_vs_NL':frontier,'all_coefficient_parseval_pass':True,'independent_direct_ANF_checks':direct_checks[0],'seconds':time.perf_counter()-start,'scope':'Exhaustive over the full coefficient space; functions are not identified under equivalence.'}
 Path(f'work/pareto_n{n}.json').write_text(json.dumps(report,indent=2))
 np.savez_compressed(f'work/pareto_n{n}.npz',nonlinearity=nl,Q2=Q,M2=M)
 print('DONE',n,report['max_nonlinearity'],report['max_nonlinearity_count'],[(r['nonlinearity'],r['min_Q2']) for r in frontier],report['seconds'],flush=True)
for n in [8,10]:run(n)
