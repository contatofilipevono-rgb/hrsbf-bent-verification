"""Full independent Gray enumeration using packed truth tables, not FWHT in coefficient space."""
import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks,rotations
for n in [8,10]:
 start=time.perf_counter();gs,even,masks=setup(n);x=np.arange(1<<n,dtype=np.uint32)
 seen=set();characters=[]
 for s in range(1<<n):
  if s in seen:continue
  seen.update(rotations(s,n));bits=np.bitwise_count(x&np.uint32(s))%2
  characters.append(int.from_bytes(np.packbits(bits,bitorder='little').tobytes(),'little'))
 expected=np.load(f'work/pareto_n{n}.npz');NL=expected['nonlinearity'];Q=expected['Q2'];M=expected['M2']
 tt=0;c=0;N=1<<len(gs);direction_weights=[n]*(n//2)+[n//2]
 for i in range(N):
  if i:
   bit=(i&-i).bit_length()-1;tt^=gs[bit][1];c^=1<<bit
  ac=list(checks(tt,n,even,masks))
  q=sum(w*v*v for w,v in zip(direction_weights,ac));m=max(map(abs,ac))
  assert q==int(Q[c]) and m==int(M[c]),('AC',n,c)
  mx=max(abs((1<<n)-2*(tt^character).bit_count()) for character in characters)
  assert (1<<(n-1))-mx//2==int(NL[c]),('NL',n,c)
  if i and i%262144==0:print('GRAY',n,i,'/',N,round(time.perf_counter()-start,2),flush=True)
 report={'n':n,'functions_checked':N,'all_saved_nonlinearities_agree':True,'all_saved_Q2_agree':True,'all_saved_M2_agree':True,'method':'Gray coefficient enumeration; packed truth-table XOR updates; Walsh by direct Hamming weights against linear characters; autocorrelations by direct differences.','seconds':time.perf_counter()-start}
 Path(f'work/pareto_gray_verification_n{n}.json').write_text(json.dumps(report,indent=2))
 print('DONE',report,flush=True)
