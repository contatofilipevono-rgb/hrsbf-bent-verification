import json,time
from collections import Counter
from pathlib import Path
data=json.load(open('work/T28_branch_reports.json'));directions=json.load(open('work/T28_balancing_translations.json'));reports=[];start=time.perf_counter()
def toggle(p,m):
 if m in p:p.remove(m)
 else:p.add(m)
for rec,dr in zip(data['branches'],directions):
 Q={int(m,16) for m in dr['branch_fourth_polynomial_hex']};assert (1<<23) in Q and not any(m>>23&1 for m in Q if m.bit_count()>1)
 Q.remove(1<<23);P={int(m,16) for m in rec['monomials_hex']};reduced=set()
 for m in P:
  if not(m>>23&1):toggle(reduced,m)
  else:
   other=m^(1<<23)
   for n in Q:toggle(reduced,other|n)
 linear=[m.bit_length()-1 for m in reduced if m.bit_count()==1];nonlinear=0
 for m in reduced:
  if m.bit_count()>1:nonlinear|=m
 report={'branch':rec['branch_c99'],'free_dimension_after_fourth':len(rec['free_indices'])-1,'eliminated_variable':23,'monomials':len(reduced),'degree_histogram':dict(Counter(m.bit_count() for m in reduced)),'constant':0 in reduced,'isolated_linear_variables':[j for j in linear if not(nonlinear>>j&1)],'polynomial_hex':[hex(m) for m in sorted(reduced)]}
 reports.append(report);print({k:v for k,v in report.items() if k!='polynomial_hex'})
Path('work/T28_after_all_five.json').write_text(json.dumps({'branches':reports,'seconds':time.perf_counter()-start},indent=2))
