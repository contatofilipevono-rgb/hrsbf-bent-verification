import json
from fractions import Fraction
from pathlib import Path
data=json.load(open('work/T28_radical_polynomials.json'));restrictions=json.load(open('work/T28_exact_restriction_rank.json'));reports=[]
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def bias(P):
 P=set(P);pairs=0
 while any(m.bit_count()==2 for m in P):
  edge=next(m for m in P if m.bit_count()==2);i=edge&-edge;j=edge^i
  A={m^i for m in P if m&i and not m&j};B={m^j for m in P if m&j and not m&i};R={m for m in P if not m&(i|j)}
  assert all(m.bit_count()<=1 for m in A|B)
  for a in A:
   for b in B:toggle(R,a|b)
  P=R;pairs+=1
 if any(m.bit_count()==1 for m in P):return Fraction(0),pairs,True
 return Fraction(-1 if 0 in P else 1,2**pairs),pairs,False
total=Fraction(0)
for rec,restriction in zip(data,restrictions):
 D=[{int(m,16) for m in row} for row in rec['polynomials_hex']];n=len(D);records=[];summation=Fraction(0)
 for choice in range(1<<n):
  P=set()
  for j,row in enumerate(D):
   if choice>>j&1:P^=row
  assert all(m.bit_count()<=2 for m in P)
  value,pairs,balanced=bias(P);summation+=value
  records.append({'combination':choice,'bias':[value.numerator,value.denominator],'eliminated_pairs':pairs,'residual_linear':balanced})
 zero=summation/2**n;r=restriction['polar_rank'];upper=Fraction(1,2)+zero/Fraction(2**(r//2+1));measure=Fraction(1,32 if rec['branch']==0 else 64);total+=measure*upper
 report={'branch':rec['branch'],'radical_dimension':n,'radical_zero_fraction':[zero.numerator,zero.denominator],'branch_pass_fraction_upper_bound':[upper.numerator,upper.denominator],'quadratic_biases':records};reports.append(report);print({k:v for k,v in report.items() if k!='quadratic_biases'},float(upper),flush=True)
excluded=1-total;report={'branches':reports,'global_pass_fraction_upper_bound':[total.numerator,total.denominator],'global_excluded_fraction_lower_bound':[excluded.numerator,excluded.denominator],'excluded_percent_lower_bound':float(excluded*100),'scope':'Exact common-zero density of quadratic radical derivatives; uniform bound on remaining quadratic slices, not exact full sixth-condition density.'};print('TOTAL',report['global_pass_fraction_upper_bound'],report['global_excluded_fraction_lower_bound'],report['excluded_percent_lower_bound']);Path('work/T28_exact_radical_density.json').write_text(json.dumps(report,indent=2))
