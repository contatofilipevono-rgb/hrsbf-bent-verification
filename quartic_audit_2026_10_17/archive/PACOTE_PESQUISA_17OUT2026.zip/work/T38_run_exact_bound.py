from pathlib import Path
import subprocess,sys
src=Path('work/T35_joint_exact_bound.py').read_text(encoding='utf-8').replace('work/T35_joint_radicals.json','work/T38_joint_radicals.json').replace('work/T35_joint_exact_bound.json','work/T38_joint_exact_bound.json').replace('upper/=8','upper/=16')
Path('work/T38_joint_exact_bound.py').write_text(src,encoding='utf-8');subprocess.run([sys.executable,'work/T38_joint_exact_bound.py'],check=True)
