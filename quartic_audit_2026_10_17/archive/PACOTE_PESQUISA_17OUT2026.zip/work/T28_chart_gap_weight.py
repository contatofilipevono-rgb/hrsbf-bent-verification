import json
from pathlib import Path
data=json.load(open('work/T28_chart_comparison.json'))
P={int(m,16) for m in data['A_xor_B']['polynomial_hex']};N=110;pairs=0;free=set(range(116))-{0,23,57,99,113,115}
def toggle(p,m):
 if m in p:p.remove(m)
 else:p.add(m)
while any(m.bit_count()==2 for m in P):
 edge=next(m for m in P if m.bit_count()==2);i=edge&-edge;j=edge^i
 A={m^i for m in P if m&i and not m&j};B={m^j for m in P if m&j and not m&i}
 R={m for m in P if not m&(i|j)}
 for a in A:
  for b in B:toggle(R,a|b)
 P=R;pairs+=1;free.remove(i.bit_length()-1);free.remove(j.bit_length()-1)
if any(m.bit_count()==1 for m in P):bias=0;num=1;den=2
else:
 bias=(-1 if 0 in P else 1);den=2**(pairs+1);num=2**pairs-bias
report={'gap':'A xor B','quadratic_eliminated_pairs':pairs,'residual_linear':any(m.bit_count()==1 for m in P),'residual_constant':0 in P,'ones_fraction_numerator':num,'ones_fraction_denominator':den,'bound_reason':'Whenever A xor B=1, at least one of charts A,B violates the sixth condition. Each chart has original-space measure 1/64.','global_candidate_fraction_upper_bound_numerator':3*den-num,'global_candidate_fraction_upper_bound_denominator':64*den}
print(report);Path('work/T28_chart_gap_weight.json').write_text(json.dumps(report,indent=2))
