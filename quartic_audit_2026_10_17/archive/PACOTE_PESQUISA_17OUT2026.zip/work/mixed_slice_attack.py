import sys,json,time,random
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks
import numpy as np
n=int(sys.argv[1]) if len(sys.argv)>1 else 16
blocks=int(sys.argv[2]) if len(sys.argv)>2 else 64
gs,even,masks=setup(n);N=len(gs);dim=22
random_seed=20261016102 if n==16 else 20261017111
rng=random.Random(random_seed)
x=np.arange(1<<n,dtype=np.uint32);half=x[x%2==0]
truth=np.stack([np.unpackbits(np.frombuffer(w.to_bytes((1<<n)//8,'little'),dtype=np.uint8),bitorder='little') for _,w in gs])
dirs=[1]+[1|(1<<d) for d in range(1,n//2+1)]
sig=[truth[:,half]^truth[:,half^a] for a in dirs]
seed=int('994c638324480fb7e20526b4c174e' if n==16 else '3573f66ba26',16)
tt=0
for j,(_,w) in enumerate(gs):
 if seed>>j&1:tt^=w
vals=list(checks(tt,n,even,masks));best=sum(v*v for v in vals)
winner={'coefficient_hex':hex(seed),'energy':best,'correlations':vals}
pool=[seed];records=[];start=time.perf_counter()
for block in range(blocks):
 parent=pool[rng.randrange(len(pool))] if block%3 else seed
 # Unique pivot variables guarantee independence, while nonpivot variables
 # provide mixed directions absent from the previous coordinate searches.
 pivots=rng.sample(range(N),dim);rest=sorted(set(range(N))-set(pivots))
 hs=[]
 for p in pivots:
  degree=2+block%3
  hs.append((1<<p)^sum(1<<j for j in rng.sample(rest,degree-1)))
 E=np.zeros(1<<dim,dtype=np.int64);C=[]
 active=[j for j in range(N) if parent>>j&1]
 for lam in sig:
  signs=2-4*np.bitwise_xor.reduce(lam[active],axis=0).astype(np.int32)
  projected=np.zeros(len(half),dtype=np.uint32)
  for k,h in enumerate(hs):
   cols=[j for j in range(N) if h>>j&1]
   projected|=np.bitwise_xor.reduce(lam[cols],axis=0).astype(np.uint32)<<k
  v=np.bincount(projected,weights=signs,minlength=1<<dim).astype(np.int32)
  for k in range(dim):
   vv=v.reshape(-1,2,1<<k);a=vv[:,0,:].copy();b=vv[:,1,:].copy();vv[:,0,:]=a+b;vv[:,1,:]=a-b
  E+=v.astype(np.int64)**2;C.append(v)
 inds=np.argpartition(E,15)[:16];inds=inds[np.argsort(E[inds])]
 candidates=[]
 for s in inds:
  c=parent
  for k,h in enumerate(hs):
   if int(s)>>k&1:c^=h
  candidates.append(c)
  if int(E[s])<best:
   vals=[int(v[s]) for v in C];tt=0
   for j,(_,w) in enumerate(gs):
    if c>>j&1:tt^=w
   assert vals==list(checks(tt,n,even,masks))
   best=int(E[s]);seed=c;winner={'coefficient_hex':hex(c),'energy':best,'correlations':vals}
   print('BEST',block,winner,flush=True)
 pool=list(dict.fromkeys(candidates+pool))[:64]
 records.append({'block':block,'base':hex(parent),'basis_hex':[hex(h) for h in hs],'minimum_energy':int(E[inds[0]])})
 report={'n':n,'dimension':dim,'slices':len(records),'evaluations_with_possible_overlap':len(records)*(1<<dim),'best':winner,'global_lower_bound_proven':False,'seed':random_seed,'seconds':time.perf_counter()-start,'records':records}
 output='work/mixed_slice_attack.json' if n==16 else f'work/mixed_slice_attack_n{n}.json'
 open(output,'w').write(json.dumps(report,indent=2))
 print('SLICE',block,'min',int(E[inds[0]]),'best',best,'seconds',round(report['seconds'],2),flush=True)
 if best==0:break
