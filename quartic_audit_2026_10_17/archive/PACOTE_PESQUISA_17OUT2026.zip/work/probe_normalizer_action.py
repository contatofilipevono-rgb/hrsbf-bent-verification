import json
from pathlib import Path
from itertools import combinations
import numpy as np
seen=set();orbits=[];index={}
for T in combinations(range(16),4):
 m=sum(1<<j for j in T)
 if m in seen:continue
 orb=set();r=m
 for _ in range(16):orb.add(r);r=((r<<1)&65535)|(r>>15)
 seen|=orb
 for v in orb:index[v]=len(orbits)
 orbits.append(orb)
def permute(x,k):return sum(((x>>i)&1)<<((k*i)%16) for i in range(16))
def rotations(x):
 out=set()
 for _ in range(16):out.add(x);x=((x<<1)&65535)|(x>>15)
 return out
seven=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));factor=json.load(open('work/post_T20_quadratic_factored.json'));data=np.load('work/anf_cubic_obstructions.npz');supports=[0x3f3f,0x5f5f,0x6f6f,0x33ff,0x66ff,0x73bf,0x76ef];reports=[]
for k in range(1,16,2):
 coefficient_permutation=[index[permute(min(orb),k)] for orb in orbits]
 support_permutation=[]
 for u in supports:
  target=rotations(permute(u,k));matches=[j for j,v in enumerate(supports) if v in target];assert len(matches)==1;support_permutation.append(matches[0])
 record={'unit':k,'coefficient_permutation':coefficient_permutation,'support_permutation':support_permutation,'a_image':coefficient_permutation[57],'b_image':coefficient_permutation[99],'113_image':coefficient_permutation[113],'115_image':coefficient_permutation[115]};reports.append(record);print({key:v for key,v in record.items() if key!='coefficient_permutation'})
unseen=set(range(1,128));char_orbits=[]
while unseen:
 c=min(unseen);orbit={sum(((c>>i)&1)<<perm['support_permutation'][i] for i in range(7)) for perm in reports};assert orbit<=set(range(1,128));unseen-=orbit;char_orbits.append(sorted(orbit))
print('character orbits',len(char_orbits),'sizes',[len(o) for o in char_orbits]);Path('work/T40_normalizer_action.json').write_text(json.dumps({'supports':[hex(u) for u in supports],'actions':reports,'character_orbits':char_orbits},indent=2))
