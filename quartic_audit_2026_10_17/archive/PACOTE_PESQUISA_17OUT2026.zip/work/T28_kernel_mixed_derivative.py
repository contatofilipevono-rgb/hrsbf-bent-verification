import json
from pathlib import Path
data=json.load(open('work/T28_after_all_five.json'));audit=json.load(open('work/T28_fiber_descent_audit.json'));reports=[]
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
for rec,ar in zip(data['branches'],audit['branches']):
 P={int(m,16) for m in rec['polynomial_hex']};b=rec['branch'];excluded={0,23,99,113,115}|({57} if b else set());mask=sum(1<<j for j in range(116) if j not in excluded);witness=None;checked=0
 for item in ar['nonzero_derivatives']:
  if item['degree']!=2:continue
  d=int(item['kernel_direction_hex'],16);D=derivative(P,d&mask)
  for item2 in ar['nonzero_derivatives']:
   e=int(item2['kernel_direction_hex'],16);checked+=1
   if derivative(D,e&mask)=={0}:witness={'original_direction_d_hex':hex(d),'original_direction_e_hex':hex(e),'free_direction_d_hex':hex(d&mask),'free_direction_e_hex':hex(e&mask)};break
  if witness:break
 report={'branch':b,'kernel_pairs_checked':checked,'constant_one_second_derivative_witness':witness};reports.append(report);print(report,flush=True)
Path('work/T28_kernel_mixed_derivative.json').write_text(json.dumps(reports,indent=2))
