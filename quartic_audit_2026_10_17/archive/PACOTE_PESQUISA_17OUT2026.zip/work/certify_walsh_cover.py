import sys,json,time,threading
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/deps_local');sys.path.insert(0,'work/recovered')
from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
from test_short_witness import setup,rotations
start=time.perf_counter();r=json.load(open('work/optimized_walsh_cover_n10.json'));clauses=r['final_hard_clauses'];cache=np.load('work/walsh_cover_cache_n10.npz');freq=cache['frequency'];bound=r['exact_global_minimum']-1
core=clauses
proof=None
for encoding in [EncType.cardnetwrk,EncType.seqcounter,EncType.totalizer]:
 card=CardEnc.atmost(lits=list(range(1,109)),bound=bound,top_id=108,encoding=encoding)
 cnf=card.clauses+core
 with Solver(name='g4',bootstrap_with=cnf,with_proof=True) as solver:
  timer=threading.Timer(60,solver.interrupt);timer.start()
  result=solver.solve_limited(expect_interrupt=True);timer.cancel()
  print('SOLVER',encoding,'result',result,'seconds',time.perf_counter()-start,flush=True)
  if result is False:proof=solver.get_proof();break
assert proof,'No proof within the allotted solver attempts; lower-bound certification remains unresolved.'
Path('work/walsh_cover_lower_bound.cnf').write_text(f'p cnf {card.nv} {len(cnf)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in cnf))
Path('work/walsh_cover_lower_bound.drup').write_text('\n'.join(proof)+'\n')
# Independently check every added proof clause by reverse unit propagation.
# Deleted clauses can be retained: all previously verified clauses are logical
# consequences, so retaining them preserves soundness of the final conclusion.
checked=0;empty=False
with Solver(name='m22',bootstrap_with=cnf) as checker:
 for line in proof:
  if line.startswith('d '):continue
  clause=list(map(int,line.split()))
  assert clause[-1]==0;clause=clause[:-1]
  status,_=checker.propagate(assumptions=[-lit for lit in clause])
  assert status is False,('Non-RUP proof clause',checked,line)
  checker.add_clause(clause);checked+=1
  if not clause:empty=True
 assert empty
# Recompute all Walsh frequencies directly on every core witness, without
# trusting the precomputed cover bitsets or coefficient-space transform.
gs,_,_=setup(10);x=np.arange(1024,dtype=np.uint32);witnesses=[]
for clause in core:
 key=str(tuple(clause));c=int(r['lower_bound_witnesses'][key],16);tt=np.zeros(1024,dtype=np.uint8)
 for j,(orb,_) in enumerate(gs):
  if c>>j&1:
   for term in orb:tt^=((x&term)==term)
 w=1-2*tt.astype(np.int32)
 for k in range(10):
  vv=w.reshape(-1,2,1<<k);a=vv[:,0,:].copy();b=vv[:,1,:].copy();vv[:,0,:]=a+b;vv[:,1,:]=a-b
 actual=[j+1 for j,s in enumerate(freq) if abs(int(w[s]))>=64]
 assert actual==clause,(hex(c),actual,clause)
 witnesses.append({'coefficients_hex':hex(c),'frequency_options':[int(freq[j-1]) for j in clause],'max_abs_walsh':int(np.abs(w).max())})
report={'n':10,'threshold':64,'exact_minimum':r['exact_global_minimum'],'cover':r['cover'],'lower_bound_at_most':bound,'lower_bound_witness_functions':len(core),'deletion_minimal_witness_set':False,'proof_format':'DRUP','proof_clauses_RUP_checked_with_independent_solver':checked,'empty_clause_verified':empty,'all_witness_frequency_options_directly_recomputed':True,'upper_bound_all_functions_verified':4194304,'seconds':time.perf_counter()-start,'witnesses':witnesses}
Path('work/walsh_cover_minimum_certificate.json').write_text(json.dumps(report,indent=2))
print({k:v for k,v in report.items() if k!='witnesses'},flush=True)
