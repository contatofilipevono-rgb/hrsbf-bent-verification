import json,time
from pathlib import Path
from collections import Counter
raw=json.load(open('outputs/T37_NOVA_CONDICAO_CERTIFICADO.json'));seven=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));Q4=json.load(open('work/T28_balancing_translations.json'));base=json.load(open('work/T32_combined_models.json'));reports=[];start=time.perf_counter()
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def substitute(P,j,Q):
 out=set()
 for m in P:
  if m>>j&1:
   for n in Q:toggle(out,(m^(1<<j))|n)
  else:toggle(out,m)
 return out
for branch in range(2):
 P={int(m,16) for m in raw['polynomial_after_three_laws_hex']};C={1<<j for j in seven['L'] if j!=0}
 if branch:C.add(0)
 P=substitute(P,0,C)
 if branch:P=substitute(P,57,{1<<j for j in seven['K']})
 Q={int(m,16) for m in Q4[branch]['branch_fourth_polynomial_hex']};Q.remove(1<<23);P=substitute(P,23,Q)
 G={1<<j for j in seven['R']}
 if not branch:
  for j in seven['M']+seven['K']:toggle(G,1<<j)
  for j in seven['K']:toggle(G,(1<<57)|(1<<j))
 G.remove(1<<5);P=substitute(P,5,G)
 nonlinear=0
 for m in P:
  if m.bit_count()>1:nonlinear|=m
 isolated=sorted(m.bit_length()-1 for m in P if m.bit_count()==1 and not m&nonlinear)
 report={'support_mask':'0x33ff','branch':branch,'terms':len(P),'degree_histogram':dict(Counter(m.bit_count() for m in P)),'isolated_linear_variables':isolated,'polynomial_hex':[hex(m) for m in sorted(P)]};reports.append(report);print({k:v for k,v in report.items() if k!='polynomial_hex'},flush=True)
Path('work/T38_new_normalized_models.json').write_text(json.dumps(reports,indent=2));Path('work/T38_all_four_models.json').write_text(json.dumps(base+reports,indent=2));print('seconds',time.perf_counter()-start)
