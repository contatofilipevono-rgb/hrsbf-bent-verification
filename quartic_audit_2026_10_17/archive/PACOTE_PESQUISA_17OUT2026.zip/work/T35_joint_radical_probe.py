import json
from pathlib import Path
from collections import Counter
data=json.load(open('work/T32_combined_models.json'));restrictions=json.load(open('work/T35_joint_restrictions.json'));reports=[]
def nullspace(rows,n):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in range(n):
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
for rec in restrictions:
 if len(rec['supports'])!=3:continue
 S=rec['coordinates'];mask=sum(1<<j for j in S);polys=[{int(m,16) for m in next(r for r in data if r['branch']==rec['branch'] and r['support_mask']==s)['polynomial_hex']} for s in rec['supports']];results=[]
 for choice in range(1,8):
  P=set()
  for i,poly in enumerate(polys):
   if choice>>i&1:P^=poly
  assert all((m&mask).bit_count()<=1 for m in P if m.bit_count()>2)
  polar=[sum((((1<<i)|(1<<j)) in P)<<k for k,j in enumerate(S) if i!=j) for i in S];R=nullspace(polar,len(S));D=[derivative(P,sum(((d>>i)&1)<<j for i,j in enumerate(S))) for d in R];assert all(all(not m&mask for m in row) for row in D)
  higher={m for row in D for m in row if m.bit_count()>2};conditioned=[];remaining=higher
  while remaining and len(conditioned)<8:
   counts=Counter(j for m in remaining for j in range(116) if m>>j&1);j=counts.most_common(1)[0][0];conditioned.append(j);remaining={m&~sum(1<<k for k in conditioned) for m in higher if (m&~sum(1<<k for k in conditioned)).bit_count()>2}
  result={'combination':choice,'polar_rank':len(S)-len(R),'radical_dimension':len(R),'derivative_degree_histograms':[dict(Counter(m.bit_count() for m in row)) for row in D],'conditioning_coordinates':conditioned,'quadratic_after_conditioning':not remaining,'directions_hex':[hex(sum(((d>>i)&1)<<j for i,j in enumerate(S))) for d in R],'polynomials_hex':[[hex(m) for m in sorted(row)] for row in D]};results.append(result);print(rec['branch'],choice,'radical',len(R),'conditioning',conditioned,'sufficient',not remaining,flush=True)
 reports.append({'branch':rec['branch'],'supports':rec['supports'],'coordinates':S,'combinations':results})
Path('work/T35_joint_radicals.json').write_text(json.dumps(reports,indent=2))
