import json
from pathlib import Path
from itertools import combinations
data=json.load(open('work/T35_global_5f.json'));P={int(m,16) for m in data['polynomial_hex']};free=sorted(set(range(116))-{99,113,115})
def nullspace(rows,variables):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in variables:
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
contractions={}
for m in P:
 if m.bit_count()==3:
  for j in free:
   if m>>j&1:contractions[m^(1<<j)]=contractions.get(m^(1<<j),0)^(1<<j)
radical=nullspace(contractions.values(),free);D=[derivative(P,d) for d in radical];assert all(all(m.bit_count()<=1 for m in row) for row in D)
factor=json.load(open('work/post_T20_quadratic_factored.json'));seventh=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));Lmask=sum(1<<j for j in seventh['L'])
forms=[side for block in factor['products'] for side in [block['I'],block['J']]]+[[57],[23,31,39,112],seventh['R']]
original=[d^(((d>>57)&1)<<113)^(((d&Lmask).bit_count()%2)<<99) for d in radical]
agg_changes=[sum(((d&sum(1<<j for j in group)).bit_count()%2)<<i for i,group in enumerate(forms)) for d in original]
rows=[sum(((v>>j)&1)<<i for i,v in enumerate(agg_changes)) for j in range(11)]
kernel_combos=nullspace(rows,list(range(len(radical))));results=[]
for combo in kernel_combos:
 direction=0
 for i,d in enumerate(radical):
  if combo>>i&1:direction^=d
 der=derivative(P,direction);results.append({'free_direction_hex':hex(direction),'derivative_polynomial_hex':[hex(m) for m in sorted(der)]})
report={'cubic_polar_radical_dimension':len(radical),'radical_directions_hex':[hex(d) for d in radical],'affine_derivatives_hex':[[hex(m) for m in sorted(row)] for row in D],'aggregate_changes_hex':[hex(v) for v in agg_changes],'directions_preserving_all_eleven_aggregates':results}
Path('work/T35_affine_derivatives.json').write_text(json.dumps(report,indent=2));print(report)
