import sys,json,math
from pathlib import Path
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16);index={m:j for j,(orb,_) in enumerate(gs) for m in orb};units=[1,3,5,7,9,11,13,15]
records=json.load(open('work/fiber_code_certificate.json'));weights=[r['generator_weights'] for r in records]
remaining=set(range(116));classes=[]
while remaining:
 j=min(remaining);members=set()
 for k in units:
  mask=sum(1<<((k*i)%16) for i in range(16) if gs[j][0][0]>>i&1);members.add(index[mask])
 remaining-=members
 assert all(weights[0][q]==weights[0][j] and weights[1][q]==weights[1][j] for q in members)
 classes.append({'representative_index':j,'support':[i for i in range(16) if gs[j][0][0]>>i&1],'members':sorted(members),'number_of_orbit_generators':len(members),'weight_on_16_complementary_orbits':weights[0][j],'weight_on_32_alternating_orbits':weights[1][j]})
assert sum(len(c['members']) for c in classes)==116
Path('work/fiber_normalizer_classes.json').write_text(json.dumps(classes,indent=2))
lines=['# Tabela reduzida das identidades de paridade nas fibras','',f'Os 116 geradores quárticos cíclicos dividem-se em {len(classes)} classes sob os multiplicadores ímpares módulo 16. A tabela cobre todos os geradores.','',
'O multiplicador x_i↦x_(ki mod 16), k ímpar, preserva as fibras x_(i+8)=x_i+1 e x_(i+8)=x_i+1_(i par), pois preserva tanto a antipodalidade quanto a paridade dos índices. Ele normaliza os grupos de rotações que agem nessas fibras. Portanto permuta as órbitas dessas ações e preserva o peso do vetor de valores de cada gerador nas representantes.','',
'As duas colunas finais são contagens inteiras, reconstruídas a partir dos monômios. A primeira é sempre par e a segunda é sempre múltipla de quatro. A paridade de ambas já basta à prova das duas leis.','',
'| Índice | Suporte representante | Geradores na classe | Peso na fibra 255 | Peso na fibra 85 |','|---:|---|---:|---:|---:|']
for c in classes:lines.append(f"| {c['representative_index']} | {c['support']} | {c['number_of_orbit_generators']} | {c['weight_on_16_complementary_orbits']} | {c['weight_on_32_alternating_orbits']} |")
Path('outputs/T20_TABELA_PARIDADES.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('CLASSES',len(classes))
