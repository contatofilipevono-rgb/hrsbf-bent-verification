import json
from pathlib import Path
import numpy as np
action=json.load(open('work/T40_normalizer_action.json'));seven=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));factor=json.load(open('work/post_T20_quadratic_factored.json'));Q4branch=json.load(open('work/T28_balancing_translations.json'))
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def substitute(P,j,Q):
 out=set()
 for m in P:
  if m>>j&1:
   for n in Q:toggle(out,(m^(1<<j))|n)
  else:toggle(out,m)
 return out
def reduce_laws(P):
 P=substitute(P,115,set());P=substitute(P,113,{1<<57});return substitute(P,99,{1<<j for j in seven['L']})
def transform(P,permutation):
 out=set()
 for m in P:toggle(out,sum(1<<permutation[j] for j in range(116) if m>>j&1))
 return out
core={}
core['law115']={1<<115};core['law57_113']={1<<57,1<<113};core['law99_L']={1<<99}^{1<<j for j in seven['L']}
q={1<<j for j in factor['linear']}
for block in factor['products']:
 for i in block['I']:
  for j in block['J']:toggle(q,(1<<i)|(1<<j))
core['fourth']=q
core['fifth']={(1<<99)|(1<<j) for j in [57]+seven['K']}
core['seventh']={1<<j for j in seven['R']+seven['M']+seven['K']}
for j in seven['M']:toggle(core['seventh'],(1<<99)|(1<<j))
for j in seven['K']:toggle(core['seventh'],(1<<57)|(1<<j))
for a in action['actions']:
 pi=a['coefficient_permutation'];assert sorted(pi)==list(range(116))
 for name,P in core.items():assert reduce_laws(transform(P,pi))==reduce_laws(P),(a['unit'],name)
 assert reduce_laws({1<<pi[57]})=={1<<57} and reduce_laws({1<<pi[99]})==reduce_laws({1<<99})
print('All eight units preserve the three-law space, core conditions, and both charts.',flush=True)
data=np.load('work/anf_cubic_obstructions.npz');features=data['feature_masks'];bitrows=data['polynomial_bitsets'];supports=data['supports'];family={}
for u in [0x33ff,0x66ff,0x73bf,0x76ef]:
 i=int(np.flatnonzero(supports==u)[0]);bits=np.unpackbits(bitrows[i],bitorder='little')[:len(features)];family[hex(u)]={int(features[j,0])|(int(features[j,1])<<64) for j in np.flatnonzero(bits)}
for a in action['actions']:
 for i,u in enumerate(action['supports'][3:]):
  target=action['supports'][a['support_permutation'][3+i]]
  assert reduce_laws(transform(family[u],a['coefficient_permutation']))==family[target]
print('All four new polynomials are related by the verified unit action.',flush=True)
models=[]
for support,Psource in family.items():
 for branch in range(2):
  C={1<<j for j in seven['L'] if j!=0}
  if branch:C.add(0)
  P=substitute(Psource,0,C)
  if branch:P=substitute(P,57,{1<<j for j in seven['K']})
  Q={int(m,16) for m in Q4branch[branch]['branch_fourth_polynomial_hex']};Q.remove(1<<23);P=substitute(P,23,Q)
  G={1<<j for j in seven['R']}
  if not branch:
   for j in seven['M']+seven['K']:toggle(G,1<<j)
   for j in seven['K']:toggle(G,(1<<57)|(1<<j))
  G.remove(1<<5);P=substitute(P,5,G);models.append({'support_mask':support,'branch':branch,'polynomial_hex':[hex(m) for m in sorted(P)]})
Path('work/T40_family_polynomials.json').write_text(json.dumps({u:[hex(m) for m in sorted(P)] for u,P in family.items()},indent=2))
Path('work/T40_all_seven_models.json').write_text(json.dumps(json.load(open('work/T32_combined_models.json'))+models,indent=2))
Path('work/T40_symmetry_validation.json').write_text(json.dumps({'verification':'PASS','units_checked':8,'core_conditions_checked':len(core),'charts_preserved':True,'periodic_family_polynomials_checked':32,'nonzero_character_count':127,'character_orbits':len(action['character_orbits'])},indent=2));print('127 character bounds reduce to',len(action['character_orbits']),'symmetry orbits.')
