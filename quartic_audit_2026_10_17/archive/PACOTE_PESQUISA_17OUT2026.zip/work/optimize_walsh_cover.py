"""Counterexample-guided minimum Walsh-frequency cover; finite solver models are checked globally."""
import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/deps_local')
from pysat.formula import WCNF
from pysat.examples.rc2 import RC2
cache=np.load('work/walsh_cover_cache_n10.npz');freq=cache['frequency'];packed=cache['bitsets'];N=4194304
covers=[int.from_bytes(row.tobytes(),'little') for row in packed]
universe=(1<<N)-1
data=np.load('work/pareto_n10.npz');critical=np.flatnonzero(data['nonlinearity']==480)
clauses=set();witnesses={};start=time.perf_counter();records=[]
def add(c):
 c=int(c);clause=tuple((np.flatnonzero((packed[:,c//8]>>(c%8))&1)+1).tolist())
 assert clause
 if clause not in clauses:clauses.add(clause);witnesses[str(clause)]=hex(c)
for c in critical:add(c)
for iteration in range(128):
 cnf=WCNF()
 for clause in sorted(clauses):cnf.append(list(clause))
 for j in range(len(freq)):cnf.append([-(j+1)],weight=1)
 with RC2(cnf,solver='g4') as rc2:
  model=rc2.compute();assert model is not None
  selected=[j for j in range(len(freq)) if j+1 in model];lower_bound=rc2.cost
 assert len(selected)==lower_bound
 missing=universe
 for j in selected:missing&=~covers[j]
 record={'iteration':iteration,'cover_size_optimal_on_witness_subset':lower_bound,'frequencies':[int(freq[j]) for j in selected],'global_uncovered':missing.bit_count(),'hard_clauses':len(clauses),'seconds':time.perf_counter()-start}
 records.append(record);print(record,flush=True)
 report={'n':10,'threshold':64,'records':records,'exact_global_minimum':lower_bound if not missing else None,'cover':[int(freq[j]) for j in selected] if not missing else None,'solver':'PySAT RC2 with Glucose4; optimum checked against all 4194304 functions','lower_bound_witnesses':witnesses,'final_hard_clauses':[list(c) for c in sorted(clauses)]}
 Path('work/optimized_walsh_cover_n10.json').write_text(json.dumps(report,indent=2))
 if not missing:break
 missing_bytes=np.frombuffer(missing.to_bytes(N//8,'little'),dtype=np.uint8)
 positions=np.flatnonzero(np.unpackbits(missing_bytes,bitorder='little'))
 # A spread of counterexamples, plus the lowest indices, avoids learning
 # only one cluster at a time. Every added constraint has a saved witness.
 chosen=np.unique(np.r_[positions[:64],positions[np.linspace(0,len(positions)-1,min(256,len(positions)),dtype=int)]])
 for c in chosen:add(c)
