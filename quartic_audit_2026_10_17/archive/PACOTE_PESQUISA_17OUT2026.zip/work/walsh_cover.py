import sys,json,time
from itertools import combinations
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,rotations
def fwht(v):
 for k in range(v.size.bit_length()-1):
  vv=v.reshape(-1,2,1<<k);a=vv[:,0,:].copy();b=vv[:,1,:].copy();vv[:,0,:]=a+b;vv[:,1,:]=a-b
def run(n,threshold):
 start=time.perf_counter();gs,_,_=setup(n);N=1<<len(gs);x=np.arange(1<<n,dtype=np.uint32);sig=np.zeros(len(x),dtype=np.uint32)
 for j,(_,word) in enumerate(gs):sig|=np.unpackbits(np.frombuffer(word.to_bytes((1<<n)//8,'little'),dtype=np.uint8),bitorder='little').astype(np.uint32)<<j
 seen=set();freq=[];covers=[];unique=[]
 for s in range(1<<n):
  if s in seen:continue
  seen.update(rotations(s,n));freq.append(s)
  sign=1-2*(np.bitwise_count(x&np.uint32(s))%2).astype(np.int32)
  v=np.zeros(N,dtype=np.int32);np.add.at(v,sig,sign);fwht(v)
  b=np.packbits(np.abs(v)>=threshold,bitorder='little').tobytes();covers.append(int.from_bytes(b,'little'))
  if len(freq)%16==0:print('COVERS',n,len(freq),flush=True)
 universe=(1<<N)-1;uncovered=universe;selected=[]
 np.savez_compressed(f'work/walsh_cover_cache_n{n}.npz',frequency=np.array(freq),bitsets=np.stack([np.frombuffer(v.to_bytes((N+7)//8,'little'),dtype=np.uint8) for v in covers]))
 while uncovered:
  j=max(range(len(freq)),key=lambda j:(covers[j]&uncovered).bit_count())
  gain=(covers[j]&uncovered).bit_count()
  if gain==0:raise ValueError('Threshold does not cover coefficient space')
  selected.append(j);uncovered&=~covers[j]
 # Remove dominated frequency tests, retaining the earliest equal cover.
 candidates=[j for j in range(len(freq)) if not any(j!=k and covers[j]&~covers[k]==0 and (covers[j]!=covers[k] or k<j) for k in range(len(freq)))]
 minimum=None;witness=None;searched=[]
 data=np.load(f'work/pareto_n{n}.npz');critical=np.flatnonzero(data['nonlinearity']==data['nonlinearity'].max())
 small=[]
 for cover in covers:
  packed=np.frombuffer(cover.to_bytes((N+7)//8,'little'),dtype=np.uint8)
  flags=(packed[critical//8]>>(critical%8))&1
  small.append(int.from_bytes(np.packbits(flags,bitorder='little').tobytes(),'little'))
 small_universe=(1<<len(critical))-1
 for size in range(1,min(len(selected),4)+1):
  checked=0;found=None
  for comb in combinations(candidates,size):
   checked+=1;small_missing=small_universe
   for j in comb:small_missing&=~small[j]
   if small_missing:continue
   missing=universe
   for j in comb:missing&=~covers[j]
   if not missing:found=comb;break
  searched.append({'size':size,'checked':checked,'all_subsets_if_no_cover':found is None})
  if found is not None:minimum=size;witness=list(found);break
  print('MINIMUM SEARCH',n,size,checked,flush=True)
 chosen=witness if witness is not None else selected
 witnesses=[]
 for j in chosen:
  missing=universe
  for k in chosen:
   if k!=j:missing&=~covers[k]
  if missing:
   low=missing&-missing;witnesses.append({'removed_frequency':freq[j],'coefficients_hex':hex(low.bit_length()-1)})
 report={'n':n,'threshold':threshold,'full_functions':N,'frequencies_tested':freq,'single_cover_sizes':[v.bit_count() for v in covers],'greedy_cover':[freq[j] for j in selected],'exact_minimum':minimum,'cover':[freq[j] for j in chosen],'undominated_candidates':[freq[j] for j in candidates],'search':searched,'indispensability_witnesses':witnesses,'seconds':time.perf_counter()-start,'scope':'Minimum among the cyclic-frequency representatives for this fixed absolute-Walsh threshold only.'}
 Path(f'work/walsh_cover_n{n}.json').write_text(json.dumps(report,indent=2))
 np.savez_compressed(f'work/walsh_cover_n{n}.npz',frequency=np.array(freq),bitsets=np.stack([np.frombuffer(v.to_bytes((N+7)//8,'little'),dtype=np.uint8) for v in covers]))
 print('DONE',n,report['cover'],minimum,report['seconds'],flush=True)
run(8,36)
run(10,64)
