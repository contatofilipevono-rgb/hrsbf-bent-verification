from pathlib import Path
import json,subprocess,sys
combined=[r for r in json.load(open('work/T32_combined_models.json')) if r['support_mask']=='0x3f3f'];out=Path('outputs')
cert={'combined_models':combined,'quadratic_restrictions':json.load(open('work/T32_exact_restriction_rank.json')),'radical_polynomials':json.load(open('work/T32_radical_polynomials.json')),'density':json.load(open('work/T32_exact_radical_density.json')),'seventh_branch_models':[r for r in json.load(open('work/T31_after_all_five.json')) if r['support_mask']=='0x7777']}
(out/'T32_COMBINACAO_CERTIFICADO.json').write_text(json.dumps(cert,indent=2),encoding='utf-8')
src=(out/'VERIFICAR_REFINAMENTO_T29.py').read_text().replace("refinement=json.loads((base/'T29_RADICAIS_CERTIFICADO.json').read_text())", "refinement=json.loads((base/'T32_COMBINACAO_CERTIFICADO.json').read_text())")
src=src.replace('def symplectic_bias(P):','def quadratic_bias(P):')
src=src.replace('total=Fraction(0);counts=[]','''def symplectic_bias(P):
 if all(m.bit_count()<=2 for m in P):return quadratic_bias(P)
 assert all(m.bit_count()<=3 and m>>57&1 for m in P if m.bit_count()>2)
 answers=[]
 for value in [0,1]:
  Q=set()
  for m in P:
   if m>>57&1:
    if value:toggle(Q,m^(1<<57))
   else:toggle(Q,m)
  answers.append(quadratic_bias(Q))
 return sum(answers)/2
for old,seventh,new in zip(cert['reduced_models']['branches'],refinement['seventh_branch_models'],refinement['combined_models']):
 Q={int(m,16) for m in seventh['polynomial_hex']}
 assert (1<<5) in Q and all(not m>>5&1 for m in Q if m.bit_count()>1)
 Q.remove(1<<5);R=set()
 for m in map(lambda x:int(x,16),old['polynomial_hex']):
  if m>>5&1:
   for n in Q:toggle(R,(m^(1<<5))|n)
  else:toggle(R,m)
 assert R=={int(m,16) for m in new['polynomial_hex']}
cert['reduced_models']['branches']=refinement['combined_models']
cert['quadratic_restrictions']=refinement['quadratic_restrictions']
total=Fraction(0);counts=[]''')
src=src.replace('m.bit_count()<=2 for m in value','m.bit_count()<=3 for m in value').replace("32 if reduced['branch']==0 else 64","64 if reduced['branch']==0 else 128")
src=src.replace("Q={int(m,16) for m in seventh['polynomial_hex']}","""Q={int(m,16) for m in seventh['polynomial_hex']}
 formula=json.loads((base/'T31_SETIMA_CERTIFICADO.json').read_text())
 expected={1<<j for j in formula['R']}
 if old['branch']==0:
  for j in formula['M']+formula['K']:toggle(expected,1<<j)
  for j in formula['K']:toggle(expected,(1<<57)|(1<<j))
 assert Q==expected""")
src=src.replace("directions=[int(d,16) for d in radical['directions_hex']]", """assert all((m&mask).bit_count()<=1 for m in P if m.bit_count()>2)
 actual_rows=[sum((((1<<i)|(1<<j)) in P)<<k for k,j in enumerate(S) if i!=j) for i in S]
 assert actual_rows==[int(v,16) for v in restriction['polar_rows_hex']]
 assert rank(actual_rows)==restriction['polar_rank']
 directions=[int(d,16) for d in radical['directions_hex']]""")
(out/'VERIFICAR_COMBINACAO_T32.py').write_text(src,encoding='utf-8')
result=subprocess.run([sys.executable,str(out/'VERIFICAR_COMBINACAO_T32.py')],capture_output=True,text=True,check=True)
(out/'T32_VERIFICACAO.json').write_text(result.stdout,encoding='utf-8');print(result.stdout)
