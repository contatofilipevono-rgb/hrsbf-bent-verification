from pathlib import Path
import subprocess,sys
src=Path('work/next_ANF_bit_branches.py').read_text()
src=src.replace("start=time.perf_counter();gs,_,_=setup(16);", "mask=int(sys.argv[1],16); prefix=f'work/T31_{mask:02x}'; start=time.perf_counter();gs,_,_=setup(16);")
src=src.replace("points=np.array([v|(w<<8) for v in range(64) for w in range(v+1,64)],dtype=np.uint32);", "small=[v for v in range(256) if v&mask==v]; assert len(small)==64; points=np.array([v|(w<<8) for v in small for w in small if v<w],dtype=np.uint32);")
src=src.replace("allpoints=np.array([v|(w<<8) for v in range(64) for w in range(64)],dtype=np.uint32);", "allpoints=np.array([v|(w<<8) for v in small for w in small],dtype=np.uint32);")
src=src.replace("reports=[]", """reports=[]
diagonal={}
for a in range(2):
 for b in range(2):
  coeff=((1<<57)|(1<<113) if a else 0)^((1<<99) if b else 0); val=0
  for v in small:
   x=v|(v<<8);fx=sum(((word>>x)&1) for j,(_,word) in enumerate(gs) if coeff>>j&1)%2;val+=1-2*fx
  assert val%16==0;diagonal[a,b]=val
print('DIAGONAL',mask,diagonal,flush=True)
""")
src=src.replace("if (branch+origin_word.bit_count()//4)%2:toggle(0)", "if (diagonal[0,branch]//16+origin_word.bit_count()//4)%2:toggle(0)\n if (diagonal[0,branch]//16-diagonal[1,branch]//16)%2:\n  for j,c in zip(free,coefficient_basis):\n   if c>>57&1:toggle(1<<j)")
src=src.replace("f'work/T28_branch{branch}.npz'", "f'{prefix}_branch{branch}.npz'")
src=src.replace("B0=16*(4-2*a-3*branch)", "B0=diagonal[a,branch]")
src=src.replace("Path('work/T28_branch_reports.json')", "Path(prefix+'_branch_reports.json')")
Path('work/T31_support_model.py').write_text(src,encoding='utf-8')
for mask in ['5f','6f','77']:
 subprocess.run([sys.executable,'work/T31_support_model.py',mask],check=True)
