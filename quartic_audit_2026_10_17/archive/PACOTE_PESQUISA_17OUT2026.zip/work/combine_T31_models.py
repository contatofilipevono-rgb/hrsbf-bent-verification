import json
from pathlib import Path
from collections import Counter
data=json.load(open('work/T31_after_all_five.json'));sixth=json.load(open('work/T28_after_all_five.json'))['branches'];reports=[]
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
for branch in range(2):
 Q={int(m,16) for m in next(r for r in data if r['support_mask']=='0x7777' and r['branch']==branch)['polynomial_hex']};assert (1<<5) in Q and not any(m>>5&1 for m in Q if m.bit_count()>1);Q.remove(1<<5)
 for rec in [sixth[branch]]+[r for r in data if r['branch']==branch and r['support_mask']!='0x7777']:
  support=rec.get('support_mask','0x3f3f');P={int(m,16) for m in rec['polynomial_hex']};out=set()
  for m in P:
   if m>>5&1:
    for n in Q:toggle(out,(m^(1<<5))|n)
   else:toggle(out,m)
  result={'support_mask':support,'branch':branch,'terms':len(out),'degree_histogram':dict(Counter(m.bit_count() for m in out)),'polynomial_hex':[hex(m) for m in sorted(out)]};reports.append(result);print({k:v for k,v in result.items() if k!='polynomial_hex'})
Path('work/T32_combined_models.json').write_text(json.dumps(reports,indent=2))
src=Path('work/T28_exact_restriction_rank.py').read_text().replace("data=json.load(open('work/T28_after_all_five.json'));reports=[]", "data={'branches':[r for r in json.load(open('work/T32_combined_models.json')) if r['support_mask']=='0x3f3f']};reports=[]").replace("'work/T28_exact_restriction_rank.json'","'work/T32_exact_restriction_rank.json'")
Path('work/T32_find_restrictions.py').write_text(src)
