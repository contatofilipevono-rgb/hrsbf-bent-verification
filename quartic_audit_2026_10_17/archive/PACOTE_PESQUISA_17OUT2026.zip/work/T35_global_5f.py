"""Exact small quadratic condition at support 0x5f77, after only three T20 laws."""
import sys,json,time
from pathlib import Path
from itertools import combinations
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16);small=[v for v in range(256) if v&0x5f==v];points=[v|(w<<8) for v in small for w in small if v<w];assert len(points)==2016
words=[sum((sum((x&m)==m for m in orb)%2)<<k for k,x in enumerate(points)) for orb,_ in gs];O=sum((x.bit_count()%2)<<k for k,x in enumerate(points));L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
free=sorted(set(range(116))-{99,113,115});cb=[];basis=[]
for j in free:
 c=(1<<j)^((1<<113) if j==57 else 0)^((1<<99) if j in L else 0);cb.append(c);word=0
 for k in range(116):
  if c>>k&1:word^=words[k]
 basis.append(word)
assert O.bit_count()%4==0
assert all(w.bit_count()%2==0 and (w.bit_count()-2*(w&O).bit_count())%4==0 for w in basis)
assert all((v&w).bit_count()%2==0 for v,w in combinations(basis,2))
P=set()
def toggle(m):
 if m in P:P.remove(m)
 else:P.add(m)
if O.bit_count()//4%2:toggle(0)
for i,w in enumerate(basis):
 if (w.bit_count()-2*(w&O).bit_count())//4%2:toggle(1<<free[i])
for i,j in combinations(range(len(free)),2):
 inter=basis[i]&basis[j]
 if (inter.bit_count()//2+(inter&O).bit_count())%2:toggle((1<<free[i])|(1<<free[j]))
for i,j,k in combinations(range(len(free)),3):
 if (basis[i]&basis[j]&basis[k]).bit_count()%2:toggle((1<<free[i])|(1<<free[j])|(1<<free[k]))

for j in L:toggle(1<<j)  # The diagonal term B0/16 has parity b=L at this support.
from collections import Counter
contractions={}
for m in P:
 if m.bit_count()==3:
  for j in free:
   if m>>j&1:contractions[m^(1<<j)]=contractions.get(m^(1<<j),0)^(1<<j)
B={}
for row in contractions.values():
 while row:
  j=row.bit_length()-1
  if j in B:row^=B[j]
  else:B[j]=row;break
report={'support_mask':'0x5f5f','after_three_laws':True,'monomials':len(P),'degree_histogram':dict(Counter(m.bit_count() for m in P)),'cubic_essential_dimension':len(B),'cubic_polar_radical_dimension':len(free)-len(B),'polynomial_hex':[hex(m) for m in sorted(P)]}
Path('work/T35_global_5f.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='polynomial_hex'})
