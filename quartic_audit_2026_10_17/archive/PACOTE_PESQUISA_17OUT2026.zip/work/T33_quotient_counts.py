import json
from pathlib import Path
import numpy as np
data=dict(np.load('outputs/T27_parameterization.npz'));P=data['P'];cert=json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'));groups={name:cert[name] for name in ['R','M','K']};groups.update(a=[57],b=[99])
masks={name:sum((sum(int(P[j,k]) for k in group)%2)<<j for j in range(33)) for name,group in groups.items()}
print('MASKS', {name:hex(v) for name,v in masks.items()},flush=True)
def parity(ids,mask):return (np.bitwise_count(ids&np.uint64(mask))%2).astype(np.uint8)
def condition(ids):
 R,M,K,a,b=[parity(ids,masks[name]) for name in ['R','M','K','a','b']]
 return R^M^K^(b&M)^(a&K)
prefix_only=all(mask<(1<<21) for mask in masks.values());reports=[];total=0
for group,width in [(11,11),(12,12)]:
 parents=data[f'parents_{group}'];constant=condition(parents)
 if prefix_only:
  good=constant==0;total+=int(good.sum())*(1<<width);reports.append({'group':group,'original_parents':len(parents),'passing_parents':int(good.sum()),'failing_parents':int((~good).sum()),'states_after_seventh':int(good.sum())*(1<<width)})
  data[f'parents_{group}']=parents[good]
  if group==11:
   for field in ['gradient_11','constant_11']:data[field]=data[field][good]
 else:
  reports.append({'group':group,'prefix_constant_histogram':np.bincount(constant,minlength=2).tolist()})
report={'forms_masks33_hex':{k:hex(v) for k,v in masks.items()},'seventh_determined_by_prefix21':prefix_only,'groups':reports,'complete_domain_before_energy_Poisson':total if prefix_only else None,'scope':'Exact filtering of T27 quotient domain by the seventh condition; not bent counts and no GPU execution.'}
Path('work/T33_quotient_counts.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
if prefix_only:np.savez_compressed('work/T33_parameterization.npz',**data)
