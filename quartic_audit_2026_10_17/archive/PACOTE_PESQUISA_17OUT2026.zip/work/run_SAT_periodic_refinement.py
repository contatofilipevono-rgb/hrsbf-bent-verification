from pathlib import Path
import subprocess,sys
src=Path('work/solve_cubic_native_xor.py').read_text()
extra="""equation([1<<j for j in json.load(open('outputs/T31_SETIMA_CERTIFICADO.json'))['R']])
for support in ['5f','6f']:
 rec=json.load(open(f'work/T31_{support}_branch_reports.json'))['branches'][1]
 equation([int(m,16) for m in rec['monomials_hex']])
"""
src=src.replace('s.add_clause([100]);',extra+'s.add_clause([100]);').replace('cubic_native_xor_report.json','SAT_periodic_refinement_report.json').replace('389 cubic necessary conditions, Q4, fifth branch constraints, and next h/16 bit','389 cubic necessary conditions, Q4, fifth branch constraints, and second bits at all four period-eight weight-twelve supports')
Path('work/SAT_periodic_refinement.py').write_text(src)
subprocess.run([sys.executable,'work/SAT_periodic_refinement.py'],check=True)
