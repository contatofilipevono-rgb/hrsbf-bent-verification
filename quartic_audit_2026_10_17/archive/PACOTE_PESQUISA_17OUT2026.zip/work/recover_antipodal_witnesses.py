import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
from VERIFICAR_CANDIDATO_C16 import verify
family=json.load(open('work/quadratic_product_family.json'));previous=json.load(open('work/quadratic_product_PC2_exhaustion.json'));blocks=[a['block'] for a in previous['records'] if len(a['survivors_after_each_direction'])==9]
coefficients=[int(family['generators'][j]['coefficient_hex'],16) for j in family['independent_generator_indices']];gs,_,_=setup(16);words=[]
for c in coefficients:
 tt=0
 for j,(_,w) in enumerate(gs):
  if c>>j&1:tt^=w
 words.append(tt)
truth=np.stack([np.unpackbits(np.frombuffer(w.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little') for w in words]);x=np.arange(65536,dtype=np.uint32);half=x[x%2==0];signatures=[]
for a in [1]+[1|(1<<d) for d in range(1,8)]:
 derivative=truth[:,half]^truth[:,half^a];fixed=np.zeros(32768,dtype=np.uint8);free=np.zeros(32768,dtype=np.uint32)
 for j in range(8):fixed|=derivative[j]<<j
 for j in range(20):free|=derivative[8+j].astype(np.uint32)<<j
 signatures.append((fixed,free))
records=[]
for block in blocks:
 alive=np.ones(1<<20,dtype=bool)
 for fixed,free in signatures:
  weights=2-4*(np.bitwise_count(fixed&np.uint8(block))%2).astype(np.int32);v=np.bincount(free,weights=weights,minlength=1<<20).astype(np.int32)
  for j in range(20):
   w=v.reshape(-1,2,1<<j);a=w[:,0,:].copy();b=w[:,1,:].copy();w[:,0,:]=a+b;w[:,1,:]=a-b
  alive&=v==0
 for z in np.flatnonzero(alive):
  c=0
  for j in range(28):
   if ((block>>j)&1 if j<8 else (int(z)>>(j-8))&1):c^=coefficients[j]
  result=verify(c);assert result['autocorrelations'][:8]==[0]*8 and result['autocorrelations'][8]!=0
  result['E2']=sum(a*a for a in result['autocorrelations']);records.append(result)
assert len(records)==16
report={'functions_passing_first_eight_directions':16,'all_independently_verified':True,'minimum_E2_among_these':min(r['E2'] for r in records),'antipodal_correlation_values':sorted(set(r['autocorrelations'][8] for r in records)),'records':records,'scope':'These sixteen functions prove that the antipodal direction cannot be omitted from a fixed low-weight witness set for the structured family. They are not counterexamples to C16.'}
Path('work/antipodal_witnesses.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='records'})
