import sys,json,ast,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'outputs');sys.path.insert(0,'work/recovered')
import GRAU4_T33_A100 as t33
from test_short_witness import setup
start=time.perf_counter();p=dict(np.load('outputs/T33_parameterization.npz'));rng=np.random.default_rng(2026101733);tested=0
assert len(np.intersect1d(p['parents_10'],p['parents_11']))==0
for width,mapper in [(10,t33.cpu_ids10),(11,t33.cpu_ids11)]:
 parents=p[f'parents_{width}'];assert len(np.unique(parents))==len(parents)
 for row in rng.integers(0,len(parents),16):
  ids=mapper(np.arange(int(row)*(1<<width),(int(row)+1)*(1<<width),dtype=np.uint64),p)
  assert len(np.unique(ids))==1<<width and np.all((ids&np.uint64((1<<21)-1))==parents[row])
  assert not np.any(t33.quadratic(ids)) and not np.any(t33.fifth(ids)) and not np.any(t33.seventh(ids));tested+=len(ids)
 parents=parents.astype(np.uint64);constant=t33.quadratic(parents);gradient=np.zeros(len(parents),dtype=np.uint16)
 for k in range(12):gradient|=((t33.quadratic(parents^(np.uint64(1)<<np.uint64(21+k)))^constant).astype(np.uint16)<<k)
 if width==10:
  ga=p['gradient_a'];gb=p['gradient_b'];pa=p['pivot_a'];pb=p['pivot_b'];ca=p['constant_a'];cb=p['constant_b']
  a=(gradient>>pa)&1;b=(gradient>>pb)&1
  assert np.array_equal((a*ga)^(b*gb),gradient)
  assert np.array_equal((a*ca)^(b*cb),constant)
  r=np.full(len(parents),0x7e,dtype=np.uint16);a=(r>>pa)&1;b=(r>>pb)&1
  assert np.array_equal((a*ga)^(b*gb),r)
  assert np.array_equal((a*ca)^(b*cb),t33.seventh(parents))
 else:
  assert np.all((gradient==0)|(gradient==p['gradient_11']))
  assert np.array_equal(constant,(gradient!=0)*p['constant_11'])
  assert np.array_equal(t33.seventh(parents),p['constant_11'])
 assert not np.any(t33.fifth(parents))
gs,_,_=setup(16);direct=0;small=[v for v in range(256) if v&0x77==v];points=np.array([v|(w<<8) for v in small for w in small]);sign=1-2*(np.bitwise_count(points)%2).astype(np.int32)
for width,mapper in [(10,t33.cpu_ids10),(11,t33.cpu_ids11)]:
 ids=mapper(rng.integers(0,len(p[f'parents_{width}'])*(1<<width),64,dtype=np.uint64),p)
 for state in ids:
  c=(np.array([int(state)>>j&1 for j in range(33)],dtype=np.uint8)@p['P'])&1;tt=0
  for j,(_,word) in enumerate(gs):
   if c[j]:tt^=word
  W0=65536-2*tt.bit_count();assert W0%256==0
  truth=np.unpackbits(np.frombuffer(tt.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little');h=int(np.sum((1-2*truth[points].astype(np.int32))*sign));assert h%32==0
  direct+=1
report={'verification':'PASS','CPU_mapped_states_checked':tested,'all_parent_equation_equivalences_checked':len(p['parents_10'])+len(p['parents_11']),'direct_original_ANF_Walsh_and_seventh_checks':direct,'groups_disjoint_and_mappings_injective':True,'complete_T33_domain':162537472,'GPU_executed':False,'scope':'Complete affine-system equivalence on all parents, plus full selected extension cubes and original-ANF checks. CUDA mapper and GPU filters require the packaged pilot crosschecks.','seconds':time.perf_counter()-start}
Path('outputs/T33_MAPPING_CPU_VALIDATION.json').write_text(json.dumps(report,indent=2));print(report)
