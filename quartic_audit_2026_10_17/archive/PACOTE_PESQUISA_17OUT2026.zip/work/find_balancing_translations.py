"""Find exact constant derivatives of cubic branch polynomials preserving Q4."""
import json
from pathlib import Path
from itertools import combinations
def nullspace(rows,variables):
 basis={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in basis:v^=basis[j]
   else:basis[j]=v;break
 free=[j for j in variables if j not in basis];vectors=[]
 for j in free:
  v=1<<j
  for pivot in sorted(basis):
   if (basis[pivot]&v).bit_count()%2:v^=1<<pivot
  assert all((v&r).bit_count()%2==0 for r in rows)
  vectors.append(v)
 return vectors
def sum_vectors(combo,base):
 v=0
 for j,b in enumerate(base):
  if combo>>j&1:v^=b
 return v
def kernel_map(base,images):
 rows=[sum(((im>>j)&1)<<i for i,im in enumerate(images)) for j in range(max([0]+[im.bit_length() for im in images]))]
 return [sum_vectors(v,base) for v in nullspace(rows,list(range(len(base))))]
def toggle(poly,m):
 if m in poly:poly.remove(m)
 else:poly.add(m)
def derivative(poly,d):
 out=set()
 for m in poly:
  bits=[1<<j for j in range(m.bit_length()) if m>>j&1 and d>>j&1]
  for choice in range(1,1<<len(bits)):
   removed=0
   for j,b in enumerate(bits):
    if choice>>j&1:removed|=b
   toggle(out,m^removed)
 return out
def linear_derivative(poly,d):
 return sum(m for m in derivative(poly,d) if m.bit_count()==1)
reports=[];factor=json.load(open('work/post_T20_quadratic_factored.json'));data=json.load(open('work/T28_branch_reports.json'))
import numpy as np
for rec in data['branches']:
 b=rec['branch_c99'];poly={int(v,16) for v in rec['monomials_hex']};free=rec['free_indices'];model=np.load(f'work/T28_branch{b}.npz');cb=[int(lo)|(int(hi)<<64) for lo,hi in model['coefficient_basis']];origin=int(rec['origin_coefficient_hex'],16)
 def form(group):
  mask=sum(1<<j for j in group);constant=(origin&mask).bit_count()%2
  linear=sum(((c&mask).bit_count()%2)<<j for c,j in zip(cb,free))
  return constant,linear
 Q=set();c,m=form(factor['linear'])
 if c:toggle(Q,0)
 for j in free:
  if m>>j&1:toggle(Q,1<<j)
 for block in factor['products']:
  a,A=form(block['I']);c,C=form(block['J'])
  if a*c:toggle(Q,0)
  if a:
   for j in free:
    if C>>j&1:toggle(Q,1<<j)
  if c:
   for j in free:
    if A>>j&1:toggle(Q,1<<j)
  for j in free:
   if A>>j&1:
    for k in free:
     if C>>k&1:toggle(Q,(1<<j)|(1<<k))
 contractions={}
 for mon in poly:
  if mon.bit_count()!=3:continue
  inds=[j for j in free if mon>>j&1]
  for i,j in combinations(inds,2):
   other=mon^((1<<i)|(1<<j));key=(1<<i)|(1<<j);contractions[key]=contractions.get(key,0)^other
 K=nullspace(list(contractions.values()),free)
 K0=kernel_map(K,[linear_derivative(poly,d) for d in K])
 assert all(not any(m.bit_count()>0 for m in derivative(poly,d)) for d in K0)
 K1=kernel_map(K0,[linear_derivative(Q,d) for d in K0])
 qconstant=[int(0 in derivative(Q,d)) for d in K1]
 K2=[sum_vectors(v,K1) for v in nullspace([sum(bit<<j for j,bit in enumerate(qconstant))],list(range(len(K1))))]
 assert all(derivative(Q,d)==set() for d in K2)
 good=[d for d in K2 if derivative(poly,d)=={0}]
 witness=min(good,key=int.bit_count) if good else None
 original_delta=0
 if witness is not None:
  for j,c in zip(free,cb):
   if witness>>j&1:original_delta^=c
 report={'branch':b,'cubic_polar_radical_dimension':len(K),'constant_derivative_dimension':len(K0),'directions_preserving_fourth_dimension':len(K2),'balancing_direction_found':witness is not None,'free_direction_hex':None if witness is None else hex(witness),'original_coefficient_direction_hex':None if witness is None else hex(original_delta),'direction_support':[] if witness is None else [j for j in range(116) if original_delta>>j&1],'branch_fourth_polynomial_hex':[hex(m) for m in sorted(Q)]}
 reports.append(report);print({k:v for k,v in report.items() if k!='branch_fourth_polynomial_hex'})
Path('work/T28_balancing_translations.json').write_text(json.dumps(reports,indent=2))
