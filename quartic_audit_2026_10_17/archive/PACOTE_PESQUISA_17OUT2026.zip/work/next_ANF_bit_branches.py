"""Exact next h_f(0x3f3f)/16 bit on the two branches of the fifth condition."""
import sys,json,random,time
from itertools import combinations
from collections import Counter
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();gs,_,_=setup(16);L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106];fifth=json.load(open('work/fifth_quadratic.json'));K=[j for j in fifth['I'] if j!=57]
points=np.array([v|(w<<8) for v in range(64) for w in range(v+1,64)],dtype=np.uint32);assert len(points)==2016
words=[]
for orb,_ in gs:
 val=np.zeros(2016,dtype=np.uint8)
 for m in orb:val^=((points&m)==m)
 words.append(int.from_bytes(np.packbits(val,bitorder='little').tobytes(),'little'))
offset=int.from_bytes(np.packbits(np.bitwise_count(points)%2,bitorder='little').tobytes(),'little')
allpoints=np.array([v|(w<<8) for v in range(64) for w in range(64)],dtype=np.uint32);sign=1-2*(np.bitwise_count(allpoints)%2).astype(np.int32)
reports=[]
for branch in [0,1]:
 excluded={0,99,113,115}|({57} if branch else set());free=sorted(set(range(116))-excluded)
 origin=(1<<0)|(1<<99) if branch else 0;origin_word=offset^(words[0]^words[99] if branch else 0)
 basis=[];coefficient_basis=[]
 for j in free:
  c=(1<<j)|((1<<0) if j in L else 0)
  if branch:
   if j in K:c^=(1<<57)|(1<<113)
  elif j==57:c^=1<<113
  coefficient_basis.append(c);w=0
  for k in range(116):
   if c>>k&1:w^=words[k]
  basis.append(w)
 assert origin_word.bit_count()%4==0
 assert all(w.bit_count()%2==0 and (w.bit_count()-2*(w&origin_word).bit_count())%4==0 for w in basis)
 assert all((a&b).bit_count()%2==0 for a,b in combinations(basis,2))
 poly=set()
 def toggle(m):
  if m in poly:poly.remove(m)
  else:poly.add(m)
 if (branch+origin_word.bit_count()//4)%2:toggle(0)
 for i,w in enumerate(basis):
  if ((w.bit_count()-2*(w&origin_word).bit_count())//4)%2:toggle(1<<free[i])
 for i,j in combinations(range(len(free)),2):
  inter=basis[i]&basis[j]
  if (inter.bit_count()//2+(inter&origin_word).bit_count())%2:toggle((1<<free[i])|(1<<free[j]))
 for i,j,k in combinations(range(len(free)),3):
  if (basis[i]&basis[j]&basis[k]).bit_count()%2:toggle((1<<free[i])|(1<<free[j])|(1<<free[k]))
 linear=[m.bit_length()-1 for m in poly if m.bit_count()==1];nonlinear=0
 for m in poly:
  if m.bit_count()>1:nonlinear|=m
 isolated=[j for j in linear if not(nonlinear>>j&1)]
 arr=np.array([[m&((1<<64)-1),m>>64] for m in sorted(poly)],dtype=np.uint64).reshape(-1,2);np.savez_compressed(f'work/T28_branch{branch}.npz',monomials=arr,free=np.array(free),coefficient_basis=np.array([[c&((1<<64)-1),c>>64] for c in coefficient_basis],dtype=np.uint64))
 rng=random.Random(20261017301+branch);hist=[0,0];examples={}
 for sample in range(128):
  z=rng.getrandbits(116)&sum(1<<j for j in free);c=origin;cw=origin_word
  for i,j in enumerate(free):
   if z>>j&1:c^=coefficient_basis[i];cw^=basis[i]
  a=c>>57&1;B0=16*(4-2*a-3*branch);h=B0+4032-4*cw.bit_count();assert h%16==0
  value=sum((z&m)==m for m in poly)%2;assert value==(h//16)%2
  tt=0
  for j,(_,word) in enumerate(gs):
   if c>>j&1:tt^=word
  truth=np.unpackbits(np.frombuffer(tt.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little');direct=int(np.sum((1-2*truth[allpoints].astype(np.int32))*sign));assert direct==h
  hist[value]+=1;examples.setdefault(str(value),{'coefficient_hex':hex(c),'h_u':h,'next_bit':value})
 report={'branch_c99':branch,'free_dimension_before_fourth_condition':len(free),'origin_coefficient_hex':hex(origin),'free_indices':free,'monomial_count':len(poly),'degree_histogram':dict(Counter(m.bit_count() for m in poly)),'isolated_linear_variables':isolated,'constant_term':0 in poly,'random_histogram':hist,'direct_original_ANF_checks':128,'examples':examples,'monomials_hex':[hex(m) for m in sorted(poly)]}
 reports.append(report);print({k:v for k,v in report.items() if k not in ['monomials_hex','free_indices']},flush=True)
Path('work/T28_branch_reports.json').write_text(json.dumps({'branches':reports,'seconds':time.perf_counter()-start,'scope':'Exact next-bit polynomials on the linear/affine branches given by the first three laws and the fifth condition. The fourth condition has not been substituted. Bentness requires next_bit zero; branch sample frequencies are not global rates.'},indent=2))
