import json
from collections import Counter
from pathlib import Path
data=json.load(open('work/T28_after_all_five.json'));P0=set(int(m,16) for m in data['branches'][0]['polynomial_hex']);P1=set(int(m,16) for m in data['branches'][1]['polynomial_hex'])
K=[j for j in json.load(open('work/fifth_quadratic.json'))['I'] if j!=57]
def toggle(p,m):
 if m in p:p.remove(m)
 else:p.add(m)
def sub(P,t):
 out=set()
 for m in P:
  if not m>>57&1:toggle(out,m)
  else:
   other=m^(1<<57)
   if t:toggle(out,other)
   for j in K:toggle(out,other|(1<<j))
 return out
A=sub(P0,0);B=sub(P0,1);C=P1
report={}
for name,P in [('A_b0_I0',A),('B_b0_I1',B),('C_b1_I0',C),('A_xor_B',A^B),('A_xor_C',A^C),('B_xor_C',B^C),('A_xor_B_xor_C',A^B^C)]:
 report[name]={'terms':len(P),'degree_histogram':dict(Counter(m.bit_count() for m in P)),'constant':0 in P,'polynomial_hex':[hex(m) for m in sorted(P)]}
 print(name,{k:v for k,v in report[name].items() if k!='polynomial_hex'})
Path('work/T28_chart_comparison.json').write_text(json.dumps(report,indent=2))
