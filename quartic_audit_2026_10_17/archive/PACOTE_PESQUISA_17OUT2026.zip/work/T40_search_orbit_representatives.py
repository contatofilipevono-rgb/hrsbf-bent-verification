from pathlib import Path
import subprocess,sys
src=Path('work/characterwise_restriction_search.py').read_text(encoding='utf-8').replace('work/T38_all_four_models.json','work/T40_all_seven_models.json').replace('work/T39_characterwise_restrictions.json','work/T40_characterwise_restrictions.json')
src=src.replace("supports=['0x3f3f','0x5f5f','0x6f6f','0x33ff']", "action=json.load(open('work/T40_normalizer_action.json'));supports=action['supports'];representatives=[min(o) for o in action['character_orbits'] if min(o)>15]")
src=src.replace('for choice in range(1,16):','for choice in representatives:')
Path('work/T40_find_restrictions.py').write_text(src,encoding='utf-8');subprocess.run([sys.executable,'work/T40_find_restrictions.py'],check=True)
