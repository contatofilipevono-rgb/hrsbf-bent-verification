import json,time
from pathlib import Path
from itertools import combinations
from collections import Counter
data=json.load(open('work/T40_all_seven_models.json'));reports=[];start=time.perf_counter();supports=['0x3f3f','0x5f5f','0x6f6f','0x33ff','0x66ff','0x73bf','0x76ef']
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def restrict(P,C,value):
 selected=sum(1<<j for j in C);ones=sum(((value>>i)&1)<<j for i,j in enumerate(C));zeros=selected^ones;out=set()
 for m in P:
  if not m&zeros:toggle(out,m&~selected)
 return out
def rank(rows):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 return len(B)
for branch in [1]:
 source=[{int(m,16) for m in next(r for r in data if r['branch']==branch and r['support_mask']==s)['polynomial_hex']} for s in supports]
 for character in [11,14,59,62]:
  original=set()
  for j,P in enumerate(source):
   if character>>j&1:original^=P
  for value in range(4):
   P=restrict(original,[35,61],value);used=sorted({j for m in P for j in range(116) if m>>j&1});bad={j:set() for j in used};edge=set()
   nonlinear=0
   for m in P:
    ids=[j for j in used if m>>j&1]
    if len(ids)>1:nonlinear|=m
    if len(ids)>2:
     for i,j in combinations(ids,2):bad[i].add(j);bad[j].add(i)
    elif len(ids)==2:edge.add(tuple(ids))
   isolated=[m.bit_length()-1 for m in P if m.bit_count()==1 and not m&nonlinear];allowed={j:set(used)-bad[j]-{j} for j in used};best=None
   def visit(R,C,X):
    global best
    if not C and not X:
     rows=[sum((tuple(sorted((i,j))) in edge)<<k for k,j in enumerate(R) if i!=j) for i in R];r=rank(rows);candidate=(len(R)-r//2,len(R),sorted(R),r)
     if best is None or candidate>best:best=candidate
     return
    u=max(C|X,key=lambda u:len(C&allowed[u]))
    for v in list(C-allowed[u]):visit(R+[v],C&allowed[v],X&allowed[v]);C.remove(v);X.add(v)
   visit([],set(used),set());rec={'branch':branch,'character':character,'conditioning_coordinates':[35,61],'condition_value':value,'polynomial_degree_histogram':dict(Counter(m.bit_count() for m in P)),'isolated_linear':isolated,'best_restriction':best};reports.append(rec);print(rec,flush=True)
Path('work/T42_conditioned_hard_characters.json').write_text(json.dumps(reports,indent=2));print('seconds',time.perf_counter()-start)
