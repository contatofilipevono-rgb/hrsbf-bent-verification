import json,time
from pathlib import Path
from fractions import Fraction
action=json.load(open('work/T40_normalizer_action.json'));previous=json.load(open('work/T39_characterwise_exact_bound.json'));data=json.load(open('work/T40_characterwise_restrictions.json'));start=time.perf_counter();reports=[]
def toggle(P,m):
 if m in P:P.remove(m)
 else:P.add(m)
def reduce_rows(rows):
 B={};combos={}
 for i,row in enumerate(rows):
  v=set(row);combo=1<<i
  while v:
   p=max(v)
   if p in B:v^=B[p];combo^=combos[p]
   else:B[p]=v;combos[p]=combo;break
  if v=={0}:return [],[],combo
 return list(B.values()),list(combos.values()),None
def restrict(P,coordinates,value):
 selected=sum(1<<j for j in coordinates);ones=sum(((value>>i)&1)<<j for i,j in enumerate(coordinates));zeros=selected^ones;out=set()
 for m in P:
  if not m&zeros:toggle(out,m&~selected)
 assert all(m.bit_count()<=2 for m in out)
 return out
def bias(P):
 P=set(P);pairs=0
 while any(m.bit_count()==2 for m in P):
  edge=next(m for m in P if m.bit_count()==2);i=edge&-edge;j=edge^i
  A={m^i for m in P if m&i and not m&j};B={m^j for m in P if m&j and not m&i};R={m for m in P if not m&(i|j)}
  for a in A:
   for b in B:toggle(R,a|b)
  P=R;pairs+=1
 if any(m.bit_count()==1 for m in P):return Fraction(0)
 return Fraction(-1 if 0 in P else 1,2**pairs)
total=Fraction(0)
for branch in data:
 selected=[];amplitudes=Fraction(0)
 for character in branch['characters']:
  outcomes=[]
  for option_index,option in enumerate(character['candidate_options'][:2]):
   D=[{int(m,16) for m in row} for row in option['polynomials_hex']]
   prebasis,precombos,inconsistent=reduce_rows(D)
   if inconsistent is not None:
    D=[{0}];preselection=[inconsistent]
   else:
    D=prebasis[:8];preselection=precombos[:8]
   condition=option['conditioning_coordinates'];cases=[];Z=Fraction(0);checks=0
   for value in range(1<<len(condition)):
    rows=[restrict(row,condition,value) for row in D];basis,combos,inconsistent=reduce_rows(rows)
    if inconsistent is not None:
     cases.append({'condition_value':value,'inconsistent_equation_combination':hex(inconsistent),'equation_basis_combinations':[],'quadratic_biases':[],'zero_fraction':[0,1]});continue
    values=[];summation=Fraction(0)
    for choice in range(1<<len(basis)):
     P=set()
     for j,row in enumerate(basis):
      if choice>>j&1:P^=row
     q=bias(P);values.append([q.numerator,q.denominator]);summation+=q;checks+=1
    z=summation/Fraction(1<<len(basis));Z+=z/Fraction(1<<len(condition));cases.append({'condition_value':value,'inconsistent_equation_combination':None,'equation_basis_combinations':[hex(c) for c in combos],'quadratic_biases':values,'zero_fraction':[z.numerator,z.denominator]})
   amplitude=Z/Fraction(2**(option['polar_rank']//2));outcome={**option,'selected_radical_equation_combinations':[hex(c) for c in preselection],'radical_density_is_upper_bound':True,'option_index':option_index,'radical_zero_fraction':[Z.numerator,Z.denominator],'average_absolute_slice_bias':[amplitude.numerator,amplitude.denominator],'conditioned_cases':cases,'quadratic_sums':checks};outcomes.append(outcome)
   print('branch',branch['branch'],'character',character['combination'],'option',option_index,'amplitude',str(amplitude),'sums',checks,'sec',round(time.perf_counter()-start,1),flush=True)
  best=min(outcomes,key=lambda r:Fraction(*r['average_absolute_slice_bias']));selected.append({'combination':character['combination'],**best});amplitudes+=Fraction(*best['average_absolute_slice_bias'])
  Path('work/T40_partial_bounds.json').write_text(json.dumps({'completed_branches':reports,'current_branch':branch['branch'],'completed_characters':selected},indent=2))
 selected.extend(r for r in previous['branches'][branch['branch']]['characters'] if r['combination'] in [min(o) for o in action['character_orbits']])
 selected.sort(key=lambda r:r['combination']);amplitudes=Fraction(0)
 assert [r['combination'] for r in selected]==[min(o) for o in action['character_orbits']]
 for r in selected:
  orbit=next(o for o in action['character_orbits'] if r['combination'] in o);r['symmetry_orbit']=orbit;amplitudes+=len(orbit)*Fraction(*r['average_absolute_slice_bias'])
 upper=(1+amplitudes)/128;lower=max(Fraction(0),(1-amplitudes)/128);total+=upper/Fraction(64 if branch['branch']==0 else 128)
 reports.append({'branch':branch['branch'],'supports':branch['supports'],'conditional_pass_upper_bound':[upper.numerator,upper.denominator],'conditional_pass_lower_bound':[lower.numerator,lower.denominator],'characters':selected});print('BRANCH',branch['branch'],str(upper),float(upper),flush=True)
report={'branches':reports,'global_pass_upper_bound':[total.numerator,total.denominator],'global_excluded_lower_bound':[(1-total).numerator,(1-total).denominator],'excluded_percent_lower_bound':float(100*(1-total)),'seconds':time.perf_counter()-start,'scope':'Symmetry-orbit character restrictions for the thirteen necessary conditions, with exact equation-basis reduction and rational quadratic sums. Independent verification pending.'};Path('work/T40_exact_orbit_bound.json').write_text(json.dumps(report,indent=2));print('GLOBAL',str(total),report['excluded_percent_lower_bound'],flush=True)
