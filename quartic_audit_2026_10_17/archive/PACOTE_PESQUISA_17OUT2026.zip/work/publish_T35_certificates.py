from pathlib import Path
import json,subprocess,sys
out=Path('outputs');raw=[]
for support,path in [('0x3f3f','work/T28_branch_reports.json'),('0x5f5f','work/T31_5f_branch_reports.json'),('0x6f6f','work/T31_6f_branch_reports.json')]:
 for rec in json.load(open(path))['branches']:raw.append({**rec,'support_mask':support})
certificate={'raw_models':raw,'combined_models':json.load(open('work/T32_combined_models.json'))}
(out/'T35_POLINOMIOS_CERTIFICADO.json').write_text(json.dumps(certificate,indent=2))
certificate={'radicals':json.load(open('work/T35_joint_radicals.json')),'density':json.load(open('work/T35_joint_exact_bound.json'))}
(out/'T35_LIMITE_CERTIFICADO.json').write_text(json.dumps(certificate,indent=2))
result=subprocess.run([sys.executable,str(out/'VERIFICAR_POLINOMIOS_T35.py')],capture_output=True,text=True,check=True)
print(result.stdout)
report=json.loads(result.stdout[result.stdout.index('{'):]);(out/'T35_POLINOMIOS_VERIFICACAO.json').write_text(json.dumps(report,indent=2))
