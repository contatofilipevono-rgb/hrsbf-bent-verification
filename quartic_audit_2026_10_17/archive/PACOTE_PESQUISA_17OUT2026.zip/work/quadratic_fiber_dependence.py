import sys,json
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
gs,_,_=setup(16)
def add(basis,v):
 while v:
  j=v.bit_length()-1
  if j in basis:v^=basis[j]
  else:basis[j]=v;return True
 return False
forms=json.load(open('work/post_T20_quadratic_factored.json'));L=[sum(1<<j for j in side) for term in forms['products'] for side in [term['I'],term['J']]];R=sum(1<<j for j in forms['linear'])
report=[]
for zs,label in [([0,255],'two_fibers'),([0,85,170,255,51],'T16'),([v|(v<<4) for v in range(16)],'T17')]:
 basis={}
 for z in zs:
  for u in range(256):
   x=u|((u^z)<<8);vector=sum(((w>>x)&1)<<j for j,(_,w) in enumerate(gs));add(basis,vector)
 old=len(basis);indicators=[]
 for form in L+[R]:
  copy=dict(basis);indicators.append(not add(copy,form))
 joint=dict(basis)
 for form in L+[R]:add(joint,form)
 rec={'restriction':label,'rank':old,'each_form_determined_by_restriction':indicators,'rank_after_all_forms':len(joint),'new_dimensions':len(joint)-old};report.append(rec);print(rec)
open('work/quadratic_fiber_dependence.json','w').write(json.dumps(report,indent=2))
