import sys,json,time,random
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks
import numpy as np
n=12;dim=21;gs,even,masks=setup(n);N=len(gs)
rng=random.Random(20261017110);x=np.arange(1<<n,dtype=np.uint32);half=x[x%2==0]
truth=np.stack([np.unpackbits(np.frombuffer(w.to_bytes((1<<n)//8,'little'),dtype=np.uint8),bitorder='little') for _,w in gs])
dirs=[1]+[1|(1<<d) for d in range(1,n//2+1)];sig=[truth[:,half]^truth[:,half^a] for a in dirs]
seed=int('7332b53f99b',16);best=5120;pool=[seed];records=[];start=time.perf_counter();winner=None
for block in range(96):
 parent=seed if block%3==0 else pool[rng.randrange(len(pool))]
 free=sorted(rng.sample(range(N),dim));base=parent
 for col in free:base&=~(1<<col)
 active=[j for j in range(N) if base>>j&1];E=np.zeros(1<<dim,dtype=np.int64);C=[]
 for lam in sig:
  parity=np.bitwise_xor.reduce(lam[active],axis=0) if active else np.zeros(len(half),dtype=np.uint8)
  weights=2-4*parity.astype(np.int32);projected=np.zeros(len(half),dtype=np.uint32)
  for k,col in enumerate(free):projected|=lam[col].astype(np.uint32)<<k
  v=np.bincount(projected,weights=weights,minlength=1<<dim).astype(np.int32)
  for k in range(dim):
   vv=v.reshape(-1,2,1<<k);a=vv[:,0,:].copy();b=vv[:,1,:].copy();vv[:,0,:]=a+b;vv[:,1,:]=a-b
  E+=v.astype(np.int64)**2;C.append(v)
 inds=np.argpartition(E,15)[:16];inds=inds[np.argsort(E[inds])];candidates=[]
 for s in inds:
  c=base|sum(((int(s)>>k)&1)<<j for k,j in enumerate(free));candidates.append(c)
  if int(E[s])<=best:
   vals=[int(v[s]) for v in C];tt=0
   for j,(_,w) in enumerate(gs):
    if c>>j&1:tt^=w
   assert vals==list(checks(tt,n,even,masks))
   if winner is None or int(E[s])<best:
    best=int(E[s]);seed=c;winner={'coefficient_hex':hex(c),'energy':best,'correlations':vals}
    print('BEST',block,winner,flush=True)
 pool=list(dict.fromkeys(candidates+pool))[:64]
 records.append({'block':block,'base':hex(base),'free_columns':free,'minimum_energy':int(E[inds[0]])})
 report={'n':n,'dimension':dim,'slices':len(records),'evaluations_with_possible_overlap':len(records)*(1<<dim),'best':winner,'global_lower_bound_proven':False,'seed':20261017110,'seconds':time.perf_counter()-start,'records':records}
 open('work/attack_n12.json','w').write(json.dumps(report,indent=2))
 if block%8==7:print('PROGRESS',block+1,best,round(report['seconds'],2),flush=True)
 if best==0:break
