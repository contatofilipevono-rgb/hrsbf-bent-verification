"""Explicit cubic obstructions from the classical integer-ANF criterion."""
import sys,json,time
from itertools import combinations
from collections import Counter
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,rotations
start=time.perf_counter();gs,_,_=setup(16);index={m:j for j,(orb,_) in enumerate(gs) for m in orb};powers=[1<<j for j in range(116)];L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
reps=[];polys=[];info=[]
def toggle(poly,term):
 if term in poly:poly.remove(term)
 else:poly.add(term)
for weight in [11,12]:
 seen=set()
 for T in combinations(range(16),weight):
  u=sum(1<<j for j in T)
  if u in seen:continue
  orb=rotations(u,16);seen.update(orb);poly=set()
  if weight==11:
   for shared in T:
    rest=[j for j in T if j!=shared]
    for D in combinations(rest,4):
     remaining=sorted(set(rest)-set(D));third=index[sum(1<<j for j in D)];v=1<<shared
     for other in combinations(remaining[1:],2):
      A=(remaining[0],)+other;B=set(remaining)-set(A)
      a=index[v|sum(1<<j for j in A)];b=index[v|sum(1<<j for j in B)]
      toggle(poly,powers[a]|powers[b]|powers[third])
  else:
   for other in combinations(T[1:],3):
    A=(T[0],)+other;remaining=sorted(set(T)-set(A));a=index[sum(1<<j for j in A)]
    for last in combinations(remaining[1:],3):
     B=(remaining[0],)+last;C=set(remaining)-set(B);b=index[sum(1<<j for j in B)];c=index[sum(1<<j for j in C)]
     toggle(poly,powers[a]|powers[b]|powers[c])
  # Linear substitutions from the three proved T20 laws, over F2.
  reduced=set()
  for m in poly:
   if m>>115&1:continue
   if m>>113&1:m=(m^(1<<113))|(1<<57)
   terms=[m] if not(m>>99&1) else [(m^(1<<99))|(1<<j) for j in L]
   for term in terms:toggle(reduced,term)
  reps.append(u);polys.append(reduced);info.append({'weight':weight,'support_mask':u,'raw_terms':len(poly),'terms_after_linear_laws':len(reduced),'degree_histogram':dict(Counter(m.bit_count() for m in reduced))})
  if len(info)%32==0:print('POLYNOMIALS',len(info),'seconds',round(time.perf_counter()-start,2),flush=True)
features=sorted(set().union(*polys),key=lambda m:(m.bit_count(),m));feature_index={m:j for j,m in enumerate(features)};nbytes=(len(features)+7)//8;rows=np.zeros((len(polys),nbytes),dtype=np.uint8)
for i,poly in enumerate(polys):
 ix=np.array([feature_index[m] for m in poly],dtype=np.int64);np.bitwise_or.at(rows[i],ix//8,(1<<(ix%8)).astype(np.uint8))
rowwords=[int.from_bytes(row.tobytes(),'little') for row in rows];basis={};basis_combo={};low=[]
for i,row in enumerate(rowwords):
 v=row;combo=1<<i
 while v:
  pivot=v.bit_length()-1
  if pivot in basis:v^=basis[pivot];combo^=basis_combo[pivot]
  else:
   basis[pivot]=v;basis_combo[pivot]=combo
   if features[pivot].bit_count()<3:low.append({'degree':features[pivot].bit_count(),'combination_hex':hex(combo),'terms_hex':[hex(features[j]) for j in range(len(features)) if v>>j&1]})
   break
feature_masks=np.array([[m&((1<<64)-1),m>>64] for m in features],dtype=np.uint64).reshape(-1,2)
np.savez_compressed('work/anf_cubic_obstructions.npz',supports=np.array(reps,dtype=np.uint16),feature_masks=feature_masks,polynomial_bitsets=rows)
# Independent truth-table Möbius checks on saved sample, including weight12.
samples=json.load(open('work/anf_2adic_probe.json'))['records'];checked=0
for rec in samples[:16]:
 c=int(rec['coefficient_hex'],16);tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 truth=np.unpackbits(np.frombuffer(tt.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little');h=1-2*truth.astype(np.int32)
 for k in range(16):v=h.reshape(-1,2,1<<k);v[:,1,:]-=v[:,0,:]
 assert all(h[u]%8==0 for u in reps)
 lo=np.uint64(c&((1<<64)-1));hi=np.uint64(c>>64)
 vals=((feature_masks[:,0]&lo)==feature_masks[:,0])&((feature_masks[:,1]&hi)==feature_masks[:,1]);packed=int.from_bytes(np.packbits(vals,bitorder='little').tobytes(),'little')
 actual=[(row&packed).bit_count()%2 for row in rowwords];expected=[int(h[u]//8)%2 for u in reps]
 assert actual==expected
 checked+=len(reps)
report={'polynomials':len(polys),'by_support_weight':dict(Counter(a['weight'] for a in info)),'formal_feature_count':len(features),'formal_polynomial_rank':len(basis),'degree_at_most_two_combinations':low,'independent_truth_table_polynomial_checks':checked,'per_polynomial':info,'seconds':time.perf_counter()-start,'scope':'Exact necessary h_f(u)/8 mod2 equations after three T20 linear substitutions; the classical criterion demands stronger divisibility at weight12. No system infeasibility claim.'}
Path('work/anf_cubic_obstructions_report.json').write_text(json.dumps(report,indent=2));print('DONE',{k:v for k,v in report.items() if k not in ['per_polynomial','degree_at_most_two_combinations']},'low_degree_rows',len(low),flush=True)
