from pathlib import Path
import json
out=Path('outputs')
cert={'branch_models':json.load(open('work/T28_branch_reports.json')),'reduced_models':json.load(open('work/T28_after_all_five.json')),'quadratic_restrictions':json.load(open('work/T28_exact_restriction_rank.json')),'fourth_factorization':json.load(open('work/post_T20_quadratic_factored.json')),'fifth_factorization':json.load(open('work/fifth_quadratic.json'))}
(out/'T28_SEXTA_CERTIFICADO.json').write_text(json.dumps(cert,indent=2),encoding='utf-8')
for name in ['T28_independent_verification.json','cubic_native_xor_report.json','T28_constant_mixed_derivatives.json','T28_chart_gap_weight.json']:
 (out/name).write_bytes((Path('work')/name).read_bytes())
src=Path('work/verify_T28_independent.py').read_text()
src=src.replace("start=time.perf_counter();seen=set();orbits=[]", "base=Path(__file__).resolve().parent\ncertificate=json.loads((base/'T28_SEXTA_CERTIFICADO.json').read_text())\nstart=time.perf_counter();seen=set();orbits=[]")
src=src.replace("json.load(open('work/post_T20_quadratic_factored.json'))", "certificate['fourth_factorization']")
src=src.replace("json.load(open('work/fifth_quadratic.json'))", "certificate['fifth_factorization']")
src=src.replace("json.load(open('work/T28_after_all_five.json'))", "certificate['reduced_models']")
marker="report={'branches':reports"
extra='''# Complete coefficient reconstruction, not random interpolation.
pair_positions=[v*64+w for v in range(64) for w in range(v+1,64)]
pair_words=[sum(((word>>pos)&1)<<k for k,pos in enumerate(pair_positions)) for word in words]
offset=sum(((points[pos].bit_count())%2)<<k for k,pos in enumerate(pair_positions))
diagonal_words=[sum(((word>>(v*64+v))&1)<<v for v in range(64)) for word in words]
Da=diagonal_words[57]^diagonal_words[113];Db=diagonal_words[99]
for j in range(116):
 if j not in [57,99,113,115]:assert diagonal_words[j]==0
for a in range(2):
 for b in range(2):assert 64-2*((Da if a else 0)^(Db if b else 0)).bit_count()==16*(4-2*a-3*b)
def toggle(p,m):
 if m in p:p.remove(m)
 else:p.add(m)
coefficient_checks=0;restriction_checks=[]
for branch,raw,reduced,restriction in zip(range(2),certificate['branch_models']['branches'],data['branches'],certificate['quadratic_restrictions']):
 free=raw['free_indices'];origin=(1<<0)|(1<<99) if branch else 0
 O=offset^(pair_words[0]^pair_words[99] if branch else 0);basis=[];coefficient_basis=[]
 for j in free:
  c=(1<<j)^((1<<0) if j in L else 0)
  if branch:
   if j in K:c^=(1<<57)|(1<<113)
  elif j==57:c^=1<<113
  coefficient_basis.append(c);w=0
  for k in range(116):
   if c>>k&1:w^=pair_words[k]
  basis.append(w)
 assert O.bit_count()%4==0
 assert all(w.bit_count()%2==0 and (w.bit_count()-2*(O&w).bit_count())%4==0 for w in basis)
 assert all((v&w).bit_count()%2==0 for v,w in combinations(basis,2))
 P=set()
 if (branch+O.bit_count()//4)%2:toggle(P,0)
 for i,w in enumerate(basis):
  if ((w.bit_count()-2*(O&w).bit_count())//4)%2:toggle(P,1<<free[i])
 for i,j in combinations(range(len(free)),2):
  intersection=basis[i]&basis[j]
  if (intersection.bit_count()//2+(O&intersection).bit_count())%2:toggle(P,(1<<free[i])|(1<<free[j]))
 for i,j,k in combinations(range(len(free)),3):
  if (basis[i]&basis[j]&basis[k]).bit_count()%2:toggle(P,(1<<free[i])|(1<<free[j])|(1<<free[k]))
 assert P==set(int(m,16) for m in raw['monomials_hex'])
 def form(indices):
  mask=sum(1<<j for j in indices)
  return {(1<<j) for j,c in zip(free,coefficient_basis) if (c&mask).bit_count()%2} ^ ({0} if (origin&mask).bit_count()%2 else set())
 Q=form(factor['linear'])
 for block in factor['products']:
  for a in form(block['I']):
   for b in form(block['J']):toggle(Q,a|b)
 assert (1<<23) in Q and all(not m>>23&1 for m in Q if m.bit_count()>1)
 Q.remove(1<<23);R=set()
 for m in P:
  if m>>23&1:
   for n in Q:toggle(R,(m^(1<<23))|n)
  else:toggle(R,m)
 assert R==set(int(m,16) for m in reduced['polynomial_hex'])
 coefficient_checks+=len(P)+len(R)
 S=restriction['coordinates'];mask=sum(1<<j for j in S)
 assert all((m&mask).bit_count()<=1 for m in R if m.bit_count()>2)
 quadratic={m for m in R if m.bit_count()==2 and m&mask==m}
 values=[]
 for z in range(1<<len(S)):
  assignment=sum(((z>>i)&1)<<j for i,j in enumerate(S))
  values.append(sum((assignment&m)==m for m in quadratic)%2)
 weights=[sum(value^((z&linear).bit_count()%2) for z,value in enumerate(values)) for linear in range(1<<len(S))]
 minimum=min(min(weights),len(values)-max(weights))
 numerator,denominator=restriction['violation_fraction_lower_bound']
 assert minimum*denominator==len(values)*numerator
 restriction_checks.append({'branch':branch,'dimension':len(S),'affine_restrictions_exhaustively_checked':2*(1<<len(S)),'minimum_ones':minimum,'subcube_size':len(values)})
assert restriction_checks[0]['minimum_ones']*4==restriction_checks[0]['subcube_size']
assert restriction_checks[1]['minimum_ones']*8==3*restriction_checks[1]['subcube_size']
print('Complete polynomial reconstruction PASS:',coefficient_checks,'coefficient terms; subcube certificates:',restriction_checks)
'''
src=src.replace(marker,extra+'\n'+marker)
src=src.replace("'45/1024'", "'17/512'").replace("'979/1024'", "'495/512'").replace("'degree-four minimum-weight bound; no exact sixth-condition density or nonexistence claim'", "'certified quadratic-subcube minimum weights; no exact sixth-condition density or nonexistence claim'")
src=src.replace("Path('work/T28_independent_verification.json').write_text(json.dumps(report,indent=2));", "")
(out/'VERIFICAR_SEXTA_CONDICAO.py').write_text(src,encoding='utf-8')
import subprocess,sys
result=subprocess.run([sys.executable,str(out/'VERIFICAR_SEXTA_CONDICAO.py')],capture_output=True,text=True,check=True)
report=json.loads(result.stdout.splitlines()[-1]);report['complete_polynomial_reconstruction_verified']=True
report['quadratic_subcube_minimum_weight_certificates_verified']=True
(out/'T28_VERIFICACAO.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(result.stdout)
