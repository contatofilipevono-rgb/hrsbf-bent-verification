from pathlib import Path
import json,shutil,subprocess,sys
out=Path('outputs');verified=json.load(open(out/'T35_LIMITE_VERIFICACAO.json'));assert verified['verification']=='PASS' and verified['independent_quadratic_bias_checks']==4800
shutil.copyfile('work/T35_NOVE_CONDICOES_draft.md',out/'T35_NOVE_CONDICOES.md')
p=out/'LEIA_PRIMEIRO.md';s=p.read_text(encoding='utf-8');s=s.replace('98,7541%','99,6274%').replace('por sete condições necessárias','por nove condições necessárias').replace('**T32_COMBINACAO_SEIS_SETE.md:** prova do limite global de exclusão de 99,6274%, incluindo a sexta condição e somas quadráticas racionais exatas.','**T35_NOVE_CONDICOES.md:** prova do limite global de exclusão de 99,6274%. Um único lema vetorial combina três bits periódicos; todos os polinômios e 4.800 somas quadráticas foram conferidos independentemente.');p.write_text(s,encoding='utf-8')
p=out/'REGISTRO_PESQUISA.md';s=p.read_text(encoding='utf-8');s=s.replace('## Alternativas seguintes, em ordem de utilidade','''## R21 — Nove condições, um lema vetorial e exclusão de 99,6274%

**Estado: polinômios completos e 4.800 somas conferidos por método independente.** Aos sete filtros anteriores foram acrescentados os segundos bits nos suportes periódicos 0x5f5f e 0x6f6f. Os três bits em 0x3f3f, 0x5f5f e 0x6f6f foram analisados conjuntamente, após a forma normal de seis condições, em uma mesma restrição quadrática nas coordenadas {27,64,73,77,88,92,112}.

Um lema de caracteres vetoriais reduz a passagem conjunta a sete módulos de somas quadráticas. As densidades radicais são calculadas exatamente, condicionando no máximo três coordenadas externas para obter somas quadráticas. A fração global que pode passar é no máximo **2097035386883/562949953421312**, excluindo pelo menos **99,6274916848046%**. Isso não é densidade exata nem inexistência global.

O primeiro verificador reconstrói 226.930 termos de coeficientes dos seis modelos de ramos e confere 192 avaliações da ANF original. O segundo confere todos os postos, bases radicais, derivadas e 4.800 somas quadráticas por base simplética, independente da eliminação de pares usada na geração. Arquivos: `T35_NOVE_CONDICOES.md`, `VERIFICAR_POLINOMIOS_T35.py`, `VERIFICAR_LIMITE_CONJUNTO_T35.py` e seus certificados/relatórios.

O mesmo lema com apenas um bit contém T28/T29/T32, simplificando a organização das provas. O domínio GPU continua em T33; os dois novos bits ainda não foram incorporados ao quociente. Novidade bibliográfica continua não estabelecida.

## Alternativas seguintes, em ordem de utilidade''');p.write_text(s,encoding='utf-8')
p=out/'MANUSCRITO_RASCUNHO.md';s=p.read_text(encoding='utf-8');s=s.replace('A fifth factored condition from the integer ANF leaves exactly 3/64 of the original coefficient space as candidates.','A factored six-condition normal form is controlled by eleven aggregate parities and leaves exactly 3/128 of the original coefficient space. Combining three additional periodic second bits through one vector-character lemma gives a rigorous pass fraction at most 2097035386883/562949953421312, excluding at least 99.6274916848046%. All coefficient models and 4,800 quadratic sums have independent checks.');s=s.replace('## 5. Quintic obstruction and open searches','''### A common vector-character bound for nine necessary conditions

The first three linear laws together with Q4, the fifth, and the seventh conditions have a small normal form in eleven aggregate parities. Nine bits are chosen freely, one forbidden two-bit pattern is removed, and two parities are reconstructed. Only 384 of 512 patterns are admissible. The rank of the three laws and eleven aggregate forms is fourteen, so the original fraction is exactly 3/128.

On each of the two resulting affine charts, consider the three necessary integer-ANF bits at supports 0x3f3f, 0x5f5f, 0x6f6f, after the exact substitutions. Their restrictions to S={27,64,73,77,88,92,112} are quadratic with constant polar forms. For any vector P of m such bits, let r_lambda be the polar rank of a nonzero character combination and Z_lambda the common-zero density of its radical derivatives in the external coordinates. Character expansion and the quadratic Gauss-sum modulus give Pr(P=0) ≤ 2^(−m)(1+sum_lambda 2^(−r_lambda/2) Z_lambda). This includes the earlier scalar bounds as m=1.

For m=3, all radical-zero densities can be evaluated exactly after conditioning on at most three coordinates. The two conditional pass bounds are 1375476686851/8796093022208 and 172033/1048576. Their chart measures are 1/64 and 1/128, yielding global pass at most 2097035386883/562949953421312. All coefficients of the six chart models were reconstructed; 192 original-ANF evaluations and 4,800 quadratic sums were checked independently. The exact survivor density is not known. See T34_FORMA_NORMAL.md and T35_NOVE_CONDICOES.md for the consolidated argument.

## 5. Quintic obstruction and open searches''');p.write_text(s,encoding='utf-8')
print('T34/T35 published; current overview and manuscript updated.')
