from pathlib import Path
import json,hashlib,zipfile,io
out=Path('outputs');files={name:(out/name).read_bytes() for name in ['GRAU4_T33_A100.py','GRAU4_T16_A100.py','T33_parameterization.npz','T33_exact_domain_report.json','T33_MAPPING_CPU_VALIDATION.json','T33_DESCIDA_CERTIFICADO.json','T33_DESCIDA_VERIFICACAO.json','VERIFICAR_DESCIDA_T33.py','T31_SETIMA_CERTIFICADO.json']}
files['LEIA_PRIMEIRO.md']='''# T33 — novo domínio exato para A100

O experimento retoma os filtros necessários de T16, impondo antes as três leis lineares demonstradas e as duas condições quadráticas. O domínio completo tem 162.537.472 estados, contra 1.604.829.184 da execução T16 anterior. Não são contagens de funções bent.

Use a mesma configuração NumPy/CuPy que já executou T16 na sua A100. O código não instala pacotes nem monta o Drive automaticamente. Se CuPy não estiver disponível, consulte https://docs.cupy.dev/en/stable/install.html e use o pacote compatível com o ambiente CUDA do Colab.

Primeiro execute o piloto padrão de 16.777.216 estados. Ele reconstrói as tabelas, compara geradores de estados e filtros GPU/CPU, salva checkpoint e estima o tempo restante a partir da velocidade medida. Só os resultados observados no piloto permitem estimar o custo real. Para prosseguir do checkpoint, execute run(full_scan=True).

O notebook inclui células separadas para piloto, continuação completa e download. O checkpoint fica na pasta T33_results da sessão. Baixe o arquivo de resultados antes de encerrar a sessão ou preserve essa pasta por conta própria.

Antes de esta entrega ser criada, a lógica de geração de estados foi verificada em CPU, incluindo todos os sistemas afins dos 111.876 pais retidos. Não houve execução GPU de T33 pelo assistente. Os testes CUDA/CPU estão incluídos e são obrigatórios antes da varredura.

Enviar GRAU4_T33_RESULTADOS.zip depois da execução permitirá conferir o manifesto, as contagens e o escopo. Um piloto não deve ser apresentado como varredura completa; sobreviventes não são certificados bent.
'''.encode('utf8')
manifest=''.join(hashlib.sha256(v).hexdigest()+'  '+n+'\n' for n,v in sorted(files.items()));files['SHA256SUMS.txt']=manifest.encode()
target=out/'GRAU4_T33_COLAB.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for n,v in sorted(files.items()):z.writestr(n,v)
cells=[]
def md(s):cells.append({'cell_type':'markdown','metadata':{},'source':s.splitlines(keepends=True)})
def code(s):cells.append({'cell_type':'code','execution_count':None,'metadata':{},'outputs':[],'source':s.splitlines(keepends=True)})
md('# T33: leis demonstradas e nova condição quadrática\n\nEscolha A100 em **Ambiente de execução → Alterar tipo de ambiente de execução**. Use o mesmo ambiente CuPy de T16. Este notebook começa por um piloto; depois é possível retomar a varredura completa no mesmo checkpoint.\n\nO domínio exato tem 162.537.472 estados. A execução GPU ainda não foi realizada pelo assistente; as conferências CPU/GPU abaixo são obrigatórias.\n')
code('''from google.colab import files
from pathlib import Path
import zipfile,io,hashlib,sys
uploaded=files.upload()  # selecione GRAU4_T33_COLAB.zip
name='GRAU4_T33_COLAB.zip'
if name not in uploaded: raise ValueError('Selecione o arquivo GRAU4_T33_COLAB.zip fornecido.')
root=Path('/content/GRAU4_T33');root.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(uploaded[name])) as archive:
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        expected,path=line.split('  ',1)
        assert hashlib.sha256(archive.read(path)).hexdigest()==expected,path
    archive.extractall(root)
sys.path.insert(0,str(root))
import cupy as cp
print('CuPy',cp.__version__,'GPU',cp.cuda.runtime.getDeviceProperties(0)['name'])
from GRAU4_T33_A100 import run
print('Pacote e manifesto conferidos.')
''')
md('## Piloto obrigatório\n\nEle compara a geração de estados e os filtros GPU/CPU, processa um prefixo explícito e salva checkpoint.\n')
code('result=run(full_scan=False, pilot_states=1<<24)\n')
md('## Varredura completa, retomando o checkpoint\n\nExecute esta célula após conferir que o piloto terminou com PASS e avaliar a velocidade medida. A célula continua até completar o domínio finito.\n')
code('# Remova o comentário para continuar a varredura completa:\n# result=run(full_scan=True)\n')
md('## Baixar os resultados\n\nUm piloto e uma varredura completa usam o mesmo nome de arquivo; o JSON interno identifica o alcance.\n')
code("from google.colab import files\nfiles.download(result)\n")
notebook={'nbformat':4,'nbformat_minor':5,'metadata':{'colab':{'name':'GRAU4_T33_A100.ipynb'},'kernelspec':{'name':'python3','display_name':'Python 3'},'language_info':{'name':'python'}},'cells':cells}
(out/'GRAU4_T33_A100.ipynb').write_text(json.dumps(notebook,indent=2,ensure_ascii=False),encoding='utf8')
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
print({'archive':str(target),'bytes':target.stat().st_size,'manifest_verified':True,'notebook_cells':len(cells)})
