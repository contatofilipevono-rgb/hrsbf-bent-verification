from pathlib import Path
import subprocess,sys
src=Path('work/T28_radical_polynomials.py').read_text().replace("data=json.load(open('work/T28_after_all_five.json'));", "data={'branches':[r for r in json.load(open('work/T32_combined_models.json')) if r['support_mask']=='0x3f3f']};").replace('T28_exact_restriction_rank.json','T32_exact_restriction_rank.json').replace('T28_radical_polynomials.json','T32_radical_polynomials.json')
Path('work/T32_radical_polynomials.py').write_text(src)
subprocess.run([sys.executable,'work/T32_radical_polynomials.py'],check=True)
src=Path('work/T28_exact_radical_density.py').read_text().replace('T28_radical_polynomials.json','T32_radical_polynomials.json').replace('T28_exact_restriction_rank.json','T32_exact_restriction_rank.json').replace('T28_exact_radical_density.json','T32_exact_radical_density.json').replace("32 if rec['branch']==0 else 64","64 if rec['branch']==0 else 128")
src=src.replace(' P=set(P);pairs=0',''' P=set(P)
 if any(m.bit_count()>2 for m in P):
  assert all(m.bit_count()<=3 and (m>>57&1) for m in P if m.bit_count()>2)
  values=[]
  for value in [0,1]:
   Q=set()
   for m in P:
    if m>>57&1:
     if value:toggle(Q,m^(1<<57))
    else:toggle(Q,m)
   values.append(bias(Q)[0])
  return sum(values)/2,-1,False
 pairs=0''').replace('  assert all(m.bit_count()<=2 for m in P)','  assert all(m.bit_count()<=3 for m in P)')
Path('work/T32_exact_radical_density.py').write_text(src)
subprocess.run([sys.executable,'work/T32_exact_radical_density.py'],check=True)
