import json,random,time,math
from pathlib import Path
from itertools import combinations
from collections import Counter
from fractions import Fraction
start=time.perf_counter();data=json.load(open('work/T40_all_seven_models.json'));supports=['0x3f3f','0x5f5f','0x6f6f','0x33ff','0x66ff','0x73bf','0x76ef'];branch=1;character=11;P=set()
for j,support in enumerate(supports):
 if character>>j&1:P^={int(m,16) for m in next(r for r in data if r['branch']==branch and r['support_mask']==support)['polynomial_hex']}
free=sorted(set(range(116))-{0,5,23,57,99,113,115});contractions={}
for m in P:
 if m.bit_count()==4:
  for j in free:
   if m>>j&1:contractions[m^(1<<j)]=contractions.get(m^(1<<j),0)^(1<<j)
def nullspace(rows,variables):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 out=[]
 for j in variables:
  if j in B:continue
  v=1<<j
  for p in sorted(B):
   if (v&B[p]).bit_count()%2:v^=1<<p
  out.append(v)
 return out
def derivative(P,d):
 out=set()
 for m in P:
  sub=m&d
  while sub:
   n=m^sub
   if n in out:out.remove(n)
   else:out.add(n)
   sub=(sub-1)&(m&d)
 return out
def rank(rows):
 B={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j in B:v^=B[j]
   else:B[j]=v;break
 return len(B)
radical=nullspace(contractions.values(),free);rng=random.Random(2026101743);directions=[];matrices=[]
while len(directions)<12:
 d=0
 for v in radical:
  if rng.randrange(2):d^=v
 if rank(directions+[d])==len(directions):continue
 D=derivative(P,d);assert all(m.bit_count()<=2 for m in D);rows=[0]*len(free);index={v:i for i,v in enumerate(free)}
 for m in D:
  if m.bit_count()==2:
   a=m&-m;b=m^a;i=index[a.bit_length()-1];j=index[b.bit_length()-1];rows[i]^=1<<j;rows[j]^=1<<i
 directions.append(d);matrices.append(rows)
print('quartic radical',len(radical),'selected directions',len(directions),'seconds',time.perf_counter()-start,flush=True)
current=[0]*len(free);old=0;hist=Counter();summation=Fraction(1)
for ordinal in range(1,1<<len(directions)):
 gray=ordinal^(ordinal>>1);changed=(gray^old).bit_length()-1;current=[a^b for a,b in zip(current,matrices[changed])];r=rank(current);assert r%2==0;hist[r]+=1;summation+=Fraction(1,2**(r//2));old=gray
square=summation/Fraction(1<<len(directions));scale=1<<40;ceil=math.isqrt((square.numerator*scale*scale)//square.denominator)
while ceil*ceil*square.denominator<square.numerator*scale*scale:ceil+=1
upper=Fraction(ceil,scale);report={'branch':branch,'character':character,'direction_space_dimension':len(radical),'subspace_dimension':len(directions),'rank_histogram':dict(hist),'squared_bias_upper_bound':str(square),'bias_upper_bound':str(upper),'bias_upper_bound_decimal':float(upper),'directions_hex':[hex(v) for v in directions],'matrices_hex':[[hex(v) for v in rows] for rows in matrices],'free_indices':free,'seconds':time.perf_counter()-start,'scope':'Exact finite-difference rank upper bound, exploratory until independently verified.'};Path('work/T43_derivative_rank_probe.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k not in ['directions_hex','matrices_hex','free_indices']},flush=True)
