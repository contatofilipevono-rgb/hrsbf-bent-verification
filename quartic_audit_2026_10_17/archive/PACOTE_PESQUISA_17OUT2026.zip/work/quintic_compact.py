"""Coefficient-only certificate for the first autocorrelation bit in n=16."""
import sys,json,time,random
from itertools import combinations
from functools import lru_cache
from pathlib import Path
sys.path.insert(0,'work/recovered')
from test_short_witness import setup,checks
def build():
 gs,even,masks=setup(16)
 index={m:j for j,(orb,_) in enumerate(gs) for m in orb}
 triples=[];labels=[[] for _ in range(9)]
 for T in combinations(range(1,16),3):
  mask=sum(1<<(i-1) for i in T);q=mask<<1;triples.append(mask)
  for d in range(9):
   js={index[q|1]}
   if d and d not in T:
    j=index[q|(1<<d)]
    if j in js:js.remove(j)
    else:js.add(j)
   labels[d].append(sum(1<<j for j in js))
 return gs,even,masks,triples,labels
def matching_parity(triples,edge_bits,k=15):
 edges={m:b for m,b in zip(triples,edge_bits) if b}
 @lru_cache(None)
 def F(mask):
  if not mask:return 1
  if mask.bit_count()==3:return edges.get(mask,0)
  p=mask&-mask;rem=mask^p;bits=[]
  while rem:b=rem&-rem;rem^=b;bits.append(b)
  out=0
  for j,k in combinations(bits,2):
   tri=p|j|k
   if tri in edges:out^=F(mask^tri)
  return out
 return F((1<<k)-1)
def main():
 start=time.perf_counter();gs,even,masks,triples,labels=build()
 model={'n':16,'variables':116,'coefficient_order':'First previously unseen cyclic orbit in combinations(range(16),4); distinct monomials only.','triple_masks_on_coordinates_1_to_15':triples,'linear_form_coefficient_masks_hex':[[hex(q) for q in L] for L in labels],'directions':[1]+[1|(1<<d) for d in range(1,9)],'interpretation':'P_d is the parity of perfect matchings of the 15-vertex 3-uniform hypergraph with edge coefficient parity(c & label[d,T]); C_f(a_d)/64 == P_d mod 2.','max_degree':5,'necessary_for_PC2':'P_0 = ... = P_8 = 0','sufficient_for_PC2':False}
 Path('work/quintic_compact_model.json').write_text(json.dumps(model,indent=2))
 probe=json.load(open('work/parity_probe.json'))
 choices=[probe['examples'][str(1<<j)] for j in range(9)]+[probe['examples']['0']]
 rng=random.Random(20261016104)
 for _ in range(22):
  c=rng.getrandbits(116);tt=0
  for j,(_,word) in enumerate(gs):
   if c>>j&1:tt^=word
  choices.append({'c':hex(c),'correlations':list(checks(tt,16,even,masks))})
 records=[]
 for it,ex in enumerate(choices):
  c=int(ex['c'],16);p=[]
  for d in range(9):
   bit=matching_parity(triples,[(c&L).bit_count()%2 for L in labels[d]])
   assert bit==((ex['correlations'][d]//64)&1)
   p.append(bit)
  records.append({'coefficients_hex':hex(c),'correlations':ex['correlations'],'quintic_bits':p})
  if it%4==0:print('CHECK',it,'seconds',round(time.perf_counter()-start,2),flush=True)
 report={'coefficient_words_checked':len(records),'quintic_vs_truth_table_checks':len(records)*9,'all_pass':True,'linear_independence_certificate':records[:9],'zero_quintic_system_not_sufficient_example':records[9],'random_seed':20261016104,'seconds':time.perf_counter()-start,'records':records}
 Path('work/quintic_compact_validation.json').write_text(json.dumps(report,indent=2))
 print('DONE',report['quintic_vs_truth_table_checks'],report['seconds'],flush=True)
if __name__=='__main__':main()
