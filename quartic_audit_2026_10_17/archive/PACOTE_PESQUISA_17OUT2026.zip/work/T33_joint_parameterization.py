import json
from pathlib import Path
import numpy as np
data=dict(np.load('outputs/T27_parameterization.npz'));forms=json.load(open('work/T33_quotient_counts.json'))['forms_masks33_hex'];masks={k:int(v,16) for k,v in forms.items()};r=masks['R']>>21;assert r and r<4096
def parity(ids,mask):return (np.bitwise_count(ids&np.uint64(mask))%2).astype(np.uint8)
def condition(ids):
 R,M,K,a,b=[parity(ids,masks[name]) for name in ['R','M','K','a','b']]
 return R^M^K^(b&M)^(a&K)
parents=data['parents_11'];g=data['gradient_11'].astype(np.uint32);c=data['constant_11'].astype(np.uint8);s=condition(parents)
same=g==r;consistent=s==c;rank2=~same;single=same&consistent;none=same&~consistent
ga=[];gb=[];ca=[];cb=[];pivots=[]
for gi,ci,si in zip(g[rank2],c[rank2],s[rank2]):
 gi=int(gi);ci=int(ci);si=int(si);p=(gi&-gi).bit_length()-1;ri=r^ (gi if r>>p&1 else 0);ti=si^(ci if r>>p&1 else 0);q=(ri&-ri).bit_length()-1
 gi2=gi^(ri if gi>>q&1 else 0);ci2=ci^(ti if gi>>q&1 else 0)
 assert gi2>>p&1 and not gi2>>q&1 and ri>>q&1 and not ri>>p&1
 ga.append(gi2);gb.append(ri);ca.append(ci2);cb.append(ti);pivots.append([p,q])
single_parents=np.r_[data['parents_12'],parents[single]]
out={'P':data['P'],'parents_10':parents[rank2],'gradient_a':np.array(ga,dtype=np.uint16),'gradient_b':np.array(gb,dtype=np.uint16),'constant_a':np.array(ca,dtype=np.uint8),'constant_b':np.array(cb,dtype=np.uint8),'pivot_a':np.array([p for p,q in pivots],dtype=np.uint8),'pivot_b':np.array([q for p,q in pivots],dtype=np.uint8),'parents_11':single_parents,'gradient_11':np.full(len(single_parents),r,dtype=np.uint16),'constant_11':condition(single_parents)}
np.savez_compressed('work/T33_parameterization.npz',**out)
report={'original_T27_domain':325074944,'extension_seventh_gradient12_hex':hex(r),'parents_rank_two':int(rank2.sum()),'parents_rank_one':len(single_parents),'coincident_equations':int(same.sum()),'coincident_consistent':int(single.sum()),'inconsistent_parents':int(none.sum()),'rank_two_extensions_per_parent':1024,'rank_one_extensions_per_parent':2048,'complete_T33_domain':int(rank2.sum())*1024+len(single_parents)*2048,'scope':'Exact domain before final energy and Poisson filters, satisfying first five conditions and seventh condition. Sixth does not descend and is not imposed. GPU not executed.'}
Path('work/T33_joint_domain_report.json').write_text(json.dumps(report,indent=2));print(report)
