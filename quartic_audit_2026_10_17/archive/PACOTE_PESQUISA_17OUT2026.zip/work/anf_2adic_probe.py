"""Pilot for the complete classical 2-adic ANF criterion, after four proved conditions."""
import sys,json,random,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'work/recovered')
from test_short_witness import setup
start=time.perf_counter();gs,_,_=setup(16);x=np.arange(65536,dtype=np.uint32);weight=np.bitwise_count(x)
canonical=x.copy();rotation=x.copy()
for _ in range(15):rotation=((rotation<<1)&65535)|(rotation>>15);canonical=np.minimum(canonical,rotation)
reps={w:np.unique(canonical[weight==w]) for w in range(11,17)}
def transform(truth):
 h=1-2*truth.astype(np.int32)
 for k in range(16):
  v=h.reshape(-1,2,1<<k);v[:,1,:]-=v[:,0,:]
 return h
def tests(h):
 out={}
 for w in range(11,16):out[str(w)]=int(np.count_nonzero(h[reps[w]]%(1<<(w-7))))
 out['full_support_good']=int(h[65535]%512==256)
 return out
control_truth=(np.bitwise_count((x&255)&(x>>8))%2).astype(np.uint8);control=tests(transform(control_truth));assert all(control[str(w)]==0 for w in range(11,16)) and control['full_support_good']
factor=json.load(open('work/post_T20_quadratic_factored.json'));L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106];rng=random.Random(20261017208);records=[];binary_basis={}
for it in range(64):
 c=rng.getrandbits(116)&~sum(1<<j for j in [57,99,113,115]);c|=(sum(c>>j&1 for j in L)%2)<<99
 a=sum(c>>j&1 for j in [23,31,39,112])%2
 for block in factor['products']:a^=(sum(c>>j&1 for j in block['I'])%2)&(sum(c>>j&1 for j in block['J'])%2)
 c|=a<<57;c|=a<<113
 tt=0
 for j,(_,word) in enumerate(gs):
  if c>>j&1:tt^=word
 W0=65536-2*tt.bit_count();assert W0%256==0
 truth=np.unpackbits(np.frombuffer(tt.to_bytes(8192,'little'),dtype=np.uint8),bitorder='little');h=transform(truth);assert np.all(h[reps[11]]%8==0)
 bits=(h[reps[11]]//8)%2;vector=sum(int(b)<<j for j,b in enumerate(bits));v=vector
 while v:
  j=v.bit_length()-1
  if j in binary_basis:v^=binary_basis[j]
  else:binary_basis[j]=v;break
 rec={'coefficient_hex':hex(c),'W0':W0,'violations_by_support_weight':tests(h),'weight11_pattern_hex':hex(vector)};records.append(rec)
report={'sampled_functions_passing_four_conditions':len(records),'weight11_orbits':len(reps[11]),'support_orbits_counts':{str(w):len(rs) for w,rs in reps.items()},'positive_control':control,'weight11_empirical_pattern_rank':len(binary_basis),'passed_weight11':sum(r['violations_by_support_weight']['11']==0 for r in records),'records':records,'seconds':time.perf_counter()-start,'scope':'Random functions from the four-condition parametrization; not exhaustive and not a claim of a global rejection rate. Criterion is classical; this experiment probes which additional equations are informative.'}
Path('work/anf_2adic_probe.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='records'})
