"""Bounded native-XOR SAT pilot; a SAT model is only a necessary-condition candidate."""
import os,sys,json,time,pathlib
sys.path.insert(0,'work/deps_local')
dll_handles=[os.add_dll_directory(str(p.parent.resolve())) for p in pathlib.Path('work/deps_local/pycryptosat-5.17.0.data').rglob('*.dll')]
import pycryptosat
import numpy as np
start=time.perf_counter();s=pycryptosat.Solver(time_limit=45,threads=1)
data=np.load('work/anf_cubic_obstructions.npz');features=[int(a)|(int(b)<<64) for a,b in data['feature_masks']]
nextvar=116;cache={1<<j:j+1 for j in range(116)};clauses=0
def variable(m):
 global nextvar,clauses
 if m in cache:return cache[m]
 bit=m&-m;a=variable(bit);b=variable(m^bit);nextvar+=1;y=nextvar
 s.add_clause([-y,a]);s.add_clause([-y,b]);s.add_clause([y,-a,-b]);clauses+=3;cache[m]=y;return y
for m in features:variable(m)
print('AND built',nextvar,clauses,'seconds',time.perf_counter()-start,flush=True)
xors=0;literals=0
def equation(poly,rhs=False):
 global xors,literals
 row=[variable(m) for m in poly if m];rhs=bool(rhs)^(0 in poly)
 s.add_xor_clause(row,rhs);xors+=1;literals+=len(row)
for row in data['polynomial_bitsets']:
 bits=np.unpackbits(row,bitorder='little')[:len(features)];equation([features[i] for i in np.flatnonzero(bits)])
factor=json.load(open('work/post_T20_quadratic_factored.json'));Q=set(1<<j for j in factor['linear'])
for block in factor['products']:
 for j in block['I']:
  for k in block['J']:
   m=(1<<j)|(1<<k)
   if m in Q:Q.remove(m)
   else:Q.add(m)
equation(Q)
L=[0,4,8,14,18,22,42,46,52,56,71,81,85,94,98,106]
K=[j for j in json.load(open('work/fifth_quadratic.json'))['I'] if j!=57]
equation([1<<j for j in L],True);equation([1<<j for j in K+[57]])
P=json.load(open('work/T28_branch_reports.json'))['branches'][1]
equation([int(m,16) for m in P['monomials_hex']])
s.add_clause([100]);s.add_clause([-116]);s.add_xor_clause([58,114],False)
print('SYSTEM',nextvar,clauses,xors,literals,'build seconds',time.perf_counter()-start,flush=True)
t=time.perf_counter();answer,model=s.solve();elapsed=time.perf_counter()-t
report={'solver':'pycryptosat '+pycryptosat.__version__,'branch_c99':1,'variables':nextvar,'and_clauses':clauses,'xor_equations':xors+1,'xor_literals':literals+2,'time_limit_seconds':45,'solve_seconds':elapsed,'answer':answer,'scope':'389 cubic necessary conditions, Q4, fifth branch constraints, and next h/16 bit; no full bentness encoding and no independent UNSAT proof.'}
if answer:
 c=sum((bool(model[j+1]))<<j for j in range(116));report['coefficient_hex']=hex(c)
 assignment=c;violations=[]
 for i,row in enumerate(data['polynomial_bitsets']):
  bits=np.unpackbits(row,bitorder='little')[:len(features)]
  if sum((assignment&features[j])==features[j] for j in np.flatnonzero(bits))%2:violations.append(i)
 assert not violations
 report['all_389_polynomials_verified']=True
pathlib.Path('work/cubic_native_xor_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
