from pathlib import Path
from itertools import combinations
from collections import Counter
import numpy as np
import json,time

OUT=Path('outputs');OUT.mkdir(exist_ok=True)

def rotations(m,n):
    return sorted({((m<<k)|(m>>(n-k)))&((1<<n)-1) for k in range(n)})

def setup(n):
    seen=set();gs=[];x=np.arange(1<<n,dtype=np.uint32)
    for t in combinations(range(n),4):
        m=sum(1<<i for i in t)
        if m in seen:continue
        orb=rotations(m,n);seen.update(orb)
        a=np.zeros(1<<n,dtype=np.uint8)
        for q in orb:a^=((x&q)==q)
        gs.append((orb,int.from_bytes(np.packbits(a,bitorder='little').tobytes(),'little')))
    even=int.from_bytes(np.packbits((x&1)==0,bitorder='little').tobytes(),'little')
    masks=[int.from_bytes(np.packbits((x&(1<<d))==0,bitorder='little').tobytes(),'little') for d in range(1,n//2+1)]
    return gs,even,masks

def checks(tt,n,even,masks):
    a=tt&even;b=(tt>>1)&even
    yield (1<<n)-4*(a^b).bit_count()
    for d,mask in enumerate(masks,1):
        shift=1<<d
        perm=((b>>shift)&mask)|((b&mask)<<shift)
        yield (1<<n)-4*(a^perm).bit_count()

def run(n,exhaustive,limit,seed):
    gs,even,masks=setup(n);start=time.perf_counter()
    hist=np.zeros(n//2+2,dtype=np.int64);prefix_examples={};positive=hist.copy();negative=hist.copy()
    rng=np.random.default_rng(seed);tt=0;c=0;processed=0;counterexamples=[]
    if exhaustive:limit=1<<len(gs)
    for i in range(limit):
        if exhaustive:
            if i:
                bit=(i&-i).bit_length()-1
                tt^=gs[bit][1];c^=1<<bit
        else:
            raw=rng.bytes((len(gs)+7)//8)
            c=int.from_bytes(raw,'little')&((1<<len(gs))-1)
            tt=0;v=c
            while v:
                bit=(v&-v).bit_length()-1;tt^=gs[bit][1];v&=v-1
        for k,S in enumerate(checks(tt,n,even,masks)):
            if S:
                hist[k]+=1
                if S>0:positive[k]+=1
                else:negative[k]+=1
                prefix_examples.setdefault(str(k),{'coefficients_hex':hex(c),'first_nonzero_correlation':S})
                break
        else:
            hist[-1]+=1
            counterexamples.append({'coefficients_hex':hex(c),'supports':[gs[j][0][0] for j in range(len(gs)) if c>>j&1]})
        processed=i+1
        if len(counterexamples)>=4:break
    r={'n':n,'quartic_orbits':len(gs),'exhaustive_requested':exhaustive,
       'processed':processed,'full_space':str(1<<len(gs)),'seed':seed,
       'directions':[1]+[1|(1<<d) for d in range(1,n//2+1)],
       'first_nonzero_histogram':hist.tolist(),'positive_first':positive.tolist(),'negative_first':negative.tolist(),
       'prefix_examples':prefix_examples,'counterexamples':counterexamples,
       'seconds':time.perf_counter()-start}
    (OUT/f'TESTEMUNHAS_CURTAS_n{n}.json').write_text(json.dumps(r,indent=2),encoding='utf8')
    print(json.dumps(r),flush=True)
    return r

if __name__=='__main__':
    result=[]
    for n,exhaustive,limit in [(8,True,0),(10,True,0),(12,False,100000),(16,False,20000)]:
        result.append(run(n,exhaustive,limit,20261016+n))
    (OUT/'TESTEMUNHAS_CURTAS_RESUMO.json').write_text(json.dumps(result,indent=2),encoding='utf8')
