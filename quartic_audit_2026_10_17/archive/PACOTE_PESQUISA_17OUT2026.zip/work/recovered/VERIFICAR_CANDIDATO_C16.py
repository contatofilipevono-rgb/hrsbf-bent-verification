"""Verify a candidate against C16 using direct ANF and a complete Walsh transform.
Usage: python VERIFICAR_CANDIDATO_C16.py 0xCOEFFICIENTS
Only Python and NumPy are required. Coefficient order matches combinations(range(16),4).
"""
from itertools import combinations
import sys,json
import numpy as np

def verify(coefficient):
    if not 0<=coefficient<(1<<116):raise ValueError('Expected a 116-bit nonnegative coefficient word.')
    n=16;x=np.arange(65536,dtype=np.uint32);truth=np.zeros(65536,dtype=np.uint8)
    seen=set();generators=[];selected=[]
    for t in combinations(range(n),4):
        m=sum(1<<i for i in t)
        if m in seen:continue
        orbit=sorted({((m<<k)|(m>>(n-k)))&65535 for k in range(n)})
        seen.update(orbit);j=len(generators);generators.append(orbit)
        if coefficient>>j&1:
            selected.append([i for i in range(16) if orbit[0]>>i&1])
            for term in orbit:truth^=((x&term)==term)
    assert len(generators)==116
    rotation=((x<<1)&65535)|(x>>15)
    assert np.array_equal(truth,truth[rotation])
    directions=[1]+[1|(1<<d) for d in range(1,9)]
    ac=[int(np.sum(1-2*(truth^truth[x^a]).astype(np.int64))) for a in directions]
    w=1-2*truth.astype(np.int64)
    for j in range(16):
        step=1<<j;view=w.reshape(-1,2,step)
        left=view[:,0,:].copy();right=view[:,1,:].copy()
        view[:,0,:]=left+right;view[:,1,:]=left-right
    assert int(w@w)==2**32
    return {'coefficient_hex':hex(coefficient),'degree':4 if coefficient else 0,
            'rotation_symmetry_verified':True,'selected_orbit_supports':selected,
            'directions':directions,'autocorrelations':ac,
            'refutes_C16':all(v==0 for v in ac),
            'is_bent':bool(np.all(np.abs(w)==256)),
            'min_abs_walsh':int(np.abs(w).min()),'max_abs_walsh':int(np.abs(w).max())}

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit(__doc__)
    print(json.dumps(verify(int(sys.argv[1],0)),indent=2))
