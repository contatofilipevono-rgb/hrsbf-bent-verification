# Estado atual da pesquisa — 17/10/2026

O resultado global mais forte demonstrado é a exclusão de **pelo menos 99,96433819284775%** do espaço H(16,4) como candidato a bent, por treze condições necessárias. A prova combina 18.080 somas quadráticas independentes com 1.441.770 postos de matrizes conferidos por outro método. Estes resultados não demonstram inexistência global nem resolvem C16; os sobreviventes não são certificados bent.

**Avanço:** quatro condições relacionadas por simetria superam a meta de 99,9% de exclusão. A densidade exata dos sobreviventes permanece desconhecida. Os limites superiores de exclusão de T36/T39 valem para os conjuntos anteriores de nove/dez condições.

**Novo teste exato T41:** a amplitude Walsh em zero foi reduzida a uma contagem em 4.080 órbitas. A identidade e os controles passaram; os pilotos SAT reforçados foram inconclusivos.

## O que ler

1. **T34_FORMA_NORMAL.md:** apresentação curta das três leis lineares e das condições quarta, quinta e sétima. Onze paridades agregadas reduzem a contagem a 512 casos, dos quais 384 são válidos.
2. **T44_LIMITE_POR_DIFERENCAS.md:** prova do limite global atual por diferenças finitas e partições afins. T40 certifica os modelos e o limite anterior de 99,9431%; T39 preserva o resultado histórico de dez condições.
3. **T33_DOMINIO_GPU.md:** redução exata do domínio preparado para A100 a 162.537.472 estados. A lógica foi validada em CPU; CUDA e varredura GPU ainda não foram executadas.
4. **REGISTRO_PESQUISA.md:** resultados demonstrados, tentativas inconclusivas, alternativas e evolução cronológica.
5. **MANUSCRITO_RASCUNHO.md:** rascunho em inglês para revisão e confronto bibliográfico.

## Outros resultados

- Fronteiras exatas de não linearidade e energia local em oito e dez variáveis, reproduzidas por dois métodos: FRONTEIRAS_EXATAS.csv.
- Coberturas espectrais mínimas: dois testes em oito variáveis e 17 em dez, nos limiares registrados. A minimalidade possui certificado conferido independentemente.
- Enumeração completa de uma família estruturada de dimensão 28 em H(16,4): nenhuma das 268.435.456 funções satisfaz PC(2). Esse resultado vale apenas nessa família.
- Sistema explícito de 389 obstruções cúbicas inteiras. Os pilotos SAT atingiram seus limites de tempo sem concluir; não excluíram candidatos.

## Executar e reproduzir

O pacote atual para o próximo piloto A100 é **GRAU4_T33_COLAB.zip**, com notebook **GRAU4_T33_A100.ipynb**. Comece pelo piloto obrigatório com comparação CUDA/CPU e checkpoint. Sobreviventes dos filtros não são certificados bent. T26/T27 são versões históricas.

**PACOTE_PESQUISA_17OUT2026.zip** reúne documentos, dados e código com manifesto SHA-256. Os novos verificadores de certificados usam Python padrão; a geração e validação dos estados usam NumPy. REPRODUCAO_CERTIFICADOS_T28_T33.json registra a execução isolada dos seis verificadores extraídos do pacote, todos aprovados.

T30 demonstra uma distinção operacional: a sexta condição sozinha não reduz o quociente das cinco fibras, pois cada estado admite representantes com os dois valores do bit. A sétima condição desce a esse quociente e reduz T27 para T33.
