# Research checkpoint â€” 17 October 2026

Start with outputs/LEIA_PRIMEIRO.md. The current modular research draft is outputs/MANUSCRITO_MODULAR_CONSOLIDADO.md; the broader earlier draft preserves the finite Pareto and spectral-cover results.

Thirteen necessary conditions exclude at least 99.96433819284775% of H(16,4). The six-condition core has an eleven-parity normal form. Seven additional bits are bounded without assuming independence; unit symmetry reduces 127 characters to 43 orbits. Complete coefficient reconstructions, symmetry actions, 18,080 independent quadratic sums and 173 equation-span checks establish the T40 bound. T43/T44 refine it through 1,441,770 independently checked difference-matrix ranks. The exact survivor density is unknown, and global nonexistence is not proved here. T41 supplies an exact Walsh-zero test; T45 certifies an additional condition not implied by the thirteen filters. Further candidate refinements in work/ are exploratory until their independent verification reports pass.

The prepared GPU domain has 162537472 states. Use GRAU4_T33_COLAB.zip and GRAU4_T33_A100.ipynb for the mandatory pilot and CUDA/CPU crosschecks. No GPU execution is claimed. The global thirteen-condition bound has not been incorporated into this quotient. Historical T26/T27 packages remain available for reproduction.

To verify only the modular certificates, run REPRODUZIR_CERTIFICADOS_MODULARES.py with standard Python; no third-party packages are needed. It checks the normal form, full coefficient models, and independent quadratic sums. The T40 quadratic-sum checker took about thirteen minutes, T43 about fifteen minutes and T44 about eight minutes on the development CPU with concurrent research tasks; these are not runtime estimates for other systems.

For the full small-space enumerations and earlier certificates, install requirements.txt and run REPRODUZIR_RESULTADOS.py. Optional exploratory MILP needs requirements-optional.txt. Search scripts are not run by default. Timeouts in the SAT and MILP pilots excluded no candidates.

The complete 28-dimensional edge-matching family contains no PC(2) function among its 268435456 members. This is a subfamily theorem, not a global C16 proof.

SHA256SUMS.txt covers every packaged file. The package contains no third-party solver binaries.
