# T33 — novo domínio exato para A100

O experimento retoma os filtros necessários de T16, impondo antes as três leis lineares demonstradas e as duas condições quadráticas. O domínio completo tem 162.537.472 estados, contra 1.604.829.184 da execução T16 anterior. Não são contagens de funções bent.

Use a mesma configuração NumPy/CuPy que já executou T16 na sua A100. O código não instala pacotes nem monta o Drive automaticamente. Se CuPy não estiver disponível, consulte https://docs.cupy.dev/en/stable/install.html e use o pacote compatível com o ambiente CUDA do Colab.

Primeiro execute o piloto padrão de 16.777.216 estados. Ele reconstrói as tabelas, compara geradores de estados e filtros GPU/CPU, salva checkpoint e estima o tempo restante a partir da velocidade medida. Só os resultados observados no piloto permitem estimar o custo real. Para prosseguir do checkpoint, execute run(full_scan=True).

O notebook inclui células separadas para piloto, continuação completa e download. O checkpoint fica na pasta T33_results da sessão. Baixe o arquivo de resultados antes de encerrar a sessão ou preserve essa pasta por conta própria.

Antes de esta entrega ser criada, a lógica de geração de estados foi verificada em CPU, incluindo todos os sistemas afins dos 111.876 pais retidos. Não houve execução GPU de T33 pelo assistente. Os testes CUDA/CPU estão incluídos e são obrigatórios antes da varredura.

Enviar GRAU4_T33_RESULTADOS.zip depois da execução permitirá conferir o manifesto, as contagens e o escopo. Um piloto não deve ser apresentado como varredura completa; sobreviventes não são certificados bent.
