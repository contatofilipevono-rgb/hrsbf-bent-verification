"""Extract and symbolically certify ALL 17 weight-11/12 syzygies (7 from w11 + 10 from w12)
and the 18th syzygy (from per_w12_b3 / w13_b3 / w14_b3) that have EXACT DEGREE <= 2
on the 98-dimensional super-subspace W_98 = V_56^even (+) U_42!
Verify symbolically:
1. Every single one of the 17 weight-11/12 syzygies has D_d B_r^{(98)} == 0 for all 98 basis vectors of W_98.
2. Check which linear forms of q their 98x98 bilinear matrices B_r^{(98)}(q) depend on!"""
import sys, time, random
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

from analyze_exact_26_syzygies_anf import build_w11_symbolic_anfs_subset, build_w12_symbolic_anfs
from check_joint_cubic_rank_and_syzygies import build_orbits, compute_zeta_bits
from inspect_26_quadratic_in_U_conditions import find_nullspace
from verify_14parity_normal_form import blocks
from inspect_16_bilinear_forms import find_row_basis

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)
    _, reps13 = build_orbits(13)
    _, reps14 = build_orbits(14)
    per_w12 = [0x3f3f, 0x5f5f, 0x6f6f, 0x7777]
    nonper_reps12 = [w for w in reps12 if w not in per_w12]
    nonper_reps13 = [w for w in reps13 if w != 0x7f7f]
    nonper_reps14 = [w for w in reps14 if w != 0x7f7f]
    rep_to_idx = { m: idx for idx, orb in enumerate(orbits4) for m in orb }

    block_names_8 = ['u1', 'v1', 'u2', 'v2', 'u3', 'v3', 'u4', 'v4']
    u_v_vars = sorted([j for bn in block_names_8 for j in blocks[bn]])
    V56_basis = []
    for bn in block_names_8:
        bvars = sorted(blocks[bn])
        p0 = bvars[0]
        for j in bvars[1:]:
            V56_basis.append((1 << p0) ^ (1 << j))

    U48_vars = sorted(set(range(116)) - set(u_v_vars) - {57, 99, 113, 115})
    lin_forms_6 = [
        set(blocks['R1'] + blocks['R2'] + blocks['R3'] + blocks['R4']),
        set(blocks['R2'] + blocks['R3']),
        set(blocks['R2'] + blocks['W1']),
        set(blocks['R3'] + blocks['W2']),
        set(blocks['R1'] + blocks['W3']),
        {23, 31, 39, 112},
    ]
    pivots_6 = {}
    U42_basis = []
    for j in U48_vars:
        syn = sum((1 << b_i) for b_i, lf in enumerate(lin_forms_6) if j in lf)
        vec = 1 << j
        while syn:
            lsb = (syn & -syn).bit_length() - 1
            if lsb in pivots_6:
                ps, pv = pivots_6[lsb]
                syn ^= ps
                vec ^= pv
            else:
                pivots_6[lsb] = (syn, vec)
                break
        if syn == 0:
            U42_basis.append(vec)
    W98_basis = V56_basis + U42_basis
    mask98 = [sum((1 << a) for a in range(98) if (W98_basis[a] >> v) & 1) for v in range(116)]

    rng = random.Random(20261017)
    def rand_W98():
        c = 0
        for v in W98_basis:
            if rng.randint(0, 1): c ^= v
        return c

    N_CUBES = 500
    pts = []
    for _ in range(N_CUBES):
        d1, d2, d3 = rand_W98(), rand_W98(), rand_W98()
        for mask in range(1, 8):
            pt = 0
            if mask & 1: pt ^= d1
            if mask & 2: pt ^= d2
            if mask & 4: pt ^= d3
            pts.append(pt)
    _, _, b2, b3, _ = compute_zeta_bits(pts, orbits4)
    def compress_3diff(val_int):
        res = 0
        for t in range(N_CUBES):
            if ((val_int >> (7 * t)) & 0x7F).bit_count() & 1: res |= (1 << t)
        return res

    r_w11 = [compress_3diff(b2[v]) for v in reps11]
    r_w12 = [compress_3diff(b2[w]) for w in nonper_reps12]
    r_per12 = [compress_3diff(b3[w]) for w in per_w12]
    r_w13 = [compress_3diff(b3[w]) for w in nonper_reps13]
    r_w14 = [compress_3diff(b3[w]) for w in nonper_reps14]

    null_w11 = find_nullspace(r_w11)
    null_w12 = find_nullspace(r_w12)
    null_431 = find_nullspace(r_w11 + r_w12 + r_per12 + r_w13 + r_w14)
    print(f"On W_98: len(null_w11)={len(null_w11)}, len(null_w12)={len(null_w12)}, len(null_431)={len(null_431)}")

    # Print the 10 weight-12 syzygies on W_98!
    for idx_s, comb in enumerate(null_w12):
        terms = [hex(nonper_reps12[i]) for i in range(len(nonper_reps12)) if (comb >> i) & 1]
        print(f"  W98-Syz12 #{idx_s:2d} ({len(terms)} terms): {terms}")

    # Find the 18th syzygy in null_431 (the one that uses per_w12 / w13 / w14)!
    for comb in null_431:
        if (comb >> 385) != 0:
            terms11 = [hex(reps11[i]) for i in range(273) if (comb >> i) & 1]
            terms12 = [hex(nonper_reps12[i]) for i in range(112) if (comb >> (273 + i)) & 1]
            terms_p12 = [hex(per_w12[i]) for i in range(4) if (comb >> (385 + i)) & 1]
            terms13 = [hex(nonper_reps13[i]) for i in range(35) if (comb >> (389 + i)) & 1]
            terms14 = [hex(nonper_reps14[i]) for i in range(7) if (comb >> (424 + i)) & 1]
            print(f"  18th W98-Syzygy: w11={terms11}, w12={terms12}, per_w12={terms_p12}, w13={terms13}, w14={terms14}")

    # Build exact symbolic ANFs of the 7 w11 and 10 w12 syzygies on W_98, and verify symbolically:
    # 1) D_d B_r^{(98)} == 0 for all d in W98_basis
    # 2) Which linear forms of q their 98x98 matrices depend on!
    active_w11_indices = sorted({ i for comb in null_w11 for i in range(len(reps11)) if (comb >> i) & 1 })
    anfs11 = build_w11_symbolic_anfs_subset([reps11[i] for i in active_w11_indices], rep_to_idx)
    anfs12 = build_w12_symbolic_anfs(nonper_reps12, rep_to_idx)

    syz_17_polys = []
    for idx_s, comb in enumerate(null_w11):
        poly_s = set()
        for i in active_w11_indices:
            if (comb >> i) & 1: poly_s ^= anfs11[reps11[i]]
        syz_17_polys.append((f"Syz11 #{idx_s}", poly_s))
    for idx_s, comb in enumerate(null_w12):
        poly_s = set()
        for i, w in enumerate(nonper_reps12):
            if (comb >> i) & 1: poly_s ^= anfs12[w]
        syz_17_polys.append((f"Syz12 #{idx_s}", poly_s))

    all_98_forms = set()
    for name, poly_s in syz_17_polys:
        k_to_pairs = {}
        for m in poly_s:
            if m.bit_count() == 3:
                b1 = m & -m; r1 = m ^ b1
                b2 = r1 & -r1; b3 = r1 ^ b2
                v1, v2, v3 = b1.bit_length()-1, b2.bit_length()-1, b3.bit_length()-1
                k_to_pairs.setdefault(v1, []).append((v2, v3))
                k_to_pairs.setdefault(v2, []).append((v1, v3))
                k_to_pairs.setdefault(v3, []).append((v1, v2))
        dk_mats = []
        for k in range(116):
            adj = [0] * 98
            for v1, v2 in k_to_pairs.get(k, []):
                m1, m2 = mask98[v1], mask98[v2]
                if not (m1 and m2): continue
                for a in range(98):
                    if (m1 >> a) & 1: adj[a] ^= m2
                    if (m2 >> a) & 1: adj[a] ^= m1
            for a in range(98): adj[a] &= ~(1 << a)
            dk_mats.append(adj)
        for a_idx, d in enumerate(W98_basis):
            mat_d = [0] * 98
            for k in range(116):
                if (d >> k) & 1:
                    for row_i in range(98): mat_d[row_i] ^= dk_mats[k][row_i]
            assert not any(mat_d), f"{name} failed symbolic W98 cubic check at basis {a_idx}!"
        pair_forms = {}
        for k in range(116):
            mat_k = dk_mats[k]
            for a in range(98):
                row_a = mat_k[a] >> (a + 1)
                while row_a:
                    lsb = (row_a & -row_a).bit_length() - 1
                    b = a + 1 + lsb
                    pair_forms[(a, b)] = pair_forms.get((a, b), 0) | (1 << k)
                    row_a &= row_a - 1
        forms_set = set(pair_forms.values()) - {0}
        rk_q = len(find_row_basis(list(forms_set)))
        all_98_forms.update(forms_set)
        print(f"  {name:10s}: CERTIFIED Symbolic deg_{{W98}} <= 2! | 98x98 matrix depends on {rk_q:2d} linear forms of q!")

    total_rk_98 = len(find_row_basis(list(all_98_forms)))
    print(f"\nTOTAL RANK in q of ALL SEVENTEEN 98x98 bilinear matrices B_r^(98)(q) on W_98: {total_rk_98} linear forms!")
    for idx_f, b in enumerate(find_row_basis(list(all_98_forms))):
        vars_f = [k for k in range(116) if (b >> k) & 1]
        b_names = { bn for v in vars_f for bn, bv in blocks.items() if v in bv }
        print(f"  Form #{idx_f:2d} (weight {len(vars_f):2d} in blocks {sorted(b_names)}): {vars_f}")

if __name__ == '__main__':
    main()
