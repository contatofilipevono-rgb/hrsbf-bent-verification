"""Build the 100% EXACT SYMBOLIC ANF (in all 116 variables!) of:
1. All 7 weight-11 syzygies (using the 23,100 covering triples |m1 U m2 U m3| = 11)
2. All 19 weight-12 syzygies (using the 5,775 disjoint partitions m1 |_| m2 |_| m3 = 12)
And analyze the EXACT symbolic structure of their (1, 2) and (0, 2) bilinear terms B_r(q_uv) on U_38 and U_52!"""
import json, sys, time
from itertools import combinations
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

from check_joint_cubic_rank_and_syzygies import build_orbits, compute_zeta_bits
from inspect_26_quadratic_in_U_conditions import find_nullspace, mat_rank_gf2
from verify_14parity_normal_form import blocks
from exact_symbolic_anf_w11_w12 import build_w12_symbolic_anfs

def build_w11_symbolic_anfs_subset(target_reps11, rep_to_idx):
    # Precompute the 23,100 unordered triples {m1, m2, m3} of 4-subsets of {0..10} whose union has size 11.
    # Structure: one shared element s in {0..10} belonging to m1 and m2, and the remaining 10 elements partitioned
    # into (m1 \ {s}) of size 3, (m2 \ {s}) of size 3, and m3 of size 4!
    triples_11 = []
    all_11 = set(range(11))
    for s in range(11):
        rem10 = sorted(all_11 - {s})
        for m3 in combinations(rem10, 4):
            rem6 = sorted(set(rem10) - set(m3))
            first_6 = rem6[0]
            for m1_rest in combinations(rem6[1:], 2):
                m1 = tuple(sorted((s, first_6) + m1_rest))
                m2 = tuple(sorted({s} | (set(rem6) - {first_6} - set(m1_rest))))
                triples_11.append((m1, m2, m3))
    assert len(triples_11) == 23100

    anfs11 = {}
    for v in target_reps11:
        bits = [i for i in range(16) if (v >> i) & 1]
        bit_masks = [1 << b for b in bits]
        sub4_orb = {}
        for comb in combinations(range(11), 4):
            mask = bit_masks[comb[0]] | bit_masks[comb[1]] | bit_masks[comb[2]] | bit_masks[comb[3]]
            sub4_orb[comb] = rep_to_idx[mask]
        poly = set()
        for m1, m2, m3 in triples_11:
            o1, o2, o3 = sub4_orb[m1], sub4_orb[m2], sub4_orb[m3]
            mon = (1 << o1) | (1 << o2) | (1 << o3)
            if mon in poly:
                poly.remove(mon)
            else:
                poly.add(mon)
        anfs11[v] = poly
    return anfs11

def main():
    t0 = time.perf_counter()
    orbits4, reps4 = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)
    per_w12 = [0x3f3f, 0x5f5f, 0x6f6f, 0x7777]
    nonper_reps12 = [w for w in reps12 if w not in per_w12]
    rep_to_idx = { m: idx for idx, orb in enumerate(orbits4) for m in orb }

    u_v_vars = []
    for k in ['u1', 'v1', 'u2', 'v2', 'u3', 'v3', 'u4', 'v4']:
        u_v_vars.extend(blocks[k])
    u_v_vars = sorted(u_v_vars)
    u_v_mask = sum(1 << j for j in u_v_vars)
    U52_vars = sorted(set(range(116)) - set(u_v_vars))

    # Find the 7 weight-11 syzygies first via cubes on U52, then build the exact ANFs of the involved weight-11 orbits!
    import random
    rng = random.Random(20261017)
    def rand_U52():
        c = 0
        for j in U52_vars:
            if rng.randint(0, 1): c ^= (1 << j)
        return c

    N_CUBES = 400
    pts = []
    for _ in range(N_CUBES):
        d1, d2, d3 = rand_U52(), rand_U52(), rand_U52()
        for mask in range(1, 8):
            pt = 0
            if mask & 1: pt ^= d1
            if mask & 2: pt ^= d2
            if mask & 4: pt ^= d3
            pts.append(pt)
    _, _, b2, _, _ = compute_zeta_bits(pts, orbits4)
    def compress_3diff(val_int):
        res = 0
        for t in range(N_CUBES):
            if ((val_int >> (7 * t)) & 0x7F).bit_count() & 1:
                res |= (1 << t)
        return res

    null_w11 = find_nullspace([compress_3diff(b2[v]) for v in reps11])
    active_w11_indices = sorted({ i for comb in null_w11 for i in range(len(reps11)) if (comb >> i) & 1 })
    print(f"7 w11 syzygies use {len(active_w11_indices)} distinct weight-11 orbits. Building their exact symbolic ANFs...")
    anfs11 = build_w11_symbolic_anfs_subset([reps11[i] for i in active_w11_indices], rep_to_idx)
    anfs12 = build_w12_symbolic_anfs(nonper_reps12, rep_to_idx)
    print(f"Built exact symbolic ANFs in {time.perf_counter()-t0:.2f}s!")

    # Verify the 7 weight-11 syzygies have ZERO (0, 3) cubic terms in U52 symbolically!
    syz_polys_26 = []
    for idx_s, comb in enumerate(null_w11):
        poly_s = set()
        for i in active_w11_indices:
            if (comb >> i) & 1:
                poly_s ^= anfs11[reps11[i]]
        bideg = {}
        for m in poly_s:
            kuv = (m & u_v_mask).bit_count()
            ku52 = (m & ~u_v_mask).bit_count()
            bideg[(kuv, ku52)] = bideg.get((kuv, ku52), 0) + 1
        assert bideg.get((0, 3), 0) == 0, f"Syz11 #{idx_s} has non-zero (0, 3)!"
        syz_polys_26.append(('w11', idx_s, poly_s))
        print(f"  Syz11 #{idx_s} CERTIFIED Symbolic (0,3)==0 | total_mons={len(poly_s):5d} | bideg={dict(sorted(bideg.items()))}")

    # Add the 19 weight-12 syzygies
    pure_U52_cubics = sorted({ m for w in nonper_reps12 for m in anfs12[w] if (m & u_v_mask) == 0 and m.bit_count() == 3 })
    cub_idx = { m: i for i, m in enumerate(pure_U52_cubics) }
    rows_w12_exact = []
    for w in nonper_reps12:
        row = 0
        for m in anfs12[w]:
            if (m & u_v_mask) == 0 and m.bit_count() == 3:
                row |= (1 << cub_idx[m])
        rows_w12_exact.append(row)
    syz12_exact = find_nullspace(rows_w12_exact)
    for idx_s, comb in enumerate(syz12_exact):
        poly_s = set()
        for i, w in enumerate(nonper_reps12):
            if (comb >> i) & 1:
                poly_s ^= anfs12[w]
        syz_polys_26.append(('w12', idx_s, poly_s))

    # NOW: Analyze the exact (1, 2) and (0, 2) terms of all 26 syzygies!
    # Every (1, 2) monomial has the form: q_k * u_a * u_b where k in u_v_vars (64 vars) and a, b in U52_vars (52 vars).
    # Wait: how many distinct linear forms in q_uv appear as coefficients of u_a * u_b across ALL 26 syzygies?!
    uv_to_bit = { k: idx for idx, k in enumerate(u_v_vars) }
    all_linear_forms_uv = set()
    for kind, idx_s, poly_s in syz_polys_26:
        pair_forms = {}
        for m in poly_s:
            kuv = (m & u_v_mask).bit_count()
            ku52 = (m & ~u_v_mask).bit_count()
            if kuv == 1 and ku52 == 2:
                q_m = m & u_v_mask
                u_m = m & ~u_v_mask
                k_bit = uv_to_bit[q_m.bit_length() - 1]
                pair_forms[u_m] = pair_forms.get(u_m, 0) ^ (1 << k_bit)
        forms_set = set(pair_forms.values()) - {0}
        rk_uv = mat_rank_gf2(list(forms_set), 64)
        all_linear_forms_uv.update(forms_set)
        print(f"  {kind} #{idx_s:2d}: active u_a*u_b pairs = {len(pair_forms):3d}, distinct q_uv linear forms = {len(forms_set):2d}, rank in q_uv = {rk_uv:2d}/64")

    total_rk_uv = mat_rank_gf2(list(all_linear_forms_uv), 64)
    print(f"\nTOTAL RANK in q_uv (64 vars) of ALL (1, 2) bilinear coefficients across ALL 26 syzygies: {total_rk_uv}/64 (from {len(all_linear_forms_uv)} distinct forms)!")

if __name__ == '__main__':
    main()
