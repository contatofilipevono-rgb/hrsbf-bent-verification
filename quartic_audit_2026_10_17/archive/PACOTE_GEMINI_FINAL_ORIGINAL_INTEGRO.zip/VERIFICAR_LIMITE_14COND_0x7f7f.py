"""Complete parallel certificate and verifier for the 14-condition system (T40/T43/T44 + 0x7f7f first bit)."""
import json, sys, time
from pathlib import Path
from fractions import Fraction
from multiprocessing import Pool
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from test_0x7f7f_on_T40 import R_7f7f_branches, toggle

def fast_symplectic_bias(P):
    constant = 0
    linear_mask = 0
    adjacency = {}
    for m in P:
        if m == 0:
            constant ^= 1
        else:
            a = m & -m
            b = m ^ a
            if b == 0:
                linear_mask ^= a
            else:
                ia = a.bit_length() - 1
                ib = b.bit_length() - 1
                adjacency[ia] = adjacency.get(ia, 0) ^ b
                adjacency[ib] = adjacency.get(ib, 0) ^ a
    vars_all = sorted(set(adjacency.keys()) | {j for j in range(116) if (linear_mask >> j) & 1})
    vecs = [(1 << j, adjacency.get(j, 0), (linear_mask >> j) & 1) for j in vars_all]
    pairs = 0
    sign = constant
    while True:
        pair = None
        n = len(vecs)
        for i in range(n):
            vi, adj_i, qi = vecs[i]
            if adj_i == 0:
                continue
            for j in range(i + 1, n):
                vj, adj_j, qj = vecs[j]
                if (vi & adj_j).bit_count() & 1:
                    pair = (i, j)
                    break
            if pair is not None:
                break
        if pair is None:
            break
        i, j = pair
        e, adj_e, qe = vecs[i]
        f, adj_f, qf = vecs[j]
        sign ^= (qe & qf)
        pairs += 1
        new_vecs = []
        for k, (v, adj_v, qv) in enumerate(vecs):
            if k == i or k == j:
                continue
            pv_e = (v & adj_e).bit_count() & 1
            pv_f = (v & adj_f).bit_count() & 1
            if pv_f:
                v ^= e
                adj_v ^= adj_e
                qv ^= qe
            if pv_e:
                v ^= f
                adj_v ^= adj_f
                qv ^= qf
            if pv_e and pv_f:
                qv ^= 1
            new_vecs.append((v, adj_v, qv))
        vecs = new_vecs
    for v, adj_v, qv in vecs:
        if qv:
            return Fraction(0)
    return Fraction(-1 if sign else 1, 1 << pairs)

def rank(rows):
    B = {}
    for v in rows:
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j]
            else:
                B[j] = v
                break
    return len(B)

def polynomial_rank_and_basis(rows):
    features = sorted(set().union(*rows))
    if not features:
        return 0, [], None
    index = {m: i for i, m in enumerate(features)}
    B = {}
    basis_combos = []
    for r_idx, row in enumerate(rows):
        v = sum(1 << index[m] for m in row)
        c = 1 << r_idx
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j][0]
                c ^= B[j][1]
            else:
                B[j] = (v, c)
                basis_combos.append(c)
                break
    if 0 in index and index[0] == 0:
        v = 1
        c = 0
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j][0]
                c ^= B[j][1]
            else:
                break
        if v == 0:
            return len(B), basis_combos, c
    return len(B), basis_combos, None

def derivative(P, d):
    out = set()
    for m in P:
        sub = m & d
        while sub:
            toggle(out, m ^ sub)
            sub = (sub - 1) & (m & d)
    return out

def restrict(P, coordinates, value):
    selected = sum(1 << j for j in coordinates)
    ones = sum(((value >> i) & 1) << j for i, j in enumerate(coordinates))
    zeros = selected ^ ones
    out = set()
    for m in P:
        if not (m & zeros):
            toggle(out, m & ~selected)
    return out

def combination(rows, c):
    P = set()
    for j, row in enumerate(rows):
        if (c >> j) & 1:
            P ^= row
    return P

def eval_shifted_orbit(args):
    branch, character, P = args
    S = character['coordinates']
    directions = [int(v, 16) for v in character['directions_hex']]
    D = [derivative(P, d) for d in directions]
    preselection = character.get('selected_radical_equation_combinations')
    if preselection is not None:
        D = [combination(D, int(c, 16)) for c in preselection]
    condition = character['conditioning_coordinates']
    n_cases = 1 << len(condition)
    Z = Fraction(0)
    for cond_val in range(n_cases):
        rows = [restrict(row, condition, cond_val) for row in D]
        rk, basis_combos, incon = polynomial_rank_and_basis(rows)
        if incon is not None:
            continue
        basis = [combination(rows, c) for c in basis_combos]
        summation = Fraction(0)
        for idx in range(1 << len(basis)):
            Q_comb = combination(basis, idx)
            summation += fast_symplectic_bias(Q_comb)
        z = summation / Fraction(1 << len(basis))
        Z += z / Fraction(n_cases)
    r_used = character['polar_rank']
    return branch, character['combination'], Z / Fraction(1 << (r_used // 2))

if __name__ == '__main__':
    t0 = time.perf_counter()
    t40_cert = json.loads((base / 'T40_LIMITE_CERTIFICADO.json').read_text())
    t43_deriv = json.loads((base / 'T43_DERIVADAS_CERTIFICADO.json').read_text())['cases']
    t43_cert = json.loads((base / 'T43_LIMITE_CERTIFICADO.json').read_text())
    t44_deriv = json.loads((base / 'T44_DERIVADAS_CERTIFICADO.json').read_text())['cases']
    t44_cert = json.loads((base / 'T44_LIMITE_CERTIFICADO.json').read_text())
    models = (
        json.loads((base / 'T35_POLINOMIOS_CERTIFICADO.json').read_text())['combined_models']
        + json.loads((base / 'T40_MODELOS_CERTIFICADO.json').read_text())['models']
    )

    # 1. Verify exact bilinear invariance B_{P^Q}(d) == B_P(d) on all T43 and T44 cases!
    t43_checked = 0
    for case in t43_deriv:
        branch = case['branch']
        condition = case['conditioning_coordinates']
        value = case['condition_value']
        Q = restrict(R_7f7f_branches[branch], condition, value)
        assert all(m.bit_count() <= 2 for m in Q), "Q must be degree <= 2 after conditioning in T43!"
        for d_hex in case['directions_hex']:
            d = int(d_hex, 16)
            dq = derivative(Q, d)
            assert all(m.bit_count() <= 1 for m in dq), "derivative(Q, d) must be degree <= 1 in T43!"
            t43_checked += 1

    t44_checked = 0
    for case in t44_deriv:
        branch = case['branch']
        condition = case['conditioning_coordinates']
        value = case['condition_value']
        linear_forms = case.get('conditioning_linear_forms', [])
        Q = restrict(R_7f7f_branches[branch], condition, value & ((1 << len(condition)) - 1))
        for fi, form in enumerate(linear_forms):
            pivot = form[0]
            replacement = {1 << j for j in form[1:]}
            out = set()
            if (value >> (len(condition) + fi)) & 1:
                replacement.add(0)
            for m in Q:
                if (m >> pivot) & 1:
                    for term in replacement:
                        toggle(out, (m ^ (1 << pivot)) | term)
                else:
                    toggle(out, m)
            Q = out
        assert all(m.bit_count() <= 2 for m in Q), "Q must be degree <= 2 after conditioning in T44!"
        for d_hex in case['directions_hex']:
            d = int(d_hex, 16)
            dq = derivative(Q, d)
            assert all(m.bit_count() <= 1 for m in dq), "derivative(Q, d) must be degree <= 1 in T44!"
            t44_checked += 1

    print(f"Verified exact bilinear invariance B_{{P^Q}}(d) == B_P(d) on all {t43_checked} T43 directions and {t44_checked} T44 directions!")

    # 2. Compute shifted slice amplitudes in parallel across 12 cores!
    tasks = []
    for branch_record in t40_cert['branches']:
        branch = branch_record['branch']
        supports = branch_record['supports']
        polys = [
            {int(m, 16) for m in next(r for r in models if r['branch'] == branch and r['support_mask'] == s)['polynomial_hex']}
            for s in supports
        ]
        Q_7f7f = R_7f7f_branches[branch]
        for character in branch_record['characters']:
            choice = character['combination']
            P = combination(polys, choice) ^ Q_7f7f
            tasks.append((branch, character, P))

    slice_shifted_amps = {0: {}, 1: {}}
    with Pool(12) as pool:
        for branch, choice, amp in pool.map(eval_shifted_orbit, tasks):
            slice_shifted_amps[branch][choice] = amp

    top16_ref = None
    if (base / 'T45B_TOP16_REFINEMENT.json').exists():
        top16_ref = json.loads((base / 'T45B_TOP16_REFINEMENT.json').read_text())

    # 3. Compare the 13-condition bounds (T40, T43, T44, T44+Top16) with the 14-condition bounds (+0x7f7f)!
    configs = [('T40', t40_cert), ('T43', t43_cert), ('T44', t44_cert)]
    if top16_ref is not None:
        configs.append(('T44+Top16', t44_cert))
    for label, cert13 in configs:
        global_13 = Fraction(0)
        global_14 = Fraction(0)
        for b_rec in cert13['branches']:
            branch = b_rec['branch']
            Q_7f7f = R_7f7f_branches[branch]
            if branch == 0:
                pure_q = (fast_symplectic_bias(restrict(Q_7f7f, [57], 0)) + fast_symplectic_bias(restrict(Q_7f7f, [57], 1))) / 2
            else:
                pure_q = fast_symplectic_bias(Q_7f7f)
            amp_sum_old = Fraction(0)
            amp_sum_shifted = Fraction(0)
            for ch in b_rec['characters']:
                choice = ch['combination']
                orbit_len = len(ch['symmetry_orbit'])
                if label == 'T40':
                    a_old = Fraction(*ch['average_absolute_slice_bias'])
                    a_sh = slice_shifted_amps[branch][choice]
                else:
                    a_old = Fraction(*ch['selected_amplitude'])
                    a_sh = slice_shifted_amps[branch][choice]
                    t43_ch = next(x for x in t43_cert['branches'][branch]['characters'] if x['combination'] == choice)
                    if t43_ch['new_amplitude'] is not None:
                        a_sh = min(a_sh, Fraction(*t43_ch['new_amplitude']))
                    if label in ('T44', 'T44+Top16'):
                        t44_ch = next(x for x in t44_cert['branches'][branch]['characters'] if x['combination'] == choice)
                        if t44_ch['new_amplitude'] is not None:
                            a_sh = min(a_sh, Fraction(*t44_ch['new_amplitude']))
                    if label == 'T44+Top16' and top16_ref is not None:
                        b_dict = top16_ref[f'branch{branch}_amplitudes']
                        if str(choice) in b_dict:
                            a_top = Fraction(*b_dict[str(choice)])
                            a_old = min(a_old, a_top)
                            a_sh = min(a_sh, a_top)
                amp_sum_old += orbit_len * a_old
                amp_sum_shifted += orbit_len * a_sh
            cond_13 = (1 + amp_sum_old) / 128
            cond_14 = (1 + pure_q + amp_sum_old + amp_sum_shifted) / 256
            weight = Fraction(1, 64 if branch == 0 else 128)
            global_13 += weight * cond_13
            global_14 += weight * cond_14
            print(f"[{label}] Branch {branch}: 13-cond = {float(cond_13):.8f}, 14-cond (+0x7f7f) = {float(cond_14):.8f} (amp_old={float(amp_sum_old):.6f}, amp_sh={float(amp_sum_shifted):.6f})")
        print(f"==> [{label}] Global 13-cond bound: {global_13} = {float(global_13):.8e} (excl {float(100*(1-global_13)):.10f}%)")
        print(f"==> [{label}+0x7f7f] Global 14-cond bound: {global_14} = {float(global_14):.8e} (excl {float(100*(1-global_14)):.10f}%)\n")

    print(f"Completed in {time.perf_counter() - t0:.2f}s!")

