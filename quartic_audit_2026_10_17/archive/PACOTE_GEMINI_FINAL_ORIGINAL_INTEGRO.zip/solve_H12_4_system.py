"""Analyze the 43 quadratic equations on the 37-dimensional space of H(12, 4):
1. Compute the quadratic radical (linear nullspace of quadratic terms) to find if syzygies yield more linear equations.
2. Evaluate rank and test solutions on CPU!"""
import sys, time
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

from prove_H12_4_exhaustive import build_orbits_12, compute_zeta_12

def main():
    t0 = time.perf_counter()
    orbits4, idx4, reps4 = build_orbits_12(4)
    _, _, reps8 = build_orbits_12(8)
    reps12 = [0xFFF]

    # 5 Linear laws of H(12, 4):
    # c40 = 0
    # c42 = c26
    # c39 = c8 ^ c14 ^ c19 ^ c26
    # c37 = c0 ^ c2 ^ c6 ^ c12 ^ c15 ^ c23 ^ c25
    # c36 = c1 ^ c7 ^ c9 ^ c18 ^ c24 ^ c32 ^ c34
    eliminated = {40, 42, 39, 37, 36}
    free38 = [j for j in range(43) if j not in eliminated]
    assert len(free38) == 38, f"Expected 38 free vars, got {len(free38)}"

    def make_vec38(active_indices):
        c = 0
        for i in active_indices:
            c |= (1 << free38[i])
        if (c >> 26) & 1:
            c |= (1 << 42)
        c39 = ((c >> 8) ^ (c >> 14) ^ (c >> 19) ^ (c >> 26)) & 1
        if c39: c |= (1 << 39)
        c37 = ((c >> 0) ^ (c >> 2) ^ (c >> 6) ^ (c >> 12) ^ (c >> 15) ^ (c >> 23) ^ (c >> 25)) & 1
        if c37: c |= (1 << 37)
        c36 = ((c >> 1) ^ (c >> 7) ^ (c >> 9) ^ (c >> 18) ^ (c >> 24) ^ (c >> 32) ^ (c >> 34)) & 1
        if c36: c |= (1 << 36)
        return c

    # Evaluate on origin, singletons, and pairs of the 38 variables (1 + 38 + 38*37/2 = 742 points):
    pts = [make_vec38([])]
    for i in range(38):
        pts.append(make_vec38([i]))
    for i in range(38):
        for j in range(i + 1, 38):
            pts.append(make_vec38([i, j]))

    b0, b1, b2, b3, b4, b5 = compute_zeta_12(pts, orbits4)

    def extract_poly38(val_int):
        v0 = val_int & 1
        lin = 0
        for i in range(38):
            if ((val_int >> (1 + i)) & 1) ^ v0:
                lin |= (1 << i)
        quad = {}
        p_idx = 1 + 38
        for i in range(38):
            li = (lin >> i) & 1
            for j in range(i + 1, 38):
                lj = (lin >> j) & 1
                vij = (val_int >> p_idx) & 1
                p_idx += 1
                if vij ^ v0 ^ li ^ lj:
                    quad[(i, j)] = 1
        return v0, lin, quad

    # Collect equations:
    all_eqs = []
    for w in reps8:
        all_eqs.append((f"w8 {hex(w)} b1", b1[w]))
    for w in [0x3cf, 0x5d7, 0x6db]:
        all_eqs.append((f"per_w8 {hex(w)} b2", b2[w]))
    all_eqs.append(("0xfff b3", b3[0xFFF]))

    quad_rows = []
    eq_info = []
    pair_map = {}
    pair_idx = 0
    for i in range(38):
        for j in range(i + 1, 38):
            pair_map[(i, j)] = pair_idx
            pair_idx += 1

    for name, val in all_eqs:
        v0, lin, quad = extract_poly38(val)
        row = 0
        for pair in quad:
            row |= (1 << pair_map[pair])
        quad_rows.append(row)
        eq_info.append((name, v0, lin, quad))

    # Find nullspace of quadratic terms (syzygies of degree 2 that yield degree <= 1):
    from inspect_26_quadratic_in_U_conditions import find_nullspace
    null_quad = find_nullspace(quad_rows)
    print(f"Total equations: {len(all_eqs)}, Nullspace of quadratic terms: {len(null_quad)} syzygies!")

    new_lin_pivs = {}
    for comb in null_quad:
        comb_lin = 0
        comb_v0 = 0
        comb_names = []
        for eq_i in range(len(all_eqs)):
            if (comb >> eq_i) & 1:
                name, v0, lin, _ = eq_info[eq_i]
                comb_lin ^= lin
                comb_v0 ^= v0
                comb_names.append(name)
        if comb_lin != 0 or comb_v0 != 0:
            v, r = comb_lin, comb_v0
            while v:
                lsb = (v & -v).bit_length() - 1
                if lsb in new_lin_pivs:
                    pv, pr = new_lin_pivs[lsb]
                    v ^= pv
                    r ^= pr
                else:
                    new_lin_pivs[lsb] = (v, r)
                    break
            if v == 0 and r == 1:
                print(f"CONTRADICTION FOUND FROM QUADRATIC SYZYGY! {comb_names}")

    print(f"New linear rank from quadratic syzygies: {len(new_lin_pivs)} additional linear laws!")
    for lsb in sorted(new_lin_pivs.keys()):
        pv, pr = new_lin_pivs[lsb]
        terms = [free38[j] for j in range(38) if (pv >> j) & 1]
        print(f"  c_{free38[lsb]:2d}: {terms} = {pr}")

    print(f"Total linear dimension reduction: 5 initial + {len(new_lin_pivs)} syzygies = {5 + len(new_lin_pivs)} linear laws!")
    print(f"Remaining free dimension of H(12, 4): {43 - 5 - len(new_lin_pivs)}")

if __name__ == '__main__':
    main()
