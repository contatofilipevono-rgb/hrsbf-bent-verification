"""Inspect all degree-1, degree-2, and degree-3 subcube divisibility equations in H(12, 4)
(dimension 43, 2^43 functions) and check how many linear and quadratic equations exist!"""
import time, random
from itertools import combinations

def rot12(m, k=1):
    return ((m << k) | (m >> (12 - k))) & 0xFFF

def build_orbits_12(k_weight):
    ORB = []; index = {}; reps = []
    for t in combinations(range(12), k_weight):
        m = sum(1 << j for j in t)
        if m in index: continue
        orb = set(); r = m
        for _ in range(12): orb.add(r); r = rot12(r, 1)
        for r in orb: index[r] = len(ORB)
        ORB.append(sorted(orb))
        reps.append(m)
    return ORB, index, reps

def compute_zeta_12(samples, orbits4):
    N_TOT = len(samples)
    C_orb = [0] * 43
    for s_idx, c in enumerate(samples):
        for j in range(43):
            if (c >> j) & 1:
                C_orb[j] |= (1 << s_idx)

    anf = [0] * 4096
    for j, orb in enumerate(orbits4):
        cj = C_orb[j]
        if cj:
            for m in orb:
                anf[m] = cj

    tt = anf[:]
    for bit in range(12):
        step = 1 << bit
        for i in range(0, 4096, step << 1):
            for j in range(i, i + step):
                tt[j + step] ^= tt[j]

    b0 = tt[:]
    b1 = [0] * 4096
    b2 = [0] * 4096
    b3 = [0] * 4096
    b4 = [0] * 4096
    b5 = [0] * 4096

    for bit in range(12):
        step = 1 << bit
        for i in range(0, 4096, step << 1):
            for j in range(i, i + step):
                k = j + step
                x0, y0 = b0[k], b0[j]; b0[k] = x0 ^ y0; c1 = x0 & y0
                x1, y1 = b1[k], b1[j]; s1 = x1 ^ y1; b1[k] = s1 ^ c1; c2 = (x1 & y1) | (s1 & c1)
                x2, y2 = b2[k], b2[j]; s2 = x2 ^ y2; b2[k] = s2 ^ c2; c3 = (x2 & y2) | (s2 & c2)
                x3, y3 = b3[k], b3[j]; s3 = x3 ^ y3; b3[k] = s3 ^ c3; c4 = (x3 & y3) | (s3 & c3)
                x4, y4 = b4[k], b4[j]; s4 = x4 ^ y4; b4[k] = s4 ^ c4; c5 = (x4 & y4) | (s4 & c4)
                b5[k] ^= b5[j] ^ c5
    return b0, b1, b2, b3, b4, b5

def main():
    t0 = time.perf_counter()
    orbits4, idx4, reps4 = build_orbits_12(4)
    _, _, reps7 = build_orbits_12(7)
    _, _, reps8 = build_orbits_12(8)
    _, _, reps9 = build_orbits_12(9)
    _, _, reps10 = build_orbits_12(10)
    _, _, reps11 = build_orbits_12(11)
    reps12 = [0xFFF]
    print(f"H(12, 4): 43 orbits | w7={len(reps7)}, w8={len(reps8)}, w9={len(reps9)}, w10={len(reps10)}, w11={len(reps11)}")

    # In H(12, 4) (m = 6):
    # Zhang-Gao requires 2^{|u| - 6 + 1} = 2^{|u| - 5} | h_f(u) = 2^{|u|} - 2 * wt(f|_{<= u}),
    # which means 2^{|u| - 6} | wt(f|_{<= u}) for |u| < 12!
    # Specifically:
    #   |u| = 7:  2^1 = 2 | wt  -> b0[u] == 0
    #   |u| = 8:  2^2 = 4 | wt  -> b0[u] == b1[u] == 0
    #   |u| = 9:  2^3 = 8 | wt  -> b0[u] == b1[u] == b2[u] == 0
    #   |u| = 10: 2^4 = 16 | wt -> b0[u] == b1[u] == b2[u] == b3[u] == 0
    #   |u| = 11: 2^5 = 32 | wt -> b0[u] == b1[u] == b2[u] == b3[u] == b4[u] == 0
    #   |u| = 12: wt == 2048 +- 32 -> b0 == b1 == b2 == b3 == b4 == 0 and b5 == 1!

    # Evaluate on all 947 points of weight <= 2 in GF(2)^43 to interpolate ALL degree <= 2 conditions!
    pts_deg2 = [0]
    for i in range(43):
        pts_deg2.append(1 << i)
    for i in range(43):
        for j in range(i + 1, 43):
            pts_deg2.append((1 << i) | (1 << j))

    b0, b1, b2, b3, b4, b5 = compute_zeta_12(pts_deg2, orbits4)
    print(f"Evaluated all 4096 supports on {len(pts_deg2)} pts in {time.perf_counter()-t0:.2f}s")

    # Also check on 60 random 3-cubes which conditions have exact degree <= 2 on ALL of H(12, 4) (or after linear laws)!
    rng = random.Random(20261017)
    pts_c3 = []
    for _ in range(80):
        d1, d2, d3 = rng.getrandbits(43), rng.getrandbits(43), rng.getrandbits(43)
        for mask in range(1, 8):
            pt = 0
            if mask & 1: pt ^= d1
            if mask & 2: pt ^= d2
            if mask & 4: pt ^= d3
            pts_c3.append(pt)
    cb0, cb1, cb2, cb3, cb4, cb5 = compute_zeta_12(pts_c3, orbits4)

    def is_deg_le_2(val_int):
        for t in range(80):
            chunk = (val_int >> (7 * t)) & 0x7F
            if chunk.bit_count() & 1:
                return False
        return True

    for w_name, r_list, bit_list in [
        ("w7", reps7, [("b0", b0, cb0)]),
        ("w8", reps8, [("b0", b0, cb0), ("b1", b1, cb1)]),
        ("w9", reps9, [("b0", b0, cb0), ("b1", b1, cb1), ("b2", b2, cb2)]),
        ("w10", reps10, [("b1", b1, cb1), ("b2", b2, cb2), ("b3", b3, cb3)]),
        ("w11", reps11, [("b2", b2, cb2), ("b3", b3, cb3), ("b4", b4, cb4)]),
        ("w12", reps12, [("b2", b2, cb2), ("b3", b3, cb3), ("b4", b4, cb4), ("b5", b5, cb5)]),
    ]:
        for b_name, barr, cbarr in bit_list:
            nz = [u for u in r_list if barr[u] != 0 or cbarr[u] != 0]
            deg2 = [u for u in nz if is_deg_le_2(cbarr[u])]
            print(f"  {w_name:3s} {b_name}: active={len(nz):2d}/{len(r_list):2d}, deg<=2={len(deg2):2d}/{len(nz):2d} {[hex(u) for u in deg2[:6]]}")

if __name__ == '__main__':
    main()
