"""Compute the joint GF(2) rank and syzygies of all carry-free conditions across
weights 11, 12, 13, 14 on 1,500 T34 core samples and 1,500 2-law samples!"""
import json, sys, time, random
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

def rot(m, k=1):
    return ((m << k) | (m >> (16 - k))) & 0xFFFF

def build_orbits(k_weight):
    ORB = []; index = {}; reps = []
    for t in combinations(range(16), k_weight):
        m = sum(1 << j for j in t)
        if m in index: continue
        orb = set(); r = m
        for _ in range(16): orb.add(r); r = rot(r, 1)
        for r in orb: index[r] = len(ORB)
        ORB.append(orb)
        reps.append(m)
    return ORB, reps

def compute_zeta_bits(samples, orbits4):
    N_TOT = len(samples)
    C_orb = [0] * 116
    for s_idx, c in enumerate(samples):
        for j in range(116):
            if (c >> j) & 1:
                C_orb[j] |= (1 << s_idx)

    anf = [0] * 65536
    for j, orb in enumerate(orbits4):
        cj = C_orb[j]
        if cj:
            for m in orb:
                anf[m] = cj

    tt = anf[:]
    for bit in range(16):
        step = 1 << bit
        for i in range(0, 65536, step << 1):
            for j in range(i, i + step):
                tt[j + step] ^= tt[j]

    b0 = tt[:]
    b1 = [0] * 65536
    b2 = [0] * 65536
    b3 = [0] * 65536
    b4 = [0] * 65536

    for bit in range(16):
        step = 1 << bit
        for i in range(0, 65536, step << 1):
            for j in range(i, i + step):
                k = j + step
                x0, y0 = b0[k], b0[j]; b0[k] = x0 ^ y0; c1 = x0 & y0
                x1, y1 = b1[k], b1[j]; s1 = x1 ^ y1; b1[k] = s1 ^ c1; c2 = (x1 & y1) | (s1 & c1)
                x2, y2 = b2[k], b2[j]; s2 = x2 ^ y2; b2[k] = s2 ^ c2; c3 = (x2 & y2) | (s2 & c2)
                x3, y3 = b3[k], b3[j]; s3 = x3 ^ y3; b3[k] = s3 ^ c3; c4 = (x3 & y3) | (s3 & c3)
                b4[k] ^= b4[j] ^ c4
    return b0, b1, b2, b3, b4

def gf2_rank(rows):
    basis = []
    for r in rows:
        v = r
        for b in basis:
            lsb = (b & -b).bit_length() - 1
            if (v >> lsb) & 1:
                v ^= b
        if v != 0:
            basis.append(v)
    return len(basis)

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)
    _, reps13 = build_orbits(13)
    _, reps14 = build_orbits(14)
    print(f"Orbit counts: w11={len(reps11)}, w12={len(reps12)}, w13={len(reps13)}, w14={len(reps14)}")

    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    rng = random.Random(20261017)
    def sample_t34(branch):
        free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        return c

    N_SAMPLES = 1500
    samples = [sample_t34(0) for _ in range(N_SAMPLES // 2)] + [sample_t34(1) for _ in range(N_SAMPLES // 2)]
    b0, b1, b2, b3, b4 = compute_zeta_bits(samples, orbits4)
    print(f"Computed Zeta bits on {N_SAMPLES} T34 core samples in {time.perf_counter()-t0:.2f}s")

    rows_w11_b2 = [b2[u] for u in reps11]
    rows_w12_b2 = [b2[u] for u in reps12 if b2[u] != 0]
    rows_w12_b3_per = [b3[u] for u in reps12 if b2[u] == 0]
    rows_w13_b3 = [b3[u] for u in reps13]
    rows_w14_b3 = [b3[u] for u in reps14]

    r11 = gf2_rank(rows_w11_b2)
    r12_b2 = gf2_rank(rows_w12_b2)
    r11_12_b2 = gf2_rank(rows_w11_b2 + rows_w12_b2)
    r13_b3 = gf2_rank(rows_w13_b3)
    r14_b3 = gf2_rank(rows_w14_b3)
    r_all_b2_b3 = gf2_rank(rows_w11_b2 + rows_w12_b2 + rows_w12_b3_per + rows_w13_b3 + rows_w14_b3)

    print(f"\n=== GF(2) RANKS ON T34 CORE ({N_SAMPLES} samples) ===")
    print(f"  Rank(w11 b2 [273 pure cubics]):                {r11} / {len(rows_w11_b2)}")
    print(f"  Rank(w12 b2 [112 pure cubics]):                {r12_b2} / {len(rows_w12_b2)}")
    print(f"  Joint Rank(w11 b2 + w12 b2 [385 pure cubics]): {r11_12_b2} / {len(rows_w11_b2) + len(rows_w12_b2)}")
    print(f"  Rank(w12 periodic b3 [4 orbits]):              {gf2_rank(rows_w12_b3_per)} / {len(rows_w12_b3_per)}")
    print(f"  Rank(w13 b3 [35 carry-free orbits]):           {r13_b3} / {len(rows_w13_b3)}")
    print(f"  Rank(w14 b3 [8 carry-free orbits]):            {r14_b3} / {len(rows_w14_b3)}")
    print(f"  Joint Rank(ALL carry-free conditions):         {r_all_b2_b3}")

    # Wait: why is Joint Rank(w11 b2 + w12 b2) equal to r11_12_b2?
    # Because for any weight-12 support w, is b2[w] in the span of {b2[v] : |v|=11}?!
    # Let's check! And what about w14 b3 (which are the 8 weight-14 orbits including 0x7f7f!)?
    print("\n=== CHECKING WEIGHT-14 ORBITS (b3 = h_f(u)//16 mod 2, where bentness requires 128 | h_f(u)) ===")
    for idx, u in enumerate(reps14):
        # Check degree of b3[u] on 2-law space!
        print(f"  w14[{idx}] u=0x{u:04x}: b2==0? {b2[u]==0}, b3 popcount={b3[u].bit_count()}/{N_SAMPLES}, b4 popcount={b4[u].bit_count()}/{N_SAMPLES}")

    # Check if all 8 weight-14 orbits have degree <= 3 (or degree 2!) for b3[u] on the 2-law space!
    # Wait: for u = 0x7f7f, we ALREADY know b3[0x7f7f] has DEGREE 2 on the 2-law space (P_2laws)!
    # What about the OTHER 7 weight-14 orbits?!
    def rand_2law():
        c = rng.getrandbits(116)
        c &= ~(1 << 115)
        c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
        return c

    # Test degree of b3[u] on 2-law space for all 8 weight-14 orbits and all 35 weight-13 orbits using 64 cubes of dimension d!
    for d in [2, 3, 4]:
        cubes = []
        for _ in range(40):
            base_c = rand_2law()
            dirs = [rand_2law() for _ in range(d)]
            for mask in range(1 << d):
                pt = base_c
                for b in range(d):
                    if (mask >> b) & 1:
                        pt ^= dirs[b]
                cubes.append(pt)
        _, _, _, cb3, _ = compute_zeta_bits(cubes, orbits4)
        # For each orbit, check if the d-th finite difference is zero across all 40 cubes!
        def is_deg_lt_d(val_int):
            mask_cube = (1 << (1 << d)) - 1
            for t in range(40):
                chunk = (val_int >> (t << d)) & mask_cube
                if chunk.bit_count() & 1:
                    return False
            return True
        w14_lt = [idx for idx, u in enumerate(reps14) if is_deg_lt_d(cb3[u])]
        w13_lt = [idx for idx, u in enumerate(reps13) if is_deg_lt_d(cb3[u])]
        print(f"On 2-law space, orbits with deg(b3) < {d}: w14={w14_lt} ({len(w14_lt)}/8), w13={len(w13_lt)}/35")

if __name__ == '__main__':
    main()
