"""Find the exact 26 linear combinations of the 388 pure cubic conditions that are
PURELY QUADRATIC (degree <= 2) on the 43-dimensional free subspace U_43, and analyze
the rank distribution of their 43x43 alternating bilinear matrices B_r(q)!"""
import json, sys, time, random
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from check_joint_cubic_rank_and_syzygies import build_orbits, compute_zeta_bits, gf2_rank

def find_nullspace(rows):
    """Given a list of n integer bit-rows, return a list of basis masks (as n-bit ints) for the left nullspace."""
    pivot_map = {}  # lsb -> (row_val, comb_mask)
    null_basis = []
    for idx, r in enumerate(rows):
        v = r
        m = 1 << idx
        while v:
            lsb = (v & -v).bit_length() - 1
            if lsb in pivot_map:
                pv, pm = pivot_map[lsb]
                v ^= pv
                m ^= pm
            else:
                pivot_map[lsb] = (v, m)
                break
        if v == 0:
            null_basis.append(m)
    return null_basis

def mat_rank_gf2(adj_masks, n_dim):
    """Compute GF(2) rank of an n_dim x n_dim matrix given as list of n_dim bitmasks."""
    basis = []
    for row in adj_masks:
        v = row
        for b in basis:
            lsb = (b & -b).bit_length() - 1
            if (v >> lsb) & 1:
                v ^= b
        if v != 0:
            basis.append(v)
    return len(basis)

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)

    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    q_vars = set([0, 5, 23, 57, 99, 113, 115, 31, 39, 112])
    q_vars.update(seven['K'])
    for p in factor['products']:
        q_vars.update(p['I'])
        q_vars.update(p['J'])
    U_vars = sorted(set(range(116)) - q_vars)
    print(f"len(q_vars) = {len(q_vars)}, len(U_vars) = {len(U_vars)}")

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    # Basis vectors of U_43 in T34_lin:
    U_basis = []
    for j in U_vars:
        c = 1 << j
        c |= parity(c, seven['L']) << 0
        c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ parity(c, seven['K'])) << 5
        U_basis.append(c)

    rng = random.Random(20261017)
    def rand_U_lin():
        c = 0
        for u_vec in U_basis:
            if rng.randint(0, 1):
                c ^= u_vec
        return c

    # Step 1: Use 800 random 3-cubes in U_43 to find the exact nullspace on U_43 x U_43 x U_43
    N_CUBES = 800
    pts = []
    for _ in range(N_CUBES):
        d1, d2, d3 = rand_U_lin(), rand_U_lin(), rand_U_lin()
        for mask in range(1, 8):
            pt = 0
            if mask & 1: pt ^= d1
            if mask & 2: pt ^= d2
            if mask & 4: pt ^= d3
            pts.append(pt)
    _, _, b2, b3, _ = compute_zeta_bits(pts, orbits4)

    def compress_3diff(val_int):
        res = 0
        for t in range(N_CUBES):
            chunk = (val_int >> (7 * t)) & 0x7F
            if chunk.bit_count() & 1:
                res |= (1 << t)
        return res

    per_w12 = [0x3f3f, 0x5f5f, 0x6f6f, 0x7777]
    nonper_reps12 = [w for w in reps12 if w not in per_w12]
    rows_w11 = [compress_3diff(b2[v]) for v in reps11]
    rows_w12 = [compress_3diff(b2[w]) for w in nonper_reps12]

    null_w11 = find_nullspace(rows_w11)
    null_w12 = find_nullspace(rows_w12)
    null_all = find_nullspace(rows_w11 + rows_w12)
    print(f"Found {len(null_w11)} w11 quadratic-in-U syzygies, {len(null_w12)} w12 quadratic-in-U syzygies, {len(null_all)} total ({time.perf_counter()-t0:.2f}s)")

    # Print weights (number of orbits combined) of each syzygy!
    print("\n=== WEIGHT-11 QUADRATIC-IN-U CONDITIONS (7 total) ===")
    for idx, m in enumerate(null_w11):
        supp = [reps11[i] for i in range(len(reps11)) if (m >> i) & 1]
        print(f"  Q11[{idx}]: combines {len(supp)} w11 orbits: {[hex(x) for x in supp[:6]]}...")

    print("\n=== WEIGHT-12 QUADRATIC-IN-U CONDITIONS (19 total) ===")
    for idx, m in enumerate(null_w12):
        supp = [nonper_reps12[i] for i in range(len(nonper_reps12)) if (m >> i) & 1]
        print(f"  Q12[{idx:2d}]: combines {len(supp)} w12 orbits: {[hex(x) for x in supp[:6]]}...")

    # Wait: are ANY single w11 or w12 orbits already degree <= 2 on U_43?!
    single_w11 = [hex(reps11[i]) for i, r in enumerate(rows_w11) if r == 0]
    single_w12 = [hex(nonper_reps12[i]) for i, r in enumerate(rows_w12) if r == 0]
    print(f"\nSingle w11 orbits with deg_U <= 2: {len(single_w11)} -> {single_w11}")
    print(f"Single w12 orbits with deg_U <= 2: {len(single_w12)} -> {single_w12}")

    # Step 2: For any fixed q in T34 core, the 43x43 alternating matrix B_r(q)_{i, j}
    # is D_{U_basis[i], U_basis[j]}^{(2)} Q_r(q) = Q_r(q) ^ Q_r(q ^ u_i) ^ Q_r(q ^ u_j) ^ Q_r(q ^ u_i ^ u_j)!
    # Notice that since Q_r has total degree 3 and deg_U(Q_r) <= 2,
    # D_{u_i, u_j}^{(2)} Q_r(q) has DEGREE <= 1 IN q (so it only depends on q through linear forms)!
    # Let's evaluate B_r(q)_{i, j} at 20 random T34 core points q and check the rank of the 43x43 matrix B_r(q)!
    def sample_t34(branch):
        free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        return c

    # To evaluate D_{u_i, u_j}^{(2)} Q_r(q) at a point q, we need Q_r at:
    # q, q ^ u_i (43 pts), q ^ u_j, q ^ u_i ^ u_j (43*42/2 = 903 pts) -> total 1 + 43 + 903 = 947 points per q!
    # Even better: since D_{u_i, u_j}^{(2)} Q_r(q) is AFFINE-LINEAR in q, we can evaluate it at a random q in 0.8 seconds!
    q_test = sample_t34(0)
    pts_q = [q_test]
    for i in range(43):
        pts_q.append(q_test ^ U_basis[i])
    for i in range(43):
        for j in range(i + 1, 43):
            pts_q.append(q_test ^ U_basis[i] ^ U_basis[j])

    _, _, qb2, _, _ = compute_zeta_bits(pts_q, orbits4)

    # Combine qb2 according to the 26 null_all basis masks:
    all_cubic_reps = [(11, v) for v in reps11] + [(12, w) for w in nonper_reps12]
    all_qb2 = [qb2[v] for _, v in all_cubic_reps]

    print(f"\n=== 43x43 BILINEAR MATRIX RANKS AT A RANDOM CORE POINT q (total pts={len(pts_q)}) ===")
    for s_idx, m in enumerate(null_all):
        val_vec = 0
        for bit_i in range(len(all_qb2)):
            if (m >> bit_i) & 1:
                val_vec ^= all_qb2[bit_i]
        v0 = val_vec & 1
        vi = [(val_vec >> (1 + i)) & 1 for i in range(43)]
        adj = [0] * 43
        pair_idx = 1 + 43
        for i in range(43):
            for j in range(i + 1, 43):
                vij = (val_vec >> pair_idx) & 1
                pair_idx += 1
                bij = v0 ^ vi[i] ^ vi[j] ^ vij
                if bij:
                    adj[i] |= (1 << j)
                    adj[j] |= (1 << i)
        rk = mat_rank_gf2(adj, 43)
        print(f"  Syzygy Q[{s_idx:2d}] (weight {m.bit_count():3d}): 43x43 alternating matrix rank = {rk:2d} (bias <= 2^-{rk//2})")

if __name__ == '__main__':
    main()
