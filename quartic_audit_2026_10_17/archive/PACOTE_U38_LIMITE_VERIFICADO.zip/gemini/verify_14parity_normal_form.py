"""Verify the exact 14-parity normal form theorem for the 6 core conditions + 0x7f7f first bit!"""
import json, sys, itertools
from pathlib import Path
from fractions import Fraction
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from derive_0x7f7f import P, toggle

P_2laws = set()
for m in P:
    if (m >> 115) & 1: continue
    if (m >> 113) & 1: m = (m ^ (1 << 113)) | (1 << 57)
    toggle(P_2laws, m)

blocks = {
    'u1': [0, 4, 8, 18, 42, 52, 56, 94],
    'v1': [14, 22, 46, 71, 81, 85, 98, 106],
    'u2': [1, 9, 15, 28, 53, 67, 76, 103],
    'v2': [3, 11, 34, 45, 55, 69, 78, 89],
    'u3': [2, 10, 25, 37, 54, 68, 83, 104],
    'v3': [12, 20, 29, 33, 41, 48, 96, 110],
    'u4': [13, 21, 38, 70, 74, 93, 97, 109],
    'v4': [24, 32, 47, 72, 80, 86, 91, 107],
    'R1': [5, 6, 7, 50, 51, 58],
    'R2': [16, 17, 19, 59, 63, 95],
    'R3': [43, 44, 49, 62, 66, 100],
    'R4': [82, 84, 87, 102, 105, 108],
    'W1': [26, 27, 30, 60, 64, 111],
    'W2': [35, 36, 40, 61, 65, 114],
    'W3': [75, 77, 79, 88, 90, 101],
    'a':  [57],
    'b99': [99],
}

# Reconstruct P_2laws from the compact algebraic formula and check exact equality of polynomial sets!
def add_prod(target, listA, listB):
    for x in listA:
        for y in listB:
            if x == y: toggle(target, 1 << x)
            else: toggle(target, (1 << x) | (1 << y))

P_formula = set()
# Linear: b + K + M = u1+v1 + u2+v2+u4+v4 + u3+v3
for name in ['u1', 'v1', 'u2', 'v2', 'u3', 'v3', 'u4', 'v4']:
    for x in blocks[name]: toggle(P_formula, 1 << x)

b_list = blocks['u1'] + blocks['v1']
K_list = blocks['u2'] + blocks['v2'] + blocks['u4'] + blocks['v4']
M_list = blocks['u3'] + blocks['v3']
R_list = blocks['R1'] + blocks['R2'] + blocks['R3'] + blocks['R4']
J1_list = blocks['v2'] + blocks['u4']
J2_list = blocks['u2'] + blocks['v4']
J3_list = blocks['v3'] + blocks['u4'] + blocks['v4']
a1_list = blocks['R2'] + blocks['W1']
a2_list = blocks['R3'] + blocks['W2']
a3_list = blocks['R1'] + blocks['W3']

# Before setting b99 = b, there is (b + b99)*K:
add_prod(P_formula, b_list + blocks['b99'], K_list)
# + b * (R2 + R3):
add_prod(P_formula, b_list, blocks['R2'] + blocks['R3'])
# + R * J3:
add_prod(P_formula, R_list, J3_list)
# + (a + alpha3) * K:
add_prod(P_formula, blocks['a'] + a3_list, K_list)
# + alpha1 * (M + J1):
add_prod(P_formula, a1_list, M_list + J1_list)
# + alpha2 * (M + J2):
add_prod(P_formula, a2_list, M_list + J2_list)

assert P_formula == P_2laws, f"Symmetric diff size: {len(P_formula ^ P_2laws)}"
print("EXACT POLYNOMIAL IDENTITY P_formula == P_2laws VERIFIED (0 diff out of 1984 monomials)!")

# Count admissible patterns over (u1..u4, v1..v4, a, r23, alpha1, alpha2, alpha3) in {0,1}^13
# where r23 = R2 ^ R3, alpha1 = R2 ^ W1, alpha2 = R3 ^ W2, alpha3 = R1 ^ W3,
# and normalize by the 5 eliminated parity equations:
#   c115 = 0, c113 = a, c99 = b, t = a ^ sum(u_i * v_i), R = ((1^b)&M) ^ ((1^a)&K):
admissible_b0 = 0
admissible_b1 = 0
total_space = (1 << 13) * (1 << 5)
for bits in itertools.product(range(2), repeat=13):
    u1, v1, u2, v2, u3, v3, u4, v4, a, r23, al1, al2, al3 = bits
    b = u1 ^ v1
    K = u2 ^ v2 ^ u4 ^ v4
    M = u3 ^ v3
    if b & (a ^ K): continue
    t = a ^ (u1 & v1) ^ (u2 & v2) ^ (u3 & v3) ^ (u4 & v4)
    R = ((1 ^ b) & M) ^ ((1 ^ a) & K)
    J1 = v2 ^ u4
    J2 = u2 ^ v4
    J3 = v3 ^ u4 ^ v4
    val_0x7f7f = (
        b ^ K ^ M
        ^ (b & r23)
        ^ (R & J3)
        ^ ((a ^ al3) & K)
        ^ (al1 & (M ^ J1))
        ^ (al2 & (M ^ J2))
    )
    if val_0x7f7f == 0:
        if b == 0: admissible_b0 += 1
        else: admissible_b1 += 1

print(f"Admissible 13-bit patterns (out of 8192, with 5 eliminated parities c115, c113, c99, t, R -> denom {total_space}):")
print(f"  Branch b=0: {admissible_b0} / 8192 patterns -> global fraction {Fraction(admissible_b0, total_space)} (was 1/64 = 16/1024)")
print(f"  Branch b=1: {admissible_b1} / 8192 patterns -> global fraction {Fraction(admissible_b1, total_space)} (was 1/128 = 8/1024)")
print(f"  Total 7-condition core: {admissible_b0 + admissible_b1} / 8192 patterns -> global fraction {Fraction(admissible_b0 + admissible_b1, total_space)} (was 3/128 = 24/1024)")


