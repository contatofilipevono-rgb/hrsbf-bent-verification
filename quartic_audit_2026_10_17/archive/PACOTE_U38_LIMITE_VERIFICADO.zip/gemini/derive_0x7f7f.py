"""Compute the exact polynomial of h_f(0x7f7f)/16 mod 2 using tau_8-invariant 4-block coverings!"""
import itertools, random, time

t0 = time.perf_counter()
n = 16
def rot(m, k=1): return ((m << k) | (m >> (n - k))) & 0xFFFF

seen = set(); ORB = []; index = {}
for t in itertools.combinations(range(n), 4):
    m = sum(1 << j for j in t)
    if m in index: continue
    orb = set(); r = m
    for _ in range(n): orb.add(r); r = rot(r, 1)
    for r in orb: index[r] = len(ORB)
    ORB.append(orb)

u = 0x7f7f
T = [j for j in range(16) if (u >> j) & 1]
assert len(T) == 14
# All 4-subsets of T:
subsets4 = [sum(1 << j for j in c) for c in itertools.combinations(T, 4)]
print(f"Number of 4-subsets of T (size 14): {len(subsets4)}") # comb(14, 4) = 1001

# Separate 4-subsets into tau_8-fixed and tau_8-pairs {A, tau_8(A)}:
fixed_subsets = []
paired_subsets = []
seen_s = set()
for s in subsets4:
    if s in seen_s: continue
    s8 = rot(s, 8)
    assert s8 in subsets4
    if s == s8:
        fixed_subsets.append(s)
        seen_s.add(s)
    else:
        paired_subsets.append((s, s8))
        seen_s.add(s); seen_s.add(s8)

print(f"tau_8-fixed 4-subsets in T: {len(fixed_subsets)} (orbits: {sorted({index[s] for s in fixed_subsets})})")
print(f"tau_8-paired 4-subsets in T: {len(paired_subsets)} pairs")

# A tau_8-fixed 4-element subset {A, B, C, D} of subsets4 such that A | B | C | D == u:
# Case 1: Two pairs (A, A8) and (B, B8) from paired_subsets!
# Wait: A | A8 is tau_8-invariant, and (A | A8) | (B | B8) == u!
# Since u has 14 elements (7 antipodal pairs), and each (A | A8) has at most 4 antipodal pairs (8 elements),
# (A | A8) | (B | B8) == u iff the union of the antipodal projections of A and B is all 7 pairs of u!
P = set()
def toggle(P, m):
    if m in P: P.remove(m)
    else: P.add(m)

# Count Case 1: two pairs from paired_subsets
c1 = 0
union_pair = [(s | s8, index[s]) for s, s8 in paired_subsets]
for i in range(len(union_pair)):
    u1, idx1 = union_pair[i]
    for j in range(i + 1, len(union_pair)):
        u2, idx2 = union_pair[j]
        if (u1 | u2) == u:
            toggle(P, (1 << idx1) | (1 << idx2))
            c1 += 1

# Count Case 2: one pair (A, A8) from paired_subsets and two fixed C, D from fixed_subsets
c2 = 0
for u1, idx1 in union_pair:
    for i in range(len(fixed_subsets)):
        sC = fixed_subsets[i]; idxC = index[sC]
        for j in range(i + 1, len(fixed_subsets)):
            sD = fixed_subsets[j]; idxD = index[sD]
            if (u1 | sC | sD) == u:
                toggle(P, (1 << idx1) | (1 << idxC) | (1 << idxD))
                c2 += 1

# Count Case 3: four fixed subsets A, B, C, D from fixed_subsets
c3 = 0
for comb in itertools.combinations(fixed_subsets, 4):
    if (comb[0] | comb[1] | comb[2] | comb[3]) == u:
        m = 0
        for s in comb: m |= (1 << index[s])
        toggle(P, m)
        c3 += 1

print(f"Coverings: Case1(2,2)={c1}, Case2(2,1,1)={c2}, Case3(1,1,1,1)={c3}")
print(f"Raw polynomial P for h_f(0x7f7f)/16 mod 2: {len(P)} monomials, max degree = {max(m.bit_count() for m in P)}, degrees = { {d: sum(1 for m in P if m.bit_count()==d) for d in range(1,5)} }")

if __name__ == '__main__':
    # Verify against direct evaluation of h_f(0x7f7f)//16 % 2 on 32 random coefficient vectors in ALL of H(16,4)!
    points = [x for x in range(65536) if (x & u) == x] # 2^14 = 16384 points
    truth_words = [sum((sum(x & m == m for m in orb) % 2) << k for k, x in enumerate(points)) for orb in ORB]
    chi = sum((x.bit_count() % 2) << k for k, x in enumerate(points))

    rng = random.Random(42)
    for t in range(32):
        c = rng.getrandbits(116)
        word = chi
        for j in range(116):
            if (c >> j) & 1: word ^= truth_words[j]
        h_val = (1 << 14) - 2 * word.bit_count()
        assert h_val % 16 == 0
        bit_actual = (h_val // 16) % 2
        bit_poly = sum((c & m) == m for m in P) % 2
        assert bit_actual == bit_poly, f"Mismatch at trial {t}: {bit_actual} != {bit_poly}"

    print(f"EXACT IDENTITY VERIFIED ON 32 RANDOM H(16,4) FUNCTIONS in {time.perf_counter()-t0:.2f}s!")

