"""Inspect Delta B_j = pair_00[j] ^ pair_11[j] and the exact polynomial degree of W_f(0x7fff)/32 mod 2!"""
import json, sys, time, random
from pathlib import Path
from itertools import combinations
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from explore_S11_and_W7fff import orbits, points_00, points_11, truth_00, truth_11, full_offset, eval_S00_S11

positions = [i * 128 + j for i in range(128) for j in range(i + 1, 128)]
pair_00 = [sum(((w >> p) & 1) << k for k, p in enumerate(positions)) for w in truth_00]
pair_11 = [sum(((w >> p) & 1) << k for k, p in enumerate(positions)) for w in truth_11]
offset = sum((points_00[p].bit_count() % 2) << k for k, p in enumerate(positions))

diag_00 = [sum(((w >> (i * 128 + i)) & 1) << i for i in range(128)) for w in truth_00]
diag_11 = [sum(((w >> (i * 128 + i)) & 1) << i for i in range(128)) for w in truth_11]

active = [j for j in range(116) if j not in [113, 115]]
B0 = {j: pair_00[j] ^ (pair_00[113] if j == 57 else 0) for j in active}
B1 = {j: pair_11[j] ^ (pair_11[113] if j == 57 else 0) for j in active}
DB = {j: B0[j] ^ B1[j] for j in active}

nonzero_DB = [j for j in active if DB[j] != 0]
print(f"Active vars: {len(active)}, vars with DB[j] != 0: {len(nonzero_DB)}")
print("Zero DB[j] vars:", [j for j in active if DB[j] == 0])

# Check diagonal difference D00 - D11:
for j in active:
    d0 = diag_00[j] ^ (diag_00[113] if j == 57 else 0)
    d1 = diag_11[j] ^ (diag_11[113] if j == 57 else 0)
    if d0 != 0 or d1 != 0:
        print(f"Diag var {j}: wt(d0)={d0.bit_count()}, wt(d1)={d1.bit_count()}, wt(d0^d1)={(d0^d1).bit_count()}")

# Check finite-difference degree of P_W(c) = (W_f(0x7fff) // 32) % 2 on the 2-law space!
# For a polynomial F(c) over GF(2), its degree is <= d iff its (d+1)-th finite difference vanishes on random points & directions!
def P_W(c):
    s00, s11 = eval_S00_S11(c)
    w = s00 - s11
    assert w % 32 == 0
    return (w // 32) & 1

rng = random.Random(123)
def rand_2law():
    c = rng.getrandbits(116)
    c &= ~(1 << 115)
    c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
    return c

for deg_test in [1, 2, 3, 4]:
    non_zero = 0
    for _ in range(200):
        c0 = rand_2law()
        dirs = [1 << j for j in rng.sample(active, deg_test)]
        for idx in range(len(dirs)):
            if dirs[idx] == (1 << 57):
                dirs[idx] |= (1 << 113)
        val = 0
        for mask in range(1 << deg_test):
            pt = c0
            for b in range(deg_test):
                if (mask >> b) & 1:
                    pt ^= dirs[b]
            val ^= P_W(pt)
        if val != 0:
            non_zero += 1
    print(f"Order-{deg_test} finite difference of (W_f(0x7fff)//32)%2 on 2-law space: {non_zero}/200 nonzero")
