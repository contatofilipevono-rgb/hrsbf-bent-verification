"""Explore S_11 (the shifted 0x7f7f coset y_7 = y_15 = 1) and W_f(0x7fff) = S_00 - S_11 on H(16,4) and the T34 core!"""
import json, sys, time, random, math
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from derive_0x7f7f import ORB as orbits, P as P_S00, toggle

t0 = time.perf_counter()
old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
factor = old['fourth_factorization']
t45_cert = json.loads((base / 'T45_NOVA_CONDICAO_CERTIFICADO.json').read_text())

u = 0x7f7f
shift = (1 << 7) | (1 << 15) # 0x8080, complement of 0x7f7f!
mask = u & 255
small = [v for v in range(256) if (v & mask) == v]
points_00 = [v | (w << 8) for v in small for w in small]
points_11 = [x | shift for x in points_00]

truth_00 = [sum((sum((x & m) == m for m in orb) % 2) << k for k, x in enumerate(points_00)) for orb in orbits]
truth_11 = [sum((sum((x & m) == m for m in orb) % 2) << k for k, x in enumerate(points_11)) for orb in orbits]
full_offset = sum((x.bit_count() % 2) << k for k, x in enumerate(points_00))

def eval_S00_S11(c):
    w00 = full_offset
    w11 = full_offset
    for j in range(116):
        if (c >> j) & 1:
            w00 ^= truth_00[j]
            w11 ^= truth_11[j]
    s00 = 16384 - 2 * w00.bit_count()
    s11 = 16384 - 2 * w11.bit_count()
    return s00, s11

# 1. Check T45 witness (which passed all 13 T40 conditions AND had S00 = -128)!
c_wit = int(t45_cert['witness_coefficient_hex'], 16)
s00_w, s11_w = eval_S00_S11(c_wit)
print(f"T45 witness: S_00 = h_f(0x7f7f) = {s00_w}, S_11 = {s11_w}, W_f(0x7fff) = S_00 - S_11 = {s00_w - s11_w}")
print(f"  Does T45 witness fail 32 | S_11? {s11_w % 32 != 0} (S_11 mod 32 = {s11_w % 32})")
print(f"  Does T45 witness fail W_f(0x7fff) == +-256? {abs(s00_w - s11_w) != 256}")

# 2. Check gcd of S_11 and W_f(0x7fff) = S_00 - S_11 on:
#    (a) General H(16,4)
#    (b) 2-law space (c115=0, c113=c57)
#    (c) 6-condition core (T34)
rng = random.Random(42)
g_all_s11 = 0; g_all_w = 0
for _ in range(200):
    c = rng.getrandbits(116)
    s00, s11 = eval_S00_S11(c)
    g_all_s11 = math.gcd(g_all_s11, abs(s11))
    g_all_w = math.gcd(g_all_w, abs(s00 - s11))
print(f"General H(16,4) (200 samples): gcd(S_11) = {g_all_s11}, gcd(W_f(0x7fff)) = {g_all_w}")

g_2law_s11 = 0; g_2law_w = 0
for _ in range(200):
    c = rng.getrandbits(116)
    c &= ~(1 << 115)
    c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
    s00, s11 = eval_S00_S11(c)
    g_2law_s11 = math.gcd(g_2law_s11, abs(s11))
    g_2law_w = math.gcd(g_2law_w, abs(s00 - s11))
print(f"After 2 linear laws (c115=0, c113=c57): gcd(S_11) = {g_2law_s11}, gcd(W_f(0x7fff)) = {g_2law_w}")

def parity(c, indices):
    return sum((c >> j) & 1 for j in indices) % 2

for branch in [0, 1]:
    free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
    g_core_s11 = 0; g_core_w = 0
    s11_mod32 = {}
    w_mod64 = {}
    for _ in range(500):
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        s00, s11 = eval_S00_S11(c)
        g_core_s11 = math.gcd(g_core_s11, abs(s11))
        g_core_w = math.gcd(g_core_w, abs(s00 - s11))
        s11_mod32[s11 % 32] = s11_mod32.get(s11 % 32, 0) + 1
        w_mod64[(s00 - s11) % 64] = w_mod64.get((s00 - s11) % 64, 0) + 1
    print(f"Branch {branch} core (500 samples): gcd(S_11) = {g_core_s11}, gcd(W_f(0x7fff)) = {g_core_w}")
    print(f"  S_11 mod 32:", dict(sorted(s11_mod32.items())))
    print(f"  W_f(0x7fff) mod 64:", dict(sorted(w_mod64.items())))
