"""Test 0x7f7f on the T45 witness and on the exact T35/T40 branch charts!"""
import json, sys, time
from pathlib import Path
from fractions import Fraction
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from derive_0x7f7f import P as P_0x7f7f_raw, ORB as orbits, index, toggle


if __name__ == '__main__':
    # 1. Test the T45 witness (which passes all 13 conditions of T40) on 0x7f7f!
    t45_cert = json.loads((base / 'T45_NOVA_CONDICAO_CERTIFICADO.json').read_text())
    c_wit = int(t45_cert['witness_coefficient_hex'], 16)
    monomials = [m for j, orb in enumerate(orbits) if (c_wit >> j) & 1 for m in orb]
    cache = {}
    def f_wit(x):
        if x not in cache:
            cache[x] = sum((x & m) == m for m in monomials) % 2
        return cache[x]

    def h_wit(u):
        total = 0
        x = u
        while True:
            total += (1 - 2 * f_wit(x)) * (-1 if (u.bit_count() - x.bit_count()) % 2 else 1)
            if x == 0: break
            x = (x - 1) & u
        return total

    h_7f7f = h_wit(0x7f7f)
    p_7f7f_wit = sum((c_wit & m) == m for m in P_0x7f7f_raw) % 2
    print(f"T45 witness (passes all 13 T40 conditions): h_f(0x7f7f) = {h_7f7f}")
    print(f"  divisible by 16? {h_7f7f % 16 == 0}")
    print(f"  divisible by 32? {h_7f7f % 32 == 0} (P_0x7f7f(c_wit) = {p_7f7f_wit}, (h_f//16)%2 = {(h_7f7f//16)%2})")
    print(f"  divisible by 64? {h_7f7f % 64 == 0}")
    print(f"  divisible by 128 (required by Zhang-Gao)? {h_7f7f % 128 == 0}")

    for fname in ['T37_NOVA_CONDICAO_CERTIFICADO.json', 'T34_FORMA_NORMAL_CERTIFICADO.json']:
        if (base / fname).exists():
            d = json.loads((base / fname).read_text())
            for k, v in d.items():
                if 'witness' in k and isinstance(v, str) and v.startswith('0x'):
                    cw = int(v, 16)
                    pw = sum((cw & m) == m for m in P_0x7f7f_raw) % 2
                    print(f"Witness in {fname} ({k}): P_0x7f7f = {pw}")


# 2. Reduce P_0x7f7f_raw to the exact T35/T40 branch=0 and branch=1 coordinates!
old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
seventh = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
L = seventh['L']
K = seventh['K']
factor = old['fourth_factorization']

def substitute(poly, j, Q):
    out = set()
    for m in poly:
        if (m >> j) & 1:
            for n in Q:
                toggle(out, (m ^ (1 << j)) | n)
        else:
            toggle(out, m)
    return out

R_7f7f_branches = {}
for branch in [0, 1]:
    free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
    origin = ((1 << 0) | (1 << 99)) if branch else 0
    cb = []
    for j in free:
        c = (1 << j) ^ ((1 << 0) if j in L else 0)
        if branch:
            if j in K:
                c ^= (1 << 57) | (1 << 113)
        elif j == 57:
            c ^= 1 << 113
        cb.append(c)
    # Substitute c_k = origin_k ^ sum_{j in free} z_j cb[j]_k into P_0x7f7f_raw
    # For each k in 0..115, let's build its linear form in z_j (plus constant 0 if in origin)
    lin_forms = {}
    for k in range(116):
        form_k = set()
        if (origin >> k) & 1:
            form_k.add(0)
        for j, c in zip(free, cb):
            if (c >> k) & 1:
                form_k.add(1 << j)
        lin_forms[k] = form_k

    P_sub = set()
    for m in P_0x7f7f_raw:
        # Multiply lin_forms[k] for all k in m
        prod = {0}
        for k in range(116):
            if (m >> k) & 1:
                new_prod = set()
                for a in prod:
                    for b in lin_forms[k]:
                        toggle(new_prod, a | b)
                prod = new_prod
        for term in prod:
            toggle(P_sub, term)

    # Now eliminate 23 using Q and 5 using G, just like VERIFICAR_POLINOMIOS_T35.py
    def form(group):
        mask = sum(1 << j for j in group)
        return {(1 << j) for j, c in zip(free, cb) if (c & mask).bit_count() % 2} ^ ({0} if (origin & mask).bit_count() % 2 else set())
    Q = form(factor['linear'])
    for block in factor['products']:
        for a in form(block['I']):
            for b in form(block['J']):
                toggle(Q, a | b)
    Q.remove(1 << 23)
    R_poly = substitute(P_sub, 23, Q)

    G = {1 << j for j in seventh['R']}
    if branch == 0:
        for j in seventh['M'] + K:
            toggle(G, 1 << j)
        for j in K:
            toggle(G, (1 << 57) | (1 << j))
    G.remove(1 << 5)
    R_poly = substitute(R_poly, 5, G)
    R_7f7f_branches[branch] = R_poly
    degs = {}
    for m in R_poly:
        d = m.bit_count()
        degs[d] = degs.get(d, 0) + 1
    print(f"Branch {branch}: R_0x7f7f has {len(R_poly)} monomials, degree distribution = {dict(sorted(degs.items()))}")
    # Check if any degree > 2 monomials do NOT contain 57
    high_no_57 = [m for m in R_poly if m.bit_count() > 2 and not ((m >> 57) & 1)]
    print(f"  Degree > 2 monomials without c_57: {len(high_no_57)}")
