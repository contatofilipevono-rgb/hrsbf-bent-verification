"""Test all 388 degree-3 conditions (273 weight-11 b2 + 112 non-periodic weight-12 b2 + 3 periodic weight-12 b3)
for quadratic syzygies (linear combinations whose 3rd-order derivatives vanish on:
  Case A: Full 114-dim 2-law space
  Case B: 109-dim linear T34 space
  Case C: U_66 x U_66 x U_66 (purely quadratic on U_66!)
  Case D: U_66 x U_66 x T34_lin (constant bilinear form B_P on U_66!)
)"""
import json, sys, time, random
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from check_joint_cubic_rank_and_syzygies import build_orbits, compute_zeta_bits, gf2_rank

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)

    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    # Identify the 50 core variables and 66 U-variables of T40/T43/T44:
    # Let's check how T40 defines U_66!
    # In T34, the quadratic condition is c23 = a + parity([31,39,112]) + sum I*J,
    # and the nonlinear term on Branch 0 is a * parity(K).
    q_vars = set([0, 5, 23, 57, 99, 113, 115, 31, 39, 112])
    q_vars.update(seven['K'])
    for p in factor['products']:
        q_vars.update(p['I'])
        q_vars.update(p['J'])
    U_vars = sorted(set(range(116)) - q_vars)
    print(f"len(q_vars) = {len(q_vars)}, len(U_vars) = {len(U_vars)}")

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    rng = random.Random(20261017)

    # Linear subspace of 2-law space: c115 = 0, c113 = c57 (dim 114)
    def rand_2law():
        c = rng.getrandbits(116)
        c &= ~(1 << 115)
        c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
        return c

    # Linear subspace of T34 (Branch 0 homogeneous directions: b99=0, c115=0, c113=c57, c0=parity(L), c5=parity(R)+parity(M)+parity(K))
    free_lin = sorted(set(range(116)) - {0, 5, 23, 99, 113, 115})
    def rand_t34_lin():
        c = 0
        for j in free_lin:
            if rng.randint(0, 1):
                c |= (1 << j)
        c |= ((c >> 57) & 1) << 113
        c |= parity(c, seven['L']) << 0
        c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ parity(c, seven['K'])) << 5
        return c

    # Direction in U_vars adjusted by linear pivots c0 and c5 so it stays in T34_lin!
    U_free = [j for j in U_vars if j not in (0, 5, 23, 99, 113, 115)]
    def rand_U_lin():
        c = 0
        for j in U_free:
            if rng.randint(0, 1):
                c |= (1 << j)
        c |= parity(c, seven['L']) << 0
        c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ parity(c, seven['K'])) << 5
        return c

    # Note: for a degree-3 polynomial P(c), the 3rd derivative D_{d1, d2, d3}^{(3)} P(c) is CONSTANT (independent of base point c)!
    # So we can set base_c = 0, and for each triple (d1, d2, d3), evaluate P on the 8 points of span(d1, d2, d3) (or 7 non-zero points since P(0)=0)!
    N_CUBES = 500

    def test_case(name, gen_d1, gen_d2, gen_d3):
        t_c = time.perf_counter()
        pts = []
        for _ in range(N_CUBES):
            d1, d2, d3 = gen_d1(), gen_d2(), gen_d3()
            for mask in range(1, 8):
                pt = 0
                if mask & 1: pt ^= d1
                if mask & 2: pt ^= d2
                if mask & 4: pt ^= d3
                pts.append(pt)
        _, _, b2, b3, _ = compute_zeta_bits(pts, orbits4)

        def compress_3diff(val_int):
            # Each cube uses 7 consecutive bits; XOR them together!
            res = 0
            for t in range(N_CUBES):
                chunk = (val_int >> (7 * t)) & 0x7F
                if chunk.bit_count() & 1:
                    res |= (1 << t)
            return res

        per_w12 = [0x3f3f, 0x5f5f, 0x6f6f, 0x7777]
        rows_w11 = [compress_3diff(b2[v]) for v in reps11]
        rows_w12_nonper = [compress_3diff(b2[w]) for w in reps12 if w not in per_w12]
        rows_w12_per = [compress_3diff(b3[w]) for w in reps12 if w in per_w12 and w != 0x7777]
        all_rows = rows_w11 + rows_w12_nonper + rows_w12_per

        rk_w11 = gf2_rank(rows_w11)
        rk_w12 = gf2_rank(rows_w12_nonper)
        rk_all = gf2_rank(all_rows)
        print(f"\n=== {name} ({time.perf_counter()-t_c:.2f}s) ===")
        print(f"  3rd-derivative rank of 273 w11 conditions:      {rk_w11} / 273 (nullity = {273 - rk_w11})")
        print(f"  3rd-derivative rank of 112 w12 conditions:      {rk_w12} / 112 (nullity = {112 - rk_w12})")
        print(f"  3rd-derivative rank of ALL 388 conditions:      {rk_all} / {len(all_rows)} (nullity = {len(all_rows) - rk_all})")

    test_case("Case A: Full 114-dim 2-law space (d1, d2, d3 in 2-law)", rand_2law, rand_2law, rand_2law)
    test_case("Case B: 109-dim T34 linear space (d1, d2, d3 in T34_lin)", rand_t34_lin, rand_t34_lin, rand_t34_lin)
    test_case("Case C: Pure U_66 space (d1, d2, d3 in U_66)", rand_U_lin, rand_U_lin, rand_U_lin)
    test_case("Case D: U_66 x U_66 x T34_lin (d1, d2 in U_66, d3 in T34_lin)", rand_U_lin, rand_U_lin, rand_t34_lin)

if __name__ == '__main__':
    main()
