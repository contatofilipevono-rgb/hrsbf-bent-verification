# Guia de Auditoria Adversarial Independente (Para Gemini)

Este pacote contém todos os certificados JSON, manuscritos matemáticos e verificadores independentes em Python padrão (sem dependências externas) da pesquisa sobre a inexistência de funções booleanas bent no espaço $H(16,4)$ (dimensão 116) e sua generalização para $H(2m,4)$ ($2m \ge 8$).

**Instrução ao Auditor Adversarial:**
Não aceite relatórios `PASS` ou percentuais numéricos pelo valor de face. Sua missão é tentar **refutar, encontrar lacunas lógicas, erros de sinal/normalização, falhas de invariância de calibre (gauge) ou extrapolações indevidas** entre o que está **provado/certificado exaustivamente** e o que é **observação em amostra finita ou conjectura aberta**. Se houver ambiente de execução Python (3.10+), execute diretamente os scripts verificadores listados abaixo.

---

## 1. Mapa do Que Está Provado vs. Conjecturado neste Pacote

### A. Resultados Exatos e Certificados (Teoremas em $H(16,4)$, $H(8,4)$ e $H(10,4)$)

1. **Forma Normal de 14 Paridades da 7ª Condição de Núcleo (`0x7f7f`, 1º bit) e Densidade Exata do Núcleo de 7 Condições:**
   - **Verificador:** `verify_14parity_normal_form.py` (apoia-se em `derive_0x7f7f.py`).
   - **Afirmação Provada:** No espaço das 2 leis lineares ($c_{115}=0, c_{113}=c_{57}$), o polinômio $P_{\text{0x7f7f}}(c) = \frac{h_f(\text{0x7f7f})}{16} \pmod 2$ possui **exatamente 1.984 monômios de grau $\le 2$** (64 lineares e 1.920 quadráticos; todos os 202 monômios cúbicos se anulam identicamente sob as 2 leis lineares) e é identicamente igual (diferença simétrica `0 / 1.984`) à forma normal fechada em 14 paridades disjuntas:
     $$P_{\text{0x7f7f}} = b \oplus K \oplus M \oplus (b \oplus c_{99})K \oplus b(R_2 \oplus R_3) \oplus R J_3 \oplus (a \oplus \alpha_3)K \oplus \alpha_1(M \oplus J_1) \oplus \alpha_2(M \oplus J_2),$$
     onde $\alpha_1 = R_2 \oplus W_1$, $\alpha_2 = R_3 \oplus W_2$, $\alpha_3 = R_1 \oplus W_3$, e $W_1, W_2, W_3$ são três blocos de 6 órbitas completamente disjuntos das 50 variáveis do núcleo `T34`.
   - **Densidade Exata do Núcleo de 7 Condições (`T34` + $P_{\text{0x7f7f}}=0$):**
     - Ramo $b = 0$: $\frac{9}{1024}$ (contra $\frac{1}{64} = \frac{16}{1024}$ em `T34`).
     - Ramo $b = 1$: $\frac{1}{256} = \frac{4}{1024}$ (contra $\frac{1}{128} = \frac{8}{1024}$ em `T34`).
     - Densidade global exata do núcleo de 7 condições: **$\frac{13}{1024}$** (redução de $45{,}83\%$ em relação a $\frac{3}{128} = \frac{24}{1024}$), reduzindo o piso assintótico (*carpet*) do método de soma de caracteres de 7 condições fora do núcleo de $\frac{3}{16384} \approx 1{,}83105 \times 10^{-4}$ para **$\frac{13}{131072} \approx 9{,}91821 \times 10^{-5}$**.

2. **Teorema de Invariância Bilinear sob $P_{\text{0x7f7f}}$ e Limite Global Certificado de 14 Condições:**
   - **Verificadores e Certificados:** `VERIFICAR_LIMITE_14COND_0x7f7f.py`, `test_0x7f7f_on_T40.py`, `compute_14cond_bound.py`, `T45B_TOP16_REFINEMENT.json`, `T47_LIMITE_14COND_CERTIFICADO.json`, `refine_t44_top16.py`, `refine_t44_next9.py`.
   - **Afirmação Provada:** Como a restrição de $P_{\text{0x7f7f}}$ ao núcleo `T34` tem grau $\le 2$ (no Ramo 0 após condicionar em $a = c_{57} \in \{0,1\}$, e no Ramo 1 diretamente pois $a = K$), sua primeira derivada direcional $D_d R_{\text{0x7f7f}}$ tem grau $\le 1$ (afim) e sua forma bilinear alternada de segunda derivada é **identicamente nula**:
     $$B_{P_\lambda \oplus R_{\text{0x7f7f}}}(d) \equiv B_{P_\lambda}(d) \quad \forall d, \forall \lambda \in \mathbb{F}_2^7 \setminus \{0\}.$$
     Portanto, todos os certificados de posto de diferenças finitas de `T43` ($k \in \{10,12\}$), `T44` ($k=14$) e `T45B_TOP16_REFINEMENT.json` ($k=16$ em 26 órbitas de `T44`) permanecem **exatamente válidos** para os caracteres deslocados por $R_{\text{0x7f7f}}$.
   - **Cotas Superiores Globais Exatas Certificadas:**
     - `T40` (13 cond.): $\frac{1310509920535861}{2^{61}} \approx 5{,}683431 \times 10^{-4}$ ($\ge 99{,}9431656919\%$ excluído).
     - `T40 + 0x7f7f` (14 cond.): $\frac{4465784380695475}{2^{63}} \approx 4{,}841813 \times 10^{-4}$ ($\ge 99{,}9515818687\%$ excluído).
     - `T43 + 0x7f7f` (14 cond.): $\frac{3040800148062131}{2^{63}} \approx 3{,}296842 \times 10^{-4}$ ($\ge 99{,}9670315787\%$ excluído).
     - `T44 + 0x7f7f` (14 cond.): $\frac{2512965847270323}{2^{63}} \approx 2{,}724563 \times 10^{-4}$ ($\ge 99{,}9727543697\%$ excluído).
     - `T44 + Top26` (13 cond., $k=16$): $\frac{1254870463218455}{2^{62}} \approx 2{,}721067 \times 10^{-4}$ ($\ge 99{,}9727893344\%$ excluído).
     - **`T44 + Top26 + 0x7f7f` (14 cond., $k=16$):** **$\frac{3469169466878495}{2^{64}} \approx 1{,}880641 \times 10^{-4}$** (**$\ge 99{,}9811935946\%$ excluído**).

3. **Teorema do Colapso Diagonal Antípoda em $H(2m,4)$ e Prova Exaustiva para $H(8,4)$ e $H(10,4)$:**
   - **Verificador:** `verify_general_conjecture_small_n.py`.
   - **Afirmação Provada:** Na diagonal antípoda $\Delta_m = \{x = (x_0, x_0) \in \mathbb{F}_2^{2m}\}$, todas as $\dim H(2m,4) - \lfloor m/2 \rfloor$ órbitas não-antípodas se anulam identicamente (verificado para $2m \in \{8, 10, 12, 14, 16\}$). Em $H(8,4)$ ($1.024$ funções) e $H(10,4)$ ($4.194.304$ funções), a torre de condições periódico–antípodas de defeito $\le 1$ elimina exaustivamente **$100\%$ das funções** (`0 / 1.024` e `0 / 4.194.304` sobreviventes).

4. **Teorema da Congruência Universal das 128 Frequências de Defeito Antípoda 1 em $H(16,4)$:**
   - **Verificadores:** `verify_128_defect1_theorem.py`, `explore_S11_and_W7fff.py`, `check_weight14_and_W7fff.py`.
   - **Afirmação Provada:** Para todas as 128 frequências $w(w_0) = (w_0, w_0) \oplus e_{15}$ ($w_0 \in \mathbb{F}_2^7$), os 32.768 pontos com $y_7 \ne y_{15}$ cancelam-se por simetria $\tau_8$, $W_f(w(w_0)) = S_{00}(w_0) - S_{11}(w_0) \equiv 0 \pmod{32}$ vale identicamente no espaço das 2 leis, e $W_f(w(w_0)) \equiv W_f(\text{0x7fff}) \pmod{64}$ independe de $w_0$. Além disso, o vetor testemunha `c_wit` de `T45` (que passa nas 13 condições de `T40` e tem $S_{00} = -128$) possui $S_{11} = +384$ e $W_f(\text{0x7fff}) = -512 \ne \pm 256$, sendo imediatamente eliminado.

5. **Teorema das 388 Condições Cúbicas Puras Livres de Carry e das 26 Sizígias Quadráticas Diretas em $U_{38}$ (Sem Cauchy–Schwarz):**
   - **Verificadores:** `check_all_w11_w12_cubic_conditions.py`, `check_joint_cubic_rank_and_syzygies.py`, `inspect_26_quadratic_in_U_conditions.py`, `check_B_q_dependency.py`, `verify_U38_direct_quadratic_theorem.py`.
   - **Afirmação Provada:**
     - As 273 órbitas de peso 11 e as 112 órbitas não-periódicas de peso 12 satisfazem $8 \mid h_f(v)$ identicamente em $H(16,4)$, e seu bit de ordem 8, $b_2[v] = \frac{h_f(v)}{8} \pmod 2 = C_3(v) \bmod 2 = 0$, fornece $385$ equações polinomiais cúbicas puras ($\deg \le 3$) livres de carry (que, com as 3 órbitas periódicas de peso 12, têm posto $\mathbb{F}_2$ máximo $388 / 388$ no núcleo `T34`).
     - Existe um subespaço de dimensão 38, $U_{38} \subset U_{43}$, que preserva identicamente todas as **7 condições do núcleo (`T34 + 0x7f7f`)** sem tocar em nenhum pivô, e um subespaço de **26 sizígias linearmente independentes** $Q_0, \dots, Q_{25}$ cujas derivadas de 3ª ordem em $U_{38} \times U_{38} \times U_{38}$ se anulam identicamente. Em cada coset $q + U_{38}$, $Q_\lambda(q + u)$ tem grau $\le 2$ diretamente em $u \in U_{38}$ (sem necessidade de derivada direcional nem raiz quadrada de Cauchy–Schwarz), e sua matriz bilinear alternada $38 \times 38$ $B_\lambda^{(38)}(q)$ independe de $c_{23}, c_{31}, c_{39}, c_{57}, c_{112}$.

---

### B. O Que É Observação em Amostra Finita ou Conjectura Aberta (NÃO Promover a Teorema sem Prova Global)

1. **Inexistência Global em $H(16,4)$ e $H(2m,4)$ para $2m \ge 12$:** Continua em aberto (Conjecturas Gerais A e B em `T47_TEORIA_E_CONJECTURA_GERAL.md`). A cota certificada em $H(16,4)$ é $\le 1{,}880641 \times 10^{-4}$ ($\ge 99{,}9811935946\%$ excluído), o que **não** é $100\%$.
2. **Taxas de Sobrevivência `0 / N` em Amostras Aleatórias do Núcleo `T34`:** Nos scripts `verify_128_defect1_theorem.py`, `analyze_delta_h_hierarchy.py` e `check_all_w11_w12_cubic_conditions.py`, observamos `0 / 500`, `0 / 600` e `0 / 1000` sobreviventes no núcleo `T34` quando impomos as 128 frequências de defeito 1, as 21 diferenças antípodas de peso 10 ou as 273 condições cúbicas de peso 11. Esses números são **evidências empíricas em amostras finitas** da Conjectura Geral B, **não** provas exaustivas em $H(16,4)$.

---

## 2. Roteiro de Execução Rápida para o Auditor

Extraia todos os arquivos na mesma pasta e execute (com Python 3.10+ padrão):

```bash
# 1. Verificar a forma normal de 14 paridades de 0x7f7f (0 diff em 1.984 monômios) e densidade 13/1024 (~1s):
python verify_14parity_normal_form.py

# 2. Verificar o limite global certificado de 14 condições (T40, T43, T44, T44+Top26 + 0x7f7f) em paralelo (~15s):
python VERIFICAR_LIMITE_14COND_0x7f7f.py

# 3. Verificar o colapso diagonal em H(2m,4) e a prova exaustiva 0/1024 em H(8,4) e 0/4194304 em H(10,4) (~3s):
python verify_general_conjecture_small_n.py

# 4. Verificar a congruência universal mod 64 das 128 frequências de defeito antípoda 1 em H(16,4) (~3s):
python verify_128_defect1_theorem.py

# 5. Verificar as 388 condições cúbicas livres de carry e as 26 sizígias quadráticas diretas em U_38 (~3s):
python check_joint_cubic_rank_and_syzygies.py
python verify_U38_direct_quadratic_theorem.py
```

---

## 3. Perguntas Específicas para a Auditoria Adversarial do Gemini

1. **Auditoria de `verify_14parity_normal_form.py` e `VERIFICAR_LIMITE_14COND_0x7f7f.py`:**
   - Confira se a substituição das variáveis pivô no Ramo 0 e no Ramo 1 preserva exatamente a medida condicional sobre $\{0,1\}^{116}$ e se a invariância bilinear $B_{P_\lambda \oplus R_{\text{0x7f7f}}}(d) \equiv B_{P_\lambda}(d)$ está livre de termos cúbicos residuais quando $a = c_{57}$ é fixado em $\{0,1\}$ no Ramo 0.
2. **Auditoria de `T45B_TOP16_REFINEMENT.json`:**
   - Confira se a restrição a submatrizes principais $64 \times 64$ (usando a monotonicidade $\text{rank}(B_{\text{sub}}) \le \text{rank}(B_{\text{full}}) \implies 2^{-\text{rank}(B_{\text{full}})/2} \le 2^{-\text{rank}(B_{\text{sub}})/2}$) mantém a direção correta da desigualdade para todas as 26 órbitas refinadas em $k = 16$.
3. **Auditoria do Teorema $U_{38}$ (`verify_U38_direct_quadratic_theorem.py`) e da Conjectura Geral B (`T47_TEORIA_E_CONJECTURA_GERAL.md`):**
   - Verifique se o subespaço $U_{38}$ realmente comuta com todas as 7 condições do núcleo (`T34 + 0x7f7f`) sem tocar em nenhum pivô, e avalie como converter as 26 sizígias quadráticas diretas em $U_{38}$ (onde não há raiz quadrada de Cauchy–Schwarz e o piso assintótico cai para $\frac{13}{2^{36}} \approx 1{,}89 \times 10^{-10}$) no próximo certificado global `T50`.
