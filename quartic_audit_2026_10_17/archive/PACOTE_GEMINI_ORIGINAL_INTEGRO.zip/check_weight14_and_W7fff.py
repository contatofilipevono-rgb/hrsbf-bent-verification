"""Check Order-5 finite difference of W_f(0x7fff)/32 mod 2 and explore all 8 weight-14 supports u_(d)!"""
import json, sys, time, random, math
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from explore_S11_and_W7fff import orbits, eval_S00_S11, seven, factor

active = [j for j in range(116) if j not in [113, 115]]
rng = random.Random(123)

def P_W(c):
    s00, s11 = eval_S00_S11(c)
    w = s00 - s11
    assert w % 32 == 0
    return (w // 32) & 1

def rand_2law():
    c = rng.getrandbits(116)
    c &= ~(1 << 115)
    c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
    return c

non_zero_5 = 0
for _ in range(100):
    c0 = rand_2law()
    dirs = [1 << j for j in rng.sample(active, 5)]
    for idx in range(len(dirs)):
        if dirs[idx] == (1 << 57):
            dirs[idx] |= (1 << 113)
    val = 0
    for mask in range(1 << 5):
        pt = c0
        for b in range(5):
            if (mask >> b) & 1:
                pt ^= dirs[b]
        val ^= P_W(pt)
    if val != 0:
        non_zero_5 += 1
print(f"Order-5 finite difference of (W_f(0x7fff)//32)%2 on 2-law space: {non_zero_5}/100 nonzero (0 means EXACT degree <= 4!)")

# Also check on the 6-condition core (T34): what is the distribution of W_f(0x7fff) mod 256 and h_f(0x7f7f) mod 128?
# Wait: remember that for a bent function:
#   W_f(0x7fff) = S_00 - S_11 in {+256, -256}
#   h_f(0x7f7f) = S_00 in {-256, -128, 0, +128, +256} (and 128 | S_00, 128 | S_11)!
# Wait: since S_00 - S_11 = W_f(0x7fff) = +-256 and 128 | S_00, this forces:
#   1) S_00 % 128 == 0
#   2) S_11 % 128 == 0
#   3) (S_00 - S_11) % 256 == 0 AND S_00 != S_11!
def parity(c, indices):
    return sum((c >> j) & 1 for j in indices) % 2

for branch in [0, 1]:
    free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
    n_samples = 2000
    pass_s00_32 = 0
    pass_both_32 = 0
    pass_both_64 = 0
    pass_both_128 = 0
    pass_exact_bent_pair = 0
    for _ in range(n_samples):
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        s00, s11 = eval_S00_S11(c)
        if s00 % 32 == 0:
            pass_s00_32 += 1
        if s00 % 32 == 0 and (s00 - s11) % 64 == 0:
            pass_both_32 += 1
        if s00 % 64 == 0 and s11 % 64 == 0:
            pass_both_64 += 1
        if s00 % 128 == 0 and s11 % 128 == 0 and (s00 - s11) % 256 == 0:
            pass_both_128 += 1
        if abs(s00) <= 256 and s00 % 128 == 0 and abs(s00 - s11) == 256:
            pass_exact_bent_pair += 1
    print(f"\nBranch {branch} ({n_samples} core samples):")
    print(f"  32 | S_00 (1 bit, P_0x7f7f=0):                    {pass_s00_32}/{n_samples} ({pass_s00_32/n_samples:.4f})")
    print(f"  32 | S_00 and 64 | (S_00 - S_11) (2 bits):        {pass_both_32}/{n_samples} ({pass_both_32/n_samples:.4f})")
    print(f"  64 | S_00 and 64 | S_11 (3 bits):                 {pass_both_64}/{n_samples} ({pass_both_64/n_samples:.4f})")
    print(f"  128 | S_00, 128 | S_11, 256 | (S_00-S_11) (6b):   {pass_both_128}/{n_samples} ({pass_both_128/n_samples:.4f})")
    print(f"  Exact Diophantine |S_00|<=256 & |S_00-S_11|==256: {pass_exact_bent_pair}/{n_samples} ({pass_exact_bent_pair/n_samples:.4f})")
