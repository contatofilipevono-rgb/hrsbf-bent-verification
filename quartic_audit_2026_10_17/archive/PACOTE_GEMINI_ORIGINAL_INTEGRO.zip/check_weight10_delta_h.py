"""Check Delta h_f(u; 7) = S_00(u) - S_11(u; 7) on all weight-10 and weight-12 tau_8-invariant supports u <= 0x7f7f!"""
import json, sys, time, random, math
from pathlib import Path
from itertools import combinations
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from explore_S11_and_W7fff import orbits, seven, factor

t0 = time.perf_counter()
shift = (1 << 7) | (1 << 15) # 0x8080

# Weight-10 tau_8-invariant supports u <= 0x7f7f: choose 5 bits from 0..6
u10_list = []
for comb in combinations(range(7), 5):
    u0 = sum(1 << j for j in comb)
    u10_list.append(u0 | (u0 << 8))

# Weight-12 tau_8-invariant supports u <= 0x7f7f: choose 6 bits from 0..6
u12_list = []
for comb in combinations(range(7), 6):
    u0 = sum(1 << j for j in comb)
    u12_list.append(u0 | (u0 << 8))

print(f"Found {len(u10_list)} weight-10 supports and {len(u12_list)} weight-12 supports inside 0x7f7f.")

# Test on 100 random 2-law functions and 100 core functions:
# What is the gcd of S_00(u), S_11(u; 7), and Delta h_f(u; 7) = S_00(u) - S_11(u; 7)?
rng = random.Random(42)

def eval_u(u, c_list):
    pts00 = [x for x in range(65536) if (x & u) == x]
    pts11 = [x | shift for x in pts00]
    n_pts = len(pts00)
    t00 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts00)) for orb in orbits]
    t11 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts11)) for orb in orbits]
    off = sum((x.bit_count() & 1) << k for k, x in enumerate(pts00))
    res = []
    for c in c_list:
        w00 = off; w11 = off
        for j in range(116):
            if (c >> j) & 1:
                w00 ^= t00[j]; w11 ^= t11[j]
        s00 = n_pts - 2 * w00.bit_count()
        s11 = n_pts - 2 * w11.bit_count()
        res.append((s00, s11, s00 - s11))
    return res

def parity(c, indices):
    return sum((c >> j) & 1 for j in indices) % 2

c_2law = []
for _ in range(100):
    c = rng.getrandbits(116)
    c &= ~(1 << 115)
    c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
    c_2law.append(c)

c_core = []
free0 = sorted(set(range(116)) - {0, 99, 113, 115})
for _ in range(100):
    c = rng.getrandbits(116) & sum(1 << j for j in free0 if j not in [23, 5])
    c |= parity(c, seven['L']) << 0
    c |= ((c >> 57) & 1) << 113
    a = (c >> 57) & 1
    c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
    c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
    c_core.append(c)

print("\n=== Weight-12 supports u <= 0x7f7f (Zhang-Gao requires 32 | S_00(u) and 32 | Delta h_f(u; 7)!) ===")
for u in u12_list[:4]:
    r2 = eval_u(u, c_2law)
    rc = eval_u(u, c_core)
    g2_s00 = math.gcd(*[abs(x[0]) for x in r2])
    g2_s11 = math.gcd(*[abs(x[1]) for x in r2])
    g2_dh  = math.gcd(*[abs(x[2]) for x in r2])
    gc_s00 = math.gcd(*[abs(x[0]) for x in rc])
    gc_s11 = math.gcd(*[abs(x[1]) for x in rc])
    gc_dh  = math.gcd(*[abs(x[2]) for x in rc])
    print(f"  u={hex(u)}: 2-law gcd(S00, S11, Dh)=({g2_s00}, {g2_s11}, {g2_dh}) | Core gcd(S00, S11, Dh)=({gc_s00}, {gc_s11}, {gc_dh})")

print("\n=== Weight-10 supports u <= 0x7f7f (Zhang-Gao requires 8 | S_00(u) and 16 | Delta h_f(u; 7)!) ===")
for u in u10_list[:6]:
    r2 = eval_u(u, c_2law)
    rc = eval_u(u, c_core)
    g2_s00 = math.gcd(*[abs(x[0]) for x in r2])
    g2_s11 = math.gcd(*[abs(x[1]) for x in r2])
    g2_dh  = math.gcd(*[abs(x[2]) for x in r2])
    gc_s00 = math.gcd(*[abs(x[0]) for x in rc])
    gc_s11 = math.gcd(*[abs(x[1]) for x in rc])
    gc_dh  = math.gcd(*[abs(x[2]) for x in rc])
    print(f"  u={hex(u)}: 2-law gcd(S00, S11, Dh)=({g2_s00}, {g2_s11}, {g2_dh}) | Core gcd(S00, S11, Dh)=({gc_s00}, {gc_s11}, {gc_dh})")
