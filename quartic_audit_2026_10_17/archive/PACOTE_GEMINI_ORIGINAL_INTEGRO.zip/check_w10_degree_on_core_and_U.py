"""Check the exact algebraic degree of the 21 weight-10 antipodal difference conditions
P_{Delta,10}^{(u)}(c) = (Delta_7 h_f(u) // 16) mod 2 on:
  1. The full 2-law space (114 vars)
  2. The T34 core (Branch 0 and Branch 1)
  3. The 66-dimensional subspace U of variables outside the T34 core (used in T40/T43/T44)!
Also check linear independence of these conditions from the 7 T40 conditions!
"""
import json, sys, time, random, math
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

def build_orbits():
    def rot(m, k=1): return ((m << k) | (m >> (16 - k))) & 0xFFFF
    ORB = []; index = {}
    for t in combinations(range(16), 4):
        m = sum(1 << j for j in t)
        if m in index: continue
        orb = set(); r = m
        for _ in range(16): orb.add(r); r = rot(r, 1)
        for r in orb: index[r] = len(ORB)
        ORB.append(orb)
    return ORB

def main():
    t0 = time.perf_counter()
    orbits = build_orbits()
    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    shift = (1 << 7) | (1 << 15)  # 0x8080

    u10_list = []
    for comb in combinations(range(7), 5):
        u0 = sum(1 << j for j in comb)
        u10_list.append((comb, u0 | (u0 << 8)))

    def build_bitsliced(u):
        pts00 = [x for x in range(65536) if (x & u) == x]
        pts11 = [x | shift for x in pts00]
        n_pts = len(pts00)
        t00 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts00)) for orb in orbits]
        t11 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts11)) for orb in orbits]
        return n_pts, t00, t11

    w10_evals = [(comb, u, build_bitsliced(u)) for comb, u in u10_list]

    def eval_dh16(c, bdata):
        n_pts, t00, t11 = bdata
        w00 = 0
        w11 = 0
        for j in range(116):
            if (c >> j) & 1:
                w00 ^= t00[j]
                w11 ^= t11[j]
        s00 = n_pts - 2 * w00.bit_count()
        s11 = n_pts - 2 * w11.bit_count()
        return ((s00 - s11) // 16) & 1

    # What are the 66 U-variables in T40/T43/T44?
    # Let's extract the core variables of T34:
    core_vars = set([0, 99, 113, 115, 57, 31, 39, 112])
    core_vars.update(seven['L'])
    core_vars.update(seven['R'])
    core_vars.update(seven['M'])
    core_vars.update(seven['K'])
    for p in factor['products']:
        core_vars.update(p['I'])
        core_vars.update(p['J'])
    U_vars = sorted(set(range(116)) - core_vars)
    print(f"Number of core_vars: {len(core_vars)}, number of U_vars: {len(U_vars)}")

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    rng = random.Random(20261017)

    def sample_t34(branch):
        free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        return c

    def rand_U():
        c = 0
        for j in U_vars:
            if rng.randint(0, 1):
                c |= (1 << j)
        return c

    # Note: adding a vector u in U_vars to a T34 core point c DOES NOT change any of the T34 core conditions!
    # Wait: let's verify that U_vars is completely disjoint from all T34 equations!
    # Yes, because core_vars contains all indices appearing in T34!
    print("\n=== CHECKING DEGREE IN U_vars (66 vars disjoint from T34 core) ===")
    for idx, (comb, u, bdata) in enumerate(w10_evals):
        # Test degree in U_vars starting from random T34 core points
        deg_U = 0
        for d in range(1, 5):
            nonzero = 0
            for _ in range(100):
                base_c = sample_t34(rng.randint(0, 1))
                dirs = [rand_U() for _ in range(d)]
                val = 0
                for mask in range(1 << d):
                    pt = base_c
                    for b in range(d):
                        if (mask >> b) & 1:
                            pt ^= dirs[b]
                    val ^= eval_dh16(pt, bdata)
                if val != 0:
                    nonzero += 1
            if nonzero > 0:
                deg_U = d
        # Also test degree of cross-derivative D_{u_dir} P(c) with respect to core variables!
        print(f"  w10[{idx:2d}] u=0x{u:04x} {comb}: deg_U(Dh/16) = {deg_U}")

    # Check how many linearly independent conditions the 21 weight-10 supports give on T34 core,
    # and how many are cyclic rotations (by 8 or within 0..6?) Wait: 0x7f7f is NOT invariant under +1 rotation,
    # it IS invariant under reflection i <-> 6-i (and i+8 <-> 14-i)!
    N_TEST = 500
    pts = [sample_t34(0) for _ in range(N_TEST)] + [sample_t34(1) for _ in range(N_TEST)]
    mat = []
    for idx, (comb, u, bdata) in enumerate(w10_evals):
        row = 0
        for k, c in enumerate(pts):
            if eval_dh16(c, bdata):
                row |= (1 << k)
        mat.append((idx, u, comb, row))

    # Compute GF(2) rank of the 21 weight-10 conditions on the 1000 T34 core points:
    basis = []
    indep_indices = []
    for idx, u, comb, row in mat:
        v = row
        for b in basis:
            lsb = (b & -b).bit_length() - 1
            if (v >> lsb) & 1:
                v ^= b
        if v != 0:
            basis.append(v)
            indep_indices.append((idx, hex(u), comb))

    print(f"\nGF(2) rank of the 21 weight-10 conditions (Dh/16 mod 2) on T34 core: {len(basis)} / 21")
    for item in indep_indices:
        print(f"  Independent generator: w10[{item[0]:2d}] u={item[1]} comb={item[2]}")

if __name__ == '__main__':
    main()
