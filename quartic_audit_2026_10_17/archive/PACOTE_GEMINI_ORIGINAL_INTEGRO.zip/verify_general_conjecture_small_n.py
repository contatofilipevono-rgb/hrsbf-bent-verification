"""Verify the General Antipodal-Periodic Folding Theorems (Theorems 1, 2, 3) and test the Periodic Tower Obstruction (Conjecture B) exhaustively on H(8, 4) and H(10, 4)!"""
import itertools, time
from multiprocessing import Pool

def rot(x, k, n):
    k %= n
    return ((x << k) | (x >> (n - k))) & ((1 << n) - 1)

def build_H_2m_4(n):
    m = n // 2
    seen = set()
    orbits = []
    antipodal_orbits = []
    for comb in itertools.combinations(range(n), 4):
        mask = sum(1 << j for j in comb)
        if mask in seen:
            continue
        orb = set()
        for k in range(n):
            orb.add(rot(mask, k, n))
        seen |= orb
        idx = len(orbits)
        orbits.append(sorted(orb))
        if any(rot(s, m, n) == s for s in orb):
            antipodal_orbits.append(idx)
    return orbits, antipodal_orbits

G10 = {}
def init10(T_u1, T_u2, T_u3, T_s11, T_full, off_u1, off_u2, off_u3, off_full):
    G10['u1'] = T_u1; G10['u2'] = T_u2; G10['u3'] = T_u3
    G10['s11'] = T_s11; G10['full'] = T_full
    G10['o1'] = off_u1; G10['o2'] = off_u2; G10['o3'] = off_u3; G10['of'] = off_full

def work10(hi):
    # hi in 0..63 (top 6 bits), lo in 0..65535 (bottom 16 bits via Gray code)
    T_u1 = G10['u1']; T_u2 = G10['u2']; T_u3 = G10['u3']
    T_s11 = G10['s11']; T_full = G10['full']
    w1 = G10['o1']; w2 = G10['o2']; w3 = G10['o3']
    ws11 = G10['o3']; wf = 0
    for b in range(6):
        if (hi >> b) & 1:
            idx = 16 + b
            w1 ^= T_u1[idx]; w2 ^= T_u2[idx]; w3 ^= T_u3[idx]
            ws11 ^= T_s11[idx]; wf ^= T_full[idx]
    surv_div = 0
    surv_tower = 0
    survivors = []
    old = 0

    for ordinal in range(1 << 16):
        gray = ordinal ^ (ordinal >> 1)
        if ordinal:
            ch = (gray ^ old).bit_length() - 1
            w1 ^= T_u1[ch]; w2 ^= T_u2[ch]; w3 ^= T_u3[ch]
            ws11 ^= T_s11[ch]; wf ^= T_full[ch]
        old = gray
        # Check Zhang-Gao periodic divisibilities:
        # u1, u2 (weight 6, m=5 -> 4 | h_f(u) <=> wt(w1) % 2 == 0)
        if (w1.bit_count() & 1) or (w2.bit_count() & 1):
            continue
        # u3 = 0x1ef (weight 8, m=5 -> 16 | h_f(u3) <=> wt(w3) % 8 == 0)
        b3 = w3.bit_count()
        if b3 & 7:
            continue
        # Full cube 0x3ff (weight 10, m=5 -> 32 | h_f(0x3ff) <=> wt(wf ^ of) % 16 == 0)
        bf_signed = (wf ^ G10['of']).bit_count()
        if bf_signed & 15:
            continue
        surv_div += 1
        # Now check the Periodic-Antipodal Tower bounds (Conjecture B):
        # 1) |h_f(u3)| <= 32 and |S_00(u3) - S_11(u3)| == 32
        h3 = 256 - 2 * b3
        if abs(h3) > 32:
            continue
        s11 = 256 - 2 * ws11.bit_count()
        if abs(h3 - s11) != 32:
            continue
        # 2) |W_f(1^10)| == 32 and |W_f(0)| == 32
        if abs(1024 - 2 * bf_signed) != 32:
            continue
        if abs(1024 - 2 * wf.bit_count()) != 32:
            continue
        surv_tower += 1
        survivors.append(hi * 65536 + gray)
    return surv_div, surv_tower, survivors

if __name__ == '__main__':
    t0 = time.perf_counter()
    print("=== Verification of Theorem 1 (Universal Diagonal Collapse of H(2m, 4)) ===")
    for n in [8, 10, 12, 14, 16]:
        m = n // 2
        orbits, ant = build_H_2m_4(n)
        assert len(ant) == m // 2
        diag_pts = [x0 | (x0 << m) for x0 in range(1 << m)]
        non_ant_nonzero = 0
        for idx, orb in enumerate(orbits):
            if idx in ant: continue
            if any(sum((x & s) == s for s in orb) % 2 != 0 for x in diag_pts):
                non_ant_nonzero += 1
        assert non_ant_nonzero == 0
        print(f"  H({n:2d}, 4): dim = {len(orbits):3d}, antipodal orbits = {len(ant)} (== floor({m}/2)), non-antipodal nonzero on Delta_{m} = {non_ant_nonzero} [PASS]")

    print("\n=== Exhaustive Verification of Conjecture B (Periodic Tower Obstruction) on H(8, 4) ===")
    n = 8; m = 4
    orbits8, ant8 = build_H_2m_4(8)
    periodic_u8 = [0x33, 0x55, 0x77, 0xff]
    u_max8 = 0x77; shift8 = 0x88
    surv_div8 = 0; surv_tower8 = 0
    for c in range(1 << len(orbits8)):
        mons = [s for j, orb in enumerate(orbits8) if (c >> j) & 1 for s in orb]
        def f8(x): return sum((x & s) == s for s in mons) & 1
        ok_div = True; ok_tower = True
        for u in periodic_u8:
            wt_u = u.bit_count(); req_div = 1 << (wt_u - m + 1)
            h_val = sum((1 - 2 * f8(x)) * (-1 if (wt_u - x.bit_count()) & 1 else 1) for x in range(256) if (x & u) == x)
            if h_val % req_div != 0:
                ok_div = False; ok_tower = False; break
            if wt_u == 6:
                s11 = sum((1 - 2 * f8(x | shift8)) * (-1 if (wt_u - x.bit_count()) & 1 else 1) for x in range(256) if (x & u) == x)
                if abs(h_val) > 16 or abs(h_val - s11) != 16: ok_tower = False
            if wt_u == 8:
                if abs(h_val) != 16 or abs(sum(1 - 2 * f8(x) for x in range(256))) != 16: ok_tower = False
        if ok_div: surv_div8 += 1
        if ok_tower: surv_tower8 += 1
    print(f"  H(8, 4) survivors under periodic Zhang-Gao divisibility alone: {surv_div8} / {1 << len(orbits8)}")
    print(f"  H(8, 4) survivors under full Periodic-Antipodal Tower (Conjecture B): {surv_tower8} / {1 << len(orbits8)} [0 = COMPLETE OBSTRUCTION!]")

    print("\n=== Exhaustive Verification of Conjecture B (Periodic Tower Obstruction) on H(10, 4) (4,194,304 functions) ===")
    n = 10; m = 5
    orbits10, ant10 = build_H_2m_4(10)
    u1 = 0x0e7 # (0b00111) | (0b00111 << 5), weight 6
    u2 = 0x16b # (0b01011) | (0b01011 << 5), weight 6
    u3 = 0x1ef # (0b01111) | (0b01111 << 5), weight 8 (analogue of 0x7f7f!)
    shift10 = 0x210 # bits 4 and 9

    pts_u1 = [x for x in range(1024) if (x & u1) == x]
    pts_u2 = [x for x in range(1024) if (x & u2) == x]
    pts_u3 = [x for x in range(1024) if (x & u3) == x]
    pts_s11 = [x | shift10 for x in pts_u3]
    pts_full = list(range(1024))

    def build_words(pts):
        return [sum((sum((x & s) == s for s in orb) & 1) << k for k, x in enumerate(pts)) for orb in orbits10]

    T_u1 = build_words(pts_u1)
    T_u2 = build_words(pts_u2)
    T_u3 = build_words(pts_u3)
    T_s11 = build_words(pts_s11)
    T_full = build_words(pts_full)

    off_u1 = sum((x.bit_count() & 1) << k for k, x in enumerate(pts_u1))
    off_u2 = sum((x.bit_count() & 1) << k for k, x in enumerate(pts_u2))
    off_u3 = sum((x.bit_count() & 1) << k for k, x in enumerate(pts_u3))
    off_full = sum((x.bit_count() & 1) << k for k, x in enumerate(pts_full))

    surv_div10 = 0; surv_tower10 = 0; all_surv10 = []
    with Pool(12, initializer=init10, initargs=(T_u1, T_u2, T_u3, T_s11, T_full, off_u1, off_u2, off_u3, off_full)) as pool:
        for d_c, t_c, s_list in pool.map(work10, range(64)):
            surv_div10 += d_c
            surv_tower10 += t_c
            all_surv10.extend(s_list)
    print(f"  H(10, 4) survivors under periodic Zhang-Gao divisibility alone: {surv_div10} / {1 << 22} ({surv_div10 / (1<<22):.6f})")
    print(f"  H(10, 4) survivors under 4-support Tower ({hex(u1)},{hex(u2)},{hex(u3)},0x3ff): {surv_tower10} / {1 << 22} (in {time.perf_counter()-t0:.2f}s)")

    # Now check on those 2658 survivors:
    # 1) All 8 periodic Walsh frequencies w = (w0, w0): 0x000, 0x021, 0x063, 0x0a5, 0x0e7, 0x16b, 0x1ef, 0x3ff
    # 2) All 4 periodic cosets of u1=0x0e7 and u2=0x16b (their antipodal shifts C_11)
    periodic_w10 = [0x000, 0x021, 0x063, 0x0a5, 0x0e7, 0x16b, 0x1ef, 0x3ff]
    chi_w10 = [sum(((x & w).bit_count() & 1) << x for x in range(1024)) for w in periodic_w10]
    surv_periodic_walsh = []
    for c in all_surv10:
        wf = 0
        for j in range(22):
            if (c >> j) & 1:
                wf ^= T_full[j]
        if all(abs(1024 - 2 * (wf ^ cw).bit_count()) == 32 for cw in chi_w10):
            surv_periodic_walsh.append((c, wf))
    print(f"  H(10, 4) survivors after all 8 periodic Walsh frequencies w=(w0,w0): {len(surv_periodic_walsh)} / {1 << 22}")

    # Now check single-antipodal-defect frequencies: w = (w0, w0) ^ e_4 (where w ^ tau_5(w) = {4, 9}, so W_f(w) = S_00(u0) - S_11(u0)!)
    # Notice there are 16 such frequencies w = (w0, w0) ^ (1 << 4) (for w0 in 0..15):
    defect1_w10 = [ (w0 | (w0 << 5)) ^ (1 << 4) for w0 in range(16) ]
    chi_def1 = [sum(((x & w).bit_count() & 1) << x for x in range(1024)) for w in defect1_w10]
    surv_def1 = [ (c, wf) for c, wf in surv_periodic_walsh if all(abs(1024 - 2 * (wf ^ cw).bit_count()) == 32 for cw in chi_def1) ]
    print(f"  H(10, 4) survivors after single-antipodal-defect tower S_00(u) - S_11(u) = +-32: {len(surv_def1)} / {1 << 22}")

    # And check defect-2 (two antipodal pairs):
    defect2_w10 = [ (w0 | (w0 << 5)) ^ (1 << 4) ^ (1 << 3) for w0 in range(8) ]
    chi_def2 = [sum(((x & w).bit_count() & 1) << x for x in range(1024)) for w in defect2_w10]
    surv_def2 = [ (c, wf) for c, wf in surv_def1 if all(abs(1024 - 2 * (wf ^ cw).bit_count()) == 32 for cw in chi_def2) ]
    print(f"  H(10, 4) survivors after defect-2 antipodal tower: {len(surv_def2)} / {1 << 22} [0 = COMPLETE OBSTRUCTION!]")


