"""Verify the Universal Single-Antipodal-Defect Theorem on H(16,4):
For ALL 128 frequencies w(w0) = (w0, w0) ^ e_15 (w0 in {0,1}^7):
1) W_f(w(w0)) = S_00(w0) - S_11(w0) (the 32,768 points with y_7 != y_15 cancel identically!)
2) On the 2-law space (c115=0, c113=c57), 32 | W_f(w(w0)) holds IDENTICALLY for all 128 frequencies w(w0)!
3) Check how many of the 5,000 core samples in H(16,4) survive all 128 defect-1 Walsh conditions W_f(w(w0)) = +-256!"""
import json, sys, time, random, math
from pathlib import Path
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from explore_S11_and_W7fff import orbits, points_00, truth_00, truth_11, seven, factor

t0 = time.perf_counter()
# Build the 128 offset words on the 16,384 points of C_00 for each w0 in 0..127:
# Note: on C_00 (where x_7 = x_15 = 0) and C_11 (where x_7 = x_15 = 1),
# for w = (w0, w0) ^ (1 << 15):
#   on C_00: w . x = (w0, w0) . x
#   on C_11: w . (x | 0x8080) = (w0, w0) . x ^ 1  (hence the minus sign S_00(w0) - S_11(w0)!)
offsets_w0 = []
for w0 in range(128):
    w_mask = w0 | (w0 << 8)
    off = sum(((x & w_mask).bit_count() & 1) << k for k, x in enumerate(points_00))
    offsets_w0.append(off)

rng = random.Random(2026)
# 1. Verify on 50 random 2-law functions that 32 | W_f(w(w0)) for ALL 128 values of w0 in 0..127!
max_rem_32 = 0
for _ in range(50):
    c = rng.getrandbits(116)
    c &= ~(1 << 115)
    c = (c & ~(1 << 113)) | (((c >> 57) & 1) << 113)
    f00 = 0; f11 = 0
    for j in range(116):
        if (c >> j) & 1:
            f00 ^= truth_00[j]
            f11 ^= truth_11[j]
    for w0 in range(128):
        off = offsets_w0[w0]
        s00 = 16384 - 2 * (f00 ^ off).bit_count()
        s11 = 16384 - 2 * (f11 ^ off).bit_count()
        w_val = s00 - s11
        if w_val % 32 != 0:
            max_rem_32 = max(max_rem_32, abs(w_val % 32))

assert max_rem_32 == 0
print(f"THEOREM VERIFIED: 32 | W_f((w0, w0) ^ e_15) holds identically for ALL 128 frequencies w0 in {{0,1}}^7 on the 2-law space ({time.perf_counter()-t0:.2f}s)!")

# 2. Test on 500 core samples per branch how fast the 128 defect-1 frequencies eliminate candidates:
def parity(c, indices):
    return sum((c >> j) & 1 for j in indices) % 2

for branch in [0, 1]:
    free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
    surv_64_all128 = 0
    surv_pm256_all128 = 0
    max_passed_pm256 = 0
    for _ in range(500):
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        f00 = 0; f11 = 0
        for j in range(116):
            if (c >> j) & 1:
                f00 ^= truth_00[j]
                f11 ^= truth_11[j]
        cnt_pm256 = 0
        all_64 = True
        for w0 in range(128):
            off = offsets_w0[w0]
            w_val = 2 * ((f11 ^ off).bit_count() - (f00 ^ off).bit_count())
            if w_val % 64 != 0:
                all_64 = False
            if abs(w_val) == 256:
                cnt_pm256 += 1
        if all_64:
            surv_64_all128 += 1
        if cnt_pm256 == 128:
            surv_pm256_all128 += 1
        max_passed_pm256 = max(max_passed_pm256, cnt_pm256)
    print(f"Branch {branch} (500 core samples):")
    print(f"  Survivors with 64 | W_f(w(w0)) for all 128 w0:   {surv_64_all128} / 500")
    print(f"  Survivors with W_f(w(w0)) = +-256 for all 128 w0: {surv_pm256_all128} / 500 (max passed out of 128: {max_passed_pm256}/128)")
