"""Interpolate the exact ANF of the quadratic and cubic antipodal subcube difference
conditions on the 2-law space, and test their survival on the T34 core!"""
import json, sys, time, random, math
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

def build_orbits():
    def rot(m, k=1): return ((m << k) | (m >> (16 - k))) & 0xFFFF
    ORB = []; index = {}
    for t in combinations(range(16), 4):
        m = sum(1 << j for j in t)
        if m in index: continue
        orb = set(); r = m
        for _ in range(16): orb.add(r); r = rot(r, 1)
        for r in orb: index[r] = len(ORB)
        ORB.append(orb)
    return ORB

def main():
    t0 = time.perf_counter()
    orbits = build_orbits()
    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    shift = (1 << 7) | (1 << 15)  # 0x8080

    u10_list = []
    for comb in combinations(range(7), 5):
        u0 = sum(1 << j for j in comb)
        u10_list.append((comb, u0 | (u0 << 8)))

    u12_list = []
    for comb in combinations(range(7), 6):
        u0 = sum(1 << j for j in comb)
        u12_list.append((comb, u0 | (u0 << 8)))

    def build_bitsliced(u):
        pts00 = [x for x in range(65536) if (x & u) == x]
        pts11 = [x | shift for x in pts00]
        n_pts = len(pts00)
        t00 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts00)) for orb in orbits]
        t11 = [sum((sum((x & m) == m for m in orb) & 1) << k for k, x in enumerate(pts11)) for orb in orbits]
        return n_pts, t00, t11

    print("Building bit-sliced evaluators for 21 weight-10 and 7 weight-12 supports...")
    w10_evals = [(comb, u, build_bitsliced(u)) for comb, u in u10_list]
    w12_evals = [(comb, u, build_bitsliced(u)) for comb, u in u12_list]
    print(f"Built in {time.perf_counter() - t0:.2f}s")

    def eval_dh(c, bdata):
        n_pts, t00, t11 = bdata
        w00 = 0
        w11 = 0
        for j in range(116):
            if (c >> j) & 1:
                w00 ^= t00[j]
                w11 ^= t11[j]
        s00 = n_pts - 2 * w00.bit_count()
        s11 = n_pts - 2 * w11.bit_count()
        return s00, s11, s00 - s11

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    rng = random.Random(20261017)

    def sample_t34(branch):
        free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        return c

    N_SAMPLES = 500
    t34_b0 = [sample_t34(0) for _ in range(N_SAMPLES)]
    t34_b1 = [sample_t34(1) for _ in range(N_SAMPLES)]
    t34_samples = t34_b0 + t34_b1

    print("\n=== CHECKING WEIGHT-12 SUPPORTS ON T34 CORE ===")
    w12_vecs = []
    for idx, (comb, u, bdata) in enumerate(w12_evals):
        vals0 = [eval_dh(c, bdata)[2] for c in t34_b0]
        vals1 = [eval_dh(c, bdata)[2] for c in t34_b1]
        g0 = math.gcd(*[abs(v) for v in vals0])
        g1 = math.gcd(*[abs(v) for v in vals1])
        vals = vals0 + vals1
        bit16 = tuple((v // 16) & 1 for v in vals)
        bit32 = tuple((v // 32) & 1 for v in vals)
        bit64 = tuple((v // 64) & 1 for v in vals)
        w12_vecs.append((idx, u, g0, g1, bit16, bit32, bit64))
        c16_0 = sum((v // 16) & 1 for v in vals0)
        c16_1 = sum((v // 16) & 1 for v in vals1)
        c32_0 = sum((v // 32) & 1 for v in vals0)
        c32_1 = sum((v // 32) & 1 for v in vals1)
        print(f"  w12[{idx}] u=0x{u:04x}: Core gcd(B0, B1)=({g0:2d}, {g1:2d}) | Dh/16=1 count (B0,B1)=({c16_0},{c16_1}) | Dh/32=1 count (B0,B1)=({c32_0},{c32_1})")

    print("\n=== CHECKING WEIGHT-10 SUPPORTS ON T34 CORE ===")
    w10_vecs = []
    for idx, (comb, u, bdata) in enumerate(w10_evals):
        vals0 = [eval_dh(c, bdata)[2] for c in t34_b0]
        vals1 = [eval_dh(c, bdata)[2] for c in t34_b1]
        g0 = math.gcd(*[abs(v) for v in vals0])
        g1 = math.gcd(*[abs(v) for v in vals1])
        vals = vals0 + vals1
        bit8 = tuple((v // 8) & 1 for v in vals)
        bit16 = tuple((v // 16) & 1 for v in vals)
        w10_vecs.append((idx, u, g0, g1, bit8, bit16))
        c8_0 = sum((v // 8) & 1 for v in vals0)
        c8_1 = sum((v // 8) & 1 for v in vals1)
        c16_0 = sum((v // 16) & 1 for v in vals0)
        c16_1 = sum((v // 16) & 1 for v in vals1)
        print(f"  w10[{idx:2d}] u=0x{u:04x}: Core gcd(B0, B1)=({g0:2d}, {g1:2d}) | Dh/8=1 (B0,B1)=({c8_0},{c8_1}) | Dh/16=1 (B0,B1)=({c16_0},{c16_1})")

    # Interpolate exact ANF on 2-law space of the quadratic conditions!
    # Free variables on 2-law space: all j in 0..115 except 113 and 115 (where bit 57 toggles both 57 and 113)
    free_2law = [j for j in range(116) if j not in (113, 115)]
    def vec_from_vars(var_list):
        c = 0
        for v in var_list:
            c |= (1 << v)
            if v == 57:
                c |= (1 << 113)
        return c

    def interpolate_deg2(fn):
        v0 = fn(0)
        lin = {}
        for v in free_2law:
            val = fn(vec_from_vars([v])) ^ v0
            if val:
                lin[v] = 1
        quad = []
        for i_idx, u_var in enumerate(free_2law):
            lu = lin.get(u_var, 0)
            for v_var in free_2law[i_idx + 1:]:
                lv = lin.get(v_var, 0)
                val = fn(vec_from_vars([u_var, v_var])) ^ v0 ^ lu ^ lv
                if val:
                    quad.append((u_var, v_var))
        return v0, sorted(lin.keys()), quad

    print("\n=== INTERPOLATING EXACT ANF OF QUADRATIC WEIGHT-12 CONDITIONS (Dh/16 mod 2) ===")
    for idx, (comb, u, bdata) in enumerate(w12_evals):
        v0, lin, quad = interpolate_deg2(lambda c: (eval_dh(c, bdata)[2] // 16) & 1)
        print(f"  w12[{idx}] u=0x{u:04x}: const={v0}, len(lin)={len(lin)}, len(quad)={len(quad)}")
        if idx == 0:
            print(f"    lin={lin}")
            print(f"    quad[:10]={quad[:10]}")

    # Joint survival on T34 core:
    surv_w10_b0 = sum(1 for i in range(N_SAMPLES) if all(v[5][i] == 0 for v in w10_vecs))
    surv_w10_b1 = sum(1 for i in range(N_SAMPLES, 2*N_SAMPLES) if all(v[5][i] == 0 for v in w10_vecs))
    surv_w12_16_b0 = sum(1 for i in range(N_SAMPLES) if all(v[4][i] == 0 for v in w12_vecs))
    surv_w12_16_b1 = sum(1 for i in range(N_SAMPLES, 2*N_SAMPLES) if all(v[4][i] == 0 for v in w12_vecs))
    surv_w12_32_b0 = sum(1 for i in range(N_SAMPLES) if all(v[4][i] == 0 and v[5][i] == 0 for v in w12_vecs))
    surv_w12_32_b1 = sum(1 for i in range(N_SAMPLES, 2*N_SAMPLES) if all(v[4][i] == 0 and v[5][i] == 0 for v in w12_vecs))
    surv_w12_128_b0 = sum(1 for i in range(N_SAMPLES) if all(v[4][i] == 0 and v[5][i] == 0 and v[6][i] == 0 for v in w12_vecs))
    surv_w12_128_b1 = sum(1 for i in range(N_SAMPLES, 2*N_SAMPLES) if all(v[4][i] == 0 and v[5][i] == 0 and v[6][i] == 0 for v in w12_vecs))
    surv_both_b0 = sum(1 for i in range(N_SAMPLES) if all(v[5][i] == 0 for v in w10_vecs) and all(v[4][i] == 0 and v[5][i] == 0 and v[6][i] == 0 for v in w12_vecs))
    surv_both_b1 = sum(1 for i in range(N_SAMPLES, 2*N_SAMPLES) if all(v[5][i] == 0 for v in w10_vecs) and all(v[4][i] == 0 and v[5][i] == 0 and v[6][i] == 0 for v in w12_vecs))

    print(f"\n=== JOINT SURVIVAL ON T34 CORE ({N_SAMPLES} B0 + {N_SAMPLES} B1) ===")
    print(f"  21 weight-10 (32 | Dh):         B0={surv_w10_b0}/{N_SAMPLES}, B1={surv_w10_b1}/{N_SAMPLES}")
    print(f"   7 weight-12 (32 | Dh, 1st bit): B0={surv_w12_16_b0}/{N_SAMPLES}, B1={surv_w12_16_b1}/{N_SAMPLES}")
    print(f"   7 weight-12 (64 | Dh, 2 bits):  B0={surv_w12_32_b0}/{N_SAMPLES}, B1={surv_w12_32_b1}/{N_SAMPLES}")
    print(f"   7 weight-12 (128 | Dh, 3 bits): B0={surv_w12_128_b0}/{N_SAMPLES}, B1={surv_w12_128_b1}/{N_SAMPLES}")
    print(f"  Combined weight-10 + weight-12:  B0={surv_both_b0}/{N_SAMPLES}, B1={surv_both_b1}/{N_SAMPLES}")

if __name__ == '__main__':
    main()
