"""Refine the top 16 unrefined character orbits of T44 at k=16 across all 3 charts (b=0 c57=0, b=0 c57=1, b=1) in parallel!"""
import json, sys, time, random, math
from pathlib import Path
from fractions import Fraction
from collections import Counter
from multiprocessing import Pool
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from rank_profile import direction_kernel, polar_rows, rank_low, restrict

top_orbits = [30, 27, 58, 10, 123, 3, 28, 25, 54, 51, 60, 12, 61, 13, 57, 9]

def rk_vecs(vs):
    B = {}
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in B: v ^= B[p]
            else: B[p] = v; break
    return len(B)

def compress_mat(mat, S):
    # Extract 64x64 principal submatrix on indices S (len(S) == 64)
    out = []
    for i in S:
        row = mat[i]
        c_row = 0
        for bit_idx, j in enumerate(S):
            if (row >> j) & 1:
                c_row |= (1 << bit_idx)
        out.append(c_row)
    return out

def solve_case(args):
    branch, c57, comb, P, free, k = args
    t0 = time.perf_counter()
    K = direction_kernel(P, free)
    rnd = random.Random(1000 * comb + 10 * branch + (c57 or 0))
    # Pick k random linearly independent directions in K (dense combinations avoid weight-2 low-rank artifacts!)
    dirs = []
    while len(dirs) < k:
        v = 0
        for b in K:
            if rnd.getrandbits(1):
                v ^= b
        if v and rk_vecs(dirs + [v]) > len(dirs):
            dirs.append(v)
    mats = [polar_rows(P, d, free) for d in dirs]
    n = len(free)
    deg = [sum(m[i].bit_count() for m in mats) for i in range(n)]
    S = sorted(sorted(range(n), key=lambda i: -deg[i])[:64])
    sub_mats = [compress_mat(m, S) for m in mats]

    cur = [0] * 64
    old = 0
    hist = Counter()
    for ordinal in range(1, 1 << k):
        gray = ordinal ^ (ordinal >> 1)
        ch = (gray ^ old).bit_length() - 1
        cur = [a ^ b for a, b in zip(cur, sub_mats[ch])]
        old = gray
        # Inline rank_low on 64-bit rows:
        B = {}
        for v in cur:
            while v:
                p = v & -v
                if p in B:
                    v ^= B[p]
                else:
                    B[p] = v
                    break
        r = len(B)
        hist[r] += 1
    sq = (1 + sum(Fraction(cnt, 1 << (r // 2)) for r, cnt in hist.items())) / Fraction(1 << k)
    # Exact rational upper bound on sqrt(sq): ceil(sqrt(sq) * 2^30) / 2^30
    denom = 1 << 30
    num = math.isqrt(sq.numerator * (1 << 60) // sq.denominator)
    while Fraction(num, denom) ** 2 < sq:
        num += 1
    beta = Fraction(num, denom)
    assert beta * beta >= sq
    return branch, c57, comb, min(hist), beta, time.perf_counter() - t0

if __name__ == '__main__':
    t_start = time.perf_counter()
    t40 = json.loads((base / 'T40_LIMITE_CERTIFICADO.json').read_text())
    t44 = json.loads((base / 'T44_LIMITE_CERTIFICADO.json').read_text())
    models = (
        json.loads((base / 'T35_POLINOMIOS_CERTIFICADO.json').read_text())['combined_models']
        + json.loads((base / 'T40_MODELOS_CERTIFICADO.json').read_text())['models']
    )

    k = 16
    tasks = []
    for branch in [0, 1]:
        supports = t40['branches'][branch]['supports']
        polys = [
            {int(m, 16) for m in next(r for r in models if r['branch'] == branch and r['support_mask'] == s)['polynomial_hex']}
            for s in supports
        ]
        free = sorted(set(range(116)) - {0, 5, 23, 57, 99, 113, 115})
        for comb in top_orbits:
            P = set()
            for j in range(7):
                if (comb >> j) & 1:
                    P ^= polys[j]
            if branch == 0:
                tasks.append((0, 0, comb, restrict(P, [57], 0), free, k))
                tasks.append((0, 1, comb, restrict(P, [57], 1), free, k))
            else:
                tasks.append((1, None, comb, P, free, k))

    print(f"Launching {len(tasks)} cases at k={k} across 12 CPU cores...", flush=True)
    results = {}
    with Pool(12) as pool:
        for done, (branch, c57, comb, min_r, beta, dt) in enumerate(pool.imap_unordered(solve_case, tasks), 1):
            results[(branch, c57, comb)] = (min_r, beta)
            if done % 8 == 0 or done == len(tasks):
                print(f"  Completed {done}/{len(tasks)} cases (elapsed {time.perf_counter()-t_start:.1f}s) - last: br={branch} c57={c57} comb={comb} min_r={min_r} beta={float(beta):.6f}", flush=True)

    # Save refined amplitudes and compute new global 13-cond and 14-cond (+0x7f7f) bounds!
    refined_amps = {0: {}, 1: {}}
    for comb in top_orbits:
        b0_0 = results[(0, 0, comb)][1]
        b0_1 = results[(0, 1, comb)][1]
        refined_amps[0][comb] = (b0_0 + b0_1) / 2
        refined_amps[1][comb] = results[(1, None, comb)][1]

    out_data = {
        'k': k,
        'orbits_refined': top_orbits,
        'branch0_amplitudes': {str(c): [refined_amps[0][c].numerator, refined_amps[0][c].denominator] for c in top_orbits},
        'branch1_amplitudes': {str(c): [refined_amps[1][c].numerator, refined_amps[1][c].denominator] for c in top_orbits},
    }
    (base / 'T45B_TOP16_REFINEMENT.json').write_text(json.dumps(out_data, indent=2))
    print(f"Saved T45B_TOP16_REFINEMENT.json in {time.perf_counter()-t_start:.2f}s!")
