# T47–T49: Teoria Estrutural Antípoda–Periódica, Limite Certificado de 14 Condições e Conjectura Geral para $H(2m, 4)$

## 1. Resumo Executivo

Este documento consolida os avanços teóricos e computacionais posteriores a `T40–T46`:
1. **Forma Normal Exata de 14 Paridades de `0x7f7f` (1º bit) e Núcleo de 7 Condições (`T34 + 0x7f7f`):** A condição necessária de bentness $P_{\text{0x7f7f}}(c) = \frac{h_f(\text{0x7f7f})}{16} \pmod 2 = 0$ reduz-se, no espaço das 2 leis lineares ($c_{115}=0, c_{113}=c_{57}$), a um polinômio quadrático de 1.984 monômios fatorável exatamente em 14 paridades disjuntas (`verify_14parity_normal_form.py`). A medida exata do núcleo cai de $\frac{3}{128} = \frac{24}{1024}$ para **$\frac{13}{1024}$** ($\frac{9}{1024}$ no Ramo 0 e $\frac{1}{256}$ no Ramo 1), reduzindo o piso assintótico em **$45{,}83\%$**.
2. **Teorema de Invariância Bilinear e Novo Limite Certificado Global (`T44 + Top26 + 0x7f7f`):** Como a restrição de $P_{\text{0x7f7f}}$ ao núcleo tem grau $\le 2$ (fixando $c_{57} \in \{0,1\}$ no Ramo 0), sua segunda derivada direcional é identicamente nula: $B_{P_\lambda \oplus R_{\text{0x7f7f}}}(d) \equiv B_{P_\lambda}(d)$. Combinado com o refinamento em $k=16$ direções para 26 órbitas (`T45B_TOP16_REFINEMENT.json`), obtemos a nova cota global certificada de 14 condições:
   $$\Pr_{f \in H(16,4)}(f \text{ é bent}) \le \frac{3469169466878495}{2^{64}} \approx 1{,}880641 \times 10^{-4} \quad (\ge 99{,}9811935946\% \text{ excluído}).$$
3. **Teoria Geral do Colapso Diagonal Antípoda e Dualidade Rotacional em $H(2m, 4)$:** Demonstramos que sobre a diagonal antípoda $\Delta_m = \{x_{i+m} = x_i\} \cong \mathbb{F}_2^m$, todas as $\dim H(2m,4) - \lfloor m/2 \rfloor$ órbitas não-antípodas se anulam identicamente, restando apenas $\lfloor m/2 \rfloor$ formas quadráticas rotacionalmente simétricas. Pela dualidade rotacional ($f^*$ também é rotacionalmente simétrica), derivamos a hierarquia de diferenças antípodas $\Delta_r h_f(u; w_0) = S_{00}(u; w_0) - S_{11}(u; r, w_0) = h_f(u \cup \{r, r+m\}; (w_0, w_0) \oplus e_r) \equiv 0 \pmod{2^{|u|-m+3}}$.
4. **Teorema das 388 Condições Cúbicas Puras Livres de Carry e das 26 Sizígias Quadráticas Diretas em $U_{38}$:** Demonstramos que os 273 suportes cíclicos de peso 11 e os 112 suportes não-periódicos de peso 12 geram 385 equações cúbicas puras livres de carry $C_3(v) \equiv 0 \pmod 2$ que, somadas às 3 órbitas periódicas de peso 12, possuem posto $\mathbb{F}_2$ máximo $388/388$ no núcleo `T34`. Além disso, existe um subespaço invariante de dimensão 38, $U_{38} \subset U_{43}$, sobre o qual 26 sizígias linearmente independentes têm grau $\le 2$ diretamente (sem Cauchy–Schwarz), com matrizes bilineares $38 \times 38$ independentes de $c_{23}, c_{31}, c_{39}, c_{57}, c_{112}$ e posto até 30.
5. **Conjectura Geral da Torre Periódico–Antípoda para $H(2m, 4)$ ($2m \ge 8$):** Verificada exaustivamente para $H(8,4)$ (`0 / 1.024`) e $H(10,4)$ (`0 / 4.194.304`).

---

## 2. Demonstração dos Cinco Teoremas Estruturais

### Teorema 1 (Colapso Diagonal Antípoda Universal em $H(2m, 4)$)
Seja $\tau_m(x)_i = x_{i+m \bmod 2m}$ e $\Delta_m = \{x \in \mathbb{F}_2^{2m} : \tau_m(x) = x\} = \{(x_0, x_0) : x_0 \in \mathbb{F}_2^m\}$.
Para cada órbita cíclica $\mathcal{O} \subset \binom{\mathbb{Z}_{2m}}{4}$ de monômios de grau 4:
- Se $\mathcal{O}$ não é composta por conjuntos $\tau_m$-invariantes, a involução $\tau_m$ particiona $\mathcal{O}$ em pares disjuntos $\{S, \tau_m(S)\}$. Sobre $\Delta_m$, $x_{i+m} = x_i$ implica $\prod_{i \in S} x_i = \prod_{i \in \tau_m(S)} x_i$, logo $\prod_{i \in S} x_i \oplus \prod_{i \in \tau_m(S)} x_i = 0$ identicamente sobre $\Delta_m$.
- Um conjunto $S \in \binom{\mathbb{Z}_{2m}}{4}$ é $\tau_m$-invariante ($\tau_m(S) = S$) se e somente se é união de dois pares antípodas $\{i, i+m\} \cup \{j, j+m\}$. Tais conjuntos formam exatamente $\lfloor m/2 \rfloor$ órbitas cíclicas $O_d$ ($1 \le d \le \lfloor m/2 \rfloor$). Sobre $\Delta_m$, como $x_i x_{i+m} = x_i^2 = x_i$, cada $O_d$ restringe-se à forma quadrática rotacionalmente simétrica $Q_{m,d}(x_0) = \sum_{i=0}^{m-1} x_{0,i} x_{0,i+d \bmod m}$ (com metade dos termos quando $d = m/2$). $\blacksquare$

---

### Teorema 2 (Dualidade Rotacional e Hierarquia de Diferenças Antípodas)
Seja $f \in H(2m, 4)$ uma função bent com dual $f^*$, de modo que $W_f(z) = 2^m(1 - 2f^*(z))$. Pela invariância de $f$ sob rotação cíclica $\rho$, $W_f(\rho(z)) = W_f(z)$, logo $f^*(\rho(z)) = f^*(z)$ (e em particular $f^* \circ \tau_m = f^*$).
Pela fórmula de somação de Poisson no subespaço $C_u = \{x \in \mathbb{F}_2^{2m} : x_i = 0 \;\forall i \notin u\}$ ($|u| \ge m$), para todo deslocamento de frequência $w \in \mathbb{F}_2^{2m}$:
$$h_f(u; w) := \sum_{x \preceq u} (-1)^{f(x) \oplus w\cdot x} = 2^{|u|-2m} \sum_{z \in w + C_u^\perp} W_f(z) = 2^{|u|} - 2^{|u|-m+1}\,\text{wt}\!\left(f^*|_{w + C_u^\perp}\right) \equiv 0 \pmod{2^{|u|-m+1}}.$$
Se $u \subseteq 1^{2m} \setminus \{r, r+m\}$ é $\tau_m$-invariante e $w = (w_0, w_0) \oplus e_r$, então no subcubo $u^+ = u \cup \{r, r+m\}$ de peso $|u|+2$:
$$h_f(u \cup \{r, r+m\}; (w_0, w_0) \oplus e_r) = S_{00}(u; w_0) - S_{10}(u; w_0) + S_{01}(u; w_0) - S_{11}(u; r, w_0) = S_{00}(u; w_0) - S_{11}(u; r, w_0) =: \Delta_r h_f(u; w_0),$$
pois $\tau_m$ troca os cosets $(y_r, y_{r+m}) = (1,0)$ e $(0,1)$, garantindo $S_{10}(u; w_0) = S_{01}(u; w_0)$. Logo:
$$\Delta_r h_f(u; w_0) = 2^{|u|+2} - 2^{|u|-m+3}\,\text{wt}\!\left(f^*|_{(w_0,w_0)\oplus e_r + C_{u^+}^\perp}\right) \equiv 0 \pmod{2^{|u|-m+3}}. \quad \blacksquare$$

---

### Teorema 3 (Congruência Universal das 128 Frequências de Defeito Antípoda 1 em $H(16,4)$)
Para $u = \text{0x7f7f} = 1^{16} \setminus \{7, 15\}$ ($|u| = 14$) e qualquer $w_0 \in \mathbb{F}_2^7$, a frequência $w(w_0) = (w_0, w_0) \oplus e_{15}$ satisfaz:
1. $W_f(w(w_0)) = S_{00}(w_0) - S_{11}(w_0)$ (pelo Teorema 2 com $u = \text{0x7f7f}$ e $u^+ = 1^{16}$).
2. Sobre a diagonal $\Delta_8 \cap C_{\text{0x7f7f}} \cong \mathbb{F}_2^7$, $(w_0, w_0) \cdot (x_0, x_0) = 2(w_0 \cdot x_0) \equiv 0 \pmod 2$, logo a contribuição diagonal independe de $w_0$, e sob as 2 leis lineares ($c_{115}=0, c_{113}=c_{57}$) a diferença antípoda diagonal $\Delta f(x_0, x_0) = c_{115} = 0$ anula-se identicamente, fazendo com que a diagonal contribua $0$ para $S_{00}(w_0) - S_{11}(w_0)$.
3. Fora da diagonal, os $16.384 - 128 = 16.256$ pontos agrupam-se em $8.128$ pares sob $\tau_8$. A diferença entre $W_f(w(w_0))$ e $W_f(e_{15})$ provém dos termos divisíveis por $L_{w_0}(x) = (w_0, w_0) \cdot x$ (grau 1 em $x$). Como $\deg_x(f_{00}) = 4$ e $\deg_x(\Delta f) \le 3$, qualquer produto $L_{w_0} f_{00}^a (\Delta f)^b$ com $a + b \le 3$ e $b \ge 1$ tem grau em $x$ no máximo $1 + 4(2) + 3(1) = 12 < 14$, cuja soma sobre $\mathbb{F}_2^{14}$ se anula nos termos de ordem $\le 3$, garantindo $64 \mid (W_f(w(w_0)) - W_f(e_{15}))$. $\blacksquare$

---

### Teorema 4 (Sistema de 388 Condições Cúbicas Puras Livres de Carry em $H(16,4)$)
Para qualquer suporte $v \subset \{0,\dots,15\}$ de peso $|v| \in \{11, 12\}$, a expansão inteira $h_f(v) = \sum_{k \ge 0} (-2)^k \sum_{M_1 < \dots < M_k \subseteq v} 2^{|v| - |M_1 \cup \dots \cup M_k|}$ satisfaz:
- Para $k = 0, 1$: $2^{|v|} \equiv 0 \pmod{16}$ e $-2 \cdot 2^{|v|-4} \equiv 0 \pmod{16}$.
- Para $k = 2$: como $|M_1 \cup M_2| \le 8$, $4 \cdot 2^{|v| - |M_1 \cup M_2|} \ge 4 \cdot 2^{|v|-8} \ge 32 \equiv 0 \pmod{16}$ para todo $|v| \ge 11$.
- Para $k \ge 4$: $(-2)^k \equiv 0 \pmod{16}$.
- Para $k = 3$: $(-8) \cdot 2^{|v| - |M_1 \cup M_2 \cup M_3|} \equiv 8 \pmod{16} \iff M_1 \cup M_2 \cup M_3 = v$.
Logo, $8 \mid h_f(v)$ vale identicamente em $H(16,4)$, e o coeficiente de $2^3 = 8$ módulo 2 é o polinômio cúbico puro livre de carry:
$$b_2[v](c) = \frac{h_f(v)}{8} \pmod 2 = C_3(v) \bmod 2 = \bigoplus_{\substack{\{M_1, M_2, M_3\} \\ M_1 \cup M_2 \cup M_3 = v}} c_{\text{orb}(M_1)} c_{\text{orb}(M_2)} c_{\text{orb}(M_3)} = \bigoplus_{\substack{u \subseteq v \\ 4 \le |u| \le |v|}} \left(\binom{N_f(u)}{3} \bmod 2\right).$$
Pelo teorema de Zhang–Gao, bentness exige $2^{|v|-7} \mid h_f(v)$, logo $b_2[v](c) = 0$ para todas as **273 órbitas de peso 11** e **116 órbitas de peso 12** (das quais 112 são não-periódicas e linearmente independentes no núcleo `T34`, enquanto as 4 periódicas anulam $b_2$ no núcleo `T34` e fornecem 3 condições cúbicas independentes em $b_3[w] = \frac{h_f(w)}{16} \pmod 2$). O posto $\mathbb{F}_2$ conjunto dessas $273 + 112 + 3 = 388$ condições de grau 3 no núcleo `T34` é **$388 / 388$**. $\blacksquare$

---

### Teorema 5 (As 26 Sizígias Quadráticas Diretas em $U_{38}$ sem Cauchy–Schwarz)
Seja $U_{43}$ o subespaço das 43 variáveis fora de $q_{\text{vars}}$ (disjunto de $u_1,\dots,v_4$ e de $\{0,5,23,31,39,57,99,112,113,115\}$), e seja $U_{38} \subset U_{43}$ o núcleo de dimensão 38 das 5 formas lineares $(R, R_2 \oplus R_3, \alpha_1, \alpha_2, \alpha_3)$.
1. Como nenhuma variável de $U_{38}$ altera as paridades $(R, R_2 \oplus R_3, \alpha_1, \alpha_2, \alpha_3)$ nem participa de $L, M, K$ ou dos produtos quadráticos de $c_{23}$, o núcleo de 7 condições $\mathcal{C}_7 = \{\text{T34} \wedge P_{\text{0x7f7f}}=0\}$ é invariante por translação por $U_{38}$ ($\mathcal{C}_7 + U_{38} = \mathcal{C}_7$).
2. Entre as 385 condições cúbicas puras $b_2[v]$ de pesos 11 e 12, o subespaço das combinações lineares cujas derivadas de 3ª ordem em $U_{38} \times U_{38} \times U_{38}$ se anulam identicamente tem dimensão **26** ($7$ de peso 11 e $19$ de peso 12).
3. Para cada uma dessas 26 condições $Q_r(q + u)$ ($u \in U_{38}$), $\deg_u(Q_r) \le 2$ e $\deg_{\text{total}}(Q_r) \le 3$, logo a matriz bilinear alternada $38 \times 38$ $B_r^{(38)}(q)_{i,j} = D_{u_i, u_j}^{(2)} Q_r(q + u)$ é afim-linear em $q$, tem derivada nula em relação a $c_{23}, c_{31}, c_{39}, c_{57}, c_{112}$, e limita diretamente o viés no coset $q + U_{38}$ por $2^{-\text{rank}(B_\lambda^{(38)}(q))/2}$ sem usar Cauchy–Schwarz. $\blacksquare$

---

## 3. Enunciado Formal da Conjectura Geral para $H(2m, 4)$ ($2m \ge 8$)

- **Conjectura Geral A (Inexistência Global):** Para todo inteiro par $2m \ge 8$, não existem funções booleanas bent em $H(2m, 4)$.
- **Conjectura Geral B (Obstrução da Torre Periódico–Antípoda de Defeito $\le 1$):** Para todo $m \ge 4$, o subsistema finito formado por:
  1. $W_f(w_0, w_0) = \pm 2^m$ ($\forall w_0 \in \mathbb{F}_2^m / \mathbb{Z}_m$),
  2. $W_f((w_0, w_0) \oplus e_{m-1}) = S_{00}(w_0) - S_{11}(w_0) = \pm 2^m$ ($\forall w_0 \in \mathbb{F}_2^{m-1}$), e
  3. As congruências de subcubos de defeito $\le 1$, $\Delta_{m-1} h_f(u) \equiv 0 \pmod{2^{|u|-m+3}}$ e $C_3(v) \equiv 0 \pmod 2$ ($|v| \in \{m+3, m+4\}$),
  não possui solução em $H(2m, 4)$ (provado exaustivamente para $2m=8$ e $2m=10$ em `verify_general_conjecture_small_n.py`).
