"""Refine the remaining 9 orbits with amp >= 0.0078 ([1, 5, 7, 49, 52, 53, 120, 121, 125] + 24) at k=16 across all 3 charts!"""
import json, sys, time
from pathlib import Path
from fractions import Fraction
from multiprocessing import Pool
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from refine_t44_top16 import solve_case, restrict

next_orbits = [1, 5, 7, 49, 52, 53, 120, 121, 125, 24]

if __name__ == '__main__':
    t_start = time.perf_counter()
    t40 = json.loads((base / 'T40_LIMITE_CERTIFICADO.json').read_text())
    models = (
        json.loads((base / 'T35_POLINOMIOS_CERTIFICADO.json').read_text())['combined_models']
        + json.loads((base / 'T40_MODELOS_CERTIFICADO.json').read_text())['models']
    )
    existing = json.loads((base / 'T45B_TOP16_REFINEMENT.json').read_text())

    k = 16
    tasks = []
    for branch in [0, 1]:
        supports = t40['branches'][branch]['supports']
        polys = [
            {int(m, 16) for m in next(r for r in models if r['branch'] == branch and r['support_mask'] == s)['polynomial_hex']}
            for s in supports
        ]
        free = sorted(set(range(116)) - {0, 5, 23, 57, 99, 113, 115})
        for comb in next_orbits:
            if branch == 1 and comb == 120:
                continue # comb=120 on branch 1 already has amp=0 in T40!
            P = set()
            for j in range(7):
                if (comb >> j) & 1:
                    P ^= polys[j]
            if branch == 0:
                tasks.append((0, 0, comb, restrict(P, [57], 0), free, k))
                tasks.append((0, 1, comb, restrict(P, [57], 1), free, k))
            else:
                tasks.append((1, None, comb, P, free, k))

    print(f"Launching {len(tasks)} cases at k={k} across 12 CPU cores...", flush=True)
    results = {}
    with Pool(12) as pool:
        for done, (branch, c57, comb, min_r, beta, dt) in enumerate(pool.imap_unordered(solve_case, tasks), 1):
            results[(branch, c57, comb)] = (min_r, beta)
            if done % 7 == 0 or done == len(tasks):
                print(f"  Completed {done}/{len(tasks)} cases (elapsed {time.perf_counter()-t_start:.1f}s) - last: br={branch} c57={c57} comb={comb} min_r={min_r} beta={float(beta):.6f}", flush=True)

    for comb in next_orbits:
        b0 = (results[(0, 0, comb)][1] + results[(0, 1, comb)][1]) / 2
        existing['branch0_amplitudes'][str(comb)] = [b0.numerator, b0.denominator]
        if (1, None, comb) in results:
            b1 = results[(1, None, comb)][1]
            existing['branch1_amplitudes'][str(comb)] = [b1.numerator, b1.denominator]
        if comb not in existing['orbits_refined']:
            existing['orbits_refined'].append(comb)

    (base / 'T45B_TOP16_REFINEMENT.json').write_text(json.dumps(existing, indent=2))
    print(f"Updated T45B_TOP16_REFINEMENT.json (now {len(existing['orbits_refined'])} orbits) in {time.perf_counter()-t_start:.2f}s!")
