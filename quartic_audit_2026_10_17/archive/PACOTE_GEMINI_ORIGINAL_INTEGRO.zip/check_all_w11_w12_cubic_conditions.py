"""Test all 273 cyclic orbits of weight-11 supports (where bentness requires 16 | h_f(v),
so the pure cubic C_3(v) = (h_f(v) // 8) mod 2 = 0) and all 116 cyclic orbits of weight-12
supports on the T34 core!"""
import json, sys, time, random, math
from pathlib import Path
from itertools import combinations

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))

def rot(m, k=1):
    return ((m << k) | (m >> (16 - k))) & 0xFFFF

def build_orbits(k_weight):
    ORB = []; index = {}; reps = []
    for t in combinations(range(16), k_weight):
        m = sum(1 << j for j in t)
        if m in index: continue
        orb = set(); r = m
        for _ in range(16): orb.add(r); r = rot(r, 1)
        for r in orb: index[r] = len(ORB)
        ORB.append(orb)
        reps.append(m)
    return ORB, reps

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)
    print(f"Built {len(orbits4)} weight-4 orbits, {len(reps11)} weight-11 orbits, {len(reps12)} weight-12 orbits in {time.perf_counter()-t0:.2f}s")

    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    rng = random.Random(20261017)
    def sample_t34(branch):
        free = sorted(set(range(116)) - {0, 99, 113, 115} - ({57} if branch else set()))
        c = rng.getrandbits(116) & sum(1 << j for j in free if j not in [23, 5])
        if branch:
            c |= 1 << 99
            c |= parity(c, seven['K']) << 57
        c |= (branch ^ parity(c, seven['L'])) << 0
        c |= ((c >> 57) & 1) << 113
        a = (c >> 57) & 1
        c |= (a ^ parity(c, [31, 39, 112]) ^ sum(parity(c, p['I']) * parity(c, p['J']) for p in factor['products']) % 2) << 23
        c |= (parity(c, seven['R']) ^ ((1 ^ branch) & parity(c, seven['M'])) ^ ((1 ^ a) & parity(c, seven['K']))) << 5
        return c

    # Wait: we can evaluate f(x) for ALL x in 0..65535 for 512 T34 core samples simultaneously using 512-bit integers!
    # Look how fast that is: 65,536 points, and for each x in 0..65535 we precompute the 116-bit mask of which orbits are active at x!
    # Wait: even better, for 512 samples c_0, ..., c_{511}, we can compute for each orbit j the 512-bit integer C_j,
    # and for each x in 0..65535 xor C_j for the active orbits at x!
    # Even simpler: each orbit j has <= 16 monomials m. A monomial m is active at x iff (x & m) == m (a subcube of size 2^{12} = 4096)!
    # Better yet: Fast Mobius Transform (ANF -> truth table) in 16 variables on 512-bit integers!
    # Let's do a 16-variable Fast Mobius Transform (FMT) on 512-bit integers!
    # In 16 variables, FMT takes 16 * 65536 = 1,048,576 XORs of 512-bit integers (~0.08 seconds in Python)!
    # AND THEN a Second Fast Mobius Transform (subset sum over subcubes) in 16 variables on integers? No, for truth table -> subcube sums, we want integer sums, OR we just sum over x <= v!
    N_B0 = 300
    N_B1 = 300
    N_TOT = N_B0 + N_B1
    samples = [sample_t34(0) for _ in range(N_B0)] + [sample_t34(1) for _ in range(N_B1)]

    # Pack samples by orbit j: C_orb[j] is an N_TOT-bit integer
    C_orb = [0] * 116
    for s_idx, c in enumerate(samples):
        for j in range(116):
            if (c >> j) & 1:
                C_orb[j] |= (1 << s_idx)

    # Initialize ANF array of size 65536 with N_TOT-bit integers
    anf = [0] * 65536
    for j, orb in enumerate(orbits4):
        cj = C_orb[j]
        if cj:
            for m in orb:
                anf[m] = cj

    # Fast Mobius Transform (ANF -> Truth Table TT[x] for all x in 0..65535):
    tt = anf[:]
    for bit in range(16):
        step = 1 << bit
        for i in range(0, 65536, step << 1):
            for j in range(i, i + step):
                tt[j + step] ^= tt[j]

    print(f"Computed full 65,536 truth tables for {N_TOT} T34 core samples in {time.perf_counter()-t0:.2f}s!")

    # Wait: how do we compute h_f(v) mod 16 or mod 32 for ALL 65,536 supports v and ALL 600 samples simultaneously?!
    # By bitwise ZETA TRANSFORM with 5-bit vertical counters!!
    # HOLD ON!
    # For each x in 0..65535, tt[x] is an N_TOT-bit integer (1 if f(x)=1, 0 if f(x)=0).
    # The Hamming weight wt(f|_{<= v}) = sum_{x <= v} f(x) mod 16 ONLY needs a 4-bit counter (b0, b1, b2, b3) of N_TOT-bit integers at each of the 65,536 nodes!
    # Wait: h_f(v) = 2^{|v|} - 2 * wt(f|_{<= v})!
    # So:
    #   (h_f(v) // 8) mod 2  ==  (wt(f|_{<= v}) // 4) mod 2  ==  bit b2 of wt(f|_{<= v})!!
    #   (h_f(v) // 16) mod 2 ==  (wt(f|_{<= v}) // 8) mod 2  ==  bit b3 of wt(f|_{<= v})!!
    # AND a 4-bit ripple-carry adder across 16 Zeta-transform steps on 65,536 nodes takes:
    # 16 * 32768 * (10 bitwise ops on 600-bit ints) = ~0.3 seconds in Python for ALL 65,536 SUPPORTS SIMULTANEOUSLY!!
    t1 = time.perf_counter()
    b0 = tt[:]
    b1 = [0] * 65536
    b2 = [0] * 65536
    b3 = [0] * 65536
    b4 = [0] * 65536

    for bit in range(16):
        step = 1 << bit
        for i in range(0, 65536, step << 1):
            for j in range(i, i + step):
                k = j + step
                # Add (b4[j], b3[j], b2[j], b1[j], b0[j]) into k
                x0, y0 = b0[k], b0[j]
                b0[k] = x0 ^ y0
                c1 = x0 & y0

                x1, y1 = b1[k], b1[j]
                s1 = x1 ^ y1
                b1[k] = s1 ^ c1
                c2 = (x1 & y1) | (s1 & c1)

                x2, y2 = b2[k], b2[j]
                s2 = x2 ^ y2
                b2[k] = s2 ^ c2
                c3 = (x2 & y2) | (s2 & c2)

                x3, y3 = b3[k], b3[j]
                s3 = x3 ^ y3
                b3[k] = s3 ^ c3
                c4 = (x3 & y3) | (s3 & c3)

                b4[k] ^= b4[j] ^ c4

    print(f"Computed exact subcube sums mod 64 for ALL 65,536 supports x {N_TOT} samples in {time.perf_counter()-t1:.2f}s!!")

    # Check weight-11 orbits:
    # Since h_f(v) = 2^11 - 2 * wt(v) = 2048 - 2 * wt(v):
    #   2 | h_f(v) always
    #   4 | h_f(v) iff b0[v] == 0
    #   8 | h_f(v) iff b0[v] == 0 and b1[v] == 0
    #  16 | h_f(v) iff b0[v] == 0, b1[v] == 0, and b2[v] == 0!
    w11_b0_nonzero = sum(1 for v in reps11 if b0[v] != 0)
    w11_b1_nonzero = sum(1 for v in reps11 if b1[v] != 0)
    w11_b2_nonzero = sum(1 for v in reps11 if b2[v] != 0)
    print(f"\n=== WEIGHT-11 ORBITS (273 total) ON T34 CORE ({N_TOT} samples) ===")
    print(f"  Orbits with b0 != 0 (4 not div h_f):  {w11_b0_nonzero} / 273")
    print(f"  Orbits with b1 != 0 (8 not div h_f):  {w11_b1_nonzero} / 273")
    print(f"  Orbits with b2 != 0 (16 not div h_f): {w11_b2_nonzero} / 273")

    # Compute GF(2) rank of b2[v] across the 273 weight-11 orbits!
    basis11 = []
    indep11 = []
    for idx, v in enumerate(reps11):
        row = b2[v]
        for b in basis11:
            lsb = (b & -b).bit_length() - 1
            if (row >> lsb) & 1:
                row ^= b
        if row != 0:
            basis11.append(row)
            indep11.append((idx, v))
    print(f"  GF(2) rank of pure cubic conditions b2[v] = (h_f(v)//8 mod 2) on T34 core: {len(basis11)} / 273!!")

    # Check weight-12 orbits:
    # h_f(w) = 4096 - 2 * wt(w):
    #   8 | h_f(w) iff b0[w] == b1[w] == 0
    #  16 | h_f(w) iff b2[w] == 0
    #  32 | h_f(w) iff b2[w] == 0 and b3[w] == 0!
    w12_b2_nonzero = sum(1 for w in reps12 if b2[w] != 0)
    w12_b2_zero_orbits = [w for w in reps12 if b2[w] == 0]
    print(f"\n=== WEIGHT-12 ORBITS (116 total) ON T34 CORE ({N_TOT} samples) ===")
    print(f"  Orbits with b2 == 0 identically on T34 core (16 | h_f(w)): {len(w12_b2_zero_orbits)} / 116")
    print(f"  Orbits with b2 != 0 on T34 core (8-bit active!):           {w12_b2_nonzero} / 116")

    # Wait: for the weight-12 orbits where b2 != 0 on T34 core, b2[w] = (h_f(w)//8 mod 2) = C_3(w) mod 2 MUST ALSO VANISH FOR EVERY BENT FUNCTION!!
    basis12_b2 = []
    for w in reps12:
        row = b2[w]
        for b in basis12_b2:
            lsb = (b & -b).bit_length() - 1
            if (row >> lsb) & 1:
                row ^= b
        if row != 0:
            basis12_b2.append(row)
    print(f"  GF(2) rank of weight-12 8-bit conditions b2[w] = (h_f(w)//8 mod 2) on T34 core: {len(basis12_b2)} / 116!!")

    # And for the weight-12 orbits where b2 == 0 on T34 core, b3[w] = (h_f(w)//16 mod 2) must vanish!
    basis12_b3 = []
    for w in w12_b2_zero_orbits:
        row = b3[w]
        for b in basis12_b3:
            lsb = (b & -b).bit_length() - 1
            if (row >> lsb) & 1:
                row ^= b
        if row != 0:
            basis12_b3.append(row)
    print(f"  GF(2) rank of weight-12 16-bit conditions b3[w] (where 16|h_f on core): {len(basis12_b3)} / {len(w12_b2_zero_orbits)}!!")

    # Check weight-13 orbits (273 total, where 64 | h_f(u) so b2 == b3 == b4 == 0!):
    _, reps13 = build_orbits(13)
    w13_b2_zero = [u for u in reps13 if b2[u] == 0]
    w13_b3_zero = [u for u in reps13 if b2[u] == 0 and b3[u] == 0]
    print(f"\n=== WEIGHT-13 ORBITS (273 total) ON T34 CORE ===")
    print(f"  Orbits with b2 == 0 (16 | h_f): {len(w13_b2_zero)} / 273")
    print(f"  Orbits with b2 == b3 == 0 (32 | h_f): {len(w13_b3_zero)} / 273")

    # Joint survival across all 600 T34 core samples:
    alive_w11 = (1 << N_TOT) - 1
    for v in reps11:
        alive_w11 &= ~b2[v]
    alive_w12 = (1 << N_TOT) - 1
    for w in reps12:
        alive_w12 &= ~(b2[w] | b3[w])
    print(f"\n=== SURVIVAL ON {N_TOT} T34 CORE SAMPLES ===")
    print(f"  Survivors of 273 weight-11 pure cubic conditions (b2==0): {alive_w11.bit_count()} / {N_TOT}")
    print(f"  Survivors of 116 weight-12 conditions (b2==b3==0):        {alive_w12.bit_count()} / {N_TOT}")

if __name__ == '__main__':
    main()
