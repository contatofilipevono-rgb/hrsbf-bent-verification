"""Check all 68 variables of q_free to see EXACTLY which q-variables appear in B_r(q)
for the 26 quadratic-in-U_43 syzygies!"""
import json, sys, time, random
from pathlib import Path

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from check_joint_cubic_rank_and_syzygies import build_orbits, compute_zeta_bits
from inspect_26_quadratic_in_U_conditions import find_nullspace, mat_rank_gf2

def main():
    t0 = time.perf_counter()
    orbits4, _ = build_orbits(4)
    _, reps11 = build_orbits(11)
    _, reps12 = build_orbits(12)

    old = json.loads((base / 'T28_SEXTA_CERTIFICADO.json').read_text())
    seven = json.loads((base / 'T31_SETIMA_CERTIFICADO.json').read_text())
    factor = old['fourth_factorization']

    q_vars = set([0, 5, 23, 57, 99, 113, 115, 31, 39, 112])
    q_vars.update(seven['K'])
    for p in factor['products']:
        q_vars.update(p['I'])
        q_vars.update(p['J'])
    U_vars = sorted(set(range(116)) - q_vars)

    def parity(c, indices):
        return sum((c >> j) & 1 for j in indices) % 2

    U_basis = []
    for j in U_vars:
        c = 1 << j
        c |= parity(c, seven['L']) << 0
        c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ parity(c, seven['K'])) << 5
        U_basis.append(c)

    q_free = sorted(q_vars - {0, 5, 99, 113, 115})

    def make_q_vec(a):
        c = 1 << a
        if a == 57:
            c |= (1 << 113)
        c |= parity(c, seven['L']) << 0
        c |= (parity(c, seven['R']) ^ parity(c, seven['M']) ^ parity(c, seven['K'])) << 5
        return c

    rng = random.Random(20261017)
    def rand_U_lin():
        c = 0
        for u_vec in U_basis:
            if rng.randint(0, 1):
                c ^= u_vec
        return c

    # Instead of evaluating all 903 pairs (u_i, u_j) for each of the 68 q_a (which would be 68*903 = 61,404 points),
    # test 60 random pairs (u_i, u_j) across all 68 q_a -> only 68 * 60 * 4 = 16,320 points (or 68 * 200 = 13,600 pts)!
    # Even better: for each q_a (68 vectors), we want D_{q_a, d1, d2}^{(3)} Q_r on 50 random pairs (d1, d2) in U_43!
    N_PAIRS = 40
    pairs_U = [(rand_U_lin(), rand_U_lin()) for _ in range(N_PAIRS)]

    # First find the 26 syzygies
    pts_c = []
    for _ in range(600):
        d1, d2, d3 = rand_U_lin(), rand_U_lin(), rand_U_lin()
        for mask in range(1, 8):
            pt = 0
            if mask & 1: pt ^= d1
            if mask & 2: pt ^= d2
            if mask & 4: pt ^= d3
            pts_c.append(pt)
    _, _, b2, _, _ = compute_zeta_bits(pts_c, orbits4)
    def compress_3diff(val_int, n_c=600):
        res = 0
        for t in range(n_c):
            chunk = (val_int >> (7 * t)) & 0x7F
            if chunk.bit_count() & 1:
                res |= (1 << t)
        return res

    per_w12 = [0x3f3f, 0x5f5f, 0x6f6f, 0x7777]
    nonper_reps12 = [w for w in reps12 if w not in per_w12]
    rows_w11 = [compress_3diff(b2[v]) for v in reps11]
    rows_w12 = [compress_3diff(b2[w]) for w in nonper_reps12]
    null_all = find_nullspace(rows_w11 + rows_w12)
    all_cubic_reps = reps11 + nonper_reps12
    print(f"Found {len(null_all)} syzygies in {time.perf_counter()-t0:.2f}s")

    # Now test all 68 q_a in batches of 17 (17 * 40 * 7 = 4,760 pts per batch)
    zero_q_vars = []
    nonzero_q_vars = []
    for batch_start in range(0, len(q_free), 17):
        batch = q_free[batch_start:batch_start + 17]
        pts_q = []
        for a in batch:
            qa = make_q_vec(a)
            for d1, d2 in pairs_U:
                for mask in range(1, 8):
                    pt = 0
                    if mask & 1: pt ^= qa
                    if mask & 2: pt ^= d1
                    if mask & 4: pt ^= d2
                    pts_q.append(pt)
        _, _, qb2, _, _ = compute_zeta_bits(pts_q, orbits4)
        all_qb2 = [qb2[v] for v in all_cubic_reps]
        for a_idx, a in enumerate(batch):
            any_nz = False
            for m in null_all:
                val_vec = 0
                for bit_i in range(len(all_qb2)):
                    if (m >> bit_i) & 1:
                        val_vec ^= all_qb2[bit_i]
                for p_i in range(N_PAIRS):
                    chunk = (val_vec >> (7 * (a_idx * N_PAIRS + p_i))) & 0x7F
                    if chunk.bit_count() & 1:
                        any_nz = True
                        break
                if any_nz:
                    break
            if any_nz:
                nonzero_q_vars.append(a)
            else:
                zero_q_vars.append(a)

    print(f"\nq_free variables with D_{{q_a}} B_r == 0 for ALL 26 syzygies ({len(zero_q_vars)}/{len(q_free)}): {zero_q_vars}")
    print(f"q_free variables with D_{{q_a}} B_r != 0 ({len(nonzero_q_vars)}/{len(q_free)}): {nonzero_q_vars}")

if __name__ == '__main__':
    main()
