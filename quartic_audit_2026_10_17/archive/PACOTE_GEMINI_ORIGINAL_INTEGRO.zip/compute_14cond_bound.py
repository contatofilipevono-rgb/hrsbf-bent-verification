"""Fast exact verification of T40 and exact computation of the new 14-condition certified bound (T40 + 0x7f7f)!"""
import json, sys, time
from pathlib import Path
from fractions import Fraction
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base))
from test_0x7f7f_on_T40 import R_7f7f_branches, toggle

t0 = time.perf_counter()
certificate = json.loads((base / 'T40_LIMITE_CERTIFICADO.json').read_text())
models = (
    json.loads((base / 'T35_POLINOMIOS_CERTIFICADO.json').read_text())['combined_models']
    + json.loads((base / 'T40_MODELOS_CERTIFICADO.json').read_text())['models']
)
symmetry = json.loads((base / 'T40_SIMETRIA_CERTIFICADO.json').read_text())

def fast_symplectic_bias(P):
    constant = 0
    linear_mask = 0
    adjacency = {}
    for m in P:
        if m == 0:
            constant ^= 1
        else:
            a = m & -m
            b = m ^ a
            if b == 0:
                linear_mask ^= a
            else:
                ia = a.bit_length() - 1
                ib = b.bit_length() - 1
                adjacency[ia] = adjacency.get(ia, 0) ^ b
                adjacency[ib] = adjacency.get(ib, 0) ^ a
    vars_all = sorted(set(adjacency.keys()) | {j for j in range(116) if (linear_mask >> j) & 1})
    # Each basis vector v has:
    #   adj_v = sum_{j in v} adjacency[j]
    #   qv = q(v)
    # And polar(u, v) = (u & adj_v).bit_count() & 1!
    vecs = []
    for j in vars_all:
        v = 1 << j
        adj_v = adjacency.get(j, 0)
        qv = (linear_mask >> j) & 1
        vecs.append((v, adj_v, qv))
    pairs = 0
    sign = constant
    while True:
        pair = None
        n = len(vecs)
        for i in range(n):
            vi, adj_i, qi = vecs[i]
            if adj_i == 0:
                continue
            for j in range(i + 1, n):
                vj, adj_j, qj = vecs[j]
                if ((vi & adj_j).bit_count() & 1):
                    pair = (i, j)
                    break
            if pair is not None:
                break
        if pair is None:
            break
        i, j = pair
        e, adj_e, qe = vecs[i]
        f, adj_f, qf = vecs[j]
        sign ^= (qe & qf)
        pairs += 1
        new_vecs = []
        for k, (v, adj_v, qv) in enumerate(vecs):
            if k == i or k == j:
                continue
            pv_e = (v & adj_e).bit_count() & 1
            pv_f = (v & adj_f).bit_count() & 1
            if pv_f:
                v ^= e
                adj_v ^= adj_e
                qv ^= qe
            if pv_e:
                v ^= f
                adj_v ^= adj_f
                qv ^= qf
            if pv_e and pv_f:
                qv ^= 1
            new_vecs.append((v, adj_v, qv))
        vecs = new_vecs
    for v, adj_v, qv in vecs:
        if qv:
            return Fraction(0)
    return Fraction(-1 if sign else 1, 1 << pairs)

def rank(rows):
    B = {}
    for v in rows:
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j]
            else:
                B[j] = v
                break
    return len(B)

def polynomial_rank_and_basis(rows):
    features = sorted(set().union(*rows))
    if not features:
        return 0, [], None
    index = {m: i for i, m in enumerate(features)}
    B = {}
    basis_combos = []
    for r_idx, row in enumerate(rows):
        v = sum(1 << index[m] for m in row)
        c = 1 << r_idx
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j][0]
                c ^= B[j][1]
            else:
                B[j] = (v, c)
                basis_combos.append(c)
                break
    # Check if {0} (constant 1, feature 0) is in the span!
    if 0 in index and index[0] == 0:
        # Try to reduce 1 << 0 using B
        v = 1
        c = 0
        while v:
            j = v.bit_length() - 1
            if j in B:
                v ^= B[j][0]
                c ^= B[j][1]
            else:
                break
        if v == 0:
            return len(B), basis_combos, c
    return len(B), basis_combos, None

def derivative(P, d):
    out = set()
    for m in P:
        sub = m & d
        while sub:
            toggle(out, m ^ sub)
            sub = (sub - 1) & (m & d)
    return out

def restrict(P, coordinates, value):
    selected = sum(1 << j for j in coordinates)
    ones = sum(((value >> i) & 1) << j for i, j in enumerate(coordinates))
    zeros = selected ^ ones
    out = set()
    for m in P:
        if not (m & zeros):
            toggle(out, m & ~selected)
    return out

def combination(rows, c):
    P = set()
    for j, row in enumerate(rows):
        if (c >> j) & 1:
            P ^= row
    return P

# 1. Verify all 18,080 quadratic sums of T40 using fast_symplectic_bias and measure time!
t_check = time.perf_counter()
checks = 0
for branch_record in certificate['branches']:
    branch = branch_record['branch']
    supports = branch_record['supports']
    polys = [
        {int(m, 16) for m in next(r for r in models if r['branch'] == branch and r['support_mask'] == s)['polynomial_hex']}
        for s in supports
    ]
    for character in branch_record['characters']:
        choice = character['combination']
        P = combination(polys, choice)
        directions = [int(v, 16) for v in character['directions_hex']]
        D = [derivative(P, d) for d in directions]
        preselection = character.get('selected_radical_equation_combinations')
        if preselection is not None:
            D = [combination(D, int(c, 16)) for c in preselection]
        condition = character['conditioning_coordinates']
        for case in character['conditioned_cases']:
            rows = [restrict(row, condition, case['condition_value']) for row in D]
            if case['inconsistent_equation_combination'] is not None:
                continue
            basis = [combination(rows, int(c, 16)) for c in case['equation_basis_combinations']]
            for idx, expected in enumerate(case['quadratic_biases']):
                Q = combination(basis, idx)
                actual = fast_symplectic_bias(Q)
                assert actual == Fraction(*expected), f"Mismatch: {actual} != {Fraction(*expected)}"
                checks += 1
print(f"Verified all {checks} quadratic sums of T40 in {time.perf_counter() - t_check:.2f}s (vs 958.61s in VERIFICAR_LIMITE_T40.py)!")

# 2. Now compute the exact slice bounds for all 43 shifted character orbits P_lambda ^ R_0x7f7f
#    plus the pure R_0x7f7f character!
t_14 = time.perf_counter()
total_upper_14 = Fraction(0)
total_lower_14 = Fraction(0)
shifted_checks = 0
for branch_record in certificate['branches']:
    branch = branch_record['branch']
    supports = branch_record['supports']
    polys = [
        {int(m, 16) for m in next(r for r in models if r['branch'] == branch and r['support_mask'] == s)['polynomial_hex']}
        for s in supports
    ]
    Q_7f7f = R_7f7f_branches[branch]
    # Pure Q_7f7f character bias (orbit size 1):
    if branch == 0:
        b0 = fast_symplectic_bias(restrict(Q_7f7f, [57], 0))
        b1 = fast_symplectic_bias(restrict(Q_7f7f, [57], 1))
        pure_q_amp = abs((b0 + b1) / 2)
    else:
        pure_q_amp = abs(fast_symplectic_bias(Q_7f7f))
    print(f"\nBranch {branch}: pure R_0x7f7f bias amplitude = {pure_q_amp}")

    amplitudes_old = Fraction(0)
    amplitudes_shifted = Fraction(0)
    for character in branch_record['characters']:
        choice = character['combination']
        orbit = character['symmetry_orbit']
        amp_old = Fraction(*character['average_absolute_slice_bias'])
        amplitudes_old += len(orbit) * amp_old

        # Shifted character P ^ Q_7f7f:
        P = combination(polys, choice) ^ Q_7f7f
        S = character['coordinates']
        mask = sum(1 << j for j in S)
        assert all((m & mask).bit_count() <= 1 for m in P if m.bit_count() > 2)
        polar = [sum((((1 << i) | (1 << j)) in P) << k for k, j in enumerate(S) if i != j) for i in S]
        r_new = rank(polar)
        # Note: if r_new == character['polar_rank'], character['directions_hex'] is the exact radical basis!
        # And we can use the exact same preselection (or all radical directions if r_new != r_old).
        if r_new == character['polar_rank']:
            directions = [int(v, 16) for v in character['directions_hex']]
            D = [derivative(P, d) for d in directions]
            preselection = character.get('selected_radical_equation_combinations')
            if preselection is not None:
                D = [combination(D, int(c, 16)) for c in preselection]
        else:
            # Recompute nullspace directions for choice == 2 on branch 1:
            # Or even simpler, character['directions_hex'] is a valid isotropic radical subspace of dimension len(S) - r_old!
            # Wait: let's check if polar_rank on S for P^Q is r_new = 0 for choice == 2 on branch 1!
            pivots = {}
            directions = []
            for i, row_p in enumerate(polar):
                v = row_p
                c = 1 << S[i]
                while v:
                    j = v.bit_length() - 1
                    if j in pivots:
                        v ^= pivots[j][0]
                        c ^= pivots[j][1]
                    else:
                        pivots[j] = (v, c)
                        break
                if v == 0:
                    directions.append(c)
            D = [derivative(P, d) for d in directions]
            if len(D) > 10:
                D = D[:10]
        condition = character['conditioning_coordinates']
        n_cases = 1 << len(condition)
        Z = Fraction(0)
        for cond_val in range(n_cases):
            rows = [restrict(row, condition, cond_val) for row in D]
            rk, basis_combos, incon = polynomial_rank_and_basis(rows)
            if incon is not None:
                continue
            basis = [combination(rows, c) for c in basis_combos]
            summation = Fraction(0)
            for idx in range(1 << len(basis)):
                Q_comb = combination(basis, idx)
                summation += fast_symplectic_bias(Q_comb)
                shifted_checks += 1
            z = summation / Fraction(1 << len(basis))
            assert 0 <= z <= 1
            Z += z / Fraction(n_cases)
        amp_shifted = Z / Fraction(1 << (r_new // 2))
        amplitudes_shifted += len(orbit) * amp_shifted

    # Total over all 255 nonzero characters of the 8 conditions on this branch:
    total_amp = amplitudes_old + pure_q_amp + amplitudes_shifted
    upper_14 = (1 + total_amp) / 256
    lower_14 = max(Fraction(0), (1 - total_amp) / 256)
    weight = Fraction(1, 64 if branch == 0 else 128)
    total_upper_14 += weight * upper_14
    total_lower_14 += weight * lower_14
    print(f"Branch {branch}: amplitudes_old = {float(amplitudes_old):.6f}, amplitudes_shifted = {float(amplitudes_shifted):.6f}")
    print(f"  13-cond conditional pass upper bound (T40): {float((1 + amplitudes_old)/128):.8f}")
    print(f"  14-cond conditional pass upper bound (T40 + 0x7f7f): {float(upper_14):.8f} = {upper_14}")

print(f"\nComputed {shifted_checks} shifted quadratic sums in {time.perf_counter() - t_14:.2f}s!")
print(f"13-cond global pass upper bound (T40): {Fraction(*certificate['global_pass_upper_bound'])} = {float(Fraction(*certificate['global_pass_upper_bound'])):.10e}")
print(f"14-cond global pass upper bound (T40 + 0x7f7f): {total_upper_14} = {float(total_upper_14):.10e}")
print(f"14-cond global excluded lower bound: {1 - total_upper_14} ({float(100 * (1 - total_upper_14)):.14f}%)")
print(f"Reduction factor in global pass upper bound: {float(Fraction(*certificate['global_pass_upper_bound']) / total_upper_14):.4f}x")
