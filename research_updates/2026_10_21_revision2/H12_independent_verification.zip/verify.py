"""Integrity check and independent finite replay. Run with standard Python."""
from pathlib import Path
import hashlib,json,subprocess,sys

if not __debug__:
    raise RuntimeError('Do not use python -O: assertions are part of the checker.')
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
for name,expected in manifest.items():
    p=root/name
    if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
        raise RuntimeError('Integrity mismatch: '+name)
print('PASS_SUPPLEMENT_INTEGRITY',flush=True)
if sys.argv[1:]==['--integrity-only']:
    sys.exit(0)
if sys.argv[1:]:
    raise RuntimeError('Usage: python verify.py [--integrity-only]')
work=root/'quartic_audit_2026_10_17/cpu_replay'
subprocess.run([sys.executable,'-X','utf8','verify_certificate.py'],cwd=work,check=True)
