# Supplement to the H(12,4) preprint

This package offers a compact, independent replay of the finite exclusion, plus the final Lean statement and evidence. It does not contain the entire compiled Lean dependency graph. It contains no CUDA executable and requires no GPU.

## Independent certificate replay

Python 3.10 or later, standard library only. Run `python verify.py` from the extracted package root to check file integrity and replay the certificate. Do not use `python -O`; assertions are part of the original checker. The two component commands are:

    cd quartic_audit_2026_10_17/cpu_replay
    python verify_model.py
    python verify_certificate.py

The first command checks the concrete basis, necessary linear and periodic reductions, affine maps and polynomial substitutions. The second verifies the full affine decomposition and every terminal Walsh witness. This is the independent four-root Python certificate; the fourth case is contradictory. It is distinct from the three root proofs accepted by Lean. Do not combine their node counts.

Expected final status: PASS_COMPLETE_SYMBOLIC_COVER_AND_WALSH_REJECTIONS. The checker has to cover all 164288 coefficient vectors at its solution leaves and check their original-ANF Walsh witnesses. It does not enumerate all 2^43 coefficient vectors. Running times depend on hardware.

## Formal proof

The final theorem is `H12Final.no_bent_quartic`, universally quantified over BitVec 43 without filter assumptions. The separate Fourier theorem connects the autocorrelation predicate to Walsh flatness. Lean 4.35.0 was used. The complete source version is commit 344ab2e1b330d4a6be3f00603e9423db39cf3354 at:

https://github.com/contatofilipevono-rgb/hrsbf-bent-verification

See research_updates/2026_10_20_final_integration/CONCLUSAO_FORMAL_H12.md in the repository for dependency archive pins and full preservation records. The compact replay is not a replacement for a fresh kernel rebuild and is not itself a Lean proof. The final full binary artifact SHA256 is 2cc9b4aadfe6bfd5f89721b5a72f9768854f4d46c475763dd29953f8153b331c. A complete rebuild can take hours.

## Integrity

MANIFEST_SHA256.json hashes the supplied files; verify it before replay. Hashes identify bytes and do not replace mathematical verification. Checks may create a fresh SYMBOLIC_CERTIFICATE_AUDIT.json with a new execution time.

The manuscript is licensed CC BY 4.0, following the author's instruction to use the same mode as the V1 preprint. Software licensing must be read from the verification repository; the manuscript's licence does not override third-party software licences.
