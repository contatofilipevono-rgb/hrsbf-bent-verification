# Nonexistence of homogeneous rotation symmetric bent functions of degree four in twelve variables

## Abstract

We prove that no homogeneous rotation symmetric Boolean function of degree four in twelve variables is bent. The full quartic cyclic space has forty-three independent coefficients. We reduce bentness in this space to three explicit affine families of dimension thirty-six, together with quadratic necessary conditions. The reduction combines divisibility of weights on coordinate subspaces, three linear consequences of the resulting equations, and autocorrelation congruences on inputs of period four. An algebraic identity excludes a fourth periodic case. We then refute the three remaining families by finite certificates using polynomial identities, affine substitutions and exhaustive branching, with exact Walsh witnesses at the terminal states. A soundness theorem and the three concrete refutations are verified in Lean. The formal conclusion excludes bentness for every choice of the forty-three coefficients, and its equivalence with the Walsh formulation is checked. The structural argument is given explicitly, and an independent checker provides a separate replay of the finite certificate. The result establishes the twelve-variable quartic case of the homogeneous rotation symmetric bent function conjecture.

**Keywords:** Boolean functions; bent functions; rotation symmetry; homogeneous functions; computer-assisted proof; Lean.

## 1 Introduction

Bent Boolean functions have Walsh coefficients of constant absolute value and consequently attain maximum distance from the affine Boolean functions [1]. Their existence is restricted to even numbers of variables. Rotation symmetry gives a natural class in which to investigate the interaction between this spectral property and algebraic structure: a single monomial determines all its cyclic translates, so a function can be specified by substantially fewer coefficients than an arbitrary algebraic normal form.

Stănică and Maitra [2] studied the enumeration and cryptographic properties of rotation symmetric Boolean functions and formulated the conjecture that homogeneous rotation symmetric functions of degree greater than two are not bent. Subsequent work established necessary conditions and nonexistence results for various parameters and support configurations; see, for example, Meng, Chen and Fu [3]. Sun, Shi, Liu and Fu [4] developed further restrictions using autocorrelations, distances between indices and derivatives. These approaches motivate the use of periodic inputs and algebraic constraints in the present work.

The following selected results indicate the parameter and support restrictions relevant to the present problem. The table is a comparison of stated results, rather than an exhaustive classification of all cases of the conjecture. For the interval criterion, $s_f$ denotes the largest circular gap between consecutive indices in a monomial of $f$.

| Source | Parameters or hypothesis | Conclusion and boundary |
|---|---|---|
| Stănică--Maitra [2] | Rotation symmetric functions studied up to ten variables | Computational evidence motivating the conjecture; not a twelve-variable exclusion |
| Meng--Chen--Fu [3], as reproduced in Lemma 7 of [4] | Homogeneous degree at least three and $s_f\le n/2$ | Non-bentness under the interval condition; this does not cover arbitrary supports |
| Cusick--Sanger, arXiv:1708.09313, Theorem 3.8 | $n=2p$, $p>2$ prime | A homogeneous bent function must have even degree; twelve is not of the form $2p$ |
| Sun et al. [4], Theorems 1--2 | Growth conditions on the odd prime factors of $n$ | Orbit-value and orbit-count restrictions; the hypotheses fail at $n=12$ |
| Sun et al. [4], Theorems 3--6 | Support-distance conditions, parity patterns or cubic degree | Further conditional exclusions; Theorem 4(2) has degree threshold five at $n=12$ |
| Present theorem | $n=12$, degree four, all forty-three cyclic coefficients | Nonexistence throughout the complete homogeneous quartic space |

For $n=12=2^2\cdot3$, the first odd prime is $3$, whereas the first prime bound in Theorems 1--2 of [4] is $16$. Their Theorems 3 and 4(1) retain restrictions on supports; Theorem 4(2) requires degree at least $\lfloor12/4\rfloor+2=5$; and Theorems 5--6 concern cubic functions. We therefore treat the full quartic cyclic space directly, rather than assuming that one of those restricted criteria applies to every coefficient vector.

There are forty-three cyclic orbits of quartic monomials in twelve variables. The complete coefficient space consequently has $2^{43}$ elements.

**Theorem 1.1.** No homogeneous rotation symmetric Boolean function of degree four in twelve variables is bent.

Our contribution has two parts. First, restricted weight divisibility, three linear consequences, a period-four autocorrelation argument and an exclusion identity place every hypothetical bent function in one of three explicit thirty-six-dimensional affine families. Second, finite refutations exclude every bent observation in those families. The refutation rules have a soundness proof, and that proof and the three concrete instances are checked in Lean. Thus the structural reduction and the finite exclusions form a single coverage argument for the full coefficient space. The linear identities, affine parametrizations and acceptance conditions are included in the exposition.

Rotation symmetry alone does not exclude bentness above degree two. Polujan, Kudin and Pasalic [5] construct rotation symmetric bent functions outside the completed Maiorana--McFarland class. Their quartic family has $n=2m$ with $m$ odd and $3\nmid m$, while their maximum-degree family has degree six at $n=12$. Tang's preprint (Cryptology ePrint Archive 2026/1799, https://eprint.iacr.org/2026/1799) gives constructions in dimensions $30\cdot7^j$ and $70t$. These parameter sets do not include twelve. Homogeneity concerns the whole algebraic normal form and must be distinguished from maximum degree and from membership in a particular bent class.

The present quartic argument is self-contained.[^v1]

[^v1]: Related work by the author concerns antipodal necessity in degree at most three and the homogeneous cubic case (preprint, https://doi.org/10.6084/m9.figshare.34165260.v2). It is not used as a hypothesis here.

Section 2 specifies the family and spectral conventions. Section 3 derives the necessary conditions and affine reduction. Section 4 defines the certificates and their soundness. Section 5 composes the concrete refutations with the structural reduction. Section 6 discusses extensions, Section 7 identifies the data, and Appendix C gives the exact formal interpretation.

## 2 Preliminaries and the quartic cyclic space

All polynomial arithmetic is over $\mathbb F_2$ unless otherwise stated. Let $V=\mathbb F_2^{12}$, with coordinates numbered from $0$ to $11$. Write $\rho$ for cyclic rotation by one position. A Boolean function $f:V\to\mathbb F_2$ is rotation symmetric if $f\circ\rho=f$. Its algebraic normal form is the unique square-free polynomial representing it. It is homogeneous of degree four if every monomial in this form has degree four.

Let $\mathcal O_0,\ldots,\mathcal O_{42}$ be the ordered cyclic orbits of four-element subsets listed in Appendix A. Define

\[
p_j(x)=\sum_{S\in\mathcal O_j}\prod_{i\in S}x_i,
\qquad f_c(x)=\sum_{j=0}^{42}c_jp_j(x),\quad c\in\mathbb F_2^{43}. \tag{2.1}
\]

**Proposition 2.1.** The family (2.1) consists of the zero function and all homogeneous rotation symmetric functions of degree four on $V$, each represented exactly once.

**Proof.** Rotation acts on monomial supports. Uniqueness of algebraic normal form implies that rotation invariance is equivalent to constancy of the coefficient on each support orbit. The forty-three orbits in Appendix A are pairwise disjoint and cover the $\binom{12}{4}=495$ four-element supports. Assigning one coefficient to each orbit therefore gives every invariant quartic form. Disjointness makes the representation unique. Every nonzero combination has a degree-four monomial and hence has degree exactly four. ∎

For $a,u\in V$, define the Walsh transform and autocorrelation by

\[
W_f(a)=\sum_{x\in V}(-1)^{f(x)+a\cdot x},\qquad
C_f(u)=\sum_{x\in V}(-1)^{f(x)+f(x+u)}. \tag{2.2}
\]

The function is bent when $|W_f(a)|=64$ for every $a$.

**Lemma 2.2.** A Boolean function on $V$ is bent if and only if $C_f(u)=0$ for every nonzero $u\in V$.

**Proof.** Expanding the square of $W_f(a)$ and putting $y=x+u$ gives

\[
W_f(a)^2=\sum_{u\in V}C_f(u)(-1)^{a\cdot u}. \tag{2.3}
\]

Since $C_f(0)=4096$, vanishing at nonzero directions implies $W_f(a)^2=4096$. Conversely, Fourier inversion applied to (2.3) gives

\[
C_f(u)=2^{-12}\sum_{a\in V}W_f(a)^2(-1)^{a\cdot u}.
\]

If the squares are all $4096$, character orthogonality makes this zero for nonzero $u$. ∎

## 3 Necessary conditions and affine reduction

### 3.1 Quadratic conditions from restricted weights

For an eight-element coordinate set $S$, let $V_S$ be the coordinate subspace supported on $S$. Orthogonality gives the restriction identity

\[
\sum_{x\in V_S}(-1)^{f(x)}=\frac1{16}\sum_{a\in V_S^\perp}W_f(a). \tag{3.1}
\]

**Lemma 3.1.** If $f$ is bent, then the weight of $f|_{V_S}$ is divisible by four.

**Proof.** There are sixteen frequencies in $V_S^\perp$. For a bent function the right side of (3.1) is four times a sum of sixteen signs, and is therefore divisible by eight. The left side equals $256-2\operatorname{wt}(f|_{V_S})$. The stated divisibility follows. ∎

For this family the parity bit gives no additional constraint: each quartic monomial supported in $S$ takes value one on exactly $2^{8-4}=16$ inputs of $V_S$, so the sum of its values is zero in $\mathbb F_2$. The same holds for any sum of these monomials. The second weight bit is the first nontrivial divisibility condition used here.

For bits $t_x$, the second binary digit of the integer $\sum_x t_x$ is
$\sum_{x<y}t_xt_y$ in $\mathbb F_2$: both are $\binom{\sum_x t_x}{2}$ modulo two. Applying this to $t_x=f_c(x)$ produces a polynomial $Q_S(c)$ of degree at most two, after reducing $c_i^2=c_i$. Lemma 3.1 implies $Q_S(c)=0$ whenever $f_c$ is bent.

This definition is explicit and does not require interpolation. If $v_i=(p_i(x))_{x\in V_S}$, its coefficients are

\[
[c_i]Q_S=\left\lfloor |v_i|/2\right\rfloor\bmod2,
\qquad
[c_ic_j]Q_S=(|v_i|\bmod2)(|v_j|\bmod2)+|v_i\cap v_j|\bmod2\quad(i<j). \tag{3.2}
\]

For the second formula, the coefficient is the sum of $v_i(x)v_j(y)$ over all ordered pairs with $x\ne y$, which equals the displayed expression. The first formula counts pairs of ones in $v_i$.

Only a necessary consequence of weight divisibility is retained in each $Q_S$: vanishing of its second binary digit. We do not assert that a common zero of these equations is bent.

There are forty-three cyclic orbits of eight-element subsets, obtained by complementing the quartic support orbits. If $T=\rho^r(S)$, rotation is a bijection from $V_S$ to $V_T$ and $f_c(\rho^r x)=f_c(x)$, so the two restrictions have equal weight for every $c$. Their second weight bits, and hence their filter polynomials, coincide. Thus one equation per support orbit is sufficient. Write $Q_0,\ldots,Q_{42}$ for the resulting equations, ordered by the eight-coordinate support masks in Appendix B. The filter numbering is independent of the quartic orbit numbering.

### 3.2 Linear consequences

Define

\[
\begin{aligned}
R_1={}&c_1+c_7+c_9+c_{18}+c_{24}+c_{32}+c_{34}+c_{36},\\
R_2={}&c_{26}+c_{40}+c_{42},\\
R_3={}&c_0+c_1+c_2+c_6+c_7+c_9+c_{12}+c_{15}+c_{18}
       +c_{23}+c_{24}+c_{25}+c_{32}+c_{34}+c_{36}+c_{37}.
\end{aligned} \tag{3.3}
\]

**Lemma 3.2.** Every common zero of the forty-three quadratic conditions satisfies $R_1=R_2=R_3=0$.

**Proof by explicit polynomial identities.** In the Boolean polynomial ring
$\mathbb F_2[c_0,\ldots,c_{42}]/(c_i^2+c_i)$, each $R_i$ is a sum of products of a filter $Q_j$ with either $1$ or a coefficient variable. The three lists have respectively twenty-two, one and twenty-four products. Their full factors are displayed in Appendix B; the filters are reconstructed from (3.2). Multiplication and cancellation of equal monomials give (3.3). Such identities can be found by linear algebra in the span of the polynomials $Q_j$ and $c_vQ_j$; checking the displayed products is sufficient for the proof, independently of how they were found. Evaluation at a common zero makes each product zero. ∎

Thus (3.3) is derived from necessary conditions; it is not an additional assumption restricting the family under investigation. The explicit identities form part of the finite certificate. Appendix B also derives the single-filter identity for $R_2$ directly from restricted weights.

### 3.3 Restriction to period four

Let $r(y)=(y,y,y)$ for $y\in\mathbb F_2^4$. Direct restriction of the orbit sums gives

\[
f_c(r(y))=\alpha A(y)+\beta B(y)+\gamma E_3(y)+\delta D(y), \tag{3.4}
\]

where

\[
\begin{aligned}
A&=y_0y_1+y_1y_2+y_2y_3+y_3y_0,\\
B&=y_0y_2+y_1y_3,\\
E_3&=y_0y_1y_2+y_0y_1y_3+y_0y_2y_3+y_1y_2y_3,\\
D&=y_0y_1y_2y_3.
\end{aligned}
\]

Here $\alpha=c_{15}+c_{18}+c_{19}+c_{23}+c_{24}$, $\beta=c_{40}$, $\delta=c_{42}$, and

\[
\gamma=\sum_{j\in J}c_j,\quad
J=\{1,2,3,5,6,7,8,9,11,12,13,16,17,20,21,22,25,27,28,29,30,32,34,36,38,39,41\}. \tag{3.5}
\]

**Lemma 3.3.** If $f_c$ is bent, then the tuple $(\alpha,\beta,\gamma,\delta)$ is one of

\[
(0,1,0,0),\quad(1,1,0,0),\quad(0,0,0,1),\quad(1,1,1,1). \tag{3.6}
\]

**Proof.** Put $g=f_c\circ r$. Rotation by four coordinates has order three. For each nonzero $u\in\mathbb F_2^4$, the summand defining $C_{f_c}(r(u))$ is constant on its orbits. There are sixteen fixed points, precisely the $r(y)$, and all other orbits have size three. Therefore

\[
C_{f_c}(r(u))\equiv C_g(u)\pmod3. \tag{3.7}
\]

Lemma 2.2 implies that every $C_g(u)$ is divisible by three. The following table performs the complete sixteen-case check. The truth-table integer has bit $y$ equal to $g(y)$; a direction $u$ is likewise encoded by its four binary coordinates. For every rejected tuple the table gives one nonzero residue. In each of the four surviving rows all fifteen nonzero directions have residue zero.

| Code | Tuple | Truth table | Rejection witness $u$ | $C_g(u)$ | Residue mod 3 |
|---:|---|---|---:|---:|---:|
| 0 | $(0,0,0,0)$ | `0x0000` | 1 | 16 | 1 |
| 1 | $(1,0,0,0)$ | `0x1248` | 5 | 16 | 1 |
| 2 | $(0,1,0,0)$ | `0x6ca0` | --- | --- | all 15 are 0 |
| 3 | $(1,1,0,0)$ | `0x7ee8` | --- | --- | all 15 are 0 |
| 4 | $(0,0,1,0)$ | `0x6880` | 3 | 8 | 2 |
| 5 | $(1,0,1,0)$ | `0x7ac8` | 3 | -8 | 1 |
| 6 | $(0,1,1,0)$ | `0x0420` | 1 | 8 | 2 |
| 7 | $(1,1,1,0)$ | `0x1668` | 1 | -8 | 1 |
| 8 | $(0,0,0,1)$ | `0x8000` | --- | --- | all 15 are 0 |
| 9 | $(1,0,0,1)$ | `0x9248` | 1 | -4 | 2 |
| 10 | $(0,1,0,1)$ | `0xeca0` | 1 | 4 | 1 |
| 11 | $(1,1,0,1)$ | `0xfee8` | 1 | 4 | 1 |
| 12 | $(0,0,1,1)$ | `0xe880` | 1 | 4 | 1 |
| 13 | $(1,0,1,1)$ | `0xfac8` | 1 | 4 | 1 |
| 14 | $(0,1,1,1)$ | `0x8420` | 1 | 4 | 1 |
| 15 | $(1,1,1,1)$ | `0x9668` | --- | --- | all 15 are 0 |

Each entry is obtained by evaluating (3.4) on the sixteen inputs and summing $(-1)^{g(y)+g(y+u)}$. Thus every tuple outside (3.6) has an explicit contradiction to (3.7). ∎

**Lemma 3.4.** A bent $f_c$ cannot have the last tuple in (3.6).

**Proof.** Let $Q$ be the filter for the eight-coordinate support with binary mask `0x3cf`. Formula (3.2) gives

\[
Q=L+c_{26}+c_{40}+c_{26}c_{42},\qquad
L=c_0+c_2+c_6+c_{12}+c_{15}+c_{23}+c_{25}+c_{37}=R_1+R_3.
\]

The Boolean identity

\[
c_{40}c_{42}=Q+R_1+R_3+(1+c_{42})R_2 \tag{3.8}
\]

follows by expansion. All terms on the right vanish for a bent function. Since $\beta=c_{40}$ and $\delta=c_{42}$, the tuple $(1,1,1,1)$ contradicts (3.8). ∎

### 3.4 Three affine families

For each of the first three tuples in (3.6), impose its four values and the three equations (3.3). These seven independent affine equations define a family $\phi_k(\mathbb F_2^{36})$, where $k=0,1,2$ corresponds respectively to codes $2,3,8$.

An explicit parametrization avoids a rank calculation hidden in software. Choose freely the coordinates

\[
I=\{0,1,\ldots,23,25,27,28,29,30,31,32,33,34,35,38,39\}.
\]

Determine the other coordinates in the following order:

\[
\begin{aligned}
c_{24}&=\alpha+c_{15}+c_{18}+c_{19}+c_{23},\\
c_{40}&=\beta,\qquad c_{42}=\delta,\qquad c_{26}=\beta+\delta,\\
c_{36}&=c_1+c_7+c_9+c_{18}+c_{24}+c_{32}+c_{34},\\
c_{37}&=c_0+c_1+c_2+c_6+c_7+c_9+c_{12}+c_{15}+c_{18}
 +c_{23}+c_{24}+c_{25}+c_{32}+c_{34}+c_{36},\\
c_{41}&=\gamma+\sum_{j\in J\setminus\{41\}}c_j.
\end{aligned} \tag{3.9}
\]

Each right side uses only free or previously determined coordinates. Projection onto $I$ is the inverse of this parametrization on the family. In particular, each family has dimension thirty-six.

**Proposition 3.5.** If $f_c$ is bent, then there exist $k\in\{0,1,2\}$ and $u\in\mathbb F_2^{36}$ such that

\[
c=\phi_k(u),\qquad Q_j(\phi_k(u))=0\quad(0\le j<43). \tag{3.10}
\]

**Proof.** Lemmas 3.1–3.4 give the seven equations for one of the three tuples. Formula (3.9) reconstructs $c$ from its free coordinates. The filter conditions follow from Lemma 3.1. ∎

## 4 Refutation certificates

Write $q_{k,j}=Q_j\circ\phi_k$. Exact substitution gives forty-three Boolean quadratic polynomials in thirty-six variables for each family. A state is a pair $(k,E)$, where $k\in\{0,1,2\}$ identifies the family and $E:\mathbb F_2^{36}\to\mathbb F_2^{36}$ is an affine map. The coordinate expressions of $E$ constitute its environment. The root of family $k$ is $(k,\mathrm{id})$. Its equations at a state are $q_{k,j}(E(z))=0$, and its observation is the forty-three-dimensional coefficient vector $\phi_k(E(z))$.

The assertion proved by a refutation at this state is

\[
\forall z\in\mathbb F_2^{36},\quad
\bigl(q_{k,j}(E(z))=0\text{ for every }j\bigr)
\ \Longrightarrow\ \neg\operatorname{Bent}(f_{\phi_k(E(z))}).
\]

The certificate records the data needed to establish this assertion recursively, using the following rules. All polynomial equalities are equalities in the Boolean polynomial ring, so repeated variable factors are reduced using $z_i^2=z_i$.

**Contradiction.** A specified sum of the current equations is the constant polynomial one. No common zero exists.

**Elimination.** A specified sum of the current equations is $z_i+a(z)$, where $a$ is affine. Any common zero satisfies $z_i=a(z)$. Define $T_{i,a}(z)$ by replacing coordinate $i$ of $z$ with $a(z)$ and leaving the other coordinates unchanged. The child environment is $E\circ T_{i,a}$. At an assignment satisfying the equality, $T_{i,a}(z)=z$, so the child has exactly the same observation and satisfies the same equations at that assignment.

**Branching.** For an affine $a$, use children with environments $E\circ T_{i,a}$ and $E\circ T_{i,a+1}$. Every assignment satisfies exactly one of $z_i=a(z)$ and $z_i=a(z)+1$, so it is preserved by one of the two update maps. Both children must have refutations.

In the supplied concrete certificates, each chosen $a$ is independent of $z_i$, so these are ordinary variable eliminations or splits. The abstract soundness argument is more general and does not require that independence: the update map is defined even if $a$ contains $z_i$, and the equalities above still imply $T_{i,a}(z)=z$ in the appropriate child. Soundness is induction on a finite certificate; it does not assume that every possible update decreases a variable count.

**Terminal rejection.** The composed coefficient observation depends only on an explicitly checked finite set of active coordinates. Enumerate their assignments. For each resulting coefficient vector $c$, the certificate supplies a frequency $b\in V$ such that

\[
W_{f_c}(b)^2\ne4096. \tag{4.1}
\]

The Walsh values are evaluated with exact integer arithmetic; no floating-point threshold or probabilistic rejection is used. Every observation at that terminal is therefore non-bent. The support check on the observation is essential: it justifies that varying the enumerated active coordinates covers every observation of the state, including those from assignments not satisfying the current quadratic equations.

**Proposition 4.1 (soundness).** An accepted refutation at a state excludes bentness of every observed function whose parameters satisfy the equations at that state.

**Proof.** Induct on the refutation. At a contradiction node, evaluation at a common zero would give $0=1$. At an elimination node, the polynomial identity forces the equality and therefore $T_{i,a}(z)=z$; the child applies to the same assignment in its composed environment. At a branching node, one of the two affine equalities holds, and the corresponding child applies. At a terminal, the checked support condition identifies the observation with one obtained from an enumerated active assignment. Its verified witness (4.1) contradicts bentness. ∎

For example, if the sum of two current equations is $z_3+z_0+1$, any common zero has $z_3=z_0+1$ and can be passed to the elimination child. This is a deduction from equations, rather than deletion of the branch $z_3=z_0$. Branching, when used, retains both possible values. Keeping these operations distinct is necessary for coverage.

The implementation stores polynomials and affine maps as packed bit representations. Its evaluation and substitution lemmas connect those representations to the interpretation above. Terminal lookup tables are accompanied by proofs that their stored coefficient keys have valid Walsh witnesses. Consequently a successful lookup does not introduce an assumption that the listed functions are non-bent.

## 5 Certified verification and the main theorem

### 5.1 Concrete acceptance

**Proposition 5.1 (finite certified verification).** For each $k=0,1,2$, the supplied certificate is an accepted refutation of the equations $q_{k,j}=0$ with coefficient observation $\phi_k$.

This proposition is the computational part of the proof. Each concrete instance is a proof object of the refutation predicate in Section 4. The three instances are combined without an additional hypothesis; their exact names and sizes are recorded in Appendix C.

The concrete instances were checked in Lean and composed with the general soundness and coverage theorems. The final theorem therefore does not assume the correctness of a certificate generator or a search result. Lean's proof architecture is described in [6]. Appendix C gives the formal definitions, logical dependencies and verification records.

### 5.2 Completion of the proof

**Proof of Theorem 1.1.** By Proposition 2.1, write a putative bent function as $f_c$. Proposition 3.5 places $c$ in one of the three affine families and gives a common zero of its necessary quadratic equations. Proposition 5.1 supplies the corresponding refutation. Proposition 4.1 excludes bentness of its observation, which is exactly $f_c$. This is a contradiction. ∎

The exact final formal statement is

```lean
theorem H12Final.no_bent_quartic (c : BitVec 43) :
    ¬ H12Descent.BentAC (H12.quarticFunction c)
```

Here `BitVec 43` represents $\mathbb F_2^{43}$, and the concrete function evaluates the orbit sums (2.1) on twelve-bit inputs. `BentAC` is the autocorrelation condition of Lemma 2.2. The formal theorem `H12Fourier.bent_iff_flat` proves its equivalence with Walsh flatness on this domain. Thus the result also gives

\[
\forall c\in\mathbb F_2^{43}\ \exists b\in V:\quad W_{f_c}(b)^2\ne4096. \tag{5.1}
\]

The concrete support orbits used by the formal theorem are the orbits in Appendix A. Their disjointness and coverage give the mathematical identification in Proposition 2.1. The implementation and source audit for this identification are described in Appendix C.

### 5.3 Use of AI-assisted tools

During this research and the preparation of the manuscript, generative AI tools (OpenAI Codex, Gemini and Claude) were used to support mathematical discussion and manuscript preparation. Codex also assisted with programming and Lean formalization; Claude was used for adversarial review. The formal nonexistence statement was verified by the Lean kernel using the certificates described in this paper. Responsibility for the scientific content and the final manuscript rests with the author.

## 6 Conclusion and availability of verification material

Theorem 1.1 settles the quartic case in twelve variables by combining structural reductions with certified finite refutations. The necessary weight conditions yield a quadratic system; periodic autocorrelations and its linear consequences reduce coverage to three explicit affine families. The certificate then excludes every bent observation in those families.

The next parameter case requires new reductions. For sixteen variables there are 116 quartic cyclic coefficients, and rotation by four positions has order four rather than three. Consequently the modulo-three orbit descent in (3.7) does not transfer directly. One would need suitable necessary restrictions, an explicit cover of the resulting families and new refutations with their own soundness linkage.

Allowing lower-degree terms is a different problem: it changes both the restricted-weight polynomials and the periodic normal form. In particular, the antipodal quadratic $\sum_{i=0}^{5}x_ix_{i+6}$ is already bent, so a blanket nonexistence statement for all functions of degree at most four would be false. The role of homogeneity, rather than low degree of a restriction alone, must remain explicit in any extension.

## 7 Data availability

The exact mathematical source archive, independent certificate checker and verification records accompany this manuscript. The [verification repository](https://github.com/contatofilipevono-rgb/hrsbf-bent-verification) preserves a [fixed preparation record](https://github.com/contatofilipevono-rgb/hrsbf-bent-verification/tree/1e0e052/research_updates/2026_10_21_preprint) and the [completed formal integration](https://github.com/contatofilipevono-rgb/hrsbf-bent-verification/tree/9be0d98/research_updates/2026_10_20_final_integration). Appendix C describes the formal interpretation and the supplementary files; detailed hashes and execution records are supplied with those files.

## Appendix A: Ordered quartic support orbits

Each row gives the representative support and the orbit size for the coefficient index used in (2.1). Indices are zero based and all translates are modulo twelve. The orbit sizes total $40\cdot12+2\cdot6+3=495$.

| Index | Representative support | Orbit size |
|---:|---|---:|
| 0 | $\{0,1,2,3\}$ | 12 |
| 1 | $\{0,1,2,4\}$ | 12 |
| 2 | $\{0,1,2,5\}$ | 12 |
| 3 | $\{0,1,2,6\}$ | 12 |
| 4 | $\{0,1,2,7\}$ | 12 |
| 5 | $\{0,4,5,6\}$ | 12 |
| 6 | $\{0,3,4,5\}$ | 12 |
| 7 | $\{0,2,3,4\}$ | 12 |
| 8 | $\{0,1,3,4\}$ | 12 |
| 9 | $\{0,1,3,5\}$ | 12 |
| 10 | $\{0,1,3,6\}$ | 12 |
| 11 | $\{0,1,3,7\}$ | 12 |
| 12 | $\{0,4,5,7\}$ | 12 |
| 13 | $\{0,3,4,6\}$ | 12 |
| 14 | $\{0,2,3,5\}$ | 12 |
| 15 | $\{0,1,4,5\}$ | 12 |
| 16 | $\{0,1,4,6\}$ | 12 |
| 17 | $\{0,1,4,7\}$ | 12 |
| 18 | $\{0,1,4,8\}$ | 12 |
| 19 | $\{0,3,4,7\}$ | 12 |
| 20 | $\{0,2,3,6\}$ | 12 |
| 21 | $\{0,1,5,6\}$ | 12 |
| 22 | $\{0,1,5,7\}$ | 12 |
| 23 | $\{0,1,5,8\}$ | 12 |
| 24 | $\{0,3,4,8\}$ | 12 |
| 25 | $\{0,2,3,7\}$ | 12 |
| 26 | $\{0,1,6,7\}$ | 6 |
| 27 | $\{0,2,6,7\}$ | 12 |
| 28 | $\{0,3,6,7\}$ | 12 |
| 29 | $\{0,4,6,7\}$ | 12 |
| 30 | $\{0,2,5,6\}$ | 12 |
| 31 | $\{0,3,5,6\}$ | 12 |
| 32 | $\{0,2,4,5\}$ | 12 |
| 33 | $\{0,2,4,6\}$ | 12 |
| 34 | $\{0,2,4,7\}$ | 12 |
| 35 | $\{0,2,4,8\}$ | 12 |
| 36 | $\{0,3,5,7\}$ | 12 |
| 37 | $\{0,2,5,7\}$ | 12 |
| 38 | $\{0,2,5,8\}$ | 12 |
| 39 | $\{0,3,5,8\}$ | 12 |
| 40 | $\{0,2,6,8\}$ | 6 |
| 41 | $\{0,3,6,8\}$ | 12 |
| 42 | $\{0,3,6,9\}$ | 3 |

## Appendix B: Filter ordering and linear certificates

A mask $s$ denotes the coordinate set $\{i: \operatorname{bit}_i(s)=1\}$. In the following order, $Q_j$ is obtained from that support using (3.2):

\[
\begin{gathered}
255,383,639,509,447,703,765,831,1013,507,479 \\
735,893,863,1375,763,927,1003,1005,503,495,751 \\
957,879,1391,891,943,1455,1403,759,975,983,987 \\
989,887,1399,955,951,1463,1467,1495,1499,1755.
\end{gathered}
\]

Define $m_{-1}=1$ and $m_v=c_v$ for $0\le v<43$. Each row below encodes the exact identity $R_i=\sum_{(j,v)\in T_i}m_vQ_j$. The products are in the Boolean polynomial ring.

For $R_1$, the pairs in $T_1$ are

\[
\begin{gathered}
(1,7),(3,1),(5,32),(8,9),(10,5),(12,13),(13,30) \\
(15,20),(17,16),(19,3),(21,29),(24,36),(26,27),(28,34) \\
(31,22),(33,11),(34,24),(36,18),(38,41),(40,-1),(40,40) \\
(41,38).
\end{gathered}
\]

For $R_2$, the pairs in $T_2$ are

\[
\begin{gathered}
(42,-1).
\end{gathered}
\]

For $R_3$, the pairs in $T_3$ are

\[
\begin{gathered}
(30,-1),(30,26),(30,40),(30,42),(40,-1),(40,26),(40,40) \\
(40,42),(42,0),(42,1),(42,2),(42,6),(42,7),(42,9) \\
(42,12),(42,15),(42,18),(42,23),(42,24),(42,25),(42,32) \\
(42,34),(42,36),(42,37).
\end{gathered}
\]

In particular, $R_2=Q_{42}$. The filter used in (3.8) is $Q_{30}$, since its support mask is $975=\mathtt{0x3cf}$. These conventions make every linear identity and the excluded periodic case reproducible directly from the orbit table and (3.2).

For a direct example, $Q_{42}$ uses $S=\{0,1,3,4,6,7,9,10\}$. Put $w_i=\operatorname{wt}(p_i|_{V_S})$ and $w_{ij}=|\operatorname{supp}(p_i|_{V_S})\cap\operatorname{supp}(p_j|_{V_S})|$. Counting the quartic supports on this eight-coordinate set gives $w_{26}=30$, $w_{40}=30$, $w_{42}=30$; every other $w_i$ is divisible by four and every $w_{ij}$ is even. The weight identity for a sum, reduced modulo four, is

\[
\operatorname{wt}(f_c|_{V_S})\equiv\sum_i c_iw_i-2\sum_{i<j}c_ic_jw_{ij}\pmod4.
\]

It follows that $Q_{42}=c_{26}+c_{40}+c_{42}=R_2$. These counts can be checked by enumerating the 256 inputs of $V_S$ from Appendix A; they are supplied with the independent transcription check. The longer identities for $R_1$ and $R_3$ are polynomial certificates whose full factors are listed above.

## Appendix C: Formal interpretation and certificate sizes

### C.1 What the formal theorem says

Inputs are natural numbers from 0 to 4095. Coordinate $i$ is bit $i$ of the input, with the least significant bit indexed by zero. In a coefficient word of type `BitVec 43`, bit $j$ is the coefficient of row $j$ of Appendix A. Bitwise AND tests monomial containment, XOR is addition in $\mathbb F_2$, and the orbit fold sums each distinct support once. The exact defining expressions are:

```lean
def monomialValue (s x : Nat) : Bool := (x &&& s) == s
```

```lean
def orbitValue (o : List Nat) (x : Nat) : Bool :=
  o.foldl (fun a s => a ^^ monomialValue s x) false
```

```lean
def quarticFunction (c : BitVec 43) (x : Nat) : Bool :=
  (c.getLsbD 0 && orbitValue (quarticOrbits[(0 : Fin 43).val]!) x) ^^
  (c.getLsbD 1 && orbitValue (quarticOrbits[(1 : Fin 43).val]!) x) ^^
  (c.getLsbD 2 && orbitValue (quarticOrbits[(2 : Fin 43).val]!) x) ^^
  (c.getLsbD 3 && orbitValue (quarticOrbits[(3 : Fin 43).val]!) x) ^^
  (c.getLsbD 4 && orbitValue (quarticOrbits[(4 : Fin 43).val]!) x) ^^
  (c.getLsbD 5 && orbitValue (quarticOrbits[(5 : Fin 43).val]!) x) ^^
  (c.getLsbD 6 && orbitValue (quarticOrbits[(6 : Fin 43).val]!) x) ^^
  (c.getLsbD 7 && orbitValue (quarticOrbits[(7 : Fin 43).val]!) x) ^^
  (c.getLsbD 8 && orbitValue (quarticOrbits[(8 : Fin 43).val]!) x) ^^
  (c.getLsbD 9 && orbitValue (quarticOrbits[(9 : Fin 43).val]!) x) ^^
  (c.getLsbD 10 && orbitValue (quarticOrbits[(10 : Fin 43).val]!) x) ^^
  (c.getLsbD 11 && orbitValue (quarticOrbits[(11 : Fin 43).val]!) x) ^^
  (c.getLsbD 12 && orbitValue (quarticOrbits[(12 : Fin 43).val]!) x) ^^
  (c.getLsbD 13 && orbitValue (quarticOrbits[(13 : Fin 43).val]!) x) ^^
  (c.getLsbD 14 && orbitValue (quarticOrbits[(14 : Fin 43).val]!) x) ^^
  (c.getLsbD 15 && orbitValue (quarticOrbits[(15 : Fin 43).val]!) x) ^^
  (c.getLsbD 16 && orbitValue (quarticOrbits[(16 : Fin 43).val]!) x) ^^
  (c.getLsbD 17 && orbitValue (quarticOrbits[(17 : Fin 43).val]!) x) ^^
  (c.getLsbD 18 && orbitValue (quarticOrbits[(18 : Fin 43).val]!) x) ^^
  (c.getLsbD 19 && orbitValue (quarticOrbits[(19 : Fin 43).val]!) x) ^^
  (c.getLsbD 20 && orbitValue (quarticOrbits[(20 : Fin 43).val]!) x) ^^
  (c.getLsbD 21 && orbitValue (quarticOrbits[(21 : Fin 43).val]!) x) ^^
  (c.getLsbD 22 && orbitValue (quarticOrbits[(22 : Fin 43).val]!) x) ^^
  (c.getLsbD 23 && orbitValue (quarticOrbits[(23 : Fin 43).val]!) x) ^^
  (c.getLsbD 24 && orbitValue (quarticOrbits[(24 : Fin 43).val]!) x) ^^
  (c.getLsbD 25 && orbitValue (quarticOrbits[(25 : Fin 43).val]!) x) ^^
  (c.getLsbD 26 && orbitValue (quarticOrbits[(26 : Fin 43).val]!) x) ^^
  (c.getLsbD 27 && orbitValue (quarticOrbits[(27 : Fin 43).val]!) x) ^^
  (c.getLsbD 28 && orbitValue (quarticOrbits[(28 : Fin 43).val]!) x) ^^
  (c.getLsbD 29 && orbitValue (quarticOrbits[(29 : Fin 43).val]!) x) ^^
  (c.getLsbD 30 && orbitValue (quarticOrbits[(30 : Fin 43).val]!) x) ^^
  (c.getLsbD 31 && orbitValue (quarticOrbits[(31 : Fin 43).val]!) x) ^^
  (c.getLsbD 32 && orbitValue (quarticOrbits[(32 : Fin 43).val]!) x) ^^
  (c.getLsbD 33 && orbitValue (quarticOrbits[(33 : Fin 43).val]!) x) ^^
  (c.getLsbD 34 && orbitValue (quarticOrbits[(34 : Fin 43).val]!) x) ^^
  (c.getLsbD 35 && orbitValue (quarticOrbits[(35 : Fin 43).val]!) x) ^^
  (c.getLsbD 36 && orbitValue (quarticOrbits[(36 : Fin 43).val]!) x) ^^
  (c.getLsbD 37 && orbitValue (quarticOrbits[(37 : Fin 43).val]!) x) ^^
  (c.getLsbD 38 && orbitValue (quarticOrbits[(38 : Fin 43).val]!) x) ^^
  (c.getLsbD 39 && orbitValue (quarticOrbits[(39 : Fin 43).val]!) x) ^^
  (c.getLsbD 40 && orbitValue (quarticOrbits[(40 : Fin 43).val]!) x) ^^
  (c.getLsbD 41 && orbitValue (quarticOrbits[(41 : Fin 43).val]!) x) ^^
  (c.getLsbD 42 && orbitValue (quarticOrbits[(42 : Fin 43).val]!) x)
```

```lean
def derivativeSign (f : Nat → Bool) (u x : Nat) : Int :=
  if f x == f (x ^^^ u) then 1 else -1
```

```lean
def BentAC (f : Nat → Bool) : Prop :=
  ∀ u, u < 4096 → u ≠ 0 → ((List.range 4096).map (derivativeSign f u)).sum = 0
```

```lean
def total (xs : List α) (f : α → Int) : Int := (xs.map f).sum
```

```lean
def sign (b : Bool) : Int := if b then -1 else 1
```

```lean
def dotBits : Nat → Nat → Nat → Bool
  | 0, _, _ => false
  | n+1, a, x => dotBits n a x ^^ (a.testBit n && x.testBit n)
```

```lean
def character (a x : Nat) : Int := sign (dotBits 12 a x)
```

```lean
def walsh (f : Nat → Bool) (a : Nat) : Int :=
  total (List.range 4096) (fun x => sign (f x) * character a x)
```

The first three definitions are in namespace `H12`, the next two in `H12Descent`, and the remaining definitions in `H12Walsh`. The source list `quarticOrbits` is the explicit list of masks for the 43 orbits. The supplementary source-to-article audit compares each of those masks with the translates of the corresponding row of Appendix A, checks all 495 supports and checks that the expanded coefficient expression contains exactly the 43 matching index pairs. It does not infer the correspondence from similar names.

Proposition 2.1 is the mathematical representation argument using uniqueness of algebraic normal form. The final Lean module proves the concrete universal statement; it does not include an additional abstract theorem representing every arbitrary invariant algebraic normal form. The proof of Proposition 2.1 and the explicit source correspondence identify that concrete statement with Theorem 1.1.

### C.2 The three concrete refutations

The root proofs are `H12CloudChart0.refutation`, `H12CloudChart1.refutation` and `H12CloudChart2.refutation`; they are composed in `H12Final.all_chart_refutations`. The following counts were extracted from the reachable proof-constructor graphs in their certified sources, rather than estimated from module counts. All referenced nodes are reachable from the root, and all source hashes match the certified archive.

| Family (periodic code) | Nodes | Splits | Contradiction leaves | Terminal leaves | Terminal assignments |
|---|---:|---:|---:|---:|---:|
| 0 (2) | 142,802 | 13,357 | 11,018 | 2,340 | 46,912 |
| 1 (3) | 142,930 | 13,357 | 11,038 | 2,320 | 46,400 |
| 2 (8) | 64,343 | 7,113 | 5,121 | 1,993 | 70,976 |

For each root the maximum edge depth is 36 and the maximum number of split nodes along a path is 22. The largest terminal active-coordinate counts are respectively 7, 7 and 8. Terminal assignments are counted with multiplicity across terminal states; they are not asserted to be distinct coefficient vectors. Elimination-node counts are respectively 116,087, 116,215, 50,116.

The separate four-root Python certificate has 67,658 nodes and checks 164,288 coefficient vectors at its solution leaves. Its counts are not counts of these three Lean trees and must not be added to the table. It includes the fourth initial case as contradictory.

### C.3 Verification records and their limits

The original integration completed on 21 October 2026 using Lean 4.35.0. Its preparation directory is named for 20 October, when the integration work was organized; the directory date is not a claim that the final check finished that day. The integration uses the source commit identified in the supplementary records, with the two final modules checked by `leanchecker`. Axiom reports for `all_chart_refutations`, `no_bent_quartic`, `no_flat_quartic` and `walsh_witness` contain only `propext`, `Classical.choice` and `Quot.sound`, with neither `sorryAx` nor `ofReduceBool`.

The independent checker is a separate implementation. On the copy prepared for the first review, replay completed in approximately 139 seconds on one machine. A subsequent reviewer reported approximately 101 seconds on another machine. These are observations, not guarantees about review time or formal reconstruction. Assertions are part of the checker, so it must be run without Python's optimization flag.

The complete formal archive contains 2,091 distinct previously certified dependency modules and the two final modules. Its mathematical sources retain the certified hashes. A full fresh rebuild of the minimal Lake distribution packaging has not been performed during this editorial revision. Sources, final records, exact hashes and the source-to-article audit are supplied separately; temporary execution caches are not needed to preserve them.

## References

[1] Rothaus, O.S.: On “bent” functions. J. Combin. Theory Ser. A **20**, 300–305 (1976). https://doi.org/10.1016/0097-3165(76)90024-8

[2] Stănică, P., Maitra, S.: Rotation symmetric Boolean functions—Count and cryptographic properties. Discrete Appl. Math. **156**, 1567–1580 (2008). https://doi.org/10.1016/j.dam.2007.04.029

[3] Meng, Q., Chen, L., Fu, F.-W.: On homogeneous rotation symmetric bent functions. Discrete Appl. Math. **158**, 1111–1117 (2010). https://doi.org/10.1016/j.dam.2010.02.009

[4] Sun, L., Shi, Z., Liu, J., Fu, F.-W.: On the conjecture about the nonexistence of homogeneous rotation symmetric bent functions. Des. Codes Cryptogr. **94**, Article 93 (2026). https://doi.org/10.1007/s10623-026-01848-4

[5] Polujan, A., Kudin, S., Pasalic, E.: Rotation-symmetric bent functions outside the completed Maiorana--McFarland class. IEEE Trans. Inf. Theory **72**(6), 4341–4351 (2026). https://doi.org/10.1109/TIT.2026.3685133

[6] de Moura, L., Ullrich, S.: The Lean 4 theorem prover and programming language. In: Platzer, A., Sutcliffe, G. (eds.) Automated Deduction—CADE 28, Lecture Notes in Computer Science **12699**, pp. 625–635. Springer (2021). https://doi.org/10.1007/978-3-030-79876-5_37
