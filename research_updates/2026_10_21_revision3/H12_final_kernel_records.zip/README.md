# Preserved final integration records

These are records of the completed original Lean integration, not a new rebuild.
The two sources and four build/kernel logs have been compared byte for byte
with their SHA256 values in the original final integration report. The four
H12Final axiom reports contain only propext, Classical.choice and Quot.sound.
The complete source archive is supplied separately. Logs are evidence to inspect,
not an independent replacement for kernel verification or source review.
