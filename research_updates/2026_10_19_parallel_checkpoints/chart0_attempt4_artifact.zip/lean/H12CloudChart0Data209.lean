import H12CloudChart0Data208

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env52910 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,16384,8541,8203,16400,30825,320,8540,4161,32,20481,20635,8328,65,31124,16449,4177,2341,157,112,257,20577,4249,513]

theorem envBound52910 : H12AffineFastState.Bounded env52910 := by
  intro p hp
  have h : env52910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52909_52910 : H12AffineEnvironment.transform 9 321 env52909 = env52910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52909 == env52910) = true)

theorem identity52910 : scanCanonicalize (H12AffineFastState.compose env52910 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52910 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env52911 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,16384,8541,8203,16400,30825,320,8540,4161,32,20481,20499,8192,65,31004,16449,4177,2341,21,112,257,20577,4113,513]

theorem envBound52911 : H12AffineFastState.Bounded env52911 := by
  intro p hp
  have h : env52911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52910_52911 : H12AffineEnvironment.transform 6 8 env52910 = env52911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52910 == env52911) = true)

theorem identity52911 : scanCanonicalize (H12AffineFastState.compose env52911 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound52911 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env52912 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12621,8541,8203,12637,2340,320,8540,4161,32,8524,8542,8192,65,2129,12556,4177,2341,21,112,257,8492,4113,513]

theorem envBound52912 : H12AffineFastState.Bounded env52912 := by
  intro p hp
  have h : env52912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52911_52912 : H12AffineEnvironment.transform 13 12621 env52911 = env52912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env52911 == env52912) = true)

theorem identity52912 : scanCanonicalize (H12AffineFastState.compose env52912 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52912 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52913 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,269,4160,80,262,4176,2340,320,81,4161,32,65,83,269,65,2129,4097,4177,2341,21,112,257,33,4113,513]

theorem envBound52913 : H12AffineFastState.Bounded env52913 := by
  intro p hp
  have h : env52913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52912_52913 : H12AffineEnvironment.transform 12 269 env52912 = env52913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52912 == env52913) = true)

theorem identity52913 : scanCanonicalize (H12AffineFastState.compose env52913 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound52913 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env52914 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2576,269,2640,80,262,2624,2340,320,81,2641,32,65,83,269,65,2129,2577,2625,2341,21,112,257,33,2561,513]

theorem envBound52914 : H12AffineFastState.Bounded env52914 := by
  intro p hp
  have h : env52914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52913_52914 : H12AffineEnvironment.transform 11 2576 env52913 = env52914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env52913 == env52914) = true)

theorem identity52914 : scanCanonicalize (H12AffineFastState.compose env52914 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52914 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env52915 : List Nat := [2,4,8,16,1,64,8,256,512,321,2048,2576,269,2640,80,262,2624,2309,320,81,2641,1,65,83,269,65,2129,2577,2625,2308,21,81,257,0,2561,513]

theorem envBound52915 : H12AffineFastState.Bounded env52915 := by
  intro p hp
  have h : env52915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52914_52915 : H12AffineEnvironment.transform 4 1 env52914 = env52915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52914 == env52915) = true)

theorem identity52915 : scanCanonicalize (H12AffineFastState.compose env52915 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound52915 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env52916 : List Nat := [2,4,8,16,1,64,8,256,512,321,276,772,269,836,80,262,852,17,320,81,837,1,65,83,269,65,325,773,853,16,21,81,257,0,789,513]

theorem envBound52916 : H12AffineFastState.Bounded env52916 := by
  intro p hp
  have h : env52916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52915_52916 : H12AffineEnvironment.transform 10 276 env52915 = env52916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env52915 == env52916) = true)

theorem identity52916 : scanCanonicalize (H12AffineFastState.compose env52916 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52916 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52917 : List Nat := [2,4,8,16,1,64,8,4,512,69,16,512,9,576,80,2,592,17,68,81,577,1,65,83,9,65,65,513,593,16,21,81,5,0,529,513]

theorem envBound52917 : H12AffineFastState.Bounded env52917 := by
  intro p hp
  have h : env52917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52916_52917 : H12AffineEnvironment.transform 7 4 env52916 = env52917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52916 == env52917) = true)

theorem identity52917 : scanCanonicalize (H12AffineFastState.compose env52917 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52917 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52918 : List Nat := [2,4,8,1,1,64,8,4,512,69,1,512,9,576,65,2,577,0,68,64,577,1,65,66,9,65,65,513,576,1,4,64,5,0,512,513]

theorem envBound52918 : H12AffineFastState.Bounded env52918 := by
  intro p hp
  have h : env52918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52917_52918 : H12AffineEnvironment.transform 3 1 env52917 = env52918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52917 == env52918) = true)

theorem identity52918 : scanCanonicalize (H12AffineFastState.compose env52918 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52919 : List Nat := [2,4,8,1,1,0,8,4,512,5,1,512,9,512,1,2,513,0,4,0,513,1,1,2,9,1,1,513,512,1,4,0,5,0,512,513]

theorem envBound52919 : H12AffineFastState.Bounded env52919 := by
  intro p hp
  have h : env52919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52918_52919 : H12AffineEnvironment.transform 5 0 env52918 = env52919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52918 == env52919) = true)

theorem identity52919 : scanCanonicalize (H12AffineFastState.compose env52919 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52920 : List Nat := [2,4,8,1,1,0,8,4,0,5,1,0,9,0,1,2,1,0,4,0,1,1,1,2,9,1,1,1,0,1,4,0,5,0,0,1]

theorem envBound52920 : H12AffineFastState.Bounded env52920 := by
  intro p hp
  have h : env52920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52919_52920 : H12AffineEnvironment.transform 8 0 env52919 = env52920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52919 == env52920) = true)

def env52921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4161,32,8388608,8430023,8328,65,56713,8393985,8406289,8412260,1500,8451181,257,21792,46213,513]

theorem envBound52921 : H12AffineFastState.Bounded env52921 := by
  intro p hp
  have h : env52921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52896_52921 : H12AffineEnvironment.transform 16 16401 env52896 = env52921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52896 == env52921) = true)

theorem identity52921 : scanCanonicalize (H12AffineFastState.compose env52921 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound52921 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4161,32,17,41430,8328,65,56713,5392,17664,23669,1500,62588,257,21792,46213,513]

theorem envBound52922 : H12AffineFastState.Bounded env52922 := by
  intro p hp
  have h : env52922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52921_52922 : H12AffineEnvironment.transform 22 17 env52921 = env52922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52921 == env52922) = true)

theorem identity52922 : scanCanonicalize (H12AffineFastState.compose env52922 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52922 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4161,32,17,41310,8192,65,56577,5392,17664,23669,1364,62588,257,21792,46093,513]

theorem envBound52923 : H12AffineFastState.Bounded env52923 := by
  intro p hp
  have h : env52923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52922_52923 : H12AffineEnvironment.transform 6 8 env52922 = env52923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52922 == env52923) = true)

theorem identity52923 : scanCanonicalize (H12AffineFastState.compose env52923 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52923 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5392,35188,1025,32769,4161,32,17,41310,8192,65,34816,5392,4097,2420,1364,41341,257,33,46093,513]

theorem envBound52924 : H12AffineFastState.Bounded env52924 := by
  intro p hp
  have h : env52924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52923_52924 : H12AffineEnvironment.transform 13 5377 env52923 = env52924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52923 == env52924) = true)

theorem identity52924 : scanCanonicalize (H12AffineFastState.compose env52924 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52924 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,343,5392,35188,1025,32769,4161,32,17,32770,348,65,34816,5392,4097,2420,1364,32801,257,33,38225,513]

theorem envBound52925 : H12AffineFastState.Bounded env52925 := by
  intro p hp
  have h : env52925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52924_52925 : H12AffineEnvironment.transform 12 348 env52924 = env52925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52924 == env52925) = true)

theorem identity52925 : scanCanonicalize (H12AffineFastState.compose env52925 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound52925 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,343,5392,2340,1025,81,4161,32,17,82,348,65,2128,5392,4097,2420,1364,113,257,33,5377,513]

theorem envBound52926 : H12AffineFastState.Bounded env52926 := by
  intro p hp
  have h : env52926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52925_52926 : H12AffineEnvironment.transform 14 80 env52925 = env52926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env52925 == env52926) = true)

def env52927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,8388608,8487372,8328,65,171417,8393985,8406289,8526965,1500,8451180,257,21792,46213,74250]

theorem envBound52927 : H12AffineFastState.Bounded env52927 := by
  intro p hp
  have h : env52927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52894_52927 : H12AffineEnvironment.transform 21 33 env52894 = env52927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env52894 == env52927) = true)

theorem identity52927 : scanCanonicalize (H12AffineFastState.compose env52927 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound52927 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,73754,41430,8328,65,171417,79131,91403,212079,1500,119926,257,21792,46213,74250]

theorem envBound52928 : H12AffineFastState.Bounded env52928 := by
  intro p hp
  have h : env52928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52927_52928 : H12AffineEnvironment.transform 22 73754 env52927 = env52928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env52927 == env52928) = true)

def env52929 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,73754,41122,8328,65,171245,78959,91263,212079,1192,119926,117,21588,46213,74250]

theorem envBound52929 : H12AffineFastState.Bounded env52929 := by
  intro p hp
  have h : env52929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52928_52929 : H12AffineEnvironment.transform 7 116 env52928 = env52929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52928 == env52929) = true)

theorem identity52929 : scanCanonicalize (H12AffineFastState.compose env52929 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52929 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52930 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4161,33,17,41122,8328,65,171245,5220,17524,138340,1192,62589,117,21588,46213,513]

theorem envBound52930 : H12AffineFastState.Bounded env52930 := by
  intro p hp
  have h : env52930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52929_52930 : H12AffineEnvironment.transform 15 8203 env52929 = env52930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52929 == env52930) = true)

theorem identity52930 : scanCanonicalize (H12AffineFastState.compose env52930 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound52930 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52931 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4161,33,17,41083,8273,65,171060,5220,17524,138340,1137,62589,117,21588,46172,513]

theorem envBound52931 : H12AffineFastState.Bounded env52931 := by
  intro p hp
  have h : env52931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52930_52931 : H12AffineEnvironment.transform 6 89 env52930 = env52931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env52930 == env52931) = true)

theorem identity52931 : scanCanonicalize (H12AffineFastState.compose env52931 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52931 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env52932 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,1,8203,131072,23668,1025,0,4161,33,17,8314,8273,65,138293,5220,17524,138340,1137,29820,117,21588,13405,513]

theorem envBound52932 : H12AffineFastState.Bounded env52932 := by
  intro p hp
  have h : env52932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52931_52932 : H12AffineEnvironment.transform 14 1 env52931 = env52932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52931 == env52932) = true)

theorem identity52932 : scanCanonicalize (H12AffineFastState.compose env52932 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 24680) := by decide +kernel

theorem selectedBound52932 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env52933 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,1,8203,24680,23668,1025,0,4161,33,17,8314,8273,65,31837,5220,17524,31756,1137,29820,117,21588,13405,513]

theorem envBound52933 : H12AffineFastState.Bounded env52933 := by
  intro p hp
  have h : env52933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52932_52933 : H12AffineEnvironment.transform 16 24680 env52932 = env52933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24680 env52932 == env52933) = true)

theorem identity52933 : scanCanonicalize (H12AffineFastState.compose env52933 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound52933 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52934 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,5157,1,8203,13389,2129,1025,0,4161,33,17,8314,8273,65,10360,5220,4177,10281,1137,8281,117,113,13405,513]

theorem envBound52934 : H12AffineFastState.Bounded env52934 := by
  intro p hp
  have h : env52934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52933_52934 : H12AffineEnvironment.transform 13 5157 env52933 = env52934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env52933 == env52934) = true)

theorem identity52934 : scanCanonicalize (H12AffineFastState.compose env52934 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52934 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env52935 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,1,8203,13340,2048,1025,0,4112,33,17,8235,8192,16,10281,5173,4096,10281,1056,8200,36,32,13324,513]

theorem envBound52935 : H12AffineFastState.Bounded env52935 := by
  intro p hp
  have h : env52935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52934_52935 : H12AffineEnvironment.transform 5 17 env52934 = env52935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52934 == env52935) = true)

theorem identity52935 : scanCanonicalize (H12AffineFastState.compose env52935 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound52935 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52936 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5173,2048,1025,0,4112,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound52936 : H12AffineFastState.Bounded env52936 := by
  intro p hp
  have h : env52936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52935_52936 : H12AffineEnvironment.transform 12 41 env52935 = env52936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env52935 == env52936) = true)

def env52937 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,73754,41123,8328,65,171244,78958,91262,212079,1193,119926,116,21589,46213,74250]

theorem envBound52937 : H12AffineFastState.Bounded env52937 := by
  intro p hp
  have h : env52937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52928_52937 : H12AffineEnvironment.transform 7 117 env52928 = env52937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52928 == env52937) = true)

def env52938 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,131072,56325,1025,32769,4145,33,73754,41123,8328,49,171164,78878,91150,211999,1193,119814,4,21541,46213,74250]

theorem envBound52938 : H12AffineFastState.Bounded env52938 := by
  intro p hp
  have h : env52938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52937_52938 : H12AffineEnvironment.transform 5 48 env52937 = env52938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env52937 == env52938) = true)

theorem identity52938 : scanCanonicalize (H12AffineFastState.compose env52938 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 81971) := by decide +kernel

theorem selectedBound52938 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env52939 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,81971,56325,1025,32769,4145,33,73754,41123,8328,49,122031,78878,91150,31788,1193,119814,4,21541,46213,74250]

theorem envBound52939 : H12AffineFastState.Bounded env52939 := by
  intro p hp
  have h : env52939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52938_52939 : H12AffineEnvironment.transform 16 81971 env52938 = env52939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 81971 env52938 == env52939) = true)

theorem identity52939 : scanCanonicalize (H12AffineFastState.compose env52939 (packedSelected [0,2,4,5,6,8,9,11,17,18,20,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21542) := by decide +kernel

theorem selectedBound52939 : packedSelected [0,2,4,5,6,8,9,11,17,18,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52940 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,21542,5141,56325,1025,32769,4145,33,29756,41123,8328,49,34953,24632,12328,31788,1193,32800,4,21541,46213,30252]

theorem envBound52940 : H12AffineFastState.Bounded env52940 := by
  intro p hp
  have h : env52940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52939_52940 : H12AffineEnvironment.transform 15 21542 env52939 = env52940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21542 env52939 == env52940) = true)

theorem identity52940 : scanCanonicalize (H12AffineFastState.compose env52940 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound52940 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env52941 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,8233,21542,5141,31788,1025,8232,4145,33,29756,138,8328,49,10400,24632,12328,31788,1193,8201,4,21541,5292,30252]

theorem envBound52941 : H12AffineFastState.Bounded env52941 := by
  intro p hp
  have h : env52941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52940_52941 : H12AffineEnvironment.transform 14 8233 env52940 = env52941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env52940 == env52941) = true)

theorem identity52941 : scanCanonicalize (H12AffineFastState.compose env52941 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound52941 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env52942 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,5261,8233,171,5141,10401,1025,8232,4145,33,8369,138,8328,49,10400,13493,12328,10401,1193,8201,4,168,5292,8865]

theorem envBound52942 : H12AffineFastState.Bounded env52942 := by
  intro p hp
  have h : env52942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52941_52942 : H12AffineEnvironment.transform 13 5261 env52941 = env52942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env52941 == env52942) = true)

theorem identity52942 : scanCanonicalize (H12AffineFastState.compose env52942 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound52942 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52943 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,9,5261,32,171,5141,2216,1025,33,4145,33,184,138,129,49,2217,5308,4129,2216,1193,0,4,168,5292,680]

theorem envBound52943 : H12AffineFastState.Bounded env52943 := by
  intro p hp
  have h : env52943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52942_52943 : H12AffineEnvironment.transform 12 9 env52942 = env52943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env52942 == env52943) = true)

theorem identity52943 : scanCanonicalize (H12AffineFastState.compose env52943 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52943 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env52944 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,9,5125,32,35,5141,2080,1025,33,4145,33,48,2,9,49,2081,5172,4129,2080,1057,0,4,32,5156,544]

theorem envBound52944 : H12AffineFastState.Bounded env52944 := by
  intro p hp
  have h : env52944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52943_52944 : H12AffineEnvironment.transform 6 8 env52943 = env52944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52943 == env52944) = true)

theorem identity52944 : scanCanonicalize (H12AffineFastState.compose env52944 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52944 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52945 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,1,2,5141,2049,1025,0,4112,0,17,2,9,16,2048,5141,4096,2049,1024,0,4,1,5125,513]

theorem envBound52945 : H12AffineFastState.Bounded env52945 := by
  intro p hp
  have h : env52945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52944_52945 : H12AffineEnvironment.transform 4 1 env52944 = env52945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52944 == env52945) = true)

def env52946 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,131072,56324,1025,32769,4144,33,73754,41123,8328,48,171165,78879,91151,211998,1193,119815,5,21540,46213,74250]

theorem envBound52946 : H12AffineFastState.Bounded env52946 := by
  intro p hp
  have h : env52946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52937_52946 : H12AffineEnvironment.transform 5 49 env52937 = env52946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52937 == env52946) = true)

theorem identity52946 : scanCanonicalize (H12AffineFastState.compose env52946 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 111766) := by decide +kernel

theorem selectedBound52946 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env52947 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,111766,56324,1025,32769,4144,33,73754,41123,8328,48,75787,78879,91151,34952,1193,119815,5,21540,46213,74250]

theorem envBound52947 : H12AffineFastState.Bounded env52947 := by
  intro p hp
  have h : env52947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52946_52947 : H12AffineEnvironment.transform 16 111766 env52946 = env52947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111766 env52946 == env52947) = true)

theorem identity52947 : scanCanonicalize (H12AffineFastState.compose env52947 (packedSelected [3,4,5,8,20,22,23,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound52947 : packedSelected [3,4,5,8,20,22,23,28,32] rootPS < 2^1333 := by decide +kernel

def env52948 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,29831,49169,56324,1025,32769,4144,33,21661,41123,8328,48,23692,16536,4232,34952,1193,41088,5,21540,46213,22157]

theorem envBound52948 : H12AffineFastState.Bounded env52948 := by
  intro p hp
  have h : env52948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52947_52948 : H12AffineEnvironment.transform 15 29831 env52947 = env52948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env52947 == env52948) = true)

theorem identity52948 : scanCanonicalize (H12AffineFastState.compose env52948 (packedSelected [0,5,6,7,9,11,12,15,19,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound52948 : packedSelected [0,5,6,7,9,11,12,15,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env52949 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,16384,32768,21543,49169,56324,1025,32769,4144,33,21661,32771,40,48,23692,16536,4232,34952,1193,32800,5,21540,37925,22157]

theorem envBound52949 : H12AffineFastState.Bounded env52949 := by
  intro p hp
  have h : env52949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52948_52949 : H12AffineEnvironment.transform 12 160 env52948 = env52949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env52948 == env52949) = true)

theorem identity52949 : scanCanonicalize (H12AffineFastState.compose env52949 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52949 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env52950 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,16384,1,21543,16400,23557,1025,0,4144,33,21661,2,40,48,23692,16536,4232,2185,1193,33,5,21540,5156,22157]

theorem envBound52950 : H12AffineFastState.Bounded env52950 := by
  intro p hp
  have h : env52950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52949_52950 : H12AffineEnvironment.transform 14 1 env52949 = env52950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52949 == env52950) = true)

theorem identity52950 : scanCanonicalize (H12AffineFastState.compose env52950 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound52950 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env52951 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,5261,1,170,5277,2184,1025,0,4144,33,16,2,40,48,2049,5141,4232,2185,1193,33,5,169,5156,512]

theorem envBound52951 : H12AffineFastState.Bounded env52951 := by
  intro p hp
  have h : env52951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52950_52951 : H12AffineEnvironment.transform 13 5261 env52950 = env52951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env52950 == env52951) = true)

theorem identity52951 : scanCanonicalize (H12AffineFastState.compose env52951 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52952 : List Nat := [2,4,8,16,32,49,8,4,512,1024,2048,4096,40,5125,1,34,5141,2048,1025,0,4144,33,16,2,40,48,2049,5141,4096,2049,1057,33,5,33,5156,512]

theorem envBound52952 : H12AffineFastState.Bounded env52952 := by
  intro p hp
  have h : env52952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52951_52952 : H12AffineEnvironment.transform 6 8 env52951 = env52952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52951 == env52952) = true)

theorem identity52952 : scanCanonicalize (H12AffineFastState.compose env52952 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52952 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52953 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,8,5125,1,2,5141,2048,1025,0,4112,1,16,2,8,16,2049,5141,4096,2049,1025,1,5,1,5124,512]

theorem envBound52953 : H12AffineFastState.Bounded env52953 := by
  intro p hp
  have h : env52953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52952_52953 : H12AffineEnvironment.transform 4 0 env52952 = env52953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52952 == env52953) = true)

theorem identity52953 : scanCanonicalize (H12AffineFastState.compose env52953 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound52953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52954 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,17,8,1044,1,2,1028,2048,1025,0,1,1,16,2,8,16,2049,1028,17,2049,1025,1,5,1,1045,512]

theorem envBound52954 : H12AffineFastState.Bounded env52954 := by
  intro p hp
  have h : env52954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52953_52954 : H12AffineEnvironment.transform 11 17 env52953 = env52954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env52953 == env52954) = true)

theorem identity52954 : scanCanonicalize (H12AffineFastState.compose env52954 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound52954 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52955 : List Nat := [2,4,8,16,0,17,8,4,512,533,2048,17,8,513,1,2,529,2048,532,0,1,1,16,2,8,16,2049,529,17,2049,532,1,5,1,512,512]

theorem envBound52955 : H12AffineFastState.Bounded env52955 := by
  intro p hp
  have h : env52955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52954_52955 : H12AffineEnvironment.transform 9 533 env52954 = env52955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env52954 == env52955) = true)

theorem identity52955 : scanCanonicalize (H12AffineFastState.compose env52955 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52955 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52956 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,17,8,1,1,2,17,2048,20,0,1,1,16,2,8,16,2049,17,17,2049,20,1,5,1,0,0]

theorem envBound52956 : H12AffineFastState.Bounded env52956 := by
  intro p hp
  have h : env52956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52955_52956 : H12AffineEnvironment.transform 8 0 env52955 = env52956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52955 == env52956) = true)

theorem identity52956 : scanCanonicalize (H12AffineFastState.compose env52956 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound52956 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52957 : List Nat := [2,4,7,16,0,17,7,4,0,21,2048,17,7,1,1,2,17,2048,20,0,1,1,16,2,7,16,2049,17,17,2049,20,1,5,1,0,0]

theorem envBound52957 : H12AffineFastState.Bounded env52957 := by
  intro p hp
  have h : env52957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52956_52957 : H12AffineEnvironment.transform 2 7 env52956 = env52957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env52956 == env52957) = true)

def env52958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound52958 : H12AffineFastState.Bounded env52958 := by
  intro p hp
  have h : env52958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52474_52958 : H12AffineEnvironment.transform 26 30393345 env52474 = env52958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env52474 == env52958) = true)

def env52959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound52959 : H12AffineFastState.Bounded env52959 := by
  intro p hp
  have h : env52959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52958_52959 : H12AffineEnvironment.transform 18 1024 env52958 = env52959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env52958 == env52959) = true)

theorem identity52959 : scanCanonicalize (H12AffineFastState.compose env52959 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510136) := by decide +kernel

theorem selectedBound52959 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510136,8328,65,12585145,2509877,10507600,8830976,8801448,6729081,256,10882069,10939824,8874879]

theorem envBound52960 : H12AffineFastState.Bounded env52960 := by
  intro p hp
  have h : env52960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52959_52960 : H12AffineEnvironment.transform 23 510136 env52959 = env52960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510136 env52959 == env52960) = true)

def env52961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513204,510136,8328,65,6705549,2509877,396388,2136372,2102684,6729081,256,21793,46212,2175563]

theorem envBound52961 : H12AffineFastState.Bounded env52961 := by
  intro p hp
  have h : env52961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52960_52961 : H12AffineEnvironment.transform 22 2513204 env52960 = env52961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513204 env52960 == env52961) = true)

def env52962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513204,510136,8328,65,2409661,2509877,396388,2136372,2102684,2373705,256,21793,46212,2175563]

theorem envBound52962 : H12AffineFastState.Bounded env52962 := by
  intro p hp
  have h : env52962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52961_52962 : H12AffineEnvironment.transform 21 169264 env52961 = env52962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env52961 == env52962) = true)

def env52963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,510136,8328,65,316669,416885,396388,35188,1500,272393,256,21793,46212,74251]

theorem envBound52963 : H12AffineFastState.Bounded env52963 := by
  intro p hp
  have h : env52963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52962_52963 : H12AffineEnvironment.transform 20 4160 env52962 = env52963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52962 == env52963) = true)

theorem identity52963 : scanCanonicalize (H12AffineFastState.compose env52963 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52963 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,169264,412020,452786,8328,65,316669,416885,396388,35188,1500,272393,256,21793,46212,513]

theorem envBound52964 : H12AffineFastState.Bounded env52964 := by
  intro p hp
  have h : env52964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52963_52964 : H12AffineEnvironment.transform 15 8202 env52963 = env52964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52963 == env52964) = true)

def env52965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,54560,264548,305314,8328,65,316669,269413,281716,35188,1500,272393,256,21793,46212,513]

theorem envBound52965 : H12AffineFastState.Bounded env52965 := by
  intro p hp
  have h : env52965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52964_52965 : H12AffineEnvironment.transform 16 16400 env52964 = env52965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52964 == env52965) = true)

theorem identity52965 : scanCanonicalize (H12AffineFastState.compose env52965 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound52965 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,2420,1024,32769,4160,54560,16,41430,8328,65,56713,5393,17664,35188,1500,8573,256,21793,46212,513]

theorem envBound52966 : H12AffineFastState.Bounded env52966 := by
  intro p hp
  have h : env52966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52965_52966 : H12AffineEnvironment.transform 17 2420 env52965 = env52966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env52965 == env52966) = true)

theorem identity52966 : scanCanonicalize (H12AffineFastState.compose env52966 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound52966 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8202,16400,2420,1024,21897,4160,168,16,29790,8328,65,2049,5393,17664,23804,1500,8573,256,21793,24844,513]

theorem envBound52967 : H12AffineFastState.Bounded env52967 := by
  intro p hp
  have h : env52967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52966_52967 : H12AffineEnvironment.transform 14 21896 env52966 = env52967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env52966 == env52967) = true)

theorem identity52967 : scanCanonicalize (H12AffineFastState.compose env52967 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound52967 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env52968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21896,478,16400,2420,1024,21897,4160,168,16,21898,348,65,2049,5393,17664,23804,1500,169,256,21793,16600,513]

theorem envBound52968 : H12AffineFastState.Bounded env52968 := by
  intro p hp
  have h : env52968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52967_52968 : H12AffineEnvironment.transform 12 468 env52967 = env52968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env52967 == env52968) = true)

theorem identity52968 : scanCanonicalize (H12AffineFastState.compose env52968 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound52968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,1,478,5529,2420,1024,0,4160,168,16,3,348,65,2049,5393,4233,2421,1500,169,256,168,5457,513]

theorem envBound52969 : H12AffineFastState.Bounded env52969 := by
  intro p hp
  have h : env52969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52968_52969 : H12AffineEnvironment.transform 13 5513 env52968 = env52969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env52968 == env52969) = true)

theorem identity52969 : scanCanonicalize (H12AffineFastState.compose env52969 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52969 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env52970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,468,1417,1,478,1433,2420,1024,0,64,168,16,3,348,65,2049,1297,137,2421,1500,169,256,168,1361,513]

theorem envBound52970 : H12AffineFastState.Bounded env52970 := by
  intro p hp
  have h : env52970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52969_52970 : H12AffineEnvironment.transform 11 0 env52969 = env52970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52969 == env52970) = true)

theorem identity52970 : scanCanonicalize (H12AffineFastState.compose env52970 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound52970 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52971 : List Nat := [2,4,8,16,32,11,128,256,512,1024,2048,0,415,1417,1,405,1433,2367,1024,0,11,168,16,3,279,10,2049,1297,137,2366,1431,169,256,168,1306,513]

theorem envBound52971 : H12AffineFastState.Bounded env52971 := by
  intro p hp
  have h : env52971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52970_52971 : H12AffineEnvironment.transform 5 11 env52970 = env52971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env52970 == env52971) = true)

theorem identity52971 : scanCanonicalize (H12AffineFastState.compose env52971 (packedSelected [4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52971 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env52972 : List Nat := [2,4,8,16,32,11,128,256,512,272,2048,0,415,153,1,405,137,2367,272,0,11,168,16,3,279,10,2049,1,137,2366,135,169,256,168,10,513]

theorem envBound52972 : H12AffineFastState.Bounded env52972 := by
  intro p hp
  have h : env52972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52971_52972 : H12AffineEnvironment.transform 9 272 env52971 = env52972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52971 == env52972) = true)

def env52973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4160,54561,264549,305315,8328,65,316669,269412,281717,35188,1500,272393,256,21793,46212,513]

theorem envBound52973 : H12AffineFastState.Bounded env52973 := by
  intro p hp
  have h : env52973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52964_52973 : H12AffineEnvironment.transform 16 16401 env52964 = env52973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52964 == env52973) = true)

def env52974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4112,54561,264501,305315,8328,17,316589,269364,281637,35108,1420,272393,256,21793,46212,513]

theorem envBound52974 : H12AffineFastState.Bounded env52974 := by
  intro p hp
  have h : env52974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52973_52974 : H12AffineEnvironment.transform 5 16 env52973 = env52974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52973 == env52974) = true)

theorem identity52974 : scanCanonicalize (H12AffineFastState.compose env52974 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound52974 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env52975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32161,1024,32769,4112,54561,29844,54530,8328,17,43276,24981,12676,35108,1420,21928,256,21793,46212,513]

theorem envBound52975 : H12AffineFastState.Bounded env52975 := by
  intro p hp
  have h : env52975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52974_52975 : H12AffineEnvironment.transform 17 32161 env52974 = env52975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env52974 == env52975) = true)

theorem identity52975 : scanCanonicalize (H12AffineFastState.compose env52975 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52975 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env52976 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32041,1024,32769,4112,54561,29724,54530,8192,17,43276,24861,12556,35108,1284,21792,256,21793,46092,513]

theorem envBound52976 : H12AffineFastState.Bounded env52976 := by
  intro p hp
  have h : env52976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52975_52976 : H12AffineEnvironment.transform 6 8 env52975 = env52976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52975 == env52976) = true)

theorem identity52976 : scanCanonicalize (H12AffineFastState.compose env52976 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52976 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env52977 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,263,16401,23588,1024,32769,4112,54561,21777,54530,269,17,34817,16400,4097,35108,1284,21792,256,21793,38145,513]

theorem envBound52977 : H12AffineFastState.Bounded env52977 := by
  intro p hp
  have h : env52977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52976_52977 : H12AffineEnvironment.transform 12 269 env52976 = env52977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52976 == env52977) = true)

def env52978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4113,54561,264500,305315,8328,16,316588,269365,281636,35109,1421,272393,256,21793,46212,513]

theorem envBound52978 : H12AffineFastState.Bounded env52978 := by
  intro p hp
  have h : env52978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52973_52978 : H12AffineEnvironment.transform 5 17 env52973 = env52978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52973 == env52978) = true)

theorem identity52978 : scanCanonicalize (H12AffineFastState.compose env52978 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52978 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env52979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1024,32769,4113,54561,8476,32907,8328,16,64644,13341,25612,35109,1421,33,256,21793,46212,513]

theorem envBound52979 : H12AffineFastState.Bounded env52979 := by
  intro p hp
  have h : env52979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52978_52979 : H12AffineEnvironment.transform 17 10280 env52978 = env52979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52978 == env52979) = true)

theorem identity52979 : scanCanonicalize (H12AffineFastState.compose env52979 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 12465) := by decide +kernel

theorem selectedBound52979 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env52980 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,12465,32768,8202,12448,10280,1024,32769,4113,42384,8476,32907,8328,16,35893,13341,5309,35109,1421,33,256,9616,46212,513]

theorem envBound52980 : H12AffineFastState.Bounded env52980 := by
  intro p hp
  have h : env52980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52979_52980 : H12AffineEnvironment.transform 13 12465 env52979 = env52980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12465 env52979 == env52980) = true)

theorem identity52980 : scanCanonicalize (H12AffineFastState.compose env52980 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound52980 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env52981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1053,5292,32768,1047,5309,3125,1024,32769,4113,33165,1281,32907,1173,16,35893,4096,5309,35109,1421,33,256,397,37017,513]

theorem envBound52981 : H12AffineFastState.Bounded env52981 := by
  intro p hp
  have h : env52981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52980_52981 : H12AffineEnvironment.transform 12 1053 env52980 = env52981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env52980 == env52981) = true)

theorem identity52981 : scanCanonicalize (H12AffineFastState.compose env52981 (packedSelected [0,1,4,5,7,8,9,11,12,14,15,17,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52981 : packedSelected [0,1,4,5,7,8,9,11,12,14,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env52982 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1053,5292,32768,1047,5309,3125,1024,32769,4113,32937,1061,32907,1173,16,35893,4096,5309,34817,1193,33,36,169,37017,513]

theorem envBound52982 : H12AffineFastState.Bounded env52982 := by
  intro p hp
  have h : env52982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52981_52982 : H12AffineEnvironment.transform 7 36 env52981 = env52982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52981 == env52982) = true)

theorem identity52982 : scanCanonicalize (H12AffineFastState.compose env52982 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52982 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env52983 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,1053,5156,32768,1047,5173,3125,1024,32769,4113,32801,1061,32771,1053,16,35893,4096,5173,34817,1057,33,36,33,36881,513]

theorem envBound52983 : H12AffineFastState.Bounded env52983 := by
  intro p hp
  have h : env52983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52982_52983 : H12AffineEnvironment.transform 6 8 env52982 = env52983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52982 == env52983) = true)

theorem identity52983 : scanCanonicalize (H12AffineFastState.compose env52983 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52983 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52984 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1053,3125,32768,1047,3108,3125,1024,32769,2048,32801,1061,32771,1053,16,35893,2065,3108,34817,1057,33,36,33,34816,513]

theorem envBound52984 : H12AffineFastState.Bounded env52984 := by
  intro p hp
  have h : env52984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52983_52984 : H12AffineEnvironment.transform 11 2065 env52983 = env52984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52983 == env52984) = true)

theorem identity52984 : scanCanonicalize (H12AffineFastState.compose env52984 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52984 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52985 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1053,3125,1077,1047,3108,3125,1024,1076,2048,1044,1061,1078,1053,16,2048,2065,3108,3124,1057,33,36,33,3125,513]

theorem envBound52985 : H12AffineFastState.Bounded env52985 := by
  intro p hp
  have h : env52985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52984_52985 : H12AffineEnvironment.transform 14 1077 env52984 = env52985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env52984 == env52985) = true)

theorem identity52985 : scanCanonicalize (H12AffineFastState.compose env52985 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound52985 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52986 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1588,1573,1053,513,1077,1047,528,513,1024,1076,1588,1044,1061,1078,1053,16,1588,1573,528,512,1057,33,36,33,513,513]

theorem envBound52986 : H12AffineFastState.Bounded env52986 := by
  intro p hp
  have h : env52986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52985_52986 : H12AffineEnvironment.transform 10 1588 env52985 = env52986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env52985 == env52986) = true)

theorem identity52986 : scanCanonicalize (H12AffineFastState.compose env52986 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52987 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1557,1540,1053,513,1044,1047,528,513,1024,1045,1557,1044,1028,1047,1053,16,1557,1540,528,512,1024,0,5,0,513,513]

theorem envBound52987 : H12AffineFastState.Bounded env52987 := by
  intro p hp
  have h : env52987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52986_52987 : H12AffineEnvironment.transform 4 1 env52986 = env52987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52986 == env52987) = true)

theorem identity52987 : scanCanonicalize (H12AffineFastState.compose env52987 (packedSelected [1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52987 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env52988 : List Nat := [2,4,8,16,1,17,8,5,512,20,513,528,9,513,0,3,528,513,20,1,513,0,16,3,9,16,513,528,528,512,20,0,5,0,513,513]

theorem envBound52988 : H12AffineFastState.Bounded env52988 := by
  intro p hp
  have h : env52988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52987_52988 : H12AffineEnvironment.transform 9 20 env52987 = env52988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52987 == env52988) = true)

theorem identity52988 : scanCanonicalize (H12AffineFastState.compose env52988 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52989 : List Nat := [2,4,8,16,1,17,8,5,0,20,1,16,9,1,0,3,16,1,20,1,1,0,16,3,9,16,1,16,16,0,20,0,5,0,1,1]

theorem envBound52989 : H12AffineFastState.Bounded env52989 := by
  intro p hp
  have h : env52989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52988_52989 : H12AffineEnvironment.transform 8 0 env52988 = env52989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52988 == env52989) = true)

def env52990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,510136,8328,65,316668,416884,396388,35189,1501,272392,256,21793,46212,74250]

theorem envBound52990 : H12AffineFastState.Bounded env52990 := by
  intro p hp
  have h : env52990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52962_52990 : H12AffineEnvironment.transform 20 4161 env52962 = env52990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52962 == env52990) = true)

theorem identity52990 : scanCanonicalize (H12AffineFastState.compose env52990 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound52990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,4161,169264,120014,21763,8328,65,215367,115151,102879,35189,1501,243123,256,21793,46212,74250]

theorem envBound52991 : H12AffineFastState.Bounded env52991 := by
  intro p hp
  have h : env52991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52990_52991 : H12AffineEnvironment.transform 17 236987 env52990 = env52991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env52990 == env52991) = true)

def env52992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130175,1024,32769,4161,62708,120014,21763,8328,65,75907,115151,102879,35189,1501,119927,256,21793,46212,74250]

theorem envBound52992 : H12AffineFastState.Bounded env52992 := by
  intro p hp
  have h : env52992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52991_52992 : H12AffineEnvironment.transform 16 25028 env52991 = env52992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env52991 == env52992) = true)

theorem identity52992 : scanCanonicalize (H12AffineFastState.compose env52992 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound52992 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env52993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,25028,64929,1024,32769,4161,62708,54544,21763,8328,65,10589,49169,36865,35189,1501,54697,256,21793,46212,9172]

theorem envBound52993 : H12AffineFastState.Bounded env52993 := by
  intro p hp
  have h : env52993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52992_52993 : H12AffineEnvironment.transform 15 478 env52992 = env52993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env52992 == env52993) = true)

theorem identity52993 : scanCanonicalize (H12AffineFastState.compose env52993 (packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound52993 : packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS < 2^1333 := by decide +kernel

def env52994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29829,478,25028,2340,1024,29828,4161,113,8597,21763,8328,65,10589,13460,25732,32240,1501,8492,256,21793,16385,9172]

theorem envBound52994 : H12AffineFastState.Bounded env52994 := by
  intro p hp
  have h : env52994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52993_52994 : H12AffineEnvironment.transform 14 29829 env52993 = env52994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env52993 == env52994) = true)

theorem identity52994 : scanCanonicalize (H12AffineFastState.compose env52994 (packedSelected [0,3,4,7,10,17,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound52994 : packedSelected [0,3,4,7,10,17,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,1,478,5440,2340,1024,0,4161,113,8597,8583,8328,65,10589,13460,4096,2420,1501,8492,256,8613,13445,9172]

theorem envBound52995 : H12AffineFastState.Bounded env52995 := by
  intro p hp
  have h : env52995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52994_52995 : H12AffineEnvironment.transform 13 13444 env52994 = env52995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env52994 == env52995) = true)

theorem identity52995 : scanCanonicalize (H12AffineFastState.compose env52995 (packedSelected [0,3,5,6,7,11,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52995 : packedSelected [0,3,5,6,7,11,14,16] rootPS < 2^1333 := by decide +kernel

def env52996 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,13357,1,375,5440,2340,1024,0,4161,113,8508,8494,8225,65,10589,13373,4096,2420,1396,8492,256,8460,13356,9085]

theorem envBound52996 : H12AffineFastState.Bounded env52996 := by
  intro p hp
  have h : env52996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52995_52996 : H12AffineEnvironment.transform 6 41 env52995 = env52996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52995 == env52996) = true)

theorem identity52996 : scanCanonicalize (H12AffineFastState.compose env52996 (packedSelected [0,3,5,6,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52996 : packedSelected [0,3,5,6,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env52997 : List Nat := [2,4,8,16,32,64,41,4,512,1024,2048,4096,8192,13357,1,115,5188,2080,1024,0,4161,113,8248,8234,8225,65,10329,13373,4096,2160,1136,8232,4,8200,13356,8825]

theorem envBound52997 : H12AffineFastState.Bounded env52997 := by
  intro p hp
  have h : env52997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52996_52997 : H12AffineEnvironment.transform 7 4 env52996 = env52997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52996 == env52997) = true)

def env52998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130174,1024,32769,4161,62709,120014,21763,8328,65,75906,115151,102879,35189,1501,119926,256,21793,46212,74250]

theorem envBound52998 : H12AffineFastState.Bounded env52998 := by
  intro p hp
  have h : env52998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52991_52998 : H12AffineEnvironment.transform 16 25029 env52991 = env52998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env52991 == env52998) = true)

theorem identity52998 : scanCanonicalize (H12AffineFastState.compose env52998 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound52998 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env52999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,16401,122282,1024,32769,4161,54561,120014,21763,348,65,67926,115151,102879,35189,1501,119926,256,21793,38224,66526]

theorem envBound52999 : H12AffineFastState.Bounded env52999 := by
  intro p hp
  have h : env52999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52998_52999 : H12AffineEnvironment.transform 12 468 env52998 = env52999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env52998 == env52999) = true)

theorem identity52999 : scanCanonicalize (H12AffineFastState.compose env52999 (packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound52999 : packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS < 2^1333 := by decide +kernel

def env53000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,32768,65536,5529,100386,1024,32769,4161,32937,98630,139,348,65,67926,103495,102879,35189,1501,98814,256,169,38224,66526]

theorem envBound53000 : H12AffineFastState.Bounded env53000 := by
  intro p hp
  have h : env53000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52999_53000 : H12AffineEnvironment.transform 13 5512 env52999 = env53000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env52999 == env53000) = true)

theorem identity53000 : scanCanonicalize (H12AffineFastState.compose env53000 (packedSelected [0,3,4,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound53000 : packedSelected [0,3,4,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env53001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,81,65536,5529,67699,1024,80,4161,248,65815,139,348,65,67926,70678,70030,2340,1501,65967,256,169,5377,66526]

theorem envBound53001 : H12AffineFastState.Bounded env53001 := by
  intro p hp
  have h : env53001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53000_53001 : H12AffineEnvironment.transform 14 81 env53000 = env53001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env53000 == env53001) = true)

theorem identity53001 : scanCanonicalize (H12AffineFastState.compose env53001 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound53001 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,81,114,5529,2049,1024,80,4161,248,357,139,348,65,2340,5220,4604,2340,1501,477,256,169,5377,940]

theorem envBound53002 : H12AffineFastState.Bounded env53002 := by
  intro p hp
  have h : env53002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53001_53002 : H12AffineEnvironment.transform 15 114 env53001 = env53002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env53001 == env53002) = true)

theorem identity53002 : scanCanonicalize (H12AffineFastState.compose env53002 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53002 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53003 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,1,34,5529,2049,1024,0,4113,168,309,139,268,17,2340,5172,4524,2340,1421,397,256,169,5377,940]

theorem envBound53003 : H12AffineFastState.Bounded env53003 := by
  intro p hp
  have h : env53003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53002_53003 : H12AffineEnvironment.transform 5 16 env53002 = env53003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53002 == env53003) = true)

theorem identity53003 : scanCanonicalize (H12AffineFastState.compose env53003 (packedSelected [0,1,3,4,5,6,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53003 : packedSelected [0,1,3,4,5,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env53004 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,388,4249,1,34,4232,2049,273,0,4113,168,309,139,268,17,2340,4389,4524,2340,156,397,256,169,4112,940]

theorem envBound53004 : H12AffineFastState.Bounded env53004 := by
  intro p hp
  have h : env53004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53003_53004 : H12AffineEnvironment.transform 9 273 env53003 = env53004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53003 == env53004) = true)

theorem identity53004 : scanCanonicalize (H12AffineFastState.compose env53004 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53004 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53005 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,4113,1,34,4096,2049,273,0,4113,32,309,3,268,17,2340,4389,4388,2340,20,261,256,33,4112,804]

theorem envBound53005 : H12AffineFastState.Bounded env53005 := by
  intro p hp
  have h : env53005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53004_53005 : H12AffineEnvironment.transform 6 8 env53004 = env53005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53004 == env53005) = true)

theorem identity53005 : scanCanonicalize (H12AffineFastState.compose env53005 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2847) := by decide +kernel

theorem selectedBound53005 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53006 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2847,268,2830,1,34,2847,2049,273,0,2830,32,309,3,268,17,2340,2618,2619,2340,20,261,256,33,2831,804]

theorem envBound53006 : H12AffineFastState.Bounded env53006 := by
  intro p hp
  have h : env53006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53005_53006 : H12AffineEnvironment.transform 11 2847 env53005 = env53006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2847 env53005 == env53006) = true)

theorem identity53006 : scanCanonicalize (H12AffineFastState.compose env53006 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53006 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env53007 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,2847,268,2830,1,2,2847,2049,273,0,2830,0,277,3,268,17,2308,2586,2587,2308,20,261,256,1,2831,772]

theorem envBound53007 : H12AffineFastState.Bounded env53007 := by
  intro p hp
  have h : env53007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53006_53007 : H12AffineEnvironment.transform 4 0 env53006 = env53007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53006 == env53007) = true)

theorem identity53007 : scanCanonicalize (H12AffineFastState.compose env53007 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53008 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2587,8,2570,1,2,2587,2049,21,0,2570,0,17,3,8,17,2048,2586,2587,2048,20,1,4,1,2571,512]

theorem envBound53008 : H12AffineFastState.Bounded env53008 := by
  intro p hp
  have h : env53008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53007_53008 : H12AffineEnvironment.transform 7 4 env53007 = env53008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53007 == env53008) = true)

theorem identity53008 : scanCanonicalize (H12AffineFastState.compose env53008 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound53008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53009 : List Nat := [2,4,8,16,0,16,8,4,512,21,517,30,8,15,1,2,30,516,21,0,15,0,17,3,8,17,517,31,30,517,20,1,4,1,14,512]

theorem envBound53009 : H12AffineFastState.Bounded env53009 := by
  intro p hp
  have h : env53009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53008_53009 : H12AffineEnvironment.transform 10 517 env53008 = env53009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env53008 == env53009) = true)

theorem identity53009 : scanCanonicalize (H12AffineFastState.compose env53009 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound53009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53010 : List Nat := [2,4,8,6,0,6,8,4,512,3,517,8,8,15,1,2,8,516,3,0,15,0,7,3,8,7,517,9,8,517,2,1,4,1,14,512]

theorem envBound53010 : H12AffineFastState.Bounded env53010 := by
  intro p hp
  have h : env53010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53009_53010 : H12AffineEnvironment.transform 3 6 env53009 = env53010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env53009 == env53010) = true)

theorem identity53010 : scanCanonicalize (H12AffineFastState.compose env53010 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound53010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53011 : List Nat := [2,4,7,6,0,6,7,4,512,3,517,7,7,0,1,2,7,516,3,0,0,0,7,3,7,7,517,6,7,517,2,1,4,1,1,512]

theorem envBound53011 : H12AffineFastState.Bounded env53011 := by
  intro p hp
  have h : env53011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53010_53011 : H12AffineEnvironment.transform 2 7 env53010 = env53011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env53010 == env53011) = true)

theorem identity53011 : scanCanonicalize (H12AffineFastState.compose env53011 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound53011 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53012 : List Nat := [2,4,7,6,0,6,7,4,5,3,0,7,7,0,1,2,7,1,3,0,0,0,7,3,7,7,0,6,7,0,2,1,4,1,1,5]

theorem envBound53012 : H12AffineFastState.Bounded env53012 := by
  intro p hp
  have h : env53012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53011_53012 : H12AffineEnvironment.transform 8 5 env53011 = env53012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env53011 == env53012) = true)

def env53013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513204,510136,8328,65,2409660,2509877,396388,2136372,2102684,2373704,256,21793,46212,2175563]

theorem envBound53013 : H12AffineFastState.Bounded env53013 := by
  intro p hp
  have h : env53013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52961_53013 : H12AffineEnvironment.transform 21 169265 env52961 = env53013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env52961 == env53013) = true)

def env53014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,510136,8328,65,316668,416885,396388,35188,1500,272392,256,21793,46212,74251]

theorem envBound53014 : H12AffineFastState.Bounded env53014 := by
  intro p hp
  have h : env53014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53013_53014 : H12AffineEnvironment.transform 20 4160 env53013 = env53014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53013 == env53014) = true)

theorem identity53014 : scanCanonicalize (H12AffineFastState.compose env53014 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound53014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,169265,73754,41430,8328,65,245138,79131,91402,35188,1500,213350,256,21793,46212,74251]

theorem envBound53015 : H12AffineFastState.Bounded env53015 := by
  intro p hp
  have h : env53015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53014_53015 : H12AffineEnvironment.transform 17 223598 env53014 = env53015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env53014 == env53015) = true)

def env53016 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4112,169265,73754,41350,8328,17,245138,79131,91402,35108,1420,213302,256,21793,46212,74251]

theorem envBound53016 : H12AffineFastState.Bounded env53016 := by
  intro p hp
  have h : env53016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53015_53016 : H12AffineEnvironment.transform 5 16 env53015 = env53016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53015 == env53016) = true)

theorem identity53016 : scanCanonicalize (H12AffineFastState.compose env53016 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound53016 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env53017 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,108967,1024,32769,4112,21928,73754,41350,8328,17,97547,79131,91402,35108,1420,98735,256,21793,46212,74251]

theorem envBound53017 : H12AffineFastState.Bounded env53017 := by
  intro p hp
  have h : env53017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53016_53017 : H12AffineEnvironment.transform 16 49305 env53016 = env53017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env53016 == env53017) = true)

theorem identity53017 : scanCanonicalize (H12AffineFastState.compose env53017 (packedSelected [0,1,4,7,11,16,17,20,22,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound53017 : packedSelected [0,1,4,7,11,16,17,20,22,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env53018 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40970,49305,2477,1024,32769,4112,21928,32784,41350,8328,17,56577,38161,50432,35108,1420,8613,256,21793,46212,33281]

theorem envBound53018 : H12AffineFastState.Bounded env53018 := by
  intro p hp
  have h : env53018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53017_53018 : H12AffineEnvironment.transform 15 40970 env53017 = env53018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env53017 == env53018) = true)

theorem identity53018 : scanCanonicalize (H12AffineFastState.compose env53018 (packedSelected [1,5,8,16,18,19,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound53018 : packedSelected [1,5,8,16,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,21647,13340,2477,1024,29828,4112,21928,29845,21763,8328,17,10628,24980,12677,32161,1420,8613,256,21793,16385,30340]

theorem envBound53019 : H12AffineFastState.Bounded env53019 := by
  intro p hp
  have h : env53019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53018_53019 : H12AffineEnvironment.transform 14 29829 env53018 = env53019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env53018 == env53019) = true)

theorem identity53019 : scanCanonicalize (H12AffineFastState.compose env53019 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13477) := by decide +kernel

theorem selectedBound53019 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env53020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13477,32,8234,13340,2477,1024,33,4112,8461,48,8614,8328,17,10628,5425,12677,2308,1420,8613,256,8580,13476,545]

theorem envBound53020 : H12AffineFastState.Bounded env53020 := by
  intro p hp
  have h : env53020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53019_53020 : H12AffineEnvironment.transform 13 13477 env53019 = env53020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13477 env53019 == env53020) = true)

theorem identity53020 : scanCanonicalize (H12AffineFastState.compose env53020 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53020 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env53021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5545,32,294,5392,2477,1024,33,4112,1,48,170,388,17,2184,5425,4233,2308,1420,169,256,136,5544,545]

theorem envBound53021 : H12AffineFastState.Bounded env53021 := by
  intro p hp
  have h : env53021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53020_53021 : H12AffineEnvironment.transform 12 268 env53020 = env53021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53020 == env53021) = true)

theorem identity53021 : scanCanonicalize (H12AffineFastState.compose env53021 (packedSelected [0,3,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound53021 : packedSelected [0,3,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2608,268,3993,32,294,3872,2477,1024,33,2592,1,48,170,388,17,2184,3841,2745,2308,1420,169,256,136,3992,545]

theorem envBound53022 : H12AffineFastState.Bounded env53022 := by
  intro p hp
  have h : env53022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53021_53022 : H12AffineEnvironment.transform 11 2608 env53021 = env53022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env53021 == env53022) = true)

theorem identity53022 : scanCanonicalize (H12AffineFastState.compose env53022 (packedSelected [3,5,6,7,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 669) := by decide +kernel

theorem selectedBound53022 : packedSelected [3,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env53023 : List Nat := [2,4,8,16,32,16,128,256,512,669,2048,2608,268,2308,32,294,2493,2477,669,33,2592,1,48,170,388,17,2184,2460,2745,2308,785,169,256,136,2309,545]

theorem envBound53023 : H12AffineFastState.Bounded env53023 := by
  intro p hp
  have h : env53023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53022_53023 : H12AffineEnvironment.transform 9 669 env53022 = env53023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 669 env53022 == env53023) = true)

theorem identity53023 : scanCanonicalize (H12AffineFastState.compose env53023 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound53023 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53024 : List Nat := [2,4,8,16,32,16,128,256,512,669,821,261,268,561,32,294,648,664,669,33,277,1,48,170,388,17,957,681,396,561,785,169,256,136,560,545]

theorem envBound53024 : H12AffineFastState.Bounded env53024 := by
  intro p hp
  have h : env53024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53023_53024 : H12AffineEnvironment.transform 10 821 env53023 = env53024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env53023 == env53024) = true)

theorem identity53024 : scanCanonicalize (H12AffineFastState.compose env53024 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound53024 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env53025 : List Nat := [2,4,8,16,32,16,128,256,185,36,396,261,268,136,32,294,49,33,36,33,277,1,48,170,388,17,260,16,396,136,424,169,256,136,137,152]

theorem envBound53025 : H12AffineFastState.Bounded env53025 := by
  intro p hp
  have h : env53025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53024_53025 : H12AffineEnvironment.transform 8 185 env53024 = env53025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env53024 == env53025) = true)

theorem identity53025 : scanCanonicalize (H12AffineFastState.compose env53025 (packedSelected [0,1,3,4,5,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound53025 : packedSelected [0,1,3,4,5,8,10,14] rootPS < 2^1333 := by decide +kernel

def env53026 : List Nat := [2,4,8,16,32,16,128,172,185,36,32,169,160,136,32,138,49,33,36,33,185,1,48,170,40,17,168,16,32,136,4,169,172,136,137,152]

theorem envBound53026 : H12AffineFastState.Bounded env53026 := by
  intro p hp
  have h : env53026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53025_53026 : H12AffineEnvironment.transform 7 172 env53025 = env53026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53025 == env53026) = true)

def env53027 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4113,169265,73754,41351,8328,16,245138,79131,91402,35109,1421,213303,256,21793,46212,74251]

theorem envBound53027 : H12AffineFastState.Bounded env53027 := by
  intro p hp
  have h : env53027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53015_53027 : H12AffineEnvironment.transform 5 17 env53015 = env53027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53015 == env53027) = true)

theorem identity53027 : scanCanonicalize (H12AffineFastState.compose env53027 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 82335) := by decide +kernel

theorem selectedBound53027 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env53028 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,10400,1024,32769,4113,119982,73754,41351,8328,16,64525,79131,91402,35109,1421,168,256,21793,46212,74251]

theorem envBound53028 : H12AffineFastState.Bounded env53028 := by
  intro p hp
  have h : env53028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53027_53028 : H12AffineEnvironment.transform 16 82335 env53027 = env53028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82335 env53027 == env53028) = true)

theorem identity53028 : scanCanonicalize (H12AffineFastState.compose env53028 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound53028 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53029 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,65536,82335,10400,1024,8580,4113,95531,73754,2,8328,16,23944,79131,91402,10400,1421,168,256,21793,5377,74251]

theorem envBound53029 : H12AffineFastState.Bounded env53029 := by
  intro p hp
  have h : env53029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53028_53029 : H12AffineEnvironment.transform 14 8581 env53028 = env53029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env53028 == env53029) = true)

theorem identity53029 : scanCanonicalize (H12AffineFastState.compose env53029 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53029 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53030 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8203,24980,10400,1024,8580,4113,21792,17,2,8328,16,23944,5392,17665,10400,1421,168,256,21793,5377,512]

theorem envBound53030 : H12AffineFastState.Bounded env53030 := by
  intro p hp
  have h : env53030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53029_53030 : H12AffineEnvironment.transform 15 8203 env53029 = env53030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53029 == env53030) = true)

theorem identity53030 : scanCanonicalize (H12AffineFastState.compose env53030 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53030 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53031 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,16384,429,35,16828,2184,1024,428,4113,21792,17,2,160,16,23944,5392,17665,2184,1421,168,256,21793,5377,512]

theorem envBound53031 : H12AffineFastState.Bounded env53031 := by
  intro p hp
  have h : env53031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53030_53031 : H12AffineEnvironment.transform 12 40 env53030 = env53031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53030 == env53031) = true)

theorem identity53031 : scanCanonicalize (H12AffineFastState.compose env53031 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53031 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env53032 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,16384,396,2,16797,2184,1024,397,4113,21761,17,2,129,16,23944,5392,17665,2184,1421,137,256,21760,5377,512]

theorem envBound53032 : H12AffineFastState.Bounded env53032 := by
  intro p hp
  have h : env53032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53031_53032 : H12AffineEnvironment.transform 4 1 env53031 = env53032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53031 == env53032) = true)

theorem identity53032 : scanCanonicalize (H12AffineFastState.compose env53032 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound53032 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env53033 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,5125,396,2,5528,2184,1024,397,4113,260,17,2,129,16,2445,5392,4356,2184,1421,137,256,261,5377,512]

theorem envBound53033 : H12AffineFastState.Bounded env53033 := by
  intro p hp
  have h : env53033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53032_53033 : H12AffineEnvironment.transform 13 5125 env53032 = env53033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env53032 == env53033) = true)

theorem identity53033 : scanCanonicalize (H12AffineFastState.compose env53033 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound53033 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53034 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,4096,9,5125,1,2,5141,2184,1024,0,4113,137,17,2,129,16,2048,5277,4233,2184,1024,137,141,136,5260,512]

theorem envBound53034 : H12AffineFastState.Bounded env53034 := by
  intro p hp
  have h : env53034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53033_53034 : H12AffineEnvironment.transform 7 141 env53033 = env53034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env53033 == env53034) = true)

theorem identity53034 : scanCanonicalize (H12AffineFastState.compose env53034 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound53034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53035 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,136,9,1165,1,2,1181,2184,1024,0,153,137,17,2,129,16,2048,1045,1,2184,1024,137,141,136,1028,512]

theorem envBound53035 : H12AffineFastState.Bounded env53035 := by
  intro p hp
  have h : env53035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53034_53035 : H12AffineEnvironment.transform 11 136 env53034 = env53035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env53034 == env53035) = true)

theorem identity53035 : scanCanonicalize (H12AffineFastState.compose env53035 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound53035 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env53036 : List Nat := [2,4,8,16,1,17,128,141,512,1024,1054,136,9,1165,1,2,1181,1174,1024,0,153,137,17,2,129,16,1054,1045,1,1174,1024,137,141,136,1028,512]

theorem envBound53036 : H12AffineFastState.Bounded env53036 := by
  intro p hp
  have h : env53036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53035_53036 : H12AffineEnvironment.transform 10 1054 env53035 = env53036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env53035 == env53036) = true)

def env53037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,510136,8328,65,316669,416884,396388,35189,1501,272393,256,21793,46212,74250]

theorem envBound53037 : H12AffineFastState.Bounded env53037 := by
  intro p hp
  have h : env53037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53013_53037 : H12AffineEnvironment.transform 20 4161 env53013 = env53037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53013 == env53037) = true)

theorem identity53037 : scanCanonicalize (H12AffineFastState.compose env53037 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound53037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,169265,412021,400486,8328,65,316669,416884,396388,35189,1501,272393,256,21793,46212,63188]

theorem envBound53038 : H12AffineFastState.Bounded env53038 := by
  intro p hp
  have h : env53038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53037_53038 : H12AffineEnvironment.transform 15 54494 env53037 = env53038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env53037 == env53038) = true)

def env53039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1024,32769,4161,54641,264501,285734,8328,65,316669,269364,281636,35189,1501,272393,256,21793,46212,63188]

theorem envBound53039 : H12AffineFastState.Bounded env53039 := by
  intro p hp
  have h : env53039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53038_53039 : H12AffineEnvironment.transform 16 16448 env53038 = env53039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env53038 == env53039) = true)

theorem identity53039 : scanCanonicalize (H12AffineFastState.compose env53039 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound53039 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,56436,1024,32769,4161,54641,54593,32850,8328,65,2185,49216,36944,35189,1501,62589,256,21793,46212,63188]

theorem envBound53040 : H12AffineFastState.Bounded env53040 := by
  intro p hp
  have h : env53040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53039_53040 : H12AffineEnvironment.transform 17 56436 env53039 = env53040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env53039 == env53040) = true)

theorem identity53040 : scanCanonicalize (H12AffineFastState.compose env53040 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound53040 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env53041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,21510,16448,23724,1024,217,4161,21929,21913,138,8328,65,2185,16536,4232,2477,1501,29861,256,21793,13404,30220]

theorem envBound53041 : H12AffineFastState.Bounded env53041 := by
  intro p hp
  have h : env53041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53040_53041 : H12AffineEnvironment.transform 14 216 env53040 = env53041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env53040 == env53041) = true)

theorem identity53041 : scanCanonicalize (H12AffineFastState.compose env53041 (packedSelected [3,5,9,12,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53041 : packedSelected [3,5,9,12,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,216,262,5440,2476,1024,217,4161,169,153,138,8328,65,2185,5528,4232,2477,1501,8613,256,33,13404,8972]

theorem envBound53042 : H12AffineFastState.Bounded env53042 := by
  intro p hp
  have h : env53042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53041_53042 : H12AffineEnvironment.transform 13 5376 env53041 = env53042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53041 == env53042) = true)

theorem identity53042 : scanCanonicalize (H12AffineFastState.compose env53042 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53042 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env53043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,216,262,5440,2476,1024,217,4161,169,153,138,389,65,2185,5528,4232,2477,1501,168,256,33,5457,513]

theorem envBound53043 : H12AffineFastState.Bounded env53043 := by
  intro p hp
  have h : env53043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53042_53043 : H12AffineEnvironment.transform 12 269 env53042 = env53043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53042 == env53043) = true)

theorem identity53043 : scanCanonicalize (H12AffineFastState.compose env53043 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53043 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,262,5440,2341,1024,80,4161,32,16,3,268,65,2048,5393,4097,2340,1364,33,256,33,5457,513]

theorem envBound53044 : H12AffineFastState.Bounded env53044 := by
  intro p hp
  have h : env53044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53043_53044 : H12AffineEnvironment.transform 6 9 env53043 = env53044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53043 == env53044) = true)

theorem identity53044 : scanCanonicalize (H12AffineFastState.compose env53044 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound53044 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53045 : List Nat := [2,4,8,16,32,64,9,256,512,768,2048,4096,269,4608,81,262,4672,2341,768,80,4161,32,16,3,268,65,2048,4625,4097,2340,596,33,256,33,4689,513]

theorem envBound53045 : H12AffineFastState.Bounded env53045 := by
  intro p hp
  have h : env53045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53044_53045 : H12AffineEnvironment.transform 9 768 env53044 = env53045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env53044 == env53045) = true)

theorem identity53045 : scanCanonicalize (H12AffineFastState.compose env53045 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound53045 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53046 : List Nat := [2,4,8,16,32,49,9,256,512,768,2048,4096,269,4608,32,262,4657,2341,768,33,4144,32,16,3,268,48,2048,4625,4097,2340,549,33,256,33,4640,513]

theorem envBound53046 : H12AffineFastState.Bounded env53046 := by
  intro p hp
  have h : env53046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53045_53046 : H12AffineEnvironment.transform 5 49 env53045 = env53046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env53045 == env53046) = true)

theorem identity53046 : scanCanonicalize (H12AffineFastState.compose env53046 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound53046 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53047 : List Nat := [2,4,8,16,32,49,9,256,512,768,48,4096,269,4608,32,262,4657,277,768,33,4144,32,16,3,268,48,48,4625,4097,276,549,33,256,33,4640,513]

theorem envBound53047 : H12AffineFastState.Bounded env53047 := by
  intro p hp
  have h : env53047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53046_53047 : H12AffineEnvironment.transform 10 48 env53046 = env53047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env53046 == env53047) = true)

theorem identity53047 : scanCanonicalize (H12AffineFastState.compose env53047 (packedSelected [0,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53047 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env53048 : List Nat := [2,4,8,16,32,49,9,256,16,272,48,4096,269,4112,32,262,4129,277,272,33,4144,32,16,3,268,48,48,4097,4097,276,53,33,256,33,4144,17]

theorem envBound53048 : H12AffineFastState.Bounded env53048 := by
  intro p hp
  have h : env53048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53047_53048 : H12AffineEnvironment.transform 8 16 env53047 = env53048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53047 == env53048) = true)

theorem identity53048 : scanCanonicalize (H12AffineFastState.compose env53048 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound53048 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env53049 : List Nat := [2,4,8,16,17,0,9,256,16,272,1,4096,269,4112,17,262,4112,277,272,16,4097,17,16,3,268,1,1,4097,4097,276,4,16,256,16,4097,17]

theorem envBound53049 : H12AffineFastState.Bounded env53049 := by
  intro p hp
  have h : env53049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53048_53049 : H12AffineEnvironment.transform 4 17 env53048 = env53049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env53048 == env53049) = true)

theorem identity53049 : scanCanonicalize (H12AffineFastState.compose env53049 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound53049 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env53050 : List Nat := [2,4,8,16,17,0,9,256,16,272,1,17,269,1,17,262,1,277,272,16,16,17,16,3,268,1,1,16,16,276,4,16,256,16,16,17]

theorem envBound53050 : H12AffineFastState.Bounded env53050 := by
  intro p hp
  have h : env53050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53049_53050 : H12AffineEnvironment.transform 11 17 env53049 = env53050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53049 == env53050) = true)

theorem identity53050 : scanCanonicalize (H12AffineFastState.compose env53050 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53051 : List Nat := [2,4,8,16,17,0,9,5,16,21,1,17,8,1,17,3,1,16,21,16,16,17,16,3,9,1,1,16,16,17,4,16,5,16,16,17]

theorem envBound53051 : H12AffineFastState.Bounded env53051 := by
  intro p hp
  have h : env53051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53050_53051 : H12AffineEnvironment.transform 7 5 env53050 = env53051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53050 == env53051) = true)

theorem identity53051 : scanCanonicalize (H12AffineFastState.compose env53051 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53051 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53052 : List Nat := [2,4,8,1,0,0,9,5,1,4,1,0,8,1,0,3,1,1,4,1,1,0,1,3,9,1,1,1,1,0,4,1,5,1,1,0]

theorem envBound53052 : H12AffineFastState.Bounded env53052 := by
  intro p hp
  have h : env53052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53051_53052 : H12AffineEnvironment.transform 3 1 env53051 = env53052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53051 == env53052) = true)

theorem identity53052 : scanCanonicalize (H12AffineFastState.compose env53052 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53052 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53053 : List Nat := [2,1,8,1,0,0,9,0,1,1,1,0,8,1,0,3,1,1,1,1,1,0,1,3,9,1,1,1,1,0,1,1,0,1,1,0]

theorem envBound53053 : H12AffineFastState.Bounded env53053 := by
  intro p hp
  have h : env53053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53052_53053 : H12AffineEnvironment.transform 1 1 env53052 = env53053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53052 == env53053) = true)

theorem identity53053 : scanCanonicalize (H12AffineFastState.compose env53053 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53054 : List Nat := [1,1,8,1,0,0,9,0,1,1,1,0,8,1,0,0,1,1,1,1,1,0,1,0,9,1,1,1,1,0,1,1,0,1,1,0]

theorem envBound53054 : H12AffineFastState.Bounded env53054 := by
  intro p hp
  have h : env53054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53053_53054 : H12AffineEnvironment.transform 0 1 env53053 = env53054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53053 == env53054) = true)

theorem identity53054 : scanCanonicalize (H12AffineFastState.compose env53054 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53054 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53055 : List Nat := [1,1,1,1,0,0,0,0,1,1,1,0,1,1,0,0,1,1,1,1,1,0,1,0,0,1,1,1,1,0,1,1,0,1,1,0]

theorem envBound53055 : H12AffineFastState.Bounded env53055 := by
  intro p hp
  have h : env53055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53054_53055 : H12AffineEnvironment.transform 2 1 env53054 = env53055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53054 == env53055) = true)

def env53056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1024,32769,4161,54640,264500,285735,8328,65,316669,269365,281637,35189,1501,272393,256,21793,46212,63188]

theorem envBound53056 : H12AffineFastState.Bounded env53056 := by
  intro p hp
  have h : env53056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53038_53056 : H12AffineEnvironment.transform 16 16449 env53038 = env53056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env53038 == env53056) = true)

theorem identity53056 : scanCanonicalize (H12AffineFastState.compose env53056 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound53056 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,56573,1024,32769,4161,54640,54729,32986,8328,65,2048,49352,37080,35189,1501,62708,256,21793,46212,63188]

theorem envBound53057 : H12AffineFastState.Bounded env53057 := by
  intro p hp
  have h : env53057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53056_53057 : H12AffineEnvironment.transform 17 56573 env53056 = env53057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env53056 == env53057) = true)

theorem identity53057 : scanCanonicalize (H12AffineFastState.compose env53057 (packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound53057 : packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS < 2^1333 := by decide +kernel

def env53058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13689,32768,41383,13624,43396,1024,32769,4161,40969,41136,32986,8328,65,2048,46513,37080,35189,1501,33165,256,8280,46212,33709]

theorem envBound53058 : H12AffineFastState.Bounded env53058 := by
  intro p hp
  have h : env53058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53057_53058 : H12AffineEnvironment.transform 13 13689 env53057 = env53058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env53057 == env53058) = true)

theorem identity53058 : scanCanonicalize (H12AffineFastState.compose env53058 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound53058 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env53059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5377,32768,33247,5440,35324,1024,32769,4161,32881,32968,32986,240,65,2048,38345,37080,35189,1501,33165,256,32,38140,33709]

theorem envBound53059 : H12AffineFastState.Bounded env53059 := by
  intro p hp
  have h : env53059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53058_53059 : H12AffineEnvironment.transform 12 120 env53058 = env53059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env53058 == env53059) = true)

theorem identity53059 : scanCanonicalize (H12AffineFastState.compose env53059 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53059 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env53060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5377,0,479,5440,2556,1024,1,4161,113,200,218,240,65,2048,5577,4312,2421,1501,397,256,32,5372,941]

theorem envBound53060 : H12AffineFastState.Bounded env53060 := by
  intro p hp
  have h : env53060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53059_53060 : H12AffineEnvironment.transform 14 0 env53059 = env53060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53059 == env53060) = true)

theorem identity53060 : scanCanonicalize (H12AffineFastState.compose env53060 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound53060 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env53061 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,120,5372,0,34,5309,2049,1024,1,4161,113,200,218,240,65,2048,5172,4312,2184,1056,112,253,32,5372,592]

theorem envBound53061 : H12AffineFastState.Bounded env53061 := by
  intro p hp
  have h : env53061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53060_53061 : H12AffineEnvironment.transform 7 253 env53060 = env53061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env53060 == env53061) = true)

theorem identity53061 : scanCanonicalize (H12AffineFastState.compose env53061 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53061 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53062 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5236,0,34,5173,2049,1024,1,4161,113,64,82,120,65,2048,5172,4176,2048,1056,112,117,32,5236,592]

theorem envBound53062 : H12AffineFastState.Bounded env53062 := by
  intro p hp
  have h : env53062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53061_53062 : H12AffineEnvironment.transform 6 8 env53061 = env53062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53061 == env53062) = true)

def env53063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513205,510136,8328,65,6705548,2509877,396389,2136373,2102685,6729081,256,21792,46213,2175562]

theorem envBound53063 : H12AffineFastState.Bounded env53063 := by
  intro p hp
  have h : env53063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52960_53063 : H12AffineEnvironment.transform 22 2513205 env52960 = env53063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513205 env52960 == env53063) = true)

def env53064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513205,510136,8328,65,2409660,2509877,396389,2136373,2102685,2373705,256,21792,46213,2175562]

theorem envBound53064 : H12AffineFastState.Bounded env53064 := by
  intro p hp
  have h : env53064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53063_53064 : H12AffineEnvironment.transform 21 169264 env53063 = env53064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env53063 == env53064) = true)

def env53065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,510136,8328,65,316668,416885,396389,35189,1501,272393,256,21792,46213,74250]

theorem envBound53065 : H12AffineFastState.Bounded env53065 := by
  intro p hp
  have h : env53065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53064_53065 : H12AffineEnvironment.transform 20 4160 env53064 = env53065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53064 == env53065) = true)

theorem identity53065 : scanCanonicalize (H12AffineFastState.compose env53065 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound53065 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,156132,412021,474220,8328,65,270376,416885,396389,32161,1501,272393,256,21792,16465,74250]

theorem envBound53066 : H12AffineFastState.Bounded env53066 := by
  intro p hp
  have h : env53066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53065_53066 : H12AffineEnvironment.transform 14 29908 env53065 = env53066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env53065 == env53066) = true)

def env53067 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4112,156084,411941,474172,8328,17,270376,416805,396341,32161,1421,272393,256,21792,16385,74250]

theorem envBound53067 : H12AffineFastState.Bounded env53067 := by
  intro p hp
  have h : env53067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53066_53067 : H12AffineEnvironment.transform 5 16 env53066 = env53067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53066 == env53067) = true)

theorem identity53067 : scanCanonicalize (H12AffineFastState.compose env53067 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215226) := by decide +kernel

theorem selectedBound53067 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,215226,1024,29829,4112,156084,65951,29830,8328,17,223378,70815,83087,32161,1421,221363,256,21792,16385,74250]

theorem envBound53068 : H12AffineFastState.Bounded env53068 := by
  intro p hp
  have h : env53068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53067_53068 : H12AffineEnvironment.transform 17 215226 env53067 = env53068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215226 env53067 == env53068) = true)

theorem identity53068 : scanCanonicalize (H12AffineFastState.compose env53068 (packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound53068 : packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env53069 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,32160,1024,29829,4112,87214,65951,29830,8328,17,23944,70815,83087,32161,1421,21929,256,21792,16385,74250]

theorem envBound53069 : H12AffineFastState.Bounded env53069 := by
  intro p hp
  have h : env53069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53068_53069 : H12AffineEnvironment.transform 16 79130 env53068 = env53069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env53068 == env53069) = true)

theorem identity53069 : scanCanonicalize (H12AffineFastState.compose env53069 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound53069 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,30082,16536,32160,1024,29829,4112,8492,29725,29830,8328,17,23944,24861,12557,32161,1421,21929,256,21792,16385,22408]

theorem envBound53070 : H12AffineFastState.Bounded env53070 := by
  intro p hp
  have h : env53070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53069_53070 : H12AffineEnvironment.transform 15 30082 env53069 = env53070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env53069 == env53070) = true)

theorem identity53070 : scanCanonicalize (H12AffineFastState.compose env53070 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound53070 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env53071 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,398,13460,2476,1024,137,4112,8492,17,138,8328,17,10628,5393,12557,2477,1421,8613,256,8492,13325,9092]

theorem envBound53071 : H12AffineFastState.Bounded env53071 := by
  intro p hp
  have h : env53071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53070_53071 : H12AffineEnvironment.transform 13 13324 env53070 = env53071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env53070 == env53071) = true)

def env53072 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4113,156085,411940,474173,8328,16,270376,416804,396340,32161,1420,272393,256,21792,16384,74250]

theorem envBound53072 : H12AffineFastState.Bounded env53072 := by
  intro p hp
  have h : env53072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53066_53072 : H12AffineEnvironment.transform 5 17 env53066 = env53072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53066 == env53072) = true)

theorem identity53072 : scanCanonicalize (H12AffineFastState.compose env53072 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound53072 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53073 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,215091,1024,29828,4113,156085,65815,29710,8328,16,223259,70679,82951,32161,1420,221242,256,21792,16384,74250]

theorem envBound53073 : H12AffineFastState.Bounded env53073 := by
  intro p hp
  have h : env53073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53072_53073 : H12AffineEnvironment.transform 17 215091 env53072 = env53073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env53072 == env53073) = true)

theorem identity53073 : scanCanonicalize (H12AffineFastState.compose env53073 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound53073 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env53074 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,29963,131072,146744,1024,29828,4113,156085,29724,29710,8328,16,138512,24860,12556,32161,1420,136497,256,21792,16384,22273]

theorem envBound53074 : H12AffineFastState.Bounded env53074 := by
  intro p hp
  have h : env53074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53073_53074 : H12AffineEnvironment.transform 15 29963 env53073 = env53074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env53073 == env53074) = true)

theorem identity53074 : scanCanonicalize (H12AffineFastState.compose env53074 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound53074 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env53075 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,29963,24981,23725,1024,29828,4113,32,29724,29710,8328,16,31877,24860,12556,32161,1420,29860,256,21792,16384,22273]

theorem envBound53075 : H12AffineFastState.Bounded env53075 := by
  intro p hp
  have h : env53075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53074_53075 : H12AffineEnvironment.transform 16 24981 env53074 = env53075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env53074 == env53075) = true)

theorem identity53075 : scanCanonicalize (H12AffineFastState.compose env53075 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53075 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env53076 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,8203,13461,2477,1024,8580,4113,32,8476,8462,8328,16,10629,13340,12556,10401,1420,8612,256,32,5376,513]

theorem envBound53076 : H12AffineFastState.Bounded env53076 := by
  intro p hp
  have h : env53076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53075_53076 : H12AffineEnvironment.transform 13 5376 env53075 = env53076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53075 == env53076) = true)

theorem identity53076 : scanCanonicalize (H12AffineFastState.compose env53076 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53077 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,13341,2341,1024,8460,4113,32,8476,8462,8192,16,10509,13340,12556,10281,1284,8492,256,32,5376,513]

theorem envBound53077 : H12AffineFastState.Bounded env53077 := by
  intro p hp
  have h : env53077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53076_53077 : H12AffineEnvironment.transform 6 8 env53076 = env53077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53076 == env53077) = true)

theorem identity53077 : scanCanonicalize (H12AffineFastState.compose env53077 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound53077 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53078 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,4381,5376,4112,4374,1280,2341,1024,4113,4113,32,4097,4115,4381,16,6160,1281,17,6452,1284,4145,256,32,5376,513]

theorem envBound53078 : H12AffineFastState.Bounded env53078 := by
  intro p hp
  have h : env53078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53077_53078 : H12AffineEnvironment.transform 12 4381 env53077 = env53078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env53077 == env53078) = true)

theorem identity53078 : scanCanonicalize (H12AffineFastState.compose env53078 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53078 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53079 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,4381,4404,4112,4374,308,2341,52,4113,4113,32,4097,4115,4381,16,6160,309,17,6452,304,4145,256,32,4404,513]

theorem envBound53079 : H12AffineFastState.Bounded env53079 := by
  intro p hp
  have h : env53079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53078_53079 : H12AffineEnvironment.transform 9 52 env53078 = env53079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53078 == env53079) = true)

theorem identity53079 : scanCanonicalize (H12AffineFastState.compose env53079 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53079 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53080 : List Nat := [2,4,8,16,32,17,8,256,512,52,1,4096,4381,4404,4112,4374,308,292,52,4113,4113,32,4097,4115,4381,16,4113,309,17,4405,304,4145,256,32,4404,513]

theorem envBound53080 : H12AffineFastState.Bounded env53080 := by
  intro p hp
  have h : env53080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53079_53080 : H12AffineEnvironment.transform 10 1 env53079 = env53080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53079 == env53080) = true)

theorem identity53080 : scanCanonicalize (H12AffineFastState.compose env53080 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound53080 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env53081 : List Nat := [2,4,8,16,32,17,8,256,512,52,1,17,268,293,1,263,308,292,52,0,0,32,16,2,268,16,0,309,17,292,304,32,256,32,293,513]

theorem envBound53081 : H12AffineFastState.Bounded env53081 := by
  intro p hp
  have h : env53081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53080_53081 : H12AffineEnvironment.transform 11 17 env53080 = env53081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53080 == env53081) = true)

theorem identity53081 : scanCanonicalize (H12AffineFastState.compose env53081 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53082 : List Nat := [2,4,8,16,32,17,8,4,512,52,1,17,8,33,1,3,48,32,52,0,0,32,16,2,8,16,0,49,17,32,52,32,4,32,33,513]

theorem envBound53082 : H12AffineFastState.Bounded env53082 := by
  intro p hp
  have h : env53082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53081_53082 : H12AffineEnvironment.transform 7 4 env53081 = env53082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53081 == env53082) = true)

theorem identity53082 : scanCanonicalize (H12AffineFastState.compose env53082 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound53082 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53083 : List Nat := [2,4,8,16,32,17,8,4,43,52,1,17,8,33,1,3,48,32,52,0,0,32,16,2,8,16,0,49,17,32,52,32,4,32,33,42]

theorem envBound53083 : H12AffineFastState.Bounded env53083 := by
  intro p hp
  have h : env53083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53082_53083 : H12AffineEnvironment.transform 8 43 env53082 = env53083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env53082 == env53083) = true)

theorem identity53083 : scanCanonicalize (H12AffineFastState.compose env53083 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53084 : List Nat := [2,4,3,16,32,17,3,4,32,52,1,17,3,33,1,3,48,32,52,0,0,32,16,2,3,16,0,49,17,32,52,32,4,32,33,33]

theorem envBound53084 : H12AffineFastState.Bounded env53084 := by
  intro p hp
  have h : env53084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53083_53084 : H12AffineEnvironment.transform 2 3 env53083 = env53084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53083 == env53084) = true)

theorem identity53084 : scanCanonicalize (H12AffineFastState.compose env53084 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53085 : List Nat := [2,1,3,16,32,17,3,1,32,49,1,17,3,33,1,3,48,32,49,0,0,32,16,2,3,16,0,49,17,32,49,32,1,32,33,33]

theorem envBound53085 : H12AffineFastState.Bounded env53085 := by
  intro p hp
  have h : env53085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53084_53085 : H12AffineEnvironment.transform 1 1 env53084 = env53085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53084 == env53085) = true)

theorem identity53085 : scanCanonicalize (H12AffineFastState.compose env53085 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53085 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53086 : List Nat := [2,1,3,16,16,17,3,1,16,1,1,17,3,17,1,3,0,16,1,0,0,16,16,2,3,16,0,1,17,16,1,16,1,16,17,17]

theorem envBound53086 : H12AffineFastState.Bounded env53086 := by
  intro p hp
  have h : env53086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53085_53086 : H12AffineEnvironment.transform 4 16 env53085 = env53086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53085 == env53086) = true)

theorem identity53086 : scanCanonicalize (H12AffineFastState.compose env53086 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound53086 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53087 : List Nat := [2,1,3,3,3,2,3,1,3,1,1,2,3,2,1,3,0,3,1,0,0,3,3,2,3,3,0,1,2,3,1,3,1,3,2,2]

theorem envBound53087 : H12AffineFastState.Bounded env53087 := by
  intro p hp
  have h : env53087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53086_53087 : H12AffineEnvironment.transform 3 3 env53086 = env53087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env53086 == env53087) = true)

def env53088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,510136,8328,65,316669,416884,396389,35188,1500,272392,256,21792,46213,74251]

theorem envBound53088 : H12AffineFastState.Bounded env53088 := by
  intro p hp
  have h : env53088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53064_53088 : H12AffineEnvironment.transform 20 4161 env53064 = env53088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53064 == env53088) = true)

theorem identity53088 : scanCanonicalize (H12AffineFastState.compose env53088 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound53088 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,98780,8328,65,171417,5392,17665,35188,1500,156012,256,21792,46213,74251]

theorem envBound53089 : H12AffineFastState.Bounded env53089 := by
  intro p hp
  have h : env53089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53088_53089 : H12AffineEnvironment.transform 17 149860 env53088 = env53089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env53088 == env53089) = true)

def env53090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,98644,8192,65,171281,5392,17665,35188,1364,156012,256,21792,46093,74251]

theorem envBound53090 : H12AffineFastState.Bounded env53090 := by
  intro p hp
  have h : env53090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53089_53090 : H12AffineEnvironment.transform 6 8 env53089 = env53090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53089 == env53090) = true)

theorem identity53090 : scanCanonicalize (H12AffineFastState.compose env53090 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound53090 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1024,32769,4161,62589,16,98644,8192,65,64604,5392,17665,35188,1364,33,256,21792,46093,74251]

theorem envBound53091 : H12AffineFastState.Bounded env53091 := by
  intro p hp
  have h : env53091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53090_53091 : H12AffineEnvironment.transform 16 24909 env53090 = env53091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env53090 == env53091) = true)

theorem identity53091 : scanCanonicalize (H12AffineFastState.compose env53091 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound53091 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,10281,1024,32769,4161,62589,16,29790,8192,65,64604,5392,17665,35188,1364,33,256,21792,46093,55041]

theorem envBound53092 : H12AffineFastState.Bounded env53092 := by
  intro p hp
  have h : env53092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53091_53092 : H12AffineEnvironment.transform 15 62730 env53091 = env53092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env53091 == env53092) = true)

theorem identity53092 : scanCanonicalize (H12AffineFastState.compose env53092 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound53092 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env53093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,33110,5393,10281,1024,32769,4161,32801,16,2,8192,65,34816,5392,12637,35188,1364,33,256,8572,46093,41821]

theorem envBound53093 : H12AffineFastState.Bounded env53093 := by
  intro p hp
  have h : env53093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53092_53093 : H12AffineEnvironment.transform 13 13404 env53092 = env53093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env53092 == env53093) = true)

theorem identity53093 : scanCanonicalize (H12AffineFastState.compose env53093 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53093 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,5393,2421,1024,32769,4161,32801,16,2,348,65,34816,5392,4097,35188,1364,33,256,32,38225,33281]

theorem envBound53094 : H12AffineFastState.Bounded env53094 := by
  intro p hp
  have h : env53094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53093_53094 : H12AffineEnvironment.transform 12 348 env53093 = env53094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53093 == env53094) = true)

theorem identity53094 : scanCanonicalize (H12AffineFastState.compose env53094 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53094 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53095 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,32768,33030,5393,2341,1024,32769,4113,32801,16,2,268,17,34816,5392,4097,35108,1284,33,256,32,38145,33281]

theorem envBound53095 : H12AffineFastState.Bounded env53095 := by
  intro p hp
  have h : env53095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53094_53095 : H12AffineEnvironment.transform 5 16 env53094 = env53095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53094 == env53095) = true)

theorem identity53095 : scanCanonicalize (H12AffineFastState.compose env53095 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 4389) := by decide +kernel

theorem selectedBound53095 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53096 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,4389,4131,5393,2341,1024,4388,4113,4356,16,2,268,17,6437,5392,4097,6145,1284,33,256,32,1060,4900]

theorem envBound53096 : H12AffineFastState.Bounded env53096 := by
  intro p hp
  have h : env53096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53095_53096 : H12AffineEnvironment.transform 14 4389 env53095 = env53096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4389 env53095 == env53096) = true)

theorem identity53096 : scanCanonicalize (H12AffineFastState.compose env53096 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound53096 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env53097 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1557,268,789,1840,1590,772,2341,1024,1841,1540,1809,16,2,268,17,3888,773,1556,3604,1284,33,256,32,1060,1329]

theorem envBound53097 : H12AffineFastState.Bounded env53097 := by
  intro p hp
  have h : env53097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53096_53097 : H12AffineEnvironment.transform 11 1557 env53096 = env53097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env53096 == env53097) = true)

theorem identity53097 : scanCanonicalize (H12AffineFastState.compose env53097 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound53097 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env53098 : List Nat := [2,4,8,16,32,16,8,256,512,785,2048,260,268,789,33,295,772,2341,785,32,277,0,16,2,268,17,2081,773,261,2309,533,33,256,32,821,544]

theorem envBound53098 : H12AffineFastState.Bounded env53098 := by
  intro p hp
  have h : env53098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53097_53098 : H12AffineEnvironment.transform 9 785 env53097 = env53098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env53097 == env53098) = true)

theorem identity53098 : scanCanonicalize (H12AffineFastState.compose env53098 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53098 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53099 : List Nat := [2,4,8,16,1,16,8,256,512,785,2048,260,268,789,0,262,772,2308,785,1,277,0,16,2,268,17,2048,773,261,2309,533,0,256,1,788,513]

theorem envBound53099 : H12AffineFastState.Bounded env53099 := by
  intro p hp
  have h : env53099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53098_53099 : H12AffineEnvironment.transform 4 1 env53098 = env53099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53098 == env53099) = true)

theorem identity53099 : scanCanonicalize (H12AffineFastState.compose env53099 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53100 : List Nat := [2,4,8,16,1,16,8,256,16,257,2048,260,268,261,0,262,276,2308,257,1,277,0,16,2,268,17,2048,277,261,2309,5,0,256,1,260,17]

theorem envBound53100 : H12AffineFastState.Bounded env53100 := by
  intro p hp
  have h : env53100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53099_53100 : H12AffineEnvironment.transform 8 16 env53099 = env53100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53099 == env53100) = true)

theorem identity53100 : scanCanonicalize (H12AffineFastState.compose env53100 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53101 : List Nat := [2,4,8,16,1,16,8,20,16,21,2048,16,24,17,0,18,0,2064,21,1,1,0,16,2,24,17,2048,1,17,2065,5,0,20,1,16,17]

theorem envBound53101 : H12AffineFastState.Bounded env53101 := by
  intro p hp
  have h : env53101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53100_53101 : H12AffineEnvironment.transform 7 20 env53100 = env53101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53100 == env53101) = true)

theorem identity53101 : scanCanonicalize (H12AffineFastState.compose env53101 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound53101 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53102 : List Nat := [2,4,8,16,1,16,8,20,16,21,17,16,24,17,0,18,0,1,21,1,1,0,16,2,24,17,17,1,17,0,5,0,20,1,16,17]

theorem envBound53102 : H12AffineFastState.Bounded env53102 := by
  intro p hp
  have h : env53102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53101_53102 : H12AffineEnvironment.transform 10 17 env53101 = env53102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env53101 == env53102) = true)

def env53103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,98645,8193,65,171280,5392,17665,35188,1365,156012,256,21792,46092,74251]

theorem envBound53103 : H12AffineFastState.Bounded env53103 := by
  intro p hp
  have h : env53103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53089_53103 : H12AffineEnvironment.transform 6 9 env53089 = env53103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53089 == env53103) = true)

theorem identity53103 : scanCanonicalize (H12AffineFastState.compose env53103 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound53103 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4161,21793,16,98645,8193,65,23809,5392,17665,35188,1365,41341,256,21792,46092,74251]

theorem envBound53104 : H12AffineFastState.Bounded env53104 := by
  intro p hp
  have h : env53104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53103_53104 : H12AffineEnvironment.transform 16 49169 env53103 = env53104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env53103 == env53104) = true)

theorem identity53104 : scanCanonicalize (H12AffineFastState.compose env53104 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound53104 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env53105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62811,49169,35189,1024,32769,4161,21793,16,29710,8193,65,23809,5392,17665,35188,1365,41341,256,21792,46092,55120]

theorem envBound53105 : H12AffineFastState.Bounded env53105 := by
  intro p hp
  have h : env53105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53104_53105 : H12AffineEnvironment.transform 15 62811 env53104 = env53105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env53104 == env53105) = true)

theorem identity53105 : scanCanonicalize (H12AffineFastState.compose env53105 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53105 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env53106 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,62730,49169,35108,1024,32769,4112,21793,16,29710,8193,16,23809,5392,17665,35109,1284,41260,256,21792,46092,55041]

theorem envBound53106 : H12AffineFastState.Bounded env53106 := by
  intro p hp
  have h : env53106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53105_53106 : H12AffineEnvironment.transform 5 17 env53105 = env53106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53105 == env53106) = true)

theorem identity53106 : scanCanonicalize (H12AffineFastState.compose env53106 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound53106 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53107 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,32768,41262,37941,35108,1024,32769,4112,261,16,8234,8193,16,2341,5392,4389,35109,1284,41260,256,260,46092,33573]

theorem envBound53107 : H12AffineFastState.Bounded env53107 := by
  intro p hp
  have h : env53107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53106_53107 : H12AffineEnvironment.transform 13 5156 env53106 = env53107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env53106 == env53107) = true)

theorem identity53107 : scanCanonicalize (H12AffineFastState.compose env53107 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53107 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53108 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5156,32768,33030,37941,35108,1024,32769,4112,261,16,2,41,16,2341,5392,4389,35109,1284,33028,256,260,37924,33573]

theorem envBound53108 : H12AffineFastState.Bounded env53108 := by
  intro p hp
  have h : env53108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53107_53108 : H12AffineEnvironment.transform 12 40 env53107 = env53108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53107 == env53108) = true)

theorem identity53108 : scanCanonicalize (H12AffineFastState.compose env53108 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53108 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53109 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5156,0,262,5173,2340,1024,1,4112,261,16,2,41,16,2341,5392,4389,2341,1284,260,256,260,5156,805]

theorem envBound53109 : H12AffineFastState.Bounded env53109 := by
  intro p hp
  have h : env53109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53108_53109 : H12AffineEnvironment.transform 14 0 env53108 = env53109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53108 == env53109) = true)

theorem identity53109 : scanCanonicalize (H12AffineFastState.compose env53109 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound53109 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53110 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,772,40,1824,0,262,1841,2340,1024,1,788,261,16,2,41,16,2341,1556,545,2341,1284,260,256,260,1824,805]

theorem envBound53110 : H12AffineFastState.Bounded env53110 := by
  intro p hp
  have h : env53110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53109_53110 : H12AffineEnvironment.transform 11 772 env53109 = env53110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env53109 == env53110) = true)

theorem identity53110 : scanCanonicalize (H12AffineFastState.compose env53110 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound53110 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53111 : List Nat := [2,4,8,16,32,17,9,256,512,1024,512,772,40,1824,0,262,1841,804,1024,1,788,261,16,2,41,16,805,1556,545,805,1284,260,256,260,1824,805]

theorem envBound53111 : H12AffineFastState.Bounded env53111 := by
  intro p hp
  have h : env53111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53110_53111 : H12AffineEnvironment.transform 10 512 env53110 = env53111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env53110 == env53111) = true)

theorem identity53111 : scanCanonicalize (H12AffineFastState.compose env53111 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound53111 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env53112 : List Nat := [2,4,8,16,32,17,9,256,512,548,512,772,40,260,0,262,277,804,548,1,788,261,16,2,41,16,805,48,545,805,800,260,256,260,260,805]

theorem envBound53112 : H12AffineFastState.Bounded env53112 := by
  intro p hp
  have h : env53112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53111_53112 : H12AffineEnvironment.transform 9 548 env53111 = env53112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env53111 == env53112) = true)

theorem identity53112 : scanCanonicalize (H12AffineFastState.compose env53112 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound53112 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53113 : List Nat := [2,4,8,16,32,17,9,256,48,20,48,308,40,260,0,262,277,276,20,1,292,261,16,2,41,16,277,48,17,277,272,260,256,260,260,277]

theorem envBound53113 : H12AffineFastState.Bounded env53113 := by
  intro p hp
  have h : env53113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53112_53113 : H12AffineEnvironment.transform 8 48 env53112 = env53113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env53112 == env53113) = true)

theorem identity53113 : scanCanonicalize (H12AffineFastState.compose env53113 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53113 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env53114 : List Nat := [2,4,8,16,1,17,9,256,17,20,17,277,9,260,0,262,277,276,20,1,261,261,16,2,8,16,277,17,17,277,272,260,256,260,260,277]

theorem envBound53114 : H12AffineFastState.Bounded env53114 := by
  intro p hp
  have h : env53114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53113_53114 : H12AffineEnvironment.transform 4 1 env53113 = env53114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53113 == env53114) = true)

theorem identity53114 : scanCanonicalize (H12AffineFastState.compose env53114 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53115 : List Nat := [2,4,8,16,1,17,9,5,17,20,17,16,9,1,0,3,16,17,20,1,0,0,16,2,8,16,16,17,17,16,21,1,5,1,1,16]

theorem envBound53115 : H12AffineFastState.Bounded env53115 := by
  intro p hp
  have h : env53115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53114_53115 : H12AffineEnvironment.transform 7 5 env53114 = env53115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53114 == env53115) = true)

theorem identity53115 : scanCanonicalize (H12AffineFastState.compose env53115 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53115 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53116 : List Nat := [2,4,8,1,1,0,9,5,0,5,0,1,9,1,0,3,1,0,5,1,0,0,1,2,8,1,1,0,0,1,4,1,5,1,1,1]

theorem envBound53116 : H12AffineFastState.Bounded env53116 := by
  intro p hp
  have h : env53116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53115_53116 : H12AffineEnvironment.transform 3 1 env53115 = env53116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53115 == env53116) = true)

def env53117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513205,510136,8328,65,2409661,2509877,396389,2136373,2102685,2373704,256,21792,46213,2175562]

theorem envBound53117 : H12AffineFastState.Bounded env53117 := by
  intro p hp
  have h : env53117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53063_53117 : H12AffineEnvironment.transform 21 169265 env53063 = env53117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env53063 == env53117) = true)

def env53118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,510136,8328,65,316669,416885,396389,35189,1501,272392,256,21792,46213,74250]

theorem envBound53118 : H12AffineFastState.Bounded env53118 := by
  intro p hp
  have h : env53118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53117_53118 : H12AffineEnvironment.transform 20 4160 env53117 = env53118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53117 == env53118) = true)

theorem identity53118 : scanCanonicalize (H12AffineFastState.compose env53118 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound53118 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,169265,62660,95497,8328,65,158028,57796,45524,35189,1501,169401,256,21792,46213,74250]

theorem envBound53119 : H12AffineFastState.Bounded env53119 := by
  intro p hp
  have h : env53119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53118_53119 : H12AffineEnvironment.transform 17 179633 env53118 = env53119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env53118 == env53119) = true)

theorem identity53119 : scanCanonicalize (H12AffineFastState.compose env53119 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53119 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env53120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179633,1024,32769,4160,169265,62660,21762,8328,65,158028,57796,45524,35189,1501,169401,256,21792,46213,513]

theorem envBound53120 : H12AffineFastState.Bounded env53120 := by
  intro p hp
  have h : env53120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53119_53120 : H12AffineEnvironment.transform 15 8203 env53119 = env53120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53119 == env53120) = true)

theorem identity53120 : scanCanonicalize (H12AffineFastState.compose env53120 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound53120 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env53121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64928,1024,32769,4160,54560,62660,21762,8328,65,10589,57796,45524,35189,1501,54696,256,21792,46213,513]

theorem envBound53121 : H12AffineFastState.Bounded env53121 := by
  intro p hp
  have h : env53121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53120_53121 : H12AffineEnvironment.transform 16 16401 env53120 = env53121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53120 == env53121) = true)

theorem identity53121 : scanCanonicalize (H12AffineFastState.compose env53121 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound53121 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16401,2420,1024,29909,4160,8692,16,21762,8328,65,10589,5392,17664,32161,1501,8572,256,21792,16465,513]

theorem envBound53122 : H12AffineFastState.Bounded env53122 := by
  intro p hp
  have h : env53122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53121_53122 : H12AffineEnvironment.transform 14 29908 env53121 = env53122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env53121 == env53122) = true)

theorem identity53122 : scanCanonicalize (H12AffineFastState.compose env53122 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53122 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,16401,2420,1024,21896,4160,169,16,21762,469,65,2048,5392,17664,23804,1501,33,256,21792,16465,513]

theorem envBound53123 : H12AffineFastState.Bounded env53123 := by
  intro p hp
  have h : env53123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53122_53123 : H12AffineEnvironment.transform 12 349 env53122 = env53123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53122 == env53123) = true)

theorem identity53123 : scanCanonicalize (H12AffineFastState.compose env53123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,16401,2420,1024,21760,4160,33,16,21762,349,65,2048,5392,17664,23668,1365,33,256,21792,16465,513]

theorem envBound53124 : H12AffineFastState.Bounded env53124 := by
  intro p hp
  have h : env53124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53123_53124 : H12AffineEnvironment.transform 6 8 env53123 = env53124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53123 == env53124) = true)

theorem identity53124 : scanCanonicalize (H12AffineFastState.compose env53124 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53124 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53125 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21761,263,16401,2341,1024,21760,4113,33,16,21762,268,16,2048,5392,17664,23589,1284,33,256,21792,16384,513]

theorem envBound53125 : H12AffineFastState.Bounded env53125 := by
  intro p hp
  have h : env53125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53124_53125 : H12AffineEnvironment.transform 5 17 env53124 = env53125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53124 == env53125) = true)

theorem identity53125 : scanCanonicalize (H12AffineFastState.compose env53125 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound53125 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53126 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,268,16384,18724,263,16401,2341,1024,18725,3124,33,16,18727,268,16,2048,2357,17664,16384,1284,33,256,18693,16384,513]

theorem envBound53126 : H12AffineFastState.Bounded env53126 := by
  intro p hp
  have h : env53126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53125_53126 : H12AffineEnvironment.transform 11 3109 env53125 = env53126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env53125 == env53126) = true)

theorem identity53126 : scanCanonicalize (H12AffineFastState.compose env53126 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound53126 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53127 : List Nat := [2,4,8,16,32,17,8,256,512,542,2048,2619,268,16384,18724,263,16401,2341,542,18725,2602,33,16,18727,268,16,2048,2357,17182,16384,794,33,256,18693,16384,513]

theorem envBound53127 : H12AffineFastState.Bounded env53127 := by
  intro p hp
  have h : env53127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53126_53127 : H12AffineEnvironment.transform 9 542 env53126 = env53127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env53126 == env53127) = true)

theorem identity53127 : scanCanonicalize (H12AffineFastState.compose env53127 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound53127 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env53128 : List Nat := [2,4,8,16,32,17,8,256,512,542,261,830,268,16384,16417,263,16401,32,542,16416,815,33,16,16418,268,16,261,48,17182,16384,794,33,256,16384,16384,513]

theorem envBound53128 : H12AffineFastState.Bounded env53128 := by
  intro p hp
  have h : env53128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53127_53128 : H12AffineEnvironment.transform 10 261 env53127 = env53128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env53127 == env53128) = true)

theorem identity53128 : scanCanonicalize (H12AffineFastState.compose env53128 (packedSelected [0,2,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53128 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env53129 : List Nat := [2,4,8,16,32,17,8,36,512,542,33,538,40,16384,16417,35,16401,32,542,16416,523,33,16,16418,40,16,33,48,16954,16384,574,33,36,16384,16384,513]

theorem envBound53129 : H12AffineFastState.Bounded env53129 := by
  intro p hp
  have h : env53129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53128_53129 : H12AffineEnvironment.transform 7 36 env53128 = env53129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53128 == env53129) = true)

theorem identity53129 : scanCanonicalize (H12AffineFastState.compose env53129 (packedSelected [0,1,2] rootPS)) = affineNative (2^(13+1) ^^^ 572) := by decide +kernel

theorem selectedBound53129 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env53130 : List Nat := [2,4,8,16,32,17,8,36,512,542,33,538,40,572,541,35,557,32,542,540,523,33,16,542,40,16,33,48,6,572,574,33,36,572,572,513]

theorem envBound53130 : H12AffineFastState.Bounded env53130 := by
  intro p hp
  have h : env53130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53129_53130 : H12AffineEnvironment.transform 13 572 env53129 = env53130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 572 env53129 == env53130) = true)

def env53131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,510136,8328,65,316668,416884,396389,35188,1500,272393,256,21792,46213,74251]

theorem envBound53131 : H12AffineFastState.Bounded env53131 := by
  intro p hp
  have h : env53131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53117_53131 : H12AffineEnvironment.transform 20 4161 env53117 = env53131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53117 == env53131) = true)

def env53132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169265,155996,254096,8328,65,64724,160860,140365,35188,1500,33,256,21792,46213,74251]

theorem envBound53132 : H12AffineFastState.Bounded env53132 := by
  intro p hp
  have h : env53132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53131_53132 : H12AffineEnvironment.transform 17 10280 env53131 = env53132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53131 == env53132) = true)

def env53133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21793,41292,73856,8328,65,64724,46156,58461,35188,1500,33,256,21792,46213,74251]

theorem envBound53133 : H12AffineFastState.Bounded env53133 := by
  intro p hp
  have h : env53133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53132_53133 : H12AffineEnvironment.transform 16 49168 env53132 = env53133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53132 == env53133) = true)

theorem identity53133 : scanCanonicalize (H12AffineFastState.compose env53133 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53133 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1024,8540,4161,21793,17,73856,8328,65,23945,5393,17664,10281,1500,33,256,21792,5592,74251]

theorem envBound53134 : H12AffineFastState.Bounded env53134 := by
  intro p hp
  have h : env53134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53133_53134 : H12AffineEnvironment.transform 14 8541 env53133 = env53134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53133 == env53134) = true)

theorem identity53134 : scanCanonicalize (H12AffineFastState.compose env53134 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound53134 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env53135 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,16384,8541,65536,24909,10280,189,8540,4161,20892,17,73856,8328,65,22836,4524,16829,10281,353,33,256,20893,4453,74251]

theorem envBound53135 : H12AffineFastState.Bounded env53135 := by
  intro p hp
  have h : env53135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53134_53135 : H12AffineEnvironment.transform 9 189 env53134 = env53135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env53134 == env53135) = true)

theorem identity53135 : scanCanonicalize (H12AffineFastState.compose env53135 (packedSelected [2,4,6,11,16,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound53135 : packedSelected [2,4,6,11,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env53136 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,16384,8541,114,24909,10280,189,8540,4161,20892,17,8434,8328,65,22836,4524,16829,10281,353,33,256,20893,4453,8825]

theorem envBound53136 : H12AffineFastState.Bounded env53136 := by
  intro p hp
  have h : env53136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53135_53136 : H12AffineEnvironment.transform 15 114 env53135 = env53136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env53135 == env53136) = true)

theorem identity53136 : scanCanonicalize (H12AffineFastState.compose env53136 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound53136 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env53137 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,4161,8541,114,12556,10280,189,8540,4161,477,17,8434,8328,65,2421,4524,4604,10281,353,33,256,476,4453,8825]

theorem envBound53137 : H12AffineFastState.Bounded env53137 := by
  intro p hp
  have h : env53137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53136_53137 : H12AffineEnvironment.transform 13 4161 env53136 = env53137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env53136 == env53137) = true)

theorem identity53137 : scanCanonicalize (H12AffineFastState.compose env53137 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53137 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env53138 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,348,4161,1,114,4176,2420,189,0,4161,477,17,430,468,65,2421,4524,4604,2421,353,33,256,476,4453,805]

theorem envBound53138 : H12AffineFastState.Bounded env53138 := by
  intro p hp
  have h : env53138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53137_53138 : H12AffineEnvironment.transform 12 348 env53137 = env53138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53137 == env53138) = true)

theorem identity53138 : scanCanonicalize (H12AffineFastState.compose env53138 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound53138 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53139 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,240,4161,1,114,4176,2264,189,0,4161,113,17,2,120,65,2265,4096,4176,2265,205,33,172,112,4297,649]

theorem envBound53139 : H12AffineFastState.Bounded env53139 := by
  intro p hp
  have h : env53139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53138_53139 : H12AffineEnvironment.transform 7 172 env53138 = env53139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53138 == env53139) = true)

theorem identity53139 : scanCanonicalize (H12AffineFastState.compose env53139 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound53139 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53140 : List Nat := [2,4,8,16,32,64,128,172,512,189,80,4096,240,4161,1,114,4176,136,189,0,4161,113,17,2,120,65,137,4096,4176,137,205,33,172,112,4297,649]

theorem envBound53140 : H12AffineFastState.Bounded env53140 := by
  intro p hp
  have h : env53140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53139_53140 : H12AffineEnvironment.transform 10 80 env53139 = env53140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env53139 == env53140) = true)

theorem identity53140 : scanCanonicalize (H12AffineFastState.compose env53140 (packedSelected [1,2,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53140 : packedSelected [1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53141 : List Nat := [2,4,8,16,32,16,128,172,512,189,0,4096,160,4113,1,34,4096,136,189,0,4113,33,17,2,40,17,137,4096,4096,137,157,33,172,32,4249,649]

theorem envBound53141 : H12AffineFastState.Bounded env53141 := by
  intro p hp
  have h : env53141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53140_53141 : H12AffineEnvironment.transform 5 16 env53140 = env53141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53140 == env53141) = true)

theorem identity53141 : scanCanonicalize (H12AffineFastState.compose env53141 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound53141 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53142 : List Nat := [2,4,8,16,32,16,128,172,512,189,0,16,160,1,1,34,16,136,189,0,1,33,17,2,40,17,137,16,16,137,157,33,172,32,137,649]

theorem envBound53142 : H12AffineFastState.Bounded env53142 := by
  intro p hp
  have h : env53142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53141_53142 : H12AffineEnvironment.transform 11 16 env53141 = env53142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53141 == env53142) = true)

theorem identity53142 : scanCanonicalize (H12AffineFastState.compose env53142 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53142 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env53143 : List Nat := [2,4,8,16,32,16,9,37,512,52,0,16,41,1,1,34,16,1,52,0,1,33,17,2,40,17,0,16,16,0,20,33,37,32,0,512]

theorem envBound53143 : H12AffineFastState.Bounded env53143 := by
  intro p hp
  have h : env53143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53142_53143 : H12AffineEnvironment.transform 6 9 env53142 = env53143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53142 == env53143) = true)

theorem identity53143 : scanCanonicalize (H12AffineFastState.compose env53143 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound53143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53144 : List Nat := [2,4,8,16,32,16,9,37,14,52,0,16,41,1,1,34,16,1,52,0,1,33,17,2,40,17,0,16,16,0,20,33,37,32,0,14]

theorem envBound53144 : H12AffineFastState.Bounded env53144 := by
  intro p hp
  have h : env53144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53143_53144 : H12AffineEnvironment.transform 8 14 env53143 = env53144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env53143 == env53144) = true)

theorem identity53144 : scanCanonicalize (H12AffineFastState.compose env53144 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53145 : List Nat := [2,4,8,16,1,16,9,4,14,21,0,16,8,1,1,3,16,1,21,0,1,0,17,2,9,17,0,16,16,0,20,0,4,1,0,14]

theorem envBound53145 : H12AffineFastState.Bounded env53145 := by
  intro p hp
  have h : env53145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53144_53145 : H12AffineEnvironment.transform 4 1 env53144 = env53145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53144 == env53145) = true)

def env53146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21792,41293,73857,8328,65,64724,46157,58460,35188,1500,33,256,21792,46213,74251]

theorem envBound53146 : H12AffineFastState.Bounded env53146 := by
  intro p hp
  have h : env53146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53132_53146 : H12AffineEnvironment.transform 16 49169 env53132 = env53146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env53132 == env53146) = true)

theorem identity53146 : scanCanonicalize (H12AffineFastState.compose env53146 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound53146 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1024,8661,4161,21792,153,73857,8328,65,23808,5529,17800,10400,1500,33,256,21792,5457,74251]

theorem envBound53147 : H12AffineFastState.Bounded env53147 := by
  intro p hp
  have h : env53147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53146_53147 : H12AffineEnvironment.transform 14 8660 env53146 = env53147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env53146 == env53147) = true)

theorem identity53147 : scanCanonicalize (H12AffineFastState.compose env53147 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound53147 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env53148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1433,65536,17800,3173,1024,1432,4161,21792,153,66764,1221,65,23808,5529,17800,3309,1500,33,256,21792,5457,67142]

theorem envBound53148 : H12AffineFastState.Bounded env53148 := by
  intro p hp
  have h : env53148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53147_53148 : H12AffineEnvironment.transform 12 1101 env53147 = env53148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env53147 == env53148) = true)

theorem identity53148 : scanCanonicalize (H12AffineFastState.compose env53148 (packedSelected [0,1,2,3,5,6,7,8,10,16,26] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound53148 : packedSelected [0,1,2,3,5,6,7,8,10,16,26] rootPS < 2^1333 := by decide +kernel

def env53149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1433,1046,17800,3173,1024,1432,4161,21792,153,218,1221,65,23808,5529,17800,3309,1500,33,256,21792,5457,592]

theorem envBound53149 : H12AffineFastState.Bounded env53149 := by
  intro p hp
  have h : env53149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53148_53149 : H12AffineEnvironment.transform 15 1046 env53148 = env53149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env53148 == env53149) = true)

theorem identity53149 : scanCanonicalize (H12AffineFastState.compose env53149 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound53149 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env53150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5236,1433,1046,4604,3173,1024,1432,4161,340,153,218,1221,65,2420,5529,4604,3309,1500,33,256,340,5457,592]

theorem envBound53150 : H12AffineFastState.Bounded env53150 := by
  intro p hp
  have h : env53150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53149_53150 : H12AffineEnvironment.transform 13 5236 env53149 = env53150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env53149 == env53150) = true)

theorem identity53150 : scanCanonicalize (H12AffineFastState.compose env53150 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53150 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env53151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5236,1297,1046,4468,3173,1024,1296,4161,340,17,82,1101,65,2420,5393,4468,3173,1364,33,256,340,5457,592]

theorem envBound53151 : H12AffineFastState.Bounded env53151 := by
  intro p hp
  have h : env53151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53150_53151 : H12AffineEnvironment.transform 6 8 env53150 = env53151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53150 == env53151) = true)

theorem identity53151 : scanCanonicalize (H12AffineFastState.compose env53151 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53151 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53152 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4453,0,263,4468,2420,273,1,4161,340,17,82,348,65,2420,4096,4468,2420,69,33,256,340,4160,592]

theorem envBound53152 : H12AffineFastState.Bounded env53152 := by
  intro p hp
  have h : env53152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53151_53152 : H12AffineEnvironment.transform 9 273 env53151 = env53152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53151 == env53152) = true)

theorem identity53152 : scanCanonicalize (H12AffineFastState.compose env53152 (packedSelected [0,4,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound53152 : packedSelected [0,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53153 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2324,348,2161,0,263,2144,2420,273,1,2389,340,17,82,348,65,2420,2324,2144,2420,69,33,256,340,2388,592]

theorem envBound53153 : H12AffineFastState.Bounded env53153 := by
  intro p hp
  have h : env53153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53152_53153 : H12AffineEnvironment.transform 11 2324 env53152 = env53153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env53152 == env53153) = true)

theorem identity53153 : scanCanonicalize (H12AffineFastState.compose env53153 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53153 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env53154 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2096,120,2161,0,35,2144,2128,53,1,2161,112,17,82,120,65,2128,2096,2144,2128,69,33,36,112,2160,592]

theorem envBound53154 : H12AffineFastState.Bounded env53154 := by
  intro p hp
  have h : env53154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53153_53154 : H12AffineEnvironment.transform 7 36 env53153 = env53154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53153 == env53154) = true)

theorem identity53154 : scanCanonicalize (H12AffineFastState.compose env53154 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound53154 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53155 : List Nat := [2,4,8,16,32,49,8,36,512,53,2048,2096,9,2048,0,35,2065,2081,53,1,2048,1,17,35,9,48,2081,2096,2065,2081,52,33,36,1,2049,545]

theorem envBound53155 : H12AffineFastState.Bounded env53155 := by
  intro p hp
  have h : env53155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53154_53155 : H12AffineEnvironment.transform 5 49 env53154 = env53155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env53154 == env53155) = true)

def env53156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169265,155997,254097,8328,65,64725,160861,140364,35188,1500,32,256,21792,46213,74251]

theorem envBound53156 : H12AffineFastState.Bounded env53156 := by
  intro p hp
  have h : env53156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53131_53156 : H12AffineEnvironment.transform 17 10281 env53131 = env53156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53131 == env53156) = true)

def env53157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21793,41293,73857,8328,65,64725,46157,58460,35188,1500,32,256,21792,46213,74251]

theorem envBound53157 : H12AffineFastState.Bounded env53157 := by
  intro p hp
  have h : env53157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53156_53157 : H12AffineEnvironment.transform 16 49168 env53156 = env53157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53156 == env53157) = true)

theorem identity53157 : scanCanonicalize (H12AffineFastState.compose env53157 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53157 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21793,41293,73737,8192,65,64605,46157,58460,35188,1364,32,256,21792,46093,74251]

theorem envBound53158 : H12AffineFastState.Bounded env53158 := by
  intro p hp
  have h : env53158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53157_53158 : H12AffineEnvironment.transform 6 8 env53157 = env53158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53157 == env53158) = true)

theorem identity53158 : scanCanonicalize (H12AffineFastState.compose env53158 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53158 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env53159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10281,1024,8541,4161,21793,17,73737,8192,65,23809,5393,17664,10280,1364,32,256,21792,5457,74251]

theorem envBound53159 : H12AffineFastState.Bounded env53159 := by
  intro p hp
  have h : env53159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53158_53159 : H12AffineEnvironment.transform 14 8540 env53158 = env53159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53158 == env53159) = true)

theorem identity53159 : scanCanonicalize (H12AffineFastState.compose env53159 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53159 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env53160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24908,10281,1024,8541,4161,21793,17,8543,8192,65,23809,5393,17664,10280,1364,32,256,21792,5457,9053]

theorem envBound53160 : H12AffineFastState.Bounded env53160 := by
  intro p hp
  have h : env53160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53159_53160 : H12AffineEnvironment.transform 15 342 env53159 = env53160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53159 == env53160) = true)

theorem identity53160 : scanCanonicalize (H12AffineFastState.compose env53160 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound53160 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,342,5393,10281,1024,8541,4161,8572,17,8543,8192,65,10588,5393,12637,10280,1364,32,256,8573,5457,9053]

theorem envBound53161 : H12AffineFastState.Bounded env53161 := by
  intro p hp
  have h : env53161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53160_53161 : H12AffineEnvironment.transform 13 13405 env53160 = env53161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env53160 == env53161) = true)

theorem identity53161 : scanCanonicalize (H12AffineFastState.compose env53161 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53161 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5393,2421,1024,1,4161,32,17,3,348,65,2048,5393,4097,2420,1364,32,256,33,5457,513]

theorem envBound53162 : H12AffineFastState.Bounded env53162 := by
  intro p hp
  have h : env53162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53161_53162 : H12AffineEnvironment.transform 12 348 env53161 = env53162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53161 == env53162) = true)

theorem identity53162 : scanCanonicalize (H12AffineFastState.compose env53162 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2927) := by decide +kernel

theorem selectedBound53162 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2927,348,3694,0,342,3710,2421,1024,1,2862,32,17,3,348,65,2048,3710,2926,2420,1364,32,256,33,3646,513]

theorem envBound53163 : H12AffineFastState.Bounded env53163 := by
  intro p hp
  have h : env53163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53162_53163 : H12AffineEnvironment.transform 11 2927 env53162 = env53163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2927 env53162 == env53163) = true)

theorem identity53163 : scanCanonicalize (H12AffineFastState.compose env53163 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53163 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53164 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2878,269,3647,0,263,3631,2340,1024,1,2862,32,17,3,269,16,2048,3631,2879,2341,1285,32,256,33,3646,513]

theorem envBound53164 : H12AffineFastState.Bounded env53164 := by
  intro p hp
  have h : env53164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53163_53164 : H12AffineEnvironment.transform 5 17 env53163 = env53164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53163 == env53164) = true)

theorem identity53164 : scanCanonicalize (H12AffineFastState.compose env53164 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound53164 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53165 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1819,1061,269,292,0,263,308,1599,1024,1,1077,32,17,3,269,16,1819,308,1060,1598,1285,32,256,33,293,513]

theorem envBound53165 : H12AffineFastState.Bounded env53165 := by
  intro p hp
  have h : env53165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53164_53165 : H12AffineEnvironment.transform 10 1819 env53164 = env53165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env53164 == env53165) = true)

theorem identity53165 : scanCanonicalize (H12AffineFastState.compose env53165 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound53165 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53166 : List Nat := [2,4,8,16,32,17,8,256,512,542,261,571,269,292,0,263,308,33,542,1,555,32,17,3,269,16,261,308,570,32,795,32,256,33,293,513]

theorem envBound53166 : H12AffineFastState.Bounded env53166 := by
  intro p hp
  have h : env53166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0