import H12CloudChart0Data197

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env50142 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,16384,292,18546,2064,2129,101,293,16465,18465,18788,18806,120,64,16676,16401,16401,2049,18736,18465,256,18772,2340,513]

theorem envBound50142 : H12AffineFastState.Bounded env50142 := by
  intro p hp
  have h : env50142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50141_50142 : H12AffineEnvironment.transform 11 2064 env50141 = env50142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env50141 == env50142) = true)

theorem identity50142 : scanCanonicalize (H12AffineFastState.compose env50142 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound50142 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env50143 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,2420,292,262,2064,2129,101,293,2341,341,16,2,120,64,2128,2405,2405,2049,68,341,256,32,2340,513]

theorem envBound50143 : H12AffineFastState.Bounded env50143 := by
  intro p hp
  have h : env50143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50142_50143 : H12AffineEnvironment.transform 13 2420 env50142 = env50143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env50142 == env50143) = true)

def env50144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329731,62540,21763,8193,64,158028,57676,102742,406604,75102,329730,256,21793,46092,513]

theorem envBound50144 : H12AffineFastState.Bounded env50144 := by
  intro p hp
  have h : env50144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50122_50144 : H12AffineEnvironment.transform 6 9 env50122 = env50144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50122 == env50144) = true)

def env50145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,73771,62540,21763,8193,64,158028,57676,102742,138340,75102,73770,256,21793,46092,513]

theorem envBound50145 : H12AffineFastState.Bounded env50145 := by
  intro p hp
  have h : env50145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50144_50145 : H12AffineEnvironment.transform 17 10280 env50144 = env50145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50144 == env50145) = true)

def env50146 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62492,21763,8193,16,157980,57628,102662,138292,75022,73770,256,21793,46092,513]

theorem envBound50146 : H12AffineFastState.Bounded env50146 := by
  intro p hp
  have h : env50146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50145_50146 : H12AffineEnvironment.transform 5 16 env50145 = env50146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50145 == env50146) = true)

theorem identity50146 : scanCanonicalize (H12AffineFastState.compose env50146 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50146 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env50147 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10280,1024,1,77851,73771,29724,21763,8193,16,157980,24860,69894,138292,75022,73770,256,21793,13324,513]

theorem envBound50147 : H12AffineFastState.Bounded env50147 := by
  intro p hp
  have h : env50147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50146_50147 : H12AffineEnvironment.transform 14 0 env50146 = env50147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50146 == env50147) = true)

theorem identity50147 : scanCanonicalize (H12AffineFastState.compose env50147 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound50147 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env50148 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,16400,10280,1024,1,77851,73771,29724,21763,8193,16,10508,24860,69894,23588,75022,73770,256,21793,13324,513]

theorem envBound50148 : H12AffineFastState.Bounded env50148 := by
  intro p hp
  have h : env50148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50147_50148 : H12AffineEnvironment.transform 16 16400 env50147 = env50148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50147 == env50148) = true)

theorem identity50148 : scanCanonicalize (H12AffineFastState.compose env50148 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50148 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50149 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,16400,10280,1024,1,4113,33,29724,21763,8193,16,10508,24860,12556,23588,1284,32,256,21793,13324,513]

theorem envBound50149 : H12AffineFastState.Bounded env50149 := by
  intro p hp
  have h : env50149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50148_50149 : H12AffineEnvironment.transform 15 8202 env50148 = env50149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50148 == env50149) = true)

theorem identity50149 : scanCanonicalize (H12AffineFastState.compose env50149 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50149 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50150 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,8202,13340,10280,1024,1,4113,33,16,8463,8193,16,10508,5392,12556,10280,1284,32,256,8493,13324,513]

theorem envBound50150 : H12AffineFastState.Bounded env50150 := by
  intro p hp
  have h : env50150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50149_50150 : H12AffineEnvironment.transform 13 13324 env50149 = env50150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50149 == env50150) = true)

theorem identity50150 : scanCanonicalize (H12AffineFastState.compose env50150 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50150 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50151 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5156,0,34,5172,2048,1024,1,4113,33,16,295,41,16,2340,5392,4388,2048,1284,32,256,261,5156,513]

theorem envBound50151 : H12AffineFastState.Bounded env50151 := by
  intro p hp
  have h : env50151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50150_50151 : H12AffineEnvironment.transform 12 40 env50150 = env50151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50150 == env50151) = true)

theorem identity50151 : scanCanonicalize (H12AffineFastState.compose env50151 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50151 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50152 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1024,1,4113,33,16,2,41,16,2049,5173,4097,2048,1057,32,37,32,5156,513]

theorem envBound50152 : H12AffineFastState.Bounded env50152 := by
  intro p hp
  have h : env50152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50151_50152 : H12AffineEnvironment.transform 7 37 env50151 = env50152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50151 == env50152) = true)

theorem identity50152 : scanCanonicalize (H12AffineFastState.compose env50152 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50153 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,34,4097,2048,53,1,4113,33,16,2,41,16,2049,4096,4097,2048,20,32,37,32,4113,513]

theorem envBound50153 : H12AffineFastState.Bounded env50153 := by
  intro p hp
  have h : env50153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50152_50153 : H12AffineEnvironment.transform 9 53 env50152 = env50153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50152 == env50153) = true)

theorem identity50153 : scanCanonicalize (H12AffineFastState.compose env50153 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound50153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50154 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2064,40,2049,0,34,2065,2048,53,1,2049,33,16,2,41,16,2049,2064,2065,2048,20,32,37,32,2049,513]

theorem envBound50154 : H12AffineFastState.Bounded env50154 := by
  intro p hp
  have h : env50154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50153_50154 : H12AffineEnvironment.transform 11 2064 env50153 = env50154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env50153 == env50154) = true)

theorem identity50154 : scanCanonicalize (H12AffineFastState.compose env50154 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50155 : List Nat := [2,4,8,10,32,10,9,37,512,47,2048,2058,40,2049,0,34,2059,2048,47,1,2049,33,10,2,41,10,2049,2058,2059,2048,14,32,37,32,2049,513]

theorem envBound50155 : H12AffineFastState.Bounded env50155 := by
  intro p hp
  have h : env50155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50154_50155 : H12AffineEnvironment.transform 3 10 env50154 = env50155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50154 == env50155) = true)

theorem identity50155 : scanCanonicalize (H12AffineFastState.compose env50155 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50155 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50156 : List Nat := [2,4,8,10,32,10,9,37,512,47,0,10,40,1,0,34,11,0,47,1,1,33,10,2,41,10,1,10,11,0,14,32,37,32,1,513]

theorem envBound50156 : H12AffineFastState.Bounded env50156 := by
  intro p hp
  have h : env50156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50155_50156 : H12AffineEnvironment.transform 10 0 env50155 = env50156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50155 == env50156) = true)

def env50157 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62493,21763,8193,17,157981,57629,102663,138293,75023,73770,256,21793,46092,513]

theorem envBound50157 : H12AffineFastState.Bounded env50157 := by
  intro p hp
  have h : env50157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50145_50157 : H12AffineEnvironment.transform 5 17 env50145 = env50157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50145 == env50157) = true)

theorem identity50157 : scanCanonicalize (H12AffineFastState.compose env50157 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50157 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env50158 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77850,73771,62493,21763,8193,17,67846,57629,102663,97326,75023,73770,256,21793,46092,513]

theorem envBound50158 : H12AffineFastState.Bounded env50158 := by
  intro p hp
  have h : env50158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50157_50158 : H12AffineEnvironment.transform 16 90139 env50157 = env50158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50157 == env50158) = true)

theorem identity50158 : scanCanonicalize (H12AffineFastState.compose env50158 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound50158 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50159 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,65536,90139,10280,1024,21761,77850,73771,8477,21763,8193,17,67846,13341,82951,97326,75023,73770,256,21793,24844,513]

theorem envBound50159 : H12AffineFastState.Bounded env50159 := by
  intro p hp
  have h : env50159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50158_50159 : H12AffineEnvironment.transform 14 21760 env50158 = env50159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env50158 == env50159) = true)

theorem identity50159 : scanCanonicalize (H12AffineFastState.compose env50159 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound50159 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50160 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,29963,5392,10280,1024,21761,17681,21792,8477,21763,8193,17,31757,13341,12556,2341,20484,21793,256,21793,24844,513]

theorem envBound50160 : H12AffineFastState.Bounded env50160 := by
  intro p hp
  have h : env50160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50159_50160 : H12AffineEnvironment.transform 15 29963 env50159 = env50160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env50159 == env50160) = true)

theorem identity50160 : scanCanonicalize (H12AffineFastState.compose env50160 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50160 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env50161 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,292,8495,5392,10280,1024,293,4405,260,8477,295,8193,17,10281,13341,12556,2341,1056,261,256,261,13608,513]

theorem envBound50161 : H12AffineFastState.Bounded env50161 := by
  intro p hp
  have h : env50161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50160_50161 : H12AffineEnvironment.transform 13 5156 env50160 = env50161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50160 == env50161) = true)

theorem identity50161 : scanCanonicalize (H12AffineFastState.compose env50161 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50161 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env50162 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,5156,1,8202,5173,10280,1024,0,4112,33,8248,2,8193,17,10281,13341,12329,2048,1056,32,37,32,13325,513]

theorem envBound50162 : H12AffineFastState.Bounded env50162 := by
  intro p hp
  have h : env50162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50161_50162 : H12AffineEnvironment.transform 7 37 env50161 = env50162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50161 == env50162) = true)

theorem identity50162 : scanCanonicalize (H12AffineFastState.compose env50162 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50162 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50163 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,16,8192,1076,1,8202,1061,10280,1024,0,0,33,8248,2,8193,17,10281,9229,8249,2048,1056,32,37,32,9245,513]

theorem envBound50163 : H12AffineFastState.Bounded env50163 := by
  intro p hp
  have h : env50163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50162_50163 : H12AffineEnvironment.transform 11 16 env50162 = env50163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50162 == env50163) = true)

theorem identity50163 : scanCanonicalize (H12AffineFastState.compose env50163 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound50163 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env50164 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,16,8192,1076,1,8202,1061,9245,1024,0,0,33,8248,2,8193,17,9244,9229,8249,1077,1056,32,37,32,9245,513]

theorem envBound50164 : H12AffineFastState.Bounded env50164 := by
  intro p hp
  have h : env50164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50163_50164 : H12AffineEnvironment.transform 10 1077 env50163 = env50164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env50163 == env50164) = true)

theorem identity50164 : scanCanonicalize (H12AffineFastState.compose env50164 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50164 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50165 : List Nat := [2,4,8,16,32,17,9,37,512,20,33,16,8192,32,1,8202,49,8201,20,0,0,33,8248,2,8193,17,8200,8217,8249,33,52,32,37,32,8201,513]

theorem envBound50165 : H12AffineFastState.Bounded env50165 := by
  intro p hp
  have h : env50165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50164_50165 : H12AffineEnvironment.transform 9 20 env50164 = env50165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50164 == env50165) = true)

theorem identity50165 : scanCanonicalize (H12AffineFastState.compose env50165 (packedSelected [0,1,8] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound50165 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env50166 : List Nat := [2,4,8,4,32,5,9,37,512,0,33,4,8192,32,1,8202,37,8201,0,0,0,33,8236,2,8193,5,8200,8205,8237,33,32,32,37,32,8201,513]

theorem envBound50166 : H12AffineFastState.Bounded env50166 := by
  intro p hp
  have h : env50166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50165_50166 : H12AffineEnvironment.transform 3 4 env50165 = env50166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env50165 == env50166) = true)

theorem identity50166 : scanCanonicalize (H12AffineFastState.compose env50166 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50166 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env50167 : List Nat := [2,4,8,4,32,5,9,37,512,0,33,4,41,32,1,35,37,32,0,0,0,33,5,2,40,5,33,36,4,33,32,32,37,32,32,513]

theorem envBound50167 : H12AffineFastState.Bounded env50167 := by
  intro p hp
  have h : env50167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50166_50167 : H12AffineEnvironment.transform 12 41 env50166 = env50167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50166 == env50167) = true)

theorem identity50167 : scanCanonicalize (H12AffineFastState.compose env50167 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound50167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50168 : List Nat := [2,4,8,4,32,5,9,37,10,0,33,4,41,32,1,35,37,32,0,0,0,33,5,2,40,5,33,36,4,33,32,32,37,32,32,11]

theorem envBound50168 : H12AffineFastState.Bounded env50168 := by
  intro p hp
  have h : env50168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50167_50168 : H12AffineEnvironment.transform 8 10 env50167 = env50168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env50167 == env50168) = true)

theorem identity50168 : scanCanonicalize (H12AffineFastState.compose env50168 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50169 : List Nat := [2,4,8,4,12,5,9,9,10,0,13,4,5,12,1,15,9,12,0,0,0,13,5,2,4,5,13,8,4,13,12,12,9,12,12,11]

theorem envBound50169 : H12AffineFastState.Bounded env50169 := by
  intro p hp
  have h : env50169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50168_50169 : H12AffineEnvironment.transform 4 12 env50168 = env50169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50168 == env50169) = true)

def env50170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,73770,62540,21763,8193,64,158028,57676,102742,138341,75102,73771,256,21793,46092,513]

theorem envBound50170 : H12AffineFastState.Bounded env50170 := by
  intro p hp
  have h : env50170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50144_50170 : H12AffineEnvironment.transform 17 10281 env50144 = env50170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50144 == env50170) = true)

theorem identity50170 : scanCanonicalize (H12AffineFastState.compose env50170 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50170 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,77899,73770,16,21763,8193,64,158028,5392,91402,138341,75102,73771,256,21793,16464,513]

theorem envBound50171 : H12AffineFastState.Bounded env50171 := by
  intro p hp
  have h : env50171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50170_50171 : H12AffineEnvironment.transform 14 29788 env50170 = env50171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50170 == env50171) = true)

theorem identity50171 : scanCanonicalize (H12AffineFastState.compose env50171 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound50171 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10281,1024,29789,77899,73770,16,21763,8193,64,67926,5392,91402,97407,75102,73771,256,21793,16464,513]

theorem envBound50172 : H12AffineFastState.Bounded env50172 := by
  intro p hp
  have h : env50172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50171_50172 : H12AffineEnvironment.transform 16 90138 env50171 = env50172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env50171 == env50172) = true)

theorem identity50172 : scanCanonicalize (H12AffineFastState.compose env50172 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound50172 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,28698,4096,10281,1024,29789,16465,20528,16,21763,8193,64,31052,5392,5392,3173,21828,20529,256,21793,16464,513]

theorem envBound50173 : H12AffineFastState.Bounded env50173 := by
  intro p hp
  have h : env50173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50172_50173 : H12AffineEnvironment.transform 15 28698 env50172 = env50173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env50172 == env50173) = true)

theorem identity50173 : scanCanonicalize (H12AffineFastState.compose env50173 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound50173 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16465,17431,4096,7204,1024,16464,16465,20528,16,21763,5132,64,19777,5392,5392,3173,21828,20529,256,21793,16464,513]

theorem envBound50174 : H12AffineFastState.Bounded env50174 := by
  intro p hp
  have h : env50174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50173_50174 : H12AffineEnvironment.transform 12 5133 env50173 = env50174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env50173 == env50174) = true)

theorem identity50174 : scanCanonicalize (H12AffineFastState.compose env50174 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound50174 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env50175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,16384,16465,17431,1061,2049,1024,16464,16465,17429,16,16678,41,64,19777,309,309,3173,16737,17428,256,16644,16464,513]

theorem envBound50175 : H12AffineFastState.Bounded env50175 := by
  intro p hp
  have h : env50175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50174_50175 : H12AffineEnvironment.transform 11 1061 env50174 = env50175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env50174 == env50175) = true)

theorem identity50175 : scanCanonicalize (H12AffineFastState.compose env50175 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound50175 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env50176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,2128,2049,3143,1061,2049,1024,2048,2049,3141,16,2422,41,64,1297,309,309,3173,2353,3140,256,2388,2048,513]

theorem envBound50176 : H12AffineFastState.Bounded env50176 := by
  intro p hp
  have h : env50176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50175_50176 : H12AffineEnvironment.transform 13 2128 env50175 = env50176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env50175 == env50176) = true)

theorem identity50176 : scanCanonicalize (H12AffineFastState.compose env50176 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50176 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env50177 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1061,40,2128,2049,3143,1061,2049,1024,2048,2049,3141,16,2050,41,64,1125,65,65,3173,2117,3140,116,2080,2048,513]

theorem envBound50177 : H12AffineFastState.Bounded env50177 := by
  intro p hp
  have h : env50177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50176_50177 : H12AffineEnvironment.transform 7 116 env50176 = env50177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50176 == env50177) = true)

theorem identity50177 : scanCanonicalize (H12AffineFastState.compose env50177 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound50177 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50178 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1077,1061,40,1125,1076,114,1061,1076,1024,1077,1076,112,16,1079,41,64,1125,65,65,80,1136,113,116,1045,1077,513]

theorem envBound50178 : H12AffineFastState.Bounded env50178 := by
  intro p hp
  have h : env50178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50177_50178 : H12AffineEnvironment.transform 10 1077 env50177 = env50178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env50177 == env50178) = true)

theorem identity50178 : scanCanonicalize (H12AffineFastState.compose env50178 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50178 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50179 : List Nat := [2,4,8,16,32,64,9,116,512,100,81,65,40,1,80,114,65,80,100,81,80,112,16,83,41,64,1,65,65,80,20,113,116,113,81,513]

theorem envBound50179 : H12AffineFastState.Bounded env50179 := by
  intro p hp
  have h : env50179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50178_50179 : H12AffineEnvironment.transform 9 100 env50178 = env50179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50178 == env50179) = true)

theorem identity50179 : scanCanonicalize (H12AffineFastState.compose env50179 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50179 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env50180 : List Nat := [2,4,8,16,16,64,9,68,512,84,81,65,24,1,80,66,65,80,84,81,80,64,16,83,25,64,1,65,65,80,20,65,68,65,81,513]

theorem envBound50180 : H12AffineFastState.Bounded env50180 := by
  intro p hp
  have h : env50180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50179_50180 : H12AffineEnvironment.transform 4 16 env50179 = env50180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50179 == env50180) = true)

theorem identity50180 : scanCanonicalize (H12AffineFastState.compose env50180 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound50180 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50181 : List Nat := [2,4,8,16,16,64,9,68,80,84,81,65,24,1,80,66,65,80,84,81,80,64,16,83,25,64,1,65,65,80,20,65,68,65,81,81]

theorem envBound50181 : H12AffineFastState.Bounded env50181 := by
  intro p hp
  have h : env50181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50180_50181 : H12AffineEnvironment.transform 8 80 env50180 = env50181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env50180 == env50181) = true)

def env50182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound50182 : H12AffineFastState.Bounded env50182 := by
  intro p hp
  have h : env50182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49939_50182 : H12AffineEnvironment.transform 18 1025 env49939 = env50182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49939 == env50182) = true)

theorem identity50182 : scanCanonicalize (H12AffineFastState.compose env50182 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262473) := by decide +kernel

theorem selectedBound50182 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262473,16777216,8328,64,23414216,18973836,184472,2377160,19071448,23160256,257,16990564,17014977,19015183]

theorem envBound50183 : H12AffineFastState.Bounded env50183 := by
  intro p hp
  have h : env50183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50182_50183 : H12AffineEnvironment.transform 22 2262473 env50182 = env50183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262473 env50182 == env50183) = true)

def env50184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262473,201796,8328,64,6705548,2265288,184472,2377160,2102684,6451588,257,21792,46213,2175563]

theorem envBound50184 : H12AffineFastState.Bounded env50184 := by
  intro p hp
  have h : env50184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50183_50184 : H12AffineEnvironment.transform 23 201796 env50183 = env50184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201796 env50183 == env50184) = true)

def env50185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603796,2098512,17664,2377160,2102684,6349852,257,21792,46213,2175563]

theorem envBound50185 : H12AffineFastState.Bounded env50185 := by
  intro p hp
  have h : env50185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50184_50185 : H12AffineEnvironment.transform 16 38296 env50184 = env50185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env50184 == env50185) = true)

def env50186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157716,2098512,17664,2377160,2102684,2411676,257,21792,46213,2175563]

theorem envBound50186 : H12AffineFastState.Bounded env50186 := by
  intro p hp
  have h : env50186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50185_50186 : H12AffineEnvironment.transform 21 272512 env50185 = env50186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50185 == env50186) = true)

theorem identity50186 : scanCanonicalize (H12AffineFastState.compose env50186 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50186 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,2097152,272512,2101329,41430,8328,64,2157716,2098512,17664,2377160,2102684,2411676,257,21792,46213,2101825]

theorem envBound50187 : H12AffineFastState.Bounded env50187 := by
  intro p hp
  have h : env50187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50186_50187 : H12AffineEnvironment.transform 15 8202 env50186 = env50187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50186 == env50187) = true)

def env50188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,2097152,272392,2101329,41310,8192,64,2157596,2098512,17664,2377024,2102548,2411540,257,21792,46093,2101825]

theorem envBound50188 : H12AffineFastState.Bounded env50188 := by
  intro p hp
  have h : env50188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50187_50188 : H12AffineEnvironment.transform 6 8 env50187 = env50188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50187 == env50188) = true)

theorem identity50188 : scanCanonicalize (H12AffineFastState.compose env50188 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276585) := by decide +kernel

theorem selectedBound50188 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,276585,272392,272440,41310,8192,64,316533,277817,17664,32041,273789,62589,257,21792,46093,272936]

theorem envBound50189 : H12AffineFastState.Bounded env50189 := by
  intro p hp
  have h : env50189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50188_50189 : H12AffineEnvironment.transform 20 276585 env50188 = env50189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276585 env50188 == env50189) = true)

theorem identity50189 : scanCanonicalize (H12AffineFastState.compose env50189 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50189 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10280,1025,32769,4161,32,16,41310,8192,64,64605,5393,17664,32041,1365,62589,257,21792,46093,512]

theorem envBound50190 : H12AffineFastState.Bounded env50190 := by
  intro p hp
  have h : env50190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50189_50190 : H12AffineEnvironment.transform 17 10280 env50189 = env50190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50189 == env50190) = true)

theorem identity50190 : scanCanonicalize (H12AffineFastState.compose env50190 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 12621) := by decide +kernel

theorem selectedBound50190 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,12621,8202,9309,10280,1025,12620,4161,32,16,4115,8192,64,19728,5393,17664,32041,1365,17712,257,21792,1344,512]

theorem envBound50191 : H12AffineFastState.Bounded env50191 := by
  intro p hp
  have h : env50191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50190_50191 : H12AffineEnvironment.transform 14 12621 env50190 = env50191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12621 env50190 == env50191) = true)

theorem identity50191 : scanCanonicalize (H12AffineFastState.compose env50191 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound50191 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1125,12621,8202,9309,10280,1025,12620,4161,32,16,4115,8192,64,2421,5393,357,14668,1365,341,257,4421,1344,512]

theorem envBound50192 : H12AffineFastState.Bounded env50192 := by
  intro p hp
  have h : env50192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50191_50192 : H12AffineEnvironment.transform 13 1125 env50191 = env50192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env50191 == env50192) = true)

theorem identity50192 : scanCanonicalize (H12AffineFastState.compose env50192 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound50192 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env50193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,97,8192,1125,8492,8202,9309,10280,1025,8493,32,32,16,114,8192,64,2421,1392,357,10541,1365,341,257,292,1344,512]

theorem envBound50193 : H12AffineFastState.Bounded env50193 := by
  intro p hp
  have h : env50193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50192_50193 : H12AffineEnvironment.transform 11 97 env50192 = env50193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env50192 == env50193) = true)

def env50194 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,2097152,272393,2101329,41311,8193,64,2157597,2098512,17664,2377025,2102549,2411541,257,21792,46092,2101825]

theorem envBound50194 : H12AffineFastState.Bounded env50194 := by
  intro p hp
  have h : env50194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50187_50194 : H12AffineEnvironment.transform 6 9 env50187 = env50194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50187 == env50194) = true)

theorem identity50194 : scanCanonicalize (H12AffineFastState.compose env50194 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301365) := by decide +kernel

theorem selectedBound50194 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,301365,272393,297316,41311,8193,64,292136,302181,17664,56436,298016,21792,257,21792,46092,297844]

theorem envBound50195 : H12AffineFastState.Bounded env50195 := by
  intro p hp
  have h : env50195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50194_50195 : H12AffineEnvironment.transform 20 301365 env50194 = env50195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301365 env50194 == env50195) = true)

theorem identity50195 : scanCanonicalize (H12AffineFastState.compose env50195 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 64605) := by decide +kernel

theorem selectedBound50195 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,64605,1025,32769,25960,54356,30009,41311,8193,64,35189,24632,17664,56436,28797,21792,257,21792,46092,30505]

theorem envBound50196 : H12AffineFastState.Bounded env50196 := by
  intro p hp
  have h : env50196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50195_50196 : H12AffineEnvironment.transform 17 64605 env50195 = env50196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64605 env50195 == env50196) = true)

theorem identity50196 : scanCanonicalize (H12AffineFastState.compose env50196 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound50196 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env50197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,8202,38161,35188,1025,32769,4161,41341,16,41311,8193,64,35189,5393,12329,43357,1364,8201,257,8201,46092,512]

theorem envBound50197 : H12AffineFastState.Bounded env50197 := by
  intro p hp
  have h : env50197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50196_50197 : H12AffineEnvironment.transform 13 13609 env50196 = env50197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env50196 == env50197) = true)

theorem identity50197 : scanCanonicalize (H12AffineFastState.compose env50197 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50197 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,0,8202,5393,2420,1025,1,4161,8573,16,8543,8193,64,2421,5393,12329,10589,1364,8201,257,8201,13324,512]

theorem envBound50198 : H12AffineFastState.Bounded env50198 := by
  intro p hp
  have h : env50198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50197_50198 : H12AffineEnvironment.transform 14 0 env50197 = env50198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50197 == env50198) = true)

theorem identity50198 : scanCanonicalize (H12AffineFastState.compose env50198 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50198 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env50199 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13609,0,8202,5393,2341,1025,1,4112,8492,16,8462,8193,17,2340,5393,12329,10508,1285,8201,257,8201,13324,512]

theorem envBound50199 : H12AffineFastState.Bounded env50199 := by
  intro p hp
  have h : env50199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50198_50199 : H12AffineEnvironment.transform 5 17 env50198 = env50199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50198 == env50199) = true)

theorem identity50199 : scanCanonicalize (H12AffineFastState.compose env50199 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound50199 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env50200 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7180,2341,0,7174,5393,2341,1025,1,4112,7456,16,7426,7181,17,2340,5393,3109,5376,1285,7173,257,7173,2048,512]

theorem envBound50200 : H12AffineFastState.Bounded env50200 := by
  intro p hp
  have h : env50200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50199_50200 : H12AffineEnvironment.transform 12 7180 env50199 = env50200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env50199 == env50200) = true)

theorem identity50200 : scanCanonicalize (H12AffineFastState.compose env50200 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound50200 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env50201 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,3132,2341,0,3126,1313,2341,1025,1,32,3344,16,3378,3133,17,2340,1313,3109,1328,1285,3125,257,3125,2048,512]

theorem envBound50201 : H12AffineFastState.Bounded env50201 := by
  intro p hp
  have h : env50201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50200_50201 : H12AffineEnvironment.transform 11 48 env50200 = env50201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50200 == env50201) = true)

theorem identity50201 : scanCanonicalize (H12AffineFastState.compose env50201 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound50201 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env50202 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1044,48,40,1329,0,34,1313,1329,1025,1,32,260,16,294,41,17,1328,1313,49,1328,1285,33,257,33,1044,512]

theorem envBound50202 : H12AffineFastState.Bounded env50202 := by
  intro p hp
  have h : env50202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50201_50202 : H12AffineEnvironment.transform 10 1044 env50201 = env50202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env50201 == env50202) = true)

theorem identity50202 : scanCanonicalize (H12AffineFastState.compose env50202 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50203 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1044,48,40,1044,0,34,1028,1044,1025,1,32,33,16,3,41,17,1045,1028,49,1045,1056,33,36,33,1044,512]

theorem envBound50203 : H12AffineFastState.Bounded env50203 := by
  intro p hp
  have h : env50203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50202_50203 : H12AffineEnvironment.transform 7 37 env50202 = env50203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50202 == env50203) = true)

theorem identity50203 : scanCanonicalize (H12AffineFastState.compose env50203 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound50203 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50204 : List Nat := [2,4,8,16,32,17,9,37,512,17,5,48,40,5,0,34,21,5,16,1,32,33,16,3,41,17,4,21,49,4,49,33,36,33,5,512]

theorem envBound50204 : H12AffineFastState.Bounded env50204 := by
  intro p hp
  have h : env50204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50203_50204 : H12AffineEnvironment.transform 9 17 env50203 = env50204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env50203 == env50204) = true)

theorem identity50204 : scanCanonicalize (H12AffineFastState.compose env50204 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound50204 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50205 : List Nat := [2,4,8,16,32,17,9,37,11,17,5,48,40,5,0,34,21,5,16,1,32,33,16,3,41,17,4,21,49,4,49,33,36,33,5,11]

theorem envBound50205 : H12AffineFastState.Bounded env50205 := by
  intro p hp
  have h : env50205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50204_50205 : H12AffineEnvironment.transform 8 11 env50204 = env50205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env50204 == env50205) = true)

theorem identity50205 : scanCanonicalize (H12AffineFastState.compose env50205 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50205 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50206 : List Nat := [2,0,8,16,32,17,9,33,11,17,1,48,40,1,0,34,17,1,16,1,32,33,16,3,41,17,0,17,49,0,49,33,32,33,1,11]

theorem envBound50206 : H12AffineFastState.Bounded env50206 := by
  intro p hp
  have h : env50206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50205_50206 : H12AffineEnvironment.transform 1 0 env50205 = env50206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50205 == env50206) = true)

theorem identity50206 : scanCanonicalize (H12AffineFastState.compose env50206 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound50206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50207 : List Nat := [2,0,8,16,3,17,9,2,11,17,1,19,11,1,0,1,17,1,16,1,3,2,16,3,10,17,0,17,18,0,18,2,3,2,1,11]

theorem envBound50207 : H12AffineFastState.Bounded env50207 := by
  intro p hp
  have h : env50207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50206_50207 : H12AffineEnvironment.transform 4 3 env50206 = env50207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env50206 == env50207) = true)

theorem identity50207 : scanCanonicalize (H12AffineFastState.compose env50207 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50207 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50208 : List Nat := [1,0,8,16,0,17,9,1,8,17,1,16,8,1,0,1,17,1,16,1,0,1,16,0,9,17,0,17,17,0,17,1,0,1,1,8]

theorem envBound50208 : H12AffineFastState.Bounded env50208 := by
  intro p hp
  have h : env50208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50207_50208 : H12AffineEnvironment.transform 0 1 env50207 = env50208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50207 == env50208) = true)

def env50209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157717,2098512,17664,2377160,2102684,2411677,257,21792,46213,2175563]

theorem envBound50209 : H12AffineFastState.Bounded env50209 := by
  intro p hp
  have h : env50209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50185_50209 : H12AffineEnvironment.transform 21 272513 env50185 = env50209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50185 == env50209) = true)

theorem identity50209 : scanCanonicalize (H12AffineFastState.compose env50209 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound50209 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,77898,272513,73755,98780,8328,64,122079,79130,17664,357762,75222,392407,257,21792,46213,513]

theorem envBound50210 : H12AffineFastState.Bounded env50210 := by
  intro p hp
  have h : env50210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50209_50210 : H12AffineEnvironment.transform 20 77898 env50209 = env50210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env50209 == env50210) = true)

def env50211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272393,73755,98644,8192,64,121943,79130,17664,357642,75102,392287,257,21792,46093,513]

theorem envBound50211 : H12AffineFastState.Bounded env50211 := by
  intro p hp
  have h : env50211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50210_50211 : H12AffineEnvironment.transform 6 8 env50210 = env50211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50210 == env50211) = true)

def env50212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,77898,33,73755,98644,8192,64,121943,79130,17664,89378,75102,119927,257,21792,46093,513]

theorem envBound50212 : H12AffineFastState.Bounded env50212 := by
  intro p hp
  have h : env50212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50211_50212 : H12AffineEnvironment.transform 17 10280 env50211 = env50212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50211 == env50212) = true)

theorem identity50212 : scanCanonicalize (H12AffineFastState.compose env50212 (packedSelected [2,6,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound50212 : packedSelected [2,6,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env50213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,10280,1025,21760,77898,33,73755,87125,8192,64,67926,79130,17664,89378,75102,65910,257,21792,24844,513]

theorem envBound50213 : H12AffineFastState.Bounded env50213 := by
  intro p hp
  have h : env50213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50212_50213 : H12AffineEnvironment.transform 14 21761 env50212 = env50213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env50212 == env50213) = true)

theorem identity50213 : scanCanonicalize (H12AffineFastState.compose env50213 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound50213 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env50214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21591,16401,10280,1025,21760,25629,33,29772,2,8192,64,23809,24909,17664,2421,28937,21793,257,21792,24844,513]

theorem envBound50214 : H12AffineFastState.Bounded env50214 := by
  intro p hp
  have h : env50214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50213_50214 : H12AffineEnvironment.transform 15 21591 env50213 = env50214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env50213 == env50214) = true)

theorem identity50214 : scanCanonicalize (H12AffineFastState.compose env50214 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50214 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21591,16401,2421,1025,21760,17728,33,21777,2,349,64,23809,16400,17664,2421,20564,21793,257,21792,16465,513]

theorem envBound50215 : H12AffineFastState.Bounded env50215 := by
  intro p hp
  have h : env50215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50214_50215 : H12AffineEnvironment.transform 12 349 env50214 = env50215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50214 == env50215) = true)

theorem identity50215 : scanCanonicalize (H12AffineFastState.compose env50215 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound50215 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,263,5441,2421,1025,80,4112,33,65,2,349,64,2129,5440,4176,2421,1284,113,257,112,5377,513]

theorem envBound50216 : H12AffineFastState.Bounded env50216 := by
  intro p hp
  have h : env50216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50215_50216 : H12AffineEnvironment.transform 13 5456 env50215 = env50216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env50215 == env50216) = true)

theorem identity50216 : scanCanonicalize (H12AffineFastState.compose env50216 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50216 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env50217 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5392,2340,1025,1,4112,33,16,2,268,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound50217 : H12AffineFastState.Bounded env50217 := by
  intro p hp
  have h : env50217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50216_50217 : H12AffineEnvironment.transform 5 17 env50216 = env50217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50216 == env50217) = true)

theorem identity50217 : scanCanonicalize (H12AffineFastState.compose env50217 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50218 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5173,2049,1025,1,4112,33,16,2,41,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound50218 : H12AffineFastState.Bounded env50218 := by
  intro p hp
  have h : env50218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50217_50218 : H12AffineEnvironment.transform 7 37 env50217 = env50218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50217 == env50218) = true)

def env50219 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,0,34,1029,2049,1025,1,32,33,16,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound50219 : H12AffineFastState.Bounded env50219 := by
  intro p hp
  have h : env50219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50218_50219 : H12AffineEnvironment.transform 11 48 env50218 = env50219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50218 == env50219) = true)

theorem identity50219 : scanCanonicalize (H12AffineFastState.compose env50219 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50220 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,48,41,1044,0,34,1029,2049,1025,1,32,33,16,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,16]

theorem envBound50220 : H12AffineFastState.Bounded env50220 := by
  intro p hp
  have h : env50220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50219_50220 : H12AffineEnvironment.transform 8 17 env50219 = env50220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50219 == env50220) = true)

def env50221 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,41,32,0,34,49,2049,53,1,32,33,16,2,41,17,2048,48,49,2049,21,32,36,33,32,16]

theorem envBound50221 : H12AffineFastState.Bounded env50221 := by
  intro p hp
  have h : env50221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50220_50221 : H12AffineEnvironment.transform 9 52 env50220 = env50221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50220 == env50221) = true)

theorem identity50221 : scanCanonicalize (H12AffineFastState.compose env50221 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound50221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50222 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,48,41,32,0,34,49,33,53,1,32,33,16,2,41,17,32,48,49,33,21,32,36,33,32,16]

theorem envBound50222 : H12AffineFastState.Bounded env50222 := by
  intro p hp
  have h : env50222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50221_50222 : H12AffineEnvironment.transform 10 32 env50221 = env50222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env50221 == env50222) = true)

def leafEnv50222 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,48,41,32,0,34,49,33,53,1,32,33,16,2,20,41,1,17,32,48,49,33,21,32,36,33,5,34,32,16,1,32,0]

def active50222 : List Nat := [0,1,2,3,4]

def tree50222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50222 : H12WitnessSearch.Good tree50222 := H12GlobalWitnessIndex.good

theorem leafIdentity50222 : H12AffineFastState.composeSystem env50222 rootObs = leafEnv50222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50222 rootObs == leafEnv50222) = true)

theorem terminalChecked50222 : H12PackedTerminal.terminalCheckFast leafEnv50222 active50222 tree50222 = true := by decide +kernel

def env50223 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,41,33,0,34,48,2049,52,1,32,33,16,2,41,17,2048,49,49,2049,20,32,36,33,33,16]

theorem envBound50223 : H12AffineFastState.Bounded env50223 := by
  intro p hp
  have h : env50223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50220_50223 : H12AffineEnvironment.transform 9 53 env50220 = env50223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50220 == env50223) = true)

theorem identity50223 : scanCanonicalize (H12AffineFastState.compose env50223 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound50223 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50224 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,41,33,0,34,48,27,52,1,32,33,16,2,41,17,26,49,49,27,20,32,36,33,33,16]

theorem envBound50224 : H12AffineFastState.Bounded env50224 := by
  intro p hp
  have h : env50224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50223_50224 : H12AffineEnvironment.transform 10 26 env50223 = env50224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env50223 == env50224) = true)

def leafEnv50224 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,41,33,0,34,48,27,52,1,32,33,16,2,21,41,1,17,26,49,49,27,20,32,36,33,5,34,33,16,1,32,0]

def active50224 : List Nat := [0,1,2,3,4]

def tree50224 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50224 : H12WitnessSearch.Good tree50224 := H12GlobalWitnessIndex.good

theorem leafIdentity50224 : H12AffineFastState.composeSystem env50224 rootObs = leafEnv50224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50224 rootObs == leafEnv50224) = true)

theorem terminalChecked50224 : H12PackedTerminal.terminalCheckFast leafEnv50224 active50224 tree50224 = true := by decide +kernel

def env50225 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,0,34,1028,2049,1025,1,33,33,16,2,41,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound50225 : H12AffineFastState.Bounded env50225 := by
  intro p hp
  have h : env50225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50218_50225 : H12AffineEnvironment.transform 11 49 env50218 = env50225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50218 == env50225) = true)

theorem identity50225 : scanCanonicalize (H12AffineFastState.compose env50225 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound50225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50226 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,49,41,561,0,34,544,2049,549,1,33,33,16,2,41,17,2048,545,48,2049,517,32,36,33,561,513]

theorem envBound50226 : H12AffineFastState.Bounded env50226 := by
  intro p hp
  have h : env50226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50225_50226 : H12AffineEnvironment.transform 9 548 env50225 = env50226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env50225 == env50226) = true)

def env50227 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,41,33,0,34,48,2049,53,1,33,33,16,2,41,17,2048,49,48,2049,21,32,36,33,33,17]

theorem envBound50227 : H12AffineFastState.Bounded env50227 := by
  intro p hp
  have h : env50227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50226_50227 : H12AffineEnvironment.transform 8 16 env50226 = env50227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50226 == env50227) = true)

theorem identity50227 : scanCanonicalize (H12AffineFastState.compose env50227 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound50227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50228 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,49,41,33,0,34,48,32,53,1,33,33,16,2,41,17,33,49,48,32,21,32,36,33,33,17]

theorem envBound50228 : H12AffineFastState.Bounded env50228 := by
  intro p hp
  have h : env50228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50227_50228 : H12AffineEnvironment.transform 10 33 env50227 = env50228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env50227 == env50228) = true)

def leafEnv50228 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,49,41,33,0,34,48,32,53,1,33,33,16,2,20,41,1,17,33,49,48,32,21,32,36,33,5,34,33,17,1,33,0]

def active50228 : List Nat := [0,1,2,3,4]

def tree50228 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50228 : H12WitnessSearch.Good tree50228 := H12GlobalWitnessIndex.good

theorem leafIdentity50228 : H12AffineFastState.composeSystem env50228 rootObs = leafEnv50228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50228 rootObs == leafEnv50228) = true)

theorem terminalChecked50228 : H12PackedTerminal.terminalCheckFast leafEnv50228 active50228 tree50228 = true := by decide +kernel

def env50229 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,41,32,0,34,49,2049,52,1,33,33,16,2,41,17,2048,48,48,2049,20,32,36,33,32,16]

theorem envBound50229 : H12AffineFastState.Bounded env50229 := by
  intro p hp
  have h : env50229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50226_50229 : H12AffineEnvironment.transform 8 17 env50226 = env50229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50226 == env50229) = true)

theorem identity50229 : scanCanonicalize (H12AffineFastState.compose env50229 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound50229 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50230 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,41,32,0,34,49,27,52,1,33,33,16,2,41,17,26,48,48,27,20,32,36,33,32,16]

theorem envBound50230 : H12AffineFastState.Bounded env50230 := by
  intro p hp
  have h : env50230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50229_50230 : H12AffineEnvironment.transform 10 26 env50229 = env50230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env50229 == env50230) = true)

def leafEnv50230 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,41,32,0,34,49,27,52,1,33,33,16,2,21,41,1,17,26,48,48,27,20,32,36,33,5,34,32,16,1,33,0]

def active50230 : List Nat := [0,1,2,3,4]

def tree50230 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50230 : H12WitnessSearch.Good tree50230 := H12GlobalWitnessIndex.good

theorem leafIdentity50230 : H12AffineFastState.composeSystem env50230 rootObs = leafEnv50230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50230 rootObs == leafEnv50230) = true)

theorem terminalChecked50230 : H12PackedTerminal.terminalCheckFast leafEnv50230 active50230 tree50230 = true := by decide +kernel

def env50231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77898,32,73755,98644,8192,64,121943,79130,17664,89379,75102,119926,257,21792,46093,513]

theorem envBound50231 : H12AffineFastState.Bounded env50231 := by
  intro p hp
  have h : env50231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50211_50231 : H12AffineEnvironment.transform 17 10281 env50211 = env50231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50211 == env50231) = true)

theorem identity50231 : scanCanonicalize (H12AffineFastState.compose env50231 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50231 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4161,32,16,41311,8192,64,64604,5393,17664,32040,1365,62589,257,21792,46093,513]

theorem envBound50232 : H12AffineFastState.Bounded env50232 := by
  intro p hp
  have h : env50232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50231_50232 : H12AffineEnvironment.transform 15 8203 env50231 = env50232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50231 == env50232) = true)

theorem identity50232 : scanCanonicalize (H12AffineFastState.compose env50232 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound50232 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,32768,3143,38160,1125,1025,32769,4161,32,16,36115,3148,64,53264,5393,17664,20836,1365,55345,257,21792,38977,513]

theorem envBound50233 : H12AffineFastState.Bounded env50233 := by
  intro p hp
  have h : env50233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50232_50233 : H12AffineEnvironment.transform 12 3148 env50232 = env50233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env50232 == env50233) = true)

theorem identity50233 : scanCanonicalize (H12AffineFastState.compose env50233 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound50233 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,21761,3143,16401,1125,1025,21760,4161,32,16,22546,3148,64,1297,5393,17664,20836,1365,3376,257,21792,19776,513]

theorem envBound50234 : H12AffineFastState.Bounded env50234 := by
  intro p hp
  have h : env50234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50233_50234 : H12AffineEnvironment.transform 14 21761 env50233 = env50234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env50233 == env50234) = true)

theorem identity50234 : scanCanonicalize (H12AffineFastState.compose env50234 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound50234 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,349,16384,21761,342,16401,1125,1025,21760,4161,32,16,21763,349,64,1297,5393,17664,20836,1365,33,257,21792,16465,513]

theorem envBound50235 : H12AffineFastState.Bounded env50235 := by
  intro p hp
  have h : env50235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50234_50235 : H12AffineEnvironment.transform 10 1297 env50234 = env50235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env50234 == env50235) = true)

theorem identity50235 : scanCanonicalize (H12AffineFastState.compose env50235 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50235 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50236 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,16384,21540,115,16401,1125,1025,21541,4161,32,16,21542,120,64,1076,5172,17445,20545,1136,33,36,21509,16465,513]

theorem envBound50236 : H12AffineFastState.Bounded env50236 := by
  intro p hp
  have h : env50236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50235_50236 : H12AffineEnvironment.transform 7 37 env50235 = env50236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50235 == env50236) = true)

theorem identity50236 : scanCanonicalize (H12AffineFastState.compose env50236 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound50236 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env50237 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,4112,1076,115,4097,1125,1025,1077,4161,32,16,1078,120,64,1076,5172,5173,81,1136,33,36,1045,4161,513]

theorem envBound50237 : H12AffineFastState.Bounded env50237 := by
  intro p hp
  have h : env50237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50236_50237 : H12AffineEnvironment.transform 13 4112 env50236 = env50237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env50236 == env50237) = true)

theorem identity50237 : scanCanonicalize (H12AffineFastState.compose env50237 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50237 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50238 : List Nat := [2,4,8,16,32,64,8,37,512,100,80,4096,120,4112,80,115,4097,1,101,81,4161,32,16,82,120,64,80,4176,4177,81,20,33,36,113,4161,513]

theorem envBound50238 : H12AffineFastState.Bounded env50238 := by
  intro p hp
  have h : env50238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50237_50238 : H12AffineEnvironment.transform 9 100 env50237 = env50238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50237 == env50238) = true)

theorem identity50238 : scanCanonicalize (H12AffineFastState.compose env50238 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50238 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50239 : List Nat := [2,4,8,16,32,64,8,37,512,100,80,17,120,1,80,115,16,1,101,81,80,32,16,82,120,64,80,65,64,81,20,33,36,113,80,513]

theorem envBound50239 : H12AffineFastState.Bounded env50239 := by
  intro p hp
  have h : env50239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50238_50239 : H12AffineEnvironment.transform 11 17 env50238 = env50239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50238 == env50239) = true)

theorem identity50239 : scanCanonicalize (H12AffineFastState.compose env50239 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50239 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50240 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,17,41,1,1,34,16,1,52,0,1,32,16,3,41,17,1,16,17,0,20,33,36,32,1,513]

theorem envBound50240 : H12AffineFastState.Bounded env50240 := by
  intro p hp
  have h : env50240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50239_50240 : H12AffineEnvironment.transform 5 17 env50239 = env50240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50239 == env50240) = true)

theorem identity50240 : scanCanonicalize (H12AffineFastState.compose env50240 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50241 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,1,1,3,16,1,21,0,1,1,16,3,8,17,1,16,17,0,20,0,5,1,1,513]

theorem envBound50241 : H12AffineFastState.Bounded env50241 := by
  intro p hp
  have h : env50241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50240_50241 : H12AffineEnvironment.transform 4 1 env50240 = env50241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50240 == env50241) = true)

theorem identity50241 : scanCanonicalize (H12AffineFastState.compose env50241 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50242 : List Nat := [2,4,8,16,1,17,8,4,16,20,1,17,8,1,1,3,16,1,21,0,1,1,16,3,8,17,1,16,17,0,20,0,5,1,1,17]

theorem envBound50242 : H12AffineFastState.Bounded env50242 := by
  intro p hp
  have h : env50242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50241_50242 : H12AffineEnvironment.transform 8 16 env50241 = env50242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50241 == env50242) = true)

def env50243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272392,73755,98645,8193,64,121942,79130,17664,357643,75103,392286,257,21792,46092,513]

theorem envBound50243 : H12AffineFastState.Bounded env50243 := by
  intro p hp
  have h : env50243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50210_50243 : H12AffineEnvironment.transform 6 9 env50210 = env50243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50210 == env50243) = true)

theorem identity50243 : scanCanonicalize (H12AffineFastState.compose env50243 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound50243 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,50497,272392,54544,29790,8193,64,10589,49169,17664,294912,53332,264533,257,21792,46092,513]

theorem envBound50244 : H12AffineFastState.Bounded env50244 := by
  intro p hp
  have h : env50244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50243_50244 : H12AffineEnvironment.transform 15 62731 env50243 = env50244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env50243 == env50244) = true)

theorem identity50244 : scanCanonicalize (H12AffineFastState.compose env50244 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound50244 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env50245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,10589,1025,32769,50497,341,54544,29790,8193,64,10589,49169,17664,43357,53332,8200,257,21792,46092,513]

theorem envBound50245 : H12AffineFastState.Bounded env50245 := by
  intro p hp
  have h : env50245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50244_50245 : H12AffineEnvironment.transform 17 10589 env50244 = env50245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env50244 == env50245) = true)

theorem identity50245 : scanCanonicalize (H12AffineFastState.compose env50245 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound50245 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env50246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8313,21874,13672,10589,1025,8312,25912,341,30057,29790,8193,64,10589,24680,17664,2340,28717,8200,257,21792,5237,513]

theorem envBound50246 : H12AffineFastState.Bounded env50246 := by
  intro p hp
  have h : env50246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50245_50246 : H12AffineEnvironment.transform 14 8313 env50245 = env50246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env50245 == env50246) = true)

theorem identity50246 : scanCanonicalize (H12AffineFastState.compose env50246 (packedSelected [1,2,3,4,6,8,9,10,11,12,14,15,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound50246 : packedSelected [1,2,3,4,6,8,9,10,11,12,14,15,18,20,24] rootPS < 2^1333 := by decide +kernel

def env50247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,8313,1047,13672,10589,1025,8312,13405,341,9228,9531,8193,64,10589,12557,5221,2340,8520,8200,257,1093,5237,513]

theorem envBound50247 : H12AffineFastState.Bounded env50247 := by
  intro p hp
  have h : env50247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50246_50247 : H12AffineEnvironment.transform 13 4453 env50246 = env50247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env50246 == env50247) = true)

theorem identity50247 : scanCanonicalize (H12AffineFastState.compose env50247 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound50247 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env50248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,4453,1125,1047,4468,3393,1025,1124,4161,341,16,295,1053,64,3393,5393,5221,2340,1364,1044,257,1093,5237,513]

theorem envBound50248 : H12AffineFastState.Bounded env50248 := by
  intro p hp
  have h : env50248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50247_50248 : H12AffineEnvironment.transform 12 1052 env50247 = env50248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env50247 == env50248) = true)

theorem identity50248 : scanCanonicalize (H12AffineFastState.compose env50248 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50248 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50249 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,40,4453,81,35,4468,2421,53,80,4161,341,16,295,41,64,2421,4389,4177,2340,352,32,257,113,4161,513]

theorem envBound50249 : H12AffineFastState.Bounded env50249 := by
  intro p hp
  have h : env50249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50248_50249 : H12AffineEnvironment.transform 9 52 env50248 = env50249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50248 == env50249) = true)

theorem identity50249 : scanCanonicalize (H12AffineFastState.compose env50249 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50249 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50250 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,40,4404,0,35,4389,2340,53,1,4112,260,16,295,41,17,2340,4389,4096,2340,305,32,257,32,4112,513]

theorem envBound50250 : H12AffineFastState.Bounded env50250 := by
  intro p hp
  have h : env50250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50249_50250 : H12AffineEnvironment.transform 5 17 env50249 = env50250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50249 == env50250) = true)

theorem identity50250 : scanCanonicalize (H12AffineFastState.compose env50250 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50250 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50251 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,0,35,4096,2049,53,1,4112,33,16,2,41,17,2049,4096,4096,2049,20,32,36,32,4112,513]

theorem envBound50251 : H12AffineFastState.Bounded env50251 := by
  intro p hp
  have h : env50251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50250_50251 : H12AffineEnvironment.transform 7 37 env50250 = env50251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50250 == env50251) = true)

theorem identity50251 : scanCanonicalize (H12AffineFastState.compose env50251 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50252 : List Nat := [2,4,8,16,32,17,9,37,0,52,2048,4096,40,4113,0,35,4096,2049,53,1,4112,33,16,2,41,17,2049,4096,4096,2049,20,32,36,32,4112,1]

theorem envBound50252 : H12AffineFastState.Bounded env50252 := by
  intro p hp
  have h : env50252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50251_50252 : H12AffineEnvironment.transform 8 0 env50251 = env50252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50251 == env50252) = true)

theorem identity50252 : scanCanonicalize (H12AffineFastState.compose env50252 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound50252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50253 : List Nat := [2,4,8,16,32,17,9,37,0,52,27,4096,40,4113,0,35,4096,26,53,1,4112,33,16,2,41,17,26,4096,4096,26,20,32,36,32,4112,1]

theorem envBound50253 : H12AffineFastState.Bounded env50253 := by
  intro p hp
  have h : env50253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50252_50253 : H12AffineEnvironment.transform 10 27 env50252 = env50253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env50252 == env50253) = true)

theorem identity50253 : scanCanonicalize (H12AffineFastState.compose env50253 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50253 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50254 : List Nat := [2,4,8,16,32,17,9,37,0,52,27,17,40,0,0,35,17,26,53,1,1,33,16,2,41,17,26,17,17,26,20,32,36,32,1,1]

theorem envBound50254 : H12AffineFastState.Bounded env50254 := by
  intro p hp
  have h : env50254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50253_50254 : H12AffineEnvironment.transform 11 17 env50253 = env50254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50253 == env50254) = true)

theorem identity50254 : scanCanonicalize (H12AffineFastState.compose env50254 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50254 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50255 : List Nat := [2,4,8,11,32,10,9,37,0,47,0,10,40,0,0,35,10,1,46,1,1,33,11,2,41,10,1,10,10,1,15,32,36,32,1,1]

theorem envBound50255 : H12AffineFastState.Bounded env50255 := by
  intro p hp
  have h : env50255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50254_50255 : H12AffineEnvironment.transform 3 11 env50254 = env50255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50254 == env50255) = true)

def env50256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603797,2098513,17665,2377160,2102684,6349853,257,21792,46213,2175563]

theorem envBound50256 : H12AffineFastState.Bounded env50256 := by
  intro p hp
  have h : env50256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50184_50256 : H12AffineEnvironment.transform 16 38297 env50184 = env50256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env50184 == env50256) = true)

def env50257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157717,2098513,17665,2377160,2102684,2411677,257,21792,46213,2175563]

theorem envBound50257 : H12AffineFastState.Bounded env50257 := by
  intro p hp
  have h : env50257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50256_50257 : H12AffineEnvironment.transform 21 272512 env50256 = env50257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50256 == env50257) = true)

theorem identity50257 : scanCanonicalize (H12AffineFastState.compose env50257 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound50257 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38297,262144,1025,32769,2097152,272512,2101328,21762,8328,64,2157717,2098513,17665,2377160,2102684,2411677,257,21792,46213,2156180]

theorem envBound50258 : H12AffineFastState.Bounded env50258 := by
  intro p hp
  have h : env50258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50257_50258 : H12AffineEnvironment.transform 15 54495 env50257 = env50258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env50257 == env50258) = true)

def env50259 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,2097152,272512,2101248,21762,8328,16,2157717,2098433,17665,2377112,2102684,2411677,257,21792,46213,2156180]

theorem envBound50259 : H12AffineFastState.Bounded env50259 := by
  intro p hp
  have h : env50259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50258_50259 : H12AffineEnvironment.transform 5 16 env50258 = env50259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50258 == env50259) = true)

theorem identity50259 : scanCanonicalize (H12AffineFastState.compose env50259 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound50259 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env50260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,58397,272512,62493,21762,8328,16,2184,57628,17665,303493,61825,272512,257,21792,46213,649]

theorem envBound50260 : H12AffineFastState.Bounded env50260 := by
  intro p hp
  have h : env50260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50259_50260 : H12AffineEnvironment.transform 20 58397 env50259 = env50260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env50259 == env50260) = true)

theorem identity50260 : scanCanonicalize (H12AffineFastState.compose env50260 (packedSelected [1,3,5,12,15,17,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound50260 : packedSelected [1,3,5,12,15,17,26,28] rootPS < 2^1333 := by decide +kernel

def env50261 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,32161,1025,32769,58397,21793,62493,21762,8328,16,2184,57628,17665,56356,61825,21793,257,21792,46213,649]

theorem envBound50261 : H12AffineFastState.Bounded env50261 := by
  intro p hp
  have h : env50261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50260_50261 : H12AffineEnvironment.transform 17 32161 env50260 = env50261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env50260 == env50261) = true)

theorem identity50261 : scanCanonicalize (H12AffineFastState.compose env50261 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound50261 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env50262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,262,16400,32161,1025,21896,12692,21793,8596,21762,8328,16,2184,13461,17665,2477,9224,21793,257,21792,24844,649]

theorem envBound50262 : H12AffineFastState.Bounded env50262 := by
  intro p hp
  have h : env50262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50261_50262 : H12AffineEnvironment.transform 14 21897 env50261 = env50262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env50261 == env50262) = true)

theorem identity50262 : scanCanonicalize (H12AffineFastState.compose env50262 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50262 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env50263 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,136,262,5393,10400,1025,137,12692,32,8596,3,8328,16,2184,13461,4096,2477,9224,32,257,33,13325,649]

theorem envBound50263 : H12AffineFastState.Bounded env50263 := by
  intro p hp
  have h : env50263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50262_50263 : H12AffineEnvironment.transform 13 5377 env50262 = env50263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50262 == env50263) = true)

theorem identity50263 : scanCanonicalize (H12AffineFastState.compose env50263 (packedSelected [3,4,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound50263 : packedSelected [3,4,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5148,5377,136,262,5393,7356,1025,137,1416,32,5512,3,5268,16,2184,137,4096,2477,4116,32,257,33,17,649]

theorem envBound50264 : H12AffineFastState.Bounded env50264 := by
  intro p hp
  have h : env50264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50263_50264 : H12AffineEnvironment.transform 12 5148 env50263 = env50264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env50263 == env50264) = true)

theorem identity50264 : scanCanonicalize (H12AffineFastState.compose env50264 (packedSelected [0,2,4,7,9,10,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound50264 : packedSelected [0,2,4,7,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env50265 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1432,388,153,136,262,137,2340,1025,137,1416,32,16,3,268,16,2184,137,1432,2477,1420,32,257,33,17,649]

theorem envBound50265 : H12AffineFastState.Bounded env50265 := by
  intro p hp
  have h : env50265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50264_50265 : H12AffineEnvironment.transform 11 1432 env50264 = env50265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env50264 == env50265) = true)

theorem identity50265 : scanCanonicalize (H12AffineFastState.compose env50265 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound50265 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1589,1432,388,153,136,262,137,1809,1025,137,1416,32,16,3,268,16,1725,137,1432,1944,1420,32,257,33,17,649]

theorem envBound50266 : H12AffineFastState.Bounded env50266 := by
  intro p hp
  have h : env50266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50265_50266 : H12AffineEnvironment.transform 10 1589 env50265 = env50266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env50265 == env50266) = true)

theorem identity50266 : scanCanonicalize (H12AffineFastState.compose env50266 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound50266 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env50267 : List Nat := [2,4,8,16,32,16,128,256,292,1024,1297,1432,388,153,136,262,137,1077,1025,137,1416,32,16,3,268,16,1433,137,1432,1212,1420,32,257,33,17,429]

theorem envBound50267 : H12AffineFastState.Bounded env50267 := by
  intro p hp
  have h : env50267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50266_50267 : H12AffineEnvironment.transform 8 292 env50266 = env50267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env50266 == env50267) = true)

theorem identity50267 : scanCanonicalize (H12AffineFastState.compose env50267 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound50267 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env50268 : List Nat := [2,4,8,16,32,16,128,188,152,1024,1197,1060,56,153,136,186,137,1077,1025,137,1076,32,16,3,176,16,1061,137,1060,1212,1072,32,189,33,17,17]

theorem envBound50268 : H12AffineFastState.Bounded env50268 := by
  intro p hp
  have h : env50268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50267_50268 : H12AffineEnvironment.transform 7 188 env50267 = env50268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env50267 == env50268) = true)

theorem identity50268 : scanCanonicalize (H12AffineFastState.compose env50268 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound50268 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50269 : List Nat := [2,4,8,16,32,16,24,36,0,1024,1077,1060,56,1,16,34,17,1077,1025,17,1076,32,16,3,40,16,1061,17,1060,1060,1072,32,37,33,17,17]

theorem envBound50269 : H12AffineFastState.Bounded env50269 := by
  intro p hp
  have h : env50269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50268_50269 : H12AffineEnvironment.transform 6 24 env50268 = env50269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env50268 == env50269) = true)

def env50270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,262144,1025,32769,2097152,272512,2101249,21762,8328,17,2157717,2098432,17665,2377113,2102684,2411677,257,21792,46213,2156180]

theorem envBound50270 : H12AffineFastState.Bounded env50270 := by
  intro p hp
  have h : env50270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50258_50270 : H12AffineEnvironment.transform 5 17 env50258 = env50270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50258 == env50270) = true)

def env50271 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23808,1025,32769,2097152,30080,2101249,21762,8328,17,2157717,2098432,17665,2103449,2102684,2134429,257,21792,46213,2156180]

theorem envBound50271 : H12AffineFastState.Bounded env50271 := by
  intro p hp
  have h : env50271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50270_50271 : H12AffineEnvironment.transform 17 23808 env50270 = env50271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env50270 == env50271) = true)

theorem identity50271 : scanCanonicalize (H12AffineFastState.compose env50271 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 12345) := by decide +kernel

theorem selectedBound50271 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env50272 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23808,1025,32769,12345,30080,8248,21762,8328,17,56492,13625,17665,10400,9637,41380,257,21792,46213,54957]

theorem envBound50272 : H12AffineFastState.Bounded env50272 := by
  intro p hp
  have h : env50272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50271_50272 : H12AffineEnvironment.transform 20 12345 env50271 = env50272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12345 env50271 == env50272) = true)

theorem identity50272 : scanCanonicalize (H12AffineFastState.compose env50272 (packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21677) := by decide +kernel

theorem selectedBound50272 : packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env50273 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21677,35,16692,23808,1025,21676,12345,30080,8248,21762,8328,17,2049,13625,17665,10400,9637,29961,257,21792,24616,512]

theorem envBound50273 : H12AffineFastState.Bounded env50273 := by
  intro p hp
  have h : env50273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50272_50273 : H12AffineEnvironment.transform 14 21677 env50272 = env50273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21677 env50272 == env50273) = true)

theorem identity50273 : scanCanonicalize (H12AffineFastState.compose env50273 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound50273 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env50274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21677,35,16692,23808,1025,21676,4540,21509,445,21762,269,17,2049,5308,17665,2341,1056,21644,257,21792,16813,512]

theorem envBound50274 : H12AffineFastState.Bounded env50274 := by
  intro p hp
  have h : env50274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50273_50274 : H12AffineEnvironment.transform 12 389 env50273 = env50274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env50273 == env50274) = true)

theorem identity50274 : scanCanonicalize (H12AffineFastState.compose env50274 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound50274 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50275 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,21677,35,16536,23724,1025,21676,4112,21509,17,21678,161,17,2049,5308,17581,2185,1056,21644,173,21644,16385,512]

theorem envBound50275 : H12AffineFastState.Bounded env50275 := by
  intro p hp
  have h : env50275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50274_50275 : H12AffineEnvironment.transform 7 172 env50274 = env50275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env50274 == env50275) = true)

theorem identity50275 : scanCanonicalize (H12AffineFastState.compose env50275 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5260) := by decide +kernel

theorem selectedBound50275 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50276 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5260,33,35,5140,2080,1025,32,4112,137,17,34,161,17,2049,5308,4129,2185,1056,0,173,0,5261,512]

theorem envBound50276 : H12AffineFastState.Bounded env50276 := by
  intro p hp
  have h : env50276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50275_50276 : H12AffineEnvironment.transform 13 5260 env50275 = env50276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5260 env50275 == env50276) = true)

theorem identity50276 : scanCanonicalize (H12AffineFastState.compose env50276 (packedSelected [3,4,5,6,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound50276 : packedSelected [3,4,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env50277 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1044,4096,41,5260,33,35,5140,1076,1025,32,4112,137,17,34,161,17,1045,5308,4129,1181,1056,0,173,0,5261,512]

theorem envBound50277 : H12AffineFastState.Bounded env50277 := by
  intro p hp
  have h : env50277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50276_50277 : H12AffineEnvironment.transform 10 1044 env50276 = env50277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env50276 == env50277) = true)

theorem identity50277 : scanCanonicalize (H12AffineFastState.compose env50277 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound50277 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env50278 : List Nat := [2,4,8,16,32,17,128,172,512,188,168,4096,41,4144,33,35,4264,136,189,32,4112,137,17,34,161,17,169,4096,4129,33,156,0,173,0,4145,512]

theorem envBound50278 : H12AffineFastState.Bounded env50278 := by
  intro p hp
  have h : env50278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50277_50278 : H12AffineEnvironment.transform 9 188 env50277 = env50278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env50277 == env50278) = true)

theorem identity50278 : scanCanonicalize (H12AffineFastState.compose env50278 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound50278 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50279 : List Nat := [2,4,8,16,32,17,41,5,512,21,1,4096,41,4144,33,35,4097,33,20,32,4112,32,17,34,8,17,0,4096,4129,33,53,0,4,0,4145,512]

theorem envBound50279 : H12AffineFastState.Bounded env50279 := by
  intro p hp
  have h : env50279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50278_50279 : H12AffineEnvironment.transform 6 41 env50278 = env50279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env50278 == env50279) = true)

theorem identity50279 : scanCanonicalize (H12AffineFastState.compose env50279 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50279 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50280 : List Nat := [2,4,8,16,0,17,9,5,512,21,1,4096,9,4112,1,3,4097,1,20,0,4112,0,17,2,8,17,0,4096,4097,1,21,0,4,0,4113,512]

theorem envBound50280 : H12AffineFastState.Bounded env50280 := by
  intro p hp
  have h : env50280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50279_50280 : H12AffineEnvironment.transform 4 0 env50279 = env50280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50279 == env50280) = true)

theorem identity50280 : scanCanonicalize (H12AffineFastState.compose env50280 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 527) := by decide +kernel

theorem selectedBound50280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50281 : List Nat := [2,4,8,16,0,17,9,5,512,21,1,527,9,543,1,3,526,1,20,0,543,0,17,2,8,17,0,527,526,1,21,0,4,0,542,512]

theorem envBound50281 : H12AffineFastState.Bounded env50281 := by
  intro p hp
  have h : env50281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50280_50281 : H12AffineEnvironment.transform 11 527 env50280 = env50281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 527 env50280 == env50281) = true)

theorem identity50281 : scanCanonicalize (H12AffineFastState.compose env50281 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound50281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50282 : List Nat := [2,4,8,16,0,17,9,5,30,21,1,17,9,1,1,3,16,1,20,0,1,0,17,2,8,17,0,17,16,1,21,0,4,0,0,30]

theorem envBound50282 : H12AffineFastState.Bounded env50282 := by
  intro p hp
  have h : env50282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50281_50282 : H12AffineEnvironment.transform 8 30 env50281 = env50282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env50281 == env50282) = true)

def env50283 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23809,1025,32769,2097152,30081,2101249,21762,8328,17,2157717,2098432,17665,2103448,2102684,2134428,257,21792,46213,2156180]

theorem envBound50283 : H12AffineFastState.Bounded env50283 := by
  intro p hp
  have h : env50283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50270_50283 : H12AffineEnvironment.transform 17 23809 env50270 = env50283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env50270 == env50283) = true)

theorem identity50283 : scanCanonicalize (H12AffineFastState.compose env50283 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 12464) := by decide +kernel

theorem selectedBound50283 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env50284 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23809,1025,32769,12464,30081,8369,21762,8328,17,56357,13744,17665,10280,9516,41260,257,21792,46213,54820]

theorem envBound50284 : H12AffineFastState.Bounded env50284 := by
  intro p hp
  have h : env50284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50283_50284 : H12AffineEnvironment.transform 20 12464 env50283 = env50284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12464 env50283 == env50284) = true)

theorem identity50284 : scanCanonicalize (H12AffineFastState.compose env50284 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound50284 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,22,26] rootPS < 2^1333 := by decide +kernel

def env50285 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,32768,41091,38297,10508,1025,32769,12464,396,8369,8463,8328,17,43048,13744,12556,10280,9516,41260,257,8493,46213,41513]

theorem envBound50285 : H12AffineFastState.Bounded env50285 := by
  intro p hp
  have h : env50285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50284_50285 : H12AffineEnvironment.transform 13 13325 env50284 = env50285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env50284 == env50285) = true)

theorem identity50285 : scanCanonicalize (H12AffineFastState.compose env50285 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50285 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env50286 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,5157,32768,32939,38297,2340,1025,32769,4248,396,153,295,160,17,34816,5528,4388,2048,1284,33028,257,261,38061,33281]

theorem envBound50286 : H12AffineFastState.Bounded env50286 := by
  intro p hp
  have h : env50286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50285_50286 : H12AffineEnvironment.transform 12 40 env50285 = env50286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50285 == env50286) = true)

theorem identity50286 : scanCanonicalize (H12AffineFastState.compose env50286 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound50286 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env50287 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,5157,293,398,5308,2340,1025,292,4248,396,153,295,160,17,2341,5528,4388,2048,1284,33,257,261,5512,804]

theorem envBound50287 : H12AffineFastState.Bounded env50287 := by
  intro p hp
  have h : env50287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50286_50287 : H12AffineEnvironment.transform 14 293 env50286 = env50287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env50286 == env50287) = true)

theorem identity50287 : scanCanonicalize (H12AffineFastState.compose env50287 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50287 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50288 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5157,293,262,5172,2340,1025,292,4112,260,17,295,40,17,2341,5392,4388,2048,1284,33,257,261,5376,804]

theorem envBound50288 : H12AffineFastState.Bounded env50288 := by
  intro p hp
  have h : env50288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50287_50288 : H12AffineEnvironment.transform 6 8 env50287 = env50288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50287 == env50288) = true)

theorem identity50288 : scanCanonicalize (H12AffineFastState.compose env50288 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50288 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env50289 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,40,5157,293,262,5172,292,1025,292,4112,260,17,295,40,17,293,5392,4388,0,1284,33,257,261,5376,804]

theorem envBound50289 : H12AffineFastState.Bounded env50289 := by
  intro p hp
  have h : env50289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50288_50289 : H12AffineEnvironment.transform 10 0 env50288 = env50289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50288 == env50289) = true)

theorem identity50289 : scanCanonicalize (H12AffineFastState.compose env50289 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50289 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env50290 : List Nat := [2,4,8,16,32,17,8,256,512,21,0,4096,40,4144,293,262,4129,292,20,292,4112,260,17,295,40,17,293,4357,4388,0,273,33,257,261,4373,804]

theorem envBound50290 : H12AffineFastState.Bounded env50290 := by
  intro p hp
  have h : env50290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50289_50290 : H12AffineEnvironment.transform 9 21 env50289 = env50290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50289 == env50290) = true)

theorem identity50290 : scanCanonicalize (H12AffineFastState.compose env50290 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound50290 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env50291 : List Nat := [2,4,8,16,32,17,8,256,512,21,0,48,40,0,293,262,17,292,20,292,32,260,17,295,40,17,293,309,276,0,273,33,257,261,293,804]

theorem envBound50291 : H12AffineFastState.Bounded env50291 := by
  intro p hp
  have h : env50291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50290_50291 : H12AffineEnvironment.transform 11 48 env50290 = env50291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50290 == env50291) = true)

theorem identity50291 : scanCanonicalize (H12AffineFastState.compose env50291 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound50291 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50292 : List Nat := [2,4,8,16,32,17,8,256,309,21,0,48,40,0,293,262,17,292,20,292,32,260,17,295,40,17,293,309,276,0,273,33,257,261,293,17]

theorem envBound50292 : H12AffineFastState.Bounded env50292 := by
  intro p hp
  have h : env50292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50291_50292 : H12AffineEnvironment.transform 8 309 env50291 = env50292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env50291 == env50292) = true)

def env50293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157716,2098513,17665,2377160,2102684,2411676,257,21792,46213,2175563]

theorem envBound50293 : H12AffineFastState.Bounded env50293 := by
  intro p hp
  have h : env50293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50256_50293 : H12AffineEnvironment.transform 21 272513 env50256 = env50293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50256 == env50293) = true)

theorem identity50293 : scanCanonicalize (H12AffineFastState.compose env50293 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound50293 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,115870,272513,120014,98781,8328,64,75786,115151,17665,360790,119042,329730,257,21792,46213,63189]

theorem envBound50294 : H12AffineFastState.Bounded env50294 := by
  intro p hp
  have h : env50294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50293_50294 : H12AffineEnvironment.transform 20 115870 env50293 = env50294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env50293 == env50294) = true)

def env50295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10400,1025,32769,115870,33,120014,98781,8328,64,75786,115151,17665,109046,119042,73890,257,21792,46213,63189]

theorem envBound50295 : H12AffineFastState.Bounded env50295 := by
  intro p hp
  have h : env50295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50294_50295 : H12AffineEnvironment.transform 17 10400 env50294 = env50295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env50294 == env50295) = true)

theorem identity50295 : scanCanonicalize (H12AffineFastState.compose env50295 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound50295 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env50296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,342,38297,10400,1025,32769,50632,33,54680,32907,8328,64,10588,49305,17665,43168,53332,8692,257,21792,46213,63189]

theorem envBound50296 : H12AffineFastState.Bounded env50296 := by
  intro p hp
  have h : env50296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50295_50296 : H12AffineEnvironment.transform 15 342 env50295 = env50296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env50295 == env50296) = true)

theorem identity50296 : scanCanonicalize (H12AffineFastState.compose env50296 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50296 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env50297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,38297,2557,1025,32769,50632,33,54680,32907,469,64,2049,49305,17665,35325,53332,169,257,21792,38360,55176]

theorem envBound50297 : H12AffineFastState.Bounded env50297 := by
  intro p hp
  have h : env50297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50296_50297 : H12AffineEnvironment.transform 12 349 env50296 = env50297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50296 == env50297) = true)

theorem identity50297 : scanCanonicalize (H12AffineFastState.compose env50297 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50297 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env50298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,342,5529,2557,1025,1,17864,33,21912,139,469,64,2049,16537,17665,2557,20564,169,257,21792,5592,22408]

theorem envBound50298 : H12AffineFastState.Bounded env50298 := by
  intro p hp
  have h : env50298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50297_50298 : H12AffineEnvironment.transform 14 0 env50297 = env50298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50297 == env50298) = true)

theorem identity50298 : scanCanonicalize (H12AffineFastState.compose env50298 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound50298 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5236,0,342,5529,2557,1025,1,4540,33,492,139,469,64,2049,5357,4469,2557,1056,169,257,340,5592,1020]

theorem envBound50299 : H12AffineFastState.Bounded env50299 := by
  intro p hp
  have h : env50299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50298_50299 : H12AffineEnvironment.transform 13 5236 env50298 = env50299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env50298 == env50299) = true)

theorem identity50299 : scanCanonicalize (H12AffineFastState.compose env50299 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50299 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50300 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,121,5236,0,114,5309,2265,1025,1,4248,33,200,139,241,64,2049,5357,4177,2265,1056,169,37,112,5372,728]

theorem envBound50300 : H12AffineFastState.Bounded env50300 := by
  intro p hp
  have h : env50300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50299_50300 : H12AffineEnvironment.transform 7 36 env50299 = env50300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50299 == env50300) = true)

theorem identity50300 : scanCanonicalize (H12AffineFastState.compose env50300 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound50300 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env50301 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,2249,121,3261,0,114,3188,2265,1025,1,2129,33,200,139,241,64,2049,3108,2200,2265,1056,169,37,112,3125,728]

theorem envBound50301 : H12AffineFastState.Bounded env50301 := by
  intro p hp
  have h : env50301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50300_50301 : H12AffineEnvironment.transform 11 2249 env50300 = env50301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env50300 == env50301) = true)

def env50302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10401,1025,32769,115870,32,120014,98781,8328,64,75786,115151,17665,109047,119042,73891,257,21792,46213,63189]

theorem envBound50302 : H12AffineFastState.Bounded env50302 := by
  intro p hp
  have h : env50302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50294_50302 : H12AffineEnvironment.transform 17 10401 env50294 = env50302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env50294 == env50302) = true)

theorem identity50302 : scanCanonicalize (H12AffineFastState.compose env50302 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62710) := by decide +kernel

theorem selectedBound50302 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env50303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62710,38297,10401,1025,32769,12392,32,8248,29995,8328,64,56572,13625,17665,23809,9716,54357,257,21792,46213,63189]

theorem envBound50303 : H12AffineFastState.Bounded env50303 := by
  intro p hp
  have h : env50303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50302_50303 : H12AffineEnvironment.transform 15 62710 env50302 = env50303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62710 env50302 == env50303) = true)

theorem identity50303 : scanCanonicalize (H12AffineFastState.compose env50303 (packedSelected [1,4,9,14,16,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50303 : packedSelected [1,4,9,14,16,19,28,31] rootPS < 2^1333 := by decide +kernel

def env50304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,34,24909,10401,1025,29909,12392,32,8248,29995,8328,64,10280,13625,17665,23809,9716,8321,257,21792,16465,513]

theorem envBound50304 : H12AffineFastState.Bounded env50304 := by
  intro p hp
  have h : env50304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50303_50304 : H12AffineEnvironment.transform 14 29908 env50303 = env50304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50303 == env50304) = true)

theorem identity50304 : scanCanonicalize (H12AffineFastState.compose env50304 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 11460) := by decide +kernel

theorem selectedBound50304 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env50305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11460,6160,34,3465,10401,1025,6161,12392,32,8248,6639,8328,64,10280,13625,10693,12741,9716,8321,257,14820,11413,513]

theorem envBound50305 : H12AffineFastState.Bounded env50305 := by
  intro p hp
  have h : env50305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50304_50305 : H12AffineEnvironment.transform 13 11460 env50304 = env50305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11460 env50304 == env50305) = true)

theorem identity50305 : scanCanonicalize (H12AffineFastState.compose env50305 (packedSelected [0,7,10,11,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound50305 : packedSelected [0,7,10,11,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env50306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,152,8192,11460,2184,34,3465,10401,1025,2185,8432,32,8248,2423,8328,64,10280,9633,10693,8541,9716,8321,257,10620,11413,513]

theorem envBound50306 : H12AffineFastState.Bounded env50306 := by
  intro p hp
  have h : env50306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50305_50306 : H12AffineEnvironment.transform 11 152 env50305 = env50306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env50305 == env50306) = true)

theorem identity50306 : scanCanonicalize (H12AffineFastState.compose env50306 (packedSelected [2,6,12,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound50306 : packedSelected [2,6,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env50307 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,152,8192,10360,2184,34,2357,10401,189,2185,8432,32,8248,2423,8328,64,10280,8477,10693,8541,8520,8321,257,10620,10281,513]

theorem envBound50307 : H12AffineFastState.Bounded env50307 := by
  intro p hp
  have h : env50307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50306_50307 : H12AffineEnvironment.transform 9 188 env50306 = env50307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env50306 == env50307) = true)

theorem identity50307 : scanCanonicalize (H12AffineFastState.compose env50307 (packedSelected [1,2,3,5,6,8,9,11,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50307 : packedSelected [1,2,3,5,6,8,9,11,16,22] rootPS < 2^1333 := by decide +kernel

def env50308 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,152,8192,10360,2184,34,2112,10401,189,2185,8432,32,8248,2050,8328,64,10280,8296,10416,8232,8253,8321,116,10249,10281,513]

theorem envBound50308 : H12AffineFastState.Bounded env50308 := by
  intro p hp
  have h : env50308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50307_50308 : H12AffineEnvironment.transform 7 117 env50307 = env50308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50307 == env50308) = true)

theorem identity50308 : scanCanonicalize (H12AffineFastState.compose env50308 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 2289) := by decide +kernel

theorem selectedBound50308 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env50309 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,152,2289,137,2184,34,2112,80,189,2185,2049,32,2249,2050,2169,64,217,2201,65,2265,2252,2160,116,248,216,513]

theorem envBound50309 : H12AffineFastState.Bounded env50309 := by
  intro p hp
  have h : env50309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50308_50309 : H12AffineEnvironment.transform 12 2289 env50308 = env50309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2289 env50308 == env50309) = true)

theorem identity50309 : scanCanonicalize (H12AffineFastState.compose env50309 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound50309 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env50310 : List Nat := [2,4,8,16,32,64,128,117,512,188,136,152,121,137,0,34,200,80,189,1,137,32,65,138,241,64,217,17,65,81,68,248,116,248,216,513]

theorem envBound50310 : H12AffineFastState.Bounded env50310 := by
  intro p hp
  have h : env50310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50309_50310 : H12AffineEnvironment.transform 10 136 env50309 = env50310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env50309 == env50310) = true)

theorem identity50310 : scanCanonicalize (H12AffineFastState.compose env50310 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound50310 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50311 : List Nat := [2,4,8,16,32,64,24,117,512,36,16,0,121,17,0,34,80,80,37,1,17,32,65,18,105,64,65,17,65,81,68,96,116,96,64,513]

theorem envBound50311 : H12AffineFastState.Bounded env50311 := by
  intro p hp
  have h : env50311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50310_50311 : H12AffineEnvironment.transform 6 24 env50310 = env50311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env50310 == env50311) = true)

theorem identity50311 : scanCanonicalize (H12AffineFastState.compose env50311 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50312 : List Nat := [2,4,8,16,32,64,24,117,48,36,16,0,121,17,0,34,80,80,37,1,17,32,65,18,105,64,65,17,65,81,68,96,116,96,64,49]

theorem envBound50312 : H12AffineFastState.Bounded env50312 := by
  intro p hp
  have h : env50312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50311_50312 : H12AffineEnvironment.transform 8 48 env50311 = env50312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50311 == env50312) = true)

def env50313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262473,201797,8328,64,6705549,2265289,184472,2377160,2102685,6451589,257,21793,46212,2175562]

theorem envBound50313 : H12AffineFastState.Bounded env50313 := by
  intro p hp
  have h : env50313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50183_50313 : H12AffineEnvironment.transform 23 201797 env50183 = env50313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201797 env50183 == env50313) = true)

def env50314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603797,2098513,17664,2377160,2102685,6349853,257,21793,46212,2175562]

theorem envBound50314 : H12AffineFastState.Bounded env50314 := by
  intro p hp
  have h : env50314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50313_50314 : H12AffineEnvironment.transform 16 38296 env50313 = env50314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env50313 == env50314) = true)

def env50315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157717,2098513,17664,2377160,2102685,2411677,257,21793,46212,2175562]

theorem envBound50315 : H12AffineFastState.Bounded env50315 := by
  intro p hp
  have h : env50315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50314_50315 : H12AffineEnvironment.transform 21 272512 env50314 = env50315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50314 == env50315) = true)

theorem identity50315 : scanCanonicalize (H12AffineFastState.compose env50315 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound50315 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,58517,272512,62660,98781,8328,64,2048,57796,17664,303453,61704,272392,257,21793,46212,120543]

theorem envBound50316 : H12AffineFastState.Bounded env50316 := by
  intro p hp
  have h : env50316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50315_50316 : H12AffineEnvironment.transform 20 58517 env50315 = env50316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env50315 == env50316) = true)

def env50317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10280,1025,32769,58517,168,62660,98781,8328,64,2048,57796,17664,35189,61704,32,257,21793,46212,120543]

theorem envBound50317 : H12AffineFastState.Bounded env50317 := by
  intro p hp
  have h : env50317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50316_50317 : H12AffineEnvironment.transform 17 10280 env50316 = env50317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50316 == env50317) = true)

theorem identity50317 : scanCanonicalize (H12AffineFastState.compose env50317 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50317 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,5528,10280,1025,1,25749,168,29892,66013,8328,64,2048,25028,17664,2421,28936,32,257,21793,13444,87775]

theorem envBound50318 : H12AffineFastState.Bounded env50318 := by
  intro p hp
  have h : env50318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50317_50318 : H12AffineEnvironment.transform 14 0 env50317 = env50318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50317 == env50318) = true)

theorem identity50318 : scanCanonicalize (H12AffineFastState.compose env50318 (packedSelected [2,3,6,7,9,10,11,16,17,18,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50318 : packedSelected [2,3,6,7,9,10,11,16,17,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,5528,10280,1025,1,25749,168,29892,8662,8328,64,2048,25028,17664,2421,28936,32,257,21793,13444,30420]

theorem envBound50319 : H12AffineFastState.Bounded env50319 := by
  intro p hp
  have h : env50319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50318_50319 : H12AffineEnvironment.transform 15 8203 env50318 = env50319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50318 == env50319) = true)

theorem identity50319 : scanCanonicalize (H12AffineFastState.compose env50319 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50319 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50320 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,0,8203,5440,10280,1025,1,25677,112,29724,8462,8272,64,2048,24860,17664,2421,28936,32,257,21793,13404,30220]

theorem envBound50320 : H12AffineFastState.Bounded env50320 := by
  intro p hp
  have h : env50320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50319_50320 : H12AffineEnvironment.transform 6 88 env50319 = env50320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50319 == env50320) = true)

theorem identity50320 : scanCanonicalize (H12AffineFastState.compose env50320 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound50320 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env50321 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13325,0,8203,5440,10280,1025,1,4160,112,17,8462,8272,64,2048,5393,12557,2421,1285,32,257,8492,13404,513]

theorem envBound50321 : H12AffineFastState.Bounded env50321 := by
  intro p hp
  have h : env50321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50320_50321 : H12AffineEnvironment.transform 13 13325 env50320 = env50321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env50320 == env50321) = true)

theorem identity50321 : scanCanonicalize (H12AffineFastState.compose env50321 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50321 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50322 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,8203,5392,10280,1025,1,4112,32,17,8462,8192,16,2048,5393,12557,2341,1285,32,257,8492,13324,513]

theorem envBound50322 : H12AffineFastState.Bounded env50322 := by
  intro p hp
  have h : env50322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50321_50322 : H12AffineEnvironment.transform 5 16 env50321 = env50322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50321 == env50322) = true)

theorem identity50322 : scanCanonicalize (H12AffineFastState.compose env50322 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound50322 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env50323 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,8192,8761,0,8203,804,10280,1025,1,1572,32,17,8462,8192,16,2048,805,10041,2341,1285,32,257,8492,8760,513]

theorem envBound50323 : H12AffineFastState.Bounded env50323 := by
  intro p hp
  have h : env50323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50322_50323 : H12AffineEnvironment.transform 11 1588 env50322 = env50323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env50322 == env50323) = true)

theorem identity50323 : scanCanonicalize (H12AffineFastState.compose env50323 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50323 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50324 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,269,820,0,262,804,2341,1025,1,1572,32,17,3,269,16,2048,805,1588,2341,1285,32,257,33,821,513]

theorem envBound50324 : H12AffineFastState.Bounded env50324 := by
  intro p hp
  have h : env50324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50323_50324 : H12AffineEnvironment.transform 12 269 env50323 = env50324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50323 == env50324) = true)

theorem identity50324 : scanCanonicalize (H12AffineFastState.compose env50324 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50325 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,544,269,820,0,262,804,2341,21,1,560,32,17,3,269,16,2048,805,544,2341,273,32,257,33,821,513]

theorem envBound50325 : H12AffineFastState.Bounded env50325 := by
  intro p hp
  have h : env50325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50324_50325 : H12AffineEnvironment.transform 9 20 env50324 = env50325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50324 == env50325) = true)

theorem identity50325 : scanCanonicalize (H12AffineFastState.compose env50325 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound50325 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50326 : List Nat := [2,4,8,16,32,16,8,256,512,20,815,544,269,820,0,262,804,522,21,1,560,32,17,3,269,16,815,805,544,522,273,32,257,33,821,513]

theorem envBound50326 : H12AffineFastState.Bounded env50326 := by
  intro p hp
  have h : env50326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50325_50326 : H12AffineEnvironment.transform 10 815 env50325 = env50326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env50325 == env50326) = true)

theorem identity50326 : scanCanonicalize (H12AffineFastState.compose env50326 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound50326 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50327 : List Nat := [2,4,8,16,32,16,8,256,293,20,10,261,269,17,0,262,1,303,21,1,277,32,17,3,269,16,10,0,261,303,273,32,257,33,16,292]

theorem envBound50327 : H12AffineFastState.Bounded env50327 := by
  intro p hp
  have h : env50327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50326_50327 : H12AffineEnvironment.transform 8 293 env50326 = env50327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env50326 == env50327) = true)

theorem identity50327 : scanCanonicalize (H12AffineFastState.compose env50327 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50327 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50328 : List Nat := [2,4,8,16,1,16,8,256,260,20,10,261,269,17,0,262,1,270,21,1,277,1,17,3,269,16,10,0,261,270,273,1,257,0,16,261]

theorem envBound50328 : H12AffineFastState.Bounded env50328 := by
  intro p hp
  have h : env50328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50327_50328 : H12AffineEnvironment.transform 4 1 env50327 = env50328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50327 == env50328) = true)

theorem identity50328 : scanCanonicalize (H12AffineFastState.compose env50328 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound50328 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50329 : List Nat := [2,4,8,16,1,16,8,18,22,20,10,23,31,17,0,20,1,28,21,1,7,1,17,3,31,16,10,0,23,28,3,1,19,0,16,23]

theorem envBound50329 : H12AffineFastState.Bounded env50329 := by
  intro p hp
  have h : env50329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50328_50329 : H12AffineEnvironment.transform 7 18 env50328 = env50329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env50328 == env50329) = true)

def env50330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10281,1025,32769,58517,169,62660,98781,8328,64,2048,57796,17664,35188,61704,33,257,21793,46212,120543]

theorem envBound50330 : H12AffineFastState.Bounded env50330 := by
  intro p hp
  have h : env50330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50316_50330 : H12AffineEnvironment.transform 17 10281 env50316 = env50330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50316 == env50330) = true)

theorem identity50330 : scanCanonicalize (H12AffineFastState.compose env50330 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound50330 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1330,38296,10281,1025,32769,58517,169,62660,34031,8328,64,2048,57796,17664,35188,61704,33,257,21793,46212,54253]

theorem envBound50331 : H12AffineFastState.Bounded env50331 := by
  intro p hp
  have h : env50331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50330_50331 : H12AffineEnvironment.transform 15 1330 env50330 = env50331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env50330 == env50331) = true)

theorem identity50331 : scanCanonicalize (H12AffineFastState.compose env50331 (packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound50331 : packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS < 2^1333 := by decide +kernel

def env50332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,32768,1330,38296,10281,1025,32769,38281,169,34264,34031,8328,64,2048,37080,13340,35188,32788,33,257,9277,46212,41713]

theorem envBound50332 : H12AffineFastState.Bounded env50332 := by
  intro p hp
  have h : env50332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50331_50332 : H12AffineEnvironment.transform 13 12572 env50331 = env50332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env50331 == env50332) = true)

theorem identity50332 : scanCanonicalize (H12AffineFastState.compose env50332 (packedSelected [0,1,3,9,12,15,16,17,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound50332 : packedSelected [0,1,3,9,12,15,16,17,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env50333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,428,1330,5172,10281,1025,429,5157,169,1140,1347,8328,64,2048,4468,13340,2264,440,33,257,9277,13608,9053]

theorem envBound50333 : H12AffineFastState.Bounded env50333 := by
  intro p hp
  have h : env50333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50332_50333 : H12AffineEnvironment.transform 14 428 env50332 = env50333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env50332 == env50333) = true)

theorem identity50333 : scanCanonicalize (H12AffineFastState.compose env50333 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound50333 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env50334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,5236,428,1330,5172,3393,1025,429,5157,169,1140,1347,1504,64,2048,4468,4468,2264,440,33,257,341,4160,1589]

theorem envBound50334 : H12AffineFastState.Bounded env50334 := by
  intro p hp
  have h : env50334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50333_50334 : H12AffineEnvironment.transform 12 1384 env50333 = env50334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env50333 == env50334) = true)

theorem identity50334 : scanCanonicalize (H12AffineFastState.compose env50334 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50334 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5236,292,1330,5172,3393,1025,293,5157,33,1140,1347,1384,64,2048,4468,4468,2128,304,33,257,341,4160,1589]

theorem envBound50335 : H12AffineFastState.Bounded env50335 := by
  intro p hp
  have h : env50335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50334_50335 : H12AffineEnvironment.transform 6 8 env50334 = env50335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50334 == env50335) = true)

theorem identity50335 : scanCanonicalize (H12AffineFastState.compose env50335 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50335 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50336 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,40,4404,292,114,4468,2049,321,293,4453,33,308,3,40,64,2048,4468,4468,2128,304,33,257,341,4160,885]

theorem envBound50336 : H12AffineFastState.Bounded env50336 := by
  intro p hp
  have h : env50336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50335_50336 : H12AffineEnvironment.transform 9 320 env50335 = env50336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50335 == env50336) = true)

def env50337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157716,2098513,17664,2377160,2102685,2411676,257,21793,46212,2175562]

theorem envBound50337 : H12AffineFastState.Bounded env50337 := by
  intro p hp
  have h : env50337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50314_50337 : H12AffineEnvironment.transform 21 272513 env50314 = env50337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50314 == env50337) = true)

theorem identity50337 : scanCanonicalize (H12AffineFastState.compose env50337 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound50337 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,262144,1025,29908,2097152,272513,2101329,95496,8328,64,2103361,2098513,17664,2377160,2102685,2373705,257,21793,16465,2175562]

theorem envBound50338 : H12AffineFastState.Bounded env50338 := by
  intro p hp
  have h : env50338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50337_50338 : H12AffineEnvironment.transform 14 29909 env50337 = env50338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env50337 == env50338) = true)

def env50339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,262144,1025,8660,2097152,272513,2101329,73736,8328,64,2103361,2098513,4096,2363592,2102685,2373705,257,33,5457,2175562]

theorem envBound50339 : H12AffineFastState.Bounded env50339 := by
  intro p hp
  have h : env50339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50338_50339 : H12AffineEnvironment.transform 13 5376 env50338 = env50339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50338 == env50339) = true)

theorem identity50339 : scanCanonicalize (H12AffineFastState.compose env50339 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 333923) := by decide +kernel

theorem selectedBound50339 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env50340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,262144,1025,8660,333923,272513,329778,73736,8328,64,327714,335154,4096,67755,331262,73770,257,33,5457,272937]

theorem envBound50340 : H12AffineFastState.Bounded env50340 := by
  intro p hp
  have h : env50340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50339_50340 : H12AffineEnvironment.transform 20 333923 env50339 = env50340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 333923 env50339 == env50340) = true)

theorem identity50340 : scanCanonicalize (H12AffineFastState.compose env50340 (packedSelected [0,1,2,5,6,8,11,14,17,18,19,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound50340 : packedSelected [0,1,2,5,6,8,11,14,17,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,2421,1025,8660,69910,8692,65863,73736,8328,64,67927,70727,4096,67755,66699,73770,257,33,5457,9052]

theorem envBound50341 : H12AffineFastState.Bounded env50341 := by
  intro p hp
  have h : env50341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50340_50341 : H12AffineEnvironment.transform 17 2421 env50340 = env50341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env50340 == env50341) = true)

theorem identity50341 : scanCanonicalize (H12AffineFastState.compose env50341 (packedSelected [0,2,3,4,5,6,7,8,9,11,14,17,18,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50341 : packedSelected [0,2,3,4,5,6,7,8,9,11,14,17,18,28] rootPS < 2^1333 := by decide +kernel

def env50342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13389,2421,1025,8540,69910,8572,65863,73736,8192,64,67927,70727,4096,67619,66563,73770,257,33,5457,9052]

theorem envBound50342 : H12AffineFastState.Bounded env50342 := by
  intro p hp
  have h : env50342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50341_50342 : H12AffineEnvironment.transform 6 8 env50341 = env50342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50341 == env50342) = true)

theorem identity50342 : scanCanonicalize (H12AffineFastState.compose env50342 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound50342 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,343,13389,2421,1025,8540,4161,8572,16,8543,8192,64,2048,5392,4096,2420,1364,8573,257,33,5457,9052]

theorem envBound50343 : H12AffineFastState.Bounded env50343 := by
  intro p hp
  have h : env50343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50342_50343 : H12AffineEnvironment.transform 15 343 env50342 = env50343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env50342 == env50343) = true)

theorem identity50343 : scanCanonicalize (H12AffineFastState.compose env50343 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound50343 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2341,8192,3109,8541,343,11624,2421,1025,8540,2404,8572,16,8543,8192,64,2048,3125,2341,2420,1364,8573,257,33,3188,9052]

theorem envBound50344 : H12AffineFastState.Bounded env50344 := by
  intro p hp
  have h : env50344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50343_50344 : H12AffineEnvironment.transform 11 2341 env50343 = env50344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env50343 == env50344) = true)

theorem identity50344 : scanCanonicalize (H12AffineFastState.compose env50344 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound50344 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50345 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2341,8192,3109,8492,294,11545,2308,1025,8493,2325,8461,16,8494,8192,49,2048,3125,2341,2309,1317,8460,257,33,3077,9005]

theorem envBound50345 : H12AffineFastState.Bounded env50345 := by
  intro p hp
  have h : env50345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50344_50345 : H12AffineEnvironment.transform 5 49 env50344 = env50345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env50344 == env50345) = true)

theorem identity50345 : scanCanonicalize (H12AffineFastState.compose env50345 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50346 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2341,269,3109,33,294,3092,2308,1025,32,2325,0,16,35,269,49,2048,3125,2341,2309,1317,1,257,33,3077,544]

theorem envBound50346 : H12AffineFastState.Bounded env50346 := by
  intro p hp
  have h : env50346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50345_50346 : H12AffineEnvironment.transform 12 269 env50345 = env50346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50345 == env50346) = true)

theorem identity50346 : scanCanonicalize (H12AffineFastState.compose env50346 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50346 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50347 : List Nat := [2,4,8,16,32,49,8,256,512,20,2048,2341,269,2097,33,294,2048,2308,21,32,2325,0,16,35,269,49,2048,2081,2341,2309,305,1,257,33,2065,544]

theorem envBound50347 : H12AffineFastState.Bounded env50347 := by
  intro p hp
  have h : env50347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50346_50347 : H12AffineEnvironment.transform 9 20 env50346 = env50347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50346 == env50347) = true)

theorem identity50347 : scanCanonicalize (H12AffineFastState.compose env50347 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound50347 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50348 : List Nat := [2,4,8,16,32,49,8,256,512,20,277,48,269,292,33,294,277,17,21,32,0,0,16,35,269,49,277,308,48,16,305,1,257,33,260,544]

theorem envBound50348 : H12AffineFastState.Bounded env50348 := by
  intro p hp
  have h : env50348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50347_50348 : H12AffineEnvironment.transform 10 277 env50347 = env50348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env50347 == env50348) = true)

theorem identity50348 : scanCanonicalize (H12AffineFastState.compose env50348 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound50348 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env50349 : List Nat := [2,4,8,16,32,49,8,52,512,20,33,48,57,16,33,18,33,17,21,32,0,0,16,35,57,49,33,0,48,16,5,1,53,33,48,544]

theorem envBound50349 : H12AffineFastState.Bounded env50349 := by
  intro p hp
  have h : env50349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50348_50349 : H12AffineEnvironment.transform 7 52 env50348 = env50349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env50348 == env50349) = true)

def env50350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,262144,1025,8661,2097152,272513,2101329,73737,8328,64,2103361,2098513,4097,2363593,2102685,2373705,257,32,5456,2175562]

theorem envBound50350 : H12AffineFastState.Bounded env50350 := by
  intro p hp
  have h : env50350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50338_50350 : H12AffineEnvironment.transform 13 5377 env50338 = env50350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50338 == env50350) = true)

theorem identity50350 : scanCanonicalize (H12AffineFastState.compose env50350 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound50350 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env50351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,478,13388,262144,1025,8661,2097152,272513,2101329,8663,8328,64,2103361,2098513,4097,2363593,2102685,2373705,257,32,5456,2110356]

theorem envBound50351 : H12AffineFastState.Bounded env50351 := by
  intro p hp
  have h : env50351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50350_50351 : H12AffineEnvironment.transform 15 478 env50350 = env50351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env50350 == env50351) = true)

theorem identity50351 : scanCanonicalize (H12AffineFastState.compose env50351 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound50351 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env50352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,478,13388,262144,1025,8661,276584,272513,272441,8663,8328,64,270377,277817,4097,10401,273909,33,257,32,5456,265212]

theorem envBound50352 : H12AffineFastState.Bounded env50352 := by
  intro p hp
  have h : env50352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50351_50352 : H12AffineEnvironment.transform 20 276584 env50351 = env50352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env50351 == env50352) = true)

theorem identity50352 : scanCanonicalize (H12AffineFastState.compose env50352 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound50352 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env50353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,478,13388,10281,1025,8661,4161,168,16,8663,8328,64,2048,5392,4097,10401,1500,33,257,32,5456,9173]

theorem envBound50353 : H12AffineFastState.Bounded env50353 := by
  intro p hp
  have h : env50353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50352_50353 : H12AffineEnvironment.transform 17 10281 env50352 = env50353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50352 == env50353) = true)

theorem identity50353 : scanCanonicalize (H12AffineFastState.compose env50353 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound50353 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,5377,1297,478,4233,3308,1025,1296,4161,168,16,1298,1101,64,2048,5392,4097,3172,1500,33,257,32,5456,1808]

theorem envBound50354 : H12AffineFastState.Bounded env50354 := by
  intro p hp
  have h : env50354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50353_50354 : H12AffineEnvironment.transform 12 1221 env50353 = env50354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env50353 == env50354) = true)

theorem identity50354 : scanCanonicalize (H12AffineFastState.compose env50354 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50354 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env50355 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,241,4405,293,478,4233,2264,53,292,4161,168,16,294,121,64,2048,4388,4097,2128,488,33,257,32,4452,804]

theorem envBound50355 : H12AffineFastState.Bounded env50355 := by
  intro p hp
  have h : env50355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50354_50355 : H12AffineEnvironment.transform 9 52 env50354 = env50355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50354 == env50355) = true)

theorem identity50355 : scanCanonicalize (H12AffineFastState.compose env50355 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50355 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50356 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,41,4405,293,262,4177,2048,53,292,4161,112,16,294,121,64,2048,4388,4097,2128,304,33,257,32,4452,804]

theorem envBound50356 : H12AffineFastState.Bounded env50356 := by
  intro p hp
  have h : env50356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50355_50356 : H12AffineEnvironment.transform 6 88 env50355 = env50356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50355 == env50356) = true)

theorem identity50356 : scanCanonicalize (H12AffineFastState.compose env50356 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50356 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50357 : List Nat := [2,4,8,16,32,48,40,256,512,52,2048,4096,41,4405,293,262,4129,2048,53,292,4145,0,16,294,9,48,2048,4388,4097,2080,304,33,257,32,4372,804]

theorem envBound50357 : H12AffineFastState.Bounded env50357 := by
  intro p hp
  have h : env50357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50356_50357 : H12AffineEnvironment.transform 5 48 env50356 = env50357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50356 == env50357) = true)

theorem identity50357 : scanCanonicalize (H12AffineFastState.compose env50357 (packedSelected [0,2,4,7,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50357 : packedSelected [0,2,4,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env50358 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,4096,41,4113,1,34,4129,2048,53,0,4145,0,16,2,9,48,2048,4096,4097,2080,20,33,37,32,4144,512]

theorem envBound50358 : H12AffineFastState.Bounded env50358 := by
  intro p hp
  have h : env50358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50357_50358 : H12AffineEnvironment.transform 7 36 env50357 = env50358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50357 == env50358) = true)

theorem identity50358 : scanCanonicalize (H12AffineFastState.compose env50358 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound50358 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50359 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,2097,41,2080,1,34,2064,2048,53,0,2048,0,16,2,9,48,2048,2097,2096,2080,20,33,37,32,2049,512]

theorem envBound50359 : H12AffineFastState.Bounded env50359 := by
  intro p hp
  have h : env50359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50358_50359 : H12AffineEnvironment.transform 11 2097 env50358 = env50359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env50358 == env50359) = true)

theorem identity50359 : scanCanonicalize (H12AffineFastState.compose env50359 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50359 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env50360 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,1,2,2064,2048,21,0,2048,0,16,2,9,16,2048,2065,2064,2048,20,1,5,0,2049,512]

theorem envBound50360 : H12AffineFastState.Bounded env50360 := by
  intro p hp
  have h : env50360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50359_50360 : H12AffineEnvironment.transform 4 0 env50359 = env50360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50359 == env50360) = true)

def env50361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603796,2098512,17665,2377160,2102685,6349852,257,21793,46212,2175562]

theorem envBound50361 : H12AffineFastState.Bounded env50361 := by
  intro p hp
  have h : env50361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50313_50361 : H12AffineEnvironment.transform 16 38297 env50313 = env50361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env50313 == env50361) = true)

def env50362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157716,2098512,17665,2377160,2102685,2411676,257,21793,46212,2175562]

theorem envBound50362 : H12AffineFastState.Bounded env50362 := by
  intro p hp
  have h : env50362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50361_50362 : H12AffineEnvironment.transform 21 272512 env50361 = env50362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50361 == env50362) = true)

theorem identity50362 : scanCanonicalize (H12AffineFastState.compose env50362 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound50362 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,272512,17,98780,8328,64,64725,5393,17665,284041,1500,318685,257,21793,46212,74251]

theorem envBound50363 : H12AffineFastState.Bounded env50363 := by
  intro p hp
  have h : env50363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50362_50363 : H12AffineEnvironment.transform 20 4161 env50362 = env50363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50362 == env50363) = true)

theorem identity50363 : scanCanonicalize (H12AffineFastState.compose env50363 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50363 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,4161,272512,17,41430,8328,64,64725,5393,17665,284041,1500,318685,257,21793,46212,513]

theorem envBound50364 : H12AffineFastState.Bounded env50364 := by
  intro p hp
  have h : env50364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50363_50364 : H12AffineEnvironment.transform 15 8202 env50363 = env50364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50363 == env50364) = true)

def env50365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157717,2098512,17665,2377160,2102685,2411677,257,21793,46212,2175562]

theorem envBound50365 : H12AffineFastState.Bounded env50365 := by
  intro p hp
  have h : env50365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50361_50365 : H12AffineEnvironment.transform 21 272513 env50361 = env50365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50361 == env50365) = true)

def env50366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272393,2101328,98644,8192,64,2157597,2098512,17665,2377024,2102549,2411541,257,21793,46092,2175562]

theorem envBound50366 : H12AffineFastState.Bounded env50366 := by
  intro p hp
  have h : env50366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50365_50366 : H12AffineEnvironment.transform 6 8 env50365 = env50366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50365 == env50366) = true)

def env50367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272393,16,98644,8192,64,64605,5392,17665,283904,1365,318549,257,21793,46092,74250]

theorem envBound50367 : H12AffineFastState.Bounded env50367 := by
  intro p hp
  have h : env50367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50366_50367 : H12AffineEnvironment.transform 20 4160 env50366 = env50367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50366 == env50367) = true)

theorem identity50367 : scanCanonicalize (H12AffineFastState.compose env50367 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50367 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4160,272393,16,41311,8192,64,64605,5392,17665,283904,1365,318549,257,21793,46092,513]

theorem envBound50368 : H12AffineFastState.Bounded env50368 := by
  intro p hp
  have h : env50368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50367_50368 : H12AffineEnvironment.transform 15 8203 env50367 = env50368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50367 == env50368) = true)

theorem identity50368 : scanCanonicalize (H12AffineFastState.compose env50368 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound50368 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,16401,262144,1025,21761,4160,272393,16,29791,8192,64,10589,5392,17665,283904,1365,264533,257,21793,24844,513]

theorem envBound50369 : H12AffineFastState.Bounded env50369 := by
  intro p hp
  have h : env50369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50368_50369 : H12AffineEnvironment.transform 14 21760 env50368 = env50369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env50368 == env50369) = true)

theorem identity50369 : scanCanonicalize (H12AffineFastState.compose env50369 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50369 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8203,13388,262144,1025,8540,4160,272393,16,2,8192,64,10589,5392,12636,270685,1365,264533,257,8572,5457,513]

theorem envBound50370 : H12AffineFastState.Bounded env50370 := by
  intro p hp
  have h : env50370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50369_50370 : H12AffineEnvironment.transform 13 13405 env50369 = env50370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50369 == env50370) = true)

theorem identity50370 : scanCanonicalize (H12AffineFastState.compose env50370 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50370 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50371 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,81,263,5440,262144,1025,80,4160,264453,16,2,268,64,2129,5392,4176,262225,1365,264533,257,112,5457,513]

theorem envBound50371 : H12AffineFastState.Bounded env50371 := by
  intro p hp
  have h : env50371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50370_50371 : H12AffineEnvironment.transform 12 268 env50370 = env50371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50370 == env50371) = true)

theorem identity50371 : scanCanonicalize (H12AffineFastState.compose env50371 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50371 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50372 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5237,81,35,5220,262144,1025,80,4160,264225,16,2,40,64,2129,5172,4176,262225,1137,264305,37,112,5237,513]

theorem envBound50372 : H12AffineFastState.Bounded env50372 := by
  intro p hp
  have h : env50372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50371_50372 : H12AffineEnvironment.transform 7 36 env50371 = env50372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50371 == env50372) = true)

theorem identity50372 : scanCanonicalize (H12AffineFastState.compose env50372 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50372 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env50373 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5173,262144,1025,1,4113,264225,16,2,40,17,2048,5172,4097,262144,1056,264224,37,33,5156,513]

theorem envBound50373 : H12AffineFastState.Bounded env50373 := by
  intro p hp
  have h : env50373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50372_50373 : H12AffineEnvironment.transform 5 17 env50372 = env50373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50372 == env50373) = true)

theorem identity50373 : scanCanonicalize (H12AffineFastState.compose env50373 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound50373 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50374 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5173,2048,1025,1,4113,33,16,2,40,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound50374 : H12AffineFastState.Bounded env50374 := by
  intro p hp
  have h : env50374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50373_50374 : H12AffineEnvironment.transform 17 2048 env50373 = env50374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env50373 == env50374) = true)

def env50375 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1044,0,35,1029,2048,1025,1,33,33,16,2,40,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound50375 : H12AffineFastState.Bounded env50375 := by
  intro p hp
  have h : env50375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50374_50375 : H12AffineEnvironment.transform 11 48 env50374 = env50375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50374 == env50375) = true)

theorem identity50375 : scanCanonicalize (H12AffineFastState.compose env50375 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound50375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50376 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,40,1044,0,35,1029,1077,1025,1,33,33,16,2,40,17,1077,1028,49,1077,1056,32,37,33,1044,513]

theorem envBound50376 : H12AffineFastState.Bounded env50376 := by
  intro p hp
  have h : env50376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50375_50376 : H12AffineEnvironment.transform 10 1077 env50375 = env50376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env50375 == env50376) = true)

def env50377 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,40,32,0,35,49,1,53,1,33,33,16,2,40,17,1,48,49,1,20,32,37,33,32,513]

theorem envBound50377 : H12AffineFastState.Bounded env50377 := by
  intro p hp
  have h : env50377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50376_50377 : H12AffineEnvironment.transform 9 52 env50376 = env50377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50376 == env50377) = true)

theorem identity50377 : scanCanonicalize (H12AffineFastState.compose env50377 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50378 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,9,1,0,2,16,1,20,1,0,0,16,2,9,17,1,17,16,1,20,1,4,0,1,513]

theorem envBound50378 : H12AffineFastState.Bounded env50378 := by
  intro p hp
  have h : env50378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50377_50378 : H12AffineEnvironment.transform 4 1 env50377 = env50378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50377 == env50378) = true)

def leafEnv50378 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,9,1,0,2,16,1,20,1,0,0,16,2,21,9,1,17,1,17,16,1,20,1,4,0,5,2,1,513,1,0,0]

def active50378 : List Nat := [0,1,2,3,8]

def tree50378 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50378 : H12WitnessSearch.Good tree50378 := H12GlobalWitnessIndex.good

theorem leafIdentity50378 : H12AffineFastState.composeSystem env50378 rootObs = leafEnv50378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50378 rootObs == leafEnv50378) = true)

theorem terminalChecked50378 : H12PackedTerminal.terminalCheckFast leafEnv50378 active50378 tree50378 = true := by decide +kernel

def env50379 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,33,0,35,48,0,52,1,33,33,16,2,40,17,0,49,49,0,21,32,37,33,33,513]

theorem envBound50379 : H12AffineFastState.Bounded env50379 := by
  intro p hp
  have h : env50379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50376_50379 : H12AffineEnvironment.transform 9 53 env50376 = env50379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50376 == env50379) = true)

theorem identity50379 : scanCanonicalize (H12AffineFastState.compose env50379 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound50379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50380 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,40,33,0,35,48,0,52,1,33,33,16,2,40,17,0,49,49,0,21,32,37,33,33,11]

theorem envBound50380 : H12AffineFastState.Bounded env50380 := by
  intro p hp
  have h : env50380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50379_50380 : H12AffineEnvironment.transform 8 10 env50379 = env50380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env50379 == env50380) = true)

def leafEnv50380 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,40,33,0,35,48,0,52,1,33,33,16,2,20,40,1,17,0,49,49,0,21,32,37,33,5,35,33,11,1,33,0]

def active50380 : List Nat := [0,1,2,3,4]

def tree50380 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50380 : H12WitnessSearch.Good tree50380 := H12GlobalWitnessIndex.good

theorem leafIdentity50380 : H12AffineFastState.composeSystem env50380 rootObs = leafEnv50380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50380 rootObs == leafEnv50380) = true)

theorem terminalChecked50380 : H12PackedTerminal.terminalCheckFast leafEnv50380 active50380 tree50380 = true := by decide +kernel

def env50381 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1045,0,35,1028,2048,1025,1,32,33,16,2,40,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound50381 : H12AffineFastState.Bounded env50381 := by
  intro p hp
  have h : env50381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50374_50381 : H12AffineEnvironment.transform 11 49 env50374 = env50381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50374 == env50381) = true)

theorem identity50381 : scanCanonicalize (H12AffineFastState.compose env50381 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50382 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,40,1045,0,35,1028,0,1025,1,32,33,16,2,40,17,0,1029,48,0,1056,32,37,33,1045,513]

theorem envBound50382 : H12AffineFastState.Bounded env50382 := by
  intro p hp
  have h : env50382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50381_50382 : H12AffineEnvironment.transform 10 0 env50381 = env50382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50381 == env50382) = true)

def env50383 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,33,0,35,48,0,53,1,32,33,16,2,40,17,0,49,48,0,20,32,37,33,33,513]

theorem envBound50383 : H12AffineFastState.Bounded env50383 := by
  intro p hp
  have h : env50383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50382_50383 : H12AffineEnvironment.transform 9 52 env50382 = env50383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50382 == env50383) = true)

theorem identity50383 : scanCanonicalize (H12AffineFastState.compose env50383 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50384 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,9,0,0,2,17,0,20,1,1,0,16,2,9,17,0,16,17,0,20,1,4,0,0,513]

theorem envBound50384 : H12AffineFastState.Bounded env50384 := by
  intro p hp
  have h : env50384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50383_50384 : H12AffineEnvironment.transform 4 1 env50383 = env50384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50383 == env50384) = true)

def leafEnv50384 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,9,0,0,2,17,0,20,1,1,0,16,2,21,9,1,17,0,16,17,0,20,1,4,0,5,2,0,513,1,1,0]

def active50384 : List Nat := [0,1,2,3,8]

def tree50384 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50384 : H12WitnessSearch.Good tree50384 := H12GlobalWitnessIndex.good

theorem leafIdentity50384 : H12AffineFastState.composeSystem env50384 rootObs = leafEnv50384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50384 rootObs == leafEnv50384) = true)

theorem terminalChecked50384 : H12PackedTerminal.terminalCheckFast leafEnv50384 active50384 tree50384 = true := by decide +kernel

def env50385 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,40,32,0,35,49,0,52,1,32,33,16,2,40,17,0,48,48,0,21,32,37,33,32,513]

theorem envBound50385 : H12AffineFastState.Bounded env50385 := by
  intro p hp
  have h : env50385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50382_50385 : H12AffineEnvironment.transform 9 53 env50382 = env50385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50382 == env50385) = true)

theorem identity50385 : scanCanonicalize (H12AffineFastState.compose env50385 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound50385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50386 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,40,32,0,35,49,0,52,1,32,33,16,2,40,17,0,48,48,0,21,32,37,33,32,11]

theorem envBound50386 : H12AffineFastState.Bounded env50386 := by
  intro p hp
  have h : env50386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50385_50386 : H12AffineEnvironment.transform 8 10 env50385 = env50386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env50385 == env50386) = true)

def leafEnv50386 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,40,32,0,35,49,0,52,1,32,33,16,2,20,40,1,17,0,48,48,0,21,32,37,33,5,35,32,11,1,32,0]

def active50386 : List Nat := [0,1,2,3,4]

def tree50386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50386 : H12WitnessSearch.Good tree50386 := H12GlobalWitnessIndex.good

theorem leafIdentity50386 : H12AffineFastState.composeSystem env50386 rootObs = leafEnv50386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50386 rootObs == leafEnv50386) = true)

theorem terminalChecked50386 : H12PackedTerminal.terminalCheckFast leafEnv50386 active50386 tree50386 = true := by decide +kernel

def env50387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272393,17,98644,8192,64,64604,5393,17665,283905,1364,318548,257,21793,46092,74251]

theorem envBound50387 : H12AffineFastState.Bounded env50387 := by
  intro p hp
  have h : env50387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50366_50387 : H12AffineEnvironment.transform 20 4161 env50366 = env50387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50366 == env50387) = true)

theorem identity50387 : scanCanonicalize (H12AffineFastState.compose env50387 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50387 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,33,17,98644,8192,64,64604,5393,17665,32041,1364,62588,257,21793,46092,74251]

theorem envBound50388 : H12AffineFastState.Bounded env50388 := by
  intro p hp
  have h : env50388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50387_50388 : H12AffineEnvironment.transform 17 10280 env50387 = env50388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50387 == env50388) = true)

theorem identity50388 : scanCanonicalize (H12AffineFastState.compose env50388 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound50388 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env50389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10280,1025,32769,4161,33,17,98644,8192,64,43356,5393,4097,10281,1364,41340,257,33,46092,74251]

theorem envBound50389 : H12AffineFastState.Bounded env50389 := by
  intro p hp
  have h : env50389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50388_50389 : H12AffineEnvironment.transform 13 5376 env50388 = env50389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50388 == env50389) = true)

theorem identity50389 : scanCanonicalize (H12AffineFastState.compose env50389 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound50389 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env50390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40971,38161,10280,1025,32769,4161,33,17,8543,8192,64,43356,5393,4097,10281,1364,41340,257,33,46092,33280]

theorem envBound50390 : H12AffineFastState.Bounded env50390 := by
  intro p hp
  have h : env50390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50389_50390 : H12AffineEnvironment.transform 15 40971 env50389 = env50390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env50389 == env50390) = true)

theorem identity50390 : scanCanonicalize (H12AffineFastState.compose env50390 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50390 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env50391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,8202,5392,10280,1025,0,4161,33,17,8543,8192,64,10589,5393,4097,10281,1364,8573,257,33,13325,513]

theorem envBound50391 : H12AffineFastState.Bounded env50391 := by
  intro p hp
  have h : env50391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50390_50391 : H12AffineEnvironment.transform 14 1 env50390 = env50391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50390 == env50391) = true)

theorem identity50391 : scanCanonicalize (H12AffineFastState.compose env50391 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50391 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5392,2420,1025,0,4161,33,17,3,348,64,2049,5393,4097,2421,1364,33,257,33,5457,513]

theorem envBound50392 : H12AffineFastState.Bounded env50392 := by
  intro p hp
  have h : env50392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50391_50392 : H12AffineEnvironment.transform 12 348 env50391 = env50392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50391 == env50392) = true)

theorem identity50392 : scanCanonicalize (H12AffineFastState.compose env50392 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

end H12CloudChart0