import H12CloudChart0Data185

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans47097_47098 : H12AffineEnvironment.transform 7 5 env47097 = env47098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47097 == env47098) = true)

def env47099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound47099 : H12AffineFastState.Bounded env47099 := by
  intro p hp
  have h : env47099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46920_47099 : H12AffineEnvironment.transform 18 1025 env46920 = env47099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46920 == env47099) = true)

theorem identity47099 : scanCanonicalize (H12AffineFastState.compose env47099 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140301) := by decide +kernel

theorem selectedBound47099 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,16777216,8328,64,29868033,17014913,8548701,8830977,25265169,21184972,257,25419937,25362692,25207750]

theorem envBound47100 : H12AffineFastState.Bounded env47100 := by
  intro p hp
  have h : env47100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47099_47100 : H12AffineEnvironment.transform 20 140301 env47099 = env47100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140301 env47099 == env47100) = true)

def env47101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,8631680,8328,64,4486529,8393985,8548701,8830977,143761,12645452,257,21793,46212,202310]

theorem envBound47101 : H12AffineFastState.Bounded env47101 := by
  intro p hp
  have h : env47101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47100_47101 : H12AffineEnvironment.transform 23 8631680 env47100 = env47101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631680 env47100 == env47101) = true)

def env47102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180360,95496,8328,64,4486529,185737,45525,262281,143761,4338884,257,21793,46212,202310]

theorem envBound47102 : H12AffineFastState.Bounded env47102 := by
  intro p hp
  have h : env47102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47101_47102 : H12AffineEnvironment.transform 22 180360 env47101 = env47102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env47101 == env47102) = true)

def env47103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180360,95496,8328,64,23809,185737,45525,262281,143761,400452,257,21793,46212,202310]

theorem envBound47103 : H12AffineFastState.Bounded env47103 := by
  intro p hp
  have h : env47103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47102_47103 : H12AffineEnvironment.transform 21 272512 env47102 = env47103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47102 == env47103) = true)

theorem identity47103 : scanCanonicalize (H12AffineFastState.compose env47103 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound47103 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140301,272512,144477,95496,8328,64,23809,139612,17664,262281,143761,400452,257,21793,16465,202310]

theorem envBound47104 : H12AffineFastState.Bounded env47104 := by
  intro p hp
  have h : env47104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47103_47104 : H12AffineEnvironment.transform 14 29909 env47103 = env47104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env47103 == env47104) = true)

def env47105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272392,144477,95496,8192,64,23809,139612,17664,262145,143641,400452,257,21793,16465,202310]

theorem envBound47105 : H12AffineFastState.Bounded env47105 := by
  intro p hp
  have h : env47105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47104_47105 : H12AffineEnvironment.transform 6 8 env47104 = env47105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47104 == env47105) = true)

theorem identity47105 : scanCanonicalize (H12AffineFastState.compose env47105 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound47105 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env47106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,140301,33,144477,95496,8192,64,23809,139612,17664,10280,143641,144493,257,21793,16465,202310]

theorem envBound47106 : H12AffineFastState.Bounded env47106 := by
  intro p hp
  have h : env47106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47105_47106 : H12AffineEnvironment.transform 17 10281 env47105 = env47106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47105 == env47106) = true)

theorem identity47106 : scanCanonicalize (H12AffineFastState.compose env47106 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47106 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,140301,33,144477,73736,8192,64,2049,139612,4096,10280,143641,144493,257,33,5457,202310]

theorem envBound47107 : H12AffineFastState.Bounded env47107 := by
  intro p hp
  have h : env47107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47106_47107 : H12AffineEnvironment.transform 13 5376 env47106 = env47107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47106 == env47107) = true)

theorem identity47107 : scanCanonicalize (H12AffineFastState.compose env47107 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 78127) := by decide +kernel

theorem selectedBound47107 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env47108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,78127,10281,1025,8540,70946,33,66930,73736,8192,64,2049,69747,4096,10280,65590,66882,257,33,5457,10089]

theorem envBound47108 : H12AffineFastState.Bounded env47108 := by
  intro p hp
  have h : env47108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47107_47108 : H12AffineEnvironment.transform 16 78127 env47107 = env47108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78127 env47107 == env47108) = true)

theorem identity47108 : scanCanonicalize (H12AffineFastState.compose env47108 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47108 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47109 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8313,65536,77835,10281,1025,8312,70662,33,66646,73736,8192,64,2049,69747,4096,10280,65590,66662,37,33,5237,9805]

theorem envBound47109 : H12AffineFastState.Bounded env47109 := by
  intro p hp
  have h : env47109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47108_47109 : H12AffineEnvironment.transform 7 36 env47108 = env47109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47108 == env47109) = true)

theorem identity47109 : scanCanonicalize (H12AffineFastState.compose env47109 (packedSelected [11,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound47109 : packedSelected [11,16,20,23] rootPS < 2^1333 := by decide +kernel

def env47110 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5156,1077,65536,70727,3173,1025,1076,70662,33,66646,66628,1100,64,2049,69747,4096,3172,65590,66662,37,33,5237,513]

theorem envBound47110 : H12AffineFastState.Bounded env47110 := by
  intro p hp
  have h : env47110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47109_47110 : H12AffineEnvironment.transform 12 1100 env47109 = env47110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env47109 == env47110) = true)

theorem identity47110 : scanCanonicalize (H12AffineFastState.compose env47110 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound47110 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47111 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5156,1077,1094,4097,3173,1025,1076,4160,33,16,2,1100,64,2049,5173,4096,3172,1136,32,37,33,5237,513]

theorem envBound47111 : H12AffineFastState.Bounded env47111 := by
  intro p hp
  have h : env47111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47110_47111 : H12AffineEnvironment.transform 15 1094 env47110 = env47111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env47110 == env47111) = true)

theorem identity47111 : scanCanonicalize (H12AffineFastState.compose env47111 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound47111 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env47112 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,1100,3173,1077,1094,2112,3173,1025,1076,2049,33,16,2,1100,64,2049,3188,2113,3172,1136,32,37,33,3124,513]

theorem envBound47112 : H12AffineFastState.Bounded env47112 := by
  intro p hp
  have h : env47112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47111_47112 : H12AffineEnvironment.transform 11 2113 env47111 = env47112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env47111 == env47112) = true)

theorem identity47112 : scanCanonicalize (H12AffineFastState.compose env47112 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47112 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47113 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2113,40,2049,81,34,2112,2049,101,80,2049,33,16,2,40,64,2049,2064,2113,2048,20,32,37,33,2128,513]

theorem envBound47113 : H12AffineFastState.Bounded env47113 := by
  intro p hp
  have h : env47113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47112_47113 : H12AffineEnvironment.transform 9 100 env47112 = env47113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47112 == env47113) = true)

theorem identity47113 : scanCanonicalize (H12AffineFastState.compose env47113 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47113 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env47114 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,40,2049,1,34,2064,2049,53,0,2049,33,16,2,40,16,2049,2064,2065,2048,20,32,37,33,2048,513]

theorem envBound47114 : H12AffineFastState.Bounded env47114 := by
  intro p hp
  have h : env47114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47113_47114 : H12AffineEnvironment.transform 5 16 env47113 = env47114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47113 == env47114) = true)

theorem identity47114 : scanCanonicalize (H12AffineFastState.compose env47114 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound47114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47115 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,40,49,1,34,32,49,53,0,49,33,16,2,40,16,49,32,33,48,20,32,37,33,48,513]

theorem envBound47115 : H12AffineFastState.Bounded env47115 := by
  intro p hp
  have h : env47115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47114_47115 : H12AffineEnvironment.transform 10 48 env47114 = env47115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env47114 == env47115) = true)

def leafEnv47115 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,40,49,1,34,32,49,53,0,49,33,16,2,21,40,1,16,49,32,33,48,20,32,37,33,5,34,48,513,1,48,0]

def active47115 : List Nat := [0,1,2,3,4,8]

def tree47115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47115 : H12WitnessSearch.Good tree47115 := H12GlobalWitnessIndex.good

theorem leafIdentity47115 : H12AffineFastState.composeSystem env47115 rootObs = leafEnv47115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47115 rootObs == leafEnv47115) = true)

theorem terminalChecked47115 : H12PackedTerminal.terminalCheckFast leafEnv47115 active47115 tree47115 = true := by decide +kernel

def env47116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272393,144477,95496,8193,64,23809,139612,17664,262144,143640,400452,257,21793,16465,202310]

theorem envBound47116 : H12AffineFastState.Bounded env47116 := by
  intro p hp
  have h : env47116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47104_47116 : H12AffineEnvironment.transform 6 9 env47104 = env47116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47104 == env47116) = true)

theorem identity47116 : scanCanonicalize (H12AffineFastState.compose env47116 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound47116 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env47117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,76159,1025,29789,140301,65910,144477,95496,8193,64,23809,139612,17664,76159,143640,210235,257,21793,16465,202310]

theorem envBound47117 : H12AffineFastState.Bounded env47117 := by
  intro p hp
  have h : env47117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47116_47117 : H12AffineEnvironment.transform 17 76159 env47116 = env47117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env47116 == env47117) = true)

theorem identity47117 : scanCanonicalize (H12AffineFastState.compose env47117 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound47117 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,70727,76159,1025,29789,77898,65910,73754,95496,8193,64,23809,79131,17664,76159,75103,8572,257,21793,16465,513]

theorem envBound47118 : H12AffineFastState.Bounded env47118 := by
  intro p hp
  have h : env47118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47117_47118 : H12AffineEnvironment.transform 16 70727 env47117 = env47118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env47117 == env47118) = true)

theorem identity47118 : scanCanonicalize (H12AffineFastState.compose env47118 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47118 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env47119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70727,76159,1025,8540,77898,65910,73754,73737,8193,64,2048,79131,4097,76159,75103,8572,257,32,5456,513]

theorem envBound47119 : H12AffineFastState.Bounded env47119 := by
  intro p hp
  have h : env47119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47118_47119 : H12AffineEnvironment.transform 13 5377 env47118 = env47119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47118 == env47119) = true)

theorem identity47119 : scanCanonicalize (H12AffineFastState.compose env47119 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47119 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,70727,67618,1025,1,69911,65910,65863,65876,348,64,2048,70726,4097,67618,66562,33,257,32,5456,513]

theorem envBound47120 : H12AffineFastState.Bounded env47120 := by
  intro p hp
  have h : env47120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47119_47120 : H12AffineEnvironment.transform 12 349 env47119 = env47120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47119 == env47120) = true)

theorem identity47120 : scanCanonicalize (H12AffineFastState.compose env47120 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47120 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env47121 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,0,65536,70727,67618,1025,1,69682,65619,65634,65649,121,64,2048,70726,4097,67618,66562,33,36,32,5237,513]

theorem envBound47121 : H12AffineFastState.Bounded env47121 := by
  intro p hp
  have h : env47121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47120_47121 : H12AffineEnvironment.transform 7 37 env47120 = env47121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47120 == env47121) = true)

theorem identity47121 : scanCanonicalize (H12AffineFastState.compose env47121 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound47121 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env47122 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,0,35,5220,2049,1025,1,4113,112,65,82,121,64,2048,5221,4097,2049,1057,33,36,32,5237,513]

theorem envBound47122 : H12AffineFastState.Bounded env47122 := by
  intro p hp
  have h : env47122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47121_47122 : H12AffineEnvironment.transform 15 35 env47121 = env47122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env47121 == env47122) = true)

theorem identity47122 : scanCanonicalize (H12AffineFastState.compose env47122 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47122 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env47123 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4113,33,16,3,40,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound47123 : H12AffineFastState.Bounded env47123 := by
  intro p hp
  have h : env47123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47122_47123 : H12AffineEnvironment.transform 5 17 env47122 = env47123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47122 == env47123) = true)

def env47124 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1044,0,35,1029,2049,1025,1,33,33,16,3,40,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound47124 : H12AffineFastState.Bounded env47124 := by
  intro p hp
  have h : env47124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47123_47124 : H12AffineEnvironment.transform 11 48 env47123 = env47124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47123 == env47124) = true)

theorem identity47124 : scanCanonicalize (H12AffineFastState.compose env47124 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47125 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,41,32,0,35,49,2049,53,1,33,33,16,3,40,17,2048,48,49,2049,21,33,36,32,32,513]

theorem envBound47125 : H12AffineFastState.Bounded env47125 := by
  intro p hp
  have h : env47125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47124_47125 : H12AffineEnvironment.transform 9 52 env47124 = env47125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47124 == env47125) = true)

def env47126 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1045,0,35,1028,2049,1025,1,32,33,16,3,40,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound47126 : H12AffineFastState.Bounded env47126 := by
  intro p hp
  have h : env47126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47123_47126 : H12AffineEnvironment.transform 11 49 env47123 = env47126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47123 == env47126) = true)

def env47127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180360,95496,8328,64,23808,185737,45525,262281,143761,400453,257,21793,46212,202310]

theorem envBound47127 : H12AffineFastState.Bounded env47127 := by
  intro p hp
  have h : env47127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47102_47127 : H12AffineEnvironment.transform 21 272513 env47102 = env47127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47102 == env47127) = true)

theorem identity47127 : scanCanonicalize (H12AffineFastState.compose env47127 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound47127 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,272513,62660,95496,8328,64,23808,57797,45525,262281,1501,272393,257,21793,46212,74250]

theorem envBound47128 : H12AffineFastState.Bounded env47128 := by
  intro p hp
  have h : env47128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47127_47128 : H12AffineEnvironment.transform 16 13388 env47127 = env47128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env47127 == env47128) = true)

theorem identity47128 : scanCanonicalize (H12AffineFastState.compose env47128 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47128 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,13388,262144,1025,32769,4161,272513,62660,21763,8328,64,23808,57797,45525,262281,1501,272393,257,21793,46212,513]

theorem envBound47129 : H12AffineFastState.Bounded env47129 := by
  intro p hp
  have h : env47129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47128_47129 : H12AffineEnvironment.transform 15 8203 env47128 = env47129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47128 == env47129) = true)

theorem identity47129 : scanCanonicalize (H12AffineFastState.compose env47129 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47129 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env47130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,262144,1025,32769,4161,264533,54544,21763,348,64,23808,49169,36865,262281,1501,264669,257,21793,38224,513]

theorem envBound47130 : H12AffineFastState.Bounded env47130 := by
  intro p hp
  have h : env47130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47129_47130 : H12AffineEnvironment.transform 12 468 env47129 = env47130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47129 == env47130) = true)

theorem identity47130 : scanCanonicalize (H12AffineFastState.compose env47130 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound47130 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env47131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,2420,1025,32769,4161,33,54544,21763,348,64,23808,49169,36865,2557,1501,169,257,21793,38224,513]

theorem envBound47131 : H12AffineFastState.Bounded env47131 := by
  intro p hp
  have h : env47131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47130_47131 : H12AffineEnvironment.transform 17 2420 env47130 = env47131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env47130 == env47131) = true)

theorem identity47131 : scanCanonicalize (H12AffineFastState.compose env47131 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound47131 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env47132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,32768,479,5528,2420,1025,32769,4161,33,34048,1299,348,64,3344,36865,36865,2557,1501,169,257,1329,38224,513]

theorem envBound47132 : H12AffineFastState.Bounded env47132 := by
  intro p hp
  have h : env47132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47131_47132 : H12AffineEnvironment.transform 13 4112 env47131 = env47132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env47131 == env47132) = true)

theorem identity47132 : scanCanonicalize (H12AffineFastState.compose env47132 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 6296) := by decide +kernel

theorem selectedBound47132 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env47133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,6296,479,5528,2420,1025,6297,4161,33,7576,1299,348,64,3344,2201,2201,2557,1501,169,257,1329,3528,513]

theorem envBound47133 : H12AffineFastState.Bounded env47133 := by
  intro p hp
  have h : env47133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47132_47133 : H12AffineEnvironment.transform 14 6296 env47132 = env47133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6296 env47132 == env47133) = true)

theorem identity47133 : scanCanonicalize (H12AffineFastState.compose env47133 (packedSelected [0,4,6,10,11,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound47133 : packedSelected [0,4,6,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,468,508,2420,479,1140,2420,1025,2421,429,33,3188,1299,348,64,3344,2201,2201,2557,1501,169,257,1329,3528,513]

theorem envBound47134 : H12AffineFastState.Bounded env47134 := by
  intro p hp
  have h : env47134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47133_47134 : H12AffineEnvironment.transform 11 492 env47133 = env47134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env47133 == env47134) = true)

theorem identity47134 : scanCanonicalize (H12AffineFastState.compose env47134 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47134 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env47135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,372,2420,343,1140,2420,1025,2421,293,33,3188,1299,348,64,3344,2065,2065,2421,1365,33,257,1329,3392,513]

theorem envBound47135 : H12AffineFastState.Bounded env47135 := by
  intro p hp
  have h : env47135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47134_47135 : H12AffineEnvironment.transform 6 8 env47134 = env47135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47134 == env47135) = true)

theorem identity47135 : scanCanonicalize (H12AffineFastState.compose env47135 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound47135 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,356,348,372,81,343,1140,81,1025,80,293,33,1361,1299,348,64,1077,308,308,80,1365,33,257,1329,1125,513]

theorem envBound47136 : H12AffineFastState.Bounded env47136 := by
  intro p hp
  have h : env47136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47135_47136 : H12AffineEnvironment.transform 10 293 env47135 = env47136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env47135 == env47136) = true)

theorem identity47136 : scanCanonicalize (H12AffineFastState.compose env47136 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound47136 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47137 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,356,348,372,81,343,65,81,52,80,293,33,356,294,348,64,0,308,308,80,352,33,257,260,80,513]

theorem envBound47137 : H12AffineFastState.Bounded env47137 := by
  intro p hp
  have h : env47137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47136_47137 : H12AffineEnvironment.transform 9 53 env47136 = env47137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47136 == env47137) = true)

theorem identity47137 : scanCanonicalize (H12AffineFastState.compose env47137 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47137 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47138 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,65,121,81,81,114,65,81,52,80,0,33,65,3,121,64,0,17,17,80,69,33,36,33,80,513]

theorem envBound47138 : H12AffineFastState.Bounded env47138 := by
  intro p hp
  have h : env47138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47137_47138 : H12AffineEnvironment.transform 7 37 env47137 = env47138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47137 == env47138) = true)

theorem identity47138 : scanCanonicalize (H12AffineFastState.compose env47138 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47138 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47139 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,40,0,0,35,16,0,52,1,0,33,16,3,40,17,0,17,17,1,20,33,36,33,1,513]

theorem envBound47139 : H12AffineFastState.Bounded env47139 := by
  intro p hp
  have h : env47139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47138_47139 : H12AffineEnvironment.transform 5 17 env47138 = env47139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47138 == env47139) = true)

theorem identity47139 : scanCanonicalize (H12AffineFastState.compose env47139 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound47139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47140 : List Nat := [2,4,8,16,32,17,8,37,26,53,0,16,40,0,0,35,16,0,52,1,0,33,16,3,40,17,0,17,17,1,20,33,36,33,1,27]

theorem envBound47140 : H12AffineFastState.Bounded env47140 := by
  intro p hp
  have h : env47140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47139_47140 : H12AffineEnvironment.transform 8 26 env47139 = env47140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env47139 == env47140) = true)

theorem identity47140 : scanCanonicalize (H12AffineFastState.compose env47140 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47140 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47141 : List Nat := [2,4,8,1,32,0,8,37,11,36,0,1,40,0,0,35,1,0,37,1,0,33,1,3,40,0,0,0,0,1,5,33,36,33,1,10]

theorem envBound47141 : H12AffineFastState.Bounded env47141 := by
  intro p hp
  have h : env47141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47140_47141 : H12AffineEnvironment.transform 3 1 env47140 = env47141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47140 == env47141) = true)

theorem identity47141 : scanCanonicalize (H12AffineFastState.compose env47141 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47141 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47142 : List Nat := [2,4,2,1,32,0,2,37,1,36,0,1,34,0,0,35,1,0,37,1,0,33,1,3,34,0,0,0,0,1,5,33,36,33,1,0]

theorem envBound47142 : H12AffineFastState.Bounded env47142 := by
  intro p hp
  have h : env47142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47141_47142 : H12AffineEnvironment.transform 2 2 env47141 = env47142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47141 == env47142) = true)

def env47143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180361,95497,8328,64,4486529,185736,45524,262280,143761,4338885,257,21793,46212,202310]

theorem envBound47143 : H12AffineFastState.Bounded env47143 := by
  intro p hp
  have h : env47143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47101_47143 : H12AffineEnvironment.transform 22 180361 env47101 = env47143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env47101 == env47143) = true)

def env47144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180361,95497,8328,64,23809,185736,45524,262280,143761,400453,257,21793,46212,202310]

theorem envBound47144 : H12AffineFastState.Bounded env47144 := by
  intro p hp
  have h : env47144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47143_47144 : H12AffineEnvironment.transform 21 272512 env47143 = env47144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47143 == env47144) = true)

def env47145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272392,180225,95497,8192,64,23809,185600,45404,262144,143641,400453,257,21793,46092,202310]

theorem envBound47145 : H12AffineFastState.Bounded env47145 := by
  intro p hp
  have h : env47145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47144_47145 : H12AffineEnvironment.transform 6 8 env47144 = env47145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47144 == env47145) = true)

def env47146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,17,95497,8192,64,23809,5392,45404,262144,61705,318549,257,21793,46092,120406]

theorem envBound47146 : H12AffineFastState.Bounded env47146 := by
  intro p hp
  have h : env47146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47145_47146 : H12AffineEnvironment.transform 16 49168 env47145 = env47146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47145 == env47146) = true)

theorem identity47146 : scanCanonicalize (H12AffineFastState.compose env47146 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47146 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,58397,41340,17,95497,8192,64,23809,5392,45404,35188,61705,21793,257,21793,46092,120406]

theorem envBound47147 : H12AffineFastState.Bounded env47147 := by
  intro p hp
  have h : env47147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47146_47147 : H12AffineEnvironment.transform 17 35188 env47146 = env47147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47146 == env47147) = true)

theorem identity47147 : scanCanonicalize (H12AffineFastState.compose env47147 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound47147 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,65536,13673,31757,1025,30072,4452,21509,17,95497,8192,64,23809,5392,17445,31757,1136,21793,257,21793,16757,74543]

theorem envBound47148 : H12AffineFastState.Bounded env47148 := by
  intro p hp
  have h : env47148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47147_47148 : H12AffineEnvironment.transform 14 30073 env47147 = env47148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env47147 == env47148) = true)

theorem identity47148 : scanCanonicalize (H12AffineFastState.compose env47148 (packedSelected [3,5,10,12,15,18,19,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound47148 : packedSelected [3,5,10,12,15,18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env47149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8460,65536,13673,10360,1025,8461,4452,112,17,74108,8192,64,2420,5392,4176,10360,1136,340,257,340,5376,74543]

theorem envBound47149 : H12AffineFastState.Bounded env47149 := by
  intro p hp
  have h : env47149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47148_47149 : H12AffineEnvironment.transform 13 5237 env47148 = env47149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env47148 == env47149) = true)

theorem identity47149 : scanCanonicalize (H12AffineFastState.compose env47149 (packedSelected [0,2,3,5,6,7,9,10,11,14,15,16,22] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound47149 : packedSelected [0,2,3,5,6,7,9,10,11,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env47150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,5237,7505,65536,2356,5157,1025,7504,4452,112,17,72993,7261,64,2420,5392,4176,5157,1136,340,257,340,5376,73586]

theorem envBound47150 : H12AffineFastState.Bounded env47150 := by
  intro p hp
  have h : env47150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47149_47150 : H12AffineEnvironment.transform 12 7261 env47149 = env47150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env47149 == env47150) = true)

theorem identity47150 : scanCanonicalize (H12AffineFastState.compose env47150 (packedSelected [4,9,10,12,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47150 : packedSelected [4,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env47151 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7261,5237,7204,65536,2113,5157,1025,7205,4113,112,17,72788,7261,64,2049,5221,4176,5157,1136,33,116,33,5237,73223]

theorem envBound47151 : H12AffineFastState.Bounded env47151 := by
  intro p hp
  have h : env47151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47150_47151 : H12AffineEnvironment.transform 7 117 env47150 = env47151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47150 == env47151) = true)

theorem identity47151 : scanCanonicalize (H12AffineFastState.compose env47151 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound47151 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47152 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7261,5237,7204,7175,2113,5157,1025,7205,4113,112,17,83,7261,64,2049,5221,4176,5157,1136,33,116,33,5237,512]

theorem envBound47152 : H12AffineFastState.Bounded env47152 := by
  intro p hp
  have h : env47152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47151_47152 : H12AffineEnvironment.transform 15 7175 env47151 = env47152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env47151 == env47152) = true)

theorem identity47152 : scanCanonicalize (H12AffineFastState.compose env47152 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound47152 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47153 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3108,121,2129,0,35,2113,2049,1025,1,3125,112,17,83,121,64,2049,2113,3188,2049,1136,33,116,33,2129,512]

theorem envBound47153 : H12AffineFastState.Bounded env47153 := by
  intro p hp
  have h : env47153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47152_47153 : H12AffineEnvironment.transform 11 3108 env47152 = env47153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env47152 == env47153) = true)

theorem identity47153 : scanCanonicalize (H12AffineFastState.compose env47153 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47153 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47154 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,3076,89,2129,0,3,2113,2049,1025,1,3093,80,17,83,89,64,2049,2113,3156,2049,1104,1,84,1,2129,512]

theorem envBound47154 : H12AffineFastState.Bounded env47154 := by
  intro p hp
  have h : env47154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47153_47154 : H12AffineEnvironment.transform 4 0 env47153 = env47154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47153 == env47154) = true)

theorem identity47154 : scanCanonicalize (H12AffineFastState.compose env47154 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound47154 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47155 : List Nat := [2,4,8,16,0,64,8,85,512,85,2048,2129,89,2129,0,3,2113,2049,84,1,2112,80,17,83,89,64,2049,2113,2049,2049,5,1,84,1,2129,512]

theorem envBound47155 : H12AffineFastState.Bounded env47155 := by
  intro p hp
  have h : env47155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47154_47155 : H12AffineEnvironment.transform 9 85 env47154 = env47155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env47154 == env47155) = true)

theorem identity47155 : scanCanonicalize (H12AffineFastState.compose env47155 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound47155 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47156 : List Nat := [2,4,8,16,0,64,8,85,512,85,64,17,89,17,0,3,1,65,84,1,0,80,17,83,89,64,65,1,65,65,5,1,84,1,17,512]

theorem envBound47156 : H12AffineFastState.Bounded env47156 := by
  intro p hp
  have h : env47156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47155_47156 : H12AffineEnvironment.transform 10 64 env47155 = env47156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env47155 == env47156) = true)

theorem identity47156 : scanCanonicalize (H12AffineFastState.compose env47156 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47157 : List Nat := [2,4,8,16,0,16,8,5,512,5,16,17,9,17,0,3,1,17,4,1,0,0,17,3,9,16,17,1,17,17,5,1,4,1,17,512]

theorem envBound47157 : H12AffineFastState.Bounded env47157 := by
  intro p hp
  have h : env47157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47156_47157 : H12AffineEnvironment.transform 5 16 env47156 = env47157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47156 == env47157) = true)

theorem identity47157 : scanCanonicalize (H12AffineFastState.compose env47157 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound47157 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47158 : List Nat := [2,4,8,16,0,16,8,5,17,5,16,17,9,17,0,3,1,17,4,1,0,0,17,3,9,16,17,1,17,17,5,1,4,1,17,17]

theorem envBound47158 : H12AffineFastState.Bounded env47158 := by
  intro p hp
  have h : env47158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47157_47158 : H12AffineEnvironment.transform 8 17 env47157 = env47158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env47157 == env47158) = true)

theorem identity47158 : scanCanonicalize (H12AffineFastState.compose env47158 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47158 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47159 : List Nat := [2,4,8,0,0,0,8,5,1,5,0,1,9,1,0,3,1,1,4,1,0,0,1,3,9,0,1,1,1,1,5,1,4,1,1,1]

theorem envBound47159 : H12AffineFastState.Bounded env47159 := by
  intro p hp
  have h : env47159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47158_47159 : H12AffineEnvironment.transform 3 0 env47158 = env47159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47158 == env47159) = true)

theorem identity47159 : scanCanonicalize (H12AffineFastState.compose env47159 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47160 : List Nat := [2,0,8,0,0,0,8,1,1,1,0,1,9,1,0,3,1,1,0,1,0,0,1,3,9,0,1,1,1,1,1,1,0,1,1,1]

theorem envBound47160 : H12AffineFastState.Bounded env47160 := by
  intro p hp
  have h : env47160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47159_47160 : H12AffineEnvironment.transform 1 0 env47159 = env47160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47159 == env47160) = true)

def env47161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,16,95497,8192,64,23809,5393,45404,262144,61704,318548,257,21793,46092,120407]

theorem envBound47161 : H12AffineFastState.Bounded env47161 := by
  intro p hp
  have h : env47161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47145_47161 : H12AffineEnvironment.transform 16 49169 env47145 = env47161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47145 == env47161) = true)

theorem identity47161 : scanCanonicalize (H12AffineFastState.compose env47161 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47161 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1025,8540,17729,272392,16,95497,8192,64,23809,5393,4097,262144,20565,294153,257,21793,5457,96010]

theorem envBound47162 : H12AffineFastState.Bounded env47162 := by
  intro p hp
  have h : env47162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47161_47162 : H12AffineEnvironment.transform 14 8541 env47161 = env47162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47161 == env47162) = true)

theorem identity47162 : scanCanonicalize (H12AffineFastState.compose env47162 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound47162 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env47163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,2421,1025,8540,17729,8573,16,95497,8192,64,23809,5393,4097,2421,20565,29820,257,21793,5457,96010]

theorem envBound47163 : H12AffineFastState.Bounded env47163 := by
  intro p hp
  have h : env47163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47162_47163 : H12AffineEnvironment.transform 17 2421 env47162 = env47163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env47162 == env47163) = true)

theorem identity47163 : scanCanonicalize (H12AffineFastState.compose env47163 (packedSelected [4,7,9,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound47163 : packedSelected [4,7,9,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21511,24908,2421,1025,8540,17729,8573,16,8462,8192,64,23809,5393,4097,2421,20565,29820,257,21793,5457,8973]

theorem envBound47164 : H12AffineFastState.Bounded env47164 := by
  intro p hp
  have h : env47164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47163_47164 : H12AffineEnvironment.transform 15 21511 env47163 = env47164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env47163 == env47164) = true)

theorem identity47164 : scanCanonicalize (H12AffineFastState.compose env47164 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound47164 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env47165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8495,5220,2421,1025,8540,12393,8573,16,8462,8192,64,10281,5393,4097,2421,9597,340,257,8201,5457,8973]

theorem envBound47165 : H12AffineFastState.Bounded env47165 := by
  intro p hp
  have h : env47165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47164_47165 : H12AffineEnvironment.transform 13 13608 env47164 = env47165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env47164 == env47165) = true)

theorem identity47165 : scanCanonicalize (H12AffineFastState.compose env47165 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47165 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env47166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,372,262,5220,2421,1025,373,4160,340,16,295,41,64,2048,5393,4097,2421,1364,340,257,32,5457,804]

theorem envBound47166 : H12AffineFastState.Bounded env47166 := by
  intro p hp
  have h : env47166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47165_47166 : H12AffineEnvironment.transform 12 41 env47165 = env47166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47165 == env47166) = true)

theorem identity47166 : scanCanonicalize (H12AffineFastState.compose env47166 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47166 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47167 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,293,262,5173,2340,1025,292,4113,261,16,295,41,17,2048,5393,4097,2340,1285,261,257,32,5376,804]

theorem envBound47167 : H12AffineFastState.Bounded env47167 := by
  intro p hp
  have h : env47167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47166_47167 : H12AffineEnvironment.transform 5 17 env47166 = env47167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47166 == env47167) = true)

theorem identity47167 : scanCanonicalize (H12AffineFastState.compose env47167 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound47167 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env47168 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,17,41,1296,293,262,1060,2340,1025,292,0,261,16,295,41,17,2048,1280,16,2340,1285,261,257,32,1297,804]

theorem envBound47168 : H12AffineFastState.Bounded env47168 := by
  intro p hp
  have h : env47168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47167_47168 : H12AffineEnvironment.transform 11 17 env47167 = env47168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47167 == env47168) = true)

theorem identity47168 : scanCanonicalize (H12AffineFastState.compose env47168 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47168 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env47169 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,17,41,292,293,262,16,2340,53,292,0,261,16,295,41,17,2048,308,16,2340,305,261,257,32,293,804]

theorem envBound47169 : H12AffineFastState.Bounded env47169 := by
  intro p hp
  have h : env47169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47168_47169 : H12AffineEnvironment.transform 9 52 env47168 = env47169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47168 == env47169) = true)

def env47170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272393,180224,95497,8193,64,23809,185601,45405,262145,143640,400453,257,21793,46093,202310]

theorem envBound47170 : H12AffineFastState.Bounded env47170 := by
  intro p hp
  have h : env47170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47144_47170 : H12AffineEnvironment.transform 6 9 env47144 = env47170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47144 == env47170) = true)

def env47171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,16,95497,8193,64,23809,5393,45405,262145,61704,318549,257,21793,46093,120406]

theorem envBound47171 : H12AffineFastState.Bounded env47171 := by
  intro p hp
  have h : env47171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47170_47171 : H12AffineEnvironment.transform 16 49168 env47170 = env47171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47170 == env47171) = true)

theorem identity47171 : scanCanonicalize (H12AffineFastState.compose env47171 (packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 64888) := by decide +kernel

theorem selectedBound47171 : packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env47172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,64888,1025,32769,58397,54641,16,95497,8193,64,23809,5393,45405,64889,61704,8493,257,21793,46093,120406]

theorem envBound47172 : H12AffineFastState.Bounded env47172 := by
  intro p hp
  have h : env47172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47171_47172 : H12AffineEnvironment.transform 17 64888 env47171 = env47172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64888 env47171 == env47172) = true)

theorem identity47172 : scanCanonicalize (H12AffineFastState.compose env47172 (packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47172 : packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env47173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49168,56436,1025,32769,50449,54641,16,87045,269,64,23809,5393,36945,56437,53252,33,257,21793,38145,120406]

theorem envBound47173 : H12AffineFastState.Bounded env47173 := by
  intro p hp
  have h : env47173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47172_47173 : H12AffineEnvironment.transform 12 268 env47172 = env47173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47172 == env47173) = true)

theorem identity47173 : scanCanonicalize (H12AffineFastState.compose env47173 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound47173 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env47174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,32768,65536,38208,35108,1025,32769,36929,32801,16,65877,269,64,2129,5393,36945,35109,34132,33,257,113,38145,99078]

theorem envBound47174 : H12AffineFastState.Bounded env47174 := by
  intro p hp
  have h : env47174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47173_47174 : H12AffineEnvironment.transform 13 5456 env47173 = env47174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env47173 == env47174) = true)

theorem identity47174 : scanCanonicalize (H12AffineFastState.compose env47174 (packedSelected [2,3,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 39943) := by decide +kernel

theorem selectedBound47174 : packedSelected [2,3,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env47175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,32768,39943,38208,35108,1025,32769,36929,32801,16,40274,269,64,2129,5393,36945,35109,34132,33,257,113,38145,7937]

theorem envBound47175 : H12AffineFastState.Bounded env47175 := by
  intro p hp
  have h : env47175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47174_47175 : H12AffineEnvironment.transform 15 39943 env47174 = env47175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 39943 env47174 == env47175) = true)

theorem identity47175 : scanCanonicalize (H12AffineFastState.compose env47175 (packedSelected [3,4,7,8,11,14,19] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound47175 : packedSelected [3,4,7,8,11,14,19] rootPS < 2^1333 := by decide +kernel

def env47176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,268,2048,32768,33111,34832,35108,1025,32769,36113,32801,16,32770,269,64,2129,2113,36097,35109,34132,33,257,113,34897,593]

theorem envBound47176 : H12AffineFastState.Bounded env47176 := by
  intro p hp
  have h : env47176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47175_47176 : H12AffineEnvironment.transform 11 3408 env47175 = env47176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env47175 == env47176) = true)

theorem identity47176 : scanCanonicalize (H12AffineFastState.compose env47176 (packedSelected [1,2,6,8,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47176 : packedSelected [1,2,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env47177 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3108,120,2048,32768,32803,34832,34896,1025,32769,35941,32801,16,32770,121,64,2129,2113,35957,34897,33824,33,117,113,34897,593]

theorem envBound47177 : H12AffineFastState.Bounded env47177 := by
  intro p hp
  have h : env47177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47176_47177 : H12AffineEnvironment.transform 7 116 env47176 = env47177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47176 == env47177) = true)

theorem identity47177 : scanCanonicalize (H12AffineFastState.compose env47177 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound47177 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47178 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3108,120,2048,1124,1095,3188,3124,1025,1125,2049,1093,16,1126,121,64,2129,2113,2065,3125,68,33,117,113,3125,593]

theorem envBound47178 : H12AffineFastState.Bounded env47178 := by
  intro p hp
  have h : env47178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47177_47178 : H12AffineEnvironment.transform 14 1124 env47177 = env47178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env47177 == env47178) = true)

theorem identity47178 : scanCanonicalize (H12AffineFastState.compose env47178 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47178 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47179 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,120,2048,1,34,2065,2129,100,0,2049,32,16,3,121,64,2129,2113,2065,2128,68,33,117,113,2128,593]

theorem envBound47179 : H12AffineFastState.Bounded env47179 := by
  intro p hp
  have h : env47179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47178_47179 : H12AffineEnvironment.transform 9 101 env47178 = env47179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47178 == env47179) = true)

theorem identity47179 : scanCanonicalize (H12AffineFastState.compose env47179 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound47179 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env47180 : List Nat := [2,4,8,16,32,64,9,116,512,101,529,592,120,529,1,34,512,576,100,0,528,32,16,3,121,64,576,592,512,577,68,33,117,113,577,593]

theorem envBound47180 : H12AffineFastState.Bounded env47180 := by
  intro p hp
  have h : env47180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47179_47180 : H12AffineEnvironment.transform 10 529 env47179 = env47180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env47179 == env47180) = true)

theorem identity47180 : scanCanonicalize (H12AffineFastState.compose env47180 (packedSelected [1,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47180 : packedSelected [1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env47181 : List Nat := [2,4,8,16,32,16,9,36,512,53,529,512,40,529,1,34,512,528,52,0,528,32,16,3,41,16,528,512,512,529,20,33,37,33,529,513]

theorem envBound47181 : H12AffineFastState.Bounded env47181 := by
  intro p hp
  have h : env47181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47180_47181 : H12AffineEnvironment.transform 5 16 env47180 = env47181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47180 == env47181) = true)

def env47182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,17,95497,8193,64,23809,5392,45405,262145,61705,318548,257,21793,46093,120407]

theorem envBound47182 : H12AffineFastState.Bounded env47182 := by
  intro p hp
  have h : env47182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47170_47182 : H12AffineEnvironment.transform 16 49169 env47170 = env47182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47170 == env47182) = true)

theorem identity47182 : scanCanonicalize (H12AffineFastState.compose env47182 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47182 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58396,33,17,95497,8193,64,23809,5392,45405,10281,61705,62588,257,21793,46093,120407]

theorem envBound47183 : H12AffineFastState.Bounded env47183 := by
  intro p hp
  have h : env47183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47182_47183 : H12AffineEnvironment.transform 17 10280 env47182 = env47183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47182 == env47183) = true)

theorem identity47183 : scanCanonicalize (H12AffineFastState.compose env47183 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound47183 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,24860,10280,1025,8460,17681,33,17,95497,8193,64,23809,5392,4176,10281,20484,21873,257,21793,5376,96090]

theorem envBound47184 : H12AffineFastState.Bounded env47184 := by
  intro p hp
  have h : env47184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47183_47184 : H12AffineEnvironment.transform 14 8461 env47183 = env47184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env47183 == env47184) = true)

theorem identity47184 : scanCanonicalize (H12AffineFastState.compose env47184 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound47184 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env47185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,263,24860,10280,1025,8460,17681,33,17,29710,8193,64,23809,5392,4176,10281,20484,21873,257,21793,5376,30301]

theorem envBound47185 : H12AffineFastState.Bounded env47185 := by
  intro p hp
  have h : env47185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47184_47185 : H12AffineEnvironment.transform 15 263 env47184 = env47185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env47184 == env47185) = true)

theorem identity47185 : scanCanonicalize (H12AffineFastState.compose env47185 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47185 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env47186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,17681,33,17,21763,268,64,23809,5392,4176,2340,20484,21873,257,21793,5376,22352]

theorem envBound47186 : H12AffineFastState.Bounded env47186 := by
  intro p hp
  have h : env47186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47185_47186 : H12AffineEnvironment.transform 12 269 env47185 = env47186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47185 == env47186) = true)

theorem identity47186 : scanCanonicalize (H12AffineFastState.compose env47186 (packedSelected [0,3,5,6,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound47186 : packedSelected [0,3,5,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,269,16384,0,263,16401,2341,1025,1,17681,33,17,19731,268,64,17681,3328,2112,2340,18452,19809,257,19761,3344,20288]

theorem envBound47187 : H12AffineFastState.Bounded env47187 := by
  intro p hp
  have h : env47187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47186_47187 : H12AffineEnvironment.transform 11 2064 env47186 = env47187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env47186 == env47187) = true)

theorem identity47187 : scanCanonicalize (H12AffineFastState.compose env47187 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47187 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env47188 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2064,40,16384,0,34,16401,2048,1025,1,17460,33,17,19510,41,64,17460,3109,2112,2049,18452,19524,36,19476,3125,20069]

theorem envBound47188 : H12AffineFastState.Bounded env47188 := by
  intro p hp
  have h : env47188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47187_47188 : H12AffineEnvironment.transform 7 37 env47187 = env47188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47187 == env47188) = true)

theorem identity47188 : scanCanonicalize (H12AffineFastState.compose env47188 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound47188 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env47189 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2064,40,3125,0,34,3108,2048,1025,1,2049,33,17,3,41,64,2049,3109,2112,2049,1057,113,36,33,3125,592]

theorem envBound47189 : H12AffineFastState.Bounded env47189 := by
  intro p hp
  have h : env47189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47188_47189 : H12AffineEnvironment.transform 13 3125 env47188 = env47189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env47188 == env47189) = true)

theorem identity47189 : scanCanonicalize (H12AffineFastState.compose env47189 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47189 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47190 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1076,1060,40,1,0,34,16,1076,1025,1,1077,33,17,3,41,64,1077,17,1140,1077,1057,113,36,33,1,592]

theorem envBound47190 : H12AffineFastState.Bounded env47190 := by
  intro p hp
  have h : env47190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47189_47190 : H12AffineEnvironment.transform 10 1076 env47189 = env47190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env47189 == env47190) = true)

theorem identity47190 : scanCanonicalize (H12AffineFastState.compose env47190 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47190 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env47191 : List Nat := [2,4,8,16,32,64,9,37,512,101,81,65,40,1,0,34,16,81,100,1,80,33,17,3,41,64,80,17,17,80,68,113,36,33,1,592]

theorem envBound47191 : H12AffineFastState.Bounded env47191 := by
  intro p hp
  have h : env47191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47190_47191 : H12AffineEnvironment.transform 9 101 env47190 = env47191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47190 == env47191) = true)

theorem identity47191 : scanCanonicalize (H12AffineFastState.compose env47191 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47191 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47192 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,17,40,1,0,34,16,1,52,1,0,33,17,3,41,16,0,17,17,0,20,33,36,33,1,512]

theorem envBound47192 : H12AffineFastState.Bounded env47192 := by
  intro p hp
  have h : env47192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47191_47192 : H12AffineEnvironment.transform 5 16 env47191 = env47192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47191 == env47192) = true)

theorem identity47192 : scanCanonicalize (H12AffineFastState.compose env47192 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47193 : List Nat := [2,4,8,4,32,4,9,37,512,33,1,5,40,1,0,34,4,1,32,1,0,33,5,3,41,4,0,5,5,0,0,33,36,33,1,512]

theorem envBound47193 : H12AffineFastState.Bounded env47193 := by
  intro p hp
  have h : env47193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47192_47193 : H12AffineEnvironment.transform 3 4 env47192 = env47193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47192 == env47193) = true)

theorem identity47193 : scanCanonicalize (H12AffineFastState.compose env47193 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47194 : List Nat := [2,4,8,4,6,4,9,3,512,7,1,5,14,1,0,4,4,1,6,1,0,7,5,3,15,4,0,5,5,0,0,7,2,7,1,512]

theorem envBound47194 : H12AffineFastState.Bounded env47194 := by
  intro p hp
  have h : env47194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47193_47194 : H12AffineEnvironment.transform 4 6 env47193 = env47194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47193 == env47194) = true)

theorem identity47194 : scanCanonicalize (H12AffineFastState.compose env47194 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47195 : List Nat := [2,3,8,3,1,3,9,3,512,0,1,2,9,1,0,3,3,1,1,1,0,0,2,3,8,3,0,2,2,0,0,0,2,0,1,512]

theorem envBound47195 : H12AffineFastState.Bounded env47195 := by
  intro p hp
  have h : env47195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47194_47195 : H12AffineEnvironment.transform 1 3 env47194 = env47195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47194 == env47195) = true)

theorem identity47195 : scanCanonicalize (H12AffineFastState.compose env47195 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound47195 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47196 : List Nat := [2,3,8,3,1,3,9,3,11,0,1,2,9,1,0,3,3,1,1,1,0,0,2,3,8,3,0,2,2,0,0,0,2,0,1,11]

theorem envBound47196 : H12AffineFastState.Bounded env47196 := by
  intro p hp
  have h : env47196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47195_47196 : H12AffineEnvironment.transform 8 11 env47195 = env47196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env47195 == env47196) = true)

def env47197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180361,95497,8328,64,23808,185736,45524,262280,143761,400452,257,21793,46212,202310]

theorem envBound47197 : H12AffineFastState.Bounded env47197 := by
  intro p hp
  have h : env47197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47143_47197 : H12AffineEnvironment.transform 21 272513 env47143 = env47197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47143 == env47197) = true)

theorem identity47197 : scanCanonicalize (H12AffineFastState.compose env47197 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound47197 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58517,272513,17,95497,8328,64,23808,5392,45524,262280,61705,318684,257,21793,46212,120542]

theorem envBound47198 : H12AffineFastState.Bounded env47198 := by
  intro p hp
  have h : env47198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47197_47198 : H12AffineEnvironment.transform 16 49304 env47197 = env47198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env47197 == env47198) = true)

def env47199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,17,95497,8192,64,23808,5392,45404,262144,61705,318548,257,21793,46092,120406]

theorem envBound47199 : H12AffineFastState.Bounded env47199 := by
  intro p hp
  have h : env47199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47198_47199 : H12AffineEnvironment.transform 6 8 env47198 = env47199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47198 == env47199) = true)

theorem identity47199 : scanCanonicalize (H12AffineFastState.compose env47199 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47199 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,58397,41341,17,95497,8192,64,23808,5392,45404,35188,61705,21792,257,21793,46092,120406]

theorem envBound47200 : H12AffineFastState.Bounded env47200 := by
  intro p hp
  have h : env47200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47199_47200 : H12AffineEnvironment.transform 17 35188 env47199 = env47200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47199 == env47200) = true)

theorem identity47200 : scanCanonicalize (H12AffineFastState.compose env47200 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound47200 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,65536,46392,35188,1025,32769,37173,41341,17,65569,8192,64,10280,5392,45404,35188,33825,8200,257,8201,46092,107390]

theorem envBound47201 : H12AffineFastState.Bounded env47201 := by
  intro p hp
  have h : env47201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47200_47201 : H12AffineEnvironment.transform 13 13608 env47200 = env47201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env47200 == env47201) = true)

theorem identity47201 : scanCanonicalize (H12AffineFastState.compose env47201 (packedSelected [0,2,4,6,7,9,11,14,19,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47201 : packedSelected [0,2,4,6,7,9,11,14,19,23,26] rootPS < 2^1333 := by decide +kernel

def env47202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,65536,37940,35188,1025,32769,37173,32881,17,65569,268,64,2340,5392,36944,35188,33825,260,257,261,38144,98930]

theorem envBound47202 : H12AffineFastState.Bounded env47202 := by
  intro p hp
  have h : env47202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47201_47202 : H12AffineEnvironment.transform 12 268 env47201 = env47202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47201 == env47202) = true)

theorem identity47202 : scanCanonicalize (H12AffineFastState.compose env47202 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound47202 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env47203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,115,37940,35188,1025,32769,37173,32881,17,82,268,64,2340,5392,36944,35188,33825,260,257,261,38144,33281]

theorem envBound47203 : H12AffineFastState.Bounded env47203 := by
  intro p hp
  have h : env47203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47202_47203 : H12AffineEnvironment.transform 15 115 env47202 = env47203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env47202 == env47203) = true)

theorem identity47203 : scanCanonicalize (H12AffineFastState.compose env47203 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47203 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env47204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,1,115,5173,2421,1025,0,4404,112,17,82,268,64,2340,5392,4177,2421,1056,260,257,261,5377,512]

theorem envBound47204 : H12AffineFastState.Bounded env47204 := by
  intro p hp
  have h : env47204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47203_47204 : H12AffineEnvironment.transform 14 1 env47203 = env47204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47203 == env47204) = true)

theorem identity47204 : scanCanonicalize (H12AffineFastState.compose env47204 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47204 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47205 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,268,5156,1,3,5173,2309,1025,0,4404,0,17,34,268,48,2340,5392,4129,2309,1056,260,257,261,5377,512]

theorem envBound47205 : H12AffineFastState.Bounded env47205 := by
  intro p hp
  have h : env47205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47204_47205 : H12AffineEnvironment.transform 5 48 env47204 = env47205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47204 == env47205) = true)

theorem identity47205 : scanCanonicalize (H12AffineFastState.compose env47205 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47205 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47206 : List Nat := [2,4,8,16,32,48,8,37,512,1024,2048,4096,41,5156,1,3,5173,2080,1025,0,4113,0,17,34,41,48,2049,5173,4129,2080,1056,33,36,32,5156,512]

theorem envBound47206 : H12AffineFastState.Bounded env47206 := by
  intro p hp
  have h : env47206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47205_47206 : H12AffineEnvironment.transform 7 37 env47205 = env47206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47205 == env47206) = true)

theorem identity47206 : scanCanonicalize (H12AffineFastState.compose env47206 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47206 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47207 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,9,5124,1,3,5141,2048,1025,0,4113,0,17,2,9,16,2049,5141,4097,2048,1024,1,4,0,5124,512]

theorem envBound47207 : H12AffineFastState.Bounded env47207 := by
  intro p hp
  have h : env47207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47206_47207 : H12AffineEnvironment.transform 4 0 env47206 = env47207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47206 == env47207) = true)

theorem identity47207 : scanCanonicalize (H12AffineFastState.compose env47207 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3599) := by decide +kernel

theorem selectedBound47207 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47208 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,3599,9,2571,1,3,2586,2048,1025,0,3614,0,17,2,9,16,2049,2586,3598,2048,1024,1,4,0,2571,512]

theorem envBound47208 : H12AffineFastState.Bounded env47208 := by
  intro p hp
  have h : env47208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47207_47208 : H12AffineEnvironment.transform 11 3599 env47207 = env47208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3599 env47207 == env47208) = true)

theorem identity47208 : scanCanonicalize (H12AffineFastState.compose env47208 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound47208 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47209 : List Nat := [2,4,8,16,0,16,8,5,512,30,2048,2577,9,2571,1,3,2586,2048,31,0,2560,0,17,2,9,16,2049,2586,2576,2048,30,1,4,0,2571,512]

theorem envBound47209 : H12AffineFastState.Bounded env47209 := by
  intro p hp
  have h : env47209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47208_47209 : H12AffineEnvironment.transform 9 30 env47208 = env47209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env47208 == env47209) = true)

theorem identity47209 : scanCanonicalize (H12AffineFastState.compose env47209 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound47209 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47210 : List Nat := [2,4,8,16,0,16,8,5,16,30,2048,2049,9,2075,1,3,2058,2048,31,0,2064,0,17,2,9,16,2049,2058,2048,2048,30,1,4,0,2075,16]

theorem envBound47210 : H12AffineFastState.Bounded env47210 := by
  intro p hp
  have h : env47210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47209_47210 : H12AffineEnvironment.transform 8 16 env47209 = env47210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env47209 == env47210) = true)

theorem identity47210 : scanCanonicalize (H12AffineFastState.compose env47210 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound47210 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47211 : List Nat := [2,4,8,16,0,16,8,5,16,30,11,10,9,16,1,3,1,11,31,0,27,0,17,2,9,16,10,1,11,11,30,1,4,0,16,16]

theorem envBound47211 : H12AffineFastState.Bounded env47211 := by
  intro p hp
  have h : env47211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47210_47211 : H12AffineEnvironment.transform 10 11 env47210 = env47211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env47210 == env47211) = true)

theorem identity47211 : scanCanonicalize (H12AffineFastState.compose env47211 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound47211 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47212 : List Nat := [2,4,8,2,0,2,8,5,2,12,11,10,9,2,1,3,1,11,13,0,9,0,3,2,9,2,10,1,11,11,12,1,4,0,2,2]

theorem envBound47212 : H12AffineFastState.Bounded env47212 := by
  intro p hp
  have h : env47212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47211_47212 : H12AffineEnvironment.transform 3 2 env47211 = env47212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env47211 == env47212) = true)

theorem identity47212 : scanCanonicalize (H12AffineFastState.compose env47212 (packedSelected [0,8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47212 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env47213 : List Nat := [1,4,8,1,0,1,8,5,1,12,8,9,9,1,1,0,1,8,13,0,9,0,0,1,9,1,9,1,8,8,12,1,4,0,1,1]

theorem envBound47213 : H12AffineFastState.Bounded env47213 := by
  intro p hp
  have h : env47213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47212_47213 : H12AffineEnvironment.transform 0 1 env47212 = env47213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47212 == env47213) = true)

theorem identity47213 : scanCanonicalize (H12AffineFastState.compose env47213 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47214 : List Nat := [1,0,8,1,0,1,8,1,1,8,8,9,9,1,1,0,1,8,9,0,9,0,0,1,9,1,9,1,8,8,8,1,0,0,1,1]

theorem envBound47214 : H12AffineFastState.Bounded env47214 := by
  intro p hp
  have h : env47214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47213_47214 : H12AffineEnvironment.transform 1 0 env47213 = env47214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47213 == env47214) = true)

theorem identity47214 : scanCanonicalize (H12AffineFastState.compose env47214 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47214 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env47215 : List Nat := [1,0,0,1,0,1,0,1,1,0,0,1,1,1,1,0,1,0,1,0,1,0,0,1,1,1,1,1,0,0,0,1,0,0,1,1]

theorem envBound47215 : H12AffineFastState.Bounded env47215 := by
  intro p hp
  have h : env47215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47214_47215 : H12AffineEnvironment.transform 2 0 env47214 = env47215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47214 == env47215) = true)

def env47216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,17,95497,8193,64,23808,5392,45405,262145,61705,318549,257,21793,46093,120407]

theorem envBound47216 : H12AffineFastState.Bounded env47216 := by
  intro p hp
  have h : env47216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47198_47216 : H12AffineEnvironment.transform 6 9 env47198 = env47216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47198 == env47216) = true)

theorem identity47216 : scanCanonicalize (H12AffineFastState.compose env47216 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47216 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58396,32,17,95497,8193,64,23808,5392,45405,10281,61705,62589,257,21793,46093,120407]

theorem envBound47217 : H12AffineFastState.Bounded env47217 := by
  intro p hp
  have h : env47217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47216_47217 : H12AffineEnvironment.transform 17 10280 env47216 = env47217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47216 == env47217) = true)

theorem identity47217 : scanCanonicalize (H12AffineFastState.compose env47217 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound47217 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,16449,10280,1025,81,25676,32,17,95497,8193,64,23808,5392,12557,10281,29017,29741,257,21793,13405,87559]

theorem envBound47218 : H12AffineFastState.Bounded env47218 := by
  intro p hp
  have h : env47218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47217_47218 : H12AffineEnvironment.transform 14 80 env47217 = env47218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env47217 == env47218) = true)

theorem identity47218 : scanCanonicalize (H12AffineFastState.compose env47218 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound47218 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,30042,16449,10280,1025,81,25676,32,17,83,8193,64,23808,5392,12557,10281,29017,29741,257,21793,13405,9053]

theorem envBound47219 : H12AffineFastState.Bounded env47219 := by
  intro p hp
  have h : env47219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47218_47219 : H12AffineEnvironment.transform 15 30042 env47218 = env47219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env47218 == env47219) = true)

theorem identity47219 : scanCanonicalize (H12AffineFastState.compose env47219 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47219 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env47220 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,29962,16401,10280,1025,1,25628,32,17,3,8193,16,23808,5392,12557,10281,28937,29741,257,21793,13325,8973]

theorem envBound47220 : H12AffineFastState.Bounded env47220 := by
  intro p hp
  have h : env47220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47219_47220 : H12AffineEnvironment.transform 5 16 env47219 = env47220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47219 == env47220) = true)

theorem identity47220 : scanCanonicalize (H12AffineFastState.compose env47220 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound47220 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47221 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,16384,0,26926,16401,10280,1025,1,25628,32,17,3,8193,16,16676,2356,11561,10281,27949,26633,257,18693,10281,8973]

theorem envBound47221 : H12AffineFastState.Bounded env47221 := by
  intro p hp
  have h : env47221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47220_47221 : H12AffineEnvironment.transform 11 3108 env47220 = env47221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env47220 == env47221) = true)

theorem identity47221 : scanCanonicalize (H12AffineFastState.compose env47221 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47221 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47222 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,10280,0,262,10297,10280,1025,1,3124,32,17,3,8193,16,10508,2356,11561,10281,1285,33,257,8493,10281,8973]

theorem envBound47222 : H12AffineFastState.Bounded env47222 := by
  intro p hp
  have h : env47222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47221_47222 : H12AffineEnvironment.transform 13 10280 env47221 = env47222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10280 env47221 == env47222) = true)

theorem identity47222 : scanCanonicalize (H12AffineFastState.compose env47222 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3133) := by decide +kernel

theorem selectedBound47222 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47223 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,3133,1045,0,262,1028,1045,1025,1,3124,32,17,3,3132,16,1329,2356,276,1044,1285,33,257,3344,1044,3888]

theorem envBound47223 : H12AffineFastState.Bounded env47223 := by
  intro p hp
  have h : env47223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47222_47223 : H12AffineEnvironment.transform 12 3133 env47222 = env47223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3133 env47222 == env47223) = true)

theorem identity47223 : scanCanonicalize (H12AffineFastState.compose env47223 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound47223 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env47224 : List Nat := [2,4,8,16,32,16,9,256,512,1024,261,1313,1336,1045,0,262,1028,1045,1025,1,1329,32,17,3,1337,16,1329,49,276,1044,1285,33,257,1045,1044,1589]

theorem envBound47224 : H12AffineFastState.Bounded env47224 := by
  intro p hp
  have h : env47224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47223_47224 : H12AffineEnvironment.transform 10 261 env47223 = env47224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env47223 == env47224) = true)

theorem identity47224 : scanCanonicalize (H12AffineFastState.compose env47224 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47224 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env47225 : List Nat := [2,4,8,16,32,16,9,256,512,52,261,277,268,33,0,262,48,33,53,1,261,32,17,3,269,16,261,49,276,32,305,33,257,33,32,513]

theorem envBound47225 : H12AffineFastState.Bounded env47225 := by
  intro p hp
  have h : env47225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47224_47225 : H12AffineEnvironment.transform 9 52 env47224 = env47225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47224 == env47225) = true)

theorem identity47225 : scanCanonicalize (H12AffineFastState.compose env47225 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound47225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47226 : List Nat := [2,4,8,16,32,16,9,53,512,52,48,32,57,33,0,51,48,33,53,1,48,32,17,3,56,16,48,49,33,32,4,33,52,33,32,513]

theorem envBound47226 : H12AffineFastState.Bounded env47226 := by
  intro p hp
  have h : env47226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47225_47226 : H12AffineEnvironment.transform 7 53 env47225 = env47226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env47225 == env47226) = true)

theorem identity47226 : scanCanonicalize (H12AffineFastState.compose env47226 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound47226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47227 : List Nat := [2,4,8,16,32,16,9,53,33,52,48,32,57,33,0,51,48,33,53,1,48,32,17,3,56,16,48,49,33,32,4,33,52,33,32,32]

theorem envBound47227 : H12AffineFastState.Bounded env47227 := by
  intro p hp
  have h : env47227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47226_47227 : H12AffineEnvironment.transform 8 33 env47226 = env47227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env47226 == env47227) = true)

theorem identity47227 : scanCanonicalize (H12AffineFastState.compose env47227 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47228 : List Nat := [2,4,8,16,17,16,9,4,16,5,1,17,8,16,0,2,1,16,4,1,1,17,17,3,9,16,1,0,16,17,4,16,5,16,17,17]

theorem envBound47228 : H12AffineFastState.Bounded env47228 := by
  intro p hp
  have h : env47228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47227_47228 : H12AffineEnvironment.transform 4 17 env47227 = env47228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47227 == env47228) = true)

def env47229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,8631681,8328,64,4486528,8393984,8548701,8830977,143760,12645453,257,21792,46213,202311]

theorem envBound47229 : H12AffineFastState.Bounded env47229 := by
  intro p hp
  have h : env47229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47100_47229 : H12AffineEnvironment.transform 23 8631681 env47100 = env47229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631681 env47100 == env47229) = true)

def env47230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180360,95497,8328,64,4486528,185736,45525,262281,143760,4338885,257,21792,46213,202311]

theorem envBound47230 : H12AffineFastState.Bounded env47230 := by
  intro p hp
  have h : env47230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47229_47230 : H12AffineEnvironment.transform 22 180360 env47229 = env47230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env47229 == env47230) = true)

def env47231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180360,95497,8328,64,23808,185736,45525,262281,143760,400453,257,21792,46213,202311]

theorem envBound47231 : H12AffineFastState.Bounded env47231 := by
  intro p hp
  have h : env47231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47230_47231 : H12AffineEnvironment.transform 21 272512 env47230 = env47231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47230 == env47231) = true)

theorem identity47231 : scanCanonicalize (H12AffineFastState.compose env47231 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound47231 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,115871,272512,73754,95497,8328,64,23808,79130,45525,262281,119042,392407,257,21792,46213,63189]

theorem envBound47232 : H12AffineFastState.Bounded env47232 := by
  intro p hp
  have h : env47232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47231_47232 : H12AffineEnvironment.transform 16 123026 env47231 = env47232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env47231 == env47232) = true)

def env47233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,115871,32,73754,95497,8328,64,23808,79130,45525,10281,119042,119927,257,21792,46213,63189]

theorem envBound47233 : H12AffineFastState.Bounded env47233 := by
  intro p hp
  have h : env47233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47232_47233 : H12AffineEnvironment.transform 17 10400 env47232 = env47233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47232 == env47233) = true)

theorem identity47233 : scanCanonicalize (H12AffineFastState.compose env47233 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound47233 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,16400,10400,1025,32769,25629,32,32920,54667,8328,64,23808,38296,45525,10281,29056,29941,257,21792,46213,63189]

theorem envBound47234 : H12AffineFastState.Bounded env47234 := by
  intro p hp
  have h : env47234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47233_47234 : H12AffineEnvironment.transform 15 41090 env47233 = env47234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env47233 == env47234) = true)

theorem identity47234 : scanCanonicalize (H12AffineFastState.compose env47234 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47234 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env47235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,41090,13389,10400,1025,32769,4160,32,32920,41430,8328,64,10589,38296,45525,10281,1501,168,257,8573,46213,33416]

theorem envBound47235 : H12AffineFastState.Bounded env47235 := by
  intro p hp
  have h : env47235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47234_47235 : H12AffineEnvironment.transform 13 13405 env47234 = env47235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47234 == env47235) = true)

theorem identity47235 : scanCanonicalize (H12AffineFastState.compose env47235 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound47235 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env47236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8661,343,13389,10400,1025,8660,4160,32,8525,3,8328,64,10589,13389,4096,10281,1501,168,257,8573,5456,9053]

theorem envBound47236 : H12AffineFastState.Bounded env47236 := by
  intro p hp
  have h : env47236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47235_47236 : H12AffineEnvironment.transform 14 8661 env47235 = env47236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env47235 == env47236) = true)

theorem identity47236 : scanCanonicalize (H12AffineFastState.compose env47236 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,343,5392,2557,1025,137,4160,32,16,3,469,64,2048,5392,4096,2420,1501,168,257,32,5456,512]

theorem envBound47237 : H12AffineFastState.Bounded env47237 := by
  intro p hp
  have h : env47237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47236_47237 : H12AffineEnvironment.transform 12 349 env47236 = env47237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47236 == env47237) = true)

theorem identity47237 : scanCanonicalize (H12AffineFastState.compose env47237 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47237 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47238 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,349,5376,136,343,5392,2525,1025,137,4160,0,16,3,469,64,2048,5392,4096,2388,1501,136,257,0,5456,512]

theorem envBound47238 : H12AffineFastState.Bounded env47238 := by
  intro p hp
  have h : env47238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47237_47238 : H12AffineEnvironment.transform 4 0 env47237 = env47238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47237 == env47238) = true)

theorem identity47238 : scanCanonicalize (H12AffineFastState.compose env47238 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47238 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47239 : List Nat := [2,4,8,16,0,64,128,5,512,1024,2048,4096,88,5125,136,82,5141,2264,1025,137,4160,0,16,3,208,64,2048,5141,4096,2129,1240,136,4,0,5205,512]

theorem envBound47239 : H12AffineFastState.Bounded env47239 := by
  intro p hp
  have h : env47239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47238_47239 : H12AffineEnvironment.transform 7 5 env47238 = env47239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47238 == env47239) = true)

theorem identity47239 : scanCanonicalize (H12AffineFastState.compose env47239 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound47239 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47240 : List Nat := [2,4,8,16,0,64,128,5,512,204,2048,4096,88,4297,136,82,4313,2264,205,137,4160,0,16,3,208,64,2048,4313,4096,2129,20,136,4,0,4249,512]

theorem envBound47240 : H12AffineFastState.Bounded env47240 := by
  intro p hp
  have h : env47240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47239_47240 : H12AffineEnvironment.transform 9 204 env47239 = env47240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env47239 == env47240) = true)

theorem identity47240 : scanCanonicalize (H12AffineFastState.compose env47240 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47241 : List Nat := [2,4,8,16,0,64,9,5,512,69,2048,4096,88,4160,1,82,4176,2129,68,0,4160,0,16,3,89,64,2048,4176,4096,2129,20,1,4,0,4112,512]

theorem envBound47241 : H12AffineFastState.Bounded env47241 := by
  intro p hp
  have h : env47241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47240_47241 : H12AffineEnvironment.transform 6 9 env47240 = env47241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47240 == env47241) = true)

theorem identity47241 : scanCanonicalize (H12AffineFastState.compose env47241 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47241 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47242 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,4096,9,4113,1,3,4097,2048,21,0,4113,0,16,3,8,17,2048,4097,4096,2048,20,1,4,0,4112,512]

theorem envBound47242 : H12AffineFastState.Bounded env47242 := by
  intro p hp
  have h : env47242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47241_47242 : H12AffineEnvironment.transform 5 17 env47241 = env47242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47241 == env47242) = true)

theorem identity47242 : scanCanonicalize (H12AffineFastState.compose env47242 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound47242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47243 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2576,9,2561,1,3,2577,2048,21,0,2561,0,16,3,8,17,2048,2577,2576,2048,20,1,4,0,2560,512]

theorem envBound47243 : H12AffineFastState.Bounded env47243 := by
  intro p hp
  have h : env47243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47242_47243 : H12AffineEnvironment.transform 11 2576 env47242 = env47243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env47242 == env47243) = true)

theorem identity47243 : scanCanonicalize (H12AffineFastState.compose env47243 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound47243 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47244 : List Nat := [2,4,8,16,0,17,9,5,21,20,2048,2053,9,2068,1,3,2052,2048,21,0,2068,0,16,3,8,17,2048,2052,2053,2048,20,1,4,0,2069,21]

theorem envBound47244 : H12AffineFastState.Bounded env47244 := by
  intro p hp
  have h : env47244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47243_47244 : H12AffineEnvironment.transform 8 21 env47243 = env47244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env47243 == env47244) = true)

theorem identity47244 : scanCanonicalize (H12AffineFastState.compose env47244 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47244 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47245 : List Nat := [2,4,8,4,0,5,9,5,1,0,2048,2053,9,2048,1,3,2052,2048,1,0,2048,0,4,3,8,5,2048,2052,2053,2048,0,1,4,0,2049,1]

theorem envBound47245 : H12AffineFastState.Bounded env47245 := by
  intro p hp
  have h : env47245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47244_47245 : H12AffineEnvironment.transform 3 4 env47244 = env47245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47244 == env47245) = true)

def env47246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,115871,33,73754,95497,8328,64,23808,79130,45525,10280,119042,119926,257,21792,46213,63189]

theorem envBound47246 : H12AffineFastState.Bounded env47246 := by
  intro p hp
  have h : env47246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47232_47246 : H12AffineEnvironment.transform 17 10401 env47232 = env47246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47232 == env47246) = true)

theorem identity47246 : scanCanonicalize (H12AffineFastState.compose env47246 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound47246 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57676,10401,1025,32769,50497,33,8644,29911,8328,64,23808,13508,45525,10280,53468,54696,257,21792,46213,63189]

theorem envBound47247 : H12AffineFastState.Bounded env47247 := by
  intro p hp
  have h : env47247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47246_47247 : H12AffineEnvironment.transform 15 478 env47246 = env47247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env47246 == env47247) = true)

theorem identity47247 : scanCanonicalize (H12AffineFastState.compose env47247 (packedSelected [0,4,7,14,17,18,19,22,23,26,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47247 : packedSelected [0,4,7,14,17,18,19,22,23,26,35] rootPS < 2^1333 := by decide +kernel

def env47248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,5528,10401,1025,29909,12693,33,8644,29911,8328,64,23808,13508,17665,10280,9224,8572,257,21792,16465,513]

theorem envBound47248 : H12AffineFastState.Bounded env47248 := by
  intro p hp
  have h : env47248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47247_47248 : H12AffineEnvironment.transform 14 29908 env47247 = env47248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47247 == env47248) = true)

theorem identity47248 : scanCanonicalize (H12AffineFastState.compose env47248 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47248 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,478,5528,2421,1025,21761,4161,33,16,21763,348,64,23808,5392,17665,2556,1500,168,257,21792,16465,513]

theorem envBound47249 : H12AffineFastState.Bounded env47249 := by
  intro p hp
  have h : env47249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47248_47249 : H12AffineEnvironment.transform 12 468 env47248 = env47249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47248 == env47249) = true)

theorem identity47249 : scanCanonicalize (H12AffineFastState.compose env47249 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound47249 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env47250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5528,2421,1025,136,4161,33,16,138,348,64,2185,5392,4232,2556,1500,168,257,169,5592,513]

theorem envBound47250 : H12AffineFastState.Bounded env47250 := by
  intro p hp
  have h : env47250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47249_47250 : H12AffineEnvironment.transform 13 5513 env47249 = env47250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47249 == env47250) = true)

theorem identity47250 : scanCanonicalize (H12AffineFastState.compose env47250 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound47250 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47251 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5237,137,34,5220,2185,1025,136,4161,33,16,138,160,64,2185,5356,4232,2048,1056,168,253,169,5156,513]

theorem envBound47251 : H12AffineFastState.Bounded env47251 := by
  intro p hp
  have h : env47251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47250_47251 : H12AffineEnvironment.transform 7 252 env47250 = env47251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env47250 == env47251) = true)

theorem identity47251 : scanCanonicalize (H12AffineFastState.compose env47251 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound47251 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47252 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,40,5237,81,34,5220,2129,1025,80,4161,33,16,82,120,64,2129,5172,4176,2048,1056,112,37,113,5156,513]

theorem envBound47252 : H12AffineFastState.Bounded env47252 := by
  intro p hp
  have h : env47252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47251_47252 : H12AffineEnvironment.transform 6 88 env47251 = env47252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env47251 == env47252) = true)

theorem identity47252 : scanCanonicalize (H12AffineFastState.compose env47252 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47252 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env47253 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5173,2048,1025,1,4112,33,16,3,41,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound47253 : H12AffineFastState.Bounded env47253 := by
  intro p hp
  have h : env47253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47252_47253 : H12AffineEnvironment.transform 5 17 env47252 = env47253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47252 == env47253) = true)

def env47254 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,0,34,1029,2048,1025,1,32,33,16,3,41,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound47254 : H12AffineFastState.Bounded env47254 := by
  intro p hp
  have h : env47254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47253_47254 : H12AffineEnvironment.transform 11 48 env47253 = env47254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47253 == env47254) = true)

theorem identity47254 : scanCanonicalize (H12AffineFastState.compose env47254 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound47254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47255 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,48,40,1044,0,34,1029,529,1025,1,32,33,16,3,41,17,529,1028,49,529,1056,33,37,32,1044,513]

theorem envBound47255 : H12AffineFastState.Bounded env47255 := by
  intro p hp
  have h : env47255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47254_47255 : H12AffineEnvironment.transform 10 529 env47254 = env47255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env47254 == env47255) = true)

def env47256 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,32,0,34,49,529,53,1,32,33,16,3,41,17,529,48,49,529,20,33,37,32,32,513]

theorem envBound47256 : H12AffineFastState.Bounded env47256 := by
  intro p hp
  have h : env47256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47255_47256 : H12AffineEnvironment.transform 9 52 env47255 = env47256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47255 == env47256) = true)

def env47257 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,33,0,34,48,529,52,1,32,33,16,3,41,17,529,49,49,529,21,33,37,32,33,513]

theorem envBound47257 : H12AffineFastState.Bounded env47257 := by
  intro p hp
  have h : env47257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47255_47257 : H12AffineEnvironment.transform 9 53 env47255 = env47257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47255 == env47257) = true)

theorem identity47257 : scanCanonicalize (H12AffineFastState.compose env47257 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47258 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,40,33,0,34,48,58,52,1,32,33,16,3,41,17,58,49,49,58,21,33,37,32,33,42]

theorem envBound47258 : H12AffineFastState.Bounded env47258 := by
  intro p hp
  have h : env47258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47257_47258 : H12AffineEnvironment.transform 8 43 env47257 = env47258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47257 == env47258) = true)

def leafEnv47258 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,40,33,0,34,48,58,52,1,32,33,16,3,20,41,1,17,58,49,49,58,21,33,37,32,5,35,33,42,1,32,0]

def active47258 : List Nat := [0,1,2,3,4]

def tree47258 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47258 : H12WitnessSearch.Good tree47258 := H12GlobalWitnessIndex.good

theorem leafIdentity47258 : H12AffineFastState.composeSystem env47258 rootObs = leafEnv47258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47258 rootObs == leafEnv47258) = true)

theorem terminalChecked47258 : H12PackedTerminal.terminalCheckFast leafEnv47258 active47258 tree47258 = true := by decide +kernel

def env47259 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,0,34,1028,2048,1025,1,33,33,16,3,41,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound47259 : H12AffineFastState.Bounded env47259 := by
  intro p hp
  have h : env47259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47253_47259 : H12AffineEnvironment.transform 11 49 env47253 = env47259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47253 == env47259) = true)

theorem identity47259 : scanCanonicalize (H12AffineFastState.compose env47259 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound47259 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47260 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,40,1045,0,34,1028,1572,1025,1,33,33,16,3,41,17,1572,1029,48,1572,1056,33,37,32,1045,513]

theorem envBound47260 : H12AffineFastState.Bounded env47260 := by
  intro p hp
  have h : env47260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47259_47260 : H12AffineEnvironment.transform 10 1572 env47259 = env47260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env47259 == env47260) = true)

def env47261 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,33,0,34,48,528,53,1,33,33,16,3,41,17,528,49,48,528,20,33,37,32,33,513]

theorem envBound47261 : H12AffineFastState.Bounded env47261 := by
  intro p hp
  have h : env47261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47260_47261 : H12AffineEnvironment.transform 9 52 env47260 = env47261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47260 == env47261) = true)

def env47262 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,32,0,34,49,529,52,1,33,33,16,3,41,17,529,48,48,529,21,33,37,32,32,513]

theorem envBound47262 : H12AffineFastState.Bounded env47262 := by
  intro p hp
  have h : env47262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47260_47262 : H12AffineEnvironment.transform 9 53 env47260 = env47262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47260 == env47262) = true)

theorem identity47262 : scanCanonicalize (H12AffineFastState.compose env47262 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47263 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,40,32,0,34,49,59,52,1,33,33,16,3,41,17,59,48,48,59,21,33,37,32,32,43]

theorem envBound47263 : H12AffineFastState.Bounded env47263 := by
  intro p hp
  have h : env47263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47262_47263 : H12AffineEnvironment.transform 8 42 env47262 = env47263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47262 == env47263) = true)

def leafEnv47263 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,40,32,0,34,49,59,52,1,33,33,16,3,20,41,1,17,59,48,48,59,21,33,37,32,5,35,32,43,1,33,0]

def active47263 : List Nat := [0,1,2,3,4]

def tree47263 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47263 : H12WitnessSearch.Good tree47263 := H12GlobalWitnessIndex.good

theorem leafIdentity47263 : H12AffineFastState.composeSystem env47263 rootObs = leafEnv47263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47263 rootObs == leafEnv47263) = true)

theorem terminalChecked47263 : H12PackedTerminal.terminalCheckFast leafEnv47263 active47263 tree47263 = true := by decide +kernel

def env47264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180360,95497,8328,64,23809,185736,45525,262281,143760,400452,257,21792,46213,202311]

theorem envBound47264 : H12AffineFastState.Bounded env47264 := by
  intro p hp
  have h : env47264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47230_47264 : H12AffineEnvironment.transform 21 272513 env47230 = env47264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47230 == env47264) = true)

theorem identity47264 : scanCanonicalize (H12AffineFastState.compose env47264 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47264 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272513,180360,21762,8328,64,23809,185736,45525,262281,143760,400452,257,21792,46213,144972]

theorem envBound47265 : H12AffineFastState.Bounded env47265 := by
  intro p hp
  have h : env47265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47264_47265 : H12AffineEnvironment.transform 15 8203 env47264 = env47265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47264 == env47265) = true)

def env47266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272393,180224,21762,8192,64,23809,185600,45405,262145,143640,400452,257,21792,46093,144972]

theorem envBound47266 : H12AffineFastState.Bounded env47266 := by
  intro p hp
  have h : env47266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47265_47266 : H12AffineEnvironment.transform 6 8 env47265 = env47266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47265 == env47266) = true)

def env47267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58397,272393,16,21762,8192,64,23809,5392,45405,262145,61704,318548,257,21792,46093,63068]

theorem envBound47267 : H12AffineFastState.Bounded env47267 := by
  intro p hp
  have h : env47267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47266_47267 : H12AffineEnvironment.transform 16 49168 env47266 = env47267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47266 == env47267) = true)

theorem identity47267 : scanCanonicalize (H12AffineFastState.compose env47267 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47267 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,24909,262144,1025,8540,17728,272393,16,21762,8192,64,23809,5392,4096,262145,20565,294153,257,21792,5456,22273]

theorem envBound47268 : H12AffineFastState.Bounded env47268 := by
  intro p hp
  have h : env47268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47267_47268 : H12AffineEnvironment.transform 14 8541 env47267 = env47268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47267 == env47268) = true)

theorem identity47268 : scanCanonicalize (H12AffineFastState.compose env47268 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound47268 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env47269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,24909,10281,1025,8540,17728,32,16,21762,8192,64,23809,5392,4096,10280,20565,21792,257,21792,5456,22273]

theorem envBound47269 : H12AffineFastState.Bounded env47269 := by
  intro p hp
  have h : env47269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47268_47269 : H12AffineEnvironment.transform 17 10281 env47268 = env47269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47268 == env47269) = true)

theorem identity47269 : scanCanonicalize (H12AffineFastState.compose env47269 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound47269 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env47270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,1095,17665,3173,1025,1296,17728,32,16,21762,1100,64,23809,5392,4096,3172,20565,21792,257,21792,5456,22273]

theorem envBound47270 : H12AffineFastState.Bounded env47270 := by
  intro p hp
  have h : env47270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47269_47270 : H12AffineEnvironment.transform 12 1100 env47269 = env47270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env47269 == env47270) = true)

theorem identity47270 : scanCanonicalize (H12AffineFastState.compose env47270 (packedSelected [2,4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47270 : packedSelected [2,4,9,16] rootPS < 2^1333 := by decide +kernel

def env47271 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,16384,1297,1047,17665,3125,1025,1296,17680,32,16,21762,1052,16,23809,5392,4096,3124,20485,21792,257,21792,5376,22273]

theorem envBound47271 : H12AffineFastState.Bounded env47271 := by
  intro p hp
  have h : env47271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47270_47271 : H12AffineEnvironment.transform 5 16 env47270 = env47271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47270 == env47271) = true)

theorem identity47271 : scanCanonicalize (H12AffineFastState.compose env47271 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound47271 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47272 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2064,1052,16384,1297,1047,17665,3125,1025,1296,17680,32,16,19730,1052,16,17681,3328,2064,3124,18453,19760,257,19760,3344,20241]

theorem envBound47272 : H12AffineFastState.Bounded env47272 := by
  intro p hp
  have h : env47272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47271_47272 : H12AffineEnvironment.transform 11 2064 env47271 = env47272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env47271 == env47272) = true)

theorem identity47272 : scanCanonicalize (H12AffineFastState.compose env47272 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound47272 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47273 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2064,1052,2341,1297,1047,3108,3125,1025,1296,3125,32,16,1079,1052,16,3124,3328,2064,3124,304,1045,257,1045,3344,1588]

theorem envBound47273 : H12AffineFastState.Bounded env47273 := by
  intro p hp
  have h : env47273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47272_47273 : H12AffineEnvironment.transform 13 2341 env47272 = env47273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env47272 == env47273) = true)

theorem identity47273 : scanCanonicalize (H12AffineFastState.compose env47273 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47273 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47274 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,269,2341,0,262,2357,2340,272,1,2340,32,16,294,269,16,2341,2065,2064,2341,304,260,257,260,2049,805]

theorem envBound47274 : H12AffineFastState.Bounded env47274 := by
  intro p hp
  have h : env47274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47273_47274 : H12AffineEnvironment.transform 9 273 env47273 = env47274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47273 == env47274) = true)

theorem identity47274 : scanCanonicalize (H12AffineFastState.compose env47274 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47274 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47275 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,41,2049,0,34,2065,2048,52,1,2048,32,16,2,41,16,2049,2065,2064,2049,20,32,37,32,2049,513]

theorem envBound47275 : H12AffineFastState.Bounded env47275 := by
  intro p hp
  have h : env47275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47274_47275 : H12AffineEnvironment.transform 7 36 env47274 = env47275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47274 == env47275) = true)

theorem identity47275 : scanCanonicalize (H12AffineFastState.compose env47275 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound47275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47276 : List Nat := [2,4,8,16,32,16,8,36,512,53,545,561,41,544,0,34,560,545,52,1,545,32,16,2,41,16,544,560,561,544,20,32,37,32,544,513]

theorem envBound47276 : H12AffineFastState.Bounded env47276 := by
  intro p hp
  have h : env47276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47275_47276 : H12AffineEnvironment.transform 10 545 env47275 = env47276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env47275 == env47276) = true)

theorem identity47276 : scanCanonicalize (H12AffineFastState.compose env47276 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47277 : List Nat := [2,4,8,16,16,16,8,20,512,5,529,513,25,528,0,18,512,529,4,1,529,16,16,2,25,16,528,512,513,528,20,16,21,16,528,513]

theorem envBound47277 : H12AffineFastState.Bounded env47277 := by
  intro p hp
  have h : env47277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47276_47277 : H12AffineEnvironment.transform 4 16 env47276 = env47277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47276 == env47277) = true)

theorem identity47277 : scanCanonicalize (H12AffineFastState.compose env47277 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47278 : List Nat := [2,4,8,1,1,1,8,5,512,5,512,513,8,513,0,3,512,512,4,1,512,1,1,2,8,1,513,512,513,513,5,1,4,1,513,513]

theorem envBound47278 : H12AffineFastState.Bounded env47278 := by
  intro p hp
  have h : env47278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47277_47278 : H12AffineEnvironment.transform 3 1 env47277 = env47278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47277 == env47278) = true)

theorem identity47278 : scanCanonicalize (H12AffineFastState.compose env47278 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47278 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47279 : List Nat := [2,4,8,1,1,1,8,5,0,5,0,1,8,1,0,3,0,0,4,1,0,1,1,2,8,1,1,0,1,1,5,1,4,1,1,1]

theorem envBound47279 : H12AffineFastState.Bounded env47279 := by
  intro p hp
  have h : env47279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47278_47279 : H12AffineEnvironment.transform 8 0 env47278 = env47279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47278 == env47279) = true)

def env47280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58396,272393,17,21762,8192,64,23809,5393,45405,262145,61705,318549,257,21792,46093,63069]

theorem envBound47280 : H12AffineFastState.Bounded env47280 := by
  intro p hp
  have h : env47280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47266_47280 : H12AffineEnvironment.transform 16 49169 env47266 = env47280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47266 == env47280) = true)

theorem identity47280 : scanCanonicalize (H12AffineFastState.compose env47280 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,35188,1025,32769,58396,41341,17,21762,8192,64,23809,5393,45405,35189,61705,21793,257,21792,46093,63069]

theorem envBound47281 : H12AffineFastState.Bounded env47281 := by
  intro p hp
  have h : env47281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47280_47281 : H12AffineEnvironment.transform 17 35188 env47280 = env47281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47280 == env47281) = true)

theorem identity47281 : scanCanonicalize (H12AffineFastState.compose env47281 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound47281 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env47282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,5392,23669,1025,21760,12573,29820,17,21762,8192,64,23809,5393,25692,23668,9224,21793,257,21792,24844,9052]

theorem envBound47282 : H12AffineFastState.Bounded env47282 := by
  intro p hp
  have h : env47282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47281_47282 : H12AffineEnvironment.transform 14 21761 env47281 = env47282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env47281 == env47282) = true)

theorem identity47282 : scanCanonicalize (H12AffineFastState.compose env47282 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47282 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,5392,23669,1025,21760,4160,21793,17,21762,349,64,23809,5393,17665,23668,1365,21793,257,21792,16465,513]

theorem envBound47283 : H12AffineFastState.Bounded env47283 := by
  intro p hp
  have h : env47283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47282_47283 : H12AffineEnvironment.transform 12 349 env47282 = env47283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47282 == env47283) = true)

theorem identity47283 : scanCanonicalize (H12AffineFastState.compose env47283 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47283 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2421,1025,0,4160,33,17,2,349,64,2049,5393,4097,2420,1365,33,257,32,5457,513]

theorem envBound47284 : H12AffineFastState.Bounded env47284 := by
  intro p hp
  have h : env47284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47283_47284 : H12AffineEnvironment.transform 13 5376 env47283 = env47284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47283 == env47284) = true)

theorem identity47284 : scanCanonicalize (H12AffineFastState.compose env47284 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47284 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47285 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,349,4160,1,342,4176,2421,321,0,4160,33,17,2,349,64,2049,4177,4097,2420,21,33,257,32,4113,513]

theorem envBound47285 : H12AffineFastState.Bounded env47285 := by
  intro p hp
  have h : env47285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47284_47285 : H12AffineEnvironment.transform 9 320 env47284 = env47285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47284 == env47285) = true)

theorem identity47285 : scanCanonicalize (H12AffineFastState.compose env47285 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound47285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47286 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,356,349,292,1,342,308,2421,321,0,292,33,17,2,349,64,2049,309,357,2420,21,33,257,32,373,513]

theorem envBound47286 : H12AffineFastState.Bounded env47286 := by
  intro p hp
  have h : env47286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47285_47286 : H12AffineEnvironment.transform 11 356 env47285 = env47286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env47285 == env47286) = true)

def env47287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272392,180225,21762,8193,64,23809,185601,45404,262144,143641,400452,257,21792,46092,144972]

theorem envBound47287 : H12AffineFastState.Bounded env47287 := by
  intro p hp
  have h : env47287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47265_47287 : H12AffineEnvironment.transform 6 9 env47265 = env47287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47265 == env47287) = true)

def env47288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58397,272392,17,21762,8193,64,23809,5393,45404,262144,61705,318548,257,21792,46092,63068]

theorem envBound47288 : H12AffineFastState.Bounded env47288 := by
  intro p hp
  have h : env47288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47287_47288 : H12AffineEnvironment.transform 16 49168 env47287 = env47288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47287 == env47288) = true)

theorem identity47288 : scanCanonicalize (H12AffineFastState.compose env47288 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47288 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10280,1025,32769,58397,32,17,21762,8193,64,23809,5393,45404,10280,61705,62588,257,21792,46092,63068]

theorem envBound47289 : H12AffineFastState.Bounded env47289 := by
  intro p hp
  have h : env47289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47288_47289 : H12AffineEnvironment.transform 17 10280 env47288 = env47289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47288 == env47289) = true)

theorem identity47289 : scanCanonicalize (H12AffineFastState.compose env47289 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound47289 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env47290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,5393,10280,1025,21760,12572,32,17,21762,8193,64,23809,5393,25693,10280,9224,8573,257,21792,24845,9053]

theorem envBound47290 : H12AffineFastState.Bounded env47290 := by
  intro p hp
  have h : env47290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47289_47290 : H12AffineEnvironment.transform 14 21761 env47289 = env47290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env47289 == env47290) = true)

theorem identity47290 : scanCanonicalize (H12AffineFastState.compose env47290 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47290 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env47291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,5393,10280,1025,8541,12572,32,17,8543,8193,64,10588,5393,4096,10280,9224,8573,257,8573,5456,9053]

theorem envBound47291 : H12AffineFastState.Bounded env47291 := by
  intro p hp
  have h : env47291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47290_47291 : H12AffineEnvironment.transform 13 13405 env47290 = env47291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47290 == env47291) = true)

theorem identity47291 : scanCanonicalize (H12AffineFastState.compose env47291 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47291 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47292 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,8233,8203,5220,10280,1025,8232,12393,32,17,8234,8193,64,10281,5220,4096,10280,9224,8200,116,8200,5157,8744]

theorem envBound47292 : H12AffineFastState.Bounded env47292 := by
  intro p hp
  have h : env47292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47291_47292 : H12AffineEnvironment.transform 7 117 env47291 = env47292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47291 == env47292) = true)

theorem identity47292 : scanCanonicalize (H12AffineFastState.compose env47292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47293 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,0,34,5220,2049,1025,1,4160,32,17,3,40,64,2048,5220,4096,2049,1057,33,116,33,5157,513]

theorem envBound47293 : H12AffineFastState.Bounded env47293 := by
  intro p hp
  have h : env47293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47292_47293 : H12AffineEnvironment.transform 12 41 env47292 = env47293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47292 == env47293) = true)

theorem identity47293 : scanCanonicalize (H12AffineFastState.compose env47293 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47293 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47294 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,41,4112,0,34,4096,2049,101,1,4160,32,17,3,40,64,2048,4096,4096,2049,69,33,116,33,4161,513]

theorem envBound47294 : H12AffineFastState.Bounded env47294 := by
  intro p hp
  have h : env47294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47293_47294 : H12AffineEnvironment.transform 9 100 env47293 = env47294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47293 == env47294) = true)

theorem identity47294 : scanCanonicalize (H12AffineFastState.compose env47294 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound47294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47295 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,16,41,0,0,34,16,2049,101,1,80,32,17,3,40,64,2048,16,16,2049,69,33,116,33,81,513]

theorem envBound47295 : H12AffineFastState.Bounded env47295 := by
  intro p hp
  have h : env47295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47294_47295 : H12AffineEnvironment.transform 11 16 env47294 = env47295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47294 == env47295) = true)

theorem identity47295 : scanCanonicalize (H12AffineFastState.compose env47295 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47296 : List Nat := [2,4,8,16,17,64,9,68,512,85,2048,16,24,0,0,19,16,2049,84,1,80,17,17,3,25,64,2048,16,16,2049,69,16,69,16,81,513]

theorem envBound47296 : H12AffineFastState.Bounded env47296 := by
  intro p hp
  have h : env47296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47295_47296 : H12AffineEnvironment.transform 4 17 env47295 = env47296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47295 == env47296) = true)

def env47297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58396,272392,16,21762,8193,64,23809,5392,45404,262144,61704,318549,257,21792,46092,63069]

theorem envBound47297 : H12AffineFastState.Bounded env47297 := by
  intro p hp
  have h : env47297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47287_47297 : H12AffineEnvironment.transform 16 49169 env47287 = env47297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47287 == env47297) = true)

theorem identity47297 : scanCanonicalize (H12AffineFastState.compose env47297 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47297 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env47298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,49169,262144,1025,32769,50496,264532,16,21762,349,64,23809,5392,36864,262144,53332,318549,257,21792,38224,55041]

theorem envBound47298 : H12AffineFastState.Bounded env47298 := by
  intro p hp
  have h : env47298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47297_47298 : H12AffineEnvironment.transform 12 348 env47297 = env47298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47297 == env47298) = true)

def env47299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180361,95496,8328,64,4486528,185737,45524,262280,143760,4338884,257,21792,46213,202311]

theorem envBound47299 : H12AffineFastState.Bounded env47299 := by
  intro p hp
  have h : env47299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47229_47299 : H12AffineEnvironment.transform 22 180361 env47229 = env47299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env47229 == env47299) = true)

def env47300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180361,95496,8328,64,23808,185737,45524,262280,143760,400452,257,21792,46213,202311]

theorem envBound47300 : H12AffineFastState.Bounded env47300 := by
  intro p hp
  have h : env47300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47299_47300 : H12AffineEnvironment.transform 21 272512 env47299 = env47300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47299 == env47300) = true)

theorem identity47300 : scanCanonicalize (H12AffineFastState.compose env47300 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound47300 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272512,120015,95496,8328,64,23808,115151,45524,262280,75222,329730,257,21792,46213,513]

theorem envBound47301 : H12AffineFastState.Bounded env47301 := by
  intro p hp
  have h : env47301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47300_47301 : H12AffineEnvironment.transform 16 70726 env47300 = env47301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env47300 == env47301) = true)

def env47302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272392,119879,95496,8192,64,23808,115015,45404,262144,75102,329730,257,21792,46093,513]

theorem envBound47302 : H12AffineFastState.Bounded env47302 := by
  intro p hp
  have h : env47302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47301_47302 : H12AffineEnvironment.transform 6 8 env47301 = env47302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47301 == env47302) = true)

theorem identity47302 : scanCanonicalize (H12AffineFastState.compose env47302 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47302 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,262144,1025,32769,77899,272392,106522,65877,8192,64,10589,111898,45404,262144,75102,329730,257,8573,46093,513]

theorem envBound47303 : H12AffineFastState.Bounded env47303 := by
  intro p hp
  have h : env47303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47302_47303 : H12AffineEnvironment.transform 13 13405 env47302 = env47303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47302 == env47303) = true)

theorem identity47303 : scanCanonicalize (H12AffineFastState.compose env47303 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 100467) := by decide +kernel

theorem selectedBound47303 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,100467,1025,32769,77899,106619,106522,65877,8192,64,10589,111898,45404,100467,75102,32881,257,8573,46093,513]

theorem envBound47304 : H12AffineFastState.Bounded env47304 := by
  intro p hp
  have h : env47304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47303_47304 : H12AffineEnvironment.transform 17 100467 env47303 = env47304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100467 env47303 == env47304) = true)

theorem identity47304 : scanCanonicalize (H12AffineFastState.compose env47304 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound47304 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env47305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,33110,38160,2341,1025,32769,45341,8493,8524,32771,8192,64,10589,13388,45404,2341,41992,32881,257,8573,46093,513]

theorem envBound47305 : H12AffineFastState.Bounded env47305 := by
  intro p hp
  have h : env47305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47304_47305 : H12AffineEnvironment.transform 15 33110 env47304 = env47305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env47304 == env47305) = true)

theorem identity47305 : scanCanonicalize (H12AffineFastState.compose env47305 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound47305 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1077,1379,4389,2341,1025,1076,13608,8493,8524,1078,8192,64,10589,13388,13673,2341,8253,1092,257,8573,12344,513]

theorem envBound47306 : H12AffineFastState.Bounded env47306 := by
  intro p hp
  have h : env47306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47305_47306 : H12AffineEnvironment.transform 14 1077 env47305 = env47306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env47305 == env47306) = true)

theorem identity47306 : scanCanonicalize (H12AffineFastState.compose env47306 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47306 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env47307 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1077,1331,4389,2341,1025,1076,13608,8493,8476,1078,8192,16,10509,13340,13625,2341,8253,1044,257,8493,12344,513]

theorem envBound47307 : H12AffineFastState.Bounded env47307 := by
  intro p hp
  have h : env47307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47306_47307 : H12AffineEnvironment.transform 5 16 env47306 = env47307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47306 == env47307) = true)

theorem identity47307 : scanCanonicalize (H12AffineFastState.compose env47307 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47307 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47308 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,12345,1,263,4389,2341,53,0,12572,8493,8476,2,8192,16,10509,12328,12557,2341,8253,32,257,8493,12344,513]

theorem envBound47308 : H12AffineFastState.Bounded env47308 := by
  intro p hp
  have h : env47308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47307_47308 : H12AffineEnvironment.transform 9 52 env47307 = env47308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47307 == env47308) = true)

theorem identity47308 : scanCanonicalize (H12AffineFastState.compose env47308 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound47308 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env47309 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,513,8192,8760,1,263,804,2341,53,0,8989,8493,8476,2,8192,16,10509,8745,8972,2341,8253,32,257,8493,8761,513]

theorem envBound47309 : H12AffineFastState.Bounded env47309 := by
  intro p hp
  have h : env47309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47308_47309 : H12AffineEnvironment.transform 11 513 env47308 = env47309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env47308 == env47309) = true)

theorem identity47309 : scanCanonicalize (H12AffineFastState.compose env47309 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound47309 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47310 : List Nat := [2,4,8,16,32,16,8,256,512,52,820,513,8192,8760,1,263,804,529,53,0,8989,8493,8476,2,8192,16,8761,8745,8972,529,8253,32,257,8493,8761,513]

theorem envBound47310 : H12AffineFastState.Bounded env47310 := by
  intro p hp
  have h : env47310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47309_47310 : H12AffineEnvironment.transform 10 820 env47309 = env47310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env47309 == env47310) = true)

def env47311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272393,119878,95496,8193,64,23808,115014,45405,262145,75103,329730,257,21792,46092,513]

theorem envBound47311 : H12AffineFastState.Bounded env47311 := by
  intro p hp
  have h : env47311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47301_47311 : H12AffineEnvironment.transform 6 9 env47301 = env47311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47301 == env47311) = true)

def env47312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180361,95496,8328,64,23809,185737,45524,262280,143760,400453,257,21792,46213,202311]

theorem envBound47312 : H12AffineFastState.Bounded env47312 := by
  intro p hp
  have h : env47312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47299_47312 : H12AffineEnvironment.transform 21 272513 env47299 = env47312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47299 == env47312) = true)

theorem identity47312 : scanCanonicalize (H12AffineFastState.compose env47312 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound47312 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,140301,272513,180361,41430,8328,64,23809,185737,45524,262280,143760,400453,257,21792,46213,180889]

theorem envBound47313 : H12AffineFastState.Bounded env47313 := by
  intro p hp
  have h : env47313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47312_47313 : H12AffineEnvironment.transform 15 54494 env47312 = env47313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env47312 == env47313) = true)

def env47314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,140301,272393,180225,41310,8192,64,23809,185601,45404,262144,143640,400453,257,21792,46093,180753]

theorem envBound47314 : H12AffineFastState.Bounded env47314 := by
  intro p hp
  have h : env47314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47313_47314 : H12AffineEnvironment.transform 6 8 env47313 = env47314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47313 == env47314) = true)

theorem identity47314 : scanCanonicalize (H12AffineFastState.compose env47314 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 49461) := by decide +kernel

theorem selectedBound47314 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env47315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49461,262144,1025,32769,58680,272393,308,41310,8192,64,23809,5172,45404,262144,61485,318832,257,21792,46093,804]

theorem envBound47315 : H12AffineFastState.Bounded env47315 := by
  intro p hp
  have h : env47315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47314_47315 : H12AffineEnvironment.transform 16 49461 env47314 = env47315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49461 env47314 == env47315) = true)

theorem identity47315 : scanCanonicalize (H12AffineFastState.compose env47315 (packedSelected [2,3,5,6,9,12,14,15,16,17,18,20,22,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound47315 : packedSelected [2,3,5,6,9,12,14,15,16,17,18,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env47316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,21874,16401,262144,1025,293,25628,272393,308,8314,8192,64,23809,5172,12408,262144,28937,285780,257,21792,13609,804]

theorem envBound47316 : H12AffineFastState.Bounded env47316 := by
  intro p hp
  have h : env47316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47315_47316 : H12AffineEnvironment.transform 14 292 env47315 = env47316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env47315 == env47316) = true)

theorem identity47316 : scanCanonicalize (H12AffineFastState.compose env47316 (packedSelected [3,4,9,10,14,17,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound47316 : packedSelected [3,4,9,10,14,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env47317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,292,21874,16401,262144,1025,293,17509,264304,308,3,121,64,23809,5172,4097,262144,20848,285780,257,21792,5456,804]

theorem envBound47317 : H12AffineFastState.Bounded env47317 := by
  intro p hp
  have h : env47317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47316_47317 : H12AffineEnvironment.transform 12 121 env47316 = env47317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env47316 == env47317) = true)

theorem identity47317 : scanCanonicalize (H12AffineFastState.compose env47317 (packedSelected [16,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47317 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env47318 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,0,21590,16401,262144,1025,1,17509,264304,16,3,121,64,23589,5172,4097,262144,20564,285780,37,21508,5236,512]

theorem envBound47318 : H12AffineFastState.Bounded env47318 := by
  intro p hp
  have h : env47318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47317_47318 : H12AffineEnvironment.transform 7 36 env47317 = env47318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47317 == env47318) = true)

theorem identity47318 : scanCanonicalize (H12AffineFastState.compose env47318 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound47318 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47319 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5204,0,2,5189,262144,1025,1,4145,264304,16,3,121,64,2161,5172,4097,262144,1024,264192,37,80,5236,512]

theorem envBound47319 : H12AffineFastState.Bounded env47319 := by
  intro p hp
  have h : env47319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47318_47319 : H12AffineEnvironment.transform 13 5204 env47318 = env47319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env47318 == env47319) = true)

theorem identity47319 : scanCanonicalize (H12AffineFastState.compose env47319 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound47319 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env47320 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5204,0,2,5189,2048,1025,1,4145,112,16,3,121,64,2161,5172,4097,2048,1024,0,37,80,5236,512]

theorem envBound47320 : H12AffineFastState.Bounded env47320 := by
  intro p hp
  have h : env47320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47319_47320 : H12AffineEnvironment.transform 17 2048 env47319 = env47320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env47319 == env47320) = true)

theorem identity47320 : scanCanonicalize (H12AffineFastState.compose env47320 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47320 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47321 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,9,5156,0,2,5173,2048,1025,1,4145,0,16,3,9,48,2049,5172,4097,2048,1024,0,37,32,5124,512]

theorem envBound47321 : H12AffineFastState.Bounded env47321 := by
  intro p hp
  have h : env47321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47320_47321 : H12AffineEnvironment.transform 5 48 env47320 = env47321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47320 == env47321) = true)

theorem identity47321 : scanCanonicalize (H12AffineFastState.compose env47321 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound47321 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47322 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,528,9,1588,0,2,1573,2048,1025,1,545,0,16,3,9,48,2049,1572,529,2048,1024,0,37,32,1556,512]

theorem envBound47322 : H12AffineFastState.Bounded env47322 := by
  intro p hp
  have h : env47322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47321_47322 : H12AffineEnvironment.transform 11 528 env47321 = env47322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env47321 == env47322) = true)

theorem identity47322 : scanCanonicalize (H12AffineFastState.compose env47322 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound47322 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47323 : List Nat := [2,4,8,16,32,48,8,36,512,1024,528,528,9,1588,0,2,1573,528,1025,1,545,0,16,3,9,48,529,1572,529,528,1024,0,37,32,1556,512]

theorem envBound47323 : H12AffineFastState.Bounded env47323 := by
  intro p hp
  have h : env47323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47322_47323 : H12AffineEnvironment.transform 10 528 env47322 = env47323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env47322 == env47323) = true)

theorem identity47323 : scanCanonicalize (H12AffineFastState.compose env47323 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47323 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47324 : List Nat := [2,4,8,1,32,33,8,36,512,1024,513,513,9,1573,0,2,1573,513,1025,1,545,0,1,3,9,33,512,1572,512,513,1024,0,37,32,1541,512]

theorem envBound47324 : H12AffineFastState.Bounded env47324 := by
  intro p hp
  have h : env47324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47323_47324 : H12AffineEnvironment.transform 3 1 env47323 = env47324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47323 == env47324) = true)

theorem identity47324 : scanCanonicalize (H12AffineFastState.compose env47324 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound47324 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47325 : List Nat := [2,4,8,1,32,33,8,36,512,36,513,513,9,513,0,2,513,513,37,1,545,0,1,3,9,33,512,512,512,513,36,0,37,32,545,512]

theorem envBound47325 : H12AffineFastState.Bounded env47325 := by
  intro p hp
  have h : env47325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47324_47325 : H12AffineEnvironment.transform 9 36 env47324 = env47325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env47324 == env47325) = true)

theorem identity47325 : scanCanonicalize (H12AffineFastState.compose env47325 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound47325 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47326 : List Nat := [2,4,8,1,15,14,8,11,512,11,513,513,9,513,0,2,513,513,10,1,526,0,1,3,9,14,512,512,512,513,11,0,10,15,526,512]

theorem envBound47326 : H12AffineFastState.Bounded env47326 := by
  intro p hp
  have h : env47326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47325_47326 : H12AffineEnvironment.transform 4 15 env47325 = env47326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env47325 == env47326) = true)

theorem identity47326 : scanCanonicalize (H12AffineFastState.compose env47326 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound47326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47327 : List Nat := [2,4,6,1,1,0,6,5,512,5,513,513,7,513,0,2,513,513,4,1,512,0,1,3,7,0,512,512,512,513,5,0,4,1,512,512]

theorem envBound47327 : H12AffineFastState.Bounded env47327 := by
  intro p hp
  have h : env47327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47326_47327 : H12AffineEnvironment.transform 2 6 env47326 = env47327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env47326 == env47327) = true)

theorem identity47327 : scanCanonicalize (H12AffineFastState.compose env47327 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47328 : List Nat := [2,4,6,1,1,0,6,5,0,5,1,1,7,1,0,2,1,1,4,1,0,0,1,3,7,0,0,0,0,1,5,0,4,1,0,0]

theorem envBound47328 : H12AffineFastState.Bounded env47328 := by
  intro p hp
  have h : env47328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47327_47328 : H12AffineEnvironment.transform 8 0 env47327 = env47328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47327 == env47328) = true)

def env47329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,140301,272392,180224,41311,8193,64,23809,185600,45405,262145,143641,400453,257,21792,46092,180752]

theorem envBound47329 : H12AffineFastState.Bounded env47329 := by
  intro p hp
  have h : env47329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47313_47329 : H12AffineEnvironment.transform 6 9 env47313 = env47329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47313 == env47329) = true)

theorem identity47329 : scanCanonicalize (H12AffineFastState.compose env47329 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound47329 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env47330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157801,1025,32769,140301,147553,180224,41311,8193,64,23809,185600,45405,157800,143641,29740,257,21792,46092,180752]

theorem envBound47330 : H12AffineFastState.Bounded env47330 := by
  intro p hp
  have h : env47330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47329_47330 : H12AffineEnvironment.transform 17 157801 env47329 = env47330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env47329 == env47330) = true)

theorem identity47330 : scanCanonicalize (H12AffineFastState.compose env47330 (packedSelected [0,3,4,5,12,14,15,16,18,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound47330 : packedSelected [0,3,4,5,12,14,15,16,18,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env47331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43128,1025,32769,58396,32880,17,41311,8193,64,23809,5393,45405,43129,61704,29740,257,21792,46092,513]

theorem envBound47331 : H12AffineFastState.Bounded env47331 := by
  intro p hp
  have h : env47331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47330_47331 : H12AffineEnvironment.transform 16 49169 env47330 = env47331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47330 == env47331) = true)

theorem identity47331 : scanCanonicalize (H12AffineFastState.compose env47331 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound47331 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21511,16449,10280,1025,81,25676,32,17,8463,8193,64,23809,5393,12557,10281,29016,29740,257,21792,13404,513]

theorem envBound47332 : H12AffineFastState.Bounded env47332 := by
  intro p hp
  have h : env47332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47331_47332 : H12AffineEnvironment.transform 14 80 env47331 = env47332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env47331 == env47332) = true)

theorem identity47332 : scanCanonicalize (H12AffineFastState.compose env47332 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47332 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env47333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,263,5441,10280,1025,81,12620,32,17,8463,8193,64,2049,5393,12557,10281,9304,8492,257,32,13404,513]

theorem envBound47333 : H12AffineFastState.Bounded env47333 := by
  intro p hp
  have h : env47333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47332_47333 : H12AffineEnvironment.transform 13 5376 env47332 = env47333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47332 == env47333) = true)

theorem identity47333 : scanCanonicalize (H12AffineFastState.compose env47333 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47333 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,80,263,5441,2421,1025,81,4113,32,17,82,348,64,2049,5393,4176,2420,1285,113,257,32,5377,513]

theorem envBound47334 : H12AffineFastState.Bounded env47334 := by
  intro p hp
  have h : env47334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47333_47334 : H12AffineEnvironment.transform 12 349 env47333 = env47334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47333 == env47334) = true)

theorem identity47334 : scanCanonicalize (H12AffineFastState.compose env47334 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound47334 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env47335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,349,2048,80,263,2113,2421,1025,81,3345,32,17,82,348,64,2049,2065,3408,2420,1285,113,257,32,2049,513]

theorem envBound47335 : H12AffineFastState.Bounded env47335 := by
  intro p hp
  have h : env47335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47334_47335 : H12AffineEnvironment.transform 11 3328 env47334 = env47335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env47334 == env47335) = true)

theorem identity47335 : scanCanonicalize (H12AffineFastState.compose env47335 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47335 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env47336 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,268,2048,1,263,2064,2340,1025,0,3345,32,17,3,269,17,2049,2065,3329,2341,1285,32,257,32,2049,513]

theorem envBound47336 : H12AffineFastState.Bounded env47336 := by
  intro p hp
  have h : env47336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47335_47336 : H12AffineEnvironment.transform 5 17 env47335 = env47336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47335 == env47336) = true)

theorem identity47336 : scanCanonicalize (H12AffineFastState.compose env47336 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47337 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1281,268,1,1,263,17,293,1025,0,1296,32,17,3,269,17,0,16,1280,292,1285,32,257,32,0,513]

theorem envBound47337 : H12AffineFastState.Bounded env47337 := by
  intro p hp
  have h : env47337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47336_47337 : H12AffineEnvironment.transform 10 1 env47336 = env47337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47336 == env47337) = true)

def env47338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound47338 : H12AffineFastState.Bounded env47338 := by
  intro p hp
  have h : env47338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46919_47338 : H12AffineEnvironment.transform 26 30393345 env46919 = env47338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env46919 == env47338) = true)

def env47339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound47339 : H12AffineFastState.Bounded env47339 := by
  intro p hp
  have h : env47339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47338_47339 : H12AffineEnvironment.transform 18 1024 env47338 = env47339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env47338 == env47339) = true)

theorem identity47339 : scanCanonicalize (H12AffineFastState.compose env47339 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound47339 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21455181,18973837,2159644,418125,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound47340 : H12AffineFastState.Bounded env47340 := by
  intro p hp
  have h : env47340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47339_47340 : H12AffineEnvironment.transform 22 41292 env47339 = env47340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env47339 == env47340) = true)

def env47341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21331969,18973837,2159644,294913,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound47341 : H12AffineFastState.Bounded env47341 := by
  intro p hp
  have h : env47341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47340_47341 : H12AffineEnvironment.transform 16 57676 env47340 = env47341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env47340 == env47341) = true)

def env47342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,16777216,8328,64,21080105,18973837,2159644,43049,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound47342 : H12AffineFastState.Bounded env47342 := by
  intro p hp
  have h : env47342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47341_47342 : H12AffineEnvironment.transform 17 10280 env47341 = env47342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47341 == env47342) = true)

def env47343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,16777216,8192,64,21080105,18973701,2159644,43049,16852317,23160136,256,18965864,18973765,16777731]

theorem envBound47343 : H12AffineFastState.Bounded env47343 := by
  intro p hp
  have h : env47343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47342_47343 : H12AffineEnvironment.transform 6 8 env47342 = env47343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47342 == env47343) = true)

theorem identity47343 : scanCanonicalize (H12AffineFastState.compose env47343 (packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound47343 : packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,73770,41292,16777216,8192,64,16812035,18973701,2159644,43049,16852317,18892130,256,18965864,18973765,16777731]

theorem envBound47344 : H12AffineFastState.Bounded env47344 := by
  intro p hp
  have h : env47344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47343_47344 : H12AffineEnvironment.transform 21 73770 env47343 = env47344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env47343 == env47344) = true)

theorem identity47344 : scanCanonicalize (H12AffineFastState.compose env47344 (packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2155882) := by decide +kernel

theorem selectedBound47344 : packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env47345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,73770,41292,2155882,8192,64,2125161,90479,2159644,43049,2211895,40968,256,98306,90415,2156393]

theorem envBound47345 : H12AffineFastState.Bounded env47345 := by
  intro p hp
  have h : env47345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47344_47345 : H12AffineEnvironment.transform 23 2155882 env47344 = env47345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155882 env47344 == env47345) = true)

theorem identity47345 : scanCanonicalize (H12AffineFastState.compose env47345 (packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound47345 : packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env47346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,58397,73770,41292,375,8192,64,35188,90479,4097,43049,74794,40968,256,98306,90415,884]

theorem envBound47346 : H12AffineFastState.Bounded env47346 := by
  intro p hp
  have h : env47346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47345_47346 : H12AffineEnvironment.transform 20 58397 env47345 = env47346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env47345 == env47346) = true)

theorem identity47346 : scanCanonicalize (H12AffineFastState.compose env47346 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound47346 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env47347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8575,57676,10280,1024,32769,58397,341,41292,375,8192,64,35188,16400,4097,43049,1365,40968,256,41341,16464,884]

theorem envBound47347 : H12AffineFastState.Bounded env47347 := by
  intro p hp
  have h : env47347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47346_47347 : H12AffineEnvironment.transform 15 8575 env47346 = env47347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env47346 == env47347) = true)

theorem identity47347 : scanCanonicalize (H12AffineFastState.compose env47347 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound47347 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env47348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,8575,38209,10280,1024,32769,36880,341,41292,375,8192,64,35188,13341,4097,43049,1365,40968,256,41341,13405,884]

theorem envBound47348 : H12AffineFastState.Bounded env47348 := by
  intro p hp
  have h : env47348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47347_47348 : H12AffineEnvironment.transform 13 13325 env47347 = env47348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env47347 == env47348) = true)

def env47349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,16777216,8193,64,21080105,18973700,2159644,43049,16852317,23160137,256,18965865,18973765,16777730]

theorem envBound47349 : H12AffineFastState.Bounded env47349 := by
  intro p hp
  have h : env47349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47342_47349 : H12AffineEnvironment.transform 6 9 env47342 = env47349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47342 == env47349) = true)

theorem identity47349 : scanCanonicalize (H12AffineFastState.compose env47349 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound47349 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,3,8193,64,4302890,2196487,2159644,43049,75102,6382922,256,2188650,2196550,513]

theorem envBound47350 : H12AffineFastState.Bounded env47350 := by
  intro p hp
  have h : env47350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47349_47350 : H12AffineEnvironment.transform 23 3 env47349 = env47350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env47349 == env47350) = true)

theorem identity47350 : scanCanonicalize (H12AffineFastState.compose env47350 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound47350 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env47351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,10280,1024,32769,2097152,4194304,41292,3,8193,64,4196384,2106381,2159644,43049,34132,6341952,256,2147680,2106444,513]

theorem envBound47351 : H12AffineFastState.Bounded env47351 := by
  intro p hp
  have h : env47351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47350_47351 : H12AffineEnvironment.transform 15 40970 env47350 = env47351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env47350 == env47351) = true)

theorem identity47351 : scanCanonicalize (H12AffineFastState.compose env47351 (packedSelected [1,2,5,6,8,11,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47351 : packedSelected [1,2,5,6,8,11,17,18,24] rootPS < 2^1333 := by decide +kernel

def env47352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,343,16401,10280,1024,8540,2097152,4194304,17,3,8193,64,4196384,2106381,2118977,2420,9225,6317085,256,2122813,2106444,513]

theorem envBound47352 : H12AffineFastState.Bounded env47352 := by
  intro p hp
  have h : env47352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47351_47352 : H12AffineEnvironment.transform 14 8541 env47351 = env47352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47351 == env47352) = true)

theorem identity47352 : scanCanonicalize (H12AffineFastState.compose env47352 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound47352 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,343,16401,10280,1024,8540,2097152,2114913,17,3,8193,64,2116929,2106381,2118977,2420,9225,8572,256,2122813,2106444,513]

theorem envBound47353 : H12AffineFastState.Bounded env47353 := by
  intro p hp
  have h : env47353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47352_47353 : H12AffineEnvironment.transform 21 2114913 env47352 = env47353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env47352 == env47353) = true)

theorem identity47353 : scanCanonicalize (H12AffineFastState.compose env47353 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound47353 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env47354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,343,16401,10280,1024,8540,17729,32,17,3,8193,64,2048,24908,4096,2420,9225,8572,256,8572,24845,513]

theorem envBound47354 : H12AffineFastState.Bounded env47354 := by
  intro p hp
  have h : env47354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47353_47354 : H12AffineEnvironment.transform 20 17729 env47353 = env47354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env47353 == env47354) = true)

def env47355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41292,16777216,8328,64,21080104,18973837,2159644,43048,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound47355 : H12AffineFastState.Bounded env47355 := by
  intro p hp
  have h : env47355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47341_47355 : H12AffineEnvironment.transform 17 10281 env47341 = env47355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47341 == env47355) = true)

end H12CloudChart0