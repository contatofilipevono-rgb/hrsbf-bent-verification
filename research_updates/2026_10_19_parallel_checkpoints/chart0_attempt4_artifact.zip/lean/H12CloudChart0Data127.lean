import H12CloudChart0Data126

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env32230 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8433,65536,24801,10401,1025,8432,4161,32,73755,95277,8328,64,97446,16400,91182,67755,94422,168,37,73771,90202,22053]

theorem envBound32230 : H12AffineFastState.Bounded env32230 := by
  intro p hp
  have h : env32230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32215_32230 : H12AffineEnvironment.transform 14 8433 env32215 = env32230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env32215 == env32230) = true)

theorem identity32230 : scanCanonicalize (H12AffineFastState.compose env32230 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound32230 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32231 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8433,8323,24801,10401,1025,8432,4161,32,152,21678,8328,64,23589,16400,17581,10280,20565,168,37,168,16601,22053]

theorem envBound32231 : H12AffineFastState.Bounded env32231 := by
  intro p hp
  have h : env32231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32230_32231 : H12AffineEnvironment.transform 15 8323 env32230 = env32231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env32230 == env32231) = true)

theorem identity32231 : scanCanonicalize (H12AffineFastState.compose env32231 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32231 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env32232 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,13404,8433,8323,5309,10401,1025,8432,4161,32,152,8434,8328,64,10361,13388,12529,10280,9225,168,37,168,13445,8825]

theorem envBound32232 : H12AffineFastState.Bounded env32232 := by
  intro p hp
  have h : env32232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32231_32232 : H12AffineEnvironment.transform 13 13404 env32231 = env32232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32231 == env32232) = true)

theorem identity32232 : scanCanonicalize (H12AffineFastState.compose env32232 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound32232 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32233 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,240,5292,1,115,5309,2129,1025,0,4161,32,152,2,120,64,2185,5308,4097,2264,1273,168,37,168,5237,649]

theorem envBound32233 : H12AffineFastState.Bounded env32233 := by
  intro p hp
  have h : env32233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32232_32233 : H12AffineEnvironment.transform 12 240 env32232 = env32233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env32232 == env32233) = true)

theorem identity32233 : scanCanonicalize (H12AffineFastState.compose env32233 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32233 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32234 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,160,5292,1,35,5309,2049,1025,0,4113,32,152,2,40,16,2185,5308,4097,2184,1193,168,37,168,5157,649]

theorem envBound32234 : H12AffineFastState.Bounded env32234 := by
  intro p hp
  have h : env32234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32233_32234 : H12AffineEnvironment.transform 5 16 env32233 = env32234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32233 == env32234) = true)

def env32235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound32235 : H12AffineFastState.Bounded env32235 := by
  intro p hp
  have h : env32235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31850_32235 : H12AffineEnvironment.transform 26 30393345 env31850 = env32235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env31850 == env32235) = true)

def env32236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound32236 : H12AffineFastState.Bounded env32236 := by
  intro p hp
  have h : env32236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32235_32236 : H12AffineEnvironment.transform 18 1024 env32235 = env32236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env32235 == env32236) = true)

theorem identity32236 : scanCanonicalize (H12AffineFastState.compose env32236 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound32236 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,16777216,8328,64,29868033,16835015,8466459,8830977,25265169,20971658,256,25207270,25182274,25207751]

theorem envBound32237 : H12AffineFastState.Bounded env32237 := by
  intro p hp
  have h : env32237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32236_32237 : H12AffineEnvironment.transform 20 91467 env32236 = env32237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env32236 == env32237) = true)

def env32238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120028,8328,64,12981469,79131,8466459,8830977,8409293,4314198,256,8484154,8492190,8484635]

theorem envBound32238 : H12AffineFastState.Bounded env32238 := by
  intro p hp
  have h : env32238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32237_32238 : H12AffineEnvironment.transform 23 120028 env32237 = env32238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120028 env32237 == env32238) = true)

def env32239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981469,79131,8466459,8820105,8389957,4293086,256,8462514,8492190,8462995]

theorem envBound32239 : H12AffineFastState.Bounded env32239 := by
  intro p hp
  have h : env32239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32238_32239 : H12AffineEnvironment.transform 13 5512 env32238 = env32239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env32238 == env32239) = true)

def env32240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787197,79131,8466459,8820105,8389957,98814,256,8462514,8492190,8462995]

theorem envBound32240 : H12AffineFastState.Bounded env32240 := by
  intro p hp
  have h : env32240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32239_32240 : H12AffineEnvironment.transform 21 32 env32239 = env32240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32239 == env32240) = true)

theorem identity32240 : scanCanonicalize (H12AffineFastState.compose env32240 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound32240 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,98766,98644,8328,64,496947,79131,45525,463943,99467,98814,256,41340,5456,41821]

theorem envBound32241 : H12AffineFastState.Bounded env32241 := by
  intro p hp
  have h : env32241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32240_32241 : H12AffineEnvironment.transform 22 98766 env32240 = env32241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env32240 == env32241) = true)

def env32242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10400,1024,32769,78019,32,98766,98644,8328,64,245139,79131,45525,212199,99467,98814,256,41340,5456,41821]

theorem envBound32242 : H12AffineFastState.Bounded env32242 := by
  intro p hp
  have h : env32242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32241_32242 : H12AffineEnvironment.transform 17 10400 env32241 = env32242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32241 == env32242) = true)

def env32243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,77899,32,98630,98644,8192,64,245019,79131,45405,212079,99331,98678,256,41340,5456,41821]

theorem envBound32243 : H12AffineFastState.Bounded env32243 := by
  intro p hp
  have h : env32243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32242_32243 : H12AffineEnvironment.transform 6 8 env32242 = env32243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32242 == env32243) = true)

theorem identity32243 : scanCanonicalize (H12AffineFastState.compose env32243 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound32243 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env32244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,10280,1024,32769,45340,32,17,3,8192,64,146508,46156,45405,179512,1364,33,256,41340,5456,41821]

theorem envBound32244 : H12AffineFastState.Bounded env32244 := by
  intro p hp
  have h : env32244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32243_32244 : H12AffineEnvironment.transform 15 33111 env32243 = env32244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env32243 == env32244) = true)

theorem identity32244 : scanCanonicalize (H12AffineFastState.compose env32244 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13372) := by decide +kernel

theorem selectedBound32244 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,13372,10280,1024,32769,45340,32,17,3,8192,64,2160,46156,45405,35076,1364,33,256,41340,5456,41821]

theorem envBound32245 : H12AffineFastState.Bounded env32245 := by
  intro p hp
  have h : env32245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32244_32245 : H12AffineEnvironment.transform 16 13372 env32244 = env32245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13372 env32244 == env32245) = true)

theorem identity32245 : scanCanonicalize (H12AffineFastState.compose env32245 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound32245 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env32246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,32768,33111,5441,2389,1024,32769,36961,32,17,3,381,64,2160,38193,36896,35076,1364,33,256,32769,5456,33312]

theorem envBound32246 : H12AffineFastState.Bounded env32246 := by
  intro p hp
  have h : env32246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32245_32246 : H12AffineEnvironment.transform 12 381 env32245 = env32246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env32245 == env32246) = true)

theorem identity32246 : scanCanonicalize (H12AffineFastState.compose env32246 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound32246 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env32247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,32,375,5441,2389,1024,33,4161,32,17,3,381,64,2160,5393,4096,2340,1364,33,256,33,5456,512]

theorem envBound32247 : H12AffineFastState.Bounded env32247 := by
  intro p hp
  have h : env32247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32246_32247 : H12AffineEnvironment.transform 14 32 env32246 = env32247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env32246 == env32247) = true)

def env32248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,77898,32,98631,98644,8193,64,245018,79131,45404,212078,99330,98679,256,41340,5456,41821]

theorem envBound32248 : H12AffineFastState.Bounded env32248 := by
  intro p hp
  have h : env32248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32242_32248 : H12AffineEnvironment.transform 6 9 env32242 = env32248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32242 == env32248) = true)

theorem identity32248 : scanCanonicalize (H12AffineFastState.compose env32248 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32248 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,32,73755,73736,8193,64,203846,79131,4096,212078,75102,73771,256,32,5456,513]

theorem envBound32249 : H12AffineFastState.Bounded env32249 := by
  intro p hp
  have h : env32249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32248_32249 : H12AffineEnvironment.transform 14 8540 env32248 = env32249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32248 == env32249) = true)

theorem identity32249 : scanCanonicalize (H12AffineFastState.compose env32249 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound32249 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,13673,10281,1024,8541,77898,32,73755,73736,8193,64,76079,79131,4096,67847,75102,73771,256,32,5456,513]

theorem envBound32250 : H12AffineFastState.Bounded env32250 := by
  intro p hp
  have h : env32250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32249_32250 : H12AffineEnvironment.transform 16 13673 env32249 = env32250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env32249 == env32250) = true)

theorem identity32250 : scanCanonicalize (H12AffineFastState.compose env32250 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound32250 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,9499,13673,10281,1024,8541,5457,32,1280,1299,8193,64,3124,4096,4096,11292,69,1328,256,32,5456,513]

theorem envBound32251 : H12AffineFastState.Bounded env32251 := by
  intro p hp
  have h : env32251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32250_32251 : H12AffineEnvironment.transform 15 9499 env32250 = env32251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env32250 == env32251) = true)

theorem identity32251 : scanCanonicalize (H12AffineFastState.compose env32251 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32251 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env32252 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8540,8202,12408,10281,273,8541,4160,32,17,2,8193,64,2341,4096,4096,10509,69,33,256,32,4161,513]

theorem envBound32252 : H12AffineFastState.Bounded env32252 := by
  intro p hp
  have h : env32252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32251_32252 : H12AffineEnvironment.transform 9 273 env32251 = env32252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32251 == env32252) = true)

theorem identity32252 : scanCanonicalize (H12AffineFastState.compose env32252 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32252 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32253 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,8192,4112,8232,8202,12408,10281,101,8233,4160,32,17,2,8193,64,2129,4096,4096,10361,69,33,116,32,4161,513]

theorem envBound32253 : H12AffineFastState.Bounded env32253 := by
  intro p hp
  have h : env32253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32252_32253 : H12AffineEnvironment.transform 7 116 env32252 = env32253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32252 == env32253) = true)

theorem identity32253 : scanCanonicalize (H12AffineFastState.compose env32253 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound32253 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32254 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,8192,2129,8232,8202,10297,10281,101,8233,2049,32,17,2,8193,64,2129,2113,2113,10361,69,33,116,32,2048,513]

theorem envBound32254 : H12AffineFastState.Bounded env32254 := by
  intro p hp
  have h : env32254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32253_32254 : H12AffineEnvironment.transform 11 2113 env32253 = env32254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env32253 == env32254) = true)

theorem identity32254 : scanCanonicalize (H12AffineFastState.compose env32254 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound32254 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32255 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,120,2129,80,114,2113,2129,101,81,2049,32,17,2,121,64,2129,2113,2113,2049,69,33,116,32,2048,513]

theorem envBound32255 : H12AffineFastState.Bounded env32255 := by
  intro p hp
  have h : env32255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32254_32255 : H12AffineEnvironment.transform 12 120 env32254 = env32255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env32254 == env32255) = true)

theorem identity32255 : scanCanonicalize (H12AffineFastState.compose env32255 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound32255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32256 : List Nat := [2,4,8,16,32,64,9,116,512,101,122,59,120,43,80,114,59,43,101,81,123,32,17,2,121,64,43,59,59,123,69,33,116,32,122,513]

theorem envBound32256 : H12AffineFastState.Bounded env32256 := by
  intro p hp
  have h : env32256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32255_32256 : H12AffineEnvironment.transform 10 122 env32255 = env32256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env32255 == env32256) = true)

theorem identity32256 : scanCanonicalize (H12AffineFastState.compose env32256 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound32256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32257 : List Nat := [2,4,8,16,32,58,9,14,512,31,0,59,2,43,42,8,59,43,31,43,1,32,17,2,3,58,43,59,59,1,63,33,14,32,0,513]

theorem envBound32257 : H12AffineFastState.Bounded env32257 := by
  intro p hp
  have h : env32257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32256_32257 : H12AffineEnvironment.transform 5 58 env32256 = env32257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env32256 == env32257) = true)

theorem identity32257 : scanCanonicalize (H12AffineFastState.compose env32257 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound32257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32258 : List Nat := [2,4,8,16,32,58,9,14,59,31,0,59,2,43,42,8,59,43,31,43,1,32,17,2,3,58,43,59,59,1,63,33,14,32,0,58]

theorem envBound32258 : H12AffineFastState.Bounded env32258 := by
  intro p hp
  have h : env32258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32257_32258 : H12AffineEnvironment.transform 8 59 env32257 = env32258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env32257 == env32258) = true)

theorem identity32258 : scanCanonicalize (H12AffineFastState.compose env32258 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32258 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32259 : List Nat := [2,4,8,16,11,17,9,14,16,31,0,16,2,0,1,8,16,0,31,0,1,11,17,2,3,17,0,16,16,1,20,10,14,11,0,17]

theorem envBound32259 : H12AffineFastState.Bounded env32259 := by
  intro p hp
  have h : env32259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32258_32259 : H12AffineEnvironment.transform 4 11 env32258 = env32259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32258 == env32259) = true)

def env32260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10401,1024,32769,78019,32,98766,98644,8328,64,245138,79131,45525,212198,99467,98814,256,41340,5456,41821]

theorem envBound32260 : H12AffineFastState.Bounded env32260 := by
  intro p hp
  have h : env32260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32241_32260 : H12AffineEnvironment.transform 17 10401 env32241 = env32260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32241 == env32260) = true)

theorem identity32260 : scanCanonicalize (H12AffineFastState.compose env32260 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound32260 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,103630,10401,1024,32769,78019,32,98766,98644,8328,64,10588,79131,45525,43048,99467,98814,256,41340,5456,41821]

theorem envBound32261 : H12AffineFastState.Bounded env32261 := by
  intro p hp
  have h : env32261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32260_32261 : H12AffineEnvironment.transform 16 103630 env32260 = env32261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env32260 == env32261) = true)

theorem identity32261 : scanCanonicalize (H12AffineFastState.compose env32261 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound32261 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env32262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,5392,10401,1024,32769,45341,32,16,138,8328,64,10588,46277,45525,43048,1365,32,256,41340,5456,41821]

theorem envBound32262 : H12AffineFastState.Bounded env32262 := by
  intro p hp
  have h : env32262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32261_32262 : H12AffineEnvironment.transform 15 33246 env32261 = env32262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env32261 == env32262) = true)

theorem identity32262 : scanCanonicalize (H12AffineFastState.compose env32262 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound32262 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,32768,33246,5392,2340,1024,32769,37016,32,16,138,269,64,2265,38208,36944,35245,1365,32,256,33017,5456,33496]

theorem envBound32263 : H12AffineFastState.Bounded env32263 := by
  intro p hp
  have h : env32263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32262_32263 : H12AffineEnvironment.transform 12 389 env32262 = env32263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env32262 == env32263) = true)

theorem identity32263 : scanCanonicalize (H12AffineFastState.compose env32263 (packedSelected [0,1,3,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32263 : packedSelected [0,1,3,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env32264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33110,5392,2340,1024,32769,36880,32,16,2,269,64,2129,38208,36944,35109,1365,32,256,32881,5456,33360]

theorem envBound32264 : H12AffineFastState.Bounded env32264 := by
  intro p hp
  have h : env32264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32263_32264 : H12AffineEnvironment.transform 6 8 env32263 = env32264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32263 == env32264) = true)

theorem identity32264 : scanCanonicalize (H12AffineFastState.compose env32264 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound32264 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1345,1047,5392,2340,1024,1344,5457,32,16,2,269,64,2129,4097,5393,3172,1365,32,256,1328,5456,1809]

theorem envBound32265 : H12AffineFastState.Bounded env32265 := by
  intro p hp
  have h : env32265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32264_32265 : H12AffineEnvironment.transform 14 1345 env32264 = env32265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env32264 == env32265) = true)

theorem identity32265 : scanCanonicalize (H12AffineFastState.compose env32265 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound32265 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env32266 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,269,5376,1328,1047,5392,2340,1024,1329,5408,32,16,2,269,49,2080,4097,5393,3093,1316,32,256,1328,5409,1809]

theorem envBound32266 : H12AffineFastState.Bounded env32266 := by
  intro p hp
  have h : env32266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32265_32266 : H12AffineEnvironment.transform 5 49 env32265 = env32266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env32265 == env32266) = true)

theorem identity32266 : scanCanonicalize (H12AffineFastState.compose env32266 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32266 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32267 : List Nat := [2,4,8,16,32,49,8,256,512,273,2048,4096,269,4113,33,262,4097,2340,273,32,4145,32,16,2,269,49,2080,4097,4096,2308,53,32,256,33,4144,512]

theorem envBound32267 : H12AffineFastState.Bounded env32267 := by
  intro p hp
  have h : env32267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32266_32267 : H12AffineEnvironment.transform 9 273 env32266 = env32267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32266 == env32267) = true)

theorem identity32267 : scanCanonicalize (H12AffineFastState.compose env32267 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32267 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32268 : List Nat := [2,4,8,16,32,49,8,37,512,52,2048,4096,40,4113,33,35,4097,2049,52,32,4145,32,16,2,40,49,2080,4097,4096,2081,53,32,37,33,4144,512]

theorem envBound32268 : H12AffineFastState.Bounded env32268 := by
  intro p hp
  have h : env32268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32267_32268 : H12AffineEnvironment.transform 7 37 env32267 = env32268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32267 == env32268) = true)

theorem identity32268 : scanCanonicalize (H12AffineFastState.compose env32268 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32268 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32269 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,4096,8,4113,1,3,4097,2049,20,0,4113,0,16,2,8,17,2048,4097,4096,2049,21,0,5,1,4112,512]

theorem envBound32269 : H12AffineFastState.Bounded env32269 := by
  intro p hp
  have h : env32269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32268_32269 : H12AffineEnvironment.transform 4 0 env32268 = env32269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32268 == env32269) = true)

theorem identity32269 : scanCanonicalize (H12AffineFastState.compose env32269 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32270 : List Nat := [2,4,8,16,0,17,8,5,0,20,2048,4096,8,4113,1,3,4097,2049,20,0,4113,0,16,2,8,17,2048,4097,4096,2049,21,0,5,1,4112,0]

theorem envBound32270 : H12AffineFastState.Bounded env32270 := by
  intro p hp
  have h : env32270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32269_32270 : H12AffineEnvironment.transform 8 0 env32269 = env32270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32269 == env32270) = true)

theorem identity32270 : scanCanonicalize (H12AffineFastState.compose env32270 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound32270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32271 : List Nat := [2,4,8,16,0,17,8,5,0,20,30,4096,8,4113,1,3,4097,31,20,0,4113,0,16,2,8,17,30,4097,4096,31,21,0,5,1,4112,0]

theorem envBound32271 : H12AffineFastState.Bounded env32271 := by
  intro p hp
  have h : env32271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32270_32271 : H12AffineEnvironment.transform 10 30 env32270 = env32271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env32270 == env32271) = true)

theorem identity32271 : scanCanonicalize (H12AffineFastState.compose env32271 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound32271 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32272 : List Nat := [2,4,8,16,0,17,8,5,0,20,30,15,8,30,1,3,14,31,20,0,30,0,16,2,8,17,30,14,15,31,21,0,5,1,31,0]

theorem envBound32272 : H12AffineFastState.Bounded env32272 := by
  intro p hp
  have h : env32272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32271_32272 : H12AffineEnvironment.transform 11 15 env32271 = env32272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env32271 == env32272) = true)

def leafEnv32272 : List Nat := [2,4,8,16,0,17,8,5,0,20,30,15,8,30,1,3,14,31,20,0,30,0,16,2,21,8,1,17,30,14,15,31,21,0,5,1,4,3,31,0,1,31,0]

def active32272 : List Nat := [0,1,2,3]

def tree32272 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32272 : H12WitnessSearch.Good tree32272 := H12GlobalWitnessIndex.good

theorem leafIdentity32272 : H12AffineFastState.composeSystem env32272 rootObs = leafEnv32272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32272 rootObs == leafEnv32272) = true)

theorem terminalChecked32272 : H12PackedTerminal.terminalCheckFast leafEnv32272 active32272 tree32272 = true := by decide +kernel

def env32273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787196,79131,8466459,8820105,8389957,98815,256,8462514,8492190,8462995]

theorem envBound32273 : H12AffineFastState.Bounded env32273 := by
  intro p hp
  have h : env32273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32239_32273 : H12AffineEnvironment.transform 21 33 env32239 = env32273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32239 == env32273) = true)

theorem identity32273 : scanCanonicalize (H12AffineFastState.compose env32273 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound32273 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,262144,1024,32769,45341,33,8388608,138,8328,64,8787196,46277,8434117,8820105,8389957,33,256,8429932,8394048,8430413]

theorem envBound32274 : H12AffineFastState.Bounded env32274 := by
  intro p hp
  have h : env32274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32273_32274 : H12AffineEnvironment.transform 15 33246 env32273 = env32274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env32273 == env32274) = true)

theorem identity32274 : scanCanonicalize (H12AffineFastState.compose env32274 (packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 297452) := by decide +kernel

theorem selectedBound32274 : packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env32275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,262144,1024,32769,45341,33,297452,138,8328,64,171280,46277,276521,138341,298153,33,256,272512,302252,273057]

theorem envBound32275 : H12AffineFastState.Bounded env32275 := by
  intro p hp
  have h : env32275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32274_32275 : H12AffineEnvironment.transform 22 297452 env32274 = env32275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297452 env32274 == env32275) = true)

def env32276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,10280,1024,32769,45341,33,41412,138,8328,64,171280,46277,4097,138341,42113,33,256,168,46212,649]

theorem envBound32276 : H12AffineFastState.Bounded env32276 := by
  intro p hp
  have h : env32276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32275_32276 : H12AffineEnvironment.transform 17 10280 env32275 = env32276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32275 == env32276) = true)

theorem identity32276 : scanCanonicalize (H12AffineFastState.compose env32276 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound32276 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env32277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,13461,10280,1024,32769,45341,33,41412,138,8328,64,43397,46277,4097,10480,42113,33,256,168,46212,649]

theorem envBound32277 : H12AffineFastState.Bounded env32277 := by
  intro p hp
  have h : env32277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32276_32277 : H12AffineEnvironment.transform 16 13461 env32276 = env32277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env32276 == env32277) = true)

theorem identity32277 : scanCanonicalize (H12AffineFastState.compose env32277 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32277 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env32278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,32768,33246,5528,2341,1024,32769,36880,33,32969,138,389,64,34952,38344,4097,2557,34188,33,256,168,38281,649]

theorem envBound32278 : H12AffineFastState.Bounded env32278 := by
  intro p hp
  have h : env32278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32277_32278 : H12AffineEnvironment.transform 12 269 env32277 = env32278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32277 == env32278) = true)

theorem identity32278 : scanCanonicalize (H12AffineFastState.compose env32278 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound32278 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env32279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,216,262,5528,2341,1024,217,4296,33,17,138,389,64,2128,5392,4097,2557,1364,33,256,168,5457,649]

theorem envBound32279 : H12AffineFastState.Bounded env32279 := by
  intro p hp
  have h : env32279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32278_32279 : H12AffineEnvironment.transform 14 216 env32278 = env32279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env32278 == env32279) = true)

theorem identity32279 : scanCanonicalize (H12AffineFastState.compose env32279 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32279 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env32280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,262,5392,2341,1024,81,4160,33,17,2,269,64,2128,5392,4097,2421,1364,33,256,32,5457,513]

theorem envBound32280 : H12AffineFastState.Bounded env32280 := by
  intro p hp
  have h : env32280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32279_32280 : H12AffineEnvironment.transform 6 8 env32279 = env32280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32279 == env32280) = true)

theorem identity32280 : scanCanonicalize (H12AffineFastState.compose env32280 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound32280 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,814,4096,269,5376,80,262,5392,523,1024,81,4160,33,17,2,269,64,894,5392,4097,603,1364,33,256,32,5457,513]

theorem envBound32281 : H12AffineFastState.Bounded env32281 := by
  intro p hp
  have h : env32281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32280_32281 : H12AffineEnvironment.transform 10 814 env32280 = env32281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env32280 == env32281) = true)

theorem identity32281 : scanCanonicalize (H12AffineFastState.compose env32281 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32281 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env32282 : List Nat := [2,4,8,16,32,64,8,36,512,1024,522,4096,41,5156,80,34,5172,523,1024,81,4160,33,17,2,41,64,602,5172,4097,603,1136,33,36,32,5237,513]

theorem envBound32282 : H12AffineFastState.Bounded env32282 := by
  intro p hp
  have h : env32282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32281_32282 : H12AffineEnvironment.transform 7 36 env32281 = env32282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32281 == env32282) = true)

theorem identity32282 : scanCanonicalize (H12AffineFastState.compose env32282 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32282 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32283 : List Nat := [2,4,8,16,32,17,8,36,512,1024,522,4096,41,5156,1,34,5172,523,1024,0,4113,33,17,2,41,17,523,5172,4097,522,1057,33,36,32,5156,513]

theorem envBound32283 : H12AffineFastState.Bounded env32283 := by
  intro p hp
  have h : env32283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32282_32283 : H12AffineEnvironment.transform 5 17 env32282 = env32283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32282 == env32283) = true)

theorem identity32283 : scanCanonicalize (H12AffineFastState.compose env32283 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32284 : List Nat := [2,4,8,16,32,17,8,36,512,52,522,4096,41,4112,1,34,4096,523,52,0,4113,33,17,2,41,17,523,4096,4097,522,21,33,36,32,4112,513]

theorem envBound32284 : H12AffineFastState.Bounded env32284 := by
  intro p hp
  have h : env32284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32283_32284 : H12AffineEnvironment.transform 9 52 env32283 = env32284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32283 == env32284) = true)

theorem identity32284 : scanCanonicalize (H12AffineFastState.compose env32284 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound32284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32285 : List Nat := [2,4,8,16,32,17,8,36,512,52,522,543,41,527,1,34,543,523,52,0,526,33,17,2,41,17,523,543,542,522,21,33,36,32,527,513]

theorem envBound32285 : H12AffineFastState.Bounded env32285 := by
  intro p hp
  have h : env32285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32284_32285 : H12AffineEnvironment.transform 11 543 env32284 = env32285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env32284 == env32285) = true)

theorem identity32285 : scanCanonicalize (H12AffineFastState.compose env32285 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound32285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32286 : List Nat := [2,4,8,16,32,17,8,36,7,52,13,24,41,8,1,34,24,12,52,0,9,33,17,2,41,17,12,24,25,13,21,33,36,32,8,6]

theorem envBound32286 : H12AffineFastState.Bounded env32286 := by
  intro p hp
  have h : env32286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32285_32286 : H12AffineEnvironment.transform 8 7 env32285 = env32286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env32285 == env32286) = true)

theorem identity32286 : scanCanonicalize (H12AffineFastState.compose env32286 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound32286 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32287 : List Nat := [2,4,8,16,5,17,8,1,7,17,13,24,12,8,1,7,24,12,17,0,9,4,17,2,12,17,12,24,25,13,21,4,1,5,8,6]

theorem envBound32287 : H12AffineFastState.Bounded env32287 := by
  intro p hp
  have h : env32287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32286_32287 : H12AffineEnvironment.transform 4 5 env32286 = env32287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env32286 == env32287) = true)

def env32288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,10281,1024,32769,45341,33,41413,138,8328,64,171280,46277,4096,138341,42112,33,256,169,46213,648]

theorem envBound32288 : H12AffineFastState.Bounded env32288 := by
  intro p hp
  have h : env32288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32275_32288 : H12AffineEnvironment.transform 17 10281 env32275 = env32288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32275 == env32288) = true)

theorem identity32288 : scanCanonicalize (H12AffineFastState.compose env32288 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound32288 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env32289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2049,32768,33246,131072,10281,1024,32769,44180,33,41413,138,8328,64,163993,43340,3465,131564,42112,33,256,169,43276,648]

theorem envBound32289 : H12AffineFastState.Bounded env32289 := by
  intro p hp
  have h : env32289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32288_32289 : H12AffineEnvironment.transform 11 3465 env32288 = env32289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env32288 == env32289) = true)

theorem identity32289 : scanCanonicalize (H12AffineFastState.compose env32289 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound32289 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2049,8661,8203,131072,10281,1024,8660,3393,33,16,138,8328,64,139596,2201,3465,131564,1365,33,256,169,2265,648]

theorem envBound32290 : H12AffineFastState.Bounded env32290 := by
  intro p hp
  have h : env32290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32289_32290 : H12AffineEnvironment.transform 14 8661 env32289 = env32290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env32289 == env32290) = true)

theorem identity32290 : scanCanonicalize (H12AffineFastState.compose env32290 (packedSelected [1,2,4,8,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound32290 : packedSelected [1,2,4,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env32291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,1221,2049,1296,1230,131072,3308,1024,1297,3393,33,16,138,1101,64,132489,2201,3465,131564,1365,33,256,169,2265,648]

theorem envBound32291 : H12AffineFastState.Bounded env32291 := by
  intro p hp
  have h : env32291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32290_32291 : H12AffineEnvironment.transform 12 1221 env32290 = env32291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env32290 == env32291) = true)

theorem identity32291 : scanCanonicalize (H12AffineFastState.compose env32291 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32291 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env32292 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2200,468,2049,1,479,131072,2557,273,0,2128,33,16,138,348,64,131224,2201,2200,131564,68,33,256,169,2265,648]

theorem envBound32292 : H12AffineFastState.Bounded env32292 := by
  intro p hp
  have h : env32292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32291_32292 : H12AffineEnvironment.transform 9 273 env32291 = env32292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32291 == env32292) = true)

theorem identity32292 : scanCanonicalize (H12AffineFastState.compose env32292 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32292 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32293 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2200,120,2049,1,115,131072,2129,189,0,2128,33,16,138,240,64,131224,2201,2200,131136,68,33,172,169,2265,648]

theorem envBound32293 : H12AffineFastState.Bounded env32293 := by
  intro p hp
  have h : env32293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32292_32293 : H12AffineEnvironment.transform 7 172 env32292 = env32293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32292 == env32293) = true)

theorem identity32293 : scanCanonicalize (H12AffineFastState.compose env32293 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 2201) := by decide +kernel

theorem selectedBound32293 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env32294 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2200,120,2049,1,115,2201,2129,189,0,2128,33,16,138,240,64,2049,2201,2200,2265,68,33,172,169,2265,648]

theorem envBound32294 : H12AffineFastState.Bounded env32294 := by
  intro p hp
  have h : env32294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32293_32294 : H12AffineEnvironment.transform 16 2201 env32293 = env32294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2201 env32293 == env32294) = true)

theorem identity32294 : scanCanonicalize (H12AffineFastState.compose env32294 (packedSelected [5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32294 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env32295 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2065,120,2049,1,115,2064,2129,52,0,2128,33,16,3,121,64,2049,2064,2065,2128,68,33,37,32,2128,513]

theorem envBound32295 : H12AffineFastState.Bounded env32295 := by
  intro p hp
  have h : env32295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32294_32295 : H12AffineEnvironment.transform 6 9 env32294 = env32295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32294 == env32295) = true)

theorem identity32295 : scanCanonicalize (H12AffineFastState.compose env32295 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32295 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32296 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,2049,1,34,2064,2048,52,0,2049,33,16,3,40,17,2049,2064,2065,2049,21,33,37,32,2049,513]

theorem envBound32296 : H12AffineFastState.Bounded env32296 := by
  intro p hp
  have h : env32296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32295_32296 : H12AffineEnvironment.transform 5 17 env32295 = env32296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32295 == env32296) = true)

def env32297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981469,79131,8466459,8820104,8389956,4293087,256,8462515,8492190,8462994]

theorem envBound32297 : H12AffineFastState.Bounded env32297 := by
  intro p hp
  have h : env32297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32238_32297 : H12AffineEnvironment.transform 13 5513 env32238 = env32297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32238 == env32297) = true)

def env32298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787197,79131,8466459,8820104,8389956,98815,256,8462515,8492190,8462994]

theorem envBound32298 : H12AffineFastState.Bounded env32298 := by
  intro p hp
  have h : env32298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32297_32298 : H12AffineEnvironment.transform 21 32 env32297 = env32298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32297 == env32298) = true)

theorem identity32298 : scanCanonicalize (H12AffineFastState.compose env32298 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound32298 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,73755,98645,8328,64,472294,79131,4096,505235,75103,98815,256,168,46213,649]

theorem envBound32299 : H12AffineFastState.Bounded env32299 := by
  intro p hp
  have h : env32299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32298_32299 : H12AffineEnvironment.transform 22 73755 env32298 = env32299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env32298 == env32299) = true)

theorem identity32299 : scanCanonicalize (H12AffineFastState.compose env32299 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32299 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env32300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472174,79131,4096,505115,75103,98679,256,32,46093,513]

theorem envBound32300 : H12AffineFastState.Bounded env32300 := by
  intro p hp
  have h : env32300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32299_32300 : H12AffineEnvironment.transform 6 8 env32299 = env32300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32299 == env32300) = true)

theorem identity32300 : scanCanonicalize (H12AffineFastState.compose env32300 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32300 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,32,73755,73737,8192,64,472174,79131,4096,463943,75103,73771,256,32,5457,513]

theorem envBound32301 : H12AffineFastState.Bounded env32301 := by
  intro p hp
  have h : env32301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32300_32301 : H12AffineEnvironment.transform 14 8540 env32300 = env32301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32300 == env32301) = true)

theorem identity32301 : scanCanonicalize (H12AffineFastState.compose env32301 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32301 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4161,32,16,2,8192,64,398437,5392,4096,406604,1364,32,256,32,5457,513]

theorem envBound32302 : H12AffineFastState.Bounded env32302 := by
  intro p hp
  have h : env32302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32301_32302 : H12AffineEnvironment.transform 15 8203 env32301 = env32302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32301 == env32302) = true)

theorem identity32302 : scanCanonicalize (H12AffineFastState.compose env32302 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10360,1024,8541,4161,32,16,2,8192,64,146461,5392,4096,138292,1364,32,256,32,5457,513]

theorem envBound32303 : H12AffineFastState.Bounded env32303 := by
  intro p hp
  have h : env32303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32302_32303 : H12AffineEnvironment.transform 17 10360 env32302 = env32303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32302 == env32303) = true)

def env32304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787196,79131,8466459,8820104,8389956,98814,256,8462515,8492190,8462994]

theorem envBound32304 : H12AffineFastState.Bounded env32304 := by
  intro p hp
  have h : env32304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32297_32304 : H12AffineEnvironment.transform 21 33 env32297 = env32304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32297 == env32304) = true)

theorem identity32304 : scanCanonicalize (H12AffineFastState.compose env32304 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32304 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,262144,1024,32769,4297,33,8388608,41310,8328,64,8787196,5392,8392720,8820104,8389956,41461,256,8388792,8434837,8389273]

theorem envBound32305 : H12AffineFastState.Bounded env32305 := by
  intro p hp
  have h : env32305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32304_32305 : H12AffineEnvironment.transform 15 8203 env32304 = env32305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32304 == env32305) = true)

def env32306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,8388608,41310,8192,64,8787060,5392,8392720,8819968,8389956,41341,256,8388656,8434717,8389137]

theorem envBound32306 : H12AffineFastState.Bounded env32306 := by
  intro p hp
  have h : env32306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32305_32306 : H12AffineEnvironment.transform 6 8 env32305 = env32306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32305 == env32306) = true)

theorem identity32306 : scanCanonicalize (H12AffineFastState.compose env32306 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297268) := by decide +kernel

theorem selectedBound32306 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,297268,41310,8192,64,171328,5392,301348,138292,298096,41341,256,297220,277801,297765]

theorem envBound32307 : H12AffineFastState.Bounded env32307 := by
  intro p hp
  have h : env32307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32306_32307 : H12AffineEnvironment.transform 22 297268 env32306 = env32307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297268 env32306 == env32307) = true)

theorem identity32307 : scanCanonicalize (H12AffineFastState.compose env32307 (packedSelected [0,1,5,7,9,10,12,14,15,16,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32307 : packedSelected [0,1,5,7,9,10,12,14,15,16,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10360,1024,32769,4161,33,41292,41310,8192,64,171328,5392,45404,138292,41992,41341,256,41340,5457,41821]

theorem envBound32308 : H12AffineFastState.Bounded env32308 := by
  intro p hp
  have h : env32308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32307_32308 : H12AffineEnvironment.transform 17 10360 env32307 = env32308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32307 == env32308) = true)

theorem identity32308 : scanCanonicalize (H12AffineFastState.compose env32308 (packedSelected [0,5,7,9,12,14,15,16,18,19,21,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound32308 : packedSelected [0,5,7,9,12,14,15,16,18,19,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env32309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,10360,1024,8461,4161,33,64,82,8192,64,146508,5392,4176,138292,1284,113,256,112,5457,593]

theorem envBound32309 : H12AffineFastState.Bounded env32309 := by
  intro p hp
  have h : env32309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32308_32309 : H12AffineEnvironment.transform 14 8460 env32308 = env32309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env32308 == env32309) = true)

theorem identity32309 : scanCanonicalize (H12AffineFastState.compose env32309 (packedSelected [1,2,4,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32309 : packedSelected [1,2,4,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env32310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,343,131072,2340,1024,81,4161,33,64,82,348,64,138512,5392,4176,138292,1284,113,256,112,5457,593]

theorem envBound32310 : H12AffineFastState.Bounded env32310 := by
  intro p hp
  have h : env32310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32309_32310 : H12AffineEnvironment.transform 12 348 env32309 = env32310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32309 == env32310) = true)

theorem identity32310 : scanCanonicalize (H12AffineFastState.compose env32310 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound32310 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env32311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,343,5440,2340,1024,81,4161,33,64,82,348,64,2128,5392,4176,2420,1284,113,256,112,5457,593]

theorem envBound32311 : H12AffineFastState.Bounded env32311 := by
  intro p hp
  have h : env32311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32310_32311 : H12AffineEnvironment.transform 16 5440 env32310 = env32311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env32310 == env32311) = true)

theorem identity32311 : scanCanonicalize (H12AffineFastState.compose env32311 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32311 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env32312 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5392,2340,1024,1,4113,33,16,2,268,16,2048,5392,4096,2340,1284,33,256,32,5377,513]

theorem envBound32312 : H12AffineFastState.Bounded env32312 := by
  intro p hp
  have h : env32312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32311_32312 : H12AffineEnvironment.transform 5 16 env32311 = env32312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32311 == env32312) = true)

theorem identity32312 : scanCanonicalize (H12AffineFastState.compose env32312 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32313 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4113,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound32313 : H12AffineFastState.Bounded env32313 := by
  intro p hp
  have h : env32313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32312_32313 : H12AffineEnvironment.transform 7 36 env32312 = env32313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32312 == env32313) = true)

def env32314 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,0,35,1028,2048,1024,1,33,33,16,2,40,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound32314 : H12AffineFastState.Bounded env32314 := by
  intro p hp
  have h : env32314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32313_32314 : H12AffineEnvironment.transform 11 48 env32313 = env32314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32313 == env32314) = true)

theorem identity32314 : scanCanonicalize (H12AffineFastState.compose env32314 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound32314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32315 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,48,40,1045,0,35,1028,1076,1024,1,33,33,16,2,40,16,1076,1028,48,1076,1056,33,36,32,1045,513]

theorem envBound32315 : H12AffineFastState.Bounded env32315 := by
  intro p hp
  have h : env32315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32314_32315 : H12AffineEnvironment.transform 10 1076 env32314 = env32315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env32314 == env32315) = true)

def env32316 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,40,33,0,35,48,0,52,1,33,33,16,2,40,16,0,48,48,0,20,33,36,32,33,513]

theorem envBound32316 : H12AffineFastState.Bounded env32316 := by
  intro p hp
  have h : env32316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32315_32316 : H12AffineEnvironment.transform 9 52 env32315 = env32316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32315 == env32316) = true)

def env32317 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,40,32,0,35,49,1,53,1,33,33,16,2,40,16,1,49,48,1,21,33,36,32,32,513]

theorem envBound32317 : H12AffineFastState.Bounded env32317 := by
  intro p hp
  have h : env32317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32315_32317 : H12AffineEnvironment.transform 9 53 env32315 = env32317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32315 == env32317) = true)

theorem identity32317 : scanCanonicalize (H12AffineFastState.compose env32317 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32318 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,48,40,32,0,35,49,1,53,1,33,33,16,2,40,16,1,49,48,1,21,33,36,32,32,43]

theorem envBound32318 : H12AffineFastState.Bounded env32318 := by
  intro p hp
  have h : env32318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32317_32318 : H12AffineEnvironment.transform 8 42 env32317 = env32318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32317 == env32318) = true)

def leafEnv32318 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,48,40,32,0,35,49,1,53,1,33,33,16,2,21,40,1,16,1,49,48,1,21,33,36,32,4,35,32,43,1,33,0]

def active32318 : List Nat := [0,1,2,3,4]

def tree32318 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32318 : H12WitnessSearch.Good tree32318 := H12GlobalWitnessIndex.good

theorem leafIdentity32318 : H12AffineFastState.composeSystem env32318 rootObs = leafEnv32318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32318 rootObs == leafEnv32318) = true)

theorem terminalChecked32318 : H12PackedTerminal.terminalCheckFast leafEnv32318 active32318 tree32318 = true := by decide +kernel

def env32319 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,0,35,1029,2048,1024,1,32,33,16,2,40,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound32319 : H12AffineFastState.Bounded env32319 := by
  intro p hp
  have h : env32319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32313_32319 : H12AffineEnvironment.transform 11 49 env32313 = env32319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32313 == env32319) = true)

theorem identity32319 : scanCanonicalize (H12AffineFastState.compose env32319 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32320 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,49,40,1044,0,35,1029,1,1024,1,32,33,16,2,40,16,1,1029,49,1,1056,33,36,32,1044,513]

theorem envBound32320 : H12AffineFastState.Bounded env32320 := by
  intro p hp
  have h : env32320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32319_32320 : H12AffineEnvironment.transform 10 1 env32319 = env32320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32319 == env32320) = true)

def env32321 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,40,32,0,35,49,1,52,1,32,33,16,2,40,16,1,49,49,1,20,33,36,32,32,513]

theorem envBound32321 : H12AffineFastState.Bounded env32321 := by
  intro p hp
  have h : env32321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32320_32321 : H12AffineEnvironment.transform 9 52 env32320 = env32321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32320 == env32321) = true)

def env32322 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,0,35,48,1,53,1,32,33,16,2,40,16,1,48,49,1,21,33,36,32,33,513]

theorem envBound32322 : H12AffineFastState.Bounded env32322 := by
  intro p hp
  have h : env32322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32320_32322 : H12AffineEnvironment.transform 9 53 env32320 = env32322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32320 == env32322) = true)

theorem identity32322 : scanCanonicalize (H12AffineFastState.compose env32322 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32323 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,49,40,33,0,35,48,1,53,1,32,33,16,2,40,16,1,48,49,1,21,33,36,32,33,43]

theorem envBound32323 : H12AffineFastState.Bounded env32323 := by
  intro p hp
  have h : env32323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32322_32323 : H12AffineEnvironment.transform 8 42 env32322 = env32323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32322 == env32323) = true)

def leafEnv32323 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,49,40,33,0,35,48,1,53,1,32,33,16,2,21,40,1,16,1,48,49,1,21,33,36,32,4,35,33,43,1,32,0]

def active32323 : List Nat := [0,1,2,3,4]

def tree32323 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32323 : H12WitnessSearch.Good tree32323 := H12GlobalWitnessIndex.good

theorem leafIdentity32323 : H12AffineFastState.composeSystem env32323 rootObs = leafEnv32323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32323 rootObs == leafEnv32323) = true)

theorem terminalChecked32323 : H12PackedTerminal.terminalCheckFast leafEnv32323 active32323 tree32323 = true := by decide +kernel

def env32324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,8388608,41310,8193,64,8787061,5392,8392720,8819969,8389956,41340,256,8388657,8434716,8389136]

theorem envBound32324 : H12AffineFastState.Bounded env32324 := by
  intro p hp
  have h : env32324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32305_32324 : H12AffineEnvironment.transform 6 9 env32305 = env32324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32305 == env32324) = true)

theorem identity32324 : scanCanonicalize (H12AffineFastState.compose env32324 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound32324 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,262144,1024,32769,4160,33,8388608,41310,8193,64,8651061,5392,8392720,8683585,8389956,41340,256,8388657,8434716,8389136]

theorem envBound32325 : H12AffineFastState.Bounded env32325 := by
  intro p hp
  have h : env32325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32324_32325 : H12AffineEnvironment.transform 16 5440 env32324 = env32325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env32324 == env32325) = true)

theorem identity32325 : scanCanonicalize (H12AffineFastState.compose env32325 (packedSelected [0,9,18,19,22,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound32325 : packedSelected [0,9,18,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,2340,1024,32769,4160,33,8388608,41310,8193,64,8390673,5392,8392720,8423781,8389956,41340,256,8388657,8434716,8389136]

theorem envBound32326 : H12AffineFastState.Bounded env32326 := by
  intro p hp
  have h : env32326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32325_32326 : H12AffineEnvironment.transform 17 2340 env32325 = env32326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env32325 == env32326) = true)

theorem identity32326 : scanCanonicalize (H12AffineFastState.compose env32326 (packedSelected [0,1,7,8,9,12,14,15,19,20,21,22] rootPS)) = affineNative (2^(22+1) ^^^ 33124) := by decide +kernel

theorem selectedBound32326 : packedSelected [0,1,7,8,9,12,14,15,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env32327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,2340,1024,32769,4160,33,33124,41310,8193,64,35189,5392,37236,2049,33824,41340,256,33109,13688,33652]

theorem envBound32327 : H12AffineFastState.Bounded env32327 := by
  intro p hp
  have h : env32327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32326_32327 : H12AffineEnvironment.transform 22 33124 env32326 = env32327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 33124 env32326 == env32327) = true)

theorem identity32327 : scanCanonicalize (H12AffineFastState.compose env32327 (packedSelected [0,2,6,7,11,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32327 : packedSelected [0,2,6,7,11,16,23] rootPS < 2^1333 := by decide +kernel

def env32328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,262,5440,2340,1024,32769,4160,33,33124,32851,268,64,35189,5392,37236,2049,33824,32881,256,33109,5237,33652]

theorem envBound32328 : H12AffineFastState.Bounded env32328 := by
  intro p hp
  have h : env32328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32327_32328 : H12AffineEnvironment.transform 12 269 env32327 = env32328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32327 == env32328) = true)

theorem identity32328 : scanCanonicalize (H12AffineFastState.compose env32328 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound32328 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,292,262,5440,2340,1024,293,4160,33,64,375,268,64,2129,5392,4176,2049,1284,341,256,113,5237,592]

theorem envBound32329 : H12AffineFastState.Bounded env32329 := by
  intro p hp
  have h : env32329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32328_32329 : H12AffineEnvironment.transform 14 292 env32328 = env32329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env32328 == env32329) = true)

theorem identity32329 : scanCanonicalize (H12AffineFastState.compose env32329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32330 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,269,4160,292,262,4096,2340,320,293,4160,33,64,375,268,64,2129,4176,4176,2049,68,341,256,113,4405,592]

theorem envBound32330 : H12AffineFastState.Bounded env32330 := by
  intro p hp
  have h : env32330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32329_32330 : H12AffineEnvironment.transform 9 320 env32329 = env32330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32329 == env32330) = true)

theorem identity32330 : scanCanonicalize (H12AffineFastState.compose env32330 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound32330 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env32331 : List Nat := [2,4,8,16,32,64,9,256,512,320,372,4096,269,4160,292,262,4096,80,320,293,4160,33,64,375,268,64,293,4176,4176,373,68,341,256,113,4405,592]

theorem envBound32331 : H12AffineFastState.Bounded env32331 := by
  intro p hp
  have h : env32331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32330_32331 : H12AffineEnvironment.transform 10 372 env32330 = env32331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env32330 == env32331) = true)

theorem identity32331 : scanCanonicalize (H12AffineFastState.compose env32331 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32331 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32332 : List Nat := [2,4,8,16,32,16,9,256,512,272,292,4096,269,4112,292,262,4096,0,272,293,4112,33,16,295,268,16,293,4096,4096,293,20,261,256,33,4405,512]

theorem envBound32332 : H12AffineFastState.Bounded env32332 := by
  intro p hp
  have h : env32332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32331_32332 : H12AffineEnvironment.transform 5 16 env32331 = env32332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32331 == env32332) = true)

theorem identity32332 : scanCanonicalize (H12AffineFastState.compose env32332 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32333 : List Nat := [2,4,8,16,32,16,9,4,512,20,32,4096,9,4112,32,2,4096,0,20,33,4112,33,16,35,8,16,33,4096,4096,33,20,1,4,33,4145,512]

theorem envBound32333 : H12AffineFastState.Bounded env32333 := by
  intro p hp
  have h : env32333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32332_32333 : H12AffineEnvironment.transform 7 4 env32332 = env32333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32332 == env32333) = true)

theorem identity32333 : scanCanonicalize (H12AffineFastState.compose env32333 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound32333 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32334 : List Nat := [2,4,8,16,32,16,9,4,20,20,32,4096,9,4112,32,2,4096,0,20,33,4112,33,16,35,8,16,33,4096,4096,33,20,1,4,33,4145,20]

theorem envBound32334 : H12AffineFastState.Bounded env32334 := by
  intro p hp
  have h : env32334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32333_32334 : H12AffineEnvironment.transform 8 20 env32333 = env32334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env32333 == env32334) = true)

theorem identity32334 : scanCanonicalize (H12AffineFastState.compose env32334 (packedSelected [1,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound32334 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env32335 : List Nat := [2,4,8,16,32,16,9,4,20,20,32,48,9,32,32,2,48,0,20,33,32,33,16,35,8,16,33,48,48,33,20,1,4,33,1,20]

theorem envBound32335 : H12AffineFastState.Bounded env32335 := by
  intro p hp
  have h : env32335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32334_32335 : H12AffineEnvironment.transform 11 48 env32334 = env32335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32334 == env32335) = true)

theorem identity32335 : scanCanonicalize (H12AffineFastState.compose env32335 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32335 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32336 : List Nat := [2,4,8,16,0,16,9,4,20,20,0,16,9,0,0,2,16,0,20,1,0,1,16,3,8,16,1,16,16,1,20,1,4,1,1,20]

theorem envBound32336 : H12AffineFastState.Bounded env32336 := by
  intro p hp
  have h : env32336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32335_32336 : H12AffineEnvironment.transform 4 0 env32335 = env32336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32335 == env32336) = true)

def env32337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120029,8328,64,12981468,79130,8466459,8830977,8409292,4314199,256,8484155,8492191,8484634]

theorem envBound32337 : H12AffineFastState.Bounded env32337 := by
  intro p hp
  have h : env32337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32237_32337 : H12AffineEnvironment.transform 23 120029 env32237 = env32337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120029 env32237 == env32337) = true)

def env32338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981468,79130,8466459,8820105,8389956,4293087,256,8462515,8492191,8462994]

theorem envBound32338 : H12AffineFastState.Bounded env32338 := by
  intro p hp
  have h : env32338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32337_32338 : H12AffineEnvironment.transform 13 5512 env32337 = env32338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env32337 == env32338) = true)

def env32339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787196,79130,8466459,8820105,8389956,98815,256,8462515,8492191,8462994]

theorem envBound32339 : H12AffineFastState.Bounded env32339 := by
  intro p hp
  have h : env32339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32338_32339 : H12AffineEnvironment.transform 21 32 env32338 = env32339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32338 == env32339) = true)

theorem identity32339 : scanCanonicalize (H12AffineFastState.compose env32339 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32339 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,8388608,98645,8192,64,8787060,79130,8466459,8819969,8389956,98679,256,8462395,8492055,8462874]

theorem envBound32340 : H12AffineFastState.Bounded env32340 := by
  intro p hp
  have h : env32340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32339_32340 : H12AffineEnvironment.transform 6 8 env32339 = env32340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32339 == env32340) = true)

def env32341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,16,98645,8192,64,398436,79130,77835,431377,1364,98679,256,73771,103431,74250]

theorem envBound32341 : H12AffineFastState.Bounded env32341 := by
  intro p hp
  have h : env32341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32340_32341 : H12AffineEnvironment.transform 22 16 env32340 = env32341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env32340 == env32341) = true)

theorem identity32341 : scanCanonicalize (H12AffineFastState.compose env32341 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32341 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41310,8192,64,398436,5393,4096,431377,1364,41340,256,32,46092,513]

theorem envBound32342 : H12AffineFastState.Bounded env32342 := by
  intro p hp
  have h : env32342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32341_32342 : H12AffineEnvironment.transform 15 8203 env32341 = env32342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32341 == env32342) = true)

theorem identity32342 : scanCanonicalize (H12AffineFastState.compose env32342 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32342 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,32,16,2,8192,64,398436,5393,4096,406605,1364,32,256,32,5456,513]

theorem envBound32343 : H12AffineFastState.Bounded env32343 := by
  intro p hp
  have h : env32343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32342_32343 : H12AffineEnvironment.transform 14 8540 env32342 = env32343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32342 == env32343) = true)

theorem identity32343 : scanCanonicalize (H12AffineFastState.compose env32343 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32343 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10360,1024,8541,4160,32,16,2,8192,64,146460,5393,4096,138293,1364,32,256,32,5456,513]

theorem envBound32344 : H12AffineFastState.Bounded env32344 := by
  intro p hp
  have h : env32344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32343_32344 : H12AffineEnvironment.transform 17 10360 env32343 = env32344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32343 == env32344) = true)

def env32345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,17,98645,8192,64,398437,79130,77834,431376,1365,98679,256,73770,103430,74251]

theorem envBound32345 : H12AffineFastState.Bounded env32345 := by
  intro p hp
  have h : env32345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32340_32345 : H12AffineEnvironment.transform 22 17 env32340 = env32345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env32340 == env32345) = true)

theorem identity32345 : scanCanonicalize (H12AffineFastState.compose env32345 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32345 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,77899,32,17,98645,8192,64,146509,79130,77834,179512,1365,98679,256,73770,103430,74251]

theorem envBound32346 : H12AffineFastState.Bounded env32346 := by
  intro p hp
  have h : env32346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32345_32346 : H12AffineEnvironment.transform 17 10280 env32345 = env32346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32345 == env32346) = true)

def env32347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787197,79130,8466459,8820105,8389956,98814,256,8462515,8492191,8462994]

theorem envBound32347 : H12AffineFastState.Bounded env32347 := by
  intro p hp
  have h : env32347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32338_32347 : H12AffineEnvironment.transform 21 33 env32338 = env32347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32338 == env32347) = true)

theorem identity32347 : scanCanonicalize (H12AffineFastState.compose env32347 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound32347 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,152,98645,8328,64,398437,79130,77955,431377,1500,98814,256,73771,103431,74250]

theorem envBound32348 : H12AffineFastState.Bounded env32348 := by
  intro p hp
  have h : env32348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32347_32348 : H12AffineEnvironment.transform 22 152 env32347 = env32348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env32347 == env32348) = true)

def env32349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,33,16,98645,8192,64,398437,79130,77835,431377,1364,98678,256,73771,103431,74250]

theorem envBound32349 : H12AffineFastState.Bounded env32349 := by
  intro p hp
  have h : env32349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32348_32349 : H12AffineEnvironment.transform 6 8 env32348 = env32349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32348 == env32349) = true)

theorem identity32349 : scanCanonicalize (H12AffineFastState.compose env32349 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32349 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41310,8192,64,398437,5393,4096,431377,1364,41341,256,32,46092,513]

theorem envBound32350 : H12AffineFastState.Bounded env32350 := by
  intro p hp
  have h : env32350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32349_32350 : H12AffineEnvironment.transform 15 8203 env32349 = env32350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32349 == env32350) = true)

theorem identity32350 : scanCanonicalize (H12AffineFastState.compose env32350 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32350 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,33,16,2,8192,64,398437,5393,4096,406605,1364,33,256,32,5456,513]

theorem envBound32351 : H12AffineFastState.Bounded env32351 := by
  intro p hp
  have h : env32351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32350_32351 : H12AffineEnvironment.transform 14 8540 env32350 = env32351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32350 == env32351) = true)

theorem identity32351 : scanCanonicalize (H12AffineFastState.compose env32351 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32351 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10360,1024,8541,4160,33,16,2,8192,64,146461,5393,4096,138293,1364,33,256,32,5456,513]

theorem envBound32352 : H12AffineFastState.Bounded env32352 := by
  intro p hp
  have h : env32352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32351_32352 : H12AffineEnvironment.transform 17 10360 env32351 = env32352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32351 == env32352) = true)

theorem identity32352 : scanCanonicalize (H12AffineFastState.compose env32352 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound32352 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10360,1024,8541,4160,33,16,2,8192,64,2128,5393,4096,10360,1364,33,256,32,5456,513]

theorem envBound32353 : H12AffineFastState.Bounded env32353 := by
  intro p hp
  have h : env32353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32352_32353 : H12AffineEnvironment.transform 16 13389 env32352 = env32353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env32352 == env32353) = true)

theorem identity32353 : scanCanonicalize (H12AffineFastState.compose env32353 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32353 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5441,2420,1024,81,4160,33,16,2,268,64,2128,5393,4096,2420,1364,33,256,32,5456,513]

theorem envBound32354 : H12AffineFastState.Bounded env32354 := by
  intro p hp
  have h : env32354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32353_32354 : H12AffineEnvironment.transform 12 268 env32353 = env32354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32353 == env32354) = true)

theorem identity32354 : scanCanonicalize (H12AffineFastState.compose env32354 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32354 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32355 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5157,80,34,5220,2129,1024,81,4160,33,16,2,41,64,2128,5172,4096,2129,1137,33,37,32,5237,513]

theorem envBound32355 : H12AffineFastState.Bounded env32355 := by
  intro p hp
  have h : env32355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32354_32355 : H12AffineEnvironment.transform 7 37 env32354 = env32355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32354 == env32355) = true)

theorem identity32355 : scanCanonicalize (H12AffineFastState.compose env32355 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32355 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32356 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,0,34,5172,2049,1024,1,4112,33,16,2,41,16,2048,5172,4096,2049,1057,33,37,32,5157,513]

theorem envBound32356 : H12AffineFastState.Bounded env32356 := by
  intro p hp
  have h : env32356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32355_32356 : H12AffineEnvironment.transform 5 16 env32355 = env32356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32355 == env32356) = true)

def env32357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,17,98645,8193,64,398437,79130,77834,431377,1365,98679,256,73771,103431,74250]

theorem envBound32357 : H12AffineFastState.Bounded env32357 := by
  intro p hp
  have h : env32357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32348_32357 : H12AffineEnvironment.transform 6 9 env32348 = env32357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32348 == env32357) = true)

theorem identity32357 : scanCanonicalize (H12AffineFastState.compose env32357 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32357 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,77898,33,17,98645,8193,64,171280,79130,77834,138340,1365,98679,256,73771,103431,74250]

theorem envBound32358 : H12AffineFastState.Bounded env32358 := by
  intro p hp
  have h : env32358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32357_32358 : H12AffineEnvironment.transform 17 35189 env32357 = env32358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32357 == env32358) = true)

theorem identity32358 : scanCanonicalize (H12AffineFastState.compose env32358 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound32358 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5392,35189,1024,32769,77898,33,17,98645,8193,64,34816,79130,77834,2420,1365,98679,256,73771,103431,74250]

theorem envBound32359 : H12AffineFastState.Bounded env32359 := by
  intro p hp
  have h : env32359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32358_32359 : H12AffineEnvironment.transform 16 5392 env32358 = env32359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env32358 == env32359) = true)

def env32360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981468,79130,8466459,8820104,8389957,4293086,256,8462514,8492191,8462995]

theorem envBound32360 : H12AffineFastState.Bounded env32360 := by
  intro p hp
  have h : env32360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32337_32360 : H12AffineEnvironment.transform 13 5513 env32337 = env32360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32337 == env32360) = true)

def env32361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787196,79130,8466459,8820104,8389957,98814,256,8462514,8492191,8462995]

theorem envBound32361 : H12AffineFastState.Bounded env32361 := by
  intro p hp
  have h : env32361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32360_32361 : H12AffineEnvironment.transform 21 32 env32360 = env32361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32360 == env32361) = true)

theorem identity32361 : scanCanonicalize (H12AffineFastState.compose env32361 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32361 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,262144,1024,8541,78018,32,8388608,73736,8328,64,8787196,79130,8466459,8795348,8389957,73890,256,8462514,8467907,8462995]

theorem envBound32362 : H12AffineFastState.Bounded env32362 := by
  intro p hp
  have h : env32362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32361_32362 : H12AffineEnvironment.transform 14 8540 env32361 = env32362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32361 == env32362) = true)

def env32363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,78018,32,8388608,73736,8328,64,8535132,79130,8466459,8526964,8389957,73890,256,8462514,8467907,8462995]

theorem envBound32363 : H12AffineFastState.Bounded env32363 := by
  intro p hp
  have h : env32363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32362_32363 : H12AffineEnvironment.transform 17 10400 env32362 = env32363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32362 == env32363) = true)

def env32364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,78018,32,136584,73736,8328,64,10708,79130,206227,2556,135373,73890,256,210234,204875,210715]

theorem envBound32364 : H12AffineFastState.Bounded env32364 := by
  intro p hp
  have h : env32364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32363_32364 : H12AffineEnvironment.transform 22 136584 env32363 = env32364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136584 env32363 == env32364) = true)

theorem identity32364 : scanCanonicalize (H12AffineFastState.compose env32364 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound32364 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env32365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,5393,10400,1024,8541,78018,32,153,73736,8328,64,10708,79130,77954,2556,1500,73890,256,73771,79194,74250]

theorem envBound32365 : H12AffineFastState.Bounded env32365 := by
  intro p hp
  have h : env32365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32364_32365 : H12AffineEnvironment.transform 16 5393 env32364 = env32365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env32364 == env32365) = true)

theorem identity32365 : scanCanonicalize (H12AffineFastState.compose env32365 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32365 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8203,5393,10400,1024,8541,4297,32,153,3,8328,64,10708,5393,4233,2556,1500,169,256,32,5457,513]

theorem envBound32366 : H12AffineFastState.Bounded env32366 := by
  intro p hp
  have h : env32366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32365_32366 : H12AffineEnvironment.transform 15 8203 env32365 = env32366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32365 == env32366) = true)

theorem identity32366 : scanCanonicalize (H12AffineFastState.compose env32366 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32366 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10280,1024,8541,4161,32,17,3,8192,64,10588,5393,4097,2420,1364,33,256,32,5457,513]

theorem envBound32367 : H12AffineFastState.Bounded env32367 := by
  intro p hp
  have h : env32367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32366_32367 : H12AffineEnvironment.transform 6 8 env32366 = env32367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32366 == env32367) = true)

theorem identity32367 : scanCanonicalize (H12AffineFastState.compose env32367 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32367 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5393,2421,1024,0,4161,32,17,3,349,64,2049,5393,4097,2420,1364,33,256,32,5457,513]

theorem envBound32368 : H12AffineFastState.Bounded env32368 := by
  intro p hp
  have h : env32368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32367_32368 : H12AffineEnvironment.transform 12 349 env32367 = env32368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32367 == env32368) = true)

theorem identity32368 : scanCanonicalize (H12AffineFastState.compose env32368 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1866) := by decide +kernel

theorem selectedBound32368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1866,4096,349,5377,1,342,5393,1599,1024,0,4161,32,17,3,349,64,1867,5393,4097,1598,1364,33,256,32,5457,513]

theorem envBound32369 : H12AffineFastState.Bounded env32369 := by
  intro p hp
  have h : env32369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32368_32369 : H12AffineEnvironment.transform 10 1866 env32368 = env32369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1866 env32368 == env32369) = true)

theorem identity32369 : scanCanonicalize (H12AffineFastState.compose env32369 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound32369 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32370 : List Nat := [2,4,8,16,32,64,8,256,512,321,523,4096,349,4160,1,342,4176,894,321,0,4161,32,17,3,349,64,522,4176,4097,895,21,33,256,32,4112,513]

theorem envBound32370 : H12AffineFastState.Bounded env32370 := by
  intro p hp
  have h : env32370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32369_32370 : H12AffineEnvironment.transform 9 321 env32369 = env32370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32369 == env32370) = true)

theorem identity32370 : scanCanonicalize (H12AffineFastState.compose env32370 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32371 : List Nat := [2,4,8,16,32,64,8,4,512,69,523,4096,89,4160,1,82,4176,634,69,0,4161,32,17,3,89,64,522,4176,4097,635,21,33,4,32,4112,513]

theorem envBound32371 : H12AffineFastState.Bounded env32371 := by
  intro p hp
  have h : env32371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32370_32371 : H12AffineEnvironment.transform 7 4 env32370 = env32371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32370 == env32371) = true)

theorem identity32371 : scanCanonicalize (H12AffineFastState.compose env32371 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound32371 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env32372 : List Nat := [2,4,8,16,32,49,8,4,512,52,523,4096,40,4145,1,35,4129,523,52,0,4144,32,17,3,40,49,522,4129,4097,522,21,33,4,32,4112,513]

theorem envBound32372 : H12AffineFastState.Bounded env32372 := by
  intro p hp
  have h : env32372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32371_32372 : H12AffineEnvironment.transform 5 49 env32371 = env32372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env32371 == env32372) = true)

theorem identity32372 : scanCanonicalize (H12AffineFastState.compose env32372 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound32372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32373 : List Nat := [2,4,8,16,32,49,8,4,53,52,62,4096,40,4145,1,35,4129,62,52,0,4144,32,17,3,40,49,63,4129,4097,63,21,33,4,32,4112,52]

theorem envBound32373 : H12AffineFastState.Bounded env32373 := by
  intro p hp
  have h : env32373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32372_32373 : H12AffineEnvironment.transform 8 53 env32372 = env32373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env32372 == env32373) = true)

theorem identity32373 : scanCanonicalize (H12AffineFastState.compose env32373 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 8) := by decide +kernel

theorem selectedBound32373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32374 : List Nat := [2,4,8,16,32,49,8,4,53,52,62,8,40,57,1,35,41,62,52,0,56,32,17,3,40,49,63,41,9,63,21,33,4,32,24,52]

theorem envBound32374 : H12AffineFastState.Bounded env32374 := by
  intro p hp
  have h : env32374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32373_32374 : H12AffineEnvironment.transform 11 8 env32373 = env32374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 8 env32373 == env32374) = true)

theorem identity32374 : scanCanonicalize (H12AffineFastState.compose env32374 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32374 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env32375 : List Nat := [2,4,8,16,0,17,8,4,21,20,30,8,8,25,1,3,9,30,20,0,24,0,17,3,8,17,31,9,9,31,21,1,4,0,24,20]

theorem envBound32375 : H12AffineFastState.Bounded env32375 := by
  intro p hp
  have h : env32375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32374_32375 : H12AffineEnvironment.transform 4 0 env32374 = env32375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32374 == env32375) = true)

theorem identity32375 : scanCanonicalize (H12AffineFastState.compose env32375 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32375 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32376 : List Nat := [2,4,3,16,0,17,3,4,21,20,21,3,3,18,1,3,2,21,20,0,19,0,17,3,3,17,20,2,2,20,21,1,4,0,19,20]

theorem envBound32376 : H12AffineFastState.Bounded env32376 := by
  intro p hp
  have h : env32376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32375_32376 : H12AffineEnvironment.transform 2 3 env32375 = env32376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32375 == env32376) = true)

theorem identity32376 : scanCanonicalize (H12AffineFastState.compose env32376 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32376 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32377 : List Nat := [2,4,3,0,0,1,3,4,5,4,5,3,3,2,1,3,2,5,4,0,3,0,1,3,3,1,4,2,2,4,5,1,4,0,3,4]

theorem envBound32377 : H12AffineFastState.Bounded env32377 := by
  intro p hp
  have h : env32377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32376_32377 : H12AffineEnvironment.transform 3 0 env32376 = env32377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32376 == env32377) = true)

def env32378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,78018,32,136585,73736,8328,64,10709,79130,206226,2557,135372,73890,256,210235,204874,210714]

theorem envBound32378 : H12AffineFastState.Bounded env32378 := by
  intro p hp
  have h : env32378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32363_32378 : H12AffineEnvironment.transform 22 136585 env32363 = env32378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136585 env32363 == env32378) = true)

theorem identity32378 : scanCanonicalize (H12AffineFastState.compose env32378 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound32378 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env32379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,70862,10400,1024,8541,78018,32,65863,73736,8328,64,10709,79130,12636,2557,66562,73890,256,8693,13444,9172]

theorem envBound32379 : H12AffineFastState.Bounded env32379 := by
  intro p hp
  have h : env32379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32378_32379 : H12AffineEnvironment.transform 16 70862 env32378 = env32379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env32378 == env32379) = true)

theorem identity32379 : scanCanonicalize (H12AffineFastState.compose env32379 (packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32379 : packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env32380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,65536,70862,2420,1024,137,69910,32,65863,66012,348,64,2049,70862,4232,2557,66562,65910,256,33,5456,512]

theorem envBound32380 : H12AffineFastState.Bounded env32380 := by
  intro p hp
  have h : env32380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32379_32380 : H12AffineEnvironment.transform 12 468 env32379 = env32380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32379 == env32380) = true)

theorem identity32380 : scanCanonicalize (H12AffineFastState.compose env32380 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 7391) := by decide +kernel

theorem selectedBound32380 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,7391,2065,2420,1024,137,3529,32,7576,7427,348,64,2049,2065,4232,2557,6365,7593,256,33,5456,512]

theorem envBound32381 : H12AffineFastState.Bounded env32381 := by
  intro p hp
  have h : env32381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32380_32381 : H12AffineEnvironment.transform 15 7391 env32380 = env32381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7391 env32380 == env32381) = true)

theorem identity32381 : scanCanonicalize (H12AffineFastState.compose env32381 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound32381 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2233,468,3376,136,1126,2065,2420,1024,137,3529,32,1313,1466,348,64,2049,2065,2097,2557,100,1296,256,33,3561,512]

theorem envBound32382 : H12AffineFastState.Bounded env32382 := by
  intro p hp
  have h : env32382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32381_32382 : H12AffineEnvironment.transform 11 2233 env32381 = env32382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env32381 == env32382) = true)

theorem identity32382 : scanCanonicalize (H12AffineFastState.compose env32382 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32382 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env32383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,185,468,1328,136,1126,17,372,1024,137,1481,32,1313,1466,348,64,1,17,49,509,100,1296,256,33,1513,512]

theorem envBound32383 : H12AffineFastState.Bounded env32383 := by
  intro p hp
  have h : env32383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32382_32383 : H12AffineEnvironment.transform 10 0 env32382 = env32383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32382 == env32383) = true)

theorem identity32383 : scanCanonicalize (H12AffineFastState.compose env32383 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound32383 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env32384 : List Nat := [2,4,8,16,32,64,128,256,512,204,0,185,468,508,136,170,17,372,204,137,261,32,493,374,348,64,1,17,49,509,100,476,256,33,293,512]

theorem envBound32384 : H12AffineFastState.Bounded env32384 := by
  intro p hp
  have h : env32384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32383_32384 : H12AffineEnvironment.transform 9 204 env32383 = env32384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env32383 == env32384) = true)

theorem identity32384 : scanCanonicalize (H12AffineFastState.compose env32384 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound32384 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32385 : List Nat := [2,4,8,16,32,64,128,85,512,204,0,185,129,169,136,170,17,33,204,137,80,32,184,35,9,64,1,17,49,168,100,137,85,33,112,512]

theorem envBound32385 : H12AffineFastState.Bounded env32385 := by
  intro p hp
  have h : env32385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32384_32385 : H12AffineEnvironment.transform 7 85 env32384 = env32385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env32384 == env32385) = true)

theorem identity32385 : scanCanonicalize (H12AffineFastState.compose env32385 (packedSelected [0,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound32385 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env32386 : List Nat := [2,4,8,16,32,64,40,85,512,100,0,17,41,1,32,2,17,33,100,33,80,32,16,35,9,64,1,17,49,0,100,33,85,33,112,512]

theorem envBound32386 : H12AffineFastState.Bounded env32386 := by
  intro p hp
  have h : env32386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32385_32386 : H12AffineEnvironment.transform 6 40 env32385 = env32386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env32385 == env32386) = true)

theorem identity32386 : scanCanonicalize (H12AffineFastState.compose env32386 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32386 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32387 : List Nat := [2,4,8,16,0,64,8,85,512,68,0,17,9,1,0,2,17,1,68,1,80,0,16,3,9,64,1,17,17,0,68,1,85,1,80,512]

theorem envBound32387 : H12AffineFastState.Bounded env32387 := by
  intro p hp
  have h : env32387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32386_32387 : H12AffineEnvironment.transform 4 0 env32386 = env32387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32386 == env32387) = true)

theorem identity32387 : scanCanonicalize (H12AffineFastState.compose env32387 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32388 : List Nat := [2,4,8,1,0,64,8,68,512,68,0,0,9,1,0,2,0,1,68,1,65,0,1,3,9,64,1,0,0,0,68,1,68,1,65,512]

theorem envBound32388 : H12AffineFastState.Bounded env32388 := by
  intro p hp
  have h : env32388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32387_32388 : H12AffineEnvironment.transform 3 1 env32387 = env32388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32387 == env32388) = true)

theorem identity32388 : scanCanonicalize (H12AffineFastState.compose env32388 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32389 : List Nat := [2,0,8,1,0,64,8,64,512,64,0,0,9,1,0,2,0,1,64,1,65,0,1,3,9,64,1,0,0,0,64,1,64,1,65,512]

theorem envBound32389 : H12AffineFastState.Bounded env32389 := by
  intro p hp
  have h : env32389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32388_32389 : H12AffineEnvironment.transform 1 0 env32388 = env32389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32388 == env32389) = true)

theorem identity32389 : scanCanonicalize (H12AffineFastState.compose env32389 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32390 : List Nat := [2,0,8,1,0,0,8,0,512,0,0,0,9,1,0,2,0,1,0,1,1,0,1,3,9,0,1,0,0,0,0,1,0,1,1,512]

theorem envBound32390 : H12AffineFastState.Bounded env32390 := by
  intro p hp
  have h : env32390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32389_32390 : H12AffineEnvironment.transform 5 0 env32389 = env32390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32389 == env32390) = true)

theorem identity32390 : scanCanonicalize (H12AffineFastState.compose env32390 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32390 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32391 : List Nat := [2,0,8,1,0,0,8,0,0,0,0,0,9,1,0,2,0,1,0,1,1,0,1,3,9,0,1,0,0,0,0,1,0,1,1,0]

theorem envBound32391 : H12AffineFastState.Bounded env32391 := by
  intro p hp
  have h : env32391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32390_32391 : H12AffineEnvironment.transform 8 0 env32390 = env32391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32390 == env32391) = true)

def env32392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1024,8541,78018,32,8388608,73736,8328,64,8535133,79130,8466459,8526965,8389957,73890,256,8462514,8467907,8462995]

theorem envBound32392 : H12AffineFastState.Bounded env32392 := by
  intro p hp
  have h : env32392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32362_32392 : H12AffineEnvironment.transform 17 10401 env32362 = env32392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32362 == env32392) = true)

theorem identity32392 : scanCanonicalize (H12AffineFastState.compose env32392 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound32392 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1024,8541,78018,32,16,73736,8328,64,146509,79130,77835,138341,1365,73890,256,73890,79315,74371]

theorem envBound32393 : H12AffineFastState.Bounded env32393 := by
  intro p hp
  have h : env32393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32392_32393 : H12AffineEnvironment.transform 22 16 env32392 = env32393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env32392 == env32393) = true)

theorem identity32393 : scanCanonicalize (H12AffineFastState.compose env32393 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound32393 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,79251,10401,1024,8541,78018,32,16,73736,8328,64,68062,79130,77835,76278,1365,73890,256,73890,79315,74371]

theorem envBound32394 : H12AffineFastState.Bounded env32394 := by
  intro p hp
  have h : env32394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32393_32394 : H12AffineEnvironment.transform 16 79251 env32393 = env32394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env32393 == env32394) = true)

theorem identity32394 : scanCanonicalize (H12AffineFastState.compose env32394 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound32394 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,65536,70726,2420,1024,136,69911,32,16,66013,349,64,68062,70863,70110,67619,1365,65911,256,65911,70662,66390]

theorem envBound32395 : H12AffineFastState.Bounded env32395 := by
  intro p hp
  have h : env32395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32394_32395 : H12AffineEnvironment.transform 12 469 env32394 = env32395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env32394 == env32395) = true)

theorem identity32395 : scanCanonicalize (H12AffineFastState.compose env32395 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound32395 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env32396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,343,5393,2420,1024,136,4160,32,16,138,349,64,2185,5528,4233,2420,1365,32,256,32,5457,513]

theorem envBound32396 : H12AffineFastState.Bounded env32396 := by
  intro p hp
  have h : env32396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32395_32396 : H12AffineEnvironment.transform 15 343 env32395 = env32396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env32395 == env32396) = true)

theorem identity32396 : scanCanonicalize (H12AffineFastState.compose env32396 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32396 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32397 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,469,4248,137,343,4096,2420,273,136,4160,32,16,138,349,64,2185,4233,4233,2420,68,32,256,32,4160,513]

theorem envBound32397 : H12AffineFastState.Bounded env32397 := by
  intro p hp
  have h : env32397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32396_32397 : H12AffineEnvironment.transform 9 273 env32396 = env32397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32396 == env32397) = true)

theorem identity32397 : scanCanonicalize (H12AffineFastState.compose env32397 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32397 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32398 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4112,1,343,4096,2420,273,0,4160,32,16,2,349,64,2049,4097,4097,2420,68,32,256,32,4160,513]

theorem envBound32398 : H12AffineFastState.Bounded env32398 := by
  intro p hp
  have h : env32398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32397_32398 : H12AffineEnvironment.transform 6 8 env32397 = env32398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32397 == env32398) = true)

theorem identity32398 : scanCanonicalize (H12AffineFastState.compose env32398 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32399 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,4096,72,4112,1,66,4096,2145,4,0,4160,32,16,2,72,64,2049,4097,4097,2145,68,32,21,32,4160,513]

theorem envBound32399 : H12AffineFastState.Bounded env32399 := by
  intro p hp
  have h : env32399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32398_32399 : H12AffineEnvironment.transform 7 21 env32398 = env32399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32398 == env32399) = true)

theorem identity32399 : scanCanonicalize (H12AffineFastState.compose env32399 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound32399 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32400 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,545,72,561,1,66,545,2145,4,0,609,32,16,2,72,64,2049,544,544,2145,68,32,21,32,609,513]

theorem envBound32400 : H12AffineFastState.Bounded env32400 := by
  intro p hp
  have h : env32400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32399_32400 : H12AffineEnvironment.transform 11 545 env32399 = env32400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env32399 == env32400) = true)

def env32401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787197,79130,8466459,8820104,8389957,98815,256,8462514,8492191,8462995]

theorem envBound32401 : H12AffineFastState.Bounded env32401 := by
  intro p hp
  have h : env32401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32360_32401 : H12AffineEnvironment.transform 21 33 env32360 = env32401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32360 == env32401) = true)

theorem identity32401 : scanCanonicalize (H12AffineFastState.compose env32401 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound32401 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,41292,98644,8328,64,439729,79130,102743,406724,41993,98815,256,98814,79315,99295]

theorem envBound32402 : H12AffineFastState.Bounded env32402 := by
  intro p hp
  have h : env32402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32401_32402 : H12AffineEnvironment.transform 22 41292 env32401 = env32402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env32401 == env32402) = true)

theorem identity32402 : scanCanonicalize (H12AffineFastState.compose env32402 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound32402 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env32403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,108926,1024,32769,78018,33,41292,98644,8328,64,203983,79130,102743,236986,41993,98815,256,98814,79315,99295]

theorem envBound32403 : H12AffineFastState.Bounded env32403 := by
  intro p hp
  have h : env32403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32402_32403 : H12AffineEnvironment.transform 17 108926 env32402 = env32403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env32402 == env32403) = true)

theorem identity32403 : scanCanonicalize (H12AffineFastState.compose env32403 (packedSelected [0,1,3,9,11,12,15,16,18,20,21,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound32403 : packedSelected [0,1,3,9,11,12,15,16,18,20,21,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,10400,1024,32769,45340,33,41292,138,8328,64,171281,46276,4233,138340,41993,33,256,32,46093,513]

theorem envBound32404 : H12AffineFastState.Bounded env32404 := by
  intro p hp
  have h : env32404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32403_32404 : H12AffineEnvironment.transform 15 33246 env32403 = env32404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env32403 == env32404) = true)

theorem identity32404 : scanCanonicalize (H12AffineFastState.compose env32404 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound32404 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env32405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,13461,10400,1024,32769,45340,33,41292,138,8328,64,43396,46276,4233,10481,41993,33,256,32,46093,513]

theorem envBound32405 : H12AffineFastState.Bounded env32405 := by
  intro p hp
  have h : env32405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32404_32405 : H12AffineEnvironment.transform 16 13461 env32404 = env32405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env32404 == env32405) = true)

theorem identity32405 : scanCanonicalize (H12AffineFastState.compose env32405 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound32405 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env32406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8203,13461,10400,1024,8660,4297,33,153,138,8328,64,2129,5393,4233,10481,1500,33,256,32,5592,513]

theorem envBound32406 : H12AffineFastState.Bounded env32406 := by
  intro p hp
  have h : env32406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32405_32406 : H12AffineEnvironment.transform 14 8661 env32405 = env32406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env32405 == env32406) = true)

theorem identity32406 : scanCanonicalize (H12AffineFastState.compose env32406 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound32406 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1172,5513,1345,1183,4097,3124,1024,1344,4297,33,153,138,1052,64,2129,5393,4233,3173,1500,33,256,32,5592,513]

theorem envBound32407 : H12AffineFastState.Bounded env32407 := by
  intro p hp
  have h : env32407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32406_32407 : H12AffineEnvironment.transform 12 1172 env32406 = env32407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env32406 == env32407) = true)

theorem identity32407 : scanCanonicalize (H12AffineFastState.compose env32407 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32407 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32408 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,468,4297,1,479,4097,2420,320,0,4297,33,153,138,348,64,2129,4177,4233,2341,156,33,256,32,4248,513]

theorem envBound32408 : H12AffineFastState.Bounded env32408 := by
  intro p hp
  have h : env32408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32407_32408 : H12AffineEnvironment.transform 9 320 env32407 = env32408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32407 == env32408) = true)

theorem identity32408 : scanCanonicalize (H12AffineFastState.compose env32408 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32408 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32409 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,4249,1,399,4097,2340,272,0,4249,33,153,138,268,16,2049,4097,4233,2341,156,33,256,32,4248,513]

theorem envBound32409 : H12AffineFastState.Bounded env32409 := by
  intro p hp
  have h : env32409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32408_32409 : H12AffineEnvironment.transform 5 16 env32408 = env32409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32408 == env32409) = true)

theorem identity32409 : scanCanonicalize (H12AffineFastState.compose env32409 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32409 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32410 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4113,1,263,4097,2340,272,0,4113,33,17,2,268,16,2049,4097,4097,2341,20,33,256,32,4112,513]

theorem envBound32410 : H12AffineFastState.Bounded env32410 := by
  intro p hp
  have h : env32410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32409_32410 : H12AffineEnvironment.transform 6 8 env32409 = env32410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32409 == env32410) = true)

theorem identity32410 : scanCanonicalize (H12AffineFastState.compose env32410 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32411 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,1,34,4097,2049,53,0,4113,33,17,2,41,16,2049,4097,4097,2048,20,33,37,32,4112,513]

theorem envBound32411 : H12AffineFastState.Bounded env32411 := by
  intro p hp
  have h : env32411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32410_32411 : H12AffineEnvironment.transform 7 37 env32410 = env32411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32410 == env32411) = true)

theorem identity32411 : scanCanonicalize (H12AffineFastState.compose env32411 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2084) := by decide +kernel

theorem selectedBound32411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32412 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2084,41,2101,1,34,2085,2049,53,0,2101,33,17,2,41,16,2049,2085,2085,2048,20,33,37,32,2100,513]

theorem envBound32412 : H12AffineFastState.Bounded env32412 := by
  intro p hp
  have h : env32412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32411_32412 : H12AffineEnvironment.transform 11 2084 env32411 = env32412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2084 env32411 == env32412) = true)

theorem identity32412 : scanCanonicalize (H12AffineFastState.compose env32412 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound32412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32413 : List Nat := [2,4,8,16,32,16,8,37,29,53,2048,2084,41,2101,1,34,2085,2049,53,0,2101,33,17,2,41,16,2049,2085,2085,2048,20,33,37,32,2100,28]

theorem envBound32413 : H12AffineFastState.Bounded env32413 := by
  intro p hp
  have h : env32413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32412_32413 : H12AffineEnvironment.transform 8 29 env32412 = env32413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env32412 == env32413) = true)

theorem identity32413 : scanCanonicalize (H12AffineFastState.compose env32413 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound32413 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32414 : List Nat := [2,4,8,16,32,16,8,37,29,53,23,51,41,34,1,34,50,22,53,0,34,33,17,2,41,16,22,50,50,23,20,33,37,32,35,28]

theorem envBound32414 : H12AffineFastState.Bounded env32414 := by
  intro p hp
  have h : env32414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32413_32414 : H12AffineEnvironment.transform 10 23 env32413 = env32414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env32413 == env32414) = true)

theorem identity32414 : scanCanonicalize (H12AffineFastState.compose env32414 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound32414 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32415 : List Nat := [2,4,8,16,22,16,8,19,29,3,23,5,31,20,1,20,4,22,3,0,20,23,17,2,31,16,22,4,4,23,20,23,19,22,21,28]

theorem envBound32415 : H12AffineFastState.Bounded env32415 := by
  intro p hp
  have h : env32415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32414_32415 : H12AffineEnvironment.transform 4 22 env32414 = env32415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env32414 == env32415) = true)

theorem identity32415 : scanCanonicalize (H12AffineFastState.compose env32415 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32415 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32416 : List Nat := [0,4,8,16,20,16,8,17,29,1,21,5,29,20,1,20,4,20,1,0,20,21,17,0,29,16,20,4,4,21,20,21,17,20,21,28]

theorem envBound32416 : H12AffineFastState.Bounded env32416 := by
  intro p hp
  have h : env32416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32415_32416 : H12AffineEnvironment.transform 0 0 env32415 = env32416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32415 == env32416) = true)

def env32417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound32417 : H12AffineFastState.Bounded env32417 := by
  intro p hp
  have h : env32417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32235_32417 : H12AffineEnvironment.transform 18 1025 env32235 = env32417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env32235 == env32417) = true)

theorem identity32417 : scanCanonicalize (H12AffineFastState.compose env32417 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10651083) := by decide +kernel

theorem selectedBound32417 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10651083,8328,64,6637003,8585542,10507600,8830976,2294234,12836874,257,213351,237762,2237965]

theorem envBound32418 : H12AffineFastState.Bounded env32418 := by
  intro p hp
  have h : env32418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32417_32418 : H12AffineEnvironment.transform 23 10651083 env32417 = env32418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10651083 env32417 == env32418) = true)

def env32419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180360,2114883,8328,64,6637003,115150,2266584,262280,2294234,4268162,257,213351,237762,2237965]

theorem envBound32419 : H12AffineFastState.Bounded env32419 := by
  intro p hp
  have h : env32419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32418_32419 : H12AffineEnvironment.transform 22 180360 env32418 = env32419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env32418 == env32419) = true)

def env32420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,169371,8328,64,4691219,115150,17664,262280,119042,4268162,257,213351,237762,63189]

theorem envBound32420 : H12AffineFastState.Bounded env32420 := by
  intro p hp
  have h : env32420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32419_32420 : H12AffineEnvironment.transform 20 184536 env32419 = env32420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env32419 == env32420) = true)

def env32421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,169371,8328,64,245139,115150,17664,262280,119042,329730,257,213351,237762,63189]

theorem envBound32421 : H12AffineFastState.Bounded env32421 := by
  intro p hp
  have h : env32421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32420_32421 : H12AffineEnvironment.transform 21 272512 env32420 = env32421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32420 == env32421) = true)

theorem identity32421 : scanCanonicalize (H12AffineFastState.compose env32421 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32421 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140300,272512,144476,155983,8328,64,215367,79130,17664,262280,75222,329730,257,213351,218134,513]

theorem envBound32422 : H12AffineFastState.Bounded env32422 := by
  intro p hp
  have h : env32422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32421_32422 : H12AffineEnvironment.transform 14 29908 env32421 = env32422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32421 == env32422) = true)

def env32423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272392,144476,155983,8192,64,215367,79130,17664,262144,75102,329730,257,213351,218134,513]

theorem envBound32423 : H12AffineFastState.Bounded env32423 := by
  intro p hp
  have h : env32423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32422_32423 : H12AffineEnvironment.transform 6 8 env32422 = env32423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32422 == env32423) = true)

theorem identity32423 : scanCanonicalize (H12AffineFastState.compose env32423 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound32423 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,82966,272392,87110,65877,8192,64,10589,79130,17664,262144,75102,329730,257,8573,13324,513]

theorem envBound32424 : H12AffineFastState.Bounded env32424 := by
  intro p hp
  have h : env32424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32423_32424 : H12AffineEnvironment.transform 16 90138 env32423 = env32424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env32423 == env32424) = true)

theorem identity32424 : scanCanonicalize (H12AffineFastState.compose env32424 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound32424 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97327,1025,29789,82966,87079,87110,65877,8192,64,10589,79130,17664,97327,75102,29741,257,8573,13324,513]

theorem envBound32425 : H12AffineFastState.Bounded env32425 := by
  intro p hp
  have h : env32425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32424_32425 : H12AffineEnvironment.transform 17 97327 env32424 = env32425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env32424 == env32425) = true)

theorem identity32425 : scanCanonicalize (H12AffineFastState.compose env32425 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound32425 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2341,1025,29789,12572,8493,8524,29791,8192,64,10589,16400,17664,2341,20564,29741,257,8573,13324,513]

theorem envBound32426 : H12AffineFastState.Bounded env32426 := by
  intro p hp
  have h : env32426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32425_32426 : H12AffineEnvironment.transform 15 29962 env32425 = env32426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env32425 == env32426) = true)

theorem identity32426 : scanCanonicalize (H12AffineFastState.compose env32426 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32426 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env32427 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,29962,5392,2341,1025,29709,12572,8493,8476,29711,8192,16,10509,16400,17664,2341,20484,29741,257,8493,13324,513]

theorem envBound32427 : H12AffineFastState.Bounded env32427 := by
  intro p hp
  have h : env32427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32426_32427 : H12AffineEnvironment.transform 5 16 env32426 = env32427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32426 == env32427) = true)

theorem identity32427 : scanCanonicalize (H12AffineFastState.compose env32427 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32427 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32428 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,263,5392,2341,1025,0,12572,8493,8476,2,8192,16,10509,13341,12557,2341,9225,32,257,8493,13324,513]

theorem envBound32428 : H12AffineFastState.Bounded env32428 := by
  intro p hp
  have h : env32428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32427_32428 : H12AffineEnvironment.transform 13 13325 env32427 = env32428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32427 == env32428) = true)

theorem identity32428 : scanCanonicalize (H12AffineFastState.compose env32428 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 5661) := by decide +kernel

theorem selectedBound32428 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32429 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5661,528,1,263,5392,2341,1025,0,1793,5936,5889,2,5661,16,7952,512,1808,2341,4628,32,257,5936,529,513]

theorem envBound32429 : H12AffineFastState.Bounded env32429 := by
  intro p hp
  have h : env32429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32428_32429 : H12AffineEnvironment.transform 12 5661 env32428 = env32429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5661 env32428 == env32429) = true)

theorem identity32429 : scanCanonicalize (H12AffineFastState.compose env32429 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound32429 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env32430 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,2616,528,1,263,2357,2341,1025,0,1793,2837,2852,2,2616,16,821,512,1808,2341,3633,32,257,2837,529,513]

theorem envBound32430 : H12AffineFastState.Bounded env32430 := by
  intro p hp
  have h : env32430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32429_32430 : H12AffineEnvironment.transform 11 3109 env32429 = env32430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env32429 == env32430) = true)

theorem identity32430 : scanCanonicalize (H12AffineFastState.compose env32430 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound32430 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env32431 : List Nat := [2,4,8,16,32,16,8,256,512,1024,821,1808,269,528,1,263,512,528,1025,0,1793,32,17,2,269,16,821,512,1808,528,1284,32,257,32,529,513]

theorem envBound32431 : H12AffineFastState.Bounded env32431 := by
  intro p hp
  have h : env32431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32430_32431 : H12AffineEnvironment.transform 10 821 env32430 = env32431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env32430 == env32431) = true)

theorem identity32431 : scanCanonicalize (H12AffineFastState.compose env32431 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound32431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32432 : List Nat := [2,4,8,16,32,16,8,256,512,784,821,0,269,528,1,263,512,528,785,0,17,32,17,2,269,16,821,512,0,528,532,32,257,32,529,513]

theorem envBound32432 : H12AffineFastState.Bounded env32432 := by
  intro p hp
  have h : env32432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32431_32432 : H12AffineEnvironment.transform 9 784 env32431 = env32432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env32431 == env32432) = true)

theorem identity32432 : scanCanonicalize (H12AffineFastState.compose env32432 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32432 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32433 : List Nat := [2,4,8,16,32,16,8,37,512,565,528,0,40,528,1,34,512,528,564,0,17,32,17,2,40,16,528,512,0,528,532,32,36,32,529,513]

theorem envBound32433 : H12AffineFastState.Bounded env32433 := by
  intro p hp
  have h : env32433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32432_32433 : H12AffineEnvironment.transform 7 37 env32432 = env32433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32432 == env32433) = true)

theorem identity32433 : scanCanonicalize (H12AffineFastState.compose env32433 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32434 : List Nat := [2,4,8,0,32,0,8,37,512,549,512,0,40,512,1,34,512,512,548,0,1,32,1,2,40,0,512,512,0,512,516,32,36,32,513,513]

theorem envBound32434 : H12AffineFastState.Bounded env32434 := by
  intro p hp
  have h : env32434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32433_32434 : H12AffineEnvironment.transform 3 0 env32433 = env32434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32433 == env32434) = true)

def env32435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272393,144476,155983,8193,64,215367,79130,17664,262145,75103,329730,257,213351,218134,513]

theorem envBound32435 : H12AffineFastState.Bounded env32435 := by
  intro p hp
  have h : env32435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32422_32435 : H12AffineEnvironment.transform 6 9 env32422 = env32435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32422 == env32435) = true)

def env32436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,169371,8328,64,245138,115150,17664,262280,119042,329731,257,213351,237762,63189]

theorem envBound32436 : H12AffineFastState.Bounded env32436 := by
  intro p hp
  have h : env32436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32420_32436 : H12AffineEnvironment.transform 21 272513 env32420 = env32436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32420 == env32436) = true)

theorem identity32436 : scanCanonicalize (H12AffineFastState.compose env32436 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound32436 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58517,272513,62661,41430,8328,64,100831,115150,17664,262280,119042,329731,257,95530,103567,63189]

theorem envBound32437 : H12AffineFastState.Bounded env32437 := by
  intro p hp
  have h : env32437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32436_32437 : H12AffineEnvironment.transform 16 13389 env32436 = env32437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env32436 == env32437) = true)

def env32438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58517,169,62661,41430,8328,64,100831,115150,17664,10400,119042,73771,257,95530,103567,63189]

theorem envBound32438 : H12AffineFastState.Bounded env32438 := by
  intro p hp
  have h : env32438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32437_32438 : H12AffineEnvironment.transform 17 10280 env32437 = env32438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32437 == env32438) = true)

theorem identity32438 : scanCanonicalize (H12AffineFastState.compose env32438 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound32438 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13389,10280,1025,8661,17729,169,21777,2,8328,64,75787,90138,17664,10400,94422,73771,257,95530,79195,22273]

theorem envBound32439 : H12AffineFastState.Bounded env32439 := by
  intro p hp
  have h : env32439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32438_32439 : H12AffineEnvironment.transform 14 8660 env32438 = env32439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env32438 == env32439) = true)

theorem identity32439 : scanCanonicalize (H12AffineFastState.compose env32439 (packedSelected [0,2,5,6,7,11,17,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32439 : packedSelected [0,2,5,6,7,11,17,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8660,65536,13389,10280,1025,8661,12621,169,8477,2,8328,64,75787,70678,12556,10400,66778,73771,257,65830,79195,8973]

theorem envBound32440 : H12AffineFastState.Bounded env32440 := by
  intro p hp
  have h : env32440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32439_32440 : H12AffineEnvironment.transform 13 13324 env32439 = env32440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32439 == env32440) = true)

theorem identity32440 : scanCanonicalize (H12AffineFastState.compose env32440 (packedSelected [3,5,10,16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound32440 : packedSelected [3,5,10,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env32441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8660,478,13389,10280,1025,8661,12621,169,8477,2,8328,64,10709,5576,12556,10400,1284,8693,257,248,13445,8973]

theorem envBound32441 : H12AffineFastState.Bounded env32441 := by
  intro p hp
  have h : env32441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32440_32441 : H12AffineEnvironment.transform 15 478 env32440 = env32441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env32440 == env32441) = true)

theorem identity32441 : scanCanonicalize (H12AffineFastState.compose env32441 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32441 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env32442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5592,0,478,5529,2556,1025,1,4249,169,201,2,348,64,2049,5576,4312,2420,1284,33,257,248,5457,729]

theorem envBound32442 : H12AffineFastState.Bounded env32442 := by
  intro p hp
  have h : env32442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32441_32442 : H12AffineEnvironment.transform 12 468 env32441 = env32442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32441 == env32442) = true)

theorem identity32442 : scanCanonicalize (H12AffineFastState.compose env32442 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 2009) := by decide +kernel

theorem selectedBound32442 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2009,4096,468,5592,0,478,5529,1573,1025,1,4249,169,201,2,348,64,2008,5576,4312,1709,1284,33,257,248,5457,729]

theorem envBound32443 : H12AffineFastState.Bounded env32443 := by
  intro p hp
  have h : env32443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32442_32443 : H12AffineEnvironment.transform 10 2009 env32442 = env32443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2009 env32442 == env32443) = true)

theorem identity32443 : scanCanonicalize (H12AffineFastState.compose env32443 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound32443 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32444 : List Nat := [2,4,8,16,32,64,121,256,512,1024,1824,4096,301,5409,0,295,5472,1573,1025,1,4192,80,48,2,348,64,1825,5425,4129,1620,1284,33,257,1,5457,544]

theorem envBound32444 : H12AffineFastState.Bounded env32444 := by
  intro p hp
  have h : env32444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32443_32444 : H12AffineEnvironment.transform 6 121 env32443 = env32444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env32443 == env32444) = true)

theorem identity32444 : scanCanonicalize (H12AffineFastState.compose env32444 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32444 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32445 : List Nat := [2,4,8,16,0,64,89,256,512,1024,1792,4096,269,5377,0,263,5440,1541,1025,1,4160,80,16,2,348,64,1793,5393,4097,1620,1284,1,257,1,5457,512]

theorem envBound32445 : H12AffineFastState.Bounded env32445 := by
  intro p hp
  have h : env32445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32444_32445 : H12AffineEnvironment.transform 4 0 env32444 = env32445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32444 == env32445) = true)

theorem identity32445 : scanCanonicalize (H12AffineFastState.compose env32445 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32445 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32446 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1792,4096,269,5377,0,263,5392,1541,1025,1,4112,0,16,2,268,16,1793,5393,4097,1540,1284,1,257,1,5377,512]

theorem envBound32446 : H12AffineFastState.Bounded env32446 := by
  intro p hp
  have h : env32446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32445_32446 : H12AffineEnvironment.transform 5 16 env32445 = env32446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32445 == env32446) = true)

theorem identity32446 : scanCanonicalize (H12AffineFastState.compose env32446 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32447 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1541,4096,8,5124,0,2,5141,1541,1025,1,4112,0,16,2,9,16,1540,5140,4097,1540,1025,1,4,1,5124,512]

theorem envBound32447 : H12AffineFastState.Bounded env32447 := by
  intro p hp
  have h : env32447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32446_32447 : H12AffineEnvironment.transform 7 5 env32446 = env32447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32446 == env32447) = true)

theorem identity32447 : scanCanonicalize (H12AffineFastState.compose env32447 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound32447 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32448 : List Nat := [2,4,8,16,0,16,9,5,512,20,529,4096,8,4112,0,2,4097,529,21,1,4112,0,16,2,9,16,528,4096,4097,528,21,1,4,1,4112,512]

theorem envBound32448 : H12AffineFastState.Bounded env32448 := by
  intro p hp
  have h : env32448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32447_32448 : H12AffineEnvironment.transform 9 20 env32447 = env32448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env32447 == env32448) = true)

theorem identity32448 : scanCanonicalize (H12AffineFastState.compose env32448 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound32448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32449 : List Nat := [2,4,8,16,0,16,9,5,512,20,529,17,8,1,0,2,16,529,21,1,1,0,16,2,9,16,528,17,16,528,21,1,4,1,1,512]

theorem envBound32449 : H12AffineFastState.Bounded env32449 := by
  intro p hp
  have h : env32449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32448_32449 : H12AffineEnvironment.transform 11 17 env32448 = env32449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32448 == env32449) = true)

theorem identity32449 : scanCanonicalize (H12AffineFastState.compose env32449 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound32449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32450 : List Nat := [2,4,8,4,0,4,9,5,512,0,517,5,8,1,0,2,4,517,1,1,1,0,4,2,9,4,516,5,4,516,1,1,4,1,1,512]

theorem envBound32450 : H12AffineFastState.Bounded env32450 := by
  intro p hp
  have h : env32450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32449_32450 : H12AffineEnvironment.transform 3 4 env32449 = env32450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env32449 == env32450) = true)

theorem identity32450 : scanCanonicalize (H12AffineFastState.compose env32450 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32450 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32451 : List Nat := [2,4,8,4,0,4,9,5,0,0,5,5,8,1,0,2,4,5,1,1,1,0,4,2,9,4,4,5,4,4,1,1,4,1,1,0]

theorem envBound32451 : H12AffineFastState.Bounded env32451 := by
  intro p hp
  have h : env32451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32450_32451 : H12AffineEnvironment.transform 8 0 env32450 = env32451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32450 == env32451) = true)

theorem identity32451 : scanCanonicalize (H12AffineFastState.compose env32451 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32451 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32452 : List Nat := [2,1,8,1,0,1,9,0,0,0,0,0,8,1,0,2,1,0,1,1,1,0,1,2,9,1,1,0,1,1,1,1,1,1,1,0]

theorem envBound32452 : H12AffineFastState.Bounded env32452 := by
  intro p hp
  have h : env32452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32451_32452 : H12AffineEnvironment.transform 1 1 env32451 = env32452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32451 == env32452) = true)

def env32453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58517,168,62661,41430,8328,64,100831,115150,17664,10401,119042,73770,257,95530,103567,63189]

theorem envBound32453 : H12AffineFastState.Bounded env32453 := by
  intro p hp
  have h : env32453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32437_32453 : H12AffineEnvironment.transform 17 10281 env32437 = env32453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32437 == env32453) = true)

theorem identity32453 : scanCanonicalize (H12AffineFastState.compose env32453 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound32453 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,13389,10281,1025,30112,4404,168,356,21623,8328,64,97406,78959,17664,10401,74915,73770,257,95530,90414,884]

theorem envBound32454 : H12AffineFastState.Bounded env32454 := by
  intro p hp
  have h : env32454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32453_32454 : H12AffineEnvironment.transform 14 30113 env32453 = env32454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env32453 == env32454) = true)

theorem identity32454 : scanCanonicalize (H12AffineFastState.compose env32454 (packedSelected [0,1,7,9,10,11,12,14,15,17,18,20,22,23,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound32454 : packedSelected [0,1,7,9,10,11,12,14,15,17,18,20,22,23,26,28,32] rootPS < 2^1333 := by decide +kernel

def env32455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,9279,13389,10281,1025,30112,4404,168,356,21623,8328,64,22593,4176,17664,10401,156,1045,257,20757,17681,884]

theorem envBound32455 : H12AffineFastState.Bounded env32455 := by
  intro p hp
  have h : env32455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32454_32455 : H12AffineEnvironment.transform 15 9279 env32454 = env32455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env32454 == env32455) = true)

theorem identity32455 : scanCanonicalize (H12AffineFastState.compose env32455 (packedSelected [0,7,8,9,10,12,15,17,18,20,22,23,28,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32455 : packedSelected [0,7,8,9,10,12,15,17,18,20,22,23,28,35] rootPS < 2^1333 := by decide +kernel

def env32456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,508,9279,13389,10281,1025,509,4404,168,356,8234,8328,64,11292,4176,12637,10401,156,1045,257,9544,12620,884]

theorem envBound32456 : H12AffineFastState.Bounded env32456 := by
  intro p hp
  have h : env32456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32455_32456 : H12AffineEnvironment.transform 13 13405 env32455 = env32456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32455 == env32456) = true)

theorem identity32456 : scanCanonicalize (H12AffineFastState.compose env32456 (packedSelected [1,2,3,6,8,9,10,11,14,16,17,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound32456 : packedSelected [1,2,3,6,8,9,10,11,14,16,17,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env32457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1172,4297,508,171,4313,3261,1025,509,4404,168,356,1214,1052,64,2184,4176,5577,3125,156,1045,257,476,5592,884]

theorem envBound32457 : H12AffineFastState.Bounded env32457 := by
  intro p hp
  have h : env32457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32456_32457 : H12AffineEnvironment.transform 12 1172 env32456 = env32457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env32456 == env32457) = true)

theorem identity32457 : scanCanonicalize (H12AffineFastState.compose env32457 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32457 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env32458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4161,372,35,4177,3125,1025,373,4404,32,356,1078,1052,64,2048,4176,5441,3125,20,1045,257,340,5456,884]

theorem envBound32458 : H12AffineFastState.Bounded env32458 := by
  intro p hp
  have h : env32458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32457_32458 : H12AffineEnvironment.transform 6 8 env32457 = env32458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32457 == env32458) = true)

theorem identity32458 : scanCanonicalize (H12AffineFastState.compose env32458 (packedSelected [2,3,4,5,6,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound32458 : packedSelected [2,3,4,5,6,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1076,1052,1141,372,35,1125,3125,1025,373,1280,32,356,1078,1052,64,2048,1124,373,3125,20,1045,257,340,356,884]

theorem envBound32459 : H12AffineFastState.Bounded env32459 := by
  intro p hp
  have h : env32459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32458_32459 : H12AffineEnvironment.transform 11 1076 env32458 = env32459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env32458 == env32459) = true)

theorem identity32459 : scanCanonicalize (H12AffineFastState.compose env32459 (packedSelected [2,3,5,6,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32459 : packedSelected [2,3,5,6,10,16] rootPS < 2^1333 := by decide +kernel

def env32460 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1052,1141,1,35,1125,3125,1025,0,1141,32,17,1078,1052,64,2048,1124,0,3125,20,1045,116,33,17,513]

theorem envBound32460 : H12AffineFastState.Bounded env32460 := by
  intro p hp
  have h : env32460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32459_32460 : H12AffineEnvironment.transform 7 117 env32459 = env32460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32459 == env32460) = true)

def env32461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,169370,8328,64,4691218,115150,17665,262280,119043,4268162,257,213351,237762,63188]

theorem envBound32461 : H12AffineFastState.Bounded env32461 := by
  intro p hp
  have h : env32461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32419_32461 : H12AffineEnvironment.transform 20 184537 env32419 = env32461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env32419 == env32461) = true)

def env32462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,169370,8328,64,245138,115150,17665,262280,119043,329730,257,213351,237762,63188]

theorem envBound32462 : H12AffineFastState.Bounded env32462 := by
  intro p hp
  have h : env32462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32461_32462 : H12AffineEnvironment.transform 21 272512 env32461 = env32462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32461 == env32462) = true)

def env32463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180224,169234,8192,64,245018,115014,17665,262144,119043,329730,257,213351,237642,63068]

theorem envBound32463 : H12AffineFastState.Bounded env32463 := by
  intro p hp
  have h : env32463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32462_32463 : H12AffineEnvironment.transform 6 8 env32462 = env32463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32462 == env32463) = true)

def env32464 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,16,21762,8192,64,97546,115014,17665,262144,119043,329730,257,98679,90202,63068]

theorem envBound32464 : H12AffineFastState.Bounded env32464 := by
  intro p hp
  have h : env32464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32463_32464 : H12AffineEnvironment.transform 16 49168 env32463 = env32464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32463 == env32464) = true)

theorem identity32464 : scanCanonicalize (H12AffineFastState.compose env32464 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32464 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,262144,1025,8540,4161,272392,16,21762,8192,64,97546,90139,17665,262144,94302,329730,257,73770,90202,22273]

theorem envBound32465 : H12AffineFastState.Bounded env32465 := by
  intro p hp
  have h : env32465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32464_32465 : H12AffineEnvironment.transform 14 8541 env32464 = env32465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32464 == env32465) = true)

theorem identity32465 : scanCanonicalize (H12AffineFastState.compose env32465 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound32465 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,2421,1025,8540,4161,8573,16,21762,8192,64,97546,90139,17665,2421,94302,65911,257,73770,90202,22273]

theorem envBound32466 : H12AffineFastState.Bounded env32466 := by
  intro p hp
  have h : env32466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32465_32466 : H12AffineEnvironment.transform 17 2421 env32465 = env32466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env32465 == env32466) = true)

theorem identity32466 : scanCanonicalize (H12AffineFastState.compose env32466 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound32466 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30043,24909,2421,1025,8540,4161,8573,16,21762,8192,64,2129,5440,17665,2421,1285,29740,257,21873,5377,22273]

theorem envBound32467 : H12AffineFastState.Bounded env32467 := by
  intro p hp
  have h : env32467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32466_32467 : H12AffineEnvironment.transform 15 30043 env32466 = env32467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env32466 == env32467) = true)

theorem identity32467 : scanCanonicalize (H12AffineFastState.compose env32467 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32467 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,372,21874,16740,2421,1025,373,4161,340,16,21762,41,64,2129,5440,17665,2421,1285,21509,257,21873,5377,22273]

theorem envBound32468 : H12AffineFastState.Bounded env32468 := by
  intro p hp
  have h : env32468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32467_32468 : H12AffineEnvironment.transform 12 41 env32467 = env32468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32467 == env32468) = true)

theorem identity32468 : scanCanonicalize (H12AffineFastState.compose env32468 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32468 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env32469 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,81,21591,16449,2128,1025,80,4161,113,16,21543,41,64,2129,5221,17444,2128,1056,21509,36,21588,5156,22052]

theorem envBound32469 : H12AffineFastState.Bounded env32469 := by
  intro p hp
  have h : env32469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32468_32469 : H12AffineEnvironment.transform 7 37 env32468 = env32469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32468 == env32469) = true)

theorem identity32469 : scanCanonicalize (H12AffineFastState.compose env32469 (packedSelected [4,5,7,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32469 : packedSelected [4,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env32470 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,41,16384,81,20530,16449,2128,100,80,4161,113,16,20546,41,64,2129,4096,16449,2128,69,20576,36,20529,4161,21057]

theorem envBound32470 : H12AffineFastState.Bounded env32470 := by
  intro p hp
  have h : env32470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32469_32470 : H12AffineEnvironment.transform 9 101 env32469 = env32470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32469 == env32470) = true)

theorem identity32470 : scanCanonicalize (H12AffineFastState.compose env32470 (packedSelected [0,2,3,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 6752) := by decide +kernel

theorem selectedBound32470 : packedSelected [0,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env32471 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,41,6752,81,2642,6689,2128,100,80,4161,113,16,2594,41,64,2129,4096,6689,2128,69,2560,36,2641,4161,2081]

theorem envBound32471 : H12AffineFastState.Bounded env32471 := by
  intro p hp
  have h : env32471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32470_32471 : H12AffineEnvironment.transform 13 6752 env32470 = env32471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6752 env32470 == env32471) = true)

theorem identity32471 : scanCanonicalize (H12AffineFastState.compose env32471 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32471 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32472 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,6705,0,2563,6689,2049,53,1,4112,32,16,2594,41,17,2048,4096,6689,2049,20,2560,36,2560,4112,2081]

theorem envBound32472 : H12AffineFastState.Bounded env32472 := by
  intro p hp
  have h : env32472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32471_32472 : H12AffineEnvironment.transform 5 17 env32471 = env32472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32471 == env32472) = true)

theorem identity32472 : scanCanonicalize (H12AffineFastState.compose env32472 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32472 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32473 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,4096,41,4656,0,514,4640,0,53,1,4112,32,16,547,41,17,1,4096,4640,0,20,513,36,513,4112,32]

theorem envBound32473 : H12AffineFastState.Bounded env32473 := by
  intro p hp
  have h : env32473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32472_32473 : H12AffineEnvironment.transform 10 1 env32472 = env32473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32472 == env32473) = true)

theorem identity32473 : scanCanonicalize (H12AffineFastState.compose env32473 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound32473 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32474 : List Nat := [2,4,8,16,32,17,8,37,32,52,1,4096,41,4112,0,34,4096,0,53,1,4112,32,16,3,41,17,1,4096,4096,0,20,33,36,33,4112,32]

theorem envBound32474 : H12AffineFastState.Bounded env32474 := by
  intro p hp
  have h : env32474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32473_32474 : H12AffineEnvironment.transform 8 32 env32473 = env32474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env32473 == env32474) = true)

theorem identity32474 : scanCanonicalize (H12AffineFastState.compose env32474 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32475 : List Nat := [2,4,8,16,17,17,8,20,17,5,1,4096,24,4112,0,19,4096,0,4,1,4112,17,16,3,24,17,1,4096,4096,0,20,16,21,16,4112,17]

theorem envBound32475 : H12AffineFastState.Bounded env32475 := by
  intro p hp
  have h : env32475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32474_32475 : H12AffineEnvironment.transform 4 17 env32474 = env32475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32474 == env32475) = true)

theorem identity32475 : scanCanonicalize (H12AffineFastState.compose env32475 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound32475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32476 : List Nat := [2,4,6,16,17,17,6,20,17,5,1,4096,22,4112,0,19,4096,0,4,1,4112,17,16,3,22,17,1,4096,4096,0,20,16,21,16,4112,17]

theorem envBound32476 : H12AffineFastState.Bounded env32476 := by
  intro p hp
  have h : env32476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32475_32476 : H12AffineEnvironment.transform 2 6 env32475 = env32476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env32475 == env32476) = true)

theorem identity32476 : scanCanonicalize (H12AffineFastState.compose env32476 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32476 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32477 : List Nat := [2,4,6,1,0,0,6,5,0,5,1,4096,7,4097,0,2,4096,0,4,1,4097,0,1,3,7,0,1,4096,4096,0,5,1,4,1,4097,0]

theorem envBound32477 : H12AffineFastState.Bounded env32477 := by
  intro p hp
  have h : env32477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32476_32477 : H12AffineEnvironment.transform 3 1 env32476 = env32477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32476 == env32477) = true)

theorem identity32477 : scanCanonicalize (H12AffineFastState.compose env32477 (packedSelected [7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32477 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32478 : List Nat := [2,4,6,1,0,0,6,5,0,5,1,1,7,0,0,2,1,0,4,1,0,0,1,3,7,0,1,1,1,0,5,1,4,1,0,0]

theorem envBound32478 : H12AffineFastState.Bounded env32478 := by
  intro p hp
  have h : env32478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32477_32478 : H12AffineEnvironment.transform 11 1 env32477 = env32478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32477 == env32478) = true)

def env32479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21763,8192,64,97547,115014,17665,262144,119043,329730,257,98678,90203,63068]

theorem envBound32479 : H12AffineFastState.Bounded env32479 := by
  intro p hp
  have h : env32479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32463_32479 : H12AffineEnvironment.transform 16 49169 env32463 = env32479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32463 == env32479) = true)

theorem identity32479 : scanCanonicalize (H12AffineFastState.compose env32479 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,4160,41340,17,21763,8192,64,97547,115014,17665,35188,119043,98678,257,98678,90203,63068]

theorem envBound32480 : H12AffineFastState.Bounded env32480 := by
  intro p hp
  have h : env32480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32479_32480 : H12AffineEnvironment.transform 17 35188 env32479 = env32480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32479 == env32480) = true)

theorem identity32480 : scanCanonicalize (H12AffineFastState.compose env32480 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound32480 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env32481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,65536,13672,31757,1025,30072,4160,21509,17,21763,8192,64,97547,78911,17665,31757,74874,95247,257,95247,90203,805]

theorem envBound32481 : H12AffineFastState.Bounded env32481 := by
  intro p hp
  have h : env32481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32480_32481 : H12AffineEnvironment.transform 14 30073 env32480 = env32481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env32480 == env32481) = true)

theorem identity32481 : scanCanonicalize (H12AffineFastState.compose env32481 (packedSelected [0,3,4,5,7,10,12,15,18,19,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound32481 : packedSelected [0,3,4,5,7,10,12,15,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env32482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,263,13672,31757,1025,30072,4160,21509,17,21763,8192,64,31756,13624,17665,31757,9597,29960,257,29960,24924,805]

theorem envBound32482 : H12AffineFastState.Bounded env32482 := by
  intro p hp
  have h : env32482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32481_32482 : H12AffineEnvironment.transform 15 263 env32481 = env32482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env32481 == env32482) = true)

theorem identity32482 : scanCanonicalize (H12AffineFastState.compose env32482 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32482 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env32483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21841,263,5440,23589,1025,21840,4160,21509,17,21763,40,64,23588,5392,17665,23589,1365,21792,257,21792,16756,805]

theorem envBound32483 : H12AffineFastState.Bounded env32483 := by
  intro p hp
  have h : env32483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32482_32483 : H12AffineEnvironment.transform 12 40 env32482 = env32483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32482 == env32483) = true)

theorem identity32483 : scanCanonicalize (H12AffineFastState.compose env32483 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound32483 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env32484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,277,40,16384,17476,263,1109,19760,1025,17477,341,17680,17,17430,40,64,19761,1029,17665,19760,1365,17461,257,17461,16756,805]

theorem envBound32484 : H12AffineFastState.Bounded env32484 := by
  intro p hp
  have h : env32484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32483_32484 : H12AffineEnvironment.transform 11 277 env32483 = env32484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env32483 == env32484) = true)

theorem identity32484 : scanCanonicalize (H12AffineFastState.compose env32484 (packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound32484 : packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env32485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,277,40,1344,260,263,1109,2160,1025,261,341,80,17,342,40,64,2161,1029,65,2160,1365,373,257,373,1076,805]

theorem envBound32485 : H12AffineFastState.Bounded env32485 := by
  intro p hp
  have h : env32485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32484_32485 : H12AffineEnvironment.transform 13 1344 env32484 = env32485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env32484 == env32485) = true)

theorem identity32485 : scanCanonicalize (H12AffineFastState.compose env32485 (packedSelected [2,6,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32485 : packedSelected [2,6,15] rootPS < 2^1333 := by decide +kernel

def env32486 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,96,40,1077,113,114,1109,2160,1025,112,32,80,17,35,40,64,2161,1029,65,2160,1056,0,116,0,1076,592]

theorem envBound32486 : H12AffineFastState.Bounded env32486 := by
  intro p hp
  have h : env32486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32485_32486 : H12AffineEnvironment.transform 7 117 env32485 = env32486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32485 == env32486) = true)

theorem identity32486 : scanCanonicalize (H12AffineFastState.compose env32486 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32486 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32487 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1077,32,35,1028,2081,1025,33,32,1,17,35,40,17,2080,1029,16,2081,1056,0,37,0,1076,513]

end H12CloudChart0