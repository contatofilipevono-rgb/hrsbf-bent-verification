import H12CloudChart0Data137

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans35023_35024 : H12AffineEnvironment.transform 14 8540 env35023 = env35024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35023 == env35024) = true)

theorem identity35024 : scanCanonicalize (H12AffineFastState.compose env35024 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound35024 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10361,1024,8541,77898,32,16,73737,8192,64,146461,79131,77835,138292,1364,73771,256,73771,79194,74250]

theorem envBound35025 : H12AffineFastState.Bounded env35025 := by
  intro p hp
  have h : env35025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35024_35025 : H12AffineEnvironment.transform 17 10361 env35024 = env35025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env35024 == env35025) = true)

theorem identity35025 : scanCanonicalize (H12AffineFastState.compose env35025 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound35025 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,10361,1024,8541,77898,32,16,73737,8192,64,67846,79131,77835,76079,1364,73771,256,73771,79194,74250]

theorem envBound35026 : H12AffineFastState.Bounded env35026 := by
  intro p hp
  have h : env35026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35025_35026 : H12AffineEnvironment.transform 16 79131 env35025 = env35026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env35025 == env35026) = true)

theorem identity35026 : scanCanonicalize (H12AffineFastState.compose env35026 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35026 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env35027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,115,13672,10361,1024,8541,12345,32,16,8314,8192,64,2421,13672,12408,10588,1364,8280,256,8280,13609,8825]

theorem envBound35027 : H12AffineFastState.Bounded env35027 := by
  intro p hp
  have h : env35027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35026_35027 : H12AffineEnvironment.transform 15 115 env35026 = env35027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35026 == env35027) = true)

theorem identity35027 : scanCanonicalize (H12AffineFastState.compose env35027 (packedSelected [0,3,5,7,10,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35027 : packedSelected [0,3,5,7,10,11,16] rootPS < 2^1333 := by decide +kernel

def env35028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,5377,8540,115,13672,8313,1024,8541,12345,32,16,8314,8192,64,373,13672,12408,8540,1364,8280,256,8280,13609,8825]

theorem envBound35028 : H12AffineFastState.Bounded env35028 := by
  intro p hp
  have h : env35028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35027_35028 : H12AffineEnvironment.transform 10 0 env35027 = env35028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35027 == env35028) = true)

theorem identity35028 : scanCanonicalize (H12AffineFastState.compose env35028 (packedSelected [0,3,5,7,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound35028 : packedSelected [0,3,5,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,4136,5377,4468,115,1344,4177,1024,4469,17,32,16,4178,4136,64,373,1344,80,4468,1364,4208,256,4208,1281,4689]

theorem envBound35029 : H12AffineFastState.Bounded env35029 := by
  intro p hp
  have h : env35029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35028_35029 : H12AffineEnvironment.transform 12 4136 env35028 = env35029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env35028 == env35029) = true)

theorem identity35029 : scanCanonicalize (H12AffineFastState.compose env35029 (packedSelected [2,3,4,5,6,9,10,14,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound35029 : packedSelected [2,3,4,5,6,9,10,14,18,20] rootPS < 2^1333 := by decide +kernel

def env35030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,293,269,1060,81,115,1344,372,1024,80,17,32,16,375,269,64,373,1344,80,81,1364,341,256,341,1281,884]

theorem envBound35030 : H12AffineFastState.Bounded env35030 := by
  intro p hp
  have h : env35030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35029_35030 : H12AffineEnvironment.transform 11 293 env35029 = env35030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env35029 == env35030) = true)

theorem identity35030 : scanCanonicalize (H12AffineFastState.compose env35030 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35030 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35031 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,80,120,1060,81,115,1077,1,1024,80,17,32,16,2,120,64,0,1077,80,81,1057,32,117,32,1140,513]

theorem envBound35031 : H12AffineFastState.Bounded env35031 := by
  intro p hp
  have h : env35031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35030_35031 : H12AffineEnvironment.transform 7 117 env35030 = env35031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35030 == env35031) = true)

theorem identity35031 : scanCanonicalize (H12AffineFastState.compose env35031 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound35031 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35032 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,80,120,65,81,115,80,1,101,80,17,32,16,2,120,64,0,80,80,81,68,32,117,32,17,513]

theorem envBound35032 : H12AffineFastState.Bounded env35032 := by
  intro p hp
  have h : env35032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35031_35032 : H12AffineEnvironment.transform 9 101 env35031 = env35032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env35031 == env35032) = true)

theorem identity35032 : scanCanonicalize (H12AffineFastState.compose env35032 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35033 : List Nat := [2,4,8,16,32,64,8,117,16,101,0,80,120,65,81,115,80,1,101,80,17,32,16,2,120,64,0,80,80,81,68,32,117,32,17,17]

theorem envBound35033 : H12AffineFastState.Bounded env35033 := by
  intro p hp
  have h : env35033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35032_35033 : H12AffineEnvironment.transform 8 16 env35032 = env35033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35032 == env35033) = true)

theorem identity35033 : scanCanonicalize (H12AffineFastState.compose env35033 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound35033 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35034 : List Nat := [2,4,8,16,32,33,8,20,16,4,0,49,25,32,48,18,49,1,4,49,17,32,16,2,25,33,0,49,49,48,37,32,20,32,17,17]

theorem envBound35034 : H12AffineFastState.Bounded env35034 := by
  intro p hp
  have h : env35034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35033_35034 : H12AffineEnvironment.transform 5 33 env35033 = env35034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env35033 == env35034) = true)

theorem identity35034 : scanCanonicalize (H12AffineFastState.compose env35034 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35034 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35035 : List Nat := [2,4,8,16,17,16,8,20,16,4,0,0,25,17,1,18,0,1,4,0,17,17,16,2,25,16,0,0,0,1,20,17,20,17,17,17]

theorem envBound35035 : H12AffineFastState.Bounded env35035 := by
  intro p hp
  have h : env35035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35034_35035 : H12AffineEnvironment.transform 4 17 env35034 = env35035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35034 == env35035) = true)

theorem identity35035 : scanCanonicalize (H12AffineFastState.compose env35035 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35036 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,0,8,0,1,3,0,1,4,0,0,0,1,2,8,1,0,0,0,1,5,0,5,0,0,0]

theorem envBound35036 : H12AffineFastState.Bounded env35036 := by
  intro p hp
  have h : env35036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35035_35036 : H12AffineEnvironment.transform 3 1 env35035 = env35036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35035 == env35036) = true)

def env35037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,17,98645,8192,64,398437,79131,77834,431376,1365,98679,256,73770,103431,74251]

theorem envBound35037 : H12AffineFastState.Bounded env35037 := by
  intro p hp
  have h : env35037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35022_35037 : H12AffineEnvironment.transform 22 17 env35022 = env35037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env35022 == env35037) = true)

theorem identity35037 : scanCanonicalize (H12AffineFastState.compose env35037 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound35037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,77898,32,17,98645,8192,64,171280,79131,77834,138341,1365,98679,256,73770,103431,74251]

theorem envBound35038 : H12AffineFastState.Bounded env35038 := by
  intro p hp
  have h : env35038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35037_35038 : H12AffineEnvironment.transform 17 35189 env35037 = env35038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env35037 == env35038) = true)

theorem identity35038 : scanCanonicalize (H12AffineFastState.compose env35038 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35038 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,131072,35189,1024,32769,4160,32,17,41311,8192,64,171280,5393,4096,138341,1365,41341,256,32,46093,513]

theorem envBound35039 : H12AffineFastState.Bounded env35039 := by
  intro p hp
  have h : env35039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35038_35039 : H12AffineEnvironment.transform 15 8202 env35038 = env35039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35038 == env35039) = true)

theorem identity35039 : scanCanonicalize (H12AffineFastState.compose env35039 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12637) := by decide +kernel

theorem selectedBound35039 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,12637,35189,1024,32769,4160,32,17,41311,8192,64,44109,5393,4096,11576,1365,41341,256,32,46093,513]

theorem envBound35040 : H12AffineFastState.Bounded env35040 := by
  intro p hp
  have h : env35040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35039_35040 : H12AffineEnvironment.transform 16 12637 env35039 = env35040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12637 env35039 == env35040) = true)

theorem identity35040 : scanCanonicalize (H12AffineFastState.compose env35040 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound35040 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env35041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1094,5393,35189,1024,32769,4160,32,17,34067,1100,64,34817,5393,4096,2420,1365,34097,256,32,36929,513]

theorem envBound35041 : H12AffineFastState.Bounded env35041 := by
  intro p hp
  have h : env35041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35040_35041 : H12AffineEnvironment.transform 12 1100 env35040 = env35041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env35040 == env35041) = true)

theorem identity35041 : scanCanonicalize (H12AffineFastState.compose env35041 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound35041 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,513,1100,1792,32768,1094,1808,35189,1024,32769,577,32,17,34067,1100,64,34817,1808,513,2420,1365,34097,256,32,33344,513]

theorem envBound35042 : H12AffineFastState.Bounded env35042 := by
  intro p hp
  have h : env35042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35041_35042 : H12AffineEnvironment.transform 11 513 env35041 = env35042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env35041 == env35042) = true)

theorem identity35042 : scanCanonicalize (H12AffineFastState.compose env35042 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound35042 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,513,1100,1792,1297,1094,1808,3172,1024,1296,577,32,17,2,1100,64,3344,1808,513,2420,1365,32,256,32,1873,513]

theorem envBound35043 : H12AffineFastState.Bounded env35043 := by
  intro p hp
  have h : env35043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35042_35043 : H12AffineEnvironment.transform 14 1297 env35042 = env35043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env35042 == env35043) = true)

theorem identity35043 : scanCanonicalize (H12AffineFastState.compose env35043 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35043 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35044 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,513,121,821,292,115,805,2129,53,293,577,32,17,2,121,64,2341,805,513,2420,352,32,256,32,868,513]

theorem envBound35044 : H12AffineFastState.Bounded env35044 := by
  intro p hp
  have h : env35044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35043_35044 : H12AffineEnvironment.transform 9 53 env35043 = env35044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35043 == env35044) = true)

def env35045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,8388608,98645,8193,64,8787060,79131,8466458,8819969,8389956,98679,256,8462395,8492055,8462875]

theorem envBound35045 : H12AffineFastState.Bounded env35045 := by
  intro p hp
  have h : env35045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35021_35045 : H12AffineEnvironment.transform 6 9 env35021 = env35045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35021 == env35045) = true)

def env35046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,16,98645,8193,64,398436,79131,77834,431377,1364,98679,256,73771,103431,74251]

theorem envBound35046 : H12AffineFastState.Bounded env35046 := by
  intro p hp
  have h : env35046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35045_35046 : H12AffineEnvironment.transform 22 16 env35045 = env35046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env35045 == env35046) = true)

theorem identity35046 : scanCanonicalize (H12AffineFastState.compose env35046 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35046 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env35047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398436,5393,4096,431377,1364,41341,256,33,46093,513]

theorem envBound35047 : H12AffineFastState.Bounded env35047 := by
  intro p hp
  have h : env35047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35046_35047 : H12AffineEnvironment.transform 15 8202 env35046 = env35047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35046 == env35047) = true)

theorem identity35047 : scanCanonicalize (H12AffineFastState.compose env35047 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35047 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398436,5393,4096,406605,1364,33,256,33,5457,513]

theorem envBound35048 : H12AffineFastState.Bounded env35048 := by
  intro p hp
  have h : env35048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35047_35048 : H12AffineEnvironment.transform 14 8540 env35047 = env35048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35047 == env35048) = true)

theorem identity35048 : scanCanonicalize (H12AffineFastState.compose env35048 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35048 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35049 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,32,16,3,8193,16,398388,5393,4096,406557,1284,33,256,33,5377,513]

theorem envBound35049 : H12AffineFastState.Bounded env35049 := by
  intro p hp
  have h : env35049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35048_35049 : H12AffineEnvironment.transform 5 16 env35048 = env35049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35048 == env35049) = true)

theorem identity35049 : scanCanonicalize (H12AffineFastState.compose env35049 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound35049 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35050 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1024,8461,4113,32,16,3,8193,16,146461,5393,4096,138292,1284,33,256,33,5377,513]

theorem envBound35050 : H12AffineFastState.Bounded env35050 := by
  intro p hp
  have h : env35050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35049_35050 : H12AffineEnvironment.transform 17 10281 env35049 = env35050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35049 == env35050) = true)

theorem identity35050 : scanCanonicalize (H12AffineFastState.compose env35050 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35050 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35051 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,131072,2341,1024,1,4113,32,16,3,269,16,138513,5393,4096,138292,1284,33,256,33,5377,513]

theorem envBound35051 : H12AffineFastState.Bounded env35051 := by
  intro p hp
  have h : env35051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35050_35051 : H12AffineEnvironment.transform 12 268 env35050 = env35051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35050 == env35051) = true)

theorem identity35051 : scanCanonicalize (H12AffineFastState.compose env35051 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35051 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35052 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4113,0,262,131072,2341,272,1,4113,32,16,3,269,16,137217,4097,4096,137508,20,33,256,33,4113,513]

theorem envBound35052 : H12AffineFastState.Bounded env35052 := by
  intro p hp
  have h : env35052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35051_35052 : H12AffineEnvironment.transform 9 272 env35051 = env35052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35051 == env35052) = true)

theorem identity35052 : scanCanonicalize (H12AffineFastState.compose env35052 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound35052 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35053 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4113,0,262,4097,2341,272,1,4113,32,16,3,269,16,2048,4097,4096,2341,20,33,256,33,4113,513]

theorem envBound35053 : H12AffineFastState.Bounded env35053 := by
  intro p hp
  have h : env35053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35052_35053 : H12AffineEnvironment.transform 16 4097 env35052 = env35053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env35052 == env35053) = true)

theorem identity35053 : scanCanonicalize (H12AffineFastState.compose env35053 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35053 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35054 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,0,35,4097,2048,53,1,4113,32,16,3,40,16,2048,4097,4096,2048,20,33,37,33,4113,513]

theorem envBound35054 : H12AffineFastState.Bounded env35054 := by
  intro p hp
  have h : env35054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35053_35054 : H12AffineEnvironment.transform 7 37 env35053 = env35054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35053 == env35054) = true)

theorem identity35054 : scanCanonicalize (H12AffineFastState.compose env35054 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound35054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35055 : List Nat := [2,4,8,16,32,16,9,37,512,53,528,4096,41,4113,0,35,4097,528,53,1,4113,32,16,3,40,16,528,4097,4096,528,20,33,37,33,4113,513]

theorem envBound35055 : H12AffineFastState.Bounded env35055 := by
  intro p hp
  have h : env35055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35054_35055 : H12AffineEnvironment.transform 10 528 env35054 = env35055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env35054 == env35055) = true)

theorem identity35055 : scanCanonicalize (H12AffineFastState.compose env35055 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound35055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35056 : List Nat := [2,4,8,16,32,16,9,37,512,53,528,571,41,554,0,35,570,528,53,1,554,32,16,3,40,16,528,570,571,528,20,33,37,33,554,513]

theorem envBound35056 : H12AffineFastState.Bounded env35056 := by
  intro p hp
  have h : env35056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35055_35056 : H12AffineEnvironment.transform 11 571 env35055 = env35056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env35055 == env35056) = true)

def env35057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,17,98645,8193,64,398437,79131,77835,431376,1365,98679,256,73770,103430,74250]

theorem envBound35057 : H12AffineFastState.Bounded env35057 := by
  intro p hp
  have h : env35057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35045_35057 : H12AffineEnvironment.transform 22 17 env35045 = env35057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env35045 == env35057) = true)

theorem identity35057 : scanCanonicalize (H12AffineFastState.compose env35057 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35057 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,77899,32,17,98645,8193,64,146509,79131,77835,179512,1365,98679,256,73770,103430,74250]

theorem envBound35058 : H12AffineFastState.Bounded env35058 := by
  intro p hp
  have h : env35058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35057_35058 : H12AffineEnvironment.transform 17 10280 env35057 = env35058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35057 == env35058) = true)

def env35059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787061,79131,8466579,8819969,8389956,98678,256,8462395,8492190,8462994]

theorem envBound35059 : H12AffineFastState.Bounded env35059 := by
  intro p hp
  have h : env35059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35020_35059 : H12AffineEnvironment.transform 21 33 env35020 = env35059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35020 == env35059) = true)

theorem identity35059 : scanCanonicalize (H12AffineFastState.compose env35059 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound35059 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,16,98645,8328,64,398437,79131,77955,431377,1364,98678,256,73771,103566,74370]

theorem envBound35060 : H12AffineFastState.Bounded env35060 := by
  intro p hp
  have h : env35060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35059_35060 : H12AffineEnvironment.transform 22 16 env35059 = env35060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env35059 == env35060) = true)

def env35061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,16,98645,8192,64,398437,79131,77835,431377,1364,98678,256,73771,103430,74250]

theorem envBound35061 : H12AffineFastState.Bounded env35061 := by
  intro p hp
  have h : env35061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35060_35061 : H12AffineEnvironment.transform 6 8 env35060 = env35061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35060 == env35061) = true)

theorem identity35061 : scanCanonicalize (H12AffineFastState.compose env35061 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35061 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,33,16,73737,8192,64,398437,79131,77835,406605,1364,73770,256,73771,79194,74250]

theorem envBound35062 : H12AffineFastState.Bounded env35062 := by
  intro p hp
  have h : env35062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35061_35062 : H12AffineEnvironment.transform 14 8540 env35061 = env35062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35061 == env35062) = true)

theorem identity35062 : scanCanonicalize (H12AffineFastState.compose env35062 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound35062 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,138293,1024,8541,77898,33,16,73737,8192,64,2128,79131,77835,10360,1364,73770,256,73771,79194,74250]

theorem envBound35063 : H12AffineFastState.Bounded env35063 := by
  intro p hp
  have h : env35063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35062_35063 : H12AffineEnvironment.transform 17 138293 env35062 = env35063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env35062 == env35063) = true)

theorem identity35063 : scanCanonicalize (H12AffineFastState.compose env35063 (packedSelected [0,7,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound35063 : packedSelected [0,7,11,15,20] rootPS < 2^1333 := by decide +kernel

def env35064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,1094,131072,138293,1024,8541,13324,33,16,9295,8192,64,2128,12637,13389,10360,1364,9324,256,9325,12572,9804]

theorem envBound35064 : H12AffineFastState.Bounded env35064 := by
  intro p hp
  have h : env35064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35063_35064 : H12AffineEnvironment.transform 15 1094 env35063 = env35064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env35063 == env35064) = true)

theorem identity35064 : scanCanonicalize (H12AffineFastState.compose env35064 (packedSelected [0,2,4,5,6,7,9,12,14,15,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound35064 : packedSelected [0,2,4,5,6,7,9,12,14,15,19,24] rootPS < 2^1333 := by decide +kernel

def env35065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1124,1094,131072,138293,1024,1125,4404,33,16,375,1336,64,2128,5221,4469,3392,1364,340,256,341,5156,884]

theorem envBound35065 : H12AffineFastState.Bounded env35065 := by
  intro p hp
  have h : env35065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35064_35065 : H12AffineEnvironment.transform 12 1336 env35064 = env35065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env35064 == env35065) = true)

theorem identity35065 : scanCanonicalize (H12AffineFastState.compose env35065 (packedSelected [2,4,6,9,11,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35065 : packedSelected [2,4,6,9,11,14,16] rootPS < 2^1333 := by decide +kernel

def env35066 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1124,1094,131072,138293,1024,1125,4161,33,16,2,1101,64,2128,5221,4096,3125,1057,33,117,32,5156,513]

theorem envBound35066 : H12AffineFastState.Bounded env35066 := by
  intro p hp
  have h : env35066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35065_35066 : H12AffineEnvironment.transform 7 117 env35065 = env35066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35065 == env35066) = true)

theorem identity35066 : scanCanonicalize (H12AffineFastState.compose env35066 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound35066 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35067 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1124,1094,4176,3173,1024,1125,4161,33,16,2,1101,64,2128,5221,4096,3125,1057,33,117,32,5156,513]

theorem envBound35067 : H12AffineFastState.Bounded env35067 := by
  intro p hp
  have h : env35067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35066_35067 : H12AffineEnvironment.transform 16 4176 env35066 = env35067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env35066 == env35067) = true)

theorem identity35067 : scanCanonicalize (H12AffineFastState.compose env35067 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound35067 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35068 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,1101,1124,1124,1094,64,3173,1024,1125,81,33,16,2,1101,64,2128,1141,16,3125,1057,33,117,32,1076,513]

theorem envBound35068 : H12AffineFastState.Bounded env35068 := by
  intro p hp
  have h : env35068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35067_35068 : H12AffineEnvironment.transform 11 16 env35067 = env35068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env35067 == env35068) = true)

theorem identity35068 : scanCanonicalize (H12AffineFastState.compose env35068 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35068 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env35069 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,16,41,0,0,34,64,2049,100,1,81,33,16,2,41,64,2128,17,16,2129,69,33,117,32,80,513]

theorem envBound35069 : H12AffineFastState.Bounded env35069 := by
  intro p hp
  have h : env35069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35068_35069 : H12AffineEnvironment.transform 9 100 env35068 = env35069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35068 == env35069) = true)

theorem identity35069 : scanCanonicalize (H12AffineFastState.compose env35069 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound35069 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35070 : List Nat := [2,4,8,16,32,64,8,117,512,100,81,16,41,0,0,34,64,80,100,1,81,33,16,2,41,64,1,17,16,0,69,33,117,32,80,513]

theorem envBound35070 : H12AffineFastState.Bounded env35070 := by
  intro p hp
  have h : env35070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35069_35070 : H12AffineEnvironment.transform 10 81 env35069 = env35070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env35069 == env35070) = true)

def env35071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,33,16,98645,8193,64,398437,79131,77834,431377,1364,98678,256,73771,103431,74251]

theorem envBound35071 : H12AffineFastState.Bounded env35071 := by
  intro p hp
  have h : env35071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35060_35071 : H12AffineEnvironment.transform 6 9 env35060 = env35071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35060 == env35071) = true)

theorem identity35071 : scanCanonicalize (H12AffineFastState.compose env35071 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35071 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env35072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398437,5393,4096,431377,1364,41340,256,33,46093,513]

theorem envBound35072 : H12AffineFastState.Bounded env35072 := by
  intro p hp
  have h : env35072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35071_35072 : H12AffineEnvironment.transform 15 8202 env35071 = env35072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35071 == env35072) = true)

theorem identity35072 : scanCanonicalize (H12AffineFastState.compose env35072 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35072 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398437,5393,4096,406605,1364,32,256,33,5457,513]

theorem envBound35073 : H12AffineFastState.Bounded env35073 := by
  intro p hp
  have h : env35073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35072_35073 : H12AffineEnvironment.transform 14 8540 env35072 = env35073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35072 == env35073) = true)

theorem identity35073 : scanCanonicalize (H12AffineFastState.compose env35073 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35073 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35074 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,33,16,3,8193,16,398389,5393,4096,406557,1284,32,256,33,5377,513]

theorem envBound35074 : H12AffineFastState.Bounded env35074 := by
  intro p hp
  have h : env35074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35073_35074 : H12AffineEnvironment.transform 5 16 env35073 = env35074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35073 == env35074) = true)

theorem identity35074 : scanCanonicalize (H12AffineFastState.compose env35074 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound35074 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35075 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,138293,1024,8461,4113,33,16,3,8193,16,2048,5393,4096,10280,1284,32,256,33,5377,513]

theorem envBound35075 : H12AffineFastState.Bounded env35075 := by
  intro p hp
  have h : env35075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35074_35075 : H12AffineEnvironment.transform 17 138293 env35074 = env35075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env35074 == env35075) = true)

theorem identity35075 : scanCanonicalize (H12AffineFastState.compose env35075 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35075 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35076 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,13341,10280,1024,8461,4113,33,16,3,8193,16,2048,5393,4096,10280,1284,32,256,33,5377,513]

theorem envBound35076 : H12AffineFastState.Bounded env35076 := by
  intro p hp
  have h : env35076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35075_35076 : H12AffineEnvironment.transform 16 13341 env35075 = env35076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env35075 == env35076) = true)

theorem identity35076 : scanCanonicalize (H12AffineFastState.compose env35076 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35076 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35077 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1024,1,4113,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound35077 : H12AffineFastState.Bounded env35077 := by
  intro p hp
  have h : env35077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35076_35077 : H12AffineEnvironment.transform 12 268 env35076 = env35077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35076 == env35077) = true)

theorem identity35077 : scanCanonicalize (H12AffineFastState.compose env35077 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35078 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5172,2049,1024,1,4113,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound35078 : H12AffineFastState.Bounded env35078 := by
  intro p hp
  have h : env35078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35077_35078 : H12AffineEnvironment.transform 7 37 env35077 = env35078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35077 == env35078) = true)

def env35079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119893,8328,64,12981333,79130,8466579,8830976,8409156,4314199,256,8484155,8492191,8484754]

theorem envBound35079 : H12AffineFastState.Bounded env35079 := by
  intro p hp
  have h : env35079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34956_35079 : H12AffineEnvironment.transform 23 119893 env34956 = env35079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119893 env34956 == env35079) = true)

def env35080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981333,79130,8466579,8819968,8389956,4292951,256,8462395,8492191,8462994]

theorem envBound35080 : H12AffineFastState.Bounded env35080 := by
  intro p hp
  have h : env35080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35079_35080 : H12AffineEnvironment.transform 13 5376 env35079 = env35080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35079 == env35080) = true)

def env35081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787061,79130,8466579,8819968,8389956,98679,256,8462395,8492191,8462994]

theorem envBound35081 : H12AffineFastState.Bounded env35081 := by
  intro p hp
  have h : env35081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35080_35081 : H12AffineEnvironment.transform 21 32 env35080 = env35081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35080 == env35081) = true)

theorem identity35081 : scanCanonicalize (H12AffineFastState.compose env35081 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound35081 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,73875,98645,8328,64,472294,79130,4096,505235,75223,98679,256,168,46092,513]

theorem envBound35082 : H12AffineFastState.Bounded env35082 := by
  intro p hp
  have h : env35082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35081_35082 : H12AffineEnvironment.transform 22 73875 env35081 = env35082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env35081 == env35082) = true)

def env35083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98645,8192,64,472174,79130,4096,505115,75103,98679,256,32,46092,513]

theorem envBound35083 : H12AffineFastState.Bounded env35083 := by
  intro p hp
  have h : env35083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35082_35083 : H12AffineEnvironment.transform 6 8 env35082 = env35083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35082 == env35083) = true)

theorem identity35083 : scanCanonicalize (H12AffineFastState.compose env35083 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound35083 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,77899,32,73755,98645,8192,64,262516,79130,4096,294913,75103,98679,256,32,46092,513]

theorem envBound35084 : H12AffineFastState.Bounded env35084 := by
  intro p hp
  have h : env35084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35083_35084 : H12AffineEnvironment.transform 16 79130 env35083 = env35084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env35083 == env35084) = true)

theorem identity35084 : scanCanonicalize (H12AffineFastState.compose env35084 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33862) := by decide +kernel

theorem selectedBound35084 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33862,45404,262144,1024,32769,46093,32,42077,1299,8192,64,262516,45404,4096,294913,41241,1329,256,32,46092,513]

theorem envBound35085 : H12AffineFastState.Bounded env35085 := by
  intro p hp
  have h : env35085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35084_35085 : H12AffineEnvironment.transform 15 33862 env35084 = env35085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33862 env35084 == env35085) = true)

theorem identity35085 : scanCanonicalize (H12AffineFastState.compose env35085 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(17+1) ^^^ 44109) := by decide +kernel

theorem selectedBound35085 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env35086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33862,45404,44109,1024,32769,46093,32,42077,1299,8192,64,44345,45404,4096,11340,41241,1329,256,32,46092,513]

theorem envBound35086 : H12AffineFastState.Bounded env35086 := by
  intro p hp
  have h : env35086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35085_35086 : H12AffineEnvironment.transform 17 44109 env35085 = env35086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44109 env35085 == env35086) = true)

theorem identity35086 : scanCanonicalize (H12AffineFastState.compose env35086 (packedSelected [3,5,10,11,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound35086 : packedSelected [3,5,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env35087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1345,263,13341,10508,1024,1344,12620,32,8476,1299,8192,64,10360,13341,4096,11340,9304,1329,256,32,12621,513]

theorem envBound35087 : H12AffineFastState.Bounded env35087 := by
  intro p hp
  have h : env35087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35086_35087 : H12AffineEnvironment.transform 14 1345 env35086 = env35087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env35086 == env35087) = true)

theorem identity35087 : scanCanonicalize (H12AffineFastState.compose env35087 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound35087 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env35088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,1345,263,4389,3124,1024,1344,5236,32,1060,1299,1336,64,3392,4389,4096,2420,352,1329,256,32,5237,513]

theorem envBound35088 : H12AffineFastState.Bounded env35088 := by
  intro p hp
  have h : env35088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35087_35088 : H12AffineEnvironment.transform 12 1336 env35087 = env35088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env35087 == env35088) = true)

theorem identity35088 : scanCanonicalize (H12AffineFastState.compose env35088 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound35088 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1336,65,1345,263,1124,3124,1024,1344,309,32,1060,1299,1336,64,3392,1124,1345,2420,352,1329,256,32,308,513]

theorem envBound35089 : H12AffineFastState.Bounded env35089 := by
  intro p hp
  have h : env35089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35088_35089 : H12AffineEnvironment.transform 11 1345 env35088 = env35089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35088 == env35089) = true)

theorem identity35089 : scanCanonicalize (H12AffineFastState.compose env35089 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35089 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env35090 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1101,65,1076,114,1124,3124,1024,1077,64,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,65,513]

theorem envBound35090 : H12AffineFastState.Bounded env35090 := by
  intro p hp
  have h : env35090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35089_35090 : H12AffineEnvironment.transform 7 117 env35089 = env35090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35089 == env35090) = true)

theorem identity35090 : scanCanonicalize (H12AffineFastState.compose env35090 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound35090 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env35091 : List Nat := [2,4,8,16,32,64,8,117,81,1024,2048,1076,1101,65,1076,114,1124,3124,1024,1077,64,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,65,80]

theorem envBound35091 : H12AffineFastState.Bounded env35091 := by
  intro p hp
  have h : env35091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35090_35091 : H12AffineEnvironment.transform 8 81 env35090 = env35091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env35090 == env35091) = true)

theorem identity35091 : scanCanonicalize (H12AffineFastState.compose env35091 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound35091 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35092 : List Nat := [2,4,8,16,32,64,8,117,81,68,2048,112,9,65,112,114,32,2160,68,113,64,32,96,34,9,64,2161,32,112,2049,21,0,117,32,65,80]

theorem envBound35092 : H12AffineFastState.Bounded env35092 := by
  intro p hp
  have h : env35092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35091_35092 : H12AffineEnvironment.transform 9 68 env35091 = env35092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env35091 == env35092) = true)

theorem identity35092 : scanCanonicalize (H12AffineFastState.compose env35092 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35092 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env35093 : List Nat := [2,4,8,16,32,49,8,4,32,53,2048,1,9,48,1,3,32,2049,53,0,49,32,17,34,9,49,2048,32,1,2049,21,0,4,32,48,33]

theorem envBound35093 : H12AffineFastState.Bounded env35093 := by
  intro p hp
  have h : env35093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35092_35093 : H12AffineEnvironment.transform 5 49 env35092 = env35093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35092 == env35093) = true)

def env35094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98645,8193,64,472175,79130,4096,505114,75102,98679,256,33,46092,513]

theorem envBound35094 : H12AffineFastState.Bounded env35094 := by
  intro p hp
  have h : env35094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35082_35094 : H12AffineEnvironment.transform 6 9 env35082 = env35094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35082 == env35094) = true)

theorem identity35094 : scanCanonicalize (H12AffineFastState.compose env35094 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35094 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77898,32,73754,73737,8193,64,472175,79130,4096,463942,75102,73771,256,33,5456,513]

theorem envBound35095 : H12AffineFastState.Bounded env35095 := by
  intro p hp
  have h : env35095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35094_35095 : H12AffineEnvironment.transform 14 8540 env35094 = env35095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35094 == env35095) = true)

theorem identity35095 : scanCanonicalize (H12AffineFastState.compose env35095 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35095 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,262144,1024,8541,4160,32,16,3,8193,64,398437,5392,4096,406604,1364,33,256,33,5456,513]

theorem envBound35096 : H12AffineFastState.Bounded env35096 := by
  intro p hp
  have h : env35096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35095_35096 : H12AffineEnvironment.transform 15 8202 env35095 = env35096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35095 == env35096) = true)

theorem identity35096 : scanCanonicalize (H12AffineFastState.compose env35096 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35096 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35097 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,262144,1024,8461,4112,32,16,3,8193,16,398389,5392,4096,406556,1284,33,256,33,5376,513]

theorem envBound35097 : H12AffineFastState.Bounded env35097 := by
  intro p hp
  have h : env35097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35096_35097 : H12AffineEnvironment.transform 5 16 env35096 = env35097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35096 == env35097) = true)

theorem identity35097 : scanCanonicalize (H12AffineFastState.compose env35097 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound35097 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35098 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10281,1024,8461,4112,32,16,3,8193,16,146460,5392,4096,138293,1284,33,256,33,5376,513]

theorem envBound35098 : H12AffineFastState.Bounded env35098 := by
  intro p hp
  have h : env35098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35097_35098 : H12AffineEnvironment.transform 17 10281 env35097 = env35098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35097 == env35098) = true)

theorem identity35098 : scanCanonicalize (H12AffineFastState.compose env35098 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound35098 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35099 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10281,1024,8461,4112,32,16,3,8193,16,2048,5392,4096,10281,1284,33,256,33,5376,513]

theorem envBound35099 : H12AffineFastState.Bounded env35099 := by
  intro p hp
  have h : env35099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35098_35099 : H12AffineEnvironment.transform 16 13340 env35098 = env35099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env35098 == env35099) = true)

theorem identity35099 : scanCanonicalize (H12AffineFastState.compose env35099 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound35099 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35100 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5376,1296,1046,4096,3125,1024,1297,4112,32,16,3,1053,16,2048,5392,4096,3125,1284,33,256,33,5376,513]

theorem envBound35100 : H12AffineFastState.Bounded env35100 := by
  intro p hp
  have h : env35100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35099_35100 : H12AffineEnvironment.transform 12 1052 env35099 = env35100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env35099 == env35100) = true)

theorem identity35100 : scanCanonicalize (H12AffineFastState.compose env35100 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35100 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35101 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1052,5376,1296,1046,4096,1076,1024,1297,4112,32,16,3,1053,16,1,5392,4096,1076,1284,33,256,33,5376,513]

theorem envBound35101 : H12AffineFastState.Bounded env35101 := by
  intro p hp
  have h : env35101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35100_35101 : H12AffineEnvironment.transform 10 1 env35100 = env35101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35100 == env35101) = true)

theorem identity35101 : scanCanonicalize (H12AffineFastState.compose env35101 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound35101 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env35102 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1280,1052,0,1296,1046,1280,1076,1024,1297,1296,32,16,3,1053,16,1,16,1280,1076,1284,33,256,33,0,513]

theorem envBound35102 : H12AffineFastState.Bounded env35102 := by
  intro p hp
  have h : env35102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35101_35102 : H12AffineEnvironment.transform 11 1280 env35101 = env35102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env35101 == env35102) = true)

theorem identity35102 : scanCanonicalize (H12AffineFastState.compose env35102 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35102 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35103 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,17,269,0,1,263,17,293,273,0,1,32,16,3,268,16,1,16,17,293,21,33,256,33,0,513]

theorem envBound35103 : H12AffineFastState.Bounded env35103 := by
  intro p hp
  have h : env35103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35102_35103 : H12AffineEnvironment.transform 9 273 env35102 = env35103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35102 == env35103) = true)

theorem identity35103 : scanCanonicalize (H12AffineFastState.compose env35103 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound35103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35104 : List Nat := [2,4,8,16,32,16,9,53,512,36,1,17,56,0,1,50,17,16,36,0,1,32,16,3,57,16,1,16,17,16,21,33,53,33,0,513]

theorem envBound35104 : H12AffineFastState.Bounded env35104 := by
  intro p hp
  have h : env35104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35103_35104 : H12AffineEnvironment.transform 7 53 env35103 = env35104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env35103 == env35104) = true)

theorem identity35104 : scanCanonicalize (H12AffineFastState.compose env35104 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound35104 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35105 : List Nat := [2,4,8,16,32,16,9,53,9,36,1,17,56,0,1,50,17,16,36,0,1,32,16,3,57,16,1,16,17,16,21,33,53,33,0,8]

theorem envBound35105 : H12AffineFastState.Bounded env35105 := by
  intro p hp
  have h : env35105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35104_35105 : H12AffineEnvironment.transform 8 9 env35104 = env35105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env35104 == env35105) = true)

theorem identity35105 : scanCanonicalize (H12AffineFastState.compose env35105 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35105 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35106 : List Nat := [2,4,3,16,32,16,2,53,2,36,1,17,51,0,1,50,17,16,36,0,1,32,16,3,50,16,1,16,17,16,21,33,53,33,0,3]

theorem envBound35106 : H12AffineFastState.Bounded env35106 := by
  intro p hp
  have h : env35106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35105_35106 : H12AffineEnvironment.transform 2 3 env35105 = env35106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35105 == env35106) = true)

theorem identity35106 : scanCanonicalize (H12AffineFastState.compose env35106 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35106 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35107 : List Nat := [2,4,3,16,16,16,2,5,2,20,1,17,3,0,1,2,17,16,20,0,1,16,16,3,2,16,1,16,17,16,21,17,5,17,0,3]

theorem envBound35107 : H12AffineFastState.Bounded env35107 := by
  intro p hp
  have h : env35107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35106_35107 : H12AffineEnvironment.transform 4 16 env35106 = env35107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35106 == env35107) = true)

def env35108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787060,79130,8466579,8819968,8389956,98678,256,8462395,8492191,8462994]

theorem envBound35108 : H12AffineFastState.Bounded env35108 := by
  intro p hp
  have h : env35108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35080_35108 : H12AffineEnvironment.transform 21 33 env35080 = env35108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35080 == env35108) = true)

theorem identity35108 : scanCanonicalize (H12AffineFastState.compose env35108 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35108 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,4160,33,8388608,41430,8328,64,8787060,5529,8392720,8819968,8389956,41461,256,8388792,8434716,8389137]

theorem envBound35109 : H12AffineFastState.Bounded env35109 := by
  intro p hp
  have h : env35109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35108_35109 : H12AffineEnvironment.transform 15 8323 env35108 = env35109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35108 == env35109) = true)

def env35110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,8388608,41430,8328,64,8651060,5529,8392720,8683584,8389956,41461,256,8388792,8434716,8389137]

theorem envBound35110 : H12AffineFastState.Bounded env35110 := by
  intro p hp
  have h : env35110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35109_35110 : H12AffineEnvironment.transform 16 5440 env35109 = env35110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env35109 == env35110) = true)

theorem identity35110 : scanCanonicalize (H12AffineFastState.compose env35110 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297405) := by decide +kernel

theorem selectedBound35110 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,297405,41430,8328,64,34953,5529,301485,2557,298233,41461,256,297221,277921,297900]

theorem envBound35111 : H12AffineFastState.Bounded env35111 := by
  intro p hp
  have h : env35111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35110_35111 : H12AffineEnvironment.transform 22 297405 env35110 = env35111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297405 env35110 == env35111) = true)

theorem identity35111 : scanCanonicalize (H12AffineFastState.compose env35111 (packedSelected [1,4,5,7,8,9,16,19,20,21,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35111 : packedSelected [1,4,5,7,8,9,16,19,20,21,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35188,1024,32769,4160,33,201,41430,8328,64,34953,5529,4313,2557,1421,41461,256,113,46293,728]

theorem envBound35112 : H12AffineFastState.Bounded env35112 := by
  intro p hp
  have h : env35112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35111_35112 : H12AffineEnvironment.transform 17 35188 env35111 = env35112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35111 == env35112) = true)

theorem identity35112 : scanCanonicalize (H12AffineFastState.compose env35112 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound35112 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,137,8323,5440,2557,1024,136,4160,33,201,8543,8328,64,2048,5529,4313,2557,1421,8572,256,113,13404,728]

theorem envBound35113 : H12AffineFastState.Bounded env35113 := by
  intro p hp
  have h : env35113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35112_35113 : H12AffineEnvironment.transform 14 137 env35112 = env35113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env35112 == env35113) = true)

theorem identity35113 : scanCanonicalize (H12AffineFastState.compose env35113 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound35113 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env35114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,137,262,5440,2557,1024,136,4160,33,201,218,269,64,2048,5529,4313,2557,1421,249,256,113,5593,728]

theorem envBound35114 : H12AffineFastState.Bounded env35114 := by
  intro p hp
  have h : env35114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35113_35114 : H12AffineEnvironment.transform 12 389 env35113 = env35114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env35113 == env35114) = true)

theorem identity35114 : scanCanonicalize (H12AffineFastState.compose env35114 (packedSelected [0,1,3,4,5,7,8,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound35114 : packedSelected [0,1,3,4,5,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env35115 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,5372,137,250,5308,2049,1024,136,4160,33,201,218,241,64,2048,5221,4313,2049,1137,249,252,113,5157,728]

theorem envBound35115 : H12AffineFastState.Bounded env35115 := by
  intro p hp
  have h : env35115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35114_35115 : H12AffineEnvironment.transform 7 252 env35114 = env35115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env35114 == env35115) = true)

theorem identity35115 : scanCanonicalize (H12AffineFastState.compose env35115 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35115 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35116 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,0,115,5173,2049,1024,1,4160,33,64,83,120,64,2048,5221,4176,2049,1137,112,117,113,5157,593]

theorem envBound35116 : H12AffineFastState.Bounded env35116 := by
  intro p hp
  have h : env35116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35115_35116 : H12AffineEnvironment.transform 6 9 env35115 = env35116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35115 == env35116) = true)

theorem identity35116 : scanCanonicalize (H12AffineFastState.compose env35116 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35116 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35117 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5173,2049,1024,1,4112,33,16,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound35117 : H12AffineFastState.Bounded env35117 := by
  intro p hp
  have h : env35117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35116_35117 : H12AffineEnvironment.transform 5 16 env35116 = env35117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35116 == env35117) = true)

def env35118 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,0,35,1029,2049,1024,1,32,33,16,3,40,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound35118 : H12AffineFastState.Bounded env35118 := by
  intro p hp
  have h : env35118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35117_35118 : H12AffineEnvironment.transform 11 48 env35117 = env35118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35117 == env35118) = true)

def env35119 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,0,35,1028,2049,1024,1,33,33,16,3,40,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound35119 : H12AffineFastState.Bounded env35119 := by
  intro p hp
  have h : env35119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35117_35119 : H12AffineEnvironment.transform 11 49 env35117 = env35119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35117 == env35119) = true)

theorem identity35119 : scanCanonicalize (H12AffineFastState.compose env35119 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35119 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35120 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,41,33,0,35,49,2049,53,1,33,33,16,3,40,16,2048,49,49,2049,20,32,37,33,33,513]

theorem envBound35120 : H12AffineFastState.Bounded env35120 := by
  intro p hp
  have h : env35120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35119_35120 : H12AffineEnvironment.transform 9 53 env35119 = env35120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35119 == env35120) = true)

theorem identity35120 : scanCanonicalize (H12AffineFastState.compose env35120 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35121 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,0,2,16,2049,20,1,0,0,16,3,9,16,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound35121 : H12AffineFastState.Bounded env35121 := by
  intro p hp
  have h : env35121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35120_35121 : H12AffineEnvironment.transform 4 1 env35120 = env35121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35120 == env35121) = true)

def leafEnv35121 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,0,2,16,2049,20,1,0,0,16,3,20,9,1,16,2048,16,16,2049,20,1,4,0,4,3,0,513,1,0,0]

def active35121 : List Nat := [0,1,2,3,8,10]

def tree35121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35121 : H12WitnessSearch.Good tree35121 := H12GlobalWitnessIndex.good

theorem leafIdentity35121 : H12AffineFastState.composeSystem env35121 rootObs = leafEnv35121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35121 rootObs == leafEnv35121) = true)

theorem terminalChecked35121 : H12PackedTerminal.terminalCheckFast leafEnv35121 active35121 tree35121 = true := by decide +kernel

def env35122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,8388608,41430,8328,64,8651061,5529,8392720,8683585,8389956,41461,256,8388792,8434716,8389137]

theorem envBound35122 : H12AffineFastState.Bounded env35122 := by
  intro p hp
  have h : env35122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35109_35122 : H12AffineEnvironment.transform 16 5441 env35109 = env35122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env35109 == env35122) = true)

theorem identity35122 : scanCanonicalize (H12AffineFastState.compose env35122 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297268) := by decide +kernel

theorem selectedBound35122 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,297268,41430,8328,64,34817,5529,301348,2421,298096,41461,256,297356,277800,297765]

theorem envBound35123 : H12AffineFastState.Bounded env35123 := by
  intro p hp
  have h : env35123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35122_35123 : H12AffineEnvironment.transform 22 297268 env35122 = env35123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297268 env35122 == env35123) = true)

theorem identity35123 : scanCanonicalize (H12AffineFastState.compose env35123 (packedSelected [0,1,3,4,7,11,16,19,20,22,24,26,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound35123 : packedSelected [0,1,3,4,7,11,16,19,20,22,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env35124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,10400,1024,32769,4160,33,41364,41430,8328,64,34817,5529,45444,2421,42192,41461,256,41260,5512,41861]

theorem envBound35124 : H12AffineFastState.Bounded env35124 := by
  intro p hp
  have h : env35124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35123_35124 : H12AffineEnvironment.transform 17 10400 env35123 = env35124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35123 == env35124) = true)

theorem identity35124 : scanCanonicalize (H12AffineFastState.compose env35124 (packedSelected [3,10,16,19,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound35124 : packedSelected [3,10,16,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env35125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,136,8323,5441,10400,1024,137,4160,33,8476,8542,8328,64,2185,5529,12556,2421,9304,8573,256,8612,5512,8973]

theorem envBound35125 : H12AffineFastState.Bounded env35125 := by
  intro p hp
  have h : env35125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35124_35125 : H12AffineEnvironment.transform 14 136 env35124 = env35125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env35124 == env35125) = true)

theorem identity35125 : scanCanonicalize (H12AffineFastState.compose env35125 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound35125 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env35126 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,136,8323,5357,10400,1024,137,4160,33,8368,8434,8328,64,2185,5173,12448,2265,9304,8401,172,8200,5156,8865]

theorem envBound35126 : H12AffineFastState.Bounded env35126 := by
  intro p hp
  have h : env35126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35125_35126 : H12AffineEnvironment.transform 7 172 env35125 = env35126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env35125 == env35126) = true)

theorem identity35126 : scanCanonicalize (H12AffineFastState.compose env35126 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35126 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35127 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,1,8202,5220,10281,1024,0,4160,33,8249,8315,8193,64,2048,5173,12329,2128,9304,8280,37,8200,5156,8744]

theorem envBound35127 : H12AffineFastState.Bounded env35127 := by
  intro p hp
  have h : env35127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35126_35127 : H12AffineEnvironment.transform 6 9 env35126 = env35127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35126 == env35127) = true)

theorem identity35127 : scanCanonicalize (H12AffineFastState.compose env35127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35128 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,8192,4112,1,8202,4177,10281,53,0,4160,33,8249,8315,8193,64,2048,4096,12329,2128,8301,8280,37,8200,4113,8744]

theorem envBound35128 : H12AffineFastState.Bounded env35128 := by
  intro p hp
  have h : env35128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35127_35128 : H12AffineEnvironment.transform 9 53 env35127 = env35128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35127 == env35128) = true)

theorem identity35128 : scanCanonicalize (H12AffineFastState.compose env35128 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2633) := by decide +kernel

theorem selectedBound35128 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env35129 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,2633,4112,1,2627,4177,608,53,0,4160,33,2672,2610,2632,64,2048,4096,6752,2128,2596,2577,37,2625,4113,2145]

theorem envBound35129 : H12AffineFastState.Bounded env35129 := by
  intro p hp
  have h : env35129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35128_35129 : H12AffineEnvironment.transform 12 2633 env35128 = env35129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2633 env35128 == env35129) = true)

theorem identity35129 : scanCanonicalize (H12AffineFastState.compose env35129 (packedSelected [2,14] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound35129 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env35130 : List Nat := [2,4,8,16,32,64,9,37,512,53,528,4096,89,4112,1,83,4177,608,53,0,4160,33,96,34,88,64,528,4096,4208,576,52,1,37,81,4113,625]

theorem envBound35130 : H12AffineFastState.Bounded env35130 := by
  intro p hp
  have h : env35130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35129_35130 : H12AffineEnvironment.transform 10 528 env35129 = env35130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env35129 == env35130) = true)

theorem identity35130 : scanCanonicalize (H12AffineFastState.compose env35130 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35130 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35131 : List Nat := [2,4,8,16,0,64,9,5,512,21,528,4096,89,4112,1,83,4177,576,21,0,4160,1,64,2,88,64,528,4096,4176,576,20,1,5,81,4113,593]

theorem envBound35131 : H12AffineFastState.Bounded env35131 := by
  intro p hp
  have h : env35131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35130_35131 : H12AffineEnvironment.transform 4 0 env35130 = env35131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35130 == env35131) = true)

theorem identity35131 : scanCanonicalize (H12AffineFastState.compose env35131 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 21) := by decide +kernel

theorem selectedBound35131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35132 : List Nat := [2,4,8,16,0,21,9,5,512,21,528,4096,12,4112,1,6,4100,533,21,0,4117,1,21,2,13,21,528,4096,4101,533,20,1,5,4,4113,516]

theorem envBound35132 : H12AffineFastState.Bounded env35132 := by
  intro p hp
  have h : env35132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35131_35132 : H12AffineEnvironment.transform 5 21 env35131 = env35132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env35131 == env35132) = true)

theorem identity35132 : scanCanonicalize (H12AffineFastState.compose env35132 (packedSelected [1,4] rootPS)) = affineNative (2^(11+1) ^^^ 531) := by decide +kernel

theorem selectedBound35132 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env35133 : List Nat := [2,4,8,16,0,21,9,5,512,21,528,531,12,515,1,6,535,533,21,0,518,1,21,2,13,21,528,531,534,533,20,1,5,4,514,516]

theorem envBound35133 : H12AffineFastState.Bounded env35133 := by
  intro p hp
  have h : env35133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35132_35133 : H12AffineEnvironment.transform 11 531 env35132 = env35133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 531 env35132 == env35133) = true)

theorem identity35133 : scanCanonicalize (H12AffineFastState.compose env35133 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35133 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env35134 : List Nat := [2,4,8,11,0,14,9,5,512,14,523,520,12,515,1,6,524,526,14,0,518,1,14,2,13,14,523,520,525,526,15,1,5,4,514,516]

theorem envBound35134 : H12AffineFastState.Bounded env35134 := by
  intro p hp
  have h : env35134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35133_35134 : H12AffineEnvironment.transform 3 11 env35133 = env35134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35133 == env35134) = true)

def env35135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981333,79130,8466579,8819969,8389957,4292950,256,8462394,8492191,8462995]

theorem envBound35135 : H12AffineFastState.Bounded env35135 := by
  intro p hp
  have h : env35135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35079_35135 : H12AffineEnvironment.transform 13 5377 env35079 = env35135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35079 == env35135) = true)

def env35136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787061,79130,8466579,8819969,8389957,98678,256,8462394,8492191,8462995]

theorem envBound35136 : H12AffineFastState.Bounded env35136 := by
  intro p hp
  have h : env35136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35135_35136 : H12AffineEnvironment.transform 21 32 env35135 = env35136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35135 == env35136) = true)

theorem identity35136 : scanCanonicalize (H12AffineFastState.compose env35136 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound35136 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,98766,98644,8328,64,497083,79130,45405,464079,99467,98678,256,41460,5457,41821]

theorem envBound35137 : H12AffineFastState.Bounded env35137 := by
  intro p hp
  have h : env35137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35136_35137 : H12AffineEnvironment.transform 22 98766 env35136 = env35137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env35136 == env35137) = true)

def env35138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77970,32,98718,98564,8328,16,497083,79130,45325,464031,99467,98598,256,41380,5377,41741]

theorem envBound35138 : H12AffineFastState.Bounded env35138 := by
  intro p hp
  have h : env35138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35137_35138 : H12AffineEnvironment.transform 5 16 env35137 = env35138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35137 == env35138) = true)

theorem identity35138 : scanCanonicalize (H12AffineFastState.compose env35138 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound35138 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env35139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,146744,1024,32769,77970,32,98718,98564,8328,16,108675,79130,45325,76199,99467,98598,256,41380,5377,41741]

theorem envBound35139 : H12AffineFastState.Bounded env35139 := by
  intro p hp
  have h : env35139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35138_35139 : H12AffineEnvironment.transform 17 146744 env35138 = env35139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env35138 == env35139) = true)

theorem identity35139 : scanCanonicalize (H12AffineFastState.compose env35139 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound35139 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env35140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,33166,131072,146744,1024,32769,45340,32,16,138,8328,16,10509,46228,45325,43049,1285,168,256,41380,5377,41741]

theorem envBound35140 : H12AffineFastState.Bounded env35140 := by
  intro p hp
  have h : env35140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35139_35140 : H12AffineEnvironment.transform 15 33166 env35139 = env35140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env35139 == env35140) = true)

theorem identity35140 : scanCanonicalize (H12AffineFastState.compose env35140 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound35140 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env35141 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,33166,5529,10401,1024,32769,45340,32,16,138,8328,16,10509,46228,45325,43049,1285,168,256,41380,5377,41741]

theorem envBound35141 : H12AffineFastState.Bounded env35141 := by
  intro p hp
  have h : env35141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35140_35141 : H12AffineEnvironment.transform 16 5529 env35140 = env35141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env35140 == env35141) = true)

theorem identity35141 : scanCanonicalize (H12AffineFastState.compose env35141 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound35141 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env35142 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,8202,5529,10401,1024,8581,4248,32,16,138,8328,16,10509,5392,4233,2477,1285,168,256,32,5377,649]

theorem envBound35142 : H12AffineFastState.Bounded env35142 := by
  intro p hp
  have h : env35142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35141_35142 : H12AffineEnvironment.transform 14 8580 env35141 = env35142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env35141 == env35142) = true)

theorem identity35142 : scanCanonicalize (H12AffineFastState.compose env35142 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35142 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env35143 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4405,8580,8202,4525,10401,52,8581,4248,32,16,138,8328,16,10509,4388,4233,2477,305,168,256,32,4405,649]

theorem envBound35143 : H12AffineFastState.Bounded env35143 := by
  intro p hp
  have h : env35143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35142_35143 : H12AffineEnvironment.transform 9 52 env35142 = env35143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35142 == env35143) = true)

theorem identity35143 : scanCanonicalize (H12AffineFastState.compose env35143 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound35143 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35144 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,129,4405,261,139,4525,2080,52,260,4248,32,16,138,9,16,2444,4388,4233,2477,305,168,256,32,4405,649]

theorem envBound35144 : H12AffineFastState.Bounded env35144 := by
  intro p hp
  have h : env35144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35143_35144 : H12AffineEnvironment.transform 12 129 env35143 = env35144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env35143 == env35144) = true)

theorem identity35144 : scanCanonicalize (H12AffineFastState.compose env35144 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound35144 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env35145 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,2201,129,2476,261,139,2356,2080,52,260,2049,32,16,138,9,16,2444,2493,2064,2477,305,168,256,32,2476,649]

theorem envBound35145 : H12AffineFastState.Bounded env35145 := by
  intro p hp
  have h : env35145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35144_35145 : H12AffineEnvironment.transform 11 2201 env35144 = env35145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env35144 == env35145) = true)

theorem identity35145 : scanCanonicalize (H12AffineFastState.compose env35145 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35145 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env35146 : List Nat := [2,4,8,16,32,16,128,173,512,52,2048,2201,129,2049,168,139,2201,2080,52,169,2049,32,16,138,9,16,2081,2064,2064,2048,156,168,173,32,2049,649]

theorem envBound35146 : H12AffineFastState.Bounded env35146 := by
  intro p hp
  have h : env35146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35145_35146 : H12AffineEnvironment.transform 7 173 env35145 = env35146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35145 == env35146) = true)

theorem identity35146 : scanCanonicalize (H12AffineFastState.compose env35146 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35146 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35147 : List Nat := [2,4,8,16,32,16,128,173,512,52,0,153,129,1,168,139,153,32,52,169,1,32,16,138,9,16,33,16,16,0,156,168,173,32,1,649]

theorem envBound35147 : H12AffineFastState.Bounded env35147 := by
  intro p hp
  have h : env35147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35146_35147 : H12AffineEnvironment.transform 10 0 env35146 = env35147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35146 == env35147) = true)

theorem identity35147 : scanCanonicalize (H12AffineFastState.compose env35147 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound35147 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35148 : List Nat := [2,4,8,16,32,16,128,173,0,52,0,153,129,1,168,139,153,32,52,169,1,32,16,138,9,16,33,16,16,0,156,168,173,32,1,137]

theorem envBound35148 : H12AffineFastState.Bounded env35148 := by
  intro p hp
  have h : env35148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35147_35148 : H12AffineEnvironment.transform 8 0 env35147 = env35148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env35147 == env35148) = true)

theorem identity35148 : scanCanonicalize (H12AffineFastState.compose env35148 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35148 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35149 : List Nat := [2,4,8,1,32,1,128,173,0,37,0,136,129,1,168,139,136,32,37,169,1,32,1,138,9,1,33,1,1,0,141,168,173,32,1,137]

theorem envBound35149 : H12AffineFastState.Bounded env35149 := by
  intro p hp
  have h : env35149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35148_35149 : H12AffineEnvironment.transform 3 1 env35148 = env35149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35148 == env35149) = true)

theorem identity35149 : scanCanonicalize (H12AffineFastState.compose env35149 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35150 : List Nat := [2,4,8,1,0,1,128,141,0,5,0,136,129,1,136,139,136,0,5,137,1,0,1,138,9,1,1,1,1,0,141,136,141,0,1,137]

theorem envBound35150 : H12AffineFastState.Bounded env35150 := by
  intro p hp
  have h : env35150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35149_35150 : H12AffineEnvironment.transform 4 0 env35149 = env35150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35149 == env35150) = true)

theorem identity35150 : scanCanonicalize (H12AffineFastState.compose env35150 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35151 : List Nat := [2,4,8,1,0,1,8,5,0,5,0,0,9,1,0,3,0,0,5,1,1,0,1,2,9,1,1,1,1,0,5,0,5,0,1,1]

theorem envBound35151 : H12AffineFastState.Bounded env35151 := by
  intro p hp
  have h : env35151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35150_35151 : H12AffineEnvironment.transform 6 8 env35150 = env35151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35150 == env35151) = true)

def env35152 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77971,32,98719,98565,8328,17,497083,79130,45324,464030,99467,98599,256,41381,5376,41740]

theorem envBound35152 : H12AffineFastState.Bounded env35152 := by
  intro p hp
  have h : env35152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35137_35152 : H12AffineEnvironment.transform 5 17 env35137 = env35152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35137 == env35152) = true)

theorem identity35152 : scanCanonicalize (H12AffineFastState.compose env35152 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound35152 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env35153 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77971,32,98719,98565,8328,17,34952,79130,45324,2477,99467,98599,256,41381,5376,41740]

theorem envBound35153 : H12AffineFastState.Bounded env35153 := by
  intro p hp
  have h : env35153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35152_35153 : H12AffineEnvironment.transform 17 204083 env35152 = env35153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env35152 == env35153) = true)

def env35154 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77851,32,98583,98565,8192,17,34816,79130,45324,2341,99331,98599,256,41261,5376,41740]

theorem envBound35154 : H12AffineFastState.Bounded env35154 := by
  intro p hp
  have h : env35154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35153_35154 : H12AffineEnvironment.transform 6 8 env35153 = env35154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35153 == env35154) = true)

theorem identity35154 : scanCanonicalize (H12AffineFastState.compose env35154 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound35154 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env35155 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,67618,1024,32769,77851,32,98583,98565,8192,17,34816,79130,45324,2341,99331,98599,256,41261,5376,41740]

theorem envBound35155 : H12AffineFastState.Bounded env35155 := by
  intro p hp
  have h : env35155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35154_35155 : H12AffineEnvironment.transform 16 5393 env35154 = env35155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env35154 == env35155) = true)

theorem identity35155 : scanCanonicalize (H12AffineFastState.compose env35155 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound35155 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env35156 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,32803,5393,34817,1024,32769,45112,32,308,294,8192,17,34816,46393,45324,2341,1056,260,256,41261,5376,41740]

theorem envBound35156 : H12AffineFastState.Bounded env35156 := by
  intro p hp
  have h : env35156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35155_35156 : H12AffineEnvironment.transform 15 32803 env35155 = env35156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env35155 == env35156) = true)

theorem identity35156 : scanCanonicalize (H12AffineFastState.compose env35156 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35156 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35157 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,32768,32803,5172,34817,1024,32769,45112,32,17,3,8192,17,34816,46108,45097,2048,1056,33,37,40968,5157,41513]

theorem envBound35157 : H12AffineFastState.Bounded env35157 := by
  intro p hp
  have h : env35157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35156_35157 : H12AffineEnvironment.transform 7 37 env35156 = env35157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35156 == env35157) = true)

theorem identity35157 : scanCanonicalize (H12AffineFastState.compose env35157 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound35157 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35158 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,8233,8202,5172,10280,1024,8232,4113,32,17,3,8192,17,10281,5173,4096,2048,1056,33,37,33,5157,512]

theorem envBound35158 : H12AffineFastState.Bounded env35158 := by
  intro p hp
  have h : env35158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35157_35158 : H12AffineEnvironment.transform 14 8233 env35157 = env35158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env35157 == env35158) = true)

theorem identity35158 : scanCanonicalize (H12AffineFastState.compose env35158 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound35158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35159 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5156,32,3,5172,2081,1024,33,4113,32,17,3,9,17,2080,5173,4096,2048,1056,33,37,33,5157,512]

theorem envBound35159 : H12AffineFastState.Bounded env35159 := by
  intro p hp
  have h : env35159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35158_35159 : H12AffineEnvironment.transform 12 9 env35158 = env35159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env35158 == env35159) = true)

def env35160 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77850,32,98582,98565,8193,17,34817,79130,45324,2340,99330,98599,256,41260,5376,41740]

theorem envBound35160 : H12AffineFastState.Bounded env35160 := by
  intro p hp
  have h : env35160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35153_35160 : H12AffineEnvironment.transform 6 9 env35153 = env35160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35153 == env35160) = true)

theorem identity35160 : scanCanonicalize (H12AffineFastState.compose env35160 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound35160 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env35161 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,103446,35109,1024,32769,77850,32,98582,98565,8193,17,34817,79130,45324,2340,99330,98599,256,41260,5376,41740]

theorem envBound35161 : H12AffineFastState.Bounded env35161 := by
  intro p hp
  have h : env35161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35160_35161 : H12AffineEnvironment.transform 16 103446 env35160 = env35161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env35160 == env35161) = true)

theorem identity35161 : scanCanonicalize (H12AffineFastState.compose env35161 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35161 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35162 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,32768,65536,103446,35109,1024,32769,69911,32,98582,98565,268,17,34817,70679,36865,2340,99330,98599,256,32801,5376,33281]

theorem envBound35162 : H12AffineFastState.Bounded env35162 := by
  intro p hp
  have h : env35162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35161_35162 : H12AffineEnvironment.transform 12 269 env35161 = env35162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35161 == env35162) = true)

theorem identity35162 : scanCanonicalize (H12AffineFastState.compose env35162 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35162 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35163 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,65536,70679,2340,1024,0,69911,32,65815,65796,268,17,2048,70679,4096,2340,66563,65830,256,32,5376,512]

theorem envBound35163 : H12AffineFastState.Bounded env35163 := by
  intro p hp
  have h : env35163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35162_35163 : H12AffineEnvironment.transform 14 1 env35162 = env35163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35162 == env35163) = true)

theorem identity35163 : scanCanonicalize (H12AffineFastState.compose env35163 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35163 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35164 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,1,65536,70679,2308,1024,0,69911,0,65815,65796,268,17,2048,70679,4096,2308,66563,65798,256,0,5376,512]

theorem envBound35164 : H12AffineFastState.Bounded env35164 := by
  intro p hp
  have h : env35164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35163_35164 : H12AffineEnvironment.transform 4 0 env35163 = env35164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35163 == env35164) = true)

theorem identity35164 : scanCanonicalize (H12AffineFastState.compose env35164 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35164 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env35165 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4373,1,65536,69635,2308,20,0,69911,0,65815,65796,268,17,2048,69635,4096,2308,65559,65798,256,0,4372,512]

theorem envBound35165 : H12AffineFastState.Bounded env35165 := by
  intro p hp
  have h : env35165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35164_35165 : H12AffineEnvironment.transform 9 20 env35164 = env35165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35164 == env35165) = true)

theorem identity35165 : scanCanonicalize (H12AffineFastState.compose env35165 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound35165 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35166 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4373,1,3,4096,2308,20,0,4372,0,276,263,268,17,2048,4096,4096,2308,20,261,256,0,4372,512]

theorem envBound35166 : H12AffineFastState.Bounded env35166 := by
  intro p hp
  have h : env35166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35165_35166 : H12AffineEnvironment.transform 15 3 env35165 = env35166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env35165 == env35166) = true)

theorem identity35166 : scanCanonicalize (H12AffineFastState.compose env35166 (packedSelected [1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2836) := by decide +kernel

theorem selectedBound35166 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env35167 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,2836,269,2561,1,3,2836,2308,20,0,2560,0,276,263,268,17,2048,2836,2836,2308,20,261,256,0,2560,512]

theorem envBound35167 : H12AffineFastState.Bounded env35167 := by
  intro p hp
  have h : env35167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35166_35167 : H12AffineEnvironment.transform 11 2836 env35166 = env35167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2836 env35166 == env35167) = true)

theorem identity35167 : scanCanonicalize (H12AffineFastState.compose env35167 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35167 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35168 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,2576,9,2561,1,3,2576,2048,20,0,2560,0,16,3,8,17,2048,2576,2576,2048,20,1,4,0,2560,512]

theorem envBound35168 : H12AffineFastState.Bounded env35168 := by
  intro p hp
  have h : env35168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35167_35168 : H12AffineEnvironment.transform 7 4 env35167 = env35168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35167 == env35168) = true)

theorem identity35168 : scanCanonicalize (H12AffineFastState.compose env35168 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound35168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35169 : List Nat := [2,4,8,16,0,17,9,4,20,20,2048,2052,9,2069,1,3,2052,2048,20,0,2068,0,16,3,8,17,2048,2052,2052,2048,20,1,4,0,2068,20]

theorem envBound35169 : H12AffineFastState.Bounded env35169 := by
  intro p hp
  have h : env35169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35168_35169 : H12AffineEnvironment.transform 8 20 env35168 = env35169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env35168 == env35169) = true)

theorem identity35169 : scanCanonicalize (H12AffineFastState.compose env35169 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound35169 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35170 : List Nat := [2,4,8,4,0,5,9,4,0,0,2048,2052,9,2049,1,3,2052,2048,0,0,2048,0,4,3,8,5,2048,2052,2052,2048,0,1,4,0,2048,0]

theorem envBound35170 : H12AffineFastState.Bounded env35170 := by
  intro p hp
  have h : env35170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35169_35170 : H12AffineEnvironment.transform 3 4 env35169 = env35170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env35169 == env35170) = true)

def leafEnv35170 : List Nat := [2,4,8,4,0,5,9,4,0,0,2048,2052,9,2049,1,3,2052,2048,0,0,2048,0,4,3,0,8,1,5,2048,2052,2052,2048,0,1,4,0,4,2,2048,0,1,2049,0]

def active35170 : List Nat := [0,1,2,10]

def tree35170 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35170 : H12WitnessSearch.Good tree35170 := H12GlobalWitnessIndex.good

theorem leafIdentity35170 : H12AffineFastState.composeSystem env35170 rootObs = leafEnv35170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35170 rootObs == leafEnv35170) = true)

theorem terminalChecked35170 : H12PackedTerminal.terminalCheckFast leafEnv35170 active35170 tree35170 = true := by decide +kernel

def env35171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787060,79130,8466579,8819969,8389957,98679,256,8462394,8492191,8462995]

theorem envBound35171 : H12AffineFastState.Bounded env35171 := by
  intro p hp
  have h : env35171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35135_35171 : H12AffineEnvironment.transform 21 33 env35135 = env35171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35135 == env35171) = true)

theorem identity35171 : scanCanonicalize (H12AffineFastState.compose env35171 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound35171 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,45340,33,8388608,138,8328,64,8787060,46276,8433997,8819969,8389957,169,256,8430052,8394049,8430413]

theorem envBound35172 : H12AffineFastState.Bounded env35172 := by
  intro p hp
  have h : env35172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35171_35172 : H12AffineEnvironment.transform 15 33246 env35171 = env35172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env35171 == env35172) = true)

theorem identity35172 : scanCanonicalize (H12AffineFastState.compose env35172 (packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound35172 : packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env35173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10401,1024,32769,45340,33,8388608,138,8328,64,8535253,46276,8433997,8568224,8389957,169,256,8430052,8394049,8430413]

theorem envBound35173 : H12AffineFastState.Bounded env35173 := by
  intro p hp
  have h : env35173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35172_35173 : H12AffineEnvironment.transform 17 10401 env35172 = env35173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35172 == env35173) = true)

theorem identity35173 : scanCanonicalize (H12AffineFastState.compose env35173 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound35173 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10401,1024,32769,45340,33,41292,138,8328,64,171417,46276,4097,138476,41993,169,256,168,46093,513]

theorem envBound35174 : H12AffineFastState.Bounded env35174 := by
  intro p hp
  have h : env35174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35173_35174 : H12AffineEnvironment.transform 22 41292 env35173 = env35174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env35173 == env35174) = true)

theorem identity35174 : scanCanonicalize (H12AffineFastState.compose env35174 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound35174 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13461,10401,1024,32769,45340,33,41292,138,8328,64,43276,46276,4097,10361,41993,169,256,168,46093,513]

theorem envBound35175 : H12AffineFastState.Bounded env35175 := by
  intro p hp
  have h : env35175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35174_35175 : H12AffineEnvironment.transform 16 13461 env35174 = env35175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env35174 == env35175) = true)

theorem identity35175 : scanCanonicalize (H12AffineFastState.compose env35175 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound35175 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env35176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,216,262,13461,10401,1024,217,12740,33,8596,138,8328,64,10708,13340,4097,10361,9425,169,256,168,13525,513]

theorem envBound35176 : H12AffineFastState.Bounded env35176 := by
  intro p hp
  have h : env35176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35175_35176 : H12AffineEnvironment.transform 14 216 env35175 = env35176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env35175 == env35176) = true)

theorem identity35176 : scanCanonicalize (H12AffineFastState.compose env35176 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound35176 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35177 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5377,1,262,13388,10360,1024,0,12573,33,8525,83,8273,64,10509,13340,4097,10361,9224,112,256,113,13324,513]

theorem envBound35177 : H12AffineFastState.Bounded env35177 := by
  intro p hp
  have h : env35177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35176_35177 : H12AffineEnvironment.transform 6 89 env35176 = env35177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35176 == env35177) = true)

theorem identity35177 : scanCanonicalize (H12AffineFastState.compose env35177 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35177 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35178 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,1,262,5440,2420,1024,0,4113,33,65,83,349,64,2049,5392,4097,2421,1284,112,256,113,5376,513]

theorem envBound35178 : H12AffineFastState.Bounded env35178 := by
  intro p hp
  have h : env35178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35177_35178 : H12AffineEnvironment.transform 12 268 env35177 = env35178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35177 == env35178) = true)

theorem identity35178 : scanCanonicalize (H12AffineFastState.compose env35178 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35178 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35179 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4113,33,16,2,268,17,2049,5392,4097,2340,1284,33,256,32,5376,513]

theorem envBound35179 : H12AffineFastState.Bounded env35179 := by
  intro p hp
  have h : env35179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35178_35179 : H12AffineEnvironment.transform 5 17 env35178 = env35179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35178 == env35179) = true)

theorem identity35179 : scanCanonicalize (H12AffineFastState.compose env35179 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35179 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35180 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4112,1,262,4096,2341,273,0,4113,33,16,2,268,17,2049,4097,4097,2340,21,33,256,32,4113,513]

theorem envBound35180 : H12AffineFastState.Bounded env35180 := by
  intro p hp
  have h : env35180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35179_35180 : H12AffineEnvironment.transform 9 273 env35179 = env35180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35179 == env35180) = true)

theorem identity35180 : scanCanonicalize (H12AffineFastState.compose env35180 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35180 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35181 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4112,1,35,4096,2048,52,0,4113,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4113,513]

theorem envBound35181 : H12AffineFastState.Bounded env35181 := by
  intro p hp
  have h : env35181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35180_35181 : H12AffineEnvironment.transform 7 37 env35180 = env35181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35180 == env35181) = true)

theorem identity35181 : scanCanonicalize (H12AffineFastState.compose env35181 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35182 : List Nat := [2,4,8,16,32,17,8,37,49,52,2048,4096,41,4112,1,35,4096,2048,52,0,4113,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4113,48]

theorem envBound35182 : H12AffineFastState.Bounded env35182 := by
  intro p hp
  have h : env35182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35181_35182 : H12AffineEnvironment.transform 8 49 env35181 = env35182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35181 == env35182) = true)

theorem identity35182 : scanCanonicalize (H12AffineFastState.compose env35182 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35183 : List Nat := [2,4,8,16,32,17,8,37,49,52,0,4096,41,4112,1,35,4096,0,52,0,4113,33,16,2,41,17,1,4097,4097,1,21,33,37,32,4113,48]

theorem envBound35183 : H12AffineFastState.Bounded env35183 := by
  intro p hp
  have h : env35183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35182_35183 : H12AffineEnvironment.transform 10 0 env35182 = env35183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35182 == env35183) = true)

theorem identity35183 : scanCanonicalize (H12AffineFastState.compose env35183 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound35183 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35184 : List Nat := [2,4,8,16,32,17,8,37,49,52,0,17,41,1,1,35,17,0,52,0,0,33,16,2,41,17,1,16,16,1,21,33,37,32,0,48]

theorem envBound35184 : H12AffineFastState.Bounded env35184 := by
  intro p hp
  have h : env35184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35183_35184 : H12AffineEnvironment.transform 11 17 env35183 = env35184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35183 == env35184) = true)

def env35185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound35185 : H12AffineFastState.Bounded env35185 := by
  intro p hp
  have h : env35185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34954_35185 : H12AffineEnvironment.transform 18 1025 env34954 = env35185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34954 == env35185) = true)

theorem identity35185 : scanCanonicalize (H12AffineFastState.compose env35185 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10650946) := by decide +kernel

theorem selectedBound35185 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10650946,8328,64,6636867,8585679,10507600,8830977,2294099,12836995,257,213486,237643,2238084]

theorem envBound35186 : H12AffineFastState.Bounded env35186 := by
  intro p hp
  have h : env35186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35185_35186 : H12AffineEnvironment.transform 23 10650946 env35185 = env35186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10650946 env35185 == env35186) = true)

def env35187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180224,2114882,8328,64,6636867,115151,2266448,262145,2294099,4268163,257,213486,237643,2238084]

theorem envBound35187 : H12AffineFastState.Bounded env35187 := by
  intro p hp
  have h : env35187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35186_35187 : H12AffineEnvironment.transform 22 180224 env35186 = env35187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env35186 == env35187) = true)

def env35188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,169234,8328,64,4691219,115151,17664,262145,119043,4268163,257,213486,237643,63188]

theorem envBound35188 : H12AffineFastState.Bounded env35188 := by
  intro p hp
  have h : env35188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35187_35188 : H12AffineEnvironment.transform 20 184400 env35187 = env35188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env35187 == env35188) = true)

def env35189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,169234,8328,64,245139,115151,17664,262145,119043,329731,257,213486,237643,63188]

theorem envBound35189 : H12AffineFastState.Bounded env35189 := by
  intro p hp
  have h : env35189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35188_35189 : H12AffineEnvironment.transform 21 272512 env35188 = env35189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35188 == env35189) = true)

theorem identity35189 : scanCanonicalize (H12AffineFastState.compose env35189 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound35189 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272512,17,21763,8328,64,97666,115151,17664,262145,119043,329731,257,98815,90202,63188]

theorem envBound35190 : H12AffineFastState.Bounded env35190 := by
  intro p hp
  have h : env35190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35189_35190 : H12AffineEnvironment.transform 16 49169 env35189 = env35190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35189 == env35190) = true)

def env35191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21763,8192,64,97546,115015,17664,262145,119043,329731,257,98679,90202,63068]

theorem envBound35191 : H12AffineFastState.Bounded env35191 := by
  intro p hp
  have h : env35191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35190_35191 : H12AffineEnvironment.transform 6 8 env35190 = env35191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35190 == env35191) = true)

theorem identity35191 : scanCanonicalize (H12AffineFastState.compose env35191 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,32,17,21763,8192,64,97546,115015,17664,10281,119043,73771,257,98679,90202,63068]

theorem envBound35192 : H12AffineFastState.Bounded env35192 := by
  intro p hp
  have h : env35192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35191_35192 : H12AffineEnvironment.transform 17 10280 env35191 = env35192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35191 == env35192) = true)

theorem identity35192 : scanCanonicalize (H12AffineFastState.compose env35192 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound35192 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env35193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5441,10280,1025,21841,4161,32,17,21763,8192,64,97546,70679,17664,10281,66643,73771,257,87079,90202,8972]

theorem envBound35193 : H12AffineFastState.Bounded env35193 := by
  intro p hp
  have h : env35193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35192_35193 : H12AffineEnvironment.transform 14 21840 env35192 = env35193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env35192 == env35193) = true)

theorem identity35193 : scanCanonicalize (H12AffineFastState.compose env35193 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35193 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21840,65536,5441,2420,1025,21841,4161,32,17,21763,348,64,89174,70679,17664,2421,66643,65911,257,87079,82182,592]

theorem envBound35194 : H12AffineFastState.Bounded env35194 := by
  intro p hp
  have h : env35194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35193_35194 : H12AffineEnvironment.transform 12 348 env35193 = env35194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35193 == env35194) = true)

theorem identity35194 : scanCanonicalize (H12AffineFastState.compose env35194 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound35194 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,0,65536,5441,2420,1025,1,4161,32,17,83,348,64,67846,70679,4176,2421,66643,65911,257,65911,70742,592]

theorem envBound35195 : H12AffineFastState.Bounded env35195 := by
  intro p hp
  have h : env35195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35194_35195 : H12AffineEnvironment.transform 13 5456 env35194 = env35195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env35194 == env35195) = true)

theorem identity35195 : scanCanonicalize (H12AffineFastState.compose env35195 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 6423) := by decide +kernel

theorem selectedBound35195 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,0,6423,5441,2420,1025,1,4161,32,17,83,348,64,4113,3328,4176,2421,7492,6240,257,6240,3393,592]

theorem envBound35196 : H12AffineFastState.Bounded env35196 := by
  intro p hp
  have h : env35196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35195_35196 : H12AffineEnvironment.transform 15 6423 env35195 = env35196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6423 env35195 == env35196) = true)

theorem identity35196 : scanCanonicalize (H12AffineFastState.compose env35196 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35196 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env35197 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,6423,5392,2341,1025,1,4112,32,17,2,269,17,4113,3328,4097,2340,7445,6193,257,6193,3344,513]

theorem envBound35197 : H12AffineFastState.Bounded env35197 := by
  intro p hp
  have h : env35197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35196_35197 : H12AffineEnvironment.transform 5 17 env35196 = env35197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35196 == env35197) = true)

theorem identity35197 : scanCanonicalize (H12AffineFastState.compose env35197 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35197 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35198 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,269,3344,0,262,3329,2341,1025,1,2049,32,17,2,269,17,2048,3328,2064,2340,1284,32,257,32,3344,513]

theorem envBound35198 : H12AffineFastState.Bounded env35198 := by
  intro p hp
  have h : env35198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35197_35198 : H12AffineEnvironment.transform 11 2065 env35197 = env35198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35197 == env35198) = true)

theorem identity35198 : scanCanonicalize (H12AffineFastState.compose env35198 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound35198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35199 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1312,1329,269,48,0,262,33,1029,1025,1,1313,32,17,2,269,17,1312,32,1328,1028,1284,32,257,32,48,513]

theorem envBound35199 : H12AffineFastState.Bounded env35199 := by
  intro p hp
  have h : env35199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35198_35199 : H12AffineEnvironment.transform 10 1312 env35198 = env35199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env35198 == env35199) = true)

theorem identity35199 : scanCanonicalize (H12AffineFastState.compose env35199 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound35199 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35200 : List Nat := [2,4,8,16,32,17,8,256,48,1024,1312,1329,269,48,0,262,33,1029,1025,1,1313,32,17,2,269,17,1312,32,1328,1028,1284,32,257,32,48,49]

theorem envBound35200 : H12AffineFastState.Bounded env35200 := by
  intro p hp
  have h : env35200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35199_35200 : H12AffineEnvironment.transform 8 48 env35199 = env35200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env35199 == env35200) = true)

theorem identity35200 : scanCanonicalize (H12AffineFastState.compose env35200 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35200 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35201 : List Nat := [2,4,8,16,32,17,8,256,48,272,48,33,269,48,0,262,33,277,273,1,49,32,17,2,269,17,48,32,32,276,20,32,257,32,48,49]

theorem envBound35201 : H12AffineFastState.Bounded env35201 := by
  intro p hp
  have h : env35201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35200_35201 : H12AffineEnvironment.transform 9 272 env35200 = env35201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35200 == env35201) = true)

theorem identity35201 : scanCanonicalize (H12AffineFastState.compose env35201 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35201 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35202 : List Nat := [2,4,8,16,0,17,8,256,16,272,16,1,269,16,0,262,1,277,273,1,17,0,17,2,269,17,16,0,0,276,20,0,257,0,16,17]

theorem envBound35202 : H12AffineFastState.Bounded env35202 := by
  intro p hp
  have h : env35202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35201_35202 : H12AffineEnvironment.transform 4 0 env35201 = env35202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35201 == env35202) = true)

theorem identity35202 : scanCanonicalize (H12AffineFastState.compose env35202 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35202 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env35203 : List Nat := [2,4,8,16,0,17,8,20,16,4,16,1,25,16,0,18,1,1,5,1,17,0,17,2,25,17,16,0,0,0,20,0,21,0,16,17]

theorem envBound35203 : H12AffineFastState.Bounded env35203 := by
  intro p hp
  have h : env35203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35202_35203 : H12AffineEnvironment.transform 7 20 env35202 = env35203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35202 == env35203) = true)

theorem identity35203 : scanCanonicalize (H12AffineFastState.compose env35203 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35204 : List Nat := [2,4,8,1,0,0,8,5,1,4,1,1,8,1,0,3,1,1,5,1,0,0,0,2,8,0,1,0,0,0,5,0,4,0,1,0]

theorem envBound35204 : H12AffineFastState.Bounded env35204 := by
  intro p hp
  have h : env35204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35203_35204 : H12AffineEnvironment.transform 3 1 env35203 = env35204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35203 == env35204) = true)

def env35205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21763,8193,64,97547,115014,17664,262145,119043,329731,257,98678,90202,63069]

theorem envBound35205 : H12AffineFastState.Bounded env35205 := by
  intro p hp
  have h : env35205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35190_35205 : H12AffineEnvironment.transform 6 9 env35190 = env35205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35190 == env35205) = true)

theorem identity35205 : scanCanonicalize (H12AffineFastState.compose env35205 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35205 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,4161,41341,17,21763,8193,64,97547,115014,17664,35189,119043,98679,257,98678,90202,63069]

theorem envBound35206 : H12AffineFastState.Bounded env35206 := by
  intro p hp
  have h : env35206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35205_35206 : H12AffineEnvironment.transform 17 35188 env35205 = env35206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35205 == env35206) = true)

theorem identity35206 : scanCanonicalize (H12AffineFastState.compose env35206 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound35206 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env35207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21875,49169,35188,1025,32769,4161,41341,17,21763,8193,64,10360,37941,17664,35189,33904,54276,257,54277,13609,63069]

theorem envBound35207 : H12AffineFastState.Bounded env35207 := by
  intro p hp
  have h : env35207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35206_35207 : H12AffineEnvironment.transform 15 21875 env35206 = env35207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env35206 == env35207) = true)

theorem identity35207 : scanCanonicalize (H12AffineFastState.compose env35207 (packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound35207 : packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env35208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,21875,13341,32120,1025,29709,4161,21873,17,21763,8193,64,10360,24633,17664,32121,28796,8200,257,8201,13609,593]

theorem envBound35208 : H12AffineFastState.Bounded env35208 := by
  intro p hp
  have h : env35208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35207_35208 : H12AffineEnvironment.transform 14 29708 env35207 = env35208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env35207 == env35208) = true)

theorem identity35208 : scanCanonicalize (H12AffineFastState.compose env35208 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound35208 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8233,342,13341,10589,1025,8232,4161,340,17,294,8193,64,10360,13340,4389,10588,9305,8200,257,8201,13609,593]

theorem envBound35209 : H12AffineFastState.Bounded env35209 := by
  intro p hp
  have h : env35209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35208_35209 : H12AffineEnvironment.transform 13 5157 env35208 = env35209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env35208 == env35209) = true)

theorem identity35209 : scanCanonicalize (H12AffineFastState.compose env35209 (packedSelected [0,3,5,7,10,12,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35209 : packedSelected [0,3,5,7,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env35210 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,8233,114,13341,10361,1025,8232,4161,112,17,2,8193,64,10360,13340,4097,10360,9305,8200,37,8201,13325,593]

theorem envBound35210 : H12AffineFastState.Bounded env35210 := by
  intro p hp
  have h : env35210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35209_35210 : H12AffineEnvironment.transform 7 36 env35209 = env35210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35209 == env35210) = true)

theorem identity35210 : scanCanonicalize (H12AffineFastState.compose env35210 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound35210 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35211 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5157,81,114,5221,2049,1025,80,4161,112,17,2,121,64,2048,5220,4097,2048,1057,112,37,113,5237,593]

theorem envBound35211 : H12AffineFastState.Bounded env35211 := by
  intro p hp
  have h : env35211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35210_35211 : H12AffineEnvironment.transform 12 120 env35210 = env35211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env35210 == env35211) = true)

theorem identity35211 : scanCanonicalize (H12AffineFastState.compose env35211 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound35211 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env35212 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1060,120,1,81,114,65,2049,1025,80,1125,112,17,2,121,64,2048,64,1061,2048,1057,112,37,113,81,593]

theorem envBound35212 : H12AffineFastState.Bounded env35212 := by
  intro p hp
  have h : env35212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35211_35212 : H12AffineEnvironment.transform 11 1060 env35211 = env35212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env35211 == env35212) = true)

theorem identity35212 : scanCanonicalize (H12AffineFastState.compose env35212 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35212 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env35213 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1,1060,120,1,81,114,65,0,1025,80,1125,112,17,2,121,64,1,64,1061,1,1057,112,37,113,81,593]

theorem envBound35213 : H12AffineFastState.Bounded env35213 := by
  intro p hp
  have h : env35213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35212_35213 : H12AffineEnvironment.transform 10 1 env35212 = env35213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35212 == env35213) = true)

theorem identity35213 : scanCanonicalize (H12AffineFastState.compose env35213 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35213 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35214 : List Nat := [2,4,8,16,32,64,9,36,512,52,1,16,120,1,81,114,65,0,53,80,81,112,17,2,121,64,1,64,17,1,21,112,37,113,81,593]

theorem envBound35214 : H12AffineFastState.Bounded env35214 := by
  intro p hp
  have h : env35214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35213_35214 : H12AffineEnvironment.transform 9 52 env35213 = env35214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35213 == env35214) = true)

theorem identity35214 : scanCanonicalize (H12AffineFastState.compose env35214 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35214 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35215 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,40,1,1,34,17,0,53,0,1,32,17,2,41,16,1,16,17,1,21,32,37,33,1,513]

theorem envBound35215 : H12AffineFastState.Bounded env35215 := by
  intro p hp
  have h : env35215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35214_35215 : H12AffineEnvironment.transform 5 16 env35214 = env35215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35214 == env35215) = true)

theorem identity35215 : scanCanonicalize (H12AffineFastState.compose env35215 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35216 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,1,40,1,1,34,0,0,36,0,1,32,0,2,41,1,1,1,0,1,4,32,37,33,1,513]

theorem envBound35216 : H12AffineFastState.Bounded env35216 := by
  intro p hp
  have h : env35216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35215_35216 : H12AffineEnvironment.transform 3 1 env35215 = env35216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35215 == env35216) = true)

theorem identity35216 : scanCanonicalize (H12AffineFastState.compose env35216 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35217 : List Nat := [2,4,3,1,32,1,2,36,512,37,1,1,35,1,1,34,0,0,36,0,1,32,0,2,34,1,1,1,0,1,4,32,37,33,1,513]

theorem envBound35217 : H12AffineFastState.Bounded env35217 := by
  intro p hp
  have h : env35217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35216_35217 : H12AffineEnvironment.transform 2 3 env35216 = env35217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35216 == env35217) = true)

def env35218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,169234,8328,64,245138,115151,17664,262145,119043,329730,257,213486,237643,63188]

theorem envBound35218 : H12AffineFastState.Bounded env35218 := by
  intro p hp
  have h : env35218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35188_35218 : H12AffineEnvironment.transform 21 272513 env35188 = env35218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35188 == env35218) = true)

def env35219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180224,169234,8192,64,245018,115015,17664,262145,119043,329730,257,213350,237643,63068]

theorem envBound35219 : H12AffineFastState.Bounded env35219 := by
  intro p hp
  have h : env35219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35218_35219 : H12AffineEnvironment.transform 6 8 env35218 = env35219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35218 == env35219) = true)

def env35220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,16,21762,8192,64,97546,115015,17664,262145,119043,329730,257,98678,90203,63068]

theorem envBound35220 : H12AffineFastState.Bounded env35220 := by
  intro p hp
  have h : env35220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35219_35220 : H12AffineEnvironment.transform 16 49168 env35219 = env35220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35219 == env35220) = true)

theorem identity35220 : scanCanonicalize (H12AffineFastState.compose env35220 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound35220 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env35221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,76078,1025,32769,4160,65831,16,21762,8192,64,97546,115015,17664,76079,119043,8492,257,98678,90203,63068]

theorem envBound35221 : H12AffineFastState.Bounded env35221 := by
  intro p hp
  have h : env35221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35220_35221 : H12AffineEnvironment.transform 17 76078 env35220 = env35221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env35220 == env35221) = true)

theorem identity35221 : scanCanonicalize (H12AffineFastState.compose env35221 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound35221 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env35222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,49168,10361,1025,32769,4160,112,16,21762,8192,64,31837,49168,17664,10360,53332,8492,257,32801,24844,63068]

theorem envBound35222 : H12AffineFastState.Bounded env35222 := by
  intro p hp
  have h : env35222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35221_35222 : H12AffineEnvironment.transform 15 343 env35221 = env35222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env35221 == env35222) = true)

theorem identity35222 : scanCanonicalize (H12AffineFastState.compose env35222 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound35222 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,343,5441,10361,1025,21840,4160,112,16,21762,8192,64,31837,5441,17664,10360,1285,8492,257,21872,24844,8973]

theorem envBound35223 : H12AffineFastState.Bounded env35223 := by
  intro p hp
  have h : env35223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35222_35223 : H12AffineEnvironment.transform 14 21841 env35222 = env35223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env35222 == env35223) = true)

theorem identity35223 : scanCanonicalize (H12AffineFastState.compose env35223 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound35223 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env35224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,343,5441,10361,1025,8540,4160,112,16,8462,8192,64,2129,5441,12556,10360,1285,8492,257,8572,5376,8973]

theorem envBound35224 : H12AffineFastState.Bounded env35224 := by
  intro p hp
  have h : env35224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35223_35224 : H12AffineEnvironment.transform 13 13324 env35223 = env35224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env35223 == env35224) = true)

theorem identity35224 : scanCanonicalize (H12AffineFastState.compose env35224 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35224 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env35225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,343,5441,2421,1025,80,4160,112,16,2,268,64,2129,5441,4096,2420,1285,32,257,112,5376,513]

theorem envBound35225 : H12AffineFastState.Bounded env35225 := by
  intro p hp
  have h : env35225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35224_35225 : H12AffineEnvironment.transform 12 268 env35224 = env35225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35224 == env35225) = true)

def env35226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21763,8192,64,97547,115015,17664,262145,119043,329730,257,98679,90202,63068]

theorem envBound35226 : H12AffineFastState.Bounded env35226 := by
  intro p hp
  have h : env35226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35219_35226 : H12AffineEnvironment.transform 16 49169 env35219 = env35226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35219 == env35226) = true)

theorem identity35226 : scanCanonicalize (H12AffineFastState.compose env35226 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35226 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,33,17,21763,8192,64,97547,115015,17664,10281,119043,73770,257,98679,90202,63068]

theorem envBound35227 : H12AffineFastState.Bounded env35227 := by
  intro p hp
  have h : env35227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35226_35227 : H12AffineEnvironment.transform 17 10280 env35226 = env35227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35226 == env35227) = true)

theorem identity35227 : scanCanonicalize (H12AffineFastState.compose env35227 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound35227 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env35228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,10280,1025,32769,4161,33,17,21763,8192,64,43277,5441,17664,10281,1285,62508,257,21873,46172,63068]

theorem envBound35228 : H12AffineFastState.Bounded env35228 := by
  intro p hp
  have h : env35228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35227_35228 : H12AffineEnvironment.transform 15 54278 env35227 = env35228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env35227 == env35228) = true)

theorem identity35228 : scanCanonicalize (H12AffineFastState.compose env35228 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35228 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env35229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54278,49169,2421,1025,32769,4161,33,17,21763,349,64,34896,5441,17664,2420,1285,54641,257,21873,38145,55041]

theorem envBound35229 : H12AffineFastState.Bounded env35229 := by
  intro p hp
  have h : env35229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35228_35229 : H12AffineEnvironment.transform 12 349 env35228 = env35229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35228 == env35229) = true)

theorem identity35229 : scanCanonicalize (H12AffineFastState.compose env35229 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound35229 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,32768,33110,38209,2421,1025,32769,4161,33,17,83,349,64,34896,5441,4176,2420,1285,32801,257,33,38145,33361]

theorem envBound35230 : H12AffineFastState.Bounded env35230 := by
  intro p hp
  have h : env35230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35229_35230 : H12AffineEnvironment.transform 13 5456 env35229 = env35230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env35229 == env35230) = true)

theorem identity35230 : scanCanonicalize (H12AffineFastState.compose env35230 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound35230 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,262,5393,2421,1025,81,4161,33,17,83,349,64,2048,5441,4176,2420,1285,113,257,33,5457,513]

theorem envBound35231 : H12AffineFastState.Bounded env35231 := by
  intro p hp
  have h : env35231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35230_35231 : H12AffineEnvironment.transform 14 80 env35230 = env35231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env35230 == env35231) = true)

theorem identity35231 : scanCanonicalize (H12AffineFastState.compose env35231 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35231 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35232 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1025,0,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,257,33,5376,513]

theorem envBound35232 : H12AffineFastState.Bounded env35232 := by
  intro p hp
  have h : env35232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35231_35232 : H12AffineEnvironment.transform 5 17 env35231 = env35232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35231 == env35232) = true)

theorem identity35232 : scanCanonicalize (H12AffineFastState.compose env35232 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound35232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35233 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1028,268,261,1,262,277,2340,1025,0,1044,33,17,2,268,17,2048,276,1029,2341,1285,32,257,33,260,513]

theorem envBound35233 : H12AffineFastState.Bounded env35233 := by
  intro p hp
  have h : env35233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35232_35233 : H12AffineEnvironment.transform 11 1028 env35232 = env35233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env35232 == env35233) = true)

theorem identity35233 : scanCanonicalize (H12AffineFastState.compose env35233 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35233 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35234 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,16,268,261,1,262,277,2340,21,0,0,33,17,2,268,17,2048,276,17,2341,273,32,257,33,260,513]

theorem envBound35234 : H12AffineFastState.Bounded env35234 := by
  intro p hp
  have h : env35234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35233_35234 : H12AffineEnvironment.transform 9 20 env35233 = env35234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35233 == env35234) = true)

theorem identity35234 : scanCanonicalize (H12AffineFastState.compose env35234 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound35234 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35235 : List Nat := [2,4,8,16,32,17,8,256,512,20,513,16,268,261,1,262,277,805,21,0,0,33,17,2,268,17,513,276,17,804,273,32,257,33,260,513]

theorem envBound35235 : H12AffineFastState.Bounded env35235 := by
  intro p hp
  have h : env35235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35234_35235 : H12AffineEnvironment.transform 10 513 env35234 = env35235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env35234 == env35235) = true)

theorem identity35235 : scanCanonicalize (H12AffineFastState.compose env35235 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound35235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35236 : List Nat := [2,4,8,16,32,17,8,52,512,20,513,16,56,49,1,50,33,529,21,0,0,33,17,2,56,17,513,32,17,528,37,32,53,33,48,513]

theorem envBound35236 : H12AffineFastState.Bounded env35236 := by
  intro p hp
  have h : env35236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35235_35236 : H12AffineEnvironment.transform 7 52 env35235 = env35236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env35235 == env35236) = true)

def env35237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180224,169234,8193,64,245019,115014,17664,262145,119043,329730,257,213351,237643,63069]

theorem envBound35237 : H12AffineFastState.Bounded env35237 := by
  intro p hp
  have h : env35237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35218_35237 : H12AffineEnvironment.transform 6 9 env35218 = env35237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35218 == env35237) = true)

def env35238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,16,21762,8193,64,97547,115014,17664,262145,119043,329730,257,98679,90203,63069]

theorem envBound35238 : H12AffineFastState.Bounded env35238 := by
  intro p hp
  have h : env35238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35237_35238 : H12AffineEnvironment.transform 16 49168 env35237 = env35238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35237 == env35238) = true)

theorem identity35238 : scanCanonicalize (H12AffineFastState.compose env35238 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35238 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24909,262144,1025,8540,4160,272392,16,21762,8193,64,97547,90139,17664,262145,94302,329730,257,73770,90203,22272]

theorem envBound35239 : H12AffineFastState.Bounded env35239 := by
  intro p hp
  have h : env35239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35238_35239 : H12AffineEnvironment.transform 14 8541 env35238 = env35239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35238 == env35239) = true)

theorem identity35239 : scanCanonicalize (H12AffineFastState.compose env35239 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound35239 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24909,97407,1025,8540,4160,87159,16,21762,8193,64,97547,90139,17664,97406,94302,29821,257,73770,90203,22272]

theorem envBound35240 : H12AffineFastState.Bounded env35240 := by
  intro p hp
  have h : env35240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35239_35240 : H12AffineEnvironment.transform 17 97407 env35239 = env35240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env35239 == env35240) = true)

theorem identity35240 : scanCanonicalize (H12AffineFastState.compose env35240 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound35240 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,24909,10281,1025,8540,4160,33,16,21762,8193,64,10589,13389,17664,10280,9224,29821,257,29820,13325,22272]

theorem envBound35241 : H12AffineFastState.Bounded env35241 := by
  intro p hp
  have h : env35241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35240_35241 : H12AffineEnvironment.transform 15 21590 env35240 = env35241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env35240 == env35241) = true)

theorem identity35241 : scanCanonicalize (H12AffineFastState.compose env35241 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound35241 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env35242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,8541,9499,4096,10281,1025,8540,4160,33,16,9295,8193,64,10589,13389,13389,10280,9224,1328,257,1329,13325,9805]

theorem envBound35242 : H12AffineFastState.Bounded env35242 := by
  intro p hp
  have h : env35242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35241_35242 : H12AffineEnvironment.transform 13 12621 env35241 = env35242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env35241 == env35242) = true)

theorem identity35242 : scanCanonicalize (H12AffineFastState.compose env35242 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35242 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env35243 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,12392,8312,9278,4096,10281,1025,8313,4160,33,16,9295,8193,64,10360,13389,13389,10280,9224,1045,36,1044,13325,9805]

theorem envBound35243 : H12AffineFastState.Bounded env35243 := by
  intro p hp
  have h : env35243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35242_35243 : H12AffineEnvironment.transform 7 37 env35242 = env35243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35242 == env35243) = true)

theorem identity35243 : scanCanonicalize (H12AffineFastState.compose env35243 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35243 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env35244 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,8192,12392,8312,8282,4096,10281,101,8313,4160,33,16,8235,8193,64,10360,12329,12329,10280,8300,113,36,112,12393,8745]

theorem envBound35244 : H12AffineFastState.Bounded env35244 := by
  intro p hp
  have h : env35244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35243_35244 : H12AffineEnvironment.transform 9 100 env35243 = env35244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35243 == env35244) = true)

theorem identity35244 : scanCanonicalize (H12AffineFastState.compose env35244 (packedSelected [0,2,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound35244 : packedSelected [0,2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35245 : List Nat := [2,4,8,16,32,64,9,37,0,100,2048,4096,8192,12392,8312,8282,4096,10281,101,8313,4160,33,16,8235,8193,64,10360,12329,12329,10280,8300,113,36,112,12393,8233]

theorem envBound35245 : H12AffineFastState.Bounded env35245 := by
  intro p hp
  have h : env35245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35244_35245 : H12AffineEnvironment.transform 8 0 env35244 = env35245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env35244 == env35245) = true)

theorem identity35245 : scanCanonicalize (H12AffineFastState.compose env35245 (packedSelected [3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound35245 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env35246 : List Nat := [2,4,8,16,32,64,9,37,0,100,2048,2112,8192,10280,8312,8282,2112,10281,101,8313,2048,33,16,8235,8193,64,10360,10345,10345,10280,8300,113,36,112,10281,8233]

theorem envBound35246 : H12AffineFastState.Bounded env35246 := by
  intro p hp
  have h : env35246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35245_35246 : H12AffineEnvironment.transform 11 2112 env35245 = env35246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env35245 == env35246) = true)

theorem identity35246 : scanCanonicalize (H12AffineFastState.compose env35246 (packedSelected [0,1,2,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound35246 : packedSelected [0,1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env35247 : List Nat := [2,4,8,16,32,64,9,37,0,100,2048,2112,120,2128,0,34,2112,2129,101,1,2048,33,16,83,121,64,2048,2065,2065,2128,20,113,36,112,2129,81]

theorem envBound35247 : H12AffineFastState.Bounded env35247 := by
  intro p hp
  have h : env35247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35246_35247 : H12AffineEnvironment.transform 12 120 env35246 = env35247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env35246 == env35247) = true)

theorem identity35247 : scanCanonicalize (H12AffineFastState.compose env35247 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound35247 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35248 : List Nat := [2,4,8,16,32,64,9,37,0,100,32,96,120,112,0,34,96,113,101,1,32,33,16,83,121,64,32,49,49,112,20,113,36,112,113,81]

theorem envBound35248 : H12AffineFastState.Bounded env35248 := by
  intro p hp
  have h : env35248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35247_35248 : H12AffineEnvironment.transform 10 32 env35247 = env35248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env35247 == env35248) = true)

theorem identity35248 : scanCanonicalize (H12AffineFastState.compose env35248 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35248 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env35249 : List Nat := [2,4,8,16,32,16,9,37,0,52,32,48,40,32,0,34,48,33,53,1,32,33,16,3,41,16,32,49,49,32,20,33,36,32,33,1]

theorem envBound35249 : H12AffineFastState.Bounded env35249 := by
  intro p hp
  have h : env35249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35248_35249 : H12AffineEnvironment.transform 5 16 env35248 = env35249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35248 == env35249) = true)

theorem identity35249 : scanCanonicalize (H12AffineFastState.compose env35249 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35250 : List Nat := [2,4,8,1,32,1,9,37,0,37,32,33,40,32,0,34,33,33,36,1,32,33,1,3,41,1,32,32,32,32,5,33,36,32,33,1]

theorem envBound35250 : H12AffineFastState.Bounded env35250 := by
  intro p hp
  have h : env35250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35249_35250 : H12AffineEnvironment.transform 3 1 env35249 = env35250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35249 == env35250) = true)

theorem identity35250 : scanCanonicalize (H12AffineFastState.compose env35250 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35251 : List Nat := [2,4,2,1,32,1,3,37,0,37,32,33,34,32,0,34,33,33,36,1,32,33,1,3,35,1,32,32,32,32,5,33,36,32,33,1]

theorem envBound35251 : H12AffineFastState.Bounded env35251 := by
  intro p hp
  have h : env35251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35250_35251 : H12AffineEnvironment.transform 2 2 env35250 = env35251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35250 == env35251) = true)

theorem identity35251 : scanCanonicalize (H12AffineFastState.compose env35251 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35252 : List Nat := [2,4,2,1,0,1,3,5,0,5,0,1,2,0,0,2,1,1,4,1,0,1,1,3,3,1,0,0,0,0,5,1,4,0,1,1]

theorem envBound35252 : H12AffineFastState.Bounded env35252 := by
  intro p hp
  have h : env35252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35251_35252 : H12AffineEnvironment.transform 4 0 env35251 = env35252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35251 == env35252) = true)

def env35253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21763,8193,64,97546,115014,17664,262145,119043,329730,257,98678,90202,63069]

theorem envBound35253 : H12AffineFastState.Bounded env35253 := by
  intro p hp
  have h : env35253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35237_35253 : H12AffineEnvironment.transform 16 49169 env35237 = env35253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35237 == env35253) = true)

theorem identity35253 : scanCanonicalize (H12AffineFastState.compose env35253 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,4161,41340,17,21763,8193,64,97546,115014,17664,35189,119043,98678,257,98678,90202,63069]

theorem envBound35254 : H12AffineFastState.Bounded env35254 := by
  intro p hp
  have h : env35254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35253_35254 : H12AffineEnvironment.transform 17 35188 env35253 = env35254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35253 == env35254) = true)

theorem identity35254 : scanCanonicalize (H12AffineFastState.compose env35254 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound35254 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env35255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8575,49169,35188,1025,32769,4161,41340,17,21763,8193,64,23669,57401,17664,35189,61564,40969,257,40969,16677,63069]

theorem envBound35255 : H12AffineFastState.Bounded env35255 := by
  intro p hp
  have h : env35255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35254_35255 : H12AffineEnvironment.transform 15 8575 env35254 = env35255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env35254 == env35255) = true)

theorem identity35255 : scanCanonicalize (H12AffineFastState.compose env35255 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35255 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env35256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,34,49169,35188,1025,32769,4161,32801,17,21763,348,64,23669,49508,17664,35189,53537,33108,257,33108,16677,55040]

theorem envBound35256 : H12AffineFastState.Bounded env35256 := by
  intro p hp
  have h : env35256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35255_35256 : H12AffineEnvironment.transform 12 349 env35255 = env35256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35255 == env35256) = true)

theorem identity35256 : scanCanonicalize (H12AffineFastState.compose env35256 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35256 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env35257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,34,5392,23669,1025,21760,4161,21792,17,21763,348,64,23669,5221,17664,23668,1056,21589,257,21589,16677,513]

theorem envBound35257 : H12AffineFastState.Bounded env35257 := by
  intro p hp
  have h : env35257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35256_35257 : H12AffineEnvironment.transform 14 21761 env35256 = env35257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35256 == env35257) = true)

theorem identity35257 : scanCanonicalize (H12AffineFastState.compose env35257 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound35257 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35258 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,16384,20836,34,4469,22544,100,20837,4161,20805,17,20838,348,64,22544,4096,16741,22545,69,20528,257,20528,16677,513]

theorem envBound35258 : H12AffineFastState.Bounded env35258 := by
  intro p hp
  have h : env35258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35257_35258 : H12AffineEnvironment.transform 9 101 env35257 = env35258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env35257 == env35258) = true)

theorem identity35258 : scanCanonicalize (H12AffineFastState.compose env35258 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound35258 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env35259 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4404,80,34,4469,2340,100,81,4161,113,17,82,348,64,2340,4096,4177,2341,69,260,257,260,4113,513]

theorem envBound35259 : H12AffineFastState.Bounded env35259 := by
  intro p hp
  have h : env35259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35258_35259 : H12AffineEnvironment.transform 13 4404 env35258 = env35259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env35258 == env35259) = true)

theorem identity35259 : scanCanonicalize (H12AffineFastState.compose env35259 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35259 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35260 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4161,80,34,4096,2129,100,81,4161,113,17,82,41,64,2129,4096,4177,2128,69,113,116,113,4113,513]

theorem envBound35260 : H12AffineFastState.Bounded env35260 := by
  intro p hp
  have h : env35260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35259_35260 : H12AffineEnvironment.transform 7 117 env35259 = env35260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35259 == env35260) = true)

theorem identity35260 : scanCanonicalize (H12AffineFastState.compose env35260 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound35260 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35261 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,592,40,529,80,34,592,2129,100,81,529,113,17,82,41,64,2129,592,513,2128,69,113,116,113,577,513]

theorem envBound35261 : H12AffineFastState.Bounded env35261 := by
  intro p hp
  have h : env35261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35260_35261 : H12AffineEnvironment.transform 11 592 env35260 = env35261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env35260 == env35261) = true)

theorem identity35261 : scanCanonicalize (H12AffineFastState.compose env35261 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35261 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35262 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,592,8,529,80,2,592,2129,68,81,529,81,17,82,9,64,2129,592,513,2128,69,81,84,81,577,513]

theorem envBound35262 : H12AffineFastState.Bounded env35262 := by
  intro p hp
  have h : env35262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35261_35262 : H12AffineEnvironment.transform 4 0 env35261 = env35262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35261 == env35262) = true)

theorem identity35262 : scanCanonicalize (H12AffineFastState.compose env35262 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound35262 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35263 : List Nat := [2,4,8,16,0,64,9,85,512,69,64,592,8,529,80,2,592,17,68,81,529,81,17,82,9,64,17,592,513,16,69,81,84,81,577,513]

theorem envBound35263 : H12AffineFastState.Bounded env35263 := by
  intro p hp
  have h : env35263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35262_35263 : H12AffineEnvironment.transform 10 64 env35262 = env35263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env35262 == env35263) = true)

theorem identity35263 : scanCanonicalize (H12AffineFastState.compose env35263 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35263 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35264 : List Nat := [2,4,8,16,0,64,9,85,17,69,64,65,8,0,80,2,65,17,68,81,0,81,17,82,9,64,17,65,16,16,69,81,84,81,80,16]

theorem envBound35264 : H12AffineFastState.Bounded env35264 := by
  intro p hp
  have h : env35264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35263_35264 : H12AffineEnvironment.transform 8 17 env35263 = env35264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35263 == env35264) = true)

theorem identity35264 : scanCanonicalize (H12AffineFastState.compose env35264 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35264 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35265 : List Nat := [2,4,8,1,0,64,9,68,0,69,64,65,8,0,65,2,65,0,68,64,0,64,0,67,9,64,0,65,1,1,69,64,69,64,65,1]

theorem envBound35265 : H12AffineFastState.Bounded env35265 := by
  intro p hp
  have h : env35265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35264_35265 : H12AffineEnvironment.transform 3 1 env35264 = env35265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35264 == env35265) = true)

def env35266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,169235,8328,64,4691218,115151,17665,262145,119042,4268163,257,213486,237643,63189]

theorem envBound35266 : H12AffineFastState.Bounded env35266 := by
  intro p hp
  have h : env35266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35187_35266 : H12AffineEnvironment.transform 20 184401 env35187 = env35266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env35187 == env35266) = true)

def env35267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,169235,8328,64,245138,115151,17665,262145,119042,329731,257,213486,237643,63189]

theorem envBound35267 : H12AffineFastState.Bounded env35267 := by
  intro p hp
  have h : env35267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35266_35267 : H12AffineEnvironment.transform 21 272512 env35266 = env35267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35266 == env35267) = true)

theorem identity35267 : scanCanonicalize (H12AffineFastState.compose env35267 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound35267 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58516,272512,62661,41430,8328,64,100695,115151,17665,262145,119042,329731,257,95531,103566,63189]

theorem envBound35268 : H12AffineFastState.Bounded env35268 := by
  intro p hp
  have h : env35268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35267_35268 : H12AffineEnvironment.transform 16 13509 env35267 = env35268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env35267 == env35268) = true)

def env35269 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58516,272512,62613,41350,8328,16,100615,115103,17665,262145,119042,329731,257,95531,103566,63109]

theorem envBound35269 : H12AffineFastState.Bounded env35269 := by
  intro p hp
  have h : env35269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35268_35269 : H12AffineEnvironment.transform 5 16 env35268 = env35269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35268 == env35269) = true)

theorem identity35269 : scanCanonicalize (H12AffineFastState.compose env35269 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound35269 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env35270 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,100523,1025,32769,58516,106539,62613,41350,8328,16,100615,115103,17665,100522,119042,32936,257,95531,103566,63109]

theorem envBound35270 : H12AffineFastState.Bounded env35270 := by
  intro p hp
  have h : env35270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35269_35270 : H12AffineEnvironment.transform 17 100523 env35269 = env35270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env35269 == env35270) = true)

theorem identity35270 : scanCanonicalize (H12AffineFastState.compose env35270 (packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound35270 : packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env35271 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,65536,13461,100523,1025,32769,45341,106539,41244,41350,8328,16,100615,103446,4232,100522,99467,32936,257,73890,103566,41740]

theorem envBound35271 : H12AffineFastState.Bounded env35271 := by
  intro p hp
  have h : env35271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35270_35271 : H12AffineEnvironment.transform 13 5513 env35270 = env35271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env35270 == env35271) = true)

theorem identity35271 : scanCanonicalize (H12AffineFastState.compose env35271 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound35271 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env35272 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,40971,13461,10400,1025,32769,45341,32,41244,41350,8328,16,10508,13341,4232,10401,9344,32936,257,32937,13445,41740]

theorem envBound35272 : H12AffineFastState.Bounded env35272 := by
  intro p hp
  have h : env35272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35271_35272 : H12AffineEnvironment.transform 15 40971 env35271 = env35272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env35271 == env35272) = true)

theorem identity35272 : scanCanonicalize (H12AffineFastState.compose env35272 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35272 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,1,8202,13461,10400,1025,0,12572,32,8477,8583,8328,16,10508,13341,4232,10401,9344,169,257,168,13445,8973]

theorem envBound35273 : H12AffineFastState.Bounded env35273 := by
  intro p hp
  have h : env35273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35272_35273 : H12AffineEnvironment.transform 14 1 env35272 = env35273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35272 == env35273) = true)

theorem identity35273 : scanCanonicalize (H12AffineFastState.compose env35273 (packedSelected [0,2,7,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 5253) := by decide +kernel

theorem selectedBound35273 : packedSelected [0,2,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35274 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5253,5513,1,5263,16,7205,1025,0,1433,32,5528,5378,5133,16,7561,152,4232,7204,4101,169,257,168,0,6024]

theorem envBound35274 : H12AffineFastState.Bounded env35274 := by
  intro p hp
  have h : env35274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35273_35274 : H12AffineEnvironment.transform 12 5253 env35273 = env35274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5253 env35273 == env35274) = true)

theorem identity35274 : scanCanonicalize (H12AffineFastState.compose env35274 (packedSelected [0,1,2,4,6,7,8,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound35274 : packedSelected [0,1,2,4,6,7,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35275 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1297,4096,5253,5513,1,5263,16,4404,1025,0,1433,32,5528,5378,5133,16,4248,152,4232,4405,4101,169,257,168,0,6024]

theorem envBound35275 : H12AffineFastState.Bounded env35275 := by
  intro p hp
  have h : env35275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35274_35275 : H12AffineEnvironment.transform 10 1297 env35274 = env35275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env35274 == env35275) = true)

theorem identity35275 : scanCanonicalize (H12AffineFastState.compose env35275 (packedSelected [1,2,3,4,5,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound35275 : packedSelected [1,2,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35276 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1297,17,1172,1432,1,1182,16,293,1025,0,1433,32,1417,1299,1052,16,137,152,153,292,20,169,257,168,0,1945]

theorem envBound35276 : H12AffineFastState.Bounded env35276 := by
  intro p hp
  have h : env35276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35275_35276 : H12AffineEnvironment.transform 11 17 env35275 = env35276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35275 == env35276) = true)

theorem identity35276 : scanCanonicalize (H12AffineFastState.compose env35276 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35276 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35277 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1297,17,1053,1297,1,1047,16,293,1025,0,1296,32,1280,1299,1052,16,0,17,16,292,20,32,257,33,0,1808]

theorem envBound35277 : H12AffineFastState.Bounded env35277 := by
  intro p hp
  have h : env35277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35276_35277 : H12AffineEnvironment.transform 6 9 env35276 = env35277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35276 == env35277) = true)

theorem identity35277 : scanCanonicalize (H12AffineFastState.compose env35277 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35277 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0