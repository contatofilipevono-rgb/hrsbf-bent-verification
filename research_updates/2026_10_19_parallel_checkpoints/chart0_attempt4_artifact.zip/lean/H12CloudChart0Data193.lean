import H12CloudChart0Data192

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env48878 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,0,9,1,1,2,0,0,4,0,1,0,1,2,9,1,0,1,1,1,4,0,4,1,0,1]

theorem envBound48878 : H12AffineFastState.Bounded env48878 := by
  intro p hp
  have h : env48878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48877_48878 : H12AffineEnvironment.transform 3 1 env48877 = env48878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48877 == env48878) = true)

def env48879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147456,16777216,8328,64,21039612,18949585,2233680,2557,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound48879 : H12AffineFastState.Bounded env48879 := by
  intro p hp
  have h : env48879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48822_48879 : H12AffineEnvironment.transform 17 10401 env48822 = env48879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48822 == env48879) = true)

theorem identity48879 : scanCanonicalize (H12AffineFastState.compose env48879 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound48879 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10401,1024,8541,2097152,4194304,16,16777216,8328,64,21039612,18949585,2118976,2557,16852317,23160256,256,18965984,18949401,16777867]

theorem envBound48880 : H12AffineFastState.Bounded env48880 := by
  intro p hp
  have h : env48880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48879_48880 : H12AffineEnvironment.transform 16 16400 env48879 = env48880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48879 == env48880) = true)

def env48881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,2097152,4194304,16,16777216,8192,64,21039476,18949465,2118976,2421,16852317,23160136,256,18965864,18949401,16777731]

theorem envBound48881 : H12AffineFastState.Bounded env48881 := by
  intro p hp
  have h : env48881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48880_48881 : H12AffineEnvironment.transform 6 8 env48880 = env48881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48880 == env48881) = true)

theorem identity48881 : scanCanonicalize (H12AffineFastState.compose env48881 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound48881 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env48882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,91198,4194304,16,16777216,8192,64,21039476,16793959,78206,2421,16852317,20971894,256,16777558,16793895,16777731]

theorem envBound48882 : H12AffineFastState.Bounded env48882 := by
  intro p hp
  have h : env48882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48881_48882 : H12AffineEnvironment.transform 20 91198 env48881 = env48882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env48881 == env48882) = true)

theorem identity48882 : scanCanonicalize (H12AffineFastState.compose env48882 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48882 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env48883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1024,8541,17461,4194304,16,16777216,8192,64,20982143,16793959,4469,2421,16778582,20971894,256,16777558,16793895,16777731]

theorem envBound48883 : H12AffineFastState.Bounded env48883 := by
  intro p hp
  have h : env48883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48882_48883 : H12AffineEnvironment.transform 15 8203 env48882 = env48883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48882 == env48883) = true)

theorem identity48883 : scanCanonicalize (H12AffineFastState.compose env48883 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound48883 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env48884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1024,8541,17461,32,16,16777216,8192,64,16787807,16793959,4469,2421,16778582,16777558,256,16777558,16793895,16777731]

theorem envBound48884 : H12AffineFastState.Bounded env48884 := by
  intro p hp
  have h : env48884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48883_48884 : H12AffineEnvironment.transform 21 32 env48883 = env48884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env48883 == env48884) = true)

theorem identity48884 : scanCanonicalize (H12AffineFastState.compose env48884 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound48884 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8203,13624,10281,1024,8541,12573,32,16,16777216,8192,64,16787807,16790607,4469,2421,16778582,16777558,256,16777558,16790543,16777731]

theorem envBound48885 : H12AffineFastState.Bounded env48885 := by
  intro p hp
  have h : env48885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48884_48885 : H12AffineEnvironment.transform 13 13608 env48884 = env48885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env48884 == env48885) = true)

theorem identity48885 : scanCanonicalize (H12AffineFastState.compose env48885 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound48885 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8203,13624,10281,1024,8541,12573,32,16,34,8192,64,10621,13421,4469,2421,1396,372,256,372,13357,545]

theorem envBound48886 : H12AffineFastState.Bounded env48886 := by
  intro p hp
  have h : env48886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48885_48886 : H12AffineEnvironment.transform 23 34 env48885 = env48886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env48885 == env48886) = true)

theorem identity48886 : scanCanonicalize (H12AffineFastState.compose env48886 (packedSelected [2,6,17] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48886 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env48887 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13577,8540,8203,13593,10248,1024,8541,12573,1,16,3,8192,64,10588,13388,4436,2388,1365,341,256,341,13324,512]

theorem envBound48887 : H12AffineFastState.Bounded env48887 := by
  intro p hp
  have h : env48887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48886_48887 : H12AffineEnvironment.transform 4 1 env48886 = env48887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48886 == env48887) = true)

theorem identity48887 : scanCanonicalize (H12AffineFastState.compose env48887 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48887 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48888 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5204,1,342,5188,2389,1024,0,4160,1,16,3,349,64,2049,5393,4436,2388,1365,341,256,341,5457,512]

theorem envBound48888 : H12AffineFastState.Bounded env48888 := by
  intro p hp
  have h : env48888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48887_48888 : H12AffineEnvironment.transform 12 349 env48887 = env48888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48887 == env48888) = true)

theorem identity48888 : scanCanonicalize (H12AffineFastState.compose env48888 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound48888 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48889 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1818,4096,349,5204,1,342,5188,1615,1024,0,4160,1,16,3,349,64,1819,5393,4436,1614,1365,341,256,341,5457,512]

theorem envBound48889 : H12AffineFastState.Bounded env48889 := by
  intro p hp
  have h : env48889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48888_48889 : H12AffineEnvironment.transform 10 1818 env48888 = env48889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env48888 == env48889) = true)

theorem identity48889 : scanCanonicalize (H12AffineFastState.compose env48889 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound48889 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env48890 : List Nat := [2,4,8,16,1,64,8,85,512,1024,1615,4096,8,5204,1,3,5188,1615,1024,0,4160,1,16,3,8,64,1614,5188,4097,1614,1024,0,85,0,5124,512]

theorem envBound48890 : H12AffineFastState.Bounded env48890 := by
  intro p hp
  have h : env48890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48889_48890 : H12AffineEnvironment.transform 7 85 env48889 = env48890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env48889 == env48890) = true)

theorem identity48890 : scanCanonicalize (H12AffineFastState.compose env48890 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound48890 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48891 : List Nat := [2,4,8,16,1,64,8,85,91,1024,1044,4096,8,5204,1,3,5188,1044,1024,0,4160,1,16,3,8,64,1045,5188,4097,1045,1024,0,85,0,5124,91]

theorem envBound48891 : H12AffineFastState.Bounded env48891 := by
  intro p hp
  have h : env48891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48890_48891 : H12AffineEnvironment.transform 8 91 env48890 = env48891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env48890 == env48891) = true)

theorem identity48891 : scanCanonicalize (H12AffineFastState.compose env48891 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound48891 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48892 : List Nat := [2,4,8,16,1,64,8,85,91,1024,1044,6,8,1106,1,3,1090,1044,1024,0,70,1,16,3,8,64,1045,1090,7,1045,1024,0,85,0,1026,91]

theorem envBound48892 : H12AffineFastState.Bounded env48892 := by
  intro p hp
  have h : env48892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48891_48892 : H12AffineEnvironment.transform 11 6 env48891 = env48892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env48891 == env48892) = true)

theorem identity48892 : scanCanonicalize (H12AffineFastState.compose env48892 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48892 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env48893 : List Nat := [2,4,8,16,1,64,8,85,91,4,16,6,8,86,1,3,70,16,4,0,70,1,16,3,8,64,17,70,7,17,4,0,85,0,6,91]

theorem envBound48893 : H12AffineFastState.Bounded env48893 := by
  intro p hp
  have h : env48893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48892_48893 : H12AffineEnvironment.transform 9 4 env48892 = env48893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48892 == env48893) = true)

def env48894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,16777216,8193,64,21039477,18949464,2118976,2420,16852317,23160137,256,18965865,18949401,16777730]

theorem envBound48894 : H12AffineFastState.Bounded env48894 := by
  intro p hp
  have h : env48894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48880_48894 : H12AffineEnvironment.transform 6 9 env48880 = env48894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48880 == env48894) = true)

theorem identity48894 : scanCanonicalize (H12AffineFastState.compose env48894 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48894 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,2097152,4194304,16,16777216,8193,64,20982142,18875731,2118976,2420,16778582,23086402,256,18892130,18875666,16777730]

theorem envBound48895 : H12AffineFastState.Bounded env48895 := by
  intro p hp
  have h : env48895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48894_48895 : H12AffineEnvironment.transform 15 8203 env48894 = env48895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48894 == env48895) = true)

theorem identity48895 : scanCanonicalize (H12AffineFastState.compose env48895 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound48895 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env48896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,2097152,32,16,16777216,8193,64,16787806,18875731,2118976,2420,16778582,18892130,256,18892130,18875666,16777730]

theorem envBound48896 : H12AffineFastState.Bounded env48896 := by
  intro p hp
  have h : env48896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48895_48896 : H12AffineEnvironment.transform 21 32 env48895 = env48896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env48895 == env48896) = true)

theorem identity48896 : scanCanonicalize (H12AffineFastState.compose env48896 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound48896 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,13689,32,16,16777216,8193,64,16787806,16789546,24633,2420,16778582,16805915,256,16805915,16789611,16777730]

theorem envBound48897 : H12AffineFastState.Bounded env48897 := by
  intro p hp
  have h : env48897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48896_48897 : H12AffineEnvironment.transform 20 13689 env48896 = env48897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env48896 == env48897) = true)

theorem identity48897 : scanCanonicalize (H12AffineFastState.compose env48897 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound48897 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env48898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10280,1024,8541,13689,32,16,16777216,8193,64,16787806,16789546,12329,2420,16778582,16785419,256,16785419,16789611,16777730]

theorem envBound48898 : H12AffineFastState.Bounded env48898 := by
  intro p hp
  have h : env48898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48897_48898 : H12AffineEnvironment.transform 13 4112 env48897 = env48898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env48897 == env48898) = true)

theorem identity48898 : scanCanonicalize (H12AffineFastState.compose env48898 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48898 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env48899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4112,373,34,4096,2049,1024,372,5456,32,16,16777216,40,64,16779639,16781315,4096,2420,16778582,16777250,256,16777250,16781378,16777730]

theorem envBound48899 : H12AffineFastState.Bounded env48899 := by
  intro p hp
  have h : env48899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48898_48899 : H12AffineEnvironment.transform 12 41 env48898 = env48899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48898 == env48899) = true)

theorem identity48899 : scanCanonicalize (H12AffineFastState.compose env48899 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound48899 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48900 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,41,4112,373,34,4096,2049,69,372,4373,32,16,16777216,40,64,16779639,16781315,4096,2420,16777491,16777250,256,16777250,16781378,16777730]

theorem envBound48900 : H12AffineFastState.Bounded env48900 := by
  intro p hp
  have h : env48900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48899_48900 : H12AffineEnvironment.transform 9 69 env48899 = env48900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env48899 == env48900) = true)

def env48901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147457,16777216,8328,64,21307740,18949585,2233681,270685,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound48901 : H12AffineFastState.Bounded env48901 := by
  intro p hp
  have h : env48901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48821_48901 : H12AffineEnvironment.transform 22 147457 env48821 = env48901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env48821 == env48901) = true)

theorem identity48901 : scanCanonicalize (H12AffineFastState.compose env48901 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147611) := by decide +kernel

theorem selectedBound48901 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147457,147611,8328,64,4678087,2319690,2233681,270685,75223,6497627,256,2188650,2172307,513]

theorem envBound48902 : H12AffineFastState.Bounded env48902 := by
  intro p hp
  have h : env48902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48901_48902 : H12AffineEnvironment.transform 23 147611 env48901 = env48902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147611 env48901 == env48902) = true)

def env48903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147457,147611,8328,64,4409703,2319690,2233681,2557,75223,6497627,256,2188650,2172307,513]

theorem envBound48903 : H12AffineFastState.Bounded env48903 := by
  intro p hp
  have h : env48903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48902_48903 : H12AffineEnvironment.transform 17 10400 env48902 = env48903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48902 == env48903) = true)

def env48904 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147457,147611,8328,16,4409655,2319642,2233601,2477,75143,6497547,256,2188602,2172307,513]

theorem envBound48904 : H12AffineFastState.Bounded env48904 := by
  intro p hp
  have h : env48904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48903_48904 : H12AffineEnvironment.transform 5 16 env48903 = env48904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48903 == env48904) = true)

theorem identity48904 : scanCanonicalize (H12AffineFastState.compose env48904 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound48904 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env48905 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,155964,147457,147611,8328,16,75787,2319642,2233601,2477,75143,2180151,256,2188602,2172307,513]

theorem envBound48905 : H12AffineFastState.Bounded env48905 := by
  intro p hp
  have h : env48905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48904_48905 : H12AffineEnvironment.transform 21 155964 env48904 = env48905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env48904 == env48905) = true)

theorem identity48905 : scanCanonicalize (H12AffineFastState.compose env48905 (packedSelected [2,3,4,5,6,11,14,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound48905 : packedSelected [2,3,4,5,6,11,14,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48906 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,131072,10400,1024,8461,2097152,155964,147457,147611,8328,16,10629,2253972,2233601,2477,9225,2115001,256,2122932,2106397,513]

theorem envBound48906 : H12AffineFastState.Bounded env48906 := by
  intro p hp
  have h : env48906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48905_48906 : H12AffineEnvironment.transform 15 398 env48905 = env48906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env48905 == env48906) = true)

theorem identity48906 : scanCanonicalize (H12AffineFastState.compose env48906 (packedSelected [10,11,14,15,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 140421) := by decide +kernel

theorem selectedBound48906 : packedSelected [10,11,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env48907 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,131072,10400,1024,8461,140421,155964,147457,147611,8328,16,10629,16401,12676,2477,9225,155964,256,147505,131224,513]

theorem envBound48907 : H12AffineFastState.Bounded env48907 := by
  intro p hp
  have h : env48907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48906_48907 : H12AffineEnvironment.transform 20 140421 env48906 = env48907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140421 env48906 == env48907) = true)

theorem identity48907 : scanCanonicalize (H12AffineFastState.compose env48907 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound48907 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env48908 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,16537,10400,1024,8461,25628,8613,152,2,8328,16,10629,16401,12676,2477,9225,8613,256,168,16385,513]

theorem envBound48908 : H12AffineFastState.Bounded env48908 := by
  intro p hp
  have h : env48908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48907_48908 : H12AffineEnvironment.transform 16 16537 env48907 = env48908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env48907 == env48908) = true)

theorem identity48908 : scanCanonicalize (H12AffineFastState.compose env48908 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound48908 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48909 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,136,398,16537,2340,1024,137,17816,33,152,2,268,16,2049,16401,4096,2477,1421,33,256,168,16385,513]

theorem envBound48909 : H12AffineFastState.Bounded env48909 := by
  intro p hp
  have h : env48909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48908_48909 : H12AffineEnvironment.transform 12 388 env48908 = env48909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env48908 == env48909) = true)

theorem identity48909 : scanCanonicalize (H12AffineFastState.compose env48909 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48909 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48910 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,262,16401,2340,1024,1,17680,33,16,2,268,16,2049,16401,4096,2341,1285,33,256,32,16385,513]

theorem envBound48910 : H12AffineFastState.Bounded env48910 := by
  intro p hp
  have h : env48910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48909_48910 : H12AffineEnvironment.transform 6 8 env48909 = env48910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48909 == env48910) = true)

theorem identity48910 : scanCanonicalize (H12AffineFastState.compose env48910 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48910 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48911 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,16384,0,262,16401,2340,273,1,16385,33,16,2,268,16,2049,16401,4096,2341,20,33,256,32,16385,513]

theorem envBound48911 : H12AffineFastState.Bounded env48911 := by
  intro p hp
  have h : env48911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48910_48911 : H12AffineEnvironment.transform 9 273 env48910 = env48911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48910 == env48911) = true)

theorem identity48911 : scanCanonicalize (H12AffineFastState.compose env48911 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48911 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48912 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,268,16384,0,262,16401,2340,273,1,16385,33,16,2,268,16,2049,16401,2064,2341,20,33,256,32,16385,513]

theorem envBound48912 : H12AffineFastState.Bounded env48912 := by
  intro p hp
  have h : env48912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48911_48912 : H12AffineEnvironment.transform 11 2064 env48911 = env48912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48911 == env48912) = true)

theorem identity48912 : scanCanonicalize (H12AffineFastState.compose env48912 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48912 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48913 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,41,16384,0,35,16401,2049,52,1,16385,33,16,2,41,16,2049,16401,2064,2048,20,33,37,32,16385,513]

theorem envBound48913 : H12AffineFastState.Bounded env48913 := by
  intro p hp
  have h : env48913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48912_48913 : H12AffineEnvironment.transform 7 37 env48912 = env48913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48912 == env48913) = true)

theorem identity48913 : scanCanonicalize (H12AffineFastState.compose env48913 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound48913 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env48914 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,41,2049,0,35,2064,2049,52,1,2048,33,16,2,41,16,2049,2064,2064,2048,20,33,37,32,2048,513]

theorem envBound48914 : H12AffineFastState.Bounded env48914 := by
  intro p hp
  have h : env48914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48913_48914 : H12AffineEnvironment.transform 13 2049 env48913 = env48914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env48913 == env48914) = true)

theorem identity48914 : scanCanonicalize (H12AffineFastState.compose env48914 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound48914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48915 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,41,48,0,35,33,48,52,1,49,33,16,2,41,16,48,33,33,49,20,33,37,32,49,513]

theorem envBound48915 : H12AffineFastState.Bounded env48915 := by
  intro p hp
  have h : env48915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48914_48915 : H12AffineEnvironment.transform 10 49 env48914 = env48915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env48914 == env48915) = true)

def leafEnv48915 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,41,48,0,35,33,48,52,1,49,33,16,2,20,41,1,16,48,33,33,49,20,33,37,32,4,35,49,513,1,48,0]

def active48915 : List Nat := [0,1,2,3,4,8]

def tree48915 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48915 : H12WitnessSearch.Good tree48915 := H12GlobalWitnessIndex.good

theorem leafIdentity48915 : H12AffineFastState.composeSystem env48915 rootObs = leafEnv48915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48915 rootObs == leafEnv48915) = true)

theorem terminalChecked48915 : H12PackedTerminal.terminalCheckFast leafEnv48915 active48915 tree48915 = true := by decide +kernel

def env48916 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147457,147611,8328,17,4409654,2319643,2233600,2476,75142,6497546,256,2188603,2172307,513]

theorem envBound48916 : H12AffineFastState.Bounded env48916 := by
  intro p hp
  have h : env48916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48903_48916 : H12AffineEnvironment.transform 5 17 env48903 = env48916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48903 == env48916) = true)

theorem identity48916 : scanCanonicalize (H12AffineFastState.compose env48916 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 2294822) := by decide +kernel

theorem selectedBound48916 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env48917 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,2294822,147457,147611,8328,17,2116880,2319643,2233600,2476,75142,8492,256,2188603,2172307,513]

theorem envBound48917 : H12AffineFastState.Bounded env48917 := by
  intro p hp
  have h : env48917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48916_48917 : H12AffineEnvironment.transform 21 2294822 env48916 = env48917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2294822 env48916 == env48917) = true)

theorem identity48917 : scanCanonicalize (H12AffineFastState.compose env48917 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound48917 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48918 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,65536,131072,2341,1024,137,2097152,2294822,147457,147611,269,17,2116880,2311326,2233600,2476,66563,169,256,2180286,2163734,513]

theorem envBound48918 : H12AffineFastState.Bounded env48918 := by
  intro p hp
  have h : env48918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48917_48918 : H12AffineEnvironment.transform 12 389 env48917 = env48918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env48917 == env48918) = true)

theorem identity48918 : scanCanonicalize (H12AffineFastState.compose env48918 (packedSelected [0,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound48918 : packedSelected [0,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env48919 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,65536,16536,2341,1024,137,2097152,2180286,153,3,269,17,2116880,2163718,2119064,2476,66563,169,256,2180286,2163734,513]

theorem envBound48919 : H12AffineFastState.Bounded env48919 := by
  intro p hp
  have h : env48919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48918_48919 : H12AffineEnvironment.transform 16 16536 env48918 = env48919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env48918 == env48919) = true)

theorem identity48919 : scanCanonicalize (H12AffineFastState.compose env48919 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(20+1) ^^^ 17817) := by decide +kernel

theorem selectedBound48919 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env48920 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,65536,16536,2341,1024,137,17817,65831,153,3,269,17,2185,82335,4097,2476,66563,169,256,65831,82319,513]

theorem envBound48920 : H12AffineFastState.Bounded env48920 := by
  intro p hp
  have h : env48920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48919_48920 : H12AffineEnvironment.transform 20 17817 env48919 = env48920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17817 env48919 == env48920) = true)

theorem identity48920 : scanCanonicalize (H12AffineFastState.compose env48920 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound48920 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48921 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,262,16536,2341,1024,137,17817,33,153,3,269,17,2185,16537,4097,2476,1285,169,256,33,16521,513]

theorem envBound48921 : H12AffineFastState.Bounded env48921 := by
  intro p hp
  have h : env48921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48920_48921 : H12AffineEnvironment.transform 15 262 env48920 = env48921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env48920 == env48921) = true)

theorem identity48921 : scanCanonicalize (H12AffineFastState.compose env48921 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48921 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48922 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1024,0,17680,33,16,3,269,17,2048,16400,4097,2341,1285,32,256,33,16384,513]

theorem envBound48922 : H12AffineFastState.Bounded env48922 := by
  intro p hp
  have h : env48922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48921_48922 : H12AffineEnvironment.transform 6 9 env48921 = env48922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48921 == env48922) = true)

theorem identity48922 : scanCanonicalize (H12AffineFastState.compose env48922 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound48922 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48923 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,1,262,5172,2341,1024,0,4405,33,16,3,269,17,2048,5173,4097,2341,1285,32,256,33,5157,513]

theorem envBound48923 : H12AffineFastState.Bounded env48923 := by
  intro p hp
  have h : env48923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48922_48923 : H12AffineEnvironment.transform 13 5157 env48922 = env48923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env48922 == env48923) = true)

def env48924 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2837,1,262,2820,2341,1024,0,3589,33,16,3,269,17,2048,2821,3889,2341,1285,32,256,33,2837,513]

theorem envBound48924 : H12AffineFastState.Bounded env48924 := by
  intro p hp
  have h : env48924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48923_48924 : H12AffineEnvironment.transform 11 3888 env48923 = env48924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env48923 == env48924) = true)

def env48925 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1045,1,262,1028,1573,1024,0,261,33,16,3,269,17,1792,1029,49,1573,1285,32,256,33,1045,513]

theorem envBound48925 : H12AffineFastState.Bounded env48925 := by
  intro p hp
  have h : env48925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48924_48925 : H12AffineEnvironment.transform 10 1792 env48924 = env48925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env48924 == env48925) = true)

theorem identity48925 : scanCanonicalize (H12AffineFastState.compose env48925 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48926 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,48,268,32,1,262,49,528,53,0,261,33,16,3,269,17,821,48,49,528,304,32,256,33,32,513]

theorem envBound48926 : H12AffineFastState.Bounded env48926 := by
  intro p hp
  have h : env48926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48925_48926 : H12AffineEnvironment.transform 9 53 env48925 = env48926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48925 == env48926) = true)

theorem identity48926 : scanCanonicalize (H12AffineFastState.compose env48926 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound48926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48927 : List Nat := [2,4,8,16,32,17,9,256,270,53,59,48,268,32,1,262,49,286,53,0,261,33,16,3,269,17,59,48,49,286,304,32,256,33,32,271]

theorem envBound48927 : H12AffineFastState.Bounded env48927 := by
  intro p hp
  have h : env48927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48926_48927 : H12AffineEnvironment.transform 8 270 env48926 = env48927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env48926 == env48927) = true)

def leafEnv48927 : List Nat := [2,4,8,16,32,17,9,256,270,53,59,48,268,32,1,262,49,286,53,0,261,33,16,3,304,269,1,17,59,48,49,286,304,32,256,33,4,263,32,271,1,261,0]

def active48927 : List Nat := [0,1,2,3,4,7]

def tree48927 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48927 : H12WitnessSearch.Good tree48927 := H12GlobalWitnessIndex.good

theorem leafIdentity48927 : H12AffineFastState.composeSystem env48927 rootObs = leafEnv48927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48927 rootObs == leafEnv48927) = true)

theorem terminalChecked48927 : H12PackedTerminal.terminalCheckFast leafEnv48927 active48927 tree48927 = true := by decide +kernel

def env48928 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1044,1,262,1029,1572,1024,0,260,33,16,3,269,17,1793,1028,48,1572,1285,32,256,33,1044,513]

theorem envBound48928 : H12AffineFastState.Bounded env48928 := by
  intro p hp
  have h : env48928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48924_48928 : H12AffineEnvironment.transform 10 1793 env48924 = env48928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env48924 == env48928) = true)

theorem identity48928 : scanCanonicalize (H12AffineFastState.compose env48928 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48929 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,40,1044,1,34,1029,1572,1024,0,32,33,16,3,41,17,1573,1028,48,1572,1057,32,36,33,1044,513]

theorem envBound48929 : H12AffineFastState.Bounded env48929 := by
  intro p hp
  have h : env48929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48928_48929 : H12AffineEnvironment.transform 7 36 env48928 = env48929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48928 == env48929) = true)

def env48930 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,32,1,34,49,528,52,0,32,33,16,3,41,17,529,48,48,528,21,32,36,33,32,513]

theorem envBound48930 : H12AffineFastState.Bounded env48930 := by
  intro p hp
  have h : env48930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48929_48930 : H12AffineEnvironment.transform 9 52 env48929 = env48930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48929 == env48930) = true)

def env48931 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,33,1,34,48,529,53,0,32,33,16,3,41,17,528,49,48,529,20,32,36,33,33,513]

theorem envBound48931 : H12AffineFastState.Bounded env48931 := by
  intro p hp
  have h : env48931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48929_48931 : H12AffineEnvironment.transform 9 53 env48929 = env48931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48929 == env48931) = true)

theorem identity48931 : scanCanonicalize (H12AffineFastState.compose env48931 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48932 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,40,33,1,34,48,58,53,0,32,33,16,3,41,17,59,49,48,58,20,32,36,33,33,42]

theorem envBound48932 : H12AffineFastState.Bounded env48932 := by
  intro p hp
  have h : env48932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48931_48932 : H12AffineEnvironment.transform 8 43 env48931 = env48932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48931 == env48932) = true)

def leafEnv48932 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,40,33,1,34,48,58,53,0,32,33,16,3,20,41,1,17,59,49,48,58,20,32,36,33,4,35,33,42,1,32,0]

def active48932 : List Nat := [0,1,2,3,4]

def tree48932 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48932 : H12WitnessSearch.Good tree48932 := H12GlobalWitnessIndex.good

theorem leafIdentity48932 : H12AffineFastState.composeSystem env48932 rootObs = leafEnv48932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48932 rootObs == leafEnv48932) = true)

theorem terminalChecked48932 : H12PackedTerminal.terminalCheckFast leafEnv48932 active48932 tree48932 = true := by decide +kernel

def env48933 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2836,1,262,2821,2341,1024,0,3588,33,16,3,269,17,2048,2820,3888,2341,1285,32,256,33,2836,513]

theorem envBound48933 : H12AffineFastState.Bounded env48933 := by
  intro p hp
  have h : env48933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48923_48933 : H12AffineEnvironment.transform 11 3889 env48923 = env48933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env48923 == env48933) = true)

def env48934 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1044,1,262,1029,1573,1024,0,260,33,16,3,269,17,1792,1028,48,1573,1285,32,256,33,1044,513]

theorem envBound48934 : H12AffineFastState.Bounded env48934 := by
  intro p hp
  have h : env48934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48933_48934 : H12AffineEnvironment.transform 10 1792 env48933 = env48934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env48933 == env48934) = true)

def env48935 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,49,268,32,1,262,49,529,52,0,260,33,16,3,269,17,820,48,48,529,305,32,256,33,32,513]

theorem envBound48935 : H12AffineFastState.Bounded env48935 := by
  intro p hp
  have h : env48935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48934_48935 : H12AffineEnvironment.transform 9 52 env48934 = env48935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48934 == env48935) = true)

def env48936 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,49,268,33,1,262,48,528,53,0,260,33,16,3,269,17,821,49,48,528,304,32,256,33,33,513]

theorem envBound48936 : H12AffineFastState.Bounded env48936 := by
  intro p hp
  have h : env48936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48934_48936 : H12AffineEnvironment.transform 9 53 env48934 = env48936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48934 == env48936) = true)

theorem identity48936 : scanCanonicalize (H12AffineFastState.compose env48936 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound48936 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48937 : List Nat := [2,4,8,16,32,17,9,256,271,53,58,49,268,33,1,262,48,287,53,0,260,33,16,3,269,17,58,49,48,287,304,32,256,33,33,270]

theorem envBound48937 : H12AffineFastState.Bounded env48937 := by
  intro p hp
  have h : env48937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48936_48937 : H12AffineEnvironment.transform 8 271 env48936 = env48937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env48936 == env48937) = true)

def leafEnv48937 : List Nat := [2,4,8,16,32,17,9,256,271,53,58,49,268,33,1,262,48,287,53,0,260,33,16,3,304,269,1,17,58,49,48,287,304,32,256,33,4,263,33,270,1,260,0]

def active48937 : List Nat := [0,1,2,3,4,7]

def tree48937 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48937 : H12WitnessSearch.Good tree48937 := H12GlobalWitnessIndex.good

theorem leafIdentity48937 : H12AffineFastState.composeSystem env48937 rootObs = leafEnv48937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48937 rootObs == leafEnv48937) = true)

theorem terminalChecked48937 : H12PackedTerminal.terminalCheckFast leafEnv48937 active48937 tree48937 = true := by decide +kernel

def env48938 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1045,1,262,1028,1572,1024,0,261,33,16,3,269,17,1793,1029,49,1572,1285,32,256,33,1045,513]

theorem envBound48938 : H12AffineFastState.Bounded env48938 := by
  intro p hp
  have h : env48938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48933_48938 : H12AffineEnvironment.transform 10 1793 env48933 = env48938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env48933 == env48938) = true)

theorem identity48938 : scanCanonicalize (H12AffineFastState.compose env48938 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48939 : List Nat := [2,4,8,16,32,17,9,256,512,273,528,48,268,260,1,262,277,821,273,0,261,33,16,3,269,17,528,276,49,821,20,32,256,33,260,513]

theorem envBound48939 : H12AffineFastState.Bounded env48939 := by
  intro p hp
  have h : env48939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48938_48939 : H12AffineEnvironment.transform 9 273 env48938 = env48939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48938 == env48939) = true)

def env48940 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,32,1,34,49,529,53,0,33,33,16,3,41,17,528,48,49,529,20,32,36,33,32,513]

theorem envBound48940 : H12AffineFastState.Bounded env48940 := by
  intro p hp
  have h : env48940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48939_48940 : H12AffineEnvironment.transform 7 36 env48939 = env48940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48939 == env48940) = true)

theorem identity48940 : scanCanonicalize (H12AffineFastState.compose env48940 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48941 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,40,32,1,34,49,59,53,0,33,33,16,3,41,17,58,48,49,59,20,32,36,33,32,43]

theorem envBound48941 : H12AffineFastState.Bounded env48941 := by
  intro p hp
  have h : env48941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48940_48941 : H12AffineEnvironment.transform 8 42 env48940 = env48941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48940 == env48941) = true)

def leafEnv48941 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,40,32,1,34,49,59,53,0,33,33,16,3,20,41,1,17,58,48,49,59,20,32,36,33,4,35,32,43,1,33,0]

def active48941 : List Nat := [0,1,2,3,4]

def tree48941 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48941 : H12WitnessSearch.Good tree48941 := H12GlobalWitnessIndex.good

theorem leafIdentity48941 : H12AffineFastState.composeSystem env48941 rootObs = leafEnv48941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48941 rootObs == leafEnv48941) = true)

theorem terminalChecked48941 : H12PackedTerminal.terminalCheckFast leafEnv48941 active48941 tree48941 = true := by decide +kernel

def env48942 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,48,41,33,1,35,48,528,52,0,32,33,16,3,40,17,528,49,49,528,20,32,37,33,33,513]

theorem envBound48942 : H12AffineFastState.Bounded env48942 := by
  intro p hp
  have h : env48942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48939_48942 : H12AffineEnvironment.transform 7 37 env48939 = env48942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48939 == env48942) = true)

def env48943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147457,147611,8328,64,4409702,2319690,2233681,2556,75223,6497627,256,2188650,2172307,513]

theorem envBound48943 : H12AffineFastState.Bounded env48943 := by
  intro p hp
  have h : env48943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48902_48943 : H12AffineEnvironment.transform 17 10401 env48902 = env48943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48902 == env48943) = true)

theorem identity48943 : scanCanonicalize (H12AffineFastState.compose env48943 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound48943 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10401,1024,8541,2097152,4194304,16,138,8328,64,4262263,2172251,2118976,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound48944 : H12AffineFastState.Bounded env48944 := by
  intro p hp
  have h : env48944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48943_48944 : H12AffineEnvironment.transform 16 16401 env48943 = env48944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env48943 == env48944) = true)

theorem identity48944 : scanCanonicalize (H12AffineFastState.compose env48944 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48944 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10401,1024,8541,2097152,4194304,16,138,8328,64,4204925,2098513,2118976,2556,1501,6309184,256,2114912,2098585,513]

theorem envBound48945 : H12AffineFastState.Bounded env48945 := by
  intro p hp
  have h : env48945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48944_48945 : H12AffineEnvironment.transform 15 8202 env48944 = env48945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48944 == env48945) = true)

theorem identity48945 : scanCanonicalize (H12AffineFastState.compose env48945 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound48945 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10401,1024,8541,5593,4194304,16,138,8328,64,4204925,4232,16537,2556,1501,4214937,256,20665,4160,513]

theorem envBound48946 : H12AffineFastState.Bounded env48946 := by
  intro p hp
  have h : env48946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48945_48946 : H12AffineEnvironment.transform 20 5593 env48945 = env48946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env48945 == env48946) = true)

theorem identity48946 : scanCanonicalize (H12AffineFastState.compose env48946 (packedSelected [0,3,5,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 20713) := by decide +kernel

theorem selectedBound48946 : packedSelected [0,3,5,10,14,27] rootPS < 2^1333 := by decide +kernel

def env48947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10401,1024,8541,5593,20713,16,138,8328,64,31124,4232,16537,2556,1501,112,256,20665,4160,513]

theorem envBound48947 : H12AffineFastState.Bounded env48947 := by
  intro p hp
  have h : env48947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48946_48947 : H12AffineEnvironment.transform 21 20713 env48946 = env48947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20713 env48946 == env48947) = true)

theorem identity48947 : scanCanonicalize (H12AffineFastState.compose env48947 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 11625) := by decide +kernel

theorem selectedBound48947 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env48948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11625,8540,8202,11640,10401,1024,8541,5593,15744,16,138,8328,64,5373,4232,11760,2556,1501,112,256,15824,4160,513]

theorem envBound48948 : H12AffineFastState.Bounded env48948 := by
  intro p hp
  have h : env48948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48947_48948 : H12AffineEnvironment.transform 13 11625 env48947 = env48948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11625 env48947 == env48948) = true)

theorem identity48948 : scanCanonicalize (H12AffineFastState.compose env48948 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound48948 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2209,1480,2557,2219,1497,0,1024,2556,5593,5409,16,138,2089,64,5373,4232,1361,2556,1501,112,256,5489,4160,513]

theorem envBound48949 : H12AffineFastState.Bounded env48949 := by
  intro p hp
  have h : env48949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48948_48949 : H12AffineEnvironment.transform 12 2209 env48948 = env48949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env48948 == env48949) = true)

theorem identity48949 : scanCanonicalize (H12AffineFastState.compose env48949 (packedSelected [1,8,10,11,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound48949 : packedSelected [1,8,10,11,15,23] rootPS < 2^1333 := by decide +kernel

def env48950 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,2209,429,2557,2219,444,0,101,2556,4540,4420,16,138,2089,64,4248,4232,308,2556,440,112,256,4372,4160,513]

theorem envBound48950 : H12AffineFastState.Bounded env48950 := by
  intro p hp
  have h : env48950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48949_48950 : H12AffineEnvironment.transform 9 101 env48949 = env48950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env48949 == env48950) = true)

theorem identity48950 : scanCanonicalize (H12AffineFastState.compose env48950 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound48950 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env48951 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,493,2209,429,2557,2219,444,0,101,2556,81,169,16,138,2089,64,373,357,308,2556,440,112,256,249,429,513]

theorem envBound48951 : H12AffineFastState.Bounded env48951 := by
  intro p hp
  have h : env48951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48950_48951 : H12AffineEnvironment.transform 11 493 env48950 = env48951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env48950 == env48951) = true)

theorem identity48951 : scanCanonicalize (H12AffineFastState.compose env48951 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound48951 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env48952 : List Nat := [2,4,8,16,32,64,128,256,512,101,509,493,348,429,0,342,444,0,101,1,81,169,16,138,468,64,373,357,308,1,440,112,256,249,429,513]

theorem envBound48952 : H12AffineFastState.Bounded env48952 := by
  intro p hp
  have h : env48952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48951_48952 : H12AffineEnvironment.transform 10 509 env48951 = env48952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env48951 == env48952) = true)

theorem identity48952 : scanCanonicalize (H12AffineFastState.compose env48952 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48952 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48953 : List Nat := [2,4,8,16,32,64,128,117,512,101,136,152,41,216,0,35,201,0,101,1,81,169,16,138,161,64,0,16,65,1,205,112,117,249,216,513]

theorem envBound48953 : H12AffineFastState.Bounded env48953 := by
  intro p hp
  have h : env48953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48952_48953 : H12AffineEnvironment.transform 7 117 env48952 = env48953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48952 == env48953) = true)

theorem identity48953 : scanCanonicalize (H12AffineFastState.compose env48953 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48953 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env48954 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,16,41,80,0,35,65,0,101,1,81,33,16,2,41,64,0,16,65,1,69,112,117,113,80,513]

theorem envBound48954 : H12AffineFastState.Bounded env48954 := by
  intro p hp
  have h : env48954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48953_48954 : H12AffineEnvironment.transform 6 8 env48953 = env48954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48953 == env48954) = true)

theorem identity48954 : scanCanonicalize (H12AffineFastState.compose env48954 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48955 : List Nat := [2,4,8,16,0,64,8,85,512,69,0,16,9,80,0,3,65,0,69,1,81,1,16,2,9,64,0,16,65,1,69,80,85,81,80,513]

theorem envBound48955 : H12AffineFastState.Bounded env48955 := by
  intro p hp
  have h : env48955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48954_48955 : H12AffineEnvironment.transform 4 0 env48954 = env48955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48954 == env48955) = true)

theorem identity48955 : scanCanonicalize (H12AffineFastState.compose env48955 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48955 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48956 : List Nat := [2,4,8,16,0,16,8,5,512,21,0,16,9,0,0,3,17,0,21,1,1,1,16,2,9,16,0,16,17,1,21,0,5,1,0,513]

theorem envBound48956 : H12AffineFastState.Bounded env48956 := by
  intro p hp
  have h : env48956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48955_48956 : H12AffineEnvironment.transform 5 16 env48955 = env48956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48955 == env48956) = true)

theorem identity48956 : scanCanonicalize (H12AffineFastState.compose env48956 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48956 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48957 : List Nat := [2,4,8,1,0,1,8,5,512,4,0,1,9,0,0,3,0,0,4,1,1,1,1,2,9,1,0,1,0,1,4,0,5,1,0,513]

theorem envBound48957 : H12AffineFastState.Bounded env48957 := by
  intro p hp
  have h : env48957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48956_48957 : H12AffineEnvironment.transform 3 1 env48956 = env48957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48956 == env48957) = true)

theorem identity48957 : scanCanonicalize (H12AffineFastState.compose env48957 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound48957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48958 : List Nat := [2,4,8,1,0,1,8,5,10,4,0,1,9,0,0,3,0,0,4,1,1,1,1,2,9,1,0,1,0,1,4,0,5,1,0,11]

theorem envBound48958 : H12AffineFastState.Bounded env48958 := by
  intro p hp
  have h : env48958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48957_48958 : H12AffineEnvironment.transform 8 10 env48957 = env48958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env48957 == env48958) = true)

theorem identity48958 : scanCanonicalize (H12AffineFastState.compose env48958 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48958 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48959 : List Nat := [2,4,2,1,0,1,2,5,0,4,0,1,3,0,0,3,0,0,4,1,1,1,1,2,3,1,0,1,0,1,4,0,5,1,0,1]

theorem envBound48959 : H12AffineFastState.Bounded env48959 := by
  intro p hp
  have h : env48959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48958_48959 : H12AffineEnvironment.transform 2 2 env48958 = env48959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48958 == env48959) = true)

def env48960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound48960 : H12AffineFastState.Bounded env48960 := by
  intro p hp
  have h : env48960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48819_48960 : H12AffineEnvironment.transform 18 1025 env48819 = env48960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env48819 == env48960) = true)

theorem identity48960 : scanCanonicalize (H12AffineFastState.compose env48960 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8602076) := by decide +kernel

theorem selectedBound48960 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8602076,8328,64,4489692,10667344,10507600,8830977,181709,14820380,257,2262385,2254037,254490]

theorem envBound48961 : H12AffineFastState.Bounded env48961 := by
  intro p hp
  have h : env48961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48960_48961 : H12AffineEnvironment.transform 23 8602076 env48960 = env48961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8602076 env48960 == env48961) = true)

def env48962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,8388608,8602076,8328,64,4489692,8393984,8553728,8830977,181709,12645452,257,21793,46213,254490]

theorem envBound48962 : H12AffineFastState.Bounded env48962 := by
  intro p hp
  have h : env48962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48961_48962 : H12AffineEnvironment.transform 20 184400 env48961 = env48962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env48961 == env48962) = true)

def env48963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,98780,8328,64,4489692,185600,17664,262145,181709,4338764,257,21793,46213,254490]

theorem envBound48963 : H12AffineFastState.Bounded env48963 := by
  intro p hp
  have h : env48963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48962_48963 : H12AffineEnvironment.transform 22 180224 env48962 = env48963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env48962 == env48963) = true)

def env48964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,98780,8328,64,43356,185600,17664,262145,181709,400588,257,21793,46213,254490]

theorem envBound48964 : H12AffineFastState.Bounded env48964 := by
  intro p hp
  have h : env48964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48963_48964 : H12AffineEnvironment.transform 21 272512 env48963 = env48964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48963 == env48964) = true)

def env48965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180224,98644,8192,64,43356,185600,17664,262145,181573,400452,257,21793,46093,254490]

theorem envBound48965 : H12AffineFastState.Bounded env48965 := by
  intro p hp
  have h : env48965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48964_48965 : H12AffineEnvironment.transform 6 8 env48964 = env48965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48964 == env48965) = true)

def env48966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,16,98644,8192,64,43356,5392,17664,262145,1365,318548,257,21793,46093,74250]

theorem envBound48966 : H12AffineFastState.Bounded env48966 := by
  intro p hp
  have h : env48966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48965_48966 : H12AffineEnvironment.transform 16 49168 env48965 = env48966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48965 == env48966) = true)

theorem identity48966 : scanCanonicalize (H12AffineFastState.compose env48966 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound48966 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130094,1025,32769,4160,119846,16,98644,8192,64,43356,5392,17664,130095,1365,73850,257,21793,46093,74250]

theorem envBound48967 : H12AffineFastState.Bounded env48967 := by
  intro p hp
  have h : env48967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48966_48967 : H12AffineEnvironment.transform 17 130094 env48966 = env48967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env48966 == env48967) = true)

theorem identity48967 : scanCanonicalize (H12AffineFastState.compose env48967 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48967 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,65536,46109,100387,1025,32769,4160,106539,16,98644,8192,64,43356,5392,12557,100386,1365,73850,257,8492,46093,74250]

theorem envBound48968 : H12AffineFastState.Bounded env48968 := by
  intro p hp
  have h : env48968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48967_48968 : H12AffineEnvironment.transform 13 13325 env48967 = env48968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48967 == env48968) = true)

theorem identity48968 : scanCanonicalize (H12AffineFastState.compose env48968 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48968 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env48969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,8203,46109,43048,1025,32769,4160,32800,16,41311,8192,64,43356,5392,12557,43049,1365,113,257,8492,46093,513]

theorem envBound48969 : H12AffineFastState.Bounded env48969 := by
  intro p hp
  have h : env48969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48968_48969 : H12AffineEnvironment.transform 15 8203 env48968 = env48969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48968 == env48969) = true)

theorem identity48969 : scanCanonicalize (H12AffineFastState.compose env48969 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48969 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,32768,342,38208,35189,1025,32769,4160,32800,16,32770,349,64,34817,5392,4176,35188,1365,113,257,113,38224,513]

theorem envBound48970 : H12AffineFastState.Bounded env48970 := by
  intro p hp
  have h : env48970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48969_48970 : H12AffineEnvironment.transform 12 349 env48969 = env48970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48969 == env48970) = true)

theorem identity48970 : scanCanonicalize (H12AffineFastState.compose env48970 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound48970 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1076,4096,349,5456,32768,342,38208,34113,1025,32769,4160,32800,16,32770,349,64,33845,5392,4176,34112,1365,113,257,113,38224,513]

theorem envBound48971 : H12AffineFastState.Bounded env48971 := by
  intro p hp
  have h : env48971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48970_48971 : H12AffineEnvironment.transform 10 1076 env48970 = env48971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env48970 == env48971) = true)

theorem identity48971 : scanCanonicalize (H12AffineFastState.compose env48971 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48971 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env48972 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,5237,32768,115,37989,33892,1025,32769,4160,32800,16,32770,120,64,33845,5173,4176,33893,1136,113,36,113,38005,513]

theorem envBound48972 : H12AffineFastState.Bounded env48972 := by
  intro p hp
  have h : env48972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48971_48972 : H12AffineEnvironment.transform 7 37 env48971 = env48972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48971 == env48972) = true)

theorem identity48972 : scanCanonicalize (H12AffineFastState.compose env48972 (packedSelected [0,2,7] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48972 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48973 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,5237,81,115,5172,1077,1025,80,4160,113,16,83,120,64,1124,5173,4176,1076,1136,113,36,113,5156,513]

theorem envBound48973 : H12AffineFastState.Bounded env48973 := by
  intro p hp
  have h : env48973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48972_48973 : H12AffineEnvironment.transform 14 81 env48972 = env48973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48972 == env48973) = true)

theorem identity48973 : scanCanonicalize (H12AffineFastState.compose env48973 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48973 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48974 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,41,5156,0,34,5172,1077,1025,1,4113,32,16,2,41,17,1077,5173,4097,1076,1057,32,36,32,5156,513]

theorem envBound48974 : H12AffineFastState.Bounded env48974 := by
  intro p hp
  have h : env48974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48973_48974 : H12AffineEnvironment.transform 5 17 env48973 = env48974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48973 == env48974) = true)

def env48975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,98644,8192,64,43356,5393,17664,262145,1364,318549,257,21793,46093,74251]

theorem envBound48975 : H12AffineFastState.Bounded env48975 := by
  intro p hp
  have h : env48975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48965_48975 : H12AffineEnvironment.transform 16 49169 env48965 = env48975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48965 == env48975) = true)

theorem identity48975 : scanCanonicalize (H12AffineFastState.compose env48975 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48975 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,33,17,98644,8192,64,43356,5393,17664,10280,1364,62588,257,21793,46093,74251]

theorem envBound48976 : H12AffineFastState.Bounded env48976 := by
  intro p hp
  have h : env48976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48975_48976 : H12AffineEnvironment.transform 17 10281 env48975 = env48976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48975 == env48976) = true)

theorem identity48976 : scanCanonicalize (H12AffineFastState.compose env48976 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound48976 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10281,1025,32769,4161,33,17,8542,8192,64,43356,5393,17664,10280,1364,62588,257,21793,46093,33281]

theorem envBound48977 : H12AffineFastState.Bounded env48977 := by
  intro p hp
  have h : env48977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48976_48977 : H12AffineEnvironment.transform 15 40970 env48976 = env48977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env48976 == env48977) = true)

theorem identity48977 : scanCanonicalize (H12AffineFastState.compose env48977 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48977 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env48978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,13389,10281,1025,29789,4161,33,17,8542,8192,64,23808,5393,17664,10280,1364,32,257,21793,16465,30301]

theorem envBound48978 : H12AffineFastState.Bounded env48978 := by
  intro p hp
  have h : env48978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48977_48978 : H12AffineEnvironment.transform 14 29788 env48977 = env48978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48977 == env48978) = true)

theorem identity48978 : scanCanonicalize (H12AffineFastState.compose env48978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,343,13389,10281,1025,8540,4161,33,17,8542,8192,64,2049,5393,4097,10280,1364,32,257,32,5456,9052]

theorem envBound48979 : H12AffineFastState.Bounded env48979 := by
  intro p hp
  have h : env48979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48978_48979 : H12AffineEnvironment.transform 13 5377 env48978 = env48979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48978 == env48979) = true)

theorem identity48979 : scanCanonicalize (H12AffineFastState.compose env48979 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48979 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48980 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,343,12637,10281,273,8540,4161,33,17,8542,8192,64,2049,4097,4097,10280,68,32,257,32,4160,9052]

theorem envBound48980 : H12AffineFastState.Bounded env48980 := by
  intro p hp
  have h : env48980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48979_48980 : H12AffineEnvironment.transform 9 272 env48979 = env48980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48979 == env48980) = true)

theorem identity48980 : scanCanonicalize (H12AffineFastState.compose env48980 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound48980 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48981 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,4096,8192,4113,8200,2,12296,10281,68,8201,4161,33,17,8203,8192,64,2049,4097,4097,10280,68,32,84,32,4160,8713]

theorem envBound48981 : H12AffineFastState.Bounded env48981 := by
  intro p hp
  have h : env48981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48980_48981 : H12AffineEnvironment.transform 7 85 env48980 = env48981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env48980 == env48981) = true)

theorem identity48981 : scanCanonicalize (H12AffineFastState.compose env48981 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound48981 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48982 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,4096,4201,4113,4193,2,97,6208,68,4192,4161,33,17,4194,4201,64,2049,4097,4097,6209,68,32,84,32,4160,4704]

theorem envBound48982 : H12AffineFastState.Bounded env48982 := by
  intro p hp
  have h : env48982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48981_48982 : H12AffineEnvironment.transform 12 4201 env48981 = env48982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env48981 == env48982) = true)

theorem identity48982 : scanCanonicalize (H12AffineFastState.compose env48982 (packedSelected [2,14] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound48982 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env48983 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,96,9,113,1,2,97,2080,68,0,33,33,17,2,9,64,2049,97,97,2081,68,32,84,32,32,512]

theorem envBound48983 : H12AffineFastState.Bounded env48983 := by
  intro p hp
  have h : env48983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48982_48983 : H12AffineEnvironment.transform 11 96 env48982 = env48983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env48982 == env48983) = true)

def env48984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180224,98645,8193,64,43356,185600,17664,262145,181572,400453,257,21793,46092,254490]

theorem envBound48984 : H12AffineFastState.Bounded env48984 := by
  intro p hp
  have h : env48984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48964_48984 : H12AffineEnvironment.transform 6 9 env48964 = env48984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48964 == env48984) = true)

theorem identity48984 : scanCanonicalize (H12AffineFastState.compose env48984 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound48984 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env48985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,262144,1025,32769,184400,272393,180224,8542,8193,64,43356,185600,17664,262145,181572,400453,257,21793,46092,147985]

theorem envBound48985 : H12AffineFastState.Bounded env48985 := by
  intro p hp
  have h : env48985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48984_48985 : H12AffineEnvironment.transform 15 40971 env48984 = env48985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env48984 == env48985) = true)

theorem identity48985 : scanCanonicalize (H12AffineFastState.compose env48985 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound48985 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,2421,1025,32769,184400,8572,180224,8542,8193,64,43356,185600,17664,2420,181572,136496,257,21793,46092,147985]

theorem envBound48986 : H12AffineFastState.Bounded env48986 := by
  intro p hp
  have h : env48986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48985_48986 : H12AffineEnvironment.transform 17 2421 env48985 = env48986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env48985 == env48986) = true)

theorem identity48986 : scanCanonicalize (H12AffineFastState.compose env48986 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound48986 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,2421,1025,32769,12573,8572,8525,8542,8193,64,43356,13389,17664,2420,9225,62589,257,21793,46092,41820]

theorem envBound48987 : H12AffineFastState.Bounded env48987 := by
  intro p hp
  have h : env48987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48986_48987 : H12AffineEnvironment.transform 16 57677 env48986 = env48987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env48986 == env48987) = true)

theorem identity48987 : scanCanonicalize (H12AffineFastState.compose env48987 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48987 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,24909,2421,1025,1,12573,8572,8525,8542,8193,64,10588,13389,17664,2420,9225,29821,257,21793,13324,9052]

theorem envBound48988 : H12AffineFastState.Bounded env48988 := by
  intro p hp
  have h : env48988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48987_48988 : H12AffineEnvironment.transform 14 0 env48987 = env48988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48987 == env48988) = true)

theorem identity48988 : scanCanonicalize (H12AffineFastState.compose env48988 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48988 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48989 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,0,8203,24681,2129,1025,1,12345,8280,8297,8314,8193,64,10360,13389,17444,2128,9225,29821,37,21509,13324,8824]

theorem envBound48989 : H12AffineFastState.Bounded env48989 := by
  intro p hp
  have h : env48989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48988_48989 : H12AffineEnvironment.transform 7 36 env48988 = env48989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48988 == env48989) = true)

theorem identity48989 : scanCanonicalize (H12AffineFastState.compose env48989 (packedSelected [1,2,8,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound48989 : packedSelected [1,2,8,14,19] rootPS < 2^1333 := by decide +kernel

def env48990 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,0,114,16400,2129,1025,1,4160,33,16,3,120,64,2049,5172,17444,2128,1136,21508,37,21509,5237,513]

theorem envBound48990 : H12AffineFastState.Bounded env48990 := by
  intro p hp
  have h : env48990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48989_48990 : H12AffineEnvironment.transform 12 121 env48989 = env48990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env48989 == env48990) = true)

theorem identity48990 : scanCanonicalize (H12AffineFastState.compose env48990 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound48990 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48991 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5237,0,114,5221,2129,1025,1,4160,33,16,3,120,64,2049,5172,4177,2128,1136,113,37,112,5237,513]

theorem envBound48991 : H12AffineFastState.Bounded env48991 := by
  intro p hp
  have h : env48991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48990_48991 : H12AffineEnvironment.transform 13 5237 env48990 = env48991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env48990 == env48991) = true)

theorem identity48991 : scanCanonicalize (H12AffineFastState.compose env48991 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48992 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,34,5173,2049,1025,1,4112,33,16,3,40,16,2049,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound48992 : H12AffineFastState.Bounded env48992 := by
  intro p hp
  have h : env48992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48991_48992 : H12AffineEnvironment.transform 5 16 env48991 = env48992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48991 == env48992) = true)

theorem identity48992 : scanCanonicalize (H12AffineFastState.compose env48992 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound48992 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48993 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,4096,41,5157,0,34,5173,1076,1025,1,4112,33,16,3,40,16,1076,5172,4097,1077,1056,33,37,32,5157,513]

theorem envBound48993 : H12AffineFastState.Bounded env48993 := by
  intro p hp
  have h : env48993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48992_48993 : H12AffineEnvironment.transform 10 1077 env48992 = env48993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env48992 == env48993) = true)

theorem identity48993 : scanCanonicalize (H12AffineFastState.compose env48993 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound48993 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48994 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1060,41,1,0,34,17,1076,1025,1,1076,33,16,3,40,16,1076,16,1061,1077,1056,33,37,32,1,513]

theorem envBound48994 : H12AffineFastState.Bounded env48994 := by
  intro p hp
  have h : env48994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48993_48994 : H12AffineEnvironment.transform 11 1060 env48993 = env48994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env48993 == env48994) = true)

theorem identity48994 : scanCanonicalize (H12AffineFastState.compose env48994 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48994 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48995 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,41,1,0,34,17,1,52,1,1,33,16,3,40,16,1,16,16,0,21,33,37,32,1,513]

theorem envBound48995 : H12AffineFastState.Bounded env48995 := by
  intro p hp
  have h : env48995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48994_48995 : H12AffineEnvironment.transform 9 53 env48994 = env48995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48994 == env48995) = true)

theorem identity48995 : scanCanonicalize (H12AffineFastState.compose env48995 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound48995 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48996 : List Nat := [2,4,8,16,32,16,9,36,16,53,0,17,41,1,0,34,17,1,52,1,1,33,16,3,40,16,1,16,16,0,21,33,37,32,1,17]

theorem envBound48996 : H12AffineFastState.Bounded env48996 := by
  intro p hp
  have h : env48996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48995_48996 : H12AffineEnvironment.transform 8 16 env48995 = env48996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env48995 == env48996) = true)

theorem identity48996 : scanCanonicalize (H12AffineFastState.compose env48996 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound48996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48997 : List Nat := [2,4,8,16,26,16,9,30,16,15,0,17,19,1,0,24,17,1,14,1,1,27,16,3,18,16,1,16,16,0,21,27,31,26,1,17]

theorem envBound48997 : H12AffineFastState.Bounded env48997 := by
  intro p hp
  have h : env48997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48996_48997 : H12AffineEnvironment.transform 4 26 env48996 = env48997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env48996 == env48997) = true)

def env48998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,98780,8328,64,43357,185600,17664,262145,181709,400589,257,21793,46213,254490]

theorem envBound48998 : H12AffineFastState.Bounded env48998 := by
  intro p hp
  have h : env48998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48963_48998 : H12AffineEnvironment.transform 21 272513 env48963 = env48998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48963 == env48998) = true)

theorem identity48998 : scanCanonicalize (H12AffineFastState.compose env48998 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound48998 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272513,17,98780,8328,64,43357,5393,17664,262145,1500,318684,257,21793,46213,74251]

theorem envBound48999 : H12AffineFastState.Bounded env48999 := by
  intro p hp
  have h : env48999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48998_48999 : H12AffineEnvironment.transform 16 49169 env48998 = env48999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48998 == env48999) = true)

theorem identity48999 : scanCanonicalize (H12AffineFastState.compose env48999 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48999 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272513,17,41430,8328,64,43357,5393,17664,262145,1500,318684,257,21793,46213,513]

theorem envBound49000 : H12AffineFastState.Bounded env49000 := by
  intro p hp
  have h : env49000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48999_49000 : H12AffineEnvironment.transform 15 8202 env48999 = env49000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48999 == env49000) = true)

theorem identity49000 : scanCanonicalize (H12AffineFastState.compose env49000 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound49000 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env49001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10400,1025,32769,4161,33,17,41430,8328,64,43357,5393,17664,10401,1500,62588,257,21793,46213,513]

theorem envBound49001 : H12AffineFastState.Bounded env49001 := by
  intro p hp
  have h : env49001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49000_49001 : H12AffineEnvironment.transform 17 10400 env49000 = env49001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49000 == env49001) = true)

theorem identity49001 : scanCanonicalize (H12AffineFastState.compose env49001 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49001 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16401,10400,1025,1,4161,33,17,8662,8328,64,10589,5393,17664,10401,1500,29820,257,21793,13445,513]

theorem envBound49002 : H12AffineFastState.Bounded env49002 := by
  intro p hp
  have h : env49002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49001_49002 : H12AffineEnvironment.transform 14 0 env49001 = env49002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49001 == env49002) = true)

theorem identity49002 : scanCanonicalize (H12AffineFastState.compose env49002 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound49002 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env49003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,0,1230,16401,3172,1025,1,4161,33,17,1298,1100,64,3481,5393,17664,3173,1500,20664,257,21793,4161,513]

theorem envBound49003 : H12AffineFastState.Bounded env49003 := by
  intro p hp
  have h : env49003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49002_49003 : H12AffineEnvironment.transform 12 1220 env49002 = env49003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env49002 == env49003) = true)

theorem identity49003 : scanCanonicalize (H12AffineFastState.compose env49003 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound49003 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env49004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,1212,0,1230,1197,3172,1025,1,4161,33,17,1298,1100,64,3481,5393,444,3173,1500,5124,257,4509,4161,513]

theorem envBound49004 : H12AffineFastState.Bounded env49004 := by
  intro p hp
  have h : env49004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49003_49004 : H12AffineEnvironment.transform 13 1212 env49003 = env49004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env49003 == env49004) = true)

theorem identity49004 : scanCanonicalize (H12AffineFastState.compose env49004 (packedSelected [0,1,3,4,5,8,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound49004 : packedSelected [0,1,3,4,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env49005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,65,1220,1212,0,1230,1197,3172,1025,1,0,33,17,1298,1100,64,3481,1360,444,3173,1500,1093,257,476,0,513]

theorem envBound49005 : H12AffineFastState.Bounded env49005 := by
  intro p hp
  have h : env49005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49004_49005 : H12AffineEnvironment.transform 11 65 env49004 = env49005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env49004 == env49005) = true)

theorem identity49005 : scanCanonicalize (H12AffineFastState.compose env49005 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49005 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env49006 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,65,388,508,0,398,493,2340,321,1,0,33,17,82,268,64,2265,16,444,2341,156,261,257,476,0,513]

theorem envBound49006 : H12AffineFastState.Bounded env49006 := by
  intro p hp
  have h : env49006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49005_49006 : H12AffineEnvironment.transform 9 320 env49005 = env49006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49005 == env49006) = true)

theorem identity49006 : scanCanonicalize (H12AffineFastState.compose env49006 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound49006 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env49007 : List Nat := [2,4,8,16,32,64,128,256,512,320,81,65,388,508,0,398,493,373,321,1,0,33,17,82,268,64,136,16,444,372,156,261,257,476,0,513]

theorem envBound49007 : H12AffineFastState.Bounded env49007 := by
  intro p hp
  have h : env49007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49006_49007 : H12AffineEnvironment.transform 10 81 env49006 = env49007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env49006 == env49007) = true)

def env49008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,98781,8328,64,4489692,185601,17665,262144,181709,4338765,257,21793,46213,254490]

theorem envBound49008 : H12AffineFastState.Bounded env49008 := by
  intro p hp
  have h : env49008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48962_49008 : H12AffineEnvironment.transform 22 180225 env48962 = env49008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env48962 == env49008) = true)

def env49009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,98781,8328,64,43356,185601,17665,262144,181709,400589,257,21793,46213,254490]

theorem envBound49009 : H12AffineFastState.Bounded env49009 := by
  intro p hp
  have h : env49009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49008_49009 : H12AffineEnvironment.transform 21 272512 env49008 = env49009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49008 == env49009) = true)

theorem identity49009 : scanCanonicalize (H12AffineFastState.compose env49009 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140421,272512,144596,95496,8328,64,23945,139732,17665,262144,143640,400589,257,21793,16464,202447]

theorem envBound49010 : H12AffineFastState.Bounded env49010 := by
  intro p hp
  have h : env49010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49009_49010 : H12AffineEnvironment.transform 14 29909 env49009 = env49010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49009 == env49010) = true)

theorem identity49010 : scanCanonicalize (H12AffineFastState.compose env49010 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49010 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env49011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,83103,272512,87246,95496,8328,64,23945,82382,17665,262144,86274,359639,257,21793,16464,30421]

theorem envBound49011 : H12AffineFastState.Bounded env49011 := by
  intro p hp
  have h : env49011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49010_49011 : H12AffineEnvironment.transform 16 90138 env49010 = env49011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49010 == env49011) = true)

theorem identity49011 : scanCanonicalize (H12AffineFastState.compose env49011 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49011 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env49012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,262144,1025,29908,25748,272512,29893,21763,8328,64,23945,25029,17665,262144,28937,285916,257,21793,16464,30421]

theorem envBound49012 : H12AffineFastState.Bounded env49012 := by
  intro p hp
  have h : env49012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49011_49012 : H12AffineEnvironment.transform 15 8203 env49011 = env49012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49011 == env49012) = true)

def env49013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,16401,262144,1025,29828,25748,272512,29845,21763,8328,16,23945,24981,17665,262144,28937,285836,257,21793,16384,30341]

theorem envBound49013 : H12AffineFastState.Bounded env49013 := by
  intro p hp
  have h : env49013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49012_49013 : H12AffineEnvironment.transform 5 16 env49012 = env49013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49012 == env49013) = true)

theorem identity49013 : scanCanonicalize (H12AffineFastState.compose env49013 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound49013 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env49014 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,16401,32041,1025,29828,25748,21929,29845,21763,8328,16,23945,24981,17665,32041,28937,8613,257,21793,16384,30341]

theorem envBound49014 : H12AffineFastState.Bounded env49014 := by
  intro p hp
  have h : env49014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49013_49014 : H12AffineEnvironment.transform 17 32041 env49013 = env49014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env49013 == env49014) = true)

theorem identity49014 : scanCanonicalize (H12AffineFastState.compose env49014 (packedSelected [3,4,5,7,10,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49014 : packedSelected [3,4,5,7,10,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env49015 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,4096,8192,16384,29829,8203,16401,29960,1025,29828,25748,21929,29845,21763,8328,16,21928,24981,17665,29960,28937,8613,257,21793,16384,30341]

theorem envBound49015 : H12AffineFastState.Bounded env49015 := by
  intro p hp
  have h : env49015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49014_49015 : H12AffineEnvironment.transform 10 33 env49014 = env49015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49014 == env49015) = true)

theorem identity49015 : scanCanonicalize (H12AffineFastState.compose env49015 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound49015 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49016 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,4096,388,16384,21761,399,16401,21644,1025,21760,17680,21929,21777,21763,268,16,21928,16401,17665,21644,20621,33,257,21793,16384,22273]

theorem envBound49016 : H12AffineFastState.Bounded env49016 := by
  intro p hp
  have h : env49016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49015_49016 : H12AffineEnvironment.transform 12 388 env49015 = env49016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env49015 == env49016) = true)

theorem identity49016 : scanCanonicalize (H12AffineFastState.compose env49016 (packedSelected [0,1,2,3,4,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound49016 : packedSelected [0,1,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env49017 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,49,388,16384,17712,399,16401,17597,1025,17713,17680,17816,17696,17714,268,16,17817,16401,17665,17597,16572,33,257,17680,16384,18224]

theorem envBound49017 : H12AffineFastState.Bounded env49017 := by
  intro p hp
  have h : env49017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49016_49017 : H12AffineEnvironment.transform 11 49 env49016 = env49017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49016 == env49017) = true)

theorem identity49017 : scanCanonicalize (H12AffineFastState.compose env49017 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1045) := by decide +kernel

theorem selectedBound49017 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49018 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,49,388,1045,293,399,1028,168,1025,292,261,397,309,295,268,16,396,1028,276,168,1193,33,257,261,1045,805]

theorem envBound49018 : H12AffineFastState.Bounded env49018 := by
  intro p hp
  have h : env49018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49017_49018 : H12AffineEnvironment.transform 13 1045 env49017 = env49018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1045 env49017 == env49018) = true)

def env49019 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,16401,262144,1025,29829,25748,272512,29844,21763,8328,17,23945,24980,17665,262144,28937,285837,257,21793,16385,30340]

theorem envBound49019 : H12AffineFastState.Bounded env49019 := by
  intro p hp
  have h : env49019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49012_49019 : H12AffineEnvironment.transform 5 17 env49012 = env49019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49012 == env49019) = true)

theorem identity49019 : scanCanonicalize (H12AffineFastState.compose env49019 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound49019 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env49020 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,16401,2341,1025,29829,25748,8613,29844,21763,8328,17,23945,24980,17665,2341,28937,21928,257,21793,16385,30340]

theorem envBound49020 : H12AffineFastState.Bounded env49020 := by
  intro p hp
  have h : env49020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49019_49020 : H12AffineEnvironment.transform 17 2341 env49019 = env49020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env49019 == env49020) = true)

theorem identity49020 : scanCanonicalize (H12AffineFastState.compose env49020 (packedSelected [0,1,2,4,8,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49020 : packedSelected [0,1,2,4,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env49021 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,8203,13341,2341,1025,137,4248,8613,152,8463,8328,17,10629,5528,12557,2341,1285,8612,257,8493,13325,648]

theorem envBound49021 : H12AffineFastState.Bounded env49021 := by
  intro p hp
  have h : env49021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49020_49021 : H12AffineEnvironment.transform 13 13324 env49020 = env49021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49020 == env49021) = true)

theorem identity49021 : scanCanonicalize (H12AffineFastState.compose env49021 (packedSelected [1,2,3,5,6,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3496) := by decide +kernel

theorem selectedBound49021 : packedSelected [1,2,3,5,6,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49022 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3496,8192,10660,136,8203,10677,2341,1025,137,3376,8613,152,8463,8328,17,10629,2096,11429,2341,1285,8612,257,8493,10661,648]

theorem envBound49022 : H12AffineFastState.Bounded env49022 := by
  intro p hp
  have h : env49022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49021_49022 : H12AffineEnvironment.transform 11 3496 env49021 = env49022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3496 env49021 == env49022) = true)

theorem identity49022 : scanCanonicalize (H12AffineFastState.compose env49022 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound49022 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env49023 : List Nat := [2,4,8,16,32,17,128,256,512,157,2048,2357,8192,10660,136,8203,10677,2341,156,137,2477,8613,152,8463,8328,17,10629,2096,10296,2341,408,8612,257,8493,10661,648]

theorem envBound49023 : H12AffineFastState.Bounded env49023 := by
  intro p hp
  have h : env49023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49022_49023 : H12AffineEnvironment.transform 9 157 env49022 = env49023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env49022 == env49023) = true)

theorem identity49023 : scanCanonicalize (H12AffineFastState.compose env49023 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49023 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49024 : List Nat := [2,4,8,16,32,17,128,256,512,157,2048,2357,269,2217,136,262,2232,2341,156,137,2477,168,152,2,389,17,2184,2096,2357,2341,408,169,257,32,2216,648]

theorem envBound49024 : H12AffineFastState.Bounded env49024 := by
  intro p hp
  have h : env49024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49023_49024 : H12AffineEnvironment.transform 12 269 env49023 = env49024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49023 == env49024) = true)

theorem identity49024 : scanCanonicalize (H12AffineFastState.compose env49024 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound49024 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env49025 : List Nat := [2,4,8,16,32,17,41,256,512,52,2048,2357,269,2048,33,262,2065,2341,53,32,2308,1,49,2,300,17,2081,2096,2357,2341,305,0,257,32,2049,545]

theorem envBound49025 : H12AffineFastState.Bounded env49025 := by
  intro p hp
  have h : env49025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49024_49025 : H12AffineEnvironment.transform 6 41 env49024 = env49025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env49024 == env49025) = true)

theorem identity49025 : scanCanonicalize (H12AffineFastState.compose env49025 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49025 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49026 : List Nat := [2,4,8,16,32,17,41,37,512,52,2048,2064,40,2048,33,35,2065,2048,53,32,2081,1,49,2,9,17,2081,2096,2064,2048,20,0,36,32,2049,545]

theorem envBound49026 : H12AffineFastState.Bounded env49026 := by
  intro p hp
  have h : env49026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49025_49026 : H12AffineEnvironment.transform 7 37 env49025 = env49026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49025 == env49026) = true)

theorem identity49026 : scanCanonicalize (H12AffineFastState.compose env49026 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49027 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2048,0,2,2065,2048,20,1,2048,1,16,2,9,17,2048,2065,2064,2048,20,0,5,1,2049,512]

theorem envBound49027 : H12AffineFastState.Bounded env49027 := by
  intro p hp
  have h : env49027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49026_49027 : H12AffineEnvironment.transform 4 1 env49026 = env49027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49026 == env49027) = true)

theorem identity49027 : scanCanonicalize (H12AffineFastState.compose env49027 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound49027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49028 : List Nat := [2,4,8,16,1,17,8,4,512,21,5,21,9,5,0,2,20,5,20,1,5,1,16,2,9,17,5,20,21,5,20,0,5,1,4,512]

theorem envBound49028 : H12AffineFastState.Bounded env49028 := by
  intro p hp
  have h : env49028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49027_49028 : H12AffineEnvironment.transform 10 5 env49027 = env49028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env49027 == env49028) = true)

def env49029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,98781,8328,64,43357,185601,17665,262144,181709,400588,257,21793,46213,254490]

theorem envBound49029 : H12AffineFastState.Bounded env49029 := by
  intro p hp
  have h : env49029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49008_49029 : H12AffineEnvironment.transform 21 272513 env49008 = env49029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49008 == env49029) = true)

theorem identity49029 : scanCanonicalize (H12AffineFastState.compose env49029 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound49029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58517,272513,62660,98781,8328,64,43357,57796,17665,262144,61704,272393,257,21793,46213,120543]

theorem envBound49030 : H12AffineFastState.Bounded env49030 := by
  intro p hp
  have h : env49030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49029_49030 : H12AffineEnvironment.transform 16 13509 env49029 = env49030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env49029 == env49030) = true)

def env49031 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58517,272513,62612,98701,8328,16,43277,57748,17665,262144,61704,272393,257,21793,46213,120463]

theorem envBound49031 : H12AffineFastState.Bounded env49031 := by
  intro p hp
  have h : env49031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49030_49031 : H12AffineEnvironment.transform 5 16 env49030 = env49031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49030 == env49031) = true)

theorem identity49031 : scanCanonicalize (H12AffineFastState.compose env49031 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound49031 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env49032 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,65536,13461,262144,1025,8581,17681,272513,21776,73737,8328,16,2185,16400,17665,262144,20620,272393,257,21793,5377,96011]

theorem envBound49032 : H12AffineFastState.Bounded env49032 := by
  intro p hp
  have h : env49032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49031_49032 : H12AffineEnvironment.transform 14 8580 env49031 = env49032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env49031 == env49032) = true)

theorem identity49032 : scanCanonicalize (H12AffineFastState.compose env49032 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound49032 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env49033 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,65536,13461,76199,1025,8581,17681,65830,21776,73737,8328,16,2185,16400,17665,76199,20620,65966,257,21793,5377,96011]

theorem envBound49033 : H12AffineFastState.Bounded env49033 := by
  intro p hp
  have h : env49033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49032_49033 : H12AffineEnvironment.transform 17 76199 env49032 = env49033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env49032 == env49033) = true)

theorem identity49033 : scanCanonicalize (H12AffineFastState.compose env49033 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49033 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49034 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8580,65536,13461,76199,1025,8581,12573,65830,8476,73737,8328,16,2185,13340,12557,76199,9344,65966,257,8493,5377,66311]

theorem envBound49034 : H12AffineFastState.Bounded env49034 := by
  intro p hp
  have h : env49034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49033_49034 : H12AffineEnvironment.transform 13 13324 env49033 = env49034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49033 == env49034) = true)

theorem identity49034 : scanCanonicalize (H12AffineFastState.compose env49034 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49034 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env49035 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,137,65536,5528,67754,1025,136,4112,65830,17,65796,389,16,2185,5393,4096,67754,1421,65966,257,32,5377,66311]

theorem envBound49035 : H12AffineFastState.Bounded env49035 := by
  intro p hp
  have h : env49035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49034_49035 : H12AffineEnvironment.transform 12 269 env49034 = env49035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49034 == env49035) = true)

theorem identity49035 : scanCanonicalize (H12AffineFastState.compose env49035 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49035 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49036 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,9,5125,137,65536,5276,67754,1025,136,4112,65570,17,65536,129,16,2185,5141,4096,67754,1161,65706,5,32,5125,66051]

theorem envBound49036 : H12AffineFastState.Bounded env49036 := by
  intro p hp
  have h : env49036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49035_49036 : H12AffineEnvironment.transform 7 4 env49035 = env49036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49035 == env49036) = true)

theorem identity49036 : scanCanonicalize (H12AffineFastState.compose env49036 (packedSelected [0,7,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound49036 : packedSelected [0,7,12,14] rootPS < 2^1333 := by decide +kernel

def env49037 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,3108,9,2081,137,65536,2232,67754,1025,136,3124,65570,17,65536,129,16,2185,2097,3108,67754,1161,65706,5,32,2081,66051]

theorem envBound49037 : H12AffineFastState.Bounded env49037 := by
  intro p hp
  have h : env49037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49036_49037 : H12AffineEnvironment.transform 11 3108 env49036 = env49037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env49036 == env49037) = true)

theorem identity49037 : scanCanonicalize (H12AffineFastState.compose env49037 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound49037 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49038 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,3108,9,2081,137,138,2232,2080,1025,136,3124,168,17,138,129,16,2185,2097,3108,2080,1161,32,5,32,2081,649]

theorem envBound49038 : H12AffineFastState.Bounded env49038 := by
  intro p hp
  have h : env49038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49037_49038 : H12AffineEnvironment.transform 15 138 env49037 = env49038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env49037 == env49038) = true)

theorem identity49038 : scanCanonicalize (H12AffineFastState.compose env49038 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49038 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49039 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1213,153,9,1180,137,138,1029,1181,1025,136,137,168,17,138,129,16,1076,1164,153,1181,1161,32,5,32,1180,649]

theorem envBound49039 : H12AffineFastState.Bounded env49039 := by
  intro p hp
  have h : env49039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49038_49039 : H12AffineEnvironment.transform 10 1213 env49038 = env49039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env49038 == env49039) = true)

theorem identity49039 : scanCanonicalize (H12AffineFastState.compose env49039 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49039 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49040 : List Nat := [2,4,8,16,32,16,128,4,512,53,136,153,9,169,137,138,48,168,52,136,137,168,17,138,129,16,1,185,153,168,188,32,5,32,169,649]

theorem envBound49040 : H12AffineFastState.Bounded env49040 := by
  intro p hp
  have h : env49040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49039_49040 : H12AffineEnvironment.transform 9 53 env49039 = env49040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49039 == env49040) = true)

theorem identity49040 : scanCanonicalize (H12AffineFastState.compose env49040 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49040 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49041 : List Nat := [2,4,8,16,32,16,8,4,512,53,0,17,9,33,1,2,48,32,52,0,1,32,17,2,9,16,1,49,17,32,52,32,5,32,33,513]

theorem envBound49041 : H12AffineFastState.Bounded env49041 := by
  intro p hp
  have h : env49041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49040_49041 : H12AffineEnvironment.transform 6 8 env49040 = env49041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49040 == env49041) = true)

def env49042 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58517,272513,62613,98700,8328,17,43276,57749,17665,262144,61704,272393,257,21793,46213,120462]

theorem envBound49042 : H12AffineFastState.Bounded env49042 := by
  intro p hp
  have h : env49042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49030_49042 : H12AffineEnvironment.transform 5 17 env49030 = env49042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49030 == env49042) = true)

theorem identity49042 : scanCanonicalize (H12AffineFastState.compose env49042 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound49042 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env49043 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,262144,1025,32769,45341,272513,41245,98700,8328,17,43276,46109,4233,262144,42112,272393,257,169,46213,99078]

theorem envBound49043 : H12AffineFastState.Bounded env49043 := by
  intro p hp
  have h : env49043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49042_49043 : H12AffineEnvironment.transform 13 5512 env49042 = env49043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env49042 == env49043) = true)

theorem identity49043 : scanCanonicalize (H12AffineFastState.compose env49043 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 108846) := by decide +kernel

theorem selectedBound49043 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env49044 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,108846,1025,32769,45341,98735,41245,98700,8328,17,43276,46109,4233,108846,42112,98599,257,169,46213,99078]

theorem envBound49044 : H12AffineFastState.Bounded env49044 := by
  intro p hp
  have h : env49044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49043_49044 : H12AffineEnvironment.transform 17 108846 env49043 = env49044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108846 env49043 == env49044) = true)

theorem identity49044 : scanCanonicalize (H12AffineFastState.compose env49044 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound49044 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,19,23] rootPS < 2^1333 := by decide +kernel

def env49045 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33166,13460,10400,1025,32769,45341,33,41245,2,8328,17,43276,46109,4233,10400,42112,169,257,169,46213,648]

theorem envBound49045 : H12AffineFastState.Bounded env49045 := by
  intro p hp
  have h : env49045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49044_49045 : H12AffineEnvironment.transform 15 33166 env49044 = env49045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env49044 == env49045) = true)

theorem identity49045 : scanCanonicalize (H12AffineFastState.compose env49045 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49045 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env49046 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,1077,1467,13460,10400,1025,1076,13608,33,9512,2,8328,17,11577,12328,4233,10400,8373,169,257,169,12464,648]

theorem envBound49046 : H12AffineFastState.Bounded env49046 := by
  intro p hp
  have h : env49046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49045_49046 : H12AffineEnvironment.transform 14 1077 env49045 = env49046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env49045 == env49046) = true)

theorem identity49046 : scanCanonicalize (H12AffineFastState.compose env49046 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound49046 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env49047 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,4113,428,34,12557,10400,408,429,12465,33,8369,2,8328,17,10400,12328,4233,10400,8373,169,257,169,12464,648]

theorem envBound49047 : H12AffineFastState.Bounded env49047 := by
  intro p hp
  have h : env49047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49046_49047 : H12AffineEnvironment.transform 9 409 env49046 = env49047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env49046 == env49047) = true)

theorem identity49047 : scanCanonicalize (H12AffineFastState.compose env49047 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49047 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49048 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,389,4113,428,34,4232,2341,408,429,4404,33,308,2,269,17,2341,4525,4233,2341,304,169,257,169,4405,648]

theorem envBound49048 : H12AffineFastState.Bounded env49048 := by
  intro p hp
  have h : env49048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49047_49048 : H12AffineEnvironment.transform 12 389 env49047 = env49048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49047 == env49048) = true)

theorem identity49048 : scanCanonicalize (H12AffineFastState.compose env49048 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound49048 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env49049 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,2356,389,2341,428,34,2492,2341,408,429,2048,33,308,2,269,17,2341,2201,2493,2341,304,169,257,169,2049,648]

theorem envBound49049 : H12AffineFastState.Bounded env49049 := by
  intro p hp
  have h : env49049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49048_49049 : H12AffineEnvironment.transform 11 2356 env49048 = env49049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env49048 == env49049) = true)

theorem identity49049 : scanCanonicalize (H12AffineFastState.compose env49049 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound49049 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49050 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,2201,40,2184,1,34,2065,2184,53,0,2048,33,153,2,160,17,2184,2201,2064,2184,157,169,172,169,2049,648]

theorem envBound49050 : H12AffineFastState.Bounded env49050 := by
  intro p hp
  have h : env49050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49049_49050 : H12AffineEnvironment.transform 7 173 env49049 = env49050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49049 == env49050) = true)

theorem identity49050 : scanCanonicalize (H12AffineFastState.compose env49050 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 150) := by decide +kernel

theorem selectedBound49050 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env49051 : List Nat := [2,4,8,16,32,17,128,173,512,52,150,15,40,30,1,34,135,30,53,0,150,33,153,2,160,17,30,15,134,30,157,169,172,169,151,648]

theorem envBound49051 : H12AffineFastState.Bounded env49051 := by
  intro p hp
  have h : env49051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49050_49051 : H12AffineEnvironment.transform 10 150 env49050 = env49051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 150 env49050 == env49051) = true)

theorem identity49051 : scanCanonicalize (H12AffineFastState.compose env49051 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound49051 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49052 : List Nat := [2,4,8,16,31,17,128,146,512,11,150,15,23,30,1,29,135,30,10,0,150,30,153,2,159,17,30,15,134,30,157,150,147,150,151,648]

theorem envBound49052 : H12AffineFastState.Bounded env49052 := by
  intro p hp
  have h : env49052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49051_49052 : H12AffineEnvironment.transform 4 31 env49051 = env49052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env49051 == env49052) = true)

def env49053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,8388608,8602076,8328,64,4489692,8393985,8553729,8830977,181709,12645453,257,21792,46212,254490]

theorem envBound49053 : H12AffineFastState.Bounded env49053 := by
  intro p hp
  have h : env49053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48961_49053 : H12AffineEnvironment.transform 20 184401 env48961 = env49053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env48961 == env49053) = true)

def env49054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,98780,8328,64,4489692,185601,17665,262145,181709,4338765,257,21792,46212,254490]

theorem envBound49054 : H12AffineFastState.Bounded env49054 := by
  intro p hp
  have h : env49054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49053_49054 : H12AffineEnvironment.transform 22 180224 env49053 = env49054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env49053 == env49054) = true)

def env49055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,98780,8328,64,43356,185601,17665,262145,181709,400589,257,21792,46212,254490]

theorem envBound49055 : H12AffineFastState.Bounded env49055 := by
  intro p hp
  have h : env49055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49054_49055 : H12AffineEnvironment.transform 21 272512 env49054 = env49055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49054 == env49055) = true)

theorem identity49055 : scanCanonicalize (H12AffineFastState.compose env49055 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound49055 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272512,73755,98780,8328,64,43356,79130,17665,262145,75222,392406,257,21792,46212,513]

theorem envBound49056 : H12AffineFastState.Bounded env49056 := by
  intro p hp
  have h : env49056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49055_49056 : H12AffineEnvironment.transform 16 122907 env49055 = env49056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env49055 == env49056) = true)

theorem identity49056 : scanCanonicalize (H12AffineFastState.compose env49056 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound49056 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env49057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77898,73891,73755,98780,8328,64,43356,79130,17665,67618,75222,62709,257,21792,46212,513]

theorem envBound49057 : H12AffineFastState.Bounded env49057 := by
  intro p hp
  have h : env49057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49056_49057 : H12AffineEnvironment.transform 17 67619 env49056 = env49057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env49056 == env49057) = true)

theorem identity49057 : scanCanonicalize (H12AffineFastState.compose env49057 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49057 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env49058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73891,73755,66012,8328,64,10588,79130,17665,67618,75222,29941,257,21792,13444,513]

theorem envBound49058 : H12AffineFastState.Bounded env49058 := by
  intro p hp
  have h : env49058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49057_49058 : H12AffineEnvironment.transform 14 0 env49057 = env49058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49057 == env49058) = true)

def env49059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73771,73755,65876,8192,64,10588,79130,17665,67618,75102,29821,257,21792,13324,513]

theorem envBound49059 : H12AffineFastState.Bounded env49059 := by
  intro p hp
  have h : env49059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49058_49059 : H12AffineEnvironment.transform 6 8 env49058 = env49059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49058 == env49059) = true)

theorem identity49059 : scanCanonicalize (H12AffineFastState.compose env49059 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49059 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env49060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1025,1,4161,32,16,8543,8192,64,10588,5393,17665,10281,1365,29821,257,21792,13324,513]

theorem envBound49060 : H12AffineFastState.Bounded env49060 := by
  intro p hp
  have h : env49060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49059_49060 : H12AffineEnvironment.transform 15 8203 env49059 = env49060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49059 == env49060) = true)

theorem identity49060 : scanCanonicalize (H12AffineFastState.compose env49060 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound49060 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,0,1094,16400,3173,1025,1,4161,32,16,1298,1101,64,3345,5393,17665,3172,1365,20528,257,21792,4161,513]

theorem envBound49061 : H12AffineFastState.Bounded env49061 := by
  intro p hp
  have h : env49061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49060_49061 : H12AffineEnvironment.transform 12 1101 env49060 = env49061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env49060 == env49061) = true)

theorem identity49061 : scanCanonicalize (H12AffineFastState.compose env49061 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound49061 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49062 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,16384,0,34,16400,2049,101,1,4161,32,16,374,41,64,2421,4469,16741,2048,305,20528,257,20804,4161,513]

theorem envBound49062 : H12AffineFastState.Bounded env49062 := by
  intro p hp
  have h : env49062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49061_49062 : H12AffineEnvironment.transform 9 100 env49061 = env49062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env49061 == env49062) = true)

theorem identity49062 : scanCanonicalize (H12AffineFastState.compose env49062 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound49062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49063 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4405,0,34,4389,2049,101,1,4161,32,16,374,41,64,2421,4469,4176,2048,305,261,257,113,4161,513]

theorem envBound49063 : H12AffineFastState.Bounded env49063 := by
  intro p hp
  have h : env49063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49062_49063 : H12AffineEnvironment.transform 13 4405 env49062 = env49063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env49062 == env49063) = true)

theorem identity49063 : scanCanonicalize (H12AffineFastState.compose env49063 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound49063 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env49064 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,41,4405,0,34,4389,292,101,1,4161,32,16,374,41,64,80,4469,4176,293,305,261,257,113,4161,513]

theorem envBound49064 : H12AffineFastState.Bounded env49064 := by
  intro p hp
  have h : env49064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49063_49064 : H12AffineEnvironment.transform 10 293 env49063 = env49064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env49063 == env49064) = true)

theorem identity49064 : scanCanonicalize (H12AffineFastState.compose env49064 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound49064 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49065 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,64,41,373,0,34,357,292,101,1,1,32,16,374,41,64,80,309,16,293,305,261,257,113,1,513]

theorem envBound49065 : H12AffineFastState.Bounded env49065 := by
  intro p hp
  have h : env49065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49064_49065 : H12AffineEnvironment.transform 11 64 env49064 = env49065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env49064 == env49065) = true)

theorem identity49065 : scanCanonicalize (H12AffineFastState.compose env49065 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49065 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49066 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,16,41,293,0,34,309,292,53,1,1,32,16,294,41,16,0,309,16,293,305,261,257,33,1,513]

theorem envBound49066 : H12AffineFastState.Bounded env49066 := by
  intro p hp
  have h : env49066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49065_49066 : H12AffineEnvironment.transform 5 16 env49065 = env49066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49065 == env49066) = true)

theorem identity49066 : scanCanonicalize (H12AffineFastState.compose env49066 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49066 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49067 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,41,0,0,34,16,1,53,1,1,32,16,3,41,16,0,16,16,0,20,32,36,33,1,513]

theorem envBound49067 : H12AffineFastState.Bounded env49067 := by
  intro p hp
  have h : env49067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49066_49067 : H12AffineEnvironment.transform 7 37 env49066 = env49067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49066 == env49067) = true)

theorem identity49067 : scanCanonicalize (H12AffineFastState.compose env49067 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound49067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49068 : List Nat := [2,4,8,16,32,16,8,37,16,52,0,16,41,0,0,34,16,1,53,1,1,32,16,3,41,16,0,16,16,0,20,32,36,33,1,17]

theorem envBound49068 : H12AffineFastState.Bounded env49068 := by
  intro p hp
  have h : env49068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49067_49068 : H12AffineEnvironment.transform 8 16 env49067 = env49068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env49067 == env49068) = true)

theorem identity49068 : scanCanonicalize (H12AffineFastState.compose env49068 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound49068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49069 : List Nat := [2,4,8,16,26,16,8,31,16,14,0,16,19,0,0,24,16,1,15,1,1,26,16,3,19,16,0,16,16,0,20,26,30,27,1,17]

theorem envBound49069 : H12AffineFastState.Bounded env49069 := by
  intro p hp
  have h : env49069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49068_49069 : H12AffineEnvironment.transform 4 26 env49068 = env49069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env49068 == env49069) = true)

def env49070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73770,73755,65877,8193,64,10588,79130,17665,67618,75103,29820,257,21792,13325,513]

theorem envBound49070 : H12AffineFastState.Bounded env49070 := by
  intro p hp
  have h : env49070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49058_49070 : H12AffineEnvironment.transform 6 9 env49058 = env49070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49058 == env49070) = true)

theorem identity49070 : scanCanonicalize (H12AffineFastState.compose env49070 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49070 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,342,24909,2421,1025,1,12572,8572,8525,3,8193,64,10588,13388,17665,2420,9225,29820,257,21792,13325,513]

theorem envBound49071 : H12AffineFastState.Bounded env49071 := by
  intro p hp
  have h : env49071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49070_49071 : H12AffineEnvironment.transform 15 342 env49070 = env49071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49070 == env49071) = true)

theorem identity49071 : scanCanonicalize (H12AffineFastState.compose env49071 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound49071 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,0,342,4389,2421,1025,1,12572,8572,8525,3,8193,64,10588,13388,13673,2420,9225,1044,257,9544,13325,513]

theorem envBound49072 : H12AffineFastState.Bounded env49072 := by
  intro p hp
  have h : env49072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49071_49072 : H12AffineEnvironment.transform 13 12392 env49071 = env49072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env49071 == env49072) = true)

theorem identity49072 : scanCanonicalize (H12AffineFastState.compose env49072 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound49072 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env49073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,8192,11625,0,342,3108,2421,1025,1,11293,8572,8525,3,8193,64,10588,10573,10344,2420,9225,1044,257,9544,10508,513]

theorem envBound49073 : H12AffineFastState.Bounded env49073 := by
  intro p hp
  have h : env49073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49072_49073 : H12AffineEnvironment.transform 11 3329 env49072 = env49073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env49072 == env49073) = true)

theorem identity49073 : scanCanonicalize (H12AffineFastState.compose env49073 (packedSelected [0,1,7,8,10,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49073 : packedSelected [0,1,7,8,10,18] rootPS < 2^1333 := by decide +kernel

def env49074 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,8192,11340,0,115,3108,2128,1025,1,11293,8281,8296,3,8193,64,10361,10344,10344,2129,9225,1044,36,9325,10281,513]

theorem envBound49074 : H12AffineFastState.Bounded env49074 := by
  intro p hp
  have h : env49074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49073_49074 : H12AffineEnvironment.transform 7 37 env49073 = env49074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49073 == env49074) = true)

theorem identity49074 : scanCanonicalize (H12AffineFastState.compose env49074 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49074 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49075 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,120,3124,0,115,3108,2128,1025,1,3173,33,16,3,121,64,2049,2064,2064,2129,1137,1044,36,1045,2129,513]

theorem envBound49075 : H12AffineFastState.Bounded env49075 := by
  intro p hp
  have h : env49075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49074_49075 : H12AffineEnvironment.transform 12 120 env49074 = env49075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49074 == env49075) = true)

theorem identity49075 : scanCanonicalize (H12AffineFastState.compose env49075 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49075 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49076 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,120,2049,0,115,2065,2128,52,1,2128,33,16,3,121,64,2049,2064,2064,2129,68,33,36,32,2129,513]

theorem envBound49076 : H12AffineFastState.Bounded env49076 := by
  intro p hp
  have h : env49076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49075_49076 : H12AffineEnvironment.transform 9 53 env49075 = env49076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49075 == env49076) = true)

def env49077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,98780,8328,64,43357,185601,17665,262145,181709,400588,257,21792,46212,254490]

theorem envBound49077 : H12AffineFastState.Bounded env49077 := by
  intro p hp
  have h : env49077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49054_49077 : H12AffineEnvironment.transform 21 272513 env49054 = env49077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49054 == env49077) = true)

theorem identity49077 : scanCanonicalize (H12AffineFastState.compose env49077 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49077 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272513,180224,41430,8328,64,43357,185601,17665,262145,181709,400588,257,21792,46212,180752]

theorem envBound49078 : H12AffineFastState.Bounded env49078 := by
  intro p hp
  have h : env49078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49077_49078 : H12AffineEnvironment.transform 15 8202 env49077 = env49078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49077 == env49078) = true)

theorem identity49078 : scanCanonicalize (H12AffineFastState.compose env49078 (packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound49078 : packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env49079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1025,32769,184401,180272,180224,41430,8328,64,43357,185601,17665,190640,181709,62589,257,21792,46212,180752]

theorem envBound49079 : H12AffineFastState.Bounded env49079 := by
  intro p hp
  have h : env49079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49078_49079 : H12AffineEnvironment.transform 17 190641 env49078 = env49079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env49078 == env49079) = true)

theorem identity49079 : scanCanonicalize (H12AffineFastState.compose env49079 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49079 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,131072,157872,1025,0,151632,147505,147457,8663,8328,64,10588,152832,17665,157873,148940,29820,257,21792,13445,147985]

theorem envBound49080 : H12AffineFastState.Bounded env49080 := by
  intro p hp
  have h : env49080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49079_49080 : H12AffineEnvironment.transform 14 1 env49079 = env49080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49079 == env49080) = true)

theorem identity49080 : scanCanonicalize (H12AffineFastState.compose env49080 (packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49080 : packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS < 2^1333 := by decide +kernel

def env49081 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,1,8202,131072,157872,321,0,151632,147505,147457,8663,8328,64,10588,151616,16449,157873,147596,28988,257,20576,12741,147985]

theorem envBound49081 : H12AffineFastState.Bounded env49081 := by
  intro p hp
  have h : env49081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49080_49081 : H12AffineEnvironment.transform 9 320 env49080 = env49081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49080 == env49081) = true)

theorem identity49081 : scanCanonicalize (H12AffineFastState.compose env49081 (packedSelected [1,2,4,6,8,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound49081 : packedSelected [1,2,4,6,8,20,22,26] rootPS < 2^1333 := by decide +kernel

def env49082 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,1,8202,16536,10280,321,0,4296,169,153,8663,8328,64,10588,4312,16449,10281,20,28988,257,20576,12741,649]

theorem envBound49082 : H12AffineFastState.Bounded env49082 := by
  intro p hp
  have h : env49082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49081_49082 : H12AffineEnvironment.transform 16 16536 env49081 = env49082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env49081 == env49082) = true)

theorem identity49082 : scanCanonicalize (H12AffineFastState.compose env49082 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49082 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env49083 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,4096,8192,16384,1,8202,16536,8233,321,0,4296,169,153,8663,8328,64,8541,4312,16449,8232,20,28988,257,20576,12741,649]

theorem envBound49083 : H12AffineFastState.Bounded env49083 := by
  intro p hp
  have h : env49083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49082_49083 : H12AffineEnvironment.transform 10 1 env49082 = env49083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49082 == env49083) = true)

theorem identity49083 : scanCanonicalize (H12AffineFastState.compose env49083 (packedSelected [1,2,4,8,9,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49083 : packedSelected [1,2,4,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env49084 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,4096,8192,4112,1,8202,4232,8233,321,0,4296,169,153,8663,8328,64,8541,4312,4177,8232,20,8492,257,112,12741,649]

theorem envBound49084 : H12AffineFastState.Bounded env49084 := by
  intro p hp
  have h : env49084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49083_49084 : H12AffineEnvironment.transform 13 4112 env49083 = env49084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49083 == env49084) = true)

theorem identity49084 : scanCanonicalize (H12AffineFastState.compose env49084 (packedSelected [2,3,4,5,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound49084 : packedSelected [2,3,4,5,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49085 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,153,8192,137,1,8202,17,8233,321,0,81,169,153,8663,8328,64,8541,65,200,8232,20,8492,257,112,8540,649]

theorem envBound49085 : H12AffineFastState.Bounded env49085 := by
  intro p hp
  have h : env49085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49084_49085 : H12AffineEnvironment.transform 11 153 env49084 = env49085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env49084 == env49085) = true)

theorem identity49085 : scanCanonicalize (H12AffineFastState.compose env49085 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49085 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49086 : List Nat := [2,4,8,16,32,64,128,4,512,68,1,153,8192,137,1,8202,17,8233,69,0,81,169,153,8403,8328,64,8281,65,200,8232,20,8232,5,112,8280,649]

theorem envBound49086 : H12AffineFastState.Bounded env49086 := by
  intro p hp
  have h : env49086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49085_49086 : H12AffineEnvironment.transform 7 4 env49085 = env49086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49085 == env49086) = true)

theorem identity49086 : scanCanonicalize (H12AffineFastState.compose env49086 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49086 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env49087 : List Nat := [2,4,8,16,32,64,8,4,512,68,1,17,8192,1,1,8202,17,8233,69,0,81,33,17,8283,8192,64,8281,65,64,8232,20,8232,5,112,8280,513]

theorem envBound49087 : H12AffineFastState.Bounded env49087 := by
  intro p hp
  have h : env49087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49086_49087 : H12AffineEnvironment.transform 6 8 env49086 = env49087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49086 == env49087) = true)

theorem identity49087 : scanCanonicalize (H12AffineFastState.compose env49087 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49087 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49088 : List Nat := [2,4,8,16,32,0,8,4,512,4,1,17,8192,1,1,8202,17,8233,5,0,17,33,17,8219,8192,0,8217,1,0,8232,20,8232,5,48,8216,513]

theorem envBound49088 : H12AffineFastState.Bounded env49088 := by
  intro p hp
  have h : env49088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49087_49088 : H12AffineEnvironment.transform 5 0 env49087 = env49088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49087 == env49088) = true)

theorem identity49088 : scanCanonicalize (H12AffineFastState.compose env49088 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound49088 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env49089 : List Nat := [2,4,8,16,26,0,8,4,512,4,1,17,8192,1,1,8202,17,8211,5,0,17,27,17,8219,8192,0,8217,1,0,8210,20,8210,5,10,8216,513]

theorem envBound49089 : H12AffineFastState.Bounded env49089 := by
  intro p hp
  have h : env49089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49088_49089 : H12AffineEnvironment.transform 4 26 env49088 = env49089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env49088 == env49089) = true)

theorem identity49089 : scanCanonicalize (H12AffineFastState.compose env49089 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49089 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env49090 : List Nat := [2,4,8,1,11,0,8,4,512,4,1,0,8192,1,1,8202,0,8194,5,0,0,10,0,8202,8192,0,8200,1,0,8195,5,8195,5,10,8201,513]

theorem envBound49090 : H12AffineFastState.Bounded env49090 := by
  intro p hp
  have h : env49090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49089_49090 : H12AffineEnvironment.transform 3 1 env49089 = env49090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49089 == env49090) = true)

def env49091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,98781,8328,64,4489692,185600,17664,262144,181709,4338764,257,21792,46212,254490]

theorem envBound49091 : H12AffineFastState.Bounded env49091 := by
  intro p hp
  have h : env49091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49053_49091 : H12AffineEnvironment.transform 22 180225 env49053 = env49091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env49053 == env49091) = true)

def env49092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,98781,8328,64,43356,185600,17664,262144,181709,400588,257,21792,46212,254490]

theorem envBound49092 : H12AffineFastState.Bounded env49092 := by
  intro p hp
  have h : env49092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49091_49092 : H12AffineEnvironment.transform 21 272512 env49091 = env49092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49091 == env49092) = true)

theorem identity49092 : scanCanonicalize (H12AffineFastState.compose env49092 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound49092 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,115870,272512,120014,98781,8328,64,43356,115151,17664,262144,119042,329731,257,21792,46212,63189]

theorem envBound49093 : H12AffineFastState.Bounded env49093 := by
  intro p hp
  have h : env49093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49092_49093 : H12AffineEnvironment.transform 16 70863 env49092 = env49093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env49092 == env49093) = true)

theorem identity49093 : scanCanonicalize (H12AffineFastState.compose env49093 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound49093 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env49094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,70863,262144,1025,32769,110667,272512,106523,98781,8328,64,43356,111898,12757,262144,107991,329731,257,8693,46212,33280]

theorem envBound49094 : H12AffineFastState.Bounded env49094 := by
  intro p hp
  have h : env49094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49093_49094 : H12AffineEnvironment.transform 13 13525 env49093 = env49094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env49093 == env49094) = true)

theorem identity49094 : scanCanonicalize (H12AffineFastState.compose env49094 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49094 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env49095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,13508,262144,1025,32769,36928,272512,32784,41430,8328,64,43356,38161,12757,262144,34268,272392,257,8693,46212,33280]

theorem envBound49095 : H12AffineFastState.Bounded env49095 := by
  intro p hp
  have h : env49095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49094_49095 : H12AffineEnvironment.transform 15 8203 env49094 = env49095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49094 == env49095) = true)

def env49096 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,32768,8203,13460,262144,1025,32769,36880,272512,32784,41350,8328,16,43276,38161,12677,262144,34188,272392,257,8613,46212,33280]

theorem envBound49096 : H12AffineFastState.Bounded env49096 := by
  intro p hp
  have h : env49096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49095_49096 : H12AffineEnvironment.transform 5 16 env49095 = env49096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49095 == env49096) = true)

theorem identity49096 : scanCanonicalize (H12AffineFastState.compose env49096 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49096 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49097 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,32768,263,5528,262144,1025,32769,36880,264588,32784,32906,388,16,34816,38161,4233,262144,34188,264452,257,169,38280,33280]

theorem envBound49097 : H12AffineFastState.Bounded env49097 := by
  intro p hp
  have h : env49097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49096_49097 : H12AffineEnvironment.transform 12 268 env49096 = env49097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49096 == env49097) = true)

theorem identity49097 : scanCanonicalize (H12AffineFastState.compose env49097 (packedSelected [0,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49097 : packedSelected [0,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49098 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,41,5292,32768,34,5309,262144,1025,32769,36880,264361,32784,32906,161,16,34816,37940,4233,262144,33961,264225,36,169,38061,33280]

theorem envBound49098 : H12AffineFastState.Bounded env49098 := by
  intro p hp
  have h : env49098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49097_49098 : H12AffineEnvironment.transform 7 37 env49097 = env49098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49097 == env49098) = true)

theorem identity49098 : scanCanonicalize (H12AffineFastState.compose env49098 (packedSelected [0,2,6,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49098 : packedSelected [0,2,6,9,10] rootPS < 2^1333 := by decide +kernel

def env49099 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,32768,34,5172,262144,1025,32769,36880,264224,32784,32771,40,16,34816,37940,4096,262144,33824,264225,36,32,37924,33280]

theorem envBound49099 : H12AffineFastState.Bounded env49099 := by
  intro p hp
  have h : env49099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49098_49099 : H12AffineEnvironment.transform 6 9 env49098 = env49099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49098 == env49099) = true)

def env49100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,32768,8203,13461,262144,1025,32769,36881,272512,32784,41351,8328,17,43277,38161,12676,262144,34189,272392,257,8612,46212,33280]

theorem envBound49100 : H12AffineFastState.Bounded env49100 := by
  intro p hp
  have h : env49100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49095_49100 : H12AffineEnvironment.transform 5 17 env49095 = env49100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49095 == env49100) = true)

theorem identity49100 : scanCanonicalize (H12AffineFastState.compose env49100 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound49100 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,8581,8203,13461,262144,1025,8580,12692,272512,8597,2,8328,17,2184,13460,12676,262144,9224,272392,257,8612,5377,9093]

theorem envBound49101 : H12AffineFastState.Bounded env49101 := by
  intro p hp
  have h : env49101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49100_49101 : H12AffineEnvironment.transform 14 8581 env49100 = env49101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env49100 == env49101) = true)

theorem identity49101 : scanCanonicalize (H12AffineFastState.compose env49101 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound49101 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,399,5393,262144,1025,0,4112,264452,17,2,268,17,2184,5392,4096,262144,1420,264588,257,32,5377,513]

theorem envBound49102 : H12AffineFastState.Bounded env49102 := by
  intro p hp
  have h : env49102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49101_49102 : H12AffineEnvironment.transform 12 388 env49101 = env49102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env49101 == env49102) = true)

theorem identity49102 : scanCanonicalize (H12AffineFastState.compose env49102 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound49102 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,642,4096,388,5376,1,399,5393,262144,1025,0,4112,263046,17,2,268,17,522,5392,4096,262144,1420,262926,257,32,5377,513]

theorem envBound49103 : H12AffineFastState.Bounded env49103 := by
  intro p hp
  have h : env49103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49102_49103 : H12AffineEnvironment.transform 10 642 env49102 = env49103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env49102 == env49103) = true)

theorem identity49103 : scanCanonicalize (H12AffineFastState.compose env49103 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 523) := by decide +kernel

theorem selectedBound49103 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env49104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,642,4096,388,5376,1,399,5393,523,1025,0,4112,397,17,2,268,17,522,5392,4096,523,1420,261,257,32,5377,513]

theorem envBound49104 : H12AffineFastState.Bounded env49104 := by
  intro p hp
  have h : env49104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49103_49104 : H12AffineEnvironment.transform 17 523 env49103 = env49104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 523 env49103 == env49104) = true)

theorem identity49104 : scanCanonicalize (H12AffineFastState.compose env49104 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49104 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env49105 : List Nat := [2,4,8,16,32,17,128,4,512,1024,642,4096,128,5124,1,139,5141,523,1025,0,4112,137,17,2,8,17,522,5140,4096,523,1160,1,5,32,5125,513]

theorem envBound49105 : H12AffineFastState.Bounded env49105 := by
  intro p hp
  have h : env49105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49104_49105 : H12AffineEnvironment.transform 7 4 env49104 = env49105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49104 == env49105) = true)

theorem identity49105 : scanCanonicalize (H12AffineFastState.compose env49105 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49105 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env49106 : List Nat := [2,4,8,16,1,17,128,4,512,1024,642,4096,128,5124,1,139,5141,523,1025,0,4112,137,17,2,8,17,522,5140,4096,523,1160,1,5,1,5125,513]

theorem envBound49106 : H12AffineFastState.Bounded env49106 := by
  intro p hp
  have h : env49106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49105_49106 : H12AffineEnvironment.transform 4 1 env49105 = env49106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49105 == env49106) = true)

theorem identity49106 : scanCanonicalize (H12AffineFastState.compose env49106 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49106 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49107 : List Nat := [2,4,8,16,1,17,9,4,512,1024,523,4096,9,5124,1,2,5141,523,1025,0,4112,0,17,2,8,17,522,5140,4096,523,1025,1,5,1,5125,513]

theorem envBound49107 : H12AffineFastState.Bounded env49107 := by
  intro p hp
  have h : env49107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49106_49107 : H12AffineEnvironment.transform 6 9 env49106 = env49107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49106 == env49107) = true)

theorem identity49107 : scanCanonicalize (H12AffineFastState.compose env49107 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound49107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49108 : List Nat := [2,4,8,16,1,17,9,4,512,21,523,4096,9,4113,1,2,4096,523,20,0,4112,0,17,2,8,17,522,4097,4096,523,20,1,5,1,4112,513]

theorem envBound49108 : H12AffineFastState.Bounded env49108 := by
  intro p hp
  have h : env49108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49107_49108 : H12AffineEnvironment.transform 9 21 env49107 = env49108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env49107 == env49108) = true)

theorem identity49108 : scanCanonicalize (H12AffineFastState.compose env49108 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound49108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49109 : List Nat := [2,4,8,16,1,17,9,4,30,21,21,4096,9,4113,1,2,4096,21,20,0,4112,0,17,2,8,17,20,4097,4096,21,20,1,5,1,4112,31]

theorem envBound49109 : H12AffineFastState.Bounded env49109 := by
  intro p hp
  have h : env49109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49108_49109 : H12AffineEnvironment.transform 8 30 env49108 = env49109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env49108 == env49109) = true)

theorem identity49109 : scanCanonicalize (H12AffineFastState.compose env49109 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49110 : List Nat := [1,4,8,16,1,17,9,4,29,21,21,4096,9,4113,1,1,4096,21,20,0,4112,0,17,1,8,17,20,4097,4096,21,20,1,5,1,4112,28]

theorem envBound49110 : H12AffineFastState.Bounded env49110 := by
  intro p hp
  have h : env49110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49109_49110 : H12AffineEnvironment.transform 0 1 env49109 = env49110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49109 == env49110) = true)

theorem identity49110 : scanCanonicalize (H12AffineFastState.compose env49110 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound49110 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49111 : List Nat := [1,4,8,16,1,17,9,4,29,21,21,17,9,0,1,1,17,21,20,0,1,0,17,1,8,17,20,16,17,21,20,1,5,1,1,28]

theorem envBound49111 : H12AffineFastState.Bounded env49111 := by
  intro p hp
  have h : env49111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49110_49111 : H12AffineEnvironment.transform 11 17 env49110 = env49111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49110 == env49111) = true)

def env49112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,98781,8328,64,43357,185600,17664,262144,181709,400589,257,21792,46212,254490]

theorem envBound49112 : H12AffineFastState.Bounded env49112 := by
  intro p hp
  have h : env49112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49091_49112 : H12AffineEnvironment.transform 21 272513 env49091 = env49112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49091 == env49112) = true)

theorem identity49112 : scanCanonicalize (H12AffineFastState.compose env49112 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound49112 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184401,272513,180225,21762,8328,64,43357,185600,17664,262144,181709,400589,257,21792,46212,145093]

theorem envBound49113 : H12AffineFastState.Bounded env49113 := by
  intro p hp
  have h : env49113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49112_49113 : H12AffineEnvironment.transform 15 54495 env49112 = env49113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env49112 == env49113) = true)

def env49114 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,184321,272513,180225,21762,8328,16,43277,185600,17664,262144,181661,400541,257,21792,46212,145045]

theorem envBound49114 : H12AffineFastState.Bounded env49114 := by
  intro p hp
  have h : env49114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49113_49114 : H12AffineEnvironment.transform 5 16 env49113 = env49114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49113 == env49114) = true)

theorem identity49114 : scanCanonicalize (H12AffineFastState.compose env49114 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound49114 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env49115 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,179633,1025,32769,184321,169264,180225,21762,8328,16,43277,185600,17664,179633,181661,41260,257,21792,46212,145045]

theorem envBound49115 : H12AffineFastState.Bounded env49115 := by
  intro p hp
  have h : env49115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49114_49115 : H12AffineEnvironment.transform 17 179633 env49114 = env49115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env49114 == env49115) = true)

theorem identity49115 : scanCanonicalize (H12AffineFastState.compose env49115 (packedSelected [0,1,4,7,22,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound49115 : packedSelected [0,1,4,7,22,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49116 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,262,131072,157752,1025,21896,132488,147641,136584,21762,8328,16,31876,131209,17664,157752,135188,29861,257,21792,24845,145045]

theorem envBound49116 : H12AffineFastState.Bounded env49116 := by
  intro p hp
  have h : env49116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49115_49116 : H12AffineEnvironment.transform 14 21897 env49115 = env49116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env49115 == env49116) = true)

theorem identity49116 : scanCanonicalize (H12AffineFastState.compose env49116 (packedSelected [0,9,16,17,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound49116 : packedSelected [0,9,16,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env49117 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,262,13460,23724,1025,21896,12572,29741,8476,21762,8328,16,31876,13341,17664,23724,9344,29861,257,21792,24845,513]

theorem envBound49117 : H12AffineFastState.Bounded env49117 := by
  intro p hp
  have h : env49117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49116_49117 : H12AffineEnvironment.transform 16 13460 env49116 = env49117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env49116 == env49117) = true)

theorem identity49117 : scanCanonicalize (H12AffineFastState.compose env49117 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49117 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env49118 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,136,262,13460,2477,1025,137,12572,8492,8476,3,8328,16,10629,13341,4097,2477,9344,8612,257,33,13324,513]

theorem envBound49118 : H12AffineFastState.Bounded env49118 := by
  intro p hp
  have h : env49118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49117_49118 : H12AffineEnvironment.transform 13 5377 env49117 = env49118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49117 == env49118) = true)

theorem identity49118 : scanCanonicalize (H12AffineFastState.compose env49118 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound49118 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,136,262,5392,2477,1025,137,4248,168,152,3,268,16,2049,5529,4097,2477,1284,32,257,33,5512,513]

theorem envBound49119 : H12AffineFastState.Bounded env49119 := by
  intro p hp
  have h : env49119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49118_49119 : H12AffineEnvironment.transform 12 388 env49118 = env49119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env49118 == env49119) = true)

def env49120 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,184320,272513,180225,21762,8328,17,43276,185600,17664,262144,181660,400540,257,21792,46212,145044]

theorem envBound49120 : H12AffineFastState.Bounded env49120 := by
  intro p hp
  have h : env49120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49113_49120 : H12AffineEnvironment.transform 5 17 env49113 = env49120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49113 == env49120) = true)

theorem identity49120 : scanCanonicalize (H12AffineFastState.compose env49120 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound49120 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env49121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,24860,262144,1025,32769,45340,272513,41245,21762,8328,17,43276,46108,17664,262144,42112,294272,257,21792,46212,22408]

theorem envBound49121 : H12AffineFastState.Bounded env49121 := by
  intro p hp
  have h : env49121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49120_49121 : H12AffineEnvironment.transform 16 24860 env49120 = env49121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env49120 == env49121) = true)

theorem identity49121 : scanCanonicalize (H12AffineFastState.compose env49121 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound49121 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env49122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40971,5529,262144,1025,32769,45340,272513,41245,8583,8328,17,43276,46108,12677,262144,42112,264453,257,8613,46212,8973]

theorem envBound49122 : H12AffineFastState.Bounded env49122 := by
  intro p hp
  have h : env49122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49121_49122 : H12AffineEnvironment.transform 13 13445 env49121 = env49122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env49121 == env49122) = true)

theorem identity49122 : scanCanonicalize (H12AffineFastState.compose env49122 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound49122 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env49123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40971,5529,43048,1025,32769,45340,32937,41245,8583,8328,17,43276,46108,12677,43048,42112,41261,257,8613,46212,8973]

theorem envBound49123 : H12AffineFastState.Bounded env49123 := by
  intro p hp
  have h : env49123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49122_49123 : H12AffineEnvironment.transform 17 43048 env49122 = env49123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env49122 == env49123) = true)

theorem identity49123 : scanCanonicalize (H12AffineFastState.compose env49123 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49123 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env49124 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,32768,33166,5529,35245,1025,32769,37017,32937,32920,2,269,17,34953,38297,4096,35245,34053,32936,257,32,38145,648]

theorem envBound49124 : H12AffineFastState.Bounded env49124 := by
  intro p hp
  have h : env49124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49123_49124 : H12AffineEnvironment.transform 12 389 env49123 = env49124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49123 == env49124) = true)

theorem identity49124 : scanCanonicalize (H12AffineFastState.compose env49124 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound49124 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49125 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,429,35,5529,2048,1025,428,4404,260,309,2,269,17,2340,5172,4096,2048,1192,261,257,32,5292,648]

theorem envBound49125 : H12AffineFastState.Bounded env49125 := by
  intro p hp
  have h : env49125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49124_49125 : H12AffineEnvironment.transform 14 429 env49124 = env49125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env49124 == env49125) = true)

theorem identity49125 : scanCanonicalize (H12AffineFastState.compose env49125 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound49125 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49126 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,4096,389,4541,429,35,4388,2048,188,428,4404,260,309,2,269,17,2340,4233,4096,2048,21,261,257,32,4113,648]

theorem envBound49126 : H12AffineFastState.Bounded env49126 := by
  intro p hp
  have h : env49126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49125_49126 : H12AffineEnvironment.transform 9 189 env49125 = env49126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env49125 == env49126) = true)

theorem identity49126 : scanCanonicalize (H12AffineFastState.compose env49126 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound49126 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49127 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,4096,41,4113,1,35,4232,2048,188,0,4248,168,153,2,161,17,2184,4233,4096,2048,21,169,173,32,4113,648]

theorem envBound49127 : H12AffineFastState.Bounded env49127 := by
  intro p hp
  have h : env49127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49126_49127 : H12AffineEnvironment.transform 7 172 env49126 = env49127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49126 == env49127) = true)

theorem identity49127 : scanCanonicalize (H12AffineFastState.compose env49127 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound49127 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49128 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,48,41,33,1,35,184,2048,188,0,168,168,153,2,161,17,2184,185,48,2048,21,169,173,32,33,648]

theorem envBound49128 : H12AffineFastState.Bounded env49128 := by
  intro p hp
  have h : env49128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49127_49128 : H12AffineEnvironment.transform 11 48 env49127 = env49128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49127 == env49128) = true)

theorem identity49128 : scanCanonicalize (H12AffineFastState.compose env49128 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 141) := by decide +kernel

theorem selectedBound49128 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env49129 : List Nat := [2,4,8,16,32,17,128,172,512,189,141,48,41,33,1,35,184,141,188,0,168,168,153,2,161,17,5,185,48,141,21,169,173,32,33,648]

theorem envBound49129 : H12AffineFastState.Bounded env49129 := by
  intro p hp
  have h : env49129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49128_49129 : H12AffineEnvironment.transform 10 141 env49128 = env49129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 141 env49128 == env49129) = true)

theorem identity49129 : scanCanonicalize (H12AffineFastState.compose env49129 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound49129 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env49130 : List Nat := [2,4,8,16,32,17,128,172,19,189,141,48,41,33,1,35,184,141,188,0,168,168,153,2,161,17,5,185,48,141,21,169,173,32,33,155]

theorem envBound49130 : H12AffineFastState.Bounded env49130 := by
  intro p hp
  have h : env49130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49129_49130 : H12AffineEnvironment.transform 8 19 env49129 = env49130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env49129 == env49130) = true)

theorem identity49130 : scanCanonicalize (H12AffineFastState.compose env49130 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 44) := by decide +kernel

theorem selectedBound49130 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env49131 : List Nat := [2,4,8,16,32,17,44,0,19,17,33,48,41,33,1,35,20,33,16,0,4,4,53,2,13,17,5,21,48,33,21,5,1,32,33,55]

theorem envBound49131 : H12AffineFastState.Bounded env49131 := by
  intro p hp
  have h : env49131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49130_49131 : H12AffineEnvironment.transform 6 44 env49130 = env49131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env49130 == env49131) = true)

end H12CloudChart0