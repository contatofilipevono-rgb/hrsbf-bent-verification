import H12CloudChart0Data143

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity36531 : scanCanonicalize (H12AffineFastState.compose env36531 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36531 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,17,2,8192,65,4262262,2172251,2118976,2420,75103,6382922,257,2188650,2172186,513]

theorem envBound36532 : H12AffineFastState.Bounded env36532 := by
  intro p hp
  have h : env36532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36531_36532 : H12AffineEnvironment.transform 14 8540 env36531 = env36532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36531 == env36532) = true)

theorem identity36532 : scanCanonicalize (H12AffineFastState.compose env36532 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound36532 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,79195,4194304,17,2,8192,65,4262262,4096,90139,2420,75103,4214801,257,20529,4161,513]

theorem envBound36533 : H12AffineFastState.Bounded env36533 := by
  intro p hp
  have h : env36533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36532_36533 : H12AffineEnvironment.transform 20 79195 env36532 = env36533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env36532 == env36533) = true)

theorem identity36533 : scanCanonicalize (H12AffineFastState.compose env36533 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36533 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env36534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1025,8541,5457,4194304,17,2,8192,65,4204924,4096,16401,2420,1365,4214801,257,20529,4161,513]

theorem envBound36534 : H12AffineFastState.Bounded env36534 := by
  intro p hp
  have h : env36534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36533_36534 : H12AffineEnvironment.transform 15 8202 env36533 = env36534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36533 == env36534) = true)

theorem identity36534 : scanCanonicalize (H12AffineFastState.compose env36534 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 4144) := by decide +kernel

theorem selectedBound36534 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1025,8541,5457,4144,17,2,8192,65,14668,4096,16401,2420,1365,16417,257,20529,4161,513]

theorem envBound36535 : H12AffineFastState.Bounded env36535 := by
  intro p hp
  have h : env36535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36534_36535 : H12AffineEnvironment.transform 21 4144 env36534 = env36535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4144 env36534 == env36535) = true)

theorem identity36535 : scanCanonicalize (H12AffineFastState.compose env36535 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound36535 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env36536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,1094,16401,3172,1025,1297,5457,4144,17,2,1100,65,7424,4096,16401,2420,1365,16417,257,20529,4161,513]

theorem envBound36536 : H12AffineFastState.Bounded env36536 := by
  intro p hp
  have h : env36536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36535_36536 : H12AffineEnvironment.transform 12 1100 env36535 = env36536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env36535 == env36536) = true)

theorem identity36536 : scanCanonicalize (H12AffineFastState.compose env36536 (packedSelected [4,9,23] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36536 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env36537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1100,16384,1296,1094,16401,3172,1025,1297,1345,32,17,2,1100,65,3344,16,16401,2420,1365,16417,257,16417,81,513]

theorem envBound36537 : H12AffineFastState.Bounded env36537 := by
  intro p hp
  have h : env36537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36536_36537 : H12AffineEnvironment.transform 11 16 env36536 = env36537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36536 == env36537) = true)

theorem identity36537 : scanCanonicalize (H12AffineFastState.compose env36537 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound36537 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1100,80,1296,1094,65,3172,1025,1297,1345,32,17,2,1100,65,3344,16,65,2420,1365,113,257,113,81,513]

theorem envBound36538 : H12AffineFastState.Bounded env36538 := by
  intro p hp
  have h : env36538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36537_36538 : H12AffineEnvironment.transform 13 80 env36537 = env36538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env36537 == env36538) = true)

theorem identity36538 : scanCanonicalize (H12AffineFastState.compose env36538 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound36538 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,16,1100,80,1296,1094,65,1344,1025,1297,1345,32,17,2,1100,65,1076,16,65,80,1365,113,257,113,81,513]

theorem envBound36539 : H12AffineFastState.Bounded env36539 := by
  intro p hp
  have h : env36539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36538_36539 : H12AffineEnvironment.transform 10 292 env36538 = env36539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env36538 == env36539) = true)

theorem identity36539 : scanCanonicalize (H12AffineFastState.compose env36539 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36539 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env36540 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,16,1100,80,1124,1094,65,1076,1025,1125,1077,32,17,2,1100,65,1076,16,65,80,1057,113,117,113,81,513]

theorem envBound36540 : H12AffineFastState.Bounded env36540 := by
  intro p hp
  have h : env36540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36539_36540 : H12AffineEnvironment.transform 7 116 env36539 = env36540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36539 == env36540) = true)

theorem identity36540 : scanCanonicalize (H12AffineFastState.compose env36540 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36541 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,16,120,80,80,114,65,0,53,81,1,32,17,2,120,65,0,16,65,80,21,113,117,113,81,513]

theorem envBound36541 : H12AffineFastState.Bounded env36541 := by
  intro p hp
  have h : env36541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36540_36541 : H12AffineEnvironment.transform 9 52 env36540 = env36541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36540 == env36541) = true)

def env36542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4302890,2196487,2118977,43049,99331,6382922,257,2212919,2172186,41820]

theorem envBound36542 : H12AffineFastState.Bounded env36542 := by
  intro p hp
  have h : env36542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36530_36542 : H12AffineEnvironment.transform 6 9 env36530 = env36542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36530 == env36542) = true)

theorem identity36542 : scanCanonicalize (H12AffineFastState.compose env36542 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound36542 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env36543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4196384,2106381,2118977,43049,9225,6341952,257,2122813,2131216,41820]

theorem envBound36543 : H12AffineFastState.Bounded env36543 := by
  intro p hp
  have h : env36543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36542_36543 : H12AffineEnvironment.transform 15 40970 env36542 = env36543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env36542 == env36543) = true)

theorem identity36543 : scanCanonicalize (H12AffineFastState.compose env36543 (packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36543 : packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env36544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33110,16401,2420,1025,32769,2097152,4194304,16,3,349,65,4196384,2098513,2118977,35189,1365,6341952,257,2114913,2131216,33280]

theorem envBound36544 : H12AffineFastState.Bounded env36544 := by
  intro p hp
  have h : env36544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36543_36544 : H12AffineEnvironment.transform 12 348 env36543 = env36544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36543 == env36544) = true)

theorem identity36544 : scanCanonicalize (H12AffineFastState.compose env36544 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 50496) := by decide +kernel

theorem selectedBound36544 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env36545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33110,16401,2420,1025,32769,50496,4194304,16,3,349,65,4196384,49169,36865,35189,1365,4194304,257,32801,16464,33280]

theorem envBound36545 : H12AffineFastState.Bounded env36545 := by
  intro p hp
  have h : env36545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36544_36545 : H12AffineEnvironment.transform 20 50496 env36544 = env36545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50496 env36544 == env36545) = true)

theorem identity36545 : scanCanonicalize (H12AffineFastState.compose env36545 (packedSelected [1,8,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound36545 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env36546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33110,16401,2420,1025,32769,50496,33,16,3,349,65,2049,49169,36865,35189,1365,33,257,32801,16464,33280]

theorem envBound36546 : H12AffineFastState.Bounded env36546 := by
  intro p hp
  have h : env36546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36545_36546 : H12AffineEnvironment.transform 21 33 env36545 = env36546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env36545 == env36546) = true)

theorem identity36546 : scanCanonicalize (H12AffineFastState.compose env36546 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound36546 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env36547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,32768,33110,5473,2420,1025,32769,36912,33,16,3,349,65,2049,38241,36865,35189,1365,33,257,32801,5408,33280]

theorem envBound36547 : H12AffineFastState.Bounded env36547 := by
  intro p hp
  have h : env36547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36546_36547 : H12AffineEnvironment.transform 13 5488 env36546 = env36547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env36546 == env36547) = true)

theorem identity36547 : scanCanonicalize (H12AffineFastState.compose env36547 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36547 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36548 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,32768,33030,5425,2340,1025,32769,36912,33,16,3,269,17,2049,38193,36865,35109,1285,33,257,32801,5408,33280]

theorem envBound36548 : H12AffineFastState.Bounded env36548 := by
  intro p hp
  have h : env36548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36547_36548 : H12AffineEnvironment.transform 5 16 env36547 = env36548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36547 == env36548) = true)

theorem identity36548 : scanCanonicalize (H12AffineFastState.compose env36548 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(14+1) ^^^ 4894) := by decide +kernel

theorem selectedBound36548 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36549 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,4894,4632,5425,2340,1025,4895,814,33,16,3,269,17,2049,1583,799,6715,1285,33,257,4927,5408,4382]

theorem envBound36549 : H12AffineFastState.Bounded env36549 := by
  intro p hp
  have h : env36549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36548_36549 : H12AffineEnvironment.transform 14 4894 env36548 = env36549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4894 env36548 == env36549) = true)

theorem identity36549 : scanCanonicalize (H12AffineFastState.compose env36549 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound36549 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env36550 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,268,2340,3866,3612,2357,2340,1025,3867,814,33,16,3,269,17,2049,1583,799,1599,1285,33,257,3899,2340,3354]

theorem envBound36550 : H12AffineFastState.Bounded env36550 := by
  intro p hp
  have h : env36550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36549_36550 : H12AffineEnvironment.transform 11 3076 env36549 = env36550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env36549 == env36550) = true)

theorem identity36550 : scanCanonicalize (H12AffineFastState.compose env36550 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound36550 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env36551 : List Nat := [2,4,8,16,32,16,9,256,512,1024,555,1583,268,783,1329,1079,798,783,1025,1328,814,33,16,3,269,17,554,1583,799,1599,1285,33,257,1296,783,1841]

theorem envBound36551 : H12AffineFastState.Bounded env36551 := by
  intro p hp
  have h : env36551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36550_36551 : H12AffineEnvironment.transform 10 555 env36550 = env36551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env36550 == env36551) = true)

theorem identity36551 : scanCanonicalize (H12AffineFastState.compose env36551 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36551 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env36552 : List Nat := [2,4,8,16,32,16,9,256,512,52,555,539,268,783,261,3,798,783,53,260,814,33,16,3,269,17,554,539,799,523,305,33,257,292,783,773]

theorem envBound36552 : H12AffineFastState.Bounded env36552 := by
  intro p hp
  have h : env36552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36551_36552 : H12AffineEnvironment.transform 9 52 env36551 = env36552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36551 == env36552) = true)

def env36553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272546,8328,65,4302891,2468911,2233816,295049,519227,6638946,257,2600070,2575650,445421]

theorem envBound36553 : H12AffineFastState.Bounded env36553 := by
  intro p hp
  have h : env36553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36503_36553 : H12AffineEnvironment.transform 22 147593 env36503 = env36553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env36503 == env36553) = true)

def env36554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302891,2468911,2119112,295049,371755,6638946,257,2485398,2428210,297981]

theorem envBound36554 : H12AffineFastState.Bounded env36554 := by
  intro p hp
  have h : env36554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36553_36554 : H12AffineEnvironment.transform 16 16400 env36553 = env36554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36553 == env36554) = true)

theorem identity36554 : scanCanonicalize (H12AffineFastState.compose env36554 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound36554 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16400,262144,1025,8661,2097152,4194304,153,272546,8328,65,4262399,2428411,2119112,270685,331263,6638946,257,2444610,2428210,272937]

theorem envBound36555 : H12AffineFastState.Bounded env36555 := by
  intro p hp
  have h : env36555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36554_36555 : H12AffineEnvironment.transform 14 8660 env36554 = env36555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env36554 == env36555) = true)

theorem identity36555 : scanCanonicalize (H12AffineFastState.compose env36555 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36555 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env36556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1025,8540,2097152,4194304,16,272427,8193,65,4262262,2428274,2118977,270685,331126,6638946,257,2444610,2428210,272937]

theorem envBound36556 : H12AffineFastState.Bounded env36556 := by
  intro p hp
  have h : env36556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36555_36556 : H12AffineEnvironment.transform 6 9 env36555 = env36556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36555 == env36556) = true)

theorem identity36556 : scanCanonicalize (H12AffineFastState.compose env36556 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound36556 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4262262,2172250,2118977,2421,75102,6382922,257,2188650,2172186,513]

theorem envBound36557 : H12AffineFastState.Bounded env36557 := by
  intro p hp
  have h : env36557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36556_36557 : H12AffineEnvironment.transform 17 10280 env36556 = env36557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36556 == env36557) = true)

theorem identity36557 : scanCanonicalize (H12AffineFastState.compose env36557 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36557 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4204925,2098513,2118977,2421,1365,6309185,257,2114913,2098449,513]

theorem envBound36558 : H12AffineFastState.Bounded env36558 := by
  intro p hp
  have h : env36558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36557_36558 : H12AffineEnvironment.transform 15 8203 env36557 = env36558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36557 == env36558) = true)

theorem identity36558 : scanCanonicalize (H12AffineFastState.compose env36558 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound36558 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1025,8540,2097152,2114913,16,3,8193,65,2124828,2098513,2118977,2421,1365,32,257,2114913,2098449,513]

theorem envBound36559 : H12AffineFastState.Bounded env36559 := by
  intro p hp
  have h : env36559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36558_36559 : H12AffineEnvironment.transform 21 2114913 env36558 = env36559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env36558 == env36559) = true)

theorem identity36559 : scanCanonicalize (H12AffineFastState.compose env36559 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound36559 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1025,8540,17680,113,16,3,8193,65,10508,16449,4177,2421,1365,32,257,113,16385,513]

theorem envBound36560 : H12AffineFastState.Bounded env36560 := by
  intro p hp
  have h : env36560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36559_36560 : H12AffineEnvironment.transform 20 17680 env36559 = env36560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env36559 == env36560) = true)

theorem identity36560 : scanCanonicalize (H12AffineFastState.compose env36560 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36560 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,10280,1025,8460,17680,33,16,3,8193,17,10508,16401,4097,2341,1285,32,257,33,16385,513]

theorem envBound36561 : H12AffineFastState.Bounded env36561 := by
  intro p hp
  have h : env36561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36560_36561 : H12AffineEnvironment.transform 5 16 env36560 = env36561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36560 == env36561) = true)

theorem identity36561 : scanCanonicalize (H12AffineFastState.compose env36561 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound36561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5384,16384,5125,5379,16400,7456,1025,5124,17680,33,16,3,5385,17,7172,16401,4097,2341,1285,32,257,33,16385,513]

theorem envBound36562 : H12AffineFastState.Bounded env36562 := by
  intro p hp
  have h : env36562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36561_36562 : H12AffineEnvironment.transform 12 5384 env36561 = env36562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env36561 == env36562) = true)

theorem identity36562 : scanCanonicalize (H12AffineFastState.compose env36562 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound36562 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2096,3384,16384,3125,3379,16400,1296,1025,3124,17680,33,16,3,3385,17,1076,16401,2097,2341,1285,32,257,33,16385,513]

theorem envBound36563 : H12AffineFastState.Bounded env36563 := by
  intro p hp
  have h : env36563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36562_36563 : H12AffineEnvironment.transform 11 2096 env36562 = env36563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env36562 == env36563) = true)

theorem identity36563 : scanCanonicalize (H12AffineFastState.compose env36563 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(13+1) ^^^ 3604) := by decide +kernel

theorem selectedBound36563 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36564 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2096,3384,3604,3125,3379,3588,1296,1025,3124,2820,33,16,3,3385,17,1076,3589,2097,2341,1285,32,257,33,3605,513]

theorem envBound36564 : H12AffineFastState.Bounded env36564 := by
  intro p hp
  have h : env36564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36563_36564 : H12AffineEnvironment.transform 13 3604 env36563 = env36564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3604 env36563 == env36564) = true)

theorem identity36564 : scanCanonicalize (H12AffineFastState.compose env36564 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound36564 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env36565 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1044,1060,300,512,33,295,528,1296,1025,32,1808,33,16,3,301,17,1076,529,1061,1329,1285,32,257,33,513,513]

theorem envBound36565 : H12AffineFastState.Bounded env36565 := by
  intro p hp
  have h : env36565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36564_36565 : H12AffineEnvironment.transform 10 1044 env36564 = env36565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env36564 == env36565) = true)

theorem identity36565 : scanCanonicalize (H12AffineFastState.compose env36565 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36565 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env36566 : List Nat := [2,4,8,1,32,1,9,256,512,1024,1029,1060,300,512,33,295,513,1281,1025,32,1793,33,1,3,301,0,1061,512,1061,1312,1285,32,257,33,513,513]

theorem envBound36566 : H12AffineFastState.Bounded env36566 := by
  intro p hp
  have h : env36566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36565_36566 : H12AffineEnvironment.transform 3 1 env36565 = env36566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36565 == env36566) = true)

theorem identity36566 : scanCanonicalize (H12AffineFastState.compose env36566 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36566 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env36567 : List Nat := [2,4,8,1,0,1,9,256,512,1024,1029,1028,268,512,1,263,513,1281,1025,0,1793,1,1,3,269,0,1029,512,1029,1280,1285,0,257,1,513,513]

theorem envBound36567 : H12AffineFastState.Bounded env36567 := by
  intro p hp
  have h : env36567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36566_36567 : H12AffineEnvironment.transform 4 0 env36566 = env36567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36566 == env36567) = true)

theorem identity36567 : scanCanonicalize (H12AffineFastState.compose env36567 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound36567 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36568 : List Nat := [2,4,8,1,0,1,9,256,512,769,772,773,268,512,1,263,513,512,768,0,0,1,1,3,269,0,772,512,772,513,516,0,257,1,513,513]

theorem envBound36568 : H12AffineFastState.Bounded env36568 := by
  intro p hp
  have h : env36568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36567_36568 : H12AffineEnvironment.transform 9 769 env36567 = env36568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env36567 == env36568) = true)

theorem identity36568 : scanCanonicalize (H12AffineFastState.compose env36568 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36568 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36569 : List Nat := [2,4,8,1,0,1,9,256,0,257,260,261,268,0,1,263,1,0,256,0,0,1,1,3,269,0,260,0,260,1,4,0,257,1,1,1]

theorem envBound36569 : H12AffineFastState.Bounded env36569 := by
  intro p hp
  have h : env36569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36568_36569 : H12AffineEnvironment.transform 8 0 env36568 = env36569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36568 == env36569) = true)

theorem identity36569 : scanCanonicalize (H12AffineFastState.compose env36569 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36570 : List Nat := [2,4,8,1,0,1,9,4,0,5,0,1,8,0,1,3,1,0,4,0,0,1,1,3,9,0,0,0,0,1,4,0,5,1,1,1]

theorem envBound36570 : H12AffineFastState.Bounded env36570 := by
  intro p hp
  have h : env36570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36569_36570 : H12AffineEnvironment.transform 7 4 env36569 = env36570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36569 == env36570) = true)

theorem identity36570 : scanCanonicalize (H12AffineFastState.compose env36570 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36571 : List Nat := [2,4,2,1,0,1,3,4,0,5,0,1,2,0,1,3,1,0,4,0,0,1,1,3,3,0,0,0,0,1,4,0,5,1,1,1]

theorem envBound36571 : H12AffineFastState.Bounded env36571 := by
  intro p hp
  have h : env36571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36570_36571 : H12AffineEnvironment.transform 2 2 env36570 = env36571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36570 == env36571) = true)

def env36572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302891,2468911,2119113,295049,371754,6638946,257,2485399,2428211,297980]

theorem envBound36572 : H12AffineFastState.Bounded env36572 := by
  intro p hp
  have h : env36572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36553_36572 : H12AffineEnvironment.transform 16 16401 env36553 = env36572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36553 == env36572) = true)

theorem identity36572 : scanCanonicalize (H12AffineFastState.compose env36572 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound36572 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35325,1025,32769,2097152,4194304,152,41311,8328,65,4302891,2172370,2119113,2420,75223,6407327,257,2188650,2196686,513]

theorem envBound36573 : H12AffineFastState.Bounded env36573 := by
  intro p hp
  have h : env36573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36572_36573 : H12AffineEnvironment.transform 17 35325 env36572 = env36573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env36572 == env36573) = true)

def env36574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302891,2172250,2118977,2420,75103,6407191,257,2188650,2196550,513]

theorem envBound36574 : H12AffineFastState.Bounded env36574 := by
  intro p hp
  have h : env36574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36573_36574 : H12AffineEnvironment.transform 6 8 env36573 = env36574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36573 == env36574) = true)

theorem identity36574 : scanCanonicalize (H12AffineFastState.compose env36574 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36574 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229153,2098512,2118977,2420,1365,6349853,257,2114912,2139212,513]

theorem envBound36575 : H12AffineFastState.Bounded env36575 := by
  intro p hp
  have h : env36575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36574_36575 : H12AffineEnvironment.transform 15 8202 env36574 = env36575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36574 == env36575) = true)

theorem identity36575 : scanCanonicalize (H12AffineFastState.compose env36575 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound36575 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,2097152,2114912,16,41311,8192,65,2149697,2098512,2118977,2420,1365,41341,257,2114912,2139212,513]

theorem envBound36576 : H12AffineFastState.Bounded env36576 := by
  intro p hp
  have h : env36576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36575_36576 : H12AffineEnvironment.transform 21 2114912 env36575 = env36576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env36575 == env36576) = true)

theorem identity36576 : scanCanonicalize (H12AffineFastState.compose env36576 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound36576 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8202,16401,30777,1025,29005,2097152,2114912,16,20499,8192,65,2112525,2098512,2118977,2420,1365,20529,257,2114912,2118912,513]

theorem envBound36577 : H12AffineFastState.Bounded env36577 := by
  intro p hp
  have h : env36577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36576_36577 : H12AffineEnvironment.transform 14 29004 env36576 = env36577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env36576 == env36577) = true)

theorem identity36577 : scanCanonicalize (H12AffineFastState.compose env36577 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound36577 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env36578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4096,10280,1025,8540,2097152,2102641,16,2,8192,65,2112525,2098512,2098512,2420,1365,32,257,2102641,2098449,513]

theorem envBound36578 : H12AffineFastState.Bounded env36578 := by
  intro p hp
  have h : env36578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36577_36578 : H12AffineEnvironment.transform 13 4113 env36577 = env36578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env36577 == env36578) = true)

def env36579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302891,2172251,2118976,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound36579 : H12AffineFastState.Bounded env36579 := by
  intro p hp
  have h : env36579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36573_36579 : H12AffineEnvironment.transform 6 9 env36573 = env36579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36573 == env36579) = true)

theorem identity36579 : scanCanonicalize (H12AffineFastState.compose env36579 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound36579 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env36580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115735,4194304,17,41311,8193,65,4302891,57676,102743,2420,75102,4194305,257,41341,16464,513]

theorem envBound36580 : H12AffineFastState.Bounded env36580 := by
  intro p hp
  have h : env36580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36579_36580 : H12AffineEnvironment.transform 20 115735 env36579 = env36580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env36579 == env36580) = true)

def env36581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91199,4194304,17,375,8193,65,4261891,16740,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound36581 : H12AffineFastState.Bounded env36581 := by
  intro p hp
  have h : env36581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36580_36581 : H12AffineEnvironment.transform 14 8232 env36580 = env36581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env36580 == env36581) = true)

theorem identity36581 : scanCanonicalize (H12AffineFastState.compose env36581 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36581 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env36582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,34,16401,10588,1025,8233,25629,4194304,17,375,8193,65,4196385,16740,12637,2420,9596,4194305,257,341,16464,513]

theorem envBound36582 : H12AffineFastState.Bounded env36582 := by
  intro p hp
  have h : env36582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36581_36582 : H12AffineEnvironment.transform 15 34 env36581 = env36582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36581 == env36582) = true)

theorem identity36582 : scanCanonicalize (H12AffineFastState.compose env36582 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound36582 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env36583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,34,16401,10588,1025,8233,25629,8493,17,375,8193,65,10508,16740,12637,2420,9596,8492,257,341,16464,513]

theorem envBound36583 : H12AffineFastState.Bounded env36583 := by
  intro p hp
  have h : env36583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36582_36583 : H12AffineEnvironment.transform 21 8493 env36582 = env36583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env36582 == env36583) = true)

theorem identity36583 : scanCanonicalize (H12AffineFastState.compose env36583 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36583 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env36584 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,34,16401,10280,1025,8233,25629,8281,17,3,8193,65,10360,16400,12329,2048,9224,8280,117,33,16464,513]

theorem envBound36584 : H12AffineFastState.Bounded env36584 := by
  intro p hp
  have h : env36584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36583_36584 : H12AffineEnvironment.transform 7 116 env36583 = env36584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36583 == env36584) = true)

theorem identity36584 : scanCanonicalize (H12AffineFastState.compose env36584 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36584 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36585 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,34,16401,10280,1025,8233,25629,8201,17,3,8193,17,10280,16400,12329,2048,9224,8200,37,33,16384,513]

theorem envBound36585 : H12AffineFastState.Bounded env36585 := by
  intro p hp
  have h : env36585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36584_36585 : H12AffineEnvironment.transform 5 16 env36584 = env36585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36584 == env36585) = true)

theorem identity36585 : scanCanonicalize (H12AffineFastState.compose env36585 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound36585 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36586 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,13324,8232,34,13341,10280,1025,8233,4113,8201,17,3,8193,17,10280,13340,12329,2048,9224,8200,37,33,13324,513]

theorem envBound36586 : H12AffineFastState.Bounded env36586 := by
  intro p hp
  have h : env36586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36585_36586 : H12AffineEnvironment.transform 13 13324 env36585 = env36586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env36585 == env36586) = true)

theorem identity36586 : scanCanonicalize (H12AffineFastState.compose env36586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36587 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,34,5173,2048,1025,1,4113,33,17,3,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound36587 : H12AffineFastState.Bounded env36587 := by
  intro p hp
  have h : env36587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36586_36587 : H12AffineEnvironment.transform 12 40 env36586 = env36587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36586 == env36587) = true)

def env36588 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,0,34,1029,2048,1025,1,33,33,17,3,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound36588 : H12AffineFastState.Bounded env36588 := by
  intro p hp
  have h : env36588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36587_36588 : H12AffineEnvironment.transform 11 48 env36587 = env36588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36587 == env36588) = true)

theorem identity36588 : scanCanonicalize (H12AffineFastState.compose env36588 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound36588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36589 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1541,48,40,1044,0,34,1029,1541,1025,1,33,33,17,3,41,17,1541,1028,49,1541,1056,32,37,33,1044,513]

theorem envBound36589 : H12AffineFastState.Bounded env36589 := by
  intro p hp
  have h : env36589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36588_36589 : H12AffineEnvironment.transform 10 1541 env36588 = env36589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env36588 == env36589) = true)

def env36590 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,48,40,32,0,34,49,561,53,1,33,33,17,3,41,17,561,48,49,561,20,32,37,33,32,513]

theorem envBound36590 : H12AffineFastState.Bounded env36590 := by
  intro p hp
  have h : env36590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36589_36590 : H12AffineEnvironment.transform 9 52 env36589 = env36590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36589 == env36590) = true)

theorem identity36590 : scanCanonicalize (H12AffineFastState.compose env36590 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound36590 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36591 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,11,19,27,0,25,10,522,14,1,26,26,17,3,18,17,522,11,10,522,20,27,30,26,27,513]

theorem envBound36591 : H12AffineFastState.Bounded env36591 := by
  intro p hp
  have h : env36591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36590_36591 : H12AffineEnvironment.transform 4 27 env36590 = env36591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env36590 == env36591) = true)

def leafEnv36591 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,11,19,27,0,25,10,522,14,1,26,26,17,3,21,18,1,17,522,11,10,522,20,27,30,26,5,24,27,513,1,26,0]

def active36591 : List Nat := [0,1,2,3,8]

def tree36591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36591 : H12WitnessSearch.Good tree36591 := H12GlobalWitnessIndex.good

theorem leafIdentity36591 : H12AffineFastState.composeSystem env36591 rootObs = leafEnv36591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36591 rootObs == leafEnv36591) = true)

theorem terminalChecked36591 : H12PackedTerminal.terminalCheckFast leafEnv36591 active36591 tree36591 = true := by decide +kernel

def env36592 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,48,40,33,0,34,48,560,52,1,33,33,17,3,41,17,560,49,49,560,21,32,37,33,33,513]

theorem envBound36592 : H12AffineFastState.Bounded env36592 := by
  intro p hp
  have h : env36592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36589_36592 : H12AffineEnvironment.transform 9 53 env36589 = env36592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36589 == env36592) = true)

theorem identity36592 : scanCanonicalize (H12AffineFastState.compose env36592 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36593 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,48,40,33,0,34,48,33,52,1,33,33,17,3,41,17,33,49,49,33,21,32,37,33,33,16]

theorem envBound36593 : H12AffineFastState.Bounded env36593 := by
  intro p hp
  have h : env36593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36592_36593 : H12AffineEnvironment.transform 8 17 env36592 = env36593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36592 == env36593) = true)

def leafEnv36593 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,48,40,33,0,34,48,33,52,1,33,33,17,3,20,41,1,17,33,49,49,33,21,32,37,33,5,35,33,16,1,33,0]

def active36593 : List Nat := [0,1,2,3,4]

def tree36593 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36593 : H12WitnessSearch.Good tree36593 := H12GlobalWitnessIndex.good

theorem leafIdentity36593 : H12AffineFastState.composeSystem env36593 rootObs = leafEnv36593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36593 rootObs == leafEnv36593) = true)

theorem terminalChecked36593 : H12PackedTerminal.terminalCheckFast leafEnv36593 active36593 tree36593 = true := by decide +kernel

def env36594 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,0,34,1028,2048,1025,1,32,33,17,3,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound36594 : H12AffineFastState.Bounded env36594 := by
  intro p hp
  have h : env36594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36587_36594 : H12AffineEnvironment.transform 11 49 env36587 = env36594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36587 == env36594) = true)

theorem identity36594 : scanCanonicalize (H12AffineFastState.compose env36594 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound36594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36595 : List Nat := [2,4,8,16,32,16,9,36,512,1024,560,49,40,1045,0,34,1028,560,1025,1,32,33,17,3,41,17,560,1029,48,560,1056,32,37,33,1045,513]

theorem envBound36595 : H12AffineFastState.Bounded env36595 := by
  intro p hp
  have h : env36595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36594_36595 : H12AffineEnvironment.transform 10 560 env36594 = env36595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env36594 == env36595) = true)

def env36596 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,49,40,33,0,34,48,560,53,1,32,33,17,3,41,17,560,49,48,560,20,32,37,33,33,513]

theorem envBound36596 : H12AffineFastState.Bounded env36596 := by
  intro p hp
  have h : env36596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36595_36596 : H12AffineEnvironment.transform 9 52 env36595 = env36596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36595 == env36596) = true)

theorem identity36596 : scanCanonicalize (H12AffineFastState.compose env36596 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound36596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36597 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,11,18,27,0,24,10,522,15,1,26,27,17,3,19,17,522,11,10,522,20,26,31,27,27,513]

theorem envBound36597 : H12AffineFastState.Bounded env36597 := by
  intro p hp
  have h : env36597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36596_36597 : H12AffineEnvironment.transform 4 26 env36596 = env36597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env36596 == env36597) = true)

def leafEnv36597 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,11,18,27,0,24,10,522,15,1,26,27,17,3,21,19,1,17,522,11,10,522,20,26,31,27,5,25,27,513,1,26,0]

def active36597 : List Nat := [0,1,2,3,8]

def tree36597 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36597 : H12WitnessSearch.Good tree36597 := H12GlobalWitnessIndex.good

theorem leafIdentity36597 : H12AffineFastState.composeSystem env36597 rootObs = leafEnv36597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36597 rootObs == leafEnv36597) = true)

theorem terminalChecked36597 : H12PackedTerminal.terminalCheckFast leafEnv36597 active36597 tree36597 = true := by decide +kernel

def env36598 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,49,40,32,0,34,49,560,52,1,32,33,17,3,41,17,560,48,48,560,21,32,37,33,32,513]

theorem envBound36598 : H12AffineFastState.Bounded env36598 := by
  intro p hp
  have h : env36598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36595_36598 : H12AffineEnvironment.transform 9 53 env36595 = env36598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36595 == env36598) = true)

theorem identity36598 : scanCanonicalize (H12AffineFastState.compose env36598 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36599 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,49,40,32,0,34,49,32,52,1,32,33,17,3,41,17,32,48,48,32,21,32,37,33,32,17]

theorem envBound36599 : H12AffineFastState.Bounded env36599 := by
  intro p hp
  have h : env36599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36598_36599 : H12AffineEnvironment.transform 8 16 env36598 = env36599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36598 == env36599) = true)

def leafEnv36599 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,49,40,32,0,34,49,32,52,1,32,33,17,3,20,41,1,17,32,48,48,32,21,32,37,33,5,35,32,17,1,32,0]

def active36599 : List Nat := [0,1,2,3,4]

def tree36599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36599 : H12WitnessSearch.Good tree36599 := H12GlobalWitnessIndex.good

theorem leafIdentity36599 : H12AffineFastState.composeSystem env36599 rootObs = leafEnv36599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36599 rootObs == leafEnv36599) = true)

theorem terminalChecked36599 : H12PackedTerminal.terminalCheckFast leafEnv36599 active36599 tree36599 = true := by decide +kernel

def env36600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91198,4194304,17,374,8193,65,4261890,16741,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound36600 : H12AffineFastState.Bounded env36600 := by
  intro p hp
  have h : env36600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36580_36600 : H12AffineEnvironment.transform 14 8233 env36580 = env36600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env36580 == env36600) = true)

theorem identity36600 : scanCanonicalize (H12AffineFastState.compose env36600 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound36600 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env36601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,342,16401,10589,1025,8232,25960,4194304,17,374,8193,65,4196692,16741,12328,2420,9224,4194305,257,340,16464,513]

theorem envBound36601 : H12AffineFastState.Bounded env36601 := by
  intro p hp
  have h : env36601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36600_36601 : H12AffineEnvironment.transform 15 342 env36600 = env36601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env36600 == env36601) = true)

theorem identity36601 : scanCanonicalize (H12AffineFastState.compose env36601 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound36601 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env36602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,342,16401,10589,1025,8232,25960,8573,17,374,8193,65,10281,16741,12328,2420,9224,8572,257,340,16464,513]

theorem envBound36602 : H12AffineFastState.Bounded env36602 := by
  intro p hp
  have h : env36602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36601_36602 : H12AffineEnvironment.transform 21 8573 env36601 = env36602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env36601 == env36602) = true)

theorem identity36602 : scanCanonicalize (H12AffineFastState.compose env36602 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36602 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,342,16401,2420,1025,1,17729,340,17,374,40,65,2048,16741,4097,2420,1057,341,257,340,16464,513]

theorem envBound36603 : H12AffineFastState.Bounded env36603 := by
  intro p hp
  have h : env36603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36602_36603 : H12AffineEnvironment.transform 12 41 env36602 = env36603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36602 == env36603) = true)

theorem identity36603 : scanCanonicalize (H12AffineFastState.compose env36603 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36603 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36604 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,0,262,16401,2340,1025,1,17681,260,17,294,40,17,2048,16693,4097,2340,1057,261,257,260,16384,513]

theorem envBound36604 : H12AffineFastState.Bounded env36604 := by
  intro p hp
  have h : env36604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36603_36604 : H12AffineEnvironment.transform 5 16 env36603 = env36604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36603 == env36604) = true)

theorem identity36604 : scanCanonicalize (H12AffineFastState.compose env36604 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36604 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36605 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5377,0,262,5392,2340,1025,1,4112,260,17,294,40,17,2048,5172,4097,2340,1057,261,257,260,5377,513]

theorem envBound36605 : H12AffineFastState.Bounded env36605 := by
  intro p hp
  have h : env36605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36604_36605 : H12AffineEnvironment.transform 13 5377 env36604 = env36605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36604 == env36605) = true)

theorem identity36605 : scanCanonicalize (H12AffineFastState.compose env36605 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36605 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env36606 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4112,33,17,3,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound36606 : H12AffineFastState.Bounded env36606 := by
  intro p hp
  have h : env36606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36605_36606 : H12AffineEnvironment.transform 7 37 env36605 = env36606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36605 == env36606) = true)

def env36607 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,0,35,1029,2049,1025,1,32,33,17,3,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound36607 : H12AffineFastState.Bounded env36607 := by
  intro p hp
  have h : env36607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36606_36607 : H12AffineEnvironment.transform 11 48 env36606 = env36607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36606 == env36607) = true)

theorem identity36607 : scanCanonicalize (H12AffineFastState.compose env36607 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36607 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36608 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,0,2,1029,2049,1025,1,1,0,17,3,9,17,2048,1028,16,2049,1024,1,5,0,1044,513]

theorem envBound36608 : H12AffineFastState.Bounded env36608 := by
  intro p hp
  have h : env36608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36607_36608 : H12AffineEnvironment.transform 4 1 env36607 = env36608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36607 == env36608) = true)

def env36609 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,0,0,2,17,2049,21,1,1,0,17,3,9,17,2048,16,16,2049,20,1,5,0,0,513]

theorem envBound36609 : H12AffineFastState.Bounded env36609 := by
  intro p hp
  have h : env36609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36608_36609 : H12AffineEnvironment.transform 9 20 env36608 = env36609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36608 == env36609) = true)

theorem identity36609 : scanCanonicalize (H12AffineFastState.compose env36609 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36610 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,8,0,0,2,17,1,21,1,1,0,17,3,9,17,0,16,16,1,20,1,5,0,0,513]

theorem envBound36610 : H12AffineFastState.Bounded env36610 := by
  intro p hp
  have h : env36610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36609_36610 : H12AffineEnvironment.transform 10 0 env36609 = env36610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36609 == env36610) = true)

def leafEnv36610 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,8,0,0,2,17,1,21,1,1,0,17,3,21,9,1,17,0,16,16,1,20,1,5,0,5,3,0,513,1,1,0]

def active36610 : List Nat := [0,1,2,3,8]

def tree36610 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36610 : H12WitnessSearch.Good tree36610 := H12GlobalWitnessIndex.good

theorem leafIdentity36610 : H12AffineFastState.composeSystem env36610 rootObs = leafEnv36610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36610 rootObs == leafEnv36610) = true)

theorem terminalChecked36610 : H12PackedTerminal.terminalCheckFast leafEnv36610 active36610 tree36610 = true := by decide +kernel

def env36611 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,0,2,16,2049,20,1,1,0,17,3,9,17,2048,17,16,2049,21,1,5,0,1,513]

theorem envBound36611 : H12AffineFastState.Bounded env36611 := by
  intro p hp
  have h : env36611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36608_36611 : H12AffineEnvironment.transform 9 21 env36608 = env36611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36608 == env36611) = true)

theorem identity36611 : scanCanonicalize (H12AffineFastState.compose env36611 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound36611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36612 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,17,8,1,0,2,16,522,20,1,1,0,17,3,9,17,523,17,16,522,21,1,5,0,1,513]

theorem envBound36612 : H12AffineFastState.Bounded env36612 := by
  intro p hp
  have h : env36612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36611_36612 : H12AffineEnvironment.transform 10 523 env36611 = env36612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env36611 == env36612) = true)

def leafEnv36612 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,17,8,1,0,2,16,522,20,1,1,0,17,3,20,9,1,17,523,17,16,522,21,1,5,0,5,3,1,513,1,1,0]

def active36612 : List Nat := [0,1,2,3,8]

def tree36612 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36612 : H12WitnessSearch.Good tree36612 := H12GlobalWitnessIndex.good

theorem leafIdentity36612 : H12AffineFastState.composeSystem env36612 rootObs = leafEnv36612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36612 rootObs == leafEnv36612) = true)

theorem terminalChecked36612 : H12PackedTerminal.terminalCheckFast leafEnv36612 active36612 tree36612 = true := by decide +kernel

def env36613 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,0,35,1028,2049,1025,1,33,33,17,3,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound36613 : H12AffineFastState.Bounded env36613 := by
  intro p hp
  have h : env36613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36606_36613 : H12AffineEnvironment.transform 11 49 env36606 = env36613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36606 == env36613) = true)

theorem identity36613 : scanCanonicalize (H12AffineFastState.compose env36613 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound36613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36614 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,49,41,1,0,35,16,2049,21,1,33,33,17,3,40,17,2048,17,48,2049,53,32,36,33,1,513]

theorem envBound36614 : H12AffineFastState.Bounded env36614 := by
  intro p hp
  have h : env36614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36613_36614 : H12AffineEnvironment.transform 9 20 env36613 = env36614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36613 == env36614) = true)

def env36615 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,1,0,3,16,2049,21,1,1,1,17,3,8,17,2048,17,16,2049,21,0,4,1,1,513]

theorem envBound36615 : H12AffineFastState.Bounded env36615 := by
  intro p hp
  have h : env36615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36614_36615 : H12AffineEnvironment.transform 4 0 env36614 = env36615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36614 == env36615) = true)

theorem identity36615 : scanCanonicalize (H12AffineFastState.compose env36615 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound36615 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36616 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,17,9,1,0,3,16,522,21,1,1,1,17,3,8,17,523,17,16,522,21,0,4,1,1,513]

theorem envBound36616 : H12AffineFastState.Bounded env36616 := by
  intro p hp
  have h : env36616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36615_36616 : H12AffineEnvironment.transform 10 523 env36615 = env36616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env36615 == env36616) = true)

def leafEnv36616 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,17,9,1,0,3,16,522,21,1,1,1,17,3,20,8,1,17,523,17,16,522,21,0,4,1,5,2,1,513,1,1,0]

def active36616 : List Nat := [0,1,2,3,8]

def tree36616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36616 : H12WitnessSearch.Good tree36616 := H12GlobalWitnessIndex.good

theorem leafIdentity36616 : H12AffineFastState.composeSystem env36616 rootObs = leafEnv36616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36616 rootObs == leafEnv36616) = true)

theorem terminalChecked36616 : H12PackedTerminal.terminalCheckFast leafEnv36616 active36616 tree36616 = true := by decide +kernel

def env36617 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,0,2,16,2049,21,1,0,0,17,3,9,17,2048,17,17,2049,20,1,5,0,1,513]

theorem envBound36617 : H12AffineFastState.Bounded env36617 := by
  intro p hp
  have h : env36617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36614_36617 : H12AffineEnvironment.transform 4 1 env36614 = env36617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36614 == env36617) = true)

theorem identity36617 : scanCanonicalize (H12AffineFastState.compose env36617 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound36617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36618 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,8,1,0,2,16,0,21,1,0,0,17,3,9,17,1,17,17,0,20,1,5,0,1,513]

theorem envBound36618 : H12AffineFastState.Bounded env36618 := by
  intro p hp
  have h : env36618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36617_36618 : H12AffineEnvironment.transform 10 1 env36617 = env36618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env36617 == env36618) = true)

def leafEnv36618 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,8,1,0,2,16,0,21,1,0,0,17,3,21,9,1,17,1,17,17,0,20,1,5,0,5,3,1,513,1,0,0]

def active36618 : List Nat := [0,1,2,3,8]

def tree36618 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36618 : H12WitnessSearch.Good tree36618 := H12GlobalWitnessIndex.good

theorem leafIdentity36618 : H12AffineFastState.composeSystem env36618 rootObs = leafEnv36618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36618 rootObs == leafEnv36618) = true)

theorem terminalChecked36618 : H12PackedTerminal.terminalCheckFast leafEnv36618 active36618 tree36618 = true := by decide +kernel

def env36619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound36619 : H12AffineFastState.Bounded env36619 := by
  intro p hp
  have h : env36619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34951_36619 : H12AffineEnvironment.transform 29 155254785 env34951 = env36619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env34951 == env36619) = true)

def env36620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound36620 : H12AffineFastState.Bounded env36620 := by
  intro p hp
  have h : env36620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36619_36620 : H12AffineEnvironment.transform 25 64 env36619 = env36620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env36619 == env36620) = true)

def env36621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound36621 : H12AffineFastState.Bounded env36621 := by
  intro p hp
  have h : env36621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36620_36621 : H12AffineEnvironment.transform 26 30393344 env36620 = env36621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env36620 == env36621) = true)

def env36622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound36622 : H12AffineFastState.Bounded env36622 := by
  intro p hp
  have h : env36622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36621_36622 : H12AffineEnvironment.transform 18 1024 env36621 = env36622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env36621 == env36622) = true)

theorem identity36622 : scanCanonicalize (H12AffineFastState.compose env36622 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188755) := by decide +kernel

theorem selectedBound36622 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188755,16777216,8328,64,23504339,18973836,77955,2598354,18932162,23160257,256,16818558,16793818,18990612]

theorem envBound36623 : H12AffineFastState.Bounded env36623 := by
  intro p hp
  have h : env36623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36622_36623 : H12AffineEnvironment.transform 22 2188755 env36622 = env36623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188755 env36622 == env36623) = true)

def env36624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,16777216,8328,64,17227835,18973836,77955,2598354,18932162,16850985,256,16818558,16793818,18990612]

theorem envBound36624 : H12AffineFastState.Bounded env36624 := by
  intro p hp
  have h : env36624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36623_36624 : H12AffineEnvironment.transform 21 2115048 env36623 = env36624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env36623 == env36624) = true)

def env36625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175048,8328,64,2609267,46276,77955,2598354,119178,2101345,256,2199862,2191506,63068]

theorem envBound36625 : H12AffineFastState.Bounded env36625 := by
  intro p hp
  have h : env36625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36624_36625 : H12AffineEnvironment.transform 23 2175048 env36624 = env36625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env36624 == env36625) = true)

def env36626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175048,8328,64,2590067,46276,77955,2598354,99466,2101345,256,2199862,2172306,41820]

theorem envBound36626 : H12AffineFastState.Bounded env36626 := by
  intro p hp
  have h : env36626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36625_36626 : H12AffineEnvironment.transform 13 5376 env36625 = env36626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36625 == env36626) = true)

theorem identity36626 : scanCanonicalize (H12AffineFastState.compose env36626 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound36626 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,2097152,2101480,2101328,2101451,8328,64,2532848,46276,4096,2524497,41993,2101345,256,2142645,2098449,41820]

theorem envBound36627 : H12AffineFastState.Bounded env36627 := by
  intro p hp
  have h : env36627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36626_36627 : H12AffineEnvironment.transform 15 8323 env36626 = env36627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env36626 == env36627) = true)

def env36628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2532728,46156,4096,2524497,41993,2101345,256,2142525,2098449,41820]

theorem envBound36628 : H12AffineFastState.Bounded env36628 := by
  intro p hp
  have h : env36628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36627_36628 : H12AffineEnvironment.transform 6 8 env36627 = env36628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36627 == env36628) = true)

theorem identity36628 : scanCanonicalize (H12AffineFastState.compose env36628 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound36628 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5393,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2404457,46156,4096,2396224,41993,2101345,256,2142525,2098449,41820]

theorem envBound36629 : H12AffineFastState.Bounded env36629 := by
  intro p hp
  have h : env36629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36628_36629 : H12AffineEnvironment.transform 16 5393 env36628 = env36629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env36628 == env36629) = true)

theorem identity36629 : scanCanonicalize (H12AffineFastState.compose env36629 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36629 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,262144,1024,8540,2097152,2101344,2101328,2101315,8192,64,2363700,5393,4096,2371869,1364,2101345,256,2101344,2098449,513]

theorem envBound36630 : H12AffineFastState.Bounded env36630 := by
  intro p hp
  have h : env36630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36629_36630 : H12AffineEnvironment.transform 14 8541 env36629 = env36630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36629 == env36630) = true)

theorem identity36630 : scanCanonicalize (H12AffineFastState.compose env36630 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36630 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,262144,1024,8540,5456,1328,1280,1299,8192,64,263268,5393,4096,271437,1364,1329,256,1328,4161,513]

theorem envBound36631 : H12AffineFastState.Bounded env36631 := by
  intro p hp
  have h : env36631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36630_36631 : H12AffineEnvironment.transform 20 5456 env36630 = env36631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env36630 == env36631) = true)

theorem identity36631 : scanCanonicalize (H12AffineFastState.compose env36631 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound36631 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env36632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10280,1024,8540,5456,1328,1280,1299,8192,64,11340,5393,4096,3173,1364,1329,256,1328,4161,513]

theorem envBound36632 : H12AffineFastState.Bounded env36632 := by
  intro p hp
  have h : env36632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36631_36632 : H12AffineEnvironment.transform 17 10280 env36631 = env36632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36631 == env36632) = true)

def env36633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2532729,46157,4096,2524497,41993,2101345,256,2142524,2098449,41820]

theorem envBound36633 : H12AffineFastState.Bounded env36633 := by
  intro p hp
  have h : env36633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36627_36633 : H12AffineEnvironment.transform 6 9 env36627 = env36633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36627 == env36633) = true)

theorem identity36633 : scanCanonicalize (H12AffineFastState.compose env36633 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound36633 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,46157,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2363700,46157,4096,2371868,41993,2101345,256,2142524,2098449,41820]

theorem envBound36634 : H12AffineFastState.Bounded env36634 := by
  intro p hp
  have h : env36634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36633_36634 : H12AffineEnvironment.transform 16 46157 env36633 = env36634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env36633 == env36634) = true)

theorem identity36634 : scanCanonicalize (H12AffineFastState.compose env36634 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36634 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5392,262144,1024,8540,2097152,2101345,2101328,2101314,8193,64,2363700,5392,4096,2371868,1364,2101345,256,2101345,2098449,513]

theorem envBound36635 : H12AffineFastState.Bounded env36635 := by
  intro p hp
  have h : env36635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36634_36635 : H12AffineEnvironment.transform 14 8541 env36634 = env36635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36634 == env36635) = true)

theorem identity36635 : scanCanonicalize (H12AffineFastState.compose env36635 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound36635 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5392,262144,1024,8540,4161,32,17,3,8193,64,262517,5392,4096,270685,1364,32,256,32,5456,513]

theorem envBound36636 : H12AffineFastState.Bounded env36636 := by
  intro p hp
  have h : env36636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36635_36636 : H12AffineEnvironment.transform 20 4161 env36635 = env36636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36635 == env36636) = true)

def env36637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175048,8328,64,2590066,46276,77955,2598354,99467,2101345,256,2199862,2172307,41821]

theorem envBound36637 : H12AffineFastState.Bounded env36637 := by
  intro p hp
  have h : env36637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36625_36637 : H12AffineEnvironment.transform 13 5377 env36625 = env36637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36625 == env36637) = true)

theorem identity36637 : scanCanonicalize (H12AffineFastState.compose env36637 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound36637 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,73771,16,138,8328,64,439728,46276,77955,431376,99467,73891,256,41460,5457,41821]

theorem envBound36638 : H12AffineFastState.Bounded env36638 := by
  intro p hp
  have h : env36638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36637_36638 : H12AffineEnvironment.transform 20 78018 env36637 = env36638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env36637 == env36638) = true)

def env36639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,73771,16,2,8192,64,439608,46156,77835,431376,99331,73771,256,41340,5457,41821]

theorem envBound36639 : H12AffineFastState.Bounded env36639 := by
  intro p hp
  have h : env36639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36638_36639 : H12AffineEnvironment.transform 6 8 env36638 = env36639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36638 == env36639) = true)

theorem identity36639 : scanCanonicalize (H12AffineFastState.compose env36639 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36639 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,73771,16,2,8192,64,398436,5392,77835,406604,75103,73771,256,32,5457,513]

theorem envBound36640 : H12AffineFastState.Bounded env36640 := by
  intro p hp
  have h : env36640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36639_36640 : H12AffineEnvironment.transform 14 8540 env36639 = env36640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36639 == env36640) = true)

theorem identity36640 : scanCanonicalize (H12AffineFastState.compose env36640 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound36640 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,4096,262144,1024,8541,77898,73771,16,2,8192,64,263268,5392,77835,271436,75103,73771,256,32,5457,513]

theorem envBound36641 : H12AffineFastState.Bounded env36641 := by
  intro p hp
  have h : env36641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36640_36641 : H12AffineEnvironment.transform 16 4096 env36640 = env36641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env36640 == env36641) = true)

theorem identity36641 : scanCanonicalize (H12AffineFastState.compose env36641 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound36641 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env36642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9499,4096,262144,1024,8541,5457,1328,16,2,8192,64,263268,5392,5392,271436,68,1328,256,32,5457,513]

theorem envBound36642 : H12AffineFastState.Bounded env36642 := by
  intro p hp
  have h : env36642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36641_36642 : H12AffineEnvironment.transform 15 9499 env36641 = env36642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env36641 == env36642) = true)

theorem identity36642 : scanCanonicalize (H12AffineFastState.compose env36642 (packedSelected [2,6,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36642 : packedSelected [2,6,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env36643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,373,1330,4096,262144,1024,372,5457,1328,16,2,41,64,263268,5392,5392,263269,68,1328,256,32,5457,513]

theorem envBound36643 : H12AffineFastState.Bounded env36643 := by
  intro p hp
  have h : env36643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36642_36643 : H12AffineEnvironment.transform 12 41 env36642 = env36643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36642 == env36643) = true)

theorem identity36643 : scanCanonicalize (H12AffineFastState.compose env36643 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound36643 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env36644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,373,1330,4096,3124,1024,372,5457,1328,16,2,41,64,2128,5392,5392,2129,68,1328,256,32,5457,513]

theorem envBound36644 : H12AffineFastState.Bounded env36644 := by
  intro p hp
  have h : env36644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36643_36644 : H12AffineEnvironment.transform 17 3124 env36643 = env36644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env36643 == env36644) = true)

theorem identity36644 : scanCanonicalize (H12AffineFastState.compose env36644 (packedSelected [0,1,4,5,7,8,9,12,14,15,24] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36644 : packedSelected [0,1,4,5,7,8,9,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env36645 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4453,373,342,4096,2128,100,372,4405,340,16,2,41,64,2128,4468,4468,2129,68,340,256,32,4405,513]

theorem envBound36645 : H12AffineFastState.Bounded env36645 := by
  intro p hp
  have h : env36645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36644_36645 : H12AffineEnvironment.transform 9 100 env36644 = env36645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36644 == env36645) = true)

theorem identity36645 : scanCanonicalize (H12AffineFastState.compose env36645 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36645 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36646 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,41,4161,81,114,4096,2128,100,80,4113,112,16,2,41,64,2128,4176,4176,2129,68,112,36,32,4113,513]

theorem envBound36646 : H12AffineFastState.Bounded env36646 := by
  intro p hp
  have h : env36646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36645_36646 : H12AffineEnvironment.transform 7 36 env36645 = env36646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36645 == env36646) = true)

theorem identity36646 : scanCanonicalize (H12AffineFastState.compose env36646 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound36646 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env36647 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2112,41,2049,81,114,2112,2128,100,80,2129,112,16,2,41,64,2128,2064,2064,2129,68,112,36,32,2129,513]

theorem envBound36647 : H12AffineFastState.Bounded env36647 := by
  intro p hp
  have h : env36647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36646_36647 : H12AffineEnvironment.transform 11 2112 env36646 = env36647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env36646 == env36647) = true)

theorem identity36647 : scanCanonicalize (H12AffineFastState.compose env36647 (packedSelected [0,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound36647 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env36648 : List Nat := [2,4,8,16,32,64,8,36,512,100,48,112,41,49,81,114,112,96,100,80,97,112,16,2,41,64,96,32,32,97,68,112,36,32,97,513]

theorem envBound36648 : H12AffineFastState.Bounded env36648 := by
  intro p hp
  have h : env36648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36647_36648 : H12AffineEnvironment.transform 10 48 env36647 = env36648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env36647 == env36648) = true)

theorem identity36648 : scanCanonicalize (H12AffineFastState.compose env36648 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36648 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36649 : List Nat := [2,4,8,16,32,48,8,36,512,20,48,0,41,49,33,2,0,16,20,32,17,0,16,2,41,48,16,32,32,17,52,0,36,32,17,513]

theorem envBound36649 : H12AffineFastState.Bounded env36649 := by
  intro p hp
  have h : env36649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36648_36649 : H12AffineEnvironment.transform 5 48 env36648 = env36649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36648 == env36649) = true)

theorem identity36649 : scanCanonicalize (H12AffineFastState.compose env36649 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36649 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36650 : List Nat := [2,4,8,16,1,17,8,5,512,20,17,0,8,16,0,2,0,16,20,1,17,0,16,2,8,17,16,1,1,17,21,0,5,1,17,513]

theorem envBound36650 : H12AffineFastState.Bounded env36650 := by
  intro p hp
  have h : env36650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36649_36650 : H12AffineEnvironment.transform 4 1 env36649 = env36650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36649 == env36650) = true)

def env36651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,73771,16,3,8193,64,439609,46157,77834,431376,99330,73770,256,41341,5457,41821]

theorem envBound36651 : H12AffineFastState.Bounded env36651 := by
  intro p hp
  have h : env36651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36638_36651 : H12AffineEnvironment.transform 6 9 env36638 = env36651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36638 == env36651) = true)

theorem identity36651 : scanCanonicalize (H12AffineFastState.compose env36651 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36651 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env36652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,73771,16,3,8193,64,398437,5393,77834,406604,75102,73770,256,33,5457,513]

theorem envBound36652 : H12AffineFastState.Bounded env36652 := by
  intro p hp
  have h : env36652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36651_36652 : H12AffineEnvironment.transform 14 8540 env36651 = env36652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36651 == env36652) = true)

theorem identity36652 : scanCanonicalize (H12AffineFastState.compose env36652 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36652 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env36653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77899,73771,16,3,8193,64,146508,5393,77834,138341,75102,73770,256,33,5457,513]

theorem envBound36653 : H12AffineFastState.Bounded env36653 := by
  intro p hp
  have h : env36653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36652_36653 : H12AffineEnvironment.transform 17 10281 env36652 = env36653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36652 == env36653) = true)

theorem identity36653 : scanCanonicalize (H12AffineFastState.compose env36653 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound36653 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env36654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,263,131072,10281,1024,8541,12620,8492,16,3,8193,64,146508,5393,12557,138341,9305,8493,256,33,5457,513]

theorem envBound36654 : H12AffineFastState.Bounded env36654 := by
  intro p hp
  have h : env36654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36653_36654 : H12AffineEnvironment.transform 15 263 env36653 = env36654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env36653 == env36654) = true)

theorem identity36654 : scanCanonicalize (H12AffineFastState.compose env36654 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36654 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,263,13340,10281,1024,8541,12620,8492,16,3,8193,64,2128,5393,12557,10361,9305,8493,256,33,5457,513]

theorem envBound36655 : H12AffineFastState.Bounded env36655 := by
  intro p hp
  have h : env36655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36654_36655 : H12AffineEnvironment.transform 16 13340 env36654 = env36655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env36654 == env36655) = true)

theorem identity36655 : scanCanonicalize (H12AffineFastState.compose env36655 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36655 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,263,5441,2420,1024,0,4113,113,16,3,348,64,2128,5393,4176,2340,1284,112,256,33,5457,513]

theorem envBound36656 : H12AffineFastState.Bounded env36656 := by
  intro p hp
  have h : env36656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36655_36656 : H12AffineEnvironment.transform 12 349 env36655 = env36656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36655 == env36656) = true)

theorem identity36656 : scanCanonicalize (H12AffineFastState.compose env36656 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36656 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36657 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4113,33,16,3,268,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound36657 : H12AffineFastState.Bounded env36657 := by
  intro p hp
  have h : env36657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36656_36657 : H12AffineEnvironment.transform 5 16 env36656 = env36657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36656 == env36657) = true)

theorem identity36657 : scanCanonicalize (H12AffineFastState.compose env36657 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36658 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4113,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound36658 : H12AffineFastState.Bounded env36658 := by
  intro p hp
  have h : env36658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36657_36658 : H12AffineEnvironment.transform 7 37 env36657 = env36658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36657 == env36658) = true)

def env36659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175049,8328,64,2609266,46277,77955,2598354,119179,2101344,256,2199863,2191507,63069]

theorem envBound36659 : H12AffineFastState.Bounded env36659 := by
  intro p hp
  have h : env36659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36624_36659 : H12AffineEnvironment.transform 23 2175049 env36624 = env36659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env36624 == env36659) = true)

def env36660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175049,8328,64,2590066,46277,77955,2598354,99467,2101344,256,2199863,2172307,41821]

theorem envBound36660 : H12AffineFastState.Bounded env36660 := by
  intro p hp
  have h : env36660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36659_36660 : H12AffineEnvironment.transform 13 5376 env36659 = env36660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36659 == env36660) = true)

theorem identity36660 : scanCanonicalize (H12AffineFastState.compose env36660 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102815) := by decide +kernel

theorem selectedBound36660 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102815,98679,41292,41430,8328,64,398573,46277,77955,406605,99467,98815,256,168,46092,41821]

theorem envBound36661 : H12AffineFastState.Bounded env36661 := by
  intro p hp
  have h : env36661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36660_36661 : H12AffineEnvironment.transform 20 102815 env36660 = env36661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102815 env36660 == env36661) = true)

def env36662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102815,98679,41292,41430,8328,64,146629,46277,77955,138341,99467,98815,256,168,46092,41821]

theorem envBound36662 : H12AffineFastState.Bounded env36662 := by
  intro p hp
  have h : env36662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36661_36662 : H12AffineEnvironment.transform 17 10280 env36661 = env36662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36661 == env36662) = true)

theorem identity36662 : scanCanonicalize (H12AffineFastState.compose env36662 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36662 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,78019,73771,16,138,8328,64,146629,5529,77955,138341,75223,73891,256,168,5456,513]

theorem envBound36663 : H12AffineFastState.Bounded env36663 := by
  intro p hp
  have h : env36663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36662_36663 : H12AffineEnvironment.transform 14 8540 env36662 = env36663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36662 == env36663) = true)

theorem identity36663 : scanCanonicalize (H12AffineFastState.compose env36663 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36663 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79130,10280,1024,8541,78019,73771,16,138,8328,64,68063,5529,77955,76159,75223,73891,256,168,5456,513]

theorem envBound36664 : H12AffineFastState.Bounded env36664 := by
  intro p hp
  have h : env36664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36663_36664 : H12AffineEnvironment.transform 16 79130 env36663 = env36664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36663 == env36664) = true)

theorem identity36664 : scanCanonicalize (H12AffineFastState.compose env36664 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound36664 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,9498,4096,10280,1024,8541,5593,1329,16,138,8328,64,11461,5529,5529,3173,205,1465,256,168,5456,513]

theorem envBound36665 : H12AffineFastState.Bounded env36665 := by
  intro p hp
  have h : env36665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36664_36665 : H12AffineEnvironment.transform 15 9498 env36664 = env36665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env36664 == env36665) = true)

theorem identity36665 : scanCanonicalize (H12AffineFastState.compose env36665 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound36665 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5376,508,1466,4096,2184,1024,509,5593,1329,16,138,40,64,3173,5529,5529,3173,205,1465,256,168,5456,513]

theorem envBound36666 : H12AffineFastState.Bounded env36666 := by
  intro p hp
  have h : env36666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36665_36666 : H12AffineEnvironment.transform 12 160 env36665 = env36666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env36665 == env36666) = true)

theorem identity36666 : scanCanonicalize (H12AffineFastState.compose env36666 (packedSelected [2,6,11,12,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36666 : packedSelected [2,6,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env36667 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,160,4452,508,478,4096,2184,100,509,4541,341,16,138,40,64,2049,4605,4605,2049,205,477,256,168,4404,513]

theorem envBound36667 : H12AffineFastState.Bounded env36667 := by
  intro p hp
  have h : env36667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36666_36667 : H12AffineEnvironment.transform 9 100 env36666 = env36667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36666 == env36667) = true)

theorem identity36667 : scanCanonicalize (H12AffineFastState.compose env36667 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36667 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env36668 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,160,4112,136,170,4096,2184,100,137,4297,33,16,138,40,64,2049,4233,4233,2049,205,169,116,168,4160,513]

theorem envBound36668 : H12AffineFastState.Bounded env36668 := by
  intro p hp
  have h : env36668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36667_36668 : H12AffineEnvironment.transform 7 116 env36667 = env36668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36667 == env36668) = true)

theorem identity36668 : scanCanonicalize (H12AffineFastState.compose env36668 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36668 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36669 : List Nat := [2,4,8,16,32,64,89,116,512,100,2048,4096,121,4112,81,115,4096,2129,100,80,4112,33,16,83,40,64,2049,4176,4176,2049,20,112,116,113,4160,513]

theorem envBound36669 : H12AffineFastState.Bounded env36669 := by
  intro p hp
  have h : env36669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36668_36669 : H12AffineEnvironment.transform 6 89 env36668 = env36669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36668 == env36669) = true)

theorem identity36669 : scanCanonicalize (H12AffineFastState.compose env36669 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound36669 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env36670 : List Nat := [2,4,8,16,32,64,89,116,33,100,2048,4096,121,4112,81,115,4096,2129,100,80,4112,33,16,83,40,64,2049,4176,4176,2049,20,112,116,113,4160,32]

theorem envBound36670 : H12AffineFastState.Bounded env36670 := by
  intro p hp
  have h : env36670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36669_36670 : H12AffineEnvironment.transform 8 33 env36669 = env36670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env36669 == env36670) = true)

theorem identity36670 : scanCanonicalize (H12AffineFastState.compose env36670 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36670 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env36671 : List Nat := [2,4,8,16,1,64,89,85,0,69,2048,4096,88,4112,81,82,4096,2129,69,80,4112,0,16,83,9,64,2049,4176,4176,2049,20,81,85,80,4160,1]

theorem envBound36671 : H12AffineFastState.Bounded env36671 := by
  intro p hp
  have h : env36671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36670_36671 : H12AffineEnvironment.transform 4 1 env36670 = env36671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36670 == env36671) = true)

theorem identity36671 : scanCanonicalize (H12AffineFastState.compose env36671 (packedSelected [0,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound36671 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env36672 : List Nat := [2,4,8,16,1,64,89,85,0,69,2048,2064,88,2048,81,82,2064,2129,69,80,2048,0,16,83,9,64,2049,2112,2112,2049,20,81,85,80,2128,1]

theorem envBound36672 : H12AffineFastState.Bounded env36672 := by
  intro p hp
  have h : env36672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36671_36672 : H12AffineEnvironment.transform 11 2064 env36671 = env36672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env36671 == env36672) = true)

def env36673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102815,98679,41292,41430,8328,64,146628,46277,77955,138340,99467,98815,256,168,46092,41821]

theorem envBound36673 : H12AffineFastState.Bounded env36673 := by
  intro p hp
  have h : env36673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36661_36673 : H12AffineEnvironment.transform 17 10281 env36661 = env36673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36661 == env36673) = true)

theorem identity36673 : scanCanonicalize (H12AffineFastState.compose env36673 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36673 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env36674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1024,8660,77898,73890,153,3,8328,64,146628,5392,77955,138340,75102,73770,256,168,5593,648]

theorem envBound36674 : H12AffineFastState.Bounded env36674 := by
  intro p hp
  have h : env36674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36673_36674 : H12AffineEnvironment.transform 14 8661 env36673 = env36674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36673 == env36674) = true)

theorem identity36674 : scanCanonicalize (H12AffineFastState.compose env36674 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound36674 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env36675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,131072,10281,1024,8660,4297,33,153,3,8328,64,146628,5392,4096,138340,1501,169,256,168,5593,648]

theorem envBound36675 : H12AffineFastState.Bounded env36675 := by
  intro p hp
  have h : env36675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36674_36675 : H12AffineEnvironment.transform 15 8323 env36674 = env36675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env36674 == env36675) = true)

theorem identity36675 : scanCanonicalize (H12AffineFastState.compose env36675 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound36675 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env36676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,13341,10281,1024,8660,4297,33,153,3,8328,64,2265,5392,4096,10361,1501,169,256,168,5593,648]

theorem envBound36676 : H12AffineFastState.Bounded env36676 := by
  intro p hp
  have h : env36676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36675_36676 : H12AffineEnvironment.transform 16 13341 env36675 = env36676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env36675 == env36676) = true)

theorem identity36676 : scanCanonicalize (H12AffineFastState.compose env36676 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36676 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,216,398,5392,2340,1024,217,4297,33,153,3,389,64,2265,5392,4096,2420,1501,169,256,168,5593,648]

theorem envBound36677 : H12AffineFastState.Bounded env36677 := by
  intro p hp
  have h : env36677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36676_36677 : H12AffineEnvironment.transform 12 269 env36676 = env36677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36676 == env36677) = true)

theorem identity36677 : scanCanonicalize (H12AffineFastState.compose env36677 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound36677 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36678 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,241,5372,216,114,5356,2264,1024,217,4297,33,153,3,121,64,2265,5356,4096,2184,1057,169,252,168,5157,648]

theorem envBound36678 : H12AffineFastState.Bounded env36678 := by
  intro p hp
  have h : env36678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36677_36678 : H12AffineEnvironment.transform 7 252 env36677 = env36678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env36677 == env36678) = true)

theorem identity36678 : scanCanonicalize (H12AffineFastState.compose env36678 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36678 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36679 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,114,5221,2129,1024,80,4160,33,16,3,121,64,2128,5221,4096,2049,1057,32,117,33,5157,513]

theorem envBound36679 : H12AffineFastState.Bounded env36679 := by
  intro p hp
  have h : env36679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36678_36679 : H12AffineEnvironment.transform 6 9 env36678 = env36679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36678 == env36679) = true)

theorem identity36679 : scanCanonicalize (H12AffineFastState.compose env36679 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36679 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36680 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5173,2049,1024,0,4112,33,16,3,41,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound36680 : H12AffineFastState.Bounded env36680 := by
  intro p hp
  have h : env36680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36679_36680 : H12AffineEnvironment.transform 5 16 env36679 = env36680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36679 == env36680) = true)

def env36681 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,1,34,1029,2049,1024,0,32,33,16,3,41,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound36681 : H12AffineFastState.Bounded env36681 := by
  intro p hp
  have h : env36681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36680_36681 : H12AffineEnvironment.transform 11 48 env36680 = env36681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36680 == env36681) = true)

def env36682 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,40,33,1,34,49,2049,52,0,32,33,16,3,41,16,2048,49,48,2049,21,32,37,33,33,513]

theorem envBound36682 : H12AffineFastState.Bounded env36682 := by
  intro p hp
  have h : env36682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36681_36682 : H12AffineEnvironment.transform 9 52 env36681 = env36682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36681 == env36682) = true)

theorem identity36682 : scanCanonicalize (H12AffineFastState.compose env36682 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound36682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36683 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,48,40,33,1,34,49,2049,52,0,32,33,16,3,41,16,2048,49,48,2049,21,32,37,33,33,11]

theorem envBound36683 : H12AffineFastState.Bounded env36683 := by
  intro p hp
  have h : env36683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36682_36683 : H12AffineEnvironment.transform 8 10 env36682 = env36683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env36682 == env36683) = true)

def leafEnv36683 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,48,40,33,1,34,49,2049,52,0,32,33,16,3,21,41,1,16,2048,49,48,2049,21,32,37,33,4,35,33,11,1,32,0]

def active36683 : List Nat := [0,1,2,3,4,10]

def tree36683 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36683 : H12WitnessSearch.Good tree36683 := H12GlobalWitnessIndex.good

theorem leafIdentity36683 : H12AffineFastState.composeSystem env36683 rootObs = leafEnv36683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36683 rootObs == leafEnv36683) = true)

theorem terminalChecked36683 : H12PackedTerminal.terminalCheckFast leafEnv36683 active36683 tree36683 = true := by decide +kernel

def env36684 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,40,32,1,34,48,2049,53,0,32,33,16,3,41,16,2048,48,48,2049,20,32,37,33,32,513]

theorem envBound36684 : H12AffineFastState.Bounded env36684 := by
  intro p hp
  have h : env36684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36681_36684 : H12AffineEnvironment.transform 9 53 env36681 = env36684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36681 == env36684) = true)

theorem identity36684 : scanCanonicalize (H12AffineFastState.compose env36684 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36684 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36685 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,8,0,1,2,16,2049,21,0,0,1,16,3,9,16,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound36685 : H12AffineFastState.Bounded env36685 := by
  intro p hp
  have h : env36685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36684_36685 : H12AffineEnvironment.transform 4 0 env36684 = env36685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36684 == env36685) = true)

def leafEnv36685 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,8,0,1,2,16,2049,21,0,0,1,16,3,20,9,1,16,2048,16,16,2049,20,0,5,1,4,3,0,513,1,0,0]

def active36685 : List Nat := [0,1,2,3,8,10]

def tree36685 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36685 : H12WitnessSearch.Good tree36685 := H12GlobalWitnessIndex.good

theorem leafIdentity36685 : H12AffineFastState.composeSystem env36685 rootObs = leafEnv36685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36685 rootObs == leafEnv36685) = true)

theorem terminalChecked36685 : H12PackedTerminal.terminalCheckFast leafEnv36685 active36685 tree36685 = true := by decide +kernel

def env36686 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,1,34,1028,2049,1024,0,33,33,16,3,41,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound36686 : H12AffineFastState.Bounded env36686 := by
  intro p hp
  have h : env36686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36680_36686 : H12AffineEnvironment.transform 11 49 env36680 = env36686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36680 == env36686) = true)

theorem identity36686 : scanCanonicalize (H12AffineFastState.compose env36686 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36687 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,40,32,1,34,48,2049,52,0,33,33,16,3,41,16,2048,48,49,2049,21,32,37,33,32,513]

theorem envBound36687 : H12AffineFastState.Bounded env36687 := by
  intro p hp
  have h : env36687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36686_36687 : H12AffineEnvironment.transform 9 52 env36686 = env36687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36686 == env36687) = true)

theorem identity36687 : scanCanonicalize (H12AffineFastState.compose env36687 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36688 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,49,40,32,1,34,48,2049,52,0,33,33,16,3,41,16,2048,48,49,2049,21,32,37,33,32,10]

theorem envBound36688 : H12AffineFastState.Bounded env36688 := by
  intro p hp
  have h : env36688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36687_36688 : H12AffineEnvironment.transform 8 11 env36687 = env36688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36687 == env36688) = true)

def leafEnv36688 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,49,40,32,1,34,48,2049,52,0,33,33,16,3,21,41,1,16,2048,48,49,2049,21,32,37,33,4,35,32,10,1,33,0]

def active36688 : List Nat := [0,1,2,3,4,10]

def tree36688 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36688 : H12WitnessSearch.Good tree36688 := H12GlobalWitnessIndex.good

theorem leafIdentity36688 : H12AffineFastState.composeSystem env36688 rootObs = leafEnv36688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36688 rootObs == leafEnv36688) = true)

theorem terminalChecked36688 : H12PackedTerminal.terminalCheckFast leafEnv36688 active36688 tree36688 = true := by decide +kernel

def env36689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175049,8328,64,2590067,46277,77955,2598354,99466,2101344,256,2199863,2172306,41820]

theorem envBound36689 : H12AffineFastState.Bounded env36689 := by
  intro p hp
  have h : env36689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36659_36689 : H12AffineEnvironment.transform 13 5377 env36659 = env36689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36659 == env36689) = true)

theorem identity36689 : scanCanonicalize (H12AffineFastState.compose env36689 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound36689 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,2097152,2101481,2142476,2142615,8328,64,2491565,46277,45405,2499596,1364,2101344,256,2101481,2139212,41820]

theorem envBound36690 : H12AffineFastState.Bounded env36690 := by
  intro p hp
  have h : env36690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36689_36690 : H12AffineEnvironment.transform 15 33246 env36689 = env36690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env36689 == env36690) = true)

theorem identity36690 : scanCanonicalize (H12AffineFastState.compose env36690 (packedSelected [1,12,15,19,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound36690 : packedSelected [1,12,15,19,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env36691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5528,262144,1024,32769,2097152,2101481,2142476,2142615,8328,64,2363701,46277,45405,2371988,1364,2101344,256,2101481,2139212,41820]

theorem envBound36691 : H12AffineFastState.Bounded env36691 := by
  intro p hp
  have h : env36691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36690_36691 : H12AffineEnvironment.transform 16 5528 env36690 = env36691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env36690 == env36691) = true)

def env36692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5528,262144,1024,32769,276704,272393,297452,297335,8328,64,10709,46277,45405,2420,1364,272512,256,272393,302252,41820]

theorem envBound36692 : H12AffineFastState.Bounded env36692 := by
  intro p hp
  have h : env36692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36691_36692 : H12AffineEnvironment.transform 20 276704 env36691 = env36692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276704 env36691 == env36692) = true)

theorem identity36692 : scanCanonicalize (H12AffineFastState.compose env36692 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound36692 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env36693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5528,262144,1024,8661,276704,272393,272440,272547,8328,64,10709,5393,4233,2420,1364,272512,256,272393,277880,648]

theorem envBound36693 : H12AffineFastState.Bounded env36693 := by
  intro p hp
  have h : env36693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36692_36693 : H12AffineEnvironment.transform 14 8660 env36692 = env36693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env36692 == env36693) = true)

theorem identity36693 : scanCanonicalize (H12AffineFastState.compose env36693 (packedSelected [0,2,7,11,14,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 10741) := by decide +kernel

theorem selectedBound36693 : packedSelected [0,2,7,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env36694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5528,10741,1024,8661,4373,508,461,342,8328,64,10709,5393,4233,2420,1364,373,256,508,5261,648]

theorem envBound36694 : H12AffineFastState.Bounded env36694 := by
  intro p hp
  have h : env36694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36693_36694 : H12AffineEnvironment.transform 17 10741 env36693 = env36694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10741 env36693 == env36694) = true)

theorem identity36694 : scanCanonicalize (H12AffineFastState.compose env36694 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound36694 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36695 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5341,8200,8202,5188,10281,1024,8201,4297,32,17,138,8328,64,10249,5325,4233,2216,1160,169,220,32,5261,648]

theorem envBound36695 : H12AffineFastState.Bounded env36695 := by
  intro p hp
  have h : env36695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36694_36695 : H12AffineEnvironment.transform 7 220 env36694 = env36695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env36694 == env36695) = true)

theorem identity36695 : scanCanonicalize (H12AffineFastState.compose env36695 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 209) := by decide +kernel

theorem selectedBound36695 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36696 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,209,5341,217,219,5188,2296,1024,216,4297,32,17,138,89,64,2264,5325,4233,2216,1160,169,220,32,5261,648]

theorem envBound36696 : H12AffineFastState.Bounded env36696 := by
  intro p hp
  have h : env36696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36695_36696 : H12AffineEnvironment.transform 12 209 env36695 = env36696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env36695 == env36696) = true)

theorem identity36696 : scanCanonicalize (H12AffineFastState.compose env36696 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36696 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env36697 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,4096,128,5260,136,138,5141,2217,1024,137,4248,32,17,138,8,17,2185,5276,4233,2216,1160,169,141,32,5261,648]

theorem envBound36697 : H12AffineFastState.Bounded env36697 := by
  intro p hp
  have h : env36697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36696_36697 : H12AffineEnvironment.transform 5 17 env36696 = env36697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36696 == env36697) = true)

theorem identity36697 : scanCanonicalize (H12AffineFastState.compose env36697 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound36697 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env36698 : List Nat := [2,4,8,16,32,17,128,141,137,1024,2048,4096,128,5260,136,138,5141,2217,1024,137,4248,32,17,138,8,17,2185,5276,4233,2216,1160,169,141,32,5261,1]

theorem envBound36698 : H12AffineFastState.Bounded env36698 := by
  intro p hp
  have h : env36698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36697_36698 : H12AffineEnvironment.transform 8 137 env36697 = env36698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env36697 == env36698) = true)

theorem identity36698 : scanCanonicalize (H12AffineFastState.compose env36698 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound36698 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env36699 : List Nat := [2,4,8,16,32,17,128,141,137,173,2048,4096,128,4129,136,138,4280,2217,173,137,4248,32,17,138,8,17,2185,4145,4233,2216,37,169,141,32,4128,1]

theorem envBound36699 : H12AffineFastState.Bounded env36699 := by
  intro p hp
  have h : env36699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36698_36699 : H12AffineEnvironment.transform 9 173 env36698 = env36699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env36698 == env36699) = true)

theorem identity36699 : scanCanonicalize (H12AffineFastState.compose env36699 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound36699 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env36700 : List Nat := [2,4,8,16,32,17,128,141,137,173,2048,2233,128,2200,136,138,2049,2217,173,137,2081,32,17,138,8,17,2185,2184,2096,2216,37,169,141,32,2201,1]

theorem envBound36700 : H12AffineFastState.Bounded env36700 := by
  intro p hp
  have h : env36700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36699_36700 : H12AffineEnvironment.transform 11 2233 env36699 = env36700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env36699 == env36700) = true)

theorem identity36700 : scanCanonicalize (H12AffineFastState.compose env36700 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound36700 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env36701 : List Nat := [2,4,8,16,32,17,128,141,137,173,168,17,128,48,136,138,169,1,173,137,137,32,17,138,8,17,33,32,152,0,37,169,141,32,49,1]

theorem envBound36701 : H12AffineFastState.Bounded env36701 := by
  intro p hp
  have h : env36701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36700_36701 : H12AffineEnvironment.transform 10 168 env36700 = env36701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env36700 == env36701) = true)

theorem identity36701 : scanCanonicalize (H12AffineFastState.compose env36701 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound36701 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36702 : List Nat := [2,4,8,16,32,17,56,53,49,21,16,17,56,48,48,50,17,1,21,49,49,32,17,50,8,17,33,32,32,0,37,17,53,32,49,1]

theorem envBound36702 : H12AffineFastState.Bounded env36702 := by
  intro p hp
  have h : env36702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36701_36702 : H12AffineEnvironment.transform 6 56 env36701 = env36702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env36701 == env36702) = true)

theorem identity36702 : scanCanonicalize (H12AffineFastState.compose env36702 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36703 : List Nat := [2,4,8,16,16,17,8,5,1,21,16,17,8,0,0,2,17,1,21,1,1,16,17,2,8,17,17,16,16,0,21,17,5,16,1,1]

theorem envBound36703 : H12AffineFastState.Bounded env36703 := by
  intro p hp
  have h : env36703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36702_36703 : H12AffineEnvironment.transform 4 16 env36702 = env36703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36702 == env36703) = true)

theorem identity36703 : scanCanonicalize (H12AffineFastState.compose env36703 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound36703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36704 : List Nat := [2,4,6,16,16,17,6,5,1,21,16,17,6,0,0,2,17,1,21,1,1,16,17,2,6,17,17,16,16,0,21,17,5,16,1,1]

theorem envBound36704 : H12AffineFastState.Bounded env36704 := by
  intro p hp
  have h : env36704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36703_36704 : H12AffineEnvironment.transform 2 6 env36703 = env36704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env36703 == env36704) = true)

theorem identity36704 : scanCanonicalize (H12AffineFastState.compose env36704 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36704 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36705 : List Nat := [2,4,6,1,1,0,6,5,1,4,1,0,6,0,0,2,0,1,4,1,1,1,0,2,6,0,0,1,1,0,4,0,5,1,1,1]

theorem envBound36705 : H12AffineFastState.Bounded env36705 := by
  intro p hp
  have h : env36705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36704_36705 : H12AffineEnvironment.transform 3 1 env36704 = env36705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36704 == env36705) = true)

def env36706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5528,262144,1024,32769,276705,272392,297453,297334,8328,64,10708,46277,45405,2421,1364,272513,256,272392,302253,41820]

theorem envBound36706 : H12AffineFastState.Bounded env36706 := by
  intro p hp
  have h : env36706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36691_36706 : H12AffineEnvironment.transform 20 276705 env36691 = env36706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276705 env36691 == env36706) = true)

theorem identity36706 : scanCanonicalize (H12AffineFastState.compose env36706 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36706 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env36707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5528,10281,1024,32769,4296,33,41412,41311,8328,64,10708,46277,45405,2421,1364,168,256,33,46212,41820]

theorem envBound36707 : H12AffineFastState.Bounded env36707 := by
  intro p hp
  have h : env36707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36706_36707 : H12AffineEnvironment.transform 17 10281 env36706 = env36707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36706 == env36707) = true)

theorem identity36707 : scanCanonicalize (H12AffineFastState.compose env36707 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound36707 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5528,10281,1024,8661,4296,33,16,139,8328,64,10708,5393,4233,2421,1364,168,256,33,5456,648]

theorem envBound36708 : H12AffineFastState.Bounded env36708 := by
  intro p hp
  have h : env36708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36707_36708 : H12AffineEnvironment.transform 14 8660 env36707 = env36708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env36707 == env36708) = true)

theorem identity36708 : scanCanonicalize (H12AffineFastState.compose env36708 (packedSelected [1,3,5,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36708 : packedSelected [1,3,5,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env36709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5377,508,34,5528,2049,1024,509,4296,33,16,139,160,64,2556,5393,4233,2421,1364,168,256,33,5456,648]

theorem envBound36709 : H12AffineFastState.Bounded env36709 := by
  intro p hp
  have h : env36709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36708_36709 : H12AffineEnvironment.transform 12 40 env36708 = env36709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36708 == env36709) = true)

theorem identity36709 : scanCanonicalize (H12AffineFastState.compose env36709 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound36709 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36710 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,40,5292,81,34,5173,2049,1024,80,4296,33,16,139,160,64,2129,5308,4233,2264,1273,168,173,33,5373,648]

theorem envBound36710 : H12AffineFastState.Bounded env36710 := by
  intro p hp
  have h : env36710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36709_36710 : H12AffineEnvironment.transform 7 173 env36709 = env36710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36709 == env36710) = true)

theorem identity36710 : scanCanonicalize (H12AffineFastState.compose env36710 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound36710 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env36711 : List Nat := [2,4,8,16,32,64,128,173,512,237,2048,4096,40,4161,81,34,4312,2049,237,80,4296,33,16,139,160,64,2129,4177,4233,2264,20,168,173,33,4112,648]

theorem envBound36711 : H12AffineFastState.Bounded env36711 := by
  intro p hp
  have h : env36711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36710_36711 : H12AffineEnvironment.transform 9 237 env36710 = env36711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env36710 == env36711) = true)

def env36712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,16777216,8328,64,17227834,18973836,77955,2598354,18932162,16850984,256,16818558,16793818,18990612]

theorem envBound36712 : H12AffineFastState.Bounded env36712 := by
  intro p hp
  have h : env36712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36623_36712 : H12AffineEnvironment.transform 21 2115049 env36623 = env36712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env36623 == env36712) = true)

def env36713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175048,8328,64,2609266,46276,77955,2598354,119178,2101344,256,2199862,2191506,63068]

theorem envBound36713 : H12AffineFastState.Bounded env36713 := by
  intro p hp
  have h : env36713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36712_36713 : H12AffineEnvironment.transform 23 2175048 env36712 = env36713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env36712 == env36713) = true)

def env36714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175048,8328,64,2590066,46276,77955,2598354,99466,2101344,256,2199862,2172306,41820]

theorem envBound36714 : H12AffineFastState.Bounded env36714 := by
  intro p hp
  have h : env36714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36713_36714 : H12AffineEnvironment.transform 13 5376 env36713 = env36714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36713 == env36714) = true)

theorem identity36714 : scanCanonicalize (H12AffineFastState.compose env36714 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound36714 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,169,73875,73736,8328,64,496946,46276,77955,505234,99466,32,256,98678,79314,41820]

theorem envBound36715 : H12AffineFastState.Bounded env36715 := by
  intro p hp
  have h : env36715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36714_36715 : H12AffineEnvironment.transform 20 4160 env36714 = env36715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36714 == env36715) = true)

def env36716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,73755,73736,8192,64,496946,46156,77835,505114,99330,32,256,98678,79194,41820]

theorem envBound36716 : H12AffineFastState.Bounded env36716 := by
  intro p hp
  have h : env36716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36715_36716 : H12AffineEnvironment.transform 6 8 env36715 = env36716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36715 == env36716) = true)

theorem identity36716 : scanCanonicalize (H12AffineFastState.compose env36716 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36716 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,4160,33,73755,73736,8192,64,303144,46156,77835,294912,99330,32,256,98678,79194,41820]

theorem envBound36717 : H12AffineFastState.Bounded env36717 := by
  intro p hp
  have h : env36717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36716_36717 : H12AffineEnvironment.transform 16 79130 env36716 = env36717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36716 == env36717) = true)

theorem identity36717 : scanCanonicalize (H12AffineFastState.compose env36717 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound36717 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env36718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,262144,1024,32769,4160,33,41292,41311,8192,64,303144,46156,45404,294912,1365,32,256,33,46093,41820]

theorem envBound36718 : H12AffineFastState.Bounded env36718 := by
  intro p hp
  have h : env36718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36717_36718 : H12AffineEnvironment.transform 15 33111 env36717 = env36718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env36717 == env36718) = true)

theorem identity36718 : scanCanonicalize (H12AffineFastState.compose env36718 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36718 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env36719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,10281,1024,32769,4160,33,41292,41311,8192,64,34817,46156,45404,43049,1365,32,256,33,46093,41820]

theorem envBound36719 : H12AffineFastState.Bounded env36719 := by
  intro p hp
  have h : env36719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36718_36719 : H12AffineEnvironment.transform 17 10281 env36718 = env36719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36718 == env36719) = true)

theorem identity36719 : scanCanonicalize (H12AffineFastState.compose env36719 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound36719 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8313,8494,5172,10281,1024,8312,4160,33,309,294,8192,64,10360,5173,4389,2128,1365,32,256,33,5236,805]

theorem envBound36720 : H12AffineFastState.Bounded env36720 := by
  intro p hp
  have h : env36720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36719_36720 : H12AffineEnvironment.transform 14 8313 env36719 = env36720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env36719 == env36720) = true)

theorem identity36720 : scanCanonicalize (H12AffineFastState.compose env36720 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound36720 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env36721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5376,112,295,5172,2080,1024,113,4160,33,309,294,9,64,2161,5173,4389,2128,1365,32,256,33,5236,805]

theorem envBound36721 : H12AffineFastState.Bounded env36721 := by
  intro p hp
  have h : env36721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36720_36721 : H12AffineEnvironment.transform 12 9 env36720 = env36721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env36720 == env36721) = true)

theorem identity36721 : scanCanonicalize (H12AffineFastState.compose env36721 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36721 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36722 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,9,5157,112,2,5172,2080,1024,113,4160,33,16,3,9,64,2161,5173,4096,2128,1136,32,37,33,5236,512]

theorem envBound36722 : H12AffineFastState.Bounded env36722 := by
  intro p hp
  have h : env36722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36721_36722 : H12AffineEnvironment.transform 7 37 env36721 = env36722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36721 == env36722) = true)

theorem identity36722 : scanCanonicalize (H12AffineFastState.compose env36722 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36722 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36723 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5157,33,2,5172,2080,1024,32,4113,33,16,3,9,17,2080,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound36723 : H12AffineFastState.Bounded env36723 := by
  intro p hp
  have h : env36723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36722_36723 : H12AffineEnvironment.transform 5 17 env36722 = env36723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36722 == env36723) = true)

theorem identity36723 : scanCanonicalize (H12AffineFastState.compose env36723 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound36723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36724 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,1061,9,0,33,2,17,2080,1024,32,1076,33,16,3,9,17,2080,16,1061,2049,1057,32,37,33,0,512]

theorem envBound36724 : H12AffineFastState.Bounded env36724 := by
  intro p hp
  have h : env36724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36723_36724 : H12AffineEnvironment.transform 11 1061 env36723 = env36724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env36723 == env36724) = true)

theorem identity36724 : scanCanonicalize (H12AffineFastState.compose env36724 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 574) := by decide +kernel

theorem selectedBound36724 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env36725 : List Nat := [2,4,8,16,32,17,8,37,512,1024,574,1061,9,0,33,2,17,542,1024,32,1076,33,16,3,9,17,542,16,1061,575,1057,32,37,33,0,512]

theorem envBound36725 : H12AffineFastState.Bounded env36725 := by
  intro p hp
  have h : env36725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36724_36725 : H12AffineEnvironment.transform 10 574 env36724 = env36725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 574 env36724 == env36725) = true)

theorem identity36725 : scanCanonicalize (H12AffineFastState.compose env36725 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound36725 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env36726 : List Nat := [2,4,8,16,32,17,8,37,512,20,574,49,9,0,33,2,17,542,20,32,32,33,16,3,9,17,542,16,49,575,53,32,37,33,0,512]

theorem envBound36726 : H12AffineFastState.Bounded env36726 := by
  intro p hp
  have h : env36726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36725_36726 : H12AffineEnvironment.transform 9 20 env36725 = env36726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36725 == env36726) = true)

theorem identity36726 : scanCanonicalize (H12AffineFastState.compose env36726 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound36726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36727 : List Nat := [2,4,8,5,32,4,8,37,512,1,555,36,9,0,33,2,4,523,1,32,32,33,5,3,9,4,523,5,36,554,32,32,37,33,0,512]

theorem envBound36727 : H12AffineFastState.Bounded env36727 := by
  intro p hp
  have h : env36727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36726_36727 : H12AffineEnvironment.transform 3 5 env36726 = env36727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env36726 == env36727) = true)

theorem identity36727 : scanCanonicalize (H12AffineFastState.compose env36727 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound36727 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env36728 : List Nat := [2,4,8,5,32,4,8,37,8,1,35,36,9,0,33,2,4,3,1,32,32,33,5,3,9,4,3,5,36,34,32,32,37,33,0,8]

theorem envBound36728 : H12AffineFastState.Bounded env36728 := by
  intro p hp
  have h : env36728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36727_36728 : H12AffineEnvironment.transform 8 8 env36727 = env36728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env36727 == env36728) = true)

theorem identity36728 : scanCanonicalize (H12AffineFastState.compose env36728 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36728 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36729 : List Nat := [0,4,8,5,32,4,8,37,8,1,33,36,9,0,33,0,4,1,1,32,32,33,5,1,9,4,1,5,36,32,32,32,37,33,0,8]

theorem envBound36729 : H12AffineFastState.Bounded env36729 := by
  intro p hp
  have h : env36729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36728_36729 : H12AffineEnvironment.transform 0 0 env36728 = env36729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36728 == env36729) = true)

theorem identity36729 : scanCanonicalize (H12AffineFastState.compose env36729 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36730 : List Nat := [0,4,8,5,0,4,8,5,8,1,1,4,9,0,1,0,4,1,1,0,0,1,5,1,9,4,1,5,4,0,0,0,5,1,0,8]

theorem envBound36730 : H12AffineFastState.Bounded env36730 := by
  intro p hp
  have h : env36730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36729_36730 : H12AffineEnvironment.transform 4 0 env36729 = env36730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36729 == env36730) = true)

def env36731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73754,73736,8193,64,496946,46157,77834,505115,99331,32,256,98678,79195,41820]

theorem envBound36731 : H12AffineFastState.Bounded env36731 := by
  intro p hp
  have h : env36731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36715_36731 : H12AffineEnvironment.transform 6 9 env36715 = env36731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36715 == env36731) = true)

theorem identity36731 : scanCanonicalize (H12AffineFastState.compose env36731 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound36731 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,262144,1024,32769,4160,32,73754,73736,8193,64,262517,46157,77834,270684,99331,32,256,98678,79195,41820]

theorem envBound36732 : H12AffineFastState.Bounded env36732 := by
  intro p hp
  have h : env36732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36731_36732 : H12AffineEnvironment.transform 16 103495 env36731 = env36732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env36731 == env36732) = true)

theorem identity36732 : scanCanonicalize (H12AffineFastState.compose env36732 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound36732 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env36733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,35188,1024,32769,4160,32,73754,73736,8193,64,34817,46157,77834,43048,99331,32,256,98678,79195,41820]

theorem envBound36733 : H12AffineFastState.Bounded env36733 := by
  intro p hp
  have h : env36733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36732_36733 : H12AffineEnvironment.transform 17 35188 env36732 = env36733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env36732 == env36733) = true)

theorem identity36733 : scanCanonicalize (H12AffineFastState.compose env36733 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound36733 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33031,5440,35188,1024,32769,4160,32,41245,41231,8193,64,34817,46157,45325,43048,1284,32,256,113,46172,41820]

theorem envBound36734 : H12AffineFastState.Bounded env36734 := by
  intro p hp
  have h : env36734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36733_36734 : H12AffineEnvironment.transform 15 33031 env36733 = env36734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env36733 == env36734) = true)

theorem identity36734 : scanCanonicalize (H12AffineFastState.compose env36734 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36734 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env36735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,33031,5440,35188,1024,32769,4160,32,32784,32770,268,64,34817,38208,36864,35109,1284,32,256,113,38225,33361]

theorem envBound36735 : H12AffineFastState.Bounded env36735 := by
  intro p hp
  have h : env36735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36734_36735 : H12AffineEnvironment.transform 12 269 env36734 = env36735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36734 == env36735) = true)

theorem identity36735 : scanCanonicalize (H12AffineFastState.compose env36735 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36735 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env36736 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,33031,5392,35108,1024,32769,4112,32,32784,32770,268,16,34817,38160,36864,35109,1284,32,256,33,38145,33281]

theorem envBound36736 : H12AffineFastState.Bounded env36736 := by
  intro p hp
  have h : env36736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36735_36736 : H12AffineEnvironment.transform 5 16 env36735 = env36736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36735 == env36736) = true)

theorem identity36736 : scanCanonicalize (H12AffineFastState.compose env36736 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 6965) := by decide +kernel

theorem selectedBound36736 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36737 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,6965,6706,5392,4625,1024,6964,4112,32,6949,6967,268,16,4916,3621,2869,4624,1284,32,256,33,3636,6452]

theorem envBound36737 : H12AffineFastState.Bounded env36737 := by
  intro p hp
  have h : env36737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36736_36737 : H12AffineEnvironment.transform 14 6965 env36736 = env36737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6965 env36736 == env36737) = true)

theorem identity36737 : scanCanonicalize (H12AffineFastState.compose env36737 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound36737 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env36738 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1556,269,788,3361,3110,772,1029,1024,3360,1540,32,3377,3363,268,16,1312,3621,2869,1028,1284,32,256,33,3636,3872]

theorem envBound36738 : H12AffineFastState.Bounded env36738 := by
  intro p hp
  have h : env36738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36737_36738 : H12AffineEnvironment.transform 11 1556 env36737 = env36738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env36737 == env36738) = true)

theorem identity36738 : scanCanonicalize (H12AffineFastState.compose env36738 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36738 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env36739 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,544,269,788,2325,2066,772,49,52,2324,560,32,2309,2327,268,16,276,2577,2869,48,304,32,256,33,2560,2836]

theorem envBound36739 : H12AffineFastState.Bounded env36739 := by
  intro p hp
  have h : env36739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36738_36739 : H12AffineEnvironment.transform 9 52 env36738 = env36739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36738 == env36739) = true)

theorem identity36739 : scanCanonicalize (H12AffineFastState.compose env36739 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36739 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36740 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,544,41,560,2097,2066,544,49,52,2096,560,32,2081,2099,40,16,48,2577,2577,48,20,32,36,33,2560,2608]

theorem envBound36740 : H12AffineFastState.Bounded env36740 := by
  intro p hp
  have h : env36740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36739_36740 : H12AffineEnvironment.transform 7 36 env36739 = env36740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36739 == env36740) = true)

theorem identity36740 : scanCanonicalize (H12AffineFastState.compose env36740 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36740 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36741 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,513,8,529,2064,2066,513,16,21,2065,529,1,2048,2066,9,16,17,2577,2577,17,20,1,5,0,2560,2577]

theorem envBound36741 : H12AffineFastState.Bounded env36741 := by
  intro p hp
  have h : env36741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36740_36741 : H12AffineEnvironment.transform 4 1 env36740 = env36741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36740 == env36741) = true)

theorem identity36741 : scanCanonicalize (H12AffineFastState.compose env36741 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36741 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36742 : List Nat := [2,4,8,16,1,16,9,5,16,21,2048,17,8,1,2064,2066,17,16,21,2065,1,1,2048,2066,9,16,17,2049,2049,17,20,1,5,0,2064,2049]

theorem envBound36742 : H12AffineFastState.Bounded env36742 := by
  intro p hp
  have h : env36742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36741_36742 : H12AffineEnvironment.transform 8 16 env36741 = env36742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36741 == env36742) = true)

theorem identity36742 : scanCanonicalize (H12AffineFastState.compose env36742 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound36742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36743 : List Nat := [2,4,8,16,1,16,9,5,16,21,16,17,8,1,0,2,17,16,21,1,1,1,16,2,9,16,17,17,17,17,20,1,5,0,0,17]

theorem envBound36743 : H12AffineFastState.Bounded env36743 := by
  intro p hp
  have h : env36743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36742_36743 : H12AffineEnvironment.transform 10 16 env36742 = env36743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env36742 == env36743) = true)

theorem identity36743 : scanCanonicalize (H12AffineFastState.compose env36743 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36743 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36744 : List Nat := [2,4,8,0,1,0,9,5,0,5,0,1,8,1,0,2,1,0,5,1,1,1,0,2,9,0,1,1,1,1,4,1,5,0,0,1]

theorem envBound36744 : H12AffineFastState.Bounded env36744 := by
  intro p hp
  have h : env36744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36743_36744 : H12AffineEnvironment.transform 3 0 env36743 = env36744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36743 == env36744) = true)

def env36745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175048,8328,64,2590067,46276,77955,2598354,99467,2101344,256,2199862,2172307,41821]

theorem envBound36745 : H12AffineFastState.Bounded env36745 := by
  intro p hp
  have h : env36745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36713_36745 : H12AffineEnvironment.transform 13 5377 env36713 = env36745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36713 == env36745) = true)

def env36746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101344,2175066,2175048,8192,64,2590067,46156,77835,2598234,99331,2101344,256,2199862,2172187,41821]

theorem envBound36746 : H12AffineFastState.Bounded env36746 := by
  intro p hp
  have h : env36746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36745_36746 : H12AffineEnvironment.transform 6 8 env36745 = env36746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36745 == env36746) = true)

theorem identity36746 : scanCanonicalize (H12AffineFastState.compose env36746 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36746 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,2097152,2101344,2175066,2175048,8192,64,2565167,5392,77835,2556934,75103,2101344,256,2175082,2172187,513]

theorem envBound36747 : H12AffineFastState.Bounded env36747 := by
  intro p hp
  have h : env36747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36746_36747 : H12AffineEnvironment.transform 14 8540 env36746 = env36747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36746 == env36747) = true)

theorem identity36747 : scanCanonicalize (H12AffineFastState.compose env36747 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound36747 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,262144,1024,8541,2097152,2101344,2175066,2175048,8192,64,2363700,5392,77835,2371869,75103,2101344,256,2175082,2172187,513]

theorem envBound36748 : H12AffineFastState.Bounded env36748 := by
  intro p hp
  have h : env36748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36747_36748 : H12AffineEnvironment.transform 16 79131 env36747 = env36748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env36747 == env36748) = true)

theorem identity36748 : scanCanonicalize (H12AffineFastState.compose env36748 (packedSelected [7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36748 : packedSelected [7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env36749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,65536,70679,262144,1024,81,2097152,2101344,2167126,2167108,268,64,2363700,5392,69895,2363409,66643,2101344,256,2167142,2163735,513]

theorem envBound36749 : H12AffineFastState.Bounded env36749 := by
  intro p hp
  have h : env36749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36748_36749 : H12AffineEnvironment.transform 12 268 env36748 = env36749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36748 == env36749) = true)

theorem identity36749 : scanCanonicalize (H12AffineFastState.compose env36749 (packedSelected [0,1,2,5,6,7,8,20,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound36749 : packedSelected [0,1,2,5,6,7,8,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,65536,70679,3172,1024,81,2097152,2101344,2167126,2167108,268,64,2104656,5392,69895,2104437,66643,2101344,256,2167142,2163735,513]

theorem envBound36750 : H12AffineFastState.Bounded env36750 := by
  intro p hp
  have h : env36750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36749_36750 : H12AffineEnvironment.transform 17 3172 env36749 = env36750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env36749 == env36750) = true)

theorem identity36750 : scanCanonicalize (H12AffineFastState.compose env36750 (packedSelected [3,4,5,9,10,14,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound36750 : packedSelected [3,4,5,9,10,14,20,21] rootPS < 2^1333 := by decide +kernel

def env36751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,1046,4097,3172,1024,81,2097152,2101344,2102592,2102610,268,64,2104656,5392,5393,2104437,69,2101344,256,2102640,2097153,513]

theorem envBound36751 : H12AffineFastState.Bounded env36751 := by
  intro p hp
  have h : env36751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36750_36751 : H12AffineEnvironment.transform 15 1046 env36750 = env36751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env36750 == env36751) = true)

theorem identity36751 : scanCanonicalize (H12AffineFastState.compose env36751 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36751 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36752 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4160,80,343,4097,2341,321,81,2097152,2101344,2101249,2101267,268,64,2103313,4177,4176,2103604,69,2101344,256,2101297,2097153,513]

theorem envBound36752 : H12AffineFastState.Bounded env36752 := by
  intro p hp
  have h : env36752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36751_36752 : H12AffineEnvironment.transform 9 321 env36751 = env36752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36751 == env36752) = true)

theorem identity36752 : scanCanonicalize (H12AffineFastState.compose env36752 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 1) := by decide +kernel

theorem selectedBound36752 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36753 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4160,80,343,4097,2341,321,81,1,4193,4096,4114,268,64,6160,4177,4176,6453,69,4193,256,4144,0,513]

theorem envBound36753 : H12AffineFastState.Bounded env36753 := by
  intro p hp
  have h : env36753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36752_36753 : H12AffineEnvironment.transform 20 1 env36752 = env36753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1 env36752 == env36753) = true)

theorem identity36753 : scanCanonicalize (H12AffineFastState.compose env36753 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound36753 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36754 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2357,268,2421,80,343,2356,2341,321,81,1,2388,2357,2343,268,64,293,2404,2405,0,69,2388,256,2309,0,513]

theorem envBound36754 : H12AffineFastState.Bounded env36754 := by
  intro p hp
  have h : env36754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36753_36754 : H12AffineEnvironment.transform 11 2357 env36753 = env36754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env36753 == env36754) = true)

theorem identity36754 : scanCanonicalize (H12AffineFastState.compose env36754 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36754 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env36755 : List Nat := [2,4,8,16,32,64,8,256,512,321,80,357,268,293,80,343,356,373,321,81,1,260,357,375,268,64,293,308,309,0,69,260,256,341,0,513]

theorem envBound36755 : H12AffineFastState.Bounded env36755 := by
  intro p hp
  have h : env36755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36754_36755 : H12AffineEnvironment.transform 10 80 env36754 = env36755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36754 == env36755) = true)

theorem identity36755 : scanCanonicalize (H12AffineFastState.compose env36755 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound36755 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36756 : List Nat := [2,4,8,16,32,64,8,256,308,321,80,357,268,293,80,343,356,373,321,81,1,260,357,375,268,64,293,308,309,0,69,260,256,341,0,309]

theorem envBound36756 : H12AffineFastState.Bounded env36756 := by
  intro p hp
  have h : env36756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36755_36756 : H12AffineEnvironment.transform 8 308 env36755 = env36756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env36755 == env36756) = true)

theorem identity36756 : scanCanonicalize (H12AffineFastState.compose env36756 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36756 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env36757 : List Nat := [2,4,8,16,32,64,8,37,17,100,80,64,41,0,80,114,65,80,100,81,1,33,64,82,41,64,0,17,16,0,69,33,37,112,0,16]

theorem envBound36757 : H12AffineFastState.Bounded env36757 := by
  intro p hp
  have h : env36757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36756_36757 : H12AffineEnvironment.transform 7 37 env36756 = env36757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36756 == env36757) = true)

theorem identity36757 : scanCanonicalize (H12AffineFastState.compose env36757 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36757 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36758 : List Nat := [2,4,8,1,32,64,8,37,0,100,65,64,41,0,65,99,65,65,100,64,1,33,64,67,41,64,0,0,1,0,69,33,37,97,0,1]

theorem envBound36758 : H12AffineFastState.Bounded env36758 := by
  intro p hp
  have h : env36758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36757_36758 : H12AffineEnvironment.transform 3 1 env36757 = env36758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36757 == env36758) = true)

theorem identity36758 : scanCanonicalize (H12AffineFastState.compose env36758 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36758 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36759 : List Nat := [2,4,8,1,32,1,8,37,0,37,0,1,41,0,0,34,0,0,37,1,1,33,1,2,41,1,0,0,1,0,4,33,37,32,0,1]

theorem envBound36759 : H12AffineFastState.Bounded env36759 := by
  intro p hp
  have h : env36759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36758_36759 : H12AffineEnvironment.transform 5 1 env36758 = env36759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36758 == env36759) = true)

theorem identity36759 : scanCanonicalize (H12AffineFastState.compose env36759 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36760 : List Nat := [2,4,8,1,11,1,8,14,0,14,0,1,2,0,0,9,0,0,14,1,1,10,1,2,2,1,0,0,1,0,4,10,14,11,0,1]

theorem envBound36760 : H12AffineFastState.Bounded env36760 := by
  intro p hp
  have h : env36760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36759_36760 : H12AffineEnvironment.transform 4 11 env36759 = env36760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36759 == env36760) = true)

def env36761 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101345,2175067,2175048,8193,64,2590067,46157,77834,2598235,99330,2101344,256,2199862,2172186,41821]

theorem envBound36761 : H12AffineFastState.Bounded env36761 := by
  intro p hp
  have h : env36761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36745_36761 : H12AffineEnvironment.transform 6 9 env36745 = env36761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36745 == env36761) = true)

def env36762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,2097152,2101345,2175067,2175048,8193,64,2338139,46157,77834,2329971,99330,2101344,256,2199862,2172186,41821]

theorem envBound36762 : H12AffineFastState.Bounded env36762 := by
  intro p hp
  have h : env36762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36761_36762 : H12AffineEnvironment.transform 17 10280 env36761 = env36762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36761 == env36762) = true)

theorem identity36762 : scanCanonicalize (H12AffineFastState.compose env36762 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound36762 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,77899,73770,16,3,8193,64,171280,46157,77834,179512,99330,73771,256,41341,5457,41821]

theorem envBound36763 : H12AffineFastState.Bounded env36763 := by
  intro p hp
  have h : env36763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36762_36763 : H12AffineEnvironment.transform 20 77899 env36762 = env36763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env36762 == env36763) = true)

theorem identity36763 : scanCanonicalize (H12AffineFastState.compose env36763 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound36763 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103495,10280,1024,32769,77899,73770,16,3,8193,64,67927,46157,77834,76159,99330,73771,256,41341,5457,41821]

theorem envBound36764 : H12AffineFastState.Bounded env36764 := by
  intro p hp
  have h : env36764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36763_36764 : H12AffineEnvironment.transform 16 103495 env36763 = env36764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env36763 == env36764) = true)

theorem identity36764 : scanCanonicalize (H12AffineFastState.compose env36764 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 33863) := by decide +kernel

theorem selectedBound36764 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env36765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33863,4096,10280,1024,32769,46092,42093,16,3,8193,64,36112,46157,46157,44344,69,42092,256,41341,5457,41821]

theorem envBound36765 : H12AffineFastState.Bounded env36765 := by
  intro p hp
  have h : env36765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36764_36765 : H12AffineEnvironment.transform 15 33863 env36764 = env36765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33863 env36764 == env36765) = true)

theorem identity36765 : scanCanonicalize (H12AffineFastState.compose env36765 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 9528) := by decide +kernel

theorem selectedBound36765 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env36766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9528,8575,4096,10280,1024,9529,4404,341,16,3,8193,64,10280,4469,4469,2048,69,340,256,1093,5457,1637]

theorem envBound36766 : H12AffineFastState.Bounded env36766 := by
  intro p hp
  have h : env36766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36765_36766 : H12AffineEnvironment.transform 14 9528 env36765 = env36766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9528 env36765 == env36766) = true)

theorem identity36766 : scanCanonicalize (H12AffineFastState.compose env36766 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36766 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env36767 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8232,8575,4096,10280,272,8233,4404,341,16,3,8193,64,10280,4469,4469,2048,69,340,256,341,4161,885]

theorem envBound36767 : H12AffineFastState.Bounded env36767 := by
  intro p hp
  have h : env36767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36766_36767 : H12AffineEnvironment.transform 9 272 env36766 = env36767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36766 == env36767) = true)

theorem identity36767 : scanCanonicalize (H12AffineFastState.compose env36767 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound36767 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env36768 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2404,8192,2421,8232,8575,2404,10280,272,8233,2128,341,16,3,8193,64,10280,2065,2065,2048,69,340,256,341,2341,885]

theorem envBound36768 : H12AffineFastState.Bounded env36768 := by
  intro p hp
  have h : env36768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36767_36768 : H12AffineEnvironment.transform 11 2404 env36767 = env36768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env36767 == env36768) = true)

theorem identity36768 : scanCanonicalize (H12AffineFastState.compose env36768 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36768 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36769 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2065,8192,2048,8232,8202,2065,10280,101,8233,2128,32,16,3,8193,64,10280,2065,2065,2048,69,33,117,32,2128,512]

theorem envBound36769 : H12AffineFastState.Bounded env36769 := by
  intro p hp
  have h : env36769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36768_36769 : H12AffineEnvironment.transform 7 117 env36768 = env36769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36768 == env36769) = true)

theorem identity36769 : scanCanonicalize (H12AffineFastState.compose env36769 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound36769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36770 : List Nat := [2,4,8,16,32,49,9,4,512,20,2048,2065,8192,2048,8232,8202,2065,10280,20,8233,2081,32,16,3,8193,49,10280,2065,2065,2048,52,33,4,32,2081,512]

theorem envBound36770 : H12AffineFastState.Bounded env36770 := by
  intro p hp
  have h : env36770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36769_36770 : H12AffineEnvironment.transform 5 49 env36769 = env36770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env36769 == env36770) = true)

theorem identity36770 : scanCanonicalize (H12AffineFastState.compose env36770 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound36770 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env36771 : List Nat := [2,4,8,16,21,4,9,4,512,20,2048,2065,8192,2048,8221,8202,2065,10269,20,8220,2068,21,16,3,8193,4,10269,2065,2065,2048,1,20,4,21,2068,512]

theorem envBound36771 : H12AffineFastState.Bounded env36771 := by
  intro p hp
  have h : env36771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36770_36771 : H12AffineEnvironment.transform 4 21 env36770 = env36771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env36770 == env36771) = true)

theorem identity36771 : scanCanonicalize (H12AffineFastState.compose env36771 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound36771 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36772 : List Nat := [2,4,8,16,21,4,9,4,512,20,2048,2065,8,2048,21,2,2065,2069,20,20,2068,21,16,3,9,4,2069,2065,2065,2048,1,20,4,21,2068,512]

theorem envBound36772 : H12AffineFastState.Bounded env36772 := by
  intro p hp
  have h : env36772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36771_36772 : H12AffineEnvironment.transform 12 8 env36771 = env36772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env36771 == env36772) = true)

theorem identity36772 : scanCanonicalize (H12AffineFastState.compose env36772 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound36772 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36773 : List Nat := [2,4,8,5,0,4,9,4,512,1,2048,2052,8,2048,0,2,2052,2048,1,1,2049,0,5,3,9,4,2048,2052,2052,2048,1,1,4,0,2049,512]

theorem envBound36773 : H12AffineFastState.Bounded env36773 := by
  intro p hp
  have h : env36773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36772_36773 : H12AffineEnvironment.transform 3 5 env36772 = env36773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env36772 == env36773) = true)

theorem identity36773 : scanCanonicalize (H12AffineFastState.compose env36773 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36774 : List Nat := [2,4,8,5,0,4,9,4,1,1,2048,2052,8,2048,0,2,2052,2048,1,1,2049,0,5,3,9,4,2048,2052,2052,2048,1,1,4,0,2049,1]

theorem envBound36774 : H12AffineFastState.Bounded env36774 := by
  intro p hp
  have h : env36774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36773_36774 : H12AffineEnvironment.transform 8 1 env36773 = env36774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36773 == env36774) = true)

def leafEnv36774 : List Nat := [2,4,8,5,0,4,9,4,1,1,2048,2052,8,2048,0,2,2052,2048,1,1,2049,0,5,3,1,9,1,4,2048,2052,2052,2048,1,1,4,0,4,3,2049,1,1,2048,0]

def active36774 : List Nat := [0,1,2,10]

def tree36774 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36774 : H12WitnessSearch.Good tree36774 := H12GlobalWitnessIndex.good

theorem leafIdentity36774 : H12AffineFastState.composeSystem env36774 rootObs = leafEnv36774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36774 rootObs == leafEnv36774) = true)

theorem terminalChecked36774 : H12PackedTerminal.terminalCheckFast leafEnv36774 active36774 tree36774 = true := by decide +kernel

def env36775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,2097152,2101345,2175067,2175048,8193,64,2338138,46157,77834,2329970,99330,2101344,256,2199862,2172186,41821]

theorem envBound36775 : H12AffineFastState.Bounded env36775 := by
  intro p hp
  have h : env36775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36761_36775 : H12AffineEnvironment.transform 17 10281 env36761 = env36775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36761 == env36775) = true)

theorem identity36775 : scanCanonicalize (H12AffineFastState.compose env36775 (packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36775 : packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env36776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,2097152,2101345,2175067,2175048,8193,64,2296838,5393,77834,2305070,75102,2101344,256,2175082,2172186,513]

theorem envBound36776 : H12AffineFastState.Bounded env36776 := by
  intro p hp
  have h : env36776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36775_36776 : H12AffineEnvironment.transform 14 8540 env36775 = env36776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36775 == env36776) = true)

theorem identity36776 : scanCanonicalize (H12AffineFastState.compose env36776 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound36776 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env36777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77851,73850,64,83,8193,64,146461,5393,77834,138293,75102,73851,256,113,5377,513]

theorem envBound36777 : H12AffineFastState.Bounded env36777 := by
  intro p hp
  have h : env36777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36776_36777 : H12AffineEnvironment.transform 20 77851 env36776 = env36777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env36776 == env36777) = true)

theorem identity36777 : scanCanonicalize (H12AffineFastState.compose env36777 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36777 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10281,1024,8541,4113,112,64,83,8193,64,146461,5393,4096,138293,1364,113,256,113,5377,513]

theorem envBound36778 : H12AffineFastState.Bounded env36778 := by
  intro p hp
  have h : env36778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0