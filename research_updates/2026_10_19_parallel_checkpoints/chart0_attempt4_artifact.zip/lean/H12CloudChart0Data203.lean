import H12CloudChart0Data202

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity51401 : scanCanonicalize (H12AffineFastState.compose env51401 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51401 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51402 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,40,2048,0,34,2065,2049,52,1,2049,32,16,2,41,17,2049,2065,2065,2049,20,32,37,33,2048,513]

theorem envBound51402 : H12AffineFastState.Bounded env51402 := by
  intro p hp
  have h : env51402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51401_51402 : H12AffineEnvironment.transform 7 37 env51401 = env51402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51401 == env51402) = true)

theorem identity51402 : scanCanonicalize (H12AffineFastState.compose env51402 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound51402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51403 : List Nat := [2,4,8,16,32,16,9,37,32,52,2048,2065,40,2048,0,34,2065,2049,52,1,2049,32,16,2,41,17,2049,2065,2065,2049,20,32,37,33,2048,33]

theorem envBound51403 : H12AffineFastState.Bounded env51403 := by
  intro p hp
  have h : env51403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51402_51403 : H12AffineEnvironment.transform 8 32 env51402 = env51403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env51402 == env51403) = true)

def env51404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441761,95496,8328,65,270377,436384,45524,32160,412857,156013,256,21793,46212,486254]

theorem envBound51404 : H12AffineFastState.Bounded env51404 := by
  intro p hp
  have h : env51404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51382_51404 : H12AffineEnvironment.transform 21 272513 env51382 = env51404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51382 == env51404) = true)

theorem identity51404 : scanCanonicalize (H12AffineFastState.compose env51404 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound51404 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213486,120014,95496,8328,65,215366,115151,45524,32160,75222,156013,256,21793,46212,513]

theorem envBound51405 : H12AffineFastState.Bounded env51405 := by
  intro p hp
  have h : env51405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51404_51405 : H12AffineEnvironment.transform 17 223599 env51404 = env51405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env51404 == env51405) = true)

def env51406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213350,119878,95496,8192,65,215366,115015,45404,32040,75102,156013,256,21793,46092,513]

theorem envBound51406 : H12AffineFastState.Bounded env51406 := by
  intro p hp
  have h : env51406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51405_51406 : H12AffineEnvironment.transform 6 8 env51405 = env51406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51405 == env51406) = true)

theorem identity51406 : scanCanonicalize (H12AffineFastState.compose env51406 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound51406 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env51407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,77898,33,119878,95496,8192,65,2049,115015,45404,32040,75102,73770,256,21793,46092,513]

theorem envBound51407 : H12AffineFastState.Bounded env51407 := by
  intro p hp
  have h : env51407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51406_51407 : H12AffineEnvironment.transform 16 82247 env51406 = env51407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env51406 == env51407) = true)

theorem identity51407 : scanCanonicalize (H12AffineFastState.compose env51407 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51407 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env51408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,82247,10280,1024,0,77898,33,87111,95496,8192,65,2049,82246,12637,32040,75102,73770,256,21793,13325,513]

theorem envBound51408 : H12AffineFastState.Bounded env51408 := by
  intro p hp
  have h : env51408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51407_51408 : H12AffineEnvironment.transform 14 1 env51407 = env51408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51407 == env51408) = true)

theorem identity51408 : scanCanonicalize (H12AffineFastState.compose env51408 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51408 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,65536,82247,2421,1024,0,69911,33,87111,87125,349,65,2049,82246,4096,23669,66563,65911,256,21793,5456,513]

theorem envBound51409 : H12AffineFastState.Bounded env51409 := by
  intro p hp
  have h : env51409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51408_51409 : H12AffineEnvironment.transform 12 349 env51408 = env51409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51408 == env51409) = true)

theorem identity51409 : scanCanonicalize (H12AffineFastState.compose env51409 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound51409 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21510,5441,2421,1024,0,17681,33,65,83,349,65,2049,5440,4096,23669,20485,21873,256,21793,5456,513]

theorem envBound51410 : H12AffineFastState.Bounded env51410 := by
  intro p hp
  have h : env51410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51409_51410 : H12AffineEnvironment.transform 15 21510 env51409 = env51410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env51409 == env51410) = true)

theorem identity51410 : scanCanonicalize (H12AffineFastState.compose env51410 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51410 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,263,5441,2421,1024,0,4112,33,65,83,349,65,2049,5440,4096,2420,1284,112,256,32,5456,513]

theorem envBound51411 : H12AffineFastState.Bounded env51411 := by
  intro p hp
  have h : env51411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51410_51411 : H12AffineEnvironment.transform 13 5377 env51410 = env51411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51410 == env51411) = true)

theorem identity51411 : scanCanonicalize (H12AffineFastState.compose env51411 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51411 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51412 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5392,2340,1024,0,4112,33,16,2,268,16,2049,5393,4096,2341,1284,33,256,32,5377,513]

theorem envBound51412 : H12AffineFastState.Bounded env51412 := by
  intro p hp
  have h : env51412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51411_51412 : H12AffineEnvironment.transform 5 17 env51411 = env51412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51411 == env51412) = true)

theorem identity51412 : scanCanonicalize (H12AffineFastState.compose env51412 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51413 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,268,4405,1,263,4388,2340,52,0,4112,33,16,2,268,16,2049,4389,4096,2341,304,33,256,32,4405,513]

theorem envBound51413 : H12AffineFastState.Bounded env51413 := by
  intro p hp
  have h : env51413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51412_51413 : H12AffineEnvironment.transform 9 52 env51412 = env51413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51412 == env51413) = true)

theorem identity51413 : scanCanonicalize (H12AffineFastState.compose env51413 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound51413 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51414 : List Nat := [2,4,8,16,32,17,8,256,512,52,522,4096,268,4405,1,263,4388,814,52,0,4112,33,16,2,268,16,523,4389,4096,815,304,33,256,32,4405,513]

theorem envBound51414 : H12AffineFastState.Bounded env51414 := by
  intro p hp
  have h : env51414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51413_51414 : H12AffineEnvironment.transform 10 522 env51413 = env51414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env51413 == env51414) = true)

theorem identity51414 : scanCanonicalize (H12AffineFastState.compose env51414 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound51414 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51415 : List Nat := [2,4,8,16,32,17,8,256,512,52,522,799,268,554,1,263,571,814,52,0,783,33,16,2,268,16,523,570,799,815,304,33,256,32,554,513]

theorem envBound51415 : H12AffineFastState.Bounded env51415 := by
  intro p hp
  have h : env51415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51414_51415 : H12AffineEnvironment.transform 11 799 env51414 = env51415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env51414 == env51415) = true)

def env51416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213351,119879,95496,8193,65,215366,115014,45405,32041,75103,156013,256,21793,46093,513]

theorem envBound51416 : H12AffineFastState.Bounded env51416 := by
  intro p hp
  have h : env51416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51405_51416 : H12AffineEnvironment.transform 6 9 env51405 = env51416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51405 == env51416) = true)

theorem identity51416 : scanCanonicalize (H12AffineFastState.compose env51416 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51416 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2420,1024,32769,77898,8572,119879,95496,8193,65,10589,115014,45405,32041,75103,65910,256,21793,46093,513]

theorem envBound51417 : H12AffineFastState.Bounded env51417 := by
  intro p hp
  have h : env51417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51416_51417 : H12AffineEnvironment.transform 16 90139 env51416 = env51417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51416 == env51417) = true)

theorem identity51417 : scanCanonicalize (H12AffineFastState.compose env51417 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound51417 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env51418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,65536,90139,2420,1024,21841,77898,8572,65815,95496,8193,65,10589,70678,25613,32041,75103,65910,256,21793,24925,513]

theorem envBound51418 : H12AffineFastState.Bounded env51418 := by
  intro p hp
  have h : env51418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51417_51418 : H12AffineEnvironment.transform 14 21840 env51417 = env51418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env51417 == env51418) = true)

theorem identity51418 : scanCanonicalize (H12AffineFastState.compose env51418 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound51418 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8313,65536,70962,2420,1024,8312,77898,8572,65815,65569,8193,65,10589,70678,4388,2048,75103,65910,256,8200,5236,513]

theorem envBound51419 : H12AffineFastState.Bounded env51419 := by
  intro p hp
  have h : env51419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51418_51419 : H12AffineEnvironment.transform 13 13609 env51418 = env51419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env51418 == env51419) = true)

theorem identity51419 : scanCanonicalize (H12AffineFastState.compose env51419 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound51419 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env51420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8313,114,5440,2420,1024,8312,12344,8572,357,83,8193,65,10589,5220,4388,2048,9517,260,256,8200,5236,513]

theorem envBound51420 : H12AffineFastState.Bounded env51420 := by
  intro p hp
  have h : env51420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51419_51420 : H12AffineEnvironment.transform 15 114 env51419 = env51420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env51419 == env51420) = true)

theorem identity51420 : scanCanonicalize (H12AffineFastState.compose env51420 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51420 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env51421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5156,372,114,5440,2420,1024,373,4405,113,357,83,268,65,2128,5220,4388,2048,1056,260,256,261,5236,513]

theorem envBound51421 : H12AffineFastState.Bounded env51421 := by
  intro p hp
  have h : env51421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51420_51421 : H12AffineEnvironment.transform 12 269 env51420 = env51421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51420 == env51421) = true)

theorem identity51421 : scanCanonicalize (H12AffineFastState.compose env51421 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51421 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51422 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,293,35,5393,2341,1024,292,4405,32,308,2,268,16,2049,5173,4388,2048,1056,260,256,261,5157,513]

theorem envBound51422 : H12AffineFastState.Bounded env51422 := by
  intro p hp
  have h : env51422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51421_51422 : H12AffineEnvironment.transform 5 17 env51421 = env51422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51421 == env51422) = true)

theorem identity51422 : scanCanonicalize (H12AffineFastState.compose env51422 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound51422 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51423 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1060,269,0,293,35,309,2341,1024,292,1297,32,308,2,268,16,2049,17,1280,2048,1056,260,256,261,1,513]

theorem envBound51423 : H12AffineFastState.Bounded env51423 := by
  intro p hp
  have h : env51423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51422_51423 : H12AffineEnvironment.transform 11 1060 env51422 = env51423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env51422 == env51423) = true)

theorem identity51423 : scanCanonicalize (H12AffineFastState.compose env51423 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound51423 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51424 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1060,269,0,293,35,309,1076,1024,292,1297,32,308,2,268,16,1296,17,1280,1297,1056,260,256,261,1,513]

theorem envBound51424 : H12AffineFastState.Bounded env51424 := by
  intro p hp
  have h : env51424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51423_51424 : H12AffineEnvironment.transform 10 1297 env51423 = env51424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env51423 == env51424) = true)

theorem identity51424 : scanCanonicalize (H12AffineFastState.compose env51424 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51424 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env51425 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,1060,41,0,1,35,17,1076,1024,0,1077,32,16,2,40,16,1076,17,1060,1077,1056,32,36,33,1,513]

theorem envBound51425 : H12AffineFastState.Bounded env51425 := by
  intro p hp
  have h : env51425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51424_51425 : H12AffineEnvironment.transform 7 36 env51424 = env51425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51424 == env51425) = true)

theorem identity51425 : scanCanonicalize (H12AffineFastState.compose env51425 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51426 : List Nat := [2,4,8,16,32,17,9,36,512,20,33,48,41,0,1,35,17,32,20,0,33,32,16,2,40,16,32,17,48,33,52,32,36,33,1,513]

theorem envBound51426 : H12AffineFastState.Bounded env51426 := by
  intro p hp
  have h : env51426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51425_51426 : H12AffineEnvironment.transform 9 20 env51425 = env51426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51425 == env51426) = true)

theorem identity51426 : scanCanonicalize (H12AffineFastState.compose env51426 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51427 : List Nat := [2,4,8,16,32,17,9,36,1,20,33,48,41,0,1,35,17,32,20,0,33,32,16,2,40,16,32,17,48,33,52,32,36,33,1,0]

theorem envBound51427 : H12AffineFastState.Bounded env51427 := by
  intro p hp
  have h : env51427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51426_51427 : H12AffineEnvironment.transform 8 1 env51426 = env51427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51426 == env51427) = true)

theorem identity51427 : scanCanonicalize (H12AffineFastState.compose env51427 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51427 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51428 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,16,9,0,1,3,17,0,20,0,1,0,16,2,8,16,0,17,16,1,20,0,4,1,1,0]

theorem envBound51428 : H12AffineFastState.Bounded env51428 := by
  intro p hp
  have h : env51428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51427_51428 : H12AffineEnvironment.transform 4 0 env51427 = env51428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51427 == env51428) = true)

theorem identity51428 : scanCanonicalize (H12AffineFastState.compose env51428 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51429 : List Nat := [2,4,8,10,0,11,9,4,1,14,1,10,9,0,1,3,11,0,14,0,1,0,10,2,8,10,0,11,10,1,14,0,4,1,1,0]

theorem envBound51429 : H12AffineFastState.Bounded env51429 := by
  intro p hp
  have h : env51429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51428_51429 : H12AffineEnvironment.transform 3 10 env51428 = env51429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51428 == env51429) = true)

def env51430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound51430 : H12AffineFastState.Bounded env51430 := by
  intro p hp
  have h : env51430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51231_51430 : H12AffineEnvironment.transform 18 1025 env51231 = env51430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env51231 == env51430) = true)

theorem identity51430 : scanCanonicalize (H12AffineFastState.compose env51430 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51430 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616168,18973836,10507600,8579112,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound51431 : H12AffineFastState.Bounded env51431 := by
  intro p hp
  have h : env51431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51430_51431 : H12AffineEnvironment.transform 17 10280 env51430 = env51431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51430 == env51431) = true)

def env51432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616168,18973700,10507600,8579112,25265168,23160137,257,27378724,27337992,25207630]

theorem envBound51432 : H12AffineFastState.Bounded env51432 := by
  intro p hp
  have h : env51432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51431_51432 : H12AffineEnvironment.transform 6 8 env51431 = env51432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51431 == env51432) = true)

theorem identity51432 : scanCanonicalize (H12AffineFastState.compose env51432 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound51432 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,41293,16777216,8192,65,21186917,18973700,2159645,149861,16852317,23160137,257,18965865,18973765,16777731]

theorem envBound51433 : H12AffineFastState.Bounded env51433 := by
  intro p hp
  have h : env51433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51432_51433 : H12AffineEnvironment.transform 22 41293 env51432 = env51433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env51432 == env51433) = true)

theorem identity51433 : scanCanonicalize (H12AffineFastState.compose env51433 (packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound51433 : packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,41293,16777216,8192,65,16935247,18973700,2159645,149861,16852317,18892131,257,18965865,18973765,16777731]

theorem envBound51434 : H12AffineFastState.Bounded env51434 := by
  intro p hp
  have h : env51434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51433_51434 : H12AffineEnvironment.transform 21 73770 env51433 = env51434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env51433 == env51434) = true)

def env51435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,2097152,73770,41293,16777216,8192,65,16812035,18973700,2159645,43049,16852317,18892131,257,18965865,18973765,16777731]

theorem envBound51435 : H12AffineFastState.Bounded env51435 := by
  intro p hp
  have h : env51435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51434_51435 : H12AffineEnvironment.transform 16 57676 env51434 = env51435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env51434 == env51435) = true)

theorem identity51435 : scanCanonicalize (H12AffineFastState.compose env51435 (packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2155883) := by decide +kernel

theorem selectedBound51435 : packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env51436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,2097152,73770,41293,2155883,8192,65,2125160,90479,2159645,43049,2211894,40968,257,98306,90414,2156392]

theorem envBound51436 : H12AffineFastState.Bounded env51436 := by
  intro p hp
  have h : env51436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51435_51436 : H12AffineEnvironment.transform 23 2155883 env51435 = env51436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155883 env51435 == env51436) = true)

theorem identity51436 : scanCanonicalize (H12AffineFastState.compose env51436 (packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51436 : packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env51437 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,57400,10280,1025,32769,2097152,73770,41017,2155551,8192,65,2124828,90139,2159645,43049,2211894,40968,117,98306,90202,2156060]

theorem envBound51437 : H12AffineFastState.Bounded env51437 := by
  intro p hp
  have h : env51437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51436_51437 : H12AffineEnvironment.transform 7 116 env51436 = env51437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51436 == env51437) = true)

theorem identity51437 : scanCanonicalize (H12AffineFastState.compose env51437 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51437 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env51438 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,57400,10280,1025,32769,2097152,33,41017,2155551,8192,65,2124828,16400,2159645,43049,2154557,40968,117,40969,16465,2156060]

theorem envBound51438 : H12AffineFastState.Bounded env51438 := by
  intro p hp
  have h : env51438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51437_51438 : H12AffineEnvironment.transform 15 8203 env51437 = env51438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51437 == env51438) = true)

theorem identity51438 : scanCanonicalize (H12AffineFastState.compose env51438 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound51438 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env51439 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,57400,10280,1025,32769,58396,33,41017,3,8192,65,34816,16400,4097,43049,1057,40968,117,40969,16465,512]

theorem envBound51439 : H12AffineFastState.Bounded env51439 := by
  intro p hp
  have h : env51439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51438_51439 : H12AffineEnvironment.transform 20 58396 env51438 = env51439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env51438 == env51439) = true)

theorem identity51439 : scanCanonicalize (H12AffineFastState.compose env51439 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 15484) := by decide +kernel

theorem selectedBound51439 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env51440 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,15484,32768,8203,40004,10280,1025,32769,39008,33,41017,3,8192,65,34816,15468,4097,43049,1057,40968,117,40969,15405,512]

theorem envBound51440 : H12AffineFastState.Bounded env51440 := by
  intro p hp
  have h : env51440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51439_51440 : H12AffineEnvironment.transform 13 15484 env51439 = env51440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15484 env51439 == env51440) = true)

theorem identity51440 : scanCanonicalize (H12AffineFastState.compose env51440 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51440 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env51441 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,15404,32768,8203,39956,10280,1025,32769,38960,33,41017,3,8192,17,34816,15420,4097,43049,1057,40968,37,40969,15405,512]

theorem envBound51441 : H12AffineFastState.Bounded env51441 := by
  intro p hp
  have h : env51441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51440_51441 : H12AffineEnvironment.transform 5 16 env51440 = env51441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51440 == env51441) = true)

theorem identity51441 : scanCanonicalize (H12AffineFastState.compose env51441 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound51441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51442 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,9,7205,32768,2,39956,2081,1025,32769,38960,33,32816,3,9,17,34816,7221,4097,34848,1057,32769,37,32768,7204,512]

theorem envBound51442 : H12AffineFastState.Bounded env51442 := by
  intro p hp
  have h : env51442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51441_51442 : H12AffineEnvironment.transform 12 9 env51441 = env51442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env51441 == env51442) = true)

theorem identity51442 : scanCanonicalize (H12AffineFastState.compose env51442 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51442 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51443 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,4096,9,5157,32768,2,37908,33,1025,32769,36912,33,32816,3,9,17,32768,5173,4097,32800,1057,32769,37,32768,5156,512]

theorem envBound51443 : H12AffineFastState.Bounded env51443 := by
  intro p hp
  have h : env51443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51442_51443 : H12AffineEnvironment.transform 10 0 env51442 = env51443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51442 == env51443) = true)

theorem identity51443 : scanCanonicalize (H12AffineFastState.compose env51443 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51443 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env51444 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,4096,9,5124,32768,2,37908,0,1025,32769,36881,0,32785,3,9,17,32768,5140,4097,32769,1024,32769,4,32768,5125,512]

theorem envBound51444 : H12AffineFastState.Bounded env51444 := by
  intro p hp
  have h : env51444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51443_51444 : H12AffineEnvironment.transform 4 1 env51443 = env51444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51443 == env51444) = true)

theorem identity51444 : scanCanonicalize (H12AffineFastState.compose env51444 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51444 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51445 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,1029,9,1,32768,2,32785,0,1025,32769,33812,0,32785,3,9,17,32768,17,1028,32769,1024,32769,4,32768,0,512]

theorem envBound51445 : H12AffineFastState.Bounded env51445 := by
  intro p hp
  have h : env51445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51444_51445 : H12AffineEnvironment.transform 11 1029 env51444 = env51445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env51444 == env51445) = true)

theorem identity51445 : scanCanonicalize (H12AffineFastState.compose env51445 (packedSelected [0,4] rootPS)) = affineNative (2^(14+1) ^^^ 1044) := by decide +kernel

theorem selectedBound51445 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51446 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,1029,9,1,1044,2,1029,0,1025,1045,0,0,1029,3,9,17,1044,17,1028,1045,1024,1045,4,1044,0,512]

theorem envBound51446 : H12AffineFastState.Bounded env51446 := by
  intro p hp
  have h : env51446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51445_51446 : H12AffineEnvironment.transform 14 1044 env51445 = env51446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1044 env51445 == env51446) = true)

theorem identity51446 : scanCanonicalize (H12AffineFastState.compose env51446 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51447 : List Nat := [2,4,8,16,1,16,8,5,512,21,0,16,9,1,1,2,16,0,20,0,0,0,16,3,9,17,1,17,17,0,21,0,4,1,0,512]

theorem envBound51447 : H12AffineFastState.Bounded env51447 := by
  intro p hp
  have h : env51447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51446_51447 : H12AffineEnvironment.transform 9 21 env51446 = env51447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51446 == env51447) = true)

theorem identity51447 : scanCanonicalize (H12AffineFastState.compose env51447 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51448 : List Nat := [2,4,8,16,1,16,8,5,16,21,0,16,9,1,1,2,16,0,20,0,0,0,16,3,9,17,1,17,17,0,21,0,4,1,0,16]

theorem envBound51448 : H12AffineFastState.Bounded env51448 := by
  intro p hp
  have h : env51448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51447_51448 : H12AffineEnvironment.transform 8 16 env51447 = env51448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51447 == env51448) = true)

theorem identity51448 : scanCanonicalize (H12AffineFastState.compose env51448 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound51448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51449 : List Nat := [2,4,6,16,1,16,6,5,16,21,0,16,7,1,1,2,16,0,20,0,0,0,16,3,7,17,1,17,17,0,21,0,4,1,0,16]

theorem envBound51449 : H12AffineFastState.Bounded env51449 := by
  intro p hp
  have h : env51449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51448_51449 : H12AffineEnvironment.transform 2 6 env51448 = env51449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env51448 == env51449) = true)

def env51450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,2097152,73770,41293,16777216,8192,65,16812034,18973700,2159645,43048,16852317,18892131,257,18965865,18973765,16777731]

theorem envBound51450 : H12AffineFastState.Bounded env51450 := by
  intro p hp
  have h : env51450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51434_51450 : H12AffineEnvironment.transform 16 57677 env51434 = env51450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env51434 == env51450) = true)

theorem identity51450 : scanCanonicalize (H12AffineFastState.compose env51450 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound51450 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env51451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,2097152,73770,41293,2,8192,65,34816,2196486,2159645,43048,75103,2114913,257,2188651,2196551,513]

theorem envBound51451 : H12AffineFastState.Bounded env51451 := by
  intro p hp
  have h : env51451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51450_51451 : H12AffineEnvironment.transform 23 2 env51450 = env51451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env51450 == env51451) = true)

theorem identity51451 : scanCanonicalize (H12AffineFastState.compose env51451 (packedSelected [0,2,3,5,6,7,10,11,12,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 36915) := by decide +kernel

theorem selectedBound51451 : packedSelected [0,2,3,5,6,7,10,11,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env51452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,36915,57677,10280,1025,32769,2097152,45081,41293,2,8192,65,34816,2102325,2159645,43048,46444,2114913,257,2159960,2102388,513]

theorem envBound51452 : H12AffineFastState.Bounded env51452 := by
  intro p hp
  have h : env51452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51451_51452 : H12AffineEnvironment.transform 15 36915 env51451 = env51452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36915 env51451 == env51452) = true)

theorem identity51452 : scanCanonicalize (H12AffineFastState.compose env51452 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound51452 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,32768,36915,53620,6161,1025,32769,2097152,32800,37236,2,4153,65,34816,2102325,2147364,38929,34133,2114913,257,2147681,2102388,513]

theorem envBound51453 : H12AffineFastState.Bounded env51453 := by
  intro p hp
  have h : env51453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51452_51453 : H12AffineEnvironment.transform 12 4153 env51452 = env51453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env51452 == env51453) = true)

theorem identity51453 : scanCanonicalize (H12AffineFastState.compose env51453 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound51453 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,32768,36915,53620,6161,1025,32769,5456,32800,37236,2,4153,65,34816,357,53620,38929,34133,20529,257,53297,292,513]

theorem envBound51454 : H12AffineFastState.Bounded env51454 := by
  intro p hp
  have h : env51454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51453_51454 : H12AffineEnvironment.transform 20 5456 env51453 = env51454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env51453 == env51454) = true)

theorem identity51454 : scanCanonicalize (H12AffineFastState.compose env51454 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound51454 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env51455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,4113,34,16741,6161,1025,4112,5456,4145,357,2,4153,65,6161,357,16741,2048,5444,20529,257,16416,292,513]

theorem envBound51455 : H12AffineFastState.Bounded env51455 := by
  intro p hp
  have h : env51455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51454_51455 : H12AffineEnvironment.transform 14 4113 env51454 = env51455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env51454 == env51455) = true)

theorem identity51455 : scanCanonicalize (H12AffineFastState.compose env51455 (packedSelected [0,3,5,6,7,10,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51455 : packedSelected [0,3,5,6,7,10,18] rootPS < 2^1333 := by decide +kernel

def env51456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,5377,4113,34,5220,6161,1025,4112,5456,4145,357,2,4153,65,6161,357,5220,2048,5444,1328,257,5409,292,513]

theorem envBound51456 : H12AffineFastState.Bounded env51456 := by
  intro p hp
  have h : env51456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51455_51456 : H12AffineEnvironment.transform 13 5377 env51455 = env51456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51455 == env51456) = true)

theorem identity51456 : scanCanonicalize (H12AffineFastState.compose env51456 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound51456 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env51457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,4096,4153,5377,4113,34,5220,4160,1025,4112,5456,4145,357,2,4153,65,4160,357,5220,81,5444,1328,257,5409,292,513]

theorem envBound51457 : H12AffineFastState.Bounded env51457 := by
  intro p hp
  have h : env51457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51456_51457 : H12AffineEnvironment.transform 10 81 env51456 = env51457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env51456 == env51457) = true)

theorem identity51457 : scanCanonicalize (H12AffineFastState.compose env51457 (packedSelected [1,2,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound51457 : packedSelected [1,2,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env51458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1281,1336,0,1296,34,357,1345,1025,1297,81,1328,357,2,1336,65,1345,357,357,81,69,1328,257,32,292,513]

theorem envBound51458 : H12AffineFastState.Bounded env51458 := by
  intro p hp
  have h : env51458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51457_51458 : H12AffineEnvironment.transform 11 1281 env51457 = env51458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env51457 == env51458) = true)

theorem identity51458 : scanCanonicalize (H12AffineFastState.compose env51458 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound51458 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51459 : List Nat := [2,4,8,16,32,64,8,256,512,100,81,357,348,0,372,34,357,293,101,373,81,340,357,2,348,65,293,357,357,81,69,340,257,32,292,513]

theorem envBound51459 : H12AffineFastState.Bounded env51459 := by
  intro p hp
  have h : env51459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51458_51459 : H12AffineEnvironment.transform 9 100 env51458 = env51459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env51458 == env51459) = true)

def env51460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616168,18973701,10507600,8579112,25265168,23160136,257,27378725,27337992,25207631]

theorem envBound51460 : H12AffineFastState.Bounded env51460 := by
  intro p hp
  have h : env51460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51431_51460 : H12AffineEnvironment.transform 6 9 env51431 = env51460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51431 == env51460) = true)

def env51461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,16777216,8193,65,21080104,18973701,2233680,43048,17024016,23160136,257,19104805,19096840,16966479]

theorem envBound51461 : H12AffineFastState.Bounded env51461 := by
  intro p hp
  have h : env51461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51460_51461 : H12AffineEnvironment.transform 22 147456 env51460 = env51461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env51460 == env51461) = true)

theorem identity51461 : scanCanonicalize (H12AffineFastState.compose env51461 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound51461 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env51462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188750,8193,65,4409702,2319691,2233680,43048,75102,6521862,257,2188651,2196550,513]

theorem envBound51462 : H12AffineFastState.Bounded env51462 := by
  intro p hp
  have h : env51462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51461_51462 : H12AffineEnvironment.transform 23 188750 env51461 = env51462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env51461 == env51462) = true)

def env51463 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188702,8193,17,4409654,2319643,2233600,43048,75022,6521862,257,2188603,2196502,513]

theorem envBound51463 : H12AffineFastState.Bounded env51463 := by
  intro p hp
  have h : env51463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51462_51463 : H12AffineEnvironment.transform 5 16 env51462 = env51463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51462 == env51463) = true)

theorem identity51463 : scanCanonicalize (H12AffineFastState.compose env51463 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound51463 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51464 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,4194304,147456,188702,8193,17,4409654,172301,250134,43048,75022,4341776,257,41261,16384,513]

theorem envBound51464 : H12AffineFastState.Bounded env51464 := by
  intro p hp
  have h : env51464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51463_51464 : H12AffineEnvironment.transform 20 115734 env51463 = env51464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env51463 == env51464) = true)

theorem identity51464 : scanCanonicalize (H12AffineFastState.compose env51464 (packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51464 : packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env51465 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115734,4194304,147456,180242,269,17,4409654,163841,250134,35108,66562,4341776,257,32801,16384,513]

theorem envBound51465 : H12AffineFastState.Bounded env51465 := by
  intro p hp
  have h : env51465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51464_51465 : H12AffineEnvironment.transform 12 268 env51464 = env51465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51464 == env51465) = true)

theorem identity51465 : scanCanonicalize (H12AffineFastState.compose env51465 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound51465 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env51466 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115734,32801,147456,180242,269,17,248087,163841,250134,35108,66562,180273,257,32801,16384,513]

theorem envBound51466 : H12AffineFastState.Bounded env51466 := by
  intro p hp
  have h : env51466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51465_51466 : H12AffineEnvironment.transform 21 32801 env51465 = env51466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env51465 == env51466) = true)

theorem identity51466 : scanCanonicalize (H12AffineFastState.compose env51466 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound51466 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51467 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,82199,2340,1025,32769,115734,32801,65815,98565,269,17,34816,114966,36865,35108,66562,98598,257,32801,16384,513]

theorem envBound51467 : H12AffineFastState.Bounded env51467 := by
  intro p hp
  have h : env51467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51466_51467 : H12AffineEnvironment.transform 16 82199 env51466 = env51467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env51466 == env51467) = true)

theorem identity51467 : scanCanonicalize (H12AffineFastState.compose env51467 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound51467 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51468 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16401,2340,1025,32769,50448,32801,17,32771,269,17,34816,49168,36865,35108,1284,32800,257,32801,16384,513]

theorem envBound51468 : H12AffineFastState.Bounded env51468 := by
  intro p hp
  have h : env51468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51467_51468 : H12AffineEnvironment.transform 15 262 env51467 = env51468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env51467 == env51468) = true)

theorem identity51468 : scanCanonicalize (H12AffineFastState.compose env51468 (packedSelected [4,9,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51468 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env51469 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16401,2340,1025,1,17680,33,17,3,269,17,2048,16400,4097,2340,1284,32,257,33,16384,513]

theorem envBound51469 : H12AffineFastState.Bounded env51469 := by
  intro p hp
  have h : env51469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51468_51469 : H12AffineEnvironment.transform 14 0 env51468 = env51469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51468 == env51469) = true)

theorem identity51469 : scanCanonicalize (H12AffineFastState.compose env51469 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound51469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51470 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5157,0,262,5172,2340,1025,1,4405,33,17,3,269,17,2048,5173,4097,2340,1284,32,257,33,5157,513]

theorem envBound51470 : H12AffineFastState.Bounded env51470 := by
  intro p hp
  have h : env51470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51469_51470 : H12AffineEnvironment.transform 13 5157 env51469 = env51470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env51469 == env51470) = true)

def env51471 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,268,2837,0,262,2820,2340,1025,1,3589,33,17,3,269,17,2048,2821,3889,2340,1284,32,257,33,2837,513]

theorem envBound51471 : H12AffineFastState.Bounded env51471 := by
  intro p hp
  have h : env51471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51470_51471 : H12AffineEnvironment.transform 11 3888 env51470 = env51471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env51470 == env51471) = true)

def env51472 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,268,1045,0,262,1028,1572,1025,1,261,33,17,3,269,17,1792,1029,49,1572,1284,32,257,33,1045,513]

theorem envBound51472 : H12AffineFastState.Bounded env51472 := by
  intro p hp
  have h : env51472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51471_51472 : H12AffineEnvironment.transform 10 1792 env51471 = env51472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env51471 == env51472) = true)

theorem identity51472 : scanCanonicalize (H12AffineFastState.compose env51472 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound51472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51473 : List Nat := [2,4,8,16,32,16,9,256,512,304,560,48,268,293,0,262,308,788,305,1,261,33,17,3,269,17,560,309,49,788,52,32,257,33,293,513]

theorem envBound51473 : H12AffineFastState.Bounded env51473 := by
  intro p hp
  have h : env51473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51472_51473 : H12AffineEnvironment.transform 9 304 env51472 = env51473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env51472 == env51473) = true)

def env51474 : List Nat := [2,4,8,16,32,16,9,4,512,52,560,48,8,33,0,2,48,528,53,1,1,33,17,3,9,17,560,49,49,528,52,32,5,33,33,513]

theorem envBound51474 : H12AffineFastState.Bounded env51474 := by
  intro p hp
  have h : env51474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51473_51474 : H12AffineEnvironment.transform 7 4 env51473 = env51474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51473 == env51474) = true)

theorem identity51474 : scanCanonicalize (H12AffineFastState.compose env51474 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51475 : List Nat := [2,4,8,16,32,16,9,4,16,52,32,48,8,33,0,2,48,0,53,1,1,33,17,3,9,17,32,49,49,0,52,32,5,33,33,17]

theorem envBound51475 : H12AffineFastState.Bounded env51475 := by
  intro p hp
  have h : env51475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51474_51475 : H12AffineEnvironment.transform 8 16 env51474 = env51475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51474 == env51475) = true)

def leafEnv51475 : List Nat := [2,4,8,16,32,16,9,4,16,52,32,48,8,33,0,2,48,0,53,1,1,33,17,3,53,9,1,17,32,49,49,0,52,32,5,33,5,3,33,17,1,1,0]

def active51475 : List Nat := [0,1,2,3,4]

def tree51475 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51475 : H12WitnessSearch.Good tree51475 := H12GlobalWitnessIndex.good

theorem leafIdentity51475 : H12AffineFastState.composeSystem env51475 rootObs = leafEnv51475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51475 rootObs == leafEnv51475) = true)

theorem terminalChecked51475 : H12PackedTerminal.terminalCheckFast leafEnv51475 active51475 tree51475 = true := by decide +kernel

def env51476 : List Nat := [2,4,8,16,32,16,9,5,512,53,560,48,9,32,0,3,49,529,52,1,0,33,17,3,8,17,560,48,49,529,52,32,4,33,32,513]

theorem envBound51476 : H12AffineFastState.Bounded env51476 := by
  intro p hp
  have h : env51476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51473_51476 : H12AffineEnvironment.transform 7 5 env51473 = env51476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51473 == env51476) = true)

theorem identity51476 : scanCanonicalize (H12AffineFastState.compose env51476 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51477 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,43,9,32,0,3,42,522,47,1,0,33,10,3,8,10,555,43,42,522,47,32,4,33,32,513]

theorem envBound51477 : H12AffineFastState.Bounded env51477 := by
  intro p hp
  have h : env51477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51476_51477 : H12AffineEnvironment.transform 3 11 env51476 = env51477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51476 == env51477) = true)

def leafEnv51477 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,43,9,32,0,3,42,522,47,1,0,33,10,3,46,8,1,10,555,43,42,522,47,32,4,33,5,2,32,513,1,0,0]

def active51477 : List Nat := [0,1,2,4,8]

def tree51477 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51477 : H12WitnessSearch.Good tree51477 := H12GlobalWitnessIndex.good

theorem leafIdentity51477 : H12AffineFastState.composeSystem env51477 rootObs = leafEnv51477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51477 rootObs == leafEnv51477) = true)

theorem terminalChecked51477 : H12PackedTerminal.terminalCheckFast leafEnv51477 active51477 tree51477 = true := by decide +kernel

def env51478 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,268,1044,0,262,1029,1573,1025,1,260,33,17,3,269,17,1793,1028,48,1573,1284,32,257,33,1044,513]

theorem envBound51478 : H12AffineFastState.Bounded env51478 := by
  intro p hp
  have h : env51478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51471_51478 : H12AffineEnvironment.transform 10 1793 env51471 = env51478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env51471 == env51478) = true)

theorem identity51478 : scanCanonicalize (H12AffineFastState.compose env51478 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51479 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1793,16,268,1044,0,262,1029,1540,1025,1,260,0,17,3,269,17,1793,1028,17,1540,1284,1,257,0,1044,513]

theorem envBound51479 : H12AffineFastState.Bounded env51479 := by
  intro p hp
  have h : env51479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51478_51479 : H12AffineEnvironment.transform 4 1 env51478 = env51479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51478 == env51479) = true)

def env51480 : List Nat := [2,4,8,16,1,16,9,256,512,20,789,16,268,0,0,262,17,528,21,1,260,0,17,3,269,17,789,16,17,528,272,1,257,0,0,513]

theorem envBound51480 : H12AffineFastState.Bounded env51480 := by
  intro p hp
  have h : env51480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51479_51480 : H12AffineEnvironment.transform 9 20 env51479 = env51480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51479 == env51480) = true)

theorem identity51480 : scanCanonicalize (H12AffineFastState.compose env51480 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51480 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51481 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,10,268,0,0,262,11,522,15,1,260,0,11,3,269,11,783,10,11,522,266,1,257,0,0,513]

theorem envBound51481 : H12AffineFastState.Bounded env51481 := by
  intro p hp
  have h : env51481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51480_51481 : H12AffineEnvironment.transform 3 10 env51480 = env51481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51480 == env51481) = true)

def leafEnv51481 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,10,268,0,0,262,11,522,15,1,260,0,11,3,267,269,1,11,783,10,11,522,266,1,257,0,5,263,0,513,1,260,0]

def active51481 : List Nat := [0,1,2,7,8]

def tree51481 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51481 : H12WitnessSearch.Good tree51481 := H12GlobalWitnessIndex.good

theorem leafIdentity51481 : H12AffineFastState.composeSystem env51481 rootObs = leafEnv51481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51481 rootObs == leafEnv51481) = true)

theorem terminalChecked51481 : H12PackedTerminal.terminalCheckFast leafEnv51481 active51481 tree51481 = true := by decide +kernel

def env51482 : List Nat := [2,4,8,16,1,16,9,256,512,21,788,16,268,1,0,262,16,529,20,1,260,0,17,3,269,17,788,17,17,529,273,1,257,0,1,513]

theorem envBound51482 : H12AffineFastState.Bounded env51482 := by
  intro p hp
  have h : env51482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51479_51482 : H12AffineEnvironment.transform 9 21 env51479 = env51482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51479 == env51482) = true)

theorem identity51482 : scanCanonicalize (H12AffineFastState.compose env51482 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound51482 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51483 : List Nat := [2,4,8,16,1,16,9,256,276,21,0,16,268,1,0,262,16,261,20,1,260,0,17,3,269,17,0,17,17,261,273,1,257,0,1,277]

theorem envBound51483 : H12AffineFastState.Bounded env51483 := by
  intro p hp
  have h : env51483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51482_51483 : H12AffineEnvironment.transform 8 276 env51482 = env51483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env51482 == env51483) = true)

def leafEnv51483 : List Nat := [2,4,8,16,1,16,9,256,276,21,0,16,268,1,0,262,16,261,20,1,260,0,17,3,272,269,1,17,0,17,17,261,273,1,257,0,5,263,1,277,1,260,0]

def active51483 : List Nat := [0,1,2,3,7]

def tree51483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51483 : H12WitnessSearch.Good tree51483 := H12GlobalWitnessIndex.good

theorem leafIdentity51483 : H12AffineFastState.composeSystem env51483 rootObs = leafEnv51483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51483 rootObs == leafEnv51483) = true)

theorem terminalChecked51483 : H12PackedTerminal.terminalCheckFast leafEnv51483 active51483 tree51483 = true := by decide +kernel

def env51484 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,268,2836,0,262,2821,2340,1025,1,3588,33,17,3,269,17,2048,2820,3888,2340,1284,32,257,33,2836,513]

theorem envBound51484 : H12AffineFastState.Bounded env51484 := by
  intro p hp
  have h : env51484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51470_51484 : H12AffineEnvironment.transform 11 3889 env51470 = env51484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env51470 == env51484) = true)

def env51485 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,268,1044,0,262,1029,1572,1025,1,260,33,17,3,269,17,1792,1028,48,1572,1284,32,257,33,1044,513]

theorem envBound51485 : H12AffineFastState.Bounded env51485 := by
  intro p hp
  have h : env51485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51484_51485 : H12AffineEnvironment.transform 10 1792 env51484 = env51485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env51484 == env51485) = true)

theorem identity51485 : scanCanonicalize (H12AffineFastState.compose env51485 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51486 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1540,49,8,1044,0,2,1029,1572,1025,1,0,33,17,3,9,17,1540,1028,48,1572,1024,32,5,33,1044,513]

theorem envBound51486 : H12AffineFastState.Bounded env51486 := by
  intro p hp
  have h : env51486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51485_51486 : H12AffineEnvironment.transform 7 4 env51485 = env51486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51485 == env51486) = true)

def env51487 : List Nat := [2,4,8,16,32,16,9,4,512,52,560,49,8,32,0,2,49,528,53,1,0,33,17,3,9,17,560,48,48,528,52,32,5,33,32,513]

theorem envBound51487 : H12AffineFastState.Bounded env51487 := by
  intro p hp
  have h : env51487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51486_51487 : H12AffineEnvironment.transform 9 52 env51486 = env51487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51486 == env51487) = true)

theorem identity51487 : scanCanonicalize (H12AffineFastState.compose env51487 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51487 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51488 : List Nat := [2,4,8,16,32,16,9,4,17,52,33,49,8,32,0,2,49,1,53,1,0,33,17,3,9,17,33,48,48,1,52,32,5,33,32,16]

theorem envBound51488 : H12AffineFastState.Bounded env51488 := by
  intro p hp
  have h : env51488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51487_51488 : H12AffineEnvironment.transform 8 17 env51487 = env51488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51487 == env51488) = true)

def leafEnv51488 : List Nat := [2,4,8,16,32,16,9,4,17,52,33,49,8,32,0,2,49,1,53,1,0,33,17,3,53,9,1,17,33,48,48,1,52,32,5,33,5,3,32,16,1,0,0]

def active51488 : List Nat := [0,1,2,3,4]

def tree51488 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51488 : H12WitnessSearch.Good tree51488 := H12GlobalWitnessIndex.good

theorem leafIdentity51488 : H12AffineFastState.composeSystem env51488 rootObs = leafEnv51488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51488 rootObs == leafEnv51488) = true)

theorem terminalChecked51488 : H12PackedTerminal.terminalCheckFast leafEnv51488 active51488 tree51488 = true := by decide +kernel

def env51489 : List Nat := [2,4,8,16,32,16,9,4,512,53,561,49,8,33,0,2,48,529,52,1,0,33,17,3,9,17,561,49,48,529,53,32,5,33,33,513]

theorem envBound51489 : H12AffineFastState.Bounded env51489 := by
  intro p hp
  have h : env51489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51486_51489 : H12AffineEnvironment.transform 9 53 env51486 = env51489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51486 == env51489) = true)

theorem identity51489 : scanCanonicalize (H12AffineFastState.compose env51489 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51490 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,42,8,33,0,2,43,522,47,1,0,33,10,3,9,10,554,42,43,522,46,32,5,33,33,513]

theorem envBound51490 : H12AffineFastState.Bounded env51490 := by
  intro p hp
  have h : env51490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51489_51490 : H12AffineEnvironment.transform 3 11 env51489 = env51490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51489 == env51490) = true)

def leafEnv51490 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,42,8,33,0,2,43,522,47,1,0,33,10,3,47,9,1,10,554,42,43,522,46,32,5,33,5,3,33,513,1,0,0]

def active51490 : List Nat := [0,1,2,4,8]

def tree51490 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51490 : H12WitnessSearch.Good tree51490 := H12GlobalWitnessIndex.good

theorem leafIdentity51490 : H12AffineFastState.composeSystem env51490 rootObs = leafEnv51490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51490 rootObs == leafEnv51490) = true)

theorem terminalChecked51490 : H12PackedTerminal.terminalCheckFast leafEnv51490 active51490 tree51490 = true := by decide +kernel

def env51491 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,268,1045,0,262,1028,1573,1025,1,261,33,17,3,269,17,1793,1029,49,1573,1284,32,257,33,1045,513]

theorem envBound51491 : H12AffineFastState.Bounded env51491 := by
  intro p hp
  have h : env51491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51484_51491 : H12AffineEnvironment.transform 10 1793 env51484 = env51491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env51484 == env51491) = true)

theorem identity51491 : scanCanonicalize (H12AffineFastState.compose env51491 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51492 : List Nat := [2,4,8,16,32,16,9,256,512,21,788,48,268,0,0,262,17,560,20,1,261,33,17,3,269,17,788,16,49,560,273,32,257,33,0,513]

theorem envBound51492 : H12AffineFastState.Bounded env51492 := by
  intro p hp
  have h : env51492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51491_51492 : H12AffineEnvironment.transform 9 21 env51491 = env51492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51491 == env51492) = true)

def env51493 : List Nat := [2,4,8,16,0,16,9,256,512,21,788,16,268,0,0,262,17,528,20,1,261,1,17,3,269,17,788,16,17,528,273,0,257,1,0,513]

theorem envBound51493 : H12AffineFastState.Bounded env51493 := by
  intro p hp
  have h : env51493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51492_51493 : H12AffineEnvironment.transform 4 0 env51492 = env51493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51492 == env51493) = true)

theorem identity51493 : scanCanonicalize (H12AffineFastState.compose env51493 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51493 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51494 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,10,268,0,0,262,11,522,14,1,261,1,11,3,269,11,782,10,11,522,267,0,257,1,0,513]

theorem envBound51494 : H12AffineFastState.Bounded env51494 := by
  intro p hp
  have h : env51494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51493_51494 : H12AffineEnvironment.transform 3 10 env51493 = env51494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51493 == env51494) = true)

def leafEnv51494 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,10,268,0,0,262,11,522,14,1,261,1,11,3,266,269,1,11,782,10,11,522,267,0,257,1,5,263,0,513,1,261,0]

def active51494 : List Nat := [0,1,2,7,8]

def tree51494 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51494 : H12WitnessSearch.Good tree51494 := H12GlobalWitnessIndex.good

theorem leafIdentity51494 : H12AffineFastState.composeSystem env51494 rootObs = leafEnv51494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51494 rootObs == leafEnv51494) = true)

theorem terminalChecked51494 : H12PackedTerminal.terminalCheckFast leafEnv51494 active51494 tree51494 = true := by decide +kernel

def env51495 : List Nat := [2,4,8,16,1,16,9,256,512,21,788,17,268,0,0,262,17,529,20,1,261,0,17,3,269,17,788,16,16,529,273,1,257,0,0,513]

theorem envBound51495 : H12AffineFastState.Bounded env51495 := by
  intro p hp
  have h : env51495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51492_51495 : H12AffineEnvironment.transform 4 1 env51492 = env51495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51492 == env51495) = true)

theorem identity51495 : scanCanonicalize (H12AffineFastState.compose env51495 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound51495 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51496 : List Nat := [2,4,8,16,1,16,9,256,277,21,1,17,268,0,0,262,17,260,20,1,261,0,17,3,269,17,1,16,16,260,273,1,257,0,0,276]

theorem envBound51496 : H12AffineFastState.Bounded env51496 := by
  intro p hp
  have h : env51496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51495_51496 : H12AffineEnvironment.transform 8 277 env51495 = env51496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env51495 == env51496) = true)

def leafEnv51496 : List Nat := [2,4,8,16,1,16,9,256,277,21,1,17,268,0,0,262,17,260,20,1,261,0,17,3,272,269,1,17,1,16,16,260,273,1,257,0,5,263,0,276,1,261,0]

def active51496 : List Nat := [0,1,2,3,7]

def tree51496 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51496 : H12WitnessSearch.Good tree51496 := H12GlobalWitnessIndex.good

theorem leafIdentity51496 : H12AffineFastState.composeSystem env51496 rootObs = leafEnv51496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51496 rootObs == leafEnv51496) = true)

theorem terminalChecked51496 : H12PackedTerminal.terminalCheckFast leafEnv51496 active51496 tree51496 = true := by decide +kernel

def env51497 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188703,8193,16,4409655,2319642,2233601,43048,75023,6521862,257,2188602,2196503,513]

theorem envBound51497 : H12AffineFastState.Bounded env51497 := by
  intro p hp
  have h : env51497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51462_51497 : H12AffineEnvironment.transform 5 17 env51462 = env51497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51462 == env51497) = true)

theorem identity51497 : scanCanonicalize (H12AffineFastState.compose env51497 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 2270253) := by decide +kernel

theorem selectedBound51497 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51498 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2270253,147456,188703,8193,16,2223386,2319642,2233601,43048,75023,73771,257,2188602,2196503,513]

theorem envBound51498 : H12AffineFastState.Bounded env51498 := by
  intro p hp
  have h : env51498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51497_51498 : H12AffineEnvironment.transform 21 2270253 env51497 = env51498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2270253 env51497 == env51498) = true)

theorem identity51498 : scanCanonicalize (H12AffineFastState.compose env51498 (packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound51498 : packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51499 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,221242,147456,188703,8193,16,10509,172301,250134,43048,75023,73771,257,41261,16384,513]

theorem envBound51499 : H12AffineFastState.Bounded env51499 := by
  intro p hp
  have h : env51499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51498_51499 : H12AffineEnvironment.transform 20 115735 env51498 = env51499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env51498 == env51499) = true)

theorem identity51499 : scanCanonicalize (H12AffineFastState.compose env51499 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound51499 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env51500 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10280,1025,8461,91419,221242,147456,147475,8193,16,10509,131073,225306,2340,75023,73771,257,33,16384,513]

theorem envBound51500 : H12AffineFastState.Bounded env51500 := by
  intro p hp
  have h : env51500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51499_51500 : H12AffineEnvironment.transform 14 8460 env51499 = env51500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env51499 == env51500) = true)

theorem identity51500 : scanCanonicalize (H12AffineFastState.compose env51500 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51500 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51501 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,90138,10280,1025,8461,91419,32,73754,73737,8193,16,10509,90139,4096,2340,75023,73771,257,33,16384,513]

theorem envBound51501 : H12AffineFastState.Bounded env51501 := by
  intro p hp
  have h : env51501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51500_51501 : H12AffineEnvironment.transform 16 90138 env51500 = env51501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51500 == env51501) = true)

theorem identity51501 : scanCanonicalize (H12AffineFastState.compose env51501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound51501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51502 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,263,24861,10280,1025,8461,25628,32,8477,8462,8193,16,10509,24860,4096,2340,9224,8492,257,33,16384,513]

theorem envBound51502 : H12AffineFastState.Bounded env51502 := by
  intro p hp
  have h : env51502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51501_51502 : H12AffineEnvironment.transform 15 263 env51501 = env51502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env51501 == env51502) = true)

theorem identity51502 : scanCanonicalize (H12AffineFastState.compose env51502 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51503 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1025,0,17681,32,16,3,268,16,2048,16401,4096,2340,1285,33,257,33,16384,513]

theorem envBound51503 : H12AffineFastState.Bounded env51503 := by
  intro p hp
  have h : env51503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51502_51503 : H12AffineEnvironment.transform 12 269 env51502 = env51503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51502 == env51503) = true)

theorem identity51503 : scanCanonicalize (H12AffineFastState.compose env51503 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound51503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51504 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,4145,1,263,4129,2341,1025,0,5408,32,16,3,268,16,2048,4128,4096,2340,1285,33,257,33,4145,513]

theorem envBound51504 : H12AffineFastState.Bounded env51504 := by
  intro p hp
  have h : env51504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51503_51504 : H12AffineEnvironment.transform 13 4145 env51503 = env51504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env51503 == env51504) = true)

theorem identity51504 : scanCanonicalize (H12AffineFastState.compose env51504 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3630) := by decide +kernel

theorem selectedBound51504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51505 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3630,269,3615,1,263,3599,2341,1025,0,2830,32,16,3,268,16,2048,3598,3630,2340,1285,33,257,33,3615,513]

theorem envBound51505 : H12AffineFastState.Bounded env51505 := by
  intro p hp
  have h : env51505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51504_51505 : H12AffineEnvironment.transform 11 3630 env51504 = env51505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3630 env51504 == env51505) = true)

theorem identity51505 : scanCanonicalize (H12AffineFastState.compose env51505 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51505 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51506 : List Nat := [2,4,8,16,11,17,9,256,512,1024,2048,3589,269,3615,1,263,3599,2318,1025,0,2830,11,16,3,268,16,2048,3598,3589,2319,1285,10,257,10,3615,513]

theorem envBound51506 : H12AffineFastState.Bounded env51506 := by
  intro p hp
  have h : env51506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51505_51506 : H12AffineEnvironment.transform 4 11 env51505 = env51506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51505 == env51506) = true)

theorem identity51506 : scanCanonicalize (H12AffineFastState.compose env51506 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound51506 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51507 : List Nat := [2,4,8,16,11,17,9,256,512,517,2048,2048,269,2074,1,263,2058,2318,516,0,2830,11,16,3,268,16,2048,2059,2048,2319,768,10,257,10,2074,513]

theorem envBound51507 : H12AffineFastState.Bounded env51507 := by
  intro p hp
  have h : env51507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51506_51507 : H12AffineEnvironment.transform 9 517 env51506 = env51507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env51506 == env51507) = true)

theorem identity51507 : scanCanonicalize (H12AffineFastState.compose env51507 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound51507 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51508 : List Nat := [2,4,8,16,11,17,9,256,512,517,271,271,269,277,1,263,261,1,516,0,513,11,16,3,268,16,271,260,271,0,768,10,257,10,277,513]

theorem envBound51508 : H12AffineFastState.Bounded env51508 := by
  intro p hp
  have h : env51508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51507_51508 : H12AffineEnvironment.transform 10 271 env51507 = env51508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env51507 == env51508) = true)

theorem identity51508 : scanCanonicalize (H12AffineFastState.compose env51508 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51508 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51509 : List Nat := [2,4,8,16,11,17,9,20,512,517,27,27,25,1,1,19,17,1,516,0,513,11,16,3,24,16,27,16,27,0,532,10,21,10,1,513]

theorem envBound51509 : H12AffineFastState.Bounded env51509 := by
  intro p hp
  have h : env51509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51508_51509 : H12AffineEnvironment.transform 7 20 env51508 = env51509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51508 == env51509) = true)

theorem identity51509 : scanCanonicalize (H12AffineFastState.compose env51509 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51509 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env51510 : List Nat := [2,4,8,0,11,1,9,4,512,517,11,11,9,1,1,3,1,1,516,0,513,11,0,3,8,0,11,0,11,0,516,10,5,10,1,513]

theorem envBound51510 : H12AffineFastState.Bounded env51510 := by
  intro p hp
  have h : env51510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51509_51510 : H12AffineEnvironment.transform 3 0 env51509 = env51510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51509 == env51510) = true)

theorem identity51510 : scanCanonicalize (H12AffineFastState.compose env51510 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound51510 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51511 : List Nat := [2,4,8,0,11,1,9,4,6,3,11,11,9,1,1,3,1,1,2,0,7,11,0,3,8,0,11,0,11,0,2,10,5,10,1,7]

theorem envBound51511 : H12AffineFastState.Bounded env51511 := by
  intro p hp
  have h : env51511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51510_51511 : H12AffineEnvironment.transform 8 6 env51510 = env51511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env51510 == env51511) = true)

def env51512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,16777216,8193,65,21080105,18973701,2233681,43049,17024017,23160136,257,19104804,19096841,16966478]

theorem envBound51512 : H12AffineFastState.Bounded env51512 := by
  intro p hp
  have h : env51512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51460_51512 : H12AffineEnvironment.transform 22 147457 env51460 = env51512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env51460 == env51512) = true)

def env51513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,2347268,8193,65,6453549,152833,2233681,43049,2102549,4371532,257,21792,46093,2175562]

theorem envBound51513 : H12AffineFastState.Bounded env51513 := by
  intro p hp
  have h : env51513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51512_51513 : H12AffineEnvironment.transform 23 2347268 env51512 = env51513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347268 env51512 == env51513) = true)

def env51514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147457,98644,8193,65,4204925,152833,17665,43049,148805,4371532,257,21792,46093,221722]

theorem envBound51514 : H12AffineFastState.Bounded env51514 := by
  intro p hp
  have h : env51514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51513_51514 : H12AffineEnvironment.transform 20 151632 env51513 = env51514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env51513 == env51514) = true)

theorem identity51514 : scanCanonicalize (H12AffineFastState.compose env51514 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51514 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env51515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77899,4194304,73754,98644,8193,65,4204925,79130,17665,43049,75102,4314199,257,21792,46093,513]

theorem envBound51515 : H12AffineFastState.Bounded env51515 := by
  intro p hp
  have h : env51515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51514_51515 : H12AffineEnvironment.transform 16 90139 env51514 = env51515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51514 == env51515) = true)

theorem identity51515 : scanCanonicalize (H12AffineFastState.compose env51515 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound51515 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env51516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,4194304,73754,95497,8193,65,4204925,79130,17665,23668,75102,4268042,257,21792,16464,513]

theorem envBound51516 : H12AffineFastState.Bounded env51516 := by
  intro p hp
  have h : env51516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51515_51516 : H12AffineEnvironment.transform 14 29789 env51515 = env51516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env51515 == env51516) = true)

def env51517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,32,73754,95497,8193,65,10589,79130,17665,23668,75102,73770,257,21792,16464,513]

theorem envBound51517 : H12AffineFastState.Bounded env51517 := by
  intro p hp
  have h : env51517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51516_51517 : H12AffineEnvironment.transform 21 32 env51516 = env51517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51516 == env51517) = true)

theorem identity51517 : scanCanonicalize (H12AffineFastState.compose env51517 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound51517 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,16448,10280,1025,29788,4112,32,65,21842,8193,65,10589,5441,17665,23668,1285,113,257,21792,16464,513]

theorem envBound51518 : H12AffineFastState.Bounded env51518 := by
  intro p hp
  have h : env51518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51517_51518 : H12AffineEnvironment.transform 15 8283 env51517 = env51518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env51517 == env51518) = true)

theorem identity51518 : scanCanonicalize (H12AffineFastState.compose env51518 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51518 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,342,16448,2341,1025,21841,4112,32,65,21842,268,65,2128,5441,17665,23668,1285,113,257,21792,16464,513]

theorem envBound51519 : H12AffineFastState.Bounded env51519 := by
  intro p hp
  have h : env51519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51518_51519 : H12AffineEnvironment.transform 12 269 env51518 = env51519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51518 == env51519) = true)

theorem identity51519 : scanCanonicalize (H12AffineFastState.compose env51519 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound51519 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,342,5392,2341,1025,1,4112,32,65,2,268,65,2128,5441,4177,2340,1285,113,257,112,5376,513]

theorem envBound51520 : H12AffineFastState.Bounded env51520 := by
  intro p hp
  have h : env51520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51519_51520 : H12AffineEnvironment.transform 13 5456 env51519 = env51520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env51519 == env51520) = true)

theorem identity51520 : scanCanonicalize (H12AffineFastState.compose env51520 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound51520 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,513,269,1873,0,342,1809,2341,1025,1,529,32,65,2,268,65,2128,1856,592,2340,1285,113,257,112,1793,513]

theorem envBound51521 : H12AffineFastState.Bounded env51521 := by
  intro p hp
  have h : env51521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51520_51521 : H12AffineEnvironment.transform 11 513 env51520 = env51521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env51520 == env51521) = true)

def env51522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,33,73754,95497,8193,65,10588,79130,17665,23668,75102,73771,257,21792,16464,513]

theorem envBound51522 : H12AffineFastState.Bounded env51522 := by
  intro p hp
  have h : env51522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51516_51522 : H12AffineEnvironment.transform 21 33 env51516 = env51522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51516 == env51522) = true)

theorem identity51522 : scanCanonicalize (H12AffineFastState.compose env51522 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound51522 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21511,13340,10280,1025,29788,25676,33,29725,8462,8193,65,10588,24861,17665,23668,29017,29740,257,21792,16464,513]

theorem envBound51523 : H12AffineFastState.Bounded env51523 := by
  intro p hp
  have h : env51523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51522_51523 : H12AffineEnvironment.transform 15 21511 env51522 = env51523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env51522 == env51523) = true)

theorem identity51523 : scanCanonicalize (H12AffineFastState.compose env51523 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51523 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8203,13340,10280,1025,80,4160,33,17,8462,8193,65,10588,5393,12557,10360,1365,32,257,8492,13404,513]

theorem envBound51524 : H12AffineFastState.Bounded env51524 := by
  intro p hp
  have h : env51524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51523_51524 : H12AffineEnvironment.transform 13 13324 env51523 = env51524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51523 == env51524) = true)

theorem identity51524 : scanCanonicalize (H12AffineFastState.compose env51524 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51524 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,342,5441,2421,1025,80,4160,33,17,83,348,65,2049,5393,4176,2341,1365,32,257,113,5377,513]

theorem envBound51525 : H12AffineFastState.Bounded env51525 := by
  intro p hp
  have h : env51525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51524_51525 : H12AffineEnvironment.transform 12 349 env51524 = env51525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51524 == env51525) = true)

theorem identity51525 : scanCanonicalize (H12AffineFastState.compose env51525 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51526 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2340,1025,1,4113,33,17,2,269,16,2049,5393,4097,2341,1284,32,257,32,5377,513]

theorem envBound51526 : H12AffineFastState.Bounded env51526 := by
  intro p hp
  have h : env51526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51525_51526 : H12AffineEnvironment.transform 5 17 env51525 = env51526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51525 == env51526) = true)

theorem identity51526 : scanCanonicalize (H12AffineFastState.compose env51526 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound51526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51527 : List Nat := [2,4,8,16,32,17,9,256,512,289,2048,4096,268,4129,0,263,4145,2340,288,1,4113,33,17,2,269,16,2049,4144,4097,2341,37,32,257,32,4128,513]

theorem envBound51527 : H12AffineFastState.Bounded env51527 := by
  intro p hp
  have h : env51527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51526_51527 : H12AffineEnvironment.transform 9 289 env51526 = env51527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env51526 == env51527) = true)

theorem identity51527 : scanCanonicalize (H12AffineFastState.compose env51527 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound51527 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51528 : List Nat := [2,4,8,16,32,17,9,256,292,289,2048,4096,268,4129,0,263,4145,2340,288,1,4113,33,17,2,269,16,2049,4144,4097,2341,37,32,257,32,4128,293]

theorem envBound51528 : H12AffineFastState.Bounded env51528 := by
  intro p hp
  have h : env51528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51527_51528 : H12AffineEnvironment.transform 8 292 env51527 = env51528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env51527 == env51528) = true)

theorem identity51528 : scanCanonicalize (H12AffineFastState.compose env51528 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound51528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51529 : List Nat := [2,4,8,16,32,17,9,256,292,289,2048,2080,268,2049,0,263,2065,2340,288,1,2097,33,17,2,269,16,2049,2064,2081,2341,37,32,257,32,2048,293]

theorem envBound51529 : H12AffineFastState.Bounded env51529 := by
  intro p hp
  have h : env51529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51528_51529 : H12AffineEnvironment.transform 11 2080 env51528 = env51529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env51528 == env51529) = true)

theorem identity51529 : scanCanonicalize (H12AffineFastState.compose env51529 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51530 : List Nat := [2,4,8,16,1,17,9,256,261,256,2048,2049,268,2049,0,263,2065,2309,257,1,2064,0,17,2,269,16,2049,2064,2048,2308,4,1,257,1,2048,260]

theorem envBound51530 : H12AffineFastState.Bounded env51530 := by
  intro p hp
  have h : env51530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51529_51530 : H12AffineEnvironment.transform 4 1 env51529 = env51530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51529 == env51530) = true)

theorem identity51530 : scanCanonicalize (H12AffineFastState.compose env51530 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound51530 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51531 : List Nat := [2,4,8,16,1,17,9,256,261,256,17,16,268,16,0,263,0,276,257,1,1,0,17,2,269,16,16,1,17,277,4,1,257,1,17,260]

theorem envBound51531 : H12AffineFastState.Bounded env51531 := by
  intro p hp
  have h : env51531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51530_51531 : H12AffineEnvironment.transform 10 17 env51530 = env51531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env51530 == env51531) = true)

theorem identity51531 : scanCanonicalize (H12AffineFastState.compose env51531 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51531 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51532 : List Nat := [2,4,8,16,1,17,9,21,16,21,17,16,25,16,0,18,0,1,20,1,1,0,17,2,24,16,16,1,17,0,4,1,20,1,17,17]

theorem envBound51532 : H12AffineFastState.Bounded env51532 := by
  intro p hp
  have h : env51532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51531_51532 : H12AffineEnvironment.transform 7 21 env51531 = env51532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51531 == env51532) = true)

theorem identity51532 : scanCanonicalize (H12AffineFastState.compose env51532 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51532 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env51533 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,1,8,1,0,3,0,1,5,1,1,0,0,2,9,1,1,1,0,0,4,1,5,1,0,0]

theorem envBound51533 : H12AffineFastState.Bounded env51533 := by
  intro p hp
  have h : env51533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51532_51533 : H12AffineEnvironment.transform 3 1 env51532 = env51533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51532 == env51533) = true)

theorem identity51533 : scanCanonicalize (H12AffineFastState.compose env51533 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51534 : List Nat := [2,4,2,1,1,0,3,4,1,4,0,1,2,1,0,3,0,1,5,1,1,0,0,2,3,1,1,1,0,0,4,1,5,1,0,0]

theorem envBound51534 : H12AffineFastState.Bounded env51534 := by
  intro p hp
  have h : env51534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51533_51534 : H12AffineEnvironment.transform 2 2 env51533 = env51534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51533 == env51534) = true)

def env51535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147457,98645,8193,65,4204924,152833,17664,43049,148804,4371532,257,21792,46093,221723]

theorem envBound51535 : H12AffineFastState.Bounded env51535 := by
  intro p hp
  have h : env51535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51513_51535 : H12AffineEnvironment.transform 20 151633 env51513 = env51535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env51513 == env51535) = true)

def env51536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,32,147457,98645,8193,65,10588,152833,17664,43049,148804,177260,257,21792,46093,221723]

theorem envBound51536 : H12AffineFastState.Bounded env51536 := by
  intro p hp
  have h : env51536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51535_51536 : H12AffineEnvironment.transform 21 32 env51535 = env51536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51535 == env51536) = true)

theorem identity51536 : scanCanonicalize (H12AffineFastState.compose env51536 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51536 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77899,32,73755,98645,8193,65,10588,79131,17664,43049,75102,119926,257,21792,46093,513]

theorem envBound51537 : H12AffineFastState.Bounded env51537 := by
  intro p hp
  have h : env51537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51536_51537 : H12AffineEnvironment.transform 16 90138 env51536 = env51537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51536 == env51537) = true)

theorem identity51537 : scanCanonicalize (H12AffineFastState.compose env51537 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51537 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,4161,32,17,41311,8193,65,10588,5393,17664,43049,1364,62588,257,21792,46093,513]

theorem envBound51538 : H12AffineFastState.Bounded env51538 := by
  intro p hp
  have h : env51538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51537_51538 : H12AffineEnvironment.transform 15 8202 env51537 = env51538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51537 == env51538) = true)

theorem identity51538 : scanCanonicalize (H12AffineFastState.compose env51538 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51538 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2341,1025,32769,4161,32,17,32850,268,65,2129,5393,17664,35108,1364,54641,257,21792,38144,513]

theorem envBound51539 : H12AffineFastState.Bounded env51539 := by
  intro p hp
  have h : env51539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51538_51539 : H12AffineEnvironment.transform 12 269 env51538 = env51539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51538 == env51539) = true)

theorem identity51539 : scanCanonicalize (H12AffineFastState.compose env51539 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound51539 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,263,16400,2341,1025,21840,4161,32,17,21763,268,65,2129,5393,17664,23669,1364,32,257,21792,16465,513]

theorem envBound51540 : H12AffineFastState.Bounded env51540 := by
  intro p hp
  have h : env51540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51539_51540 : H12AffineEnvironment.transform 14 21841 env51539 = env51540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env51539 == env51540) = true)

theorem identity51540 : scanCanonicalize (H12AffineFastState.compose env51540 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound51540 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,0,263,5441,2341,1025,1,4161,32,17,82,268,65,2129,5393,4177,2340,1364,32,257,113,5376,513]

theorem envBound51541 : H12AffineFastState.Bounded env51541 := by
  intro p hp
  have h : env51541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51540_51541 : H12AffineEnvironment.transform 13 5457 env51540 = env51541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env51540 == env51541) = true)

theorem identity51541 : scanCanonicalize (H12AffineFastState.compose env51541 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound51541 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51542 : List Nat := [2,4,8,16,32,64,9,256,270,1024,2048,4096,269,5457,0,263,5441,2341,1025,1,4161,32,17,82,268,65,2129,5393,4177,2340,1364,32,257,113,5376,271]

theorem envBound51542 : H12AffineFastState.Bounded env51542 := by
  intro p hp
  have h : env51542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51541_51542 : H12AffineEnvironment.transform 8 270 env51541 = env51542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env51541 == env51542) = true)

theorem identity51542 : scanCanonicalize (H12AffineFastState.compose env51542 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51542 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51543 : List Nat := [2,4,8,16,32,17,9,256,270,1024,2048,4096,269,5376,0,263,5392,2341,1025,1,4112,32,17,3,268,16,2048,5393,4096,2340,1285,32,257,32,5376,271]

theorem envBound51543 : H12AffineFastState.Bounded env51543 := by
  intro p hp
  have h : env51543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51542_51543 : H12AffineEnvironment.transform 5 17 env51542 = env51543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51542 == env51543) = true)

theorem identity51543 : scanCanonicalize (H12AffineFastState.compose env51543 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound51543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51544 : List Nat := [2,4,8,16,32,17,9,256,270,1024,2048,32,269,1312,0,263,1328,2341,1025,1,48,32,17,3,268,16,2048,1329,32,2340,1285,32,257,32,1312,271]

theorem envBound51544 : H12AffineFastState.Bounded env51544 := by
  intro p hp
  have h : env51544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51543_51544 : H12AffineEnvironment.transform 11 32 env51543 = env51544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env51543 == env51544) = true)

theorem identity51544 : scanCanonicalize (H12AffineFastState.compose env51544 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1322) := by decide +kernel

theorem selectedBound51544 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51545 : List Nat := [2,4,8,16,32,17,9,256,270,1024,1322,32,269,1312,0,263,1328,1039,1025,1,48,32,17,3,268,16,1322,1329,32,1038,1285,32,257,32,1312,271]

theorem envBound51545 : H12AffineFastState.Bounded env51545 := by
  intro p hp
  have h : env51545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51544_51545 : H12AffineEnvironment.transform 10 1322 env51544 = env51545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1322 env51544 == env51545) = true)

theorem identity51545 : scanCanonicalize (H12AffineFastState.compose env51545 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound51545 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51546 : List Nat := [2,4,8,16,32,17,9,31,17,1024,1077,32,18,1087,0,24,1071,1039,1025,1,48,32,17,3,19,16,1077,1070,32,1038,1050,32,30,32,1087,16]

theorem envBound51546 : H12AffineFastState.Bounded env51546 := by
  intro p hp
  have h : env51546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51545_51546 : H12AffineEnvironment.transform 7 31 env51545 = env51546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env51545 == env51546) = true)

theorem identity51546 : scanCanonicalize (H12AffineFastState.compose env51546 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound51546 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51547 : List Nat := [2,4,8,16,32,17,9,31,17,46,27,32,18,17,0,24,1,33,47,1,48,32,17,3,19,16,27,0,32,32,52,32,30,32,17,16]

theorem envBound51547 : H12AffineFastState.Bounded env51547 := by
  intro p hp
  have h : env51547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51546_51547 : H12AffineEnvironment.transform 9 46 env51546 = env51547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env51546 == env51547) = true)

theorem identity51547 : scanCanonicalize (H12AffineFastState.compose env51547 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51547 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51548 : List Nat := [2,4,8,1,32,0,9,14,0,46,10,32,3,0,0,9,1,33,47,1,33,32,0,3,2,1,10,0,32,32,37,32,15,32,0,1]

theorem envBound51548 : H12AffineFastState.Bounded env51548 := by
  intro p hp
  have h : env51548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51547_51548 : H12AffineEnvironment.transform 3 1 env51547 = env51548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51547 == env51548) = true)

theorem identity51548 : scanCanonicalize (H12AffineFastState.compose env51548 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound51548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51549 : List Nat := [2,4,8,1,5,0,9,14,0,11,10,5,3,0,0,9,1,4,10,1,4,5,0,3,2,1,10,0,5,5,0,5,15,5,0,1]

theorem envBound51549 : H12AffineFastState.Bounded env51549 := by
  intro p hp
  have h : env51549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51548_51549 : H12AffineEnvironment.transform 4 5 env51548 = env51549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env51548 == env51549) = true)

theorem identity51549 : scanCanonicalize (H12AffineFastState.compose env51549 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51549 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env51550 : List Nat := [2,4,2,1,5,0,3,4,0,1,0,5,3,0,0,3,1,4,0,1,4,5,0,3,2,1,0,0,5,5,0,5,5,5,0,1]

theorem envBound51550 : H12AffineFastState.Bounded env51550 := by
  intro p hp
  have h : env51550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51549_51550 : H12AffineEnvironment.transform 2 2 env51549 = env51550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51549 == env51550) = true)

theorem identity51550 : scanCanonicalize (H12AffineFastState.compose env51550 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51551 : List Nat := [2,3,2,1,2,0,3,3,0,1,0,2,3,0,0,3,1,3,0,1,3,2,0,3,2,1,0,0,2,2,0,2,2,2,0,1]

theorem envBound51551 : H12AffineFastState.Bounded env51551 := by
  intro p hp
  have h : env51551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51550_51551 : H12AffineEnvironment.transform 1 3 env51550 = env51551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51550 == env51551) = true)

def env51552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,33,147457,98645,8193,65,10589,152833,17664,43049,148804,177261,257,21792,46093,221723]

theorem envBound51552 : H12AffineFastState.Bounded env51552 := by
  intro p hp
  have h : env51552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51535_51552 : H12AffineEnvironment.transform 21 33 env51535 = env51552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51535 == env51552) = true)

theorem identity51552 : scanCanonicalize (H12AffineFastState.compose env51552 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51552 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,151633,33,147457,41311,8193,65,10589,152833,17664,43049,148804,177261,257,21792,46093,147985]

theorem envBound51553 : H12AffineFastState.Bounded env51553 := by
  intro p hp
  have h : env51553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51552_51553 : H12AffineEnvironment.transform 15 8202 env51552 = env51553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51552 == env51553) = true)

theorem identity51553 : scanCanonicalize (H12AffineFastState.compose env51553 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound51553 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env51554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24860,10280,1025,32769,12621,33,8477,41311,8193,65,10589,13341,17664,43049,9304,54641,257,21792,46093,8973]

theorem envBound51554 : H12AffineFastState.Bounded env51554 := by
  intro p hp
  have h : env51554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51553_51554 : H12AffineEnvironment.transform 16 24860 env51553 = env51554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env51553 == env51554) = true)

theorem identity51554 : scanCanonicalize (H12AffineFastState.compose env51554 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51554 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24860,10280,1025,8541,12621,33,8477,3,8193,65,10589,13341,17664,2421,9304,29741,257,21792,5457,8973]

theorem envBound51555 : H12AffineFastState.Bounded env51555 := by
  intro p hp
  have h : env51555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51554_51555 : H12AffineEnvironment.transform 14 8540 env51554 = env51555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51554 == env51555) = true)

theorem identity51555 : scanCanonicalize (H12AffineFastState.compose env51555 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51555 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env51556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,8202,5393,10280,1025,8541,12621,33,8477,3,8193,65,10589,13341,12557,2421,9304,32,257,8493,5457,8973]

theorem envBound51556 : H12AffineFastState.Bounded env51556 := by
  intro p hp
  have h : env51556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51555_51556 : H12AffineEnvironment.transform 13 13325 env51555 = env51556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51555 == env51556) = true)

theorem identity51556 : scanCanonicalize (H12AffineFastState.compose env51556 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51556 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51557 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8460,8202,5393,10280,1025,8461,12573,33,8477,3,8193,17,10509,13341,12557,2341,9224,32,257,8493,5377,8973]

theorem envBound51557 : H12AffineFastState.Bounded env51557 := by
  intro p hp
  have h : env51557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51556_51557 : H12AffineEnvironment.transform 5 16 env51556 = env51557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51556 == env51557) = true)

theorem identity51557 : scanCanonicalize (H12AffineFastState.compose env51557 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound51557 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env51558 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1337,4404,1077,1331,5393,3345,1025,1076,5156,33,1060,3,1336,17,3124,4388,5172,2341,305,32,257,1044,5377,1588]

theorem envBound51558 : H12AffineFastState.Bounded env51558 := by
  intro p hp
  have h : env51558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51557_51558 : H12AffineEnvironment.transform 12 1337 env51557 = env51558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env51557 == env51558) = true)

theorem identity51558 : scanCanonicalize (H12AffineFastState.compose env51558 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51558 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51559 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,1053,4112,1077,1047,5173,3125,1025,1076,5156,33,1060,3,1052,17,3124,4096,5172,2049,21,32,37,1044,5157,1588]

theorem envBound51559 : H12AffineFastState.Bounded env51559 := by
  intro p hp
  have h : env51559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51558_51559 : H12AffineEnvironment.transform 7 36 env51558 = env51559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51558 == env51559) = true)

theorem identity51559 : scanCanonicalize (H12AffineFastState.compose env51559 (packedSelected [2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 3104) := by decide +kernel

theorem selectedBound51559 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env51560 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3104,1053,3120,1077,1047,2069,3125,1025,1076,2052,33,1060,3,1052,17,3124,3104,2068,2049,21,32,37,1044,2053,1588]

theorem envBound51560 : H12AffineFastState.Bounded env51560 := by
  intro p hp
  have h : env51560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51559_51560 : H12AffineEnvironment.transform 11 3104 env51559 = env51560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3104 env51559 == env51560) = true)

theorem identity51560 : scanCanonicalize (H12AffineFastState.compose env51560 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound51560 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51561 : List Nat := [2,4,8,16,32,16,9,36,512,1024,12,1068,1053,1084,1077,1047,25,1081,1025,1076,8,33,1060,3,1052,17,1080,1068,24,13,21,32,37,1044,9,1588]

theorem envBound51561 : H12AffineFastState.Bounded env51561 := by
  intro p hp
  have h : env51561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51560_51561 : H12AffineEnvironment.transform 10 12 env51560 = env51561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env51560 == env51561) = true)

theorem identity51561 : scanCanonicalize (H12AffineFastState.compose env51561 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51561 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env51562 : List Nat := [2,4,8,16,32,16,9,36,512,53,12,25,40,9,0,34,25,12,52,1,8,33,17,3,41,17,13,25,24,13,21,32,37,33,9,513]

theorem envBound51562 : H12AffineFastState.Bounded env51562 := by
  intro p hp
  have h : env51562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51561_51562 : H12AffineEnvironment.transform 9 53 env51561 = env51562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51561 == env51562) = true)

theorem identity51562 : scanCanonicalize (H12AffineFastState.compose env51562 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound51562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51563 : List Nat := [2,4,8,16,5,16,9,1,512,16,12,25,13,9,0,7,25,12,17,1,8,4,17,3,12,17,13,25,24,13,21,5,0,4,9,513]

theorem envBound51563 : H12AffineFastState.Bounded env51563 := by
  intro p hp
  have h : env51563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51562_51563 : H12AffineEnvironment.transform 4 5 env51562 = env51563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env51562 == env51563) = true)

def env51564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,2347269,8193,65,6453548,152832,2233681,43049,2102548,4371533,257,21793,46092,2175563]

theorem envBound51564 : H12AffineFastState.Bounded env51564 := by
  intro p hp
  have h : env51564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51512_51564 : H12AffineEnvironment.transform 23 2347269 env51512 = env51564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347269 env51512 == env51564) = true)

def env51565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147457,98645,8193,65,4204924,152832,17665,43049,148804,4371533,257,21793,46092,221723]

theorem envBound51565 : H12AffineFastState.Bounded env51565 := by
  intro p hp
  have h : env51565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51564_51565 : H12AffineEnvironment.transform 20 151632 env51564 = env51565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env51564 == env51565) = true)

def env51566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,32,147457,98645,8193,65,10588,152832,17665,43049,148804,177261,257,21793,46092,221723]

theorem envBound51566 : H12AffineFastState.Bounded env51566 := by
  intro p hp
  have h : env51566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51565_51566 : H12AffineEnvironment.transform 21 32 env51565 = env51566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51565 == env51566) = true)

theorem identity51566 : scanCanonicalize (H12AffineFastState.compose env51566 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51566 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,32,73755,98645,8193,65,10588,79130,17665,43049,75102,119927,257,21793,46092,513]

theorem envBound51567 : H12AffineFastState.Bounded env51567 := by
  intro p hp
  have h : env51567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51566_51567 : H12AffineEnvironment.transform 16 90138 env51566 = env51567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51566 == env51567) = true)

theorem identity51567 : scanCanonicalize (H12AffineFastState.compose env51567 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51567 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,4160,32,17,41311,8193,65,10588,5392,17665,43049,1364,62589,257,21793,46092,513]

theorem envBound51568 : H12AffineFastState.Bounded env51568 := by
  intro p hp
  have h : env51568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51567_51568 : H12AffineEnvironment.transform 15 8202 env51567 = env51568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51567 == env51568) = true)

theorem identity51568 : scanCanonicalize (H12AffineFastState.compose env51568 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51568 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2341,1025,32769,4160,32,17,32850,268,65,2129,5392,17665,35108,1364,54640,257,21793,38145,513]

theorem envBound51569 : H12AffineFastState.Bounded env51569 := by
  intro p hp
  have h : env51569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51568_51569 : H12AffineEnvironment.transform 12 269 env51568 = env51569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51568 == env51569) = true)

theorem identity51569 : scanCanonicalize (H12AffineFastState.compose env51569 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound51569 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,263,16400,2341,1025,21841,4160,32,17,21762,268,65,2129,5392,17665,23668,1364,32,257,21793,16465,513]

theorem envBound51570 : H12AffineFastState.Bounded env51570 := by
  intro p hp
  have h : env51570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51569_51570 : H12AffineEnvironment.transform 14 21840 env51569 = env51570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env51569 == env51570) = true)

theorem identity51570 : scanCanonicalize (H12AffineFastState.compose env51570 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound51570 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,263,5440,2341,1025,1,4160,32,17,82,268,65,2129,5392,4177,2340,1364,32,257,113,5377,513]

theorem envBound51571 : H12AffineFastState.Bounded env51571 := by
  intro p hp
  have h : env51571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51570_51571 : H12AffineEnvironment.transform 13 5456 env51570 = env51571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env51570 == env51571) = true)

theorem identity51571 : scanCanonicalize (H12AffineFastState.compose env51571 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound51571 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51572 : List Nat := [2,4,8,16,32,64,9,256,350,1024,2048,4096,269,5456,0,263,5440,2341,1025,1,4160,32,17,82,268,65,2129,5392,4177,2340,1364,32,257,113,5377,351]

theorem envBound51572 : H12AffineFastState.Bounded env51572 := by
  intro p hp
  have h : env51572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51571_51572 : H12AffineEnvironment.transform 8 350 env51571 = env51572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env51571 == env51572) = true)

theorem identity51572 : scanCanonicalize (H12AffineFastState.compose env51572 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51572 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51573 : List Nat := [2,4,8,16,32,17,9,256,271,1024,2048,4096,269,5377,0,263,5393,2341,1025,1,4113,32,17,3,268,16,2048,5392,4096,2340,1285,32,257,32,5377,270]

theorem envBound51573 : H12AffineFastState.Bounded env51573 := by
  intro p hp
  have h : env51573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51572_51573 : H12AffineEnvironment.transform 5 17 env51572 = env51573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51572 == env51573) = true)

theorem identity51573 : scanCanonicalize (H12AffineFastState.compose env51573 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound51573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51574 : List Nat := [2,4,8,16,32,17,9,256,271,1024,2048,32,269,1313,0,263,1329,2341,1025,1,49,32,17,3,268,16,2048,1328,32,2340,1285,32,257,32,1313,270]

theorem envBound51574 : H12AffineFastState.Bounded env51574 := by
  intro p hp
  have h : env51574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51573_51574 : H12AffineEnvironment.transform 11 32 env51573 = env51574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env51573 == env51574) = true)

theorem identity51574 : scanCanonicalize (H12AffineFastState.compose env51574 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1322) := by decide +kernel

theorem selectedBound51574 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51575 : List Nat := [2,4,8,16,32,17,9,256,271,1024,1322,32,269,1313,0,263,1329,1039,1025,1,49,32,17,3,268,16,1322,1328,32,1038,1285,32,257,32,1313,270]

theorem envBound51575 : H12AffineFastState.Bounded env51575 := by
  intro p hp
  have h : env51575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51574_51575 : H12AffineEnvironment.transform 10 1322 env51574 = env51575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1322 env51574 == env51575) = true)

theorem identity51575 : scanCanonicalize (H12AffineFastState.compose env51575 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound51575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51576 : List Nat := [2,4,8,16,32,17,9,30,17,1024,1076,32,19,1087,0,25,1071,1039,1025,1,49,32,17,3,18,16,1076,1070,32,1038,1051,32,31,32,1087,16]

theorem envBound51576 : H12AffineFastState.Bounded env51576 := by
  intro p hp
  have h : env51576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51575_51576 : H12AffineEnvironment.transform 7 30 env51575 = env51576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env51575 == env51576) = true)

theorem identity51576 : scanCanonicalize (H12AffineFastState.compose env51576 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound51576 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51577 : List Nat := [2,4,8,16,32,17,9,30,17,47,27,32,19,16,0,25,0,32,46,1,49,32,17,3,18,16,27,1,32,33,52,32,31,32,16,16]

theorem envBound51577 : H12AffineFastState.Bounded env51577 := by
  intro p hp
  have h : env51577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51576_51577 : H12AffineEnvironment.transform 9 47 env51576 = env51577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env51576 == env51577) = true)

theorem identity51577 : scanCanonicalize (H12AffineFastState.compose env51577 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51577 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51578 : List Nat := [2,4,8,0,32,1,9,14,1,47,11,32,3,0,0,9,0,32,46,1,33,32,1,3,2,0,11,1,32,33,36,32,15,32,0,0]

theorem envBound51578 : H12AffineFastState.Bounded env51578 := by
  intro p hp
  have h : env51578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51577_51578 : H12AffineEnvironment.transform 3 0 env51577 = env51578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51577 == env51578) = true)

theorem identity51578 : scanCanonicalize (H12AffineFastState.compose env51578 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound51578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51579 : List Nat := [2,4,8,0,14,1,9,14,1,1,11,14,3,0,0,9,0,14,0,1,15,14,1,3,2,0,11,1,14,15,10,14,15,14,0,0]

theorem envBound51579 : H12AffineFastState.Bounded env51579 := by
  intro p hp
  have h : env51579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51578_51579 : H12AffineEnvironment.transform 4 14 env51578 = env51579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env51578 == env51579) = true)

theorem identity51579 : scanCanonicalize (H12AffineFastState.compose env51579 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51579 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env51580 : List Nat := [2,4,3,0,5,1,2,5,1,1,0,5,3,0,0,2,0,5,0,1,4,5,1,3,2,0,0,1,5,4,1,5,4,5,0,0]

theorem envBound51580 : H12AffineFastState.Bounded env51580 := by
  intro p hp
  have h : env51580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51579_51580 : H12AffineEnvironment.transform 2 3 env51579 = env51580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51579 == env51580) = true)

theorem identity51580 : scanCanonicalize (H12AffineFastState.compose env51580 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51580 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51581 : List Nat := [2,2,3,0,3,1,2,3,1,1,0,3,3,0,0,2,0,3,0,1,2,3,1,3,2,0,0,1,3,2,1,3,2,3,0,0]

theorem envBound51581 : H12AffineFastState.Bounded env51581 := by
  intro p hp
  have h : env51581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51580_51581 : H12AffineEnvironment.transform 1 2 env51580 = env51581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51580 == env51581) = true)

def env51582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,33,147457,98645,8193,65,10589,152832,17665,43049,148804,177260,257,21793,46092,221723]

theorem envBound51582 : H12AffineFastState.Bounded env51582 := by
  intro p hp
  have h : env51582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51565_51582 : H12AffineEnvironment.transform 21 33 env51565 = env51582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51565 == env51582) = true)

theorem identity51582 : scanCanonicalize (H12AffineFastState.compose env51582 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound51582 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4160,33,17,98645,8193,65,10589,5392,17665,43049,1364,62588,257,21793,46092,74251]

theorem envBound51583 : H12AffineFastState.Bounded env51583 := by
  intro p hp
  have h : env51583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51582_51583 : H12AffineEnvironment.transform 16 16400 env51582 = env51583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51582 == env51583) = true)

theorem identity51583 : scanCanonicalize (H12AffineFastState.compose env51583 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound51583 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54279,16400,10280,1025,32769,4160,33,17,21842,8193,65,10589,5392,17665,43049,1364,62588,257,21793,46092,62988]

theorem envBound51584 : H12AffineFastState.Bounded env51584 := by
  intro p hp
  have h : env51584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51583_51584 : H12AffineEnvironment.transform 15 54279 env51583 = env51584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env51583 == env51584) = true)

theorem identity51584 : scanCanonicalize (H12AffineFastState.compose env51584 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51584 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env51585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54279,16400,2421,1025,32769,4160,33,17,21842,348,65,2048,5392,17665,35188,1364,54561,257,21793,38225,55121]

theorem envBound51585 : H12AffineFastState.Bounded env51585 := by
  intro p hp
  have h : env51585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51584_51585 : H12AffineEnvironment.transform 12 349 env51584 = env51585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51584 == env51585) = true)

theorem identity51585 : scanCanonicalize (H12AffineFastState.compose env51585 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound51585 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,33111,5440,2421,1025,32769,4160,33,17,2,348,65,2048,5392,4177,35188,1364,32881,257,113,38225,33281]

theorem envBound51586 : H12AffineFastState.Bounded env51586 := by
  intro p hp
  have h : env51586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51585_51586 : H12AffineEnvironment.transform 13 5456 env51585 = env51586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env51585 == env51586) = true)

theorem identity51586 : scanCanonicalize (H12AffineFastState.compose env51586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound51586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,263,5440,2421,1025,81,4160,33,17,2,348,65,2048,5392,4177,2340,1364,33,257,113,5377,593]

theorem envBound51587 : H12AffineFastState.Bounded env51587 := by
  intro p hp
  have h : env51587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51586_51587 : H12AffineEnvironment.transform 14 80 env51586 = env51587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env51586 == env51587) = true)

theorem identity51587 : scanCanonicalize (H12AffineFastState.compose env51587 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1339) := by decide +kernel

theorem selectedBound51587 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1339,4096,349,5456,80,263,5440,1102,1025,81,4160,33,17,2,348,65,1339,5392,4177,1055,1364,33,257,113,5377,593]

theorem envBound51588 : H12AffineFastState.Bounded env51588 := by
  intro p hp
  have h : env51588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51587_51588 : H12AffineEnvironment.transform 10 1339 env51587 = env51588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1339 env51587 == env51588) = true)

theorem identity51588 : scanCanonicalize (H12AffineFastState.compose env51588 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 286) := by decide +kernel

theorem selectedBound51588 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env51589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1339,286,349,1102,80,263,1118,1102,1025,81,350,33,17,2,348,65,1339,1038,335,1055,1364,33,257,113,1055,593]

theorem envBound51589 : H12AffineFastState.Bounded env51589 := by
  intro p hp
  have h : env51589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51588_51589 : H12AffineEnvironment.transform 11 286 env51588 = env51589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 286 env51588 == env51589) = true)

theorem identity51589 : scanCanonicalize (H12AffineFastState.compose env51589 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51589 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51590 : List Nat := [2,4,8,16,17,64,9,256,512,1024,1290,286,349,1102,80,263,1118,1102,1025,81,350,16,17,2,348,65,1290,1038,335,1055,1364,16,257,64,1055,593]

theorem envBound51590 : H12AffineFastState.Bounded env51590 := by
  intro p hp
  have h : env51590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51589_51590 : H12AffineEnvironment.transform 4 17 env51589 = env51590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51589 == env51590) = true)

theorem identity51590 : scanCanonicalize (H12AffineFastState.compose env51590 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51590 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env51591 : List Nat := [2,4,8,16,17,64,9,5,512,1024,1039,27,88,1102,80,2,1118,1102,1025,81,91,16,17,2,89,65,1039,1038,74,1055,1105,16,4,64,1055,593]

theorem envBound51591 : H12AffineFastState.Bounded env51591 := by
  intro p hp
  have h : env51591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51590_51591 : H12AffineEnvironment.transform 7 5 env51590 = env51591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51590 == env51591) = true)

theorem identity51591 : scanCanonicalize (H12AffineFastState.compose env51591 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound51591 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51592 : List Nat := [2,4,8,16,17,1,9,5,512,1024,1039,27,25,1039,17,2,1055,1039,1025,16,26,16,17,2,24,0,1039,1038,11,1055,1040,16,4,1,1055,528]

theorem envBound51592 : H12AffineFastState.Bounded env51592 := by
  intro p hp
  have h : env51592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51591_51592 : H12AffineEnvironment.transform 5 1 env51591 = env51592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51591 == env51592) = true)

theorem identity51592 : scanCanonicalize (H12AffineFastState.compose env51592 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51592 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51593 : List Nat := [2,4,8,0,1,1,9,5,512,1024,1039,11,9,1039,1,2,1039,1039,1025,0,10,0,1,2,8,0,1039,1038,11,1039,1024,0,4,1,1039,512]

theorem envBound51593 : H12AffineFastState.Bounded env51593 := by
  intro p hp
  have h : env51593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51592_51593 : H12AffineEnvironment.transform 3 0 env51592 = env51593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51592 == env51593) = true)

theorem identity51593 : scanCanonicalize (H12AffineFastState.compose env51593 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound51593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51594 : List Nat := [2,4,8,0,1,1,9,5,512,14,1,11,9,1,1,2,1,1,15,0,10,0,1,2,8,0,1,0,11,1,14,0,4,1,1,512]

theorem envBound51594 : H12AffineFastState.Bounded env51594 := by
  intro p hp
  have h : env51594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51593_51594 : H12AffineEnvironment.transform 9 14 env51593 = env51594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env51593 == env51594) = true)

theorem identity51594 : scanCanonicalize (H12AffineFastState.compose env51594 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound51594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51595 : List Nat := [2,4,8,0,1,1,9,5,14,14,1,11,9,1,1,2,1,1,15,0,10,0,1,2,8,0,1,0,11,1,14,0,4,1,1,14]

theorem envBound51595 : H12AffineFastState.Bounded env51595 := by
  intro p hp
  have h : env51595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51594_51595 : H12AffineEnvironment.transform 8 14 env51594 = env51595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env51594 == env51595) = true)

theorem identity51595 : scanCanonicalize (H12AffineFastState.compose env51595 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound51595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51596 : List Nat := [2,4,6,0,1,1,7,5,0,0,1,5,7,1,1,2,1,1,1,0,4,0,1,2,6,0,1,0,5,1,0,0,4,1,1,0]

theorem envBound51596 : H12AffineFastState.Bounded env51596 := by
  intro p hp
  have h : env51596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51595_51596 : H12AffineEnvironment.transform 2 6 env51595 = env51596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env51595 == env51596) = true)

theorem identity51596 : scanCanonicalize (H12AffineFastState.compose env51596 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51597 : List Nat := [0,4,4,0,1,1,5,5,0,0,1,5,5,1,1,0,1,1,1,0,4,0,1,0,4,0,1,0,5,1,0,0,4,1,1,0]

theorem envBound51597 : H12AffineFastState.Bounded env51597 := by
  intro p hp
  have h : env51597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51596_51597 : H12AffineEnvironment.transform 0 0 env51596 = env51597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51596 == env51597) = true)

theorem identity51597 : scanCanonicalize (H12AffineFastState.compose env51597 (packedSelected [14] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51597 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env51598 : List Nat := [0,0,0,0,1,1,1,1,0,0,1,1,1,1,1,0,1,1,1,0,0,0,1,0,0,0,1,0,1,1,0,0,0,1,1,0]

theorem envBound51598 : H12AffineFastState.Bounded env51598 := by
  intro p hp
  have h : env51598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51597_51598 : H12AffineEnvironment.transform 1 0 env51597 = env51598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51597 == env51598) = true)

def env51599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147457,98644,8193,65,4204925,152832,17664,43049,148805,4371533,257,21793,46092,221722]

theorem envBound51599 : H12AffineFastState.Bounded env51599 := by
  intro p hp
  have h : env51599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51564_51599 : H12AffineEnvironment.transform 20 151633 env51564 = env51599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env51564 == env51599) = true)

theorem identity51599 : scanCanonicalize (H12AffineFastState.compose env51599 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51599 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env51600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,73754,98644,8193,65,4204925,79131,17664,43049,75102,4314198,257,21793,46092,513]

theorem envBound51600 : H12AffineFastState.Bounded env51600 := by
  intro p hp
  have h : env51600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51599_51600 : H12AffineEnvironment.transform 16 90139 env51599 = env51600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51599 == env51600) = true)

theorem identity51600 : scanCanonicalize (H12AffineFastState.compose env51600 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51600 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env51601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,4194304,73754,95496,8193,65,4204925,79131,17664,23669,75102,4268042,257,21793,16464,513]

theorem envBound51601 : H12AffineFastState.Bounded env51601 := by
  intro p hp
  have h : env51601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51600_51601 : H12AffineEnvironment.transform 14 29788 env51600 = env51601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51600 == env51601) = true)

def env51602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,32,73754,95496,8193,65,10589,79131,17664,23669,75102,73770,257,21793,16464,513]

theorem envBound51602 : H12AffineFastState.Bounded env51602 := by
  intro p hp
  have h : env51602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51601_51602 : H12AffineEnvironment.transform 21 32 env51601 = env51602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51601 == env51602) = true)

theorem identity51602 : scanCanonicalize (H12AffineFastState.compose env51602 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound51602 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,16448,10280,1025,29789,4113,32,65,21843,8193,65,10589,5440,17664,23669,1285,113,257,21793,16464,513]

theorem envBound51603 : H12AffineFastState.Bounded env51603 := by
  intro p hp
  have h : env51603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51602_51603 : H12AffineEnvironment.transform 15 8283 env51602 = env51603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env51602 == env51603) = true)

theorem identity51603 : scanCanonicalize (H12AffineFastState.compose env51603 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51603 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,342,16448,2341,1025,21840,4113,32,65,21843,268,65,2128,5440,17664,23669,1285,113,257,21793,16464,513]

theorem envBound51604 : H12AffineFastState.Bounded env51604 := by
  intro p hp
  have h : env51604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51603_51604 : H12AffineEnvironment.transform 12 269 env51603 = env51604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51603 == env51604) = true)

theorem identity51604 : scanCanonicalize (H12AffineFastState.compose env51604 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound51604 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,0,342,5393,2341,1025,1,4113,32,65,2,268,65,2128,5440,4177,2340,1285,113,257,112,5377,513]

theorem envBound51605 : H12AffineFastState.Bounded env51605 := by
  intro p hp
  have h : env51605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51604_51605 : H12AffineEnvironment.transform 13 5457 env51604 = env51605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env51604 == env51605) = true)

theorem identity51605 : scanCanonicalize (H12AffineFastState.compose env51605 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound51605 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,513,269,1872,0,342,1808,2341,1025,1,528,32,65,2,268,65,2128,1857,592,2340,1285,113,257,112,1792,513]

theorem envBound51606 : H12AffineFastState.Bounded env51606 := by
  intro p hp
  have h : env51606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51605_51606 : H12AffineEnvironment.transform 11 513 env51605 = env51606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env51605 == env51606) = true)

def env51607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,33,73754,95496,8193,65,10588,79131,17664,23669,75102,73771,257,21793,16464,513]

theorem envBound51607 : H12AffineFastState.Bounded env51607 := by
  intro p hp
  have h : env51607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51601_51607 : H12AffineEnvironment.transform 21 33 env51601 = env51607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51601 == env51607) = true)

theorem identity51607 : scanCanonicalize (H12AffineFastState.compose env51607 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound51607 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21510,13341,10280,1025,29789,25676,33,29724,8462,8193,65,10588,24861,17664,23669,29016,29741,257,21793,16464,513]

theorem envBound51608 : H12AffineFastState.Bounded env51608 := by
  intro p hp
  have h : env51608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51607_51608 : H12AffineEnvironment.transform 15 21510 env51607 = env51608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env51607 == env51608) = true)

theorem identity51608 : scanCanonicalize (H12AffineFastState.compose env51608 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51608 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8203,13341,10280,1025,80,4161,33,17,8462,8193,65,10588,5392,12557,10360,1365,32,257,8492,13405,513]

theorem envBound51609 : H12AffineFastState.Bounded env51609 := by
  intro p hp
  have h : env51609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51608_51609 : H12AffineEnvironment.transform 13 13325 env51608 = env51609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51608 == env51609) = true)

theorem identity51609 : scanCanonicalize (H12AffineFastState.compose env51609 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51609 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,342,5440,2421,1025,80,4161,33,17,83,348,65,2049,5392,4176,2341,1365,32,257,113,5376,513]

theorem envBound51610 : H12AffineFastState.Bounded env51610 := by
  intro p hp
  have h : env51610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51609_51610 : H12AffineEnvironment.transform 12 349 env51609 = env51610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51609 == env51610) = true)

theorem identity51610 : scanCanonicalize (H12AffineFastState.compose env51610 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51610 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51611 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4112,33,17,2,269,16,2049,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound51611 : H12AffineFastState.Bounded env51611 := by
  intro p hp
  have h : env51611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51610_51611 : H12AffineEnvironment.transform 5 17 env51610 = env51611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51610 == env51611) = true)

theorem identity51611 : scanCanonicalize (H12AffineFastState.compose env51611 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound51611 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51612 : List Nat := [2,4,8,16,32,17,9,256,512,288,2048,4096,268,4129,0,263,4145,2340,289,1,4112,33,17,2,269,16,2049,4144,4097,2341,36,32,257,32,4128,513]

theorem envBound51612 : H12AffineFastState.Bounded env51612 := by
  intro p hp
  have h : env51612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51611_51612 : H12AffineEnvironment.transform 9 288 env51611 = env51612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env51611 == env51612) = true)

theorem identity51612 : scanCanonicalize (H12AffineFastState.compose env51612 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound51612 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51613 : List Nat := [2,4,8,16,32,17,9,256,292,288,2048,4096,268,4129,0,263,4145,2340,289,1,4112,33,17,2,269,16,2049,4144,4097,2341,36,32,257,32,4128,293]

theorem envBound51613 : H12AffineFastState.Bounded env51613 := by
  intro p hp
  have h : env51613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51612_51613 : H12AffineEnvironment.transform 8 292 env51612 = env51613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env51612 == env51613) = true)

theorem identity51613 : scanCanonicalize (H12AffineFastState.compose env51613 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound51613 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51614 : List Nat := [2,4,8,16,32,17,9,256,292,288,2048,2081,268,2048,0,263,2064,2340,289,1,2097,33,17,2,269,16,2049,2065,2080,2341,36,32,257,32,2049,293]

theorem envBound51614 : H12AffineFastState.Bounded env51614 := by
  intro p hp
  have h : env51614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51613_51614 : H12AffineEnvironment.transform 11 2081 env51613 = env51614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env51613 == env51614) = true)

theorem identity51614 : scanCanonicalize (H12AffineFastState.compose env51614 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51614 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51615 : List Nat := [2,4,8,16,1,17,9,256,261,257,2048,2048,268,2048,0,263,2064,2309,256,1,2064,0,17,2,269,16,2049,2065,2049,2308,5,1,257,1,2049,260]

theorem envBound51615 : H12AffineFastState.Bounded env51615 := by
  intro p hp
  have h : env51615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51614_51615 : H12AffineEnvironment.transform 4 1 env51614 = env51615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51614 == env51615) = true)

theorem identity51615 : scanCanonicalize (H12AffineFastState.compose env51615 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound51615 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51616 : List Nat := [2,4,8,16,1,17,9,256,261,257,17,17,268,17,0,263,1,276,256,1,1,0,17,2,269,16,16,0,16,277,5,1,257,1,16,260]

theorem envBound51616 : H12AffineFastState.Bounded env51616 := by
  intro p hp
  have h : env51616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51615_51616 : H12AffineEnvironment.transform 10 17 env51615 = env51616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env51615 == env51616) = true)

theorem identity51616 : scanCanonicalize (H12AffineFastState.compose env51616 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51617 : List Nat := [2,4,8,16,1,17,9,20,17,21,17,17,24,17,0,19,1,0,20,1,1,0,17,2,25,16,16,0,16,1,5,1,21,1,16,16]

theorem envBound51617 : H12AffineFastState.Bounded env51617 := by
  intro p hp
  have h : env51617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51616_51617 : H12AffineEnvironment.transform 7 20 env51616 = env51617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51616 == env51617) = true)

theorem identity51617 : scanCanonicalize (H12AffineFastState.compose env51617 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51617 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env51618 : List Nat := [2,4,8,0,1,1,9,4,1,5,1,1,8,1,0,3,1,0,4,1,1,0,1,2,9,0,0,0,0,1,5,1,5,1,0,0]

theorem envBound51618 : H12AffineFastState.Bounded env51618 := by
  intro p hp
  have h : env51618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51617_51618 : H12AffineEnvironment.transform 3 0 env51617 = env51618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51617 == env51618) = true)

def env51619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound51619 : H12AffineFastState.Bounded env51619 := by
  intro p hp
  have h : env51619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49936_51619 : H12AffineEnvironment.transform 29 155254785 env49936 = env51619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env49936 == env51619) = true)

def env51620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound51620 : H12AffineFastState.Bounded env51620 := by
  intro p hp
  have h : env51620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51619_51620 : H12AffineEnvironment.transform 25 64 env51619 = env51620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env51619 == env51620) = true)

def env51621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound51621 : H12AffineFastState.Bounded env51621 := by
  intro p hp
  have h : env51621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51620_51621 : H12AffineEnvironment.transform 26 30393344 env51620 = env51621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env51620 == env51621) = true)

def env51622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound51622 : H12AffineFastState.Bounded env51622 := by
  intro p hp
  have h : env51622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51621_51622 : H12AffineEnvironment.transform 18 1024 env51621 = env51622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env51621 == env51622) = true)

theorem identity51622 : scanCanonicalize (H12AffineFastState.compose env51622 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577240) := by decide +kernel

theorem selectedBound51622 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577240,8328,64,6727000,8446421,10507601,8830977,2154825,12583064,256,41460,16464,2213535]

theorem envBound51623 : H12AffineFastState.Bounded env51623 := by
  intro p hp
  have h : env51623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51622_51623 : H12AffineEnvironment.transform 23 10577240 env51622 = env51623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577240 env51622 == env51623) = true)

def env51624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,4194304,8388608,10577240,8328,64,6705548,8393985,10507601,8795349,2102685,12583064,256,21792,16464,2175563]

theorem envBound51624 : H12AffineFastState.Bounded env51624 := by
  intro p hp
  have h : env51624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51623_51624 : H12AffineEnvironment.transform 14 29908 env51623 = env51624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env51623 == env51624) = true)

def env51625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272512,8388608,10577240,8328,64,2259212,8393985,10507601,8795349,2102685,8661016,256,21792,16464,2175563]

theorem envBound51625 : H12AffineFastState.Bounded env51625 := by
  intro p hp
  have h : env51625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51624_51625 : H12AffineEnvironment.transform 21 272512 env51624 = env51625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51624 == env51625) = true)

def env51626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272512,8388608,10563672,8328,64,2239500,8393985,10485841,8795349,2102685,8661016,256,32,5456,2175563]

theorem envBound51626 : H12AffineFastState.Bounded env51626 := by
  intro p hp
  have h : env51626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51625_51626 : H12AffineEnvironment.transform 13 5376 env51625 = env51626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51625 == env51626) = true)

def env51627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,2097152,32,8388608,10563672,8328,64,2239500,8393985,10485841,8526965,2102685,8388792,256,32,5456,2175563]

theorem envBound51627 : H12AffineFastState.Bounded env51627 := by
  intro p hp
  have h : env51627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51626_51627 : H12AffineEnvironment.transform 17 10400 env51626 = env51627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env51626 == env51627) = true)

def env51628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,2097152,32,136448,2303320,8328,64,2239500,131073,2233681,2421,2102685,136632,256,32,5456,2175563]

theorem envBound51628 : H12AffineFastState.Bounded env51628 := by
  intro p hp
  have h : env51628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51627_51628 : H12AffineEnvironment.transform 22 136448 env51627 = env51628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env51627 == env51628) = true)

theorem identity51628 : scanCanonicalize (H12AffineFastState.compose env51628 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51628 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env51629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,77898,32,136448,136466,8328,64,203846,131073,206107,2421,75223,136632,256,32,5456,513]

theorem envBound51629 : H12AffineFastState.Bounded env51629 := by
  intro p hp
  have h : env51629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51628_51629 : H12AffineEnvironment.transform 20 77898 env51628 = env51629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51628 == env51629) = true)

theorem identity51629 : scanCanonicalize (H12AffineFastState.compose env51629 (packedSelected [1,3,4,5,7,8,9,12,14,16,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound51629 : packedSelected [1,3,4,5,7,8,9,12,14,16,18,27] rootPS < 2^1333 := by decide +kernel

def env51630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5576,10400,1024,8661,77898,32,200,218,8328,64,67982,5577,78035,2421,75223,112,256,32,5456,513]

theorem envBound51630 : H12AffineFastState.Bounded env51630 := by
  intro p hp
  have h : env51630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51629_51630 : H12AffineEnvironment.transform 16 5576 env51629 = env51630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env51629 == env51630) = true)

theorem identity51630 : scanCanonicalize (H12AffineFastState.compose env51630 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51630 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,65536,5529,10400,1024,8580,77851,32,153,139,8328,17,67982,5528,77954,2340,75142,33,256,32,5377,513]

theorem envBound51631 : H12AffineFastState.Bounded env51631 := by
  intro p hp
  have h : env51631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51630_51631 : H12AffineEnvironment.transform 5 17 env51630 = env51631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51630 == env51631) = true)

theorem identity51631 : scanCanonicalize (H12AffineFastState.compose env51631 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound51631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,65536,5529,2341,1024,1,70046,32,153,139,269,17,67982,5528,69895,2340,66563,33,256,32,5377,513]

theorem envBound51632 : H12AffineFastState.Bounded env51632 := by
  intro p hp
  have h : env51632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51631_51632 : H12AffineEnvironment.transform 12 389 env51631 = env51632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env51631 == env51632) = true)

theorem identity51632 : scanCanonicalize (H12AffineFastState.compose env51632 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound51632 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,399,5529,2341,1024,1,4113,32,153,139,269,17,2049,5528,4232,2340,1420,33,256,32,5377,513]

theorem envBound51633 : H12AffineFastState.Bounded env51633 := by
  intro p hp
  have h : env51633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51632_51633 : H12AffineEnvironment.transform 15 399 env51632 = env51633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env51632 == env51633) = true)

theorem identity51633 : scanCanonicalize (H12AffineFastState.compose env51633 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51633 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51634 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,389,4112,0,399,4233,2341,272,1,4113,32,153,139,269,17,2049,4232,4232,2340,156,33,256,32,4113,513]

theorem envBound51634 : H12AffineFastState.Bounded env51634 := by
  intro p hp
  have h : env51634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51633_51634 : H12AffineEnvironment.transform 9 272 env51633 = env51634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51633 == env51634) = true)

theorem identity51634 : scanCanonicalize (H12AffineFastState.compose env51634 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51634 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51635 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,4096,161,4112,0,171,4233,2049,52,1,4113,32,153,139,41,17,2049,4232,4232,2048,156,33,36,32,4113,513]

theorem envBound51635 : H12AffineFastState.Bounded env51635 := by
  intro p hp
  have h : env51635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51634_51635 : H12AffineEnvironment.transform 7 36 env51634 = env51635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51634 == env51635) = true)

theorem identity51635 : scanCanonicalize (H12AffineFastState.compose env51635 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51636 : List Nat := [2,4,8,16,0,17,128,4,512,20,2048,4096,129,4112,0,139,4233,2049,20,1,4113,0,153,139,9,17,2049,4232,4232,2048,156,1,4,0,4113,513]

theorem envBound51636 : H12AffineFastState.Bounded env51636 := by
  intro p hp
  have h : env51636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51635_51636 : H12AffineEnvironment.transform 4 0 env51635 = env51636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51635 == env51636) = true)

def env51637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,2097152,32,136449,2303321,8328,64,2239500,131072,2233680,2420,2102685,136633,256,32,5456,2175563]

theorem envBound51637 : H12AffineFastState.Bounded env51637 := by
  intro p hp
  have h : env51637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51627_51637 : H12AffineEnvironment.transform 22 136449 env51627 = env51637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env51627 == env51637) = true)

def env51638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,2097152,32,136449,2303321,8192,64,2239500,131072,2233680,2420,2102549,136497,256,32,5456,2175563]

theorem envBound51638 : H12AffineFastState.Bounded env51638 := by
  intro p hp
  have h : env51638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51637_51638 : H12AffineEnvironment.transform 6 8 env51637 = env51638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51637 == env51638) = true)

theorem identity51638 : scanCanonicalize (H12AffineFastState.compose env51638 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(20+1) ^^^ 139548) := by decide +kernel

theorem selectedBound51638 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env51639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,139548,32,136449,66629,8192,64,3344,131072,13388,2420,144393,136497,256,32,5456,201559]

theorem envBound51639 : H12AffineFastState.Bounded env51639 := by
  intro p hp
  have h : env51639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51638_51639 : H12AffineEnvironment.transform 20 139548 env51638 = env51639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 139548 env51638 == env51639) = true)

theorem identity51639 : scanCanonicalize (H12AffineFastState.compose env51639 (packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound51639 : packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS < 2^1333 := by decide +kernel

def env51640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5376,1076,65536,131072,3392,1024,1077,132212,32,136449,66629,1384,64,3344,131072,4388,2420,135521,136497,256,32,5456,201559]

theorem envBound51640 : H12AffineFastState.Bounded env51640 := by
  intro p hp
  have h : env51640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51639_51640 : H12AffineEnvironment.transform 12 1384 env51639 = env51640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env51639 == env51640) = true)

theorem identity51640 : scanCanonicalize (H12AffineFastState.compose env51640 (packedSelected [3,7,10,14,16,18,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound51640 : packedSelected [3,7,10,14,16,18,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5376,1076,65536,4176,3392,1024,1077,5156,32,1361,66629,1384,64,3344,4176,4388,2420,305,1377,256,32,5456,66311]

theorem envBound51641 : H12AffineFastState.Bounded env51641 := by
  intro p hp
  have h : env51641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51640_51641 : H12AffineEnvironment.transform 16 4176 env51640 = env51641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env51640 == env51641) = true)

theorem identity51641 : scanCanonicalize (H12AffineFastState.compose env51641 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51641 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51642 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,4113,293,65536,4176,2129,273,292,4405,32,64,65876,121,64,2049,4176,4388,2420,305,112,256,32,4161,66311]

theorem envBound51642 : H12AffineFastState.Bounded env51642 := by
  intro p hp
  have h : env51642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51641_51642 : H12AffineEnvironment.transform 9 273 env51641 = env51642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51641 == env51642) = true)

theorem identity51642 : scanCanonicalize (H12AffineFastState.compose env51642 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound51642 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env51643 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,4113,293,342,4176,2129,273,292,4405,32,64,2,121,64,2049,4176,4388,2420,305,112,256,32,4161,593]

theorem envBound51643 : H12AffineFastState.Bounded env51643 := by
  intro p hp
  have h : env51643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51642_51643 : H12AffineEnvironment.transform 15 342 env51642 = env51643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env51642 == env51643) = true)

theorem identity51643 : scanCanonicalize (H12AffineFastState.compose env51643 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound51643 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env51644 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2113,121,2128,293,342,2065,2129,273,292,2420,32,64,2,121,64,2049,2065,2405,2420,305,112,256,32,2048,593]

theorem envBound51644 : H12AffineFastState.Bounded env51644 := by
  intro p hp
  have h : env51644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51643_51644 : H12AffineEnvironment.transform 11 2113 env51643 = env51644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env51643 == env51644) = true)

theorem identity51644 : scanCanonicalize (H12AffineFastState.compose env51644 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound51644 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51645 : List Nat := [2,4,8,16,32,64,8,256,512,273,372,309,121,292,293,342,357,293,273,292,0,32,64,2,121,64,373,357,17,0,305,112,256,32,372,593]

theorem envBound51645 : H12AffineFastState.Bounded env51645 := by
  intro p hp
  have h : env51645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51644_51645 : H12AffineEnvironment.transform 10 372 env51644 = env51645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env51644 == env51645) = true)

theorem identity51645 : scanCanonicalize (H12AffineFastState.compose env51645 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51645 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51646 : List Nat := [2,4,8,16,32,16,8,256,512,273,292,309,41,292,293,262,309,293,273,292,0,32,16,2,41,16,293,309,17,0,305,32,256,32,292,513]

theorem envBound51646 : H12AffineFastState.Bounded env51646 := by
  intro p hp
  have h : env51646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51645_51646 : H12AffineEnvironment.transform 5 16 env51645 = env51646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51645 == env51646) = true)

def env51647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,2097152,32,136449,2303321,8193,64,2239500,131072,2233680,2420,2102548,136496,256,32,5456,2175563]

theorem envBound51647 : H12AffineFastState.Bounded env51647 := by
  intro p hp
  have h : env51647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51637_51647 : H12AffineEnvironment.transform 6 9 env51637 = env51647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51637 == env51647) = true)

theorem identity51647 : scanCanonicalize (H12AffineFastState.compose env51647 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(20+1) ^^^ 132433) := by decide +kernel

theorem selectedBound51647 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env51648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,132433,32,136449,73736,8193,64,10589,131072,4097,2420,135237,136496,256,32,5456,210714]

theorem envBound51648 : H12AffineFastState.Bounded env51648 := by
  intro p hp
  have h : env51648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51647_51648 : H12AffineEnvironment.transform 20 132433 env51647 = env51648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132433 env51647 == env51648) = true)

theorem identity51648 : scanCanonicalize (H12AffineFastState.compose env51648 (packedSelected [1,8,19] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound51648 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env51649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,70727,10281,1024,8540,69910,32,65862,73736,8193,64,10589,70727,4097,2420,66562,65911,256,32,5456,9053]

theorem envBound51649 : H12AffineFastState.Bounded env51649 := by
  intro p hp
  have h : env51649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51648_51649 : H12AffineEnvironment.transform 16 70727 env51648 = env51649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env51648 == env51649) = true)

theorem identity51649 : scanCanonicalize (H12AffineFastState.compose env51649 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51649 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,65536,70727,2420,1024,1,69910,32,65862,65877,348,64,2048,70727,4097,2420,66562,65911,256,32,5456,512]

theorem envBound51650 : H12AffineFastState.Bounded env51650 := by
  intro p hp
  have h : env51650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51649_51650 : H12AffineEnvironment.transform 12 349 env51649 = env51650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51649 == env51650) = true)

theorem identity51650 : scanCanonicalize (H12AffineFastState.compose env51650 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51650 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51651 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,0,65536,70727,2388,1024,1,69910,0,65862,65877,348,64,2048,70727,4097,2388,66562,65879,256,0,5456,512]

theorem envBound51651 : H12AffineFastState.Bounded env51651 := by
  intro p hp
  have h : env51651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51650_51651 : H12AffineEnvironment.transform 4 0 env51650 = env51651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51650 == env51651) = true)

theorem identity51651 : scanCanonicalize (H12AffineFastState.compose env51651 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 2648) := by decide +kernel

theorem selectedBound51651 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env51652 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,0,2648,7711,2388,1024,1,6990,0,2846,2829,348,64,2048,7711,4097,2388,3674,2831,256,0,5456,512]

theorem envBound51652 : H12AffineFastState.Bounded env51652 := by
  intro p hp
  have h : env51652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51651_51652 : H12AffineEnvironment.transform 15 2648 env51651 = env51652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2648 env51651 == env51652) = true)

theorem identity51652 : scanCanonicalize (H12AffineFastState.compose env51652 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

end H12CloudChart0