import H12CloudChart0Data091

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound23261 : H12AffineFastState.Bounded env23261 := by
  intro p hp
  have h : env23261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23260_23261 : H12AffineEnvironment.transform 9 564 env23260 = env23261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env23260 == env23261) = true)

theorem identity23261 : scanCanonicalize (H12AffineFastState.compose env23261 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23261 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23262 : List Nat := [2,4,8,16,1,16,9,256,512,533,277,261,269,528,1,263,512,16,532,0,276,1,16,2,268,17,276,512,261,17,785,1,257,0,529,513]

theorem envBound23262 : H12AffineFastState.Bounded env23262 := by
  intro p hp
  have h : env23262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23261_23262 : H12AffineEnvironment.transform 4 1 env23261 = env23262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23261 == env23262) = true)

theorem identity23262 : scanCanonicalize (H12AffineFastState.compose env23262 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23263 : List Nat := [2,4,8,16,1,16,9,5,512,533,16,0,8,528,1,2,512,16,532,0,17,1,16,2,9,17,17,512,0,17,532,1,4,0,529,513]

theorem envBound23263 : H12AffineFastState.Bounded env23263 := by
  intro p hp
  have h : env23263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23262_23263 : H12AffineEnvironment.transform 7 5 env23262 = env23263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23262 == env23263) = true)

def env23264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,17,98780,8328,65,4365616,5393,17665,138477,1501,4256861,257,21793,46212,74251]

theorem envBound23264 : H12AffineFastState.Bounded env23264 := by
  intro p hp
  have h : env23264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23243_23264 : H12AffineEnvironment.transform 22 17 env23243 = env23264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23243 == env23264) = true)

theorem identity23264 : scanCanonicalize (H12AffineFastState.compose env23264 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23264 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56572,1025,32769,4161,4194304,17,41430,8328,65,4365616,5393,17665,138477,1501,4256861,257,21793,46212,513]

theorem envBound23265 : H12AffineFastState.Bounded env23265 := by
  intro p hp
  have h : env23265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23264_23265 : H12AffineEnvironment.transform 15 8202 env23264 = env23265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23264 == env23265) = true)

theorem identity23265 : scanCanonicalize (H12AffineFastState.compose env23265 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound23265 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56572,1025,32769,4161,112,17,41430,8328,65,171328,5393,17665,138477,1501,62509,257,21793,46212,513]

theorem envBound23266 : H12AffineFastState.Bounded env23266 := by
  intro p hp
  have h : env23266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23265_23266 : H12AffineEnvironment.transform 21 112 env23265 = env23266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env23265 == env23266) = true)

def env23267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4161,112,17,41310,8192,65,171328,5393,17665,138341,1365,62509,257,21793,46092,513]

theorem envBound23267 : H12AffineFastState.Bounded env23267 := by
  intro p hp
  have h : env23267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23266_23267 : H12AffineEnvironment.transform 6 8 env23266 = env23267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23266 == env23267) = true)

theorem identity23267 : scanCanonicalize (H12AffineFastState.compose env23267 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23267 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,32040,1025,8541,4161,112,17,2,8192,65,146460,5393,17665,138341,1365,21873,257,21793,5456,513]

theorem envBound23268 : H12AffineFastState.Bounded env23268 := by
  intro p hp
  have h : env23268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23267_23268 : H12AffineEnvironment.transform 14 8540 env23267 = env23268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23267 == env23268) = true)

theorem identity23268 : scanCanonicalize (H12AffineFastState.compose env23268 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23268 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23269 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,8202,131072,30777,272,8541,4161,112,17,2,8192,65,145677,4096,16400,137588,68,20576,257,20528,4161,513]

theorem envBound23269 : H12AffineFastState.Bounded env23269 := by
  intro p hp
  have h : env23269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23268_23269 : H12AffineEnvironment.transform 9 273 env23268 = env23269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23268 == env23269) = true)

theorem identity23269 : scanCanonicalize (H12AffineFastState.compose env23269 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound23269 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env23270 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8540,8202,131072,2129,272,8541,4161,112,17,2,8192,65,145677,4096,12408,137588,68,8200,257,8280,4161,513]

theorem envBound23270 : H12AffineFastState.Bounded env23270 := by
  intro p hp
  have h : env23270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23269_23270 : H12AffineEnvironment.transform 13 12392 env23269 = env23270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env23269 == env23270) = true)

theorem identity23270 : scanCanonicalize (H12AffineFastState.compose env23270 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 12408) := by decide +kernel

theorem selectedBound23270 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env23271 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8540,8202,12408,2129,272,8541,4161,112,17,2,8192,65,2421,4096,12408,10508,68,8200,257,8280,4161,513]

theorem envBound23271 : H12AffineFastState.Bounded env23271 := by
  intro p hp
  have h : env23271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23270_23271 : H12AffineEnvironment.transform 16 12408 env23270 = env23271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12408 env23270 == env23271) = true)

theorem identity23271 : scanCanonicalize (H12AffineFastState.compose env23271 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound23271 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23272 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4112,292,114,4096,2129,272,293,4161,112,17,2,120,65,2421,4096,4096,2420,68,112,257,32,4161,513]

theorem envBound23272 : H12AffineFastState.Bounded env23272 := by
  intro p hp
  have h : env23272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23271_23272 : H12AffineEnvironment.transform 12 120 env23271 = env23272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env23271 == env23272) = true)

def env23273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4161,112,17,41311,8193,65,171328,5393,17665,138340,1364,62509,257,21793,46093,513]

theorem envBound23273 : H12AffineFastState.Bounded env23273 := by
  intro p hp
  have h : env23273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23266_23273 : H12AffineEnvironment.transform 6 9 env23266 = env23273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23266 == env23273) = true)

def env23274 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4113,32,17,41231,8193,17,171280,5393,17665,138292,1284,62509,257,21793,46093,513]

theorem envBound23274 : H12AffineFastState.Bounded env23274 := by
  intro p hp
  have h : env23274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23273_23274 : H12AffineEnvironment.transform 5 16 env23273 = env23274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23273 == env23274) = true)

theorem identity23274 : scanCanonicalize (H12AffineFastState.compose env23274 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23274 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env23275 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,131072,23589,1025,1,4113,32,17,8463,8193,17,138512,5393,17665,138292,1284,29741,257,21793,13325,513]

theorem envBound23275 : H12AffineFastState.Bounded env23275 := by
  intro p hp
  have h : env23275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23274_23275 : H12AffineEnvironment.transform 14 0 env23274 = env23275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23274 == env23275) = true)

theorem identity23275 : scanCanonicalize (H12AffineFastState.compose env23275 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound23275 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23276 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,13340,23589,1025,1,4113,32,17,8463,8193,17,10508,5393,17665,10280,1284,29741,257,21793,13325,513]

theorem envBound23276 : H12AffineFastState.Bounded env23276 := by
  intro p hp
  have h : env23276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23275_23276 : H12AffineEnvironment.transform 16 13340 env23275 = env23276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env23275 == env23276) = true)

theorem identity23276 : scanCanonicalize (H12AffineFastState.compose env23276 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23277 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,8202,13340,2341,1025,1,4113,32,17,8463,8193,17,10508,5393,4097,10280,1284,8493,257,33,13325,513]

theorem envBound23277 : H12AffineFastState.Bounded env23277 := by
  intro p hp
  have h : env23277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23276_23277 : H12AffineEnvironment.transform 13 5376 env23276 = env23277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23276 == env23277) = true)

theorem identity23277 : scanCanonicalize (H12AffineFastState.compose env23277 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound23277 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23278 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,8192,3125,0,8202,11561,2341,1025,1,2340,32,17,8463,8193,17,10508,3108,2356,10280,1284,8493,257,33,11576,513]

theorem envBound23278 : H12AffineFastState.Bounded env23278 := by
  intro p hp
  have h : env23278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23277_23278 : H12AffineEnvironment.transform 11 2357 env23277 = env23278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env23277 == env23278) = true)

theorem identity23278 : scanCanonicalize (H12AffineFastState.compose env23278 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound23278 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env23279 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,1069,3125,0,1063,2308,2341,1025,1,2340,32,17,1314,1068,17,3361,3108,2356,3077,1284,1280,257,33,2325,513]

theorem envBound23279 : H12AffineFastState.Bounded env23279 := by
  intro p hp
  have h : env23279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23278_23279 : H12AffineEnvironment.transform 12 1069 env23278 = env23279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env23278 == env23279) = true)

theorem identity23279 : scanCanonicalize (H12AffineFastState.compose env23279 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound23279 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23280 : List Nat := [2,4,8,16,32,16,9,256,512,1024,16,293,1069,1061,0,1063,276,309,1025,1,308,32,17,1314,1068,17,1329,1076,292,1045,1284,1280,257,33,261,513]

theorem envBound23280 : H12AffineFastState.Bounded env23280 := by
  intro p hp
  have h : env23280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23279_23280 : H12AffineEnvironment.transform 10 16 env23279 = env23280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env23279 == env23280) = true)

theorem identity23280 : scanCanonicalize (H12AffineFastState.compose env23280 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23280 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env23281 : List Nat := [2,4,8,16,32,16,9,4,512,1024,16,33,1069,1061,0,1063,16,49,1025,1,48,32,17,1062,1068,17,1077,1076,32,1045,1024,1028,5,33,1,513]

theorem envBound23281 : H12AffineFastState.Bounded env23281 := by
  intro p hp
  have h : env23281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23280_23281 : H12AffineEnvironment.transform 7 4 env23280 = env23281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23280 == env23281) = true)

theorem identity23281 : scanCanonicalize (H12AffineFastState.compose env23281 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound23281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23282 : List Nat := [2,4,8,16,32,16,9,4,512,5,16,33,40,32,0,34,16,49,4,1,48,32,17,35,41,17,48,49,32,16,5,1,5,33,1,513]

theorem envBound23282 : H12AffineFastState.Bounded env23282 := by
  intro p hp
  have h : env23282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23281_23282 : H12AffineEnvironment.transform 9 5 env23281 = env23282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env23281 == env23282) = true)

def env23283 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4112,33,17,41230,8193,16,171281,5393,17665,138293,1285,62509,257,21793,46093,513]

theorem envBound23283 : H12AffineFastState.Bounded env23283 := by
  intro p hp
  have h : env23283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23273_23283 : H12AffineEnvironment.transform 5 17 env23273 = env23283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23273 == env23283) = true)

theorem identity23283 : scanCanonicalize (H12AffineFastState.compose env23283 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound23283 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env23284 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,13341,56356,1025,32769,4112,33,17,41230,8193,16,43276,5393,17665,10280,1285,62509,257,21793,46093,513]

theorem envBound23284 : H12AffineFastState.Bounded env23284 := by
  intro p hp
  have h : env23284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23283_23284 : H12AffineEnvironment.transform 16 13341 env23283 = env23284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env23283 == env23284) = true)

theorem identity23284 : scanCanonicalize (H12AffineFastState.compose env23284 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound23284 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23285 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,13341,10281,1025,29708,4112,33,17,21763,8193,16,23809,5393,17665,10280,1285,32,257,21793,16384,513]

theorem envBound23285 : H12AffineFastState.Bounded env23285 := by
  intro p hp
  have h : env23285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23284_23285 : H12AffineEnvironment.transform 14 29709 env23284 = env23285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env23284 == env23285) = true)

def env23286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458737,8393985,10507601,8527101,2102685,12645453,257,21792,46213,2175563]

theorem envBound23286 : H12AffineFastState.Bounded env23286 := by
  intro p hp
  have h : env23286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23208_23286 : H12AffineEnvironment.transform 17 56573 env23208 = env23286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env23208 == env23286) = true)

def env23287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,8388608,8487373,8328,65,4365617,8393985,8406289,8527101,1501,12645453,257,21792,46213,74251]

theorem envBound23287 : H12AffineFastState.Bounded env23287 := by
  intro p hp
  have h : env23287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23286_23287 : H12AffineEnvironment.transform 20 4160 env23286 = env23287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23286 == env23287) = true)

def env23288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,16,98781,8328,65,4365617,5393,17665,138477,1501,4256861,257,21792,46213,74251]

theorem envBound23288 : H12AffineFastState.Bounded env23288 := by
  intro p hp
  have h : env23288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23287_23288 : H12AffineEnvironment.transform 22 16 env23287 = env23288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23287 == env23288) = true)

theorem identity23288 : scanCanonicalize (H12AffineFastState.compose env23288 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound23288 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,169,16,98781,8328,65,171416,5393,17665,138477,1501,62708,257,21792,46213,74251]

theorem envBound23289 : H12AffineFastState.Bounded env23289 := by
  intro p hp
  have h : env23289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23288_23289 : H12AffineEnvironment.transform 21 169 env23288 = env23289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env23288 == env23289) = true)

def env23290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,16,98645,8192,65,171280,5393,17665,138341,1365,62588,257,21792,46093,74251]

theorem envBound23290 : H12AffineFastState.Bounded env23290 := by
  intro p hp
  have h : env23290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23289_23290 : H12AffineEnvironment.transform 6 8 env23289 = env23290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23289 == env23290) = true)

theorem identity23290 : scanCanonicalize (H12AffineFastState.compose env23290 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound23290 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,56437,1025,32769,4160,33,16,62558,8192,65,171280,5393,17665,138341,1365,62588,257,21792,46093,22272]

theorem envBound23291 : H12AffineFastState.Bounded env23291 := by
  intro p hp
  have h : env23291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23290_23291 : H12AffineEnvironment.transform 15 29963 env23290 = env23291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env23290 == env23291) = true)

theorem identity23291 : scanCanonicalize (H12AffineFastState.compose env23291 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23291 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env23292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,131072,10281,1025,29789,4160,33,16,2,8192,65,158028,5393,17665,138341,1365,32,257,21792,16465,22272]

theorem envBound23292 : H12AffineFastState.Bounded env23292 := by
  intro p hp
  have h : env23292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23291_23292 : H12AffineEnvironment.transform 14 29788 env23291 = env23292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23291 == env23292) = true)

theorem identity23292 : scanCanonicalize (H12AffineFastState.compose env23292 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound23292 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13357,113,294,131072,10281,1025,112,4160,33,16,2,8192,65,138593,5393,12588,138341,1365,32,257,8461,13436,9005]

theorem envBound23293 : H12AffineFastState.Bounded env23293 := by
  intro p hp
  have h : env23293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23292_23293 : H12AffineEnvironment.transform 13 13357 env23292 = env23293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env23292 == env23293) = true)

theorem identity23293 : scanCanonicalize (H12AffineFastState.compose env23293 (packedSelected [0,4,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23293 : packedSelected [0,4,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,113,294,131072,2049,1025,112,4160,33,16,2,40,65,138593,5393,4356,138341,1365,32,257,293,5204,773]

theorem envBound23294 : H12AffineFastState.Bounded env23294 := by
  intro p hp
  have h : env23294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23293_23294 : H12AffineEnvironment.transform 12 40 env23293 = env23294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23293 == env23294) = true)

theorem identity23294 : scanCanonicalize (H12AffineFastState.compose env23294 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound23294 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,113,294,5393,2049,1025,112,4160,33,16,2,40,65,2160,5393,4356,2420,1365,32,257,293,5204,773]

theorem envBound23295 : H12AffineFastState.Bounded env23295 := by
  intro p hp
  have h : env23295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23294_23295 : H12AffineEnvironment.transform 16 5393 env23294 = env23295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env23294 == env23295) = true)

theorem identity23295 : scanCanonicalize (H12AffineFastState.compose env23295 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23295 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23296 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,40,5125,113,35,5140,2049,1025,112,4160,33,16,2,40,65,2160,5140,4097,2161,1104,32,4,32,5204,512]

theorem envBound23296 : H12AffineFastState.Bounded env23296 := by
  intro p hp
  have h : env23296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23295_23296 : H12AffineEnvironment.transform 7 5 env23295 = env23296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23295 == env23296) = true)

theorem identity23296 : scanCanonicalize (H12AffineFastState.compose env23296 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23296 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23297 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,40,5125,1,35,5140,2049,1025,0,4144,33,16,2,40,49,2048,5140,4097,2049,1056,32,4,32,5156,512]

theorem envBound23297 : H12AffineFastState.Bounded env23297 := by
  intro p hp
  have h : env23297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23296_23297 : H12AffineEnvironment.transform 5 48 env23296 = env23297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23296 == env23297) = true)

theorem identity23297 : scanCanonicalize (H12AffineFastState.compose env23297 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound23297 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23298 : List Nat := [2,4,8,16,32,48,8,5,512,1024,11,4096,40,5125,1,35,5140,10,1025,0,4144,33,16,2,40,49,11,5140,4097,10,1056,32,4,32,5156,512]

theorem envBound23298 : H12AffineFastState.Bounded env23298 := by
  intro p hp
  have h : env23298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23297_23298 : H12AffineEnvironment.transform 10 11 env23297 = env23298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env23297 == env23298) = true)

theorem identity23298 : scanCanonicalize (H12AffineFastState.compose env23298 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound23298 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23299 : List Nat := [2,4,8,16,32,48,8,5,512,1024,11,33,40,1060,1,35,1077,10,1025,0,17,33,16,2,40,49,11,1077,32,10,1056,32,4,32,1029,512]

theorem envBound23299 : H12AffineFastState.Bounded env23299 := by
  intro p hp
  have h : env23299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23298_23299 : H12AffineEnvironment.transform 11 33 env23298 = env23299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env23298 == env23299) = true)

theorem identity23299 : scanCanonicalize (H12AffineFastState.compose env23299 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound23299 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23300 : List Nat := [2,4,8,16,32,48,8,5,512,31,11,33,40,59,1,35,42,10,30,0,17,33,16,2,40,49,11,42,32,10,63,32,4,32,26,512]

theorem envBound23300 : H12AffineFastState.Bounded env23300 := by
  intro p hp
  have h : env23300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23299_23300 : H12AffineEnvironment.transform 9 31 env23299 = env23300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env23299 == env23300) = true)

def env23301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,16,98644,8193,65,171281,5393,17665,138340,1364,62589,257,21792,46092,74251]

theorem envBound23301 : H12AffineFastState.Bounded env23301 := by
  intro p hp
  have h : env23301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23289_23301 : H12AffineEnvironment.transform 6 9 env23289 = env23301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23289 == env23301) = true)

theorem identity23301 : scanCanonicalize (H12AffineFastState.compose env23301 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound23301 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56436,1025,32769,4160,32,16,21763,8193,65,171281,5393,17665,138340,1364,62589,257,21792,46092,63068]

theorem envBound23302 : H12AffineFastState.Bounded env23302 := by
  intro p hp
  have h : env23302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23301_23302 : H12AffineEnvironment.transform 15 54359 env23301 = env23302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env23301 == env23302) = true)

theorem identity23302 : scanCanonicalize (H12AffineFastState.compose env23302 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound23302 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16400,56436,1025,32769,4160,32,16,21763,8193,65,56577,5393,17665,23668,1364,62589,257,21792,46092,63068]

theorem envBound23303 : H12AffineFastState.Bounded env23303 := by
  intro p hp
  have h : env23303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23302_23303 : H12AffineEnvironment.transform 16 16400 env23302 = env23303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23302 == env23303) = true)

theorem identity23303 : scanCanonicalize (H12AffineFastState.compose env23303 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23303 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env23304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54359,16400,56436,1025,32769,4160,32,16,21763,268,65,56577,5393,17665,23668,1364,54640,257,21792,38145,55121]

theorem envBound23304 : H12AffineFastState.Bounded env23304 := by
  intro p hp
  have h : env23304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23303_23304 : H12AffineEnvironment.transform 12 269 env23303 = env23304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23303 == env23304) = true)

theorem identity23304 : scanCanonicalize (H12AffineFastState.compose env23304 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23304 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,33031,5440,35108,1025,32769,4160,32,16,83,268,65,34897,5393,4177,2340,1364,32800,257,112,38145,33281]

theorem envBound23305 : H12AffineFastState.Bounded env23305 := by
  intro p hp
  have h : env23305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23304_23305 : H12AffineEnvironment.transform 13 5456 env23304 = env23305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23304 == env23305) = true)

theorem identity23305 : scanCanonicalize (H12AffineFastState.compose env23305 (packedSelected [0,3,5,6,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 624) := by decide +kernel

theorem selectedBound23305 : packedSelected [0,3,5,6,9,14] rootPS < 2^1333 := by decide +kernel

def env23306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,624,269,1824,32768,33031,1840,35108,1025,32769,560,32,16,83,268,65,34897,1889,545,2340,1364,32800,257,112,34673,33281]

theorem envBound23306 : H12AffineFastState.Bounded env23306 := by
  intro p hp
  have h : env23306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23305_23306 : H12AffineEnvironment.transform 11 624 env23305 = env23306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 624 env23305 == env23306) = true)

theorem identity23306 : scanCanonicalize (H12AffineFastState.compose env23306 (packedSelected [4,5,7,8,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 1604) := by decide +kernel

theorem selectedBound23306 : packedSelected [4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env23307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,624,269,1824,1604,1859,1840,3936,1025,1605,560,32,16,83,268,65,3605,1889,545,2340,1364,1636,257,112,309,1093]

theorem envBound23307 : H12AffineFastState.Bounded env23307 := by
  intro p hp
  have h : env23307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23306_23307 : H12AffineEnvironment.transform 14 1604 env23306 = env23307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1604 env23306 == env23307) = true)

def env23308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,17,98780,8328,65,4365617,5392,17664,138476,1501,4256860,257,21792,46213,74251]

theorem envBound23308 : H12AffineFastState.Bounded env23308 := by
  intro p hp
  have h : env23308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23287_23308 : H12AffineEnvironment.transform 22 17 env23287 = env23308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23287 == env23308) = true)

def env23309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,17,98644,8192,65,4365617,5392,17664,138340,1365,4256860,257,21792,46093,74251]

theorem envBound23309 : H12AffineFastState.Bounded env23309 := by
  intro p hp
  have h : env23309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23308_23309 : H12AffineEnvironment.transform 6 8 env23308 = env23309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23308 == env23309) = true)

theorem identity23309 : scanCanonicalize (H12AffineFastState.compose env23309 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound23309 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,56437,1025,32769,4160,4194304,17,2,8192,65,4365617,5392,17664,138340,1365,4256860,257,21792,46093,41821]

theorem envBound23310 : H12AffineFastState.Bounded env23310 := by
  intro p hp
  have h : env23310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23309_23310 : H12AffineEnvironment.transform 15 33110 env23309 = env23310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env23309 == env23310) = true)

theorem identity23310 : scanCanonicalize (H12AffineFastState.compose env23310 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound23310 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env23311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,56437,1025,32769,4160,4194304,17,2,8192,65,4250913,5392,17664,23668,1365,4256860,257,21792,46093,41821]

theorem envBound23311 : H12AffineFastState.Bounded env23311 := by
  intro p hp
  have h : env23311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23310_23311 : H12AffineEnvironment.transform 16 16400 env23310 = env23311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23310 == env23311) = true)

theorem identity23311 : scanCanonicalize (H12AffineFastState.compose env23311 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23311 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env23312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,32041,1025,8541,4160,4194304,17,2,8192,65,4226173,5392,17664,23668,1365,4216064,257,21792,5457,513]

theorem envBound23312 : H12AffineFastState.Bounded env23312 := by
  intro p hp
  have h : env23312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23311_23312 : H12AffineEnvironment.transform 14 8540 env23311 = env23312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23311 == env23312) = true)

theorem identity23312 : scanCanonicalize (H12AffineFastState.compose env23312 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23312 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23313 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,8202,16400,30777,273,8541,4160,4194304,17,2,8192,65,4225389,4096,16400,22884,69,4214800,257,20528,4161,513]

theorem envBound23313 : H12AffineFastState.Bounded env23313 := by
  intro p hp
  have h : env23313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23312_23313 : H12AffineEnvironment.transform 9 272 env23312 = env23313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23312 == env23313) = true)

theorem identity23313 : scanCanonicalize (H12AffineFastState.compose env23313 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23313 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23314 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,8202,4096,10281,273,8541,4160,4194304,17,2,8192,65,4204925,4096,4096,2420,69,4194304,257,32,4161,513]

theorem envBound23314 : H12AffineFastState.Bounded env23314 := by
  intro p hp
  have h : env23314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23313_23314 : H12AffineEnvironment.transform 13 4112 env23313 = env23314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env23313 == env23314) = true)

theorem identity23314 : scanCanonicalize (H12AffineFastState.compose env23314 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23315 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,8202,4096,10281,273,8541,4160,113,17,2,8192,65,10508,4096,4096,2420,69,113,257,32,4161,513]

theorem envBound23315 : H12AffineFastState.Bounded env23315 := by
  intro p hp
  have h : env23315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23314_23315 : H12AffineEnvironment.transform 21 113 env23314 = env23315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23314 == env23315) = true)

theorem identity23315 : scanCanonicalize (H12AffineFastState.compose env23315 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound23315 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23316 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,4381,4112,4161,4375,4096,6452,273,4160,4160,113,17,2,4381,65,6161,4096,4096,2420,69,113,257,32,4161,513]

theorem envBound23316 : H12AffineFastState.Bounded env23316 := by
  intro p hp
  have h : env23316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23315_23316 : H12AffineEnvironment.transform 12 4381 env23315 = env23316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env23315 == env23316) = true)

theorem identity23316 : scanCanonicalize (H12AffineFastState.compose env23316 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound23316 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23317 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,269,0,81,263,16,2340,273,80,80,113,17,2,269,65,2049,16,16,2420,69,113,257,32,81,513]

theorem envBound23317 : H12AffineFastState.Bounded env23317 := by
  intro p hp
  have h : env23317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23316_23317 : H12AffineEnvironment.transform 11 16 env23316 = env23317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23316 == env23317) = true)

theorem identity23317 : scanCanonicalize (H12AffineFastState.compose env23317 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23317 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23318 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,16,41,0,81,35,16,2048,53,80,80,113,17,2,41,65,2049,16,16,2128,69,113,37,32,81,513]

theorem envBound23318 : H12AffineFastState.Bounded env23318 := by
  intro p hp
  have h : env23318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23317_23318 : H12AffineEnvironment.transform 7 36 env23317 = env23318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23317 == env23318) = true)

theorem identity23318 : scanCanonicalize (H12AffineFastState.compose env23318 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound23318 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23319 : List Nat := [2,4,8,16,32,64,8,36,512,52,113,16,41,0,81,35,16,113,53,80,80,113,17,2,41,65,112,16,16,33,69,113,37,32,81,513]

theorem envBound23319 : H12AffineFastState.Bounded env23319 := by
  intro p hp
  have h : env23319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23318_23319 : H12AffineEnvironment.transform 10 113 env23318 = env23319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env23318 == env23319) = true)

theorem identity23319 : scanCanonicalize (H12AffineFastState.compose env23319 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23319 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23320 : List Nat := [2,4,8,16,32,64,8,36,32,52,113,16,41,0,81,35,16,113,53,80,80,113,17,2,41,65,112,16,16,33,69,113,37,32,81,33]

theorem envBound23320 : H12AffineFastState.Bounded env23320 := by
  intro p hp
  have h : env23320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23319_23320 : H12AffineEnvironment.transform 8 32 env23319 = env23320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23319 == env23320) = true)

theorem identity23320 : scanCanonicalize (H12AffineFastState.compose env23320 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23320 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23321 : List Nat := [2,4,8,16,32,48,8,36,32,52,1,16,41,0,33,35,16,1,53,32,32,1,17,2,41,49,0,16,16,33,53,1,37,32,33,33]

theorem envBound23321 : H12AffineFastState.Bounded env23321 := by
  intro p hp
  have h : env23321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23320_23321 : H12AffineEnvironment.transform 5 48 env23320 = env23321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23320 == env23321) = true)

theorem identity23321 : scanCanonicalize (H12AffineFastState.compose env23321 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23322 : List Nat := [2,4,8,16,1,17,8,5,1,21,1,16,8,0,0,2,16,1,20,1,1,1,17,2,8,16,0,16,16,0,20,1,4,1,0,0]

theorem envBound23322 : H12AffineFastState.Bounded env23322 := by
  intro p hp
  have h : env23322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23321_23322 : H12AffineEnvironment.transform 4 1 env23321 = env23322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23321 == env23322) = true)

def env23323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,4194304,17,98645,8193,65,4365617,5392,17664,138341,1364,4256860,257,21792,46092,74251]

theorem envBound23323 : H12AffineFastState.Bounded env23323 := by
  intro p hp
  have h : env23323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23308_23323 : H12AffineEnvironment.transform 6 9 env23308 = env23323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23308 == env23323) = true)

theorem identity23323 : scanCanonicalize (H12AffineFastState.compose env23323 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23323 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4160,4194304,17,41311,8193,65,4365617,5392,17664,138341,1364,4256860,257,21792,46092,513]

theorem envBound23324 : H12AffineFastState.Bounded env23324 := by
  intro p hp
  have h : env23324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23323_23324 : H12AffineEnvironment.transform 15 8202 env23323 = env23324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23323 == env23324) = true)

theorem identity23324 : scanCanonicalize (H12AffineFastState.compose env23324 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound23324 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4160,112,17,41311,8193,65,171329,5392,17664,138341,1364,62508,257,21792,46092,513]

theorem envBound23325 : H12AffineFastState.Bounded env23325 := by
  intro p hp
  have h : env23325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23324_23325 : H12AffineEnvironment.transform 21 112 env23324 = env23325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env23324 == env23325) = true)

def env23326 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4112,32,17,41231,8193,17,171281,5392,17664,138293,1284,62508,257,21792,46092,513]

theorem envBound23326 : H12AffineFastState.Bounded env23326 := by
  intro p hp
  have h : env23326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23325_23326 : H12AffineEnvironment.transform 5 16 env23325 = env23326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23325 == env23326) = true)

theorem identity23326 : scanCanonicalize (H12AffineFastState.compose env23326 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound23326 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env23327 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,131072,43049,1025,32769,4112,32,17,41231,8193,17,171281,5392,12557,138293,1284,32801,257,8493,46092,513]

theorem envBound23327 : H12AffineFastState.Bounded env23327 := by
  intro p hp
  have h : env23327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23326_23327 : H12AffineEnvironment.transform 13 13325 env23326 = env23327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env23326 == env23327) = true)

theorem identity23327 : scanCanonicalize (H12AffineFastState.compose env23327 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound23327 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23328 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,13341,43049,1025,32769,4112,32,17,41231,8193,17,43276,5392,12557,10280,1284,32801,257,8493,46092,513]

theorem envBound23328 : H12AffineFastState.Bounded env23328 := by
  intro p hp
  have h : env23328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23327_23328 : H12AffineEnvironment.transform 16 13341 env23327 = env23328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env23327 == env23328) = true)

theorem identity23328 : scanCanonicalize (H12AffineFastState.compose env23328 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23328 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23329 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,32768,262,5393,35109,1025,32769,4112,32,17,32771,269,17,34816,5392,4097,2340,1284,32801,257,33,38144,513]

theorem envBound23329 : H12AffineFastState.Bounded env23329 := by
  intro p hp
  have h : env23329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23328_23329 : H12AffineEnvironment.transform 12 268 env23328 = env23329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23328 == env23329) = true)

theorem identity23329 : scanCanonicalize (H12AffineFastState.compose env23329 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23330 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1025,1,4112,32,17,3,269,17,2048,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound23330 : H12AffineFastState.Bounded env23330 := by
  intro p hp
  have h : env23330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23329_23330 : H12AffineEnvironment.transform 14 0 env23329 = env23330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23329 == env23330) = true)

theorem identity23330 : scanCanonicalize (H12AffineFastState.compose env23330 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23330 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23331 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2308,1025,1,4112,1,17,3,269,17,2048,5392,4097,2309,1284,0,257,0,5376,513]

theorem envBound23331 : H12AffineFastState.Bounded env23331 := by
  intro p hp
  have h : env23331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23330_23331 : H12AffineEnvironment.transform 4 1 env23330 = env23331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23330 == env23331) = true)

theorem identity23331 : scanCanonicalize (H12AffineFastState.compose env23331 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound23331 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23332 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1028,268,261,0,262,277,2308,1025,1,1044,1,17,3,269,17,2048,276,1029,2309,1284,0,257,0,260,513]

theorem envBound23332 : H12AffineFastState.Bounded env23332 := by
  intro p hp
  have h : env23332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23331_23332 : H12AffineEnvironment.transform 11 1028 env23331 = env23332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env23331 == env23332) = true)

theorem identity23332 : scanCanonicalize (H12AffineFastState.compose env23332 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound23332 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23333 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1556,1028,268,261,0,262,277,1808,1025,1,1044,1,17,3,269,17,1556,276,1029,1809,1284,0,257,0,260,513]

theorem envBound23333 : H12AffineFastState.Bounded env23333 := by
  intro p hp
  have h : env23333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23332_23333 : H12AffineEnvironment.transform 10 1556 env23332 = env23333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env23332 == env23333) = true)

theorem identity23333 : scanCanonicalize (H12AffineFastState.compose env23333 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound23333 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23334 : List Nat := [2,4,8,16,1,16,9,256,512,517,17,513,268,261,0,262,277,277,516,1,529,1,17,3,269,17,17,276,512,276,769,0,257,0,260,513]

theorem envBound23334 : H12AffineFastState.Bounded env23334 := by
  intro p hp
  have h : env23334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23333_23334 : H12AffineEnvironment.transform 9 517 env23333 = env23334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env23333 == env23334) = true)

theorem identity23334 : scanCanonicalize (H12AffineFastState.compose env23334 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23334 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23335 : List Nat := [2,4,8,16,1,16,9,256,0,5,17,1,268,261,0,262,277,277,4,1,17,1,17,3,269,17,17,276,0,276,257,0,257,0,260,1]

theorem envBound23335 : H12AffineFastState.Bounded env23335 := by
  intro p hp
  have h : env23335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23334_23335 : H12AffineEnvironment.transform 8 0 env23334 = env23335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23334 == env23335) = true)

def env23336 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4113,33,17,41230,8193,16,171280,5392,17664,138292,1285,62508,257,21792,46092,513]

theorem envBound23336 : H12AffineFastState.Bounded env23336 := by
  intro p hp
  have h : env23336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23325_23336 : H12AffineEnvironment.transform 5 17 env23325 = env23336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23325 == env23336) = true)

theorem identity23336 : scanCanonicalize (H12AffineFastState.compose env23336 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound23336 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env23337 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,56357,1025,32769,4113,33,17,41230,8193,16,23808,5392,17664,56356,1285,62508,257,21792,46092,513]

theorem envBound23337 : H12AffineFastState.Bounded env23337 := by
  intro p hp
  have h : env23337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23336_23337 : H12AffineEnvironment.transform 16 49168 env23336 = env23337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23336 == env23337) = true)

theorem identity23337 : scanCanonicalize (H12AffineFastState.compose env23337 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound23337 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23338 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,13340,10281,1025,29709,4113,33,17,21762,8193,16,23808,5392,17664,10280,1285,32,257,21792,16384,513]

theorem envBound23338 : H12AffineFastState.Bounded env23338 := by
  intro p hp
  have h : env23338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23337_23338 : H12AffineEnvironment.transform 14 29708 env23337 = env23338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env23337 == env23338) = true)

def env23339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,8388608,8487372,8328,65,4365616,8393985,8406288,8527101,1500,12645453,257,21792,46213,74250]

theorem envBound23339 : H12AffineFastState.Bounded env23339 := by
  intro p hp
  have h : env23339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23286_23339 : H12AffineEnvironment.transform 20 4161 env23286 = env23339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23286 == env23339) = true)

def env23340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,16,98780,8328,65,4365616,5393,17664,138477,1500,4256861,257,21792,46213,74250]

theorem envBound23340 : H12AffineFastState.Bounded env23340 := by
  intro p hp
  have h : env23340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23339_23340 : H12AffineEnvironment.transform 22 16 env23339 = env23340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23339 == env23340) = true)

theorem identity23340 : scanCanonicalize (H12AffineFastState.compose env23340 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound23340 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,62589,16,98780,8328,65,158029,5393,17664,138477,1500,32,257,21792,46213,74250]

theorem envBound23341 : H12AffineFastState.Bounded env23341 := by
  intro p hp
  have h : env23341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23340_23341 : H12AffineEnvironment.transform 21 62589 env23340 = env23341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env23340 == env23341) = true)

theorem identity23341 : scanCanonicalize (H12AffineFastState.compose env23341 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23341 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56573,1025,32769,4161,62589,16,41431,8328,65,158029,5393,17664,138477,1500,32,257,21792,46213,513]

theorem envBound23342 : H12AffineFastState.Bounded env23342 := by
  intro p hp
  have h : env23342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23341_23342 : H12AffineEnvironment.transform 15 8203 env23341 = env23342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23341 == env23342) = true)

theorem identity23342 : scanCanonicalize (H12AffineFastState.compose env23342 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23342 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56573,1025,32769,4161,62589,16,41431,8328,65,10588,5393,17664,23804,1500,32,257,21792,46213,513]

theorem envBound23343 : H12AffineFastState.Bounded env23343 := by
  intro p hp
  have h : env23343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23342_23343 : H12AffineEnvironment.transform 16 16401 env23342 = env23343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23342 == env23343) = true)

def env23344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,17,98781,8328,65,4365616,5392,17665,138476,1500,4256860,257,21792,46213,74250]

theorem envBound23344 : H12AffineFastState.Bounded env23344 := by
  intro p hp
  have h : env23344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23339_23344 : H12AffineEnvironment.transform 22 17 env23339 = env23344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23339 == env23344) = true)

theorem identity23344 : scanCanonicalize (H12AffineFastState.compose env23344 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound23344 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10281,1025,29909,4161,4194304,17,95497,8328,65,4352484,5392,17665,138476,1500,4194440,257,21792,16465,74250]

theorem envBound23345 : H12AffineFastState.Bounded env23345 := by
  intro p hp
  have h : env23345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23344_23345 : H12AffineEnvironment.transform 14 29908 env23344 = env23345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env23344 == env23345) = true)

def env23346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1025,8661,4161,4194304,17,73737,8328,65,4340964,5392,4097,138476,1500,4194440,257,32,5457,74250]

theorem envBound23346 : H12AffineFastState.Bounded env23346 := by
  intro p hp
  have h : env23346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23345_23346 : H12AffineEnvironment.transform 13 5376 env23345 = env23346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23345 == env23346) = true)

theorem identity23346 : scanCanonicalize (H12AffineFastState.compose env23346 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23346 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,131072,10281,1025,8661,4161,4194304,17,2,8328,65,4340964,5392,4097,138476,1500,4194440,257,32,5457,513]

theorem envBound23347 : H12AffineFastState.Bounded env23347 := by
  intro p hp
  have h : env23347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23346_23347 : H12AffineEnvironment.transform 15 8203 env23346 = env23347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23346 == env23347) = true)

theorem identity23347 : scanCanonicalize (H12AffineFastState.compose env23347 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23347 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,342,131072,2420,1025,136,4161,4194304,17,2,469,65,4332985,5392,4097,138476,1500,4194440,257,32,5457,513]

theorem envBound23348 : H12AffineFastState.Bounded env23348 := by
  intro p hp
  have h : env23348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23347_23348 : H12AffineEnvironment.transform 12 349 env23347 = env23348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23347 == env23348) = true)

theorem identity23348 : scanCanonicalize (H12AffineFastState.compose env23348 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound23348 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,342,5393,2420,1025,136,4161,4194304,17,2,469,65,4196520,5392,4097,2557,1500,4194440,257,32,5457,513]

theorem envBound23349 : H12AffineFastState.Bounded env23349 := by
  intro p hp
  have h : env23349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23348_23349 : H12AffineEnvironment.transform 16 5393 env23348 = env23349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env23348 == env23349) = true)

theorem identity23349 : scanCanonicalize (H12AffineFastState.compose env23349 (packedSelected [0,1,4,5,7,8,9,11,14,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound23349 : packedSelected [0,1,4,5,7,8,9,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env23350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,342,5393,2420,1025,136,4161,169,17,2,469,65,2049,5392,4097,2557,1500,33,257,32,5457,513]

theorem envBound23350 : H12AffineFastState.Bounded env23350 := by
  intro p hp
  have h : env23350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23349_23350 : H12AffineEnvironment.transform 21 169 env23349 = env23350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env23349 == env23350) = true)

theorem identity23350 : scanCanonicalize (H12AffineFastState.compose env23350 (packedSelected [0,1,3,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound23350 : packedSelected [0,1,3,7,11,14] rootPS < 2^1333 := by decide +kernel

def env23351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1573,349,805,137,342,820,2420,1025,136,1636,169,17,2,469,65,2049,821,1572,2557,1500,33,257,32,884,513]

theorem envBound23351 : H12AffineFastState.Bounded env23351 := by
  intro p hp
  have h : env23351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23350_23351 : H12AffineEnvironment.transform 11 1573 env23350 = env23351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env23350 == env23351) = true)

theorem identity23351 : scanCanonicalize (H12AffineFastState.compose env23351 (packedSelected [2,5,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1709) := by decide +kernel

theorem selectedBound23351 : packedSelected [2,5,8,11,15] rootPS < 2^1333 := by decide +kernel

def env23352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1709,1573,349,805,137,342,820,2009,1025,136,1636,169,17,2,469,65,1708,821,1572,1872,1500,33,257,32,884,513]

theorem envBound23352 : H12AffineFastState.Bounded env23352 := by
  intro p hp
  have h : env23352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23351_23352 : H12AffineEnvironment.transform 10 1709 env23351 = env23352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1709 env23351 == env23352) = true)

theorem identity23352 : scanCanonicalize (H12AffineFastState.compose env23352 (packedSelected [0,2,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23352 : packedSelected [0,2,27] rootPS < 2^1333 := by decide +kernel

def env23353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1572,1573,349,805,0,342,820,1872,1025,1,1636,32,17,2,348,65,1573,821,1572,1872,1365,33,257,32,884,513]

theorem envBound23353 : H12AffineFastState.Bounded env23353 := by
  intro p hp
  have h : env23353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23352_23353 : H12AffineEnvironment.transform 6 9 env23352 = env23353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23352 == env23353) = true)

theorem identity23353 : scanCanonicalize (H12AffineFastState.compose env23353 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23353 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env23354 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1572,1573,269,805,0,262,820,1792,1025,1,1588,32,17,2,268,17,1573,821,1572,1792,1285,33,257,32,804,513]

theorem envBound23354 : H12AffineFastState.Bounded env23354 := by
  intro p hp
  have h : env23354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23353_23354 : H12AffineEnvironment.transform 5 16 env23353 = env23354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23353 == env23354) = true)

theorem identity23354 : scanCanonicalize (H12AffineFastState.compose env23354 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound23354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23355 : List Nat := [2,4,8,16,32,16,9,52,512,1024,1572,1573,57,529,0,50,512,1588,1025,1,1588,32,17,2,56,17,1573,513,1572,1588,1073,33,53,32,528,513]

theorem envBound23355 : H12AffineFastState.Bounded env23355 := by
  intro p hp
  have h : env23355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23354_23355 : H12AffineEnvironment.transform 7 52 env23354 = env23355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env23354 == env23355) = true)

theorem identity23355 : scanCanonicalize (H12AffineFastState.compose env23355 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound23355 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23356 : List Nat := [2,4,8,16,32,16,9,52,512,565,17,16,57,529,0,50,512,1,564,1,1,32,17,2,56,17,16,513,17,1,516,33,53,32,528,513]

theorem envBound23356 : H12AffineFastState.Bounded env23356 := by
  intro p hp
  have h : env23356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23355_23356 : H12AffineEnvironment.transform 9 565 env23355 = env23356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env23355 == env23356) = true)

def env23357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1025,8660,4161,4194304,17,73736,8328,65,4340965,5392,4096,138476,1500,4194440,257,33,5456,74250]

theorem envBound23357 : H12AffineFastState.Bounded env23357 := by
  intro p hp
  have h : env23357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23345_23357 : H12AffineEnvironment.transform 13 5377 env23345 = env23357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23345 == env23357) = true)

theorem identity23357 : scanCanonicalize (H12AffineFastState.compose env23357 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound23357 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,10281,1025,8660,4161,4194304,17,138,8328,65,4340965,5392,4096,138476,1500,4194440,257,33,5456,648]

theorem envBound23358 : H12AffineFastState.Bounded env23358 := by
  intro p hp
  have h : env23358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23357_23358 : H12AffineEnvironment.transform 15 8322 env23357 = env23358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env23357 == env23358) = true)

theorem identity23358 : scanCanonicalize (H12AffineFastState.compose env23358 (packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound23358 : packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS < 2^1333 := by decide +kernel

def env23359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,10281,1025,8660,4161,8692,17,138,8328,65,138513,5392,4096,138476,1500,8572,257,33,5456,648]

theorem envBound23359 : H12AffineFastState.Bounded env23359 := by
  intro p hp
  have h : env23359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23358_23359 : H12AffineEnvironment.transform 21 8692 env23358 = env23359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env23358 == env23359) = true)

theorem identity23359 : scanCanonicalize (H12AffineFastState.compose env23359 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23359 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env23360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,478,131072,2421,1025,136,4161,168,17,138,468,65,138513,5392,4096,138476,1500,32,257,33,5456,648]

theorem envBound23360 : H12AffineFastState.Bounded env23360 := by
  intro p hp
  have h : env23360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23359_23360 : H12AffineEnvironment.transform 12 348 env23359 = env23360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23359 == env23360) = true)

theorem identity23360 : scanCanonicalize (H12AffineFastState.compose env23360 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5560) := by decide +kernel

theorem selectedBound23360 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,478,5560,2421,1025,136,4161,168,17,138,468,65,2217,5392,4096,2388,1500,32,257,33,5456,648]

theorem envBound23361 : H12AffineFastState.Bounded env23361 := by
  intro p hp
  have h : env23361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23360_23361 : H12AffineEnvironment.transform 16 5560 env23360 = env23361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5560 env23360 == env23361) = true)

theorem identity23361 : scanCanonicalize (H12AffineFastState.compose env23361 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound23361 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23362 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5377,113,294,5440,2421,1025,112,4161,80,17,114,300,65,2129,5392,4096,2388,1316,32,257,33,5456,624]

theorem envBound23362 : H12AffineFastState.Bounded env23362 := by
  intro p hp
  have h : env23362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23361_23362 : H12AffineEnvironment.transform 6 120 env23361 = env23362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env23361 == env23362) = true)

theorem identity23362 : scanCanonicalize (H12AffineFastState.compose env23362 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23362 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23363 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,300,5377,1,294,5424,2309,1025,0,4145,32,17,2,300,49,2081,5392,4096,2340,1316,32,257,33,5408,512]

theorem envBound23363 : H12AffineFastState.Bounded env23363 := by
  intro p hp
  have h : env23363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23362_23363 : H12AffineEnvironment.transform 5 48 env23362 = env23363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23362 == env23363) = true)

theorem identity23363 : scanCanonicalize (H12AffineFastState.compose env23363 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23363 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23364 : List Nat := [2,4,8,16,32,48,8,256,512,52,2048,4096,300,4405,1,294,4356,2309,53,0,4145,32,17,2,300,49,2081,4388,4096,2340,272,32,257,33,4372,512]

theorem envBound23364 : H12AffineFastState.Bounded env23364 := by
  intro p hp
  have h : env23364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23363_23364 : H12AffineEnvironment.transform 9 52 env23363 = env23364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23363 == env23364) = true)

theorem identity23364 : scanCanonicalize (H12AffineFastState.compose env23364 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23364 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23365 : List Nat := [2,4,8,16,32,48,8,4,512,52,2048,4096,40,4145,1,34,4096,2049,53,0,4145,32,17,2,40,49,2081,4128,4096,2080,20,32,5,33,4112,512]

theorem envBound23365 : H12AffineFastState.Bounded env23365 := by
  intro p hp
  have h : env23365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23364_23365 : H12AffineEnvironment.transform 7 4 env23364 = env23365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23364 == env23365) = true)

theorem identity23365 : scanCanonicalize (H12AffineFastState.compose env23365 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23365 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23366 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,4096,8,4113,1,2,4096,2049,21,0,4113,0,17,2,8,17,2049,4096,4096,2048,20,0,5,1,4112,512]

theorem envBound23366 : H12AffineFastState.Bounded env23366 := by
  intro p hp
  have h : env23366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23365_23366 : H12AffineEnvironment.transform 4 0 env23365 = env23366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23365 == env23366) = true)

theorem identity23366 : scanCanonicalize (H12AffineFastState.compose env23366 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound23366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23367 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,8,2048,1,2,2065,2049,21,0,2048,0,17,2,8,17,2049,2065,2065,2048,20,0,5,1,2049,512]

theorem envBound23367 : H12AffineFastState.Bounded env23367 := by
  intro p hp
  have h : env23367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23366_23367 : H12AffineEnvironment.transform 11 2065 env23366 = env23367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env23366 == env23367) = true)

theorem identity23367 : scanCanonicalize (H12AffineFastState.compose env23367 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23368 : List Nat := [2,4,8,4,0,4,8,4,512,0,2048,2053,8,2048,1,2,2053,2049,1,0,2048,0,5,2,8,5,2049,2053,2053,2048,0,0,5,1,2049,512]

theorem envBound23368 : H12AffineFastState.Bounded env23368 := by
  intro p hp
  have h : env23368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23367_23368 : H12AffineEnvironment.transform 3 4 env23367 = env23368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23367 == env23368) = true)

theorem identity23368 : scanCanonicalize (H12AffineFastState.compose env23368 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23368 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23369 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,0,1,2,5,1,1,0,0,0,5,2,8,5,1,5,5,0,0,0,5,1,1,512]

theorem envBound23369 : H12AffineFastState.Bounded env23369 := by
  intro p hp
  have h : env23369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23368_23369 : H12AffineEnvironment.transform 10 0 env23368 = env23369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23368 == env23369) = true)

def env23370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound23370 : H12AffineFastState.Bounded env23370 := by
  intro p hp
  have h : env23370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22996_23370 : H12AffineEnvironment.transform 26 30393345 env22996 = env23370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env22996 == env23370) = true)

def env23371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound23371 : H12AffineFastState.Bounded env23371 := by
  intro p hp
  have h : env23371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23370_23371 : H12AffineEnvironment.transform 18 1024 env23370 = env23371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23370 == env23371) = true)

theorem identity23371 : scanCanonicalize (H12AffineFastState.compose env23371 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510000) := by decide +kernel

theorem selectedBound23371 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510000,8328,65,12585009,2510013,10507601,8830976,8801312,6729201,256,10882205,10939704,8874999]

theorem envBound23372 : H12AffineFastState.Bounded env23372 := by
  intro p hp
  have h : env23372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23371_23372 : H12AffineEnvironment.transform 23 510000 env23371 = env23372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env23371 == env23372) = true)

def env23373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513340,510000,8328,65,6705549,2510013,396525,2136508,2102684,6729201,256,21793,46212,2175563]

theorem envBound23373 : H12AffineFastState.Bounded env23373 := by
  intro p hp
  have h : env23373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23372_23373 : H12AffineEnvironment.transform 22 2513340 env23372 = env23373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513340 env23372 == env23373) = true)

def env23374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513340,510000,8328,65,2409525,2510013,396525,2136508,2102684,2373705,256,21793,46212,2175563]

theorem envBound23374 : H12AffineFastState.Bounded env23374 := by
  intro p hp
  have h : env23374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23373_23374 : H12AffineEnvironment.transform 21 169400 env23373 = env23374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env23373 == env23374) = true)

def env23375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,510000,8328,65,316533,417021,396525,35324,1500,272393,256,21793,46212,74251]

theorem envBound23375 : H12AffineFastState.Bounded env23375 := by
  intro p hp
  have h : env23375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23374_23375 : H12AffineEnvironment.transform 20 4160 env23374 = env23375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23374 == env23375) = true)

theorem identity23375 : scanCanonicalize (H12AffineFastState.compose env23375 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound23375 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169400,62661,95497,8328,65,158028,57796,45524,35324,1500,169264,256,21793,46212,74251]

theorem envBound23376 : H12AffineFastState.Bounded env23376 := by
  intro p hp
  have h : env23376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23375_23376 : H12AffineEnvironment.transform 17 179513 env23375 = env23376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env23375 == env23376) = true)

theorem identity23376 : scanCanonicalize (H12AffineFastState.compose env23376 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23376 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4160,169400,62661,21763,8328,65,158028,57796,45524,35324,1500,169264,256,21793,46212,513]

theorem envBound23377 : H12AffineFastState.Bounded env23377 := by
  intro p hp
  have h : env23377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23376_23377 : H12AffineEnvironment.transform 15 8202 env23376 = env23377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23376 == env23377) = true)

theorem identity23377 : scanCanonicalize (H12AffineFastState.compose env23377 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound23377 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46156,2421,1024,32769,4160,8692,62661,21763,8328,65,56576,57796,45524,35324,1500,8572,256,21793,46212,513]

theorem envBound23378 : H12AffineFastState.Bounded env23378 := by
  intro p hp
  have h : env23378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23377_23378 : H12AffineEnvironment.transform 16 46156 env23377 = env23378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env23377 == env23378) = true)

theorem identity23378 : scanCanonicalize (H12AffineFastState.compose env23378 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23378 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env23379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8202,16400,2421,1024,29789,4160,8692,153,21763,8328,65,10588,5528,17800,32160,1500,8572,256,21793,16600,513]

theorem envBound23379 : H12AffineFastState.Bounded env23379 := by
  intro p hp
  have h : env23379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23378_23379 : H12AffineEnvironment.transform 14 29788 env23378 = env23379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23378 == env23379) = true)

theorem identity23379 : scanCanonicalize (H12AffineFastState.compose env23379 (packedSelected [2,4,6,9,14,17,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound23379 : packedSelected [2,4,6,9,14,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env23380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21896,478,16400,2421,1024,21897,4160,32,153,21763,348,65,2184,5528,17800,23668,1500,168,256,21793,16600,513]

theorem envBound23380 : H12AffineFastState.Bounded env23380 := by
  intro p hp
  have h : env23380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23379_23380 : H12AffineEnvironment.transform 12 468 env23379 = env23380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env23379 == env23380) = true)

theorem identity23380 : scanCanonicalize (H12AffineFastState.compose env23380 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound23380 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env23381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3408,468,16384,18648,478,16400,2421,1024,18649,3344,32,153,18515,348,65,2184,2248,17800,16676,1500,168,256,18545,16600,513]

theorem envBound23381 : H12AffineFastState.Bounded env23381 := by
  intro p hp
  have h : env23381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23380_23381 : H12AffineEnvironment.transform 11 3408 env23380 = env23381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env23380 == env23381) = true)

theorem identity23381 : scanCanonicalize (H12AffineFastState.compose env23381 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23381 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env23382 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2113,468,16384,18648,478,16400,2421,273,18649,2049,32,153,18515,348,65,2184,2248,16537,16676,205,168,256,18545,16600,513]

theorem envBound23382 : H12AffineFastState.Bounded env23382 := by
  intro p hp
  have h : env23382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23381_23382 : H12AffineEnvironment.transform 9 273 env23381 = env23382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23381 == env23382) = true)

theorem identity23382 : scanCanonicalize (H12AffineFastState.compose env23382 (packedSelected [0,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2557) := by decide +kernel

theorem selectedBound23382 : packedSelected [0,9,10] rootPS < 2^1333 := by decide +kernel

def env23383 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2113,468,2557,293,478,2541,2421,273,292,2049,32,153,430,348,65,2184,2248,2404,2265,205,168,256,396,2341,513]

theorem envBound23383 : H12AffineFastState.Bounded env23383 := by
  intro p hp
  have h : env23383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23382_23383 : H12AffineEnvironment.transform 13 2557 env23382 = env23383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2557 env23382 == env23383) = true)

theorem identity23383 : scanCanonicalize (H12AffineFastState.compose env23383 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound23383 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23384 : List Nat := [2,4,8,16,32,64,89,256,512,273,2048,2113,269,2340,293,263,2356,2421,273,292,2049,32,64,375,348,65,2129,2065,2404,2048,20,113,256,341,2341,513]

theorem envBound23384 : H12AffineFastState.Bounded env23384 := by
  intro p hp
  have h : env23384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23383_23384 : H12AffineEnvironment.transform 6 89 env23383 = env23384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env23383 == env23384) = true)

theorem identity23384 : scanCanonicalize (H12AffineFastState.compose env23384 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23384 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env23385 : List Nat := [2,4,8,16,32,64,89,37,512,52,2048,2113,40,2049,0,34,2065,2128,52,1,2049,32,64,82,121,65,2129,2065,2113,2048,20,113,37,112,2048,513]

theorem envBound23385 : H12AffineFastState.Bounded env23385 := by
  intro p hp
  have h : env23385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23384_23385 : H12AffineEnvironment.transform 7 37 env23384 = env23385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23384 == env23385) = true)

theorem identity23385 : scanCanonicalize (H12AffineFastState.compose env23385 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound23385 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env23386 : List Nat := [2,4,8,16,32,64,89,37,512,52,624,561,40,625,0,34,609,544,52,1,625,32,64,82,121,65,545,609,561,624,20,113,37,112,624,513]

theorem envBound23386 : H12AffineFastState.Bounded env23386 := by
  intro p hp
  have h : env23386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23385_23386 : H12AffineEnvironment.transform 10 624 env23385 = env23386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env23385 == env23386) = true)

theorem identity23386 : scanCanonicalize (H12AffineFastState.compose env23386 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound23386 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env23387 : List Nat := [2,4,8,16,32,64,89,37,49,52,65,0,40,64,0,34,80,17,52,1,64,32,64,82,121,65,16,80,0,65,20,113,37,112,65,48]

theorem envBound23387 : H12AffineFastState.Bounded env23387 := by
  intro p hp
  have h : env23387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23386_23387 : H12AffineEnvironment.transform 8 49 env23386 = env23387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env23386 == env23387) = true)

theorem identity23387 : scanCanonicalize (H12AffineFastState.compose env23387 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23388 : List Nat := [2,4,8,16,32,17,8,37,49,52,16,0,40,17,0,34,1,17,52,1,17,32,17,3,40,16,16,1,0,16,20,32,37,33,16,48]

theorem envBound23388 : H12AffineFastState.Bounded env23388 := by
  intro p hp
  have h : env23388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23387_23388 : H12AffineEnvironment.transform 5 17 env23387 = env23388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23387 == env23388) = true)

theorem identity23388 : scanCanonicalize (H12AffineFastState.compose env23388 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23389 : List Nat := [2,4,8,0,32,1,8,37,33,36,0,0,40,1,0,34,1,1,36,1,1,32,1,3,40,0,0,1,0,0,4,32,37,33,0,32]

theorem envBound23389 : H12AffineFastState.Bounded env23389 := by
  intro p hp
  have h : env23389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23388_23389 : H12AffineEnvironment.transform 3 0 env23388 = env23389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23388 == env23389) = true)

def env23390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,510000,8328,65,316532,417020,396525,35325,1501,272392,256,21793,46212,74250]

theorem envBound23390 : H12AffineFastState.Bounded env23390 := by
  intro p hp
  have h : env23390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23374_23390 : H12AffineEnvironment.transform 20 4161 env23374 = env23390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23374 == env23390) = true)

def env23391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169400,156117,253976,8328,65,64604,160980,140485,35325,1501,32,256,21793,46212,74250]

theorem envBound23391 : H12AffineFastState.Bounded env23391 := by
  intro p hp
  have h : env23391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23390_23391 : H12AffineEnvironment.transform 17 10280 env23390 = env23391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23390 == env23391) = true)

def env23392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21928,41413,73736,8328,65,64604,46276,58581,35325,1501,32,256,21793,46212,74250]

theorem envBound23392 : H12AffineFastState.Bounded env23392 := by
  intro p hp
  have h : env23392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23391_23392 : H12AffineEnvironment.transform 16 49168 env23391 = env23392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23391 == env23392) = true)

theorem identity23392 : scanCanonicalize (H12AffineFastState.compose env23392 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound23392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49168,10280,1024,32769,4161,21928,41413,41310,8328,65,64604,46276,58581,35325,1501,32,256,21793,46212,41820]

theorem envBound23393 : H12AffineFastState.Bounded env23393 := by
  intro p hp
  have h : env23393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23392_23393 : H12AffineEnvironment.transform 15 33110 env23392 = env23393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env23392 == env23393) = true)

theorem identity23393 : scanCanonicalize (H12AffineFastState.compose env23393 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound23393 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env23394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30073,29743,13673,10280,1024,30072,4161,21928,21692,21543,8328,65,2341,16829,4524,31876,1501,32,256,21793,16893,22053]

theorem envBound23394 : H12AffineFastState.Bounded env23394 := by
  intro p hp
  have h : env23394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23393_23394 : H12AffineEnvironment.transform 14 30073 env23393 = env23394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env23393 == env23394) = true)

theorem identity23394 : scanCanonicalize (H12AffineFastState.compose env23394 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 1504) := by decide +kernel

theorem selectedBound23394 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env23395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1504,16384,20633,20943,4233,3528,1024,20632,4161,21928,21692,21543,1384,65,2341,16829,4524,22884,1501,32,256,21793,16893,22053]

theorem envBound23395 : H12AffineFastState.Bounded env23395 := by
  intro p hp
  have h : env23395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23394_23395 : H12AffineEnvironment.transform 12 1504 env23394 = env23395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1504 env23394 == env23395) = true)

theorem identity23395 : scanCanonicalize (H12AffineFastState.compose env23395 (packedSelected [1,2,4,5,6,8,16,22,24] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23395 : packedSelected [1,2,4,5,6,8,16,22,24] rootPS < 2^1333 := by decide +kernel

def env23396 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,468,16384,20633,20943,4233,2556,52,20632,4161,20892,20616,20499,348,65,2341,16829,4524,22884,489,32,256,20757,16893,21009]

theorem envBound23396 : H12AffineFastState.Bounded env23396 := by
  intro p hp
  have h : env23396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23395_23396 : H12AffineEnvironment.transform 9 52 env23395 = env23396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23395 == env23396) = true)

theorem identity23396 : scanCanonicalize (H12AffineFastState.compose env23396 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23396 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env23397 : List Nat := [2,4,8,16,32,64,128,36,512,52,2048,4096,240,16384,20633,20715,4233,2264,52,20632,4161,20664,20616,20499,120,65,2049,16537,4232,22592,205,32,36,20529,16601,21009]

theorem envBound23397 : H12AffineFastState.Bounded env23397 := by
  intro p hp
  have h : env23397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23396_23397 : H12AffineEnvironment.transform 7 36 env23396 = env23397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23396 == env23397) = true)

theorem identity23397 : scanCanonicalize (H12AffineFastState.compose env23397 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound23397 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23398 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,41,16384,20544,20530,4176,2049,52,20545,4161,20577,20561,20499,120,65,2049,16448,4177,22592,20,32,36,20529,16384,21009]

theorem envBound23398 : H12AffineFastState.Bounded env23398 := by
  intro p hp
  have h : env23398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23397_23398 : H12AffineEnvironment.transform 6 89 env23397 = env23398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env23397 == env23398) = true)

theorem identity23398 : scanCanonicalize (H12AffineFastState.compose env23398 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound23398 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23399 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,41,4113,81,35,4176,2049,52,80,4161,112,64,2,120,65,2049,4177,4177,2129,20,32,36,32,4113,512]

theorem envBound23399 : H12AffineFastState.Bounded env23399 := by
  intro p hp
  have h : env23399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23398_23399 : H12AffineEnvironment.transform 13 4113 env23398 = env23399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env23398 == env23399) = true)

theorem identity23399 : scanCanonicalize (H12AffineFastState.compose env23399 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound23399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23400 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,112,41,97,81,35,32,2049,52,80,49,112,64,2,120,65,2049,33,33,2129,20,32,36,32,97,512]

theorem envBound23400 : H12AffineFastState.Bounded env23400 := by
  intro p hp
  have h : env23400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23399_23400 : H12AffineEnvironment.transform 11 112 env23399 = env23400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env23399 == env23400) = true)

theorem identity23400 : scanCanonicalize (H12AffineFastState.compose env23400 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23400 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23401 : List Nat := [2,4,8,16,32,48,41,36,512,52,2048,0,41,17,33,35,32,2049,52,32,49,0,48,2,8,49,2049,33,33,2081,20,32,36,32,17,512]

theorem envBound23401 : H12AffineFastState.Bounded env23401 := by
  intro p hp
  have h : env23401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23400_23401 : H12AffineEnvironment.transform 5 48 env23400 = env23401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23400 == env23401) = true)

theorem identity23401 : scanCanonicalize (H12AffineFastState.compose env23401 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound23401 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env23402 : List Nat := [2,4,8,16,32,48,41,36,512,52,32,0,41,17,33,35,32,33,52,32,49,0,48,2,8,49,33,33,33,1,20,32,36,32,17,512]

theorem envBound23402 : H12AffineFastState.Bounded env23402 := by
  intro p hp
  have h : env23402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23401_23402 : H12AffineEnvironment.transform 10 32 env23401 = env23402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env23401 == env23402) = true)

theorem identity23402 : scanCanonicalize (H12AffineFastState.compose env23402 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23402 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23403 : List Nat := [2,4,8,1,32,33,41,36,512,37,32,0,41,0,33,35,32,33,37,32,32,0,33,2,8,32,33,33,33,1,5,32,36,32,0,512]

theorem envBound23403 : H12AffineFastState.Bounded env23403 := by
  intro p hp
  have h : env23403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23402_23403 : H12AffineEnvironment.transform 3 1 env23402 = env23403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23402 == env23403) = true)

theorem identity23403 : scanCanonicalize (H12AffineFastState.compose env23403 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23403 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23404 : List Nat := [2,4,8,1,0,1,9,4,512,5,0,0,9,0,1,3,0,1,5,0,0,0,1,2,8,0,1,1,1,1,5,0,4,0,0,512]

theorem envBound23404 : H12AffineFastState.Bounded env23404 := by
  intro p hp
  have h : env23404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23403_23404 : H12AffineEnvironment.transform 4 0 env23403 = env23404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23403 == env23404) = true)

theorem identity23404 : scanCanonicalize (H12AffineFastState.compose env23404 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23405 : List Nat := [2,4,8,1,0,1,9,4,1,5,0,0,9,0,1,3,0,1,5,0,0,0,1,2,8,0,1,1,1,1,5,0,4,0,0,1]

theorem envBound23405 : H12AffineFastState.Bounded env23405 := by
  intro p hp
  have h : env23405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23404_23405 : H12AffineEnvironment.transform 8 1 env23404 = env23405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23404 == env23405) = true)

theorem identity23405 : scanCanonicalize (H12AffineFastState.compose env23405 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23406 : List Nat := [2,0,8,1,0,1,9,0,1,1,0,0,9,0,1,3,0,1,1,0,0,0,1,2,8,0,1,1,1,1,1,0,0,0,0,1]

theorem envBound23406 : H12AffineFastState.Bounded env23406 := by
  intro p hp
  have h : env23406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23405_23406 : H12AffineEnvironment.transform 1 0 env23405 = env23406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23405 == env23406) = true)

def env23407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21929,41412,73737,8328,65,64604,46277,58580,35325,1501,32,256,21793,46212,74250]

theorem envBound23407 : H12AffineFastState.Bounded env23407 := by
  intro p hp
  have h : env23407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23391_23407 : H12AffineEnvironment.transform 16 49169 env23391 = env23407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env23391 == env23407) = true)

theorem identity23407 : scanCanonicalize (H12AffineFastState.compose env23407 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound23407 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,49169,10280,1024,32769,4161,21929,41412,41431,8328,65,64604,46277,58580,35325,1501,32,256,21793,46212,41940]

theorem envBound23408 : H12AffineFastState.Bounded env23408 := by
  intro p hp
  have h : env23408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23407_23408 : H12AffineEnvironment.transform 15 33246 env23407 = env23408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env23407 == env23408) = true)

theorem identity23408 : scanCanonicalize (H12AffineFastState.compose env23408 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound23408 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env23409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12620,32768,33246,45405,10280,1024,32769,4161,9445,41412,41431,8328,65,36112,46277,38296,35325,1501,32,256,9325,46212,41940]

theorem envBound23409 : H12AffineFastState.Bounded env23409 := by
  intro p hp
  have h : env23409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23408_23409 : H12AffineEnvironment.transform 13 12620 env23408 = env23409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env23408 == env23409) = true)

theorem identity23409 : scanCanonicalize (H12AffineFastState.compose env23409 (packedSelected [0,9,11,18,19,22,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound23409 : packedSelected [0,9,11,18,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env23410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12620,1077,1515,13672,10280,1024,1076,4161,9445,9713,9698,8328,65,2341,12528,4525,3528,1501,32,256,9325,12465,10209]

theorem envBound23410 : H12AffineFastState.Bounded env23410 := by
  intro p hp
  have h : env23410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23409_23410 : H12AffineEnvironment.transform 14 1077 env23409 = env23410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env23409 == env23410) = true)

theorem identity23410 : scanCanonicalize (H12AffineFastState.compose env23410 (packedSelected [0,2,4,6,7,9,11,14,16,18,19,20,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23410 : packedSelected [0,2,4,6,7,9,11,14,16,18,19,20,26] rootPS < 2^1333 := by decide +kernel

def env23411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,4161,1077,1515,5221,2341,1024,1076,4161,1512,1276,1263,389,65,2341,4605,4525,3528,1501,32,256,1376,4540,1772]

theorem envBound23411 : H12AffineFastState.Bounded env23411 := by
  intro p hp
  have h : env23411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23410_23411 : H12AffineEnvironment.transform 12 269 env23410 = env23411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23410 == env23411) = true)

theorem identity23411 : scanCanonicalize (H12AffineFastState.compose env23411 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound23411 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23412 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,269,4161,429,115,4605,2341,408,428,4161,112,356,375,389,65,2341,4605,4525,2128,69,32,256,248,4540,884]

theorem envBound23412 : H12AffineFastState.Bounded env23412 := by
  intro p hp
  have h : env23412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23411_23412 : H12AffineEnvironment.transform 9 408 env23411 = env23412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env23411 == env23412) = true)

theorem identity23412 : scanCanonicalize (H12AffineFastState.compose env23412 (packedSelected [0,1,2,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound23412 : packedSelected [0,1,2,7,8,14] rootPS < 2^1333 := by decide +kernel

def env23413 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,429,269,492,429,115,80,2341,408,428,492,112,356,375,389,65,2341,80,0,2128,69,32,256,248,17,884]

theorem envBound23413 : H12AffineFastState.Bounded env23413 := by
  intro p hp
  have h : env23413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23412_23413 : H12AffineEnvironment.transform 11 429 env23412 = env23413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env23412 == env23413) = true)

theorem identity23413 : scanCanonicalize (H12AffineFastState.compose env23413 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound23413 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env23414 : List Nat := [2,4,8,16,32,64,128,252,512,100,2048,81,241,16,81,115,80,2265,100,80,16,112,152,139,121,65,2265,80,0,2128,69,32,252,248,17,648]

theorem envBound23414 : H12AffineFastState.Bounded env23414 := by
  intro p hp
  have h : env23414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23413_23414 : H12AffineEnvironment.transform 7 252 env23413 = env23414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env23413 == env23414) = true)

theorem identity23414 : scanCanonicalize (H12AffineFastState.compose env23414 (packedSelected [1,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23414 : packedSelected [1,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env23415 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,1,161,16,1,35,0,2185,52,0,16,32,152,139,41,17,2185,0,0,2048,21,32,172,168,17,648]

theorem envBound23415 : H12AffineFastState.Bounded env23415 := by
  intro p hp
  have h : env23415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23414_23415 : H12AffineEnvironment.transform 5 16 env23414 = env23415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23414 == env23415) = true)

theorem identity23415 : scanCanonicalize (H12AffineFastState.compose env23415 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound23415 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env23416 : List Nat := [2,4,8,16,32,16,128,172,512,52,162,1,161,16,1,35,0,43,52,0,16,32,152,139,41,17,43,0,0,162,21,32,172,168,17,648]

theorem envBound23416 : H12AffineFastState.Bounded env23416 := by
  intro p hp
  have h : env23416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23415_23416 : H12AffineEnvironment.transform 10 162 env23415 = env23416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env23415 == env23416) = true)

theorem identity23416 : scanCanonicalize (H12AffineFastState.compose env23416 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23416 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env23417 : List Nat := [2,4,8,16,32,16,128,172,32,52,162,1,161,16,1,35,0,43,52,0,16,32,152,139,41,17,43,0,0,162,21,32,172,168,17,168]

theorem envBound23417 : H12AffineFastState.Bounded env23417 := by
  intro p hp
  have h : env23417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23416_23417 : H12AffineEnvironment.transform 8 32 env23416 = env23417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23416 == env23417) = true)

theorem identity23417 : scanCanonicalize (H12AffineFastState.compose env23417 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound23417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23418 : List Nat := [2,4,8,16,31,16,128,147,31,11,157,1,158,16,1,28,0,20,11,0,16,31,152,139,22,17,20,0,0,157,21,31,147,151,17,151]

theorem envBound23418 : H12AffineFastState.Bounded env23418 := by
  intro p hp
  have h : env23418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23417_23418 : H12AffineEnvironment.transform 4 31 env23417 = env23418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env23417 == env23418) = true)

theorem identity23418 : scanCanonicalize (H12AffineFastState.compose env23418 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound23418 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23419 : List Nat := [2,4,8,13,2,13,128,142,2,11,128,1,131,13,1,1,0,9,11,0,13,2,133,139,11,12,9,0,0,128,8,2,142,138,12,138]

theorem envBound23419 : H12AffineFastState.Bounded env23419 := by
  intro p hp
  have h : env23419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23418_23419 : H12AffineEnvironment.transform 3 13 env23418 = env23419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env23418 == env23419) = true)

theorem identity23419 : scanCanonicalize (H12AffineFastState.compose env23419 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23419 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23420 : List Nat := [2,4,8,13,2,13,8,6,2,11,8,1,11,13,1,1,0,9,11,0,13,2,13,3,11,12,9,0,0,8,8,2,6,2,12,2]

theorem envBound23420 : H12AffineFastState.Bounded env23420 := by
  intro p hp
  have h : env23420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23419_23420 : H12AffineEnvironment.transform 6 8 env23419 = env23420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23419 == env23420) = true)

theorem identity23420 : scanCanonicalize (H12AffineFastState.compose env23420 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23421 : List Nat := [1,4,8,13,1,13,8,5,1,8,8,1,8,13,1,1,0,9,8,0,13,1,13,0,8,12,9,0,0,8,8,1,5,1,12,1]

theorem envBound23421 : H12AffineFastState.Bounded env23421 := by
  intro p hp
  have h : env23421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23420_23421 : H12AffineEnvironment.transform 0 1 env23420 = env23421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23420 == env23421) = true)

def env23422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169400,156116,253977,8328,65,64605,160981,140484,35325,1501,33,256,21793,46212,74250]

theorem envBound23422 : H12AffineFastState.Bounded env23422 := by
  intro p hp
  have h : env23422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23390_23422 : H12AffineEnvironment.transform 17 10281 env23390 = env23422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23390 == env23422) = true)

def env23423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21928,41412,73737,8328,65,64605,46277,58580,35325,1501,33,256,21793,46212,74250]

theorem envBound23423 : H12AffineFastState.Bounded env23423 := by
  intro p hp
  have h : env23423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23422_23423 : H12AffineEnvironment.transform 16 49168 env23422 = env23423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23422 == env23423) = true)

theorem identity23423 : scanCanonicalize (H12AffineFastState.compose env23423 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23423 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4161,21928,41412,2,8328,65,64605,46277,58580,35325,1501,33,256,21793,46212,513]

theorem envBound23424 : H12AffineFastState.Bounded env23424 := by
  intro p hp
  have h : env23424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23423_23424 : H12AffineEnvironment.transform 15 8203 env23423 = env23424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23423 == env23424) = true)

theorem identity23424 : scanCanonicalize (H12AffineFastState.compose env23424 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23424 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,16401,10281,1024,0,4161,21928,8645,2,8328,65,31836,13508,25813,2556,1501,33,256,21793,13445,513]

theorem envBound23425 : H12AffineFastState.Bounded env23425 := by
  intro p hp
  have h : env23425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23424_23425 : H12AffineEnvironment.transform 14 1 env23424 = env23425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23424 == env23425) = true)

def env23426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21929,41413,73736,8328,65,64605,46276,58581,35325,1501,33,256,21793,46212,74250]

theorem envBound23426 : H12AffineFastState.Bounded env23426 := by
  intro p hp
  have h : env23426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23422_23426 : H12AffineEnvironment.transform 16 49169 env23422 = env23426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env23422 == env23426) = true)

theorem identity23426 : scanCanonicalize (H12AffineFastState.compose env23426 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound23426 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1024,32769,4161,21929,41413,138,8328,65,64605,46276,58581,35325,1501,33,256,21793,46212,648]

theorem envBound23427 : H12AffineFastState.Bounded env23427 := by
  intro p hp
  have h : env23427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23426_23427 : H12AffineEnvironment.transform 15 8322 env23426 = env23427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env23426 == env23427) = true)

theorem identity23427 : scanCanonicalize (H12AffineFastState.compose env23427 (packedSelected [10,12,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound23427 : packedSelected [10,12,18,19,23] rootPS < 2^1333 := by decide +kernel

def env23428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8580,8322,24981,10281,1024,8581,4161,21929,65,138,8328,65,24025,5440,17745,10361,1501,33,256,21793,5376,648]

theorem envBound23428 : H12AffineFastState.Bounded env23428 := by
  intro p hp
  have h : env23428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23427_23428 : H12AffineEnvironment.transform 14 8580 env23427 = env23428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env23427 == env23428) = true)

theorem identity23428 : scanCanonicalize (H12AffineFastState.compose env23428 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23428 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env23429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,216,478,16585,2421,1024,217,4161,21929,65,138,468,65,24025,5440,17745,2341,1501,33,256,21793,5376,648]

theorem envBound23429 : H12AffineFastState.Bounded env23429 := by
  intro p hp
  have h : env23429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23428_23429 : H12AffineEnvironment.transform 12 348 env23428 = env23429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23428 == env23429) = true)

theorem identity23429 : scanCanonicalize (H12AffineFastState.compose env23429 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23429 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23430 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,137,399,16536,2340,1024,136,4112,21929,16,138,389,16,23944,5393,17664,2341,1420,33,256,21793,5376,648]

theorem envBound23430 : H12AffineFastState.Bounded env23430 := by
  intro p hp
  have h : env23430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23429_23430 : H12AffineEnvironment.transform 5 17 env23429 = env23430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23429 == env23430) = true)

theorem identity23430 : scanCanonicalize (H12AffineFastState.compose env23430 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23430 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23431 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,263,16400,2340,1024,0,4112,21793,16,2,269,16,23808,5393,17664,2341,1284,33,256,21793,5376,512]

theorem envBound23431 : H12AffineFastState.Bounded env23431 := by
  intro p hp
  have h : env23431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23430_23431 : H12AffineEnvironment.transform 6 8 env23430 = env23431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23430 == env23431) = true)

theorem identity23431 : scanCanonicalize (H12AffineFastState.compose env23431 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23431 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23432 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,1,263,16400,2308,1024,0,4112,21761,16,2,269,16,23808,5393,17664,2309,1284,1,256,21761,5376,512]

theorem envBound23432 : H12AffineFastState.Bounded env23432 := by
  intro p hp
  have h : env23432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23431_23432 : H12AffineEnvironment.transform 4 0 env23431 = env23432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23431 == env23432) = true)

theorem identity23432 : scanCanonicalize (H12AffineFastState.compose env23432 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound23432 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23433 : List Nat := [2,4,8,16,0,17,8,256,512,1024,523,4096,269,16384,1,263,16400,783,1024,0,4112,21761,16,2,269,16,22283,5393,17664,782,1284,1,256,21761,5376,512]

theorem envBound23433 : H12AffineFastState.Bounded env23433 := by
  intro p hp
  have h : env23433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23432_23433 : H12AffineEnvironment.transform 10 523 env23432 = env23433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env23432 == env23433) = true)

theorem identity23433 : scanCanonicalize (H12AffineFastState.compose env23433 (packedSelected [1,3,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23433 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env23434 : List Nat := [2,4,8,16,0,17,8,256,512,1024,523,4096,269,5377,1,263,5393,783,1024,0,4112,0,16,2,269,16,522,5393,4097,782,1284,1,256,0,5376,512]

theorem envBound23434 : H12AffineFastState.Bounded env23434 := by
  intro p hp
  have h : env23434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23433_23434 : H12AffineEnvironment.transform 13 5377 env23433 = env23434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23433 == env23434) = true)

theorem identity23434 : scanCanonicalize (H12AffineFastState.compose env23434 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23434 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23435 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,4096,8,5124,1,2,5140,522,1024,0,4112,0,16,2,8,16,522,5140,4097,523,1025,1,5,0,5125,512]

theorem envBound23435 : H12AffineFastState.Bounded env23435 := by
  intro p hp
  have h : env23435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23434_23435 : H12AffineEnvironment.transform 7 5 env23434 = env23435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23434 == env23435) = true)

def env23436 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,16,8,1044,1,2,1028,522,1024,0,0,0,16,2,8,16,522,1028,17,523,1025,1,5,0,1045,512]

theorem envBound23436 : H12AffineFastState.Bounded env23436 := by
  intro p hp
  have h : env23436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23435_23436 : H12AffineEnvironment.transform 11 16 env23435 = env23436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23435 == env23436) = true)

theorem identity23436 : scanCanonicalize (H12AffineFastState.compose env23436 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound23436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23437 : List Nat := [2,4,8,16,0,17,8,5,512,523,523,16,8,543,1,2,527,522,523,0,0,0,16,2,8,16,522,527,17,523,522,1,5,0,542,512]

theorem envBound23437 : H12AffineFastState.Bounded env23437 := by
  intro p hp
  have h : env23437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23436_23437 : H12AffineEnvironment.transform 9 523 env23436 = env23437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env23436 == env23437) = true)

def env23438 : List Nat := [2,4,8,4,0,5,8,5,512,523,523,4,8,523,1,2,527,522,523,0,0,0,4,2,8,4,522,527,5,523,522,1,5,0,522,512]

theorem envBound23438 : H12AffineFastState.Bounded env23438 := by
  intro p hp
  have h : env23438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23437_23438 : H12AffineEnvironment.transform 3 4 env23437 = env23438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23437 == env23438) = true)

theorem identity23438 : scanCanonicalize (H12AffineFastState.compose env23438 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23439 : List Nat := [1,4,8,4,0,5,8,5,512,520,520,4,8,520,1,1,524,521,520,0,0,0,4,1,8,4,521,524,5,520,521,1,5,0,521,512]

theorem envBound23439 : H12AffineFastState.Bounded env23439 := by
  intro p hp
  have h : env23439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23438_23439 : H12AffineEnvironment.transform 0 1 env23438 = env23439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23438 == env23439) = true)

def leafEnv23439 : List Nat := [1,4,8,4,0,5,8,5,512,520,520,4,8,520,1,1,524,521,520,0,0,0,4,1,520,8,1,4,521,524,5,520,521,1,5,0,5,1,521,512,1,1,0]

def active23439 : List Nat := [1,2,8]

def tree23439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23439 : H12WitnessSearch.Good tree23439 := H12GlobalWitnessIndex.good

theorem leafIdentity23439 : H12AffineFastState.composeSystem env23439 rootObs = leafEnv23439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23439 rootObs == leafEnv23439) = true)

theorem terminalChecked23439 : H12PackedTerminal.terminalCheckFast leafEnv23439 active23439 tree23439 = true := by decide +kernel

def env23440 : List Nat := [2,4,8,5,0,4,8,5,512,523,523,5,8,522,1,2,527,522,523,0,0,0,5,2,8,5,522,527,4,523,522,1,5,0,523,512]

theorem envBound23440 : H12AffineFastState.Bounded env23440 := by
  intro p hp
  have h : env23440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23437_23440 : H12AffineEnvironment.transform 3 5 env23437 = env23440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env23437 == env23440) = true)

theorem identity23440 : scanCanonicalize (H12AffineFastState.compose env23440 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound23440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23441 : List Nat := [2,4,8,5,0,4,8,5,9,2,2,5,8,3,1,2,6,3,2,0,0,0,5,2,8,5,3,6,4,2,3,1,5,0,2,9]

theorem envBound23441 : H12AffineFastState.Bounded env23441 := by
  intro p hp
  have h : env23441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23440_23441 : H12AffineEnvironment.transform 8 9 env23440 = env23441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env23440 == env23441) = true)

def leafEnv23441 : List Nat := [2,4,8,5,0,4,8,5,9,2,2,5,8,3,1,2,6,3,2,0,0,0,5,2,2,8,1,5,3,6,4,2,3,1,5,0,5,2,2,9,1,1,0]

def active23441 : List Nat := [0,1,2]

def tree23441 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23441 : H12WitnessSearch.Good tree23441 := H12GlobalWitnessIndex.good

theorem leafIdentity23441 : H12AffineFastState.composeSystem env23441 rootObs = leafEnv23441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23441 rootObs == leafEnv23441) = true)

theorem terminalChecked23441 : H12PackedTerminal.terminalCheckFast leafEnv23441 active23441 tree23441 = true := by decide +kernel

def env23442 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,17,8,1045,1,2,1029,522,1024,0,1,0,16,2,8,16,522,1029,16,523,1025,1,5,0,1044,512]

theorem envBound23442 : H12AffineFastState.Bounded env23442 := by
  intro p hp
  have h : env23442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23435_23442 : H12AffineEnvironment.transform 11 17 env23435 = env23442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23435 == env23442) = true)

theorem identity23442 : scanCanonicalize (H12AffineFastState.compose env23442 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound23442 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23443 : List Nat := [2,4,8,16,0,17,8,5,31,1024,20,17,8,1045,1,2,1029,21,1024,0,1,0,16,2,8,16,21,1029,16,20,1025,1,5,0,1044,31]

theorem envBound23443 : H12AffineFastState.Bounded env23443 := by
  intro p hp
  have h : env23443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23442_23443 : H12AffineEnvironment.transform 8 31 env23442 = env23443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env23442 == env23443) = true)

def env23444 : List Nat := [2,4,8,16,0,17,8,5,31,0,20,17,8,21,1,2,5,21,0,0,1,0,16,2,8,16,21,5,16,20,1,1,5,0,20,31]

theorem envBound23444 : H12AffineFastState.Bounded env23444 := by
  intro p hp
  have h : env23444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23443_23444 : H12AffineEnvironment.transform 9 0 env23443 = env23444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env23443 == env23444) = true)

theorem identity23444 : scanCanonicalize (H12AffineFastState.compose env23444 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound23444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23445 : List Nat := [2,4,8,7,0,6,8,5,8,0,3,6,8,2,1,2,5,2,0,0,1,0,7,2,8,7,2,5,7,3,1,1,5,0,3,8]

theorem envBound23445 : H12AffineFastState.Bounded env23445 := by
  intro p hp
  have h : env23445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23444_23445 : H12AffineEnvironment.transform 3 7 env23444 = env23445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env23444 == env23445) = true)

def leafEnv23445 : List Nat := [2,4,8,7,0,6,8,5,8,0,3,6,8,2,1,2,5,2,0,0,1,0,7,2,0,8,1,7,2,5,7,3,1,1,5,0,5,2,3,8,1,0,0]

def active23445 : List Nat := [0,1,2]

def tree23445 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23445 : H12WitnessSearch.Good tree23445 := H12GlobalWitnessIndex.good

theorem leafIdentity23445 : H12AffineFastState.composeSystem env23445 rootObs = leafEnv23445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23445 rootObs == leafEnv23445) = true)

theorem terminalChecked23445 : H12PackedTerminal.terminalCheckFast leafEnv23445 active23445 tree23445 = true := by decide +kernel

def env23446 : List Nat := [2,4,8,16,0,17,8,5,31,1,20,17,8,20,1,2,4,21,1,0,1,0,16,2,8,16,21,4,16,20,0,1,5,0,21,31]

theorem envBound23446 : H12AffineFastState.Bounded env23446 := by
  intro p hp
  have h : env23446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23443_23446 : H12AffineEnvironment.transform 9 1 env23443 = env23446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env23443 == env23446) = true)

theorem identity23446 : scanCanonicalize (H12AffineFastState.compose env23446 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23447 : List Nat := [1,4,8,16,0,17,8,5,28,1,20,17,8,20,1,1,4,21,1,0,1,0,16,1,8,16,21,4,16,20,0,1,5,0,21,28]

theorem envBound23447 : H12AffineFastState.Bounded env23447 := by
  intro p hp
  have h : env23447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23446_23447 : H12AffineEnvironment.transform 0 1 env23446 = env23447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23446 == env23447) = true)

def leafEnv23447 : List Nat := [1,4,8,16,0,17,8,5,28,1,20,17,8,20,1,1,4,21,1,0,1,0,16,1,1,8,1,16,21,4,16,20,0,1,5,0,5,1,21,28,1,0,0]

def active23447 : List Nat := [1,2,3]

def tree23447 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23447 : H12WitnessSearch.Good tree23447 := H12GlobalWitnessIndex.good

theorem leafIdentity23447 : H12AffineFastState.composeSystem env23447 rootObs = leafEnv23447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23447 rootObs == leafEnv23447) = true)

theorem terminalChecked23447 : H12PackedTerminal.terminalCheckFast leafEnv23447 active23447 tree23447 = true := by decide +kernel

def env23448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513340,510000,8328,65,2409524,2510013,396525,2136508,2102684,2373704,256,21793,46212,2175563]

theorem envBound23448 : H12AffineFastState.Bounded env23448 := by
  intro p hp
  have h : env23448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23373_23448 : H12AffineEnvironment.transform 21 169401 env23373 = env23448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env23373 == env23448) = true)

def env23449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,510000,8328,65,316532,417021,396525,35324,1500,272392,256,21793,46212,74251]

theorem envBound23449 : H12AffineFastState.Bounded env23449 := by
  intro p hp
  have h : env23449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23448_23449 : H12AffineEnvironment.transform 20 4160 env23448 = env23449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23448 == env23449) = true)

theorem identity23449 : scanCanonicalize (H12AffineFastState.compose env23449 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23449 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,156012,412156,474341,8328,65,270497,417021,396525,32041,1500,272392,256,21793,16465,74251]

theorem envBound23450 : H12AffineFastState.Bounded env23450 := by
  intro p hp
  have h : env23450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23449_23450 : H12AffineEnvironment.transform 14 29909 env23449 = env23450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23449 == env23450) = true)

def env23451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32240,1024,29908,4160,156012,144396,213269,8328,65,23889,139533,160029,32041,1500,22008,256,21793,16465,74251]

theorem envBound23451 : H12AffineFastState.Bounded env23451 := by
  intro p hp
  have h : env23451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23450_23451 : H12AffineEnvironment.transform 17 32240 env23450 = env23451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env23450 == env23451) = true)

theorem identity23451 : scanCanonicalize (H12AffineFastState.compose env23451 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound23451 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79130,32240,1024,29908,4160,87158,65814,29711,8328,65,23889,70679,82951,32041,1500,22008,256,21793,16465,74251]

theorem envBound23452 : H12AffineFastState.Bounded env23452 := by
  intro p hp
  have h : env23452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23451_23452 : H12AffineEnvironment.transform 16 79130 env23451 = env23452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env23451 == env23452) = true)

theorem identity23452 : scanCanonicalize (H12AffineFastState.compose env23452 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30162) := by decide +kernel

theorem selectedBound23452 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env23453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30162,16584,32240,1024,29908,4160,8612,29892,29711,8328,65,23889,25029,12757,32041,1500,22008,256,21793,16465,22489]

theorem envBound23453 : H12AffineFastState.Bounded env23453 := by
  intro p hp
  have h : env23453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23452_23453 : H12AffineEnvironment.transform 15 30162 env23452 = env23453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30162 env23452 == env23453) = true)

theorem identity23453 : scanCanonicalize (H12AffineFastState.compose env23453 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound23453 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env23454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8461,8202,5392,10280,1024,8460,4160,8612,8476,8663,8328,65,2185,13341,12757,10481,1500,32,256,249,5513,513]

theorem envBound23454 : H12AffineFastState.Bounded env23454 := by
  intro p hp
  have h : env23454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23453_23454 : H12AffineEnvironment.transform 13 5592 env23453 = env23454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env23453 == env23454) = true)

theorem identity23454 : scanCanonicalize (H12AffineFastState.compose env23454 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound23454 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5592,1296,1047,5392,3125,1024,1297,4160,1465,1281,1482,1173,65,2185,4096,5576,3308,1500,32,256,249,5513,513]

theorem envBound23455 : H12AffineFastState.Bounded env23455 := by
  intro p hp
  have h : env23455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23454_23455 : H12AffineEnvironment.transform 12 1053 env23454 = env23455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env23454 == env23455) = true)

theorem identity23455 : scanCanonicalize (H12AffineFastState.compose env23455 (packedSelected [0,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound23455 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env23456 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,1053,5377,1296,1047,5392,3125,1024,1297,4160,1376,1281,1299,1100,65,2128,4096,5393,3125,1285,32,256,32,5456,513]

theorem envBound23456 : H12AffineFastState.Bounded env23456 := by
  intro p hp
  have h : env23456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23455_23456 : H12AffineEnvironment.transform 6 89 env23455 = env23456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env23455 == env23456) = true)

theorem identity23456 : scanCanonicalize (H12AffineFastState.compose env23456 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound23456 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23457 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2138,1053,3419,1296,1047,3402,3125,1024,1297,2074,1376,1281,1299,1100,65,2128,2138,3403,3125,1285,32,256,32,3338,513]

theorem envBound23457 : H12AffineFastState.Bounded env23457 := by
  intro p hp
  have h : env23457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23456_23457 : H12AffineEnvironment.transform 11 2138 env23456 = env23457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env23456 == env23457) = true)

theorem identity23457 : scanCanonicalize (H12AffineFastState.compose env23457 (packedSelected [0,2,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound23457 : packedSelected [0,2,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env23458 : List Nat := [2,4,8,16,32,64,89,95,512,1024,2048,2138,1053,3076,1103,1047,3093,3125,1024,1102,2074,1087,1118,1100,1100,65,2128,2138,3092,3125,1114,32,95,32,3157,513]

theorem envBound23458 : H12AffineFastState.Bounded env23458 := by
  intro p hp
  have h : env23458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23457_23458 : H12AffineEnvironment.transform 7 95 env23457 = env23458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env23457 == env23458) = true)

theorem identity23458 : scanCanonicalize (H12AffineFastState.compose env23458 (packedSelected [1,2,5,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound23458 : packedSelected [1,2,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env23459 : List Nat := [2,4,8,16,32,64,89,95,512,1024,74,16,1053,1102,1103,1047,1119,1151,1024,1102,80,1087,1118,1100,1100,65,26,16,1118,1151,1114,32,95,32,1055,513]

theorem envBound23459 : H12AffineFastState.Bounded env23459 := by
  intro p hp
  have h : env23459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23458_23459 : H12AffineEnvironment.transform 10 74 env23458 = env23459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env23458 == env23459) = true)

theorem identity23459 : scanCanonicalize (H12AffineFastState.compose env23459 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound23459 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env23460 : List Nat := [2,4,8,16,32,64,89,95,512,4,74,16,25,74,75,19,91,123,4,74,80,59,90,72,72,65,26,16,90,123,94,32,95,32,27,513]

theorem envBound23460 : H12AffineFastState.Bounded env23460 := by
  intro p hp
  have h : env23460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23459_23460 : H12AffineEnvironment.transform 9 4 env23459 = env23460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env23459 == env23460) = true)

theorem identity23460 : scanCanonicalize (H12AffineFastState.compose env23460 (packedSelected [0,1,2,3,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound23460 : packedSelected [0,1,2,3,6,9] rootPS < 2^1333 := by decide +kernel

def env23461 : List Nat := [2,4,8,16,32,58,35,37,512,4,48,16,25,48,49,19,33,1,4,48,42,59,32,50,50,59,26,16,32,1,36,32,37,32,27,513]

theorem envBound23461 : H12AffineFastState.Bounded env23461 := by
  intro p hp
  have h : env23461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23460_23461 : H12AffineEnvironment.transform 5 58 env23460 = env23461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env23460 == env23461) = true)

theorem identity23461 : scanCanonicalize (H12AffineFastState.compose env23461 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23462 : List Nat := [2,4,8,16,0,26,3,5,512,4,16,16,25,16,17,19,1,1,4,16,10,27,0,18,18,27,26,16,0,1,4,0,5,0,27,513]

theorem envBound23462 : H12AffineFastState.Bounded env23462 := by
  intro p hp
  have h : env23462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23461_23462 : H12AffineEnvironment.transform 4 0 env23461 = env23462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23461 == env23462) = true)

theorem identity23462 : scanCanonicalize (H12AffineFastState.compose env23462 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound23462 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env23463 : List Nat := [2,4,8,16,0,26,3,5,31,4,16,16,25,16,17,19,1,1,4,16,10,27,0,18,18,27,26,16,0,1,4,0,5,0,27,30]

theorem envBound23463 : H12AffineFastState.Bounded env23463 := by
  intro p hp
  have h : env23463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23462_23463 : H12AffineEnvironment.transform 8 31 env23462 = env23463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env23462 == env23463) = true)

theorem identity23463 : scanCanonicalize (H12AffineFastState.compose env23463 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound23463 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env23464 : List Nat := [2,4,8,3,0,9,3,5,12,4,3,3,10,3,2,0,1,1,4,3,10,8,0,1,1,8,9,3,0,1,4,0,5,0,8,13]

theorem envBound23464 : H12AffineFastState.Bounded env23464 := by
  intro p hp
  have h : env23464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23463_23464 : H12AffineEnvironment.transform 3 3 env23463 = env23464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env23463 == env23464) = true)

theorem identity23464 : scanCanonicalize (H12AffineFastState.compose env23464 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23464 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23465 : List Nat := [0,4,8,1,0,9,1,5,12,4,1,1,8,1,0,0,1,1,4,1,8,8,0,1,1,8,9,1,0,1,4,0,5,0,8,13]

theorem envBound23465 : H12AffineFastState.Bounded env23465 := by
  intro p hp
  have h : env23465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23464_23465 : H12AffineEnvironment.transform 0 0 env23464 = env23465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23464 == env23465) = true)

def env23466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32241,1024,29908,4160,156012,144397,213268,8328,65,23888,139532,160028,32041,1500,22009,256,21793,16465,74251]

theorem envBound23466 : H12AffineFastState.Bounded env23466 := by
  intro p hp
  have h : env23466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23450_23466 : H12AffineEnvironment.transform 17 32241 env23450 = env23466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env23450 == env23466) = true)

theorem identity23466 : scanCanonicalize (H12AffineFastState.compose env23466 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound23466 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79250,32241,1024,29908,4160,87294,65951,29830,8328,65,23888,70814,83086,32041,1500,22009,256,21793,16465,74251]

theorem envBound23467 : H12AffineFastState.Bounded env23467 := by
  intro p hp
  have h : env23467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23466_23467 : H12AffineEnvironment.transform 16 79250 env23466 = env23467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env23466 == env23467) = true)

theorem identity23467 : scanCanonicalize (H12AffineFastState.compose env23467 (packedSelected [0,1,3,4,5,7,8,16,17,18,19,20,22,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound23467 : packedSelected [0,1,3,4,5,7,8,16,17,18,19,20,22,23,31] rootPS < 2^1333 := by decide +kernel

def env23468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30042,16584,32241,1024,29908,4160,8612,29893,29830,8328,65,23888,25028,12756,32041,1500,22009,256,21793,16465,22353]

theorem envBound23468 : H12AffineFastState.Bounded env23468 := by
  intro p hp
  have h : env23468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23467_23468 : H12AffineEnvironment.transform 15 30042 env23467 = env23468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env23467 == env23468) = true)

theorem identity23468 : scanCanonicalize (H12AffineFastState.compose env23468 (packedSelected [3,5,9,11,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 11460) := by decide +kernel

theorem selectedBound23468 : packedSelected [3,5,9,11,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11460,6161,6558,11276,4405,1024,6160,4160,8612,6145,6210,8328,65,12692,3328,12756,4589,1500,14653,256,14821,11413,15253]

theorem envBound23469 : H12AffineFastState.Bounded env23469 := by
  intro p hp
  have h : env23469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23468_23469 : H12AffineEnvironment.transform 13 11460 env23468 = env23469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11460 env23468 == env23469) = true)

theorem identity23469 : scanCanonicalize (H12AffineFastState.compose env23469 (packedSelected [0,2,6,7,10,11,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound23469 : packedSelected [0,2,6,7,10,11,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env23470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,8192,11460,2476,2083,11276,136,1024,2477,509,8612,2492,2559,8328,65,8233,3328,8297,80,1500,10368,256,10328,11413,10792]

theorem envBound23470 : H12AffineFastState.Bounded env23470 := by
  intro p hp
  have h : env23470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23469_23470 : H12AffineEnvironment.transform 11 445 env23469 = env23470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env23469 == env23470) = true)

theorem identity23470 : scanCanonicalize (H12AffineFastState.compose env23470 (packedSelected [3,5,15,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23470 : packedSelected [3,5,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env23471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,445,8192,9412,428,35,9228,136,1024,429,509,8612,444,511,8328,65,8233,1280,8297,80,1500,8320,256,8280,9365,8744]

theorem envBound23471 : H12AffineFastState.Bounded env23471 := by
  intro p hp
  have h : env23471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23470_23471 : H12AffineEnvironment.transform 10 0 env23470 = env23471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23470 == env23471) = true)

theorem identity23471 : scanCanonicalize (H12AffineFastState.compose env23471 (packedSelected [0,2,6,7,12,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound23471 : packedSelected [0,2,6,7,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env23472 : List Nat := [2,4,8,16,32,64,128,256,512,456,0,445,8192,8460,428,35,8644,136,456,429,509,8612,444,511,8328,65,8233,200,8297,80,20,8320,256,8280,8541,8744]

theorem envBound23472 : H12AffineFastState.Bounded env23472 := by
  intro p hp
  have h : env23472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23471_23472 : H12AffineEnvironment.transform 9 456 env23471 = env23472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env23471 == env23472) = true)

theorem identity23472 : scanCanonicalize (H12AffineFastState.compose env23472 (packedSelected [2,3,4,5,6,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23472 : packedSelected [2,3,4,5,6,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23473 : List Nat := [2,4,8,16,32,16,128,256,512,408,0,445,8192,8460,428,35,8596,136,408,429,429,8612,444,431,8328,17,8233,152,8249,0,20,8320,256,8200,8461,8744]

theorem envBound23473 : H12AffineFastState.Bounded env23473 := by
  intro p hp
  have h : env23473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23472_23473 : H12AffineEnvironment.transform 5 16 env23472 = env23473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23472 == env23473) = true)

theorem identity23473 : scanCanonicalize (H12AffineFastState.compose env23473 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23473 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23474 : List Nat := [2,4,8,16,32,16,128,256,512,408,0,445,268,0,428,35,152,136,408,429,429,168,444,431,388,17,293,152,309,0,20,396,256,260,1,804]

theorem envBound23474 : H12AffineFastState.Bounded env23474 := by
  intro p hp
  have h : env23474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23473_23474 : H12AffineEnvironment.transform 12 268 env23473 = env23474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23473 == env23474) = true)

theorem identity23474 : scanCanonicalize (H12AffineFastState.compose env23474 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23474 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23475 : List Nat := [2,4,8,16,32,16,128,37,512,189,0,152,41,0,137,35,152,136,189,136,136,168,153,138,161,17,0,152,16,0,20,169,37,33,1,513]

theorem envBound23475 : H12AffineFastState.Bounded env23475 := by
  intro p hp
  have h : env23475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23474_23475 : H12AffineEnvironment.transform 7 37 env23474 = env23475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23474 == env23475) = true)

def env23476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,510000,8328,65,316533,417020,396525,35325,1501,272393,256,21793,46212,74250]

theorem envBound23476 : H12AffineFastState.Bounded env23476 := by
  intro p hp
  have h : env23476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23448_23476 : H12AffineEnvironment.transform 20 4161 env23448 = env23476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23448 == env23476) = true)

theorem identity23476 : scanCanonicalize (H12AffineFastState.compose env23476 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound23476 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,169401,16,98781,8328,65,171416,5393,17664,35325,1501,156132,256,21793,46212,74250]

theorem envBound23477 : H12AffineFastState.Bounded env23477 := by
  intro p hp
  have h : env23477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23476_23477 : H12AffineEnvironment.transform 17 149997 env23476 = env23477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env23476 == env23477) = true)

def env23478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,16,98645,8192,65,171280,5393,17664,35189,1365,156012,256,21793,46092,74250]

theorem envBound23478 : H12AffineFastState.Bounded env23478 := by
  intro p hp
  have h : env23478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23477_23478 : H12AffineEnvironment.transform 6 8 env23477 = env23478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23477 == env23478) = true)

theorem identity23478 : scanCanonicalize (H12AffineFastState.compose env23478 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound23478 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,108926,1024,32769,4161,95530,16,98645,8192,65,97547,5393,17664,35189,1365,98679,256,21793,46092,74250]

theorem envBound23479 : H12AffineFastState.Bounded env23479 := by
  intro p hp
  have h : env23479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23478_23479 : H12AffineEnvironment.transform 16 122907 env23478 = env23479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env23478 == env23479) = true)

theorem identity23479 : scanCanonicalize (H12AffineFastState.compose env23479 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound23479 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33031,24860,10361,1024,32769,4161,62509,16,82,8192,65,64524,5393,17664,35189,1365,112,256,21793,46092,41741]

theorem envBound23480 : H12AffineFastState.Bounded env23480 := by
  intro p hp
  have h : env23480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23479_23480 : H12AffineEnvironment.transform 15 33031 env23479 = env23480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env23479 == env23480) = true)

theorem identity23480 : scanCanonicalize (H12AffineFastState.compose env23480 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23480 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23481 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,32768,32802,24633,10361,1024,32769,4161,62509,16,82,8192,65,64524,5172,17445,34896,1136,112,37,21508,46092,41512]

theorem envBound23481 : H12AffineFastState.Bounded env23481 := by
  intro p hp
  have h : env23481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23480_23481 : H12AffineEnvironment.transform 7 37 env23480 = env23481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23480 == env23481) = true)

theorem identity23481 : scanCanonicalize (H12AffineFastState.compose env23481 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound23481 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env23482 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,21540,21510,24633,10361,1024,21541,4161,8201,16,82,8192,65,10280,5172,17445,23668,1136,112,37,21508,24616,30220]

theorem envBound23482 : H12AffineFastState.Bounded env23482 := by
  intro p hp
  have h : env23482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23481_23482 : H12AffineEnvironment.transform 14 21540 env23481 = env23482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env23481 == env23482) = true)

theorem identity23482 : scanCanonicalize (H12AffineFastState.compose env23482 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23482 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23483 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,21540,21510,16400,2128,1024,21541,4161,32,16,82,41,65,2049,5172,17445,23668,1136,112,37,21508,16385,22053]

theorem envBound23483 : H12AffineFastState.Bounded env23483 := by
  intro p hp
  have h : env23483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23482_23483 : H12AffineEnvironment.transform 12 41 env23482 = env23483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23482 == env23483) = true)

def env23484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,98644,8193,65,171281,5393,17664,35188,1364,156013,256,21793,46093,74250]

theorem envBound23484 : H12AffineFastState.Bounded env23484 := by
  intro p hp
  have h : env23484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23477_23484 : H12AffineEnvironment.transform 6 9 env23477 = env23484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23477 == env23484) = true)

theorem identity23484 : scanCanonicalize (H12AffineFastState.compose env23484 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound23484 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1024,32769,4161,119926,16,98644,8193,65,121943,5393,17664,35188,1364,73771,256,21793,46093,74250]

theorem envBound23485 : H12AffineFastState.Bounded env23485 := by
  intro p hp
  have h : env23485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23484_23485 : H12AffineEnvironment.transform 16 82246 env23484 = env23485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env23484 == env23485) = true)

theorem identity23485 : scanCanonicalize (H12AffineFastState.compose env23485 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound23485 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env23486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,46157,64809,1024,32769,4161,8573,16,29791,8193,65,10588,5393,17664,35188,1364,54560,256,21793,46093,55041]

theorem envBound23486 : H12AffineFastState.Bounded env23486 := by
  intro p hp
  have h : env23486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23485_23486 : H12AffineEnvironment.transform 15 62731 env23485 = env23486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env23485 == env23486) = true)

theorem identity23486 : scanCanonicalize (H12AffineFastState.compose env23486 (packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound23486 : packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env23487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,16400,2420,1024,29788,4161,8573,16,29791,8193,65,10588,5393,17664,32041,1364,8573,256,21793,16464,9052]

theorem envBound23487 : H12AffineFastState.Bounded env23487 := by
  intro p hp
  have h : env23487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23486_23487 : H12AffineEnvironment.transform 14 29789 env23486 = env23487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env23486 == env23487) = true)

def env23488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513341,510000,8328,65,6705548,2510013,396524,2136509,2102685,6729201,256,21792,46213,2175562]

theorem envBound23488 : H12AffineFastState.Bounded env23488 := by
  intro p hp
  have h : env23488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23372_23488 : H12AffineEnvironment.transform 22 2513341 env23372 = env23488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513341 env23372 == env23488) = true)

def env23489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513341,510000,8328,65,2409524,2510013,396524,2136509,2102685,2373705,256,21792,46213,2175562]

theorem envBound23489 : H12AffineFastState.Bounded env23489 := by
  intro p hp
  have h : env23489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23488_23489 : H12AffineEnvironment.transform 21 169400 env23488 = env23489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env23488 == env23489) = true)

def env23490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,510000,8328,65,316532,417021,396524,35325,1501,272393,256,21792,46213,74250]

theorem envBound23490 : H12AffineFastState.Bounded env23490 := by
  intro p hp
  have h : env23490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23489_23490 : H12AffineEnvironment.transform 20 4160 env23489 = env23490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23489 == env23490) = true)

theorem identity23490 : scanCanonicalize (H12AffineFastState.compose env23490 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound23490 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,169400,73755,41430,8328,65,245138,79131,91402,35325,1501,213487,256,21792,46213,74250]

theorem envBound23491 : H12AffineFastState.Bounded env23491 := by
  intro p hp
  have h : env23491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23490_23491 : H12AffineEnvironment.transform 17 223718 env23490 = env23491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env23490 == env23491) = true)

def env23492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67754,1024,32769,4160,62708,73755,41430,8328,65,122078,79131,91402,35325,1501,73891,256,21792,46213,74250]

theorem envBound23492 : H12AffineFastState.Bounded env23492 := by
  intro p hp
  have h : env23492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23491_23492 : H12AffineEnvironment.transform 16 24908 env23491 = env23492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env23491 == env23492) = true)

theorem identity23492 : scanCanonicalize (H12AffineFastState.compose env23492 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 9696) := by decide +kernel

theorem selectedBound23492 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env23493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9696,65536,24908,67754,1024,9697,4160,20756,73755,1078,8328,65,96574,79131,91402,11293,1501,73891,256,21792,4453,74250]

theorem envBound23493 : H12AffineFastState.Bounded env23493 := by
  intro p hp
  have h : env23493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23492_23493 : H12AffineEnvironment.transform 14 9696 env23492 = env23493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9696 env23492 == env23493) = true)

theorem identity23493 : scanCanonicalize (H12AffineFastState.compose env23493 (packedSelected [2,4,6,8,10,12,15,16,17,19,22,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 20531) := by decide +kernel

theorem selectedBound23493 : packedSelected [2,4,6,8,10,12,15,16,17,19,22,26,28] rootPS < 2^1333 := by decide +kernel

def env23494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9696,20531,24908,22681,1024,9697,4160,20756,28712,1078,8328,65,10509,25896,13625,11293,1501,28816,256,21792,4453,29241]

theorem envBound23494 : H12AffineFastState.Bounded env23494 := by
  intro p hp
  have h : env23494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23493_23494 : H12AffineEnvironment.transform 15 20531 env23493 = env23494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20531 env23493 == env23494) = true)

theorem identity23494 : scanCanonicalize (H12AffineFastState.compose env23494 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound23494 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env23495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,80,20531,17660,22681,1024,81,4160,20756,21912,1078,1336,65,3261,16536,4233,2477,1501,21792,256,21792,4453,22409]

theorem envBound23495 : H12AffineFastState.Bounded env23495 := by
  intro p hp
  have h : env23495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23494_23495 : H12AffineEnvironment.transform 12 1456 env23494 = env23495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env23494 == env23495) = true)

theorem identity23495 : scanCanonicalize (H12AffineFastState.compose env23495 (packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound23495 : packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env23496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,5593,80,1514,4389,3392,1024,81,4160,1229,65,1078,1336,65,3261,5441,4233,2477,1501,249,256,249,4453,592]

theorem envBound23496 : H12AffineFastState.Bounded env23496 := by
  intro p hp
  have h : env23496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23495_23496 : H12AffineEnvironment.transform 13 5593 env23495 = env23496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env23495 == env23496) = true)

theorem identity23496 : scanCanonicalize (H12AffineFastState.compose env23496 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound23496 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env23497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,1456,3173,80,1514,2201,3392,1024,81,2556,1229,65,1078,1336,65,3261,3325,2357,2477,1501,249,256,249,2265,592]

theorem envBound23497 : H12AffineFastState.Bounded env23497 := by
  intro p hp
  have h : env23497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23496_23497 : H12AffineEnvironment.transform 11 2492 env23496 = env23497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env23496 == env23497) = true)

theorem identity23497 : scanCanonicalize (H12AffineFastState.compose env23497 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound23497 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env23498 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,2113,1101,3173,80,1047,2201,3261,1024,81,2049,1229,65,1078,1221,65,3261,3325,2248,2128,1056,249,253,249,2265,592]

theorem envBound23498 : H12AffineFastState.Bounded env23498 := by
  intro p hp
  have h : env23498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23497_23498 : H12AffineEnvironment.transform 7 253 env23497 = env23498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env23497 == env23498) = true)

theorem identity23498 : scanCanonicalize (H12AffineFastState.compose env23498 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound23498 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23499 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1125,1060,1101,0,80,1047,1276,216,1024,81,1124,1229,65,1078,1221,65,216,152,1197,1077,1056,249,253,249,1212,592]

theorem envBound23499 : H12AffineFastState.Bounded env23499 := by
  intro p hp
  have h : env23499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23498_23499 : H12AffineEnvironment.transform 10 1125 env23498 = env23499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env23498 == env23499) = true)

theorem identity23499 : scanCanonicalize (H12AffineFastState.compose env23499 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound23499 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env23500 : List Nat := [2,4,8,16,32,64,128,253,512,84,49,112,25,0,80,67,168,216,84,81,48,153,65,98,145,65,216,152,249,97,116,249,253,249,232,592]

theorem envBound23500 : H12AffineFastState.Bounded env23500 := by
  intro p hp
  have h : env23500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23499_23500 : H12AffineEnvironment.transform 9 84 env23499 = env23500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env23499 == env23500) = true)

theorem identity23500 : scanCanonicalize (H12AffineFastState.compose env23500 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23500 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env23501 : List Nat := [2,4,8,16,32,64,24,101,512,84,49,112,25,0,80,67,48,64,84,81,48,1,65,98,9,65,64,0,97,97,116,97,101,97,112,592]

theorem envBound23501 : H12AffineFastState.Bounded env23501 := by
  intro p hp
  have h : env23501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23500_23501 : H12AffineEnvironment.transform 6 24 env23500 = env23501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23500 == env23501) = true)

theorem identity23501 : scanCanonicalize (H12AffineFastState.compose env23501 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound23501 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23502 : List Nat := [2,4,8,16,32,49,24,20,512,37,49,1,25,0,33,50,48,49,37,32,48,1,48,19,9,48,49,0,16,16,5,16,20,16,1,545]

theorem envBound23502 : H12AffineFastState.Bounded env23502 := by
  intro p hp
  have h : env23502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23501_23502 : H12AffineEnvironment.transform 5 49 env23501 = env23502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23501 == env23502) = true)

theorem identity23502 : scanCanonicalize (H12AffineFastState.compose env23502 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23502 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env23503 : List Nat := [2,4,8,16,0,17,24,20,512,5,17,1,25,0,1,18,16,17,5,0,16,1,16,19,9,16,17,0,16,16,5,16,20,16,1,513]

theorem envBound23503 : H12AffineFastState.Bounded env23503 := by
  intro p hp
  have h : env23503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23502_23503 : H12AffineEnvironment.transform 4 0 env23502 = env23503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23502 == env23503) = true)

theorem identity23503 : scanCanonicalize (H12AffineFastState.compose env23503 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound23503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23504 : List Nat := [2,4,8,11,0,10,3,15,512,5,10,1,2,0,1,9,11,10,5,0,11,1,11,8,9,11,10,0,11,11,5,11,15,11,1,513]

theorem envBound23504 : H12AffineFastState.Bounded env23504 := by
  intro p hp
  have h : env23504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23503_23504 : H12AffineEnvironment.transform 3 11 env23503 = env23504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env23503 == env23504) = true)

theorem identity23504 : scanCanonicalize (H12AffineFastState.compose env23504 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound23504 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23505 : List Nat := [2,4,5,6,0,7,3,2,512,5,7,1,2,0,1,4,6,7,5,0,6,1,6,5,4,6,7,0,6,6,5,6,2,6,1,513]

theorem envBound23505 : H12AffineFastState.Bounded env23505 := by
  intro p hp
  have h : env23505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23504_23505 : H12AffineEnvironment.transform 2 5 env23504 = env23505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env23504 == env23505) = true)

theorem identity23505 : scanCanonicalize (H12AffineFastState.compose env23505 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound23505 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23506 : List Nat := [2,3,2,1,0,0,3,2,512,2,0,1,2,0,1,3,1,0,2,0,1,1,1,2,3,1,0,0,1,1,2,1,2,1,1,513]

theorem envBound23506 : H12AffineFastState.Bounded env23506 := by
  intro p hp
  have h : env23506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23505_23506 : H12AffineEnvironment.transform 1 3 env23505 = env23506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env23505 == env23506) = true)

theorem identity23506 : scanCanonicalize (H12AffineFastState.compose env23506 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound23506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23507 : List Nat := [2,3,2,1,0,0,3,2,3,2,0,1,2,0,1,3,1,0,2,0,1,1,1,2,3,1,0,0,1,1,2,1,2,1,1,2]

theorem envBound23507 : H12AffineFastState.Bounded env23507 := by
  intro p hp
  have h : env23507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23506_23507 : H12AffineEnvironment.transform 8 3 env23506 = env23507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env23506 == env23507) = true)

def env23508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67755,1024,32769,4160,62709,73755,41430,8328,65,122079,79131,91402,35325,1501,73890,256,21792,46213,74250]

theorem envBound23508 : H12AffineFastState.Bounded env23508 := by
  intro p hp
  have h : env23508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23491_23508 : H12AffineEnvironment.transform 16 24909 env23491 = env23508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env23491 == env23508) = true)

theorem identity23508 : scanCanonicalize (H12AffineFastState.compose env23508 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound23508 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env23509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,24909,43049,1024,32769,4160,62709,32921,41430,8328,65,31837,38297,50568,35325,1501,32800,256,21792,46213,33416]

theorem envBound23509 : H12AffineFastState.Bounded env23509 := by
  intro p hp
  have h : env23509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23508_23509 : H12AffineEnvironment.transform 15 41090 env23508 = env23509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env23508 == env23509) = true)

theorem identity23509 : scanCanonicalize (H12AffineFastState.compose env23509 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23509 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env23510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,33247,16400,35188,1024,32769,4160,54696,32921,32907,469,65,23808,38297,50568,35325,1501,32800,256,21792,38360,33416]

theorem envBound23510 : H12AffineFastState.Bounded env23510 := by
  intro p hp
  have h : env23510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23509_23510 : H12AffineEnvironment.transform 12 349 env23509 = env23510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23509 == env23510) = true)

theorem identity23510 : scanCanonicalize (H12AffineFastState.compose env23510 (packedSelected [1,2,4,6,8,16,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound23510 : packedSelected [1,2,4,6,8,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env23511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21760,21727,16400,23668,1024,21761,4160,168,21913,21899,469,65,23808,16537,4232,23805,1501,21792,256,21792,16600,22408]

theorem envBound23511 : H12AffineFastState.Bounded env23511 := by
  intro p hp
  have h : env23511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23510_23511 : H12AffineEnvironment.transform 14 21760 env23510 = env23511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env23510 == env23511) = true)

theorem identity23511 : scanCanonicalize (H12AffineFastState.compose env23511 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound23511 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env23512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,136,343,5528,2556,1024,137,4160,168,17,3,469,65,2184,5393,4232,2421,1501,168,256,168,5456,512]

theorem envBound23512 : H12AffineFastState.Bounded env23512 := by
  intro p hp
  have h : env23512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23511_23512 : H12AffineEnvironment.transform 13 5512 env23511 = env23512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env23511 == env23512) = true)

theorem identity23512 : scanCanonicalize (H12AffineFastState.compose env23512 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound23512 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23513 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5409,33,343,5425,2389,1024,32,4160,1,17,3,380,65,2081,5393,4129,2421,1396,1,256,1,5456,512]

theorem envBound23513 : H12AffineFastState.Bounded env23513 := by
  intro p hp
  have h : env23513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23512_23513 : H12AffineEnvironment.transform 6 41 env23512 = env23513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env23512 == env23513) = true)

theorem identity23513 : scanCanonicalize (H12AffineFastState.compose env23513 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3345) := by decide +kernel

theorem selectedBound23513 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env23514 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,3345,349,2096,33,343,2080,2389,1024,32,3409,1,17,3,380,65,2081,2048,3376,2421,1396,1,256,1,2113,512]

theorem envBound23514 : H12AffineFastState.Bounded env23514 := by
  intro p hp
  have h : env23514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23513_23514 : H12AffineEnvironment.transform 11 3345 env23513 = env23514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3345 env23513 == env23514) = true)

theorem identity23514 : scanCanonicalize (H12AffineFastState.compose env23514 (packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23514 : packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env23515 : List Nat := [2,4,8,16,32,64,41,5,512,1024,2048,3092,88,2096,33,82,2080,2128,1024,32,3156,1,17,3,121,65,2081,2048,3125,2160,1137,1,5,1,2113,512]

theorem envBound23515 : H12AffineFastState.Bounded env23515 := by
  intro p hp
  have h : env23515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23514_23515 : H12AffineEnvironment.transform 7 5 env23514 = env23515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23514 == env23515) = true)

theorem identity23515 : scanCanonicalize (H12AffineFastState.compose env23515 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound23515 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23516 : List Nat := [2,4,8,16,32,64,41,5,512,47,2048,2107,88,2096,33,82,2080,2128,47,32,2171,1,17,3,121,65,2081,2048,2074,2160,94,1,5,1,2113,512]

theorem envBound23516 : H12AffineFastState.Bounded env23516 := by
  intro p hp
  have h : env23516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0