import H12CloudChart0Data008

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity2201 : scanCanonicalize (H12AffineFastState.compose env2201 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2202 : List Nat := [2,4,8,16,32,1,57,5,512,1024,43,4096,1030,1,1039,1085,0,11,1024,1039,58,32,1,51,1079,16,43,0,4097,11,1025,0,5,0,1,512]

theorem envBound2202 : H12AffineFastState.Bounded env2202 := by
  intro p hp
  have h : env2202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2201_2202 : H12AffineEnvironment.transform 12 1030 env2201 = env2202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2201 == env2202) = true)

theorem identity2202 : scanCanonicalize (H12AffineFastState.compose env2202 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2202 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2203 : List Nat := [2,4,8,16,17,1,8,5,512,1024,26,4096,1030,1,1039,1036,0,11,1024,1039,11,17,1,2,1030,16,26,0,4097,11,1025,0,5,0,1,512]

theorem envBound2203 : H12AffineFastState.Bounded env2203 := by
  intro p hp
  have h : env2203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2202_2203 : H12AffineEnvironment.transform 4 17 env2202 = env2203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2202 == env2203) = true)

theorem identity2203 : scanCanonicalize (H12AffineFastState.compose env2203 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2203 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2204 : List Nat := [2,4,8,1,0,1,8,5,512,1024,11,4096,1030,1,1039,1036,0,11,1024,1039,11,0,1,2,1030,1,11,0,4097,11,1025,0,5,0,1,512]

theorem envBound2204 : H12AffineFastState.Bounded env2204 := by
  intro p hp
  have h : env2204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2203_2204 : H12AffineEnvironment.transform 3 1 env2203 = env2204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2203 == env2204) = true)

def env2205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,65536,131072,262144,1024,8692,2097152,293,131320,131275,8328,131240,393312,184,135353,2080,206143,131397,256,0,131073,513]

theorem envBound2205 : H12AffineFastState.Bounded env2205 := by
  intro p hp
  have h : env2205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2192_2205 : H12AffineEnvironment.transform 13 185 env2192 = env2205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env2192 == env2205) = true)

theorem identity2205 : scanCanonicalize (H12AffineFastState.compose env2205 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4437) := by decide +kernel

theorem selectedBound2205 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,65536,131072,262144,1024,8692,4437,293,131320,131275,8328,131240,393312,184,135353,2080,206143,131397,256,0,131073,513]

theorem envBound2206 : H12AffineFastState.Bounded env2206 := by
  intro p hp
  have h : env2206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2205_2206 : H12AffineEnvironment.transform 20 4437 env2205 = env2206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4437 env2205 == env2206) = true)

theorem identity2206 : scanCanonicalize (H12AffineFastState.compose env2206 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 73787) := by decide +kernel

theorem selectedBound2206 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,65536,73787,262144,1024,8692,4437,293,73923,73968,8328,73875,335963,184,77954,2080,1284,74110,256,0,73786,513]

theorem envBound2207 : H12AffineFastState.Bounded env2207 := by
  intro p hp
  have h : env2207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2206_2207 : H12AffineEnvironment.transform 16 73787 env2206 = env2207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 73787 env2206 == env2207) = true)

theorem identity2207 : scanCanonicalize (H12AffineFastState.compose env2207 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2207 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2208 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,185,8200,65536,73787,262144,1024,8200,4265,217,73923,73968,8328,73875,335963,184,77954,2080,1272,73858,252,0,73786,513]

theorem envBound2208 : H12AffineFastState.Bounded env2208 := by
  intro p hp
  have h : env2208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2207_2208 : H12AffineEnvironment.transform 7 252 env2207 = env2208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2207 == env2208) = true)

theorem identity2208 : scanCanonicalize (H12AffineFastState.compose env2208 (packedSelected [1,3,4,9,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound2208 : packedSelected [1,3,4,9,20,24,28] rootPS < 2^1333 := by decide +kernel

def env2209 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,185,8200,8322,185,262144,1024,8200,4265,217,65,114,8328,17,262361,184,4096,2080,1272,0,252,0,184,513]

theorem envBound2209 : H12AffineFastState.Bounded env2209 := by
  intro p hp
  have h : env2209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2208_2209 : H12AffineEnvironment.transform 15 8322 env2208 = env2209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env2208 == env2209) = true)

theorem identity2209 : scanCanonicalize (H12AffineFastState.compose env2209 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound2209 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2210 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,8192,185,8200,8322,185,262144,1024,8200,168,217,65,114,8328,17,262361,184,1,2080,1272,0,252,0,184,513]

theorem envBound2210 : H12AffineFastState.Bounded env2210 := by
  intro p hp
  have h : env2210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2209_2210 : H12AffineEnvironment.transform 11 1 env2209 = env2210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env2209 == env2210) = true)

theorem identity2210 : scanCanonicalize (H12AffineFastState.compose env2210 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound2210 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env2211 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,1069,185,1061,1199,185,262144,1024,1061,168,217,65,114,1189,17,262361,184,1,2080,1272,0,252,0,184,513]

theorem envBound2211 : H12AffineFastState.Bounded env2211 := by
  intro p hp
  have h : env2211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2210_2211 : H12AffineEnvironment.transform 12 1069 env2210 = env2211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env2210 == env2211) = true)

theorem identity2211 : scanCanonicalize (H12AffineFastState.compose env2211 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound2211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2212 : List Nat := [2,4,8,16,32,64,128,252,512,116,2048,1,89,185,81,219,185,262144,116,81,168,217,65,114,209,17,262361,184,1,2080,140,0,252,0,184,513]

theorem envBound2212 : H12AffineFastState.Bounded env2212 := by
  intro p hp
  have h : env2212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2211_2212 : H12AffineEnvironment.transform 9 116 env2211 = env2212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env2211 == env2212) = true)

theorem identity2212 : scanCanonicalize (H12AffineFastState.compose env2212 (packedSelected [0,1,3,5,7,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2296) := by decide +kernel

theorem selectedBound2212 : packedSelected [0,1,3,5,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env2213 : List Nat := [2,4,8,16,32,64,128,252,512,116,2048,1,89,185,81,219,185,2296,116,81,168,217,65,114,209,17,2081,184,1,2080,140,0,252,0,184,513]

theorem envBound2213 : H12AffineFastState.Bounded env2213 := by
  intro p hp
  have h : env2213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2212_2213 : H12AffineEnvironment.transform 17 2296 env2212 = env2213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2296 env2212 == env2213) = true)

theorem identity2213 : scanCanonicalize (H12AffineFastState.compose env2213 (packedSelected [0,1,3,5,6,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound2213 : packedSelected [0,1,3,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2214 : List Nat := [2,4,8,16,32,64,128,252,512,116,16,1,89,185,81,219,185,232,116,81,168,217,65,114,209,17,49,184,1,48,140,0,252,0,184,513]

theorem envBound2214 : H12AffineFastState.Bounded env2214 := by
  intro p hp
  have h : env2214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2213_2214 : H12AffineEnvironment.transform 10 16 env2213 = env2214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env2213 == env2214) = true)

theorem identity2214 : scanCanonicalize (H12AffineFastState.compose env2214 (packedSelected [0,1,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2214 : packedSelected [0,1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env2215 : List Nat := [2,4,8,16,32,64,40,84,512,116,16,1,89,17,81,115,17,64,116,81,0,113,65,114,121,17,49,16,1,48,36,0,84,0,16,513]

theorem envBound2215 : H12AffineFastState.Bounded env2215 := by
  intro p hp
  have h : env2215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2214_2215 : H12AffineEnvironment.transform 6 40 env2214 = env2215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2214 == env2215) = true)

theorem identity2215 : scanCanonicalize (H12AffineFastState.compose env2215 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound2215 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env2216 : List Nat := [2,4,8,16,23,64,31,84,512,67,16,1,89,17,81,68,17,64,67,81,0,70,65,69,78,17,6,16,1,7,19,0,84,0,16,513]

theorem envBound2216 : H12AffineFastState.Bounded env2216 := by
  intro p hp
  have h : env2216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2215_2216 : H12AffineEnvironment.transform 4 23 env2215 = env2216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env2215 == env2216) = true)

theorem identity2216 : scanCanonicalize (H12AffineFastState.compose env2216 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound2216 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env2217 : List Nat := [2,4,8,16,23,64,31,84,91,67,16,1,89,17,81,68,17,64,67,81,0,70,65,69,78,17,6,16,1,7,19,0,84,0,16,90]

theorem envBound2217 : H12AffineFastState.Bounded env2217 := by
  intro p hp
  have h : env2217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2216_2217 : H12AffineEnvironment.transform 8 91 env2216 = env2217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env2216 == env2217) = true)

theorem identity2217 : scanCanonicalize (H12AffineFastState.compose env2217 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound2217 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env2218 : List Nat := [2,4,8,16,23,18,31,6,9,17,16,1,11,17,3,22,17,18,17,3,0,20,19,23,28,17,6,16,1,7,19,0,6,0,16,8]

theorem envBound2218 : H12AffineFastState.Bounded env2218 := by
  intro p hp
  have h : env2218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2217_2218 : H12AffineEnvironment.transform 5 18 env2217 = env2218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env2217 == env2218) = true)

def env2219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,34359738368,16925298]

theorem envBound2219 : H12AffineFastState.Bounded env2219 := by
  intro p hp
  have h : env2219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2166_2219 : H12AffineEnvironment.transform 18 1025 env2166 = env2219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2166 == env2219) = true)

def env2220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,131072,16925298]

theorem envBound2220 : H12AffineFastState.Bounded env2220 := by
  intro p hp
  have h : env2220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2219_2220 : H12AffineEnvironment.transform 34 131072 env2219 = env2220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2219 == env2220) = true)

theorem identity2220 : scanCanonicalize (H12AffineFastState.compose env2220 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6296750) := by decide +kernel

theorem selectedBound2220 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,6296750,8328,147472,409816,16385,151552,2080,6369627,4341976,257,0,131072,6444764]

theorem envBound2221 : H12AffineFastState.Bounded env2221 := by
  intro p hp
  have h : env2221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2220_2221 : H12AffineEnvironment.transform 23 6296750 env2220 = env2221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6296750 env2220 == env2221) = true)

theorem identity2221 : scanCanonicalize (H12AffineFastState.compose env2221 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 2102309) := by decide +kernel

theorem selectedBound2221 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,2102309,147521,139,8328,147472,409816,16385,151552,2080,75134,2249981,257,0,131072,148217]

theorem envBound2222 : H12AffineFastState.Bounded env2222 := by
  intro p hp
  have h : env2222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2221_2222 : H12AffineEnvironment.transform 21 2102309 env2221 = env2222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102309 env2221 == env2222) = true)

def env2223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16632,262144,1025,8692,2097152,2102309,185,139,8328,232,262176,16385,4344,2080,75134,2102277,257,0,16632,513]

theorem envBound2223 : H12AffineFastState.Bounded env2223 := by
  intro p hp
  have h : env2223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2222_2223 : H12AffineEnvironment.transform 16 16632 env2222 = env2223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2222 == env2223) = true)

theorem identity2223 : scanCanonicalize (H12AffineFastState.compose env2223 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2223 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2224 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8692,65536,16632,262144,84,8692,2097152,2101360,185,139,8328,232,262176,16385,4344,2080,74027,2101328,257,0,16632,513]

theorem envBound2224 : H12AffineFastState.Bounded env2224 := by
  intro p hp
  have h : env2224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2223_2224 : H12AffineEnvironment.transform 9 85 env2223 = env2224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2223 == env2224) = true)

theorem identity2224 : scanCanonicalize (H12AffineFastState.compose env2224 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 4264) := by decide +kernel

theorem selectedBound2224 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2225 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8692,65536,16632,262144,84,8692,4264,216,185,139,8328,232,262176,16385,4344,2080,74027,248,257,0,16632,513]

theorem envBound2225 : H12AffineFastState.Bounded env2225 := by
  intro p hp
  have h : env2225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2224_2225 : H12AffineEnvironment.transform 20 4264 env2224 = env2225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4264 env2224 == env2225) = true)

theorem identity2225 : scanCanonicalize (H12AffineFastState.compose env2225 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound2225 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2226 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8692,8583,16632,262144,84,8692,4264,216,185,139,8328,232,262176,16385,4344,2080,172,248,257,0,16632,513]

theorem envBound2226 : H12AffineFastState.Bounded env2226 := by
  intro p hp
  have h : env2226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2225_2226 : H12AffineEnvironment.transform 15 8583 env2225 = env2226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env2225 == env2226) = true)

theorem identity2226 : scanCanonicalize (H12AffineFastState.compose env2226 (packedSelected [13,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2226 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2227 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,8192,16384,8540,8495,16464,262144,84,8540,4096,112,17,35,8224,64,262176,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2227 : H12AffineFastState.Bounded env2227 := by
  intro p hp
  have h : env2227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2226_2227 : H12AffineEnvironment.transform 6 40 env2226 = env2227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2226 == env2227) = true)

theorem identity2227 : scanCanonicalize (H12AffineFastState.compose env2227 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 22640) := by decide +kernel

theorem selectedBound2227 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env2228 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,8192,16384,8540,8495,16464,22640,84,8540,4096,112,17,35,8224,64,22608,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2228 : H12AffineFastState.Bounded env2228 := by
  intro p hp
  have h : env2228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2227_2228 : H12AffineEnvironment.transform 17 22640 env2227 = env2228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22640 env2227 == env2228) = true)

theorem identity2228 : scanCanonicalize (H12AffineFastState.compose env2228 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2423) := by decide +kernel

theorem selectedBound2228 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env2229 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,2423,16384,2091,2136,16464,22640,84,2091,4096,112,17,35,2391,64,22608,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2229 : H12AffineFastState.Bounded env2229 := by
  intro p hp
  have h : env2229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2228_2229 : H12AffineEnvironment.transform 12 2423 env2228 = env2229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2423 env2228 == env2229) = true)

theorem identity2229 : scanCanonicalize (H12AffineFastState.compose env2229 (packedSelected [1,2,3,5,6,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound2229 : packedSelected [1,2,3,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env2230 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,2423,6160,2091,2136,6208,96,84,2091,4096,112,17,35,2391,64,64,6161,4176,2080,4,80,257,0,6208,513]

theorem envBound2230 : H12AffineFastState.Bounded env2230 := by
  intro p hp
  have h : env2230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2229_2230 : H12AffineEnvironment.transform 13 6160 env2229 = env2230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env2229 == env2230) = true)

theorem identity2230 : scanCanonicalize (H12AffineFastState.compose env2230 (packedSelected [2,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2230 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env2231 : List Nat := [2,4,8,16,32,0,40,256,512,21,2048,4096,2359,6160,2091,2072,6144,32,20,2091,4096,48,17,35,2327,0,0,6161,4112,2080,4,16,257,0,6144,513]

theorem envBound2231 : H12AffineFastState.Bounded env2231 := by
  intro p hp
  have h : env2231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2230_2231 : H12AffineEnvironment.transform 5 0 env2230 = env2231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2230 == env2231) = true)

theorem identity2231 : scanCanonicalize (H12AffineFastState.compose env2231 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound2231 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env2232 : List Nat := [2,4,8,16,32,0,40,256,512,21,17,4096,294,4097,58,9,4113,32,20,58,4096,48,17,35,262,0,0,4096,4112,49,4,16,257,0,4113,513]

theorem envBound2232 : H12AffineFastState.Bounded env2232 := by
  intro p hp
  have h : env2232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2231_2232 : H12AffineEnvironment.transform 10 17 env2231 = env2232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env2231 == env2232) = true)

theorem identity2232 : scanCanonicalize (H12AffineFastState.compose env2232 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound2232 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env2233 : List Nat := [2,4,8,16,32,0,40,256,512,21,17,261,294,260,58,9,276,32,20,58,261,48,17,35,262,0,0,261,277,49,4,16,257,0,276,513]

theorem envBound2233 : H12AffineFastState.Bounded env2233 := by
  intro p hp
  have h : env2233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2232_2233 : H12AffineEnvironment.transform 11 261 env2232 = env2233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env2232 == env2233) = true)

theorem identity2233 : scanCanonicalize (H12AffineFastState.compose env2233 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound2233 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env2234 : List Nat := [2,4,8,16,32,0,40,62,512,21,17,59,24,58,58,9,42,32,20,58,59,48,17,35,56,0,0,59,43,49,4,16,63,0,42,513]

theorem envBound2234 : H12AffineFastState.Bounded env2234 := by
  intro p hp
  have h : env2234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2233_2234 : H12AffineEnvironment.transform 7 62 env2233 = env2234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env2233 == env2234) = true)

theorem identity2234 : scanCanonicalize (H12AffineFastState.compose env2234 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound2234 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2235 : List Nat := [2,4,8,16,32,0,40,62,33,21,17,59,24,58,58,9,42,32,20,58,59,48,17,35,56,0,0,59,43,49,4,16,63,0,42,32]

theorem envBound2235 : H12AffineFastState.Bounded env2235 := by
  intro p hp
  have h : env2235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2234_2235 : H12AffineEnvironment.transform 8 33 env2234 = env2235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env2234 == env2235) = true)

theorem identity2235 : scanCanonicalize (H12AffineFastState.compose env2235 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound2235 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2236 : List Nat := [2,4,8,2,32,0,40,44,33,7,3,41,10,40,40,9,42,32,6,40,41,34,3,35,42,0,0,41,43,35,4,2,45,0,42,32]

theorem envBound2236 : H12AffineFastState.Bounded env2236 := by
  intro p hp
  have h : env2236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2235_2236 : H12AffineEnvironment.transform 3 2 env2235 = env2236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env2235 == env2236) = true)

theorem identity2236 : scanCanonicalize (H12AffineFastState.compose env2236 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound2236 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2237 : List Nat := [2,4,1,2,32,0,33,37,33,7,3,32,3,33,33,0,35,32,6,33,32,34,3,35,35,0,0,32,34,35,4,2,36,0,35,32]

theorem envBound2237 : H12AffineFastState.Bounded env2237 := by
  intro p hp
  have h : env2237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2236_2237 : H12AffineEnvironment.transform 2 1 env2236 = env2237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env2236 == env2237) = true)

theorem identity2237 : scanCanonicalize (H12AffineFastState.compose env2237 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound2237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2238 : List Nat := [2,4,1,2,4,0,5,1,5,7,3,4,3,5,5,0,7,4,6,5,4,6,3,7,7,0,0,4,6,7,4,2,0,0,7,4]

theorem envBound2238 : H12AffineFastState.Bounded env2238 := by
  intro p hp
  have h : env2238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2237_2238 : H12AffineEnvironment.transform 4 4 env2237 = env2238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env2237 == env2238) = true)

theorem identity2238 : scanCanonicalize (H12AffineFastState.compose env2238 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound2238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2239 : List Nat := [2,3,1,2,3,0,2,1,2,0,3,3,3,2,2,0,0,3,1,2,3,1,3,0,0,0,0,3,1,0,3,2,0,0,0,3]

theorem envBound2239 : H12AffineFastState.Bounded env2239 := by
  intro p hp
  have h : env2239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2238_2239 : H12AffineEnvironment.transform 1 3 env2238 = env2239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env2238 == env2239) = true)

theorem identity2239 : scanCanonicalize (H12AffineFastState.compose env2239 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2240 : List Nat := [1,0,1,1,0,0,1,1,1,0,0,0,0,1,1,0,0,0,1,1,0,1,0,0,0,0,0,0,1,0,0,1,0,0,0,0]

theorem envBound2240 : H12AffineFastState.Bounded env2240 := by
  intro p hp
  have h : env2240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2239_2240 : H12AffineEnvironment.transform 0 1 env2239 = env2240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2239 == env2240) = true)

def env2241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16633,262144,1025,8692,2097152,2102309,184,139,8328,233,262177,16385,4345,2080,75134,2102276,257,0,16633,512]

theorem envBound2241 : H12AffineFastState.Bounded env2241 := by
  intro p hp
  have h : env2241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2222_2241 : H12AffineEnvironment.transform 16 16633 env2222 = env2241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2222 == env2241) = true)

theorem identity2241 : scanCanonicalize (H12AffineFastState.compose env2241 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 5124) := by decide +kernel

theorem selectedBound2241 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16633,262144,1025,8692,5124,33,184,139,8328,233,262177,16385,4345,2080,75134,0,257,0,16633,512]

theorem envBound2242 : H12AffineFastState.Bounded env2242 := by
  intro p hp
  have h : env2242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2241_2242 : H12AffineEnvironment.transform 20 5124 env2241 = env2242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5124 env2241 == env2242) = true)

theorem identity2242 : scanCanonicalize (H12AffineFastState.compose env2242 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2242 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1025,8692,5124,33,184,139,8328,233,262177,16385,4345,2080,1024,0,257,0,16633,512]

theorem envBound2243 : H12AffineFastState.Bounded env2243 := by
  intro p hp
  have h : env2243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2242_2243 : H12AffineEnvironment.transform 15 8574 env2242 = env2243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2242 == env2243) = true)

def env2244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,131073,16925298]

theorem envBound2244 : H12AffineFastState.Bounded env2244 := by
  intro p hp
  have h : env2244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2219_2244 : H12AffineEnvironment.transform 34 131073 env2219 = env2244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2219 == env2244) = true)

theorem identity2244 : scanCanonicalize (H12AffineFastState.compose env2244 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4195503) := by decide +kernel

theorem selectedBound2244 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,4195503,8328,147472,409816,16385,151552,2080,4268378,4341976,257,0,131073,4343517]

theorem envBound2245 : H12AffineFastState.Bounded env2245 := by
  intro p hp
  have h : env2245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2244_2245 : H12AffineEnvironment.transform 23 4195503 env2244 = env2245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195503 env2244 == env2245) = true)

theorem identity2245 : scanCanonicalize (H12AffineFastState.compose env2245 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 9594) := by decide +kernel

theorem selectedBound2245 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,9594,131072,262144,1025,8692,2097152,4194304,147521,4195503,8328,147472,409816,16385,151552,2080,4195360,4341976,257,0,131073,4343517]

theorem envBound2246 : H12AffineFastState.Bounded env2246 := by
  intro p hp
  have h : env2246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2245_2246 : H12AffineEnvironment.transform 15 9594 env2245 = env2246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9594 env2245 == env2246) = true)

theorem identity2246 : scanCanonicalize (H12AffineFastState.compose env2246 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 148701) := by decide +kernel

theorem selectedBound2246 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,9594,131072,262144,1025,8692,2097152,148701,147521,147570,8328,147472,409816,16385,151552,2080,147709,1029,257,0,131073,512]

theorem envBound2247 : H12AffineFastState.Bounded env2247 := by
  intro p hp
  have h : env2247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2246_2247 : H12AffineEnvironment.transform 21 148701 env2246 = env2247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 148701 env2246 == env2247) = true)

theorem identity2247 : scanCanonicalize (H12AffineFastState.compose env2247 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 17660) := by decide +kernel

theorem selectedBound2247 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,9594,17660,262144,1025,8692,2097152,33,1213,1166,8328,1260,263204,16385,5372,2080,1025,1029,257,0,17661,512]

theorem envBound2248 : H12AffineFastState.Bounded env2248 := by
  intro p hp
  have h : env2248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2247_2248 : H12AffineEnvironment.transform 16 17660 env2247 = env2248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17660 env2247 == env2248) = true)

theorem identity2248 : scanCanonicalize (H12AffineFastState.compose env2248 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2248 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2249 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16632,262144,5,8692,2097152,33,185,138,8328,232,262176,16385,4344,2080,5,1,257,0,16633,512]

theorem envBound2249 : H12AffineFastState.Bounded env2249 := by
  intro p hp
  have h : env2249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2248_2249 : H12AffineEnvironment.transform 9 4 env2248 = env2249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2248 == env2249) = true)

theorem identity2249 : scanCanonicalize (H12AffineFastState.compose env2249 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound2249 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2250 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16632,2080,5,8692,2097152,33,185,138,8328,232,2048,16385,4344,2080,5,1,257,0,16633,512]

theorem envBound2250 : H12AffineFastState.Bounded env2250 := by
  intro p hp
  have h : env2250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2249_2250 : H12AffineEnvironment.transform 17 2080 env2249 = env2250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env2249 == env2250) = true)

theorem identity2250 : scanCanonicalize (H12AffineFastState.compose env2250 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2250 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2251 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16632,2080,5,8200,2097152,33,185,138,8328,232,2048,16385,4344,2080,5,1,253,0,16633,512]

theorem envBound2251 : H12AffineFastState.Bounded env2251 := by
  intro p hp
  have h : env2251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2250_2251 : H12AffineEnvironment.transform 7 252 env2250 = env2251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2250 == env2251) = true)

theorem identity2251 : scanCanonicalize (H12AffineFastState.compose env2251 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26826) := by decide +kernel

theorem selectedBound2251 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env2252 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16632,2080,5,8200,26826,33,185,138,8328,232,2048,16385,4344,2080,5,1,253,0,16633,512]

theorem envBound2252 : H12AffineFastState.Bounded env2252 := by
  intro p hp
  have h : env2252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2251_2252 : H12AffineEnvironment.transform 20 26826 env2251 = env2252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26826 env2251 == env2252) = true)

theorem identity2252 : scanCanonicalize (H12AffineFastState.compose env2252 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound2252 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2253 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12497,8200,8322,12329,2080,5,8200,6171,33,185,138,8328,232,2048,12496,4344,2080,5,1,253,0,12328,512]

theorem envBound2253 : H12AffineFastState.Bounded env2253 := by
  intro p hp
  have h : env2253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2252_2253 : H12AffineEnvironment.transform 13 12497 env2252 = env2253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env2252 == env2253) = true)

theorem identity2253 : scanCanonicalize (H12AffineFastState.compose env2253 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound2253 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env2254 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2282,6203,2274,2152,6339,2080,5,2274,6171,33,185,138,2146,232,2048,6202,4344,2080,5,1,253,0,6338,512]

theorem envBound2254 : H12AffineFastState.Bounded env2254 := by
  intro p hp
  have h : env2254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2253_2254 : H12AffineEnvironment.transform 12 2282 env2253 = env2254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env2253 == env2254) = true)

theorem identity2254 : scanCanonicalize (H12AffineFastState.compose env2254 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound2254 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env2255 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2217,2282,146,2274,2152,106,2080,5,2274,178,33,185,138,2146,232,2048,147,2129,2080,5,1,253,0,107,512]

theorem envBound2255 : H12AffineFastState.Bounded env2255 := by
  intro p hp
  have h : env2255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2254_2255 : H12AffineEnvironment.transform 11 2217 env2254 = env2255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env2254 == env2255) = true)

theorem identity2255 : scanCanonicalize (H12AffineFastState.compose env2255 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound2255 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2256 : List Nat := [2,4,8,16,32,64,128,252,512,4,58,147,208,146,216,82,106,26,5,216,178,33,185,138,88,232,58,147,107,26,5,1,253,0,107,512]

theorem envBound2256 : H12AffineFastState.Bounded env2256 := by
  intro p hp
  have h : env2256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2255_2256 : H12AffineEnvironment.transform 10 58 env2255 = env2256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env2255 == env2256) = true)

theorem identity2256 : scanCanonicalize (H12AffineFastState.compose env2256 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound2256 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env2257 : List Nat := [2,4,8,16,32,42,128,150,512,4,58,147,186,146,178,56,0,26,5,178,178,33,185,138,50,130,58,147,1,26,5,1,151,0,1,512]

theorem envBound2257 : H12AffineFastState.Bounded env2257 := by
  intro p hp
  have h : env2257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2256_2257 : H12AffineEnvironment.transform 5 42 env2256 = env2257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env2256 == env2257) = true)

theorem identity2257 : scanCanonicalize (H12AffineFastState.compose env2257 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound2257 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2258 : List Nat := [2,4,8,16,32,42,18,4,512,4,58,1,40,0,32,56,0,26,5,32,32,33,43,24,50,16,58,1,1,26,5,1,5,0,1,512]

theorem envBound2258 : H12AffineFastState.Bounded env2258 := by
  intro p hp
  have h : env2258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2257_2258 : H12AffineEnvironment.transform 6 18 env2257 = env2258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env2257 == env2258) = true)

theorem identity2258 : scanCanonicalize (H12AffineFastState.compose env2258 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound2258 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2259 : List Nat := [2,4,8,16,10,0,18,4,512,4,16,1,2,0,10,18,0,26,5,10,10,11,1,24,24,16,16,1,1,26,5,1,5,0,1,512]

theorem envBound2259 : H12AffineFastState.Bounded env2259 := by
  intro p hp
  have h : env2259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2258_2259 : H12AffineEnvironment.transform 4 10 env2258 = env2259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env2258 == env2259) = true)

theorem identity2259 : scanCanonicalize (H12AffineFastState.compose env2259 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound2259 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2260 : List Nat := [2,4,8,11,10,0,9,4,512,4,11,1,2,0,10,9,0,1,5,10,10,11,1,3,3,11,11,1,1,1,5,1,5,0,1,512]

theorem envBound2260 : H12AffineFastState.Bounded env2260 := by
  intro p hp
  have h : env2260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2259_2260 : H12AffineEnvironment.transform 3 11 env2259 = env2260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env2259 == env2260) = true)

theorem identity2260 : scanCanonicalize (H12AffineFastState.compose env2260 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound2260 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2261 : List Nat := [2,4,2,1,0,0,3,4,512,4,1,1,2,0,0,3,0,1,5,0,0,1,1,3,3,1,1,1,1,1,5,1,5,0,1,512]

theorem envBound2261 : H12AffineFastState.Bounded env2261 := by
  intro p hp
  have h : env2261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2260_2261 : H12AffineEnvironment.transform 2 2 env2260 = env2261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env2260 == env2261) = true)

theorem identity2261 : scanCanonicalize (H12AffineFastState.compose env2261 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2262 : List Nat := [2,4,2,1,0,0,3,4,7,4,1,1,2,0,0,3,0,1,5,0,0,1,1,3,3,1,1,1,1,1,5,1,5,0,1,7]

theorem envBound2262 : H12AffineFastState.Bounded env2262 := by
  intro p hp
  have h : env2262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2261_2262 : H12AffineEnvironment.transform 8 7 env2261 = env2262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2261 == env2262) = true)

def env2263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2080,17375733,13108377,525568,0,34359738368,25691699]

theorem envBound2263 : H12AffineFastState.Bounded env2263 := by
  intro p hp
  have h : env2263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2065_2263 : H12AffineEnvironment.transform 14 8693 env2065 = env2263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env2065 == env2263) = true)

theorem identity2263 : scanCanonicalize (H12AffineFastState.compose env2263 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound2263 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env2264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913971,8328,8914000,9176216,16385,151552,2080,8463814,13108377,525568,0,34359738368,512]

theorem envBound2264 : H12AffineFastState.Bounded env2264 := by
  intro p hp
  have h : env2264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2263_2264 : H12AffineEnvironment.transform 23 8913971 env2263 = env2264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env2263 == env2264) = true)

theorem identity2264 : scanCanonicalize (H12AffineFastState.compose env2264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound2264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525344,8388608,8913971,8328,8914000,9176216,16385,151552,2080,8463814,8388793,525568,0,34359738368,512]

theorem envBound2265 : H12AffineFastState.Bounded env2265 := by
  intro p hp
  have h : env2265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2264_2265 : H12AffineEnvironment.transform 21 525344 env2264 = env2265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env2264 == env2265) = true)

theorem identity2265 : scanCanonicalize (H12AffineFastState.compose env2265 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound2265 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env2266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462669,8328,8462638,8724966,16385,151552,2080,8463814,8388793,73854,0,34359738368,512]

theorem envBound2266 : H12AffineFastState.Bounded env2266 := by
  intro p hp
  have h : env2266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2265_2266 : H12AffineEnvironment.transform 18 75134 env2265 = env2266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env2265 == env2266) = true)

theorem identity2266 : scanCanonicalize (H12AffineFastState.compose env2266 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound2266 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462669,8328,8462638,8724966,16385,151552,2080,8463814,8388793,73854,0,131332,512]

theorem envBound2267 : H12AffineFastState.Bounded env2267 := by
  intro p hp
  have h : env2267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2266_2267 : H12AffineEnvironment.transform 34 131332 env2266 = env2267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env2266 == env2267) = true)

def env2268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,184,74229,8328,74134,336222,16385,151552,2080,75134,1,73854,0,131332,512]

theorem envBound2268 : H12AffineFastState.Bounded env2268 := by
  intro p hp
  have h : env2268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2267_2268 : H12AffineEnvironment.transform 22 184 env2267 = env2268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env2267 == env2268) = true)

theorem identity2268 : scanCanonicalize (H12AffineFastState.compose env2268 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound2268 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2269 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74883,8200,2097152,73891,184,73736,8328,73835,336035,16385,151552,2080,74883,1,73854,0,131321,512]

theorem envBound2269 : H12AffineFastState.Bounded env2269 := by
  intro p hp
  have h : env2269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2268_2269 : H12AffineEnvironment.transform 7 253 env2268 = env2269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2268 == env2269) = true)

def env2270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,185,74228,8328,74135,336223,16385,151552,2080,75135,0,73854,0,131332,512]

theorem envBound2270 : H12AffineFastState.Bounded env2270 := by
  intro p hp
  have h : env2270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2267_2270 : H12AffineEnvironment.transform 22 185 env2267 = env2270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env2267 == env2270) = true)

theorem identity2270 : scanCanonicalize (H12AffineFastState.compose env2270 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound2270 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env2271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223323,75134,8693,2097152,74078,185,74228,8328,74135,149764,16385,151552,2080,75135,0,73854,0,131332,512]

theorem envBound2271 : H12AffineFastState.Bounded env2271 := by
  intro p hp
  have h : env2271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2270_2271 : H12AffineEnvironment.transform 17 223323 env2270 = env2271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env2270 == env2271) = true)

def env2272 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,2097152,73890,185,73736,8328,73835,149752,16385,151552,2080,74883,0,73854,0,131320,512]

theorem envBound2272 : H12AffineFastState.Bounded env2272 := by
  intro p hp
  have h : env2272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2271_2272 : H12AffineEnvironment.transform 7 252 env2271 = env2272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2271 == env2272) = true)

theorem identity2272 : scanCanonicalize (H12AffineFastState.compose env2272 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound2272 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2273 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,151553,73890,185,73736,8328,73835,149752,16385,151552,2080,74883,0,73854,0,131320,512]

theorem envBound2273 : H12AffineFastState.Bounded env2273 := by
  intro p hp
  have h : env2273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2272_2273 : H12AffineEnvironment.transform 20 151553 env2272 = env2273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env2272 == env2273) = true)

theorem identity2273 : scanCanonicalize (H12AffineFastState.compose env2273 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound2273 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env2274 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90235,2080,74882,8201,77946,73890,185,73736,8328,73835,75907,16385,77947,2080,74883,0,73854,0,90243,512]

theorem envBound2274 : H12AffineFastState.Bounded env2274 := by
  intro p hp
  have h : env2274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2273_2274 : H12AffineEnvironment.transform 16 90235 env2273 = env2274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env2273 == env2274) = true)

theorem identity2274 : scanCanonicalize (H12AffineFastState.compose env2274 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound2274 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env2275 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16632,2080,1025,8201,4345,33,185,139,8328,232,2048,16385,4344,2080,1024,0,253,0,16384,512]

theorem envBound2275 : H12AffineFastState.Bounded env2275 := by
  intro p hp
  have h : env2275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2274_2275 : H12AffineEnvironment.transform 15 8323 env2274 = env2275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env2274 == env2275) = true)

theorem identity2275 : scanCanonicalize (H12AffineFastState.compose env2275 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound2275 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2276 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8201,8323,5260,2080,1025,8201,4345,33,185,139,8328,232,2048,5237,4344,2080,1024,0,253,0,5236,512]

theorem envBound2276 : H12AffineFastState.Bounded env2276 := by
  intro p hp
  have h : env2276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2275_2276 : H12AffineEnvironment.transform 13 5236 env2275 = env2276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env2275 == env2276) = true)

theorem identity2276 : scanCanonicalize (H12AffineFastState.compose env2276 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound2276 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2277 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,602,8201,8323,674,2080,1025,8201,1751,33,185,139,8328,232,2048,603,1750,2080,1024,0,253,0,602,512]

theorem envBound2277 : H12AffineFastState.Bounded env2277 := by
  intro p hp
  have h : env2277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2276_2277 : H12AffineEnvironment.transform 11 1582 env2276 = env2277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env2276 == env2277) = true)

theorem identity2277 : scanCanonicalize (H12AffineFastState.compose env2277 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound2277 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env2278 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3822,602,3815,3693,674,2080,1025,3815,1751,33,185,139,3686,232,2048,603,1750,2080,1024,0,253,0,602,512]

theorem envBound2278 : H12AffineFastState.Bounded env2278 := by
  intro p hp
  have h : env2278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2277_2278 : H12AffineEnvironment.transform 12 3822 env2277 = env2278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env2277 == env2278) = true)

theorem identity2278 : scanCanonicalize (H12AffineFastState.compose env2278 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2278 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2279 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,554,2794,602,2787,2665,674,2080,5,2787,723,33,185,139,2658,232,2048,603,722,2080,4,0,253,0,602,512]

theorem envBound2279 : H12AffineFastState.Bounded env2279 := by
  intro p hp
  have h : env2279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2278_2279 : H12AffineEnvironment.transform 9 4 env2278 = env2279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2278 == env2279) = true)

theorem identity2279 : scanCanonicalize (H12AffineFastState.compose env2279 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2279 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env2280 : List Nat := [2,4,8,16,32,64,120,4,512,4,2048,554,2578,602,2587,2665,602,2080,5,2587,555,33,65,115,2658,16,2048,603,554,2080,4,0,5,0,602,512]

theorem envBound2280 : H12AffineFastState.Bounded env2280 := by
  intro p hp
  have h : env2280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2279_2280 : H12AffineEnvironment.transform 6 120 env2279 = env2280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2279 == env2280) = true)

theorem identity2280 : scanCanonicalize (H12AffineFastState.compose env2280 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound2280 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2281 : List Nat := [2,4,8,16,32,64,120,4,512,4,609,554,115,602,122,8,602,577,5,122,555,33,65,115,3,16,609,603,554,577,4,0,5,0,602,512]

theorem envBound2281 : H12AffineFastState.Bounded env2281 := by
  intro p hp
  have h : env2281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2280_2281 : H12AffineEnvironment.transform 10 609 env2280 = env2281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env2280 == env2281) = true)

theorem identity2281 : scanCanonicalize (H12AffineFastState.compose env2281 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound2281 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env2282 : List Nat := [2,4,8,16,27,64,67,4,512,4,602,529,72,602,65,8,602,577,5,65,528,26,65,72,3,16,602,603,529,577,4,0,5,0,602,512]

theorem envBound2282 : H12AffineFastState.Bounded env2282 := by
  intro p hp
  have h : env2282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2281_2282 : H12AffineEnvironment.transform 4 27 env2281 = env2282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env2281 == env2282) = true)

def env2283 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,2097152,73891,185,73737,8328,73834,149753,16385,151552,2080,74882,0,73854,0,131321,512]

theorem envBound2283 : H12AffineFastState.Bounded env2283 := by
  intro p hp
  have h : env2283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2271_2283 : H12AffineEnvironment.transform 7 253 env2271 = env2283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2271 == env2283) = true)

theorem identity2283 : scanCanonicalize (H12AffineFastState.compose env2283 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound2283 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2284 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,78034,73891,185,73737,8328,73834,149753,16385,151552,2080,74882,0,73854,0,131321,512]

theorem envBound2284 : H12AffineFastState.Bounded env2284 := by
  intro p hp
  have h : env2284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2283_2284 : H12AffineEnvironment.transform 20 78034 env2283 = env2284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env2283 == env2284) = true)

theorem identity2284 : scanCanonicalize (H12AffineFastState.compose env2284 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound2284 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2285 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210517,74883,8200,78034,73891,185,73737,8328,73834,136951,7695,134670,2080,74882,0,73854,0,131321,512]

theorem envBound2285 : H12AffineFastState.Bounded env2285 := by
  intro p hp
  have h : env2285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2284_2285 : H12AffineEnvironment.transform 13 7694 env2284 = env2285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env2284 == env2285) = true)

def env2286 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205377,74883,8200,74950,73891,185,73737,8328,73834,131811,2587,134670,2080,74882,0,73854,0,131321,512]

theorem envBound2286 : H12AffineFastState.Bounded env2286 := by
  intro p hp
  have h : env2286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2285_2286 : H12AffineEnvironment.transform 11 1044 env2285 = env2286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env2285 == env2286) = true)

def env2287 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2081,74883,8200,74950,73891,185,73737,8328,73834,75907,2587,74862,2080,74882,0,73854,0,76441,512]

theorem envBound2287 : H12AffineFastState.Bounded env2287 := by
  intro p hp
  have h : env2287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2286_2287 : H12AffineEnvironment.transform 16 76384 env2286 = env2287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2286 == env2287) = true)

theorem identity2287 : scanCanonicalize (H12AffineFastState.compose env2287 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2287 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2288 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,3733,9461,2081,10774,8200,10835,11830,185,11932,8328,12031,9750,2587,11003,2080,10775,0,12011,0,9228,512]

theorem envBound2288 : H12AffineFastState.Bounded env2288 := by
  intro p hp
  have h : env2288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2287_2288 : H12AffineEnvironment.transform 15 3733 env2287 = env2288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2287 == env2288) = true)

theorem identity2288 : scanCanonicalize (H12AffineFastState.compose env2288 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2288 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2289 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,3733,2786,2081,1025,3615,1092,33,185,139,3743,232,2049,2587,1260,2080,1024,0,252,0,2587,512]

theorem envBound2289 : H12AffineFastState.Bounded env2289 := by
  intro p hp
  have h : env2289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2288_2289 : H12AffineEnvironment.transform 12 3607 env2288 = env2289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2288 == env2289) = true)

theorem identity2289 : scanCanonicalize (H12AffineFastState.compose env2289 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2289 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2290 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2626,2586,2634,2752,2786,2081,84,2634,17,33,185,139,2762,232,2049,2587,185,2080,85,0,252,0,2587,512]

theorem envBound2290 : H12AffineFastState.Bounded env2290 := by
  intro p hp
  have h : env2290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2289_2290 : H12AffineEnvironment.transform 9 85 env2289 = env2290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2289 == env2290) = true)

theorem identity2290 : scanCanonicalize (H12AffineFastState.compose env2290 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2290 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2291 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,65,2626,2586,2634,2665,2635,2081,84,2634,17,33,16,34,2659,65,2049,2587,16,2080,85,0,85,0,2587,512]

theorem envBound2291 : H12AffineFastState.Bounded env2291 := by
  intro p hp
  have h : env2291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2290_2291 : H12AffineEnvironment.transform 6 41 env2290 = env2291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2290 == env2291) = true)

def env2292 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,65,2626,2586,2634,2649,2635,2065,84,2634,17,17,16,18,2643,65,2049,2587,16,2064,85,0,85,0,2587,512]

theorem envBound2292 : H12AffineFastState.Bounded env2292 := by
  intro p hp
  have h : env2292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2291_2292 : H12AffineEnvironment.transform 4 16 env2291 = env2292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2291 == env2292) = true)

def env2293 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,65,578,538,586,601,587,17,84,586,17,17,16,18,595,65,1,539,16,16,85,0,85,0,539,512]

theorem envBound2293 : H12AffineFastState.Bounded env2293 := by
  intro p hp
  have h : env2293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2292_2293 : H12AffineEnvironment.transform 10 0 env2292 = env2293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2292 == env2293) = true)

theorem identity2293 : scanCanonicalize (H12AffineFastState.compose env2293 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound2293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2294 : List Nat := [2,4,8,16,16,64,25,84,22,85,0,65,84,12,92,79,93,17,84,92,17,17,16,18,69,65,1,13,16,16,85,0,85,0,13,22]

theorem envBound2294 : H12AffineFastState.Bounded env2294 := by
  intro p hp
  have h : env2294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2293_2294 : H12AffineEnvironment.transform 8 22 env2293 = env2294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env2293 == env2294) = true)

def env2295 : List Nat := [2,4,8,16,16,0,25,20,22,21,0,1,20,12,28,15,29,17,20,28,17,17,16,18,5,1,1,13,16,16,21,0,21,0,13,22]

theorem envBound2295 : H12AffineFastState.Bounded env2295 := by
  intro p hp
  have h : env2295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2294_2295 : H12AffineEnvironment.transform 5 0 env2294 = env2295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2294 == env2295) = true)

theorem identity2295 : scanCanonicalize (H12AffineFastState.compose env2295 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2295 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2296 : List Nat := [2,4,4,16,16,0,21,20,22,21,0,1,20,0,16,3,17,17,20,16,17,17,16,18,5,1,1,1,16,16,21,0,21,0,1,22]

theorem envBound2296 : H12AffineFastState.Bounded env2296 := by
  intro p hp
  have h : env2296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2295_2296 : H12AffineEnvironment.transform 2 4 env2295 = env2296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2295 == env2296) = true)

def leafEnv2296 : List Nat := [2,4,4,16,16,0,21,20,22,21,0,1,20,0,16,3,17,17,20,16,17,17,16,18,21,5,1,1,1,1,16,16,21,0,21,0,4,19,1,22,1,16,0]

def active2296 : List Nat := [0,1,3]

def tree2296 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2296 : H12WitnessSearch.Good tree2296 := H12GlobalWitnessIndex.good

theorem leafIdentity2296 : H12AffineFastState.composeSystem env2296 rootObs = leafEnv2296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2296 rootObs == leafEnv2296) = true)

theorem terminalChecked2296 : H12PackedTerminal.terminalCheckFast leafEnv2296 active2296 tree2296 = true := by decide +kernel

def env2297 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,0,21,12,29,14,28,17,21,29,17,17,16,18,4,0,1,13,16,16,20,0,20,0,13,22]

theorem envBound2297 : H12AffineFastState.Bounded env2297 := by
  intro p hp
  have h : env2297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2294_2297 : H12AffineEnvironment.transform 5 1 env2294 = env2297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2294 == env2297) = true)

def leafEnv2297 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,0,21,12,29,14,28,17,21,29,17,17,16,18,20,4,1,0,1,13,16,16,20,0,20,0,4,30,13,22,1,16,0]

def active2297 : List Nat := [0,1,2,3]

def tree2297 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2297 : H12WitnessSearch.Good tree2297 := H12GlobalWitnessIndex.good

theorem leafIdentity2297 : H12AffineFastState.composeSystem env2297 rootObs = leafEnv2297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2297 rootObs == leafEnv2297) = true)

theorem terminalChecked2297 : H12PackedTerminal.terminalCheckFast leafEnv2297 active2297 tree2297 = true := by decide +kernel

def env2298 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,65,579,539,587,600,586,16,84,587,17,17,16,18,594,65,0,538,16,17,85,0,85,0,538,512]

theorem envBound2298 : H12AffineFastState.Bounded env2298 := by
  intro p hp
  have h : env2298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2292_2298 : H12AffineEnvironment.transform 10 1 env2292 = env2298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2292 == env2298) = true)

theorem identity2298 : scanCanonicalize (H12AffineFastState.compose env2298 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2299 : List Nat := [2,4,8,16,16,64,25,84,7,85,1,65,68,28,76,95,77,16,84,76,17,17,16,18,85,65,0,29,16,17,85,0,85,0,29,7]

theorem envBound2299 : H12AffineFastState.Bounded env2299 := by
  intro p hp
  have h : env2299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2298_2299 : H12AffineEnvironment.transform 8 7 env2298 = env2299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2298 == env2299) = true)

def env2300 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,1,4,28,12,31,13,16,20,12,17,17,16,18,21,1,0,29,16,17,21,0,21,0,29,7]

theorem envBound2300 : H12AffineFastState.Bounded env2300 := by
  intro p hp
  have h : env2300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2299_2300 : H12AffineEnvironment.transform 5 0 env2299 = env2300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2299 == env2300) = true)

def leafEnv2300 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,1,4,28,12,31,13,16,20,12,17,17,16,18,21,21,1,1,0,29,16,17,21,0,21,0,4,15,29,7,1,16,0]

def active2300 : List Nat := [0,1,2,3]

def tree2300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2300 : H12WitnessSearch.Good tree2300 := H12GlobalWitnessIndex.good

theorem leafIdentity2300 : H12AffineFastState.composeSystem env2300 rootObs = leafEnv2300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2300 rootObs == leafEnv2300) = true)

theorem terminalChecked2300 : H12PackedTerminal.terminalCheckFast leafEnv2300 active2300 tree2300 = true := by decide +kernel

def env2301 : List Nat := [2,4,8,16,16,1,25,21,7,20,1,0,5,28,13,30,12,16,21,13,17,17,16,18,20,0,0,29,16,17,20,0,20,0,29,7]

theorem envBound2301 : H12AffineFastState.Bounded env2301 := by
  intro p hp
  have h : env2301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2299_2301 : H12AffineEnvironment.transform 5 1 env2299 = env2301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2299 == env2301) = true)

theorem identity2301 : scanCanonicalize (H12AffineFastState.compose env2301 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2302 : List Nat := [2,4,8,12,12,1,5,9,7,8,1,0,5,0,13,2,12,12,9,13,13,13,12,14,8,0,0,1,12,13,8,0,8,0,1,7]

theorem envBound2302 : H12AffineFastState.Bounded env2302 := by
  intro p hp
  have h : env2302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2301_2302 : H12AffineEnvironment.transform 3 12 env2301 = env2302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2301 == env2302) = true)

def leafEnv2302 : List Nat := [2,4,8,12,12,1,5,9,7,8,1,0,5,0,13,2,12,12,9,13,13,13,12,14,8,8,1,0,0,1,12,13,8,0,8,0,4,14,1,7,1,12,0]

def active2302 : List Nat := [0,1,2]

def tree2302 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2302 : H12WitnessSearch.Good tree2302 := H12GlobalWitnessIndex.good

theorem leafIdentity2302 : H12AffineFastState.composeSystem env2302 rootObs = leafEnv2302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2302 rootObs == leafEnv2302) = true)

theorem terminalChecked2302 : H12PackedTerminal.terminalCheckFast leafEnv2302 active2302 tree2302 = true := by decide +kernel

def env2303 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,65,2626,2586,2634,2648,2635,2064,84,2634,17,16,16,19,2642,65,2049,2587,16,2065,85,0,85,0,2587,512]

theorem envBound2303 : H12AffineFastState.Bounded env2303 := by
  intro p hp
  have h : env2303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2291_2303 : H12AffineEnvironment.transform 4 17 env2291 = env2303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2291 == env2303) = true)

def env2304 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,65,578,538,586,600,587,16,84,586,17,16,16,19,594,65,1,539,16,17,85,0,85,0,539,512]

theorem envBound2304 : H12AffineFastState.Bounded env2304 := by
  intro p hp
  have h : env2304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2303_2304 : H12AffineEnvironment.transform 10 0 env2303 = env2304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2303 == env2304) = true)

theorem identity2304 : scanCanonicalize (H12AffineFastState.compose env2304 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound2304 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2305 : List Nat := [2,4,8,16,17,29,24,9,512,8,0,28,543,538,535,517,534,16,9,535,17,16,16,19,527,28,1,539,16,17,8,0,8,0,539,512]

theorem envBound2305 : H12AffineFastState.Bounded env2305 := by
  intro p hp
  have h : env2305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2304_2305 : H12AffineEnvironment.transform 5 29 env2304 = env2305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env2304 == env2305) = true)

def env2306 : List Nat := [2,4,8,12,13,1,4,9,512,8,0,0,515,518,523,517,522,12,9,523,13,12,12,15,527,0,1,519,12,13,8,0,8,0,519,512]

theorem envBound2306 : H12AffineFastState.Bounded env2306 := by
  intro p hp
  have h : env2306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2305_2306 : H12AffineEnvironment.transform 3 12 env2305 = env2306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2305 == env2306) = true)

def leafEnv2306 : List Nat := [2,4,8,12,13,1,4,9,512,8,0,0,515,518,523,517,522,12,9,523,13,12,12,15,8,527,1,0,1,519,12,13,8,0,8,0,4,520,519,512,1,12,0]

def active2306 : List Nat := [0,1,2,8]

def tree2306 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2306 : H12WitnessSearch.Good tree2306 := H12GlobalWitnessIndex.good

theorem leafIdentity2306 : H12AffineFastState.composeSystem env2306 rootObs = leafEnv2306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2306 rootObs == leafEnv2306) = true)

theorem terminalChecked2306 : H12PackedTerminal.terminalCheckFast leafEnv2306 active2306 tree2306 = true := by decide +kernel

def env2307 : List Nat := [2,4,8,13,12,0,5,9,512,8,0,1,514,519,522,517,523,13,9,522,12,13,13,14,527,1,1,518,13,12,8,0,8,0,518,512]

theorem envBound2307 : H12AffineFastState.Bounded env2307 := by
  intro p hp
  have h : env2307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2305_2307 : H12AffineEnvironment.transform 3 13 env2305 = env2307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2305 == env2307) = true)

theorem identity2307 : scanCanonicalize (H12AffineFastState.compose env2307 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2307 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2308 : List Nat := [2,4,8,13,12,0,5,9,6,8,0,1,4,1,12,3,13,13,9,12,12,13,13,14,9,1,1,0,13,12,8,0,8,0,0,6]

theorem envBound2308 : H12AffineFastState.Bounded env2308 := by
  intro p hp
  have h : env2308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2307_2308 : H12AffineEnvironment.transform 8 6 env2307 = env2308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2307 == env2308) = true)

def leafEnv2308 : List Nat := [2,4,8,13,12,0,5,9,6,8,0,1,4,1,12,3,13,13,9,12,12,13,13,14,8,9,1,1,1,0,13,12,8,0,8,0,4,15,0,6,1,13,0]

def active2308 : List Nat := [0,1,2]

def tree2308 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2308 : H12WitnessSearch.Good tree2308 := H12GlobalWitnessIndex.good

theorem leafIdentity2308 : H12AffineFastState.composeSystem env2308 rootObs = leafEnv2308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2308 rootObs == leafEnv2308) = true)

theorem terminalChecked2308 : H12PackedTerminal.terminalCheckFast leafEnv2308 active2308 tree2308 = true := by decide +kernel

def env2309 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,65,579,539,587,601,586,17,84,587,17,16,16,19,595,65,0,538,16,16,85,0,85,0,538,512]

theorem envBound2309 : H12AffineFastState.Bounded env2309 := by
  intro p hp
  have h : env2309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2303_2309 : H12AffineEnvironment.transform 10 1 env2303 = env2309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2303 == env2309) = true)

theorem identity2309 : scanCanonicalize (H12AffineFastState.compose env2309 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound2309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2310 : List Nat := [2,4,8,16,17,12,24,24,512,25,1,13,527,539,519,533,518,17,24,519,17,16,16,19,543,13,0,538,16,16,25,0,25,0,538,512]

theorem envBound2310 : H12AffineFastState.Bounded env2310 := by
  intro p hp
  have h : env2310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2309_2310 : H12AffineEnvironment.transform 5 12 env2309 = env2310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env2309 == env2310) = true)

def env2311 : List Nat := [2,4,4,16,17,0,20,20,512,21,1,1,515,535,519,533,518,17,20,519,17,16,16,19,531,1,0,534,16,16,21,0,21,0,534,512]

theorem envBound2311 : H12AffineFastState.Bounded env2311 := by
  intro p hp
  have h : env2311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2310_2311 : H12AffineEnvironment.transform 2 4 env2310 = env2311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2310 == env2311) = true)

def leafEnv2311 : List Nat := [2,4,4,16,17,0,20,20,512,21,1,1,515,535,519,533,518,17,20,519,17,16,16,19,21,531,1,1,0,534,16,16,21,0,21,0,4,516,534,512,1,16,0]

def active2311 : List Nat := [0,1,3,8]

def tree2311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2311 : H12WitnessSearch.Good tree2311 := H12GlobalWitnessIndex.good

theorem leafIdentity2311 : H12AffineFastState.composeSystem env2311 rootObs = leafEnv2311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2311 rootObs == leafEnv2311) = true)

theorem terminalChecked2311 : H12PackedTerminal.terminalCheckFast leafEnv2311 active2311 tree2311 = true := by decide +kernel

def env2312 : List Nat := [2,4,5,16,17,1,21,21,512,20,1,0,514,534,519,533,518,17,21,519,17,16,16,19,530,0,0,535,16,16,20,0,20,0,535,512]

theorem envBound2312 : H12AffineFastState.Bounded env2312 := by
  intro p hp
  have h : env2312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2310_2312 : H12AffineEnvironment.transform 2 5 env2310 = env2312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2310 == env2312) = true)

theorem identity2312 : scanCanonicalize (H12AffineFastState.compose env2312 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2313 : List Nat := [2,4,5,16,17,1,21,21,23,20,1,0,21,1,16,2,17,17,21,16,17,16,16,19,5,0,0,0,16,16,20,0,20,0,0,23]

theorem envBound2313 : H12AffineFastState.Bounded env2313 := by
  intro p hp
  have h : env2313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2312_2313 : H12AffineEnvironment.transform 8 23 env2312 = env2313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2312 == env2313) = true)

def leafEnv2313 : List Nat := [2,4,5,16,17,1,21,21,23,20,1,0,21,1,16,2,17,17,21,16,17,16,16,19,20,5,1,0,0,0,16,16,20,0,20,0,4,19,0,23,1,16,0]

def active2313 : List Nat := [0,1,3]

def tree2313 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2313 : H12WitnessSearch.Good tree2313 := H12GlobalWitnessIndex.good

theorem leafIdentity2313 : H12AffineFastState.composeSystem env2313 rootObs = leafEnv2313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2313 rootObs == leafEnv2313) = true)

theorem terminalChecked2313 : H12PackedTerminal.terminalCheckFast leafEnv2313 active2313 tree2313 = true := by decide +kernel

def env2314 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2080,74883,8200,74950,73891,185,73737,8328,73834,75906,2587,74863,2080,74882,0,73854,0,76440,512]

theorem envBound2314 : H12AffineFastState.Bounded env2314 := by
  intro p hp
  have h : env2314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2286_2314 : H12AffineEnvironment.transform 16 76385 env2286 = env2314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2286 == env2314) = true)

theorem identity2314 : scanCanonicalize (H12AffineFastState.compose env2314 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound2314 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2315 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,225,2586,233,65536,68224,2080,66658,233,66599,65602,185,65768,105,65675,67683,2587,66702,2080,66659,0,65695,0,68217,512]

theorem envBound2315 : H12AffineFastState.Bounded env2315 := by
  intro p hp
  have h : env2315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2314_2315 : H12AffineEnvironment.transform 12 225 env2314 = env2315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env2314 == env2315) = true)

def env2316 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205376,74883,8200,74951,73891,185,73737,8328,73834,131810,2586,134670,2080,74882,0,73854,0,131321,512]

theorem envBound2316 : H12AffineFastState.Bounded env2316 := by
  intro p hp
  have h : env2316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2285_2316 : H12AffineEnvironment.transform 11 1045 env2285 = env2316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env2285 == env2316) = true)

def env2317 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2080,74883,8200,74951,73891,185,73737,8328,73834,75906,2586,74862,2080,74882,0,73854,0,76441,512]

theorem envBound2317 : H12AffineFastState.Bounded env2317 := by
  intro p hp
  have h : env2317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2316_2317 : H12AffineEnvironment.transform 16 76384 env2316 = env2317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2316 == env2317) = true)

theorem identity2317 : scanCanonicalize (H12AffineFastState.compose env2317 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound2317 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2318 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,99,10755,2080,9440,8200,9380,8384,185,8298,8328,8201,10465,2586,9229,2080,9441,0,8221,0,11002,512]

theorem envBound2318 : H12AffineFastState.Bounded env2318 := by
  intro p hp
  have h : env2318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2317_2318 : H12AffineEnvironment.transform 15 99 env2317 = env2318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env2317 == env2318) = true)

def env2319 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2081,74883,8200,74951,73891,185,73737,8328,73834,75907,2586,74863,2080,74882,0,73854,0,76440,512]

theorem envBound2319 : H12AffineFastState.Bounded env2319 := by
  intro p hp
  have h : env2319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2316_2319 : H12AffineEnvironment.transform 16 76385 env2316 = env2319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2316 == env2319) = true)

theorem identity2319 : scanCanonicalize (H12AffineFastState.compose env2319 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2319 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2320 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,65536,66678,2081,68244,3615,68304,69300,185,69150,3743,69245,67220,2586,68216,2080,68245,0,69225,0,66703,512]

theorem envBound2320 : H12AffineFastState.Bounded env2320 := by
  intro p hp
  have h : env2320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2319_2320 : H12AffineEnvironment.transform 12 3607 env2319 = env2320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2319 == env2320) = true)

theorem identity2320 : scanCanonicalize (H12AffineFastState.compose env2320 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2320 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2321 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,3733,2787,2081,1025,3615,1093,33,185,139,3743,232,2049,2586,1261,2080,1024,0,252,0,2586,512]

theorem envBound2321 : H12AffineFastState.Bounded env2321 := by
  intro p hp
  have h : env2321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2320_2321 : H12AffineEnvironment.transform 15 3733 env2320 = env2321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2320 == env2321) = true)

theorem identity2321 : scanCanonicalize (H12AffineFastState.compose env2321 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2321 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2322 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2626,2587,2634,2752,2787,2081,84,2634,16,33,185,139,2762,232,2049,2586,184,2080,85,0,252,0,2586,512]

theorem envBound2322 : H12AffineFastState.Bounded env2322 := by
  intro p hp
  have h : env2322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2321_2322 : H12AffineEnvironment.transform 9 85 env2321 = env2322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2321 == env2322) = true)

theorem identity2322 : scanCanonicalize (H12AffineFastState.compose env2322 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2322 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2323 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,64,2626,2587,2634,2665,2634,2081,84,2634,16,33,16,34,2659,65,2049,2586,17,2080,85,0,85,0,2586,512]

theorem envBound2323 : H12AffineFastState.Bounded env2323 := by
  intro p hp
  have h : env2323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2322_2323 : H12AffineEnvironment.transform 6 41 env2322 = env2323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2322 == env2323) = true)

def env2324 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,64,2626,2587,2634,2649,2634,2065,84,2634,16,17,16,18,2643,65,2049,2586,17,2064,85,0,85,0,2586,512]

theorem envBound2324 : H12AffineFastState.Bounded env2324 := by
  intro p hp
  have h : env2324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2323_2324 : H12AffineEnvironment.transform 4 16 env2323 = env2324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2323 == env2324) = true)

def env2325 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,64,578,539,586,601,586,17,84,586,16,17,16,18,595,65,1,538,17,16,85,0,85,0,538,512]

theorem envBound2325 : H12AffineFastState.Bounded env2325 := by
  intro p hp
  have h : env2325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2324_2325 : H12AffineEnvironment.transform 10 0 env2324 = env2325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2324 == env2325) = true)

theorem identity2325 : scanCanonicalize (H12AffineFastState.compose env2325 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2326 : List Nat := [2,4,8,12,12,64,5,72,512,73,0,64,578,519,586,581,586,13,72,586,12,13,12,14,591,65,1,518,13,12,73,0,73,0,518,512]

theorem envBound2326 : H12AffineFastState.Bounded env2326 := by
  intro p hp
  have h : env2326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2325_2326 : H12AffineEnvironment.transform 3 12 env2325 = env2326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2325 == env2326) = true)

def env2327 : List Nat := [2,4,8,12,12,0,5,8,512,9,0,0,514,519,522,517,522,13,8,522,12,13,12,14,527,1,1,518,13,12,9,0,9,0,518,512]

theorem envBound2327 : H12AffineFastState.Bounded env2327 := by
  intro p hp
  have h : env2327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2326_2327 : H12AffineEnvironment.transform 5 0 env2326 = env2327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2326 == env2327) = true)

def leafEnv2327 : List Nat := [2,4,8,12,12,0,5,8,512,9,0,0,514,519,522,517,522,13,8,522,12,13,12,14,9,527,1,1,1,518,13,12,9,0,9,0,4,521,518,512,1,13,0]

def active2327 : List Nat := [0,1,2,8]

def tree2327 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2327 : H12WitnessSearch.Good tree2327 := H12GlobalWitnessIndex.good

theorem leafIdentity2327 : H12AffineFastState.composeSystem env2327 rootObs = leafEnv2327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2327 rootObs == leafEnv2327) = true)

theorem terminalChecked2327 : H12PackedTerminal.terminalCheckFast leafEnv2327 active2327 tree2327 = true := by decide +kernel

def env2328 : List Nat := [2,4,8,12,12,1,5,9,512,8,0,1,515,519,523,516,523,13,9,523,12,13,12,14,526,0,1,518,13,12,8,0,8,0,518,512]

theorem envBound2328 : H12AffineFastState.Bounded env2328 := by
  intro p hp
  have h : env2328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2326_2328 : H12AffineEnvironment.transform 5 1 env2326 = env2328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2326 == env2328) = true)

theorem identity2328 : scanCanonicalize (H12AffineFastState.compose env2328 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2329 : List Nat := [2,4,8,12,12,1,5,9,6,8,0,1,5,1,13,2,13,13,9,13,12,13,12,14,8,0,1,0,13,12,8,0,8,0,0,6]

theorem envBound2329 : H12AffineFastState.Bounded env2329 := by
  intro p hp
  have h : env2329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2328_2329 : H12AffineEnvironment.transform 8 6 env2328 = env2329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2328 == env2329) = true)

def leafEnv2329 : List Nat := [2,4,8,12,12,1,5,9,6,8,0,1,5,1,13,2,13,13,9,13,12,13,12,14,8,8,1,0,1,0,13,12,8,0,8,0,4,14,0,6,1,13,0]

def active2329 : List Nat := [0,1,2]

def tree2329 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2329 : H12WitnessSearch.Good tree2329 := H12GlobalWitnessIndex.good

theorem leafIdentity2329 : H12AffineFastState.composeSystem env2329 rootObs = leafEnv2329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2329 rootObs == leafEnv2329) = true)

theorem terminalChecked2329 : H12PackedTerminal.terminalCheckFast leafEnv2329 active2329 tree2329 = true := by decide +kernel

def env2330 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,64,579,538,587,600,587,16,84,587,16,17,16,18,594,65,0,539,17,17,85,0,85,0,539,512]

theorem envBound2330 : H12AffineFastState.Bounded env2330 := by
  intro p hp
  have h : env2330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2324_2330 : H12AffineEnvironment.transform 10 1 env2324 = env2330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2324 == env2330) = true)

theorem identity2330 : scanCanonicalize (H12AffineFastState.compose env2330 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2331 : List Nat := [2,4,4,16,16,64,21,84,512,85,1,64,579,534,583,596,583,16,84,583,16,17,16,18,594,65,0,535,17,17,85,0,85,0,535,512]

theorem envBound2331 : H12AffineFastState.Bounded env2331 := by
  intro p hp
  have h : env2331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2330_2331 : H12AffineEnvironment.transform 2 4 env2330 = env2331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2330 == env2331) = true)

def env2332 : List Nat := [2,4,4,16,16,0,21,20,512,21,1,0,515,534,519,532,519,16,20,519,16,17,16,18,530,1,0,535,17,17,21,0,21,0,535,512]

theorem envBound2332 : H12AffineFastState.Bounded env2332 := by
  intro p hp
  have h : env2332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2331_2332 : H12AffineEnvironment.transform 5 0 env2331 = env2332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2331 == env2332) = true)

theorem identity2332 : scanCanonicalize (H12AffineFastState.compose env2332 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2333 : List Nat := [2,4,4,16,16,0,21,20,23,21,1,0,20,1,16,3,16,16,20,16,16,17,16,18,5,1,0,0,17,17,21,0,21,0,0,23]

theorem envBound2333 : H12AffineFastState.Bounded env2333 := by
  intro p hp
  have h : env2333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2332_2333 : H12AffineEnvironment.transform 8 23 env2332 = env2333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2332 == env2333) = true)

def leafEnv2333 : List Nat := [2,4,4,16,16,0,21,20,23,21,1,0,20,1,16,3,16,16,20,16,16,17,16,18,21,5,1,1,0,0,17,17,21,0,21,0,4,19,0,23,1,17,0]

def active2333 : List Nat := [0,1,3]

def tree2333 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2333 : H12WitnessSearch.Good tree2333 := H12GlobalWitnessIndex.good

theorem leafIdentity2333 : H12AffineFastState.composeSystem env2333 rootObs = leafEnv2333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2333 rootObs == leafEnv2333) = true)

theorem terminalChecked2333 : H12PackedTerminal.terminalCheckFast leafEnv2333 active2333 tree2333 = true := by decide +kernel

def env2334 : List Nat := [2,4,4,16,16,1,21,21,512,20,1,1,514,534,518,533,518,16,21,518,16,17,16,18,531,0,0,535,17,17,20,0,20,0,535,512]

theorem envBound2334 : H12AffineFastState.Bounded env2334 := by
  intro p hp
  have h : env2334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2331_2334 : H12AffineEnvironment.transform 5 1 env2331 = env2334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2331 == env2334) = true)

def leafEnv2334 : List Nat := [2,4,4,16,16,1,21,21,512,20,1,1,514,534,518,533,518,16,21,518,16,17,16,18,20,531,1,0,0,535,17,17,20,0,20,0,4,517,535,512,1,17,0]

def active2334 : List Nat := [0,1,3,8]

def tree2334 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2334 : H12WitnessSearch.Good tree2334 := H12GlobalWitnessIndex.good

theorem leafIdentity2334 : H12AffineFastState.composeSystem env2334 rootObs = leafEnv2334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2334 rootObs == leafEnv2334) = true)

theorem terminalChecked2334 : H12PackedTerminal.terminalCheckFast leafEnv2334 active2334 tree2334 = true := by decide +kernel

def env2335 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,64,2626,2587,2634,2648,2634,2064,84,2634,16,16,16,19,2642,65,2049,2586,17,2065,85,0,85,0,2586,512]

theorem envBound2335 : H12AffineFastState.Bounded env2335 := by
  intro p hp
  have h : env2335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2323_2335 : H12AffineEnvironment.transform 4 17 env2323 = env2335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2323 == env2335) = true)

def env2336 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,64,578,539,586,600,586,16,84,586,16,16,16,19,594,65,1,538,17,17,85,0,85,0,538,512]

theorem envBound2336 : H12AffineFastState.Bounded env2336 := by
  intro p hp
  have h : env2336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2335_2336 : H12AffineEnvironment.transform 10 0 env2335 = env2336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2335 == env2336) = true)

theorem identity2336 : scanCanonicalize (H12AffineFastState.compose env2336 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound2336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2337 : List Nat := [2,4,8,16,17,64,24,84,87,85,0,64,21,76,29,15,29,16,84,29,16,16,16,19,5,65,1,77,17,17,85,0,85,0,77,87]

theorem envBound2337 : H12AffineFastState.Bounded env2337 := by
  intro p hp
  have h : env2337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2336_2337 : H12AffineEnvironment.transform 8 87 env2336 = env2337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env2336 == env2337) = true)

def env2338 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,0,21,12,29,15,29,16,20,29,16,16,16,19,5,1,1,13,17,17,21,0,21,0,13,23]

theorem envBound2338 : H12AffineFastState.Bounded env2338 := by
  intro p hp
  have h : env2338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2337_2338 : H12AffineEnvironment.transform 5 0 env2337 = env2338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2337 == env2338) = true)

def leafEnv2338 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,0,21,12,29,15,29,16,20,29,16,16,16,19,21,5,1,1,1,13,17,17,21,0,21,0,4,30,13,23,1,17,0]

def active2338 : List Nat := [0,1,2,3]

def tree2338 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2338 : H12WitnessSearch.Good tree2338 := H12GlobalWitnessIndex.good

theorem leafIdentity2338 : H12AffineFastState.composeSystem env2338 rootObs = leafEnv2338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2338 rootObs == leafEnv2338) = true)

theorem terminalChecked2338 : H12PackedTerminal.terminalCheckFast leafEnv2338 active2338 tree2338 = true := by decide +kernel

def env2339 : List Nat := [2,4,8,16,17,1,24,21,22,20,0,1,21,13,29,15,29,16,21,29,16,16,16,19,5,0,1,12,17,17,20,0,20,0,12,22]

theorem envBound2339 : H12AffineFastState.Bounded env2339 := by
  intro p hp
  have h : env2339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2337_2339 : H12AffineEnvironment.transform 5 1 env2337 = env2339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2337 == env2339) = true)

theorem identity2339 : scanCanonicalize (H12AffineFastState.compose env2339 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2340 : List Nat := [2,4,5,16,17,1,21,21,22,20,0,1,21,0,16,2,16,16,21,16,16,16,16,19,5,0,1,1,17,17,20,0,20,0,1,22]

theorem envBound2340 : H12AffineFastState.Bounded env2340 := by
  intro p hp
  have h : env2340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2339_2340 : H12AffineEnvironment.transform 2 5 env2339 = env2340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2339 == env2340) = true)

def leafEnv2340 : List Nat := [2,4,5,16,17,1,21,21,22,20,0,1,21,0,16,2,16,16,21,16,16,16,16,19,20,5,1,0,1,1,17,17,20,0,20,0,4,19,1,22,1,17,0]

def active2340 : List Nat := [0,1,3]

def tree2340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2340 : H12WitnessSearch.Good tree2340 := H12GlobalWitnessIndex.good

theorem leafIdentity2340 : H12AffineFastState.composeSystem env2340 rootObs = leafEnv2340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2340 rootObs == leafEnv2340) = true)

theorem terminalChecked2340 : H12PackedTerminal.terminalCheckFast leafEnv2340 active2340 tree2340 = true := by decide +kernel

def env2341 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,64,579,538,587,601,587,17,84,587,16,16,16,19,595,65,0,539,17,16,85,0,85,0,539,512]

theorem envBound2341 : H12AffineFastState.Bounded env2341 := by
  intro p hp
  have h : env2341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2335_2341 : H12AffineEnvironment.transform 10 1 env2335 = env2341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2335 == env2341) = true)

theorem identity2341 : scanCanonicalize (H12AffineFastState.compose env2341 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound2341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2342 : List Nat := [2,4,8,16,17,64,24,84,71,85,1,64,4,93,12,30,12,17,84,12,16,16,16,19,20,65,0,92,17,16,85,0,85,0,92,71]

theorem envBound2342 : H12AffineFastState.Bounded env2342 := by
  intro p hp
  have h : env2342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2341_2342 : H12AffineEnvironment.transform 8 71 env2341 = env2342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env2341 == env2342) = true)

def env2343 : List Nat := [2,4,8,16,17,0,24,20,7,21,1,0,4,29,12,30,12,17,20,12,16,16,16,19,20,1,0,28,17,16,21,0,21,0,28,7]

theorem envBound2343 : H12AffineFastState.Bounded env2343 := by
  intro p hp
  have h : env2343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2342_2343 : H12AffineEnvironment.transform 5 0 env2342 = env2343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2342 == env2343) = true)

theorem identity2343 : scanCanonicalize (H12AffineFastState.compose env2343 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2344 : List Nat := [2,4,8,13,12,0,5,9,7,8,1,0,4,0,12,3,12,12,9,12,13,13,13,14,9,1,0,1,12,13,8,0,8,0,1,7]

theorem envBound2344 : H12AffineFastState.Bounded env2344 := by
  intro p hp
  have h : env2344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2343_2344 : H12AffineEnvironment.transform 3 13 env2343 = env2344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2343 == env2344) = true)

def leafEnv2344 : List Nat := [2,4,8,13,12,0,5,9,7,8,1,0,4,0,12,3,12,12,9,12,13,13,13,14,8,9,1,1,0,1,12,13,8,0,8,0,4,15,1,7,1,12,0]

def active2344 : List Nat := [0,1,2]

def tree2344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2344 : H12WitnessSearch.Good tree2344 := H12GlobalWitnessIndex.good

theorem leafIdentity2344 : H12AffineFastState.composeSystem env2344 rootObs = leafEnv2344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2344 rootObs == leafEnv2344) = true)

theorem terminalChecked2344 : H12PackedTerminal.terminalCheckFast leafEnv2344 active2344 tree2344 = true := by decide +kernel

def env2345 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,1,4,28,12,30,12,17,21,12,16,16,16,19,20,0,0,29,17,16,20,0,20,0,29,6]

theorem envBound2345 : H12AffineFastState.Bounded env2345 := by
  intro p hp
  have h : env2345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2342_2345 : H12AffineEnvironment.transform 5 1 env2342 = env2345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2342 == env2345) = true)

def leafEnv2345 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,1,4,28,12,30,12,17,21,12,16,16,16,19,20,20,1,0,0,29,17,16,20,0,20,0,4,15,29,6,1,17,0]

def active2345 : List Nat := [0,1,2,3]

def tree2345 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2345 : H12WitnessSearch.Good tree2345 := H12GlobalWitnessIndex.good

theorem leafIdentity2345 : H12AffineFastState.composeSystem env2345 rootObs = leafEnv2345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2345 rootObs == leafEnv2345) = true)

theorem terminalChecked2345 : H12PackedTerminal.terminalCheckFast leafEnv2345 active2345 tree2345 = true := by decide +kernel

def env2346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,268435456,268570625,268453921,17399809,281601389,525568,268451841,34359738368,25733062]

theorem envBound2346 : H12AffineFastState.Bounded env2346 := by
  intro p hp
  have h : env2346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1820_2346 : H12AffineEnvironment.transform 25 8914001 env1820 = env2346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env1820 == env2346) = true)

def env2347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2081,17399809,13149549,525568,1,34359738368,25733062]

theorem envBound2347 : H12AffineFastState.Bounded env2347 := by
  intro p hp
  have h : env2347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2346_2347 : H12AffineEnvironment.transform 27 16384 env2346 = env2347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env2346 == env2347) = true)

def env2348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2081,17375733,13108377,525568,1,34359738368,25691698]

theorem envBound2348 : H12AffineFastState.Bounded env2348 := by
  intro p hp
  have h : env2348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2347_2348 : H12AffineEnvironment.transform 14 8692 env2347 = env2348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env2347 == env2348) = true)

theorem identity2348 : scanCanonicalize (H12AffineFastState.compose env2348 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound2348 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env2349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,8914001,9176216,16384,151553,2081,8463815,13108377,525568,1,34359738368,512]

theorem envBound2349 : H12AffineFastState.Bounded env2349 := by
  intro p hp
  have h : env2349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2348_2349 : H12AffineEnvironment.transform 23 8913970 env2348 = env2349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env2348 == env2349) = true)

theorem identity2349 : scanCanonicalize (H12AffineFastState.compose env2349 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525345) := by decide +kernel

theorem selectedBound2349 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525345,8388608,8913970,8328,8914001,9176216,16384,151553,2081,8463815,8388792,525568,1,34359738368,512]

theorem envBound2350 : H12AffineFastState.Bounded env2350 := by
  intro p hp
  have h : env2350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2349_2350 : H12AffineEnvironment.transform 21 525345 env2349 = env2350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525345 env2349 == env2350) = true)

theorem identity2350 : scanCanonicalize (H12AffineFastState.compose env2350 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75135) := by decide +kernel

theorem selectedBound2350 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env2351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462669,8328,8462638,8724967,16384,151553,2081,8463815,8388792,73855,1,34359738368,512]

theorem envBound2351 : H12AffineFastState.Bounded env2351 := by
  intro p hp
  have h : env2351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2350_2351 : H12AffineEnvironment.transform 18 75135 env2350 = env2351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75135 env2350 == env2351) = true)

theorem identity2351 : scanCanonicalize (H12AffineFastState.compose env2351 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131333) := by decide +kernel

theorem selectedBound2351 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462669,8328,8462638,8724967,16384,151553,2081,8463815,8388792,73855,1,131333,512]

theorem envBound2352 : H12AffineFastState.Bounded env2352 := by
  intro p hp
  have h : env2352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2351_2352 : H12AffineEnvironment.transform 34 131333 env2351 = env2352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131333 env2351 == env2352) = true)

def env2353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,184,74229,8328,74134,336223,16384,151553,2081,75135,0,73855,1,131333,512]

theorem envBound2353 : H12AffineFastState.Bounded env2353 := by
  intro p hp
  have h : env2353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2352_2353 : H12AffineEnvironment.transform 22 184 env2352 = env2353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env2352 == env2353) = true)

theorem identity2353 : scanCanonicalize (H12AffineFastState.compose env2353 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound2353 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2354 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74882,8201,2097152,73891,184,73736,8328,73835,336034,16384,151553,2081,74882,0,73855,1,131320,512]

theorem envBound2354 : H12AffineFastState.Bounded env2354 := by
  intro p hp
  have h : env2354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2353_2354 : H12AffineEnvironment.transform 7 253 env2353 = env2354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2353 == env2354) = true)

def env2355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,185,74228,8328,74135,336222,16384,151553,2081,75134,1,73855,1,131333,512]

theorem envBound2355 : H12AffineFastState.Bounded env2355 := by
  intro p hp
  have h : env2355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2352_2355 : H12AffineEnvironment.transform 22 185 env2352 = env2355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env2352 == env2355) = true)

theorem identity2355 : scanCanonicalize (H12AffineFastState.compose env2355 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound2355 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env2356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223323,75135,8692,2097152,74078,185,74228,8328,74135,149765,16384,151553,2081,75134,1,73855,1,131333,512]

theorem envBound2356 : H12AffineFastState.Bounded env2356 := by
  intro p hp
  have h : env2356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2355_2356 : H12AffineEnvironment.transform 17 223323 env2355 = env2356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env2355 == env2356) = true)

def env2357 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,2097152,73890,185,73736,8328,73835,149753,16384,151553,2081,74882,1,73855,1,131321,512]

theorem envBound2357 : H12AffineFastState.Bounded env2357 := by
  intro p hp
  have h : env2357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2356_2357 : H12AffineEnvironment.transform 7 252 env2356 = env2357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2356 == env2357) = true)

theorem identity2357 : scanCanonicalize (H12AffineFastState.compose env2357 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151552) := by decide +kernel

theorem selectedBound2357 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2358 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,151552,73890,185,73736,8328,73835,149753,16384,151553,2081,74882,1,73855,1,131321,512]

theorem envBound2358 : H12AffineFastState.Bounded env2358 := by
  intro p hp
  have h : env2358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2357_2358 : H12AffineEnvironment.transform 20 151552 env2357 = env2358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151552 env2357 == env2358) = true)

theorem identity2358 : scanCanonicalize (H12AffineFastState.compose env2358 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90234) := by decide +kernel

theorem selectedBound2358 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env2359 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90234,2081,74883,8200,77946,73890,185,73736,8328,73835,75907,16384,77947,2081,74882,1,73855,1,90243,512]

theorem envBound2359 : H12AffineFastState.Bounded env2359 := by
  intro p hp
  have h : env2359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2358_2359 : H12AffineEnvironment.transform 16 90234 env2358 = env2359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90234 env2358 == env2359) = true)

theorem identity2359 : scanCanonicalize (H12AffineFastState.compose env2359 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound2359 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env2360 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16633,2081,1024,8200,4345,33,185,139,8328,232,2048,16384,4344,2081,1025,1,252,1,16384,512]

theorem envBound2360 : H12AffineFastState.Bounded env2360 := by
  intro p hp
  have h : env2360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2359_2360 : H12AffineEnvironment.transform 15 8323 env2359 = env2360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env2359 == env2360) = true)

theorem identity2360 : scanCanonicalize (H12AffineFastState.compose env2360 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound2360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2361 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8200,8323,5260,2081,1024,8200,4345,33,185,139,8328,232,2048,5237,4344,2081,1025,1,252,1,5237,512]

theorem envBound2361 : H12AffineFastState.Bounded env2361 := by
  intro p hp
  have h : env2361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2360_2361 : H12AffineEnvironment.transform 13 5237 env2360 = env2361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env2360 == env2361) = true)

theorem identity2361 : scanCanonicalize (H12AffineFastState.compose env2361 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound2361 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2362 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,602,8200,8323,675,2081,1024,8200,1750,33,185,139,8328,232,2048,602,1751,2081,1025,1,252,1,602,512]

theorem envBound2362 : H12AffineFastState.Bounded env2362 := by
  intro p hp
  have h : env2362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2361_2362 : H12AffineEnvironment.transform 11 1583 env2361 = env2362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env2361 == env2362) = true)

theorem identity2362 : scanCanonicalize (H12AffineFastState.compose env2362 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound2362 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env2363 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3822,602,3814,3693,675,2081,1024,3814,1750,33,185,139,3686,232,2048,602,1751,2081,1025,1,252,1,602,512]

theorem envBound2363 : H12AffineFastState.Bounded env2363 := by
  intro p hp
  have h : env2363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2362_2363 : H12AffineEnvironment.transform 12 3822 env2362 = env2363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env2362 == env2363) = true)

theorem identity2363 : scanCanonicalize (H12AffineFastState.compose env2363 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound2363 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2364 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,554,2795,602,2787,2664,675,2081,5,2787,723,33,185,139,2659,232,2048,602,722,2081,4,1,252,1,602,512]

theorem envBound2364 : H12AffineFastState.Bounded env2364 := by
  intro p hp
  have h : env2364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2363_2364 : H12AffineEnvironment.transform 9 5 env2363 = env2364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env2363 == env2364) = true)

theorem identity2364 : scanCanonicalize (H12AffineFastState.compose env2364 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2364 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env2365 : List Nat := [2,4,8,16,32,64,120,4,512,5,2048,554,2579,602,2587,2664,603,2081,5,2587,555,33,65,115,2659,16,2048,602,554,2081,4,1,4,1,602,512]

theorem envBound2365 : H12AffineFastState.Bounded env2365 := by
  intro p hp
  have h : env2365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2364_2365 : H12AffineEnvironment.transform 6 120 env2364 = env2365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2364 == env2365) = true)

theorem identity2365 : scanCanonicalize (H12AffineFastState.compose env2365 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound2365 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2366 : List Nat := [2,4,8,16,32,64,120,4,512,5,608,554,115,602,123,8,603,577,5,123,555,33,65,115,3,16,608,602,554,577,4,1,4,1,602,512]

theorem envBound2366 : H12AffineFastState.Bounded env2366 := by
  intro p hp
  have h : env2366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2365_2366 : H12AffineEnvironment.transform 10 608 env2365 = env2366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env2365 == env2366) = true)

theorem identity2366 : scanCanonicalize (H12AffineFastState.compose env2366 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound2366 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env2367 : List Nat := [2,4,8,16,26,64,66,4,512,5,602,528,73,602,65,8,603,577,5,65,529,27,65,73,3,16,602,602,528,577,4,1,4,1,602,512]

theorem envBound2367 : H12AffineFastState.Bounded env2367 := by
  intro p hp
  have h : env2367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2366_2367 : H12AffineEnvironment.transform 4 26 env2366 = env2367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env2366 == env2367) = true)

def env2368 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,2097152,73891,185,73737,8328,73834,149752,16384,151553,2081,74883,1,73855,1,131320,512]

theorem envBound2368 : H12AffineFastState.Bounded env2368 := by
  intro p hp
  have h : env2368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2356_2368 : H12AffineEnvironment.transform 7 253 env2356 = env2368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2356 == env2368) = true)

theorem identity2368 : scanCanonicalize (H12AffineFastState.compose env2368 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound2368 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2369 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,78035,73891,185,73737,8328,73834,149752,16384,151553,2081,74883,1,73855,1,131320,512]

theorem envBound2369 : H12AffineFastState.Bounded env2369 := by
  intro p hp
  have h : env2369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2368_2369 : H12AffineEnvironment.transform 20 78035 env2368 = env2369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env2368 == env2369) = true)

theorem identity2369 : scanCanonicalize (H12AffineFastState.compose env2369 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound2369 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2370 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210516,74882,8201,78035,73891,185,73737,8328,73834,136951,7695,134670,2081,74883,1,73855,1,131320,512]

theorem envBound2370 : H12AffineFastState.Bounded env2370 := by
  intro p hp
  have h : env2370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2369_2370 : H12AffineEnvironment.transform 13 7695 env2369 = env2370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env2369 == env2370) = true)

def env2371 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205376,74882,8201,74951,73891,185,73737,8328,73834,131811,2587,134670,2081,74883,1,73855,1,131320,512]

theorem envBound2371 : H12AffineFastState.Bounded env2371 := by
  intro p hp
  have h : env2371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2370_2371 : H12AffineEnvironment.transform 11 1044 env2370 = env2371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env2370 == env2371) = true)

def env2372 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2080,74882,8201,74951,73891,185,73737,8328,73834,75907,2587,74862,2081,74883,1,73855,1,76440,512]

theorem envBound2372 : H12AffineFastState.Bounded env2372 := by
  intro p hp
  have h : env2372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2371_2372 : H12AffineEnvironment.transform 16 76384 env2371 = env2372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2371 == env2372) = true)

theorem identity2372 : scanCanonicalize (H12AffineFastState.compose env2372 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2372 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2373 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,3733,9461,2080,10775,8201,10834,11830,185,11932,8328,12031,9750,2587,11003,2081,10774,1,12010,1,9229,512]

theorem envBound2373 : H12AffineFastState.Bounded env2373 := by
  intro p hp
  have h : env2373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2372_2373 : H12AffineEnvironment.transform 15 3733 env2372 = env2373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2372 == env2373) = true)

theorem identity2373 : scanCanonicalize (H12AffineFastState.compose env2373 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2373 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2374 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2587,3614,3733,2786,2080,1024,3614,1093,33,185,139,3743,232,2049,2587,1260,2081,1025,1,253,1,2586,512]

theorem envBound2374 : H12AffineFastState.Bounded env2374 := by
  intro p hp
  have h : env2374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2373_2374 : H12AffineEnvironment.transform 12 3607 env2373 = env2374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2373 == env2374) = true)

theorem identity2374 : scanCanonicalize (H12AffineFastState.compose env2374 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2374 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2375 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2626,2587,2635,2752,2786,2080,85,2635,16,33,185,139,2762,232,2049,2587,185,2081,84,1,253,1,2586,512]

theorem envBound2375 : H12AffineFastState.Bounded env2375 := by
  intro p hp
  have h : env2375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2374_2375 : H12AffineEnvironment.transform 9 85 env2374 = env2375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2374 == env2375) = true)

theorem identity2375 : scanCanonicalize (H12AffineFastState.compose env2375 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2375 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2376 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,65,2626,2587,2635,2664,2634,2080,85,2635,16,33,17,35,2658,64,2049,2587,17,2081,84,1,85,1,2586,512]

theorem envBound2376 : H12AffineFastState.Bounded env2376 := by
  intro p hp
  have h : env2376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2375_2376 : H12AffineEnvironment.transform 6 40 env2375 = env2376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2375 == env2376) = true)

def env2377 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,65,2626,2587,2635,2648,2634,2064,85,2635,16,17,17,19,2642,64,2049,2587,17,2065,84,1,85,1,2586,512]

theorem envBound2377 : H12AffineFastState.Bounded env2377 := by
  intro p hp
  have h : env2377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2376_2377 : H12AffineEnvironment.transform 4 16 env2376 = env2377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2376 == env2377) = true)

def env2378 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,65,578,539,587,600,586,16,85,587,16,17,17,19,594,64,1,539,17,17,84,1,85,1,538,512]

theorem envBound2378 : H12AffineFastState.Bounded env2378 := by
  intro p hp
  have h : env2378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2377_2378 : H12AffineEnvironment.transform 10 0 env2377 = env2378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2377 == env2378) = true)

theorem identity2378 : scanCanonicalize (H12AffineFastState.compose env2378 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound2378 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2379 : List Nat := [2,4,8,16,16,64,24,85,71,85,0,65,5,92,12,31,13,16,85,12,16,17,17,19,21,64,1,92,17,17,84,1,85,1,93,71]

theorem envBound2379 : H12AffineFastState.Bounded env2379 := by
  intro p hp
  have h : env2379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2378_2379 : H12AffineEnvironment.transform 8 71 env2378 = env2379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env2378 == env2379) = true)

def env2380 : List Nat := [2,4,8,16,16,0,24,21,7,21,0,1,5,28,12,31,13,16,21,12,16,17,17,19,21,0,1,28,17,17,20,1,21,1,29,7]

theorem envBound2380 : H12AffineFastState.Bounded env2380 := by
  intro p hp
  have h : env2380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2379_2380 : H12AffineEnvironment.transform 5 0 env2379 = env2380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2379 == env2380) = true)

def leafEnv2380 : List Nat := [2,4,8,16,16,0,24,21,7,21,0,1,5,28,12,31,13,16,21,12,16,17,17,19,21,21,1,0,1,28,17,17,20,1,21,1,5,14,29,7,1,17,0]

def active2380 : List Nat := [0,1,2,3]

def tree2380 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2380 : H12WitnessSearch.Good tree2380 := H12GlobalWitnessIndex.good

theorem leafIdentity2380 : H12AffineFastState.composeSystem env2380 rootObs = leafEnv2380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2380 rootObs == leafEnv2380) = true)

theorem terminalChecked2380 : H12PackedTerminal.terminalCheckFast leafEnv2380 active2380 tree2380 = true := by decide +kernel

def env2381 : List Nat := [2,4,8,16,16,1,24,20,6,20,0,0,5,29,12,31,13,16,20,12,16,17,17,19,21,1,1,29,17,17,21,1,20,1,28,6]

theorem envBound2381 : H12AffineFastState.Bounded env2381 := by
  intro p hp
  have h : env2381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2379_2381 : H12AffineEnvironment.transform 5 1 env2379 = env2381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2379 == env2381) = true)

theorem identity2381 : scanCanonicalize (H12AffineFastState.compose env2381 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2382 : List Nat := [2,4,8,13,13,1,5,9,6,9,0,0,5,0,12,2,13,13,9,12,13,12,12,14,8,1,1,0,12,12,8,1,9,1,1,6]

theorem envBound2382 : H12AffineFastState.Bounded env2382 := by
  intro p hp
  have h : env2382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2381_2382 : H12AffineEnvironment.transform 3 13 env2381 = env2382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2381 == env2382) = true)

def leafEnv2382 : List Nat := [2,4,8,13,13,1,5,9,6,9,0,0,5,0,12,2,13,13,9,12,13,12,12,14,9,8,1,1,1,0,12,12,8,1,9,1,5,14,1,6,1,12,0]

def active2382 : List Nat := [0,1,2]

def tree2382 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2382 : H12WitnessSearch.Good tree2382 := H12GlobalWitnessIndex.good

theorem leafIdentity2382 : H12AffineFastState.composeSystem env2382 rootObs = leafEnv2382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2382 rootObs == leafEnv2382) = true)

theorem terminalChecked2382 : H12PackedTerminal.terminalCheckFast leafEnv2382 active2382 tree2382 = true := by decide +kernel

def env2383 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,65,579,538,586,601,587,17,85,586,16,17,17,19,595,64,0,538,17,16,84,1,85,1,539,512]

theorem envBound2383 : H12AffineFastState.Bounded env2383 := by
  intro p hp
  have h : env2383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2377_2383 : H12AffineEnvironment.transform 10 1 env2377 = env2383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2377 == env2383) = true)

theorem identity2383 : scanCanonicalize (H12AffineFastState.compose env2383 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound2383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2384 : List Nat := [2,4,8,16,16,64,24,85,87,85,1,65,20,77,29,14,28,17,85,29,16,17,17,19,4,64,0,77,17,16,84,1,85,1,76,87]

theorem envBound2384 : H12AffineFastState.Bounded env2384 := by
  intro p hp
  have h : env2384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2383_2384 : H12AffineEnvironment.transform 8 87 env2383 = env2384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env2383 == env2384) = true)

def env2385 : List Nat := [2,4,8,16,16,0,24,21,23,21,1,1,20,13,29,14,28,17,21,29,16,17,17,19,4,0,0,13,17,16,20,1,21,1,12,23]

theorem envBound2385 : H12AffineFastState.Bounded env2385 := by
  intro p hp
  have h : env2385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2384_2385 : H12AffineEnvironment.transform 5 0 env2384 = env2385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2384 == env2385) = true)

theorem identity2385 : scanCanonicalize (H12AffineFastState.compose env2385 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2386 : List Nat := [2,4,5,16,16,0,21,21,23,21,1,1,20,0,16,3,17,17,21,16,16,17,17,19,4,0,0,0,17,16,20,1,21,1,1,23]

theorem envBound2386 : H12AffineFastState.Bounded env2386 := by
  intro p hp
  have h : env2386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2385_2386 : H12AffineEnvironment.transform 2 5 env2385 = env2386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2385 == env2386) = true)

def leafEnv2386 : List Nat := [2,4,5,16,16,0,21,21,23,21,1,1,20,0,16,3,17,17,21,16,16,17,17,19,21,4,1,0,0,0,17,16,20,1,21,1,5,18,1,23,1,17,0]

def active2386 : List Nat := [0,1,3]

def tree2386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2386 : H12WitnessSearch.Good tree2386 := H12GlobalWitnessIndex.good

theorem leafIdentity2386 : H12AffineFastState.composeSystem env2386 rootObs = leafEnv2386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2386 rootObs == leafEnv2386) = true)

theorem terminalChecked2386 : H12PackedTerminal.terminalCheckFast leafEnv2386 active2386 tree2386 = true := by decide +kernel

def env2387 : List Nat := [2,4,8,16,16,1,24,20,22,20,1,0,20,12,29,14,28,17,20,29,16,17,17,19,4,1,0,12,17,16,21,1,20,1,13,22]

theorem envBound2387 : H12AffineFastState.Bounded env2387 := by
  intro p hp
  have h : env2387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2384_2387 : H12AffineEnvironment.transform 5 1 env2384 = env2387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2384 == env2387) = true)

def leafEnv2387 : List Nat := [2,4,8,16,16,1,24,20,22,20,1,0,20,12,29,14,28,17,20,29,16,17,17,19,20,4,1,1,0,12,17,16,21,1,20,1,5,31,13,22,1,17,0]

def active2387 : List Nat := [0,1,2,3]

def tree2387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2387 : H12WitnessSearch.Good tree2387 := H12GlobalWitnessIndex.good

theorem leafIdentity2387 : H12AffineFastState.composeSystem env2387 rootObs = leafEnv2387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2387 rootObs == leafEnv2387) = true)

theorem terminalChecked2387 : H12PackedTerminal.terminalCheckFast leafEnv2387 active2387 tree2387 = true := by decide +kernel

def env2388 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,65,2626,2587,2635,2649,2634,2065,85,2635,16,16,17,18,2643,64,2049,2587,17,2064,84,1,85,1,2586,512]

theorem envBound2388 : H12AffineFastState.Bounded env2388 := by
  intro p hp
  have h : env2388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2376_2388 : H12AffineEnvironment.transform 4 17 env2376 = env2388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2376 == env2388) = true)

def env2389 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,65,578,539,587,601,586,17,85,587,16,16,17,18,595,64,1,539,17,16,84,1,85,1,538,512]

theorem envBound2389 : H12AffineFastState.Bounded env2389 := by
  intro p hp
  have h : env2389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2388_2389 : H12AffineEnvironment.transform 10 0 env2388 = env2389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2388 == env2389) = true)

theorem identity2389 : scanCanonicalize (H12AffineFastState.compose env2389 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2390 : List Nat := [2,4,5,16,17,64,20,85,512,85,0,65,578,534,582,596,583,17,85,582,16,16,17,18,595,64,1,534,17,16,84,1,85,1,535,512]

theorem envBound2390 : H12AffineFastState.Bounded env2390 := by
  intro p hp
  have h : env2390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2389_2390 : H12AffineEnvironment.transform 2 5 env2389 = env2390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2389 == env2390) = true)

def env2391 : List Nat := [2,4,5,16,17,0,20,21,512,21,0,1,514,534,518,532,519,17,21,518,16,16,17,18,531,0,1,534,17,16,20,1,21,1,535,512]

theorem envBound2391 : H12AffineFastState.Bounded env2391 := by
  intro p hp
  have h : env2391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2390_2391 : H12AffineEnvironment.transform 5 0 env2390 = env2391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2390 == env2391) = true)

def leafEnv2391 : List Nat := [2,4,5,16,17,0,20,21,512,21,0,1,514,534,518,532,519,17,21,518,16,16,17,18,21,531,1,0,1,534,17,16,20,1,21,1,5,516,535,512,1,17,0]

def active2391 : List Nat := [0,1,3,8]

def tree2391 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2391 : H12WitnessSearch.Good tree2391 := H12GlobalWitnessIndex.good

theorem leafIdentity2391 : H12AffineFastState.composeSystem env2391 rootObs = leafEnv2391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2391 rootObs == leafEnv2391) = true)

theorem terminalChecked2391 : H12PackedTerminal.terminalCheckFast leafEnv2391 active2391 tree2391 = true := by decide +kernel

def env2392 : List Nat := [2,4,5,16,17,1,20,20,512,20,0,0,515,534,519,533,518,17,20,519,16,16,17,18,530,1,1,534,17,16,21,1,20,1,535,512]

theorem envBound2392 : H12AffineFastState.Bounded env2392 := by
  intro p hp
  have h : env2392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2390_2392 : H12AffineEnvironment.transform 5 1 env2390 = env2392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2390 == env2392) = true)

theorem identity2392 : scanCanonicalize (H12AffineFastState.compose env2392 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2393 : List Nat := [2,4,5,16,17,1,20,20,23,20,0,0,20,1,16,2,17,17,20,16,16,16,17,18,5,1,1,1,17,16,21,1,20,1,0,23]

theorem envBound2393 : H12AffineFastState.Bounded env2393 := by
  intro p hp
  have h : env2393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2392_2393 : H12AffineEnvironment.transform 8 23 env2392 = env2393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2392 == env2393) = true)

def leafEnv2393 : List Nat := [2,4,5,16,17,1,20,20,23,20,0,0,20,1,16,2,17,17,20,16,16,16,17,18,20,5,1,1,1,1,17,16,21,1,20,1,5,18,0,23,1,17,0]

def active2393 : List Nat := [0,1,3]

def tree2393 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2393 : H12WitnessSearch.Good tree2393 := H12GlobalWitnessIndex.good

theorem leafIdentity2393 : H12AffineFastState.composeSystem env2393 rootObs = leafEnv2393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2393 rootObs == leafEnv2393) = true)

theorem terminalChecked2393 : H12PackedTerminal.terminalCheckFast leafEnv2393 active2393 tree2393 = true := by decide +kernel

def env2394 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,65,579,538,586,600,587,16,85,586,16,16,17,18,594,64,0,538,17,17,84,1,85,1,539,512]

theorem envBound2394 : H12AffineFastState.Bounded env2394 := by
  intro p hp
  have h : env2394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2388_2394 : H12AffineEnvironment.transform 10 1 env2388 = env2394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2388 == env2394) = true)

theorem identity2394 : scanCanonicalize (H12AffineFastState.compose env2394 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2394 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2395 : List Nat := [2,4,8,13,12,64,4,72,512,72,1,65,579,519,586,581,587,13,72,586,13,13,12,15,591,64,0,519,12,12,73,1,72,1,518,512]

theorem envBound2395 : H12AffineFastState.Bounded env2395 := by
  intro p hp
  have h : env2395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2394_2395 : H12AffineEnvironment.transform 3 13 env2394 = env2395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2394 == env2395) = true)

def env2396 : List Nat := [2,4,8,13,12,0,4,8,512,8,1,1,515,519,522,517,523,13,8,522,13,13,12,15,527,0,0,519,12,12,9,1,8,1,518,512]

theorem envBound2396 : H12AffineFastState.Bounded env2396 := by
  intro p hp
  have h : env2396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2395_2396 : H12AffineEnvironment.transform 5 0 env2395 = env2396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2395 == env2396) = true)

theorem identity2396 : scanCanonicalize (H12AffineFastState.compose env2396 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2397 : List Nat := [2,4,8,13,12,0,4,8,6,8,1,1,5,1,12,3,13,13,8,12,13,13,12,15,9,0,0,1,12,12,9,1,8,1,0,6]

theorem envBound2397 : H12AffineFastState.Bounded env2397 := by
  intro p hp
  have h : env2397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2396_2397 : H12AffineEnvironment.transform 8 6 env2396 = env2397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2396 == env2397) = true)

def leafEnv2397 : List Nat := [2,4,8,13,12,0,4,8,6,8,1,1,5,1,12,3,13,13,8,12,13,13,12,15,8,9,1,0,0,1,12,12,9,1,8,1,5,14,0,6,1,12,0]

def active2397 : List Nat := [0,1,2]

def tree2397 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2397 : H12WitnessSearch.Good tree2397 := H12GlobalWitnessIndex.good

theorem leafIdentity2397 : H12AffineFastState.composeSystem env2397 rootObs = leafEnv2397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2397 rootObs == leafEnv2397) = true)

theorem terminalChecked2397 : H12PackedTerminal.terminalCheckFast leafEnv2397 active2397 tree2397 = true := by decide +kernel

def env2398 : List Nat := [2,4,8,13,12,1,4,9,512,9,1,0,514,519,523,516,522,13,9,523,13,13,12,15,526,1,0,519,12,12,8,1,9,1,518,512]

theorem envBound2398 : H12AffineFastState.Bounded env2398 := by
  intro p hp
  have h : env2398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2395_2398 : H12AffineEnvironment.transform 5 1 env2395 = env2398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2395 == env2398) = true)

def leafEnv2398 : List Nat := [2,4,8,13,12,1,4,9,512,9,1,0,514,519,523,516,522,13,9,523,13,13,12,15,9,526,1,1,0,519,12,12,8,1,9,1,5,521,518,512,1,12,0]

def active2398 : List Nat := [0,1,2,8]

def tree2398 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2398 : H12WitnessSearch.Good tree2398 := H12GlobalWitnessIndex.good

theorem leafIdentity2398 : H12AffineFastState.composeSystem env2398 rootObs = leafEnv2398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2398 rootObs == leafEnv2398) = true)

theorem terminalChecked2398 : H12PackedTerminal.terminalCheckFast leafEnv2398 active2398 tree2398 = true := by decide +kernel

def env2399 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2081,74882,8201,74951,73891,185,73737,8328,73834,75906,2587,74863,2081,74883,1,73855,1,76441,512]

theorem envBound2399 : H12AffineFastState.Bounded env2399 := by
  intro p hp
  have h : env2399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2371_2399 : H12AffineEnvironment.transform 16 76385 env2371 = env2399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2371 == env2399) = true)

theorem identity2399 : scanCanonicalize (H12AffineFastState.compose env2399 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound2399 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2400 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,224,2587,233,65536,68225,2081,66658,233,66599,65603,185,65769,104,65674,67682,2587,66703,2081,66659,1,65695,1,68217,512]

theorem envBound2400 : H12AffineFastState.Bounded env2400 := by
  intro p hp
  have h : env2400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2399_2400 : H12AffineEnvironment.transform 12 224 env2399 = env2400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env2399 == env2400) = true)

def env2401 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205377,74882,8201,74950,73891,185,73737,8328,73834,131810,2586,134670,2081,74883,1,73855,1,131320,512]

theorem envBound2401 : H12AffineFastState.Bounded env2401 := by
  intro p hp
  have h : env2401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2370_2401 : H12AffineEnvironment.transform 11 1045 env2370 = env2401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env2370 == env2401) = true)

def env2402 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2081,74882,8201,74950,73891,185,73737,8328,73834,75906,2586,74862,2081,74883,1,73855,1,76440,512]

theorem envBound2402 : H12AffineFastState.Bounded env2402 := by
  intro p hp
  have h : env2402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2401_2402 : H12AffineEnvironment.transform 16 76384 env2401 = env2402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2401 == env2402) = true)

theorem identity2402 : scanCanonicalize (H12AffineFastState.compose env2402 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound2402 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2403 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,98,10754,2081,9440,8201,9380,8385,185,8299,8328,8200,10464,2586,9228,2081,9441,1,8221,1,11002,512]

theorem envBound2403 : H12AffineFastState.Bounded env2403 := by
  intro p hp
  have h : env2403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2402_2403 : H12AffineEnvironment.transform 15 98 env2402 = env2403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env2402 == env2403) = true)

def env2404 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2080,74882,8201,74950,73891,185,73737,8328,73834,75907,2586,74863,2081,74883,1,73855,1,76441,512]

theorem envBound2404 : H12AffineFastState.Bounded env2404 := by
  intro p hp
  have h : env2404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2401_2404 : H12AffineEnvironment.transform 16 76385 env2401 = env2404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2401 == env2404) = true)

theorem identity2404 : scanCanonicalize (H12AffineFastState.compose env2404 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2404 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2405 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,65536,66678,2080,68245,3614,68305,69300,185,69150,3743,69245,67220,2586,68216,2081,68244,1,69224,1,66702,512]

theorem envBound2405 : H12AffineFastState.Bounded env2405 := by
  intro p hp
  have h : env2405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2404_2405 : H12AffineEnvironment.transform 12 3607 env2404 = env2405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2404 == env2405) = true)

theorem identity2405 : scanCanonicalize (H12AffineFastState.compose env2405 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2405 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2406 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,3733,2787,2080,1024,3614,1092,33,185,139,3743,232,2049,2586,1261,2081,1025,1,253,1,2587,512]

theorem envBound2406 : H12AffineFastState.Bounded env2406 := by
  intro p hp
  have h : env2406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2405_2406 : H12AffineEnvironment.transform 15 3733 env2405 = env2406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2405 == env2406) = true)

theorem identity2406 : scanCanonicalize (H12AffineFastState.compose env2406 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2406 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2407 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2626,2586,2635,2752,2787,2080,85,2635,17,33,185,139,2762,232,2049,2586,184,2081,84,1,253,1,2587,512]

theorem envBound2407 : H12AffineFastState.Bounded env2407 := by
  intro p hp
  have h : env2407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2406_2407 : H12AffineEnvironment.transform 9 85 env2406 = env2407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2406 == env2407) = true)

theorem identity2407 : scanCanonicalize (H12AffineFastState.compose env2407 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2407 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2408 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,64,2626,2586,2635,2664,2635,2080,85,2635,17,33,17,35,2658,64,2049,2586,16,2081,84,1,85,1,2587,512]

theorem envBound2408 : H12AffineFastState.Bounded env2408 := by
  intro p hp
  have h : env2408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2407_2408 : H12AffineEnvironment.transform 6 40 env2407 = env2408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2407 == env2408) = true)

def env2409 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,64,2626,2586,2635,2648,2635,2064,85,2635,17,17,17,19,2642,64,2049,2586,16,2065,84,1,85,1,2587,512]

theorem envBound2409 : H12AffineFastState.Bounded env2409 := by
  intro p hp
  have h : env2409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2408_2409 : H12AffineEnvironment.transform 4 16 env2408 = env2409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2408 == env2409) = true)

def env2410 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,64,578,538,587,600,587,16,85,587,17,17,17,19,594,64,1,538,16,17,84,1,85,1,539,512]

theorem envBound2410 : H12AffineFastState.Bounded env2410 := by
  intro p hp
  have h : env2410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2409_2410 : H12AffineEnvironment.transform 10 0 env2409 = env2410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2409 == env2410) = true)

theorem identity2410 : scanCanonicalize (H12AffineFastState.compose env2410 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound2410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2411 : List Nat := [2,4,8,16,16,13,24,24,512,24,0,13,527,538,518,533,518,16,24,518,17,17,17,19,543,13,1,538,16,17,25,1,24,1,539,512]

theorem envBound2411 : H12AffineFastState.Bounded env2411 := by
  intro p hp
  have h : env2411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2410_2411 : H12AffineEnvironment.transform 5 13 env2410 = env2411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env2410 == env2411) = true)

def env2412 : List Nat := [2,4,4,16,16,1,20,20,512,20,0,1,515,534,518,533,518,16,20,518,17,17,17,19,531,1,1,534,16,17,21,1,20,1,535,512]

theorem envBound2412 : H12AffineFastState.Bounded env2412 := by
  intro p hp
  have h : env2412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2411_2412 : H12AffineEnvironment.transform 2 4 env2411 = env2412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2411 == env2412) = true)

def leafEnv2412 : List Nat := [2,4,4,16,16,1,20,20,512,20,0,1,515,534,518,533,518,16,20,518,17,17,17,19,20,531,1,1,1,534,16,17,21,1,20,1,5,516,535,512,1,16,0]

def active2412 : List Nat := [0,1,3,8]

def tree2412 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2412 : H12WitnessSearch.Good tree2412 := H12GlobalWitnessIndex.good

theorem leafIdentity2412 : H12AffineFastState.composeSystem env2412 rootObs = leafEnv2412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2412 rootObs == leafEnv2412) = true)

theorem terminalChecked2412 : H12PackedTerminal.terminalCheckFast leafEnv2412 active2412 tree2412 = true := by decide +kernel

def env2413 : List Nat := [2,4,5,16,16,0,21,21,512,21,0,0,514,535,518,533,518,16,21,518,17,17,17,19,530,0,1,535,16,17,20,1,21,1,534,512]

theorem envBound2413 : H12AffineFastState.Bounded env2413 := by
  intro p hp
  have h : env2413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2411_2413 : H12AffineEnvironment.transform 2 5 env2411 = env2413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2411 == env2413) = true)

theorem identity2413 : scanCanonicalize (H12AffineFastState.compose env2413 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound2413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2414 : List Nat := [2,4,5,16,16,0,21,21,22,21,0,0,20,1,16,3,16,16,21,16,17,17,17,19,4,0,1,1,16,17,20,1,21,1,0,22]

theorem envBound2414 : H12AffineFastState.Bounded env2414 := by
  intro p hp
  have h : env2414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2413_2414 : H12AffineEnvironment.transform 8 22 env2413 = env2414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env2413 == env2414) = true)

def leafEnv2414 : List Nat := [2,4,5,16,16,0,21,21,22,21,0,0,20,1,16,3,16,16,21,16,17,17,17,19,21,4,1,0,1,1,16,17,20,1,21,1,5,18,0,22,1,16,0]

def active2414 : List Nat := [0,1,3]

def tree2414 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2414 : H12WitnessSearch.Good tree2414 := H12GlobalWitnessIndex.good

theorem leafIdentity2414 : H12AffineFastState.composeSystem env2414 rootObs = leafEnv2414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2414 rootObs == leafEnv2414) = true)

theorem terminalChecked2414 : H12PackedTerminal.terminalCheckFast leafEnv2414 active2414 tree2414 = true := by decide +kernel

def env2415 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,64,579,539,586,601,586,17,85,586,17,17,17,19,595,64,0,539,16,16,84,1,85,1,538,512]

theorem envBound2415 : H12AffineFastState.Bounded env2415 := by
  intro p hp
  have h : env2415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2409_2415 : H12AffineEnvironment.transform 10 1 env2409 = env2415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2409 == env2415) = true)

theorem identity2415 : scanCanonicalize (H12AffineFastState.compose env2415 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound2415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2416 : List Nat := [2,4,8,16,16,28,24,9,512,9,1,28,543,539,534,517,534,17,9,534,17,17,17,19,527,28,0,539,16,16,8,1,9,1,538,512]

theorem envBound2416 : H12AffineFastState.Bounded env2416 := by
  intro p hp
  have h : env2416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2415_2416 : H12AffineEnvironment.transform 5 28 env2415 = env2416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env2415 == env2416) = true)

def env2417 : List Nat := [2,4,8,12,12,0,4,9,512,9,1,0,515,519,522,517,522,13,9,522,13,13,13,15,527,0,0,519,12,12,8,1,9,1,518,512]

theorem envBound2417 : H12AffineFastState.Bounded env2417 := by
  intro p hp
  have h : env2417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2416_2417 : H12AffineEnvironment.transform 3 12 env2416 = env2417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2416 == env2417) = true)

def leafEnv2417 : List Nat := [2,4,8,12,12,0,4,9,512,9,1,0,515,519,522,517,522,13,9,522,13,13,13,15,9,527,1,0,0,519,12,12,8,1,9,1,5,520,518,512,1,12,0]

def active2417 : List Nat := [0,1,2,8]

def tree2417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2417 : H12WitnessSearch.Good tree2417 := H12GlobalWitnessIndex.good

theorem leafIdentity2417 : H12AffineFastState.composeSystem env2417 rootObs = leafEnv2417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2417 rootObs == leafEnv2417) = true)

theorem terminalChecked2417 : H12PackedTerminal.terminalCheckFast leafEnv2417 active2417 tree2417 = true := by decide +kernel

def env2418 : List Nat := [2,4,8,13,13,1,5,9,512,9,1,1,514,518,523,517,523,12,9,523,12,12,12,14,527,1,0,518,13,13,8,1,9,1,519,512]

theorem envBound2418 : H12AffineFastState.Bounded env2418 := by
  intro p hp
  have h : env2418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2416_2418 : H12AffineEnvironment.transform 3 13 env2416 = env2418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2416 == env2418) = true)

theorem identity2418 : scanCanonicalize (H12AffineFastState.compose env2418 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2419 : List Nat := [2,4,8,13,13,1,5,9,7,9,1,1,5,1,12,2,12,12,9,12,12,12,12,14,8,1,0,1,13,13,8,1,9,1,0,7]

theorem envBound2419 : H12AffineFastState.Bounded env2419 := by
  intro p hp
  have h : env2419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2418_2419 : H12AffineEnvironment.transform 8 7 env2418 = env2419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2418 == env2419) = true)

def leafEnv2419 : List Nat := [2,4,8,13,13,1,5,9,7,9,1,1,5,1,12,2,12,12,9,12,12,12,12,14,9,8,1,1,0,1,13,13,8,1,9,1,5,14,0,7,1,13,0]

def active2419 : List Nat := [0,1,2]

def tree2419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2419 : H12WitnessSearch.Good tree2419 := H12GlobalWitnessIndex.good

theorem leafIdentity2419 : H12AffineFastState.composeSystem env2419 rootObs = leafEnv2419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2419 rootObs == leafEnv2419) = true)

theorem terminalChecked2419 : H12PackedTerminal.terminalCheckFast leafEnv2419 active2419 tree2419 = true := by decide +kernel

def env2420 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,64,2626,2586,2635,2649,2635,2065,85,2635,17,16,17,18,2643,64,2049,2586,16,2064,84,1,85,1,2587,512]

theorem envBound2420 : H12AffineFastState.Bounded env2420 := by
  intro p hp
  have h : env2420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2408_2420 : H12AffineEnvironment.transform 4 17 env2408 = env2420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2408 == env2420) = true)

def env2421 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,64,578,538,587,601,587,17,85,587,17,16,17,18,595,64,1,538,16,16,84,1,85,1,539,512]

theorem envBound2421 : H12AffineFastState.Bounded env2421 := by
  intro p hp
  have h : env2421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2420_2421 : H12AffineEnvironment.transform 10 0 env2420 = env2421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2420 == env2421) = true)

theorem identity2421 : scanCanonicalize (H12AffineFastState.compose env2421 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2422 : List Nat := [2,4,8,16,17,64,25,85,7,85,0,64,69,29,76,94,76,17,85,76,17,16,17,18,84,64,1,29,16,16,84,1,85,1,28,7]

theorem envBound2422 : H12AffineFastState.Bounded env2422 := by
  intro p hp
  have h : env2422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2421_2422 : H12AffineEnvironment.transform 8 7 env2421 = env2422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2421 == env2422) = true)

def env2423 : List Nat := [2,4,8,16,17,0,25,21,7,21,0,0,5,29,12,30,12,17,21,12,17,16,17,18,20,0,1,29,16,16,20,1,21,1,28,7]

theorem envBound2423 : H12AffineFastState.Bounded env2423 := by
  intro p hp
  have h : env2423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2422_2423 : H12AffineEnvironment.transform 5 0 env2422 = env2423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2422 == env2423) = true)

theorem identity2423 : scanCanonicalize (H12AffineFastState.compose env2423 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2424 : List Nat := [2,4,8,13,12,0,4,8,7,8,0,0,5,0,12,3,12,12,8,12,12,13,12,15,9,0,1,0,13,13,9,1,8,1,1,7]

theorem envBound2424 : H12AffineFastState.Bounded env2424 := by
  intro p hp
  have h : env2424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2423_2424 : H12AffineEnvironment.transform 3 13 env2423 = env2424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2423 == env2424) = true)

def leafEnv2424 : List Nat := [2,4,8,13,12,0,4,8,7,8,0,0,5,0,12,3,12,12,8,12,12,13,12,15,8,9,1,0,1,0,13,13,9,1,8,1,5,14,1,7,1,13,0]

def active2424 : List Nat := [0,1,2]

def tree2424 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2424 : H12WitnessSearch.Good tree2424 := H12GlobalWitnessIndex.good

theorem leafIdentity2424 : H12AffineFastState.composeSystem env2424 rootObs = leafEnv2424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2424 rootObs == leafEnv2424) = true)

theorem terminalChecked2424 : H12PackedTerminal.terminalCheckFast leafEnv2424 active2424 tree2424 = true := by decide +kernel

def env2425 : List Nat := [2,4,8,16,17,1,25,20,7,20,0,1,4,29,13,31,13,17,20,13,17,16,17,18,21,1,1,29,16,16,21,1,20,1,28,7]

theorem envBound2425 : H12AffineFastState.Bounded env2425 := by
  intro p hp
  have h : env2425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2422_2425 : H12AffineEnvironment.transform 5 1 env2422 = env2425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2422 == env2425) = true)

def leafEnv2425 : List Nat := [2,4,8,16,17,1,25,20,7,20,0,1,4,29,13,31,13,17,20,13,17,16,17,18,20,21,1,1,1,29,16,16,21,1,20,1,5,15,28,7,1,16,0]

def active2425 : List Nat := [0,1,2,3]

def tree2425 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2425 : H12WitnessSearch.Good tree2425 := H12GlobalWitnessIndex.good

theorem leafIdentity2425 : H12AffineFastState.composeSystem env2425 rootObs = leafEnv2425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2425 rootObs == leafEnv2425) = true)

theorem terminalChecked2425 : H12PackedTerminal.terminalCheckFast leafEnv2425 active2425 tree2425 = true := by decide +kernel

def env2426 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,64,579,539,586,600,586,16,85,586,17,16,17,18,594,64,0,539,16,17,84,1,85,1,538,512]

theorem envBound2426 : H12AffineFastState.Bounded env2426 := by
  intro p hp
  have h : env2426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2420_2426 : H12AffineEnvironment.transform 10 1 env2420 = env2426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2420 == env2426) = true)

theorem identity2426 : scanCanonicalize (H12AffineFastState.compose env2426 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound2426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2427 : List Nat := [2,4,8,16,17,64,25,85,22,85,1,64,85,13,92,78,92,16,85,92,17,16,17,18,68,64,0,13,16,17,84,1,85,1,12,22]

theorem envBound2427 : H12AffineFastState.Bounded env2427 := by
  intro p hp
  have h : env2427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2426_2427 : H12AffineEnvironment.transform 8 22 env2426 = env2427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env2426 == env2427) = true)

def env2428 : List Nat := [2,4,8,16,17,0,25,21,22,21,1,0,21,13,28,14,28,16,21,28,17,16,17,18,4,0,0,13,16,17,20,1,21,1,12,22]

theorem envBound2428 : H12AffineFastState.Bounded env2428 := by
  intro p hp
  have h : env2428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2427_2428 : H12AffineEnvironment.transform 5 0 env2427 = env2428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2427 == env2428) = true)

def leafEnv2428 : List Nat := [2,4,8,16,17,0,25,21,22,21,1,0,21,13,28,14,28,16,21,28,17,16,17,18,21,4,1,0,0,13,16,17,20,1,21,1,5,30,12,22,1,16,0]

def active2428 : List Nat := [0,1,2,3]

def tree2428 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2428 : H12WitnessSearch.Good tree2428 := H12GlobalWitnessIndex.good

theorem leafIdentity2428 : H12AffineFastState.composeSystem env2428 rootObs = leafEnv2428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2428 rootObs == leafEnv2428) = true)

theorem terminalChecked2428 : H12PackedTerminal.terminalCheckFast leafEnv2428 active2428 tree2428 = true := by decide +kernel

def env2429 : List Nat := [2,4,8,16,17,1,25,20,22,20,1,1,20,13,29,15,29,16,20,29,17,16,17,18,5,1,0,13,16,17,21,1,20,1,12,22]

theorem envBound2429 : H12AffineFastState.Bounded env2429 := by
  intro p hp
  have h : env2429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2427_2429 : H12AffineEnvironment.transform 5 1 env2427 = env2429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2427 == env2429) = true)

theorem identity2429 : scanCanonicalize (H12AffineFastState.compose env2429 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2430 : List Nat := [2,4,5,16,17,1,20,20,22,20,1,1,20,0,16,2,16,16,20,16,17,16,17,18,5,1,0,0,16,17,21,1,20,1,1,22]

theorem envBound2430 : H12AffineFastState.Bounded env2430 := by
  intro p hp
  have h : env2430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2429_2430 : H12AffineEnvironment.transform 2 5 env2429 = env2430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2429 == env2430) = true)

def leafEnv2430 : List Nat := [2,4,5,16,17,1,20,20,22,20,1,1,20,0,16,2,16,16,20,16,17,16,17,18,20,5,1,1,0,0,16,17,21,1,20,1,5,18,1,22,1,16,0]

def active2430 : List Nat := [0,1,3]

def tree2430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2430 : H12WitnessSearch.Good tree2430 := H12GlobalWitnessIndex.good

theorem leafIdentity2430 : H12AffineFastState.composeSystem env2430 rootObs = leafEnv2430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2430 rootObs == leafEnv2430) = true)

theorem terminalChecked2430 : H12PackedTerminal.terminalCheckFast leafEnv2430 active2430 tree2430 = true := by decide +kernel

def env2431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2081,17375732,13108376,525568,1,34359738368,25691699]

theorem envBound2431 : H12AffineFastState.Bounded env2431 := by
  intro p hp
  have h : env2431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2347_2431 : H12AffineEnvironment.transform 14 8693 env2347 = env2431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env2347 == env2431) = true)

def env2432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672785,935128,16384,151553,2081,17375732,4867288,525568,1,34359738368,17450611]

theorem envBound2432 : H12AffineFastState.Bounded env2432 := by
  intro p hp
  have h : env2432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2431_2432 : H12AffineEnvironment.transform 22 147520 env2431 = env2432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env2431 == env2432) = true)

def env2433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,34359738368,16925299]

theorem envBound2433 : H12AffineFastState.Bounded env2433 := by
  intro p hp
  have h : env2433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2432_2433 : H12AffineEnvironment.transform 18 1024 env2432 = env2433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2432 == env2433) = true)

def env2434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,131072,16925299]

theorem envBound2434 : H12AffineFastState.Bounded env2434 := by
  intro p hp
  have h : env2434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2433_2434 : H12AffineEnvironment.transform 34 131072 env2433 = env2434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2433 == env2434) = true)

theorem identity2434 : scanCanonicalize (H12AffineFastState.compose env2434 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 148851) := by decide +kernel

theorem selectedBound2434 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,148851,8328,147473,409816,16384,151553,2081,221319,4341976,256,1,131072,1792]

theorem envBound2435 : H12AffineFastState.Bounded env2435 := by
  intro p hp
  have h : env2435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2434_2435 : H12AffineEnvironment.transform 23 148851 env2434 = env2435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 148851 env2434 == env2435) = true)

theorem identity2435 : scanCanonicalize (H12AffineFastState.compose env2435 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 222374) := by decide +kernel

theorem selectedBound2435 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,222374,147520,148851,8328,147473,409816,16384,151553,2081,221319,74878,256,1,131072,1792]

theorem envBound2436 : H12AffineFastState.Bounded env2436 := by
  intro p hp
  have h : env2436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2435_2436 : H12AffineEnvironment.transform 21 222374 env2435 = env2436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 222374 env2435 == env2436) = true)

theorem identity2436 : scanCanonicalize (H12AffineFastState.compose env2436 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound2436 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2437 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,131072,262144,256,8693,2097152,221606,147520,147571,8328,147473,409816,16384,151553,2081,221319,74110,256,1,131072,512]

theorem envBound2437 : H12AffineFastState.Bounded env2437 := by
  intro p hp
  have h : env2437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2436_2437 : H12AffineEnvironment.transform 9 256 env2436 = env2437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env2436 == env2437) = true)

theorem identity2437 : scanCanonicalize (H12AffineFastState.compose env2437 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90503) := by decide +kernel

theorem selectedBound2437 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2438 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,90503,262144,256,8693,2097152,33,74183,74228,8328,74134,336223,16384,78214,2081,256,74110,256,1,90503,512]

theorem envBound2438 : H12AffineFastState.Bounded env2438 := by
  intro p hp
  have h : env2438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2437_2438 : H12AffineEnvironment.transform 16 90503 env2437 = env2438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90503 env2437 == env2438) = true)

theorem identity2438 : scanCanonicalize (H12AffineFastState.compose env2438 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2438 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2439 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,8574,16633,262144,256,8693,2097152,33,185,138,8328,232,262177,16384,4344,2081,256,0,256,1,16633,512]

end H12CloudChart0