import H12CloudChart0Data032

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound8186 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8187 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8201,8234,4096,262144,4268,8201,544,136,4281,35,8329,4640,262280,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8187 : H12AffineFastState.Bounded env8187 := by
  intro p hp
  have h : env8187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8186_8187 : H12AffineEnvironment.transform 18 4268 env8186 = env8187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4268 env8186 == env8187) = true)

theorem identity8187 : scanCanonicalize (H12AffineFastState.compose env8187 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14545) := by decide +kernel

theorem selectedBound8187 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8188 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8201,8234,4096,14545,4268,8201,544,136,4281,35,8329,4640,14425,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8188 : H12AffineFastState.Bounded env8188 := by
  intro p hp
  have h : env8188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8187_8188 : H12AffineEnvironment.transform 17 14545 env8187 = env8188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14545 env8187 == env8188) = true)

theorem identity8188 : scanCanonicalize (H12AffineFastState.compose env8188 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6907) := by decide +kernel

theorem selectedBound8188 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8189 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,6907,17,6898,6865,4096,554,4268,6898,544,136,4281,35,6770,4640,674,4264,4265,2081,717,0,4180,1,4161,512]

theorem envBound8189 : H12AffineFastState.Bounded env8189 := by
  intro p hp
  have h : env8189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8188_8189 : H12AffineEnvironment.transform 12 6907 env8188 = env8189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6907 env8188 == env8189) = true)

theorem identity8189 : scanCanonicalize (H12AffineFastState.compose env8189 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8189 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env8190 : List Nat := [2,4,8,16,32,64,128,253,96,5,2048,4096,6299,17,6290,6321,4096,74,4268,6290,64,136,4281,35,6162,4160,194,4264,4265,2081,173,0,4180,1,4161,96]

theorem envBound8190 : H12AffineFastState.Bounded env8190 := by
  intro p hp
  have h : env8190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8189_8190 : H12AffineEnvironment.transform 8 96 env8189 = env8190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8189 == env8190) = true)

theorem identity8190 : scanCanonicalize (H12AffineFastState.compose env8190 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound8190 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8191 : List Nat := [2,4,8,16,32,64,128,253,96,5,27,4096,4224,17,4233,4266,4096,74,4268,4233,64,136,4281,35,4105,4160,194,4264,4265,58,173,0,4180,1,4161,96]

theorem envBound8191 : H12AffineFastState.Bounded env8191 := by
  intro p hp
  have h : env8191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8190_8191 : H12AffineEnvironment.transform 10 27 env8190 = env8191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env8190 == env8191) = true)

theorem identity8191 : scanCanonicalize (H12AffineFastState.compose env8191 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound8191 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8192 : List Nat := [2,4,8,16,32,64,128,253,96,5,27,81,209,17,216,251,81,74,253,216,64,136,232,35,88,17,194,249,248,58,173,0,5,1,16,96]

theorem envBound8192 : H12AffineFastState.Bounded env8192 := by
  intro p hp
  have h : env8192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8191_8192 : H12AffineEnvironment.transform 11 81 env8191 = env8192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env8191 == env8192) = true)

theorem identity8192 : scanCanonicalize (H12AffineFastState.compose env8192 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8192 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8193 : List Nat := [2,4,8,16,32,64,40,85,96,5,27,81,121,17,112,83,81,74,85,112,64,32,64,35,88,17,106,81,80,58,5,0,5,1,16,96]

theorem envBound8193 : H12AffineFastState.Bounded env8193 := by
  intro p hp
  have h : env8193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8192_8193 : H12AffineEnvironment.transform 6 40 env8192 = env8193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8192 == env8193) = true)

theorem identity8193 : scanCanonicalize (H12AffineFastState.compose env8193 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8194 : List Nat := [2,4,8,16,27,64,19,85,91,5,27,81,66,17,75,83,81,74,85,75,64,27,64,24,88,17,81,81,80,1,5,0,5,1,16,91]

theorem envBound8194 : H12AffineFastState.Bounded env8194 := by
  intro p hp
  have h : env8194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8193_8194 : H12AffineEnvironment.transform 4 27 env8193 = env8194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8193 == env8194) = true)

theorem identity8194 : scanCanonicalize (H12AffineFastState.compose env8194 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8194 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8195 : List Nat := [2,4,8,16,27,0,19,21,27,5,27,17,2,17,11,19,17,10,21,11,0,27,0,24,24,17,17,17,16,1,5,0,5,1,16,27]

theorem envBound8195 : H12AffineFastState.Bounded env8195 := by
  intro p hp
  have h : env8195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8194_8195 : H12AffineEnvironment.transform 5 0 env8194 = env8195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8194 == env8195) = true)

theorem identity8195 : scanCanonicalize (H12AffineFastState.compose env8195 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8195 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8196 : List Nat := [2,4,3,16,16,0,19,21,16,5,16,17,2,17,0,19,17,1,21,0,0,16,0,19,19,17,17,17,16,1,5,0,5,1,16,16]

theorem envBound8196 : H12AffineFastState.Bounded env8196 := by
  intro p hp
  have h : env8196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8195_8196 : H12AffineEnvironment.transform 2 3 env8195 = env8196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8195 == env8196) = true)

def leafEnv8196 : List Nat := [2,4,3,16,16,0,19,21,16,5,16,17,2,17,0,19,17,1,21,0,0,16,0,19,21,19,1,17,17,17,16,1,5,0,5,1,20,3,16,16,1,0,0]

def active8196 : List Nat := [0,1,3]

def tree8196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8196 : H12WitnessSearch.Good tree8196 := H12GlobalWitnessIndex.good

theorem leafIdentity8196 : H12AffineFastState.composeSystem env8196 rootObs = leafEnv8196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8196 rootObs == leafEnv8196) = true)

theorem terminalChecked8196 : H12PackedTerminal.terminalCheckFast leafEnv8196 active8196 tree8196 = true := by decide +kernel

def env8197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,91617,8329,79375,279905,5293,5457,75786,619430,90170,525568,73770,2118541,91711]

theorem envBound8197 : H12AffineFastState.Bounded env8197 := by
  intro p hp
  have h : env8197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8162_8197 : H12AffineEnvironment.transform 23 91617 env8162 = env8197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env8162 == env8197) = true)

theorem identity8197 : scanCanonicalize (H12AffineFastState.compose env8197 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8197 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8198 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91164,8329,79375,279708,5293,5292,75786,619099,90170,525565,73770,2118256,91711]

theorem envBound8198 : H12AffineFastState.Bounded env8198 := by
  intro p hp
  have h : env8198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8197_8198 : H12AffineEnvironment.transform 7 253 env8197 = env8198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8197 == env8198) = true)

def env8199 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91164,8329,78959,279708,5293,5292,75786,618555,90170,525565,73770,2117648,91231]

theorem envBound8199 : H12AffineFastState.Bounded env8199 := by
  intro p hp
  have h : env8199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8198_8199 : H12AffineEnvironment.transform 8 96 env8198 = env8199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8198 == env8199) = true)

theorem identity8199 : scanCanonicalize (H12AffineFastState.compose env8199 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9262) := by decide +kernel

theorem selectedBound8199 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8200 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9262,4096,262144,524288,8201,2097152,16537,525328,16434,8329,4161,279708,5293,5292,3108,545813,17428,525565,1028,2117648,16497]

theorem envBound8200 : H12AffineFastState.Bounded env8200 := by
  intro p hp
  have h : env8200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8199_8200 : H12AffineEnvironment.transform 15 9262 env8199 = env8200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9262 env8199 == env8200) = true)

theorem identity8200 : scanCanonicalize (H12AffineFastState.compose env8200 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545020) := by decide +kernel

theorem selectedBound8200 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8201 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9262,4096,262144,524288,8201,545020,16537,525328,16434,8329,4161,279708,5293,5292,3108,545813,17428,525565,1028,524524,16497]

theorem envBound8201 : H12AffineFastState.Bounded env8201 := by
  intro p hp
  have h : env8201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8200_8201 : H12AffineEnvironment.transform 20 545020 env8200 = env8201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545020 env8200 == env8201) = true)

theorem identity8201 : scanCanonicalize (H12AffineFastState.compose env8201 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282654) := by decide +kernel

theorem selectedBound8201 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env8202 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9262,4096,262144,282654,8201,262370,16537,283662,16434,8329,4161,279708,5293,5292,3108,263179,17428,283875,1028,282866,16497]

theorem envBound8202 : H12AffineFastState.Bounded env8202 := by
  intro p hp
  have h : env8202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8201_8202 : H12AffineEnvironment.transform 18 282654 env8201 = env8202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282654 env8201 == env8202) = true)

theorem identity8202 : scanCanonicalize (H12AffineFastState.compose env8202 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17590) := by decide +kernel

theorem selectedBound8202 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8203 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9262,4096,17590,5288,8201,17492,16537,4280,16434,8329,4161,42,5293,5292,3108,16573,17428,4181,1028,5188,16497]

theorem envBound8203 : H12AffineFastState.Bounded env8203 := by
  intro p hp
  have h : env8203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8202_8203 : H12AffineEnvironment.transform 17 17590 env8202 = env8203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17590 env8202 == env8203) = true)

theorem identity8203 : scanCanonicalize (H12AffineFastState.compose env8203 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8203 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8204 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8201,9262,4096,1190,5288,8201,1092,137,4280,34,8329,4161,42,5293,5292,3108,173,1028,4181,1028,5188,97]

theorem envBound8204 : H12AffineFastState.Bounded env8204 := by
  intro p hp
  have h : env8204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8203_8204 : H12AffineEnvironment.transform 13 16 env8203 = env8204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8203 == env8204) = true)

def env8205 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16537,525328,91164,8329,78958,279708,5293,5292,75786,618554,90170,525565,73770,2117649,91230]

theorem envBound8205 : H12AffineFastState.Bounded env8205 := by
  intro p hp
  have h : env8205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8198_8205 : H12AffineEnvironment.transform 8 97 env8198 = env8205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8198 == env8205) = true)

theorem identity8205 : scanCanonicalize (H12AffineFastState.compose env8205 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound8205 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8206 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,25663,4096,262144,524288,8201,2097152,16537,525328,35,8329,20561,279708,5293,5292,19509,529413,1029,525565,17429,2117649,97]

theorem envBound8206 : H12AffineFastState.Bounded env8206 := by
  intro p hp
  have h : env8206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8205_8206 : H12AffineEnvironment.transform 15 25663 env8205 = env8206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env8205 == env8206) = true)

theorem identity8206 : scanCanonicalize (H12AffineFastState.compose env8206 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8206 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8207 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8201,9263,4096,262144,524288,8201,2097152,137,525328,35,8329,4161,263308,5293,5292,3109,529413,1029,525565,1029,2101249,97]

theorem envBound8207 : H12AffineFastState.Bounded env8207 := by
  intro p hp
  have h : env8207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8206_8207 : H12AffineEnvironment.transform 13 16 env8206 = env8207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8206 == env8207) = true)

theorem identity8207 : scanCanonicalize (H12AffineFastState.compose env8207 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound8207 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8208 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8201,9263,4096,262144,524288,8201,529640,137,525328,35,8329,4161,263308,5293,5292,3109,529413,1029,525565,1029,525545,97]

theorem envBound8208 : H12AffineFastState.Bounded env8208 := by
  intro p hp
  have h : env8208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8207_8208 : H12AffineEnvironment.transform 20 529640 env8207 = env8208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env8207 == env8208) = true)

theorem identity8208 : scanCanonicalize (H12AffineFastState.compose env8208 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13472) := by decide +kernel

theorem selectedBound8208 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8209 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8201,9263,4096,262144,13472,8201,8264,137,12464,35,8329,4161,263308,5293,5292,3109,8357,1029,12381,1029,12361,97]

theorem envBound8209 : H12AffineFastState.Bounded env8209 := by
  intro p hp
  have h : env8209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8208_8209 : H12AffineEnvironment.transform 18 13472 env8208 = env8209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13472 env8208 == env8209) = true)

theorem identity8209 : scanCanonicalize (H12AffineFastState.compose env8209 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9287) := by decide +kernel

theorem selectedBound8209 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8210 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8201,9263,4096,9287,13472,8201,8264,137,12464,35,8329,4161,8395,5293,5292,3109,8357,1029,12381,1029,12361,97]

theorem envBound8210 : H12AffineFastState.Bounded env8210 := by
  intro p hp
  have h : env8210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8209_8210 : H12AffineEnvironment.transform 17 9287 env8209 = env8210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9287 env8209 == env8210) = true)

theorem identity8210 : scanCanonicalize (H12AffineFastState.compose env8210 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8210 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env8211 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8,16,1,1063,4096,1103,5288,1,64,137,4280,35,129,4161,195,5293,5292,3109,173,1029,4181,1029,4161,97]

theorem envBound8211 : H12AffineFastState.Bounded env8211 := by
  intro p hp
  have h : env8211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8210_8211 : H12AffineEnvironment.transform 12 8 env8210 = env8211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8210 == env8211) = true)

theorem identity8211 : scanCanonicalize (H12AffineFastState.compose env8211 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8211 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8212 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,4096,8,16,1,1063,4096,1103,5120,1,64,33,4112,35,41,4161,107,5125,5124,3109,5,1029,4181,1029,4161,97]

theorem envBound8212 : H12AffineFastState.Bounded env8212 := by
  intro p hp
  have h : env8212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8211_8212 : H12AffineEnvironment.transform 6 40 env8211 = env8212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8211 == env8212) = true)

theorem identity8212 : scanCanonicalize (H12AffineFastState.compose env8212 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound8212 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env8213 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,1109,8,16,1,1063,1109,1103,85,1,64,33,1093,35,41,1044,107,80,81,3109,5,1029,1024,1029,1044,97]

theorem envBound8213 : H12AffineFastState.Bounded env8213 := by
  intro p hp
  have h : env8213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8212_8213 : H12AffineEnvironment.transform 11 1109 env8212 = env8213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env8212 == env8213) = true)

def env8214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79375,134217728,134500813,134500401,151259274,17307207,151273659,525568,151257258,136582892,16778206]

theorem envBound8214 : H12AffineFastState.Bounded env8214 := by
  intro p hp
  have h : env8214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8108_8214 : H12AffineEnvironment.transform 21 16741 env8108 = env8214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16741 env8108 == env8214) = true)

def env8215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79375,279904,5293,5457,16797162,17307207,16778715,525568,16795082,2118540,16778206]

theorem envBound8215 : H12AffineFastState.Bounded env8215 := by
  intro p hp
  have h : env8215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8214_8215 : H12AffineEnvironment.transform 26 279904 env8214 = env8215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279904 env8214 == env8215) = true)

def env8216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,91616,8329,79375,279904,5293,5457,75786,619431,90171,525568,73770,2118540,91710]

theorem envBound8216 : H12AffineFastState.Bounded env8216 := by
  intro p hp
  have h : env8216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8215_8216 : H12AffineEnvironment.transform 23 91616 env8215 = env8216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env8215 == env8216) = true)

theorem identity8216 : scanCanonicalize (H12AffineFastState.compose env8216 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8216 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8217 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91165,8329,79375,279709,5293,5292,75786,619098,90171,525565,73770,2118257,91710]

theorem envBound8217 : H12AffineFastState.Bounded env8217 := by
  intro p hp
  have h : env8217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8216_8217 : H12AffineEnvironment.transform 7 253 env8216 = env8217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8216 == env8217) = true)

def env8218 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91165,8329,78959,279709,5293,5292,75786,618554,90171,525565,73770,2117649,91230]

theorem envBound8218 : H12AffineFastState.Bounded env8218 := by
  intro p hp
  have h : env8218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8217_8218 : H12AffineEnvironment.transform 8 96 env8217 = env8218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8217 == env8218) = true)

theorem identity8218 : scanCanonicalize (H12AffineFastState.compose env8218 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound8218 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8219 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,25662,4096,262144,524288,8201,2097152,16536,525328,35,8329,20561,279709,5293,5292,19508,529412,1029,525565,17428,2117649,96]

theorem envBound8219 : H12AffineFastState.Bounded env8219 := by
  intro p hp
  have h : env8219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8218_8219 : H12AffineEnvironment.transform 15 25662 env8218 = env8219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env8218 == env8219) = true)

theorem identity8219 : scanCanonicalize (H12AffineFastState.compose env8219 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8219 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8220 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8201,9263,4096,262144,524288,8201,2097152,137,525328,35,8329,4160,263308,5293,5292,3109,529412,1029,525565,1029,2101248,96]

theorem envBound8220 : H12AffineFastState.Bounded env8220 := by
  intro p hp
  have h : env8220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8219_8220 : H12AffineEnvironment.transform 13 17 env8219 = env8220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8219 == env8220) = true)

theorem identity8220 : scanCanonicalize (H12AffineFastState.compose env8220 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound8220 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8221 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8201,9263,4096,262144,524288,8201,529640,137,525328,35,8329,4160,263308,5293,5292,3109,529412,1029,525565,1029,525544,96]

theorem envBound8221 : H12AffineFastState.Bounded env8221 := by
  intro p hp
  have h : env8221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8220_8221 : H12AffineEnvironment.transform 20 529640 env8220 = env8221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env8220 == env8221) = true)

theorem identity8221 : scanCanonicalize (H12AffineFastState.compose env8221 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13473) := by decide +kernel

theorem selectedBound8221 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8222 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8201,9263,4096,262144,13473,8201,8265,137,12465,35,8329,4160,263308,5293,5292,3109,8357,1029,12380,1029,12361,96]

theorem envBound8222 : H12AffineFastState.Bounded env8222 := by
  intro p hp
  have h : env8222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8221_8222 : H12AffineEnvironment.transform 18 13473 env8221 = env8222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13473 env8221 == env8222) = true)

theorem identity8222 : scanCanonicalize (H12AffineFastState.compose env8222 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9286) := by decide +kernel

theorem selectedBound8222 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8223 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8201,9263,4096,9286,13473,8201,8265,137,12465,35,8329,4160,8394,5293,5292,3109,8357,1029,12380,1029,12361,96]

theorem envBound8223 : H12AffineFastState.Bounded env8223 := by
  intro p hp
  have h : env8223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8222_8223 : H12AffineEnvironment.transform 17 9286 env8222 = env8223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9286 env8222 == env8223) = true)

theorem identity8223 : scanCanonicalize (H12AffineFastState.compose env8223 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8223 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env8224 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8,17,1,1063,4096,1102,5289,1,65,137,4281,35,129,4160,194,5293,5292,3109,173,1029,4180,1029,4161,96]

theorem envBound8224 : H12AffineFastState.Bounded env8224 := by
  intro p hp
  have h : env8224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8223_8224 : H12AffineEnvironment.transform 12 8 env8223 = env8224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8223 == env8224) = true)

theorem identity8224 : scanCanonicalize (H12AffineFastState.compose env8224 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8224 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8225 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,4096,8,17,1,1063,4096,1102,5121,1,65,33,4113,35,41,4160,106,5125,5124,3109,5,1029,4180,1029,4161,96]

theorem envBound8225 : H12AffineFastState.Bounded env8225 := by
  intro p hp
  have h : env8225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8224_8225 : H12AffineEnvironment.transform 6 40 env8224 = env8225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8224 == env8225) = true)

theorem identity8225 : scanCanonicalize (H12AffineFastState.compose env8225 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8225 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env8226 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,1108,8,17,1,1063,1108,1102,85,1,65,33,1093,35,41,1044,106,81,80,3109,5,1029,1024,1029,1045,96]

theorem envBound8226 : H12AffineFastState.Bounded env8226 := by
  intro p hp
  have h : env8226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8225_8226 : H12AffineEnvironment.transform 11 1108 env8225 = env8226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8225 == env8226) = true)

def env8227 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91165,8329,78958,279709,5293,5292,75786,618555,90171,525565,73770,2117648,91231]

theorem envBound8227 : H12AffineFastState.Bounded env8227 := by
  intro p hp
  have h : env8227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8217_8227 : H12AffineEnvironment.transform 8 97 env8217 = env8227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8217 == env8227) = true)

theorem identity8227 : scanCanonicalize (H12AffineFastState.compose env8227 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9262) := by decide +kernel

theorem selectedBound8227 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8228 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9262,4096,262144,524288,8201,2097152,16536,525328,16435,8329,4160,279709,5293,5292,3108,545813,17429,525565,1028,2117648,16497]

theorem envBound8228 : H12AffineFastState.Bounded env8228 := by
  intro p hp
  have h : env8228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8227_8228 : H12AffineEnvironment.transform 15 9262 env8227 = env8228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9262 env8227 == env8228) = true)

theorem identity8228 : scanCanonicalize (H12AffineFastState.compose env8228 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545021) := by decide +kernel

theorem selectedBound8228 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8229 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9262,4096,262144,524288,8201,545021,16536,525328,16435,8329,4160,279709,5293,5292,3108,545813,17429,525565,1028,524525,16497]

theorem envBound8229 : H12AffineFastState.Bounded env8229 := by
  intro p hp
  have h : env8229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8228_8229 : H12AffineEnvironment.transform 20 545021 env8228 = env8229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545021 env8228 == env8229) = true)

theorem identity8229 : scanCanonicalize (H12AffineFastState.compose env8229 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282655) := by decide +kernel

theorem selectedBound8229 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env8230 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9262,4096,262144,282655,8201,262370,16536,283663,16435,8329,4160,279709,5293,5292,3108,263178,17429,283874,1028,282866,16497]

theorem envBound8230 : H12AffineFastState.Bounded env8230 := by
  intro p hp
  have h : env8230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8229_8230 : H12AffineEnvironment.transform 18 282655 env8229 = env8230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282655 env8229 == env8230) = true)

theorem identity8230 : scanCanonicalize (H12AffineFastState.compose env8230 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17590) := by decide +kernel

theorem selectedBound8230 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8231 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,9262,4096,17590,5289,8201,17492,16536,4281,16435,8329,4160,43,5293,5292,3108,16572,17429,4180,1028,5188,16497]

theorem envBound8231 : H12AffineFastState.Bounded env8231 := by
  intro p hp
  have h : env8231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8230_8231 : H12AffineEnvironment.transform 17 17590 env8230 = env8231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17590 env8230 == env8231) = true)

theorem identity8231 : scanCanonicalize (H12AffineFastState.compose env8231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8232 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8201,9262,4096,1191,5289,8201,1093,137,4281,34,8329,4160,43,5293,5292,3108,173,1028,4180,1028,5188,96]

theorem envBound8232 : H12AffineFastState.Bounded env8232 := by
  intro p hp
  have h : env8232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8231_8232 : H12AffineEnvironment.transform 13 17 env8231 = env8232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8231 == env8232) = true)

def env8233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,91617,8329,79375,279904,5293,5457,75787,619430,90170,525568,73771,2118540,91711]

theorem envBound8233 : H12AffineFastState.Bounded env8233 := by
  intro p hp
  have h : env8233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8215_8233 : H12AffineEnvironment.transform 23 91617 env8215 = env8233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env8215 == env8233) = true)

theorem identity8233 : scanCanonicalize (H12AffineFastState.compose env8233 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26050) := by decide +kernel

theorem selectedBound8233 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,2097152,16741,525805,35,8329,21453,279904,5293,5457,19913,530020,1528,525568,17897,2118540,1021]

theorem envBound8234 : H12AffineFastState.Bounded env8234 := by
  intro p hp
  have h : env8234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8233_8234 : H12AffineEnvironment.transform 15 26050 env8233 = env8234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26050 env8233 == env8234) = true)

def env8235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,529264,16741,525805,35,8329,21453,279904,5293,5457,19913,530020,1528,525568,17897,540924,1021]

theorem envBound8235 : H12AffineFastState.Bounded env8235 := by
  intro p hp
  have h : env8235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8234_8235 : H12AffineEnvironment.transform 20 529264 env8234 = env8235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env8234 == env8235) = true)

theorem identity8235 : scanCanonicalize (H12AffineFastState.compose env8235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8236 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,25663,4096,262144,524288,8201,529037,16536,525328,35,8329,21040,279709,5293,5292,19508,530020,1029,525565,17428,540924,512]

theorem envBound8236 : H12AffineFastState.Bounded env8236 := by
  intro p hp
  have h : env8236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8235_8236 : H12AffineEnvironment.transform 7 253 env8235 = env8236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8235 == env8236) = true)

theorem identity8236 : scanCanonicalize (H12AffineFastState.compose env8236 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8236 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8237 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16,8201,9263,4096,262144,524288,8201,529037,136,525328,35,8329,4640,263309,5293,5292,3108,530020,1029,525565,1028,524524,512]

theorem envBound8237 : H12AffineFastState.Bounded env8237 := by
  intro p hp
  have h : env8237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8236_8237 : H12AffineEnvironment.transform 13 16 env8236 = env8237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8236 == env8237) = true)

theorem identity8237 : scanCanonicalize (H12AffineFastState.compose env8237 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8237 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8238 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8201,8234,4096,262144,524288,8201,529037,136,524309,35,8329,4640,262280,4264,4265,2081,528993,0,524536,1,524524,512]

theorem envBound8238 : H12AffineFastState.Bounded env8238 := by
  intro p hp
  have h : env8238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8237_8238 : H12AffineEnvironment.transform 9 5 env8237 = env8238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8237 == env8238) = true)

theorem identity8238 : scanCanonicalize (H12AffineFastState.compose env8238 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4269) := by decide +kernel

theorem selectedBound8238 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8239 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8201,8234,4096,262144,4269,8201,544,136,4280,35,8329,4640,262280,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8239 : H12AffineFastState.Bounded env8239 := by
  intro p hp
  have h : env8239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8238_8239 : H12AffineEnvironment.transform 18 4269 env8238 = env8239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4269 env8238 == env8239) = true)

theorem identity8239 : scanCanonicalize (H12AffineFastState.compose env8239 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14544) := by decide +kernel

theorem selectedBound8239 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8240 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8201,8234,4096,14544,4269,8201,544,136,4280,35,8329,4640,14424,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8240 : H12AffineFastState.Bounded env8240 := by
  intro p hp
  have h : env8240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8239_8240 : H12AffineEnvironment.transform 17 14544 env8239 = env8240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14544 env8239 == env8240) = true)

theorem identity8240 : scanCanonicalize (H12AffineFastState.compose env8240 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6906) := by decide +kernel

theorem selectedBound8240 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8241 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,6906,16,6899,6864,4096,554,4269,6899,544,136,4280,35,6771,4640,674,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8241 : H12AffineFastState.Bounded env8241 := by
  intro p hp
  have h : env8241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8240_8241 : H12AffineEnvironment.transform 12 6906 env8240 = env8241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6906 env8240 == env8241) = true)

theorem identity8241 : scanCanonicalize (H12AffineFastState.compose env8241 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound8241 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env8242 : List Nat := [2,4,8,16,32,64,128,253,97,5,2048,4096,6299,16,6290,6321,4096,75,4269,6290,65,136,4280,35,6162,4161,195,4264,4265,2081,173,0,4181,1,4161,97]

theorem envBound8242 : H12AffineFastState.Bounded env8242 := by
  intro p hp
  have h : env8242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8241_8242 : H12AffineEnvironment.transform 8 97 env8241 = env8242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8241 == env8242) = true)

theorem identity8242 : scanCanonicalize (H12AffineFastState.compose env8242 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound8242 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8243 : List Nat := [2,4,8,16,32,64,128,253,97,5,26,4096,4225,16,4232,4267,4096,75,4269,4232,65,136,4280,35,4104,4161,195,4264,4265,59,173,0,4181,1,4161,97]

theorem envBound8243 : H12AffineFastState.Bounded env8243 := by
  intro p hp
  have h : env8243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8242_8243 : H12AffineEnvironment.transform 10 26 env8242 = env8243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env8242 == env8243) = true)

theorem identity8243 : scanCanonicalize (H12AffineFastState.compose env8243 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound8243 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8244 : List Nat := [2,4,8,16,32,64,128,253,97,5,26,80,209,16,216,251,80,75,253,216,65,136,232,35,88,17,195,248,249,59,173,0,5,1,17,97]

theorem envBound8244 : H12AffineFastState.Bounded env8244 := by
  intro p hp
  have h : env8244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8243_8244 : H12AffineEnvironment.transform 11 80 env8243 = env8244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env8243 == env8244) = true)

theorem identity8244 : scanCanonicalize (H12AffineFastState.compose env8244 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8244 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8245 : List Nat := [2,4,8,16,32,64,88,37,97,5,26,80,9,16,0,35,80,75,37,0,65,80,48,35,88,17,27,32,33,59,117,0,5,1,17,97]

theorem envBound8245 : H12AffineFastState.Bounded env8245 := by
  intro p hp
  have h : env8245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8244_8245 : H12AffineEnvironment.transform 6 88 env8244 = env8245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8244 == env8245) = true)

theorem identity8245 : scanCanonicalize (H12AffineFastState.compose env8245 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8245 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env8246 : List Nat := [2,4,8,16,32,48,40,37,17,5,26,32,9,16,0,35,32,59,37,0,49,32,48,35,40,17,27,32,33,59,5,0,5,1,17,17]

theorem envBound8246 : H12AffineFastState.Bounded env8246 := by
  intro p hp
  have h : env8246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8245_8246 : H12AffineEnvironment.transform 5 48 env8245 = env8246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8245 == env8246) = true)

theorem identity8246 : scanCanonicalize (H12AffineFastState.compose env8246 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8246 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8247 : List Nat := [2,4,8,16,27,11,19,30,17,5,26,27,9,16,0,24,27,0,30,0,10,27,11,24,19,17,27,27,26,0,5,0,5,1,17,17]

theorem envBound8247 : H12AffineFastState.Bounded env8247 := by
  intro p hp
  have h : env8247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8246_8247 : H12AffineEnvironment.transform 4 27 env8246 = env8247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8246 == env8247) = true)

theorem identity8247 : scanCanonicalize (H12AffineFastState.compose env8247 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8248 : List Nat := [2,4,2,16,17,1,19,20,17,5,16,17,3,16,0,18,17,0,20,0,0,17,1,18,19,17,17,17,16,0,5,0,5,1,17,17]

theorem envBound8248 : H12AffineFastState.Bounded env8248 := by
  intro p hp
  have h : env8248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8247_8248 : H12AffineEnvironment.transform 2 2 env8247 = env8248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8247 == env8248) = true)

def leafEnv8248 : List Nat := [2,4,2,16,17,1,19,20,17,5,16,17,3,16,0,18,17,0,20,0,0,17,1,18,20,19,1,17,17,17,16,0,5,0,5,1,21,3,17,17,1,0,0]

def active8248 : List Nat := [0,1,3]

def tree8248 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8248 : H12WitnessSearch.Good tree8248 := H12GlobalWitnessIndex.good

theorem leafIdentity8248 : H12AffineFastState.composeSystem env8248 rootObs = leafEnv8248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8248 rootObs == leafEnv8248) = true)

theorem terminalChecked8248 : H12PackedTerminal.terminalCheckFast leafEnv8248 active8248 tree8248 = true := by decide +kernel

def env8249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,524288,8692,529265,16741,525805,35,8329,21453,279904,5293,5457,19913,530020,1528,525568,17897,540925,1021]

theorem envBound8249 : H12AffineFastState.Bounded env8249 := by
  intro p hp
  have h : env8249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8234_8249 : H12AffineEnvironment.transform 20 529265 env8234 = env8249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env8234 == env8249) = true)

def env8250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,4432,8692,545,16741,5309,35,8329,21453,279904,5293,5457,19913,1844,1528,5200,17897,20909,1021]

theorem envBound8250 : H12AffineFastState.Bounded env8250 := by
  intro p hp
  have h : env8250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8249_8250 : H12AffineEnvironment.transform 18 4432 env8249 = env8250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env8249 == env8250) = true)

theorem identity8250 : scanCanonicalize (H12AffineFastState.compose env8250 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8250 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,9682,4605,262144,4432,8692,545,373,5309,35,8329,5085,263536,5293,5457,3545,1844,1528,5200,1529,4541,1021]

theorem envBound8251 : H12AffineFastState.Bounded env8251 := by
  intro p hp
  have h : env8251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8250_8251 : H12AffineEnvironment.transform 13 16 env8250 = env8251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8250 == env8251) = true)

theorem identity8251 : scanCanonicalize (H12AffineFastState.compose env8251 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound8251 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8252 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,16,8692,9142,4605,262144,4432,8692,545,373,4825,35,8329,5085,262932,4809,4917,3005,336,924,4660,925,4541,1021]

theorem envBound8252 : H12AffineFastState.Bounded env8252 := by
  intro p hp
  have h : env8252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8251_8252 : H12AffineEnvironment.transform 9 612 env8251 = env8252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env8251 == env8252) = true)

theorem identity8252 : scanCanonicalize (H12AffineFastState.compose env8252 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7148) := by decide +kernel

theorem selectedBound8252 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8253 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,16,8692,9142,4605,7148,4432,8692,545,373,4825,35,8329,5085,6392,4809,4917,3005,336,924,4660,925,4541,1021]

theorem envBound8253 : H12AffineFastState.Bounded env8253 := by
  intro p hp
  have h : env8253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8252_8253 : H12AffineEnvironment.transform 17 7148 env8252 = env8253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7148 env8252 == env8253) = true)

theorem identity8253 : scanCanonicalize (H12AffineFastState.compose env8253 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound8253 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env8254 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,664,8192,16,8692,9142,869,2420,968,8692,545,373,65,35,8329,325,2656,81,429,3005,336,924,172,925,805,1021]

theorem envBound8254 : H12AffineFastState.Bounded env8254 := by
  intro p hp
  have h : env8254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8253_8254 : H12AffineEnvironment.transform 11 664 env8253 = env8254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env8253 == env8254) = true)

theorem identity8254 : scanCanonicalize (H12AffineFastState.compose env8254 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 493) := by decide +kernel

theorem selectedBound8254 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8255 : List Nat := [2,4,8,16,32,64,128,256,493,393,2048,373,8192,16,8692,8283,136,2420,37,8692,460,373,65,35,8329,325,2445,81,429,2128,336,113,172,112,200,16]

theorem envBound8255 : H12AffineFastState.Bounded env8255 := by
  intro p hp
  have h : env8255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8254_8255 : H12AffineEnvironment.transform 8 493 env8254 = env8255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 493 env8254 == env8255) = true)

theorem identity8255 : scanCanonicalize (H12AffineFastState.compose env8255 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8255 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8256 : List Nat := [2,4,8,16,32,64,128,85,184,220,2048,32,8192,16,8353,8283,136,2081,37,8353,153,32,65,35,8329,16,2264,81,248,2128,5,113,172,112,200,16]

theorem envBound8256 : H12AffineFastState.Bounded env8256 := by
  intro p hp
  have h : env8256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8255_8256 : H12AffineEnvironment.transform 7 85 env8255 = env8256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8255 == env8256) = true)

theorem identity8256 : scanCanonicalize (H12AffineFastState.compose env8256 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound8256 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8257 : List Nat := [2,4,8,16,32,64,128,85,184,220,32,32,8192,16,8353,8283,136,1,37,8353,153,32,65,35,8329,16,248,81,248,112,5,113,172,112,200,16]

theorem envBound8257 : H12AffineFastState.Bounded env8257 := by
  intro p hp
  have h : env8257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8256_8257 : H12AffineEnvironment.transform 10 32 env8256 = env8257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env8256 == env8257) = true)

theorem identity8257 : scanCanonicalize (H12AffineFastState.compose env8257 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound8257 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env8258 : List Nat := [2,4,8,16,32,64,128,85,184,220,32,32,50,16,147,105,136,1,37,147,153,32,65,35,187,16,248,81,248,112,5,113,172,112,200,16]

theorem envBound8258 : H12AffineFastState.Bounded env8258 := by
  intro p hp
  have h : env8258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8257_8258 : H12AffineEnvironment.transform 12 50 env8257 = env8258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env8257 == env8258) = true)

theorem identity8258 : scanCanonicalize (H12AffineFastState.compose env8258 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8258 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env8259 : List Nat := [2,4,8,16,32,11,128,30,184,151,32,32,50,16,147,34,136,1,37,147,153,32,10,35,187,16,179,26,179,59,5,58,172,59,131,16]

theorem envBound8259 : H12AffineFastState.Bounded env8259 := by
  intro p hp
  have h : env8259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8258_8259 : H12AffineEnvironment.transform 5 11 env8258 = env8259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8258 == env8259) = true)

theorem identity8259 : scanCanonicalize (H12AffineFastState.compose env8259 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8259 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8260 : List Nat := [2,4,8,16,27,11,128,30,131,151,27,27,9,16,147,25,136,1,30,147,153,27,10,24,128,16,136,26,136,0,5,1,151,0,131,16]

theorem envBound8260 : H12AffineFastState.Bounded env8260 := by
  intro p hp
  have h : env8260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8259_8260 : H12AffineEnvironment.transform 4 27 env8259 = env8260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8259 == env8260) = true)

theorem identity8260 : scanCanonicalize (H12AffineFastState.compose env8260 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8261 : List Nat := [2,4,8,16,27,11,19,30,16,4,27,27,9,16,0,25,27,1,30,0,10,27,10,24,19,16,27,26,27,0,5,1,4,0,16,16]

theorem envBound8261 : H12AffineFastState.Bounded env8261 := by
  intro p hp
  have h : env8261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8260_8261 : H12AffineEnvironment.transform 6 19 env8260 = env8261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8260 == env8261) = true)

theorem identity8261 : scanCanonicalize (H12AffineFastState.compose env8261 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8262 : List Nat := [2,4,3,16,16,0,19,21,16,4,16,16,2,16,0,18,16,1,21,0,1,16,1,19,19,16,16,17,16,0,5,1,4,0,16,16]

theorem envBound8262 : H12AffineFastState.Bounded env8262 := by
  intro p hp
  have h : env8262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8261_8262 : H12AffineEnvironment.transform 2 3 env8261 = env8262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8261 == env8262) = true)

def leafEnv8262 : List Nat := [2,4,3,16,16,0,19,21,16,4,16,16,2,16,0,18,16,1,21,0,1,16,1,19,20,19,1,16,16,17,16,0,5,1,4,0,21,2,16,16,1,0,0]

def active8262 : List Nat := [0,1,3]

def tree8262 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8262 : H12WitnessSearch.Good tree8262 := H12GlobalWitnessIndex.good

theorem leafIdentity8262 : H12AffineFastState.composeSystem env8262 rootObs = leafEnv8262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8262 rootObs == leafEnv8262) = true)

theorem terminalChecked8262 : H12PackedTerminal.terminalCheckFast leafEnv8262 active8262 tree8262 = true := by decide +kernel

def env8263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26050,4605,262144,4433,8692,544,16741,5308,35,8329,21453,279904,5293,5457,19913,1845,1528,5201,17897,20908,1021]

theorem envBound8263 : H12AffineFastState.Bounded env8263 := by
  intro p hp
  have h : env8263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8249_8263 : H12AffineEnvironment.transform 18 4433 env8249 = env8263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env8249 == env8263) = true)

theorem identity8263 : scanCanonicalize (H12AffineFastState.compose env8263 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound8263 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8692,9263,4605,262144,4433,8692,544,136,5308,35,8329,4640,263309,5293,5457,3108,1845,1528,5201,1028,4161,1021]

theorem envBound8264 : H12AffineFastState.Bounded env8264 := by
  intro p hp
  have h : env8264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8263_8264 : H12AffineEnvironment.transform 13 493 env8263 = env8264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env8263 == env8264) = true)

theorem identity8264 : scanCanonicalize (H12AffineFastState.compose env8264 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8264 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8265 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,493,8692,8235,4605,262144,4433,8692,544,136,4280,35,8329,4640,262281,4265,4437,2080,817,508,4181,0,4161,1021]

theorem envBound8265 : H12AffineFastState.Bounded env8265 := by
  intro p hp
  have h : env8265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8264_8265 : H12AffineEnvironment.transform 9 4 env8264 = env8265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8264 == env8265) = true)

theorem identity8265 : scanCanonicalize (H12AffineFastState.compose env8265 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8265 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8266 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8201,8235,4096,262144,4268,8201,544,136,4280,35,8329,4640,262281,4265,4264,2080,716,1,4181,0,4161,512]

theorem envBound8266 : H12AffineFastState.Bounded env8266 := by
  intro p hp
  have h : env8266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8265_8266 : H12AffineEnvironment.transform 7 253 env8265 = env8266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8265 == env8266) = true)

def env8267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79375,279905,5292,5456,16797163,17307207,16778714,525568,16795083,2118541,16778206]

theorem envBound8267 : H12AffineFastState.Bounded env8267 := by
  intro p hp
  have h : env8267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8214_8267 : H12AffineEnvironment.transform 26 279905 env8214 = env8267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279905 env8214 == env8267) = true)

def env8268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,91616,8329,79375,279905,5292,5456,75787,619431,90170,525568,73771,2118541,91710]

theorem envBound8268 : H12AffineFastState.Bounded env8268 := by
  intro p hp
  have h : env8268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8267_8268 : H12AffineEnvironment.transform 23 91616 env8267 = env8268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env8267 == env8268) = true)

theorem identity8268 : scanCanonicalize (H12AffineFastState.compose env8268 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound8268 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,2097152,16741,525805,35,8329,21452,279905,5292,5456,19912,530020,1529,525568,17896,2118541,1021]

theorem envBound8269 : H12AffineFastState.Bounded env8269 := by
  intro p hp
  have h : env8269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8268_8269 : H12AffineEnvironment.transform 15 26051 env8268 = env8269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env8268 == env8269) = true)

def env8270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,529264,16741,525805,35,8329,21452,279905,5292,5456,19912,530020,1529,525568,17896,540925,1021]

theorem envBound8270 : H12AffineFastState.Bounded env8270 := by
  intro p hp
  have h : env8270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8269_8270 : H12AffineEnvironment.transform 20 529264 env8269 = env8270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env8269 == env8270) = true)

theorem identity8270 : scanCanonicalize (H12AffineFastState.compose env8270 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8270 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8271 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,25662,4096,262144,524288,8201,529037,16536,525328,35,8329,21041,279708,5292,5293,19509,530020,1028,525565,17429,540925,512]

theorem envBound8271 : H12AffineFastState.Bounded env8271 := by
  intro p hp
  have h : env8271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8270_8271 : H12AffineEnvironment.transform 7 253 env8270 = env8271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8270 == env8271) = true)

theorem identity8271 : scanCanonicalize (H12AffineFastState.compose env8271 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8271 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8272 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16,8201,9262,4096,262144,524288,8201,529037,136,525328,35,8329,4641,263308,5292,5293,3109,530020,1028,525565,1029,524525,512]

theorem envBound8272 : H12AffineFastState.Bounded env8272 := by
  intro p hp
  have h : env8272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8271_8272 : H12AffineEnvironment.transform 13 16 env8271 = env8272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8271 == env8272) = true)

theorem identity8272 : scanCanonicalize (H12AffineFastState.compose env8272 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8272 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8273 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8201,8234,4096,262144,524288,8201,529037,136,524308,35,8329,4641,262280,4264,4265,2081,528992,0,524537,1,524525,512]

theorem envBound8273 : H12AffineFastState.Bounded env8273 := by
  intro p hp
  have h : env8273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8272_8273 : H12AffineEnvironment.transform 9 4 env8272 = env8273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8272 == env8273) = true)

theorem identity8273 : scanCanonicalize (H12AffineFastState.compose env8273 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4268) := by decide +kernel

theorem selectedBound8273 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8274 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8201,8234,4096,262144,4268,8201,545,136,4280,35,8329,4641,262280,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8274 : H12AffineFastState.Bounded env8274 := by
  intro p hp
  have h : env8274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8273_8274 : H12AffineEnvironment.transform 18 4268 env8273 = env8274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4268 env8273 == env8274) = true)

theorem identity8274 : scanCanonicalize (H12AffineFastState.compose env8274 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14544) := by decide +kernel

theorem selectedBound8274 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8275 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8201,8234,4096,14544,4268,8201,545,136,4280,35,8329,4641,14424,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8275 : H12AffineFastState.Bounded env8275 := by
  intro p hp
  have h : env8275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8274_8275 : H12AffineEnvironment.transform 17 14544 env8274 = env8275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14544 env8274 == env8275) = true)

theorem identity8275 : scanCanonicalize (H12AffineFastState.compose env8275 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6906) := by decide +kernel

theorem selectedBound8275 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8276 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,6906,16,6899,6864,4096,554,4268,6899,545,136,4280,35,6771,4641,674,4264,4265,2081,716,0,4181,1,4161,512]

theorem envBound8276 : H12AffineFastState.Bounded env8276 := by
  intro p hp
  have h : env8276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8275_8276 : H12AffineEnvironment.transform 12 6906 env8275 = env8276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6906 env8275 == env8276) = true)

theorem identity8276 : scanCanonicalize (H12AffineFastState.compose env8276 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8276 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env8277 : List Nat := [2,4,8,16,32,64,128,253,96,4,2048,4096,6298,16,6291,6320,4096,74,4268,6291,65,136,4280,35,6163,4161,194,4264,4265,2081,172,0,4181,1,4161,96]

theorem envBound8277 : H12AffineFastState.Bounded env8277 := by
  intro p hp
  have h : env8277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8276_8277 : H12AffineEnvironment.transform 8 96 env8276 = env8277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8276 == env8277) = true)

theorem identity8277 : scanCanonicalize (H12AffineFastState.compose env8277 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound8277 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8278 : List Nat := [2,4,8,16,32,64,128,253,96,4,27,4096,4225,16,4232,4267,4096,74,4268,4232,65,136,4280,35,4104,4161,194,4264,4265,58,172,0,4181,1,4161,96]

theorem envBound8278 : H12AffineFastState.Bounded env8278 := by
  intro p hp
  have h : env8278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8277_8278 : H12AffineEnvironment.transform 10 27 env8277 = env8278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env8277 == env8278) = true)

theorem identity8278 : scanCanonicalize (H12AffineFastState.compose env8278 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound8278 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8279 : List Nat := [2,4,8,16,32,64,128,253,96,4,27,80,209,16,216,251,80,74,252,216,65,136,232,35,88,17,194,248,249,58,172,0,5,1,17,96]

theorem envBound8279 : H12AffineFastState.Bounded env8279 := by
  intro p hp
  have h : env8279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8278_8279 : H12AffineEnvironment.transform 11 80 env8278 = env8279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env8278 == env8279) = true)

theorem identity8279 : scanCanonicalize (H12AffineFastState.compose env8279 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8279 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8280 : List Nat := [2,4,8,16,32,64,40,85,96,4,27,80,121,16,112,83,80,74,84,112,65,32,64,35,88,17,106,80,81,58,4,0,5,1,17,96]

theorem envBound8280 : H12AffineFastState.Bounded env8280 := by
  intro p hp
  have h : env8280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8279_8280 : H12AffineEnvironment.transform 6 40 env8279 = env8280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8279 == env8280) = true)

theorem identity8280 : scanCanonicalize (H12AffineFastState.compose env8280 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8281 : List Nat := [2,4,8,16,27,64,19,85,91,4,27,80,66,16,75,83,80,74,84,75,65,27,64,24,88,17,81,80,81,1,4,0,5,1,17,91]

theorem envBound8281 : H12AffineFastState.Bounded env8281 := by
  intro p hp
  have h : env8281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8280_8281 : H12AffineEnvironment.transform 4 27 env8280 = env8281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8280 == env8281) = true)

theorem identity8281 : scanCanonicalize (H12AffineFastState.compose env8281 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8281 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8282 : List Nat := [2,4,8,16,27,0,19,21,27,4,27,16,2,16,11,19,16,10,20,11,1,27,0,24,24,17,17,16,17,1,4,0,5,1,17,27]

theorem envBound8282 : H12AffineFastState.Bounded env8282 := by
  intro p hp
  have h : env8282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8281_8282 : H12AffineEnvironment.transform 5 0 env8281 = env8282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8281 == env8282) = true)

theorem identity8282 : scanCanonicalize (H12AffineFastState.compose env8282 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8283 : List Nat := [2,4,3,16,16,0,19,21,16,4,16,16,2,16,0,19,16,1,20,0,1,16,0,19,19,17,17,16,17,1,4,0,5,1,17,16]

theorem envBound8283 : H12AffineFastState.Bounded env8283 := by
  intro p hp
  have h : env8283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8282_8283 : H12AffineEnvironment.transform 2 3 env8282 = env8283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8282 == env8283) = true)

def leafEnv8283 : List Nat := [2,4,3,16,16,0,19,21,16,4,16,16,2,16,0,19,16,1,20,0,1,16,0,19,20,19,1,17,17,16,17,1,4,0,5,1,20,3,17,16,1,1,0]

def active8283 : List Nat := [0,1,3]

def tree8283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8283 : H12WitnessSearch.Good tree8283 := H12GlobalWitnessIndex.good

theorem leafIdentity8283 : H12AffineFastState.composeSystem env8283 rootObs = leafEnv8283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8283 rootObs == leafEnv8283) = true)

theorem terminalChecked8283 : H12PackedTerminal.terminalCheckFast leafEnv8283 active8283 tree8283 = true := by decide +kernel

def env8284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,524288,8692,529265,16741,525805,35,8329,21452,279905,5292,5456,19912,530020,1529,525568,17896,540924,1021]

theorem envBound8284 : H12AffineFastState.Bounded env8284 := by
  intro p hp
  have h : env8284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8269_8284 : H12AffineEnvironment.transform 20 529265 env8269 = env8284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env8269 == env8284) = true)

def env8285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,4432,8692,545,16741,5309,35,8329,21452,279905,5292,5456,19912,1844,1529,5200,17896,20908,1021]

theorem envBound8285 : H12AffineFastState.Bounded env8285 := by
  intro p hp
  have h : env8285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8284_8285 : H12AffineEnvironment.transform 18 4432 env8284 = env8285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env8284 == env8285) = true)

theorem identity8285 : scanCanonicalize (H12AffineFastState.compose env8285 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound8285 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8692,9262,4605,262144,4432,8692,545,136,5309,35,8329,4641,263308,5292,5456,3109,1844,1529,5200,1029,4161,1021]

theorem envBound8286 : H12AffineFastState.Bounded env8286 := by
  intro p hp
  have h : env8286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8285_8286 : H12AffineEnvironment.transform 13 493 env8285 = env8286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env8285 == env8286) = true)

theorem identity8286 : scanCanonicalize (H12AffineFastState.compose env8286 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8286 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8287 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,8192,493,8692,8235,4605,262144,4432,8692,545,136,4280,35,8329,4641,262281,4265,4437,2080,817,508,4181,0,4161,1021]

theorem envBound8287 : H12AffineFastState.Bounded env8287 := by
  intro p hp
  have h : env8287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8286_8287 : H12AffineEnvironment.transform 9 5 env8286 = env8287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8286 == env8287) = true)

theorem identity8287 : scanCanonicalize (H12AffineFastState.compose env8287 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8287 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8288 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8201,8235,4096,262144,4269,8201,545,136,4280,35,8329,4641,262281,4265,4264,2080,716,1,4181,0,4161,512]

theorem envBound8288 : H12AffineFastState.Bounded env8288 := by
  intro p hp
  have h : env8288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8287_8288 : H12AffineEnvironment.transform 7 253 env8287 = env8288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8287 == env8288) = true)

def env8289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,26051,4605,262144,4433,8692,544,16741,5308,35,8329,21452,279905,5292,5456,19912,1845,1529,5201,17896,20909,1021]

theorem envBound8289 : H12AffineFastState.Bounded env8289 := by
  intro p hp
  have h : env8289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8284_8289 : H12AffineEnvironment.transform 18 4433 env8284 = env8289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env8284 == env8289) = true)

theorem identity8289 : scanCanonicalize (H12AffineFastState.compose env8289 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8289 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,9683,4605,262144,4433,8692,544,373,5308,35,8329,5084,263537,5292,5456,3544,1845,1529,5201,1528,4541,1021]

theorem envBound8290 : H12AffineFastState.Bounded env8290 := by
  intro p hp
  have h : env8290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8289_8290 : H12AffineEnvironment.transform 13 16 env8289 = env8290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8289 == env8290) = true)

theorem identity8290 : scanCanonicalize (H12AffineFastState.compose env8290 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound8290 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8291 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,16,8692,9143,4605,262144,4433,8692,544,373,4824,35,8329,5084,262933,4808,4916,3004,337,925,4661,924,4541,1021]

theorem envBound8291 : H12AffineFastState.Bounded env8291 := by
  intro p hp
  have h : env8291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8290_8291 : H12AffineEnvironment.transform 9 612 env8290 = env8291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env8290 == env8291) = true)

theorem identity8291 : scanCanonicalize (H12AffineFastState.compose env8291 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7149) := by decide +kernel

theorem selectedBound8291 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8292 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,16,8692,9143,4605,7149,4433,8692,544,373,4824,35,8329,5084,6392,4808,4916,3004,337,925,4661,924,4541,1021]

theorem envBound8292 : H12AffineFastState.Bounded env8292 := by
  intro p hp
  have h : env8292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8291_8292 : H12AffineEnvironment.transform 17 7149 env8291 = env8292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7149 env8291 == env8292) = true)

theorem identity8292 : scanCanonicalize (H12AffineFastState.compose env8292 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound8292 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env8293 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,665,8192,16,8692,9143,868,2420,968,8692,544,373,65,35,8329,325,2657,81,429,3004,337,925,172,924,804,1021]

theorem envBound8293 : H12AffineFastState.Bounded env8293 := by
  intro p hp
  have h : env8293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8292_8293 : H12AffineEnvironment.transform 11 665 env8292 = env8293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env8292 == env8293) = true)

theorem identity8293 : scanCanonicalize (H12AffineFastState.compose env8293 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 492) := by decide +kernel

theorem selectedBound8293 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8294 : List Nat := [2,4,8,16,32,64,128,256,492,392,2048,373,8192,16,8692,8283,136,2420,36,8692,460,373,65,35,8329,325,2445,81,429,2128,337,113,172,112,200,17]

theorem envBound8294 : H12AffineFastState.Bounded env8294 := by
  intro p hp
  have h : env8294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8293_8294 : H12AffineEnvironment.transform 8 492 env8293 = env8294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 492 env8293 == env8294) = true)

theorem identity8294 : scanCanonicalize (H12AffineFastState.compose env8294 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8294 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8295 : List Nat := [2,4,8,16,32,64,128,85,185,221,2048,32,8192,16,8353,8283,136,2081,36,8353,153,32,65,35,8329,16,2264,81,248,2128,4,113,172,112,200,17]

theorem envBound8295 : H12AffineFastState.Bounded env8295 := by
  intro p hp
  have h : env8295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8294_8295 : H12AffineEnvironment.transform 7 85 env8294 = env8295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8294 == env8295) = true)

theorem identity8295 : scanCanonicalize (H12AffineFastState.compose env8295 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound8295 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8296 : List Nat := [2,4,8,16,32,64,128,85,185,221,137,32,8192,16,8353,8283,136,168,36,8353,153,32,65,35,8329,16,81,81,248,217,4,113,172,112,200,17]

theorem envBound8296 : H12AffineFastState.Bounded env8296 := by
  intro p hp
  have h : env8296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8295_8296 : H12AffineEnvironment.transform 10 137 env8295 = env8296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env8295 == env8296) = true)

theorem identity8296 : scanCanonicalize (H12AffineFastState.compose env8296 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound8296 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env8297 : List Nat := [2,4,8,16,32,64,128,85,185,221,137,32,154,16,59,193,136,168,36,59,153,32,65,35,19,16,81,81,248,217,4,113,172,112,200,17]

theorem envBound8297 : H12AffineFastState.Bounded env8297 := by
  intro p hp
  have h : env8297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8296_8297 : H12AffineEnvironment.transform 12 154 env8296 = env8297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env8296 == env8297) = true)

theorem identity8297 : scanCanonicalize (H12AffineFastState.compose env8297 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8297 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env8298 : List Nat := [2,4,8,16,32,11,128,30,185,150,137,32,154,16,59,138,136,168,36,59,153,32,10,35,19,16,26,26,179,146,4,58,172,59,131,17]

theorem envBound8298 : H12AffineFastState.Bounded env8298 := by
  intro p hp
  have h : env8298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8297_8298 : H12AffineEnvironment.transform 5 11 env8297 = env8298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8297 == env8298) = true)

theorem identity8298 : scanCanonicalize (H12AffineFastState.compose env8298 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8298 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8299 : List Nat := [2,4,8,16,32,11,19,30,42,5,26,32,9,16,59,25,27,59,36,59,10,32,10,35,19,16,26,26,32,1,4,58,63,59,16,17]

theorem envBound8299 : H12AffineFastState.Bounded env8299 := by
  intro p hp
  have h : env8299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8298_8299 : H12AffineEnvironment.transform 6 19 env8298 = env8299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8298 == env8299) = true)

theorem identity8299 : scanCanonicalize (H12AffineFastState.compose env8299 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8299 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8300 : List Nat := [2,4,8,16,17,11,19,30,27,5,26,17,9,16,10,25,27,10,21,10,10,17,10,18,19,16,26,26,17,1,4,11,14,10,16,17]

theorem envBound8300 : H12AffineFastState.Bounded env8300 := by
  intro p hp
  have h : env8300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8299_8300 : H12AffineEnvironment.transform 4 17 env8299 = env8300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8299 == env8300) = true)

theorem identity8300 : scanCanonicalize (H12AffineFastState.compose env8300 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8300 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8301 : List Nat := [2,4,2,16,17,1,19,20,17,5,16,17,3,16,0,19,17,0,21,0,0,17,0,18,19,16,16,16,17,1,4,1,4,0,16,17]

theorem envBound8301 : H12AffineFastState.Bounded env8301 := by
  intro p hp
  have h : env8301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8300_8301 : H12AffineEnvironment.transform 2 2 env8300 = env8301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8300 == env8301) = true)

def leafEnv8301 : List Nat := [2,4,2,16,17,1,19,20,17,5,16,17,3,16,0,19,17,0,21,0,0,17,0,18,20,19,1,16,16,16,17,1,4,1,4,0,20,2,16,17,1,1,0]

def active8301 : List Nat := [0,1,3]

def tree8301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8301 : H12WitnessSearch.Good tree8301 := H12GlobalWitnessIndex.good

theorem leafIdentity8301 : H12AffineFastState.composeSystem env8301 rootObs = leafEnv8301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8301 rootObs == leafEnv8301) = true)

theorem terminalChecked8301 : H12PackedTerminal.terminalCheckFast leafEnv8301 active8301 tree8301 = true := by decide +kernel

def env8302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,91617,8329,79375,279905,5292,5456,75786,619430,90171,525568,73770,2118541,91711]

theorem envBound8302 : H12AffineFastState.Bounded env8302 := by
  intro p hp
  have h : env8302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8267_8302 : H12AffineEnvironment.transform 23 91617 env8267 = env8302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env8267 == env8302) = true)

theorem identity8302 : scanCanonicalize (H12AffineFastState.compose env8302 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8302 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8303 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91164,8329,79375,279708,5292,5293,75786,619099,90171,525565,73770,2118256,91711]

theorem envBound8303 : H12AffineFastState.Bounded env8303 := by
  intro p hp
  have h : env8303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8302_8303 : H12AffineEnvironment.transform 7 253 env8302 = env8303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8302 == env8303) = true)

def env8304 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91164,8329,78959,279708,5292,5293,75786,618555,90171,525565,73770,2117648,91231]

theorem envBound8304 : H12AffineFastState.Bounded env8304 := by
  intro p hp
  have h : env8304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8303_8304 : H12AffineEnvironment.transform 8 96 env8303 = env8304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8303 == env8304) = true)

theorem identity8304 : scanCanonicalize (H12AffineFastState.compose env8304 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound8304 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8305 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9263,4096,262144,524288,8201,2097152,16536,525328,16435,8329,4160,279708,5292,5293,3109,545812,17428,525565,1029,2117648,16496]

theorem envBound8305 : H12AffineFastState.Bounded env8305 := by
  intro p hp
  have h : env8305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8304_8305 : H12AffineEnvironment.transform 15 9263 env8304 = env8305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env8304 == env8305) = true)

theorem identity8305 : scanCanonicalize (H12AffineFastState.compose env8305 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545020) := by decide +kernel

theorem selectedBound8305 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8306 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9263,4096,262144,524288,8201,545020,16536,525328,16435,8329,4160,279708,5292,5293,3109,545812,17428,525565,1029,524524,16496]

theorem envBound8306 : H12AffineFastState.Bounded env8306 := by
  intro p hp
  have h : env8306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8305_8306 : H12AffineEnvironment.transform 20 545020 env8305 = env8306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545020 env8305 == env8306) = true)

theorem identity8306 : scanCanonicalize (H12AffineFastState.compose env8306 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282654) := by decide +kernel

theorem selectedBound8306 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env8307 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9263,4096,262144,282654,8201,262370,16536,283662,16435,8329,4160,279708,5292,5293,3109,263178,17428,283875,1029,282866,16496]

theorem envBound8307 : H12AffineFastState.Bounded env8307 := by
  intro p hp
  have h : env8307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8306_8307 : H12AffineEnvironment.transform 18 282654 env8306 = env8307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282654 env8306 == env8307) = true)

theorem identity8307 : scanCanonicalize (H12AffineFastState.compose env8307 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17591) := by decide +kernel

theorem selectedBound8307 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env8308 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8201,9263,4096,17591,5289,8201,17493,16536,4281,16435,8329,4160,43,5292,5293,3109,16573,17428,4180,1029,5189,16496]

theorem envBound8308 : H12AffineFastState.Bounded env8308 := by
  intro p hp
  have h : env8308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8307_8308 : H12AffineEnvironment.transform 17 17591 env8307 = env8308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17591 env8307 == env8308) = true)

theorem identity8308 : scanCanonicalize (H12AffineFastState.compose env8308 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8308 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8309 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8201,9263,4096,1190,5289,8201,1092,137,4281,34,8329,4160,43,5292,5293,3109,172,1029,4180,1029,5189,97]

theorem envBound8309 : H12AffineFastState.Bounded env8309 := by
  intro p hp
  have h : env8309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8308_8309 : H12AffineEnvironment.transform 13 17 env8308 = env8309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8308 == env8309) = true)

def env8310 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,16536,525328,91164,8329,78958,279708,5292,5293,75786,618554,90171,525565,73770,2117649,91230]

theorem envBound8310 : H12AffineFastState.Bounded env8310 := by
  intro p hp
  have h : env8310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8303_8310 : H12AffineEnvironment.transform 8 97 env8303 = env8310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8303 == env8310) = true)

theorem identity8310 : scanCanonicalize (H12AffineFastState.compose env8310 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound8310 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env8311 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8201,25663,4096,262144,524288,8201,2097152,16536,525328,35,8329,20561,279708,5292,5293,19509,529413,1028,525565,17429,2117649,97]

theorem envBound8311 : H12AffineFastState.Bounded env8311 := by
  intro p hp
  have h : env8311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8310_8311 : H12AffineEnvironment.transform 15 25663 env8310 = env8311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env8310 == env8311) = true)

theorem identity8311 : scanCanonicalize (H12AffineFastState.compose env8311 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8311 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8312 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8201,9262,4096,262144,524288,8201,2097152,137,525328,35,8329,4160,263309,5292,5293,3108,529413,1028,525565,1028,2101248,97]

theorem envBound8312 : H12AffineFastState.Bounded env8312 := by
  intro p hp
  have h : env8312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8311_8312 : H12AffineEnvironment.transform 13 17 env8311 = env8312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8311 == env8312) = true)

theorem identity8312 : scanCanonicalize (H12AffineFastState.compose env8312 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound8312 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8313 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8201,9262,4096,262144,524288,8201,529640,137,525328,35,8329,4160,263309,5292,5293,3108,529413,1028,525565,1028,525544,97]

theorem envBound8313 : H12AffineFastState.Bounded env8313 := by
  intro p hp
  have h : env8313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8312_8313 : H12AffineEnvironment.transform 20 529640 env8312 = env8313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env8312 == env8313) = true)

theorem identity8313 : scanCanonicalize (H12AffineFastState.compose env8313 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13473) := by decide +kernel

theorem selectedBound8313 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env8314 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8201,9262,4096,262144,13473,8201,8265,137,12465,35,8329,4160,263309,5292,5293,3108,8356,1028,12380,1028,12361,97]

theorem envBound8314 : H12AffineFastState.Bounded env8314 := by
  intro p hp
  have h : env8314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8313_8314 : H12AffineEnvironment.transform 18 13473 env8313 = env8314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13473 env8313 == env8314) = true)

theorem identity8314 : scanCanonicalize (H12AffineFastState.compose env8314 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9286) := by decide +kernel

theorem selectedBound8314 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env8315 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8201,9262,4096,9286,13473,8201,8265,137,12465,35,8329,4160,8395,5292,5293,3108,8356,1028,12380,1028,12361,97]

theorem envBound8315 : H12AffineFastState.Bounded env8315 := by
  intro p hp
  have h : env8315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8314_8315 : H12AffineEnvironment.transform 17 9286 env8314 = env8315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9286 env8314 == env8315) = true)

theorem identity8315 : scanCanonicalize (H12AffineFastState.compose env8315 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8315 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env8316 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8,17,1,1062,4096,1102,5289,1,65,137,4281,35,129,4160,195,5292,5293,3108,172,1028,4180,1028,4161,97]

theorem envBound8316 : H12AffineFastState.Bounded env8316 := by
  intro p hp
  have h : env8316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8315_8316 : H12AffineEnvironment.transform 12 8 env8315 = env8316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8315 == env8316) = true)

theorem identity8316 : scanCanonicalize (H12AffineFastState.compose env8316 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8316 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8317 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,4096,8,17,1,1062,4096,1102,5121,1,65,33,4113,35,41,4160,107,5124,5125,3108,4,1028,4180,1028,4161,97]

theorem envBound8317 : H12AffineFastState.Bounded env8317 := by
  intro p hp
  have h : env8317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8316_8317 : H12AffineEnvironment.transform 6 40 env8316 = env8317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8316 == env8317) = true)

theorem identity8317 : scanCanonicalize (H12AffineFastState.compose env8317 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound8317 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env8318 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,1109,8,17,1,1062,1109,1102,84,1,65,33,1092,35,41,1045,107,81,80,3108,4,1028,1025,1028,1044,97]

theorem envBound8318 : H12AffineFastState.Bounded env8318 := by
  intro p hp
  have h : env8318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8317_8318 : H12AffineEnvironment.transform 11 1109 env8317 = env8318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env8317 == env8318) = true)

def env8319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,138678441,138678613,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound8319 : H12AffineFastState.Bounded env8319 := by
  intro p hp
  have h : env8319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8106_8319 : H12AffineEnvironment.transform 27 138678441 env8106 = env8319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env8106 == env8319) = true)

theorem identity8319 : scanCanonicalize (H12AffineFastState.compose env8319 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 79858) := by decide +kernel

theorem selectedBound8319 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,79858,134217728,138678441,138678613,151259274,17307578,155451870,525568,151257258,136582929,16778206]

theorem envBound8320 : H12AffineFastState.Bounded env8320 := by
  intro p hp
  have h : env8320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8319_8320 : H12AffineEnvironment.transform 25 79858 env8319 = env8320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 79858 env8319 == env8320) = true)

def env8321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79858,134217728,134500813,134500401,151259274,17307578,151273658,525568,151257258,136582929,16778206]

theorem envBound8321 : H12AffineFastState.Bounded env8321 := by
  intro p hp
  have h : env8321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8320_8321 : H12AffineEnvironment.transform 21 16740 env8320 = env8321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16740 env8320 == env8321) = true)

def env8322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79858,278624,4525,4177,16795882,17307578,16777434,525568,16793802,2119537,16778206]

theorem envBound8322 : H12AffineFastState.Bounded env8322 := by
  intro p hp
  have h : env8322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8321_8322 : H12AffineEnvironment.transform 26 278624 env8321 = env8322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278624 env8321 == env8322) = true)

def env8323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,90336,8329,79858,278624,4525,4177,75786,620378,90170,525568,73770,2119537,90942]

theorem envBound8323 : H12AffineFastState.Bounded env8323 := by
  intro p hp
  have h : env8323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8322_8323 : H12AffineEnvironment.transform 23 90336 env8322 = env8323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8322 == env8323) = true)

theorem identity8323 : scanCanonicalize (H12AffineFastState.compose env8323 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8323 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8324 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16536,525329,90336,8329,79374,278624,4177,4177,75786,620198,90170,525564,73770,2119309,90818]

theorem envBound8324 : H12AffineFastState.Bounded env8324 := by
  intro p hp
  have h : env8324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8323_8324 : H12AffineEnvironment.transform 7 252 env8323 = env8324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8323 == env8324) = true)

def env8325 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16480,525329,90136,8305,79374,278624,4177,4177,75786,620126,90170,525316,73770,2119285,90682]

theorem envBound8325 : H12AffineFastState.Bounded env8325 := by
  intro p hp
  have h : env8325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8324_8325 : H12AffineEnvironment.transform 6 120 env8324 = env8325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8324 == env8325) = true)

theorem identity8325 : scanCanonicalize (H12AffineFastState.compose env8325 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619086) := by decide +kernel

theorem selectedBound8325 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8326 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619086,16480,525329,90136,8305,79374,278624,4177,4177,75786,620126,90170,525316,73770,599099,90682]

theorem envBound8326 : H12AffineFastState.Bounded env8326 := by
  intro p hp
  have h : env8326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8325_8326 : H12AffineEnvironment.transform 20 619086 env8325 = env8326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619086 env8325 == env8326) = true)

def env8327 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619038,16432,525329,90136,8225,79374,278576,4097,4097,75786,620046,90170,525316,73770,599099,90682]

theorem envBound8327 : H12AffineFastState.Bounded env8327 := by
  intro p hp
  have h : env8327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8326_8327 : H12AffineEnvironment.transform 5 16 env8326 = env8327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8326 == env8327) = true)

theorem identity8327 : scanCanonicalize (H12AffineFastState.compose env8327 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281648) := by decide +kernel

theorem selectedBound8327 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8328 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,281648,8200,343598,16432,280609,90136,8225,79374,278576,4097,4097,75786,342590,90170,280628,73770,354315,90682]

theorem envBound8328 : H12AffineFastState.Bounded env8328 := by
  intro p hp
  have h : env8328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8327_8328 : H12AffineEnvironment.transform 18 281648 env8327 = env8328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281648 env8327 == env8328) = true)

theorem identity8328 : scanCanonicalize (H12AffineFastState.compose env8328 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound8328 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8329 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,78367,8200,16385,16432,79374,90136,8225,79374,81439,4097,4097,75786,17425,90170,79387,73770,5668,90682]

theorem envBound8329 : H12AffineFastState.Bounded env8329 := by
  intro p hp
  have h : env8329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8328_8329 : H12AffineEnvironment.transform 17 97839 env8328 = env8329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env8328 == env8329) = true)

def env8330 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619039,16433,525329,90136,8224,79374,278577,4096,4096,75786,620047,90170,525316,73770,599099,90682]

theorem envBound8330 : H12AffineFastState.Bounded env8330 := by
  intro p hp
  have h : env8330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8326_8330 : H12AffineEnvironment.transform 5 17 env8326 = env8330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8326 == env8330) = true)

theorem identity8330 : scanCanonicalize (H12AffineFastState.compose env8330 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound8330 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8331 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,524288,8200,619039,16433,525329,90136,8224,79374,81439,4096,4096,75786,620047,90170,525316,73770,599099,90682]

theorem envBound8331 : H12AffineFastState.Bounded env8331 := by
  intro p hp
  have h : env8331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8330_8331 : H12AffineEnvironment.transform 17 97838 env8330 = env8331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env8330 == env8331) = true)

theorem identity8331 : scanCanonicalize (H12AffineFastState.compose env8331 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94735) := by decide +kernel

theorem selectedBound8331 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8332 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,94735,8200,16,16433,95774,90136,8224,79374,81439,4096,4096,75786,1024,90170,95755,73770,22068,90682]

theorem envBound8332 : H12AffineFastState.Bounded env8332 := by
  intro p hp
  have h : env8332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8331_8332 : H12AffineEnvironment.transform 18 94735 env8331 = env8332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94735 env8331 == env8332) = true)

theorem identity8332 : scanCanonicalize (H12AffineFastState.compose env8332 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound8332 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8333 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,24634,4097,7700,4661,8200,16,16433,5668,34,8224,22068,24101,4096,4096,18480,1024,0,5681,16400,22068,512]

theorem envBound8333 : H12AffineFastState.Bounded env8333 := by
  intro p hp
  have h : env8333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8332_8333 : H12AffineEnvironment.transform 15 24634 env8332 = env8333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env8332 == env8333) = true)

theorem identity8333 : scanCanonicalize (H12AffineFastState.compose env8333 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8333 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8334 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,4096,8192,16384,8200,24634,4097,5150,4661,8200,16,16433,5668,34,8224,22068,21551,4096,4096,16954,1024,0,5681,16400,22068,512]

theorem envBound8334 : H12AffineFastState.Bounded env8334 := by
  intro p hp
  have h : env8334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8333_8334 : H12AffineEnvironment.transform 10 522 env8333 = env8334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8333 == env8334) = true)

theorem identity8334 : scanCanonicalize (H12AffineFastState.compose env8334 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8334 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8335 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,4096,8192,17,8200,8235,4097,5150,4661,8200,16,32,5668,34,8224,5669,5182,4096,4096,555,1024,0,5681,1,5669,512]

theorem envBound8335 : H12AffineFastState.Bounded env8335 := by
  intro p hp
  have h : env8335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8334_8335 : H12AffineEnvironment.transform 13 17 env8334 = env8335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8334 == env8335) = true)

theorem identity8335 : scanCanonicalize (H12AffineFastState.compose env8335 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound8335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8336 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,4096,1063,17,1071,1036,4097,5150,4661,1071,16,32,5668,34,1031,5669,5182,4096,4096,555,1024,0,5681,1,5669,512]

theorem envBound8336 : H12AffineFastState.Bounded env8336 := by
  intro p hp
  have h : env8336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8335_8336 : H12AffineEnvironment.transform 12 1063 env8335 = env8336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env8335 == env8336) = true)

theorem identity8336 : scanCanonicalize (H12AffineFastState.compose env8336 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8337 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,4096,1030,17,1038,1036,4097,5150,4628,1038,16,1,5637,3,1031,5636,5151,4096,4096,522,1024,0,5648,1,5636,512]

theorem envBound8337 : H12AffineFastState.Bounded env8337 := by
  intro p hp
  have h : env8337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8336_8337 : H12AffineEnvironment.transform 4 1 env8336 = env8337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8336 == env8337) = true)

theorem identity8337 : scanCanonicalize (H12AffineFastState.compose env8337 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound8337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8338 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,27,1030,17,1038,1036,26,1029,527,1038,16,1,1566,3,1031,1567,1028,27,27,522,1024,0,1547,1,1567,512]

theorem envBound8338 : H12AffineFastState.Bounded env8338 := by
  intro p hp
  have h : env8338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8337_8338 : H12AffineEnvironment.transform 11 27 env8337 = env8338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env8337 == env8338) = true)

theorem identity8338 : scanCanonicalize (H12AffineFastState.compose env8338 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8338 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env8339 : List Nat := [2,4,8,16,1,17,8,4,0,1024,10,27,1030,17,1038,1036,26,1029,15,1038,16,1,1054,3,1031,1055,1028,27,27,10,1024,0,1035,1,1055,0]

theorem envBound8339 : H12AffineFastState.Bounded env8339 := by
  intro p hp
  have h : env8339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8338_8339 : H12AffineEnvironment.transform 8 0 env8338 = env8339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8338 == env8339) = true)

theorem identity8339 : scanCanonicalize (H12AffineFastState.compose env8339 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound8339 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8340 : List Nat := [2,4,8,16,1,17,8,4,0,15,10,27,9,17,1,3,26,10,15,1,16,1,17,3,8,16,11,27,27,10,15,0,4,1,16,0]

theorem envBound8340 : H12AffineFastState.Bounded env8340 := by
  intro p hp
  have h : env8340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8339_8340 : H12AffineEnvironment.transform 9 15 env8339 = env8340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env8339 == env8340) = true)

theorem identity8340 : scanCanonicalize (H12AffineFastState.compose env8340 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8340 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8341 : List Nat := [2,4,8,10,1,11,8,4,0,15,10,1,9,11,1,3,0,10,15,1,10,1,11,3,8,10,11,1,1,10,15,0,4,1,10,0]

theorem envBound8341 : H12AffineFastState.Bounded env8341 := by
  intro p hp
  have h : env8341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8340_8341 : H12AffineEnvironment.transform 3 10 env8340 = env8341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8340 == env8341) = true)

def env8342 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16481,525329,90137,8304,79374,278624,4177,4177,75786,620127,90170,525317,73770,2119284,90683]

theorem envBound8342 : H12AffineFastState.Bounded env8342 := by
  intro p hp
  have h : env8342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8324_8342 : H12AffineEnvironment.transform 6 121 env8324 = env8342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8324 == env8342) = true)

theorem identity8342 : scanCanonicalize (H12AffineFastState.compose env8342 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545380) := by decide +kernel

theorem selectedBound8342 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8343 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545380,16481,525329,90137,8304,79374,278624,4177,4177,75786,620127,90170,525317,73770,525328,90683]

theorem envBound8343 : H12AffineFastState.Bounded env8343 := by
  intro p hp
  have h : env8343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8342_8343 : H12AffineEnvironment.transform 20 545380 env8342 = env8343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545380 env8342 == env8343) = true)

def env8344 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545332,16433,525329,90137,8224,79374,278576,4097,4097,75786,620047,90170,525317,73770,525328,90683]

theorem envBound8344 : H12AffineFastState.Bounded env8344 := by
  intro p hp
  have h : env8344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8343_8344 : H12AffineEnvironment.transform 5 16 env8343 = env8344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8343 == env8344) = true)

theorem identity8344 : scanCanonicalize (H12AffineFastState.compose env8344 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338954) := by decide +kernel

theorem selectedBound8344 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8345 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,338954,8200,359998,16433,337947,90137,8224,79374,278576,4097,4097,75786,285189,90170,337935,73770,337946,90683]

theorem envBound8345 : H12AffineFastState.Bounded env8345 := by
  intro p hp
  have h : env8345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8344_8345 : H12AffineEnvironment.transform 18 338954 env8344 = env8345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338954 env8344 == env8345) = true)

theorem identity8345 : scanCanonicalize (H12AffineFastState.compose env8345 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24068) := by decide +kernel

theorem selectedBound8345 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8346 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,24068,94734,8200,73786,16433,95775,90137,8224,79374,7732,4097,4097,75786,1025,90170,95755,73770,95774,90683]

theorem envBound8346 : H12AffineFastState.Bounded env8346 := by
  intro p hp
  have h : env8346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8345_8346 : H12AffineEnvironment.transform 17 24068 env8345 = env8346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24068 env8345 == env8346) = true)

def env8347 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545333,16432,525329,90137,8225,79374,278577,4096,4096,75786,620046,90170,525317,73770,525328,90683]

theorem envBound8347 : H12AffineFastState.Bounded env8347 := by
  intro p hp
  have h : env8347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8343_8347 : H12AffineEnvironment.transform 5 17 env8343 = env8347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8343 == env8347) = true)

theorem identity8347 : scanCanonicalize (H12AffineFastState.compose env8347 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound8347 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8348 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,524288,8200,545333,16432,525329,90137,8225,79374,24100,4096,4096,75786,620046,90170,525317,73770,525328,90683]

theorem envBound8348 : H12AffineFastState.Bounded env8348 := by
  intro p hp
  have h : env8348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8347_8348 : H12AffineEnvironment.transform 17 7701 env8347 = env8348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env8347 == env8348) = true)

theorem identity8348 : scanCanonicalize (H12AffineFastState.compose env8348 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78366) := by decide +kernel

theorem selectedBound8348 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8349 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78366,8200,90155,16432,79375,90137,8225,79374,24100,4096,4096,75786,17424,90170,79387,73770,79374,90683]

theorem envBound8349 : H12AffineFastState.Bounded env8349 := by
  intro p hp
  have h : env8349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8348_8349 : H12AffineEnvironment.transform 18 78366 env8348 = env8349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78366 env8348 == env8349) = true)

theorem identity8349 : scanCanonicalize (H12AffineFastState.compose env8349 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8349 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env8350 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,17,8200,65536,4097,7701,78366,8200,73786,33,79375,73736,8225,79374,7733,4096,4096,75786,1025,73771,79387,73770,79374,74282]

theorem envBound8350 : H12AffineFastState.Bounded env8350 := by
  intro p hp
  have h : env8350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8349_8350 : H12AffineEnvironment.transform 13 17 env8349 = env8350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8349 == env8350) = true)

theorem identity8350 : scanCanonicalize (H12AffineFastState.compose env8350 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound8350 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8351 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,8192,17,8200,65536,4097,5669,78366,8200,73786,33,79375,73736,8225,79374,5637,4096,4096,73786,1025,73771,79387,73770,79374,74282]

theorem envBound8351 : H12AffineFastState.Bounded env8351 := by
  intro p hp
  have h : env8351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8350_8351 : H12AffineEnvironment.transform 10 48 env8350 = env8351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env8350 == env8351) = true)

theorem identity8351 : scanCanonicalize (H12AffineFastState.compose env8351 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8351 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8352 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,24,17,16,65536,4097,5669,70150,16,65570,33,71191,65552,57,71190,5637,4096,4096,65570,1025,65587,71171,65586,71190,66098]

theorem envBound8352 : H12AffineFastState.Bounded env8352 := by
  intro p hp
  have h : env8352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8351_8352 : H12AffineEnvironment.transform 12 24 env8351 = env8352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8351 == env8352) = true)

theorem identity8352 : scanCanonicalize (H12AffineFastState.compose env8352 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound8352 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8353 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,24,17,16,5174,4097,5669,1584,16,5140,33,545,5158,57,544,5637,4096,4096,5140,1025,5125,565,5124,544,5636]

theorem envBound8353 : H12AffineFastState.Bounded env8353 := by
  intro p hp
  have h : env8353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8352_8353 : H12AffineEnvironment.transform 15 5174 env8352 = env8353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env8352 == env8353) = true)

theorem identity8353 : scanCanonicalize (H12AffineFastState.compose env8353 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound8353 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env8354 : List Nat := [2,4,8,16,32,17,40,5,59,1024,48,4096,24,17,16,5174,4097,5150,1035,16,5140,33,26,5158,57,27,5182,4096,4096,5140,1025,5125,14,5124,27,5183]

theorem envBound8354 : H12AffineFastState.Bounded env8354 := by
  intro p hp
  have h : env8354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8353_8354 : H12AffineEnvironment.transform 8 59 env8353 = env8354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env8353 == env8354) = true)

theorem identity8354 : scanCanonicalize (H12AffineFastState.compose env8354 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound8354 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8355 : List Nat := [2,4,8,16,32,17,40,5,59,62,48,4096,24,17,16,4104,4097,4128,53,16,4138,33,26,4120,57,27,4096,4096,4096,4138,63,4155,14,4154,27,4097]

theorem envBound8355 : H12AffineFastState.Bounded env8355 := by
  intro p hp
  have h : env8355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8354_8355 : H12AffineEnvironment.transform 9 62 env8354 = env8355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env8354 == env8355) = true)

theorem identity8355 : scanCanonicalize (H12AffineFastState.compose env8355 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8356 : List Nat := [2,4,8,16,16,17,24,5,11,14,0,4096,24,17,16,4104,4097,4112,5,16,4122,17,26,4120,9,27,4096,4096,4096,4122,15,4107,14,4106,27,4097]

theorem envBound8356 : H12AffineFastState.Bounded env8356 := by
  intro p hp
  have h : env8356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8355_8356 : H12AffineEnvironment.transform 4 16 env8355 = env8356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8355 == env8356) = true)

theorem identity8356 : scanCanonicalize (H12AffineFastState.compose env8356 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound8356 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8357 : List Nat := [2,4,8,16,16,17,24,5,11,14,0,10,24,17,16,2,11,26,5,16,16,17,26,18,9,27,10,10,10,16,15,1,14,0,27,11]

theorem envBound8357 : H12AffineFastState.Bounded env8357 := by
  intro p hp
  have h : env8357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8356_8357 : H12AffineEnvironment.transform 11 10 env8356 = env8357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env8356 == env8357) = true)

theorem identity8357 : scanCanonicalize (H12AffineFastState.compose env8357 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8358 : List Nat := [2,4,8,10,10,11,2,5,11,14,0,10,2,11,10,2,11,0,5,10,10,11,0,8,9,1,10,10,10,10,15,1,14,0,1,11]

theorem envBound8358 : H12AffineFastState.Bounded env8358 := by
  intro p hp
  have h : env8358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8357_8358 : H12AffineEnvironment.transform 3 10 env8357 = env8358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8357 == env8358) = true)

theorem identity8358 : scanCanonicalize (H12AffineFastState.compose env8358 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8358 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8359 : List Nat := [2,4,3,1,1,0,2,5,0,5,0,1,2,0,1,2,0,0,5,1,1,0,0,3,2,1,1,1,1,1,4,1,5,0,1,0]

theorem envBound8359 : H12AffineFastState.Bounded env8359 := by
  intro p hp
  have h : env8359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8358_8359 : H12AffineEnvironment.transform 2 3 env8358 = env8359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8358 == env8359) = true)

def env8360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,90337,8329,79858,278624,4525,4177,75787,620379,90171,525568,73771,2119537,90943]

theorem envBound8360 : H12AffineFastState.Bounded env8360 := by
  intro p hp
  have h : env8360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8322_8360 : H12AffineEnvironment.transform 23 90337 env8322 = env8360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8322 == env8360) = true)

theorem identity8360 : scanCanonicalize (H12AffineFastState.compose env8360 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8360 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,4605,262144,524288,8692,2097152,16740,525805,34,8329,22321,278624,4525,4177,18632,530328,248,525568,16616,2119537,1020]

theorem envBound8361 : H12AffineFastState.Bounded env8361 := by
  intro p hp
  have h : env8361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8360_8361 : H12AffineEnvironment.transform 15 24771 env8360 = env8361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8360 == env8361) = true)

def env8362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8403,4605,262144,524288,8692,2097152,372,525805,34,8329,5921,262256,4525,4177,2264,530328,248,525568,248,2103137,1020]

theorem envBound8362 : H12AffineFastState.Bounded env8362 := by
  intro p hp
  have h : env8362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8361_8362 : H12AffineEnvironment.transform 13 16 env8361 = env8362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8361 == env8362) = true)

theorem identity8362 : scanCanonicalize (H12AffineFastState.compose env8362 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8362 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8363 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8403,4097,262144,524288,8200,2097152,136,525329,34,8329,5853,262256,4177,4177,2264,530020,248,525564,248,2102941,512]

theorem envBound8363 : H12AffineFastState.Bounded env8363 := by
  intro p hp
  have h : env8363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8362_8363 : H12AffineEnvironment.transform 7 252 env8362 = env8363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8362 == env8363) = true)

theorem identity8363 : scanCanonicalize (H12AffineFastState.compose env8363 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529037) := by decide +kernel

theorem selectedBound8363 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8364 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8403,4097,262144,524288,8200,529037,136,525329,34,8329,5853,262256,4177,4177,2264,530020,248,525564,248,525328,512]

theorem envBound8364 : H12AffineFastState.Bounded env8364 := by
  intro p hp
  have h : env8364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8363_8364 : H12AffineEnvironment.transform 20 529037 env8363 = env8364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529037 env8363 == env8364) = true)

theorem identity8364 : scanCanonicalize (H12AffineFastState.compose env8364 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4660) := by decide +kernel

theorem selectedBound8364 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8365 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8403,4097,262144,4660,8200,185,136,5669,34,8329,5853,262256,4177,4177,2264,1104,248,5832,248,5668,512]

theorem envBound8365 : H12AffineFastState.Bounded env8365 := by
  intro p hp
  have h : env8365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8364_8365 : H12AffineEnvironment.transform 18 4660 env8364 = env8365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4660 env8364 == env8365) = true)

theorem identity8365 : scanCanonicalize (H12AffineFastState.compose env8365 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 13999) := by decide +kernel

theorem selectedBound8365 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8366 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8403,4097,13999,4660,8200,185,136,5669,34,8329,5853,14047,4177,4177,2264,1104,248,5832,248,5668,512]

theorem envBound8366 : H12AffineFastState.Bounded env8366 := by
  intro p hp
  have h : env8366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8365_8366 : H12AffineEnvironment.transform 17 13999 env8365 = env8366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13999 env8365 == env8366) = true)

theorem identity8366 : scanCanonicalize (H12AffineFastState.compose env8366 (packedSelected [2,13,14] rootPS)) = affineNative (2^(11+1) ^^^ 2787) := by decide +kernel

theorem selectedBound8366 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8367 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2787,8192,16,8200,8403,2786,11340,2263,8200,185,136,3270,34,8329,3134,11324,2738,2738,2264,1104,248,3115,248,3271,512]

theorem envBound8367 : H12AffineFastState.Bounded env8367 := by
  intro p hp
  have h : env8367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8366_8367 : H12AffineEnvironment.transform 11 2787 env8366 = env8367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2787 env8366 == env8367) = true)

theorem identity8367 : scanCanonicalize (H12AffineFastState.compose env8367 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3310) := by decide +kernel

theorem selectedBound8367 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env8368 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2787,3310,16,3302,3133,2786,162,2263,3302,185,136,3270,34,3175,3134,210,2738,2738,2264,1104,248,3115,248,3271,512]

theorem envBound8368 : H12AffineFastState.Bounded env8368 := by
  intro p hp
  have h : env8368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8367_8368 : H12AffineEnvironment.transform 12 3310 env8367 = env8368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3310 env8367 == env8368) = true)

theorem identity8368 : scanCanonicalize (H12AffineFastState.compose env8368 (packedSelected [13,17] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound8368 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8369 : List Nat := [2,4,8,16,32,64,128,252,512,85,2048,2787,2235,16,2227,2152,2786,162,2263,2227,185,136,2195,34,2098,2155,210,2738,2738,2264,5,248,2174,248,2194,512]

theorem envBound8369 : H12AffineFastState.Bounded env8369 := by
  intro p hp
  have h : env8369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8368_8369 : H12AffineEnvironment.transform 9 85 env8368 = env8369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env8368 == env8369) = true)

theorem identity8369 : scanCanonicalize (H12AffineFastState.compose env8369 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound8369 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8370 : List Nat := [2,4,8,16,32,64,128,252,152,85,2048,2171,2235,16,2227,2152,2170,162,2263,2227,185,136,2195,34,2098,2155,210,2090,2090,2264,5,248,2174,248,2194,152]

theorem envBound8370 : H12AffineFastState.Bounded env8370 := by
  intro p hp
  have h : env8370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8369_8370 : H12AffineEnvironment.transform 8 152 env8369 = env8370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env8369 == env8370) = true)

def env8371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8402,4605,262144,524288,8692,2097152,373,525805,34,8329,5920,262257,4525,4177,2265,530328,248,525568,249,2103136,1020]

theorem envBound8371 : H12AffineFastState.Bounded env8371 := by
  intro p hp
  have h : env8371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8361_8371 : H12AffineEnvironment.transform 13 17 env8361 = env8371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8361 == env8371) = true)

theorem identity8371 : scanCanonicalize (H12AffineFastState.compose env8371 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5201) := by decide +kernel

theorem selectedBound8371 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env8372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8402,4605,262144,5201,8692,2097152,373,4540,34,8329,5920,262257,4525,4177,2265,969,248,4433,249,2103136,1020]

theorem envBound8372 : H12AffineFastState.Bounded env8372 := by
  intro p hp
  have h : env8372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8371_8372 : H12AffineEnvironment.transform 18 5201 env8371 = env8372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5201 env8371 == env8372) = true)

def env8373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,16777216,8329,79858,278625,4524,4176,16795883,17307578,16777435,525568,16793803,2119536,16778206]

theorem envBound8373 : H12AffineFastState.Bounded env8373 := by
  intro p hp
  have h : env8373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8321_8373 : H12AffineEnvironment.transform 26 278625 env8321 = env8373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278625 env8321 == env8373) = true)

def env8374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,90336,8329,79858,278625,4524,4176,75787,620378,90171,525568,73771,2119536,90942]

theorem envBound8374 : H12AffineFastState.Bounded env8374 := by
  intro p hp
  have h : env8374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8373_8374 : H12AffineEnvironment.transform 23 90336 env8373 = env8374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8373 == env8374) = true)

theorem identity8374 : scanCanonicalize (H12AffineFastState.compose env8374 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8374 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24770,4605,262144,524288,8692,2097152,16740,525805,34,8329,22320,278625,4524,4176,18633,530328,249,525568,16617,2119536,1020]

theorem envBound8375 : H12AffineFastState.Bounded env8375 := by
  intro p hp
  have h : env8375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8374_8375 : H12AffineEnvironment.transform 15 24770 env8374 = env8375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8374 == env8375) = true)

def env8376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8402,4605,262144,524288,8692,2097152,372,525805,34,8329,5920,262257,4524,4176,2265,530328,249,525568,249,2103136,1020]

theorem envBound8376 : H12AffineFastState.Bounded env8376 := by
  intro p hp
  have h : env8376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8375_8376 : H12AffineEnvironment.transform 13 16 env8375 = env8376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8375 == env8376) = true)

theorem identity8376 : scanCanonicalize (H12AffineFastState.compose env8376 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8376 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8377 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8402,4097,262144,524288,8200,2097152,136,525329,34,8329,5852,262257,4176,4176,2265,530020,249,525564,249,2102940,512]

theorem envBound8377 : H12AffineFastState.Bounded env8377 := by
  intro p hp
  have h : env8377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8376_8377 : H12AffineEnvironment.transform 7 252 env8376 = env8377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8376 == env8377) = true)

theorem identity8377 : scanCanonicalize (H12AffineFastState.compose env8377 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529037) := by decide +kernel

theorem selectedBound8377 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8378 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8402,4097,262144,524288,8200,529037,136,525329,34,8329,5852,262257,4176,4176,2265,530020,249,525564,249,525329,512]

theorem envBound8378 : H12AffineFastState.Bounded env8378 := by
  intro p hp
  have h : env8378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8377_8378 : H12AffineEnvironment.transform 20 529037 env8377 = env8378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529037 env8377 == env8378) = true)

theorem identity8378 : scanCanonicalize (H12AffineFastState.compose env8378 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4661) := by decide +kernel

theorem selectedBound8378 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8379 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8200,8402,4097,262144,4661,8200,184,136,5668,34,8329,5852,262257,4176,4176,2265,1105,249,5833,249,5668,512]

theorem envBound8379 : H12AffineFastState.Bounded env8379 := by
  intro p hp
  have h : env8379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8378_8379 : H12AffineEnvironment.transform 18 4661 env8378 = env8379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4661 env8378 == env8379) = true)

theorem identity8379 : scanCanonicalize (H12AffineFastState.compose env8379 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound8379 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8380 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,16,2275,2105,4097,262144,4661,2275,184,136,5668,34,2146,5852,262257,4176,4176,2265,1105,249,5833,249,5668,512]

theorem envBound8380 : H12AffineFastState.Bounded env8380 := by
  intro p hp
  have h : env8380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8379_8380 : H12AffineEnvironment.transform 12 2283 env8379 = env8380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env8379 == env8380) = true)

theorem identity8380 : scanCanonicalize (H12AffineFastState.compose env8380 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 1190) := by decide +kernel

theorem selectedBound8380 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8381 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,16,2275,2105,4097,1190,4661,2275,184,136,5668,34,2146,5852,1239,4176,4176,2265,1105,249,5833,249,5668,512]

theorem envBound8381 : H12AffineFastState.Bounded env8381 := by
  intro p hp
  have h : env8381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8380_8381 : H12AffineEnvironment.transform 17 1190 env8380 = env8381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1190 env8380 == env8381) = true)

theorem identity8381 : scanCanonicalize (H12AffineFastState.compose env8381 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8381 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env8382 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2283,16,2275,2105,4097,162,4661,2275,184,136,4640,34,2146,4824,211,4176,4176,2265,85,249,4813,249,4640,512]

theorem envBound8382 : H12AffineFastState.Bounded env8382 := by
  intro p hp
  have h : env8382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8381_8382 : H12AffineEnvironment.transform 9 4 env8381 = env8382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8381 == env8382) = true)

theorem identity8382 : scanCanonicalize (H12AffineFastState.compose env8382 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2738) := by decide +kernel

theorem selectedBound8382 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8383 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2738,2283,16,2275,2105,2739,162,2183,2275,184,136,2194,34,2146,2154,211,2786,2786,2265,85,249,2175,249,2194,512]

theorem envBound8383 : H12AffineFastState.Bounded env8383 := by
  intro p hp
  have h : env8383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8382_8383 : H12AffineEnvironment.transform 11 2738 env8382 = env8383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2738 env8382 == env8383) = true)

theorem identity8383 : scanCanonicalize (H12AffineFastState.compose env8383 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 200) := by decide +kernel

theorem selectedBound8383 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8384 : List Nat := [2,4,8,16,32,64,128,252,200,4,2048,2170,2283,16,2275,2105,2171,162,2183,2275,184,136,2194,34,2146,2154,211,2090,2090,2265,85,249,2175,249,2194,200]

theorem envBound8384 : H12AffineFastState.Bounded env8384 := by
  intro p hp
  have h : env8384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8383_8384 : H12AffineEnvironment.transform 8 200 env8383 = env8384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 200 env8383 == env8384) = true)

theorem identity8384 : scanCanonicalize (H12AffineFastState.compose env8384 (packedSelected [4,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound8384 : packedSelected [4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env8385 : List Nat := [2,4,8,16,32,64,128,252,200,4,10,112,225,16,233,51,113,162,141,233,184,136,152,34,104,96,211,32,32,211,85,249,117,249,152,200]

theorem envBound8385 : H12AffineFastState.Bounded env8385 := by
  intro p hp
  have h : env8385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8384_8385 : H12AffineEnvironment.transform 10 10 env8384 = env8385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env8384 == env8385) = true)

def env8386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8403,4605,262144,524288,8692,2097152,373,525805,34,8329,5921,262256,4524,4176,2264,530328,249,525568,248,2103137,1020]

theorem envBound8386 : H12AffineFastState.Bounded env8386 := by
  intro p hp
  have h : env8386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8375_8386 : H12AffineEnvironment.transform 13 17 env8375 = env8386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8375 == env8386) = true)

theorem identity8386 : scanCanonicalize (H12AffineFastState.compose env8386 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5200) := by decide +kernel

theorem selectedBound8386 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env8387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8403,4605,262144,5200,8692,2097152,373,4541,34,8329,5921,262256,4524,4176,2264,968,249,4432,248,2103137,1020]

theorem envBound8387 : H12AffineFastState.Bounded env8387 := by
  intro p hp
  have h : env8387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8386_8387 : H12AffineEnvironment.transform 18 5200 env8386 = env8387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5200 env8386 == env8387) = true)

def env8388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16740,525805,90337,8329,79858,278625,4524,4176,75786,620379,90170,525568,73770,2119536,90943]

theorem envBound8388 : H12AffineFastState.Bounded env8388 := by
  intro p hp
  have h : env8388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8373_8388 : H12AffineEnvironment.transform 23 90337 env8373 = env8388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8373 == env8388) = true)

theorem identity8388 : scanCanonicalize (H12AffineFastState.compose env8388 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8388 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8389 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16536,525329,90337,8329,79374,278625,4176,4176,75786,620199,90170,525564,73770,2119308,90819]

theorem envBound8389 : H12AffineFastState.Bounded env8389 := by
  intro p hp
  have h : env8389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8388_8389 : H12AffineEnvironment.transform 7 252 env8388 = env8389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8388 == env8389) = true)

def env8390 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16480,525329,90137,8305,79374,278625,4176,4176,75786,620127,90170,525316,73770,2119284,90683]

theorem envBound8390 : H12AffineFastState.Bounded env8390 := by
  intro p hp
  have h : env8390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8389_8390 : H12AffineEnvironment.transform 6 120 env8389 = env8390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8389 == env8390) = true)

theorem identity8390 : scanCanonicalize (H12AffineFastState.compose env8390 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545381) := by decide +kernel

theorem selectedBound8390 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8391 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545381,16480,525329,90137,8305,79374,278625,4176,4176,75786,620127,90170,525316,73770,525329,90683]

theorem envBound8391 : H12AffineFastState.Bounded env8391 := by
  intro p hp
  have h : env8391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8390_8391 : H12AffineEnvironment.transform 20 545381 env8390 = env8391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545381 env8390 == env8391) = true)

def env8392 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545333,16432,525329,90137,8225,79374,278577,4096,4096,75786,620047,90170,525316,73770,525329,90683]

theorem envBound8392 : H12AffineFastState.Bounded env8392 := by
  intro p hp
  have h : env8392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8391_8392 : H12AffineEnvironment.transform 5 16 env8391 = env8392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8391 == env8392) = true)

theorem identity8392 : scanCanonicalize (H12AffineFastState.compose env8392 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound8392 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8393 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,524288,8200,545333,16432,525329,90137,8225,79374,24100,4096,4096,75786,620047,90170,525316,73770,525329,90683]

theorem envBound8393 : H12AffineFastState.Bounded env8393 := by
  intro p hp
  have h : env8393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8392_8393 : H12AffineEnvironment.transform 17 7701 env8392 = env8393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env8392 == env8393) = true)

theorem identity8393 : scanCanonicalize (H12AffineFastState.compose env8393 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78367) := by decide +kernel

theorem selectedBound8393 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8394 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78367,8200,90154,16432,79374,90137,8225,79374,24100,4096,4096,75786,17424,90170,79387,73770,79374,90683]

theorem envBound8394 : H12AffineFastState.Bounded env8394 := by
  intro p hp
  have h : env8394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8393_8394 : H12AffineEnvironment.transform 18 78367 env8393 = env8394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78367 env8393 == env8394) = true)

theorem identity8394 : scanCanonicalize (H12AffineFastState.compose env8394 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound8394 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env8395 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,17,8200,65536,4097,7701,78367,8200,73787,33,79374,73736,8225,79374,7733,4096,4096,75786,1025,73771,79387,73770,79374,74282]

theorem envBound8395 : H12AffineFastState.Bounded env8395 := by
  intro p hp
  have h : env8395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8394_8395 : H12AffineEnvironment.transform 13 17 env8394 = env8395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8394 == env8395) = true)

theorem identity8395 : scanCanonicalize (H12AffineFastState.compose env8395 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound8395 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8396 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,8192,17,8200,65536,4097,5668,78367,8200,73787,33,79374,73736,8225,79374,5636,4096,4096,73787,1025,73771,79387,73770,79374,74282]

theorem envBound8396 : H12AffineFastState.Bounded env8396 := by
  intro p hp
  have h : env8396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8395_8396 : H12AffineEnvironment.transform 10 49 env8395 = env8396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env8395 == env8396) = true)

theorem identity8396 : scanCanonicalize (H12AffineFastState.compose env8396 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8396 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8397 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,25,17,17,65536,4097,5668,70150,17,65570,33,71191,65553,56,71191,5636,4096,4096,65570,1025,65586,71170,65587,71191,66099]

theorem envBound8397 : H12AffineFastState.Bounded env8397 := by
  intro p hp
  have h : env8397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8396_8397 : H12AffineEnvironment.transform 12 25 env8396 = env8397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8396 == env8397) = true)

theorem identity8397 : scanCanonicalize (H12AffineFastState.compose env8397 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 1542) := by decide +kernel

theorem selectedBound8397 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8398 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,25,17,17,1542,4097,5668,5120,17,1572,33,4113,1559,56,4113,5636,4096,4096,1572,1025,1588,4100,1589,4113,1077]

theorem envBound8398 : H12AffineFastState.Bounded env8398 := by
  intro p hp
  have h : env8398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8397_8398 : H12AffineEnvironment.transform 15 1542 env8397 = env8398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1542 env8397 == env8398) = true)

theorem identity8398 : scanCanonicalize (H12AffineFastState.compose env8398 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound8398 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8399 : List Nat := [2,4,8,16,32,16,40,4,512,565,49,4096,25,17,17,51,4097,4113,4661,17,17,33,4113,34,56,4113,4145,4096,4096,17,564,1,4100,0,4113,512]

theorem envBound8399 : H12AffineFastState.Bounded env8399 := by
  intro p hp
  have h : env8399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8398_8399 : H12AffineEnvironment.transform 9 565 env8398 = env8399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env8398 == env8399) = true)

theorem identity8399 : scanCanonicalize (H12AffineFastState.compose env8399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8400 : List Nat := [2,4,8,16,10,16,2,4,512,543,27,4096,25,17,17,25,4097,4113,4639,17,17,11,4113,8,18,4113,4123,4096,4096,17,542,1,4100,0,4113,512]

theorem envBound8400 : H12AffineFastState.Bounded env8400 := by
  intro p hp
  have h : env8400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8399_8400 : H12AffineEnvironment.transform 4 10 env8399 = env8400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8399 == env8400) = true)

theorem identity8400 : scanCanonicalize (H12AffineFastState.compose env8400 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound8400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8401 : List Nat := [2,4,8,16,10,16,2,4,512,543,27,1,25,17,17,25,0,16,542,17,17,11,16,8,18,16,26,1,1,17,542,1,5,0,16,512]

theorem envBound8401 : H12AffineFastState.Bounded env8401 := by
  intro p hp
  have h : env8401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8400_8401 : H12AffineEnvironment.transform 11 1 env8400 = env8401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env8400 == env8401) = true)

theorem identity8401 : scanCanonicalize (H12AffineFastState.compose env8401 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound8401 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8402 : List Nat := [2,4,8,16,10,16,2,4,16,15,27,1,25,17,17,25,0,16,14,17,17,11,16,8,18,16,26,1,1,17,14,1,5,0,16,16]

theorem envBound8402 : H12AffineFastState.Bounded env8402 := by
  intro p hp
  have h : env8402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8401_8402 : H12AffineEnvironment.transform 8 16 env8401 = env8402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env8401 == env8402) = true)

theorem identity8402 : scanCanonicalize (H12AffineFastState.compose env8402 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8403 : List Nat := [2,4,3,16,1,16,2,4,16,4,16,1,18,17,17,18,0,16,5,17,17,0,16,3,18,16,17,1,1,17,5,1,5,0,16,16]

theorem envBound8403 : H12AffineFastState.Bounded env8403 := by
  intro p hp
  have h : env8403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8402_8403 : H12AffineEnvironment.transform 2 3 env8402 = env8403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8402 == env8403) = true)

def env8404 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545332,16433,525329,90137,8224,79374,278576,4097,4097,75786,620046,90170,525316,73770,525329,90683]

theorem envBound8404 : H12AffineFastState.Bounded env8404 := by
  intro p hp
  have h : env8404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8391_8404 : H12AffineEnvironment.transform 5 17 env8391 = env8404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8391 == env8404) = true)

theorem identity8404 : scanCanonicalize (H12AffineFastState.compose env8404 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338955) := by decide +kernel

theorem selectedBound8404 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8405 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,338955,8200,359999,16433,337946,90137,8224,79374,278576,4097,4097,75786,285189,90170,337935,73770,337946,90683]

theorem envBound8405 : H12AffineFastState.Bounded env8405 := by
  intro p hp
  have h : env8405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8404_8405 : H12AffineEnvironment.transform 18 338955 env8404 = env8405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338955 env8404 == env8405) = true)

theorem identity8405 : scanCanonicalize (H12AffineFastState.compose env8405 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24068) := by decide +kernel

theorem selectedBound8405 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8406 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,24068,94735,8200,73787,16433,95774,90137,8224,79374,7732,4097,4097,75786,1025,90170,95755,73770,95774,90683]

theorem envBound8406 : H12AffineFastState.Bounded env8406 := by
  intro p hp
  have h : env8406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8405_8406 : H12AffineEnvironment.transform 17 24068 env8405 = env8406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24068 env8405 == env8406) = true)

def env8407 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16481,525329,90136,8304,79374,278625,4176,4176,75786,620126,90170,525317,73770,2119285,90682]

theorem envBound8407 : H12AffineFastState.Bounded env8407 := by
  intro p hp
  have h : env8407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8389_8407 : H12AffineEnvironment.transform 6 121 env8389 = env8407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8389 == env8407) = true)

theorem identity8407 : scanCanonicalize (H12AffineFastState.compose env8407 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619087) := by decide +kernel

theorem selectedBound8407 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8408 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619087,16481,525329,90136,8304,79374,278625,4176,4176,75786,620126,90170,525317,73770,599098,90682]

theorem envBound8408 : H12AffineFastState.Bounded env8408 := by
  intro p hp
  have h : env8408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8407_8408 : H12AffineEnvironment.transform 20 619087 env8407 = env8408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619087 env8407 == env8408) = true)

def env8409 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619039,16433,525329,90136,8224,79374,278577,4096,4096,75786,620046,90170,525317,73770,599098,90682]

theorem envBound8409 : H12AffineFastState.Bounded env8409 := by
  intro p hp
  have h : env8409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8408_8409 : H12AffineEnvironment.transform 5 16 env8408 = env8409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8408 == env8409) = true)

theorem identity8409 : scanCanonicalize (H12AffineFastState.compose env8409 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound8409 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8410 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,524288,8200,619039,16433,525329,90136,8224,79374,81439,4096,4096,75786,620046,90170,525317,73770,599098,90682]

theorem envBound8410 : H12AffineFastState.Bounded env8410 := by
  intro p hp
  have h : env8410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8409_8410 : H12AffineEnvironment.transform 17 97838 env8409 = env8410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env8409 == env8410) = true)

theorem identity8410 : scanCanonicalize (H12AffineFastState.compose env8410 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94734) := by decide +kernel

theorem selectedBound8410 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8411 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,94734,8200,17,16433,95775,90136,8224,79374,81439,4096,4096,75786,1024,90170,95755,73770,22068,90682]

theorem envBound8411 : H12AffineFastState.Bounded env8411 := by
  intro p hp
  have h : env8411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8410_8411 : H12AffineEnvironment.transform 18 94734 env8410 = env8411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94734 env8410 == env8411) = true)

theorem identity8411 : scanCanonicalize (H12AffineFastState.compose env8411 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound8411 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8412 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,24634,4097,7700,4660,8200,17,16433,5669,34,8224,22068,24101,4096,4096,18480,1024,0,5681,16400,22068,512]

theorem envBound8412 : H12AffineFastState.Bounded env8412 := by
  intro p hp
  have h : env8412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8411_8412 : H12AffineEnvironment.transform 15 24634 env8411 = env8412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env8411 == env8412) = true)

theorem identity8412 : scanCanonicalize (H12AffineFastState.compose env8412 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 7214) := by decide +kernel

theorem selectedBound8412 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8413 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,7214,8200,15380,4097,7700,4660,8200,17,7199,5669,34,8224,2586,523,4096,4096,5150,1024,0,5681,7230,2586,512]

theorem envBound8413 : H12AffineFastState.Bounded env8413 := by
  intro p hp
  have h : env8413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8412_8413 : H12AffineEnvironment.transform 13 7214 env8412 = env8413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7214 env8412 == env8413) = true)

theorem identity8413 : scanCanonicalize (H12AffineFastState.compose env8413 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound8413 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8414 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3135,8192,17,8200,8235,3134,555,3595,8200,17,32,2586,34,8224,2586,523,3135,3135,2081,1024,0,2574,1,2586,512]

theorem envBound8414 : H12AffineFastState.Bounded env8414 := by
  intro p hp
  have h : env8414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8413_8414 : H12AffineEnvironment.transform 11 3135 env8413 = env8414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env8413 == env8414) = true)

theorem identity8414 : scanCanonicalize (H12AffineFastState.compose env8414 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound8414 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8415 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3135,1062,17,1070,1037,3134,555,3595,1070,17,32,2586,34,1030,2586,523,3135,3135,2081,1024,0,2574,1,2586,512]

theorem envBound8415 : H12AffineFastState.Bounded env8415 := by
  intro p hp
  have h : env8415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8414_8415 : H12AffineEnvironment.transform 12 1062 env8414 = env8415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env8414 == env8415) = true)

theorem identity8415 : scanCanonicalize (H12AffineFastState.compose env8415 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8415 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8416 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3103,1030,17,1038,1037,3102,523,3595,1038,17,0,2586,2,1030,2586,523,3103,3103,2049,1024,0,2574,1,2586,512]

theorem envBound8416 : H12AffineFastState.Bounded env8416 := by
  intro p hp
  have h : env8416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8415_8416 : H12AffineEnvironment.transform 4 0 env8415 = env8416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8415 == env8416) = true)

theorem identity8416 : scanCanonicalize (H12AffineFastState.compose env8416 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound8416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8417 : List Nat := [2,4,8,16,0,16,9,5,512,14,2048,2065,8,17,0,3,2064,523,2565,0,17,0,2586,2,8,2586,523,2065,2065,2049,14,0,2574,1,2586,512]

theorem envBound8417 : H12AffineFastState.Bounded env8417 := by
  intro p hp
  have h : env8417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8416_8417 : H12AffineEnvironment.transform 9 14 env8416 = env8417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env8416 == env8417) = true)

theorem identity8417 : scanCanonicalize (H12AffineFastState.compose env8417 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound8417 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env8418 : List Nat := [2,4,8,16,0,16,9,5,512,14,11,26,8,17,0,3,27,523,526,0,17,0,529,2,8,529,523,26,26,10,14,0,517,1,529,512]

theorem envBound8418 : H12AffineFastState.Bounded env8418 := by
  intro p hp
  have h : env8418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8417_8418 : H12AffineEnvironment.transform 10 11 env8417 = env8418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env8417 == env8418) = true)

theorem identity8418 : scanCanonicalize (H12AffineFastState.compose env8418 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound8418 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8419 : List Nat := [2,4,8,16,0,16,9,5,1,14,11,26,8,17,0,3,27,10,15,0,17,0,16,2,8,16,10,26,26,10,14,0,4,1,16,1]

theorem envBound8419 : H12AffineFastState.Bounded env8419 := by
  intro p hp
  have h : env8419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8418_8419 : H12AffineEnvironment.transform 8 1 env8418 = env8419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env8418 == env8419) = true)

theorem identity8419 : scanCanonicalize (H12AffineFastState.compose env8419 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8419 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8420 : List Nat := [2,4,8,11,0,11,9,5,1,14,11,1,8,10,0,3,0,10,15,0,10,0,11,2,8,11,10,1,1,10,14,0,4,1,11,1]

theorem envBound8420 : H12AffineFastState.Bounded env8420 := by
  intro p hp
  have h : env8420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8419_8420 : H12AffineEnvironment.transform 3 11 env8419 = env8420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8419 == env8420) = true)

def env8421 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619038,16432,525329,90136,8225,79374,278576,4097,4097,75786,620047,90170,525317,73770,599098,90682]

theorem envBound8421 : H12AffineFastState.Bounded env8421 := by
  intro p hp
  have h : env8421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8408_8421 : H12AffineEnvironment.transform 5 17 env8408 = env8421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8408 == env8421) = true)

theorem identity8421 : scanCanonicalize (H12AffineFastState.compose env8421 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281649) := by decide +kernel

theorem selectedBound8421 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8422 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,281649,8200,343599,16432,280608,90136,8225,79374,278576,4097,4097,75786,342590,90170,280628,73770,354315,90682]

theorem envBound8422 : H12AffineFastState.Bounded env8422 := by
  intro p hp
  have h : env8422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8421_8422 : H12AffineEnvironment.transform 18 281649 env8421 = env8422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281649 env8421 == env8422) = true)

theorem identity8422 : scanCanonicalize (H12AffineFastState.compose env8422 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound8422 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8423 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,78366,8200,16384,16432,79375,90136,8225,79374,81439,4097,4097,75786,17425,90170,79387,73770,5668,90682]

theorem envBound8423 : H12AffineFastState.Bounded env8423 := by
  intro p hp
  have h : env8423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8422_8423 : H12AffineEnvironment.transform 17 97839 env8422 = env8423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env8422 == env8423) = true)

def env8424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79858,134217728,134500812,134500400,151259274,17307578,151273659,525568,151257258,136582929,16778206]

theorem envBound8424 : H12AffineFastState.Bounded env8424 := by
  intro p hp
  have h : env8424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8320_8424 : H12AffineEnvironment.transform 21 16741 env8320 = env8424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16741 env8320 == env8424) = true)

def env8425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79858,278624,4524,4176,16795882,17307578,16777435,525568,16793802,2119537,16778206]

theorem envBound8425 : H12AffineFastState.Bounded env8425 := by
  intro p hp
  have h : env8425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8424_8425 : H12AffineEnvironment.transform 26 278624 env8424 = env8425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278624 env8424 == env8425) = true)

def env8426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,90336,8329,79858,278624,4524,4176,75786,620378,90171,525568,73770,2119537,90942]

theorem envBound8426 : H12AffineFastState.Bounded env8426 := by
  intro p hp
  have h : env8426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8425_8426 : H12AffineEnvironment.transform 23 90336 env8425 = env8426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8425 == env8426) = true)

theorem identity8426 : scanCanonicalize (H12AffineFastState.compose env8426 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8426 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8427 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16537,525329,90336,8329,79374,278624,4176,4176,75786,620198,90171,525564,73770,2119309,90818]

theorem envBound8427 : H12AffineFastState.Bounded env8427 := by
  intro p hp
  have h : env8427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8426_8427 : H12AffineEnvironment.transform 7 252 env8426 = env8427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8426 == env8427) = true)

def env8428 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16481,525329,90136,8305,79374,278624,4176,4176,75786,620126,90171,525316,73770,2119285,90682]

theorem envBound8428 : H12AffineFastState.Bounded env8428 := by
  intro p hp
  have h : env8428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8427_8428 : H12AffineEnvironment.transform 6 120 env8427 = env8428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8427 == env8428) = true)

theorem identity8428 : scanCanonicalize (H12AffineFastState.compose env8428 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545381) := by decide +kernel

theorem selectedBound8428 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8429 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545381,16481,525329,90136,8305,79374,278624,4176,4176,75786,620126,90171,525316,73770,525328,90682]

theorem envBound8429 : H12AffineFastState.Bounded env8429 := by
  intro p hp
  have h : env8429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8428_8429 : H12AffineEnvironment.transform 20 545381 env8428 = env8429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545381 env8428 == env8429) = true)

def env8430 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545333,16433,525329,90136,8225,79374,278576,4096,4096,75786,620046,90171,525316,73770,525328,90682]

theorem envBound8430 : H12AffineFastState.Bounded env8430 := by
  intro p hp
  have h : env8430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8429_8430 : H12AffineEnvironment.transform 5 16 env8429 = env8430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8429 == env8430) = true)

theorem identity8430 : scanCanonicalize (H12AffineFastState.compose env8430 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound8430 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8431 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,524288,8200,545333,16433,525329,90136,8225,79374,24101,4096,4096,75786,620046,90171,525316,73770,525328,90682]

theorem envBound8431 : H12AffineFastState.Bounded env8431 := by
  intro p hp
  have h : env8431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8430_8431 : H12AffineEnvironment.transform 17 7701 env8430 = env8431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env8430 == env8431) = true)

theorem identity8431 : scanCanonicalize (H12AffineFastState.compose env8431 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78367) := by decide +kernel

theorem selectedBound8431 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8432 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78367,8200,90154,16433,79374,90136,8225,79374,24101,4096,4096,75786,17425,90171,79387,73770,79375,90682]

theorem envBound8432 : H12AffineFastState.Bounded env8432 := by
  intro p hp
  have h : env8432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8431_8432 : H12AffineEnvironment.transform 18 78367 env8431 = env8432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78367 env8431 == env8432) = true)

theorem identity8432 : scanCanonicalize (H12AffineFastState.compose env8432 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8432 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env8433 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16,8200,65536,4097,7701,78367,8200,73786,33,79374,73736,8225,79374,7733,4096,4096,75786,1025,73771,79387,73770,79375,74282]

theorem envBound8433 : H12AffineFastState.Bounded env8433 := by
  intro p hp
  have h : env8433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8432_8433 : H12AffineEnvironment.transform 13 16 env8432 = env8433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8432 == env8433) = true)

theorem identity8433 : scanCanonicalize (H12AffineFastState.compose env8433 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound8433 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8434 : List Nat := [2,4,8,16,32,16,40,4,512,1024,48,4096,8192,16,8200,65536,4097,5669,78367,8200,73786,33,79374,73736,8225,79374,5637,4096,4096,73786,1025,73771,79387,73770,79375,74282]

theorem envBound8434 : H12AffineFastState.Bounded env8434 := by
  intro p hp
  have h : env8434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8433_8434 : H12AffineEnvironment.transform 10 48 env8433 = env8434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env8433 == env8434) = true)

theorem identity8434 : scanCanonicalize (H12AffineFastState.compose env8434 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8434 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8435 : List Nat := [2,4,8,16,32,16,40,4,512,1024,48,4096,24,16,16,65536,4097,5669,70151,16,65570,33,71190,65552,57,71190,5637,4096,4096,65570,1025,65587,71171,65586,71191,66098]

theorem envBound8435 : H12AffineFastState.Bounded env8435 := by
  intro p hp
  have h : env8435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8434_8435 : H12AffineEnvironment.transform 12 24 env8434 = env8435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8434 == env8435) = true)

theorem identity8435 : scanCanonicalize (H12AffineFastState.compose env8435 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound8435 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8436 : List Nat := [2,4,8,16,32,16,40,4,512,565,48,4096,24,16,16,65536,4097,4112,70151,16,65570,33,69667,65552,57,69667,4144,4096,4096,65570,564,65587,69686,65586,69666,66098]

theorem envBound8436 : H12AffineFastState.Bounded env8436 := by
  intro p hp
  have h : env8436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8435_8436 : H12AffineEnvironment.transform 9 565 env8435 = env8436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env8435 == env8436) = true)

theorem identity8436 : scanCanonicalize (H12AffineFastState.compose env8436 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound8436 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8437 : List Nat := [2,4,8,16,32,16,40,4,512,565,48,4096,24,16,16,50,4097,4112,4661,16,16,33,4113,34,57,4113,4144,4096,4096,16,564,1,4100,0,4112,512]

theorem envBound8437 : H12AffineFastState.Bounded env8437 := by
  intro p hp
  have h : env8437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8436_8437 : H12AffineEnvironment.transform 15 50 env8436 = env8437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env8436 == env8437) = true)

theorem identity8437 : scanCanonicalize (H12AffineFastState.compose env8437 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8438 : List Nat := [2,4,8,16,11,16,3,4,512,542,27,4096,24,16,16,25,4097,4112,4638,16,16,10,4113,9,18,4113,4123,4096,4096,16,543,1,4100,0,4112,512]

theorem envBound8438 : H12AffineFastState.Bounded env8438 := by
  intro p hp
  have h : env8438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8437_8438 : H12AffineEnvironment.transform 4 11 env8437 = env8438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8437 == env8438) = true)

theorem identity8438 : scanCanonicalize (H12AffineFastState.compose env8438 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound8438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8439 : List Nat := [2,4,8,16,11,16,3,4,512,542,27,1,24,16,16,25,0,17,543,16,16,10,16,9,18,16,26,1,1,16,543,1,5,0,17,512]

theorem envBound8439 : H12AffineFastState.Bounded env8439 := by
  intro p hp
  have h : env8439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8438_8439 : H12AffineEnvironment.transform 11 1 env8438 = env8439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env8438 == env8439) = true)

theorem identity8439 : scanCanonicalize (H12AffineFastState.compose env8439 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound8439 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8440 : List Nat := [2,4,8,16,11,16,3,4,17,15,27,1,24,16,16,25,0,17,14,16,16,10,16,9,18,16,26,1,1,16,14,1,5,0,17,17]

theorem envBound8440 : H12AffineFastState.Bounded env8440 := by
  intro p hp
  have h : env8440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8439_8440 : H12AffineEnvironment.transform 8 17 env8439 = env8440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env8439 == env8440) = true)

theorem identity8440 : scanCanonicalize (H12AffineFastState.compose env8440 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8441 : List Nat := [2,4,2,16,1,16,3,4,17,5,17,1,18,16,16,19,0,17,4,16,16,0,16,3,18,16,16,1,1,16,4,1,5,0,17,17]

end H12CloudChart0