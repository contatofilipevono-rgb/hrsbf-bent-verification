import H12CloudChart0Data051

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans13035_13036 : H12AffineEnvironment.transform 3 1 env13035 = env13036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13035 == env13036) = true)

def env13037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,121943,115151,17665,2404756,119042,329731,257,2199998,2191387,63189]

theorem envBound13037 : H12AffineFastState.Bounded env13037 := by
  intro p hp
  have h : env13037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12986_13037 : H12AffineEnvironment.transform 21 272513 env12986 = env13037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12986 == env13037) = true)

theorem identity13037 : scanCanonicalize (H12AffineFastState.compose env13037 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound13037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,272513,17,21762,8328,64,121943,115151,17665,303572,119042,329731,257,98814,90203,63189]

theorem envBound13038 : H12AffineFastState.Bounded env13038 := by
  intro p hp
  have h : env13038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13037_13038 : H12AffineEnvironment.transform 20 4160 env13037 = env13038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13037 == env13038) = true)

def env13039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272393,17,21762,8192,64,121943,115015,17665,303452,119042,329731,257,98678,90203,63069]

theorem envBound13039 : H12AffineFastState.Bounded env13039 := by
  intro p hp
  have h : env13039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13038_13039 : H12AffineEnvironment.transform 6 8 env13038 = env13039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13038 == env13039) = true)

theorem identity13039 : scanCanonicalize (H12AffineFastState.compose env13039 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound13039 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4160,21793,17,21762,8192,64,121943,115015,17665,56436,119042,95531,257,98678,90203,63069]

theorem envBound13040 : H12AffineFastState.Bounded env13040 := by
  intro p hp
  have h : env13040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13039_13040 : H12AffineEnvironment.transform 17 32040 env13039 = env13040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env13039 == env13040) = true)

theorem identity13040 : scanCanonicalize (H12AffineFastState.compose env13040 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13040 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,24909,32040,1025,32769,4160,21793,17,21762,8192,64,56577,49169,17665,56436,53332,29821,257,32800,24845,63069]

theorem envBound13041 : H12AffineFastState.Bounded env13041 := by
  intro p hp
  have h : env13041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13040_13041 : H12AffineEnvironment.transform 15 342 env13040 = env13041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13040 == env13041) = true)

theorem identity13041 : scanCanonicalize (H12AffineFastState.compose env13041 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13041 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,24909,32040,1025,1,4160,21793,17,21762,8192,64,23809,16401,17665,23668,20564,29821,257,32,24845,30301]

theorem envBound13042 : H12AffineFastState.Bounded env13042 := by
  intro p hp
  have h : env13042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13041_13042 : H12AffineEnvironment.transform 14 0 env13041 = env13042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13041 == env13042) = true)

def env13043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272392,17,21762,8193,64,121943,115014,17665,303453,119042,329731,257,98679,90203,63068]

theorem envBound13043 : H12AffineFastState.Bounded env13043 := by
  intro p hp
  have h : env13043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13038_13043 : H12AffineEnvironment.transform 6 9 env13038 = env13043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13038 == env13043) = true)

theorem identity13043 : scanCanonicalize (H12AffineFastState.compose env13043 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound13043 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56437,1025,32769,4160,62589,17,21762,8193,64,121943,115014,17665,32040,119042,119926,257,98679,90203,63068]

theorem envBound13044 : H12AffineFastState.Bounded env13044 := by
  intro p hp
  have h : env13044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13043_13044 : H12AffineEnvironment.transform 17 56437 env13043 = env13044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env13043 == env13044) = true)

def env13045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound13045 : H12AffineFastState.Bounded env13045 := by
  intro p hp
  have h : env13045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12478_13045 : H12AffineEnvironment.transform 25 65 env12478 = env13045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env12478 == env13045) = true)

def env13046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound13046 : H12AffineFastState.Bounded env13046 := by
  intro p hp
  have h : env13046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13045_13046 : H12AffineEnvironment.transform 26 30393344 env13045 = env13046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env13045 == env13046) = true)

def env13047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound13047 : H12AffineFastState.Bounded env13047 := by
  intro p hp
  have h : env13047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13046_13047 : H12AffineEnvironment.transform 18 1024 env13046 = env13047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13046 == env13047) = true)

theorem identity13047 : scanCanonicalize (H12AffineFastState.compose env13047 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound13047 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403622,18973836,10507601,8497638,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound13048 : H12AffineFastState.Bounded env13048 := by
  intro p hp
  have h : env13048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13047_13048 : H12AffineEnvironment.transform 17 223718 env13047 = env13048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env13047 == env13048) = true)

def env13049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760058,5392,10507601,8497638,10491276,4256861,256,8410417,8434836,10564187]

theorem envBound13049 : H12AffineFastState.Bounded env13049 := by
  intro p hp
  have h : env13049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13048_13049 : H12AffineEnvironment.transform 23 2199964 env13048 = env13049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env13048 == env13049) = true)

def env13050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270122,5392,17665,2210230,1500,4256861,256,2114913,2139332,74251]

theorem envBound13050 : H12AffineFastState.Bounded env13050 := by
  intro p hp
  have h : env13050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13049_13050 : H12AffineEnvironment.transform 22 2101328 env13049 = env13050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env13049 == env13050) = true)

def env13051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,16,98780,8328,65,4270122,5392,17665,109046,1500,4256861,256,21793,46212,74251]

theorem envBound13051 : H12AffineFastState.Bounded env13051 := by
  intro p hp
  have h : env13051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13050_13051 : H12AffineEnvironment.transform 20 4160 env13050 = env13051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13050 == env13051) = true)

theorem identity13051 : scanCanonicalize (H12AffineFastState.compose env13051 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound13051 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179513,1024,32769,4160,4194304,16,21763,8328,65,4259061,5392,17665,32041,1500,4256861,256,21793,46212,63188]

theorem envBound13052 : H12AffineFastState.Bounded env13052 := by
  intro p hp
  have h : env13052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13051_13052 : H12AffineEnvironment.transform 15 54495 env13051 = env13052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env13051 == env13052) = true)

def env13053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4160,4194304,16,21763,8192,65,4258941,5392,17665,32041,1364,4256861,256,21793,46092,63068]

theorem envBound13053 : H12AffineFastState.Bounded env13053 := by
  intro p hp
  have h : env13053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13052_13053 : H12AffineEnvironment.transform 6 8 env13052 = env13053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13052 == env13053) = true)

theorem identity13053 : scanCanonicalize (H12AffineFastState.compose env13053 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound13053 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32041,1024,32769,4160,4194304,16,21763,8192,65,4258941,5392,17665,32041,1364,4256861,256,21793,46092,63068]

theorem envBound13054 : H12AffineFastState.Bounded env13054 := by
  intro p hp
  have h : env13054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13053_13054 : H12AffineEnvironment.transform 16 49168 env13053 = env13054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13053 == env13054) = true)

theorem identity13054 : scanCanonicalize (H12AffineFastState.compose env13054 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound13054 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32041,1024,32769,4160,32801,16,21763,8192,65,31836,5392,17665,32041,1364,29820,256,21793,46092,63068]

theorem envBound13055 : H12AffineFastState.Bounded env13055 := by
  intro p hp
  have h : env13055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13054_13055 : H12AffineEnvironment.transform 21 32801 env13054 = env13055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env13054 == env13055) = true)

theorem identity13055 : scanCanonicalize (H12AffineFastState.compose env13055 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13055 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,24908,32041,1024,8541,4160,8573,16,21763,8192,65,31836,5392,17665,32041,1364,29820,256,21793,5456,22272]

theorem envBound13056 : H12AffineFastState.Bounded env13056 := by
  intro p hp
  have h : env13056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13055_13056 : H12AffineEnvironment.transform 14 8540 env13055 = env13056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13055 == env13056) = true)

theorem identity13056 : scanCanonicalize (H12AffineFastState.compose env13056 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13056 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env13057 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,24908,30777,272,8541,4160,8573,16,20499,8192,65,31052,4096,16401,30777,68,29036,256,20529,4160,21008]

theorem envBound13057 : H12AffineFastState.Bounded env13057 := by
  intro p hp
  have h : env13057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13056_13057 : H12AffineEnvironment.transform 9 272 env13056 = env13057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13056 == env13057) = true)

theorem identity13057 : scanCanonicalize (H12AffineFastState.compose env13057 (packedSelected [2,3,4,5,6,9,11,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound13057 : packedSelected [2,3,4,5,6,9,11,15,19] rootPS < 2^1333 := by decide +kernel

def env13058 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6476,16384,6160,18775,22528,16757,272,6161,4160,6193,16,20499,6476,65,16384,4096,16401,16757,68,18464,256,20529,4160,21008]

theorem envBound13058 : H12AffineFastState.Bounded env13058 := by
  intro p hp
  have h : env13058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13057_13058 : H12AffineEnvironment.transform 12 6476 env13057 = env13058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env13057 == env13058) = true)

theorem identity13058 : scanCanonicalize (H12AffineFastState.compose env13058 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound13058 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env13059 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,4380,16384,4160,16647,20560,16757,272,4161,4160,4193,16,20499,4380,65,16384,4096,16401,16757,68,16496,256,20529,4160,21008]

theorem envBound13059 : H12AffineFastState.Bounded env13059 := by
  intro p hp
  have h : env13059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13058_13059 : H12AffineEnvironment.transform 10 80 env13058 = env13059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env13058 == env13059) = true)

theorem identity13059 : scanCanonicalize (H12AffineFastState.compose env13059 (packedSelected [0,1,2,3,5,6,7,8,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound13059 : packedSelected [0,1,2,3,5,6,7,8,15,20] rootPS < 2^1333 := by decide +kernel

def env13060 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,65,349,16384,1,16647,16401,16757,272,0,1,32,16,16466,349,65,16384,65,16401,16757,68,16496,256,16496,1,16977]

theorem envBound13060 : H12AffineFastState.Bounded env13060 := by
  intro p hp
  have h : env13060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13059_13060 : H12AffineEnvironment.transform 11 65 env13059 = env13060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env13059 == env13060) = true)

theorem identity13060 : scanCanonicalize (H12AffineFastState.compose env13060 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13060 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13061 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,17,269,16384,1,16647,16401,16677,272,0,1,32,16,16386,269,17,16384,17,16401,16677,20,16416,256,16416,1,16897]

theorem envBound13061 : H12AffineFastState.Bounded env13061 := by
  intro p hp
  have h : env13061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13060_13061 : H12AffineEnvironment.transform 5 16 env13060 = env13061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13060 == env13061) = true)

theorem identity13061 : scanCanonicalize (H12AffineFastState.compose env13061 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13061 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env13062 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,17,41,16384,1,16419,16401,16385,52,0,1,32,16,16386,41,17,16384,17,16401,16385,20,16416,36,16416,1,16897]

theorem envBound13062 : H12AffineFastState.Bounded env13062 := by
  intro p hp
  have h : env13062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13061_13062 : H12AffineEnvironment.transform 7 36 env13061 = env13062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13061 == env13062) = true)

theorem identity13062 : scanCanonicalize (H12AffineFastState.compose env13062 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13062 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13063 : List Nat := [2,4,8,16,32,16,8,36,49,52,0,17,41,16384,1,16419,16401,16385,52,0,1,32,16,16386,41,17,16384,17,16401,16385,20,16416,36,16416,1,16432]

theorem envBound13063 : H12AffineFastState.Bounded env13063 := by
  intro p hp
  have h : env13063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13062_13063 : H12AffineEnvironment.transform 8 49 env13062 = env13063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13062 == env13063) = true)

theorem identity13063 : scanCanonicalize (H12AffineFastState.compose env13063 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13063 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env13064 : List Nat := [2,4,8,16,1,16,8,5,16,21,0,17,8,16384,1,16386,16401,16385,21,0,1,1,16,16386,8,17,16384,17,16401,16385,20,16385,5,16385,1,16401]

theorem envBound13064 : H12AffineFastState.Bounded env13064 := by
  intro p hp
  have h : env13064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13063_13064 : H12AffineEnvironment.transform 4 1 env13063 = env13064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13063 == env13064) = true)

theorem identity13064 : scanCanonicalize (H12AffineFastState.compose env13064 (packedSelected [0,1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound13064 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env13065 : List Nat := [2,4,8,16,1,16,8,5,16,21,0,17,8,1,1,3,16,0,21,0,1,1,16,3,8,17,1,17,16,0,20,0,5,0,1,16]

theorem envBound13065 : H12AffineFastState.Bounded env13065 := by
  intro p hp
  have h : env13065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13064_13065 : H12AffineEnvironment.transform 13 1 env13064 = env13065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env13064 == env13065) = true)

def env13066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,4194304,16,21763,8193,65,4258940,5392,17665,32041,1365,4256861,256,21793,46093,63069]

theorem envBound13066 : H12AffineFastState.Bounded env13066 := by
  intro p hp
  have h : env13066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13052_13066 : H12AffineEnvironment.transform 6 9 env13052 = env13066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13052 == env13066) = true)

theorem identity13066 : scanCanonicalize (H12AffineFastState.compose env13066 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound13066 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,56436,1024,32769,4160,4194304,16,21763,8193,65,4258940,5392,17665,32041,1365,4256861,256,21793,46093,63069]

theorem envBound13067 : H12AffineFastState.Bounded env13067 := by
  intro p hp
  have h : env13067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13066_13067 : H12AffineEnvironment.transform 16 24909 env13066 = env13067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env13066 == env13067) = true)

theorem identity13067 : scanCanonicalize (H12AffineFastState.compose env13067 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound13067 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env13068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,24909,10280,1024,29789,4160,4194304,16,21763,8193,65,4196384,5392,17665,32041,1365,4194305,256,21793,16465,513]

theorem envBound13068 : H12AffineFastState.Bounded env13068 := by
  intro p hp
  have h : env13068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13067_13068 : H12AffineEnvironment.transform 14 29788 env13067 = env13068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env13067 == env13068) = true)

theorem identity13068 : scanCanonicalize (H12AffineFastState.compose env13068 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound13068 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,24909,10280,1024,29789,4160,8492,16,21763,8193,65,10508,5392,17665,32041,1365,8493,256,21793,16465,513]

theorem envBound13069 : H12AffineFastState.Bounded env13069 := by
  intro p hp
  have h : env13069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13068_13069 : H12AffineEnvironment.transform 21 8492 env13068 = env13069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env13068 == env13069) = true)

theorem identity13069 : scanCanonicalize (H12AffineFastState.compose env13069 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13069 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13070 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,24861,10280,1024,29709,4112,8492,16,21763,8193,17,10508,5392,17665,32041,1285,8493,256,21793,16385,513]

theorem envBound13070 : H12AffineFastState.Bounded env13070 := by
  intro p hp
  have h : env13070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13069_13070 : H12AffineEnvironment.transform 5 16 env13069 = env13070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13069 == env13070) = true)

theorem identity13070 : scanCanonicalize (H12AffineFastState.compose env13070 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13071 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,262,16401,2340,1024,21761,4112,32,16,21763,269,17,2048,5392,17665,23589,1285,33,256,21793,16385,513]

theorem envBound13071 : H12AffineFastState.Bounded env13071 := by
  intro p hp
  have h : env13071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13070_13071 : H12AffineEnvironment.transform 12 268 env13070 = env13071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13070 == env13071) = true)

theorem identity13071 : scanCanonicalize (H12AffineFastState.compose env13071 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 3636) := by decide +kernel

theorem selectedBound13071 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13072 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,3636,6964,262,3621,2340,1024,6965,4112,32,16,6967,269,17,2048,5392,2869,4625,1285,33,256,6933,3637,513]

theorem envBound13072 : H12AffineFastState.Bounded env13072 := by
  intro p hp
  have h : env13072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13071_13072 : H12AffineEnvironment.transform 13 3636 env13071 = env13072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3636 env13071 == env13072) = true)

theorem identity13072 : scanCanonicalize (H12AffineFastState.compose env13072 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound13072 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env13073 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1557,268,3636,3361,262,3621,2340,1024,3360,1541,32,16,3362,269,17,2048,773,2869,1028,1285,33,256,3328,3637,513]

theorem envBound13073 : H12AffineFastState.Bounded env13073 := by
  intro p hp
  have h : env13073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13072_13073 : H12AffineEnvironment.transform 11 1557 env13072 = env13073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env13072 == env13073) = true)

theorem identity13073 : scanCanonicalize (H12AffineFastState.compose env13073 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound13073 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env13074 : List Nat := [2,4,8,16,32,16,9,256,512,1024,512,1557,268,1076,1825,262,1061,804,1024,1824,1541,32,16,1826,269,17,512,773,309,1028,1285,33,256,1792,1077,513]

theorem envBound13074 : H12AffineFastState.Bounded env13074 := by
  intro p hp
  have h : env13074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13073_13074 : H12AffineEnvironment.transform 10 512 env13073 = env13074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env13073 == env13074) = true)

theorem identity13074 : scanCanonicalize (H12AffineFastState.compose env13074 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13074 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env13075 : List Nat := [2,4,8,16,32,16,9,256,512,21,512,512,268,33,820,262,48,804,21,821,528,32,16,823,269,17,512,773,309,17,272,33,256,789,32,513]

theorem envBound13075 : H12AffineFastState.Bounded env13075 := by
  intro p hp
  have h : env13075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13074_13075 : H12AffineEnvironment.transform 9 21 env13074 = env13075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13074 == env13075) = true)

def env13076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,17,98781,8328,65,4270122,5392,17665,109047,1500,4256861,256,21792,46213,74251]

theorem envBound13076 : H12AffineFastState.Bounded env13076 := by
  intro p hp
  have h : env13076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13050_13076 : H12AffineEnvironment.transform 20 4161 env13050 = env13076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13050 == env13076) = true)

theorem identity13076 : scanCanonicalize (H12AffineFastState.compose env13076 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

theorem selectedBound13076 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,213350,17,98781,8328,65,158028,5392,17665,109047,1500,243003,256,21792,46213,74251]

theorem envBound13077 : H12AffineFastState.Bounded env13077 := by
  intro p hp
  have h : env13077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13076_13077 : H12AffineEnvironment.transform 21 213350 env13076 = env13077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env13076 == env13077) = true)

theorem identity13077 : scanCanonicalize (H12AffineFastState.compose env13077 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13077 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149996,1024,32769,4161,156012,17,41431,8328,65,158028,5392,17665,35325,1500,169265,256,21792,46213,513]

theorem envBound13078 : H12AffineFastState.Bounded env13078 := by
  intro p hp
  have h : env13078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13077_13078 : H12AffineEnvironment.transform 15 8202 env13077 = env13078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13077 == env13078) = true)

theorem identity13078 : scanCanonicalize (H12AffineFastState.compose env13078 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13078 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2557,1024,32769,4161,8573,17,41431,8328,65,10589,5392,17665,35325,1500,54560,256,21792,46213,513]

theorem envBound13079 : H12AffineFastState.Bounded env13079 := by
  intro p hp
  have h : env13079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13078_13079 : H12AffineEnvironment.transform 16 16401 env13078 = env13079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13078 == env13079) = true)

theorem identity13079 : scanCanonicalize (H12AffineFastState.compose env13079 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound13079 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env13080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16401,2557,1024,29709,4161,8573,17,21979,8328,65,10589,5392,17665,32241,1500,8492,256,21792,16521,513]

theorem envBound13080 : H12AffineFastState.Bounded env13080 := by
  intro p hp
  have h : env13080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13079_13080 : H12AffineEnvironment.transform 14 29708 env13079 = env13080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env13079 == env13080) = true)

theorem identity13080 : scanCanonicalize (H12AffineFastState.compose env13080 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13080 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env13081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,16401,2421,1024,29709,4161,8573,17,21843,8192,65,10589,5392,17665,32121,1364,8492,256,21792,16385,513]

theorem envBound13081 : H12AffineFastState.Bounded env13081 := by
  intro p hp
  have h : env13081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13080_13081 : H12AffineEnvironment.transform 6 8 env13080 = env13081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13080 == env13081) = true)

theorem identity13081 : scanCanonicalize (H12AffineFastState.compose env13081 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound13081 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env13082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9576,8202,4469,2421,1024,9577,4161,8573,17,1079,8192,65,10589,5392,5221,11293,1364,8492,256,1092,4453,513]

theorem envBound13082 : H12AffineFastState.Bounded env13082 := by
  intro p hp
  have h : env13082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13081_13082 : H12AffineEnvironment.transform 13 4452 env13081 = env13082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env13081 == env13082) = true)

theorem identity13082 : scanCanonicalize (H12AffineFastState.compose env13082 (packedSelected [0,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound13082 : packedSelected [0,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4452,372,1046,4469,2421,1024,373,4161,1377,17,1079,1052,65,3393,5392,5221,2049,1364,1328,256,1092,4453,513]

theorem envBound13083 : H12AffineFastState.Bounded env13083 := by
  intro p hp
  have h : env13083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13082_13083 : H12AffineEnvironment.transform 12 1052 env13082 = env13083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env13082 == env13083) = true)

theorem identity13083 : scanCanonicalize (H12AffineFastState.compose env13083 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13083 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env13084 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,4452,372,115,4469,2421,101,373,4161,260,17,82,121,65,2340,4469,4096,2049,305,341,256,33,4453,513]

theorem envBound13084 : H12AffineFastState.Bounded env13084 := by
  intro p hp
  have h : env13084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13083_13084 : H12AffineEnvironment.transform 9 101 env13083 = env13084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13083 == env13084) = true)

theorem identity13084 : scanCanonicalize (H12AffineFastState.compose env13084 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13085 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,40,4405,293,34,4388,2340,52,292,4112,260,17,3,40,16,2340,4388,4096,2049,305,260,256,33,4404,513]

theorem envBound13085 : H12AffineFastState.Bounded env13085 := by
  intro p hp
  have h : env13085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13084_13085 : H12AffineEnvironment.transform 5 17 env13084 = env13085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13084 == env13085) = true)

def env13086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270123,5392,17664,2210231,1501,4256861,256,2114912,2139333,74250]

theorem envBound13086 : H12AffineFastState.Bounded env13086 := by
  intro p hp
  have h : env13086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13049_13086 : H12AffineEnvironment.transform 22 2101329 env13049 = env13086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env13049 == env13086) = true)

def env13087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,17,98780,8328,65,4270123,5392,17664,109047,1501,4256861,256,21792,46213,74250]

theorem envBound13087 : H12AffineFastState.Bounded env13087 := by
  intro p hp
  have h : env13087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13086_13087 : H12AffineEnvironment.transform 20 4160 env13086 = env13087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13086 == env13087) = true)

theorem identity13087 : scanCanonicalize (H12AffineFastState.compose env13087 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound13087 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,243122,17,98780,8328,65,171417,5392,17664,109047,1501,213487,256,21792,46213,74250]

theorem envBound13088 : H12AffineFastState.Bounded env13088 := by
  intro p hp
  have h : env13088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13087_13088 : H12AffineEnvironment.transform 21 243122 env13087 = env13088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env13087 == env13088) = true)

def env13089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243002,17,98644,8192,65,171281,5392,17664,108927,1365,213351,256,21792,46093,74250]

theorem envBound13089 : H12AffineFastState.Bounded env13089 := by
  intro p hp
  have h : env13089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13088_13089 : H12AffineEnvironment.transform 6 8 env13088 = env13089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13088 == env13089) = true)

theorem identity13089 : scanCanonicalize (H12AffineFastState.compose env13089 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13089 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4160,144492,17,2,8192,65,171281,5392,17664,10281,1365,180273,256,21792,46093,41820]

theorem envBound13090 : H12AffineFastState.Bounded env13090 := by
  intro p hp
  have h : env13090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13089_13090 : H12AffineEnvironment.transform 15 33110 env13089 = env13090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13089 == env13090) = true)

theorem identity13090 : scanCanonicalize (H12AffineFastState.compose env13090 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13090 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33110,131072,171061,1024,32769,4160,144492,17,2,8192,65,171281,5392,12557,10281,1365,177212,256,8493,46093,41820]

theorem envBound13091 : H12AffineFastState.Bounded env13091 := by
  intro p hp
  have h : env13091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13090_13091 : H12AffineEnvironment.transform 13 13325 env13090 = env13091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13090 == env13091) = true)

theorem identity13091 : scanCanonicalize (H12AffineFastState.compose env13091 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound13091 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env13092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,263,131072,138340,1024,80,4160,144492,17,2,8192,65,138560,5392,12557,10281,1365,144493,256,8493,13404,8973]

theorem envBound13092 : H12AffineFastState.Bounded env13092 := by
  intro p hp
  have h : env13092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13091_13092 : H12AffineEnvironment.transform 14 81 env13091 = env13092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env13091 == env13092) = true)

theorem identity13092 : scanCanonicalize (H12AffineFastState.compose env13092 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound13092 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,263,13625,10589,1024,80,4160,341,17,2,8192,65,10361,5392,12557,10281,1365,340,256,8493,13404,8973]

theorem envBound13093 : H12AffineFastState.Bounded env13093 := by
  intro p hp
  have h : env13093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13092_13093 : H12AffineEnvironment.transform 16 13625 env13092 = env13093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env13092 == env13093) = true)

theorem identity13093 : scanCanonicalize (H12AffineFastState.compose env13093 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound13093 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5488,81,263,5188,2080,1024,80,4160,341,17,2,381,65,2308,5392,4208,2388,1365,340,256,80,5409,624]

theorem envBound13094 : H12AffineFastState.Bounded env13094 := by
  intro p hp
  have h : env13094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13093_13094 : H12AffineEnvironment.transform 12 381 env13093 = env13094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env13093 == env13094) = true)

theorem identity13094 : scanCanonicalize (H12AffineFastState.compose env13094 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13094 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env13095 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,88,5205,81,34,5188,2080,1024,80,4160,112,17,2,88,65,2081,5173,4208,2161,1136,113,37,80,5124,624]

theorem envBound13095 : H12AffineFastState.Bounded env13095 := by
  intro p hp
  have h : env13095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13094_13095 : H12AffineEnvironment.transform 7 37 env13094 = env13095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13094 == env13095) = true)

theorem identity13095 : scanCanonicalize (H12AffineFastState.compose env13095 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13095 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13096 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,4096,88,4160,81,34,4177,2080,21,80,4160,112,17,2,88,65,2081,4128,4208,2161,101,113,37,80,4113,624]

theorem envBound13096 : H12AffineFastState.Bounded env13096 := by
  intro p hp
  have h : env13096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13095_13096 : H12AffineEnvironment.transform 9 21 env13095 = env13096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13095 == env13096) = true)

theorem identity13096 : scanCanonicalize (H12AffineFastState.compose env13096 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound13096 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env13097 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,2058,88,2122,81,34,2139,2080,21,80,2122,112,17,2,88,65,2081,2090,2170,2161,101,113,37,80,2075,624]

theorem envBound13097 : H12AffineFastState.Bounded env13097 := by
  intro p hp
  have h : env13097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13096_13097 : H12AffineEnvironment.transform 11 2058 env13096 = env13097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env13096 == env13097) = true)

theorem identity13097 : scanCanonicalize (H12AffineFastState.compose env13097 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 85) := by decide +kernel

theorem selectedBound13097 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13098 : List Nat := [2,4,8,16,32,64,8,37,85,21,2048,2058,88,2122,81,34,2139,2080,21,80,2122,112,17,2,88,65,2081,2090,2170,2161,101,113,37,80,2075,37]

theorem envBound13098 : H12AffineFastState.Bounded env13098 := by
  intro p hp
  have h : env13098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13097_13098 : H12AffineEnvironment.transform 8 85 env13097 = env13098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 85 env13097 == env13098) = true)

theorem identity13098 : scanCanonicalize (H12AffineFastState.compose env13098 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13098 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env13099 : List Nat := [2,4,8,16,32,17,8,37,4,21,2048,2058,9,2075,0,34,2058,2080,21,1,2075,33,17,2,9,16,2081,2090,2091,2080,52,32,37,1,2075,37]

theorem envBound13099 : H12AffineFastState.Bounded env13099 := by
  intro p hp
  have h : env13099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13098_13099 : H12AffineEnvironment.transform 5 17 env13098 = env13099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13098 == env13099) = true)

theorem identity13099 : scanCanonicalize (H12AffineFastState.compose env13099 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound13099 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env13100 : List Nat := [2,4,8,16,32,17,8,37,4,21,48,58,9,43,0,34,58,16,21,1,43,33,17,2,9,16,17,26,27,16,52,32,37,1,43,37]

theorem envBound13100 : H12AffineFastState.Bounded env13100 := by
  intro p hp
  have h : env13100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13099_13100 : H12AffineEnvironment.transform 10 48 env13099 = env13100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env13099 == env13100) = true)

theorem identity13100 : scanCanonicalize (H12AffineFastState.compose env13100 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound13100 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13101 : List Nat := [2,4,8,16,23,17,8,18,4,21,7,13,9,28,0,21,13,16,21,1,28,22,17,2,9,16,17,26,27,16,3,23,18,1,28,18]

theorem envBound13101 : H12AffineFastState.Bounded env13101 := by
  intro p hp
  have h : env13101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13100_13101 : H12AffineEnvironment.transform 4 23 env13100 = env13101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env13100 == env13101) = true)

theorem identity13101 : scanCanonicalize (H12AffineFastState.compose env13101 (packedSelected [2,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13101 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13102 : List Nat := [2,4,2,16,23,17,2,18,4,21,7,7,3,22,0,21,7,16,21,1,22,22,17,2,3,16,17,16,17,16,3,23,18,1,22,18]

theorem envBound13102 : H12AffineFastState.Bounded env13102 := by
  intro p hp
  have h : env13102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13101_13102 : H12AffineEnvironment.transform 2 2 env13101 = env13102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13101 == env13102) = true)

theorem identity13102 : scanCanonicalize (H12AffineFastState.compose env13102 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13103 : List Nat := [2,2,2,16,17,17,2,18,2,19,1,1,3,16,0,19,1,16,19,1,16,16,17,2,3,16,17,16,17,16,3,17,18,1,16,18]

theorem envBound13103 : H12AffineFastState.Bounded env13103 := by
  intro p hp
  have h : env13103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13102_13103 : H12AffineEnvironment.transform 1 2 env13102 = env13103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13102 == env13103) = true)

def env13104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,243003,17,98645,8193,65,171280,5392,17664,108926,1364,213350,256,21792,46092,74250]

theorem envBound13104 : H12AffineFastState.Bounded env13104 := by
  intro p hp
  have h : env13104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13088_13104 : H12AffineEnvironment.transform 6 9 env13088 = env13104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13088 == env13104) = true)

theorem identity13104 : scanCanonicalize (H12AffineFastState.compose env13104 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13104 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,169264,17,41310,8193,65,171280,5392,17664,35189,1364,156013,256,21792,46092,513]

theorem envBound13105 : H12AffineFastState.Bounded env13105 := by
  intro p hp
  have h : env13105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13104_13105 : H12AffineEnvironment.transform 15 8203 env13104 = env13105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13104 == env13105) = true)

theorem identity13105 : scanCanonicalize (H12AffineFastState.compose env13105 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound13105 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4160,54560,17,41310,8193,65,56576,5392,17664,35189,1364,8573,256,21792,46092,513]

theorem envBound13106 : H12AffineFastState.Bounded env13106 := by
  intro p hp
  have h : env13106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13105_13106 : H12AffineEnvironment.transform 16 16400 env13105 = env13106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13105 == env13106) = true)

theorem identity13106 : scanCanonicalize (H12AffineFastState.compose env13106 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13106 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,2420,1024,8541,4160,29820,17,2,8193,65,31836,5392,17664,10281,1364,8573,256,21792,5456,513]

theorem envBound13107 : H12AffineFastState.Bounded env13107 := by
  intro p hp
  have h : env13107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13106_13107 : H12AffineEnvironment.transform 14 8540 env13106 = env13107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13106 == env13107) = true)

theorem identity13107 : scanCanonicalize (H12AffineFastState.compose env13107 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13107 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,8203,5441,2420,1024,8541,4160,8493,17,2,8193,65,10509,5392,4177,10281,1364,8573,256,113,5456,513]

theorem envBound13108 : H12AffineFastState.Bounded env13108 := by
  intro p hp
  have h : env13108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13107_13108 : H12AffineEnvironment.transform 13 5457 env13107 = env13108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13107 == env13108) = true)

theorem identity13108 : scanCanonicalize (H12AffineFastState.compose env13108 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound13108 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,57,5457,357,50,5441,2420,1024,356,4160,276,17,2,56,65,2356,5392,4177,2064,1364,324,256,113,5456,513]

theorem envBound13109 : H12AffineFastState.Bounded env13109 := by
  intro p hp
  have h : env13109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13108_13109 : H12AffineEnvironment.transform 12 57 env13108 = env13109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env13108 == env13109) = true)

theorem identity13109 : scanCanonicalize (H12AffineFastState.compose env13109 (packedSelected [1,2,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound13109 : packedSelected [1,2,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13110 : List Nat := [2,4,8,16,32,64,9,256,512,256,2048,4096,57,4177,357,50,4161,2420,256,356,4160,276,17,2,56,65,2356,4112,4177,2064,84,324,256,113,4176,513]

theorem envBound13110 : H12AffineFastState.Bounded env13110 := by
  intro p hp
  have h : env13110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13109_13110 : H12AffineEnvironment.transform 9 256 env13109 = env13110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env13109 == env13110) = true)

theorem identity13110 : scanCanonicalize (H12AffineFastState.compose env13110 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13110 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env13111 : List Nat := [2,4,8,16,32,17,9,256,512,256,2048,4096,57,4096,308,50,4112,2341,256,309,4113,276,17,2,56,16,2356,4112,4096,2064,5,277,256,32,4097,513]

theorem envBound13111 : H12AffineFastState.Bounded env13111 := by
  intro p hp
  have h : env13111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13110_13111 : H12AffineEnvironment.transform 5 17 env13110 = env13111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13110 == env13111) = true)

def env13112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,16,98781,8328,65,4270123,5392,17664,109046,1501,4256861,256,21793,46212,74250]

theorem envBound13112 : H12AffineFastState.Bounded env13112 := by
  intro p hp
  have h : env13112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13086_13112 : H12AffineEnvironment.transform 20 4161 env13086 = env13112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13086 == env13112) = true)

theorem identity13112 : scanCanonicalize (H12AffineFastState.compose env13112 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13112 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4161,4194304,16,41430,8328,65,4196384,5392,17664,35325,1501,4256861,256,21793,46212,513]

theorem envBound13113 : H12AffineFastState.Bounded env13113 := by
  intro p hp
  have h : env13113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13112_13113 : H12AffineEnvironment.transform 15 8203 env13112 = env13113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13112 == env13113) = true)

theorem identity13113 : scanCanonicalize (H12AffineFastState.compose env13113 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound13113 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4161,8573,16,41430,8328,65,10589,5392,17664,35325,1501,54560,256,21793,46212,513]

theorem envBound13114 : H12AffineFastState.Bounded env13114 := by
  intro p hp
  have h : env13114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13113_13114 : H12AffineEnvironment.transform 21 8573 env13113 = env13114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env13113 == env13114) = true)

theorem identity13114 : scanCanonicalize (H12AffineFastState.compose env13114 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13114 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env13115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,8573,16,41311,8193,65,10589,5392,17664,35188,1364,54560,256,21793,46093,513]

theorem envBound13115 : H12AffineFastState.Bounded env13115 := by
  intro p hp
  have h : env13115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13114_13115 : H12AffineEnvironment.transform 6 9 env13114 = env13115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13114 == env13115) = true)

theorem identity13115 : scanCanonicalize (H12AffineFastState.compose env13115 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound13115 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10280,1024,32769,4161,8573,16,41311,8193,65,10589,5392,17664,35188,1364,54560,256,21793,46093,513]

theorem envBound13116 : H12AffineFastState.Bounded env13116 := by
  intro p hp
  have h : env13116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13115_13116 : H12AffineEnvironment.transform 16 24908 env13115 = env13116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env13115 == env13116) = true)

theorem identity13116 : scanCanonicalize (H12AffineFastState.compose env13116 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13116 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,24908,10280,1024,21760,4161,8573,16,29790,8193,65,10589,5392,17664,23669,1364,33,256,21793,24844,513]

theorem envBound13117 : H12AffineFastState.Bounded env13117 := by
  intro p hp
  have h : env13117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13116_13117 : H12AffineEnvironment.transform 14 21761 env13116 = env13117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13116 == env13117) = true)

theorem identity13117 : scanCanonicalize (H12AffineFastState.compose env13117 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13117 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16401,2421,1024,21760,4161,32,16,21763,348,65,2048,5392,17664,23669,1364,33,256,21793,16465,513]

theorem envBound13118 : H12AffineFastState.Bounded env13118 := by
  intro p hp
  have h : env13118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13117_13118 : H12AffineEnvironment.transform 12 349 env13117 = env13118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13117 == env13118) = true)

def env13119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760059,5393,10507601,8497638,10491277,4256860,256,8410416,8434837,10564186]

theorem envBound13119 : H12AffineFastState.Bounded env13119 := by
  intro p hp
  have h : env13119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13048_13119 : H12AffineEnvironment.transform 23 2199965 env13048 = env13119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env13048 == env13119) = true)

def env13120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270123,5393,17665,2210230,1501,4256860,256,2114912,2139333,74250]

theorem envBound13120 : H12AffineFastState.Bounded env13120 := by
  intro p hp
  have h : env13120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13119_13120 : H12AffineEnvironment.transform 22 2101328 env13119 = env13120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env13119 == env13120) = true)

def env13121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,16,98781,8328,65,4270123,5393,17665,109046,1501,4256860,256,21792,46213,74250]

theorem envBound13121 : H12AffineFastState.Bounded env13121 := by
  intro p hp
  have h : env13121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13120_13121 : H12AffineEnvironment.transform 20 4160 env13120 = env13121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13120 == env13121) = true)

def env13122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98645,8192,65,4270123,5393,17665,108926,1365,4256860,256,21792,46093,74250]

theorem envBound13122 : H12AffineFastState.Bounded env13122 := by
  intro p hp
  have h : env13122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13121_13122 : H12AffineEnvironment.transform 6 8 env13121 = env13122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13121 == env13122) = true)

theorem identity13122 : scanCanonicalize (H12AffineFastState.compose env13122 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound13122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,108927,1024,32769,4160,4194304,16,98645,8192,65,4270123,5393,17665,108926,1365,4256860,256,21792,46093,74250]

theorem envBound13123 : H12AffineFastState.Bounded env13123 := by
  intro p hp
  have h : env13123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13122_13123 : H12AffineEnvironment.transform 16 49169 env13122 = env13123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env13122 == env13123) = true)

theorem identity13123 : scanCanonicalize (H12AffineFastState.compose env13123 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound13123 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5440,97326,1024,21840,4160,4194304,16,87044,8192,65,4270123,5393,17665,97327,1365,4202765,256,21792,24924,74250]

theorem envBound13124 : H12AffineFastState.Bounded env13124 := by
  intro p hp
  have h : env13124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13123_13124 : H12AffineEnvironment.transform 14 21841 env13123 = env13124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env13123 == env13124) = true)

theorem identity13124 : scanCanonicalize (H12AffineFastState.compose env13124 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound13124 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5440,97326,1024,21840,4160,21873,16,87044,8192,65,97626,5393,17665,97327,1365,29820,256,21792,24924,74250]

theorem envBound13125 : H12AffineFastState.Bounded env13125 := by
  intro p hp
  have h : env13125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13124_13125 : H12AffineEnvironment.transform 21 21873 env13124 = env13125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env13124 == env13125) = true)

theorem identity13125 : scanCanonicalize (H12AffineFastState.compose env13125 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound13125 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env13126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8312,65536,5440,67847,1024,8313,4160,8280,16,74029,8192,65,67699,5393,12328,67846,1365,341,256,8201,5237,74250]

theorem envBound13126 : H12AffineFastState.Bounded env13126 := by
  intro p hp
  have h : env13126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13125_13126 : H12AffineEnvironment.transform 13 13609 env13125 = env13126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env13125 == env13126) = true)

theorem identity13126 : scanCanonicalize (H12AffineFastState.compose env13126 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound13126 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env13127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8312,114,5440,2421,1024,8313,4160,8280,16,8543,8192,65,2049,5393,12328,2420,1365,341,256,8201,5237,8824]

theorem envBound13127 : H12AffineFastState.Bounded env13127 := by
  intro p hp
  have h : env13127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13126_13127 : H12AffineEnvironment.transform 15 114 env13126 = env13127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env13126 == env13127) = true)

theorem identity13127 : scanCanonicalize (H12AffineFastState.compose env13127 (packedSelected [1,2,3,4,6,8,9,10,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13127 : packedSelected [1,2,3,4,6,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env13128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,80,114,5440,2421,1024,81,4160,112,16,375,40,65,2049,5393,4096,2420,1365,341,256,33,5237,592]

theorem envBound13128 : H12AffineFastState.Bounded env13128 := by
  intro p hp
  have h : env13128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13127_13128 : H12AffineEnvironment.transform 12 40 env13127 = env13128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13127 == env13128) = true)

theorem identity13128 : scanCanonicalize (H12AffineFastState.compose env13128 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13128 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13129 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5156,80,114,5221,2128,1024,81,4160,112,16,82,40,65,2049,5172,4096,2129,1136,112,37,33,5237,592]

theorem envBound13129 : H12AffineFastState.Bounded env13129 := by
  intro p hp
  have h : env13129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13128_13129 : H12AffineEnvironment.transform 7 37 env13128 = env13129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13128 == env13129) = true)

theorem identity13129 : scanCanonicalize (H12AffineFastState.compose env13129 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13129 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13130 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,34,5173,2048,1024,1,4112,32,16,2,40,17,2049,5172,4096,2049,1056,32,37,33,5157,512]

theorem envBound13130 : H12AffineFastState.Bounded env13130 := by
  intro p hp
  have h : env13130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13129_13130 : H12AffineEnvironment.transform 5 16 env13129 = env13130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13129 == env13130) = true)

theorem identity13130 : scanCanonicalize (H12AffineFastState.compose env13130 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13131 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,5125,0,3,5140,2048,1024,1,4112,1,16,2,9,17,2049,5141,4096,2049,1025,1,4,0,5124,512]

theorem envBound13131 : H12AffineFastState.Bounded env13131 := by
  intro p hp
  have h : env13131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13130_13131 : H12AffineEnvironment.transform 4 1 env13130 = env13131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13130 == env13131) = true)

theorem identity13131 : scanCanonicalize (H12AffineFastState.compose env13131 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound13131 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13132 : List Nat := [2,4,8,16,1,16,8,4,512,1024,523,4096,9,5125,0,3,5140,523,1024,1,4112,1,16,2,9,17,522,5141,4096,522,1025,1,4,0,5124,512]

theorem envBound13132 : H12AffineFastState.Bounded env13132 := by
  intro p hp
  have h : env13132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13131_13132 : H12AffineEnvironment.transform 10 523 env13131 = env13132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env13131 == env13132) = true)

def env13133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98644,8193,65,4270123,5393,17665,108927,1364,4256860,256,21792,46092,74250]

theorem envBound13133 : H12AffineFastState.Bounded env13133 := by
  intro p hp
  have h : env13133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13121_13133 : H12AffineEnvironment.transform 6 9 env13121 = env13133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13121 == env13133) = true)

theorem identity13133 : scanCanonicalize (H12AffineFastState.compose env13133 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound13133 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67619,1024,32769,4160,4194304,16,98644,8193,65,4270123,5393,17665,108927,1364,4256860,256,21792,46092,74250]

theorem envBound13134 : H12AffineFastState.Bounded env13134 := by
  intro p hp
  have h : env13134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13133_13134 : H12AffineEnvironment.transform 16 24908 env13133 = env13134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env13133 == env13134) = true)

theorem identity13134 : scanCanonicalize (H12AffineFastState.compose env13134 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound13134 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env13135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67619,1024,32769,4160,65910,16,98644,8193,65,10589,5393,17665,108927,1364,128298,256,21792,46092,74250]

theorem envBound13135 : H12AffineFastState.Bounded env13135 := by
  intro p hp
  have h : env13135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13134_13135 : H12AffineEnvironment.transform 21 65910 env13134 = env13135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env13134 == env13135) = true)

theorem identity13135 : scanCanonicalize (H12AffineFastState.compose env13135 (packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound13135 : packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS < 2^1333 := by decide +kernel

def env13136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,64808,1024,32769,4160,62589,16,29791,8193,65,10589,5393,17665,23668,1364,33,256,21792,46092,55041]

theorem envBound13136 : H12AffineFastState.Bounded env13136 := by
  intro p hp
  have h : env13136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13135_13136 : H12AffineEnvironment.transform 15 62731 env13135 = env13136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env13135 == env13136) = true)

theorem identity13136 : scanCanonicalize (H12AffineFastState.compose env13136 (packedSelected [2,5,6,10,11,12,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13136 : packedSelected [2,5,6,10,11,12,14,20,24] rootPS < 2^1333 := by decide +kernel

def env13137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,33030,5441,35109,1024,32769,4160,32880,16,82,8193,65,10589,5393,12556,10361,1364,33,256,8493,46092,41740]

theorem envBound13137 : H12AffineFastState.Bounded env13137 := by
  intro p hp
  have h : env13137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13136_13137 : H12AffineEnvironment.transform 13 13325 env13136 = env13137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13136 == env13137) = true)

theorem identity13137 : scanCanonicalize (H12AffineFastState.compose env13137 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13137 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env13138 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,33030,5393,35109,1024,32769,4112,32800,16,2,8193,17,10509,5393,12556,10281,1284,33,256,8493,46092,41740]

theorem envBound13138 : H12AffineFastState.Bounded env13138 := by
  intro p hp
  have h : env13138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13137_13138 : H12AffineEnvironment.transform 5 16 env13137 = env13138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13137 == env13138) = true)

theorem identity13138 : scanCanonicalize (H12AffineFastState.compose env13138 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13138 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env13139 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,262,5393,2341,1024,1,4112,32,16,2,8193,17,10509,5393,12556,10281,1284,33,256,8493,13324,8972]

theorem envBound13139 : H12AffineFastState.Bounded env13139 := by
  intro p hp
  have h : env13139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13138_13139 : H12AffineEnvironment.transform 14 0 env13138 = env13139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13138 == env13139) = true)

theorem identity13139 : scanCanonicalize (H12AffineFastState.compose env13139 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound13139 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13140 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,8192,10280,0,262,2356,2341,1024,1,3125,32,16,2,8193,17,10509,2356,11561,10281,1284,33,256,8493,10281,8972]

theorem envBound13140 : H12AffineFastState.Bounded env13140 := by
  intro p hp
  have h : env13140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13139_13140 : H12AffineEnvironment.transform 11 3109 env13139 = env13140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env13139 == env13140) = true)

theorem identity13140 : scanCanonicalize (H12AffineFastState.compose env13140 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound13140 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env13141 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1029,32,8192,9261,0,262,1329,1312,1024,1,48,32,16,2,8193,17,9480,1329,8492,9260,1284,33,256,8493,9260,8972]

theorem envBound13141 : H12AffineFastState.Bounded env13141 := by
  intro p hp
  have h : env13141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13140_13141 : H12AffineEnvironment.transform 10 1029 env13140 = env13141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env13140 == env13141) = true)

theorem identity13141 : scanCanonicalize (H12AffineFastState.compose env13141 (packedSelected [2,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound13141 : packedSelected [2,6,10] rootPS < 2^1333 := by decide +kernel

def env13142 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1029,32,56,1045,0,262,1329,1312,1024,1,48,32,16,2,57,17,1328,1329,276,1044,1284,33,256,277,1044,820]

theorem envBound13142 : H12AffineFastState.Bounded env13142 := by
  intro p hp
  have h : env13142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13141_13142 : H12AffineEnvironment.transform 12 56 env13141 = env13142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env13141 == env13142) = true)

theorem identity13142 : scanCanonicalize (H12AffineFastState.compose env13142 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13142 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13143 : List Nat := [2,4,8,16,32,16,9,256,512,272,277,32,56,261,0,262,33,48,272,1,48,32,16,2,57,17,32,33,276,260,20,33,256,277,260,820]

theorem envBound13143 : H12AffineFastState.Bounded env13143 := by
  intro p hp
  have h : env13143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13142_13143 : H12AffineEnvironment.transform 9 272 env13142 = env13143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13142 == env13143) = true)

theorem identity13143 : scanCanonicalize (H12AffineFastState.compose env13143 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound13143 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env13144 : List Nat := [2,4,8,16,32,16,9,53,512,37,32,32,56,48,0,51,33,48,37,1,48,32,16,2,57,17,32,33,33,49,20,33,53,32,49,513]

theorem envBound13144 : H12AffineFastState.Bounded env13144 := by
  intro p hp
  have h : env13144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13143_13144 : H12AffineEnvironment.transform 7 53 env13143 = env13144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env13143 == env13144) = true)

theorem identity13144 : scanCanonicalize (H12AffineFastState.compose env13144 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound13144 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13145 : List Nat := [2,4,8,16,2,16,9,23,512,7,2,2,26,18,0,17,3,18,7,1,18,2,16,2,27,17,2,3,3,19,20,3,23,2,19,513]

theorem envBound13145 : H12AffineFastState.Bounded env13145 := by
  intro p hp
  have h : env13145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13144_13145 : H12AffineEnvironment.transform 4 2 env13144 = env13145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env13144 == env13145) = true)

theorem identity13145 : scanCanonicalize (H12AffineFastState.compose env13145 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13145 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13146 : List Nat := [2,4,8,10,2,10,9,13,512,7,2,2,0,8,0,11,3,8,7,1,8,2,10,2,1,11,2,3,3,9,14,3,13,2,9,513]

theorem envBound13146 : H12AffineFastState.Bounded env13146 := by
  intro p hp
  have h : env13146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13145_13146 : H12AffineEnvironment.transform 3 10 env13145 = env13146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13145 == env13146) = true)

theorem identity13146 : scanCanonicalize (H12AffineFastState.compose env13146 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13146 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13147 : List Nat := [2,4,3,1,2,1,2,6,512,7,2,2,0,3,0,0,3,3,7,1,3,2,1,2,1,0,2,3,3,2,5,3,6,2,2,513]

theorem envBound13147 : H12AffineFastState.Bounded env13147 := by
  intro p hp
  have h : env13147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13146_13147 : H12AffineEnvironment.transform 2 3 env13146 = env13147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13146 == env13147) = true)

theorem identity13147 : scanCanonicalize (H12AffineFastState.compose env13147 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound13147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13148 : List Nat := [2,1,3,1,2,1,2,3,512,2,2,2,0,3,0,0,3,3,2,1,3,2,1,2,1,0,2,3,3,2,0,3,3,2,2,513]

theorem envBound13148 : H12AffineFastState.Bounded env13148 := by
  intro p hp
  have h : env13148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13147_13148 : H12AffineEnvironment.transform 1 1 env13147 = env13148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env13147 == env13148) = true)

def env13149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,17,98780,8328,65,4270123,5393,17665,109047,1501,4256860,256,21793,46212,74250]

theorem envBound13149 : H12AffineFastState.Bounded env13149 := by
  intro p hp
  have h : env13149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13120_13149 : H12AffineEnvironment.transform 20 4161 env13120 = env13149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13120 == env13149) = true)

theorem identity13149 : scanCanonicalize (H12AffineFastState.compose env13149 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound13149 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,169400,17,98780,8328,65,245139,5393,17665,109047,1501,156132,256,21793,46212,74250]

theorem envBound13150 : H12AffineFastState.Bounded env13150 := by
  intro p hp
  have h : env13150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13149_13150 : H12AffineEnvironment.transform 21 169400 env13149 = env13150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env13149 == env13150) = true)

def env13151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169264,17,98644,8192,65,245019,5393,17665,108927,1365,156012,256,21793,46092,74250]

theorem envBound13151 : H12AffineFastState.Bounded env13151 := by
  intro p hp
  have h : env13151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13150_13151 : H12AffineEnvironment.transform 6 8 env13150 = env13151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13150 == env13151) = true)

theorem identity13151 : scanCanonicalize (H12AffineFastState.compose env13151 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13151 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4161,169264,17,2,8192,65,146509,5393,17665,10281,1365,156012,256,21793,46092,41820]

theorem envBound13152 : H12AffineFastState.Bounded env13152 := by
  intro p hp
  have h : env13152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13151_13152 : H12AffineEnvironment.transform 15 33110 env13151 = env13152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13151 == env13152) = true)

theorem identity13152 : scanCanonicalize (H12AffineFastState.compose env13152 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound13152 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33110,131072,171060,1024,32769,4161,169264,17,2,8192,65,146509,5393,12557,10281,1365,136544,256,8493,46092,41820]

theorem envBound13153 : H12AffineFastState.Bounded env13153 := by
  intro p hp
  have h : env13153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13152_13153 : H12AffineEnvironment.transform 13 13324 env13152 = env13153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env13152 == env13153) = true)

theorem identity13153 : scanCanonicalize (H12AffineFastState.compose env13153 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound13153 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env13154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33110,46392,10508,1024,32769,4161,8200,17,2,8192,65,35189,5393,12557,10281,1365,41048,256,8493,46092,41820]

theorem envBound13154 : H12AffineFastState.Bounded env13154 := by
  intro p hp
  have h : env13154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13153_13154 : H12AffineEnvironment.transform 16 46392 env13153 = env13154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env13153 == env13154) = true)

theorem identity13154 : scanCanonicalize (H12AffineFastState.compose env13154 (packedSelected [1,3,8,10,12,15,16,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13154 : packedSelected [1,3,8,10,12,15,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env13155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,33110,37940,2048,1024,32769,4161,260,17,2,268,65,35189,5393,4097,2341,1365,33108,256,33,38144,33360]

theorem envBound13155 : H12AffineFastState.Bounded env13155 := by
  intro p hp
  have h : env13155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13154_13155 : H12AffineEnvironment.transform 12 268 env13154 = env13155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13154 == env13155) = true)

theorem identity13155 : scanCanonicalize (H12AffineFastState.compose env13155 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound13155 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,260,82,5424,2048,1024,261,4161,260,17,2,268,65,2161,5393,4097,2341,1365,80,256,33,5124,852]

theorem envBound13156 : H12AffineFastState.Bounded env13156 := by
  intro p hp
  have h : env13156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13155_13156 : H12AffineEnvironment.transform 14 260 env13155 = env13156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env13155 == env13156) = true)

theorem identity13156 : scanCanonicalize (H12AffineFastState.compose env13156 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13156 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env13157 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,260,2,5424,2048,1024,261,4113,260,17,2,268,17,2081,5393,4097,2341,1285,0,256,33,5124,772]

theorem envBound13157 : H12AffineFastState.Bounded env13157 := by
  intro p hp
  have h : env13157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13156_13157 : H12AffineEnvironment.transform 5 16 env13156 = env13157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13156 == env13157) = true)

theorem identity13157 : scanCanonicalize (H12AffineFastState.compose env13157 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13157 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env13158 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,5376,260,2,5392,2048,1024,261,4113,260,17,2,268,17,2049,5393,4097,2309,1285,0,256,1,5124,772]

theorem envBound13158 : H12AffineFastState.Bounded env13158 := by
  intro p hp
  have h : env13158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13157_13158 : H12AffineEnvironment.transform 4 0 env13157 = env13158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13157 == env13158) = true)

theorem identity13158 : scanCanonicalize (H12AffineFastState.compose env13158 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13158 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13159 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,9,5125,1,2,5141,2048,1024,0,4113,1,17,2,9,17,2049,5140,4097,2048,1024,0,5,1,5124,513]

theorem envBound13159 : H12AffineFastState.Bounded env13159 := by
  intro p hp
  have h : env13159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13158_13159 : H12AffineEnvironment.transform 7 5 env13158 = env13159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13158 == env13159) = true)

theorem identity13159 : scanCanonicalize (H12AffineFastState.compose env13159 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound13159 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13160 : List Nat := [2,4,8,16,0,16,8,5,512,4,2048,4096,9,4097,1,2,4113,2048,4,0,4113,1,17,2,9,17,2049,4112,4097,2048,4,0,5,1,4096,513]

theorem envBound13160 : H12AffineFastState.Bounded env13160 := by
  intro p hp
  have h : env13160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13159_13160 : H12AffineEnvironment.transform 9 4 env13159 = env13160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env13159 == env13160) = true)

theorem identity13160 : scanCanonicalize (H12AffineFastState.compose env13160 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound13160 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13161 : List Nat := [2,4,8,16,0,16,8,5,512,4,2048,528,9,529,1,2,513,2048,4,0,513,1,17,2,9,17,2049,512,529,2048,4,0,5,1,528,513]

theorem envBound13161 : H12AffineFastState.Bounded env13161 := by
  intro p hp
  have h : env13161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13160_13161 : H12AffineEnvironment.transform 11 528 env13160 = env13161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env13160 == env13161) = true)

theorem identity13161 : scanCanonicalize (H12AffineFastState.compose env13161 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound13161 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13162 : List Nat := [2,4,8,16,0,16,8,5,512,4,512,528,9,529,1,2,513,512,4,0,513,1,17,2,9,17,513,512,529,512,4,0,5,1,528,513]

theorem envBound13162 : H12AffineFastState.Bounded env13162 := by
  intro p hp
  have h : env13162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13161_13162 : H12AffineEnvironment.transform 10 512 env13161 = env13162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env13161 == env13162) = true)

theorem identity13162 : scanCanonicalize (H12AffineFastState.compose env13162 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13162 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13163 : List Nat := [2,4,8,1,0,1,8,5,512,4,512,513,9,512,1,2,513,512,4,0,513,1,0,2,9,0,513,512,512,512,4,0,5,1,513,513]

theorem envBound13163 : H12AffineFastState.Bounded env13163 := by
  intro p hp
  have h : env13163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13162_13163 : H12AffineEnvironment.transform 3 1 env13162 = env13163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13162 == env13163) = true)

theorem identity13163 : scanCanonicalize (H12AffineFastState.compose env13163 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13163 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13164 : List Nat := [2,4,8,1,0,1,8,5,1,4,1,0,9,1,1,2,0,1,4,0,0,1,0,2,9,0,0,1,1,1,4,0,5,1,0,0]

theorem envBound13164 : H12AffineFastState.Bounded env13164 := by
  intro p hp
  have h : env13164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13163_13164 : H12AffineEnvironment.transform 8 1 env13163 = env13164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13163 == env13164) = true)

theorem identity13164 : scanCanonicalize (H12AffineFastState.compose env13164 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13165 : List Nat := [2,4,3,1,0,1,3,5,1,4,1,0,2,1,1,2,0,1,4,0,0,1,0,2,2,0,0,1,1,1,4,0,5,1,0,0]

theorem envBound13165 : H12AffineFastState.Bounded env13165 := by
  intro p hp
  have h : env13165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13164_13165 : H12AffineEnvironment.transform 2 3 env13164 = env13165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13164 == env13165) = true)

def env13166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,169265,17,98645,8193,65,245018,5393,17665,108926,1364,156013,256,21793,46093,74250]

theorem envBound13166 : H12AffineFastState.Bounded env13166 := by
  intro p hp
  have h : env13166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13150_13166 : H12AffineEnvironment.transform 6 9 env13150 = env13166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13150 == env13166) = true)

theorem identity13166 : scanCanonicalize (H12AffineFastState.compose env13166 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13166 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,169265,17,41310,8193,65,171281,5393,17665,35189,1364,156013,256,21793,46093,513]

theorem envBound13167 : H12AffineFastState.Bounded env13167 := by
  intro p hp
  have h : env13167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13166_13167 : H12AffineEnvironment.transform 15 8203 env13166 = env13167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13166 == env13167) = true)

theorem identity13167 : scanCanonicalize (H12AffineFastState.compose env13167 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound13167 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4161,54561,17,41310,8193,65,56577,5393,17665,35189,1364,8573,256,21793,46093,513]

theorem envBound13168 : H12AffineFastState.Bounded env13168 := by
  intro p hp
  have h : env13168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13167_13168 : H12AffineEnvironment.transform 16 16400 env13167 = env13168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13167 == env13168) = true)

theorem identity13168 : scanCanonicalize (H12AffineFastState.compose env13168 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13168 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,2420,1024,8541,4161,29821,17,2,8193,65,31837,5393,17665,10281,1364,8573,256,21793,5457,513]

theorem envBound13169 : H12AffineFastState.Bounded env13169 := by
  intro p hp
  have h : env13169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13168_13169 : H12AffineEnvironment.transform 14 8540 env13168 = env13169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13168 == env13169) = true)

theorem identity13169 : scanCanonicalize (H12AffineFastState.compose env13169 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound13169 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8203,5440,2420,1024,8541,4161,8493,17,2,8193,65,10509,5393,4177,10281,1364,8573,256,113,5457,513]

theorem envBound13170 : H12AffineFastState.Bounded env13170 := by
  intro p hp
  have h : env13170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13169_13170 : H12AffineEnvironment.transform 13 5456 env13169 = env13170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env13169 == env13170) = true)

theorem identity13170 : scanCanonicalize (H12AffineFastState.compose env13170 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound13170 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,105,5456,309,98,5440,2420,1024,308,4161,324,17,2,104,65,2404,5393,4177,2112,1364,276,256,113,5457,513]

theorem envBound13171 : H12AffineFastState.Bounded env13171 := by
  intro p hp
  have h : env13171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13170_13171 : H12AffineEnvironment.transform 12 105 env13170 = env13171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env13170 == env13171) = true)

theorem identity13171 : scanCanonicalize (H12AffineFastState.compose env13171 (packedSelected [1,2,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13171 : packedSelected [1,2,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13172 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,105,4404,309,98,4388,2420,100,308,4161,324,17,2,104,65,2404,4469,4177,2112,304,276,256,113,4405,513]

theorem envBound13172 : H12AffineFastState.Bounded env13172 := by
  intro p hp
  have h : env13172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13171_13172 : H12AffineEnvironment.transform 9 100 env13171 = env13172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13171 == env13172) = true)

theorem identity13172 : scanCanonicalize (H12AffineFastState.compose env13172 (packedSelected [1,3,5,8,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound13172 : packedSelected [1,3,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env13173 : List Nat := [2,4,8,16,32,64,9,53,512,100,2048,4096,105,4097,0,98,4113,2113,100,1,4161,113,17,2,104,65,2129,4160,4177,2112,5,33,53,113,4096,513]

theorem envBound13173 : H12AffineFastState.Bounded env13173 := by
  intro p hp
  have h : env13173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13172_13173 : H12AffineEnvironment.transform 7 53 env13172 = env13173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env13172 == env13173) = true)

def env13174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270122,5393,17664,2210231,1500,4256860,256,2114913,2139332,74251]

theorem envBound13174 : H12AffineFastState.Bounded env13174 := by
  intro p hp
  have h : env13174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13119_13174 : H12AffineEnvironment.transform 22 2101329 env13119 = env13174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env13119 == env13174) = true)

def env13175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,17,98781,8328,65,4270122,5393,17664,109047,1500,4256860,256,21793,46212,74251]

theorem envBound13175 : H12AffineFastState.Bounded env13175 := by
  intro p hp
  have h : env13175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13174_13175 : H12AffineEnvironment.transform 20 4160 env13174 = env13175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13174 == env13175) = true)

theorem identity13175 : scanCanonicalize (H12AffineFastState.compose env13175 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound13175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,156012,17,98781,8328,65,215366,5393,17664,109047,1500,169264,256,21793,46212,74251]

theorem envBound13176 : H12AffineFastState.Bounded env13176 := by
  intro p hp
  have h : env13176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13175_13176 : H12AffineEnvironment.transform 21 156012 env13175 = env13176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env13175 == env13176) = true)

def env13177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,156012,17,98645,8192,65,215366,5393,17664,108927,1364,169264,256,21793,46092,74251]

theorem envBound13177 : H12AffineFastState.Bounded env13177 := by
  intro p hp
  have h : env13177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13176_13177 : H12AffineEnvironment.transform 6 8 env13176 = env13177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13176 == env13177) = true)

theorem identity13177 : scanCanonicalize (H12AffineFastState.compose env13177 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound13177 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4160,156012,17,2,8192,65,182289,5393,17664,10280,1364,169264,256,21793,46092,41820]

theorem envBound13178 : H12AffineFastState.Bounded env13178 := by
  intro p hp
  have h : env13178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13177_13178 : H12AffineEnvironment.transform 15 33111 env13177 = env13178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env13177 == env13178) = true)

theorem identity13178 : scanCanonicalize (H12AffineFastState.compose env13178 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13178 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,149860,1024,8540,4160,156012,17,2,8192,65,158028,5393,17664,10280,1364,144493,256,21793,5457,513]

theorem envBound13179 : H12AffineFastState.Bounded env13179 := by
  intro p hp
  have h : env13179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13178_13179 : H12AffineEnvironment.transform 14 8541 env13178 = env13179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13178 == env13179) = true)

theorem identity13179 : scanCanonicalize (H12AffineFastState.compose env13179 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound13179 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5173,23889,1024,8540,4160,30041,17,2,8192,65,32121,5393,17664,10280,1364,8280,256,21793,5457,513]

theorem envBound13180 : H12AffineFastState.Bounded env13180 := by
  intro p hp
  have h : env13180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13179_13180 : H12AffineEnvironment.transform 16 5173 env13179 = env13180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env13179 == env13180) = true)

theorem identity13180 : scanCanonicalize (H12AffineFastState.compose env13180 (packedSelected [1,2,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound13180 : packedSelected [1,2,8,10,14] rootPS < 2^1333 := by decide +kernel

def env13181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,1344,1047,5173,23889,1024,1345,4160,20804,17,2,1053,65,22884,5393,17664,3125,1364,1093,256,21793,5457,513]

theorem envBound13181 : H12AffineFastState.Bounded env13181 := by
  intro p hp
  have h : env13181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13180_13181 : H12AffineEnvironment.transform 12 1053 env13180 = env13181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env13180 == env13181) = true)

theorem identity13181 : scanCanonicalize (H12AffineFastState.compose env13181 (packedSelected [0,1,2,6,7,8,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound13181 : packedSelected [0,1,2,6,7,8,10,16] rootPS < 2^1333 := by decide +kernel

def env13182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5156,1344,1047,5173,2421,1024,1345,4160,1376,17,2,1053,65,3392,5393,4388,3125,1364,1093,256,261,5457,513]

theorem envBound13182 : H12AffineFastState.Bounded env13182 := by
  intro p hp
  have h : env13182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13181_13182 : H12AffineEnvironment.transform 13 5156 env13181 = env13182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env13181 == env13182) = true)

theorem identity13182 : scanCanonicalize (H12AffineFastState.compose env13182 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13182 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env13183 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,41,4112,372,35,4097,2421,52,373,4160,340,17,2,41,65,2420,4389,4388,2049,352,113,256,261,4453,513]

theorem envBound13183 : H12AffineFastState.Bounded env13183 := by
  intro p hp
  have h : env13183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13182_13183 : H12AffineEnvironment.transform 9 52 env13182 = env13183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13182 == env13183) = true)

theorem identity13183 : scanCanonicalize (H12AffineFastState.compose env13183 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13184 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,41,4112,1,35,4097,2048,52,0,4160,33,17,2,41,65,2049,4176,4177,2049,21,113,117,112,4112,513]

theorem envBound13184 : H12AffineFastState.Bounded env13184 := by
  intro p hp
  have h : env13184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13183_13184 : H12AffineEnvironment.transform 7 117 env13183 = env13184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13183 == env13184) = true)

def env13185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,156012,17,98644,8193,65,215366,5393,17664,108926,1365,169264,256,21793,46093,74251]

theorem envBound13185 : H12AffineFastState.Bounded env13185 := by
  intro p hp
  have h : env13185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13176_13185 : H12AffineEnvironment.transform 6 9 env13176 = env13185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13176 == env13185) = true)

theorem identity13185 : scanCanonicalize (H12AffineFastState.compose env13185 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13185 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,156012,17,41310,8193,65,158028,5393,17664,35188,1365,169264,256,21793,46093,513]

theorem envBound13186 : H12AffineFastState.Bounded env13186 := by
  intro p hp
  have h : env13186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13185_13186 : H12AffineEnvironment.transform 15 8202 env13185 = env13186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13185 == env13186) = true)

theorem identity13186 : scanCanonicalize (H12AffineFastState.compose env13186 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13186 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4160,8573,17,41310,8193,65,10589,5393,17664,35188,1365,54561,256,21793,46093,513]

theorem envBound13187 : H12AffineFastState.Bounded env13187 := by
  intro p hp
  have h : env13187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13186_13187 : H12AffineEnvironment.transform 16 16401 env13186 = env13187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13186 == env13187) = true)

theorem identity13187 : scanCanonicalize (H12AffineFastState.compose env13187 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13187 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1024,8540,4160,8573,17,3,8193,65,10589,5393,17664,10281,1365,29820,256,21793,5456,513]

theorem envBound13188 : H12AffineFastState.Bounded env13188 := by
  intro p hp
  have h : env13188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13187_13188 : H12AffineEnvironment.transform 14 8541 env13187 = env13188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13187 == env13188) = true)

theorem identity13188 : scanCanonicalize (H12AffineFastState.compose env13188 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13188 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,8202,13340,2420,1024,8540,4160,8573,17,3,8193,65,10589,5393,12557,10281,1365,113,256,8492,5456,513]

theorem envBound13189 : H12AffineFastState.Bounded env13189 := by
  intro p hp
  have h : env13189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13188_13189 : H12AffineEnvironment.transform 13 13325 env13188 = env13189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13188 == env13189) = true)

theorem identity13189 : scanCanonicalize (H12AffineFastState.compose env13189 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13189 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13190 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,12392,8541,8202,12409,2420,101,8540,4160,8573,17,3,8193,65,10589,4468,12557,10281,304,113,256,8492,4405,513]

theorem envBound13190 : H12AffineFastState.Bounded env13190 := by
  intro p hp
  have h : env13190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13189_13190 : H12AffineEnvironment.transform 9 101 env13189 = env13190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13189 == env13190) = true)

theorem identity13190 : scanCanonicalize (H12AffineFastState.compose env13190 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13190 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env13191 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4405,0,343,4388,2420,101,1,4160,32,17,3,348,65,2048,4468,4176,2420,304,113,256,113,4405,513]

theorem envBound13191 : H12AffineFastState.Bounded env13191 := by
  intro p hp
  have h : env13191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13190_13191 : H12AffineEnvironment.transform 12 349 env13190 = env13191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13190 == env13191) = true)

theorem identity13191 : scanCanonicalize (H12AffineFastState.compose env13191 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13192 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,0,262,4388,2341,52,1,4113,32,17,3,269,16,2048,4389,4097,2341,304,32,256,32,4405,513]

theorem envBound13192 : H12AffineFastState.Bounded env13192 := by
  intro p hp
  have h : env13192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13191_13192 : H12AffineEnvironment.transform 5 17 env13191 = env13192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13191 == env13192) = true)

theorem identity13192 : scanCanonicalize (H12AffineFastState.compose env13192 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13193 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,0,35,4097,2048,52,1,4113,32,17,3,40,16,2048,4096,4097,2048,21,32,37,32,4112,513]

theorem envBound13193 : H12AffineFastState.Bounded env13193 := by
  intro p hp
  have h : env13193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13192_13193 : H12AffineEnvironment.transform 7 37 env13192 = env13193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13192 == env13193) = true)

theorem identity13193 : scanCanonicalize (H12AffineFastState.compose env13193 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound13193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13194 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2608,41,2592,0,35,2609,2048,52,1,2593,32,17,3,40,16,2048,2608,2609,2048,21,32,37,32,2592,513]

theorem envBound13194 : H12AffineFastState.Bounded env13194 := by
  intro p hp
  have h : env13194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13193_13194 : H12AffineEnvironment.transform 11 2608 env13193 = env13194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env13193 == env13194) = true)

theorem identity13194 : scanCanonicalize (H12AffineFastState.compose env13194 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound13194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13195 : List Nat := [2,4,8,16,32,17,9,37,512,52,17,545,41,561,0,35,544,17,52,1,560,32,17,3,40,16,17,545,544,17,21,32,37,32,561,513]

theorem envBound13195 : H12AffineFastState.Bounded env13195 := by
  intro p hp
  have h : env13195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13194_13195 : H12AffineEnvironment.transform 10 17 env13194 = env13195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13194 == env13195) = true)

def env13196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,16,98780,8328,65,4270122,5393,17664,109046,1500,4256860,256,21792,46213,74251]

theorem envBound13196 : H12AffineFastState.Bounded env13196 := by
  intro p hp
  have h : env13196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13174_13196 : H12AffineEnvironment.transform 20 4161 env13174 = env13196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13174 == env13196) = true)

theorem identity13196 : scanCanonicalize (H12AffineFastState.compose env13196 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13196 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,223718,1024,29909,4161,4194304,16,95496,8328,65,4270122,5393,17664,89378,1500,4194440,256,21792,16465,74251]

theorem envBound13197 : H12AffineFastState.Bounded env13197 := by
  intro p hp
  have h : env13197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13196_13197 : H12AffineEnvironment.transform 14 29908 env13196 = env13197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13196 == env13197) = true)

def env13198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212198,1024,8661,4161,4194304,16,73736,8328,65,4270122,5393,4096,67618,1500,4194440,256,32,5457,74251]

theorem envBound13198 : H12AffineFastState.Bounded env13198 := by
  intro p hp
  have h : env13198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13197_13198 : H12AffineEnvironment.transform 13 5376 env13197 = env13198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13197 == env13198) = true)

theorem identity13198 : scanCanonicalize (H12AffineFastState.compose env13198 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound13198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,67618,1024,8661,4161,4194304,16,73736,8328,65,4270122,5393,4096,67618,1500,4194440,256,32,5457,74251]

theorem envBound13199 : H12AffineFastState.Bounded env13199 := by
  intro p hp
  have h : env13199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13198_13199 : H12AffineEnvironment.transform 16 13508 env13198 = env13199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env13198 == env13199) = true)

theorem identity13199 : scanCanonicalize (H12AffineFastState.compose env13199 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13199 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,13508,10280,1024,8661,4161,4194304,16,2,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5457,513]

theorem envBound13200 : H12AffineFastState.Bounded env13200 := by
  intro p hp
  have h : env13200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13199_13200 : H12AffineEnvironment.transform 15 8202 env13199 = env13200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13199 == env13200) = true)

theorem identity13200 : scanCanonicalize (H12AffineFastState.compose env13200 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound13200 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,13508,10280,1024,8661,4161,112,16,2,8328,65,2128,5393,4096,10280,1500,248,256,32,5457,513]

theorem envBound13201 : H12AffineFastState.Bounded env13201 := by
  intro p hp
  have h : env13201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13200_13201 : H12AffineEnvironment.transform 21 112 env13200 = env13201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env13200 == env13201) = true)

theorem identity13201 : scanCanonicalize (H12AffineFastState.compose env13201 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13201 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env13202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,136,342,5528,2420,1024,137,4161,112,16,2,468,65,2128,5393,4096,2420,1500,248,256,32,5457,513]

theorem envBound13202 : H12AffineFastState.Bounded env13202 := by
  intro p hp
  have h : env13202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13201_13202 : H12AffineEnvironment.transform 12 348 env13201 = env13202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13201 == env13202) = true)

theorem identity13202 : scanCanonicalize (H12AffineFastState.compose env13202 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13202 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env13203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2420,1024,0,4161,112,16,2,349,65,2128,5393,4096,2420,1365,113,256,32,5457,513]

theorem envBound13203 : H12AffineFastState.Bounded env13203 := by
  intro p hp
  have h : env13203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13202_13203 : H12AffineEnvironment.transform 6 9 env13202 = env13203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13202 == env13203) = true)

def env13204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212199,1024,8660,4161,4194304,16,73737,8328,65,4270122,5393,4097,67619,1500,4194440,256,33,5456,74251]

theorem envBound13204 : H12AffineFastState.Bounded env13204 := by
  intro p hp
  have h : env13204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13197_13204 : H12AffineEnvironment.transform 13 5377 env13197 = env13204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13197 == env13204) = true)

theorem identity13204 : scanCanonicalize (H12AffineFastState.compose env13204 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound13204 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,67755,1024,8660,4161,4194304,16,73737,8328,65,4270122,5393,4097,67619,1500,4194440,256,33,5456,74251]

theorem envBound13205 : H12AffineFastState.Bounded env13205 := by
  intro p hp
  have h : env13205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13204_13205 : H12AffineEnvironment.transform 16 13388 env13204 = env13205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env13204 == env13205) = true)

theorem identity13205 : scanCanonicalize (H12AffineFastState.compose env13205 (packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound13205 : packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS < 2^1333 := by decide +kernel

def env13206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,67755,1024,8660,4161,8572,16,73737,8328,65,67926,5393,4097,67619,1500,8692,256,33,5456,74251]

theorem envBound13206 : H12AffineFastState.Bounded env13206 := by
  intro p hp
  have h : env13206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13205_13206 : H12AffineEnvironment.transform 21 8572 env13205 = env13206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env13205 == env13206) = true)

theorem identity13206 : scanCanonicalize (H12AffineFastState.compose env13206 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound13206 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env13207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,398,13388,2341,1024,8660,4161,8572,16,8583,8328,65,2264,5393,4097,2477,1500,8692,256,33,5456,9093]

theorem envBound13207 : H12AffineFastState.Bounded env13207 := by
  intro p hp
  have h : env13207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13206_13207 : H12AffineEnvironment.transform 15 398 env13206 = env13207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env13206 == env13207) = true)

theorem identity13207 : scanCanonicalize (H12AffineFastState.compose env13207 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13207 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env13208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,398,13340,2341,1024,8580,4113,8492,16,8583,8328,17,2184,5393,4097,2477,1420,8612,256,33,5376,9093]

theorem envBound13208 : H12AffineFastState.Bounded env13208 := by
  intro p hp
  have h : env13208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13207_13208 : H12AffineEnvironment.transform 5 16 env13207 = env13208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13207 == env13208) = true)

theorem identity13208 : scanCanonicalize (H12AffineFastState.compose env13208 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13208 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env13209 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,136,398,5393,2341,1024,137,4113,33,16,138,389,17,2184,5393,4097,2477,1420,169,256,33,5376,648]

theorem envBound13209 : H12AffineFastState.Bounded env13209 := by
  intro p hp
  have h : env13209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13208_13209 : H12AffineEnvironment.transform 12 269 env13208 = env13209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13208 == env13209) = true)

theorem identity13209 : scanCanonicalize (H12AffineFastState.compose env13209 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1464) := by decide +kernel

theorem selectedBound13209 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env13210 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1464,4096,269,5377,136,398,5393,1181,1024,137,4113,33,16,138,389,17,1328,5393,4097,1045,1420,169,256,33,5376,648]

theorem envBound13210 : H12AffineFastState.Bounded env13210 := by
  intro p hp
  have h : env13210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13209_13210 : H12AffineEnvironment.transform 10 1464 env13209 = env13210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1464 env13209 == env13210) = true)

theorem identity13210 : scanCanonicalize (H12AffineFastState.compose env13210 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound13210 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13211 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1464,1028,269,261,136,398,277,1181,1024,137,1045,33,16,138,389,17,1328,277,1029,1045,1420,169,256,33,260,648]

theorem envBound13211 : H12AffineFastState.Bounded env13211 := by
  intro p hp
  have h : env13211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13210_13211 : H12AffineEnvironment.transform 11 1028 env13210 = env13211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env13210 == env13211) = true)

theorem identity13211 : scanCanonicalize (H12AffineFastState.compose env13211 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13211 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env13212 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1045,1028,160,168,136,35,184,1181,1024,137,1045,33,16,138,40,17,1181,184,1029,1045,1057,169,173,33,169,648]

theorem envBound13212 : H12AffineFastState.Bounded env13212 := by
  intro p hp
  have h : env13212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13211_13212 : H12AffineEnvironment.transform 7 173 env13211 = env13212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13211 == env13212) = true)

theorem identity13212 : scanCanonicalize (H12AffineFastState.compose env13212 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13212 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13213 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1045,1028,41,33,1,35,49,1044,1024,0,1045,33,16,3,40,17,1044,49,1029,1045,1057,32,36,33,32,513]

theorem envBound13213 : H12AffineFastState.Bounded env13213 := by
  intro p hp
  have h : env13213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13212_13213 : H12AffineEnvironment.transform 6 9 env13212 = env13213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13212 == env13213) = true)

theorem identity13213 : scanCanonicalize (H12AffineFastState.compose env13213 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound13213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13214 : List Nat := [2,4,8,16,32,16,9,36,53,1024,1045,1028,41,33,1,35,49,1044,1024,0,1045,33,16,3,40,17,1044,49,1029,1045,1057,32,36,33,32,52]

theorem envBound13214 : H12AffineFastState.Bounded env13214 := by
  intro p hp
  have h : env13214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13213_13214 : H12AffineEnvironment.transform 8 53 env13213 = env13214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env13213 == env13214) = true)

theorem identity13214 : scanCanonicalize (H12AffineFastState.compose env13214 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13214 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13215 : List Nat := [2,4,8,16,32,16,9,36,53,53,32,49,41,33,1,35,49,33,53,0,32,33,16,3,40,17,33,49,48,32,20,32,36,33,32,52]

theorem envBound13215 : H12AffineFastState.Bounded env13215 := by
  intro p hp
  have h : env13215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13214_13215 : H12AffineEnvironment.transform 9 53 env13214 = env13215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13214 == env13215) = true)

theorem identity13215 : scanCanonicalize (H12AffineFastState.compose env13215 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound13215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13216 : List Nat := [2,4,8,8,32,8,9,36,45,45,32,41,41,33,1,35,41,33,45,0,32,33,8,3,40,9,33,41,40,32,12,32,36,33,32,44]

theorem envBound13216 : H12AffineFastState.Bounded env13216 := by
  intro p hp
  have h : env13216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13215_13216 : H12AffineEnvironment.transform 3 8 env13215 = env13216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env13215 == env13216) = true)

theorem identity13216 : scanCanonicalize (H12AffineFastState.compose env13216 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13216 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13217 : List Nat := [2,2,8,8,32,8,9,34,43,43,32,41,41,33,1,35,41,33,43,0,32,33,8,3,40,9,33,41,40,32,10,32,34,33,32,42]

theorem envBound13217 : H12AffineFastState.Bounded env13217 := by
  intro p hp
  have h : env13217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13216_13217 : H12AffineEnvironment.transform 1 2 env13216 = env13217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13216 == env13217) = true)

def env13218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound13218 : H12AffineFastState.Bounded env13218 := by
  intro p hp
  have h : env13218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13046_13218 : H12AffineEnvironment.transform 18 1025 env13046 = env13218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13046 == env13218) = true)

theorem identity13218 : scanCanonicalize (H12AffineFastState.compose env13218 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8685927) := by decide +kernel

theorem selectedBound13218 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8328,65,4409702,10817002,10507601,8830977,331127,15068326,257,2444747,2468975,273057]

theorem envBound13219 : H12AffineFastState.Bounded env13219 := by
  intro p hp
  have h : env13219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13218_13219 : H12AffineEnvironment.transform 23 8685927 env13218 = env13219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8685927 env13218 == env13219) = true)

def env13220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4409702,10816866,10507601,8830977,331127,15068206,257,2444611,2468975,272937]

theorem envBound13220 : H12AffineFastState.Bounded env13220 := by
  intro p hp
  have h : env13220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13219_13220 : H12AffineEnvironment.transform 6 8 env13219 = env13220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13219 == env13220) = true)

def env13221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4262262,10816866,10507601,8683537,331127,15068206,257,2444611,2468975,272937]

theorem envBound13221 : H12AffineFastState.Bounded env13221 := by
  intro p hp
  have h : env13221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13220_13221 : H12AffineEnvironment.transform 16 16400 env13220 = env13221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13220 == env13221) = true)

def env13222 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685879,8192,17,4262182,10816818,10507521,8683537,331047,15068206,257,2444563,2468927,272937]

theorem envBound13222 : H12AffineFastState.Bounded env13222 := by
  intro p hp
  have h : env13222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13221_13222 : H12AffineEnvironment.transform 5 16 env13221 = env13222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13221 == env13222) = true)

def env13223 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685879,8192,17,4262182,10815490,10506289,8683537,329751,15067422,257,2443299,2468111,272937]

theorem envBound13223 : H12AffineFastState.Bounded env13223 := by
  intro p hp
  have h : env13223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13222_13223 : H12AffineEnvironment.transform 9 304 env13222 = env13223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env13222 == env13223) = true)

theorem identity13223 : scanCanonicalize (H12AffineFastState.compose env13223 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound13223 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13224 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4194352,4491527,8192,17,4262182,6621234,6311937,4489249,329751,2484526,257,2443299,2468111,272937]

theorem envBound13224 : H12AffineFastState.Bounded env13224 := by
  intro p hp
  have h : env13224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13223_13224 : H12AffineEnvironment.transform 22 4194352 env13223 = env13224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env13223 == env13224) = true)

theorem identity13224 : scanCanonicalize (H12AffineFastState.compose env13224 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13224 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13225 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4194352,4235567,8192,17,4262182,6365210,6311937,4237321,73791,2212102,257,2187275,2195751,513]

theorem envBound13225 : H12AffineFastState.Bounded env13225 := by
  intro p hp
  have h : env13225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13224_13225 : H12AffineEnvironment.transform 17 10280 env13224 = env13225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13224 == env13225) = true)

theorem identity13225 : scanCanonicalize (H12AffineFastState.compose env13225 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 106539) := by decide +kernel

theorem selectedBound13225 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env13226 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,106539,106523,65796,8192,17,43277,2129969,2224170,67618,73791,2212102,257,2187275,2195751,513]

theorem envBound13226 : H12AffineFastState.Bounded env13226 := by
  intro p hp
  have h : env13226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13225_13226 : H12AffineEnvironment.transform 21 106539 env13225 = env13226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106539 env13225 == env13226) = true)

theorem identity13226 : scanCanonicalize (H12AffineFastState.compose env13226 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13226 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env13227 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,65536,16400,2341,305,32769,2097152,98598,98582,65796,269,17,34816,2129969,2216231,67618,65842,2212102,257,2179334,2195751,513]

theorem envBound13227 : H12AffineFastState.Bounded env13227 := by
  intro p hp
  have h : env13227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13226_13227 : H12AffineEnvironment.transform 12 269 env13226 = env13227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13226 == env13227) = true)

theorem identity13227 : scanCanonicalize (H12AffineFastState.compose env13227 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound13227 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13228 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,263,16400,2341,305,32769,2097152,32801,32785,3,269,17,34816,2129969,2150432,2341,53,2146305,257,2113537,2129952,513]

theorem envBound13228 : H12AffineFastState.Bounded env13228 := by
  intro p hp
  have h : env13228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13227_13228 : H12AffineEnvironment.transform 15 263 env13227 = env13228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env13227 == env13228) = true)

theorem identity13228 : scanCanonicalize (H12AffineFastState.compose env13228 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 16417) := by decide +kernel

theorem selectedBound13228 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13229 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,263,16400,2341,305,32769,16417,32801,32785,3,269,17,34816,49168,36865,2341,53,32800,257,32,49153,513]

theorem envBound13229 : H12AffineFastState.Bounded env13229 := by
  intro p hp
  have h : env13229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13228_13229 : H12AffineEnvironment.transform 20 16417 env13228 = env13229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16417 env13228 == env13229) = true)

theorem identity13229 : scanCanonicalize (H12AffineFastState.compose env13229 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 2058) := by decide +kernel

theorem selectedBound13229 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env13230 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,2058,263,16400,2341,305,2059,16417,2091,2075,3,269,17,10,18458,6155,2341,53,2090,257,32,18443,513]

theorem envBound13230 : H12AffineFastState.Bounded env13230 := by
  intro p hp
  have h : env13230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13229_13230 : H12AffineEnvironment.transform 14 2058 env13229 = env13230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2058 env13229 == env13230) = true)

def env13231 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685879,8192,17,4262182,10815491,10506288,8683537,329750,15067423,257,2443298,2468110,272937]

theorem envBound13231 : H12AffineFastState.Bounded env13231 := by
  intro p hp
  have h : env13231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13222_13231 : H12AffineEnvironment.transform 9 305 env13222 = env13231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env13222 == env13231) = true)

theorem identity13231 : scanCanonicalize (H12AffineFastState.compose env13231 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4466712) := by decide +kernel

theorem selectedBound13231 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13232 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4466712,4235567,8192,17,4262182,6365211,6584360,4237321,329750,2212103,257,2443298,2468110,272937]

theorem envBound13232 : H12AffineFastState.Bounded env13232 := by
  intro p hp
  have h : env13232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13231_13232 : H12AffineEnvironment.transform 22 4466712 env13231 = env13232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4466712 env13231 == env13232) = true)

def env13233 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,8192,16384,32768,65536,16400,262144,272,32769,2097152,4194304,4466712,4235535,8192,17,4262150,6365211,6584328,4237321,329750,2212103,257,2443266,2468110,272905]

theorem envBound13233 : H12AffineFastState.Bounded env13233 := by
  intro p hp
  have h : env13233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13232_13233 : H12AffineEnvironment.transform 4 0 env13232 = env13233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13232 == env13233) = true)

theorem identity13233 : scanCanonicalize (H12AffineFastState.compose env13233 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13233 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env13234 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,2097152,4194304,4458772,4227075,268,17,4262150,6357271,6576388,4229381,329750,2212103,257,2443266,2459650,264965]

theorem envBound13234 : H12AffineFastState.Bounded env13234 := by
  intro p hp
  have h : env13234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13233_13234 : H12AffineEnvironment.transform 12 268 env13233 = env13234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13233 == env13234) = true)

theorem identity13234 : scanCanonicalize (H12AffineFastState.compose env13234 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 280836) := by decide +kernel

theorem selectedBound13234 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13235 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,280836,4194304,4458772,4227075,268,17,4262150,4540435,4198400,4229381,329750,362499,257,65798,114950,264965]

theorem envBound13235 : H12AffineFastState.Bounded env13235 := by
  intro p hp
  have h : env13235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13234_13235 : H12AffineEnvironment.transform 20 280836 env13234 = env13235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 280836 env13234 == env13235) = true)

theorem identity13235 : scanCanonicalize (H12AffineFastState.compose env13235 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 362499) := by decide +kernel

theorem selectedBound13235 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env13236 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,280836,362499,98583,329728,268,17,295173,49168,366595,327942,329750,362499,257,65798,114950,264965]

theorem envBound13236 : H12AffineFastState.Bounded env13236 := by
  intro p hp
  have h : env13236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13235_13236 : H12AffineEnvironment.transform 21 362499 env13235 = env13236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362499 env13235 == env13236) = true)

theorem identity13236 : scanCanonicalize (H12AffineFastState.compose env13236 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound13236 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13237 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,2309,272,32769,16385,98566,98583,65797,268,17,34816,49168,102662,67587,65811,98566,257,65798,114950,512]

theorem envBound13237 : H12AffineFastState.Bounded env13237 := by
  intro p hp
  have h : env13237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13236_13237 : H12AffineEnvironment.transform 17 2309 env13236 = env13237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env13236 == env13237) = true)

theorem identity13237 : scanCanonicalize (H12AffineFastState.compose env13237 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound13237 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13238 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,33031,16400,2309,272,32769,16385,1,16,32770,268,17,34816,49168,4097,35076,32788,1,257,32769,16385,512]

theorem envBound13238 : H12AffineFastState.Bounded env13238 := by
  intro p hp
  have h : env13238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13237_13238 : H12AffineEnvironment.transform 15 33031 env13237 = env13238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env13237 == env13238) = true)

theorem identity13238 : scanCanonicalize (H12AffineFastState.compose env13238 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13238 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13239 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,0,263,16400,2309,272,1,16385,1,16,2,268,17,2048,16400,4097,2308,20,1,257,1,16385,512]

theorem envBound13239 : H12AffineFastState.Bounded env13239 := by
  intro p hp
  have h : env13239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13238_13239 : H12AffineEnvironment.transform 14 0 env13238 = env13239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13238 == env13239) = true)

def env13240 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,262144,273,32769,2097152,4194304,4466712,4235534,8192,17,4262151,6365211,6584329,4237321,329750,2212103,257,2443267,2468110,272904]

theorem envBound13240 : H12AffineFastState.Bounded env13240 := by
  intro p hp
  have h : env13240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13232_13240 : H12AffineEnvironment.transform 4 1 env13232 = env13240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13232 == env13240) = true)

theorem identity13240 : scanCanonicalize (H12AffineFastState.compose env13240 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound13240 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env13241 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,2309,273,32769,2097152,4194304,4202781,4235534,8192,17,4262151,6365211,6320396,4237321,65811,2212103,257,2179334,2203659,8973]

theorem envBound13241 : H12AffineFastState.Bounded env13241 := by
  intro p hp
  have h : env13241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13240_13241 : H12AffineEnvironment.transform 17 2309 env13240 = env13241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env13240 == env13241) = true)

theorem identity13241 : scanCanonicalize (H12AffineFastState.compose env13241 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 122890) := by decide +kernel

theorem selectedBound13241 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env13242 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,2309,273,32769,122890,4194304,4202781,4235534,8192,17,4262151,4243473,4296966,4237321,65811,8461,257,41228,16385,8973]

theorem envBound13242 : H12AffineFastState.Bounded env13242 := by
  intro p hp
  have h : env13242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13241_13242 : H12AffineEnvironment.transform 20 122890 env13241 = env13242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122890 env13241 == env13242) = true)

theorem identity13242 : scanCanonicalize (H12AffineFastState.compose env13242 (packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13242 : packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env13243 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,0,65536,16400,2309,273,1,90122,4194304,4202781,4202766,8192,17,4262151,4210705,4264198,4204553,65811,8461,257,8460,16385,8973]

theorem envBound13243 : H12AffineFastState.Bounded env13243 := by
  intro p hp
  have h : env13243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13242_13243 : H12AffineEnvironment.transform 14 0 env13242 = env13243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13242 == env13243) = true)

theorem identity13243 : scanCanonicalize (H12AffineFastState.compose env13243 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 65799) := by decide +kernel

theorem selectedBound13243 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env13244 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,0,65536,16400,2309,273,1,90122,65799,73754,73737,8192,17,2048,82198,4097,76046,65811,8461,257,8460,16385,8973]

theorem envBound13244 : H12AffineFastState.Bounded env13244 := by
  intro p hp
  have h : env13244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13243_13244 : H12AffineEnvironment.transform 21 65799 env13243 = env13244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65799 env13243 == env13244) = true)

theorem identity13244 : scanCanonicalize (H12AffineFastState.compose env13244 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound13244 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13245 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,4373,0,65536,4357,2309,273,1,78111,65799,73754,73737,8192,17,2048,69635,4097,76046,65811,8461,257,8460,4372,8973]

theorem envBound13245 : H12AffineFastState.Bounded env13245 := by
  intro p hp
  have h : env13245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13244_13245 : H12AffineEnvironment.transform 13 4373 env13244 = env13245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env13244 == env13245) = true)

theorem identity13245 : scanCanonicalize (H12AffineFastState.compose env13245 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound13245 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env13246 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,2325,8192,2048,0,65536,2064,2309,273,1,75786,65799,73754,73737,8192,17,2048,67862,2324,76046,65811,8461,257,8460,2049,8973]

theorem envBound13246 : H12AffineFastState.Bounded env13246 := by
  intro p hp
  have h : env13246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13245_13246 : H12AffineEnvironment.transform 11 2325 env13245 = env13246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env13245 == env13246) = true)

theorem identity13246 : scanCanonicalize (H12AffineFastState.compose env13246 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound13246 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env13247 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,2325,2056,2048,0,65536,2064,2309,273,1,65538,65799,67602,67585,2056,17,2048,67862,2324,65798,65811,2309,257,2308,2049,2821]

theorem envBound13247 : H12AffineFastState.Bounded env13247 := by
  intro p hp
  have h : env13247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13246_13247 : H12AffineEnvironment.transform 12 2056 env13246 = env13247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env13246 == env13247) = true)

theorem identity13247 : scanCanonicalize (H12AffineFastState.compose env13247 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound13247 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13248 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,16,269,261,0,65536,277,0,273,1,65538,65799,65815,65796,269,17,261,65555,17,65798,65811,0,257,1,260,512]

theorem envBound13248 : H12AffineFastState.Bounded env13248 := by
  intro p hp
  have h : env13248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13247_13248 : H12AffineEnvironment.transform 10 261 env13247 = env13248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env13247 == env13248) = true)

theorem identity13248 : scanCanonicalize (H12AffineFastState.compose env13248 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound13248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13249 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,16,269,261,0,262,277,0,273,1,260,1,17,2,269,17,261,277,17,0,21,0,257,1,260,512]

theorem envBound13249 : H12AffineFastState.Bounded env13249 := by
  intro p hp
  have h : env13249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13248_13249 : H12AffineEnvironment.transform 15 262 env13248 = env13249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env13248 == env13249) = true)

theorem identity13249 : scanCanonicalize (H12AffineFastState.compose env13249 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13250 : List Nat := [2,4,8,1,1,1,8,256,512,257,261,1,269,261,0,262,260,0,256,1,260,1,0,2,269,0,261,260,0,0,4,0,257,1,260,512]

theorem envBound13250 : H12AffineFastState.Bounded env13250 := by
  intro p hp
  have h : env13250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13249_13250 : H12AffineEnvironment.transform 3 1 env13249 = env13250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13249 == env13250) = true)

theorem identity13250 : scanCanonicalize (H12AffineFastState.compose env13250 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13250 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13251 : List Nat := [2,4,2,1,1,1,2,256,512,257,261,1,263,261,0,262,260,0,256,1,260,1,0,2,263,0,261,260,0,0,4,0,257,1,260,512]

theorem envBound13251 : H12AffineFastState.Bounded env13251 := by
  intro p hp
  have h : env13251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13250_13251 : H12AffineEnvironment.transform 2 2 env13250 = env13251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13250 == env13251) = true)

theorem identity13251 : scanCanonicalize (H12AffineFastState.compose env13251 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound13251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13252 : List Nat := [2,4,2,1,1,1,2,256,6,257,261,1,263,261,0,262,260,0,256,1,260,1,0,2,263,0,261,260,0,0,4,0,257,1,260,6]

theorem envBound13252 : H12AffineFastState.Bounded env13252 := by
  intro p hp
  have h : env13252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13251_13252 : H12AffineEnvironment.transform 8 6 env13251 = env13252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env13251 == env13252) = true)

theorem identity13252 : scanCanonicalize (H12AffineFastState.compose env13252 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13252 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13253 : List Nat := [2,4,2,1,1,1,2,4,6,5,1,1,3,1,0,2,0,0,4,1,0,1,0,2,3,0,1,0,0,0,4,0,5,1,0,6]

theorem envBound13253 : H12AffineFastState.Bounded env13253 := by
  intro p hp
  have h : env13253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13252_13253 : H12AffineEnvironment.transform 7 4 env13252 = env13253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13252 == env13253) = true)

theorem identity13253 : scanCanonicalize (H12AffineFastState.compose env13253 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound13253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13254 : List Nat := [0,4,0,1,1,1,0,4,4,5,1,1,1,1,0,0,0,0,4,1,0,1,0,0,1,0,1,0,0,0,4,0,5,1,0,4]

theorem envBound13254 : H12AffineFastState.Bounded env13254 := by
  intro p hp
  have h : env13254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13253_13254 : H12AffineEnvironment.transform 0 0 env13253 = env13254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env13253 == env13254) = true)

def env13255 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685878,8192,16,4262183,10816819,10507520,8683537,331046,15068206,257,2444562,2468926,272937]

theorem envBound13255 : H12AffineFastState.Bounded env13255 := by
  intro p hp
  have h : env13255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13221_13255 : H12AffineEnvironment.transform 5 17 env13221 = env13255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13221 == env13255) = true)

def env13256 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685878,8192,16,4262183,10815491,10506288,8683537,329750,15067422,257,2443298,2468110,272937]

theorem envBound13256 : H12AffineFastState.Bounded env13256 := by
  intro p hp
  have h : env13256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13255_13256 : H12AffineEnvironment.transform 9 304 env13255 = env13256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env13255 == env13256) = true)

theorem identity13256 : scanCanonicalize (H12AffineFastState.compose env13256 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4268090) := by decide +kernel

theorem selectedBound13256 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13257 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4268090,4565260,8192,16,4262183,6563897,6385674,4562987,329750,2410788,257,2443298,2468110,272937]

theorem envBound13257 : H12AffineFastState.Bounded env13257 := by
  intro p hp
  have h : env13257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13256_13257 : H12AffineEnvironment.transform 22 4268090 env13256 = env13257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268090 env13256 == env13257) = true)

theorem identity13257 : scanCanonicalize (H12AffineFastState.compose env13257 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13257 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env13258 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4268090,4292900,8192,16,4262183,6291473,6385674,4294659,73790,2154764,257,2187274,2195750,513]

theorem envBound13258 : H12AffineFastState.Bounded env13258 := by
  intro p hp
  have h : env13258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13257_13258 : H12AffineEnvironment.transform 17 10280 env13257 = env13258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13257 == env13258) = true)

theorem identity13258 : scanCanonicalize (H12AffineFastState.compose env13258 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13258 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env13259 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,0,65536,16400,10280,305,1,2097152,4194304,4268090,4260132,8192,16,4262183,6291473,6385674,4261891,73790,2121996,257,2187274,2162982,513]

theorem envBound13259 : H12AffineFastState.Bounded env13259 := by
  intro p hp
  have h : env13259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13258_13259 : H12AffineEnvironment.transform 14 0 env13258 = env13259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13258 == env13259) = true)

theorem identity13259 : scanCanonicalize (H12AffineFastState.compose env13259 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13259 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13260 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,0,8203,16400,10280,305,1,2097152,4194304,4194353,4202799,8192,16,4204844,6291473,6311937,4204552,53,2121996,257,2113537,2105645,513]

theorem envBound13260 : H12AffineFastState.Bounded env13260 := by
  intro p hp
  have h : env13260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13259_13260 : H12AffineEnvironment.transform 15 8203 env13259 = env13260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13259 == env13260) = true)

theorem identity13260 : scanCanonicalize (H12AffineFastState.compose env13260 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113537) := by decide +kernel

theorem selectedBound13260 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13261 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,0,8203,16400,10280,305,1,2097152,2113537,2113584,2122030,8192,16,2124077,16400,4096,2123785,53,2121996,257,2113537,2105645,513]

theorem envBound13261 : H12AffineFastState.Bounded env13261 := by
  intro p hp
  have h : env13261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13260_13261 : H12AffineEnvironment.transform 21 2113537 env13260 = env13261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113537 env13260 == env13261) = true)

theorem identity13261 : scanCanonicalize (H12AffineFastState.compose env13261 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24876) := by decide +kernel

theorem selectedBound13261 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13262 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,0,8203,16400,10280,305,1,24876,8493,8476,2,8192,16,2049,16400,4096,2341,53,32,257,8493,16385,513]

theorem envBound13262 : H12AffineFastState.Bounded env13262 := by
  intro p hp
  have h : env13262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13261_13262 : H12AffineEnvironment.transform 20 24876 env13261 = env13262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24876 env13261 == env13262) = true)

theorem identity13262 : scanCanonicalize (H12AffineFastState.compose env13262 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13262 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13263 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,269,16384,0,262,16400,2341,305,1,16417,32,17,2,269,16,2049,16400,4096,2341,53,32,257,32,16385,513]

theorem envBound13263 : H12AffineFastState.Bounded env13263 := by
  intro p hp
  have h : env13263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13262_13263 : H12AffineEnvironment.transform 12 269 env13262 = env13263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13262 == env13263) = true)

theorem identity13263 : scanCanonicalize (H12AffineFastState.compose env13263 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13263 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13264 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,269,16384,0,262,16400,2309,273,1,16385,0,17,2,269,16,2049,16400,4096,2309,21,0,257,0,16385,513]

theorem envBound13264 : H12AffineFastState.Bounded env13264 := by
  intro p hp
  have h : env13264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13263_13264 : H12AffineEnvironment.transform 4 0 env13263 = env13264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13263 == env13264) = true)

theorem identity13264 : scanCanonicalize (H12AffineFastState.compose env13264 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13264 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13265 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,17,269,16384,0,262,16400,2309,273,1,16385,0,17,2,269,16,2049,16400,17,2309,21,0,257,0,16385,513]

theorem envBound13265 : H12AffineFastState.Bounded env13265 := by
  intro p hp
  have h : env13265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13264_13265 : H12AffineEnvironment.transform 11 17 env13264 = env13265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13264 == env13265) = true)

theorem identity13265 : scanCanonicalize (H12AffineFastState.compose env13265 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound13265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13266 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,17,269,513,0,262,529,2309,273,1,512,0,17,2,269,16,2049,529,17,2309,21,0,257,0,512,513]

theorem envBound13266 : H12AffineFastState.Bounded env13266 := by
  intro p hp
  have h : env13266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13265_13266 : H12AffineEnvironment.transform 13 513 env13265 = env13266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env13265 == env13266) = true)

theorem identity13266 : scanCanonicalize (H12AffineFastState.compose env13266 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound13266 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13267 : List Nat := [2,4,8,16,0,17,8,256,512,272,529,17,269,513,0,262,529,788,273,1,512,0,17,2,269,16,528,529,17,788,21,0,257,0,512,513]

theorem envBound13267 : H12AffineFastState.Bounded env13267 := by
  intro p hp
  have h : env13267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13266_13267 : H12AffineEnvironment.transform 10 529 env13266 = env13267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env13266 == env13267) = true)

theorem identity13267 : scanCanonicalize (H12AffineFastState.compose env13267 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13267 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13268 : List Nat := [2,4,8,0,0,1,8,256,512,256,513,1,269,513,0,262,513,772,257,1,512,0,1,2,269,0,512,513,1,772,5,0,257,0,512,513]

theorem envBound13268 : H12AffineFastState.Bounded env13268 := by
  intro p hp
  have h : env13268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13267_13268 : H12AffineEnvironment.transform 3 0 env13267 = env13268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13267 == env13268) = true)

theorem identity13268 : scanCanonicalize (H12AffineFastState.compose env13268 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13268 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13269 : List Nat := [2,4,8,0,0,1,8,256,261,256,260,1,269,260,0,262,260,1,257,1,261,0,1,2,269,0,261,260,1,1,5,0,257,0,261,260]

theorem envBound13269 : H12AffineFastState.Bounded env13269 := by
  intro p hp
  have h : env13269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13268_13269 : H12AffineEnvironment.transform 8 261 env13268 = env13269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13268 == env13269) = true)

theorem identity13269 : scanCanonicalize (H12AffineFastState.compose env13269 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13270 : List Nat := [2,4,8,0,0,1,8,5,0,5,1,1,8,1,0,3,1,1,4,1,0,0,1,2,8,0,0,1,1,1,5,0,4,0,0,1]

theorem envBound13270 : H12AffineFastState.Bounded env13270 := by
  intro p hp
  have h : env13270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13269_13270 : H12AffineEnvironment.transform 7 5 env13269 = env13270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13269 == env13270) = true)

def env13271 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685878,8192,16,4262183,10815490,10506289,8683537,329751,15067423,257,2443299,2468111,272937]

theorem envBound13271 : H12AffineFastState.Bounded env13271 := by
  intro p hp
  have h : env13271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13255_13271 : H12AffineEnvironment.transform 9 305 env13255 = env13271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env13255 == env13271) = true)

theorem identity13271 : scanCanonicalize (H12AffineFastState.compose env13271 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4524050) := by decide +kernel

theorem selectedBound13271 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13272 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4524050,4292900,8192,16,4262183,6291472,6641699,4294659,329751,2154765,257,2443299,2468111,272937]

theorem envBound13272 : H12AffineFastState.Bounded env13272 := by
  intro p hp
  have h : env13272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13271_13272 : H12AffineEnvironment.transform 22 4524050 env13271 = env13272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4524050 env13271 == env13272) = true)

def env13273 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4268090,4292900,8192,16,4262183,6291472,6385675,4294659,73791,2154765,257,2187275,2195751,513]

theorem envBound13273 : H12AffineFastState.Bounded env13273 := by
  intro p hp
  have h : env13273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13272_13273 : H12AffineEnvironment.transform 17 10280 env13272 = env13273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13272 == env13273) = true)

theorem identity13273 : scanCanonicalize (H12AffineFastState.compose env13273 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13273 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env13274 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,0,65536,16400,10280,304,1,2097152,4194304,4268090,4260132,8192,16,4262183,6291472,6385675,4261891,73791,2121997,257,2187275,2162983,513]

theorem envBound13274 : H12AffineFastState.Bounded env13274 := by
  intro p hp
  have h : env13274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13273_13274 : H12AffineEnvironment.transform 14 0 env13273 = env13274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13273 == env13274) = true)

theorem identity13274 : scanCanonicalize (H12AffineFastState.compose env13274 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13274 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13275 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,0,8203,16400,10280,304,1,2097152,4194304,4194353,4202799,8192,16,4204844,6291472,6311936,4204552,52,2121997,257,2113536,2105644,513]

theorem envBound13275 : H12AffineFastState.Bounded env13275 := by
  intro p hp
  have h : env13275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13274_13275 : H12AffineEnvironment.transform 15 8203 env13274 = env13275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13274 == env13275) = true)

theorem identity13275 : scanCanonicalize (H12AffineFastState.compose env13275 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113536) := by decide +kernel

theorem selectedBound13275 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13276 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,0,8203,16400,10280,304,1,2097152,2113536,2113585,2122031,8192,16,2124076,16400,4096,2123784,52,2121997,257,2113536,2105644,513]

theorem envBound13276 : H12AffineFastState.Bounded env13276 := by
  intro p hp
  have h : env13276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13275_13276 : H12AffineEnvironment.transform 21 2113536 env13275 = env13276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113536 env13275 == env13276) = true)

theorem identity13276 : scanCanonicalize (H12AffineFastState.compose env13276 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24877) := by decide +kernel

theorem selectedBound13276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13277 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,0,8203,16400,10280,304,1,24877,8493,8476,2,8192,16,2049,16400,4096,2341,52,32,257,8493,16385,513]

theorem envBound13277 : H12AffineFastState.Bounded env13277 := by
  intro p hp
  have h : env13277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13276_13277 : H12AffineEnvironment.transform 20 24877 env13276 = env13277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24877 env13276 == env13277) = true)

theorem identity13277 : scanCanonicalize (H12AffineFastState.compose env13277 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13277 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13278 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,269,16384,0,262,16400,2341,304,1,16416,32,17,2,269,16,2049,16400,4096,2341,52,32,257,32,16385,513]

theorem envBound13278 : H12AffineFastState.Bounded env13278 := by
  intro p hp
  have h : env13278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13277_13278 : H12AffineEnvironment.transform 12 269 env13277 = env13278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13277 == env13278) = true)

theorem identity13278 : scanCanonicalize (H12AffineFastState.compose env13278 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13279 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,4096,269,16384,0,262,16400,2309,272,1,16384,0,17,2,269,16,2049,16400,4096,2309,20,0,257,0,16385,513]

theorem envBound13279 : H12AffineFastState.Bounded env13279 := by
  intro p hp
  have h : env13279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13278_13279 : H12AffineEnvironment.transform 4 0 env13278 = env13279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13278 == env13279) = true)

theorem identity13279 : scanCanonicalize (H12AffineFastState.compose env13279 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13279 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13280 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,17,269,16384,0,262,16400,2309,272,1,16384,0,17,2,269,16,2049,16400,17,2309,20,0,257,0,16385,513]

theorem envBound13280 : H12AffineFastState.Bounded env13280 := by
  intro p hp
  have h : env13280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13279_13280 : H12AffineEnvironment.transform 11 17 env13279 = env13280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13279 == env13280) = true)

theorem identity13280 : scanCanonicalize (H12AffineFastState.compose env13280 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound13280 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13281 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,17,269,512,0,262,528,2309,272,1,512,0,17,2,269,16,2049,528,17,2309,20,0,257,0,513,513]

theorem envBound13281 : H12AffineFastState.Bounded env13281 := by
  intro p hp
  have h : env13281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13280_13281 : H12AffineEnvironment.transform 13 512 env13280 = env13281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env13280 == env13281) = true)

theorem identity13281 : scanCanonicalize (H12AffineFastState.compose env13281 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound13281 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13282 : List Nat := [2,4,8,16,0,17,8,256,512,273,529,17,269,512,0,262,528,788,272,1,512,0,17,2,269,16,528,528,17,788,20,0,257,0,513,513]

theorem envBound13282 : H12AffineFastState.Bounded env13282 := by
  intro p hp
  have h : env13282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13281_13282 : H12AffineEnvironment.transform 10 529 env13281 = env13282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env13281 == env13282) = true)

theorem identity13282 : scanCanonicalize (H12AffineFastState.compose env13282 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13282 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13283 : List Nat := [2,4,8,1,0,0,8,256,512,256,512,0,269,512,0,262,513,773,257,1,512,0,0,2,269,1,513,513,0,773,5,0,257,0,513,513]

theorem envBound13283 : H12AffineFastState.Bounded env13283 := by
  intro p hp
  have h : env13283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13282_13283 : H12AffineEnvironment.transform 3 1 env13282 = env13283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13282 == env13283) = true)

theorem identity13283 : scanCanonicalize (H12AffineFastState.compose env13283 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13283 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13284 : List Nat := [2,4,8,1,0,0,8,256,261,256,261,0,269,261,0,262,260,0,257,1,261,0,0,2,269,1,260,260,0,0,5,0,257,0,260,260]

theorem envBound13284 : H12AffineFastState.Bounded env13284 := by
  intro p hp
  have h : env13284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13283_13284 : H12AffineEnvironment.transform 8 261 env13283 = env13284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13283 == env13284) = true)

def env13285 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,4194304,4268091,4292900,8192,16,4262183,6291472,6385674,4294659,73790,2154765,257,2187274,2195750,512]

theorem envBound13285 : H12AffineFastState.Bounded env13285 := by
  intro p hp
  have h : env13285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13272_13285 : H12AffineEnvironment.transform 17 10281 env13272 = env13285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13272 == env13285) = true)

theorem identity13285 : scanCanonicalize (H12AffineFastState.compose env13285 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(21+1) ^^^ 2226235) := by decide +kernel

theorem selectedBound13285 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env13286 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,2226235,2152448,2128159,8192,16,2158876,129067,34865,2125880,73790,2154765,257,2187274,2195750,512]

theorem envBound13286 : H12AffineFastState.Bounded env13286 := by
  intro p hp
  have h : env13286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13285_13286 : H12AffineEnvironment.transform 21 2226235 env13285 = env13286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2226235 env13285 == env13286) = true)

theorem identity13286 : scanCanonicalize (H12AffineFastState.compose env13286 (packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 47131) := by decide +kernel

theorem selectedBound13286 : packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env13287 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,47131,16400,10281,304,32769,2097152,2113568,2152448,2128159,8192,16,2158876,16432,34865,2125880,38949,2154765,257,2152465,2111805,512]

theorem envBound13287 : H12AffineFastState.Bounded env13287 := by
  intro p hp
  have h : env13287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13286_13287 : H12AffineEnvironment.transform 15 47131 env13286 = env13287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47131 env13286 == env13287) = true)

theorem identity13287 : scanCanonicalize (H12AffineFastState.compose env13287 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 55312) := by decide +kernel

theorem selectedBound13287 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13288 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,47131,16400,10281,304,32769,55312,38960,16,41231,8192,16,10508,16432,34865,43048,38949,14621,257,1,57645,512]

theorem envBound13288 : H12AffineFastState.Bounded env13288 := by
  intro p hp
  have h : env13288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13287_13288 : H12AffineEnvironment.transform 20 55312 env13287 = env13288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 55312 env13287 == env13288) = true)

theorem identity13288 : scanCanonicalize (H12AffineFastState.compose env13288 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 26665) := by decide +kernel

theorem selectedBound13288 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env13289 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,26665,20530,16400,10281,304,26664,12345,28697,16,18726,8192,16,10508,16432,24600,16385,28684,14621,257,1,2308,512]

theorem envBound13289 : H12AffineFastState.Bounded env13289 := by
  intro p hp
  have h : env13289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13288_13289 : H12AffineEnvironment.transform 14 26665 env13288 = env13289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26665 env13288 == env13289) = true)

theorem identity13289 : scanCanonicalize (H12AffineFastState.compose env13289 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound13289 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13290 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,6168,16384,20529,20530,16400,4145,304,20528,2081,18433,16,18726,6168,16,4372,16432,22528,16385,18452,261,257,1,2308,512]

theorem envBound13290 : H12AffineFastState.Bounded env13290 := by
  intro p hp
  have h : env13290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13289_13290 : H12AffineEnvironment.transform 12 6168 env13289 = env13290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env13289 == env13290) = true)

theorem identity13290 : scanCanonicalize (H12AffineFastState.compose env13290 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound13290 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env13291 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,6168,4405,260,263,4389,4145,304,261,2081,6452,16,6163,6168,16,4372,4357,2357,4404,6433,261,257,1,2308,512]

theorem envBound13291 : H12AffineFastState.Bounded env13291 := by
  intro p hp
  have h : env13291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13290_13291 : H12AffineEnvironment.transform 13 4405 env13290 = env13291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env13290 == env13291) = true)

theorem identity13291 : scanCanonicalize (H12AffineFastState.compose env13291 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13291 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13292 : List Nat := [2,4,8,16,32,17,8,37,512,20,2048,4096,6168,4112,33,34,4096,4145,21,32,2081,6161,16,6163,6168,16,4145,4128,2064,4113,6148,32,36,1,2081,512]

theorem envBound13292 : H12AffineFastState.Bounded env13292 := by
  intro p hp
  have h : env13292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13291_13292 : H12AffineEnvironment.transform 7 37 env13291 = env13292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13291 == env13292) = true)

theorem identity13292 : scanCanonicalize (H12AffineFastState.compose env13292 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13292 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13293 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,4096,6168,4112,0,3,4096,4112,21,1,2048,6161,16,6163,6168,16,4112,4097,2064,4113,6148,1,5,1,2048,512]

theorem envBound13293 : H12AffineFastState.Bounded env13293 := by
  intro p hp
  have h : env13293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13292_13293 : H12AffineEnvironment.transform 4 1 env13292 = env13293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13292 == env13293) = true)

theorem identity13293 : scanCanonicalize (H12AffineFastState.compose env13293 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13293 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13294 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,4096,4120,4112,0,3,4096,4112,21,1,0,4113,16,4115,4120,16,4112,4097,16,4113,4100,1,5,1,0,512]

theorem envBound13294 : H12AffineFastState.Bounded env13294 := by
  intro p hp
  have h : env13294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0