import H12CloudChart0Data096

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound24547 : H12AffineFastState.Bounded env24547 := by
  intro p hp
  have h : env24547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24546_24547 : H12AffineEnvironment.transform 2 2 env24546 = env24547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24546 == env24547) = true)

theorem identity24547 : scanCanonicalize (H12AffineFastState.compose env24547 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound24547 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24548 : List Nat := [2,4,2,1,32,1,3,36,512,37,513,513,35,512,1,35,513,513,37,0,513,32,0,2,34,0,512,512,512,513,4,33,36,32,512,513]

theorem envBound24548 : H12AffineFastState.Bounded env24548 := by
  intro p hp
  have h : env24548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24547_24548 : H12AffineEnvironment.transform 10 513 env24547 = env24548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env24547 == env24548) = true)

def env24549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441760,95496,8328,65,270377,436384,45524,32160,412856,156013,256,21792,46213,486255]

theorem envBound24549 : H12AffineFastState.Bounded env24549 := by
  intro p hp
  have h : env24549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24519_24549 : H12AffineEnvironment.transform 21 272513 env24519 = env24549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24519 == env24549) = true)

theorem identity24549 : scanCanonicalize (H12AffineFastState.compose env24549 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound24549 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,115871,243003,73754,95496,8328,65,245139,79130,45524,32160,119042,156013,256,21792,46213,63189]

theorem envBound24550 : H12AffineFastState.Bounded env24550 := by
  intro p hp
  have h : env24550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24549_24550 : H12AffineEnvironment.transform 17 236986 env24549 = env24550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env24549 == env24550) = true)

def env24551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67754,1024,32769,115871,73771,73754,95496,8328,65,75907,79130,45524,32160,119042,62589,256,21792,46213,63189]

theorem envBound24551 : H12AffineFastState.Bounded env24551 := by
  intro p hp
  have h : env24551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24550_24551 : H12AffineEnvironment.transform 16 38160 env24550 = env24551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24550 == env24551) = true)

theorem identity24551 : scanCanonicalize (H12AffineFastState.compose env24551 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound24551 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env24552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38160,56436,1024,32769,4161,62709,62660,41430,8328,65,64605,57796,45524,32160,1500,62589,256,21792,46213,63189]

theorem envBound24552 : H12AffineFastState.Bounded env24552 := by
  intro p hp
  have h : env24552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24551_24552 : H12AffineEnvironment.transform 15 54494 env24551 = env24552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env24551 == env24552) = true)

theorem identity24552 : scanCanonicalize (H12AffineFastState.compose env24552 (packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24552 : packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env24553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,21726,5392,23668,1024,1,4161,29941,29892,8662,8328,65,31837,25028,12756,32160,1500,29821,256,21792,13445,30421]

theorem envBound24553 : H12AffineFastState.Bounded env24553 := by
  intro p hp
  have h : env24553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24552_24553 : H12AffineEnvironment.transform 14 0 env24552 = env24553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24552 == env24553) = true)

theorem identity24553 : scanCanonicalize (H12AffineFastState.compose env24553 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound24553 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env24554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,0,21726,5392,23668,1024,1,4161,21792,21777,3,349,65,23944,16401,4097,23669,1500,21928,256,21792,5456,22272]

theorem envBound24554 : H12AffineFastState.Bounded env24554 := by
  intro p hp
  have h : env24554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24553_24554 : H12AffineEnvironment.transform 12 469 env24553 = env24554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env24553 == env24554) = true)

theorem identity24554 : scanCanonicalize (H12AffineFastState.compose env24554 (packedSelected [0,1,3,4,5,6,7,8,9,11,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound24554 : packedSelected [0,1,3,4,5,6,7,8,9,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24555 : List Nat := [2,4,8,16,32,64,128,141,512,1024,2048,4096,88,16384,0,21726,5277,23668,1024,1,4161,21677,21660,3,208,65,23557,16401,4097,23669,1105,21541,141,21677,5341,22157]

theorem envBound24555 : H12AffineFastState.Bounded env24555 := by
  intro p hp
  have h : env24555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24554_24555 : H12AffineEnvironment.transform 7 141 env24554 = env24555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env24554 == env24555) = true)

theorem identity24555 : scanCanonicalize (H12AffineFastState.compose env24555 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5341) := by decide +kernel

theorem selectedBound24555 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env24556 : List Nat := [2,4,8,16,32,64,128,141,512,1024,2048,4096,88,5341,0,3,5277,2217,1024,1,4161,112,65,3,208,65,2264,5324,4097,2216,1105,248,141,112,5341,592]

theorem envBound24556 : H12AffineFastState.Bounded env24556 := by
  intro p hp
  have h : env24556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24555_24556 : H12AffineEnvironment.transform 13 5341 env24555 = env24556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5341 env24555 == env24556) = true)

theorem identity24556 : scanCanonicalize (H12AffineFastState.compose env24556 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24556 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24557 : List Nat := [2,4,8,16,32,64,89,84,512,1024,2048,4096,88,5124,0,3,5188,2160,1024,1,4161,112,65,3,9,65,2049,5141,4097,2161,1105,33,84,112,5124,592]

theorem envBound24557 : H12AffineFastState.Bounded env24557 := by
  intro p hp
  have h : env24557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24556_24557 : H12AffineEnvironment.transform 6 89 env24556 = env24557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24556 == env24557) = true)

theorem identity24557 : scanCanonicalize (H12AffineFastState.compose env24557 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24557 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env24558 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5124,0,3,5140,2080,1024,1,4113,32,17,3,9,17,2049,5141,4097,2081,1025,33,4,32,5124,512]

theorem envBound24558 : H12AffineFastState.Bounded env24558 := by
  intro p hp
  have h : env24558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24557_24558 : H12AffineEnvironment.transform 5 16 env24557 = env24558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24557 == env24558) = true)

theorem identity24558 : scanCanonicalize (H12AffineFastState.compose env24558 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24559 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,0,3,5140,2049,1024,1,4113,1,17,3,9,17,2049,5141,4097,2048,1025,0,4,1,5124,512]

theorem envBound24559 : H12AffineFastState.Bounded env24559 := by
  intro p hp
  have h : env24559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24558_24559 : H12AffineEnvironment.transform 4 1 env24558 = env24559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24558 == env24559) = true)

def env24560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67755,1024,32769,115871,73770,73754,95496,8328,65,75906,79130,45524,32160,119042,62588,256,21792,46213,63189]

theorem envBound24560 : H12AffineFastState.Bounded env24560 := by
  intro p hp
  have h : env24560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24550_24560 : H12AffineEnvironment.transform 16 38161 env24550 = env24560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24550 == env24560) = true)

theorem identity24560 : scanCanonicalize (H12AffineFastState.compose env24560 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24560 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env24561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10401,1024,32769,58517,32,16,21762,8328,65,2184,5392,45524,32160,61704,62588,256,21792,46213,63189]

theorem envBound24561 : H12AffineFastState.Bounded env24561 := by
  intro p hp
  have h : env24561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24560_24561 : H12AffineEnvironment.transform 15 8202 env24560 = env24561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24560 == env24561) = true)

theorem identity24561 : scanCanonicalize (H12AffineFastState.compose env24561 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound24561 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env24562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,38161,10401,1024,32769,36928,32,16,8663,8328,65,2184,5392,45524,2421,34269,32937,256,8693,46213,33280]

theorem envBound24562 : H12AffineFastState.Bounded env24562 := by
  intro p hp
  have h : env24562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24561_24562 : H12AffineEnvironment.transform 13 13525 env24561 = env24562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env24561 == env24562) = true)

theorem identity24562 : scanCanonicalize (H12AffineFastState.compose env24562 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24562 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env24563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,8202,5393,10401,1024,1,4160,32,16,8663,8328,65,2184,5392,12756,2421,1501,169,256,8693,13445,512]

theorem envBound24563 : H12AffineFastState.Bounded env24563 := by
  intro p hp
  have h : env24563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24562_24563 : H12AffineEnvironment.transform 14 0 env24562 = env24563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24562 == env24563) = true)

theorem identity24563 : scanCanonicalize (H12AffineFastState.compose env24563 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24563 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24564 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13525,0,8202,5393,10368,1024,1,4160,1,16,8663,8328,65,2184,5392,12756,2388,1501,136,256,8660,13445,512]

theorem envBound24564 : H12AffineFastState.Bounded env24564 := by
  intro p hp
  have h : env24564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24563_24564 : H12AffineEnvironment.transform 4 1 env24563 = env24564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24563 == env24564) = true)

theorem identity24564 : scanCanonicalize (H12AffineFastState.compose env24564 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24564 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env24565 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8192,13525,0,8202,5189,10368,1024,1,4160,1,16,8323,8328,65,2184,5188,12416,2048,1161,136,84,8320,13445,512]

theorem envBound24565 : H12AffineFastState.Bounded env24565 := by
  intro p hp
  have h : env24565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24564_24565 : H12AffineEnvironment.transform 7 84 env24564 = env24565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24564 == env24565) = true)

theorem identity24565 : scanCanonicalize (H12AffineFastState.compose env24565 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound24565 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env24566 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,129,5204,0,139,5189,2049,1024,1,4160,1,16,2,9,65,2184,5188,4097,2048,1161,136,84,1,5124,512]

theorem envBound24566 : H12AffineFastState.Bounded env24566 := by
  intro p hp
  have h : env24566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24565_24566 : H12AffineEnvironment.transform 12 129 env24565 = env24566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env24565 == env24566) = true)

theorem identity24566 : scanCanonicalize (H12AffineFastState.compose env24566 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound24566 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24567 : List Nat := [2,4,8,16,1,64,128,84,512,1024,136,4096,129,5204,0,139,5189,137,1024,1,4160,1,16,2,9,65,0,5188,4097,136,1161,136,84,1,5124,512]

theorem envBound24567 : H12AffineFastState.Bounded env24567 := by
  intro p hp
  have h : env24567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24566_24567 : H12AffineEnvironment.transform 10 136 env24566 = env24567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env24566 == env24567) = true)

theorem identity24567 : scanCanonicalize (H12AffineFastState.compose env24567 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24567 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24568 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1,4096,8,5204,0,2,5189,0,1024,1,4160,1,16,2,9,65,0,5188,4097,1,1024,1,84,1,5124,512]

theorem envBound24568 : H12AffineFastState.Bounded env24568 := by
  intro p hp
  have h : env24568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24567_24568 : H12AffineEnvironment.transform 6 9 env24567 = env24568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24567 == env24568) = true)

theorem identity24568 : scanCanonicalize (H12AffineFastState.compose env24568 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound24568 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24569 : List Nat := [2,4,8,16,1,64,9,84,512,69,1,4096,8,4113,0,2,4096,0,69,1,4160,1,16,2,9,65,0,4097,4097,1,69,1,84,1,4161,512]

theorem envBound24569 : H12AffineFastState.Bounded env24569 := by
  intro p hp
  have h : env24569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24568_24569 : H12AffineEnvironment.transform 9 69 env24568 = env24569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env24568 == env24569) = true)

theorem identity24569 : scanCanonicalize (H12AffineFastState.compose env24569 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound24569 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24570 : List Nat := [2,4,8,16,1,4,9,16,512,1,1,4096,8,4113,0,2,4096,0,1,1,4100,1,16,2,9,5,0,4097,4097,1,1,1,16,1,4101,512]

theorem envBound24570 : H12AffineFastState.Bounded env24570 := by
  intro p hp
  have h : env24570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24569_24570 : H12AffineEnvironment.transform 5 4 env24569 = env24570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env24569 == env24570) = true)

theorem identity24570 : scanCanonicalize (H12AffineFastState.compose env24570 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24570 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24571 : List Nat := [2,4,8,16,1,4,9,16,512,1,1,17,8,0,0,2,17,0,1,1,21,1,16,2,9,5,0,16,16,1,1,1,16,1,20,512]

theorem envBound24571 : H12AffineFastState.Bounded env24571 := by
  intro p hp
  have h : env24571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24570_24571 : H12AffineEnvironment.transform 11 17 env24570 = env24571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24570 == env24571) = true)

theorem identity24571 : scanCanonicalize (H12AffineFastState.compose env24571 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound24571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24572 : List Nat := [2,4,8,16,1,4,9,16,5,1,1,17,8,0,0,2,17,0,1,1,21,1,16,2,9,5,0,16,16,1,1,1,16,1,20,5]

theorem envBound24572 : H12AffineFastState.Bounded env24572 := by
  intro p hp
  have h : env24572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24571_24572 : H12AffineEnvironment.transform 8 5 env24571 = env24572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env24571 == env24572) = true)

theorem identity24572 : scanCanonicalize (H12AffineFastState.compose env24572 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound24572 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24573 : List Nat := [2,1,8,16,1,1,9,16,0,1,1,17,8,0,0,2,17,0,1,1,16,1,16,2,9,0,0,16,16,1,1,1,16,1,17,0]

theorem envBound24573 : H12AffineFastState.Bounded env24573 := by
  intro p hp
  have h : env24573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24572_24573 : H12AffineEnvironment.transform 1 1 env24572 = env24573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env24572 == env24573) = true)

theorem identity24573 : scanCanonicalize (H12AffineFastState.compose env24573 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24573 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24574 : List Nat := [2,1,8,0,1,1,9,0,0,1,1,1,8,0,0,2,1,0,1,1,0,1,0,2,9,0,0,0,0,1,1,1,0,1,1,0]

theorem envBound24574 : H12AffineFastState.Bounded env24574 := by
  intro p hp
  have h : env24574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24573_24574 : H12AffineEnvironment.transform 3 0 env24573 = env24574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24573 == env24574) = true)

def env24575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441761,95497,8328,65,4196520,436385,45525,32161,412856,4606445,256,21792,46213,486255]

theorem envBound24575 : H12AffineFastState.Bounded env24575 := by
  intro p hp
  have h : env24575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24518_24575 : H12AffineEnvironment.transform 22 441761 env24518 = env24575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env24518 == env24575) = true)

def env24576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441761,95497,8328,65,270376,436385,45525,32161,412856,156013,256,21792,46213,486255]

theorem envBound24576 : H12AffineFastState.Bounded env24576 := by
  intro p hp
  have h : env24576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24575_24576 : H12AffineEnvironment.transform 21 272512 env24575 = env24576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24575 == env24576) = true)

theorem identity24576 : scanCanonicalize (H12AffineFastState.compose env24576 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound24576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,416037,272512,441761,41430,8328,65,270376,436385,45525,32161,412856,156013,256,21792,46213,442288]

theorem envBound24577 : H12AffineFastState.Bounded env24577 := by
  intro p hp
  have h : env24577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24576_24577 : H12AffineEnvironment.transform 15 54495 env24576 = env24577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env24576 == env24577) = true)

def env24578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272392,441641,41310,8192,65,270376,436265,45405,32041,412720,156013,256,21792,46093,442168]

theorem envBound24578 : H12AffineFastState.Bounded env24578 := by
  intro p hp
  have h : env24578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24577_24578 : H12AffineEnvironment.transform 6 8 env24577 = env24578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24577 == env24578) = true)

theorem identity24578 : scanCanonicalize (H12AffineFastState.compose env24578 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound24578 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env24579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,262144,1024,32769,290153,272392,297317,41310,8192,65,270376,302181,45405,32041,292988,21793,256,21792,46093,297844]

theorem envBound24579 : H12AffineFastState.Bounded env24579 := by
  intro p hp
  have h : env24579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24578_24579 : H12AffineEnvironment.transform 16 13388 env24578 = env24579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env24578 == env24579) = true)

theorem identity24579 : scanCanonicalize (H12AffineFastState.compose env24579 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound24579 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env24580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,64808,1024,32769,36929,54560,29773,41310,8192,65,56576,24909,45405,32041,34132,21793,256,21792,46093,30300]

theorem envBound24580 : H12AffineFastState.Bounded env24580 := by
  intro p hp
  have h : env24580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24579_24580 : H12AffineEnvironment.transform 17 64808 env24579 = env24580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env24579 == env24580) = true)

theorem identity24580 : scanCanonicalize (H12AffineFastState.compose env24580 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24580 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env24581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54359,5441,56357,1024,32769,36929,54560,21824,32851,269,65,56576,16448,36944,23588,34132,21793,256,21792,38144,22353]

theorem envBound24581 : H12AffineFastState.Bounded env24581 := by
  intro p hp
  have h : env24581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24580_24581 : H12AffineEnvironment.transform 12 269 env24580 = env24581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24580 == env24581) = true)

theorem identity24581 : scanCanonicalize (H12AffineFastState.compose env24581 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound24581 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,32768,33031,5441,35189,1024,32769,36929,32880,16,32851,269,65,34896,5392,36944,2420,34132,113,256,112,38144,513]

theorem envBound24582 : H12AffineFastState.Bounded env24582 := by
  intro p hp
  have h : env24582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24581_24582 : H12AffineEnvironment.transform 13 5456 env24581 = env24582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env24581 == env24582) = true)

theorem identity24582 : scanCanonicalize (H12AffineFastState.compose env24582 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24582 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env24583 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,33031,5393,35109,1024,32769,36881,32800,16,32771,269,17,34816,5392,36864,2340,34052,33,256,32,38144,513]

theorem envBound24583 : H12AffineFastState.Bounded env24583 := by
  intro p hp
  have h : env24583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24582_24583 : H12AffineEnvironment.transform 5 16 env24582 = env24583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24582 == env24583) = true)

theorem identity24583 : scanCanonicalize (H12AffineFastState.compose env24583 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24583 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24584 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,263,5393,2341,1024,1,4113,32,16,3,269,17,2048,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound24584 : H12AffineFastState.Bounded env24584 := by
  intro p hp
  have h : env24584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24583_24584 : H12AffineEnvironment.transform 14 0 env24583 = env24584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24583 == env24584) = true)

theorem identity24584 : scanCanonicalize (H12AffineFastState.compose env24584 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound24584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24585 : List Nat := [2,4,8,16,32,16,8,52,512,1024,2048,4096,57,5172,0,51,5157,2065,1024,1,4113,32,16,3,57,17,2048,5156,4096,2064,1072,33,52,32,5172,513]

theorem envBound24585 : H12AffineFastState.Bounded env24585 := by
  intro p hp
  have h : env24585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24584_24585 : H12AffineEnvironment.transform 7 52 env24584 = env24585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env24584 == env24585) = true)

theorem identity24585 : scanCanonicalize (H12AffineFastState.compose env24585 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound24585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24586 : List Nat := [2,4,8,16,32,16,8,52,512,1024,2048,2059,57,3135,0,51,3118,2065,1024,1,2074,32,16,3,57,17,2048,3119,2059,2064,1072,33,52,32,3135,513]

theorem envBound24586 : H12AffineFastState.Bounded env24586 := by
  intro p hp
  have h : env24586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24585_24586 : H12AffineEnvironment.transform 11 2059 env24585 = env24586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env24585 == env24586) = true)

theorem identity24586 : scanCanonicalize (H12AffineFastState.compose env24586 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound24586 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24587 : List Nat := [2,4,8,16,11,16,8,31,512,1024,2048,2059,18,3092,0,24,3077,2065,1024,1,2074,11,16,3,18,17,2048,3076,2059,2064,1051,10,31,11,3092,513]

theorem envBound24587 : H12AffineFastState.Bounded env24587 := by
  intro p hp
  have h : env24587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24586_24587 : H12AffineEnvironment.transform 4 11 env24586 = env24587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env24586 == env24587) = true)

theorem identity24587 : scanCanonicalize (H12AffineFastState.compose env24587 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24587 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24588 : List Nat := [2,4,8,16,11,16,8,31,512,20,2048,2059,18,2048,0,24,2065,2065,20,1,2074,11,16,3,18,17,2048,2064,2059,2064,15,10,31,11,2048,513]

theorem envBound24588 : H12AffineFastState.Bounded env24588 := by
  intro p hp
  have h : env24588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24587_24588 : H12AffineEnvironment.transform 9 20 env24587 = env24588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24587 == env24588) = true)

theorem identity24588 : scanCanonicalize (H12AffineFastState.compose env24588 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24588 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24589 : List Nat := [2,4,8,10,11,10,8,5,512,14,2048,2059,8,2048,0,2,2059,2059,14,1,2048,11,10,3,8,11,2048,2058,2059,2058,15,10,5,11,2048,513]

theorem envBound24589 : H12AffineFastState.Bounded env24589 := by
  intro p hp
  have h : env24589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24588_24589 : H12AffineEnvironment.transform 3 10 env24588 = env24589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24588 == env24589) = true)

theorem identity24589 : scanCanonicalize (H12AffineFastState.compose env24589 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound24589 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24590 : List Nat := [2,4,8,10,11,10,8,5,3,14,2048,2059,8,2048,0,2,2059,2059,14,1,2048,11,10,3,8,11,2048,2058,2059,2058,15,10,5,11,2048,2]

theorem envBound24590 : H12AffineFastState.Bounded env24590 := by
  intro p hp
  have h : env24590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24589_24590 : H12AffineEnvironment.transform 8 3 env24589 = env24590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env24589 == env24590) = true)

def env24591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272393,441640,41311,8193,65,270376,436264,45404,32040,412721,156013,256,21792,46092,442169]

theorem envBound24591 : H12AffineFastState.Bounded env24591 := by
  intro p hp
  have h : env24591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24577_24591 : H12AffineEnvironment.transform 6 9 env24577 = env24591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24577 == env24591) = true)

theorem identity24591 : scanCanonicalize (H12AffineFastState.compose env24591 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound24591 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env24592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16740,262144,1024,32769,268353,272393,326732,41311,8193,65,270376,321868,45404,32040,265557,8201,256,21792,46092,327261]

theorem envBound24592 : H12AffineFastState.Bounded env24592 := by
  intro p hp
  have h : env24592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24591_24592 : H12AffineEnvironment.transform 16 16740 env24591 = env24592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env24591 == env24592) = true)

theorem identity24592 : scanCanonicalize (H12AffineFastState.compose env24592 (packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound24592 : packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env24593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16740,35188,1024,32769,37173,41341,30008,41311,8193,65,43356,24632,45404,32040,33825,8201,256,21792,46092,30505]

theorem envBound24593 : H12AffineFastState.Bounded env24593 := by
  intro p hp
  have h : env24593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24592_24593 : H12AffineEnvironment.transform 17 35188 env24592 = env24593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env24592 == env24593) = true)

theorem identity24593 : scanCanonicalize (H12AffineFastState.compose env24593 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound24593 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,13625,35188,1024,32769,37173,41341,357,41311,8193,65,43356,5221,45404,2421,33825,8201,256,8573,46092,884]

theorem envBound24594 : H12AffineFastState.Bounded env24594 := by
  intro p hp
  have h : env24594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24593_24594 : H12AffineEnvironment.transform 13 13405 env24593 = env24594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env24593 == env24594) = true)

theorem identity24594 : scanCanonicalize (H12AffineFastState.compose env24594 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24594 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24595 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,32768,40971,13389,34816,1024,32769,36929,40969,17,41003,8193,65,43048,5221,45096,2049,33825,8201,116,8201,46092,512]

theorem envBound24595 : H12AffineFastState.Bounded env24595 := by
  intro p hp
  have h : env24595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24594_24595 : H12AffineEnvironment.transform 7 116 env24594 = env24595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24594 == env24595) = true)

theorem identity24595 : scanCanonicalize (H12AffineFastState.compose env24595 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24595 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24596 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,5157,32768,32883,5173,34816,1024,32769,36929,32881,17,32851,121,65,34896,5221,36944,2049,33825,113,116,113,38004,512]

theorem envBound24596 : H12AffineFastState.Bounded env24596 := by
  intro p hp
  have h : env24596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24595_24596 : H12AffineEnvironment.transform 12 120 env24595 = env24596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24595 == env24596) = true)

theorem identity24596 : scanCanonicalize (H12AffineFastState.compose env24596 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound24596 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env24597 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2128,32768,32883,2112,34816,1024,32769,35892,32881,17,32851,121,65,34896,2064,35877,2049,33825,113,116,113,34817,512]

theorem envBound24597 : H12AffineFastState.Bounded env24597 := by
  intro p hp
  have h : env24597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24596_24597 : H12AffineEnvironment.transform 11 3189 env24596 = env24597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env24596 == env24597) = true)

theorem identity24597 : scanCanonicalize (H12AffineFastState.compose env24597 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound24597 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env24598 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2128,112,3,2112,2160,1024,113,3140,1,17,35,121,65,2080,2064,3157,2049,1105,113,116,113,2161,512]

theorem envBound24598 : H12AffineFastState.Bounded env24598 := by
  intro p hp
  have h : env24598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24597_24598 : H12AffineEnvironment.transform 14 112 env24597 = env24598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env24597 == env24598) = true)

theorem identity24598 : scanCanonicalize (H12AffineFastState.compose env24598 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24598 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24599 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,3157,88,2128,80,3,2112,2128,1024,81,3140,1,17,3,89,65,2048,2064,3157,2049,1105,81,84,81,2129,512]

theorem envBound24599 : H12AffineFastState.Bounded env24599 := by
  intro p hp
  have h : env24599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24598_24599 : H12AffineEnvironment.transform 4 0 env24598 = env24599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24598 == env24599) = true)

theorem identity24599 : scanCanonicalize (H12AffineFastState.compose env24599 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24599 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24600 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3077,8,2048,0,3,2064,2048,1024,1,3092,1,17,3,9,17,2048,2064,3077,2049,1025,1,4,1,2049,512]

theorem envBound24600 : H12AffineFastState.Bounded env24600 := by
  intro p hp
  have h : env24600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24599_24600 : H12AffineEnvironment.transform 5 16 env24599 = env24600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24599 == env24600) = true)

theorem identity24600 : scanCanonicalize (H12AffineFastState.compose env24600 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24601 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,2065,8,2048,0,3,2064,2048,20,1,2048,1,17,3,9,17,2048,2064,2065,2049,21,1,4,1,2049,512]

theorem envBound24601 : H12AffineFastState.Bounded env24601 := by
  intro p hp
  have h : env24601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24600_24601 : H12AffineEnvironment.transform 9 20 env24600 = env24601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24600 == env24601) = true)

theorem identity24601 : scanCanonicalize (H12AffineFastState.compose env24601 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound24601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24602 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,513,8,528,0,3,512,528,20,1,528,1,17,3,9,17,528,512,513,529,21,1,4,1,529,512]

theorem envBound24602 : H12AffineFastState.Bounded env24602 := by
  intro p hp
  have h : env24602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24601_24602 : H12AffineEnvironment.transform 10 528 env24601 = env24602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env24601 == env24602) = true)

theorem identity24602 : scanCanonicalize (H12AffineFastState.compose env24602 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound24602 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24603 : List Nat := [2,4,8,16,0,16,9,4,21,20,5,20,8,5,0,3,21,5,20,1,5,1,17,3,9,17,5,21,20,4,21,1,4,1,4,21]

theorem envBound24603 : H12AffineFastState.Bounded env24603 := by
  intro p hp
  have h : env24603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24602_24603 : H12AffineEnvironment.transform 8 21 env24602 = env24603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env24602 == env24603) = true)

theorem identity24603 : scanCanonicalize (H12AffineFastState.compose env24603 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound24603 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24604 : List Nat := [2,1,8,16,0,16,9,1,16,17,0,17,8,0,0,3,16,0,17,1,0,1,17,3,9,17,0,16,17,1,16,1,1,1,1,16]

theorem envBound24604 : H12AffineFastState.Bounded env24604 := by
  intro p hp
  have h : env24604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24603_24604 : H12AffineEnvironment.transform 1 1 env24603 = env24604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env24603 == env24604) = true)

theorem identity24604 : scanCanonicalize (H12AffineFastState.compose env24604 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24604 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24605 : List Nat := [2,1,8,1,0,1,9,1,1,0,0,0,8,0,0,3,1,0,0,1,0,1,0,3,9,0,0,1,0,1,1,1,1,1,1,1]

theorem envBound24605 : H12AffineFastState.Bounded env24605 := by
  intro p hp
  have h : env24605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24604_24605 : H12AffineEnvironment.transform 3 1 env24604 = env24605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24604 == env24605) = true)

def env24606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441761,95497,8328,65,270377,436385,45525,32161,412856,156012,256,21792,46213,486255]

theorem envBound24606 : H12AffineFastState.Bounded env24606 := by
  intro p hp
  have h : env24606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24575_24606 : H12AffineEnvironment.transform 21 272513 env24575 = env24606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24575 == env24606) = true)

theorem identity24606 : scanCanonicalize (H12AffineFastState.compose env24606 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound24606 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213487,120015,95497,8328,65,215367,115151,45525,32161,75222,156012,256,21792,46213,513]

theorem envBound24607 : H12AffineFastState.Bounded env24607 := by
  intro p hp
  have h : env24607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24606_24607 : H12AffineEnvironment.transform 17 223598 env24606 = env24607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env24606 == env24607) = true)

def env24608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213351,119879,95497,8192,65,215367,115015,45405,32041,75102,156012,256,21792,46093,513]

theorem envBound24608 : H12AffineFastState.Bounded env24608 := by
  intro p hp
  have h : env24608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24607_24608 : H12AffineEnvironment.transform 6 8 env24607 = env24608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24607 == env24608) = true)

theorem identity24608 : scanCanonicalize (H12AffineFastState.compose env24608 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound24608 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env24609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,77899,33,119879,95497,8192,65,2049,115015,45405,32041,75102,73770,256,21792,46093,513]

theorem envBound24609 : H12AffineFastState.Bounded env24609 := by
  intro p hp
  have h : env24609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24608_24609 : H12AffineEnvironment.transform 16 82246 env24608 = env24609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env24608 == env24609) = true)

theorem identity24609 : scanCanonicalize (H12AffineFastState.compose env24609 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound24609 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env24610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,5393,10280,1024,32769,25628,33,32784,8542,8192,65,2049,38160,45405,32041,28937,29821,256,21792,46093,513]

theorem envBound24610 : H12AffineFastState.Bounded env24610 := by
  intro p hp
  have h : env24610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24609_24610 : H12AffineEnvironment.transform 15 21591 env24609 = env24610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env24609 == env24610) = true)

theorem identity24610 : scanCanonicalize (H12AffineFastState.compose env24610 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24610 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env24611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,5393,10280,1024,0,25628,33,17,8542,8192,65,2049,5393,12636,32041,28937,29821,256,21792,13324,513]

theorem envBound24611 : H12AffineFastState.Bounded env24611 := by
  intro p hp
  have h : env24611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24610_24611 : H12AffineEnvironment.transform 14 1 env24610 = env24611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24610 == env24611) = true)

theorem identity24611 : scanCanonicalize (H12AffineFastState.compose env24611 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24611 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,21591,5393,2340,1024,0,17680,33,17,82,268,65,2049,5393,4176,23589,20485,21873,256,21792,5376,513]

theorem envBound24612 : H12AffineFastState.Bounded env24612 := by
  intro p hp
  have h : env24612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24611_24612 : H12AffineEnvironment.transform 12 268 env24611 = env24612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24611 == env24612) = true)

theorem identity24612 : scanCanonicalize (H12AffineFastState.compose env24612 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24612 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,1,342,5393,2340,1024,0,4113,33,17,82,268,65,2049,5393,4176,2340,1284,112,256,33,5376,513]

theorem envBound24613 : H12AffineFastState.Bounded env24613 := by
  intro p hp
  have h : env24613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24612_24613 : H12AffineEnvironment.transform 13 5377 env24612 = env24613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24612 == env24613) = true)

def env24614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213350,119878,95497,8193,65,215367,115014,45404,32040,75103,156012,256,21792,46092,513]

theorem envBound24614 : H12AffineFastState.Bounded env24614 := by
  intro p hp
  have h : env24614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24607_24614 : H12AffineEnvironment.transform 6 9 env24607 = env24614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24607 == env24614) = true)

theorem identity24614 : scanCanonicalize (H12AffineFastState.compose env24614 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24614 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2420,1024,32769,77899,8572,119878,95497,8193,65,10589,115014,45404,32040,75103,65910,256,21792,46092,513]

theorem envBound24615 : H12AffineFastState.Bounded env24615 := by
  intro p hp
  have h : env24615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24614_24615 : H12AffineEnvironment.transform 16 90138 env24614 = env24615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24614 == env24615) = true)

theorem identity24615 : scanCanonicalize (H12AffineFastState.compose env24615 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound24615 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env24616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,90138,2420,1024,21840,77899,8572,65815,95497,8193,65,10589,70679,25613,32040,75103,65910,256,21792,24925,513]

theorem envBound24616 : H12AffineFastState.Bounded env24616 := by
  intro p hp
  have h : env24616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24615_24616 : H12AffineEnvironment.transform 14 21841 env24615 = env24616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env24615 == env24616) = true)

theorem identity24616 : scanCanonicalize (H12AffineFastState.compose env24616 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound24616 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,21794,13624,2420,1024,21840,25961,8572,21557,8235,8193,65,10589,16693,25613,32040,28797,21588,256,21792,24925,513]

theorem envBound24617 : H12AffineFastState.Bounded env24617 := by
  intro p hp
  have h : env24617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24616_24617 : H12AffineEnvironment.transform 15 21794 env24616 = env24617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env24616 == env24617) = true)

theorem identity24617 : scanCanonicalize (H12AffineFastState.compose env24617 (packedSelected [0,4,7,9,11,14,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24617 : packedSelected [0,4,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env24618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21841,21794,5440,2420,1024,21840,17681,260,21557,83,121,65,2341,16693,17525,23888,20485,21588,256,21792,16677,513]

theorem envBound24618 : H12AffineFastState.Bounded env24618 := by
  intro p hp
  have h : env24618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24617_24618 : H12AffineEnvironment.transform 12 120 env24617 = env24618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24617 == env24618) = true)

theorem identity24618 : scanCanonicalize (H12AffineFastState.compose env24618 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound24618 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5236,293,342,5440,2420,1024,292,4453,260,65,83,121,65,2341,5441,4097,2340,1137,32,256,340,5457,513]

theorem envBound24619 : H12AffineFastState.Bounded env24619 := by
  intro p hp
  have h : env24619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24618_24619 : H12AffineEnvironment.transform 13 5236 env24618 = env24619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env24618 == env24619) = true)

theorem identity24619 : scanCanonicalize (H12AffineFastState.compose env24619 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24619 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24620 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,120,4161,293,342,4469,2420,53,292,4453,260,65,83,121,65,2341,4468,4097,2340,68,32,256,340,4452,513]

theorem envBound24620 : H12AffineFastState.Bounded env24620 := by
  intro p hp
  have h : env24620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24619_24620 : H12AffineEnvironment.transform 9 53 env24619 = env24620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24619 == env24620) = true)

theorem identity24620 : scanCanonicalize (H12AffineFastState.compose env24620 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24620 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24621 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,4096,120,4161,80,35,4096,2049,53,81,4112,113,65,83,121,65,2128,4097,4097,2129,68,32,117,33,4113,513]

theorem envBound24621 : H12AffineFastState.Bounded env24621 := by
  intro p hp
  have h : env24621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24620_24621 : H12AffineEnvironment.transform 7 117 env24620 = env24621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24620 == env24621) = true)

theorem identity24621 : scanCanonicalize (H12AffineFastState.compose env24621 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24621 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24622 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,35,4096,2049,53,1,4112,33,17,3,41,17,2048,4097,4097,2049,20,32,37,33,4113,513]

theorem envBound24622 : H12AffineFastState.Bounded env24622 := by
  intro p hp
  have h : env24622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24621_24622 : H12AffineEnvironment.transform 5 16 env24621 = env24622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24621 == env24622) = true)

def env24623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound24623 : H12AffineFastState.Bounded env24623 := by
  intro p hp
  have h : env24623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24417_24623 : H12AffineEnvironment.transform 18 1025 env24417 = env24623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24417 == env24623) = true)

theorem identity24623 : scanCanonicalize (H12AffineFastState.compose env24623 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24623 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616169,18973836,10507601,8579113,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound24624 : H12AffineFastState.Bounded env24624 := by
  intro p hp
  have h : env24624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24623_24624 : H12AffineEnvironment.transform 17 10280 env24623 = env24624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24623 == env24624) = true)

def env24625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616169,18973700,10507601,8579113,25265168,23160137,257,27378724,27337992,25207630]

theorem envBound24625 : H12AffineFastState.Bounded env24625 := by
  intro p hp
  have h : env24625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24624_24625 : H12AffineEnvironment.transform 6 8 env24624 = env24625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24624 == env24625) = true)

theorem identity24625 : scanCanonicalize (H12AffineFastState.compose env24625 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound24625 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,2,8192,65,12838955,2196486,10507601,8579113,8487954,6382923,257,10601510,10560778,8430412]

theorem envBound24626 : H12AffineFastState.Bounded env24626 := by
  intro p hp
  have h : env24626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24625_24626 : H12AffineEnvironment.transform 23 2 env24625 = env24626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env24625 == env24626) = true)

theorem identity24626 : scanCanonicalize (H12AffineFastState.compose env24626 (packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound24626 : packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,8388608,2,8192,65,8570881,2196486,10507601,8579113,8487954,2114913,257,10601510,10560778,8430412]

theorem envBound24627 : H12AffineFastState.Bounded env24627 := by
  intro p hp
  have h : env24627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24626_24627 : H12AffineEnvironment.transform 21 73770 env24626 = env24627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env24626 == env24627) = true)

def env24628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,147456,2,8192,65,34817,2196486,2233681,43049,246802,2114913,257,2327590,2319626,189260]

theorem envBound24628 : H12AffineFastState.Bounded env24628 := by
  intro p hp
  have h : env24628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24627_24628 : H12AffineEnvironment.transform 22 147456 env24627 = env24628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env24627 == env24628) = true)

theorem identity24628 : scanCanonicalize (H12AffineFastState.compose env24628 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound24628 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env24629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,2097152,73770,8524,2,8192,65,34817,2196486,2126877,43049,107870,2114913,257,2221418,2163782,33280]

theorem envBound24629 : H12AffineFastState.Bounded env24629 := by
  intro p hp
  have h : env24629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24628_24629 : H12AffineEnvironment.transform 16 24908 env24628 = env24629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env24628 == env24629) = true)

theorem identity24629 : scanCanonicalize (H12AffineFastState.compose env24629 (packedSelected [1,4,8,9,11,12,14,15,16,17,18,19,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound24629 : packedSelected [1,4,8,9,11,12,14,15,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env24630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,91198,73770,8524,2,8192,65,34817,57400,69667,43049,107870,74079,257,33108,24696,33280]

theorem envBound24630 : H12AffineFastState.Bounded env24630 := by
  intro p hp
  have h : env24630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24629_24630 : H12AffineEnvironment.transform 20 91198 env24629 = env24630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env24629 == env24630) = true)

theorem identity24630 : scanCanonicalize (H12AffineFastState.compose env24630 (packedSelected [3,4,9,10,14,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24630 : packedSelected [3,4,9,10,14,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env24631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,24908,10280,1025,1,91198,73770,8524,2,8192,65,2049,24632,69667,10281,75102,74079,257,340,24696,512]

theorem envBound24631 : H12AffineFastState.Bounded env24631 := by
  intro p hp
  have h : env24631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24630_24631 : H12AffineEnvironment.transform 14 0 env24630 = env24631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24630 == env24631) = true)

theorem identity24631 : scanCanonicalize (H12AffineFastState.compose env24631 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 29791) := by decide +kernel

theorem selectedBound24631 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,29791,24908,10280,1025,1,4193,21621,8524,2,8192,65,2049,24632,25724,10281,20737,21760,257,340,24696,512]

theorem envBound24632 : H12AffineFastState.Bounded env24632 := by
  intro p hp
  have h : env24632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24631_24632 : H12AffineEnvironment.transform 15 29791 env24631 = env24632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29791 env24631 == env24632) = true)

theorem identity24632 : scanCanonicalize (H12AffineFastState.compose env24632 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24632 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,0,21622,16741,2049,1025,1,4193,21621,357,2,41,65,2049,16401,17493,2048,20737,21760,257,340,16465,512]

theorem envBound24633 : H12AffineFastState.Bounded env24633 := by
  intro p hp
  have h : env24633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24632_24633 : H12AffineEnvironment.transform 12 41 env24632 = env24633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24632 == env24633) = true)

theorem identity24633 : scanCanonicalize (H12AffineFastState.compose env24633 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24633 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env24634 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,21622,16401,2049,1025,1,4193,21621,17,2,41,65,2049,16401,17493,2048,20597,21620,117,32,16465,512]

theorem envBound24634 : H12AffineFastState.Bounded env24634 := by
  intro p hp
  have h : env24634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24633_24634 : H12AffineEnvironment.transform 7 116 env24633 = env24634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24633 == env24634) = true)

theorem identity24634 : scanCanonicalize (H12AffineFastState.compose env24634 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24634 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24635 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,16384,0,21590,16401,2049,1025,1,4161,21589,17,2,9,65,2049,16401,17493,2048,20565,21588,85,0,16465,512]

theorem envBound24635 : H12AffineFastState.Bounded env24635 := by
  intro p hp
  have h : env24635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24634_24635 : H12AffineEnvironment.transform 4 0 env24634 = env24635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24634 == env24635) = true)

theorem identity24635 : scanCanonicalize (H12AffineFastState.compose env24635 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound24635 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24636 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,5205,0,3,5188,2049,1025,1,4161,0,17,2,9,65,2049,5188,4096,2048,1024,1,85,0,5124,512]

theorem envBound24636 : H12AffineFastState.Bounded env24636 := by
  intro p hp
  have h : env24636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24635_24636 : H12AffineEnvironment.transform 13 5205 env24635 = env24636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env24635 == env24636) = true)

theorem identity24636 : scanCanonicalize (H12AffineFastState.compose env24636 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24636 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24637 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,0,3,5141,2049,1025,1,4112,0,17,2,9,16,2049,5141,4096,2048,1024,1,4,0,5124,512]

theorem envBound24637 : H12AffineFastState.Bounded env24637 := by
  intro p hp
  have h : env24637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24636_24637 : H12AffineEnvironment.transform 5 17 env24636 = env24637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24636 == env24637) = true)

def env24638 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1044,0,3,1029,2049,1025,1,0,0,17,2,9,16,2049,1029,16,2048,1024,1,4,0,1044,512]

theorem envBound24638 : H12AffineFastState.Bounded env24638 := by
  intro p hp
  have h : env24638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24637_24638 : H12AffineEnvironment.transform 11 16 env24637 = env24638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24637 == env24638) = true)

theorem identity24638 : scanCanonicalize (H12AffineFastState.compose env24638 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24639 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,9,1044,0,3,1029,1,1025,1,0,0,17,2,9,16,1,1029,16,0,1024,1,4,0,1044,512]

theorem envBound24639 : H12AffineFastState.Bounded env24639 := by
  intro p hp
  have h : env24639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24638_24639 : H12AffineEnvironment.transform 10 0 env24638 = env24639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24638 == env24639) = true)

def env24640 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,0,3,17,1,21,1,0,0,17,2,9,16,1,17,16,0,20,1,4,0,0,512]

theorem envBound24640 : H12AffineFastState.Bounded env24640 := by
  intro p hp
  have h : env24640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24639_24640 : H12AffineEnvironment.transform 9 20 env24639 = env24640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24639 == env24640) = true)

theorem identity24640 : scanCanonicalize (H12AffineFastState.compose env24640 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound24640 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24641 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,9,0,0,3,17,1,21,1,0,0,17,2,9,16,1,17,16,0,20,1,4,0,0,31]

theorem envBound24641 : H12AffineFastState.Bounded env24641 := by
  intro p hp
  have h : env24641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24640_24641 : H12AffineEnvironment.transform 8 31 env24640 = env24641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env24640 == env24641) = true)

def leafEnv24641 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,9,0,0,3,17,1,21,1,0,0,17,2,21,9,1,16,1,17,16,0,20,1,4,0,5,3,0,31,1,0,0]

def active24641 : List Nat := [0,1,2,3]

def tree24641 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24641 : H12WitnessSearch.Good tree24641 := H12GlobalWitnessIndex.good

theorem leafIdentity24641 : H12AffineFastState.composeSystem env24641 rootObs = leafEnv24641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24641 rootObs == leafEnv24641) = true)

theorem terminalChecked24641 : H12PackedTerminal.terminalCheckFast leafEnv24641 active24641 tree24641 = true := by decide +kernel

def env24642 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,1,0,3,16,1,20,1,0,0,17,2,9,16,1,16,16,0,21,1,4,0,1,512]

theorem envBound24642 : H12AffineFastState.Bounded env24642 := by
  intro p hp
  have h : env24642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24639_24642 : H12AffineEnvironment.transform 9 21 env24639 = env24642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24639 == env24642) = true)

theorem identity24642 : scanCanonicalize (H12AffineFastState.compose env24642 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound24642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24643 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,0,3,4,1,0,1,0,0,5,2,9,4,1,4,4,0,1,1,4,0,1,512]

theorem envBound24643 : H12AffineFastState.Bounded env24643 := by
  intro p hp
  have h : env24643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24642_24643 : H12AffineEnvironment.transform 3 4 env24642 = env24643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env24642 == env24643) = true)

def leafEnv24643 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,0,3,4,1,0,1,0,0,5,2,0,9,1,4,1,4,4,0,1,1,4,0,5,3,1,512,1,0,0]

def active24643 : List Nat := [0,1,2,8]

def tree24643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24643 : H12WitnessSearch.Good tree24643 := H12GlobalWitnessIndex.good

theorem leafIdentity24643 : H12AffineFastState.composeSystem env24643 rootObs = leafEnv24643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24643 rootObs == leafEnv24643) = true)

theorem terminalChecked24643 : H12PackedTerminal.terminalCheckFast leafEnv24643 active24643 tree24643 = true := by decide +kernel

def env24644 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1045,0,3,1028,2049,1025,1,1,0,17,2,9,16,2049,1028,17,2048,1024,1,4,0,1045,512]

theorem envBound24644 : H12AffineFastState.Bounded env24644 := by
  intro p hp
  have h : env24644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24637_24644 : H12AffineEnvironment.transform 11 17 env24637 = env24644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24637 == env24644) = true)

theorem identity24644 : scanCanonicalize (H12AffineFastState.compose env24644 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24645 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,9,1045,0,3,1028,1044,1025,1,1,0,17,2,9,16,1044,1028,17,1045,1024,1,4,0,1045,512]

theorem envBound24645 : H12AffineFastState.Bounded env24645 := by
  intro p hp
  have h : env24645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24644_24645 : H12AffineEnvironment.transform 10 1045 env24644 = env24645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env24644 == env24645) = true)

def env24646 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,9,1,0,3,16,0,21,1,1,0,17,2,9,16,0,16,17,1,20,1,4,0,1,512]

theorem envBound24646 : H12AffineFastState.Bounded env24646 := by
  intro p hp
  have h : env24646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24645_24646 : H12AffineEnvironment.transform 9 20 env24645 = env24646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24645 == env24646) = true)

theorem identity24646 : scanCanonicalize (H12AffineFastState.compose env24646 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound24646 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24647 : List Nat := [2,4,8,16,0,17,8,5,30,20,1,17,9,1,0,3,16,0,21,1,1,0,17,2,9,16,0,16,17,1,20,1,4,0,1,30]

theorem envBound24647 : H12AffineFastState.Bounded env24647 := by
  intro p hp
  have h : env24647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24646_24647 : H12AffineEnvironment.transform 8 30 env24646 = env24647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env24646 == env24647) = true)

def leafEnv24647 : List Nat := [2,4,8,16,0,17,8,5,30,20,1,17,9,1,0,3,16,0,21,1,1,0,17,2,21,9,1,16,0,16,17,1,20,1,4,0,5,3,1,30,1,1,0]

def active24647 : List Nat := [0,1,2,3]

def tree24647 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24647 : H12WitnessSearch.Good tree24647 := H12GlobalWitnessIndex.good

theorem leafIdentity24647 : H12AffineFastState.composeSystem env24647 rootObs = leafEnv24647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24647 rootObs == leafEnv24647) = true)

theorem terminalChecked24647 : H12PackedTerminal.terminalCheckFast leafEnv24647 active24647 tree24647 = true := by decide +kernel

def env24648 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,0,0,3,17,1,20,1,1,0,17,2,9,16,1,17,17,0,21,1,4,0,0,512]

theorem envBound24648 : H12AffineFastState.Bounded env24648 := by
  intro p hp
  have h : env24648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24645_24648 : H12AffineEnvironment.transform 9 21 env24645 = env24648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24645 == env24648) = true)

theorem identity24648 : scanCanonicalize (H12AffineFastState.compose env24648 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound24648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24649 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,5,9,0,0,3,5,1,0,1,1,0,5,2,9,4,1,5,5,0,1,1,4,0,0,512]

theorem envBound24649 : H12AffineFastState.Bounded env24649 := by
  intro p hp
  have h : env24649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24648_24649 : H12AffineEnvironment.transform 3 4 env24648 = env24649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env24648 == env24649) = true)

def leafEnv24649 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,5,9,0,0,3,5,1,0,1,1,0,5,2,0,9,1,4,1,5,5,0,1,1,4,0,5,3,0,512,1,1,0]

def active24649 : List Nat := [0,1,2,8]

def tree24649 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24649 : H12WitnessSearch.Good tree24649 := H12GlobalWitnessIndex.good

theorem leafIdentity24649 : H12AffineFastState.composeSystem env24649 rootObs = leafEnv24649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24649 rootObs == leafEnv24649) = true)

theorem terminalChecked24649 : H12PackedTerminal.terminalCheckFast leafEnv24649 active24649 tree24649 = true := by decide +kernel

def env24650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,147457,2,8192,65,34816,2196486,2233680,43048,246803,2114913,257,2327591,2319627,189261]

theorem envBound24650 : H12AffineFastState.Bounded env24650 := by
  intro p hp
  have h : env24650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24627_24650 : H12AffineEnvironment.transform 22 147457 env24627 = env24650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env24627 == env24650) = true)

theorem identity24650 : scanCanonicalize (H12AffineFastState.compose env24650 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound24650 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env24651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,2097152,73770,65863,2,8192,65,34816,2196486,2184214,43048,34133,2114913,257,2147681,2106445,107019]

theorem envBound24651 : H12AffineFastState.Bounded env24651 := by
  intro p hp
  have h : env24651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24650_24651 : H12AffineEnvironment.transform 16 82246 env24650 = env24651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env24650 == env24651) = true)

theorem identity24651 : scanCanonicalize (H12AffineFastState.compose env24651 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound24651 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env24652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57676,10280,1025,32769,2097152,32800,41293,2,8192,65,34816,2106380,2159644,43048,34133,2114913,257,2147681,2106445,513]

theorem envBound24652 : H12AffineFastState.Bounded env24652 := by
  intro p hp
  have h : env24652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24651_24652 : H12AffineEnvironment.transform 15 40970 env24651 = env24652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env24651 == env24652) = true)

theorem identity24652 : scanCanonicalize (H12AffineFastState.compose env24652 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound24652 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env24653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,40970,45404,10280,1025,32769,2097152,32800,41293,2,8192,65,34816,2106380,2139148,43048,34133,2102641,257,2135409,2106445,513]

theorem envBound24653 : H12AffineFastState.Bounded env24653 := by
  intro p hp
  have h : env24653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24652_24653 : H12AffineEnvironment.transform 13 4112 env24652 = env24653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env24652 == env24653) = true)

theorem identity24653 : scanCanonicalize (H12AffineFastState.compose env24653 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound24653 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env24654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,40970,45404,10280,1025,32769,13689,32800,41293,2,8192,65,34816,4469,37237,43048,34133,8200,257,40968,4404,513]

theorem envBound24654 : H12AffineFastState.Bounded env24654 := by
  intro p hp
  have h : env24654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24653_24654 : H12AffineEnvironment.transform 20 13689 env24653 = env24654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env24653 == env24654) = true)

theorem identity24654 : scanCanonicalize (H12AffineFastState.compose env24654 (packedSelected [2,4,6,9,11,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound24654 : packedSelected [2,4,6,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env24655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,4113,12315,8525,10280,1025,4112,13689,4145,12636,2,8192,65,6161,4469,356,14393,5444,8200,257,12313,4404,513]

theorem envBound24655 : H12AffineFastState.Bounded env24655 := by
  intro p hp
  have h : env24655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24654_24655 : H12AffineEnvironment.transform 14 4113 env24654 = env24655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env24654 == env24655) = true)

theorem identity24655 : scanCanonicalize (H12AffineFastState.compose env24655 (packedSelected [0,2,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound24655 : packedSelected [0,2,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,8192,372,373,8575,8525,10280,1025,372,9245,341,8248,2,8192,65,2421,17,356,10589,1056,8200,257,8573,80,513]

theorem envBound24656 : H12AffineFastState.Bounded env24656 := by
  intro p hp
  have h : env24656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24655_24656 : H12AffineEnvironment.transform 11 356 env24655 = env24656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env24655 == env24656) = true)

theorem identity24656 : scanCanonicalize (H12AffineFastState.compose env24656 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24656 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,349,372,373,34,16,2421,1025,372,1344,341,357,2,349,65,2421,17,356,2048,1056,341,257,32,80,513]

theorem envBound24657 : H12AffineFastState.Bounded env24657 := by
  intro p hp
  have h : env24657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24656_24657 : H12AffineEnvironment.transform 12 349 env24656 = env24657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24656 == env24657) = true)

theorem identity24657 : scanCanonicalize (H12AffineFastState.compose env24657 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24658 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,17,40,1,0,34,16,2048,1025,1,1077,32,16,2,40,65,2048,17,17,2048,1056,32,116,32,80,513]

theorem envBound24658 : H12AffineFastState.Bounded env24658 := by
  intro p hp
  have h : env24658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24657_24658 : H12AffineEnvironment.transform 7 117 env24657 = env24658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24657 == env24658) = true)

theorem identity24658 : scanCanonicalize (H12AffineFastState.compose env24658 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound24658 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24659 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1647,17,40,1,0,34,16,1647,1025,1,1077,32,16,2,40,65,1647,17,17,1647,1056,32,116,32,80,513]

theorem envBound24659 : H12AffineFastState.Bounded env24659 := by
  intro p hp
  have h : env24659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24658_24659 : H12AffineEnvironment.transform 10 1647 env24658 = env24659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env24658 == env24659) = true)

theorem identity24659 : scanCanonicalize (H12AffineFastState.compose env24659 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24659 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24660 : List Nat := [2,4,8,16,32,64,8,117,512,21,634,17,40,1,0,34,16,634,20,1,32,32,16,2,40,65,634,17,17,634,53,32,116,32,80,513]

theorem envBound24660 : H12AffineFastState.Bounded env24660 := by
  intro p hp
  have h : env24660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24659_24660 : H12AffineEnvironment.transform 9 21 env24659 = env24660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24659 == env24660) = true)

theorem identity24660 : scanCanonicalize (H12AffineFastState.compose env24660 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24660 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24661 : List Nat := [2,4,8,16,32,16,8,37,512,21,554,17,40,1,0,34,16,554,20,1,32,32,16,2,40,17,554,17,17,554,53,32,36,32,0,513]

theorem envBound24661 : H12AffineFastState.Bounded env24661 := by
  intro p hp
  have h : env24661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24660_24661 : H12AffineEnvironment.transform 5 16 env24660 = env24661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24660 == env24661) = true)

def env24662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616169,18973701,10507601,8579113,25265168,23160136,257,27378725,27337992,25207631]

theorem envBound24662 : H12AffineFastState.Bounded env24662 := by
  intro p hp
  have h : env24662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24624_24662 : H12AffineEnvironment.transform 6 9 env24624 = env24662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24624 == env24662) = true)

theorem identity24662 : scanCanonicalize (H12AffineFastState.compose env24662 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8429902) := by decide +kernel

theorem selectedBound24662 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,8429902,8193,65,4409703,10560843,10507601,8579113,75102,14795782,257,2188651,2196550,513]

theorem envBound24663 : H12AffineFastState.Bounded env24663 := by
  intro p hp
  have h : env24663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24662_24663 : H12AffineEnvironment.transform 23 8429902 env24662 = env24663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429902 env24662 == env24663) = true)

def env24664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155532,2114882,8193,65,4409703,115015,45405,2231333,75102,4268042,257,2188651,2196550,513]

theorem envBound24664 : H12AffineFastState.Bounded env24664 := by
  intro p hp
  have h : env24664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24663_24664 : H12AffineEnvironment.transform 22 2155532 env24663 = env24664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env24663 == env24664) = true)

def env24665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114882,8193,65,215367,115015,45405,2231333,75102,73770,257,2188651,2196550,513]

theorem envBound24665 : H12AffineFastState.Bounded env24665 := by
  intro p hp
  have h : env24665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24664_24665 : H12AffineEnvironment.transform 21 32 env24664 = env24665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env24664 == env24665) = true)

def env24666 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114834,8193,17,215319,114967,45325,2231333,75022,73770,257,2188603,2196502,513]

theorem envBound24666 : H12AffineFastState.Bounded env24666 := by
  intro p hp
  have h : env24666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24665_24666 : H12AffineEnvironment.transform 5 16 env24665 = env24666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24665 == env24666) = true)

theorem identity24666 : scanCanonicalize (H12AffineFastState.compose env24666 (packedSelected [14,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound24666 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env24667 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58397,32,17,41231,8193,17,215319,114967,45325,190520,75022,73770,257,98598,90123,513]

theorem envBound24667 : H12AffineFastState.Bounded env24667 := by
  intro p hp
  have h : env24667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24666_24667 : H12AffineEnvironment.transform 20 58397 env24666 = env24667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env24666 == env24667) = true)

theorem identity24667 : scanCanonicalize (H12AffineFastState.compose env24667 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound24667 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env24668 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10280,1025,32769,58397,32,17,41231,8193,17,190749,24861,45325,190520,34052,32800,257,8492,49153,513]

theorem envBound24668 : H12AffineFastState.Bounded env24668 := by
  intro p hp
  have h : env24668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24667_24668 : H12AffineEnvironment.transform 15 40970 env24667 = env24668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env24667 == env24668) = true)

theorem identity24668 : scanCanonicalize (H12AffineFastState.compose env24668 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24668 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24669 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,58397,32,17,41231,8193,17,43277,24861,45325,43048,34052,32800,257,8492,49153,513]

theorem envBound24669 : H12AffineFastState.Bounded env24669 := by
  intro p hp
  have h : env24669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24668_24669 : H12AffineEnvironment.transform 16 16400 env24668 = env24669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24668 == env24669) = true)

theorem identity24669 : scanCanonicalize (H12AffineFastState.compose env24669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound24669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,263,16400,10280,1025,8460,17680,32,17,2,8193,17,2048,24861,4096,2341,9225,8493,257,8492,24844,513]

theorem envBound24670 : H12AffineFastState.Bounded env24670 := by
  intro p hp
  have h : env24670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24669_24670 : H12AffineEnvironment.transform 14 8461 env24669 = env24670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env24669 == env24670) = true)

theorem identity24670 : scanCanonicalize (H12AffineFastState.compose env24670 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24670 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1025,1,17680,32,17,2,268,17,2048,16400,4096,2341,1284,32,257,33,16385,513]

theorem envBound24671 : H12AffineFastState.Bounded env24671 := by
  intro p hp
  have h : env24671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24670_24671 : H12AffineEnvironment.transform 12 269 env24670 = env24671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24670 == env24671) = true)

theorem identity24671 : scanCanonicalize (H12AffineFastState.compose env24671 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24672 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,4096,269,16384,0,263,16400,2341,20,1,16645,32,17,2,268,17,2048,16400,4096,2341,273,32,257,33,16385,513]

theorem envBound24672 : H12AffineFastState.Bounded env24672 := by
  intro p hp
  have h : env24672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24671_24672 : H12AffineEnvironment.transform 9 21 env24671 = env24672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24671 == env24672) = true)

theorem identity24672 : scanCanonicalize (H12AffineFastState.compose env24672 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound24672 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24673 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,4096,269,4373,0,263,4357,2341,20,1,4112,32,17,2,268,17,2048,4357,4096,2341,273,32,257,33,4372,513]

theorem envBound24673 : H12AffineFastState.Bounded env24673 := by
  intro p hp
  have h : env24673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24672_24673 : H12AffineEnvironment.transform 13 4373 env24672 = env24673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env24672 == env24673) = true)

theorem identity24673 : scanCanonicalize (H12AffineFastState.compose env24673 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound24673 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24674 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,560,269,805,0,263,821,2341,20,1,544,32,17,2,268,17,2048,821,560,2341,273,32,257,33,804,513]

theorem envBound24674 : H12AffineFastState.Bounded env24674 := by
  intro p hp
  have h : env24674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24673_24674 : H12AffineEnvironment.transform 11 560 env24673 = env24674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env24673 == env24674) = true)

theorem identity24674 : scanCanonicalize (H12AffineFastState.compose env24674 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound24674 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24675 : List Nat := [2,4,8,16,32,16,9,256,512,21,820,560,269,805,0,263,821,529,20,1,544,32,17,2,268,17,820,821,560,529,273,32,257,33,804,513]

theorem envBound24675 : H12AffineFastState.Bounded env24675 := by
  intro p hp
  have h : env24675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24674_24675 : H12AffineEnvironment.transform 10 820 env24674 = env24675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env24674 == env24675) = true)

theorem identity24675 : scanCanonicalize (H12AffineFastState.compose env24675 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24675 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24676 : List Nat := [2,4,8,16,32,16,9,36,512,21,528,560,41,513,0,35,529,529,20,1,544,32,17,2,40,17,528,529,560,529,53,32,37,33,512,513]

theorem envBound24676 : H12AffineFastState.Bounded env24676 := by
  intro p hp
  have h : env24676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24675_24676 : H12AffineEnvironment.transform 7 36 env24675 = env24676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24675 == env24676) = true)

theorem identity24676 : scanCanonicalize (H12AffineFastState.compose env24676 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24676 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24677 : List Nat := [2,4,8,16,0,16,9,4,512,21,528,528,9,513,0,3,529,529,20,1,512,0,17,2,8,17,528,529,528,529,21,0,5,1,512,513]

theorem envBound24677 : H12AffineFastState.Bounded env24677 := by
  intro p hp
  have h : env24677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24676_24677 : H12AffineEnvironment.transform 4 0 env24676 = env24677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24676 == env24677) = true)

def env24678 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114835,8193,16,215318,114966,45324,2231333,75023,73770,257,2188602,2196503,513]

theorem envBound24678 : H12AffineFastState.Bounded env24678 := by
  intro p hp
  have h : env24678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24665_24678 : H12AffineEnvironment.transform 5 17 env24665 = env24678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24665 == env24678) = true)

theorem identity24678 : scanCanonicalize (H12AffineFastState.compose env24678 (packedSelected [14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound24678 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env24679 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33031,131072,10280,1025,32769,2097152,32,2155532,2114835,8193,16,182289,16401,45324,2231333,41992,41261,257,2155581,2098448,513]

theorem envBound24679 : H12AffineFastState.Bounded env24679 := by
  intro p hp
  have h : env24679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24678_24679 : H12AffineEnvironment.transform 15 33031 env24678 = env24679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env24678 == env24679) = true)

theorem identity24679 : scanCanonicalize (H12AffineFastState.compose env24679 (packedSelected [11,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24679 : packedSelected [11,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24680 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33031,131072,2341,1025,32769,2097152,32,2147585,2114835,268,16,182289,16401,36865,2231333,34053,32800,257,2147632,2098448,513]

theorem envBound24680 : H12AffineFastState.Bounded env24680 := by
  intro p hp
  have h : env24680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24679_24680 : H12AffineEnvironment.transform 12 269 env24679 = env24680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24679 == env24680) = true)

theorem identity24680 : scanCanonicalize (H12AffineFastState.compose env24680 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24680 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24681 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,131072,2341,1025,1,2097152,32,2114817,2114835,268,16,149521,16401,4097,2231333,1285,32,257,2114864,2098448,513]

theorem envBound24681 : H12AffineFastState.Bounded env24681 := by
  intro p hp
  have h : env24681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24680_24681 : H12AffineEnvironment.transform 14 0 env24680 = env24681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24680 == env24681) = true)

def env24682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155532,2114882,8193,65,215366,115015,45405,2231333,75102,73771,257,2188651,2196550,513]

theorem envBound24682 : H12AffineFastState.Bounded env24682 := by
  intro p hp
  have h : env24682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24664_24682 : H12AffineEnvironment.transform 21 33 env24664 = env24682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env24664 == env24682) = true)

theorem identity24682 : scanCanonicalize (H12AffineFastState.compose env24682 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound24682 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58397,33,17,41311,8193,65,215366,115015,45405,190520,75102,73771,257,98678,90203,513]

theorem envBound24683 : H12AffineFastState.Bounded env24683 := by
  intro p hp
  have h : env24683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24682_24683 : H12AffineEnvironment.transform 20 58397 env24682 = env24683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env24682 == env24683) = true)

theorem identity24683 : scanCanonicalize (H12AffineFastState.compose env24683 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24683 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env24684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,33,17,41311,8193,65,67926,115015,45405,43048,75102,73771,257,98678,90203,513]

theorem envBound24684 : H12AffineFastState.Bounded env24684 := by
  intro p hp
  have h : env24684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24683_24684 : H12AffineEnvironment.transform 16 16400 env24683 = env24684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24683 == env24684) = true)

theorem identity24684 : scanCanonicalize (H12AffineFastState.compose env24684 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound24684 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env24685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8282,16400,10280,1025,32769,58397,33,17,41311,8193,65,10508,57629,45405,43048,1284,113,257,41260,16385,513]

theorem envBound24685 : H12AffineFastState.Bounded env24685 := by
  intro p hp
  have h : env24685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24684_24685 : H12AffineEnvironment.transform 15 8282 env24684 = env24685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env24684 == env24685) = true)

theorem identity24685 : scanCanonicalize (H12AffineFastState.compose env24685 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound24685 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8282,16400,10280,1025,80,25676,33,17,8462,8193,65,10508,24908,12556,10361,1284,113,257,8573,16385,513]

theorem envBound24686 : H12AffineFastState.Bounded env24686 := by
  intro p hp
  have h : env24686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24685_24686 : H12AffineEnvironment.transform 14 81 env24685 = env24686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env24685 == env24686) = true)

theorem identity24686 : scanCanonicalize (H12AffineFastState.compose env24686 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24686 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,81,262,16400,2420,1025,80,17680,33,17,82,349,65,2128,16400,4176,2341,1284,113,257,33,16385,513]

theorem envBound24687 : H12AffineFastState.Bounded env24687 := by
  intro p hp
  have h : env24687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24686_24687 : H12AffineEnvironment.transform 12 348 env24686 = env24687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24686 == env24687) = true)

def env24688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155533,2114883,8193,65,4409703,115014,45404,2231332,75102,4268043,257,2188651,2196550,513]

theorem envBound24688 : H12AffineFastState.Bounded env24688 := by
  intro p hp
  have h : env24688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24663_24688 : H12AffineEnvironment.transform 22 2155533 env24663 = env24688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env24663 == env24688) = true)

def env24689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114883,8193,65,215367,115014,45404,2231332,75102,73771,257,2188651,2196550,513]

theorem envBound24689 : H12AffineFastState.Bounded env24689 := by
  intro p hp
  have h : env24689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24688_24689 : H12AffineEnvironment.transform 21 32 env24688 = env24689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env24688 == env24689) = true)

theorem identity24689 : scanCanonicalize (H12AffineFastState.compose env24689 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound24689 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,73755,98645,8193,65,215367,115014,45404,247858,75102,73771,257,41341,16464,513]

theorem envBound24690 : H12AffineFastState.Bounded env24690 := by
  intro p hp
  have h : env24690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24689_24690 : H12AffineEnvironment.transform 20 115734 env24689 = env24690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env24689 == env24690) = true)

theorem identity24690 : scanCanonicalize (H12AffineFastState.compose env24690 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24690 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env24691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,115734,32,73755,98645,8193,65,67927,115014,45404,100386,75102,73771,257,41341,16464,513]

theorem envBound24691 : H12AffineFastState.Bounded env24691 := by
  intro p hp
  have h : env24691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24690_24691 : H12AffineEnvironment.transform 16 16400 env24690 = env24691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24690 == env24691) = true)

theorem identity24691 : scanCanonicalize (H12AffineFastState.compose env24691 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24691 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,58396,32,17,41311,8193,65,10589,57676,45404,43048,1364,33,257,41341,16464,513]

theorem envBound24692 : H12AffineFastState.Bounded env24692 := by
  intro p hp
  have h : env24692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24691_24692 : H12AffineEnvironment.transform 15 8202 env24691 = env24692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24691 == env24692) = true)

theorem identity24692 : scanCanonicalize (H12AffineFastState.compose env24692 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound24692 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8202,16400,10280,1025,80,25677,32,17,8462,8193,65,10589,24861,12557,10361,1364,33,257,8492,16464,513]

theorem envBound24693 : H12AffineFastState.Bounded env24693 := by
  intro p hp
  have h : env24693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24692_24693 : H12AffineEnvironment.transform 14 81 env24692 = env24693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env24692 == env24693) = true)

theorem identity24693 : scanCanonicalize (H12AffineFastState.compose env24693 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24693 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,81,342,16400,2420,1025,80,17681,32,17,82,349,65,2049,16449,4177,2341,1364,33,257,112,16464,513]

theorem envBound24694 : H12AffineFastState.Bounded env24694 := by
  intro p hp
  have h : env24694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24693_24694 : H12AffineEnvironment.transform 12 348 env24693 = env24694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24693 == env24694) = true)

theorem identity24694 : scanCanonicalize (H12AffineFastState.compose env24694 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24695 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1025,1,17681,32,17,3,268,16,2049,16400,4096,2341,1285,33,257,33,16385,513]

theorem envBound24695 : H12AffineFastState.Bounded env24695 := by
  intro p hp
  have h : env24695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24694_24695 : H12AffineEnvironment.transform 5 17 env24694 = env24695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24694 == env24695) = true)

theorem identity24695 : scanCanonicalize (H12AffineFastState.compose env24695 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24696 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2308,1025,1,17681,1,17,3,268,16,2049,16400,4096,2308,1285,0,257,0,16385,513]

theorem envBound24696 : H12AffineFastState.Bounded env24696 := by
  intro p hp
  have h : env24696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24695_24696 : H12AffineEnvironment.transform 4 1 env24695 = env24696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24695 == env24696) = true)

theorem identity24696 : scanCanonicalize (H12AffineFastState.compose env24696 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24697 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,17,269,16384,0,263,16400,2308,1025,1,17681,1,17,3,268,16,2049,16400,17,2308,1285,0,257,0,16385,513]

theorem envBound24697 : H12AffineFastState.Bounded env24697 := by
  intro p hp
  have h : env24697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24696_24697 : H12AffineEnvironment.transform 11 17 env24696 = env24697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24696 == env24697) = true)

theorem identity24697 : scanCanonicalize (H12AffineFastState.compose env24697 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound24697 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24698 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,17,269,1809,0,263,1793,2308,1025,1,512,1,17,3,268,16,2049,1793,17,2308,1285,0,257,0,1808,513]

theorem envBound24698 : H12AffineFastState.Bounded env24698 := by
  intro p hp
  have h : env24698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24697_24698 : H12AffineEnvironment.transform 13 1809 env24697 = env24698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env24697 == env24698) = true)

theorem identity24698 : scanCanonicalize (H12AffineFastState.compose env24698 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound24698 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24699 : List Nat := [2,4,8,16,1,17,9,256,512,1024,529,17,269,1809,0,263,1793,789,1025,1,512,1,17,3,268,16,528,1793,17,789,1285,0,257,0,1808,513]

theorem envBound24699 : H12AffineFastState.Bounded env24699 := by
  intro p hp
  have h : env24699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24698_24699 : H12AffineEnvironment.transform 10 529 env24698 = env24699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env24698 == env24699) = true)

theorem identity24699 : scanCanonicalize (H12AffineFastState.compose env24699 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound24699 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24700 : List Nat := [2,4,8,16,1,17,9,256,512,257,529,17,269,528,0,263,512,789,256,1,512,1,17,3,268,16,528,512,17,789,4,0,257,0,529,513]

theorem envBound24700 : H12AffineFastState.Bounded env24700 := by
  intro p hp
  have h : env24700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24699_24700 : H12AffineEnvironment.transform 9 257 env24699 = env24700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env24699 == env24700) = true)

theorem identity24700 : scanCanonicalize (H12AffineFastState.compose env24700 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound24700 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24701 : List Nat := [2,4,8,16,1,17,9,256,260,257,277,17,269,276,0,263,260,17,256,1,260,1,17,3,268,16,276,260,17,17,4,0,257,0,277,261]

theorem envBound24701 : H12AffineFastState.Bounded env24701 := by
  intro p hp
  have h : env24701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24700_24701 : H12AffineEnvironment.transform 8 260 env24700 = env24701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env24700 == env24701) = true)

def env24702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155533,2114883,8193,65,215366,115014,45404,2231332,75102,73770,257,2188651,2196550,513]

theorem envBound24702 : H12AffineFastState.Bounded env24702 := by
  intro p hp
  have h : env24702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24688_24702 : H12AffineEnvironment.transform 21 33 env24688 = env24702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env24688 == env24702) = true)

theorem identity24702 : scanCanonicalize (H12AffineFastState.compose env24702 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24702 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,2097152,33,2155533,2114883,8193,65,158028,57676,45404,2231332,1364,32,257,2114913,2139212,513]

theorem envBound24703 : H12AffineFastState.Bounded env24703 := by
  intro p hp
  have h : env24703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24702_24703 : H12AffineEnvironment.transform 15 8202 env24702 = env24703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24702 == env24703) = true)

theorem identity24703 : scanCanonicalize (H12AffineFastState.compose env24703 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 173149) := by decide +kernel

theorem selectedBound24703 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env24704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,173149,33,147536,188702,8193,65,158028,57676,45404,43129,1364,32,257,188732,131089,513]

theorem envBound24704 : H12AffineFastState.Bounded env24704 := by
  intro p hp
  have h : env24704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24703_24704 : H12AffineEnvironment.transform 20 173149 env24703 = env24704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173149 env24703 == env24704) = true)

theorem identity24704 : scanCanonicalize (H12AffineFastState.compose env24704 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound24704 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env24705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,10280,1025,32769,50448,33,8477,32851,8193,65,2049,57676,45404,43129,1364,32,257,32881,24924,513]

theorem envBound24705 : H12AffineFastState.Bounded env24705 := by
  intro p hp
  have h : env24705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24704_24705 : H12AffineEnvironment.transform 16 24909 env24704 = env24705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env24704 == env24705) = true)

theorem identity24705 : scanCanonicalize (H12AffineFastState.compose env24705 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24705 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,262,16449,2340,1025,32769,50448,33,17,32851,269,65,2049,49216,36944,35189,1364,32,257,32881,16464,513]

theorem envBound24706 : H12AffineFastState.Bounded env24706 := by
  intro p hp
  have h : env24706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24705_24706 : H12AffineEnvironment.transform 12 268 env24705 = env24706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24705 == env24706) = true)

theorem identity24706 : scanCanonicalize (H12AffineFastState.compose env24706 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24706 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,262,16449,2340,1025,1,17680,33,17,83,269,65,2049,16448,4176,2421,1364,32,257,113,16464,513]

theorem envBound24707 : H12AffineFastState.Bounded env24707 := by
  intro p hp
  have h : env24707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24706_24707 : H12AffineEnvironment.transform 14 0 env24706 = env24707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24706 == env24707) = true)

theorem identity24707 : scanCanonicalize (H12AffineFastState.compose env24707 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24707 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24708 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16400,2340,1025,1,17680,33,17,2,269,16,2049,16401,4097,2340,1285,32,257,32,16385,513]

theorem envBound24708 : H12AffineFastState.Bounded env24708 := by
  intro p hp
  have h : env24708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24707_24708 : H12AffineEnvironment.transform 5 17 env24707 = env24708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24707 == env24708) = true)

theorem identity24708 : scanCanonicalize (H12AffineFastState.compose env24708 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound24708 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24709 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4112,0,262,4096,2340,1025,1,5376,33,17,2,269,16,2049,4097,4097,2340,1285,32,257,32,4113,513]

theorem envBound24709 : H12AffineFastState.Bounded env24709 := by
  intro p hp
  have h : env24709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24708_24709 : H12AffineEnvironment.transform 13 4112 env24708 = env24709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env24708 == env24709) = true)

theorem identity24709 : scanCanonicalize (H12AffineFastState.compose env24709 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound24709 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24710 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,293,0,262,309,2340,1025,1,1077,33,17,2,269,16,2049,308,308,2340,1285,32,257,32,292,513]

theorem envBound24710 : H12AffineFastState.Bounded env24710 := by
  intro p hp
  have h : env24710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24709_24710 : H12AffineEnvironment.transform 11 309 env24709 = env24710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env24709 == env24710) = true)

theorem identity24710 : scanCanonicalize (H12AffineFastState.compose env24710 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24710 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24711 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,17,40,1,0,34,17,2048,1025,1,1077,33,17,2,41,16,2049,16,16,2048,1057,32,37,32,0,513]

theorem envBound24711 : H12AffineFastState.Bounded env24711 := by
  intro p hp
  have h : env24711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24710_24711 : H12AffineEnvironment.transform 7 36 env24710 = env24711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24710 == env24711) = true)

theorem identity24711 : scanCanonicalize (H12AffineFastState.compose env24711 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24711 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24712 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,17,40,1,0,34,17,1077,1025,1,1077,33,17,2,41,16,1076,16,16,1077,1057,32,37,32,0,513]

theorem envBound24712 : H12AffineFastState.Bounded env24712 := by
  intro p hp
  have h : env24712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24711_24712 : H12AffineEnvironment.transform 10 1077 env24711 = env24712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env24711 == env24712) = true)

def env24713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound24713 : H12AffineFastState.Bounded env24713 := by
  intro p hp
  have h : env24713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24416_24713 : H12AffineEnvironment.transform 26 30393345 env24416 = env24713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env24416 == env24713) = true)

def env24714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound24714 : H12AffineFastState.Bounded env24714 := by
  intro p hp
  have h : env24714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24713_24714 : H12AffineEnvironment.transform 18 1024 env24713 = env24714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24713 == env24714) = true)

theorem identity24714 : scanCanonicalize (H12AffineFastState.compose env24714 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534761) := by decide +kernel

theorem selectedBound24714 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,16777216,8328,65,23162216,18973837,456760,2125160,19343737,23160256,256,17263045,17270881,19271342]

theorem envBound24715 : H12AffineFastState.Bounded env24715 := by
  intro p hp
  have h : env24715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24714_24715 : H12AffineEnvironment.transform 22 2534761 env24714 = env24715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534761 env24714 == env24715) = true)

def env24716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,474340,8328,65,6705548,2537577,456760,2125160,2102685,6707492,256,21793,46213,2175562]

theorem envBound24716 : H12AffineFastState.Bounded env24716 := by
  intro p hp
  have h : env24716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24715_24716 : H12AffineEnvironment.transform 23 474340 env24715 = env24716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474340 env24715 == env24716) = true)

def env24717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101329,98780,8328,65,6352052,2098513,17664,2125160,2102685,6349852,256,21793,46213,2175562]

theorem envBound24717 : H12AffineFastState.Bounded env24717 := by
  intro p hp
  have h : env24717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24716_24717 : H12AffineEnvironment.transform 17 179512 env24716 = env24717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env24716 == env24717) = true)

def env24718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,17,98780,8328,65,4259060,5393,17664,32040,1501,4256860,256,21793,46213,74250]

theorem envBound24718 : H12AffineFastState.Bounded env24718 := by
  intro p hp
  have h : env24718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24717_24718 : H12AffineEnvironment.transform 20 4160 env24717 = env24718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24717 == env24718) = true)

theorem identity24718 : scanCanonicalize (H12AffineFastState.compose env24718 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound24718 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,17,98780,8328,65,171417,5393,17664,32040,1501,169265,256,21793,46213,74250]

theorem envBound24719 : H12AffineFastState.Bounded env24719 := by
  intro p hp
  have h : env24719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24718_24719 : H12AffineEnvironment.transform 21 156013 env24718 = env24719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env24718 == env24719) = true)

def env24720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,17,98644,8192,65,171281,5393,17664,32040,1365,169265,256,21793,46093,74250]

theorem envBound24720 : H12AffineFastState.Bounded env24720 := by
  intro p hp
  have h : env24720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24719_24720 : H12AffineEnvironment.transform 6 8 env24719 = env24720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24719 == env24720) = true)

theorem identity24720 : scanCanonicalize (H12AffineFastState.compose env24720 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24720 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179512,1024,32769,4160,156013,17,2,8192,65,171281,5393,17664,32040,1365,169265,256,21793,46093,41820]

theorem envBound24721 : H12AffineFastState.Bounded env24721 := by
  intro p hp
  have h : env24721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24720_24721 : H12AffineEnvironment.transform 15 33110 env24720 = env24721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24720 == env24721) = true)

theorem identity24721 : scanCanonicalize (H12AffineFastState.compose env24721 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound24721 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,49217,32121,1024,32769,4160,41260,17,2,8192,65,23888,5393,17664,32040,1365,21872,256,21793,46093,41820]

theorem envBound24722 : H12AffineFastState.Bounded env24722 := by
  intro p hp
  have h : env24722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24721_24722 : H12AffineEnvironment.transform 16 49217 env24721 = env24722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env24721 == env24722) = true)

theorem identity24722 : scanCanonicalize (H12AffineFastState.compose env24722 (packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound24722 : packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,33110,46393,2049,1024,32769,4160,41260,17,2,8192,65,10280,5393,12408,2128,1365,8200,256,8281,46093,41820]

theorem envBound24723 : H12AffineFastState.Bounded env24723 := by
  intro p hp
  have h : env24723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24722_24723 : H12AffineEnvironment.transform 13 13688 env24722 = env24723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env24722 == env24723) = true)

theorem identity24723 : scanCanonicalize (H12AffineFastState.compose env24723 (packedSelected [2,3,6,9,10,11,14,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24723 : packedSelected [2,3,6,9,10,11,14,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env24724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8460,8282,5173,2049,1024,8461,4160,32,17,2,8192,65,10280,5393,12408,2128,1365,8200,256,8281,5377,592]

theorem envBound24724 : H12AffineFastState.Bounded env24724 := by
  intro p hp
  have h : env24724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24723_24724 : H12AffineEnvironment.transform 14 8460 env24723 = env24724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24723 == env24724) = true)

theorem identity24724 : scanCanonicalize (H12AffineFastState.compose env24724 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24724 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env24725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5236,0,342,5173,2049,1024,1,4160,32,17,2,268,65,2340,5393,4468,2128,1365,260,256,341,5377,592]

theorem envBound24725 : H12AffineFastState.Bounded env24725 := by
  intro p hp
  have h : env24725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24724_24725 : H12AffineEnvironment.transform 12 268 env24724 = env24725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24724 == env24725) = true)

theorem identity24725 : scanCanonicalize (H12AffineFastState.compose env24725 (packedSelected [2,3,5,6,10,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24725 : packedSelected [2,3,5,6,10,12,14] rootPS < 2^1333 := by decide +kernel

def env24726 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,0,262,5173,2049,1024,1,4112,32,17,2,268,17,2340,5393,4388,2048,1285,260,256,261,5377,512]

theorem envBound24726 : H12AffineFastState.Bounded env24726 := by
  intro p hp
  have h : env24726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24725_24726 : H12AffineEnvironment.transform 5 16 env24725 = env24726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24725 == env24726) = true)

theorem identity24726 : scanCanonicalize (H12AffineFastState.compose env24726 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24726 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24727 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,268,5125,0,262,5140,2049,1024,1,4112,1,17,2,268,17,2309,5393,4357,2048,1285,260,256,261,5377,512]

theorem envBound24727 : H12AffineFastState.Bounded env24727 := by
  intro p hp
  have h : env24727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24726_24727 : H12AffineEnvironment.transform 4 1 env24726 = env24727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24726 == env24727) = true)

theorem identity24727 : scanCanonicalize (H12AffineFastState.compose env24727 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24727 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24728 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,0,3,5140,2049,1024,1,4112,1,17,2,9,17,2048,5140,4096,2048,1024,1,5,0,5124,512]

theorem envBound24728 : H12AffineFastState.Bounded env24728 := by
  intro p hp
  have h : env24728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24727_24728 : H12AffineEnvironment.transform 7 5 env24727 = env24728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24727 == env24728) = true)

theorem identity24728 : scanCanonicalize (H12AffineFastState.compose env24728 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24728 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24729 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,4096,9,4113,0,3,4096,2049,20,1,4112,1,17,2,9,17,2048,4096,4096,2048,20,1,5,0,4112,512]

theorem envBound24729 : H12AffineFastState.Bounded env24729 := by
  intro p hp
  have h : env24729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24728_24729 : H12AffineEnvironment.transform 9 20 env24728 = env24729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24728 == env24729) = true)

theorem identity24729 : scanCanonicalize (H12AffineFastState.compose env24729 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound24729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24730 : List Nat := [2,4,8,16,1,16,8,5,512,20,528,4096,9,4113,0,3,4096,529,20,1,4112,1,17,2,9,17,528,4096,4096,528,20,1,5,0,4112,512]

theorem envBound24730 : H12AffineFastState.Bounded env24730 := by
  intro p hp
  have h : env24730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24729_24730 : H12AffineEnvironment.transform 10 528 env24729 = env24730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env24729 == env24730) = true)

theorem identity24730 : scanCanonicalize (H12AffineFastState.compose env24730 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound24730 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24731 : List Nat := [2,4,8,16,1,16,8,5,15,20,31,4096,9,4113,0,3,4096,30,20,1,4112,1,17,2,9,17,31,4096,4096,31,20,1,5,0,4112,15]

theorem envBound24731 : H12AffineFastState.Bounded env24731 := by
  intro p hp
  have h : env24731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24730_24731 : H12AffineEnvironment.transform 8 15 env24730 = env24731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env24730 == env24731) = true)

theorem identity24731 : scanCanonicalize (H12AffineFastState.compose env24731 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24731 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24732 : List Nat := [2,4,8,16,1,16,8,5,15,20,31,16,9,1,0,3,16,30,20,1,0,1,17,2,9,17,31,16,16,31,20,1,5,0,0,15]

theorem envBound24732 : H12AffineFastState.Bounded env24732 := by
  intro p hp
  have h : env24732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24731_24732 : H12AffineEnvironment.transform 11 16 env24731 = env24732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24731 == env24732) = true)

theorem identity24732 : scanCanonicalize (H12AffineFastState.compose env24732 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound24732 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24733 : List Nat := [2,4,6,16,1,16,6,5,1,20,17,16,7,1,0,3,16,16,20,1,0,1,17,2,7,17,17,16,16,17,20,1,5,0,0,1]

theorem envBound24733 : H12AffineFastState.Bounded env24733 := by
  intro p hp
  have h : env24733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24732_24733 : H12AffineEnvironment.transform 2 6 env24732 = env24733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env24732 == env24733) = true)

def env24734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,17,98645,8193,65,171280,5393,17664,32040,1364,169265,256,21793,46092,74250]

theorem envBound24734 : H12AffineFastState.Bounded env24734 := by
  intro p hp
  have h : env24734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24719_24734 : H12AffineEnvironment.transform 6 9 env24719 = env24734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24719 == env24734) = true)

theorem identity24734 : scanCanonicalize (H12AffineFastState.compose env24734 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24734 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,156013,17,41310,8193,65,171280,5393,17664,32040,1364,169265,256,21793,46092,513]

theorem envBound24735 : H12AffineFastState.Bounded env24735 := by
  intro p hp
  have h : env24735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24734_24735 : H12AffineEnvironment.transform 15 8203 env24734 = env24735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24734 == env24735) = true)

theorem identity24735 : scanCanonicalize (H12AffineFastState.compose env24735 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24735 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64809,1024,32769,4160,8572,17,41310,8193,65,56577,5393,17664,32040,1364,54560,256,21793,46092,513]

theorem envBound24736 : H12AffineFastState.Bounded env24736 := by
  intro p hp
  have h : env24736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24735_24736 : H12AffineEnvironment.transform 16 16401 env24735 = env24736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24735 == env24736) = true)

theorem identity24736 : scanCanonicalize (H12AffineFastState.compose env24736 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound24736 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,23668,1024,8540,4160,8572,17,3,8193,65,31836,5393,17664,32040,1364,29821,256,21793,5457,513]

theorem envBound24737 : H12AffineFastState.Bounded env24737 := by
  intro p hp
  have h : env24737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24736_24737 : H12AffineEnvironment.transform 14 8541 env24736 = env24737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env24736 == env24737) = true)

theorem identity24737 : scanCanonicalize (H12AffineFastState.compose env24737 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24737 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24738 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16401,23589,1024,8461,4113,8493,17,3,8193,16,31757,5393,17664,32040,1285,29740,256,21793,5376,513]

theorem envBound24738 : H12AffineFastState.Bounded env24738 := by
  intro p hp
  have h : env24738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24737_24738 : H12AffineEnvironment.transform 5 17 env24737 = env24738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24737 == env24738) = true)

theorem identity24738 : scanCanonicalize (H12AffineFastState.compose env24738 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15133) := by decide +kernel

theorem selectedBound24738 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24739 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15133,8460,8203,15116,10040,1024,8461,4113,8493,17,3,8193,16,1808,5393,15901,1589,1285,3889,256,11836,5376,513]

theorem envBound24739 : H12AffineFastState.Bounded env24739 := by
  intro p hp
  have h : env24739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24738_24739 : H12AffineEnvironment.transform 13 15133 env24738 = env24739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15133 env24738 == env24739) = true)

def env24740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98780,8328,65,4259061,5392,17664,32041,1500,4256861,256,21793,46213,74251]

theorem envBound24740 : H12AffineFastState.Bounded env24740 := by
  intro p hp
  have h : env24740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24717_24740 : H12AffineEnvironment.transform 20 4161 env24717 = env24740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24717 == env24740) = true)

theorem identity24740 : scanCanonicalize (H12AffineFastState.compose env24740 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24740 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149997,1024,29908,4161,4194304,16,95497,8328,65,4196384,5392,17664,32041,1500,4194440,256,21793,16464,74251]

theorem envBound24741 : H12AffineFastState.Bounded env24741 := by
  intro p hp
  have h : env24741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24740_24741 : H12AffineEnvironment.transform 14 29909 env24740 = env24741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24740 == env24741) = true)

def env24742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138477,1024,8660,4161,4194304,16,73737,8328,65,4196384,5392,4096,10281,1500,4194440,256,33,5456,74251]

theorem envBound24742 : H12AffineFastState.Bounded env24742 := by
  intro p hp
  have h : env24742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24741_24742 : H12AffineEnvironment.transform 13 5376 env24741 = env24742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24741 == env24742) = true)

theorem identity24742 : scanCanonicalize (H12AffineFastState.compose env24742 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound24742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,67755,1024,8660,4161,4194304,16,73737,8328,65,4196384,5392,4096,10281,1500,4194440,256,33,5456,74251]

theorem envBound24743 : H12AffineFastState.Bounded env24743 := by
  intro p hp
  have h : env24743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24742_24743 : H12AffineEnvironment.transform 16 70726 env24742 = env24743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env24742 == env24743) = true)

theorem identity24743 : scanCanonicalize (H12AffineFastState.compose env24743 (packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound24743 : packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,67755,1024,8660,4161,8613,16,73737,8328,65,10629,5392,4096,10281,1500,8493,256,33,5456,74251]

theorem envBound24744 : H12AffineFastState.Bounded env24744 := by
  intro p hp
  have h : env24744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24743_24744 : H12AffineEnvironment.transform 21 8613 env24743 = env24744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env24743 == env24744) = true)

theorem identity24744 : scanCanonicalize (H12AffineFastState.compose env24744 (packedSelected [3,5,9,12,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound24744 : packedSelected [3,5,9,12,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env24745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,479,5529,2420,1024,8660,4161,8613,16,8662,8328,65,10629,5392,4096,10281,1500,8493,256,33,5456,9172]

theorem envBound24745 : H12AffineFastState.Bounded env24745 := by
  intro p hp
  have h : env24745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24744_24745 : H12AffineEnvironment.transform 15 479 env24744 = env24745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env24744 == env24745) = true)

theorem identity24745 : scanCanonicalize (H12AffineFastState.compose env24745 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24745 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,342,5392,2420,1024,8541,4161,8492,16,8543,8193,65,10508,5392,4096,10281,1365,8493,256,33,5456,9053]

theorem envBound24746 : H12AffineFastState.Bounded env24746 := by
  intro p hp
  have h : env24746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24745_24746 : H12AffineEnvironment.transform 6 9 env24745 = env24746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24745 == env24746) = true)

theorem identity24746 : scanCanonicalize (H12AffineFastState.compose env24746 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24746 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env24747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4161,113,16,2,348,65,2129,5392,4096,2420,1365,112,256,33,5456,512]

theorem envBound24747 : H12AffineFastState.Bounded env24747 := by
  intro p hp
  have h : env24747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24746_24747 : H12AffineEnvironment.transform 12 349 env24746 = env24747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24746 == env24747) = true)

theorem identity24747 : scanCanonicalize (H12AffineFastState.compose env24747 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24747 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24748 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5376,1,294,5392,2308,1024,0,4145,1,16,2,300,49,2081,5392,4096,2308,1317,0,256,33,5408,512]

theorem envBound24748 : H12AffineFastState.Bounded env24748 := by
  intro p hp
  have h : env24748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24747_24748 : H12AffineEnvironment.transform 5 48 env24747 = env24748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24747 == env24748) = true)

theorem identity24748 : scanCanonicalize (H12AffineFastState.compose env24748 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24748 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env24749 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1076,4096,301,5376,1,294,5392,1328,1024,0,4145,1,16,2,300,49,1045,5392,4096,1328,1317,0,256,33,5408,512]

theorem envBound24749 : H12AffineFastState.Bounded env24749 := by
  intro p hp
  have h : env24749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24748_24749 : H12AffineEnvironment.transform 10 1076 env24748 = env24749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env24748 == env24749) = true)

theorem identity24749 : scanCanonicalize (H12AffineFastState.compose env24749 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound24749 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24750 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1076,1061,301,293,1,294,309,1328,1024,0,1044,1,16,2,300,49,1045,309,1061,1328,1317,0,256,33,261,512]

theorem envBound24750 : H12AffineFastState.Bounded env24750 := by
  intro p hp
  have h : env24750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24749_24750 : H12AffineEnvironment.transform 11 1061 env24749 = env24750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env24749 == env24750) = true)

theorem identity24750 : scanCanonicalize (H12AffineFastState.compose env24750 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24750 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24751 : List Nat := [2,4,8,16,32,48,9,5,512,1024,1076,1061,40,32,1,35,48,1077,1024,0,1044,1,16,2,41,49,1045,48,1061,1077,1056,0,5,33,0,512]

theorem envBound24751 : H12AffineFastState.Bounded env24751 := by
  intro p hp
  have h : env24751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24750_24751 : H12AffineEnvironment.transform 7 5 env24750 = env24751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24750 == env24751) = true)

theorem identity24751 : scanCanonicalize (H12AffineFastState.compose env24751 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound24751 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24752 : List Nat := [2,4,8,16,32,48,9,5,32,1024,1076,1061,40,32,1,35,48,1077,1024,0,1044,1,16,2,41,49,1045,48,1061,1077,1056,0,5,33,0,32]

theorem envBound24752 : H12AffineFastState.Bounded env24752 := by
  intro p hp
  have h : env24752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24751_24752 : H12AffineEnvironment.transform 8 32 env24751 = env24752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env24751 == env24752) = true)

def env24753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138476,1024,8661,4161,4194304,16,73736,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,74251]

theorem envBound24753 : H12AffineFastState.Bounded env24753 := by
  intro p hp
  have h : env24753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24741_24753 : H12AffineEnvironment.transform 13 5377 env24741 = env24753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24741 == env24753) = true)

theorem identity24753 : scanCanonicalize (H12AffineFastState.compose env24753 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound24753 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70862,67618,1024,8661,4161,4194304,16,73736,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,74251]

theorem envBound24754 : H12AffineFastState.Bounded env24754 := by
  intro p hp
  have h : env24754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24753_24754 : H12AffineEnvironment.transform 16 70862 env24753 = env24754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env24753 == env24754) = true)

theorem identity24754 : scanCanonicalize (H12AffineFastState.compose env24754 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24754 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13508,10280,1024,8661,4161,4194304,16,2,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,513]

theorem envBound24755 : H12AffineFastState.Bounded env24755 := by
  intro p hp
  have h : env24755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24754_24755 : H12AffineEnvironment.transform 15 8202 env24754 = env24755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24754 == env24755) = true)

theorem identity24755 : scanCanonicalize (H12AffineFastState.compose env24755 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound24755 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13508,10280,1024,8661,4161,8613,16,2,8328,65,10629,5392,4097,10280,1500,8493,256,32,5457,513]

theorem envBound24756 : H12AffineFastState.Bounded env24756 := by
  intro p hp
  have h : env24756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24755_24756 : H12AffineEnvironment.transform 21 8613 env24755 = env24756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env24755 == env24756) = true)

theorem identity24756 : scanCanonicalize (H12AffineFastState.compose env24756 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24756 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,13388,10280,1024,8541,4161,8493,16,2,8192,65,10509,5392,4097,10280,1364,8493,256,32,5457,513]

theorem envBound24757 : H12AffineFastState.Bounded env24757 := by
  intro p hp
  have h : env24757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24756_24757 : H12AffineEnvironment.transform 6 8 env24756 = env24757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24756 == env24757) = true)

theorem identity24757 : scanCanonicalize (H12AffineFastState.compose env24757 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound24757 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,8192,1,8540,8202,8524,10280,1024,8541,1345,8493,16,2,8192,65,10509,16,1281,10280,1364,8493,256,32,81,513]

theorem envBound24758 : H12AffineFastState.Bounded env24758 := by
  intro p hp
  have h : env24758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24757_24758 : H12AffineEnvironment.transform 11 1280 env24757 = env24758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env24757 == env24758) = true)

theorem identity24758 : scanCanonicalize (H12AffineFastState.compose env24758 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound24758 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env24759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,2088,1,2420,2082,2404,0,1024,2421,1345,2309,16,2,2088,65,293,16,1281,0,1364,2309,256,32,81,513]

theorem envBound24759 : H12AffineFastState.Bounded env24759 := by
  intro p hp
  have h : env24759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24758_24759 : H12AffineEnvironment.transform 12 2088 env24758 = env24759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env24758 == env24759) = true)

theorem identity24759 : scanCanonicalize (H12AffineFastState.compose env24759 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24759 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24760 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,2088,1,2420,2082,2404,0,272,2421,81,2309,16,2,2088,65,293,16,17,0,68,2309,256,32,81,513]

theorem envBound24760 : H12AffineFastState.Bounded env24760 := by
  intro p hp
  have h : env24760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24759_24760 : H12AffineEnvironment.transform 9 272 env24759 = env24760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24759 == env24760) = true)

def env24761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101328,98781,8328,65,6352053,2098512,17665,2125160,2102685,6349853,256,21793,46213,2175562]

theorem envBound24761 : H12AffineFastState.Bounded env24761 := by
  intro p hp
  have h : env24761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24716_24761 : H12AffineEnvironment.transform 17 179513 env24716 = env24761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env24716 == env24761) = true)

def env24762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98781,8328,65,4259061,5392,17665,32040,1501,4256861,256,21793,46213,74250]

theorem envBound24762 : H12AffineFastState.Bounded env24762 := by
  intro p hp
  have h : env24762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24761_24762 : H12AffineEnvironment.transform 20 4160 env24761 = env24762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24761 == env24762) = true)

def env24763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98645,8192,65,4258941,5392,17665,32040,1365,4256861,256,21793,46093,74250]

theorem envBound24763 : H12AffineFastState.Bounded env24763 := by
  intro p hp
  have h : env24763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24762_24763 : H12AffineEnvironment.transform 6 8 env24762 = env24763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24762 == env24763) = true)

theorem identity24763 : scanCanonicalize (H12AffineFastState.compose env24763 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound24763 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,108927,1024,32769,4160,4194304,16,98645,8192,65,4258941,5392,17665,32040,1365,4256861,256,21793,46093,74250]

theorem envBound24764 : H12AffineFastState.Bounded env24764 := by
  intro p hp
  have h : env24764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24763_24764 : H12AffineEnvironment.transform 16 70726 env24763 = env24764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env24763 == env24764) = true)

theorem identity24764 : scanCanonicalize (H12AffineFastState.compose env24764 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound24764 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env24765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,108927,1024,32769,4160,4194304,16,98645,8192,65,4229153,5392,12637,2420,1365,4227073,256,8573,46093,74250]

theorem envBound24765 : H12AffineFastState.Bounded env24765 := by
  intro p hp
  have h : env24765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24764_24765 : H12AffineEnvironment.transform 13 13404 env24764 = env24765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env24764 == env24765) = true)

theorem identity24765 : scanCanonicalize (H12AffineFastState.compose env24765 (packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound24765 : packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS < 2^1333 := by decide +kernel

def env24766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,372,65536,70726,75787,1024,373,4160,4194304,16,65569,8192,65,4196693,5392,12637,2420,1365,4194677,256,8573,13689,74250]

theorem envBound24766 : H12AffineFastState.Bounded env24766 := by
  intro p hp
  have h : env24766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24765_24766 : H12AffineEnvironment.transform 14 372 env24765 = env24766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env24765 == env24766) = true)

theorem identity24766 : scanCanonicalize (H12AffineFastState.compose env24766 (packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound24766 : packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS < 2^1333 := by decide +kernel

def env24767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,372,65536,70726,75787,1024,373,4160,8201,16,65569,8192,65,10588,5392,12637,2420,1365,8572,256,8573,13689,74250]

theorem envBound24767 : H12AffineFastState.Bounded env24767 := by
  intro p hp
  have h : env24767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24766_24767 : H12AffineEnvironment.transform 21 8201 env24766 = env24767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env24766 == env24767) = true)

theorem identity24767 : scanCanonicalize (H12AffineFastState.compose env24767 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24767 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,372,65536,70726,67618,1024,373,4160,32,16,65569,41,65,2421,5392,4468,2420,1365,341,256,340,5456,66083]

theorem envBound24768 : H12AffineFastState.Bounded env24768 := by
  intro p hp
  have h : env24768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24767_24768 : H12AffineEnvironment.transform 12 41 env24767 = env24768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24767 == env24768) = true)

theorem identity24768 : scanCanonicalize (H12AffineFastState.compose env24768 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24768 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env24769 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,65536,70726,67618,1024,1,4160,32,16,65569,41,65,2049,5220,4096,2048,1057,33,116,32,5156,66083]

theorem envBound24769 : H12AffineFastState.Bounded env24769 := by
  intro p hp
  have h : env24769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24768_24769 : H12AffineEnvironment.transform 7 116 env24768 = env24769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24768 == env24769) = true)

theorem identity24769 : scanCanonicalize (H12AffineFastState.compose env24769 (packedSelected [2,3,4,5,9,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound24769 : packedSelected [2,3,4,5,9,10,20] rootPS < 2^1333 := by decide +kernel

def env24770 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,35,5221,2049,1024,1,4160,32,16,2,41,65,2049,5220,4096,2048,1057,33,116,32,5156,512]

theorem envBound24770 : H12AffineFastState.Bounded env24770 := by
  intro p hp
  have h : env24770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24769_24770 : H12AffineEnvironment.transform 15 35 env24769 = env24770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env24769 == env24770) = true)

theorem identity24770 : scanCanonicalize (H12AffineFastState.compose env24770 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound24770 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24771 : List Nat := [2,4,8,16,32,64,8,116,512,1024,555,4096,41,5237,0,35,5221,554,1024,1,4160,32,16,2,41,65,554,5220,4096,555,1057,33,116,32,5156,512]

theorem envBound24771 : H12AffineFastState.Bounded env24771 := by
  intro p hp
  have h : env24771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24770_24771 : H12AffineEnvironment.transform 10 555 env24770 = env24771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env24770 == env24771) = true)

theorem identity24771 : scanCanonicalize (H12AffineFastState.compose env24771 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24771 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24772 : List Nat := [2,4,8,16,32,48,8,4,512,1024,555,4096,41,5125,0,35,5141,554,1024,1,4144,32,16,2,41,49,554,5140,4096,555,1057,33,4,32,5156,512]

theorem envBound24772 : H12AffineFastState.Bounded env24772 := by
  intro p hp
  have h : env24772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24771_24772 : H12AffineEnvironment.transform 5 48 env24771 = env24772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24771 == env24772) = true)

def env24773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98644,8193,65,4258940,5392,17665,32040,1364,4256861,256,21793,46092,74250]

theorem envBound24773 : H12AffineFastState.Bounded env24773 := by
  intro p hp
  have h : env24773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24762_24773 : H12AffineEnvironment.transform 6 9 env24762 = env24773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24762 == env24773) = true)

theorem identity24773 : scanCanonicalize (H12AffineFastState.compose env24773 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound24773 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,67619,1024,32769,4160,4194304,16,98644,8193,65,4258940,5392,17665,32040,1364,4256861,256,21793,46092,74250]

theorem envBound24774 : H12AffineFastState.Bounded env24774 := by
  intro p hp
  have h : env24774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24773_24774 : H12AffineEnvironment.transform 16 111898 env24773 = env24774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env24773 == env24774) = true)

theorem identity24774 : scanCanonicalize (H12AffineFastState.compose env24774 (packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound24774 : packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,46156,2421,1024,32769,4160,4194304,16,32770,8193,65,4258940,5392,17665,32040,1364,4256861,256,21793,46092,9052]

theorem envBound24775 : H12AffineFastState.Bounded env24775 := by
  intro p hp
  have h : env24775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24774_24775 : H12AffineEnvironment.transform 15 342 env24774 = env24775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env24774 == env24775) = true)

theorem identity24775 : scanCanonicalize (H12AffineFastState.compose env24775 (packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound24775 : packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env24776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,46156,2421,1024,32769,4160,8572,16,32770,8193,65,56576,5392,17665,32040,1364,54561,256,21793,46092,9052]

theorem envBound24776 : H12AffineFastState.Bounded env24776 := by
  intro p hp
  have h : env24776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24775_24776 : H12AffineEnvironment.transform 21 8572 env24775 = env24776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env24775 == env24776) = true)

theorem identity24776 : scanCanonicalize (H12AffineFastState.compose env24776 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound24776 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,5393,2421,1024,8540,4160,8572,16,8543,8193,65,31837,5392,17665,32040,1364,29820,256,21793,5457,9052]

theorem envBound24777 : H12AffineFastState.Bounded env24777 := by
  intro p hp
  have h : env24777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24776_24777 : H12AffineEnvironment.transform 14 8541 env24776 = env24777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env24776 == env24777) = true)

theorem identity24777 : scanCanonicalize (H12AffineFastState.compose env24777 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound24777 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13576,8541,342,5393,2421,1024,8540,4160,8572,16,8543,8193,65,2389,5392,12297,2080,1364,372,256,8233,5457,9052]

theorem envBound24778 : H12AffineFastState.Bounded env24778 := by
  intro p hp
  have h : env24778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24777_24778 : H12AffineEnvironment.transform 13 13576 env24777 = env24778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env24777 == env24778) = true)

theorem identity24778 : scanCanonicalize (H12AffineFastState.compose env24778 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24778 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env24779 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13405,8200,3,5188,2080,1024,8201,4160,8233,16,8202,8193,65,2048,5189,12297,2080,1025,33,85,8233,5124,8713]

theorem envBound24779 : H12AffineFastState.Bounded env24779 := by
  intro p hp
  have h : env24779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24778_24779 : H12AffineEnvironment.transform 7 85 env24778 = env24779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24778 == env24779) = true)

theorem identity24779 : scanCanonicalize (H12AffineFastState.compose env24779 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24779 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24780 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8192,13405,8200,3,5188,2049,1024,8201,4160,8200,16,8202,8193,65,2048,5189,12297,2049,1025,0,85,8200,5124,8713]

theorem envBound24780 : H12AffineFastState.Bounded env24780 := by
  intro p hp
  have h : env24780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24779_24780 : H12AffineEnvironment.transform 4 1 env24779 = env24780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24779 == env24780) = true)

theorem identity24780 : scanCanonicalize (H12AffineFastState.compose env24780 (packedSelected [3,5,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound24780 : packedSelected [3,5,10,16] rootPS < 2^1333 := by decide +kernel

def env24781 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8,5205,0,3,5188,2049,1024,1,4160,0,16,2,9,65,2048,5189,4097,2049,1025,0,85,0,5124,513]

theorem envBound24781 : H12AffineFastState.Bounded env24781 := by
  intro p hp
  have h : env24781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24780_24781 : H12AffineEnvironment.transform 12 8 env24780 = env24781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24780 == env24781) = true)

theorem identity24781 : scanCanonicalize (H12AffineFastState.compose env24781 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound24781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24782 : List Nat := [2,4,8,16,1,64,9,85,512,69,2048,4096,8,4112,0,3,4097,2049,69,1,4160,0,16,2,9,65,2048,4096,4097,2049,68,0,85,0,4161,513]

theorem envBound24782 : H12AffineFastState.Bounded env24782 := by
  intro p hp
  have h : env24782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24781_24782 : H12AffineEnvironment.transform 9 69 env24781 = env24782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env24781 == env24782) = true)

theorem identity24782 : scanCanonicalize (H12AffineFastState.compose env24782 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24782 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24783 : List Nat := [2,4,8,16,1,64,9,85,512,69,2048,16,8,0,0,3,17,2049,69,1,80,0,16,2,9,65,2048,16,17,2049,68,0,85,0,81,513]

theorem envBound24783 : H12AffineFastState.Bounded env24783 := by
  intro p hp
  have h : env24783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24782_24783 : H12AffineEnvironment.transform 11 16 env24782 = env24783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24782 == env24783) = true)

theorem identity24783 : scanCanonicalize (H12AffineFastState.compose env24783 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound24783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24784 : List Nat := [2,4,8,16,1,0,9,21,512,5,2048,16,8,0,0,3,17,2049,5,1,16,0,16,2,9,1,2048,16,17,2049,4,0,21,0,17,513]

theorem envBound24784 : H12AffineFastState.Bounded env24784 := by
  intro p hp
  have h : env24784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24783_24784 : H12AffineEnvironment.transform 5 0 env24783 = env24784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env24783 == env24784) = true)

theorem identity24784 : scanCanonicalize (H12AffineFastState.compose env24784 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24784 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24785 : List Nat := [2,4,8,16,1,0,9,21,16,5,2048,16,8,0,0,3,17,2049,5,1,16,0,16,2,9,1,2048,16,17,2049,4,0,21,0,17,17]

theorem envBound24785 : H12AffineFastState.Bounded env24785 := by
  intro p hp
  have h : env24785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24784_24785 : H12AffineEnvironment.transform 8 16 env24784 = env24785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24784 == env24785) = true)

theorem identity24785 : scanCanonicalize (H12AffineFastState.compose env24785 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound24785 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24786 : List Nat := [2,4,8,16,1,0,9,21,16,5,10,16,8,0,0,3,17,11,5,1,16,0,16,2,9,1,10,16,17,11,4,0,21,0,17,17]

theorem envBound24786 : H12AffineFastState.Bounded env24786 := by
  intro p hp
  have h : env24786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24785_24786 : H12AffineEnvironment.transform 10 10 env24785 = env24786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env24785 == env24786) = true)

theorem identity24786 : scanCanonicalize (H12AffineFastState.compose env24786 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24786 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env24787 : List Nat := [2,4,8,10,1,0,9,15,10,5,10,10,8,0,0,3,11,11,5,1,10,0,10,2,9,1,10,10,11,11,4,0,15,0,11,11]

theorem envBound24787 : H12AffineFastState.Bounded env24787 := by
  intro p hp
  have h : env24787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24786_24787 : H12AffineEnvironment.transform 3 10 env24786 = env24787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24786 == env24787) = true)

def env24788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,17,98781,8328,65,4259060,5393,17665,32041,1500,4256860,256,21793,46213,74251]

theorem envBound24788 : H12AffineFastState.Bounded env24788 := by
  intro p hp
  have h : env24788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24761_24788 : H12AffineEnvironment.transform 20 4161 env24761 = env24788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24761 == env24788) = true)

theorem identity24788 : scanCanonicalize (H12AffineFastState.compose env24788 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound24788 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169401,17,98781,8328,65,158029,5393,17665,32041,1500,156133,256,21793,46213,74251]

theorem envBound24789 : H12AffineFastState.Bounded env24789 := by
  intro p hp
  have h : env24789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24788_24789 : H12AffineEnvironment.transform 21 169401 env24788 = env24789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env24788 == env24789) = true)

theorem identity24789 : scanCanonicalize (H12AffineFastState.compose env24789 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24789 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4161,169401,17,41431,8328,65,158029,5393,17665,32041,1500,156133,256,21793,46213,513]

theorem envBound24790 : H12AffineFastState.Bounded env24790 := by
  intro p hp
  have h : env24790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24789_24790 : H12AffineEnvironment.transform 15 8202 env24789 = env24790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24789 == env24790) = true)

theorem identity24790 : scanCanonicalize (H12AffineFastState.compose env24790 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24790 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64809,1024,32769,4161,54697,17,41431,8328,65,10589,5393,17665,32041,1500,8693,256,21793,46213,513]

theorem envBound24791 : H12AffineFastState.Bounded env24791 := by
  intro p hp
  have h : env24791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24790_24791 : H12AffineEnvironment.transform 16 16400 env24790 = env24791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24790 == env24791) = true)

theorem identity24791 : scanCanonicalize (H12AffineFastState.compose env24791 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound24791 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env24792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16400,2341,1024,29709,4161,8613,17,21979,8328,65,10589,5393,17665,32041,1500,8693,256,21793,16521,513]

theorem envBound24792 : H12AffineFastState.Bounded env24792 := by
  intro p hp
  have h : env24792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24791_24792 : H12AffineEnvironment.transform 14 29708 env24791 = env24792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env24791 == env24792) = true)

theorem identity24792 : scanCanonicalize (H12AffineFastState.compose env24792 (packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24792 : packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21760,262,16400,2341,1024,21761,4161,169,17,21979,388,65,2129,5393,17665,23589,1500,249,256,21793,16521,513]

theorem envBound24793 : H12AffineFastState.Bounded env24793 := by
  intro p hp
  have h : env24793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24792_24793 : H12AffineEnvironment.transform 12 268 env24792 = env24793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24792 == env24793) = true)

theorem identity24793 : scanCanonicalize (H12AffineFastState.compose env24793 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound24793 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env24794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5156,292,262,5172,2341,1024,293,4161,169,17,511,388,65,2129,5393,4389,2049,1500,249,256,261,5293,513]

theorem envBound24794 : H12AffineFastState.Bounded env24794 := by
  intro p hp
  have h : env24794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24793_24794 : H12AffineEnvironment.transform 13 5156 env24793 = env24794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env24793 == env24794) = true)

theorem identity24794 : scanCanonicalize (H12AffineFastState.compose env24794 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound24794 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env24795 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,268,4160,292,262,4176,2341,100,293,4161,169,17,511,388,65,2129,4469,4389,2049,440,249,256,261,4297,513]

theorem envBound24795 : H12AffineFastState.Bounded env24795 := by
  intro p hp
  have h : env24795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24794_24795 : H12AffineEnvironment.transform 9 100 env24794 = env24795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env24794 == env24795) = true)

theorem identity24795 : scanCanonicalize (H12AffineFastState.compose env24795 (packedSelected [2,3,6,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24795 : packedSelected [2,3,6,8,10] rootPS < 2^1333 := by decide +kernel

def env24796 : List Nat := [2,4,8,16,32,64,88,256,512,100,2048,4096,268,4160,292,262,4176,2341,100,293,4161,113,17,295,348,65,2129,4469,4389,2049,352,33,256,261,4113,513]

theorem envBound24796 : H12AffineFastState.Bounded env24796 := by
  intro p hp
  have h : env24796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24795_24796 : H12AffineEnvironment.transform 6 88 env24795 = env24796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24795 == env24796) = true)

theorem identity24796 : scanCanonicalize (H12AffineFastState.compose env24796 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24796 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24797 : List Nat := [2,4,8,16,32,64,88,37,512,100,2048,4096,41,4160,1,35,4176,2048,100,0,4161,113,17,2,121,65,2129,4176,4096,2049,69,33,37,32,4113,513]

theorem envBound24797 : H12AffineFastState.Bounded env24797 := by
  intro p hp
  have h : env24797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24796_24797 : H12AffineEnvironment.transform 7 37 env24796 = env24797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24796 == env24797) = true)

theorem identity24797 : scanCanonicalize (H12AffineFastState.compose env24797 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24798 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4112,1,35,4096,2048,52,0,4113,33,17,2,41,17,2049,4096,4096,2049,21,33,37,32,4113,513]

theorem envBound24798 : H12AffineFastState.Bounded env24798 := by
  intro p hp
  have h : env24798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24797_24798 : H12AffineEnvironment.transform 5 16 env24797 = env24798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24797 == env24798) = true)

theorem identity24798 : scanCanonicalize (H12AffineFastState.compose env24798 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound24798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24799 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,512,41,528,1,35,512,2048,52,0,529,33,17,2,41,17,2049,512,512,2049,21,33,37,32,529,513]

theorem envBound24799 : H12AffineFastState.Bounded env24799 := by
  intro p hp
  have h : env24799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24798_24799 : H12AffineEnvironment.transform 11 512 env24798 = env24799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env24798 == env24799) = true)

theorem identity24799 : scanCanonicalize (H12AffineFastState.compose env24799 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound24799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0