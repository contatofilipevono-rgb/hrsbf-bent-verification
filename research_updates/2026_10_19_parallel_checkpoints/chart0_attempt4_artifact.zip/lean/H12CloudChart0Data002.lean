import H12CloudChart0Data001

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity477 : scanCanonicalize (H12AffineFastState.compose env477 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound477 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env478 : List Nat := [2,4,8,10,10,10,8,15,3,5,9,2,3,9,1,8,2,9,4,1,9,10,10,2,3,10,9,2,2,8,14,11,14,11,9,3]

theorem envBound478 : H12AffineFastState.Bounded env478 := by
  intro p hp
  have h : env478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans477_478 : H12AffineEnvironment.transform 3 10 env477 = env478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env477 == env478) = true)

theorem identity478 : scanCanonicalize (H12AffineFastState.compose env478 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env479 : List Nat := [2,1,8,10,10,10,8,10,3,0,9,2,3,9,1,8,2,9,1,1,9,10,10,2,3,10,9,2,2,8,11,11,11,11,9,3]

theorem envBound479 : H12AffineFastState.Bounded env479 := by
  intro p hp
  have h : env479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans478_479 : H12AffineEnvironment.transform 1 1 env478 = env479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env478 == env479) = true)

def leafEnv479 : List Nat := [2,1,8,10,10,10,8,10,3,0,9,2,3,9,1,8,2,9,1,1,9,10,10,2,10,3,1,10,9,2,2,8,11,11,11,11,0,8,9,3,1,8,0]

def active479 : List Nat := [0,2]

def tree479 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood479 : H12WitnessSearch.Good tree479 := H12GlobalWitnessIndex.good

theorem leafIdentity479 : H12AffineFastState.composeSystem env479 rootObs = leafEnv479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env479 rootObs == leafEnv479) = true)

theorem terminalChecked479 : H12PackedTerminal.terminalCheckFast leafEnv479 active479 tree479 = true := by decide +kernel

def env480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,131072,138513,236,8352,132132,32,1277,74228,8328,1197,138649,132285,5309,76279,1364,73770,1516,74199,132432,74371]

theorem envBound480 : H12AffineFastState.Bounded env480 := by
  intro p hp
  have h : env480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans452_480 : H12AffineEnvironment.transform 17 138513 env452 = env480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138513 env452 == env480) = true)

theorem identity480 : scanCanonicalize (H12AffineFastState.compose env480 (packedSelected [21] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound480 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env481 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,65536,131072,138476,236,8352,132132,32,1277,73737,8328,1197,138340,132285,5309,75786,1193,73770,1041,73770,132269,74371]

theorem envBound481 : H12AffineFastState.Bounded env481 := by
  intro p hp
  have h : env481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans480_481 : H12AffineEnvironment.transform 7 253 env480 = env481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env480 == env481) = true)

def env482 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,65536,2112,5292,236,8352,3172,32,1277,73737,8328,1197,5156,3325,5309,75786,1193,73770,1041,73770,3309,74371]

theorem envBound482 : H12AffineFastState.Bounded env482 := by
  intro p hp
  have h : env482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans481_482 : H12AffineEnvironment.transform 16 2112 env481 = env482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2112 env481 == env482) = true)

theorem identity482 : scanCanonicalize (H12AffineFastState.compose env482 (packedSelected [10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound482 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env483 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,34,2112,5292,236,8352,3172,32,1277,8235,8328,1197,5156,3325,5309,10280,1193,8200,1041,8200,3309,8865]

theorem envBound483 : H12AffineFastState.Bounded env483 := by
  intro p hp
  have h : env483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans482_483 : H12AffineEnvironment.transform 15 34 env482 = env483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env482 == env483) = true)

def env484 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4161,8232,34,2112,5156,100,8232,3172,32,1141,8235,8192,1061,5156,3189,5173,10280,1057,8200,1041,8200,3173,8745]

theorem envBound484 : H12AffineFastState.Bounded env484 := by
  intro p hp
  have h : env484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans483_484 : H12AffineEnvironment.transform 6 8 env483 = env484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env483 == env484) = true)

theorem identity484 : scanCanonicalize (H12AffineFastState.compose env484 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound484 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env485 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3109,8192,3172,8232,34,2112,2049,100,8232,3172,32,1141,8235,8192,1061,2049,3189,2064,10280,1057,8200,1041,8200,3173,8745]

theorem envBound485 : H12AffineFastState.Bounded env485 := by
  intro p hp
  have h : env485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans484_485 : H12AffineEnvironment.transform 11 3109 env484 = env485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env484 == env485) = true)

theorem identity485 : scanCanonicalize (H12AffineFastState.compose env485 (packedSelected [0,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound485 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env486 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1646,587,8192,522,8232,34,1582,1647,100,8232,522,32,1141,8235,8192,1061,1647,539,1662,9798,1057,8200,1041,8200,523,8745]

theorem envBound486 : H12AffineFastState.Bounded env486 := by
  intro p hp
  have h : env486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans485_486 : H12AffineEnvironment.transform 10 1646 env485 = env486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env485 == env486) = true)

def env487 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1646,587,40,522,0,34,1582,1647,100,0,522,32,1141,3,40,1061,1647,539,1662,1646,1057,32,1041,32,523,513]

theorem envBound487 : H12AffineFastState.Bounded env487 := by
  intro p hp
  have h : env487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans486_487 : H12AffineEnvironment.transform 12 40 env486 = env487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env486 == env487) = true)

theorem identity487 : scanCanonicalize (H12AffineFastState.compose env487 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound487 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env488 : List Nat := [2,4,8,16,32,49,8,4,512,1024,1567,570,40,522,0,34,1582,1566,21,0,522,32,1028,3,40,1061,1566,539,1551,1567,1057,32,1041,32,523,513]

theorem envBound488 : H12AffineFastState.Bounded env488 := by
  intro p hp
  have h : env488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans487_488 : H12AffineEnvironment.transform 5 49 env487 = env488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env487 == env488) = true)

theorem identity488 : scanCanonicalize (H12AffineFastState.compose env488 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound488 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env489 : List Nat := [1,4,8,16,32,49,8,4,512,1024,1564,569,40,521,0,33,1581,1565,21,0,521,32,1028,0,40,1061,1565,536,1548,1564,1057,32,1041,32,520,513]

theorem envBound489 : H12AffineFastState.Bounded env489 := by
  intro p hp
  have h : env489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans488_489 : H12AffineEnvironment.transform 0 1 env488 = env489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env488 == env489) = true)

theorem identity489 : scanCanonicalize (H12AffineFastState.compose env489 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env490 : List Nat := [1,4,8,16,32,49,8,4,33,1024,1085,24,40,40,0,33,1036,1084,21,0,40,32,1028,0,40,1061,1084,57,1069,1085,1057,32,1041,32,41,32]

theorem envBound490 : H12AffineFastState.Bounded env490 := by
  intro p hp
  have h : env490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans489_490 : H12AffineEnvironment.transform 8 33 env489 = env490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env489 == env490) = true)

def leafEnv490 : List Nat := [1,4,8,16,32,49,8,4,33,1024,1085,24,40,40,0,33,1036,1084,21,0,40,32,1028,0,52,40,1,1061,1084,57,1069,1085,1057,32,1041,32,1041,32,41,32,1,41,0]

def active490 : List Nat := [1,2,3,4,9]

def tree490 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood490 : H12WitnessSearch.Good tree490 := H12GlobalWitnessIndex.good

theorem leafIdentity490 : H12AffineFastState.composeSystem env490 rootObs = leafEnv490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env490 rootObs == leafEnv490) = true)

theorem terminalChecked490 : H12PackedTerminal.terminalCheckFast leafEnv490 active490 tree490 = true := by decide +kernel

def env491 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1646,587,41,522,1,34,1582,1647,100,1,522,32,1141,2,41,1061,1647,539,1662,1647,1057,33,1041,33,523,512]

theorem envBound491 : H12AffineFastState.Bounded env491 := by
  intro p hp
  have h : env491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans486_491 : H12AffineEnvironment.transform 12 41 env486 = env491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env486 == env491) = true)

theorem identity491 : scanCanonicalize (H12AffineFastState.compose env491 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env492 : List Nat := [2,4,8,16,32,64,8,117,512,85,571,587,41,522,1,34,635,570,100,1,522,32,32,2,41,112,570,539,555,570,116,33,68,33,523,512]

theorem envBound492 : H12AffineFastState.Bounded env492 := by
  intro p hp
  have h : env492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans491_492 : H12AffineEnvironment.transform 9 85 env491 = env492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env491 == env492) = true)

theorem identity492 : scanCanonicalize (H12AffineFastState.compose env492 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound492 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env493 : List Nat := [2,4,8,16,32,10,8,63,512,31,571,513,41,522,1,34,561,570,46,1,522,32,32,2,41,58,570,539,555,570,62,33,14,33,523,512]

theorem envBound493 : H12AffineFastState.Bounded env493 := by
  intro p hp
  have h : env493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans492_493 : H12AffineEnvironment.transform 5 10 env492 = env493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env492 == env493) = true)

theorem identity493 : scanCanonicalize (H12AffineFastState.compose env493 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env494 : List Nat := [2,4,8,10,32,10,8,37,512,5,545,513,41,522,1,34,555,544,46,1,522,32,32,2,41,32,544,513,555,544,36,33,14,33,523,512]

theorem envBound494 : H12AffineFastState.Bounded env494 := by
  intro p hp
  have h : env494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans493_494 : H12AffineEnvironment.transform 3 10 env493 = env494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env493 == env494) = true)

theorem identity494 : scanCanonicalize (H12AffineFastState.compose env494 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env495 : List Nat := [2,4,6,4,32,4,6,37,512,5,545,513,39,516,1,34,549,544,32,1,516,32,32,2,39,32,544,513,549,544,36,33,0,33,517,512]

theorem envBound495 : H12AffineFastState.Bounded env495 := by
  intro p hp
  have h : env495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans494_495 : H12AffineEnvironment.transform 2 6 env494 = env495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env494 == env495) = true)

theorem identity495 : scanCanonicalize (H12AffineFastState.compose env495 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound495 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env496 : List Nat := [2,4,6,4,4,4,6,1,512,5,517,513,3,516,1,6,513,516,4,1,516,4,4,2,3,4,516,513,513,516,0,5,0,5,517,512]

theorem envBound496 : H12AffineFastState.Bounded env496 := by
  intro p hp
  have h : env496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans495_496 : H12AffineEnvironment.transform 4 4 env495 = env496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env495 == env496) = true)

theorem identity496 : scanCanonicalize (H12AffineFastState.compose env496 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env497 : List Nat := [2,4,6,4,4,4,6,1,3,5,6,2,3,7,1,6,2,7,4,1,7,4,4,2,3,4,7,2,2,7,0,5,0,5,6,3]

theorem envBound497 : H12AffineFastState.Bounded env497 := by
  intro p hp
  have h : env497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans496_497 : H12AffineEnvironment.transform 8 3 env496 = env497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env496 == env497) = true)

def leafEnv497 : List Nat := [2,4,6,4,4,4,6,1,3,5,6,2,3,7,1,6,2,7,4,1,7,4,4,2,1,3,1,4,7,2,2,7,0,5,0,5,5,6,6,3,1,7,0]

def active497 : List Nat := [0,1]

def tree497 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood497 : H12WitnessSearch.Good tree497 := H12GlobalWitnessIndex.good

theorem leafIdentity497 : H12AffineFastState.composeSystem env497 rootObs = leafEnv497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env497 rootObs == leafEnv497) = true)

theorem terminalChecked497 : H12PackedTerminal.terminalCheckFast leafEnv497 active497 tree497 = true := by decide +kernel

def env498 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,4160,8233,34,2112,5157,101,8233,3172,32,1140,8235,8193,1060,5156,3188,5172,10280,1056,8200,1041,8200,3172,8744]

theorem envBound498 : H12AffineFastState.Bounded env498 := by
  intro p hp
  have h : env498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans483_498 : H12AffineEnvironment.transform 6 9 env483 = env498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env483 == env498) = true)

theorem identity498 : scanCanonicalize (H12AffineFastState.compose env498 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound498 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env499 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,7180,4160,7205,34,2112,5157,101,7205,3172,32,1140,7207,7181,1060,5156,3188,5172,5156,1056,7172,1041,7172,3172,7716]

theorem envBound499 : H12AffineFastState.Bounded env499 := by
  intro p hp
  have h : env499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans498_499 : H12AffineEnvironment.transform 12 7180 env498 = env499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env498 == env499) = true)

theorem identity499 : scanCanonicalize (H12AffineFastState.compose env499 (packedSelected [0,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound499 : packedSelected [0,9,11] rootPS < 2^1333 := by decide +kernel

def env500 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,587,3655,523,3694,34,2112,1646,101,3694,3172,32,1140,3692,3654,1060,1647,3188,1663,1647,1056,3663,1041,3663,3172,3183]

theorem envBound500 : H12AffineFastState.Bounded env500 := by
  intro p hp
  have h : env500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans499_500 : H12AffineEnvironment.transform 11 587 env499 = env500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env499 == env500) = true)

def env501 : List Nat := [2,4,8,16,32,64,9,116,512,20,2048,587,2643,523,2682,34,2112,634,101,2682,2160,32,96,2680,2642,48,635,2144,619,635,52,2651,5,2651,2160,2171]

theorem envBound501 : H12AffineFastState.Bounded env501 := by
  intro p hp
  have h : env501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans500_501 : H12AffineEnvironment.transform 9 20 env500 = env501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env500 == env501) = true)

theorem identity501 : scanCanonicalize (H12AffineFastState.compose env501 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 553) := by decide +kernel

theorem selectedBound501 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env502 : List Nat := [2,4,8,16,32,64,9,116,512,20,553,587,122,523,83,34,617,634,101,83,601,32,96,81,123,48,635,585,619,635,52,114,5,114,601,594]

theorem envBound502 : H12AffineFastState.Bounded env502 := by
  intro p hp
  have h : env502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans501_502 : H12AffineEnvironment.transform 10 553 env501 = env502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 553 env501 == env502) = true)

theorem identity502 : scanCanonicalize (H12AffineFastState.compose env502 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound502 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env503 : List Nat := [2,4,8,16,32,49,9,5,512,20,553,570,11,523,34,34,536,523,20,34,552,32,17,32,10,48,522,568,538,522,52,3,5,3,552,547]

theorem envBound503 : H12AffineFastState.Bounded env503 := by
  intro p hp
  have h : env503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans502_503 : H12AffineEnvironment.transform 5 49 env502 = env503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env502 == env503) = true)

def env504 : List Nat := [2,0,8,16,32,49,9,1,512,16,553,570,11,523,34,34,536,523,16,34,552,32,17,32,10,48,522,568,538,522,48,3,1,3,552,547]

theorem envBound504 : H12AffineFastState.Bounded env504 := by
  intro p hp
  have h : env504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans503_504 : H12AffineEnvironment.transform 1 0 env503 = env504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env503 == env504) = true)

theorem identity504 : scanCanonicalize (H12AffineFastState.compose env504 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env505 : List Nat := [2,0,8,16,32,49,9,1,32,16,9,26,11,43,34,34,56,43,16,34,8,32,17,32,10,48,42,24,58,42,48,3,1,3,8,3]

theorem envBound505 : H12AffineFastState.Bounded env505 := by
  intro p hp
  have h : env505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans504_505 : H12AffineEnvironment.transform 8 32 env504 = env505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env504 == env505) = true)

def env506 : List Nat := [2,0,8,0,32,33,9,1,32,0,9,10,11,43,34,34,40,43,0,34,8,32,1,32,10,32,42,8,42,42,32,3,1,3,8,3]

theorem envBound506 : H12AffineFastState.Bounded env506 := by
  intro p hp
  have h : env506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans505_506 : H12AffineEnvironment.transform 3 0 env505 = env506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env505 == env506) = true)

theorem identity506 : scanCanonicalize (H12AffineFastState.compose env506 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env507 : List Nat := [2,0,8,0,2,3,9,1,2,0,9,10,11,9,0,0,10,9,0,0,8,2,1,2,10,2,8,8,8,8,2,3,1,3,8,3]

theorem envBound507 : H12AffineFastState.Bounded env507 := by
  intro p hp
  have h : env507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans506_507 : H12AffineEnvironment.transform 4 2 env506 = env507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env506 == env507) = true)

def leafEnv507 : List Nat := [2,0,8,0,2,3,9,1,2,0,9,10,11,9,0,0,10,9,0,0,8,2,1,2,2,10,1,2,8,8,8,8,2,3,1,3,0,0,8,3,1,9,0]

def active507 : List Nat := [0,2]

def tree507 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood507 : H12WitnessSearch.Good tree507 := H12GlobalWitnessIndex.good

theorem leafIdentity507 : H12AffineFastState.composeSystem env507 rootObs = leafEnv507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env507 rootObs == leafEnv507) = true)

theorem terminalChecked507 : H12PackedTerminal.terminalCheckFast leafEnv507 active507 tree507 = true := by decide +kernel

def env508 : List Nat := [2,0,8,1,32,32,9,1,32,1,9,11,11,43,34,34,41,43,1,34,8,32,0,32,10,33,42,9,43,42,33,3,1,3,8,3]

theorem envBound508 : H12AffineFastState.Bounded env508 := by
  intro p hp
  have h : env508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans505_508 : H12AffineEnvironment.transform 3 1 env505 = env508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env505 == env508) = true)

def env509 : List Nat := [2,0,8,1,8,8,9,1,8,1,9,11,11,3,10,10,1,3,1,10,8,8,0,8,10,9,2,9,3,2,9,3,1,3,8,3]

theorem envBound509 : H12AffineFastState.Bounded env509 := by
  intro p hp
  have h : env509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans508_509 : H12AffineEnvironment.transform 4 8 env508 = env509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env508 == env509) = true)

def env510 : List Nat := [2,0,0,1,0,0,1,1,0,1,1,3,3,3,2,2,1,3,1,2,0,0,0,0,2,1,2,1,3,2,1,3,1,3,0,3]

theorem envBound510 : H12AffineFastState.Bounded env510 := by
  intro p hp
  have h : env510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans509_510 : H12AffineEnvironment.transform 2 0 env509 = env510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env509 == env510) = true)

def leafEnv510 : List Nat := [2,0,0,1,0,0,1,1,0,1,1,3,3,3,2,2,1,3,1,2,0,0,0,0,1,2,1,1,2,1,3,2,1,3,1,3,0,0,0,3,1,1,0]

def active510 : List Nat := [0]

def tree510 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood510 : H12WitnessSearch.Good tree510 := H12GlobalWitnessIndex.good

theorem leafIdentity510 : H12AffineFastState.composeSystem env510 rootObs = leafEnv510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env510 rootObs == leafEnv510) = true)

theorem terminalChecked510 : H12PackedTerminal.terminalCheckFast leafEnv510 active510 tree510 = true := by decide +kernel

def env511 : List Nat := [2,0,1,1,1,1,0,1,1,1,0,2,2,3,3,3,1,3,1,3,1,1,0,1,3,0,2,0,3,2,0,3,1,3,1,3]

theorem envBound511 : H12AffineFastState.Bounded env511 := by
  intro p hp
  have h : env511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans509_511 : H12AffineEnvironment.transform 2 1 env509 = env511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env509 == env511) = true)

theorem identity511 : scanCanonicalize (H12AffineFastState.compose env511 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound511 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env512 : List Nat := [1,0,1,1,1,1,0,1,1,1,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,0]

theorem envBound512 : H12AffineFastState.Bounded env512 := by
  intro p hp
  have h : env512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans511_512 : H12AffineEnvironment.transform 0 1 env511 = env512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env511 == env512) = true)

def leafEnv512 : List Nat := [1,0,1,1,1,1,0,1,1,1,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,0,1,0,1,0,0,1,0,0,1,0,0,0,1,0,1,0,0]

def active512 : List Nat := []

def tree512 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood512 : H12WitnessSearch.Good tree512 := H12GlobalWitnessIndex.good

theorem leafIdentity512 : H12AffineFastState.composeSystem env512 rootObs = leafEnv512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env512 rootObs == leafEnv512) = true)

theorem terminalChecked512 : H12PackedTerminal.terminalCheckFast leafEnv512 active512 tree512 = true := by decide +kernel

def env513 : List Nat := [2,0,8,1,9,9,9,1,9,1,9,11,11,2,11,11,0,2,1,11,8,9,0,9,10,8,3,9,2,3,8,3,1,3,8,3]

theorem envBound513 : H12AffineFastState.Bounded env513 := by
  intro p hp
  have h : env513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans508_513 : H12AffineEnvironment.transform 4 9 env508 = env513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env508 == env513) = true)

theorem identity513 : scanCanonicalize (H12AffineFastState.compose env513 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound513 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env514 : List Nat := [2,0,3,1,2,2,2,1,2,1,2,0,0,2,0,0,0,2,1,0,3,2,0,2,1,3,3,2,2,3,3,3,1,3,3,3]

theorem envBound514 : H12AffineFastState.Bounded env514 := by
  intro p hp
  have h : env514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans513_514 : H12AffineEnvironment.transform 2 3 env513 = env514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env513 == env514) = true)

def leafEnv514 : List Nat := [2,0,3,1,2,2,2,1,2,1,2,0,0,2,0,0,0,2,1,0,3,2,0,2,3,1,1,3,3,2,2,3,3,3,1,3,0,0,3,3,1,2,0]

def active514 : List Nat := [0]

def tree514 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood514 : H12WitnessSearch.Good tree514 := H12GlobalWitnessIndex.good

theorem leafIdentity514 : H12AffineFastState.composeSystem env514 rootObs = leafEnv514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env514 rootObs == leafEnv514) = true)

theorem terminalChecked514 : H12PackedTerminal.terminalCheckFast leafEnv514 active514 tree514 = true := by decide +kernel

def env515 : List Nat := [2,1,8,16,32,49,9,0,512,17,553,570,11,523,34,34,536,523,17,34,552,32,17,32,10,48,522,568,538,522,49,3,0,3,552,547]

theorem envBound515 : H12AffineFastState.Bounded env515 := by
  intro p hp
  have h : env515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans503_515 : H12AffineEnvironment.transform 1 1 env503 = env515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env503 == env515) = true)

theorem identity515 : scanCanonicalize (H12AffineFastState.compose env515 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env516 : List Nat := [2,1,8,16,32,49,9,0,2,17,43,56,11,9,34,34,26,9,17,34,42,32,17,32,10,48,8,58,24,8,49,3,0,3,42,33]

theorem envBound516 : H12AffineFastState.Bounded env516 := by
  intro p hp
  have h : env516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans515_516 : H12AffineEnvironment.transform 8 2 env515 = env516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env515 == env516) = true)

def env517 : List Nat := [2,1,8,0,32,33,9,0,2,1,43,40,11,9,34,34,10,9,1,34,42,32,1,32,10,32,8,42,8,8,33,3,0,3,42,33]

theorem envBound517 : H12AffineFastState.Bounded env517 := by
  intro p hp
  have h : env517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans516_517 : H12AffineEnvironment.transform 3 0 env516 = env517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env516 == env517) = true)

theorem identity517 : scanCanonicalize (H12AffineFastState.compose env517 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env518 : List Nat := [2,1,8,0,2,3,9,0,2,1,9,10,11,9,0,0,10,9,1,0,8,2,1,2,10,2,8,8,8,8,3,3,0,3,8,3]

theorem envBound518 : H12AffineFastState.Bounded env518 := by
  intro p hp
  have h : env518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans517_518 : H12AffineEnvironment.transform 4 2 env517 = env518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env517 == env518) = true)

def leafEnv518 : List Nat := [2,1,8,0,2,3,9,0,2,1,9,10,11,9,0,0,10,9,1,0,8,2,1,2,3,10,1,2,8,8,8,8,3,3,0,3,1,0,8,3,1,9,0]

def active518 : List Nat := [0,2]

def tree518 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood518 : H12WitnessSearch.Good tree518 := H12GlobalWitnessIndex.good

theorem leafIdentity518 : H12AffineFastState.composeSystem env518 rootObs = leafEnv518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env518 rootObs == leafEnv518) = true)

theorem terminalChecked518 : H12PackedTerminal.terminalCheckFast leafEnv518 active518 tree518 = true := by decide +kernel

def env519 : List Nat := [2,1,8,1,32,32,9,0,2,0,43,41,11,9,34,34,11,9,0,34,42,32,0,32,10,33,8,43,9,8,32,3,0,3,42,33]

theorem envBound519 : H12AffineFastState.Bounded env519 := by
  intro p hp
  have h : env519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans516_519 : H12AffineEnvironment.transform 3 1 env516 = env519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env516 == env519) = true)

def env520 : List Nat := [2,1,8,1,8,8,9,0,2,0,3,1,11,9,10,10,11,9,0,10,2,8,0,8,10,9,8,3,9,8,8,3,0,3,2,9]

theorem envBound520 : H12AffineFastState.Bounded env520 := by
  intro p hp
  have h : env520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans519_520 : H12AffineEnvironment.transform 4 8 env519 = env520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env519 == env520) = true)

def env521 : List Nat := [2,1,0,1,0,0,1,0,2,0,3,1,3,1,2,2,3,1,0,2,2,0,0,0,2,1,0,3,1,0,0,3,0,3,2,1]

theorem envBound521 : H12AffineFastState.Bounded env521 := by
  intro p hp
  have h : env521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans520_521 : H12AffineEnvironment.transform 2 0 env520 = env521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env520 == env521) = true)

def leafEnv521 : List Nat := [2,1,0,1,0,0,1,0,2,0,3,1,3,1,2,2,3,1,0,2,2,0,0,0,0,2,1,1,0,3,1,0,0,3,0,3,1,0,2,1,1,3,0]

def active521 : List Nat := [0]

def tree521 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood521 : H12WitnessSearch.Good tree521 := H12GlobalWitnessIndex.good

theorem leafIdentity521 : H12AffineFastState.composeSystem env521 rootObs = leafEnv521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env521 rootObs == leafEnv521) = true)

theorem terminalChecked521 : H12PackedTerminal.terminalCheckFast leafEnv521 active521 tree521 = true := by decide +kernel

def env522 : List Nat := [2,1,1,1,1,1,0,0,2,0,3,1,2,0,3,3,2,0,0,3,2,1,0,1,3,0,1,3,0,1,1,3,0,3,2,0]

theorem envBound522 : H12AffineFastState.Bounded env522 := by
  intro p hp
  have h : env522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans520_522 : H12AffineEnvironment.transform 2 1 env520 = env522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env520 == env522) = true)

theorem identity522 : scanCanonicalize (H12AffineFastState.compose env522 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound522 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env523 : List Nat := [1,1,1,1,1,1,0,0,1,0,0,1,1,0,0,0,1,0,0,0,1,1,0,1,0,0,1,0,0,1,1,0,0,0,1,0]

theorem envBound523 : H12AffineFastState.Bounded env523 := by
  intro p hp
  have h : env523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans522_523 : H12AffineEnvironment.transform 0 1 env522 = env523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env522 == env523) = true)

def leafEnv523 : List Nat := [1,1,1,1,1,1,0,0,1,0,0,1,1,0,0,0,1,0,0,0,1,1,0,1,1,0,1,0,1,0,0,1,1,0,0,0,1,0,1,0,1,0,0]

def active523 : List Nat := []

def tree523 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood523 : H12WitnessSearch.Good tree523 := H12GlobalWitnessIndex.good

theorem leafIdentity523 : H12AffineFastState.composeSystem env523 rootObs = leafEnv523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env523 rootObs == leafEnv523) = true)

theorem terminalChecked523 : H12PackedTerminal.terminalCheckFast leafEnv523 active523 tree523 = true := by decide +kernel

def env524 : List Nat := [2,1,8,1,9,9,9,0,2,0,2,0,11,9,11,11,11,9,0,11,3,9,0,9,10,8,8,2,9,8,9,3,0,3,3,8]

theorem envBound524 : H12AffineFastState.Bounded env524 := by
  intro p hp
  have h : env524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans519_524 : H12AffineEnvironment.transform 4 9 env519 = env524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env519 == env524) = true)

theorem identity524 : scanCanonicalize (H12AffineFastState.compose env524 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound524 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env525 : List Nat := [2,1,3,1,2,2,2,0,2,0,2,0,0,2,0,0,0,2,0,0,3,2,0,2,1,3,3,2,2,3,2,3,0,3,3,3]

theorem envBound525 : H12AffineFastState.Bounded env525 := by
  intro p hp
  have h : env525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans524_525 : H12AffineEnvironment.transform 2 3 env524 = env525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env524 == env525) = true)

def leafEnv525 : List Nat := [2,1,3,1,2,2,2,0,2,0,2,0,0,2,0,0,0,2,0,0,3,2,0,2,2,1,1,3,3,2,2,3,2,3,0,3,1,0,3,3,1,2,0]

def active525 : List Nat := [0]

def tree525 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood525 : H12WitnessSearch.Good tree525 := H12GlobalWitnessIndex.good

theorem leafIdentity525 : H12AffineFastState.composeSystem env525 rootObs = leafEnv525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env525 rootObs == leafEnv525) = true)

theorem terminalChecked525 : H12PackedTerminal.terminalCheckFast leafEnv525 active525 tree525 = true := by decide +kernel

def env526 : List Nat := [2,4,8,16,32,64,9,116,512,21,2048,587,2642,523,2683,34,2112,635,101,2683,2161,32,97,2681,2643,49,634,2145,618,634,53,2650,4,2650,2161,2170]

theorem envBound526 : H12AffineFastState.Bounded env526 := by
  intro p hp
  have h : env526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans500_526 : H12AffineEnvironment.transform 9 21 env500 = env526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env500 == env526) = true)

theorem identity526 : scanCanonicalize (H12AffineFastState.compose env526 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env527 : List Nat := [2,4,8,16,2,64,9,86,512,21,2048,587,2642,523,2649,0,2112,601,71,2649,2131,2,67,2651,2643,19,600,2115,584,600,23,2650,4,2650,2131,2136]

theorem envBound527 : H12AffineFastState.Bounded env527 := by
  intro p hp
  have h : env527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans526_527 : H12AffineEnvironment.transform 4 2 env526 = env527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env526 == env527) = true)

theorem identity527 : scanCanonicalize (H12AffineFastState.compose env527 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound527 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env528 : List Nat := [2,4,8,16,2,64,9,86,512,21,522,587,88,523,83,0,586,601,71,83,601,2,67,81,89,19,600,585,584,600,23,80,4,80,601,594]

theorem envBound528 : H12AffineFastState.Bounded env528 := by
  intro p hp
  have h : env528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans527_528 : H12AffineEnvironment.transform 10 522 env527 = env528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env527 == env528) = true)

def env529 : List Nat := [2,4,8,16,2,20,9,2,512,21,522,543,12,523,7,0,542,525,19,7,525,2,23,5,13,19,524,541,540,524,23,4,4,4,525,518]

theorem envBound529 : H12AffineFastState.Bounded env529 := by
  intro p hp
  have h : env529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans528_529 : H12AffineEnvironment.transform 5 20 env528 = env529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env528 == env529) = true)

theorem identity529 : scanCanonicalize (H12AffineFastState.compose env529 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env530 : List Nat := [2,4,8,16,2,20,9,2,2,21,8,29,12,9,7,0,28,15,19,7,15,2,23,5,13,19,14,31,30,14,23,4,4,4,15,4]

theorem envBound530 : H12AffineFastState.Bounded env530 := by
  intro p hp
  have h : env530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans529_530 : H12AffineEnvironment.transform 8 2 env529 = env530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env529 == env530) = true)

def env531 : List Nat := [2,4,8,0,2,4,9,2,2,5,8,13,12,9,7,0,12,15,3,7,15,2,7,5,13,3,14,15,14,14,7,4,4,4,15,4]

theorem envBound531 : H12AffineFastState.Bounded env531 := by
  intro p hp
  have h : env531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans530_531 : H12AffineEnvironment.transform 3 0 env530 = env531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env530 == env531) = true)

def env532 : List Nat := [2,4,4,0,2,4,5,2,2,5,4,1,0,5,7,0,0,3,3,7,3,2,7,5,1,3,2,3,2,2,7,4,4,4,3,4]

theorem envBound532 : H12AffineFastState.Bounded env532 := by
  intro p hp
  have h : env532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans531_532 : H12AffineEnvironment.transform 2 4 env531 = env532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env531 == env532) = true)

def env533 : List Nat := [2,0,0,0,2,0,1,2,2,1,0,1,0,1,3,0,0,3,3,3,3,2,3,1,1,3,2,3,2,2,3,0,0,0,3,0]

theorem envBound533 : H12AffineFastState.Bounded env533 := by
  intro p hp
  have h : env533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans532_533 : H12AffineEnvironment.transform 1 0 env532 = env533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env532 == env533) = true)

theorem identity533 : scanCanonicalize (H12AffineFastState.compose env533 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound533 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env534 : List Nat := [1,0,0,0,1,0,1,1,1,1,0,1,0,1,0,0,0,0,0,0,0,1,0,1,1,0,1,0,1,1,0,0,0,0,0,0]

theorem envBound534 : H12AffineFastState.Bounded env534 := by
  intro p hp
  have h : env534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans533_534 : H12AffineEnvironment.transform 0 1 env533 = env534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env533 == env534) = true)

def leafEnv534 : List Nat := [1,0,0,0,1,0,1,1,1,1,0,1,0,1,0,0,0,0,0,0,0,1,0,1,1,1,1,0,1,0,1,1,0,0,0,0,1,0,0,0,1,1,0]

def active534 : List Nat := []

def tree534 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood534 : H12WitnessSearch.Good tree534 := H12GlobalWitnessIndex.good

theorem leafIdentity534 : H12AffineFastState.composeSystem env534 rootObs = leafEnv534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env534 rootObs == leafEnv534) = true)

theorem terminalChecked534 : H12PackedTerminal.terminalCheckFast leafEnv534 active534 tree534 = true := by decide +kernel

def env535 : List Nat := [2,1,1,0,2,1,0,2,2,0,1,1,0,0,2,0,0,3,3,2,3,2,2,0,1,3,2,3,2,2,2,1,1,1,3,1]

theorem envBound535 : H12AffineFastState.Bounded env535 := by
  intro p hp
  have h : env535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans532_535 : H12AffineEnvironment.transform 1 1 env532 = env535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env532 == env535) = true)

def leafEnv535 : List Nat := [2,1,1,0,2,1,0,2,2,0,1,1,0,0,2,0,0,3,3,2,3,2,2,0,1,1,1,3,2,3,2,2,2,1,1,1,2,2,3,1,1,2,0]

def active535 : List Nat := [0]

def tree535 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood535 : H12WitnessSearch.Good tree535 := H12GlobalWitnessIndex.good

theorem leafIdentity535 : H12AffineFastState.composeSystem env535 rootObs = leafEnv535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env535 rootObs == leafEnv535) = true)

theorem terminalChecked535 : H12PackedTerminal.terminalCheckFast leafEnv535 active535 tree535 = true := by decide +kernel

def env536 : List Nat := [2,4,5,0,2,4,4,2,2,5,5,0,1,4,7,0,1,2,3,7,2,2,7,5,0,3,3,2,3,3,7,4,4,4,2,4]

theorem envBound536 : H12AffineFastState.Bounded env536 := by
  intro p hp
  have h : env536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans531_536 : H12AffineEnvironment.transform 2 5 env531 = env536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env531 == env536) = true)

theorem identity536 : scanCanonicalize (H12AffineFastState.compose env536 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env537 : List Nat := [2,3,2,0,2,3,3,2,2,2,2,0,1,3,0,0,1,2,3,0,2,2,0,2,0,3,3,2,3,3,0,3,3,3,2,3]

theorem envBound537 : H12AffineFastState.Bounded env537 := by
  intro p hp
  have h : env537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans536_537 : H12AffineEnvironment.transform 1 3 env536 = env537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env536 == env537) = true)

def leafEnv537 : List Nat := [2,3,2,0,2,3,3,2,2,2,2,0,1,3,0,0,1,2,3,0,2,2,0,2,1,0,1,3,3,2,3,3,0,3,3,3,2,0,2,3,1,3,0]

def active537 : List Nat := [0]

def tree537 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood537 : H12WitnessSearch.Good tree537 := H12GlobalWitnessIndex.good

theorem leafIdentity537 : H12AffineFastState.composeSystem env537 rootObs = leafEnv537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env537 rootObs == leafEnv537) = true)

theorem terminalChecked537 : H12PackedTerminal.terminalCheckFast leafEnv537 active537 tree537 = true := by decide +kernel

def env538 : List Nat := [2,4,8,1,2,5,9,2,2,4,8,12,12,9,7,0,13,15,2,7,15,2,6,5,13,2,14,14,15,14,6,4,4,4,15,4]

theorem envBound538 : H12AffineFastState.Bounded env538 := by
  intro p hp
  have h : env538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans530_538 : H12AffineEnvironment.transform 3 1 env530 = env538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env530 == env538) = true)

theorem identity538 : scanCanonicalize (H12AffineFastState.compose env538 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound538 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env539 : List Nat := [2,3,8,1,2,2,9,2,2,3,8,11,11,9,0,0,10,8,2,0,8,2,1,2,10,2,9,9,8,9,1,3,3,3,8,3]

theorem envBound539 : H12AffineFastState.Bounded env539 := by
  intro p hp
  have h : env539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans538_539 : H12AffineEnvironment.transform 1 3 env538 = env539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env538 == env539) = true)

def leafEnv539 : List Nat := [2,3,8,1,2,2,9,2,2,3,8,11,11,9,0,0,10,8,2,0,8,2,1,2,0,10,1,2,9,9,8,9,1,3,3,3,2,0,8,3,1,9,0]

def active539 : List Nat := [0,2]

def tree539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood539 : H12WitnessSearch.Good tree539 := H12GlobalWitnessIndex.good

theorem leafIdentity539 : H12AffineFastState.composeSystem env539 rootObs = leafEnv539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env539 rootObs == leafEnv539) = true)

theorem terminalChecked539 : H12PackedTerminal.terminalCheckFast leafEnv539 active539 tree539 = true := by decide +kernel

def env540 : List Nat := [2,4,8,16,2,21,9,3,512,21,522,542,13,523,6,0,543,524,18,6,524,2,22,4,12,19,525,540,541,525,23,5,4,5,524,519]

theorem envBound540 : H12AffineFastState.Bounded env540 := by
  intro p hp
  have h : env540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans528_540 : H12AffineEnvironment.transform 5 21 env528 = env540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env528 == env540) = true)

theorem identity540 : scanCanonicalize (H12AffineFastState.compose env540 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env541 : List Nat := [2,4,8,16,2,21,9,3,4,21,14,26,13,15,6,0,27,8,18,6,8,2,22,4,12,19,9,24,25,9,23,5,4,5,8,3]

theorem envBound541 : H12AffineFastState.Bounded env541 := by
  intro p hp
  have h : env541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans540_541 : H12AffineEnvironment.transform 8 4 env540 = env541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env540 == env541) = true)

def env542 : List Nat := [2,4,8,0,2,5,9,3,4,5,14,10,13,15,6,0,11,8,2,6,8,2,6,4,12,3,9,8,9,9,7,5,4,5,8,3]

theorem envBound542 : H12AffineFastState.Bounded env542 := by
  intro p hp
  have h : env542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans541_542 : H12AffineEnvironment.transform 3 0 env541 = env542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env541 == env542) = true)

def env543 : List Nat := [2,4,4,0,2,5,5,3,4,5,2,6,1,3,6,0,7,4,2,6,4,2,6,4,0,3,5,4,5,5,7,5,4,5,4,3]

theorem envBound543 : H12AffineFastState.Bounded env543 := by
  intro p hp
  have h : env543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans542_543 : H12AffineEnvironment.transform 2 4 env542 = env543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env542 == env543) = true)

theorem identity543 : scanCanonicalize (H12AffineFastState.compose env543 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound543 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env544 : List Nat := [2,2,2,0,2,3,3,3,2,3,2,0,1,3,0,0,1,2,2,0,2,2,0,2,0,3,3,2,3,3,1,3,2,3,2,3]

theorem envBound544 : H12AffineFastState.Bounded env544 := by
  intro p hp
  have h : env544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans543_544 : H12AffineEnvironment.transform 1 2 env543 = env544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env543 == env544) = true)

def leafEnv544 : List Nat := [2,2,2,0,2,3,3,3,2,3,2,0,1,3,0,0,1,2,2,0,2,2,0,2,0,0,1,3,3,2,3,3,1,3,2,3,3,0,2,3,1,3,0]

def active544 : List Nat := [0]

def tree544 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood544 : H12WitnessSearch.Good tree544 := H12GlobalWitnessIndex.good

theorem leafIdentity544 : H12AffineFastState.composeSystem env544 rootObs = leafEnv544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env544 rootObs == leafEnv544) = true)

theorem terminalChecked544 : H12PackedTerminal.terminalCheckFast leafEnv544 active544 tree544 = true := by decide +kernel

def env545 : List Nat := [2,4,5,0,2,5,4,3,4,5,3,7,0,2,6,0,6,5,2,6,5,2,6,4,1,3,4,5,4,4,7,5,4,5,5,3]

theorem envBound545 : H12AffineFastState.Bounded env545 := by
  intro p hp
  have h : env545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans542_545 : H12AffineEnvironment.transform 2 5 env542 = env545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env542 == env545) = true)

def env546 : List Nat := [2,0,1,0,2,1,0,3,0,1,3,3,0,2,2,0,2,1,2,2,1,2,2,0,1,3,0,1,0,0,3,1,0,1,1,3]

theorem envBound546 : H12AffineFastState.Bounded env546 := by
  intro p hp
  have h : env546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans545_546 : H12AffineEnvironment.transform 1 0 env545 = env546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env545 == env546) = true)

def leafEnv546 : List Nat := [2,0,1,0,2,1,0,3,0,1,3,3,0,2,2,0,2,1,2,2,1,2,2,0,0,1,1,3,0,1,0,0,3,1,0,1,3,2,1,3,1,0,0]

def active546 : List Nat := [0]

def tree546 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood546 : H12WitnessSearch.Good tree546 := H12GlobalWitnessIndex.good

theorem leafIdentity546 : H12AffineFastState.composeSystem env546 rootObs = leafEnv546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env546 rootObs == leafEnv546) = true)

theorem terminalChecked546 : H12PackedTerminal.terminalCheckFast leafEnv546 active546 tree546 = true := by decide +kernel

def env547 : List Nat := [2,1,0,0,2,0,1,3,1,0,3,2,0,2,3,0,3,0,2,3,0,2,3,1,1,3,1,0,1,1,2,0,1,0,0,3]

theorem envBound547 : H12AffineFastState.Bounded env547 := by
  intro p hp
  have h : env547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans545_547 : H12AffineEnvironment.transform 1 1 env545 = env547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env545 == env547) = true)

theorem identity547 : scanCanonicalize (H12AffineFastState.compose env547 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound547 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env548 : List Nat := [1,1,0,0,1,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,1,1,0,1,0,1,1,1,0,1,0,0,0]

theorem envBound548 : H12AffineFastState.Bounded env548 := by
  intro p hp
  have h : env548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans547_548 : H12AffineEnvironment.transform 0 1 env547 = env548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env547 == env548) = true)

def leafEnv548 : List Nat := [1,1,0,0,1,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,1,0,1,1,0,1,0,1,1,1,0,1,0,0,0,0,0,1,1,0]

def active548 : List Nat := []

def tree548 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood548 : H12WitnessSearch.Good tree548 := H12GlobalWitnessIndex.good

theorem leafIdentity548 : H12AffineFastState.composeSystem env548 rootObs = leafEnv548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env548 rootObs == leafEnv548) = true)

theorem terminalChecked548 : H12PackedTerminal.terminalCheckFast leafEnv548 active548 tree548 = true := by decide +kernel

def env549 : List Nat := [2,4,8,1,2,4,9,3,4,4,14,11,13,15,6,0,10,8,3,6,8,2,7,4,12,2,9,9,8,9,6,5,4,5,8,3]

theorem envBound549 : H12AffineFastState.Bounded env549 := by
  intro p hp
  have h : env549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans541_549 : H12AffineEnvironment.transform 3 1 env541 = env549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env541 == env549) = true)

theorem identity549 : scanCanonicalize (H12AffineFastState.compose env549 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound549 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env550 : List Nat := [2,2,8,1,2,2,9,3,2,2,8,11,11,9,0,0,10,8,3,0,8,2,1,2,10,2,9,9,8,9,0,3,2,3,8,3]

theorem envBound550 : H12AffineFastState.Bounded env550 := by
  intro p hp
  have h : env550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans549_550 : H12AffineEnvironment.transform 1 2 env549 = env550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env549 == env550) = true)

def leafEnv550 : List Nat := [2,2,8,1,2,2,9,3,2,2,8,11,11,9,0,0,10,8,3,0,8,2,1,2,1,10,1,2,9,9,8,9,0,3,2,3,3,0,8,3,1,9,0]

def active550 : List Nat := [0,2]

def tree550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood550 : H12WitnessSearch.Good tree550 := H12GlobalWitnessIndex.good

theorem leafIdentity550 : H12AffineFastState.composeSystem env550 rootObs = leafEnv550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env550 rootObs == leafEnv550) = true)

theorem terminalChecked550 : H12PackedTerminal.terminalCheckFast leafEnv550 active550 tree550 = true := by decide +kernel

def env551 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,65536,2113,5293,236,8352,3173,32,1277,73737,8328,1197,5157,3324,5309,75786,1193,73770,1041,73770,3308,74371]

theorem envBound551 : H12AffineFastState.Bounded env551 := by
  intro p hp
  have h : env551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans481_551 : H12AffineEnvironment.transform 16 2113 env481 = env551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env481 == env551) = true)

theorem identity551 : scanCanonicalize (H12AffineFastState.compose env551 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound551 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env552 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,8322,2113,5293,236,8352,3173,32,1277,139,8328,1197,5157,3324,5309,2184,1193,168,1041,168,3308,513]

theorem envBound552 : H12AffineFastState.Bounded env552 := by
  intro p hp
  have h : env552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans551_552 : H12AffineEnvironment.transform 15 8322 env551 = env552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env551 == env552) = true)

theorem identity552 : scanCanonicalize (H12AffineFastState.compose env552 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound552 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env553 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,4297,1,35,2113,5293,236,1,3173,32,1277,139,41,1197,5157,3324,5309,2184,1193,168,1041,168,3308,513]

theorem envBound553 : H12AffineFastState.Bounded env553 := by
  intro p hp
  have h : env553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans552_553 : H12AffineEnvironment.transform 12 161 env552 = env553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env552 == env553) = true)

theorem identity553 : scanCanonicalize (H12AffineFastState.compose env553 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound553 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env554 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,4281,1,35,2097,5293,156,1,3093,32,1165,139,41,1197,5157,3212,5309,2184,1193,168,1041,168,3228,513]

theorem envBound554 : H12AffineFastState.Bounded env554 := by
  intro p hp
  have h : env554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans553_554 : H12AffineEnvironment.transform 5 48 env553 = env554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env553 == env554) = true)

theorem identity554 : scanCanonicalize (H12AffineFastState.compose env554 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound554 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env555 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3108,161,3229,1,35,2097,2185,156,1,3093,32,1165,139,41,1197,2049,3212,2201,2184,1193,168,1041,168,3228,513]

theorem envBound555 : H12AffineFastState.Bounded env555 := by
  intro p hp
  have h : env555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans554_555 : H12AffineEnvironment.transform 11 3108 env554 = env555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env554 == env555) = true)

theorem identity555 : scanCanonicalize (H12AffineFastState.compose env555 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound555 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env556 : List Nat := [2,4,8,16,32,48,128,141,512,1024,1566,570,161,643,1,35,1583,1687,156,1,523,32,1165,139,41,1197,1567,658,1671,1686,1193,168,1041,168,642,513]

theorem envBound556 : H12AffineFastState.Bounded env556 := by
  intro p hp
  have h : env556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans555_556 : H12AffineEnvironment.transform 10 1566 env555 = env556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env555 == env556) = true)

theorem identity556 : scanCanonicalize (H12AffineFastState.compose env556 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env557 : List Nat := [2,4,8,16,32,48,128,141,168,1024,1206,146,161,43,1,35,1159,1087,156,1,163,32,1165,139,41,1197,1207,58,1071,1086,1193,168,1041,168,42,169]

theorem envBound557 : H12AffineFastState.Bounded env557 := by
  intro p hp
  have h : env557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans556_557 : H12AffineEnvironment.transform 8 168 env556 = env557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env556 == env557) = true)

def env558 : List Nat := [2,4,8,16,0,16,128,141,136,1024,1174,146,129,11,1,3,1159,1055,156,1,131,0,1165,139,9,1165,1175,26,1039,1054,1161,136,1041,136,10,137]

theorem envBound558 : H12AffineFastState.Bounded env558 := by
  intro p hp
  have h : env558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans557_558 : H12AffineEnvironment.transform 4 0 env557 = env558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env557 == env558) = true)

theorem identity558 : scanCanonicalize (H12AffineFastState.compose env558 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 22) := by decide +kernel

theorem selectedBound558 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env559 : List Nat := [2,4,8,16,0,16,128,141,136,22,128,146,129,11,1,3,145,9,156,1,131,0,155,139,9,155,129,26,25,8,159,136,7,136,10,137]

theorem envBound559 : H12AffineFastState.Bounded env559 := by
  intro p hp
  have h : env559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans558_559 : H12AffineEnvironment.transform 9 22 env558 = env559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 22 env558 == env559) = true)

def leafEnv559 : List Nat := [2,4,8,16,0,16,128,141,136,22,128,146,129,11,1,3,145,9,156,1,131,0,155,139,21,9,1,155,129,26,25,8,159,136,7,136,142,138,10,137,1,130,0]

def active559 : List Nat := [0,1,2,3,6]

def tree559 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood559 : H12WitnessSearch.Good tree559 := H12GlobalWitnessIndex.good

theorem leafIdentity559 : H12AffineFastState.composeSystem env559 rootObs = leafEnv559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env559 rootObs == leafEnv559) = true)

theorem terminalChecked559 : H12PackedTerminal.terminalCheckFast leafEnv559 active559 tree559 = true := by decide +kernel

def env560 : List Nat := [2,4,8,16,1,17,128,141,137,1024,1175,146,128,10,1,2,1159,1054,156,1,130,1,1165,139,8,1164,1174,27,1038,1055,1160,137,1041,137,11,136]

theorem envBound560 : H12AffineFastState.Bounded env560 := by
  intro p hp
  have h : env560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans557_560 : H12AffineEnvironment.transform 4 1 env557 = env560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env557 == env560) = true)

theorem identity560 : scanCanonicalize (H12AffineFastState.compose env560 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 158) := by decide +kernel

theorem selectedBound560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env561 : List Nat := [2,4,8,16,1,17,128,141,137,158,9,146,128,10,1,2,25,128,156,1,130,1,19,139,8,18,8,27,144,129,22,137,143,137,11,136]

theorem envBound561 : H12AffineFastState.Bounded env561 := by
  intro p hp
  have h : env561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans560_561 : H12AffineEnvironment.transform 9 158 env560 = env561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 158 env560 == env561) = true)

def leafEnv561 : List Nat := [2,4,8,16,1,17,128,141,137,158,9,146,128,10,1,2,25,128,156,1,130,1,19,139,20,8,1,18,8,27,144,129,22,137,143,137,6,139,11,136,1,131,0]

def active561 : List Nat := [0,1,2,3,6]

def tree561 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood561 : H12WitnessSearch.Good tree561 := H12GlobalWitnessIndex.good

theorem leafIdentity561 : H12AffineFastState.composeSystem env561 rootObs = leafEnv561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env561 rootObs == leafEnv561) = true)

theorem terminalChecked561 : H12PackedTerminal.terminalCheckFast leafEnv561 active561 tree561 = true := by decide +kernel

def env562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,33,8388608,8988133,8328,525377,262280,11031617,11158593,8990183,1364,73770,525568,8988103,34359738368,74371]

theorem envBound562 : H12AffineFastState.Bounded env562 := by
  intro p hp
  have h : env562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans255_562 : H12AffineEnvironment.transform 21 33 env255 = env562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env255 == env562) = true)

theorem identity562 : scanCanonicalize (H12AffineFastState.compose env562 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound562 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8575,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525377,262280,11031617,11158593,8916120,1364,341,525568,8914104,34359738368,1020]

theorem envBound563 : H12AffineFastState.Bounded env563 := by
  intro p hp
  have h : env563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans562_563 : H12AffineEnvironment.transform 15 8575 env562 = env563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env562 == env563) = true)

theorem identity563 : scanCanonicalize (H12AffineFastState.compose env563 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound563 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env564 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525377,262280,11031617,11158593,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound564 : H12AffineFastState.Bounded env564 := by
  intro p hp
  have h : env564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans563_564 : H12AffineEnvironment.transform 7 252 env563 = env564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env563 == env564) = true)

theorem identity564 : scanCanonicalize (H12AffineFastState.compose env564 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound564 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env565 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,17596,33,8388608,8914074,8328,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound565 : H12AffineFastState.Bounded env565 := by
  intro p hp
  have h : env565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans564_565 : H12AffineEnvironment.transform 20 17596 env564 = env565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env564 == env565) = true)

theorem identity565 : scanCanonicalize (H12AffineFastState.compose env565 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 940084) := by decide +kernel

theorem selectedBound565 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env566 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,17596,33,8388608,8914074,8328,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,940084,512]

theorem envBound566 : H12AffineFastState.Bounded env566 := by
  intro p hp
  have h : env566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans565_566 : H12AffineEnvironment.transform 34 940084 env565 = env566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 940084 env565 == env566) = true)

theorem identity566 : scanCanonicalize (H12AffineFastState.compose env566 (packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound566 : packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env567 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,131072,262144,524288,0,17596,33,8388608,8914074,40,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,940084,512]

theorem envBound567 : H12AffineFastState.Bounded env567 := by
  intro p hp
  have h : env567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans566_567 : H12AffineEnvironment.transform 12 160 env566 = env567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env566 == env567) = true)

theorem identity567 : scanCanonicalize (H12AffineFastState.compose env567 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound567 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env568 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5356,262144,524288,0,17596,33,8388608,8914074,40,525377,262280,8917245,8918033,8916120,1192,169,525564,8914104,806104,512]

theorem envBound568 : H12AffineFastState.Bounded env568 := by
  intro p hp
  have h : env568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans567_568 : H12AffineEnvironment.transform 16 5356 env567 = env568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env567 == env568) = true)

theorem identity568 : scanCanonicalize (H12AffineFastState.compose env568 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 789657) := by decide +kernel

theorem selectedBound568 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env569 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5356,262144,524288,0,17596,33,789657,264195,40,525377,262280,269412,268424,262145,1192,169,525564,264225,806104,512]

theorem envBound569 : H12AffineFastState.Bounded env569 := by
  intro p hp
  have h : env569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans568_569 : H12AffineEnvironment.transform 22 789657 env568 = env569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 789657 env568 == env569) = true)

theorem identity569 : scanCanonicalize (H12AffineFastState.compose env569 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound569 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env570 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5356,2185,524288,0,17596,33,525328,138,40,525377,2049,5357,4097,2184,1192,169,525564,168,541777,512]

theorem envBound570 : H12AffineFastState.Bounded env570 := by
  intro p hp
  have h : env570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans569_570 : H12AffineEnvironment.transform 17 2185 env569 = env570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env569 == env570) = true)

theorem identity570 : scanCanonicalize (H12AffineFastState.compose env570 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound570 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env571 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,9,16384,0,35,5189,2080,524288,0,17429,33,525328,35,40,525377,2049,5188,4097,2081,1025,0,525397,1,541777,512]

theorem envBound571 : H12AffineFastState.Bounded env571 := by
  intro p hp
  have h : env571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans570_571 : H12AffineEnvironment.transform 6 41 env570 = env571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env570 == env571) = true)

def env572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988133,8328,525376,262280,11031616,11158592,13184455,1364,73770,525568,13182439,34359738368,74370]

theorem envBound572 : H12AffineFastState.Bounded env572 := by
  intro p hp
  have h : env572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans254_572 : H12AffineEnvironment.transform 14 8353 env254 = env572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env254 == env572) = true)

theorem identity572 : scanCanonicalize (H12AffineFastState.compose env572 (packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound572 : packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,476,8388608,8988133,8328,525376,262280,11031616,11158592,8989723,1364,73770,525568,8987707,34359738368,74370]

theorem envBound573 : H12AffineFastState.Bounded env573 := by
  intro p hp
  have h : env573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans572_573 : H12AffineEnvironment.transform 21 476 env572 = env573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env572 == env573) = true)

def env574 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,8388608,8987673,8328,525376,262280,11031616,11158592,8989723,1192,73770,525564,8987707,34359738368,74370]

theorem envBound574 : H12AffineFastState.Bounded env574 := by
  intro p hp
  have h : env574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans573_574 : H12AffineEnvironment.transform 7 252 env573 = env574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env573 == env574) = true)

theorem identity574 : scanCanonicalize (H12AffineFastState.compose env574 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound574 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env575 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,131072,262144,524288,8353,2097152,32,8388608,8914075,8328,525376,262280,11031616,11158592,8916121,1192,168,525564,8914105,34359738368,512]

theorem envBound575 : H12AffineFastState.Bounded env575 := by
  intro p hp
  have h : env575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans574_575 : H12AffineEnvironment.transform 15 8322 env574 = env575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env574 == env575) = true)

theorem identity575 : scanCanonicalize (H12AffineFastState.compose env575 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound575 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env576 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,131072,262144,524288,8353,17596,32,8388608,8914075,8328,525376,262280,8917244,9044220,8916121,1192,168,525564,8914105,34359738368,512]

theorem envBound576 : H12AffineFastState.Bounded env576 := by
  intro p hp
  have h : env576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans575_576 : H12AffineEnvironment.transform 20 17596 env575 = env576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env575 == env576) = true)

theorem identity576 : scanCanonicalize (H12AffineFastState.compose env576 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 9072732) := by decide +kernel

theorem selectedBound576 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env577 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,131072,262144,524288,8353,17596,32,8388608,8914075,8328,525376,262280,8917244,9044220,8916121,1192,168,525564,8914105,9072732,512]

theorem envBound577 : H12AffineFastState.Bounded env577 := by
  intro p hp
  have h : env577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans576_577 : H12AffineEnvironment.transform 34 9072732 env576 = env577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 9072732 env576 == env577) = true)

def env578 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,33,8388608,8987672,8328,525376,262280,11031616,11158592,8989723,1193,73770,525565,8987707,34359738368,74370]

theorem envBound578 : H12AffineFastState.Bounded env578 := by
  intro p hp
  have h : env578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans573_578 : H12AffineEnvironment.transform 7 253 env573 = env578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env573 == env578) = true)

def env579 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,16384,113,65536,131072,262144,524288,113,2097152,33,8388608,8979656,88,525376,262280,11031616,11158592,8981707,1193,65786,525565,8979691,34359738368,66130]

theorem envBound579 : H12AffineFastState.Bounded env579 := by
  intro p hp
  have h : env579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans578_579 : H12AffineEnvironment.transform 12 208 env578 = env579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env578 == env579) = true)

theorem identity579 : scanCanonicalize (H12AffineFastState.compose env579 (packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 725215) := by decide +kernel

theorem selectedBound579 : packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env580 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,16384,113,65536,131072,262144,524288,113,2097152,33,725215,136215,88,525376,262280,2311327,2184351,138260,1193,65786,525565,136244,34359738368,66130]

theorem envBound580 : H12AffineFastState.Bounded env580 := by
  intro p hp
  have h : env580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans579_580 : H12AffineEnvironment.transform 22 725215 env579 = env580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 725215 env579 == env580) = true)

def env581 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,2097152,33,725167,136215,40,525360,262280,2311327,2184351,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound581 : H12AffineFastState.Bounded env581 := by
  intro p hp
  have h : env581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans580_581 : H12AffineEnvironment.transform 5 48 env580 = env581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env580 == env581) = true)

def env582 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound582 : H12AffineFastState.Bounded env582 := by
  intro p hp
  have h : env582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans581_582 : H12AffineEnvironment.transform 20 268336 env581 = env582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268336 env581 == env582) = true)

def env583 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,656568,66082]

theorem envBound583 : H12AffineFastState.Bounded env583 := by
  intro p hp
  have h : env583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans582_583 : H12AffineEnvironment.transform 34 656568 env582 = env583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656568 env582 == env583) = true)

theorem identity583 : scanCanonicalize (H12AffineFastState.compose env583 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound583 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env584 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,67754,524288,1,69786,33,725167,136215,40,525360,67618,152581,17413,138260,1193,65674,525453,136244,656568,66082]

theorem envBound584 : H12AffineFastState.Bounded env584 := by
  intro p hp
  have h : env584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans583_584 : H12AffineEnvironment.transform 17 67754 env583 = env584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env583 == env584) = true)

theorem identity584 : scanCanonicalize (H12AffineFastState.compose env584 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound584 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env585 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,5277,67754,524288,1,69786,33,590898,138,40,525360,67618,16536,17413,2185,1193,65674,525453,169,528421,66082]

theorem envBound585 : H12AffineFastState.Bounded env585 := by
  intro p hp
  have h : env585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans584_585 : H12AffineEnvironment.transform 16 5277 env584 = env585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env584 == env585) = true)

theorem identity585 : scanCanonicalize (H12AffineFastState.compose env585 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound585 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env586 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3245,160,16384,1,65536,2096,67754,524288,1,68663,33,590898,138,40,525360,67618,16536,17413,2185,1193,65674,525453,169,527496,66082]

theorem envBound586 : H12AffineFastState.Bounded env586 := by
  intro p hp
  have h : env586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans585_586 : H12AffineEnvironment.transform 11 3245 env585 = env586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env585 == env586) = true)

theorem identity586 : scanCanonicalize (H12AffineFastState.compose env586 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound586 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env587 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3245,160,16384,1,35,2096,2185,524288,1,3092,33,525329,138,40,525360,2049,16536,17413,2185,1193,169,525453,169,527496,513]

theorem envBound587 : H12AffineFastState.Bounded env587 := by
  intro p hp
  have h : env587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans586_587 : H12AffineEnvironment.transform 15 35 env586 = env587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env586 == env587) = true)

theorem identity587 : scanCanonicalize (H12AffineFastState.compose env587 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound587 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env588 : List Nat := [2,4,8,16,32,48,128,141,512,1024,1,1196,160,16384,1,35,49,136,524288,1,1045,33,525329,138,40,525360,0,16536,17413,136,1193,169,525453,169,525449,513]

theorem envBound588 : H12AffineFastState.Bounded env588 := by
  intro p hp
  have h : env588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans587_588 : H12AffineEnvironment.transform 10 1 env587 = env588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env587 == env588) = true)

def env589 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,656569,66082]

theorem envBound589 : H12AffineFastState.Bounded env589 := by
  intro p hp
  have h : env589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans582_589 : H12AffineEnvironment.transform 34 656569 env582 = env589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656569 env582 == env589) = true)

theorem identity589 : scanCanonicalize (H12AffineFastState.compose env589 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 203830) := by decide +kernel

theorem selectedBound589 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env590 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,203830,524288,1,197638,33,725167,136215,40,525360,203966,16537,151705,138260,1193,65674,525453,136244,656569,66082]

theorem envBound590 : H12AffineFastState.Bounded env590 := by
  intro p hp
  have h : env590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans589_590 : H12AffineEnvironment.transform 17 203830 env589 = env590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 203830 env589 == env590) = true)

theorem identity590 : scanCanonicalize (H12AffineFastState.compose env590 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound590 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env591 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,5277,67755,524288,1,69787,33,590898,138,40,525360,67619,16537,17412,2185,1193,65674,525453,169,528420,66082]

theorem envBound591 : H12AffineFastState.Bounded env591 := by
  intro p hp
  have h : env591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans590_591 : H12AffineEnvironment.transform 16 5277 env590 = env591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env590 == env591) = true)

theorem identity591 : scanCanonicalize (H12AffineFastState.compose env591 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 19646) := by decide +kernel

theorem selectedBound591 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env592 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,19646,5277,17429,524288,1,23589,33,542860,138,40,525360,17565,16537,17412,2185,1193,19508,525453,169,528420,20124]

theorem envBound592 : H12AffineFastState.Bounded env592 := by
  intro p hp
  have h : env592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans591_592 : H12AffineEnvironment.transform 15 19646 env591 = env592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19646 env591 == env592) = true)

theorem identity592 : scanCanonicalize (H12AffineFastState.compose env592 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 3229) := by decide +kernel

theorem selectedBound592 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env593 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,3229,1,35,5277,2184,524288,1,4280,33,525329,138,40,525360,2048,3076,2201,2185,1193,169,525453,169,528420,513]

theorem envBound593 : H12AffineFastState.Bounded env593 := by
  intro p hp
  have h : env593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans592_593 : H12AffineEnvironment.transform 13 3229 env592 = env593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3229 env592 == env593) = true)

theorem identity593 : scanCanonicalize (H12AffineFastState.compose env593 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound593 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env594 : List Nat := [2,4,8,16,32,48,128,141,512,1024,136,4096,160,1045,1,35,5277,0,524288,1,4280,33,525329,138,40,525360,136,1164,17,1,1193,169,525453,169,528420,513]

theorem envBound594 : H12AffineFastState.Bounded env594 := by
  intro p hp
  have h : env594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans593_594 : H12AffineEnvironment.transform 10 136 env593 = env594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env593 == env594) = true)

theorem identity594 : scanCanonicalize (H12AffineFastState.compose env594 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound594 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env595 : List Nat := [2,4,8,16,32,48,128,141,512,1024,136,571,160,1045,1,35,1702,0,524288,1,643,33,525329,138,40,525360,136,1164,17,1,1193,169,525453,169,524831,513]

theorem envBound595 : H12AffineFastState.Bounded env595 := by
  intro p hp
  have h : env595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans594_595 : H12AffineEnvironment.transform 11 571 env594 = env595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env594 == env595) = true)

def env596 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound596 : H12AffineFastState.Bounded env596 := by
  intro p hp
  have h : env596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans581_596 : H12AffineEnvironment.transform 20 268337 env581 = env596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268337 env581 == env596) = true)

def env597 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,656568,66082]

theorem envBound597 : H12AffineFastState.Bounded env597 := by
  intro p hp
  have h : env597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans596_597 : H12AffineEnvironment.transform 34 656568 env596 = env597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656568 env596 == env597) = true)

theorem identity597 : scanCanonicalize (H12AffineFastState.compose env597 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 138260) := by decide +kernel

theorem selectedBound597 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env598 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,138260,524288,1,132133,33,725167,136215,40,525360,138396,82106,217274,138260,1193,65674,525453,136244,656568,66082]

theorem envBound598 : H12AffineFastState.Bounded env598 := by
  intro p hp
  have h : env598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans597_598 : H12AffineEnvironment.transform 17 138260 env597 = env598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138260 env597 == env598) = true)

theorem identity598 : scanCanonicalize (H12AffineFastState.compose env598 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(18+1) ^^^ 214171) := by decide +kernel

theorem selectedBound598 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env599 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,138260,214171,1,132133,33,21556,136215,40,213163,138396,82106,217274,138260,1193,65674,213014,136244,81955,66082]

theorem envBound599 : H12AffineFastState.Bounded env599 := by
  intro p hp
  have h : env599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans598_599 : H12AffineEnvironment.transform 18 214171 env598 = env599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 214171 env598 == env599) = true)

theorem identity599 : scanCanonicalize (H12AffineFastState.compose env599 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound599 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env600 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,70846,67754,20517,1,69787,33,21556,65705,40,21525,67618,82106,17412,67754,1193,65674,21672,65674,81955,66082]

theorem envBound600 : H12AffineFastState.Bounded env600 := by
  intro p hp
  have h : env600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans599_600 : H12AffineEnvironment.transform 16 70846 env599 = env600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env599 == env600) = true)

theorem identity600 : scanCanonicalize (H12AffineFastState.compose env600 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound600 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env601 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,4144,1,65536,70846,67754,21,1,69787,33,1028,65705,40,1061,67618,69770,5172,67754,1193,65674,1176,65674,69651,66082]

theorem envBound601 : H12AffineFastState.Bounded env601 := by
  intro p hp
  have h : env601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans600_601 : H12AffineEnvironment.transform 13 4144 env600 = env601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env600 == env601) = true)

def env602 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,262144,524288,1,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,656569,66082]

theorem envBound602 : H12AffineFastState.Bounded env602 := by
  intro p hp
  have h : env602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans596_602 : H12AffineEnvironment.transform 34 656569 env596 = env602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656569 env596 == env602) = true)

theorem identity602 : scanCanonicalize (H12AffineFastState.compose env602 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound602 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env603 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,2184,524288,1,4281,33,725167,136215,40,525360,2048,218150,82982,138260,1193,65674,525453,136244,656569,66082]

theorem envBound603 : H12AffineFastState.Bounded env603 := by
  intro p hp
  have h : env603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans602_603 : H12AffineEnvironment.transform 17 2184 env602 = env603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env602 == env603) = true)

theorem identity603 : scanCanonicalize (H12AffineFastState.compose env603 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(18+1) ^^^ 148664) := by decide +kernel

theorem selectedBound603 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env604 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,131072,2184,148664,1,4281,33,87063,136215,40,147592,2048,218150,82982,138260,1193,65674,147509,136244,16385,66082]

theorem envBound604 : H12AffineFastState.Bounded env604 := by
  intro p hp
  have h : env604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans603_604 : H12AffineEnvironment.transform 18 148664 env603 = env604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 148664 env603 == env604) = true)

theorem identity604 : scanCanonicalize (H12AffineFastState.compose env604 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound604 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env605 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,1,65536,70846,2184,86022,1,4281,33,87063,65705,40,87094,2048,16536,82982,67754,1193,65674,87179,65674,16385,66082]

theorem envBound605 : H12AffineFastState.Bounded env605 := by
  intro p hp
  have h : env605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans604_605 : H12AffineEnvironment.transform 16 70846 env604 = env605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env604 == env605) = true)

theorem identity605 : scanCanonicalize (H12AffineFastState.compose env605 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound605 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env606 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,4145,1,65536,70846,2184,65591,1,4281,33,66598,65705,40,66567,2048,4265,70679,67754,1193,65674,66746,65674,4144,66082]

theorem envBound606 : H12AffineFastState.Bounded env606 := by
  intro p hp
  have h : env606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans605_606 : H12AffineEnvironment.transform 13 4145 env605 = env606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env605 == env606) = true)

def env607 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,65536,131072,262144,524288,0,2097152,33,725166,136215,41,525361,262280,2311327,2184351,138260,1193,65675,525452,136244,34359738368,66083]

theorem envBound607 : H12AffineFastState.Bounded env607 := by
  intro p hp
  have h : env607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans580_607 : H12AffineEnvironment.transform 5 49 env580 = env607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env580 == env607) = true)

theorem identity607 : scanCanonicalize (H12AffineFastState.compose env607 (packedSelected [2,3,5,6,10,11,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound607 : packedSelected [2,3,5,6,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env608 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,65536,5277,262144,524288,0,2097152,33,590899,138,41,525361,262280,2183170,2184351,2185,1193,65675,525452,169,34359738368,66083]

theorem envBound608 : H12AffineFastState.Bounded env608 := by
  intro p hp
  have h : env608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans607_608 : H12AffineEnvironment.transform 16 5277 env607 = env608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env607 == env608) = true)

theorem identity608 : scanCanonicalize (H12AffineFastState.compose env608 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 2687166) := by decide +kernel

theorem selectedBound608 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env609 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,65536,5277,262144,524288,0,2097152,33,590899,138,41,525361,262280,2183170,2184351,2185,1193,65675,525452,169,2687166,66083]

theorem envBound609 : H12AffineFastState.Bounded env609 := by
  intro p hp
  have h : env609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans608_609 : H12AffineEnvironment.transform 34 2687166 env608 = env609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2687166 env608 == env609) = true)

theorem identity609 : scanCanonicalize (H12AffineFastState.compose env609 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound609 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env610 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,34,5277,262144,524288,0,2097152,33,525329,138,41,525361,262280,2117664,2118845,2185,1193,169,525452,169,2621596,513]

theorem envBound610 : H12AffineFastState.Bounded env610 := by
  intro p hp
  have h : env610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans609_610 : H12AffineEnvironment.transform 15 34 env609 = env610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env609 == env610) = true)

theorem identity610 : scanCanonicalize (H12AffineFastState.compose env610 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 528556) := by decide +kernel

theorem selectedBound610 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env611 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,34,5277,262144,524288,0,528556,33,525329,138,41,525361,262280,540812,541713,2185,1193,169,525452,169,4144,513]

theorem envBound611 : H12AffineFastState.Bounded env611 := by
  intro p hp
  have h : env611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans610_611 : H12AffineEnvironment.transform 20 528556 env610 = env611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528556 env610 == env611) = true)

theorem identity611 : scanCanonicalize (H12AffineFastState.compose env611 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 19592) := by decide +kernel

theorem selectedBound611 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env612 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,0,34,5277,262144,19592,0,23588,33,18585,138,41,18617,262280,3076,2201,2185,1193,169,18436,169,4144,513]

theorem envBound612 : H12AffineFastState.Bounded env612 := by
  intro p hp
  have h : env612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans611_612 : H12AffineEnvironment.transform 18 19592 env611 = env612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 19592 env611 == env612) = true)

theorem identity612 : scanCanonicalize (H12AffineFastState.compose env612 (packedSelected [1,4,5,7,12] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound612 : packedSelected [1,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env613 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,7846,0,34,5277,262144,4654,0,642,33,5695,138,41,5663,262280,3076,2201,2185,1193,169,5794,169,4144,513]

theorem envBound613 : H12AffineFastState.Bounded env613 := by
  intro p hp
  have h : env613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans612_613 : H12AffineEnvironment.transform 13 7846 env612 = env613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env612 == env613) = true)

theorem identity613 : scanCanonicalize (H12AffineFastState.compose env613 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 6834) := by decide +kernel

theorem selectedBound613 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env614 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,7846,0,34,5277,6834,4654,0,642,33,5695,138,41,5663,6714,3076,2201,2185,1193,169,5794,169,4144,513]

theorem envBound614 : H12AffineFastState.Bounded env614 := by
  intro p hp
  have h : env614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans613_614 : H12AffineEnvironment.transform 17 6834 env613 = env614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6834 env613 == env614) = true)

theorem identity614 : scanCanonicalize (H12AffineFastState.compose env614 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound614 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env615 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,3245,161,523,0,34,2096,1567,3715,0,642,33,2706,138,41,2738,1687,3076,2201,2185,1193,169,2575,169,3229,513]

theorem envBound615 : H12AffineFastState.Bounded env615 := by
  intro p hp
  have h : env615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans614_615 : H12AffineEnvironment.transform 11 3245 env614 = env615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env614 == env615) = true)

theorem identity615 : scanCanonicalize (H12AffineFastState.compose env615 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 35) := by decide +kernel

theorem selectedBound615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env616 : List Nat := [2,4,8,16,32,49,128,140,512,1024,35,1166,161,523,0,34,19,1567,1696,0,642,33,689,138,41,657,1687,1063,186,170,1193,169,556,169,1214,513]

theorem envBound616 : H12AffineFastState.Bounded env616 := by
  intro p hp
  have h : env616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans615_616 : H12AffineEnvironment.transform 10 35 env615 = env616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 35 env615 == env616) = true)

theorem identity616 : scanCanonicalize (H12AffineFastState.compose env616 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound616 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env617 : List Nat := [2,4,8,16,32,49,9,5,512,1024,35,1031,40,523,0,34,19,1567,1577,0,523,33,568,3,41,536,1566,1063,51,35,1056,32,556,32,1079,513]

theorem envBound617 : H12AffineFastState.Bounded env617 := by
  intro p hp
  have h : env617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans616_617 : H12AffineEnvironment.transform 6 9 env616 = env617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env616 == env617) = true)

theorem identity617 : scanCanonicalize (H12AffineFastState.compose env617 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env618 : List Nat := [2,4,8,16,32,49,9,5,512,543,35,536,40,523,0,34,19,0,54,0,523,33,568,3,41,536,1,568,51,35,575,32,556,32,552,513]

theorem envBound618 : H12AffineFastState.Bounded env618 := by
  intro p hp
  have h : env618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans617_618 : H12AffineEnvironment.transform 9 543 env617 = env618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env617 == env618) = true)

theorem identity618 : scanCanonicalize (H12AffineFastState.compose env618 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env619 : List Nat := [2,4,0,16,32,49,1,5,512,535,35,528,32,515,0,34,19,0,54,0,515,33,560,3,33,528,1,560,51,35,567,32,548,32,544,513]

theorem envBound619 : H12AffineFastState.Bounded env619 := by
  intro p hp
  have h : env619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans618_619 : H12AffineEnvironment.transform 2 0 env618 = env619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env618 == env619) = true)

theorem identity619 : scanCanonicalize (H12AffineFastState.compose env619 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound619 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env620 : List Nat := [2,4,0,16,3,18,1,5,512,535,0,528,3,515,0,1,19,0,21,0,515,2,531,3,2,528,1,531,16,0,532,3,519,3,515,513]

theorem envBound620 : H12AffineFastState.Bounded env620 := by
  intro p hp
  have h : env620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans619_620 : H12AffineEnvironment.transform 4 3 env619 = env620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env619 == env620) = true)

def env621 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,131072,262144,524288,112,2097152,33,8388608,8979657,89,525376,262280,11031616,11158592,8981706,1193,65787,525565,8979690,34359738368,66131]

theorem envBound621 : H12AffineFastState.Bounded env621 := by
  intro p hp
  have h : env621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans578_621 : H12AffineEnvironment.transform 12 209 env578 = env621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env578 == env621) = true)

theorem identity621 : scanCanonicalize (H12AffineFastState.compose env621 (packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 659596) := by decide +kernel

theorem selectedBound621 : packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env622 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,131072,262144,524288,112,2097152,33,659596,201797,89,525376,262280,2245836,2118860,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound622 : H12AffineFastState.Bounded env622 := by
  intro p hp
  have h : env622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans621_622 : H12AffineEnvironment.transform 22 659596 env621 = env622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 659596 env621 == env622) = true)

def env623 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,131072,262144,524288,112,528604,33,659596,201797,89,525376,262280,676880,541712,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound623 : H12AffineFastState.Bounded env623 := by
  intro p hp
  have h : env623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans622_623 : H12AffineEnvironment.transform 20 528604 env622 = env623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528604 env622 == env623) = true)

theorem identity623 : scanCanonicalize (H12AffineFastState.compose env623 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound623 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env624 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,5357,262144,524288,112,528604,33,525409,65704,89,525376,262280,540925,541712,67755,1193,65787,525565,65675,34359738368,66131]

theorem envBound624 : H12AffineFastState.Bounded env624 := by
  intro p hp
  have h : env624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans623_624 : H12AffineEnvironment.transform 16 5357 env623 = env624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env623 == env624) = true)

theorem identity624 : scanCanonicalize (H12AffineFastState.compose env624 (packedSelected [0,2,6,7,9,11,14,20,21,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound624 : packedSelected [0,2,6,7,9,11,14,20,21,22,23] rootPS < 2^1333 := by decide +kernel

def env625 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,34,5357,262144,524288,112,528604,33,525409,138,89,525376,262280,540925,541712,2185,1193,217,525565,169,34359738368,625]

theorem envBound625 : H12AffineFastState.Bounded env625 := by
  intro p hp
  have h : env625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans624_625 : H12AffineEnvironment.transform 15 34 env624 = env625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env624 == env625) = true)

theorem identity625 : scanCanonicalize (H12AffineFastState.compose env625 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 4160) := by decide +kernel

theorem selectedBound625 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env626 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,34,5357,262144,524288,112,528604,33,525409,138,89,525376,262280,540925,541712,2185,1193,217,525565,169,4160,625]

theorem envBound626 : H12AffineFastState.Bounded env626 := by
  intro p hp
  have h : env626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans625_626 : H12AffineEnvironment.transform 34 4160 env625 = env626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4160 env625 == env626) = true)

theorem identity626 : scanCanonicalize (H12AffineFastState.compose env626 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound626 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env627 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,0,34,5277,262144,524288,0,528556,33,525329,138,41,525360,262280,540813,541712,2185,1193,169,525453,169,4144,513]

theorem envBound627 : H12AffineFastState.Bounded env627 := by
  intro p hp
  have h : env627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans626_627 : H12AffineEnvironment.transform 5 48 env626 = env627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env626 == env627) = true)

theorem identity627 : scanCanonicalize (H12AffineFastState.compose env627 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 7353) := by decide +kernel

theorem selectedBound627 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env628 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,0,34,5277,262144,7353,0,3093,33,6312,138,41,6281,262280,23604,22697,2185,1193,169,6196,169,4144,513]

theorem envBound628 : H12AffineFastState.Bounded env628 := by
  intro p hp
  have h : env628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans627_628 : H12AffineEnvironment.transform 18 7353 env627 = env628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 7353 env627 == env628) = true)

theorem identity628 : scanCanonicalize (H12AffineFastState.compose env628 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 1566) := by decide +kernel

theorem selectedBound628 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env629 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,0,34,5277,1566,7353,0,3093,33,6312,138,41,6281,1686,23604,22697,2185,1193,169,6196,169,4144,513]

theorem envBound629 : H12AffineFastState.Bounded env629 := by
  intro p hp
  have h : env629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans628_629 : H12AffineEnvironment.transform 17 1566 env628 = env629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1566 env628 == env629) = true)

theorem identity629 : scanCanonicalize (H12AffineFastState.compose env629 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound629 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env630 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,570,161,16384,0,34,1703,1566,3715,0,3093,33,2706,138,41,2739,1686,19982,19091,2185,1193,169,2574,169,522,513]

theorem envBound630 : H12AffineFastState.Bounded env630 := by
  intro p hp
  have h : env630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans629_630 : H12AffineEnvironment.transform 11 570 env629 = env630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env629 == env630) = true)

theorem identity630 : scanCanonicalize (H12AffineFastState.compose env630 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 3228) := by decide +kernel

theorem selectedBound630 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env631 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,570,161,3228,0,34,1703,1566,3715,0,3093,33,2706,138,41,2739,1686,658,1551,2185,1193,169,2574,169,522,513]

theorem envBound631 : H12AffineFastState.Bounded env631 := by
  intro p hp
  have h : env631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans630_631 : H12AffineEnvironment.transform 13 3228 env630 = env631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3228 env630 == env631) = true)

theorem identity631 : scanCanonicalize (H12AffineFastState.compose env631 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 158) := by decide +kernel

theorem selectedBound631 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env632 : List Nat := [2,4,8,16,32,48,128,141,512,158,2048,570,161,2050,0,34,569,640,2589,0,2187,33,2706,138,41,2739,520,658,657,2185,55,169,2574,169,522,513]

theorem envBound632 : H12AffineFastState.Bounded env632 := by
  intro p hp
  have h : env632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans631_632 : H12AffineEnvironment.transform 9 158 env631 = env632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 158 env631 == env632) = true)

theorem identity632 : scanCanonicalize (H12AffineFastState.compose env632 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 521) := by decide +kernel

theorem selectedBound632 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env633 : List Nat := [2,4,8,16,32,48,128,141,512,158,521,570,161,523,0,34,569,640,20,0,642,33,155,138,41,186,520,658,657,640,55,169,7,169,522,513]

theorem envBound633 : H12AffineFastState.Bounded env633 := by
  intro p hp
  have h : env633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans632_633 : H12AffineEnvironment.transform 10 521 env632 = env633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 521 env632 == env633) = true)

theorem identity633 : scanCanonicalize (H12AffineFastState.compose env633 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound633 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env634 : List Nat := [2,4,8,16,32,48,128,141,8,158,1,50,161,3,0,34,49,136,20,0,138,33,155,138,41,186,0,154,153,136,55,169,7,169,2,9]

theorem envBound634 : H12AffineFastState.Bounded env634 := by
  intro p hp
  have h : env634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans633_634 : H12AffineEnvironment.transform 8 8 env633 = env634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env633 == env634) = true)

theorem identity634 : scanCanonicalize (H12AffineFastState.compose env634 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound634 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env635 : List Nat := [2,4,8,16,32,48,1,12,8,31,1,50,32,3,0,34,49,9,20,0,11,33,26,11,41,59,0,27,24,9,55,40,7,40,2,9]

theorem envBound635 : H12AffineFastState.Bounded env635 := by
  intro p hp
  have h : env635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans634_635 : H12AffineEnvironment.transform 6 1 env634 = env635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env634 == env635) = true)

def env636 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,131072,262144,524288,112,528605,33,659596,201797,89,525376,262280,676881,541713,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound636 : H12AffineFastState.Bounded env636 := by
  intro p hp
  have h : env636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans622_636 : H12AffineEnvironment.transform 20 528605 env622 = env636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528605 env622 == env636) = true)

theorem identity636 : scanCanonicalize (H12AffineFastState.compose env636 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound636 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env637 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,112,65536,70846,262144,524288,112,528605,33,590898,251,89,525376,262280,606383,541713,2296,1193,65787,525565,216,34359738368,66131]

theorem envBound637 : H12AffineFastState.Bounded env637 := by
  intro p hp
  have h : env637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans636_637 : H12AffineEnvironment.transform 16 70846 env636 = env637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env636 == env637) = true)

theorem identity637 : scanCanonicalize (H12AffineFastState.compose env637 (packedSelected [2,6,11,21,23] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound637 : packedSelected [2,6,11,21,23] rootPS < 2^1333 := by decide +kernel

def env638 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,1,65536,70846,262144,524288,1,528556,33,590898,138,40,525361,262280,606383,541713,2185,1193,65674,525452,169,34359738368,66082]

theorem envBound638 : H12AffineFastState.Bounded env638 := by
  intro p hp
  have h : env638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans637_638 : H12AffineEnvironment.transform 5 49 env637 = env638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env637 == env638) = true)

theorem identity638 : scanCanonicalize (H12AffineFastState.compose env638 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 4144) := by decide +kernel

theorem selectedBound638 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env639 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,1,65536,70846,262144,524288,1,528556,33,590898,138,40,525361,262280,606383,541713,2185,1193,65674,525452,169,4144,66082]

theorem envBound639 : H12AffineFastState.Bounded env639 := by
  intro p hp
  have h : env639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans638_639 : H12AffineEnvironment.transform 34 4144 env638 = env639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4144 env638 == env639) = true)

theorem identity639 : scanCanonicalize (H12AffineFastState.compose env639 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound639 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env640 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,1,35,5277,262144,524288,1,528556,33,525329,138,40,525361,262280,540812,541713,2185,1193,169,525452,169,4144,513]

theorem envBound640 : H12AffineFastState.Bounded env640 := by
  intro p hp
  have h : env640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans639_640 : H12AffineEnvironment.transform 15 35 env639 = env640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env639 == env640) = true)

theorem identity640 : scanCanonicalize (H12AffineFastState.compose env640 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 279553) := by decide +kernel

theorem selectedBound640 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env641 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,1,35,5277,262144,279553,1,283821,33,278544,138,40,278576,262280,263309,262160,2185,1193,169,278669,169,4144,513]

theorem envBound641 : H12AffineFastState.Bounded env641 := by
  intro p hp
  have h : env641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans640_641 : H12AffineEnvironment.transform 18 279553 env640 = env641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 279553 env640 == env641) = true)

theorem identity641 : scanCanonicalize (H12AffineFastState.compose env641 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound641 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env642 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,7846,1,35,5277,262144,268967,1,264715,33,270006,138,40,269974,262280,263309,262160,2185,1193,169,269867,169,4144,513]

theorem envBound642 : H12AffineFastState.Bounded env642 := by
  intro p hp
  have h : env642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans641_642 : H12AffineEnvironment.transform 13 7846 env641 = env642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env641 == env642) = true)

theorem identity642 : scanCanonicalize (H12AffineFastState.compose env642 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound642 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env643 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,570,160,3228,1,35,1703,262144,264349,1,264715,33,265356,138,40,265388,262280,263309,262160,2185,1193,169,265233,169,522,513]

theorem envBound643 : H12AffineFastState.Bounded env643 := by
  intro p hp
  have h : env643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans642_643 : H12AffineEnvironment.transform 11 570 env642 = env643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env642 == env643) = true)

theorem identity643 : scanCanonicalize (H12AffineFastState.compose env643 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 1566) := by decide +kernel

theorem selectedBound643 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env644 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,570,160,3228,1,35,1703,1566,3715,1,3093,33,2706,138,40,2738,1686,659,1550,2185,1193,169,2575,169,522,513]

theorem envBound644 : H12AffineFastState.Bounded env644 := by
  intro p hp
  have h : env644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans643_644 : H12AffineEnvironment.transform 17 1566 env643 = env644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1566 env643 == env644) = true)

theorem identity644 : scanCanonicalize (H12AffineFastState.compose env644 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound644 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env645 : List Nat := [2,4,8,16,32,49,43,39,512,1024,2048,570,11,3127,1,35,1548,1566,3624,1,3093,33,2617,33,40,2585,1597,568,1550,2082,1026,2,2575,2,522,513]

theorem envBound645 : H12AffineFastState.Bounded env645 := by
  intro p hp
  have h : env645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans644_645 : H12AffineEnvironment.transform 6 43 env644 = env645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env644 == env645) = true)

theorem identity645 : scanCanonicalize (H12AffineFastState.compose env645 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1596) := by decide +kernel

theorem selectedBound645 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env646 : List Nat := [2,4,8,16,32,49,43,39,512,1024,1596,570,11,523,1,35,1548,1566,20,1,553,33,1029,33,40,1061,1597,568,1550,1566,1026,2,1075,2,522,513]

theorem envBound646 : H12AffineFastState.Bounded env646 := by
  intro p hp
  have h : env646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans645_646 : H12AffineEnvironment.transform 10 1596 env645 = env646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1596 env645 == env646) = true)

theorem identity646 : scanCanonicalize (H12AffineFastState.compose env646 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 572) := by decide +kernel

theorem selectedBound646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env647 : List Nat := [2,4,8,16,32,49,43,39,512,572,0,570,11,523,1,35,48,34,20,1,553,33,569,33,40,537,1,568,50,34,574,2,527,2,522,513]

theorem envBound647 : H12AffineFastState.Bounded env647 := by
  intro p hp
  have h : env647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans646_647 : H12AffineEnvironment.transform 9 572 env646 = env647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 572 env646 == env647) = true)

theorem identity647 : scanCanonicalize (H12AffineFastState.compose env647 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env648 : List Nat := [2,4,8,16,32,49,43,39,35,31,0,25,11,40,1,35,48,34,20,1,10,33,26,33,40,58,1,27,50,34,29,2,44,2,41,34]

theorem envBound648 : H12AffineFastState.Bounded env648 := by
  intro p hp
  have h : env648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans647_648 : H12AffineEnvironment.transform 8 35 env647 = env648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env647 == env648) = true)

def env649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,77615105,77742081,13208934,67674549,73770,525568,13206854,34359738368,98851]

theorem envBound649 : H12AffineFastState.Bounded env649 := by
  intro p hp
  have h : env649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans252_649 : H12AffineEnvironment.transform 27 77615105 env252 = env649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615105 env252 == env649) = true)

theorem identity649 : scanCanonicalize (H12AffineFastState.compose env649 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 599234) := by decide +kernel

theorem selectedBound649 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13208934,99703,73770,525568,13206854,34359738368,98851]

theorem envBound650 : H12AffineFastState.Bounded env650 := by
  intro p hp
  have h : env650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans649_650 : H12AffineEnvironment.transform 25 599234 env649 = env650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599234 env649 == env650) = true)

def env651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13184454,75223,73770,525568,13182438,34359738368,74371]

theorem envBound651 : H12AffineFastState.Bounded env651 := by
  intro p hp
  have h : env651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans650_651 : H12AffineEnvironment.transform 14 8352 env650 = env651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env650 == env651) = true)

def env652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,8388608,8988133,8328,599234,262280,11105475,11232451,8990182,75223,73770,525568,8988102,34359738368,74371]

theorem envBound652 : H12AffineFastState.Bounded env652 := by
  intro p hp
  have h : env652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans651_652 : H12AffineEnvironment.transform 21 32 env651 = env652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env651 == env652) = true)

def env653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525328,74229,8328,599234,262280,2191571,2318547,76278,75223,73770,525568,74198,34359738368,74371]

theorem envBound653 : H12AffineFastState.Bounded env653 := by
  intro p hp
  have h : env653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans652_653 : H12AffineEnvironment.transform 22 525328 env652 = env653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env652 == env653) = true)

theorem identity653 : scanCanonicalize (H12AffineFastState.compose env653 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound653 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8574,131072,262144,524288,8352,2097152,32,525328,139,8328,525756,262280,2118061,2245037,2184,1193,340,525568,168,34359738368,1021]

theorem envBound654 : H12AffineFastState.Bounded env654 := by
  intro p hp
  have h : env654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans653_654 : H12AffineEnvironment.transform 15 8574 env653 = env654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env653 == env654) = true)

def env655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525329,74228,8328,599234,262280,2191570,2318546,76279,75223,73770,525568,74199,34359738368,74371]

theorem envBound655 : H12AffineFastState.Bounded env655 := by
  intro p hp
  have h : env655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans652_655 : H12AffineEnvironment.transform 22 525329 env652 = env655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env652 == env655) = true)

theorem identity655 : scanCanonicalize (H12AffineFastState.compose env655 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound655 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,32,525329,375,8328,525377,262280,2117713,2244689,2420,1364,169,525568,340,34359738368,512]

theorem envBound656 : H12AffineFastState.Bounded env656 := by
  intro p hp
  have h : env656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans655_656 : H12AffineEnvironment.transform 15 8323 env655 = env656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env655 == env656) = true)

theorem identity656 : scanCanonicalize (H12AffineFastState.compose env656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8323,5393,262144,524288,8352,2097152,32,525329,375,8328,525377,262280,2117713,2118976,2420,1364,169,525568,340,34359738368,512]

theorem envBound657 : H12AffineFastState.Bounded env657 := by
  intro p hp
  have h : env657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans656_657 : H12AffineEnvironment.transform 16 5393 env656 = env657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env656 == env657) = true)

theorem identity657 : scanCanonicalize (H12AffineFastState.compose env657 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound657 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env658 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,5356,262144,524288,8352,2097152,32,525329,138,8328,525377,262280,2117713,2118845,2185,1193,169,525565,169,34359738368,512]

theorem envBound658 : H12AffineFastState.Bounded env658 := by
  intro p hp
  have h : env658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans657_658 : H12AffineEnvironment.transform 7 253 env657 = env658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env657 == env658) = true)

theorem identity658 : scanCanonicalize (H12AffineFastState.compose env658 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 540908) := by decide +kernel

theorem selectedBound658 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env659 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,5356,262144,524288,8352,540908,32,525329,138,8328,525377,262280,528573,529489,2185,1193,169,525565,169,34359738368,512]

theorem envBound659 : H12AffineFastState.Bounded env659 := by
  intro p hp
  have h : env659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans658_659 : H12AffineEnvironment.transform 20 540908 env658 = env659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 540908 env658 == env659) = true)

theorem identity659 : scanCanonicalize (H12AffineFastState.compose env659 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 5293) := by decide +kernel

theorem selectedBound659 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env660 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,5356,262144,524288,8352,540908,32,525329,138,8328,525377,262280,528573,529489,2185,1193,169,525565,169,5293,512]

theorem envBound660 : H12AffineFastState.Bounded env660 := by
  intro p hp
  have h : env660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans659_660 : H12AffineEnvironment.transform 34 5293 env659 = env660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 5293 env659 == env660) = true)

theorem identity660 : scanCanonicalize (H12AffineFastState.compose env660 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound660 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env661 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,5356,23589,524288,8352,540908,32,525329,138,8328,525377,23725,528573,529489,2185,1193,169,525565,169,5293,512]

theorem envBound661 : H12AffineFastState.Bounded env661 := by
  intro p hp
  have h : env661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans660_661 : H12AffineEnvironment.transform 17 23589 env660 = env661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env660 == env661) = true)

theorem identity661 : scanCanonicalize (H12AffineFastState.compose env661 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(18+1) ^^^ 1161) := by decide +kernel

theorem selectedBound661 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env662 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,5356,23589,1161,8352,17509,32,152,138,8328,200,23725,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound662 : H12AffineFastState.Bounded env662 := by
  intro p hp
  have h : env662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans661_662 : H12AffineEnvironment.transform 18 1161 env661 = env662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1161 env661 == env662) = true)

theorem identity662 : scanCanonicalize (H12AffineFastState.compose env662 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 15879) := by decide +kernel

theorem selectedBound662 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env663 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,15879,8352,8323,5356,8738,1161,8352,14946,32,152,138,8328,200,8874,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound663 : H12AffineFastState.Bounded env663 := by
  intro p hp
  have h : env663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans662_663 : H12AffineEnvironment.transform 13 15879 env662 = env663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15879 env662 == env663) = true)

theorem identity663 : scanCanonicalize (H12AffineFastState.compose env663 (packedSelected [11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound663 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env664 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,121,7806,217,250,5356,603,1161,217,6683,32,152,138,241,200,723,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound664 : H12AffineFastState.Bounded env664 := by
  intro p hp
  have h : env664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans663_664 : H12AffineEnvironment.transform 12 121 env663 = env664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env663 == env664) = true)

theorem identity664 : scanCanonicalize (H12AffineFastState.compose env664 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound664 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env665 : List Nat := [2,4,8,16,32,64,128,253,512,167,2048,4096,121,6873,217,250,4171,603,46,217,6683,32,152,138,241,200,723,4243,4312,2185,14,169,116,169,4106,512]

theorem envBound665 : H12AffineFastState.Bounded env665 := by
  intro p hp
  have h : env665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans664_665 : H12AffineEnvironment.transform 9 167 env664 = env665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env664 == env665) = true)

theorem identity665 : scanCanonicalize (H12AffineFastState.compose env665 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound665 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env666 : List Nat := [2,4,8,16,32,64,88,37,512,127,2048,4096,121,6657,1,34,4171,603,46,1,6683,32,64,82,41,16,523,4171,4096,2129,14,113,116,113,4106,512]

theorem envBound666 : H12AffineFastState.Bounded env666 := by
  intro p hp
  have h : env666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans665_666 : H12AffineEnvironment.transform 6 88 env665 = env666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env665 == env666) = true)

def env667 : List Nat := [2,4,8,16,32,16,8,37,512,47,2048,4096,41,6657,1,34,4123,523,46,1,6683,32,16,2,41,16,523,4123,4096,2049,14,33,36,33,4106,512]

theorem envBound667 : H12AffineFastState.Bounded env667 := by
  intro p hp
  have h : env667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans666_667 : H12AffineEnvironment.transform 5 16 env666 = env667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env666 == env667) = true)

theorem identity667 : scanCanonicalize (H12AffineFastState.compose env667 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env668 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,4096,25,6657,1,18,4123,523,30,1,6683,16,16,2,25,16,523,4123,4096,2049,14,17,20,17,4106,512]

theorem envBound668 : H12AffineFastState.Bounded env668 := by
  intro p hp
  have h : env668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans667_668 : H12AffineEnvironment.transform 4 16 env667 = env668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env667 == env668) = true)

def env669 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,0,25,2561,1,18,27,523,30,1,2587,16,16,2,25,16,523,27,0,2049,14,17,20,17,10,512]

theorem envBound669 : H12AffineFastState.Bounded env669 := by
  intro p hp
  have h : env669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans668_669 : H12AffineEnvironment.transform 11 0 env668 = env669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env668 == env669) = true)

theorem identity669 : scanCanonicalize (H12AffineFastState.compose env669 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env670 : List Nat := [2,4,8,2,2,2,8,7,512,13,2048,0,11,2561,1,0,9,523,12,1,2569,2,2,2,11,2,523,9,0,2049,14,3,6,3,10,512]

theorem envBound670 : H12AffineFastState.Bounded env670 := by
  intro p hp
  have h : env670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans669_670 : H12AffineEnvironment.transform 3 2 env669 = env670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env669 == env670) = true)

def env671 : List Nat := [2,4,8,2,2,2,8,7,8,13,2048,0,11,2057,1,0,9,3,12,1,2049,2,2,2,11,2,3,9,0,2049,14,3,6,3,10,8]

theorem envBound671 : H12AffineFastState.Bounded env671 := by
  intro p hp
  have h : env671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans670_671 : H12AffineEnvironment.transform 8 8 env670 = env671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env670 == env671) = true)

def env672 : List Nat := [2,4,8,2,2,2,8,7,8,13,0,0,11,9,1,0,9,3,12,1,1,2,2,2,11,2,3,9,0,1,14,3,6,3,10,8]

theorem envBound672 : H12AffineFastState.Bounded env672 := by
  intro p hp
  have h : env672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans671_672 : H12AffineEnvironment.transform 10 0 env671 = env672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env671 == env672) = true)

theorem identity672 : scanCanonicalize (H12AffineFastState.compose env672 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env673 : List Nat := [2,4,5,2,2,2,5,7,5,0,0,0,6,4,1,0,4,3,1,1,1,2,2,2,6,2,3,4,0,1,3,3,6,3,7,5]

theorem envBound673 : H12AffineFastState.Bounded env673 := by
  intro p hp
  have h : env673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans672_673 : H12AffineEnvironment.transform 2 5 env672 = env673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env672 == env673) = true)

def env674 : List Nat := [2,0,1,2,2,2,1,3,1,0,0,0,2,0,1,0,0,3,1,1,1,2,2,2,2,2,3,0,0,1,3,3,2,3,3,1]

theorem envBound674 : H12AffineFastState.Bounded env674 := by
  intro p hp
  have h : env674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans673_674 : H12AffineEnvironment.transform 1 0 env673 = env674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env673 == env674) = true)

def leafEnv674 : List Nat := [2,0,1,2,2,2,1,3,1,0,0,0,2,0,1,0,0,3,1,1,1,2,2,2,2,2,1,2,3,0,0,1,3,3,2,3,1,0,3,1,1,3,0]

def active674 : List Nat := [0]

def tree674 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood674 : H12WitnessSearch.Good tree674 := H12GlobalWitnessIndex.good

theorem leafIdentity674 : H12AffineFastState.composeSystem env674 rootObs = leafEnv674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env674 rootObs == leafEnv674) = true)

theorem terminalChecked674 : H12PackedTerminal.terminalCheckFast leafEnv674 active674 tree674 = true := by decide +kernel

def env675 : List Nat := [2,1,0,2,2,2,0,2,0,0,0,0,3,1,1,0,1,3,1,1,1,2,2,2,3,2,3,1,0,1,3,3,3,3,2,0]

theorem envBound675 : H12AffineFastState.Bounded env675 := by
  intro p hp
  have h : env675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans673_675 : H12AffineEnvironment.transform 1 1 env673 = env675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env673 == env675) = true)

theorem identity675 : scanCanonicalize (H12AffineFastState.compose env675 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound675 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env676 : List Nat := [0,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,0,1,1,1,1,1,0,0]

theorem envBound676 : H12AffineFastState.Bounded env676 := by
  intro p hp
  have h : env676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans675_676 : H12AffineEnvironment.transform 0 0 env675 = env676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env675 == env676) = true)

def leafEnv676 : List Nat := [0,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,1,1,0,0,0,0,1,1,0,1,1,0,1,1,1,1,1,0,0,0,0,1,1,0]

def active676 : List Nat := []

def tree676 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood676 : H12WitnessSearch.Good tree676 := H12GlobalWitnessIndex.good

theorem leafIdentity676 : H12AffineFastState.composeSystem env676 rootObs = leafEnv676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env676 rootObs == leafEnv676) = true)

theorem terminalChecked676 : H12PackedTerminal.terminalCheckFast leafEnv676 active676 tree676 = true := by decide +kernel

def env677 : List Nat := [2,4,8,2,2,2,8,7,8,13,1,0,11,8,1,0,9,3,12,1,0,2,2,2,11,2,3,9,0,0,14,3,6,3,10,8]

theorem envBound677 : H12AffineFastState.Bounded env677 := by
  intro p hp
  have h : env677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans671_677 : H12AffineEnvironment.transform 10 1 env671 = env677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env671 == env677) = true)

theorem identity677 : scanCanonicalize (H12AffineFastState.compose env677 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound677 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env678 : List Nat := [2,4,6,2,2,2,6,7,6,3,1,0,5,6,1,0,7,3,2,1,0,2,2,2,5,2,3,7,0,0,0,3,6,3,4,6]

theorem envBound678 : H12AffineFastState.Bounded env678 := by
  intro p hp
  have h : env678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans677_678 : H12AffineEnvironment.transform 2 6 env677 = env678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env677 == env678) = true)

def env679 : List Nat := [2,0,2,2,2,2,2,3,2,3,1,0,1,2,1,0,3,3,2,1,0,2,2,2,1,2,3,3,0,0,0,3,2,3,0,2]

theorem envBound679 : H12AffineFastState.Bounded env679 := by
  intro p hp
  have h : env679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans678_679 : H12AffineEnvironment.transform 1 0 env678 = env679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env678 == env679) = true)

theorem identity679 : scanCanonicalize (H12AffineFastState.compose env679 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound679 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env680 : List Nat := [1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,1,0,0,0,0,0,0,1,0,0,1]

theorem envBound680 : H12AffineFastState.Bounded env680 := by
  intro p hp
  have h : env680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans679_680 : H12AffineEnvironment.transform 0 1 env679 = env680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env679 == env680) = true)

def leafEnv680 : List Nat := [1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,1,0,1,0,0,1,1,0,0]

def active680 : List Nat := []

def tree680 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood680 : H12WitnessSearch.Good tree680 := H12GlobalWitnessIndex.good

theorem leafIdentity680 : H12AffineFastState.composeSystem env680 rootObs = leafEnv680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env680 rootObs == leafEnv680) = true)

theorem terminalChecked680 : H12PackedTerminal.terminalCheckFast leafEnv680 active680 tree680 = true := by decide +kernel

def env681 : List Nat := [2,1,3,2,2,2,3,2,3,3,1,0,0,3,1,0,2,3,2,1,0,2,2,2,0,2,3,2,0,0,0,3,3,3,1,3]

theorem envBound681 : H12AffineFastState.Bounded env681 := by
  intro p hp
  have h : env681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans678_681 : H12AffineEnvironment.transform 1 1 env678 = env681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env678 == env681) = true)

def leafEnv681 : List Nat := [2,1,3,2,2,2,3,2,3,3,1,0,0,3,1,0,2,3,2,1,0,2,2,2,1,0,1,2,3,2,0,0,0,3,3,3,0,0,1,3,1,3,0]

def active681 : List Nat := [0]

def tree681 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood681 : H12WitnessSearch.Good tree681 := H12GlobalWitnessIndex.good

theorem leafIdentity681 : H12AffineFastState.composeSystem env681 rootObs = leafEnv681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env681 rootObs == leafEnv681) = true)

theorem terminalChecked681 : H12PackedTerminal.terminalCheckFast leafEnv681 active681 tree681 = true := by decide +kernel

def env682 : List Nat := [2,4,8,2,2,2,8,7,9,13,2048,0,11,2056,1,0,9,2,12,1,2048,2,2,2,11,2,2,9,0,2049,14,3,6,3,10,9]

theorem envBound682 : H12AffineFastState.Bounded env682 := by
  intro p hp
  have h : env682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans670_682 : H12AffineEnvironment.transform 8 9 env670 = env682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env670 == env682) = true)

theorem identity682 : scanCanonicalize (H12AffineFastState.compose env682 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound682 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env683 : List Nat := [2,4,8,2,2,2,8,7,9,13,2,0,11,10,1,0,9,2,12,1,2,2,2,2,11,2,2,9,0,3,14,3,6,3,10,9]

theorem envBound683 : H12AffineFastState.Bounded env683 := by
  intro p hp
  have h : env683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans682_683 : H12AffineEnvironment.transform 10 2 env682 = env683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env682 == env683) = true)

theorem identity683 : scanCanonicalize (H12AffineFastState.compose env683 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env684 : List Nat := [2,3,8,2,2,2,8,0,9,10,2,0,11,10,1,0,9,2,11,1,2,2,2,2,11,2,2,9,0,3,9,3,1,3,10,9]

theorem envBound684 : H12AffineFastState.Bounded env684 := by
  intro p hp
  have h : env684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans683_684 : H12AffineEnvironment.transform 1 3 env683 = env684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env683 == env684) = true)

theorem identity684 : scanCanonicalize (H12AffineFastState.compose env684 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound684 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env685 : List Nat := [2,3,0,2,2,2,0,0,1,2,2,0,3,2,1,0,1,2,3,1,2,2,2,2,3,2,2,1,0,3,1,3,1,3,2,1]

theorem envBound685 : H12AffineFastState.Bounded env685 := by
  intro p hp
  have h : env685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans684_685 : H12AffineEnvironment.transform 2 0 env684 = env685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env684 == env685) = true)

def leafEnv685 : List Nat := [2,3,0,2,2,2,0,0,1,2,2,0,3,2,1,0,1,2,3,1,2,2,2,2,0,3,1,2,2,1,0,3,1,3,1,3,2,0,2,1,1,3,0]

def active685 : List Nat := [0]

def tree685 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood685 : H12WitnessSearch.Good tree685 := H12GlobalWitnessIndex.good

theorem leafIdentity685 : H12AffineFastState.composeSystem env685 rootObs = leafEnv685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env685 rootObs == leafEnv685) = true)

theorem terminalChecked685 : H12PackedTerminal.terminalCheckFast leafEnv685 active685 tree685 = true := by decide +kernel

def env686 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,1,25,2560,1,18,26,523,30,1,2586,16,16,2,25,16,523,26,1,2049,14,17,20,17,11,512]

theorem envBound686 : H12AffineFastState.Bounded env686 := by
  intro p hp
  have h : env686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans668_686 : H12AffineEnvironment.transform 11 1 env668 = env686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env668 == env686) = true)

theorem identity686 : scanCanonicalize (H12AffineFastState.compose env686 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env687 : List Nat := [2,4,0,16,16,16,0,21,512,23,2048,1,17,2560,1,18,18,515,22,1,2578,16,16,2,17,16,515,18,1,2049,6,17,20,17,3,512]

theorem envBound687 : H12AffineFastState.Bounded env687 := by
  intro p hp
  have h : env687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans686_687 : H12AffineEnvironment.transform 2 0 env686 = env687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env686 == env687) = true)

def env688 : List Nat := [2,4,0,16,16,16,0,21,512,23,16,1,17,528,1,18,18,515,22,1,514,16,16,2,17,16,515,18,1,17,6,17,20,17,3,512]

theorem envBound688 : H12AffineFastState.Bounded env688 := by
  intro p hp
  have h : env688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans687_688 : H12AffineEnvironment.transform 10 16 env687 = env688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env687 == env688) = true)

theorem identity688 : scanCanonicalize (H12AffineFastState.compose env688 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound688 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env689 : List Nat := [2,4,0,16,16,16,0,21,19,23,16,1,17,3,1,18,18,16,22,1,17,16,16,2,17,16,16,18,1,17,6,17,20,17,3,19]

theorem envBound689 : H12AffineFastState.Bounded env689 := by
  intro p hp
  have h : env689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans688_689 : H12AffineEnvironment.transform 8 19 env688 = env689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env688 == env689) = true)

theorem identity689 : scanCanonicalize (H12AffineFastState.compose env689 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env690 : List Nat := [2,4,0,5,5,5,0,0,6,2,5,1,4,3,1,7,7,5,3,1,4,5,5,2,4,5,5,7,1,4,6,4,1,4,3,6]

theorem envBound690 : H12AffineFastState.Bounded env690 := by
  intro p hp
  have h : env690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans689_690 : H12AffineEnvironment.transform 3 5 env689 = env690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env689 == env690) = true)

theorem identity690 : scanCanonicalize (H12AffineFastState.compose env690 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound690 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env691 : List Nat := [2,2,0,3,3,3,0,0,0,2,3,1,2,3,1,1,1,3,3,1,2,3,3,2,2,3,3,1,1,2,0,2,1,2,3,0]

theorem envBound691 : H12AffineFastState.Bounded env691 := by
  intro p hp
  have h : env691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans690_691 : H12AffineEnvironment.transform 1 2 env690 = env691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env690 == env691) = true)

def leafEnv691 : List Nat := [2,2,0,3,3,3,0,0,0,2,3,1,2,3,1,1,1,3,3,1,2,3,3,2,1,2,1,3,3,1,1,2,0,2,1,2,3,1,3,0,1,3,0]

def active691 : List Nat := [0]

def tree691 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood691 : H12WitnessSearch.Good tree691 := H12GlobalWitnessIndex.good

theorem leafIdentity691 : H12AffineFastState.composeSystem env691 rootObs = leafEnv691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env691 rootObs == leafEnv691) = true)

theorem terminalChecked691 : H12PackedTerminal.terminalCheckFast leafEnv691 active691 tree691 = true := by decide +kernel

def env692 : List Nat := [2,4,0,16,16,16,0,21,512,23,17,1,17,529,1,18,18,515,22,1,515,16,16,2,17,16,515,18,1,16,6,17,20,17,3,512]

theorem envBound692 : H12AffineFastState.Bounded env692 := by
  intro p hp
  have h : env692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans687_692 : H12AffineEnvironment.transform 10 17 env687 = env692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env687 == env692) = true)

def env693 : List Nat := [2,4,0,16,16,16,0,21,16,23,17,1,17,1,1,18,18,19,22,1,19,16,16,2,17,16,19,18,1,16,6,17,20,17,3,16]

theorem envBound693 : H12AffineFastState.Bounded env693 := by
  intro p hp
  have h : env693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans692_693 : H12AffineEnvironment.transform 8 16 env692 = env693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env692 == env693) = true)

theorem identity693 : scanCanonicalize (H12AffineFastState.compose env693 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env694 : List Nat := [2,0,0,16,16,16,0,17,16,19,17,1,17,1,1,18,18,19,18,1,19,16,16,2,17,16,19,18,1,16,2,17,16,17,3,16]

theorem envBound694 : H12AffineFastState.Bounded env694 := by
  intro p hp
  have h : env694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans693_694 : H12AffineEnvironment.transform 1 0 env693 = env694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env693 == env694) = true)

def env695 : List Nat := [2,0,0,0,0,0,0,1,0,3,1,1,1,1,1,2,2,3,2,1,3,0,0,2,1,0,3,2,1,0,2,1,0,1,3,0]

theorem envBound695 : H12AffineFastState.Bounded env695 := by
  intro p hp
  have h : env695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans694_695 : H12AffineEnvironment.transform 3 0 env694 = env695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env694 == env695) = true)

def leafEnv695 : List Nat := [2,0,0,0,0,0,0,1,0,3,1,1,1,1,1,2,2,3,2,1,3,0,0,2,3,1,1,0,3,2,1,0,2,1,0,1,1,2,3,0,1,0,0]

def active695 : List Nat := [0]

def tree695 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood695 : H12WitnessSearch.Good tree695 := H12GlobalWitnessIndex.good

theorem leafIdentity695 : H12AffineFastState.composeSystem env695 rootObs = leafEnv695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env695 rootObs == leafEnv695) = true)

theorem terminalChecked695 : H12PackedTerminal.terminalCheckFast leafEnv695 active695 tree695 = true := by decide +kernel

def env696 : List Nat := [2,0,0,1,1,1,0,0,1,2,0,1,0,1,1,3,3,2,3,1,2,1,1,2,0,1,2,3,1,1,2,0,1,0,3,1]

theorem envBound696 : H12AffineFastState.Bounded env696 := by
  intro p hp
  have h : env696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans694_696 : H12AffineEnvironment.transform 3 1 env694 = env696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env694 == env696) = true)

theorem identity696 : scanCanonicalize (H12AffineFastState.compose env696 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound696 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env697 : List Nat := [1,0,0,1,1,1,0,0,1,1,0,1,0,1,1,0,0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1,0,0,1]

theorem envBound697 : H12AffineFastState.Bounded env697 := by
  intro p hp
  have h : env697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans696_697 : H12AffineEnvironment.transform 0 1 env696 = env697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env696 == env697) = true)

def leafEnv697 : List Nat := [1,0,0,1,1,1,0,0,1,1,0,1,0,1,1,0,0,1,0,1,1,1,1,1,0,0,1,1,1,0,1,1,1,0,1,0,1,0,0,1,1,1,0]

def active697 : List Nat := []

def tree697 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood697 : H12WitnessSearch.Good tree697 := H12GlobalWitnessIndex.good

theorem leafIdentity697 : H12AffineFastState.composeSystem env697 rootObs = leafEnv697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env697 rootObs == leafEnv697) = true)

theorem terminalChecked697 : H12PackedTerminal.terminalCheckFast leafEnv697 active697 tree697 = true := by decide +kernel

def env698 : List Nat := [2,4,0,16,16,16,0,21,17,23,17,1,17,0,1,18,18,18,22,1,18,16,16,2,17,16,18,18,1,16,6,17,20,17,3,17]

theorem envBound698 : H12AffineFastState.Bounded env698 := by
  intro p hp
  have h : env698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans692_698 : H12AffineEnvironment.transform 8 17 env692 = env698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env692 == env698) = true)

theorem identity698 : scanCanonicalize (H12AffineFastState.compose env698 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound698 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env699 : List Nat := [2,2,0,16,16,16,0,19,17,17,17,1,17,0,1,18,18,18,16,1,18,16,16,2,17,16,18,18,1,16,0,17,18,17,3,17]

theorem envBound699 : H12AffineFastState.Bounded env699 := by
  intro p hp
  have h : env699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans698_699 : H12AffineEnvironment.transform 1 2 env698 = env699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env698 == env699) = true)

def env700 : List Nat := [2,2,0,0,0,0,0,3,1,1,1,1,1,0,1,2,2,2,0,1,2,0,0,2,1,0,2,2,1,0,0,1,2,1,3,1]

theorem envBound700 : H12AffineFastState.Bounded env700 := by
  intro p hp
  have h : env700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans699_700 : H12AffineEnvironment.transform 3 0 env699 = env700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env699 == env700) = true)

theorem identity700 : scanCanonicalize (H12AffineFastState.compose env700 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound700 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env701 : List Nat := [0,0,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,1,0,1,1,1]

theorem envBound701 : H12AffineFastState.Bounded env701 := by
  intro p hp
  have h : env701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans700_701 : H12AffineEnvironment.transform 0 0 env700 = env701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env700 == env701) = true)

def leafEnv701 : List Nat := [0,0,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,1,1,0,0,0,1,0,0,1,0,1,1,0,1,1,1,0,0]

def active701 : List Nat := []

def tree701 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood701 : H12WitnessSearch.Good tree701 := H12GlobalWitnessIndex.good

theorem leafIdentity701 : H12AffineFastState.composeSystem env701 rootObs = leafEnv701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env701 rootObs == leafEnv701) = true)

theorem terminalChecked701 : H12PackedTerminal.terminalCheckFast leafEnv701 active701 tree701 = true := by decide +kernel

def env702 : List Nat := [2,2,0,1,1,1,0,2,0,0,0,1,0,0,1,3,3,3,1,1,3,1,1,2,0,1,3,3,1,1,0,0,3,0,3,0]

theorem envBound702 : H12AffineFastState.Bounded env702 := by
  intro p hp
  have h : env702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans699_702 : H12AffineEnvironment.transform 3 1 env699 = env702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env699 == env702) = true)

def leafEnv702 : List Nat := [2,2,0,1,1,1,0,2,0,0,0,1,0,0,1,3,3,3,1,1,3,1,1,2,1,0,1,1,3,3,1,1,0,0,3,0,3,3,3,0,1,1,0]

def active702 : List Nat := [0]

def tree702 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood702 : H12WitnessSearch.Good tree702 := H12GlobalWitnessIndex.good

theorem leafIdentity702 : H12AffineFastState.composeSystem env702 rootObs = leafEnv702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env702 rootObs == leafEnv702) = true)

theorem terminalChecked702 : H12PackedTerminal.terminalCheckFast leafEnv702 active702 tree702 = true := by decide +kernel

def env703 : List Nat := [2,4,8,16,32,17,9,37,512,46,2048,4096,40,6657,1,34,4122,522,46,1,6683,32,17,3,41,16,523,4122,4096,2048,14,32,37,32,4106,512]

theorem envBound703 : H12AffineFastState.Bounded env703 := by
  intro p hp
  have h : env703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans666_703 : H12AffineEnvironment.transform 5 17 env666 = env703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env666 == env703) = true)

theorem identity703 : scanCanonicalize (H12AffineFastState.compose env703 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound703 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env704 : List Nat := [2,4,8,16,32,17,9,37,512,46,570,4096,40,4155,1,34,4122,522,46,1,4129,32,17,3,41,16,523,4122,4096,570,14,32,37,32,4106,512]

theorem envBound704 : H12AffineFastState.Bounded env704 := by
  intro p hp
  have h : env704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans703_704 : H12AffineEnvironment.transform 10 570 env703 = env704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env703 == env704) = true)

def env705 : List Nat := [2,4,8,16,32,17,9,37,512,46,570,48,40,11,1,34,42,522,46,1,17,32,17,3,41,16,523,42,48,570,14,32,37,32,58,512]

theorem envBound705 : H12AffineFastState.Bounded env705 := by
  intro p hp
  have h : env705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans704_705 : H12AffineEnvironment.transform 11 48 env704 = env705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env704 == env705) = true)

theorem identity705 : scanCanonicalize (H12AffineFastState.compose env705 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 56) := by decide +kernel

theorem selectedBound705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env706 : List Nat := [2,4,8,16,32,17,9,37,56,46,2,48,40,11,1,34,42,50,46,1,17,32,17,3,41,16,51,42,48,2,14,32,37,32,58,56]

theorem envBound706 : H12AffineFastState.Bounded env706 := by
  intro p hp
  have h : env706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans705_706 : H12AffineEnvironment.transform 8 56 env705 = env706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 56 env705 == env706) = true)

def env707 : List Nat := [2,4,8,16,16,17,9,21,8,30,2,0,24,11,1,18,26,2,30,1,17,16,17,3,25,16,3,26,0,2,14,16,21,16,10,8]

theorem envBound707 : H12AffineFastState.Bounded env707 := by
  intro p hp
  have h : env707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans706_707 : H12AffineEnvironment.transform 4 16 env706 = env707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env706 == env707) = true)

theorem identity707 : scanCanonicalize (H12AffineFastState.compose env707 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env708 : List Nat := [2,4,8,2,2,3,9,7,8,12,2,0,10,11,1,0,8,2,12,1,3,2,3,3,11,2,3,8,0,2,14,2,7,2,10,8]

theorem envBound708 : H12AffineFastState.Bounded env708 := by
  intro p hp
  have h : env708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans707_708 : H12AffineEnvironment.transform 3 2 env707 = env708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env707 == env708) = true)

theorem identity708 : scanCanonicalize (H12AffineFastState.compose env708 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env709 : List Nat := [2,1,8,2,2,3,9,2,8,9,2,0,10,11,1,0,8,2,9,1,3,2,3,3,11,2,3,8,0,2,11,2,2,2,10,8]

theorem envBound709 : H12AffineFastState.Bounded env709 := by
  intro p hp
  have h : env709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans708_709 : H12AffineEnvironment.transform 1 1 env708 = env709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env708 == env709) = true)

def leafEnv709 : List Nat := [2,1,8,2,2,3,9,2,8,9,2,0,10,11,1,0,8,2,9,1,3,2,3,3,11,11,1,2,3,8,0,2,11,2,2,2,1,1,10,8,1,3,0]

def active709 : List Nat := [0,2]

def tree709 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood709 : H12WitnessSearch.Good tree709 := H12GlobalWitnessIndex.good

theorem leafIdentity709 : H12AffineFastState.composeSystem env709 rootObs = leafEnv709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env709 rootObs == leafEnv709) = true)

theorem terminalChecked709 : H12PackedTerminal.terminalCheckFast leafEnv709 active709 tree709 = true := by decide +kernel

def env710 : List Nat := [2,4,8,16,17,17,9,20,9,31,2,1,25,11,1,19,27,3,31,1,17,17,17,3,24,16,2,27,1,2,14,17,20,17,11,9]

theorem envBound710 : H12AffineFastState.Bounded env710 := by
  intro p hp
  have h : env710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans706_710 : H12AffineEnvironment.transform 4 17 env706 = env710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env706 == env710) = true)

theorem identity710 : scanCanonicalize (H12AffineFastState.compose env710 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound710 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env711 : List Nat := [2,4,0,16,17,17,1,20,1,23,2,1,17,3,1,19,19,3,23,1,17,17,17,3,16,16,2,19,1,2,6,17,20,17,3,1]

theorem envBound711 : H12AffineFastState.Bounded env711 := by
  intro p hp
  have h : env711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans710_711 : H12AffineEnvironment.transform 2 0 env710 = env711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env710 == env711) = true)

theorem identity711 : scanCanonicalize (H12AffineFastState.compose env711 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env712 : List Nat := [2,4,0,5,4,4,1,1,1,2,2,1,4,3,1,6,6,3,2,1,4,4,4,3,5,5,2,6,1,2,6,4,1,4,3,1]

theorem envBound712 : H12AffineFastState.Bounded env712 := by
  intro p hp
  have h : env712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0