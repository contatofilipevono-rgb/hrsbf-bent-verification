import H12CloudChart0Data041

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound10479 : H12AffineFastState.Bounded env10479 := by
  intro p hp
  have h : env10479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10478_10479 : H12AffineEnvironment.transform 17 67754 env10478 = env10479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env10478 == env10479) = true)

theorem identity10479 : scanCanonicalize (H12AffineFastState.compose env10479 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound10479 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env10480 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,30083,13340,32041,1025,29828,25628,21929,29725,138,8328,16,10509,24861,17665,2477,29056,8493,257,21793,16384,9092]

theorem envBound10480 : H12AffineFastState.Bounded env10480 := by
  intro p hp
  have h : env10480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10479_10480 : H12AffineEnvironment.transform 15 30083 env10479 = env10480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env10479 == env10480) = true)

theorem identity10480 : scanCanonicalize (H12AffineFastState.compose env10480 (packedSelected [1,5,8,16,17,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound10480 : packedSelected [1,5,8,16,17,20,24] rootPS < 2^1333 := by decide +kernel

def env10481 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,136,398,13340,2340,1025,137,4113,8612,16,138,8328,16,10509,5392,12556,2477,1421,8493,257,8492,13325,9092]

theorem envBound10481 : H12AffineFastState.Bounded env10481 := by
  intro p hp
  have h : env10481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10480_10481 : H12AffineEnvironment.transform 13 13325 env10480 = env10481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env10480 == env10481) = true)

theorem identity10481 : scanCanonicalize (H12AffineFastState.compose env10481 (packedSelected [0,1,2,3,4,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10481 : packedSelected [0,1,2,3,4,10,12] rootPS < 2^1333 := by decide +kernel

def env10482 : List Nat := [2,4,8,16,0,16,128,256,512,1024,2048,4096,8192,13325,136,398,13340,2308,1025,137,4113,8580,16,138,8328,16,10509,5392,12556,2445,1421,8461,257,8460,13325,9092]

theorem envBound10482 : H12AffineFastState.Bounded env10482 := by
  intro p hp
  have h : env10482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10481_10482 : H12AffineEnvironment.transform 4 0 env10481 = env10482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10481 == env10482) = true)

theorem identity10482 : scanCanonicalize (H12AffineFastState.compose env10482 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound10482 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env10483 : List Nat := [2,4,8,16,0,16,128,256,512,1024,2048,4096,388,5513,136,398,5528,2308,1025,137,4113,0,16,138,268,16,2185,5392,4232,2445,1421,137,257,136,5513,512]

theorem envBound10483 : H12AffineFastState.Bounded env10483 := by
  intro p hp
  have h : env10483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10482_10483 : H12AffineEnvironment.transform 12 388 env10482 = env10483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env10482 == env10483) = true)

theorem identity10483 : scanCanonicalize (H12AffineFastState.compose env10483 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound10483 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10484 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,8,5125,136,2,5140,2184,1025,137,4113,0,16,138,128,16,2185,5276,4232,2049,1025,137,141,136,5125,512]

theorem envBound10484 : H12AffineFastState.Bounded env10484 := by
  intro p hp
  have h : env10484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10483_10484 : H12AffineEnvironment.transform 7 140 env10483 = env10484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env10483 == env10484) = true)

def env10485 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82334,262144,1025,29829,2097152,272512,2101248,95497,8328,17,2177171,2098432,17665,2450714,2102684,2373657,257,21793,16385,2175514]

theorem envBound10485 : H12AffineFastState.Bounded env10485 := by
  intro p hp
  have h : env10485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10476_10485 : H12AffineEnvironment.transform 5 17 env10476 = env10485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10476 == env10485) = true)

theorem identity10485 : scanCanonicalize (H12AffineFastState.compose env10485 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound10485 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10486 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,399,16401,262144,1025,29829,2097152,272512,2101248,29830,8328,17,2111772,2098432,17665,2385045,2102684,2373657,257,21793,16385,2110357]

theorem envBound10486 : H12AffineFastState.Bounded env10486 := by
  intro p hp
  have h : env10486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10485_10486 : H12AffineEnvironment.transform 15 399 env10485 = env10486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env10485 == env10486) = true)

theorem identity10486 : scanCanonicalize (H12AffineFastState.compose env10486 (packedSelected [1,3,4,7,9,12,16,17,20,24,27,28,41] rootPS)) = affineNative (2^(20+1) ^^^ 25749) := by decide +kernel

theorem selectedBound10486 : packedSelected [1,3,4,7,9,12,16,17,20,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env10487 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,399,16401,262144,1025,29829,25749,272512,29845,29830,8328,17,23945,24981,17665,262144,28937,285836,257,21793,16385,22272]

theorem envBound10487 : H12AffineFastState.Bounded env10487 := by
  intro p hp
  have h : env10487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10486_10487 : H12AffineEnvironment.transform 20 25749 env10486 = env10487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25749 env10486 == env10487) = true)

theorem identity10487 : scanCanonicalize (H12AffineFastState.compose env10487 (packedSelected [1,3,4,5,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound10487 : packedSelected [1,3,4,5,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env10488 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,399,16401,32041,1025,29829,25749,21929,29845,29830,8328,17,23945,24981,17665,32041,28937,8613,257,21793,16385,22272]

theorem envBound10488 : H12AffineFastState.Bounded env10488 := by
  intro p hp
  have h : env10488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10487_10488 : H12AffineEnvironment.transform 17 32041 env10487 = env10488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env10487 == env10488) = true)

theorem identity10488 : scanCanonicalize (H12AffineFastState.compose env10488 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10488 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env10489 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,399,5392,10280,1025,8580,12692,168,8596,8583,8328,17,2184,13460,4096,10280,9224,8613,257,32,5376,513]

theorem envBound10489 : H12AffineFastState.Bounded env10489 := by
  intro p hp
  have h : env10489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10488_10489 : H12AffineEnvironment.transform 13 5377 env10488 = env10489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10488 == env10489) = true)

def env10490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177219,2098513,17665,2462110,2102684,2411676,257,21793,46213,2175563]

theorem envBound10490 : H12AffineFastState.Bounded env10490 := by
  intro p hp
  have h : env10490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10474_10490 : H12AffineEnvironment.transform 21 272513 env10474 = env10490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10474 == env10490) = true)

theorem identity10490 : scanCanonicalize (H12AffineFastState.compose env10490 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound10490 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,58517,272513,62660,98780,8328,64,121942,57796,17665,357643,61705,272393,257,21793,46213,120542]

theorem envBound10491 : H12AffineFastState.Bounded env10491 := by
  intro p hp
  have h : env10491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10490_10491 : H12AffineEnvironment.transform 20 58517 env10490 = env10491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env10490 == env10491) = true)

def env10492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,10280,1025,32769,58517,169,62660,98780,8328,64,121942,57796,17665,89379,61705,33,257,21793,46213,120542]

theorem envBound10492 : H12AffineFastState.Bounded env10492 := by
  intro p hp
  have h : env10492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10491_10492 : H12AffineEnvironment.transform 17 10280 env10491 = env10492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10491 == env10492) = true)

theorem identity10492 : scanCanonicalize (H12AffineFastState.compose env10492 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10492 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40970,57797,10280,1025,32769,58517,169,62660,8662,8328,64,31836,57796,17665,64809,61705,33,257,21793,46213,30420]

theorem envBound10493 : H12AffineFastState.Bounded env10493 := by
  intro p hp
  have h : env10493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10492_10493 : H12AffineEnvironment.transform 15 40970 env10492 = env10493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10492 == env10493) = true)

theorem identity10493 : scanCanonicalize (H12AffineFastState.compose env10493 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10493 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env10494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,10280,1025,32769,58396,32,62541,8543,8193,64,31836,57677,17665,64809,61705,33,257,21793,46092,30301]

theorem envBound10494 : H12AffineFastState.Bounded env10494 := by
  intro p hp
  have h : env10494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10493_10494 : H12AffineEnvironment.transform 6 9 env10493 = env10494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10493 == env10494) = true)

theorem identity10494 : scanCanonicalize (H12AffineFastState.compose env10494 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10494 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40970,38160,10280,1025,32769,36928,32,32785,8543,8193,64,2048,38161,12637,35189,34133,33,257,8573,46092,513]

theorem envBound10495 : H12AffineFastState.Bounded env10495 := by
  intro p hp
  have h : env10495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10494_10495 : H12AffineEnvironment.transform 13 13404 env10494 = env10495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10494 == env10495) = true)

theorem identity10495 : scanCanonicalize (H12AffineFastState.compose env10495 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10495 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10496 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,40970,38160,10280,1025,32769,36881,32,32785,8462,8193,17,2048,38161,12556,35108,34052,33,257,8492,46092,513]

theorem envBound10496 : H12AffineFastState.Bounded env10496 := by
  intro p hp
  have h : env10496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10495_10496 : H12AffineEnvironment.transform 5 17 env10495 = env10496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10495 == env10496) = true)

theorem identity10496 : scanCanonicalize (H12AffineFastState.compose env10496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10497 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,8202,5392,10280,1025,1,4113,32,17,8462,8193,17,2048,5393,12556,2340,1284,33,257,8492,13324,513]

theorem envBound10497 : H12AffineFastState.Bounded env10497 := by
  intro p hp
  have h : env10497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10496_10497 : H12AffineEnvironment.transform 14 0 env10496 = env10497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10496 == env10497) = true)

theorem identity10497 : scanCanonicalize (H12AffineFastState.compose env10497 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound10497 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env10498 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,805,8192,10024,0,8202,1589,10280,1025,1,820,32,17,8462,8193,17,2048,1588,8745,2340,1284,33,257,8492,10025,513]

theorem envBound10498 : H12AffineFastState.Bounded env10498 := by
  intro p hp
  have h : env10498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10497_10498 : H12AffineEnvironment.transform 11 805 env10497 = env10498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env10497 == env10498) = true)

theorem identity10498 : scanCanonicalize (H12AffineFastState.compose env10498 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10498 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10499 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,805,268,1572,0,262,1589,2340,1025,1,820,32,17,2,269,17,2048,1588,805,2340,1284,33,257,32,1573,513]

theorem envBound10499 : H12AffineFastState.Bounded env10499 := by
  intro p hp
  have h : env10499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10498_10499 : H12AffineEnvironment.transform 12 268 env10498 = env10499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10498 == env10499) = true)

theorem identity10499 : scanCanonicalize (H12AffineFastState.compose env10499 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10500 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,545,8,1572,0,2,1589,2080,1025,1,560,32,17,2,9,17,2048,1588,545,2080,1024,33,5,32,1573,513]

theorem envBound10500 : H12AffineFastState.Bounded env10500 := by
  intro p hp
  have h : env10500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10499_10500 : H12AffineEnvironment.transform 7 4 env10499 = env10500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10499 == env10500) = true)

theorem identity10500 : scanCanonicalize (H12AffineFastState.compose env10500 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound10500 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10501 : List Nat := [2,4,8,16,32,17,9,4,512,1024,554,545,8,1572,0,2,1589,522,1025,1,560,32,17,2,9,17,554,1588,545,522,1024,33,5,32,1573,513]

theorem envBound10501 : H12AffineFastState.Bounded env10501 := by
  intro p hp
  have h : env10501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10500_10501 : H12AffineEnvironment.transform 10 554 env10500 = env10501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env10500 == env10501) = true)

theorem identity10501 : scanCanonicalize (H12AffineFastState.compose env10501 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10501 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10502 : List Nat := [2,4,8,16,32,17,9,4,33,1024,11,0,8,1029,0,2,1044,43,1025,1,17,32,17,2,9,17,11,1045,0,43,1024,33,5,32,1028,32]

theorem envBound10502 : H12AffineFastState.Bounded env10502 := by
  intro p hp
  have h : env10502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10501_10502 : H12AffineEnvironment.transform 8 33 env10501 = env10502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10501 == env10502) = true)

theorem identity10502 : scanCanonicalize (H12AffineFastState.compose env10502 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10502 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10503 : List Nat := [2,4,8,16,32,17,9,4,33,53,11,0,8,48,0,2,33,43,52,1,17,32,17,2,9,17,11,32,0,43,53,33,5,32,49,32]

theorem envBound10503 : H12AffineFastState.Bounded env10503 := by
  intro p hp
  have h : env10503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10502_10503 : H12AffineEnvironment.transform 9 53 env10502 = env10503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10502 == env10503) = true)

theorem identity10503 : scanCanonicalize (H12AffineFastState.compose env10503 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound10503 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10504 : List Nat := [2,4,8,16,13,17,9,4,12,24,11,0,8,29,0,2,12,6,25,1,17,13,17,2,9,17,11,13,0,6,24,12,5,13,28,13]

theorem envBound10504 : H12AffineFastState.Bounded env10504 := by
  intro p hp
  have h : env10504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10503_10504 : H12AffineEnvironment.transform 4 13 env10503 = env10504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env10503 == env10504) = true)

theorem identity10504 : scanCanonicalize (H12AffineFastState.compose env10504 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound10504 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10505 : List Nat := [2,4,5,16,0,17,4,4,1,21,6,0,5,16,0,2,1,6,20,1,17,0,17,2,4,17,6,0,0,6,21,1,5,0,17,0]

theorem envBound10505 : H12AffineFastState.Bounded env10505 := by
  intro p hp
  have h : env10505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10504_10505 : H12AffineEnvironment.transform 2 5 env10504 = env10505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env10504 == env10505) = true)

theorem identity10505 : scanCanonicalize (H12AffineFastState.compose env10505 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10506 : List Nat := [0,4,5,16,0,17,4,4,1,21,4,0,5,16,0,0,1,4,20,1,17,0,17,0,4,17,4,0,0,4,21,1,5,0,17,0]

theorem envBound10506 : H12AffineFastState.Bounded env10506 := by
  intro p hp
  have h : env10506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10505_10506 : H12AffineEnvironment.transform 0 0 env10505 = env10506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10505 == env10506) = true)

def env10507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,10281,1025,32769,58517,168,62660,98780,8328,64,121942,57796,17665,89378,61705,32,257,21793,46213,120542]

theorem envBound10507 : H12AffineFastState.Bounded env10507 := by
  intro p hp
  have h : env10507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10491_10507 : H12AffineEnvironment.transform 17 10281 env10491 = env10507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10491 == env10507) = true)

theorem identity10507 : scanCanonicalize (H12AffineFastState.compose env10507 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound10507 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1331,17660,10281,1025,32769,58517,168,62660,34031,8328,64,55653,57796,17665,22545,61705,32,257,21793,46213,54253]

theorem envBound10508 : H12AffineFastState.Bounded env10508 := by
  intro p hp
  have h : env10508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10507_10508 : H12AffineEnvironment.transform 15 1331 env10507 = env10508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env10507 == env10508) = true)

theorem identity10508 : scanCanonicalize (H12AffineFastState.compose env10508 (packedSelected [1,3,5,15,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound10508 : packedSelected [1,3,5,15,26,28,38] rootPS < 2^1333 := by decide +kernel

def env10509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,293,1331,17660,10281,1025,292,26032,168,30177,1482,8328,64,22592,24801,17665,22545,28716,32,257,21793,13728,21192]

theorem envBound10509 : H12AffineFastState.Bounded env10509 := by
  intro p hp
  have h : env10509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10508_10509 : H12AffineEnvironment.transform 14 293 env10508 = env10509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env10508 == env10509) = true)

theorem identity10509 : scanCanonicalize (H12AffineFastState.compose env10509 (packedSelected [4,5,7,9,10,12,15,17,18,19,23,24,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound10509 : packedSelected [4,5,7,9,10,12,15,17,18,19,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env10510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,293,1331,17660,3392,1025,292,16601,168,20616,1482,1505,64,22592,17800,17665,22545,21829,32,257,21793,4297,21192]

theorem envBound10510 : H12AffineFastState.Bounded env10510 := by
  intro p hp
  have h : env10510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10509_10510 : H12AffineEnvironment.transform 12 1385 env10509 = env10510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env10509 == env10510) = true)

theorem identity10510 : scanCanonicalize (H12AffineFastState.compose env10510 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10510 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env10511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,16384,293,1331,17525,3392,1025,292,16464,33,20481,1347,1384,64,22592,17665,17665,22545,21829,32,257,21793,4160,21057]

theorem envBound10511 : H12AffineFastState.Bounded env10511 := by
  intro p hp
  have h : env10511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10510_10511 : H12AffineEnvironment.transform 6 9 env10510 = env10511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10510 == env10511) = true)

theorem identity10511 : scanCanonicalize (H12AffineFastState.compose env10511 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10511 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10512 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1336,16384,293,1331,17444,3345,1025,292,16385,33,20481,1298,1337,17,22545,17665,17665,22545,21780,32,257,21793,4113,21008]

theorem envBound10512 : H12AffineFastState.Bounded env10512 := by
  intro p hp
  have h : env10512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10511_10512 : H12AffineEnvironment.transform 5 17 env10511 = env10512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10511 == env10512) = true)

def env10513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound10513 : H12AffineFastState.Bounded env10513 := by
  intro p hp
  have h : env10513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9859_10513 : H12AffineEnvironment.transform 25 65 env9859 = env10513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env9859 == env10513) = true)

def env10514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound10514 : H12AffineFastState.Bounded env10514 := by
  intro p hp
  have h : env10514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10513_10514 : H12AffineEnvironment.transform 26 30393344 env10513 = env10514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env10513 == env10514) = true)

def env10515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound10515 : H12AffineFastState.Bounded env10515 := by
  intro p hp
  have h : env10515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10514_10515 : H12AffineEnvironment.transform 18 1024 env10514 = env10515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10514 == env10515) = true)

theorem identity10515 : scanCanonicalize (H12AffineFastState.compose env10515 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493614) := by decide +kernel

theorem selectedBound10515 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493614,8328,65,14797998,493602,10507601,8830976,10979518,4680046,256,8898562,8858022,10923881]

theorem envBound10516 : H12AffineFastState.Bounded env10516 := by
  intro p hp
  have h : env10516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10515_10516 : H12AffineEnvironment.transform 23 2493614 env10515 = env10516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493614 env10515 == env10516) = true)

def env10517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797998,115150,10507601,8423916,10600786,4268162,256,8487406,8478794,10544773]

theorem envBound10517 : H12AffineFastState.Bounded env10517 := by
  intro p hp
  have h : env10517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10516_10517 : H12AffineEnvironment.transform 17 149996 env10516 = env10517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env10516 == env10517) = true)

def env10518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,8388608,21762,8328,65,12705006,115150,8406289,8423916,8507666,4268162,256,8487406,8478794,8451781]

theorem envBound10518 : H12AffineFastState.Bounded env10518 := by
  intro p hp
  have h : env10518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10517_10518 : H12AffineEnvironment.transform 20 4160 env10517 = env10518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10517 == env10518) = true)

def env10519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,16,21762,8328,65,4316414,115150,17665,35324,119042,4268162,256,98814,90202,63189]

theorem envBound10519 : H12AffineFastState.Bounded env10519 := by
  intro p hp
  have h : env10519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10518_10519 : H12AffineEnvironment.transform 22 16 env10518 = env10519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env10518 == env10519) = true)

theorem identity10519 : scanCanonicalize (H12AffineFastState.compose env10519 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound10519 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149996,1024,29909,4160,4194304,16,21762,8328,65,4270122,79130,17665,32040,75222,4268162,256,95530,90202,513]

theorem envBound10520 : H12AffineFastState.Bounded env10520 := by
  intro p hp
  have h : env10520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10519_10520 : H12AffineEnvironment.transform 14 29908 env10519 = env10520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env10519 == env10520) = true)

def env10521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138476,1024,8661,4160,4194304,16,2,8328,65,4270122,79130,4097,10280,75222,4268162,256,73770,79194,513]

theorem envBound10521 : H12AffineFastState.Bounded env10521 := by
  intro p hp
  have h : env10521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10520_10521 : H12AffineEnvironment.transform 13 5376 env10520 = env10521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10520 == env10521) = true)

theorem identity10521 : scanCanonicalize (H12AffineFastState.compose env10521 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound10521 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,10280,1024,8661,4160,4194304,16,2,8328,65,4270122,79130,4097,10280,75222,4268162,256,73770,79194,513]

theorem envBound10522 : H12AffineFastState.Bounded env10522 := by
  intro p hp
  have h : env10522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10521_10522 : H12AffineEnvironment.transform 16 13508 env10521 = env10522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env10521 == env10522) = true)

def env10523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138477,1024,8660,4160,4194304,16,3,8328,65,4270122,79130,4096,10281,75222,4268162,256,73771,79195,513]

theorem envBound10523 : H12AffineFastState.Bounded env10523 := by
  intro p hp
  have h : env10523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10520_10523 : H12AffineEnvironment.transform 13 5377 env10520 = env10523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10520 == env10523) = true)

theorem identity10523 : scanCanonicalize (H12AffineFastState.compose env10523 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound10523 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,10401,1024,8660,4160,4194304,16,3,8328,65,4270122,79130,4096,10281,75222,4268162,256,73771,79195,513]

theorem envBound10524 : H12AffineFastState.Bounded env10524 := by
  intro p hp
  have h : env10524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10523_10524 : H12AffineEnvironment.transform 16 13388 env10523 = env10524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env10523 == env10524) = true)

theorem identity10524 : scanCanonicalize (H12AffineFastState.compose env10524 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound10524 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env10525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,10401,1024,8660,4160,73891,16,3,8328,65,2185,79130,4096,10281,75222,33,256,73771,79195,513]

theorem envBound10525 : H12AffineFastState.Bounded env10525 := by
  intro p hp
  have h : env10525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10524_10525 : H12AffineEnvironment.transform 21 73891 env10524 = env10525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env10524 == env10525) = true)

theorem identity10525 : scanCanonicalize (H12AffineFastState.compose env10525 (packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound10525 : packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env10526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,342,13388,10401,1024,8660,4160,8693,16,3,8328,65,2185,13388,4096,10281,9344,33,256,8573,13325,513]

theorem envBound10526 : H12AffineFastState.Bounded env10526 := by
  intro p hp
  have h : env10526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10525_10526 : H12AffineEnvironment.transform 15 342 env10525 = env10526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env10525 == env10526) = true)

theorem identity10526 : scanCanonicalize (H12AffineFastState.compose env10526 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound10526 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env10527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,342,5528,2421,1024,0,4160,33,16,3,348,65,2185,5528,4096,2557,1364,33,256,169,5593,513]

theorem envBound10527 : H12AffineFastState.Bounded env10527 := by
  intro p hp
  have h : env10527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10526_10527 : H12AffineEnvironment.transform 12 468 env10526 = env10527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env10526 == env10527) = true)

theorem identity10527 : scanCanonicalize (H12AffineFastState.compose env10527 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10527 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env10528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,1,262,5528,2341,1024,0,4112,33,16,3,268,17,2185,5528,4096,2477,1284,33,256,169,5513,513]

theorem envBound10528 : H12AffineFastState.Bounded env10528 := by
  intro p hp
  have h : env10528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10527_10528 : H12AffineEnvironment.transform 5 16 env10527 = env10528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10527 == env10528) = true)

theorem identity10528 : scanCanonicalize (H12AffineFastState.compose env10528 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10528 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10529 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5393,2341,1024,0,4112,33,16,3,268,17,2048,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound10529 : H12AffineFastState.Bounded env10529 := by
  intro p hp
  have h : env10529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10528_10529 : H12AffineEnvironment.transform 6 9 env10528 = env10529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10528 == env10529) = true)

theorem identity10529 : scanCanonicalize (H12AffineFastState.compose env10529 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound10529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10530 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,277,269,1044,1,262,1028,2341,1024,0,261,33,16,3,268,17,2048,1028,277,2340,1284,33,256,32,1045,513]

theorem envBound10530 : H12AffineFastState.Bounded env10530 := by
  intro p hp
  have h : env10530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10529_10530 : H12AffineEnvironment.transform 11 277 env10529 = env10530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env10529 == env10530) = true)

theorem identity10530 : scanCanonicalize (H12AffineFastState.compose env10530 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10531 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,277,269,1044,1,262,1028,2308,1024,0,261,0,16,3,268,17,2048,1028,277,2309,1284,0,256,1,1045,513]

theorem envBound10531 : H12AffineFastState.Bounded env10531 := by
  intro p hp
  have h : env10531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10530_10531 : H12AffineEnvironment.transform 4 1 env10530 = env10531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10530 == env10531) = true)

theorem identity10531 : scanCanonicalize (H12AffineFastState.compose env10531 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound10531 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10532 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1557,277,269,1044,1,262,1028,1809,1024,0,261,0,16,3,268,17,1557,1028,277,1808,1284,0,256,1,1045,513]

theorem envBound10532 : H12AffineFastState.Bounded env10532 := by
  intro p hp
  have h : env10532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10531_10532 : H12AffineEnvironment.transform 10 1557 env10531 = env10532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env10531 == env10532) = true)

theorem identity10532 : scanCanonicalize (H12AffineFastState.compose env10532 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound10532 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10533 : List Nat := [2,4,8,16,1,16,9,21,512,1024,1557,0,24,1044,1,19,1028,1540,1024,0,16,0,16,3,25,17,1557,1028,0,1541,1041,0,21,1,1045,513]

theorem envBound10533 : H12AffineFastState.Bounded env10533 := by
  intro p hp
  have h : env10533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10532_10533 : H12AffineEnvironment.transform 7 21 env10532 = env10533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env10532 == env10533) = true)

theorem identity10533 : scanCanonicalize (H12AffineFastState.compose env10533 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10533 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10534 : List Nat := [2,4,8,16,1,16,9,21,0,1024,1045,0,24,1044,1,19,1028,1028,1024,0,16,0,16,3,25,17,1045,1028,0,1029,1041,0,21,1,1045,1]

theorem envBound10534 : H12AffineFastState.Bounded env10534 := by
  intro p hp
  have h : env10534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10533_10534 : H12AffineEnvironment.transform 8 0 env10533 = env10534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10533 == env10534) = true)

theorem identity10534 : scanCanonicalize (H12AffineFastState.compose env10534 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10534 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10535 : List Nat := [2,4,8,1,1,1,9,4,0,1024,1028,0,9,1029,1,2,1028,1028,1024,0,1,0,1,3,8,0,1028,1028,0,1029,1024,0,4,1,1028,1]

theorem envBound10535 : H12AffineFastState.Bounded env10535 := by
  intro p hp
  have h : env10535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10534_10535 : H12AffineEnvironment.transform 3 1 env10534 = env10535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10534 == env10535) = true)

def env10536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,17,21762,8328,65,4316415,115150,17664,35325,119043,4268162,256,98815,90203,63188]

theorem envBound10536 : H12AffineFastState.Bounded env10536 := by
  intro p hp
  have h : env10536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10518_10536 : H12AffineEnvironment.transform 22 17 env10518 = env10536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env10518 == env10536) = true)

theorem identity10536 : scanCanonicalize (H12AffineFastState.compose env10536 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound10536 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,156012,17,21762,8328,65,245139,115150,17664,35325,119043,213486,256,98815,90203,63188]

theorem envBound10537 : H12AffineFastState.Bounded env10537 := by
  intro p hp
  have h : env10537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10536_10537 : H12AffineEnvironment.transform 21 156012 env10536 = env10537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env10536 == env10537) = true)

def env10538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,156012,17,21762,8192,65,245019,115014,17664,35189,119043,213350,256,98679,90203,63068]

theorem envBound10538 : H12AffineFastState.Bounded env10538 := by
  intro p hp
  have h : env10538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10537_10538 : H12AffineEnvironment.transform 6 8 env10537 = env10538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10537 == env10538) = true)

theorem identity10538 : scanCanonicalize (H12AffineFastState.compose env10538 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10538 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138340,1024,32769,4160,144492,17,2,8192,65,245019,103494,4096,35189,99331,201830,256,98679,79195,41820]

theorem envBound10539 : H12AffineFastState.Bounded env10539 := by
  intro p hp
  have h : env10539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10538_10539 : H12AffineEnvironment.transform 13 5376 env10538 = env10539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10538 == env10539) = true)

theorem identity10539 : scanCanonicalize (H12AffineFastState.compose env10539 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10539 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env10540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,65536,131072,138340,1024,8460,4160,144492,17,2,8192,65,203798,79179,4096,10360,75022,201830,256,73850,79195,593]

theorem envBound10540 : H12AffineFastState.Bounded env10540 := by
  intro p hp
  have h : env10540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10539_10540 : H12AffineEnvironment.transform 14 8461 env10539 = env10540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10539 == env10540) = true)

theorem identity10540 : scanCanonicalize (H12AffineFastState.compose env10540 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10540 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env10541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8202,131072,138340,1024,8460,4160,144492,17,2,8192,65,146460,5441,4096,10360,1284,144492,256,112,5457,593]

theorem envBound10541 : H12AffineFastState.Bounded env10541 := by
  intro p hp
  have h : env10541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10540_10541 : H12AffineEnvironment.transform 15 8202 env10540 = env10541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10540 == env10541) = true)

theorem identity10541 : scanCanonicalize (H12AffineFastState.compose env10541 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10541 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env10542 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5157,8232,8202,131072,138340,1024,8233,4160,144492,17,2,8192,65,146460,5220,4096,10360,1057,144492,37,112,5236,593]

theorem envBound10542 : H12AffineFastState.Bounded env10542 := by
  intro p hp
  have h : env10542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10541_10542 : H12AffineEnvironment.transform 7 37 env10541 = env10542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10541 == env10542) = true)

theorem identity10542 : scanCanonicalize (H12AffineFastState.compose env10542 (packedSelected [2,3,4,5,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10542 : packedSelected [2,3,4,5,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10543 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,81,115,131072,138340,1024,80,4160,136213,17,2,121,65,138341,5220,4096,2049,1057,136213,37,112,5236,593]

theorem envBound10543 : H12AffineFastState.Bounded env10543 := by
  intro p hp
  have h : env10543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10542_10543 : H12AffineEnvironment.transform 12 121 env10542 = env10543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10542 == env10543) = true)

theorem identity10543 : scanCanonicalize (H12AffineFastState.compose env10543 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound10543 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10544 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,81,115,5220,2048,1024,80,4160,113,17,2,121,65,2049,5220,4096,2049,1057,113,37,112,5236,593]

theorem envBound10544 : H12AffineFastState.Bounded env10544 := by
  intro p hp
  have h : env10544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10543_10544 : H12AffineEnvironment.transform 16 5220 env10543 = env10544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env10543 == env10544) = true)

def env10545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156012,17,21762,8193,65,245018,115015,17664,35188,119043,213351,256,98678,90203,63069]

theorem envBound10545 : H12AffineFastState.Bounded env10545 := by
  intro p hp
  have h : env10545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10537_10545 : H12AffineEnvironment.transform 6 9 env10537 = env10545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10537 == env10545) = true)

theorem identity10545 : scanCanonicalize (H12AffineFastState.compose env10545 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound10545 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1024,29789,4160,156012,17,21762,8193,65,215366,79131,17664,32040,75103,213351,256,95530,90203,513]

theorem envBound10546 : H12AffineFastState.Bounded env10546 := by
  intro p hp
  have h : env10546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10545_10546 : H12AffineEnvironment.transform 14 29788 env10545 = env10546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10545 == env10546) = true)

theorem identity10546 : scanCanonicalize (H12AffineFastState.compose env10546 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10546 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76158,1024,29789,4160,65911,17,21762,8193,65,10589,79131,17664,32040,75103,8572,256,95530,90203,513]

theorem envBound10547 : H12AffineFastState.Bounded env10547 := by
  intro p hp
  have h : env10547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10546_10547 : H12AffineEnvironment.transform 16 90139 env10546 = env10547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10546 == env10547) = true)

theorem identity10547 : scanCanonicalize (H12AffineFastState.compose env10547 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound10547 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5393,23668,1024,29789,4160,29821,17,21762,8193,65,10589,16401,17664,32040,20565,8572,256,32,5457,513]

theorem envBound10548 : H12AffineFastState.Bounded env10548 := by
  intro p hp
  have h : env10548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10547_10548 : H12AffineEnvironment.transform 15 29962 env10547 = env10548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env10547 == env10548) = true)

theorem identity10548 : scanCanonicalize (H12AffineFastState.compose env10548 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound10548 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,343,5393,10281,1024,0,4160,32,17,8543,8193,65,10589,13388,12637,2421,9224,8572,256,32,5457,513]

theorem envBound10549 : H12AffineFastState.Bounded env10549 := by
  intro p hp
  have h : env10549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10548_10549 : H12AffineEnvironment.transform 13 13405 env10548 = env10549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env10548 == env10549) = true)

theorem identity10549 : scanCanonicalize (H12AffineFastState.compose env10549 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound10549 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4113,1,343,5393,3173,1024,0,4160,32,17,1299,1101,65,3345,4096,5393,2421,68,1328,256,32,5457,513]

theorem envBound10550 : H12AffineFastState.Bounded env10550 := by
  intro p hp
  have h : env10550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10549_10550 : H12AffineEnvironment.transform 12 1100 env10549 = env10550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env10549 == env10550) = true)

theorem identity10550 : scanCanonicalize (H12AffineFastState.compose env10550 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10550 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,4096,1100,4113,1,343,5393,1125,1024,0,4160,32,17,1299,1101,65,1297,4096,5393,373,68,1328,256,32,5457,513]

theorem envBound10551 : H12AffineFastState.Bounded env10551 := by
  intro p hp
  have h : env10551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10550_10551 : H12AffineEnvironment.transform 10 0 env10550 = env10551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10550 == env10551) = true)

theorem identity10551 : scanCanonicalize (H12AffineFastState.compose env10551 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10551 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10552 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,4096,120,4113,1,343,4389,81,52,0,4160,32,17,295,121,65,293,4096,4389,373,68,260,256,32,4453,513]

theorem envBound10552 : H12AffineFastState.Bounded env10552 := by
  intro p hp
  have h : env10552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10551_10552 : H12AffineEnvironment.transform 9 52 env10551 = env10552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10551 == env10552) = true)

theorem identity10552 : scanCanonicalize (H12AffineFastState.compose env10552 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound10552 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env10553 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,308,120,293,1,343,17,81,52,0,372,32,17,295,121,65,293,308,17,373,68,260,256,32,81,513]

theorem envBound10553 : H12AffineFastState.Bounded env10553 := by
  intro p hp
  have h : env10553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10552_10553 : H12AffineEnvironment.transform 11 308 env10552 = env10553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env10552 == env10553) = true)

theorem identity10553 : scanCanonicalize (H12AffineFastState.compose env10553 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10553 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env10554 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,308,41,293,1,262,17,0,52,0,293,32,17,295,40,16,293,308,17,292,21,260,256,32,0,513]

theorem envBound10554 : H12AffineFastState.Bounded env10554 := by
  intro p hp
  have h : env10554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10553_10554 : H12AffineEnvironment.transform 5 17 env10553 = env10554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10553 == env10554) = true)

theorem identity10554 : scanCanonicalize (H12AffineFastState.compose env10554 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound10554 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env10555 : List Nat := [2,4,8,16,32,17,9,256,16,52,0,308,41,293,1,262,17,0,52,0,293,32,17,295,40,16,293,308,17,292,21,260,256,32,0,17]

theorem envBound10555 : H12AffineFastState.Bounded env10555 := by
  intro p hp
  have h : env10555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10554_10555 : H12AffineEnvironment.transform 8 16 env10554 = env10555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env10554 == env10555) = true)

theorem identity10555 : scanCanonicalize (H12AffineFastState.compose env10555 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10555 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10556 : List Nat := [2,4,8,16,32,17,9,36,16,52,0,16,41,1,1,34,17,0,52,0,1,32,17,3,40,16,1,16,17,0,21,32,36,32,0,17]

theorem envBound10556 : H12AffineFastState.Bounded env10556 := by
  intro p hp
  have h : env10556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10555_10556 : H12AffineEnvironment.transform 7 36 env10555 = env10556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10555 == env10556) = true)

theorem identity10556 : scanCanonicalize (H12AffineFastState.compose env10556 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10557 : List Nat := [2,4,8,16,17,17,9,21,16,5,0,16,24,1,1,19,17,0,5,0,1,17,17,3,25,16,1,16,17,0,21,17,21,17,0,17]

theorem envBound10557 : H12AffineFastState.Bounded env10557 := by
  intro p hp
  have h : env10557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10556_10557 : H12AffineEnvironment.transform 4 17 env10556 = env10557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10556 == env10557) = true)

theorem identity10557 : scanCanonicalize (H12AffineFastState.compose env10557 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10557 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10558 : List Nat := [2,4,8,1,0,0,9,4,1,5,0,1,9,1,1,2,0,0,5,0,1,0,0,3,8,1,1,1,0,0,4,0,4,0,0,0]

theorem envBound10558 : H12AffineFastState.Bounded env10558 := by
  intro p hp
  have h : env10558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10557_10558 : H12AffineEnvironment.transform 3 1 env10557 = env10558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10557 == env10558) = true)

def env10559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,8388608,21763,8328,65,12705007,115150,8406288,8423916,8507667,4268162,256,8487406,8478794,8451780]

theorem envBound10559 : H12AffineFastState.Bounded env10559 := by
  intro p hp
  have h : env10559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10517_10559 : H12AffineEnvironment.transform 20 4161 env10517 = env10559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10517 == env10559) = true)

def env10560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,16,21763,8328,65,4316415,115150,17664,35324,119043,4268162,256,98814,90202,63188]

theorem envBound10560 : H12AffineFastState.Bounded env10560 := by
  intro p hp
  have h : env10560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10559_10560 : H12AffineEnvironment.transform 22 16 env10559 = env10560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env10559 == env10560) = true)

def env10561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,16,21763,8192,65,4316279,115014,17664,35188,119043,4268042,256,98678,90202,63068]

theorem envBound10561 : H12AffineFastState.Bounded env10561 := by
  intro p hp
  have h : env10561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10560_10561 : H12AffineEnvironment.transform 6 8 env10560 = env10561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10560 == env10561) = true)

theorem identity10561 : scanCanonicalize (H12AffineFastState.compose env10561 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound10561 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32041,1024,32769,4161,4194304,16,21763,8192,65,4316279,115014,17664,35188,119043,4268042,256,98678,90202,63068]

theorem envBound10562 : H12AffineFastState.Bounded env10562 := by
  intro p hp
  have h : env10562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10561_10562 : H12AffineEnvironment.transform 16 13389 env10561 = env10562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env10561 == env10562) = true)

theorem identity10562 : scanCanonicalize (H12AffineFastState.compose env10562 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound10562 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env10563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,13389,32041,1024,32769,4161,4194304,16,21763,8192,65,4229153,38160,17664,35188,34133,4224092,256,54560,13324,63068]

theorem envBound10563 : H12AffineFastState.Bounded env10563 := by
  intro p hp
  have h : env10563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10562_10563 : H12AffineEnvironment.transform 15 21590 env10562 = env10563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env10562 == env10563) = true)

theorem identity10563 : scanCanonicalize (H12AffineFastState.compose env10563 (packedSelected [4,5,9,11,12,14,16,18,23,24,26,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound10563 : packedSelected [4,5,9,11,12,14,16,18,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env10564 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,8575,13389,2048,1024,32769,4161,4194304,16,8234,8192,65,4229153,38160,12329,35188,34133,4194677,256,40969,13324,33653]

theorem envBound10564 : H12AffineFastState.Bounded env10564 := by
  intro p hp
  have h : env10564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10563_10564 : H12AffineEnvironment.transform 13 13609 env10563 = env10564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env10563 == env10564) = true)

theorem identity10564 : scanCanonicalize (H12AffineFastState.compose env10564 (packedSelected [1,2,3,5,6,7,8,9,10,20,22,23,26,27,32] rootPS)) = affineNative (2^(21+1) ^^^ 33109) := by decide +kernel

theorem selectedBound10564 : packedSelected [1,2,3,5,6,7,8,9,10,20,22,23,26,27,32] rootPS < 2^1333 := by decide +kernel

def env10565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,8575,13389,2048,1024,32769,4161,33109,16,8234,8192,65,2420,38160,12329,35188,34133,32800,256,40969,13324,33653]

theorem envBound10565 : H12AffineFastState.Bounded env10565 := by
  intro p hp
  have h : env10565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10564_10565 : H12AffineEnvironment.transform 21 33109 env10564 = env10565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33109 env10564 == env10565) = true)

theorem identity10565 : scanCanonicalize (H12AffineFastState.compose env10565 (packedSelected [2,4,6,7,11,14,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10565 : packedSelected [2,4,6,7,11,14,18,22,27] rootPS < 2^1333 := by decide +kernel

def env10566 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,0,8575,13389,2048,1024,1,4161,341,16,8234,8192,65,2420,5392,12329,2420,1365,32,256,8201,13324,885]

theorem envBound10566 : H12AffineFastState.Bounded env10566 := by
  intro p hp
  have h : env10566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10565_10566 : H12AffineEnvironment.transform 14 0 env10565 = env10566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10565 == env10566) = true)

theorem identity10566 : scanCanonicalize (H12AffineFastState.compose env10566 (packedSelected [0,3,4,5,7,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound10566 : packedSelected [0,3,4,5,7,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,0,343,5221,2048,1024,1,4161,341,16,2,40,65,2420,5392,4097,2420,1365,32,256,33,5156,885]

theorem envBound10567 : H12AffineFastState.Bounded env10567 := by
  intro p hp
  have h : env10567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10566_10567 : H12AffineEnvironment.transform 12 40 env10566 = env10567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env10566 == env10567) = true)

theorem identity10567 : scanCanonicalize (H12AffineFastState.compose env10567 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10567 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10568 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,34,5221,2048,1024,1,4161,32,16,2,40,65,2049,5221,4097,2049,1056,32,117,33,5156,512]

theorem envBound10568 : H12AffineFastState.Bounded env10568 := by
  intro p hp
  have h : env10568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10567_10568 : H12AffineEnvironment.transform 7 117 env10567 = env10568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10567 == env10568) = true)

theorem identity10568 : scanCanonicalize (H12AffineFastState.compose env10568 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound10568 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10569 : List Nat := [2,4,8,16,32,64,8,117,512,1024,555,4096,40,5236,0,34,5221,555,1024,1,4161,32,16,2,40,65,554,5221,4097,554,1056,32,117,33,5156,512]

theorem envBound10569 : H12AffineFastState.Bounded env10569 := by
  intro p hp
  have h : env10569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10568_10569 : H12AffineEnvironment.transform 10 555 env10568 = env10569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env10568 == env10569) = true)

theorem identity10569 : scanCanonicalize (H12AffineFastState.compose env10569 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10569 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10570 : List Nat := [2,4,8,16,32,48,8,5,512,1024,555,4096,40,5124,0,34,5141,555,1024,1,4145,32,16,2,40,49,554,5141,4097,554,1056,32,5,33,5156,512]

theorem envBound10570 : H12AffineFastState.Bounded env10570 := by
  intro p hp
  have h : env10570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10569_10570 : H12AffineEnvironment.transform 5 48 env10569 = env10570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10569 == env10570) = true)

theorem identity10570 : scanCanonicalize (H12AffineFastState.compose env10570 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10570 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10571 : List Nat := [2,4,8,16,1,17,8,5,512,1024,522,4096,9,5124,0,3,5141,522,1024,1,4112,1,16,2,9,16,523,5141,4097,523,1025,1,5,0,5125,512]

theorem envBound10571 : H12AffineFastState.Bounded env10571 := by
  intro p hp
  have h : env10571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10570_10571 : H12AffineEnvironment.transform 4 1 env10570 = env10571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10570 == env10571) = true)

def env10572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,16,21763,8193,65,4316278,115015,17664,35189,119043,4268043,256,98679,90202,63069]

theorem envBound10572 : H12AffineFastState.Bounded env10572 := by
  intro p hp
  have h : env10572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10560_10572 : H12AffineEnvironment.transform 6 9 env10560 = env10572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10560 == env10572) = true)

theorem identity10572 : scanCanonicalize (H12AffineFastState.compose env10572 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound10572 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56436,1024,32769,4161,4194304,16,21763,8193,65,4316278,115015,17664,35189,119043,4268043,256,98679,90202,63069]

theorem envBound10573 : H12AffineFastState.Bounded env10573 := by
  intro p hp
  have h : env10573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10572_10573 : H12AffineEnvironment.transform 16 38161 env10572 = env10573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10572 == env10573) = true)

theorem identity10573 : scanCanonicalize (H12AffineFastState.compose env10573 (packedSelected [1,5,7,10,11,12,14,15,20,24,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10573 : packedSelected [1,5,7,10,11,12,14,15,20,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env10574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35188,1024,32769,4161,4194304,16,3,8193,65,4295030,103495,4096,35189,99331,4268043,256,98679,79194,41821]

theorem envBound10574 : H12AffineFastState.Bounded env10574 := by
  intro p hp
  have h : env10574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10573_10574 : H12AffineEnvironment.transform 13 5376 env10573 = env10574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10573 == env10574) = true)

theorem identity10574 : scanCanonicalize (H12AffineFastState.compose env10574 (packedSelected [0,1,5,7,8,10,14,15,16,19,20,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 32880) := by decide +kernel

theorem selectedBound10574 : packedSelected [0,1,5,7,8,10,14,15,16,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env10575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35188,1024,32769,4161,32880,16,3,8193,65,67846,103495,4096,35189,99331,106619,256,98679,79194,41821]

theorem envBound10575 : H12AffineFastState.Bounded env10575 := by
  intro p hp
  have h : env10575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10574_10575 : H12AffineEnvironment.transform 21 32880 env10574 = env10575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32880 env10574 == env10575) = true)

theorem identity10575 : scanCanonicalize (H12AffineFastState.compose env10575 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound10575 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,65536,5441,2340,1024,81,4161,32,16,3,8193,65,67846,70679,4096,2341,66643,73771,256,65831,79194,8973]

theorem envBound10576 : H12AffineFastState.Bounded env10576 := by
  intro p hp
  have h : env10576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10575_10576 : H12AffineEnvironment.transform 14 80 env10575 = env10576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env10575 == env10576) = true)

def env10577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,17,21763,8328,65,4316414,115150,17665,35325,119042,4268162,256,98815,90203,63189]

theorem envBound10577 : H12AffineFastState.Bounded env10577 := by
  intro p hp
  have h : env10577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10559_10577 : H12AffineEnvironment.transform 22 17 env10559 = env10577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env10559 == env10577) = true)

theorem identity10577 : scanCanonicalize (H12AffineFastState.compose env10577 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound10577 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,169400,17,21763,8328,65,215366,115150,17665,35325,119042,243002,256,98815,90203,63189]

theorem envBound10578 : H12AffineFastState.Bounded env10578 := by
  intro p hp
  have h : env10578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10577_10578 : H12AffineEnvironment.transform 21 169400 env10577 = env10578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env10577 == env10578) = true)

def env10579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,17,21763,8192,65,215366,115014,17665,35189,119042,243002,256,98679,90203,63069]

theorem envBound10579 : H12AffineFastState.Bounded env10579 := by
  intro p hp
  have h : env10579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10578_10579 : H12AffineEnvironment.transform 6 8 env10578 = env10579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10578 == env10579) = true)

theorem identity10579 : scanCanonicalize (H12AffineFastState.compose env10579 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138341,1024,32769,4161,169264,17,2,8192,65,203847,103495,4096,35189,99331,243002,256,98679,79194,41820]

theorem envBound10580 : H12AffineFastState.Bounded env10580 := by
  intro p hp
  have h : env10580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10579_10580 : H12AffineEnvironment.transform 13 5377 env10579 = env10580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10579 == env10580) = true)

theorem identity10580 : scanCanonicalize (H12AffineFastState.compose env10580 (packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 103731) := by decide +kernel

theorem selectedBound10580 : packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env10581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103731,100694,1024,32769,4161,65539,17,2,8192,65,35188,103495,4096,35189,99331,8201,256,98679,79194,41820]

theorem envBound10581 : H12AffineFastState.Bounded env10581 := by
  intro p hp
  have h : env10581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10580_10581 : H12AffineEnvironment.transform 16 103731 env10580 = env10581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103731 env10580 == env10581) = true)

theorem identity10581 : scanCanonicalize (H12AffineFastState.compose env10581 (packedSelected [2,4,6,7,10,11,14,19,22,23,26,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10581 : packedSelected [2,4,6,7,10,11,14,19,22,23,26,27,31] rootPS < 2^1333 := by decide +kernel

def env10582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,65536,103731,100694,1024,32769,4161,65539,17,2,348,65,35188,103495,4096,35189,99331,341,256,98679,70662,33280]

theorem envBound10582 : H12AffineFastState.Bounded env10582 := by
  intro p hp
  have h : env10582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10581_10582 : H12AffineEnvironment.transform 12 348 env10581 = env10582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10581 == env10582) = true)

theorem identity10582 : scanCanonicalize (H12AffineFastState.compose env10582 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10582 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10583 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,32768,65536,103495,100386,1024,32769,4161,65539,17,2,40,65,34816,103495,4096,34817,99331,33,116,98307,70662,33280]

theorem envBound10583 : H12AffineFastState.Bounded env10583 := by
  intro p hp
  have h : env10583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10582_10583 : H12AffineEnvironment.transform 7 116 env10582 = env10583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10582 == env10583) = true)

theorem identity10583 : scanCanonicalize (H12AffineFastState.compose env10583 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10583 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10584 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,32768,65536,103447,100386,1024,32769,4113,65539,17,2,40,17,34816,103447,4096,34817,99331,33,36,98307,70662,33280]

theorem envBound10584 : H12AffineFastState.Bounded env10584 := by
  intro p hp
  have h : env10584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10583_10584 : H12AffineEnvironment.transform 5 16 env10583 = env10584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10583 == env10584) = true)

theorem identity10584 : scanCanonicalize (H12AffineFastState.compose env10584 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound10584 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10585 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,32768,32803,5172,2049,1024,32769,4113,32800,17,2,40,17,34816,5172,4096,34817,1056,33,36,32,37925,33280]

theorem envBound10585 : H12AffineFastState.Bounded env10585 := by
  intro p hp
  have h : env10585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10584_10585 : H12AffineEnvironment.transform 15 32803 env10584 = env10585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env10584 == env10585) = true)

theorem identity10585 : scanCanonicalize (H12AffineFastState.compose env10585 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 7204) := by decide +kernel

theorem selectedBound10585 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env10586 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,7204,7175,5172,2049,1024,7205,4113,7172,17,2,40,17,5156,5172,4096,5157,1056,33,36,32,2049,7716]

theorem envBound10586 : H12AffineFastState.Bounded env10586 := by
  intro p hp
  have h : env10586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10585_10586 : H12AffineEnvironment.transform 14 7204 env10585 = env10586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7204 env10585 == env10586) = true)

theorem identity10586 : scanCanonicalize (H12AffineFastState.compose env10586 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10586 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10587 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,6160,6195,4096,2049,52,6161,4113,6192,17,2,40,17,4112,4096,4096,4113,20,33,36,32,2049,6672]

theorem envBound10587 : H12AffineFastState.Bounded env10587 := by
  intro p hp
  have h : env10587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10586_10587 : H12AffineEnvironment.transform 9 52 env10586 = env10587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10586 == env10587) = true)

theorem identity10587 : scanCanonicalize (H12AffineFastState.compose env10587 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound10587 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env10588 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2049,0,35,2064,2049,52,1,2049,32,17,2,40,17,2048,2064,2064,2049,20,33,36,32,2049,512]

theorem envBound10588 : H12AffineFastState.Bounded env10588 := by
  intro p hp
  have h : env10588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10587_10588 : H12AffineEnvironment.transform 11 2064 env10587 = env10588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env10587 == env10588) = true)

theorem identity10588 : scanCanonicalize (H12AffineFastState.compose env10588 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound10588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10589 : List Nat := [2,4,8,16,32,16,8,36,512,52,512,528,40,513,0,35,528,513,52,1,513,32,17,2,40,17,512,528,528,513,20,33,36,32,513,512]

theorem envBound10589 : H12AffineFastState.Bounded env10589 := by
  intro p hp
  have h : env10589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10588_10589 : H12AffineEnvironment.transform 10 512 env10588 = env10589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env10588 == env10589) = true)

theorem identity10589 : scanCanonicalize (H12AffineFastState.compose env10589 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 62) := by decide +kernel

theorem selectedBound10589 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10590 : List Nat := [2,4,8,16,32,16,8,36,62,52,62,46,40,63,0,35,46,63,52,1,63,32,17,2,40,17,62,46,46,63,20,33,36,32,63,62]

theorem envBound10590 : H12AffineFastState.Bounded env10590 := by
  intro p hp
  have h : env10590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10589_10590 : H12AffineEnvironment.transform 8 62 env10589 = env10590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 62 env10589 == env10590) = true)

theorem identity10590 : scanCanonicalize (H12AffineFastState.compose env10590 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10591 : List Nat := [2,4,8,16,17,16,8,21,15,5,15,31,25,14,0,18,31,14,5,1,14,17,17,2,25,17,15,31,31,14,20,16,21,17,14,15]

theorem envBound10591 : H12AffineFastState.Bounded env10591 := by
  intro p hp
  have h : env10591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10590_10591 : H12AffineEnvironment.transform 4 17 env10590 = env10591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10590 == env10591) = true)

theorem identity10591 : scanCanonicalize (H12AffineFastState.compose env10591 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound10591 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10592 : List Nat := [2,4,8,14,15,14,8,11,15,5,15,1,7,14,0,12,1,14,5,1,14,15,15,2,7,15,15,1,1,14,10,14,11,15,14,15]

theorem envBound10592 : H12AffineFastState.Bounded env10592 := by
  intro p hp
  have h : env10592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10591_10592 : H12AffineEnvironment.transform 3 14 env10591 = env10592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env10591 == env10592) = true)

theorem identity10592 : scanCanonicalize (H12AffineFastState.compose env10592 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound10592 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10593 : List Nat := [2,4,7,1,0,1,7,4,0,5,0,1,7,1,0,3,1,1,5,1,1,0,0,2,7,0,0,1,1,1,5,1,4,0,1,0]

theorem envBound10593 : H12AffineFastState.Bounded env10593 := by
  intro p hp
  have h : env10593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10592_10593 : H12AffineEnvironment.transform 2 7 env10592 = env10593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env10592 == env10593) = true)

def env10594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,17,21763,8193,65,215366,115015,17665,35188,119042,243002,256,98678,90203,63068]

theorem envBound10594 : H12AffineFastState.Bounded env10594 := by
  intro p hp
  have h : env10594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10578_10594 : H12AffineEnvironment.transform 6 9 env10578 = env10594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10578 == env10594) = true)

theorem identity10594 : scanCanonicalize (H12AffineFastState.compose env10594 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10594 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1024,29788,4161,156012,17,21763,8193,65,215366,79130,17665,32041,75103,213351,256,95531,90203,513]

theorem envBound10595 : H12AffineFastState.Bounded env10595 := by
  intro p hp
  have h : env10595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10594_10595 : H12AffineEnvironment.transform 14 29789 env10594 = env10595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10594 == env10595) = true)

theorem identity10595 : scanCanonicalize (H12AffineFastState.compose env10595 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10595 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76158,1024,29788,4161,65911,17,21763,8193,65,10589,79130,17665,32041,75103,8572,256,95531,90203,513]

theorem envBound10596 : H12AffineFastState.Bounded env10596 := by
  intro p hp
  have h : env10596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10595_10596 : H12AffineEnvironment.transform 16 90139 env10595 = env10596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10595 == env10596) = true)

theorem identity10596 : scanCanonicalize (H12AffineFastState.compose env10596 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound10596 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5392,23669,1024,29788,4161,29820,17,21763,8193,65,10589,16401,17665,32041,20564,8572,256,32,5456,513]

theorem envBound10597 : H12AffineFastState.Bounded env10597 := by
  intro p hp
  have h : env10597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10596_10597 : H12AffineEnvironment.transform 15 29963 env10596 = env10597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env10596 == env10597) = true)

theorem identity10597 : scanCanonicalize (H12AffineFastState.compose env10597 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10597 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,343,5392,10281,1024,0,4161,32,17,8543,8193,65,10589,13389,12637,2421,9224,8572,256,32,5456,513]

theorem envBound10598 : H12AffineFastState.Bounded env10598 := by
  intro p hp
  have h : env10598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10597_10598 : H12AffineEnvironment.transform 13 13404 env10597 = env10598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10597 == env10598) = true)

theorem identity10598 : scanCanonicalize (H12AffineFastState.compose env10598 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound10598 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,1,343,5392,3172,1024,0,4161,32,17,1298,1100,65,3344,4096,5392,2421,69,1329,256,32,5456,513]

theorem envBound10599 : H12AffineFastState.Bounded env10599 := by
  intro p hp
  have h : env10599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10598_10599 : H12AffineEnvironment.transform 12 1101 env10598 = env10599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env10598 == env10599) = true)

theorem identity10599 : scanCanonicalize (H12AffineFastState.compose env10599 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10599 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,4096,1101,4113,1,343,5392,1124,1024,0,4161,32,17,1298,1100,65,1296,4096,5392,373,69,1329,256,32,5456,513]

theorem envBound10600 : H12AffineFastState.Bounded env10600 := by
  intro p hp
  have h : env10600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10599_10600 : H12AffineEnvironment.transform 10 0 env10599 = env10600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10599 == env10600) = true)

theorem identity10600 : scanCanonicalize (H12AffineFastState.compose env10600 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10600 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10601 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,1101,4113,1,34,5221,1124,1024,0,4161,32,17,1127,1100,65,1125,4096,5221,0,69,1092,117,32,5157,513]

theorem envBound10601 : H12AffineFastState.Bounded env10601 := by
  intro p hp
  have h : env10601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10600_10601 : H12AffineEnvironment.transform 7 117 env10600 = env10601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10600 == env10601) = true)

theorem identity10601 : scanCanonicalize (H12AffineFastState.compose env10601 (packedSelected [1,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10601 : packedSelected [1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env10602 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,4096,1052,4113,1,34,5172,1077,1024,0,4112,32,17,1078,1053,16,1076,4096,5172,0,20,1045,36,32,5157,513]

theorem envBound10602 : H12AffineFastState.Bounded env10602 := by
  intro p hp
  have h : env10602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10601_10602 : H12AffineEnvironment.transform 5 17 env10601 = env10602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10601 == env10602) = true)

theorem identity10602 : scanCanonicalize (H12AffineFastState.compose env10602 (packedSelected [2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10602 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env10603 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,16,1052,1,1,34,1060,1077,1024,0,0,32,17,1078,1053,16,1076,16,1060,0,20,1045,36,32,1077,513]

theorem envBound10603 : H12AffineFastState.Bounded env10603 := by
  intro p hp
  have h : env10603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10602_10603 : H12AffineEnvironment.transform 11 16 env10602 = env10603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10602 == env10603) = true)

def env10604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797998,115151,10507601,8423917,10600787,4268163,256,8487407,8478795,10544772]

theorem envBound10604 : H12AffineFastState.Bounded env10604 := by
  intro p hp
  have h : env10604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10516_10604 : H12AffineEnvironment.transform 17 149997 env10516 = env10604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env10516 == env10604) = true)

def env10605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,8388608,21763,8328,65,12705006,115151,8406289,8423917,8507667,4268163,256,8487407,8478795,8451780]

theorem envBound10605 : H12AffineFastState.Bounded env10605 := by
  intro p hp
  have h : env10605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10604_10605 : H12AffineEnvironment.transform 20 4160 env10604 = env10605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10604 == env10605) = true)

def env10606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,16,21763,8328,65,4316414,115151,17665,35325,119043,4268163,256,98815,90203,63188]

theorem envBound10606 : H12AffineFastState.Bounded env10606 := by
  intro p hp
  have h : env10606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10605_10606 : H12AffineEnvironment.transform 22 16 env10605 = env10606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env10605 == env10606) = true)

theorem identity10606 : scanCanonicalize (H12AffineFastState.compose env10606 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10606 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4160,4194304,16,21763,8328,65,4259061,57796,17665,35325,61704,4194440,256,41460,16464,63188]

theorem envBound10607 : H12AffineFastState.Bounded env10607 := by
  intro p hp
  have h : env10607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10606_10607 : H12AffineEnvironment.transform 15 8203 env10606 = env10607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10606 == env10607) = true)

def env10608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4160,4194304,16,21763,8192,65,4258941,57676,17665,35189,61704,4194304,256,41340,16464,63068]

theorem envBound10608 : H12AffineFastState.Bounded env10608 := by
  intro p hp
  have h : env10608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10607_10608 : H12AffineEnvironment.transform 6 8 env10607 = env10608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10607 == env10608) = true)

theorem identity10608 : scanCanonicalize (H12AffineFastState.compose env10608 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound10608 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13388,32041,1024,32769,4160,4194304,16,21763,8192,65,4258941,57676,17665,35189,61704,4194304,256,41340,16464,63068]

theorem envBound10609 : H12AffineFastState.Bounded env10609 := by
  intro p hp
  have h : env10609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10608_10609 : H12AffineEnvironment.transform 16 13388 env10608 = env10609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env10608 == env10609) = true)

theorem identity10609 : scanCanonicalize (H12AffineFastState.compose env10609 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound10609 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env10610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13388,32041,1024,32769,4160,32800,16,21763,8192,65,31837,57676,17665,35189,61704,32800,256,41340,16464,63068]

theorem envBound10610 : H12AffineFastState.Bounded env10610 := by
  intro p hp
  have h : env10610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10609_10610 : H12AffineEnvironment.transform 21 32800 env10609 = env10610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env10609 == env10610) = true)

theorem identity10610 : scanCanonicalize (H12AffineFastState.compose env10610 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10610 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env10611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,5392,23669,1024,32769,4160,32800,16,21763,348,65,23809,49168,17665,35189,53332,32800,256,32800,16464,55040]

theorem envBound10611 : H12AffineFastState.Bounded env10611 := by
  intro p hp
  have h : env10611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10610_10611 : H12AffineEnvironment.transform 12 348 env10610 = env10611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10610 == env10611) = true)

theorem identity10611 : scanCanonicalize (H12AffineFastState.compose env10611 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21588) := by decide +kernel

theorem selectedBound10611 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env10612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21588,343,5392,23669,1024,21589,4160,21620,16,21763,348,65,23809,5188,17665,23841,1024,21620,256,21620,16464,852]

theorem envBound10612 : H12AffineFastState.Bounded env10612 := by
  intro p hp
  have h : env10612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10611_10612 : H12AffineEnvironment.transform 14 21588 env10611 = env10612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21588 env10611 == env10612) = true)

def env10613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,4194304,16,21763,8193,65,4258940,57677,17665,35188,61704,4194305,256,41341,16464,63069]

theorem envBound10613 : H12AffineFastState.Bounded env10613 := by
  intro p hp
  have h : env10613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10607_10613 : H12AffineEnvironment.transform 6 9 env10607 = env10613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10607 == env10613) = true)

theorem identity10613 : scanCanonicalize (H12AffineFastState.compose env10613 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound10613 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,56436,1024,32769,4160,4194304,16,21763,8193,65,4258940,57677,17665,35188,61704,4194305,256,41341,16464,63069]

theorem envBound10614 : H12AffineFastState.Bounded env10614 := by
  intro p hp
  have h : env10614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10613_10614 : H12AffineEnvironment.transform 16 38160 env10613 = env10614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env10613 == env10614) = true)

theorem identity10614 : scanCanonicalize (H12AffineFastState.compose env10614 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10614 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,38160,35189,1024,32769,4160,4194304,16,2,8193,65,4237693,46156,4096,35188,41993,4194305,256,41341,5457,41820]

theorem envBound10615 : H12AffineFastState.Bounded env10615 := by
  intro p hp
  have h : env10615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10614_10615 : H12AffineEnvironment.transform 13 5377 env10614 = env10615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10614 == env10615) = true)

def env10616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,17,21763,8328,65,4316415,115151,17664,35324,119042,4268163,256,98814,90202,63189]

theorem envBound10616 : H12AffineFastState.Bounded env10616 := by
  intro p hp
  have h : env10616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10605_10616 : H12AffineEnvironment.transform 22 17 env10605 = env10616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env10605 == env10616) = true)

theorem identity10616 : scanCanonicalize (H12AffineFastState.compose env10616 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound10616 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,243123,17,21763,8328,65,158028,115151,17664,35324,119042,169264,256,98814,90202,63189]

theorem envBound10617 : H12AffineFastState.Bounded env10617 := by
  intro p hp
  have h : env10617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10616_10617 : H12AffineEnvironment.transform 21 243123 env10616 = env10617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env10616 == env10617) = true)

theorem identity10617 : scanCanonicalize (H12AffineFastState.compose env10617 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound10617 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149997,1024,29909,4160,213351,17,21763,8328,65,158028,79131,17664,32040,75222,156132,256,95530,90202,513]

theorem envBound10618 : H12AffineFastState.Bounded env10618 := by
  intro p hp
  have h : env10618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10617_10618 : H12AffineEnvironment.transform 14 29908 env10617 = env10618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env10617 == env10618) = true)

theorem identity10618 : scanCanonicalize (H12AffineFastState.compose env10618 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10618 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,76278,1024,29909,4160,8572,17,21763,8328,65,67927,79131,17664,32040,75222,66047,256,95530,90202,513]

theorem envBound10619 : H12AffineFastState.Bounded env10619 := by
  intro p hp
  have h : env10619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10618_10619 : H12AffineEnvironment.transform 16 90139 env10618 = env10619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10618 == env10619) = true)

def env10620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79131,76278,1024,8661,4160,8572,17,3,8328,65,67927,79131,4096,10280,75222,66047,256,73770,79194,513]

theorem envBound10620 : H12AffineFastState.Bounded env10620 := by
  intro p hp
  have h : env10620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10619_10620 : H12AffineEnvironment.transform 13 5376 env10619 = env10620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10619 == env10620) = true)

theorem identity10620 : scanCanonicalize (H12AffineFastState.compose env10620 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10620 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79131,76159,1024,8540,4160,8572,17,3,8193,65,67927,79131,4096,10280,75103,65910,256,73770,79194,513]

theorem envBound10621 : H12AffineFastState.Bounded env10621 := by
  intro p hp
  have h : env10621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10620_10621 : H12AffineEnvironment.transform 6 9 env10620 = env10621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10620 == env10621) = true)

theorem identity10621 : scanCanonicalize (H12AffineFastState.compose env10621 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10621 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5392,2420,1024,8540,4160,8572,17,3,8193,65,10588,5392,4096,10280,1364,8573,256,33,5457,513]

theorem envBound10622 : H12AffineFastState.Bounded env10622 := by
  intro p hp
  have h : env10622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10621_10622 : H12AffineEnvironment.transform 15 8203 env10621 = env10622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10621 == env10622) = true)

theorem identity10622 : scanCanonicalize (H12AffineFastState.compose env10622 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10622 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10623 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5392,2341,1024,8461,4113,8493,17,3,8193,16,10509,5392,4096,10280,1285,8492,256,33,5376,513]

theorem envBound10623 : H12AffineFastState.Bounded env10623 := by
  intro p hp
  have h : env10623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10622_10623 : H12AffineEnvironment.transform 5 17 env10622 = env10623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10622 == env10623) = true)

theorem identity10623 : scanCanonicalize (H12AffineFastState.compose env10623 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 285) := by decide +kernel

theorem selectedBound10623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10624 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,285,5376,17,278,5392,2341,1024,16,4113,48,17,3,284,16,2064,5392,4096,2357,1285,49,256,33,5376,513]

theorem envBound10624 : H12AffineFastState.Bounded env10624 := by
  intro p hp
  have h : env10624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10623_10624 : H12AffineEnvironment.transform 12 285 env10623 = env10624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 285 env10623 == env10624) = true)

theorem identity10624 : scanCanonicalize (H12AffineFastState.compose env10624 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1792) := by decide +kernel

theorem selectedBound10624 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10625 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,4096,285,5376,17,278,5392,1573,1024,16,4113,48,17,3,284,16,1808,5392,4096,1589,1285,49,256,33,5376,513]

theorem envBound10625 : H12AffineFastState.Bounded env10625 := by
  intro p hp
  have h : env10625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10624_10625 : H12AffineEnvironment.transform 10 1792 env10624 = env10625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env10624 == env10625) = true)

theorem identity10625 : scanCanonicalize (H12AffineFastState.compose env10625 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10625 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10626 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,4096,56,5157,17,51,5173,1573,1024,16,4113,48,17,3,57,16,1589,5173,4096,1589,1056,49,37,33,5157,513]

theorem envBound10626 : H12AffineFastState.Bounded env10626 := by
  intro p hp
  have h : env10626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10625_10626 : H12AffineEnvironment.transform 7 37 env10625 = env10626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10625 == env10626) = true)

theorem identity10626 : scanCanonicalize (H12AffineFastState.compose env10626 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound10626 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10627 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,1077,56,16,17,51,0,1573,1024,16,1060,48,17,3,57,16,1589,0,1077,1589,1056,49,37,33,16,513]

theorem envBound10627 : H12AffineFastState.Bounded env10627 := by
  intro p hp
  have h : env10627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10626_10627 : H12AffineEnvironment.transform 11 1077 env10626 = env10627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env10626 == env10627) = true)

theorem identity10627 : scanCanonicalize (H12AffineFastState.compose env10627 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10627 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10628 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,1,56,16,17,51,0,529,52,16,16,48,17,3,57,16,513,0,1,513,20,49,37,33,16,513]

theorem envBound10628 : H12AffineFastState.Bounded env10628 := by
  intro p hp
  have h : env10628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10627_10628 : H12AffineEnvironment.transform 9 52 env10627 = env10628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10627 == env10628) = true)

theorem identity10628 : scanCanonicalize (H12AffineFastState.compose env10628 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10629 : List Nat := [2,4,8,16,0,17,9,5,512,20,529,1,24,16,17,19,0,529,20,16,16,16,17,3,25,16,513,0,1,513,20,17,5,1,16,513]

theorem envBound10629 : H12AffineFastState.Bounded env10629 := by
  intro p hp
  have h : env10629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10628_10629 : H12AffineEnvironment.transform 4 0 env10628 = env10629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10628 == env10629) = true)

def env10630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79130,76278,1024,8660,4160,8572,17,2,8328,65,67927,79131,4097,10281,75222,66047,256,73771,79195,513]

theorem envBound10630 : H12AffineFastState.Bounded env10630 := by
  intro p hp
  have h : env10630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10619_10630 : H12AffineEnvironment.transform 13 5377 env10619 = env10630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10619 == env10630) = true)

theorem identity10630 : scanCanonicalize (H12AffineFastState.compose env10630 (packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10630 : packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env10631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,65536,70726,67754,1024,136,4160,32,17,2,468,65,67927,70727,4097,2421,66698,66047,256,65911,70663,513]

theorem envBound10631 : H12AffineFastState.Bounded env10631 := by
  intro p hp
  have h : env10631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10630_10631 : H12AffineEnvironment.transform 12 348 env10630 = env10631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10630 == env10631) = true)

theorem identity10631 : scanCanonicalize (H12AffineFastState.compose env10631 (packedSelected [1,3,6,8,10,11,12,14,15,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound10631 : packedSelected [1,3,6,8,10,11,12,14,15,23,24] rootPS < 2^1333 := by decide +kernel

def env10632 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5377,81,65536,70726,67698,1024,80,4160,32,17,2,268,65,67927,70727,4097,2421,66642,65831,256,65911,70663,513]

theorem envBound10632 : H12AffineFastState.Bounded env10632 := by
  intro p hp
  have h : env10632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10631_10632 : H12AffineEnvironment.transform 6 88 env10631 = env10632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env10631 == env10632) = true)

theorem identity10632 : scanCanonicalize (H12AffineFastState.compose env10632 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10632 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10633 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5377,81,262,5440,2420,1024,80,4160,32,17,2,268,65,2129,5441,4097,2421,1364,33,256,113,5377,513]

theorem envBound10633 : H12AffineFastState.Bounded env10633 := by
  intro p hp
  have h : env10633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10632_10633 : H12AffineEnvironment.transform 15 262 env10632 = env10633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10632 == env10633) = true)

theorem identity10633 : scanCanonicalize (H12AffineFastState.compose env10633 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound10633 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10634 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,64,348,1345,81,262,1280,2420,1024,80,0,32,17,2,268,65,2129,1281,65,2421,1364,33,256,113,1345,513]

theorem envBound10634 : H12AffineFastState.Bounded env10634 := by
  intro p hp
  have h : env10634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10633_10634 : H12AffineEnvironment.transform 11 64 env10633 = env10634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env10633 == env10634) = true)

theorem identity10634 : scanCanonicalize (H12AffineFastState.compose env10634 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10634 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10635 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,64,348,80,81,262,17,2420,273,80,0,32,17,2,268,65,2129,16,65,2421,69,33,256,113,80,513]

theorem envBound10635 : H12AffineFastState.Bounded env10635 := by
  intro p hp
  have h : env10635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10634_10635 : H12AffineEnvironment.transform 9 273 env10634 = env10635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10634 == env10635) = true)

theorem identity10635 : scanCanonicalize (H12AffineFastState.compose env10635 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound10635 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env10636 : List Nat := [2,4,8,16,32,64,88,256,512,273,80,64,348,80,81,262,17,292,273,80,0,32,17,2,268,65,1,16,65,293,69,33,256,113,80,513]

theorem envBound10636 : H12AffineFastState.Bounded env10636 := by
  intro p hp
  have h : env10636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10635_10636 : H12AffineEnvironment.transform 10 80 env10635 = env10636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env10635 == env10636) = true)

def env10637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,8388608,21762,8328,65,12705007,115151,8406288,8423917,8507666,4268163,256,8487407,8478795,8451781]

theorem envBound10637 : H12AffineFastState.Bounded env10637 := by
  intro p hp
  have h : env10637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10604_10637 : H12AffineEnvironment.transform 20 4161 env10604 = env10637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10604 == env10637) = true)

def env10638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,16,21762,8328,65,4316415,115151,17664,35325,119042,4268163,256,98815,90203,63189]

theorem envBound10638 : H12AffineFastState.Bounded env10638 := by
  intro p hp
  have h : env10638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10637_10638 : H12AffineEnvironment.transform 22 16 env10637 = env10638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env10637 == env10638) = true)

theorem identity10638 : scanCanonicalize (H12AffineFastState.compose env10638 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound10638 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149997,1024,32769,4161,4194304,16,21762,8328,65,4196384,5392,17664,35325,1501,4256860,256,21792,46212,63189]

theorem envBound10639 : H12AffineFastState.Bounded env10639 := by
  intro p hp
  have h : env10639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10638_10639 : H12AffineEnvironment.transform 15 54495 env10638 = env10639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env10638 == env10639) = true)

def env10640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149861,1024,32769,4161,4194304,16,21762,8192,65,4196384,5392,17664,35189,1365,4256860,256,21792,46092,63069]

theorem envBound10640 : H12AffineFastState.Bounded env10640 := by
  intro p hp
  have h : env10640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10639_10640 : H12AffineEnvironment.transform 6 8 env10639 = env10640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10639 == env10640) = true)

theorem identity10640 : scanCanonicalize (H12AffineFastState.compose env10640 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound10640 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,32040,1024,32769,4161,4194304,16,21762,8192,65,4196384,5392,17664,35189,1365,4256860,256,21792,46092,63069]

theorem envBound10641 : H12AffineFastState.Bounded env10641 := by
  intro p hp
  have h : env10641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10640_10641 : H12AffineEnvironment.transform 16 13389 env10640 = env10641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env10640 == env10641) = true)

theorem identity10641 : scanCanonicalize (H12AffineFastState.compose env10641 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound10641 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33030,13389,10361,1024,32769,4161,4194304,16,83,8192,65,4196384,5392,4177,35189,1365,4235533,256,113,46092,41740]

theorem envBound10642 : H12AffineFastState.Bounded env10642 := by
  intro p hp
  have h : env10642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10641_10642 : H12AffineEnvironment.transform 13 5457 env10641 = env10642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env10641 == env10642) = true)

theorem identity10642 : scanCanonicalize (H12AffineFastState.compose env10642 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41048) := by decide +kernel

theorem selectedBound10642 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env10643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33030,13389,10361,1024,32769,4161,41048,16,83,8192,65,43128,5392,4177,35189,1365,341,256,113,46092,41740]

theorem envBound10643 : H12AffineFastState.Bounded env10643 := by
  intro p hp
  have h : env10643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10642_10643 : H12AffineEnvironment.transform 21 41048 env10642 = env10643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41048 env10642 == env10643) = true)

theorem identity10643 : scanCanonicalize (H12AffineFastState.compose env10643 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10643 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,263,13389,10361,1024,0,4161,8281,16,83,8192,65,10361,5392,4177,2420,1365,341,256,113,13325,8973]

theorem envBound10644 : H12AffineFastState.Bounded env10644 := by
  intro p hp
  have h : env10644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10643_10644 : H12AffineEnvironment.transform 14 1 env10643 = env10644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10643 == env10644) = true)

theorem identity10644 : scanCanonicalize (H12AffineFastState.compose env10644 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10644 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,18,24] rootPS < 2^1333 := by decide +kernel

def env10645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,1,263,5392,2340,1024,0,4161,260,16,83,349,65,2340,5392,4177,2420,1365,341,256,113,5456,592]

theorem envBound10645 : H12AffineFastState.Bounded env10645 := by
  intro p hp
  have h : env10645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10644_10645 : H12AffineEnvironment.transform 12 349 env10644 = env10645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10644 == env10645) = true)

theorem identity10645 : scanCanonicalize (H12AffineFastState.compose env10645 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound10645 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,349,2128,1,263,2065,2340,1024,0,3392,260,16,83,349,65,2340,2065,3408,2420,1365,341,256,113,2129,592]

theorem envBound10646 : H12AffineFastState.Bounded env10646 := by
  intro p hp
  have h : env10646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10645_10646 : H12AffineEnvironment.transform 11 3329 env10645 = env10646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env10645 == env10646) = true)

theorem identity10646 : scanCanonicalize (H12AffineFastState.compose env10646 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10646 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1280,349,81,1,263,16,293,1024,0,1345,260,16,83,349,65,293,16,1361,373,1365,341,256,113,80,592]

theorem envBound10647 : H12AffineFastState.Bounded env10647 := by
  intro p hp
  have h : env10647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10646_10647 : H12AffineEnvironment.transform 10 1 env10646 = env10647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10646 == env10647) = true)

theorem identity10647 : scanCanonicalize (H12AffineFastState.compose env10647 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound10647 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10648 : List Nat := [2,4,8,16,32,64,8,256,512,320,1,64,349,81,1,263,16,293,320,0,1,260,16,83,349,65,293,16,17,373,21,341,256,113,80,592]

theorem envBound10648 : H12AffineFastState.Bounded env10648 := by
  intro p hp
  have h : env10648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10647_10648 : H12AffineEnvironment.transform 9 320 env10647 = env10648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env10647 == env10648) = true)

theorem identity10648 : scanCanonicalize (H12AffineFastState.compose env10648 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10648 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10649 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,64,40,81,1,114,16,80,53,0,1,113,16,83,40,65,80,16,17,0,21,32,117,113,80,592]

theorem envBound10649 : H12AffineFastState.Bounded env10649 := by
  intro p hp
  have h : env10649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10648_10649 : H12AffineEnvironment.transform 7 117 env10648 = env10649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10648 == env10649) = true)

theorem identity10649 : scanCanonicalize (H12AffineFastState.compose env10649 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound10649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10650 : List Nat := [2,4,8,16,32,49,8,4,512,53,1,49,40,32,1,3,16,33,53,0,1,0,16,34,40,48,33,16,17,0,21,32,4,0,33,545]

theorem envBound10650 : H12AffineFastState.Bounded env10650 := by
  intro p hp
  have h : env10650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10649_10650 : H12AffineEnvironment.transform 5 49 env10649 = env10650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env10649 == env10650) = true)

theorem identity10650 : scanCanonicalize (H12AffineFastState.compose env10650 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10650 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10651 : List Nat := [2,4,8,16,1,16,8,4,512,20,1,16,9,1,1,3,16,0,20,0,1,0,16,3,9,17,0,16,17,0,21,1,4,0,0,512]

theorem envBound10651 : H12AffineFastState.Bounded env10651 := by
  intro p hp
  have h : env10651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10650_10651 : H12AffineEnvironment.transform 4 1 env10650 = env10651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10650 == env10651) = true)

theorem identity10651 : scanCanonicalize (H12AffineFastState.compose env10651 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound10651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10652 : List Nat := [2,0,8,16,1,16,8,0,512,16,1,16,9,1,1,3,16,0,16,0,1,0,16,3,9,17,0,16,17,0,17,1,0,0,0,512]

theorem envBound10652 : H12AffineFastState.Bounded env10652 := by
  intro p hp
  have h : env10652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10651_10652 : H12AffineEnvironment.transform 1 0 env10651 = env10652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env10651 == env10652) = true)

theorem identity10652 : scanCanonicalize (H12AffineFastState.compose env10652 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound10652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10653 : List Nat := [2,0,8,16,1,16,8,0,9,16,1,16,9,1,1,3,16,0,16,0,1,0,16,3,9,17,0,16,17,0,17,1,0,0,0,9]

theorem envBound10653 : H12AffineFastState.Bounded env10653 := by
  intro p hp
  have h : env10653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10652_10653 : H12AffineEnvironment.transform 8 9 env10652 = env10653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env10652 == env10653) = true)

theorem identity10653 : scanCanonicalize (H12AffineFastState.compose env10653 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound10653 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10654 : List Nat := [1,0,8,16,1,16,8,0,9,16,1,16,9,1,1,0,16,0,16,0,1,0,16,0,9,17,0,16,17,0,17,1,0,0,0,9]

theorem envBound10654 : H12AffineFastState.Bounded env10654 := by
  intro p hp
  have h : env10654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10653_10654 : H12AffineEnvironment.transform 0 1 env10653 = env10654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env10653 == env10654) = true)

def env10655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149860,1024,32769,4161,4194304,16,21762,8193,65,4196384,5392,17664,35188,1364,4256860,256,21792,46093,63068]

theorem envBound10655 : H12AffineFastState.Bounded env10655 := by
  intro p hp
  have h : env10655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10639_10655 : H12AffineEnvironment.transform 6 9 env10639 = env10655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10639 == env10655) = true)

theorem identity10655 : scanCanonicalize (H12AffineFastState.compose env10655 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound10655 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,56437,1024,32769,4161,4194304,16,21762,8193,65,4196384,5392,17664,35188,1364,4256860,256,21792,46093,63068]

theorem envBound10656 : H12AffineFastState.Bounded env10656 := by
  intro p hp
  have h : env10656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10655_10656 : H12AffineEnvironment.transform 16 38161 env10655 = env10656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10655 == env10656) = true)

theorem identity10656 : scanCanonicalize (H12AffineFastState.compose env10656 (packedSelected [0,3,5,7,9,10,11,14,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10656 : packedSelected [0,3,5,7,9,10,11,14,18,20,22] rootPS < 2^1333 := by decide +kernel

def env10657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,38161,35189,1024,32769,4161,4194304,16,2,8193,65,4196384,5392,4096,35188,1364,4235612,256,32,46093,41820]

theorem envBound10657 : H12AffineFastState.Bounded env10657 := by
  intro p hp
  have h : env10657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10656_10657 : H12AffineEnvironment.transform 13 5376 env10656 = env10657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10656 == env10657) = true)

theorem identity10657 : scanCanonicalize (H12AffineFastState.compose env10657 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound10657 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,38161,35189,1024,32769,4161,8573,16,2,8193,65,10589,5392,4096,35188,1364,32801,256,32,46093,41820]

theorem envBound10658 : H12AffineFastState.Bounded env10658 := by
  intro p hp
  have h : env10658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10657_10658 : H12AffineEnvironment.transform 21 8573 env10657 = env10658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env10657 == env10658) = true)

theorem identity10658 : scanCanonicalize (H12AffineFastState.compose env10658 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound10658 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env10659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,263,5440,2340,1024,80,4161,8573,16,2,8193,65,10589,5392,4096,2341,1364,112,256,32,13404,8973]

theorem envBound10659 : H12AffineFastState.Bounded env10659 := by
  intro p hp
  have h : env10659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10658_10659 : H12AffineEnvironment.transform 14 81 env10658 = env10659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env10658 == env10659) = true)

theorem identity10659 : scanCanonicalize (H12AffineFastState.compose env10659 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10659 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env10660 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,263,5392,2340,1024,0,4113,8493,16,2,8193,17,10509,5392,4096,2341,1284,32,256,32,13324,8973]

theorem envBound10660 : H12AffineFastState.Bounded env10660 := by
  intro p hp
  have h : env10660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10659_10660 : H12AffineEnvironment.transform 5 16 env10659 = env10660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10659 == env10660) = true)

theorem identity10660 : scanCanonicalize (H12AffineFastState.compose env10660 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 796) := by decide +kernel

theorem selectedBound10660 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10661 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,796,5376,1,263,5392,2340,1024,0,4113,561,16,2,797,17,2577,5392,4096,2341,1284,32,256,32,5904,17]

theorem envBound10661 : H12AffineFastState.Bounded env10661 := by
  intro p hp
  have h : env10661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10660_10661 : H12AffineEnvironment.transform 12 796 env10660 = env10661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 796 env10660 == env10661) = true)

theorem identity10661 : scanCanonicalize (H12AffineFastState.compose env10661 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound10661 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env10662 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1793,796,513,1,263,529,2340,1024,0,1808,561,16,2,797,17,2577,529,1793,2341,1284,32,256,32,17,17]

theorem envBound10662 : H12AffineFastState.Bounded env10662 := by
  intro p hp
  have h : env10662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10661_10662 : H12AffineEnvironment.transform 11 1793 env10661 = env10662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env10661 == env10662) = true)

theorem identity10662 : scanCanonicalize (H12AffineFastState.compose env10662 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10662 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env10663 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,1793,796,513,1,263,529,2308,1024,0,1808,529,16,2,797,17,2577,529,1793,2309,1284,0,256,0,17,17]

theorem envBound10663 : H12AffineFastState.Bounded env10663 := by
  intro p hp
  have h : env10663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10662_10663 : H12AffineEnvironment.transform 4 0 env10662 = env10663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10662 == env10663) = true)

theorem identity10663 : scanCanonicalize (H12AffineFastState.compose env10663 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound10663 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10664 : List Nat := [2,4,8,16,0,16,9,256,17,1024,2048,1296,269,16,1,263,0,2308,1024,0,1281,0,16,2,268,17,2048,0,1296,2309,1284,0,256,0,17,17]

theorem envBound10664 : H12AffineFastState.Bounded env10664 := by
  intro p hp
  have h : env10664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10663_10664 : H12AffineEnvironment.transform 8 17 env10663 = env10664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env10663 == env10664) = true)

def env10665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,17,21762,8328,65,4316414,115151,17665,35324,119043,4268163,256,98814,90202,63188]

theorem envBound10665 : H12AffineFastState.Bounded env10665 := by
  intro p hp
  have h : env10665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10637_10665 : H12AffineEnvironment.transform 22 17 env10637 = env10665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env10637 == env10665) = true)

theorem identity10665 : scanCanonicalize (H12AffineFastState.compose env10665 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound10665 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,213351,17,21762,8328,65,171417,115151,17665,35324,119043,156132,256,98814,90202,63188]

theorem envBound10666 : H12AffineFastState.Bounded env10666 := by
  intro p hp
  have h : env10666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10665_10666 : H12AffineEnvironment.transform 21 213351 env10665 = env10666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env10665 == env10666) = true)

def env10667 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,213351,17,21762,8192,65,171281,115015,17665,35188,119043,156012,256,98678,90202,63068]

theorem envBound10667 : H12AffineFastState.Bounded env10667 := by
  intro p hp
  have h : env10667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10666_10667 : H12AffineEnvironment.transform 6 8 env10666 = env10667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10666 == env10667) = true)

theorem identity10667 : scanCanonicalize (H12AffineFastState.compose env10667 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10667 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10668 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138341,1024,32769,4161,201831,17,2,8192,65,171281,103495,4097,35188,99331,144492,256,98678,79194,41820]

theorem envBound10668 : H12AffineFastState.Bounded env10668 := by
  intro p hp
  have h : env10668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10667_10668 : H12AffineEnvironment.transform 13 5376 env10667 = env10668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10667 == env10668) = true)

theorem identity10668 : scanCanonicalize (H12AffineFastState.compose env10668 (packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound10668 : packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS < 2^1333 := by decide +kernel

def env10669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,115,131072,138341,1024,32769,4161,136212,17,2,8192,65,171281,37940,4097,35188,33904,144492,256,33029,13609,41820]

theorem envBound10669 : H12AffineFastState.Bounded env10669 := by
  intro p hp
  have h : env10669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10668_10669 : H12AffineEnvironment.transform 15 115 env10668 = env10669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env10668 == env10669) = true)

theorem identity10669 : scanCanonicalize (H12AffineFastState.compose env10669 (packedSelected [0,2,3,4,6,7,9,10,11,14,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound10669 : packedSelected [0,2,3,4,6,7,9,10,11,14,19,23,24] rootPS < 2^1333 := by decide +kernel

def env10670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,292,115,131072,138341,1024,293,4161,136212,17,2,8192,65,138293,5392,4097,2128,1364,144492,256,33,13609,8824]

theorem envBound10670 : H12AffineFastState.Bounded env10670 := by
  intro p hp
  have h : env10670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10669_10670 : H12AffineEnvironment.transform 14 292 env10669 = env10670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env10669 == env10670) = true)

theorem identity10670 : scanCanonicalize (H12AffineFastState.compose env10670 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound10670 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env10671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,292,115,13388,10281,1024,293,4161,8280,17,2,8192,65,10361,5392,4097,2128,1364,32,256,33,13609,8824]

theorem envBound10671 : H12AffineFastState.Bounded env10671 := by
  intro p hp
  have h : env10671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10670_10671 : H12AffineEnvironment.transform 16 13388 env10670 = env10671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env10670 == env10671) = true)

theorem identity10671 : scanCanonicalize (H12AffineFastState.compose env10671 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10671 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10672 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,292,115,12637,10281,273,293,4161,8280,17,2,8192,65,10361,4097,4097,2128,69,32,256,33,12344,8824]

theorem envBound10672 : H12AffineFastState.Bounded env10672 := by
  intro p hp
  have h : env10672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10671_10672 : H12AffineEnvironment.transform 9 273 env10671 = env10672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10671 == env10672) = true)

theorem identity10672 : scanCanonicalize (H12AffineFastState.compose env10672 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound10672 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env10673 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,6429,4113,292,115,2112,4404,273,293,4161,6469,17,2,6429,65,4452,4097,4097,2128,69,32,256,33,2341,7013]

theorem envBound10673 : H12AffineFastState.Bounded env10673 := by
  intro p hp
  have h : env10673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10672_10673 : H12AffineEnvironment.transform 12 6429 env10672 = env10673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env10672 == env10673) = true)

theorem identity10673 : scanCanonicalize (H12AffineFastState.compose env10673 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10673 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env10674 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,6201,4113,0,115,2112,4112,53,1,4161,6241,17,2,6201,65,4160,4097,4097,2128,69,32,36,33,2049,6721]

theorem envBound10674 : H12AffineFastState.Bounded env10674 := by
  intro p hp
  have h : env10674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10673_10674 : H12AffineEnvironment.transform 7 36 env10673 = env10674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10673 == env10674) = true)

theorem identity10674 : scanCanonicalize (H12AffineFastState.compose env10674 (packedSelected [4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound10674 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env10675 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2113,120,2128,0,115,2112,2129,53,1,2048,32,17,2,120,65,2049,2112,2112,2128,69,32,36,33,2049,512]

theorem envBound10675 : H12AffineFastState.Bounded env10675 := by
  intro p hp
  have h : env10675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10674_10675 : H12AffineEnvironment.transform 11 2113 env10674 = env10675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env10674 == env10675) = true)

theorem identity10675 : scanCanonicalize (H12AffineFastState.compose env10675 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound10675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10676 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,96,120,113,0,115,97,112,53,1,33,32,17,2,120,65,32,97,97,113,69,32,36,33,32,512]

theorem envBound10676 : H12AffineFastState.Bounded env10676 := by
  intro p hp
  have h : env10676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10675_10676 : H12AffineEnvironment.transform 10 33 env10675 = env10676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env10675 == env10676) = true)

theorem identity10676 : scanCanonicalize (H12AffineFastState.compose env10676 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound10676 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10677 : List Nat := [2,4,8,16,32,64,8,36,11,53,33,96,120,113,0,115,97,112,53,1,33,32,17,2,120,65,32,97,97,113,69,32,36,33,32,11]

theorem envBound10677 : H12AffineFastState.Bounded env10677 := by
  intro p hp
  have h : env10677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10676_10677 : H12AffineEnvironment.transform 8 11 env10676 = env10677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env10676 == env10677) = true)

theorem identity10677 : scanCanonicalize (H12AffineFastState.compose env10677 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10677 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env10678 : List Nat := [2,4,8,16,32,16,8,36,11,53,33,48,40,33,0,35,49,32,53,1,33,32,17,2,40,17,32,49,49,33,21,32,36,33,32,11]

theorem envBound10678 : H12AffineFastState.Bounded env10678 := by
  intro p hp
  have h : env10678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10677_10678 : H12AffineEnvironment.transform 5 16 env10677 = env10678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10677 == env10678) = true)

theorem identity10678 : scanCanonicalize (H12AffineFastState.compose env10678 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound10678 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10679 : List Nat := [2,4,8,16,5,16,8,1,11,16,4,21,13,4,0,6,20,5,16,1,4,5,17,2,13,17,5,20,20,4,21,5,1,4,5,11]

theorem envBound10679 : H12AffineFastState.Bounded env10679 := by
  intro p hp
  have h : env10679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10678_10679 : H12AffineEnvironment.transform 4 5 env10678 = env10679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env10678 == env10679) = true)

theorem identity10679 : scanCanonicalize (H12AffineFastState.compose env10679 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10679 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10680 : List Nat := [2,4,0,16,5,16,0,1,3,16,4,21,5,4,0,6,20,5,16,1,4,5,17,2,5,17,5,20,20,4,21,5,1,4,5,3]

theorem envBound10680 : H12AffineFastState.Bounded env10680 := by
  intro p hp
  have h : env10680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10679_10680 : H12AffineEnvironment.transform 2 0 env10679 = env10680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10679 == env10680) = true)

theorem identity10680 : scanCanonicalize (H12AffineFastState.compose env10680 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound10680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10681 : List Nat := [2,0,0,16,1,16,0,1,3,16,0,17,1,0,0,2,16,1,16,1,0,1,17,2,1,17,1,16,16,0,17,1,1,0,1,3]

theorem envBound10681 : H12AffineFastState.Bounded env10681 := by
  intro p hp
  have h : env10681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10680_10681 : H12AffineEnvironment.transform 1 0 env10680 = env10681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env10680 == env10681) = true)

def env10682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,213351,17,21762,8193,65,171280,115014,17665,35189,119043,156013,256,98679,90202,63069]

theorem envBound10682 : H12AffineFastState.Bounded env10682 := by
  intro p hp
  have h : env10682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10666_10682 : H12AffineEnvironment.transform 6 9 env10666 = env10682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10666 == env10682) = true)

theorem identity10682 : scanCanonicalize (H12AffineFastState.compose env10682 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound10682 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149860,1024,29789,4161,213351,17,21762,8193,65,158028,79130,17665,32041,75103,156013,256,95531,90202,513]

theorem envBound10683 : H12AffineFastState.Bounded env10683 := by
  intro p hp
  have h : env10683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10682_10683 : H12AffineEnvironment.transform 14 29788 env10682 = env10683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10682 == env10683) = true)

theorem identity10683 : scanCanonicalize (H12AffineFastState.compose env10683 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10683 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76159,1024,29789,4161,8572,17,21762,8193,65,67927,79130,17665,32041,75103,65910,256,95531,90202,513]

theorem envBound10684 : H12AffineFastState.Bounded env10684 := by
  intro p hp
  have h : env10684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10683_10684 : H12AffineEnvironment.transform 16 90139 env10683 = env10684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10683 == env10684) = true)

theorem identity10684 : scanCanonicalize (H12AffineFastState.compose env10684 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound10684 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5393,23669,1024,29789,4161,8572,17,21762,8193,65,31837,16400,17665,32041,20565,29820,256,33,5456,513]

theorem envBound10685 : H12AffineFastState.Bounded env10685 := by
  intro p hp
  have h : env10685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10684_10685 : H12AffineEnvironment.transform 15 29962 env10684 = env10685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env10684 == env10685) = true)

theorem identity10685 : scanCanonicalize (H12AffineFastState.compose env10685 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10685 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env10686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,8494,5393,2129,1024,8313,4161,8572,17,294,8193,65,10361,5172,4389,10509,1137,8280,256,33,5456,513]

theorem envBound10686 : H12AffineFastState.Bounded env10686 := by
  intro p hp
  have h : env10686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10685_10686 : H12AffineEnvironment.transform 13 5156 env10685 = env10686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10685 == env10686) = true)

theorem identity10686 : scanCanonicalize (H12AffineFastState.compose env10686 (packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10686 : packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env10687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5156,1,343,5393,2129,1024,0,4161,261,17,294,120,65,2048,5172,4389,2420,1137,33,256,33,5456,513]

theorem envBound10687 : H12AffineFastState.Bounded env10687 := by
  intro p hp
  have h : env10687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10686_10687 : H12AffineEnvironment.transform 12 121 env10686 = env10687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10686 == env10687) = true)

theorem identity10687 : scanCanonicalize (H12AffineFastState.compose env10687 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10687 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10688 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5156,1,114,5172,2129,1024,0,4161,32,17,3,120,65,2048,5172,4096,2129,1137,33,37,33,5237,513]

theorem envBound10688 : H12AffineFastState.Bounded env10688 := by
  intro p hp
  have h : env10688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10687_10688 : H12AffineEnvironment.transform 7 37 env10687 = env10688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10687 == env10688) = true)

theorem identity10688 : scanCanonicalize (H12AffineFastState.compose env10688 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound10688 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10689 : List Nat := [2,4,8,16,32,64,9,37,512,565,2048,4096,121,4625,1,114,4609,2129,565,0,4161,32,17,3,120,65,2048,4609,4096,2129,580,33,37,33,4672,513]

theorem envBound10689 : H12AffineFastState.Bounded env10689 := by
  intro p hp
  have h : env10689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10688_10689 : H12AffineEnvironment.transform 9 565 env10688 = env10689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env10688 == env10689) = true)

theorem identity10689 : scanCanonicalize (H12AffineFastState.compose env10689 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10689 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10690 : List Nat := [2,4,8,16,32,17,9,37,512,565,2048,4096,40,4625,1,35,4609,2048,565,0,4112,32,17,3,41,16,2048,4609,4096,2048,533,33,37,33,4625,513]

theorem envBound10690 : H12AffineFastState.Bounded env10690 := by
  intro p hp
  have h : env10690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10689_10690 : H12AffineEnvironment.transform 5 17 env10689 = env10690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10689 == env10690) = true)

theorem identity10690 : scanCanonicalize (H12AffineFastState.compose env10690 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10691 : List Nat := [2,4,8,0,32,1,9,37,512,549,2048,4096,40,4609,1,35,4609,2048,549,0,4096,32,1,3,41,0,2048,4609,4096,2048,517,33,37,33,4609,513]

theorem envBound10691 : H12AffineFastState.Bounded env10691 := by
  intro p hp
  have h : env10691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10690_10691 : H12AffineEnvironment.transform 3 0 env10690 = env10691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10690 == env10691) = true)

theorem identity10691 : scanCanonicalize (H12AffineFastState.compose env10691 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound10691 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10692 : List Nat := [2,4,8,0,32,1,9,37,512,549,513,4096,40,4609,1,35,4609,513,549,0,4096,32,1,3,41,0,513,4609,4096,513,517,33,37,33,4609,513]

theorem envBound10692 : H12AffineFastState.Bounded env10692 := by
  intro p hp
  have h : env10692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10691_10692 : H12AffineEnvironment.transform 10 513 env10691 = env10692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env10691 == env10692) = true)

theorem identity10692 : scanCanonicalize (H12AffineFastState.compose env10692 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound10692 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10693 : List Nat := [2,4,8,0,32,1,9,37,512,549,513,513,40,0,1,35,0,513,549,0,513,32,1,3,41,0,513,0,513,513,517,33,37,33,0,513]

theorem envBound10693 : H12AffineFastState.Bounded env10693 := by
  intro p hp
  have h : env10693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10692_10693 : H12AffineEnvironment.transform 11 513 env10692 = env10693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env10692 == env10693) = true)

theorem identity10693 : scanCanonicalize (H12AffineFastState.compose env10693 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10693 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10694 : List Nat := [2,4,8,0,32,1,9,37,1,36,0,0,40,0,1,35,0,0,36,0,0,32,1,3,41,0,0,0,0,0,4,33,37,33,0,0]

theorem envBound10694 : H12AffineFastState.Bounded env10694 := by
  intro p hp
  have h : env10694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10693_10694 : H12AffineEnvironment.transform 8 1 env10693 = env10694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10693 == env10694) = true)

def env10695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound10695 : H12AffineFastState.Bounded env10695 := by
  intro p hp
  have h : env10695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10514_10695 : H12AffineEnvironment.transform 18 1025 env10514 = env10695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10514 == env10695) = true)

theorem identity10695 : scanCanonicalize (H12AffineFastState.compose env10695 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485295) := by decide +kernel

theorem selectedBound10695 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485295,16777216,8328,65,23211054,18973837,375166,2305070,19163199,23160256,257,17049730,17090855,19222505]

theorem envBound10696 : H12AffineFastState.Bounded env10696 := by
  intro p hp
  have h : env10696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10695_10696 : H12AffineEnvironment.transform 22 2485295 env10695 = env10696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485295 env10695 == env10696) = true)

def env10697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,16777216,8328,65,16959642,18973837,375166,2305070,19163199,16875892,257,17049730,17090855,19222505]

theorem envBound10697 : H12AffineFastState.Bounded env10697 := by
  intro p hp
  have h : env10697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10696_10697 : H12AffineEnvironment.transform 21 2155700 env10696 = env10697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155700 env10696 == env10697) = true)

def env10698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,2559344,8328,65,2475498,428541,375166,2305070,222543,2526212,257,2303474,2344023,148121]

theorem envBound10698 : H12AffineFastState.Bounded env10698 := by
  intro p hp
  have h : env10698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10697_10698 : H12AffineEnvironment.transform 23 2559344 env10697 = env10698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env10697 == env10698) = true)

theorem identity10698 : scanCanonicalize (H12AffineFastState.compose env10698 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388278) := by decide +kernel

theorem selectedBound10698 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,329730,153,188870,8328,65,10588,428541,375166,442520,222543,221362,257,444740,403681,148121]

theorem envBound10699 : H12AffineFastState.Bounded env10699 := by
  intro p hp
  have h : env10699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10698_10699 : H12AffineEnvironment.transform 20 388278 env10698 = env10699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388278 env10698 == env10699) = true)

theorem identity10699 : scanCanonicalize (H12AffineFastState.compose env10699 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10699 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env10700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,17,188750,8192,65,10588,428405,375166,442384,222543,221242,257,444740,403561,147985]

theorem envBound10700 : H12AffineFastState.Bounded env10700 := by
  intro p hp
  have h : env10700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10699_10700 : H12AffineEnvironment.transform 6 8 env10699 = env10700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10699 == env10700) = true)

theorem identity10700 : scanCanonicalize (H12AffineFastState.compose env10700 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound10700 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388158,329730,17,41310,8192,65,10588,313701,375166,294912,75103,73770,257,297300,288889,513]

theorem envBound10701 : H12AffineFastState.Bounded env10701 := by
  intro p hp
  have h : env10701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10700_10701 : H12AffineEnvironment.transform 16 16400 env10700 = env10701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10700 == env10701) = true)

theorem identity10701 : scanCanonicalize (H12AffineFastState.compose env10701 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10701 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env10702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,16400,262144,1025,32769,380259,329730,17,32771,349,65,2049,313701,366627,294912,66562,65911,257,297300,280868,513]

theorem envBound10702 : H12AffineFastState.Bounded env10702 := by
  intro p hp
  have h : env10702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10701_10702 : H12AffineEnvironment.transform 12 349 env10701 = env10702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10701 == env10702) = true)

def env10703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485295,2559345,8328,65,2475499,428540,375166,2305070,222542,2526213,257,2303475,2344022,148120]

theorem envBound10703 : H12AffineFastState.Bounded env10703 := by
  intro p hp
  have h : env10703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10697_10703 : H12AffineEnvironment.transform 23 2559345 env10697 = env10703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env10697 == env10703) = true)

theorem identity10703 : scanCanonicalize (H12AffineFastState.compose env10703 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound10703 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329866,17,188751,8328,65,10709,428540,375166,442384,222542,221243,257,444877,403560,148120]

theorem envBound10704 : H12AffineFastState.Bounded env10704 := by
  intro p hp
  have h : env10704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10703_10704 : H12AffineEnvironment.transform 20 388158 env10703 = env10704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env10703 == env10704) = true)

def env10705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,17,188751,8192,65,10589,428404,375166,442384,222542,221243,257,444741,403560,147984]

theorem envBound10705 : H12AffineFastState.Bounded env10705 := by
  intro p hp
  have h : env10705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10704_10705 : H12AffineEnvironment.transform 6 8 env10704 = env10705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10704 == env10705) = true)

theorem identity10705 : scanCanonicalize (H12AffineFastState.compose env10705 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10705 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329730,17,41310,8192,65,10589,313701,375166,294913,75103,73770,257,297300,288889,513]

theorem envBound10706 : H12AffineFastState.Bounded env10706 := by
  intro p hp
  have h : env10706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10705_10706 : H12AffineEnvironment.transform 16 16401 env10705 = env10706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10705 == env10706) = true)

theorem identity10706 : scanCanonicalize (H12AffineFastState.compose env10706 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10706 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env10707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115734,73770,17,41310,8192,65,10589,57677,102742,43049,75103,73770,257,41340,16465,513]

theorem envBound10707 : H12AffineFastState.Bounded env10707 := by
  intro p hp
  have h : env10707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10706_10707 : H12AffineEnvironment.transform 17 10280 env10706 = env10707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10706 == env10707) = true)

theorem identity10707 : scanCanonicalize (H12AffineFastState.compose env10707 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10707 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1025,32769,25628,32800,17,41310,8192,65,10589,57677,12636,43049,34133,32800,257,41340,16465,513]

theorem envBound10708 : H12AffineFastState.Bounded env10708 := by
  intro p hp
  have h : env10708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10707_10708 : H12AffineEnvironment.transform 15 40970 env10707 = env10708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10707 == env10708) = true)

theorem identity10708 : scanCanonicalize (H12AffineFastState.compose env10708 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10708 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env10709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33111,16401,2421,1025,32769,17729,32800,17,32771,349,65,2048,49168,4097,35188,34133,32800,257,32801,16465,513]

theorem envBound10709 : H12AffineFastState.Bounded env10709 := by
  intro p hp
  have h : env10709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10708_10709 : H12AffineEnvironment.transform 12 349 env10708 = env10709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10708 == env10709) = true)

theorem identity10709 : scanCanonicalize (H12AffineFastState.compose env10709 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10709 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,343,16401,2421,1025,1,17729,32,17,3,349,65,2048,16400,4097,2420,1365,32,257,33,16465,513]

theorem envBound10710 : H12AffineFastState.Bounded env10710 := by
  intro p hp
  have h : env10710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10709_10710 : H12AffineEnvironment.transform 14 0 env10709 = env10710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10709 == env10710) = true)

theorem identity10710 : scanCanonicalize (H12AffineFastState.compose env10710 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1636) := by decide +kernel

theorem selectedBound10710 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1636,0,343,1653,2421,1025,1,805,32,17,3,349,65,2048,1652,4097,2420,1365,32,257,33,1589,513]

theorem envBound10711 : H12AffineFastState.Bounded env10711 := by
  intro p hp
  have h : env10711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10710_10711 : H12AffineEnvironment.transform 13 1636 env10710 = env10711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1636 env10710 == env10711) = true)

theorem identity10711 : scanCanonicalize (H12AffineFastState.compose env10711 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound10711 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,528,4096,349,1636,0,343,1653,869,1025,1,805,32,17,3,349,65,528,1652,4097,868,1365,32,257,33,1589,513]

theorem envBound10712 : H12AffineFastState.Bounded env10712 := by
  intro p hp
  have h : env10712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10711_10712 : H12AffineEnvironment.transform 10 528 env10711 = env10712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env10711 == env10712) = true)

theorem identity10712 : scanCanonicalize (H12AffineFastState.compose env10712 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound10712 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env10713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,528,868,349,1636,0,343,1653,869,1025,1,805,32,17,3,349,65,528,1652,869,868,1365,32,257,33,1589,513]

theorem envBound10713 : H12AffineFastState.Bounded env10713 := by
  intro p hp
  have h : env10713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10712_10713 : H12AffineEnvironment.transform 11 868 env10712 = env10713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env10712 == env10713) = true)

theorem identity10713 : scanCanonicalize (H12AffineFastState.compose env10713 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10713 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env10714 : List Nat := [2,4,8,16,32,17,8,256,512,1024,528,821,268,1589,0,262,1572,820,1025,1,805,32,17,3,268,16,528,1573,820,821,1284,32,257,33,1589,513]

theorem envBound10714 : H12AffineFastState.Bounded env10714 := by
  intro p hp
  have h : env10714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10713_10714 : H12AffineEnvironment.transform 5 17 env10713 = env10714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10713 == env10714) = true)

theorem identity10714 : scanCanonicalize (H12AffineFastState.compose env10714 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound10714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10715 : List Nat := [2,4,8,16,32,17,8,256,512,37,528,821,268,528,0,262,513,820,36,1,805,32,17,3,268,16,528,512,820,821,289,32,257,33,528,513]

theorem envBound10715 : H12AffineFastState.Bounded env10715 := by
  intro p hp
  have h : env10715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10714_10715 : H12AffineEnvironment.transform 9 37 env10714 = env10715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env10714 == env10715) = true)

theorem identity10715 : scanCanonicalize (H12AffineFastState.compose env10715 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound10715 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10716 : List Nat := [2,4,8,16,32,17,8,256,293,37,309,16,268,309,0,262,292,17,36,1,0,32,17,3,268,16,309,293,17,16,289,32,257,33,309,292]

theorem envBound10716 : H12AffineFastState.Bounded env10716 := by
  intro p hp
  have h : env10716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10715_10716 : H12AffineEnvironment.transform 8 293 env10715 = env10716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env10715 == env10716) = true)

def env10717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329731,17,188751,8193,65,10588,428405,375166,442384,222542,221243,257,444740,403560,147985]

theorem envBound10717 : H12AffineFastState.Bounded env10717 := by
  intro p hp
  have h : env10717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10704_10717 : H12AffineEnvironment.transform 6 9 env10704 = env10717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10704 == env10717) = true)

theorem identity10717 : scanCanonicalize (H12AffineFastState.compose env10717 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound10717 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1025,32769,388158,329731,17,3,8193,65,10588,288825,375166,270684,99330,98679,257,272392,313636,41821]

theorem envBound10718 : H12AffineFastState.Bounded env10718 := by
  intro p hp
  have h : env10718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10717_10718 : H12AffineEnvironment.transform 16 57676 env10717 = env10718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env10717 == env10718) = true)

theorem identity10718 : scanCanonicalize (H12AffineFastState.compose env10718 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10718 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env10719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,43048,1025,32769,82966,106539,17,3,8193,65,10588,49169,69974,35188,99330,98679,257,32800,24844,41821]

theorem envBound10719 : H12AffineFastState.Bounded env10719 := by
  intro p hp
  have h : env10719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10718_10719 : H12AffineEnvironment.transform 17 43048 env10718 = env10719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10718 == env10719) = true)

theorem identity10719 : scanCanonicalize (H12AffineFastState.compose env10719 (packedSelected [0,5,7,11,12,15,16,17,18,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10719 : packedSelected [0,5,7,11,12,15,16,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env10720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49169,35189,1025,32769,82966,98678,17,3,348,65,2049,49169,69974,35188,99330,98679,257,32800,16465,33280]

theorem envBound10720 : H12AffineFastState.Bounded env10720 := by
  intro p hp
  have h : env10720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10719_10720 : H12AffineEnvironment.transform 12 349 env10719 = env10720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10719 == env10720) = true)

theorem identity10720 : scanCanonicalize (H12AffineFastState.compose env10720 (packedSelected [1,3,4,5,8,9,11,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound10720 : packedSelected [1,3,4,5,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env10721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33031,49169,35189,1025,32769,50449,113,17,3,348,65,2049,49169,36945,35188,1285,112,257,32800,16465,33280]

theorem envBound10721 : H12AffineFastState.Bounded env10721 := by
  intro p hp
  have h : env10721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10720_10721 : H12AffineEnvironment.transform 15 33031 env10720 = env10721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env10720 == env10721) = true)

theorem identity10721 : scanCanonicalize (H12AffineFastState.compose env10721 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10721 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env10722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5156,32768,33031,37941,35189,1025,32769,37173,113,17,3,348,65,2049,37941,36945,35188,1285,112,257,32800,5237,33280]

theorem envBound10722 : H12AffineFastState.Bounded env10722 := by
  intro p hp
  have h : env10722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10721_10722 : H12AffineEnvironment.transform 13 5156 env10721 = env10722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10721 == env10722) = true)

def env10723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,16777216,8328,65,16959643,18973837,375166,2305070,19163199,16875893,257,17049730,17090855,19222505]

theorem envBound10723 : H12AffineFastState.Bounded env10723 := by
  intro p hp
  have h : env10723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10696_10723 : H12AffineEnvironment.transform 21 2155701 env10696 = env10723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155701 env10696 == env10723) = true)

def env10724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,2559344,8328,65,2475499,428541,375166,2305070,222543,2526213,257,2303474,2344023,148121]

theorem envBound10724 : H12AffineFastState.Bounded env10724 := by
  intro p hp
  have h : env10724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10723_10724 : H12AffineEnvironment.transform 23 2559344 env10723 = env10724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env10723 == env10724) = true)

def env10725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,2559344,8192,65,2475363,428405,375166,2305070,222543,2526213,257,2303354,2344023,147985]

theorem envBound10725 : H12AffineFastState.Bounded env10725 := by
  intro p hp
  have h : env10725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10725 : H12AffineEnvironment.transform 6 8 env10724 = env10725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10724 == env10725) = true)

theorem identity10725 : scanCanonicalize (H12AffineFastState.compose env10725 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound10725 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env10726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,2155581,2485295,2444640,8192,65,2475363,313701,375166,2190398,75103,2411541,257,2188650,2196551,513]

theorem envBound10726 : H12AffineFastState.Bounded env10726 := by
  intro p hp
  have h : env10726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10725_10726 : H12AffineEnvironment.transform 16 16400 env10725 = env10726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10725 == env10726) = true)

def env10727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,2155581,2212871,2188616,8192,65,2223435,57677,102742,2190398,75103,2155581,257,2188650,2196551,513]

theorem envBound10727 : H12AffineFastState.Bounded env10727 := by
  intro p hp
  have h : env10727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10726_10727 : H12AffineEnvironment.transform 17 10280 env10726 = env10727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10726 == env10727) = true)

theorem identity10727 : scanCanonicalize (H12AffineFastState.compose env10727 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound10727 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env10728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,2097152,2155581,2122764,2147651,8192,65,2116928,57677,12637,2149429,34132,2155581,257,2147681,2106444,513]

theorem envBound10728 : H12AffineFastState.Bounded env10728 := by
  intro p hp
  have h : env10728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10727_10728 : H12AffineEnvironment.transform 15 40971 env10727 = env10728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env10727 == env10728) = true)

theorem identity10728 : scanCanonicalize (H12AffineFastState.compose env10728 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound10728 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,25676,32881,64,41231,8192,65,10508,57677,12637,43129,34132,32881,257,41261,16384,513]

theorem envBound10729 : H12AffineFastState.Bounded env10729 := by
  intro p hp
  have h : env10729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10728_10729 : H12AffineEnvironment.transform 20 25676 env10728 = env10729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env10728 == env10729) = true)

theorem identity10729 : scanCanonicalize (H12AffineFastState.compose env10729 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10729 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33110,16400,2421,1025,32769,17681,32881,64,32850,349,65,2129,49168,4096,35108,34132,32881,257,32880,16384,513]

theorem envBound10730 : H12AffineFastState.Bounded env10730 := by
  intro p hp
  have h : env10730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10729_10730 : H12AffineEnvironment.transform 12 349 env10729 = env10730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10729 == env10730) = true)

theorem identity10730 : scanCanonicalize (H12AffineFastState.compose env10730 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound10730 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,263,16400,2421,1025,80,17681,32,64,3,349,65,2129,16449,4096,2421,1285,32,257,33,16384,513]

theorem envBound10731 : H12AffineFastState.Bounded env10731 := by
  intro p hp
  have h : env10731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10730_10731 : H12AffineEnvironment.transform 14 81 env10730 = env10731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env10730 == env10731) = true)

theorem identity10731 : scanCanonicalize (H12AffineFastState.compose env10731 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10731 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10732 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16400,2340,1025,1,17681,32,17,3,268,16,2048,16400,4096,2340,1285,32,257,33,16384,513]

theorem envBound10732 : H12AffineFastState.Bounded env10732 := by
  intro p hp
  have h : env10732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10731_10732 : H12AffineEnvironment.transform 5 17 env10731 = env10732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10731 == env10732) = true)

theorem identity10732 : scanCanonicalize (H12AffineFastState.compose env10732 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10733 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,16384,0,3,16400,2080,1025,1,17429,32,17,3,8,16,2048,16400,4096,2080,1025,32,5,33,16384,513]

theorem envBound10733 : H12AffineFastState.Bounded env10733 := by
  intro p hp
  have h : env10733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10732_10733 : H12AffineEnvironment.transform 7 4 env10732 = env10733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10732 == env10733) = true)

theorem identity10733 : scanCanonicalize (H12AffineFastState.compose env10733 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound10733 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10734 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,5124,0,3,5140,2080,1025,1,4113,32,17,3,8,16,2048,5140,4096,2080,1025,32,5,33,5124,513]

theorem envBound10734 : H12AffineFastState.Bounded env10734 := by
  intro p hp
  have h : env10734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10733_10734 : H12AffineEnvironment.transform 13 5124 env10733 = env10734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env10733 == env10734) = true)

theorem identity10734 : scanCanonicalize (H12AffineFastState.compose env10734 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound10734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10735 : List Nat := [2,4,8,16,32,17,8,4,32,1024,2048,4096,8,5124,0,3,5140,2080,1025,1,4113,32,17,3,8,16,2048,5140,4096,2080,1025,32,5,33,5124,33]

theorem envBound10735 : H12AffineFastState.Bounded env10735 := by
  intro p hp
  have h : env10735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10734_10735 : H12AffineEnvironment.transform 8 32 env10734 = env10735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env10734 == env10735) = true)

theorem identity10735 : scanCanonicalize (H12AffineFastState.compose env10735 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound10735 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10736 : List Nat := [2,4,8,16,32,17,8,4,32,1024,2048,1045,8,17,0,3,1,2080,1025,1,1028,32,17,3,8,16,2048,1,1045,2080,1025,32,5,33,17,33]

theorem envBound10736 : H12AffineFastState.Bounded env10736 := by
  intro p hp
  have h : env10736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10735_10736 : H12AffineEnvironment.transform 11 1045 env10735 = env10736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env10735 == env10736) = true)

theorem identity10736 : scanCanonicalize (H12AffineFastState.compose env10736 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10736 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10737 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1045,8,17,0,3,1,2048,1025,1,1028,0,17,3,8,16,2048,1,1045,2048,1025,0,5,1,17,1]

theorem envBound10737 : H12AffineFastState.Bounded env10737 := by
  intro p hp
  have h : env10737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10736_10737 : H12AffineEnvironment.transform 4 0 env10736 = env10737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10736 == env10737) = true)

theorem identity10737 : scanCanonicalize (H12AffineFastState.compose env10737 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10737 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0