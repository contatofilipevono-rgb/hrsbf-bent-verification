import H12CloudChart0Data052

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans13293_13294 : H12AffineEnvironment.transform 10 0 env13293 = env13294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13293 == env13294) = true)

theorem identity13294 : scanCanonicalize (H12AffineFastState.compose env13294 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13295 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,17,9,1,0,3,17,1,21,1,0,0,16,2,9,16,1,16,16,0,21,1,5,1,0,512]

theorem envBound13295 : H12AffineFastState.Bounded env13295 := by
  intro p hp
  have h : env13295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13294_13295 : H12AffineEnvironment.transform 11 17 env13294 = env13295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13294 == env13295) = true)

def env13296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4262263,10816866,10507601,8683536,331127,15068206,257,2444611,2468975,272937]

theorem envBound13296 : H12AffineFastState.Bounded env13296 := by
  intro p hp
  have h : env13296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13220_13296 : H12AffineEnvironment.transform 16 16401 env13220 = env13296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13220 == env13296) = true)

theorem identity13296 : scanCanonicalize (H12AffineFastState.compose env13296 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13296 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429903,8192,65,4262263,10560842,10507601,8431672,75103,14795782,257,2188651,2196551,513]

theorem envBound13297 : H12AffineFastState.Bounded env13297 := by
  intro p hp
  have h : env13297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13296_13297 : H12AffineEnvironment.transform 17 10280 env13296 = env13297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13296 == env13297) = true)

def env13298 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429855,8192,17,4262183,10560794,10507521,8431672,75023,14795782,257,2188603,2196503,513]

theorem envBound13298 : H12AffineFastState.Bounded env13298 := by
  intro p hp
  have h : env13298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13297_13298 : H12AffineEnvironment.transform 5 16 env13297 = env13298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13297 == env13298) = true)

theorem identity13298 : scanCanonicalize (H12AffineFastState.compose env13298 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4292919) := by decide +kernel

theorem selectedBound13298 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env13299 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4292919,4268072,8192,17,4262183,6333485,6411318,4270351,75023,2114865,257,2188603,2196503,513]

theorem envBound13299 : H12AffineFastState.Bounded env13299 := by
  intro p hp
  have h : env13299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13298_13299 : H12AffineEnvironment.transform 22 4292919 env13298 = env13299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292919 env13298 == env13299) = true)

theorem identity13299 : scanCanonicalize (H12AffineFastState.compose env13299 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound13299 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env13300 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,8492,106523,65796,8192,17,75787,2131201,2225434,67619,75023,2114865,257,2188603,2196503,513]

theorem envBound13300 : H12AffineFastState.Bounded env13300 := by
  intro p hp
  have h : env13300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13299_13300 : H12AffineEnvironment.transform 21 8492 env13299 = env13300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env13299 == env13300) = true)

theorem identity13300 : scanCanonicalize (H12AffineFastState.compose env13300 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound13300 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13301 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,50449,8492,106523,65796,8192,17,75787,16400,77835,67619,75023,32800,257,106538,82182,513]

theorem envBound13301 : H12AffineFastState.Bounded env13301 := by
  intro p hp
  have h : env13301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13300_13301 : H12AffineEnvironment.transform 20 50449 env13300 = env13301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env13300 == env13301) = true)

theorem identity13301 : scanCanonicalize (H12AffineFastState.compose env13301 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound13301 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13302 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1025,32769,50449,8492,16,41231,8192,17,34816,16400,36864,43048,34052,32800,257,33,57613,513]

theorem envBound13302 : H12AffineFastState.Bounded env13302 := by
  intro p hp
  have h : env13302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13301_13302 : H12AffineEnvironment.transform 15 40971 env13301 = env13302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env13301 == env13302) = true)

theorem identity13302 : scanCanonicalize (H12AffineFastState.compose env13302 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13303 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,33030,16401,2341,1025,32769,50449,33,16,32770,269,17,34816,16400,36864,35109,34052,32800,257,33,49152,513]

theorem envBound13303 : H12AffineFastState.Bounded env13303 := by
  intro p hp
  have h : env13303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13302_13303 : H12AffineEnvironment.transform 12 269 env13302 = env13303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13302 == env13303) = true)

theorem identity13303 : scanCanonicalize (H12AffineFastState.compose env13303 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13303 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13304 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,17680,33,16,3,269,17,2049,16400,4097,2340,1285,33,257,33,16385,513]

theorem envBound13304 : H12AffineFastState.Bounded env13304 := by
  intro p hp
  have h : env13304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13303_13304 : H12AffineEnvironment.transform 14 1 env13303 = env13304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13303 == env13304) = true)

theorem identity13304 : scanCanonicalize (H12AffineFastState.compose env13304 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound13304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13305 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,269,16384,1,263,16401,2341,1025,0,17680,33,16,3,269,17,2049,16400,1313,2340,1285,33,257,33,16385,513]

theorem envBound13305 : H12AffineFastState.Bounded env13305 := by
  intro p hp
  have h : env13305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13304_13305 : H12AffineEnvironment.transform 11 1312 env13304 = env13305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env13304 == env13305) = true)

theorem identity13305 : scanCanonicalize (H12AffineFastState.compose env13305 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound13305 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13306 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1557,1312,269,16384,1,263,16401,1840,1025,0,17680,33,16,3,269,17,1556,16400,1313,1841,1285,33,257,33,16385,513]

theorem envBound13306 : H12AffineFastState.Bounded env13306 := by
  intro p hp
  have h : env13306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13305_13306 : H12AffineEnvironment.transform 10 1557 env13305 = env13306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env13305 == env13306) = true)

theorem identity13306 : scanCanonicalize (H12AffineFastState.compose env13306 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound13306 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13307 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1557,1312,269,1028,1,263,1045,1840,1025,0,276,33,16,3,269,17,1556,1044,1313,1841,1285,33,257,33,1029,513]

theorem envBound13307 : H12AffineFastState.Bounded env13307 := by
  intro p hp
  have h : env13307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13306_13307 : H12AffineEnvironment.transform 13 1028 env13306 = env13307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env13306 == env13307) = true)

theorem identity13307 : scanCanonicalize (H12AffineFastState.compose env13307 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound13307 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13308 : List Nat := [2,4,8,16,32,16,8,256,277,1024,1280,1312,269,1028,1,263,1045,1061,1025,0,276,33,16,3,269,17,1281,1044,1313,1060,1285,33,257,33,1029,276]

theorem envBound13308 : H12AffineFastState.Bounded env13308 := by
  intro p hp
  have h : env13308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13307_13308 : H12AffineEnvironment.transform 8 277 env13307 = env13308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env13307 == env13308) = true)

theorem identity13308 : scanCanonicalize (H12AffineFastState.compose env13308 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13308 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env13309 : List Nat := [2,4,8,16,32,16,8,4,17,1024,1028,1060,9,1028,1,3,1045,1061,1025,0,16,33,16,3,9,17,1029,1044,1061,1060,1025,33,5,33,1029,16]

theorem envBound13309 : H12AffineFastState.Bounded env13309 := by
  intro p hp
  have h : env13309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13308_13309 : H12AffineEnvironment.transform 7 4 env13308 = env13309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13308 == env13309) = true)

theorem identity13309 : scanCanonicalize (H12AffineFastState.compose env13309 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound13309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13310 : List Nat := [2,4,8,16,32,16,8,4,17,4,0,32,9,0,1,3,17,33,5,0,16,33,16,3,9,17,1,16,33,32,5,33,5,33,1,16]

theorem envBound13310 : H12AffineFastState.Bounded env13310 := by
  intro p hp
  have h : env13310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13309_13310 : H12AffineEnvironment.transform 9 4 env13309 = env13310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env13309 == env13310) = true)

def env13311 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429854,8192,16,4262182,10560795,10507520,8431672,75022,14795782,257,2188602,2196502,513]

theorem envBound13311 : H12AffineFastState.Bounded env13311 := by
  intro p hp
  have h : env13311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13297_13311 : H12AffineEnvironment.transform 5 17 env13297 = env13311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13297 == env13311) = true)

theorem identity13311 : scanCanonicalize (H12AffineFastState.compose env13311 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4235580) := by decide +kernel

theorem selectedBound13311 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env13312 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4235580,4194338,8192,16,4262182,6390823,6353980,4196612,75022,2188602,257,2188602,2196502,513]

theorem envBound13312 : H12AffineFastState.Bounded env13312 := by
  intro p hp
  have h : env13312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13311_13312 : H12AffineEnvironment.transform 22 4235580 env13311 = env13312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235580 env13311 == env13312) = true)

theorem identity13312 : scanCanonicalize (H12AffineFastState.compose env13312 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound13312 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env13313 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,41260,16,41230,8192,16,108554,2172171,2118928,43048,75022,2188602,257,2188602,2196502,513]

theorem envBound13313 : H12AffineFastState.Bounded env13313 := by
  intro p hp
  have h : env13313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13312_13313 : H12AffineEnvironment.transform 21 41260 env13312 = env13313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env13312 == env13313) = true)

theorem identity13313 : scanCanonicalize (H12AffineFastState.compose env13313 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13313 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13314 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,2097152,41260,16,41230,8192,16,34816,2098433,2118928,43048,1284,2114864,257,2114864,2139164,513]

theorem envBound13314 : H12AffineFastState.Bounded env13314 := by
  intro p hp
  have h : env13314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13313_13314 : H12AffineEnvironment.transform 15 8202 env13313 = env13314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13313 == env13314) = true)

theorem identity13314 : scanCanonicalize (H12AffineFastState.compose env13314 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13314 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13315 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,8202,16401,10280,1025,0,2097152,8493,16,8463,8192,16,2049,2098433,2118928,10281,1284,2114864,257,2114864,2106397,513]

theorem envBound13315 : H12AffineFastState.Bounded env13315 := by
  intro p hp
  have h : env13315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13314_13315 : H12AffineEnvironment.transform 14 1 env13314 = env13315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13314 == env13315) = true)

theorem identity13315 : scanCanonicalize (H12AffineFastState.compose env13315 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13316 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,2097152,32,16,2,269,16,2049,2098433,2118928,2340,1284,2114864,257,2114864,2098448,513]

theorem envBound13316 : H12AffineFastState.Bounded env13316 := by
  intro p hp
  have h : env13316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13315_13316 : H12AffineEnvironment.transform 12 269 env13315 = env13316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13315 == env13316) = true)

theorem identity13316 : scanCanonicalize (H12AffineFastState.compose env13316 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 18724) := by decide +kernel

theorem selectedBound13316 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13317 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,18724,32,16,2,269,16,2049,19493,7220,2340,1284,3092,257,3092,19508,513]

theorem envBound13317 : H12AffineFastState.Bounded env13317 := by
  intro p hp
  have h : env13317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13316_13317 : H12AffineEnvironment.transform 20 18724 env13316 = env13317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 18724 env13316 == env13317) = true)

theorem identity13317 : scanCanonicalize (H12AffineFastState.compose env13317 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound13317 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env13318 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7425,1,263,7440,2341,1025,0,5157,32,16,2,269,16,2049,4388,7220,2340,1284,3092,257,3092,4405,513]

theorem envBound13318 : H12AffineFastState.Bounded env13318 := by
  intro p hp
  have h : env13318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13317_13318 : H12AffineEnvironment.transform 13 7425 env13317 = env13318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env13317 == env13318) = true)

theorem identity13318 : scanCanonicalize (H12AffineFastState.compose env13318 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound13318 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13319 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,269,292,1,263,309,2341,1025,0,2048,32,16,2,269,16,2049,3329,17,2340,1284,3092,257,3092,3344,513]

theorem envBound13319 : H12AffineFastState.Bounded env13319 := by
  intro p hp
  have h : env13319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13318_13319 : H12AffineEnvironment.transform 11 3109 env13318 = env13319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env13318 == env13319) = true)

theorem identity13319 : scanCanonicalize (H12AffineFastState.compose env13319 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13319 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13320 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2064,269,292,1,263,309,2341,52,0,2048,32,16,2,269,16,2049,2356,17,2340,305,2081,257,2081,2341,513]

theorem envBound13320 : H12AffineFastState.Bounded env13320 := by
  intro p hp
  have h : env13320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13319_13320 : H12AffineEnvironment.transform 9 53 env13319 = env13320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13319 == env13320) = true)

theorem identity13320 : scanCanonicalize (H12AffineFastState.compose env13320 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13320 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13321 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,40,1,1,34,16,2048,52,0,2048,32,16,2,40,16,2049,2065,17,2049,20,2081,36,2081,2048,513]

theorem envBound13321 : H12AffineFastState.Bounded env13321 := by
  intro p hp
  have h : env13321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13320_13321 : H12AffineEnvironment.transform 7 37 env13320 = env13321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13320 == env13321) = true)

def env13322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4409702,10816867,10507601,8830977,331127,15068207,257,2444610,2468975,272936]

theorem envBound13322 : H12AffineFastState.Bounded env13322 := by
  intro p hp
  have h : env13322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13219_13322 : H12AffineEnvironment.transform 6 9 env13219 = env13322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13219 == env13322) = true)

theorem identity13322 : scanCanonicalize (H12AffineFastState.compose env13322 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 4415531) := by decide +kernel

theorem selectedBound13322 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env13323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,4415531,4712780,8193,65,4409702,6712648,6501754,4562986,331127,2526212,257,2444610,2468975,272936]

theorem envBound13323 : H12AffineFastState.Bounded env13323 := by
  intro p hp
  have h : env13323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13322_13323 : H12AffineEnvironment.transform 22 4415531 env13322 = env13323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415531 env13322 == env13323) = true)

def env13324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,4268091,4565340,8193,65,4262262,6565208,6387050,4562986,331127,2411540,257,2444610,2468975,272936]

theorem envBound13324 : H12AffineFastState.Bounded env13324 := by
  intro p hp
  have h : env13324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13323_13324 : H12AffineEnvironment.transform 16 16400 env13323 = env13324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13323 == env13324) = true)

theorem identity13324 : scanCanonicalize (H12AffineFastState.compose env13324 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13324 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1025,8541,2097152,4194304,4268091,4524032,8193,65,4262262,6565208,6387050,4522358,331127,2387272,257,2444610,2428211,272936]

theorem envBound13325 : H12AffineFastState.Bounded env13325 := by
  intro p hp
  have h : env13325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13324_13325 : H12AffineEnvironment.transform 14 8540 env13324 = env13325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13324 == env13325) = true)

theorem identity13325 : scanCanonicalize (H12AffineFastState.compose env13325 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound13325 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env13326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,76159,1025,8541,2097152,4194304,4268091,4202879,8193,65,4262262,6358055,6387050,4204553,9224,2180151,257,2122813,2106444,66391]

theorem envBound13326 : H12AffineFastState.Bounded env13326 := by
  intro p hp
  have h : env13326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13325_13326 : H12AffineEnvironment.transform 17 76159 env13325 = env13326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env13325 == env13326) = true)

theorem identity13326 : scanCanonicalize (H12AffineFastState.compose env13326 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13326 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,2420,1025,8541,2097152,4194304,4194352,4202879,8193,65,4204925,6300716,6313313,4204553,9224,2122812,257,2122813,2106444,9052]

theorem envBound13327 : H12AffineFastState.Bounded env13327 := by
  intro p hp
  have h : env13327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13326_13327 : H12AffineEnvironment.transform 15 8203 env13326 = env13327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13326 == env13327) = true)

theorem identity13327 : scanCanonicalize (H12AffineFastState.compose env13327 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 4453) := by decide +kernel

theorem selectedBound13327 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env13328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,2420,1025,8541,4453,4194304,4194352,4202879,8193,65,4204925,4207945,4211716,4204553,9224,30041,257,30040,13609,9052]

theorem envBound13328 : H12AffineFastState.Bounded env13328 := by
  intro p hp
  have h : env13328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13327_13328 : H12AffineEnvironment.transform 20 4453 env13327 = env13328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4453 env13327 == env13328) = true)

theorem identity13328 : scanCanonicalize (H12AffineFastState.compose env13328 (packedSelected [0,2,6,11,14,16,17,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound13328 : packedSelected [0,2,6,11,14,16,17,18,20,27] rootPS < 2^1333 := by decide +kernel

def env13329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,2420,1025,8541,4453,21588,21604,29995,8193,65,32041,24861,4176,31837,9224,30041,257,30040,13609,9052]

theorem envBound13329 : H12AffineFastState.Bounded env13329 := by
  intro p hp
  have h : env13329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13328_13329 : H12AffineEnvironment.transform 21 21588 env13328 = env13329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env13328 == env13329) = true)

theorem identity13329 : scanCanonicalize (H12AffineFastState.compose env13329 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound13329 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env13330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8540,8203,5173,2420,1025,8541,4453,113,65,8462,8193,65,10508,13624,4176,10360,9224,8572,257,8573,13609,9052]

theorem envBound13330 : H12AffineFastState.Bounded env13330 := by
  intro p hp
  have h : env13330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13329_13330 : H12AffineEnvironment.transform 13 5157 env13329 = env13330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env13329 == env13330) = true)

theorem identity13330 : scanCanonicalize (H12AffineFastState.compose env13330 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13330 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env13331 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5157,8460,8203,5173,2340,1025,8461,4405,33,17,8462,8193,17,10508,13624,4096,10280,9224,8492,257,8493,13609,8972]

theorem envBound13331 : H12AffineFastState.Bounded env13331 := by
  intro p hp
  have h : env13331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13330_13331 : H12AffineEnvironment.transform 5 16 env13330 = env13331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13330 == env13331) = true)

theorem identity13331 : scanCanonicalize (H12AffineFastState.compose env13331 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound13331 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env13332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,2049,8460,8203,2065,2340,1025,8461,3345,33,17,8462,8193,17,10508,10524,3108,10280,9224,8492,257,8493,10509,8972]

theorem envBound13332 : H12AffineFastState.Bounded env13332 := by
  intro p hp
  have h : env13332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13331_13332 : H12AffineEnvironment.transform 11 3108 env13331 = env13332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env13331 == env13332) = true)

theorem identity13332 : scanCanonicalize (H12AffineFastState.compose env13332 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13332 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,269,2049,1,262,2065,2340,1025,0,3345,33,17,3,268,17,2049,2065,3108,2341,1285,33,257,32,2048,513]

theorem envBound13333 : H12AffineFastState.Bounded env13333 := by
  intro p hp
  have h : env13333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13332_13333 : H12AffineEnvironment.transform 12 269 env13332 = env13333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13332 == env13333) = true)

def env13334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,4268090,4565341,8193,65,4262263,6565209,6387051,4562986,331127,2411541,257,2444610,2468975,272936]

theorem envBound13334 : H12AffineFastState.Bounded env13334 := by
  intro p hp
  have h : env13334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13323_13334 : H12AffineEnvironment.transform 16 16401 env13323 = env13334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13323 == env13334) = true)

theorem identity13334 : scanCanonicalize (H12AffineFastState.compose env13334 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound13334 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,4268090,4268072,8193,65,4262263,6333484,6387051,4270431,99330,2114912,257,2212919,2172186,41821]

theorem envBound13335 : H12AffineFastState.Bounded env13335 := by
  intro p hp
  have h : env13335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13334_13335 : H12AffineEnvironment.transform 17 35189 env13334 = env13335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env13334 == env13335) = true)

theorem identity13335 : scanCanonicalize (H12AffineFastState.compose env13335 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13335 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35189,1025,32769,2097152,4194304,4235628,4235646,8193,65,4229153,6333484,6353981,4237321,1364,2114912,257,2114913,2139212,41821]

theorem envBound13336 : H12AffineFastState.Bounded env13336 := by
  intro p hp
  have h : env13336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13335_13336 : H12AffineEnvironment.transform 15 33110 env13335 = env13336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13335 == env13336) = true)

theorem identity13336 : scanCanonicalize (H12AffineFastState.compose env13336 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2147633) := by decide +kernel

theorem selectedBound13336 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35189,1025,32769,2097152,2147633,2122845,2122831,8193,65,2116880,24861,12556,2125112,1364,2114912,257,2114913,2139212,41821]

theorem envBound13337 : H12AffineFastState.Bounded env13337 := by
  intro p hp
  have h : env13337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13336_13337 : H12AffineEnvironment.transform 21 2147633 env13336 = env13337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2147633 env13336 == env13337) = true)

theorem identity13337 : scanCanonicalize (H12AffineFastState.compose env13337 (packedSelected [0,4,5,8,10,12,16,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound13337 : packedSelected [0,4,5,8,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env13338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35189,1025,32769,25676,41341,17,3,8193,65,10588,24861,12556,2420,1364,8492,257,8493,49152,41821]

theorem envBound13338 : H12AffineFastState.Bounded env13338 := by
  intro p hp
  have h : env13338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13337_13338 : H12AffineEnvironment.transform 20 25676 env13337 = env13338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env13337 == env13338) = true)

theorem identity13338 : scanCanonicalize (H12AffineFastState.compose env13338 (packedSelected [1,2,3,7,9,10,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8280) := by decide +kernel

theorem selectedBound13338 : packedSelected [1,2,3,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8280,8462,16401,10541,1025,8281,25676,293,17,3,8193,65,10588,24861,12556,2420,1364,8492,257,8493,24664,773]

theorem envBound13339 : H12AffineFastState.Bounded env13339 := by
  intro p hp
  have h : env13339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13338_13339 : H12AffineEnvironment.transform 14 8280 env13338 = env13339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8280 env13338 == env13339) = true)

theorem identity13339 : scanCanonicalize (H12AffineFastState.compose env13339 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound13339 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,16384,81,263,16401,2340,1025,80,17477,293,17,3,8,65,2389,16660,4357,2420,1364,293,257,292,16465,773]

theorem envBound13340 : H12AffineFastState.Bounded env13340 := by
  intro p hp
  have h : env13340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13339_13340 : H12AffineEnvironment.transform 12 9 env13339 = env13340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13339 == env13340) = true)

theorem identity13340 : scanCanonicalize (H12AffineFastState.compose env13340 (packedSelected [1,2,3,4,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13340 : packedSelected [1,2,3,4,7,10,16] rootPS < 2^1333 := by decide +kernel

def env13341 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,9,16384,81,2,16401,2081,1025,80,17477,32,17,3,8,65,2128,16401,4096,2161,1105,32,4,33,16465,512]

theorem envBound13341 : H12AffineFastState.Bounded env13341 := by
  intro p hp
  have h : env13341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13340_13341 : H12AffineEnvironment.transform 7 5 env13340 = env13341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13340 == env13341) = true)

theorem identity13341 : scanCanonicalize (H12AffineFastState.compose env13341 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13341 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13342 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,9,16384,33,2,16401,2081,1025,32,17461,32,17,3,8,49,2080,16401,4096,2049,1057,32,4,33,16417,512]

theorem envBound13342 : H12AffineFastState.Bounded env13342 := by
  intro p hp
  have h : env13342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13341_13342 : H12AffineEnvironment.transform 5 48 env13341 = env13342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13341 == env13342) = true)

theorem identity13342 : scanCanonicalize (H12AffineFastState.compose env13342 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound13342 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env13343 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,9,5124,33,2,5141,2081,1025,32,4145,32,17,3,8,49,2080,5141,4096,2049,1057,32,4,33,5157,512]

theorem envBound13343 : H12AffineFastState.Bounded env13343 := by
  intro p hp
  have h : env13343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13342_13343 : H12AffineEnvironment.transform 13 5124 env13342 = env13343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env13342 == env13343) = true)

theorem identity13343 : scanCanonicalize (H12AffineFastState.compose env13343 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13343 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13344 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,0,2,5141,2048,1025,1,4112,1,17,3,8,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound13344 : H12AffineFastState.Bounded env13344 := by
  intro p hp
  have h : env13344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13343_13344 : H12AffineEnvironment.transform 4 1 env13343 = env13344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13343 == env13344) = true)

def env13345 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,0,2,1029,2048,1025,1,0,1,17,3,8,16,2049,1029,16,2049,1024,1,4,0,1044,512]

theorem envBound13345 : H12AffineFastState.Bounded env13345 := by
  intro p hp
  have h : env13345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13344_13345 : H12AffineEnvironment.transform 11 16 env13344 = env13345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13344 == env13345) = true)

def env13346 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,0,2,1028,2048,1025,1,1,1,17,3,8,16,2049,1028,17,2049,1024,1,4,0,1045,512]

theorem envBound13346 : H12AffineFastState.Bounded env13346 := by
  intro p hp
  have h : env13346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13344_13346 : H12AffineEnvironment.transform 11 17 env13344 = env13346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13344 == env13346) = true)

theorem identity13346 : scanCanonicalize (H12AffineFastState.compose env13346 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound13346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13347 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,1,0,2,16,2048,21,1,1,1,17,3,8,16,2049,16,17,2049,20,1,4,0,1,512]

theorem envBound13347 : H12AffineFastState.Bounded env13347 := by
  intro p hp
  have h : env13347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13346_13347 : H12AffineEnvironment.transform 9 20 env13346 = env13347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13346 == env13347) = true)

theorem identity13347 : scanCanonicalize (H12AffineFastState.compose env13347 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound13347 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13348 : List Nat := [2,4,8,16,1,17,9,5,512,20,543,17,9,1,0,2,16,543,21,1,1,1,17,3,8,16,542,16,17,542,20,1,4,0,1,512]

theorem envBound13348 : H12AffineFastState.Bounded env13348 := by
  intro p hp
  have h : env13348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13347_13348 : H12AffineEnvironment.transform 10 543 env13347 = env13348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env13347 == env13348) = true)

def leafEnv13348 : List Nat := [2,4,8,16,1,17,9,5,512,20,543,17,9,1,0,2,16,543,21,1,1,1,17,3,21,8,1,16,542,16,17,542,20,1,4,0,5,3,1,512,1,1,0]

def active13348 : List Nat := [0,1,2,3,8]

def tree13348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13348 : H12WitnessSearch.Good tree13348 := H12GlobalWitnessIndex.good

theorem leafIdentity13348 : H12AffineFastState.composeSystem env13348 rootObs = leafEnv13348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13348 rootObs == leafEnv13348) = true)

theorem terminalChecked13348 : H12PackedTerminal.terminalCheckFast leafEnv13348 active13348 tree13348 = true := by decide +kernel

def env13349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound13349 : H12AffineFastState.Bounded env13349 := by
  intro p hp
  have h : env13349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13045_13349 : H12AffineEnvironment.transform 26 30393345 env13045 = env13349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env13045 == env13349) = true)

def env13350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound13350 : H12AffineFastState.Bounded env13350 := by
  intro p hp
  have h : env13350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13349_13350 : H12AffineEnvironment.transform 18 1024 env13349 = env13350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13349 == env13350) = true)

theorem identity13350 : scanCanonicalize (H12AffineFastState.compose env13350 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493479) := by decide +kernel

theorem selectedBound13350 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493479,8328,65,14797862,493739,10507601,8830977,10979383,4680167,256,8898699,8857903,10924000]

theorem envBound13351 : H12AffineFastState.Bounded env13351 := by
  intro p hp
  have h : env13351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13350_13351 : H12AffineEnvironment.transform 23 2493479 env13350 = env13351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493479 env13350 == env13351) = true)

def env13352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797862,115151,10507601,8423781,10600787,4268163,256,8487407,8478795,10544772]

theorem envBound13352 : H12AffineFastState.Bounded env13352 := by
  intro p hp
  have h : env13352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13351_13352 : H12AffineEnvironment.transform 17 149860 env13351 = env13352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env13351 == env13352) = true)

def env13353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,8388608,21763,8328,65,12704870,115151,8406289,8423781,8507667,4268163,256,8487407,8478795,8451780]

theorem envBound13353 : H12AffineFastState.Bounded env13353 := by
  intro p hp
  have h : env13353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13352_13353 : H12AffineEnvironment.transform 20 4160 env13352 = env13353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13352 == env13353) = true)

def env13354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363552,21763,8328,65,215366,115151,4378673,4332613,4408371,4268163,256,4396239,4453739,4350948]

theorem envBound13354 : H12AffineFastState.Bounded env13354 := by
  intro p hp
  have h : env13354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13353_13354 : H12AffineEnvironment.transform 22 4363552 env13353 = env13354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env13353 == env13354) = true)

def env13355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169400,152,21763,8328,65,215366,115151,17801,35325,119179,243003,256,98679,90323,63068]

theorem envBound13355 : H12AffineFastState.Bounded env13355 := by
  intro p hp
  have h : env13355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13354_13355 : H12AffineEnvironment.transform 21 169400 env13354 = env13355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env13354 == env13355) = true)

def env13356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21928,152,21763,8328,65,100694,115151,17801,35325,119179,95531,256,98679,90323,63068]

theorem envBound13356 : H12AffineFastState.Bounded env13356 := by
  intro p hp
  have h : env13356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13355_13356 : H12AffineEnvironment.transform 16 49168 env13355 = env13356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13355 == env13356) = true)

theorem identity13356 : scanCanonicalize (H12AffineFastState.compose env13356 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound13356 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38297,35188,1024,32769,4160,33,152,138,8328,65,100694,103494,4096,35325,99330,73890,256,98679,79194,41941]

theorem envBound13357 : H12AffineFastState.Bounded env13357 := by
  intro p hp
  have h : env13357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13356_13357 : H12AffineEnvironment.transform 13 5513 env13356 = env13357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env13356 == env13357) = true)

theorem identity13357 : scanCanonicalize (H12AffineFastState.compose env13357 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13357 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env13358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,13509,10280,1024,8541,4160,33,152,138,8328,65,75786,79130,4096,10401,75102,73890,256,73771,79194,649]

theorem envBound13358 : H12AffineFastState.Bounded env13358 := by
  intro p hp
  have h : env13358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13357_13358 : H12AffineEnvironment.transform 14 8540 env13357 = env13358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13357 == env13358) = true)

theorem identity13358 : scanCanonicalize (H12AffineFastState.compose env13358 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound13358 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env13359 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,65536,13340,10280,1024,8541,4160,33,65,83,8273,65,75786,79130,4096,10360,75102,73851,256,73771,79194,592]

theorem envBound13359 : H12AffineFastState.Bounded env13359 := by
  intro p hp
  have h : env13359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13358_13359 : H12AffineEnvironment.transform 6 89 env13358 = env13359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env13358 == env13359) = true)

theorem identity13359 : scanCanonicalize (H12AffineFastState.compose env13359 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13359 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env13360 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,342,13340,10280,1024,8541,4160,33,65,83,8273,65,10588,13388,4096,10360,9224,8493,256,8573,13324,592]

theorem envBound13360 : H12AffineFastState.Bounded env13360 := by
  intro p hp
  have h : env13360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13359_13360 : H12AffineEnvironment.transform 15 342 env13359 = env13360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13359 == env13360) = true)

theorem identity13360 : scanCanonicalize (H12AffineFastState.compose env13360 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13360 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13361 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,0,342,5440,2420,1024,1,4160,33,65,83,269,65,2048,5392,4096,2340,1364,113,256,33,5456,592]

theorem envBound13361 : H12AffineFastState.Bounded env13361 := by
  intro p hp
  have h : env13361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13360_13361 : H12AffineEnvironment.transform 12 348 env13360 = env13361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13360 == env13361) = true)

theorem identity13361 : scanCanonicalize (H12AffineFastState.compose env13361 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound13361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13362 : List Nat := [2,4,8,16,32,64,89,256,512,4,2048,4096,348,4436,0,342,4420,2420,4,1,4160,33,65,83,269,65,2048,4372,4096,2340,336,113,256,33,4436,592]

theorem envBound13362 : H12AffineFastState.Bounded env13362 := by
  intro p hp
  have h : env13362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13361_13362 : H12AffineEnvironment.transform 9 4 env13361 = env13362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env13361 == env13362) = true)

theorem identity13362 : scanCanonicalize (H12AffineFastState.compose env13362 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound13362 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env13363 : List Nat := [2,4,8,16,32,64,89,256,512,4,325,4096,348,4436,0,342,4420,49,4,1,4160,33,65,83,269,65,325,4372,4096,97,336,113,256,33,4436,592]

theorem envBound13363 : H12AffineFastState.Bounded env13363 := by
  intro p hp
  have h : env13363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13362_13363 : H12AffineEnvironment.transform 10 325 env13362 = env13363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env13362 == env13363) = true)

theorem identity13363 : scanCanonicalize (H12AffineFastState.compose env13363 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound13363 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13364 : List Nat := [2,4,8,16,32,64,89,256,512,4,325,373,348,33,0,342,49,49,4,1,309,33,65,83,269,65,325,97,373,97,336,113,256,33,33,592]

theorem envBound13364 : H12AffineFastState.Bounded env13364 := by
  intro p hp
  have h : env13364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13363_13364 : H12AffineEnvironment.transform 11 373 env13363 = env13364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env13363 == env13364) = true)

theorem identity13364 : scanCanonicalize (H12AffineFastState.compose env13364 (packedSelected [6,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13364 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env13365 : List Nat := [2,4,8,16,0,64,89,256,512,4,325,341,348,1,0,342,17,17,4,1,277,1,65,83,269,65,325,65,341,65,336,81,256,1,1,592]

theorem envBound13365 : H12AffineFastState.Bounded env13365 := by
  intro p hp
  have h : env13365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13364_13365 : H12AffineEnvironment.transform 4 0 env13364 = env13365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13364 == env13365) = true)

theorem identity13365 : scanCanonicalize (H12AffineFastState.compose env13365 (packedSelected [1,8,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13365 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13366 : List Nat := [2,4,8,16,0,16,9,256,512,4,277,261,268,1,0,262,17,17,4,1,277,1,17,3,269,17,277,17,261,17,256,1,256,1,1,512]

theorem envBound13366 : H12AffineFastState.Bounded env13366 := by
  intro p hp
  have h : env13366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13365_13366 : H12AffineEnvironment.transform 5 16 env13365 = env13366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13365 == env13366) = true)

theorem identity13366 : scanCanonicalize (H12AffineFastState.compose env13366 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13366 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13367 : List Nat := [2,4,8,16,0,16,9,256,261,4,277,261,268,1,0,262,17,17,4,1,277,1,17,3,269,17,277,17,261,17,256,1,256,1,1,261]

theorem envBound13367 : H12AffineFastState.Bounded env13367 := by
  intro p hp
  have h : env13367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13366_13367 : H12AffineEnvironment.transform 8 261 env13366 = env13367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13366 == env13367) = true)

theorem identity13367 : scanCanonicalize (H12AffineFastState.compose env13367 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound13367 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13368 : List Nat := [2,4,8,16,0,16,9,20,17,4,1,17,24,1,0,18,17,17,4,1,1,1,17,3,25,17,1,17,17,17,20,1,20,1,1,17]

theorem envBound13368 : H12AffineFastState.Bounded env13368 := by
  intro p hp
  have h : env13368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13367_13368 : H12AffineEnvironment.transform 7 20 env13367 = env13368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env13367 == env13368) = true)

theorem identity13368 : scanCanonicalize (H12AffineFastState.compose env13368 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound13368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13369 : List Nat := [2,4,7,16,0,16,6,20,17,4,1,17,23,1,0,18,17,17,4,1,1,1,17,3,22,17,1,17,17,17,20,1,20,1,1,17]

theorem envBound13369 : H12AffineFastState.Bounded env13369 := by
  intro p hp
  have h : env13369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13368_13369 : H12AffineEnvironment.transform 2 7 env13368 = env13369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env13368 == env13369) = true)

theorem identity13369 : scanCanonicalize (H12AffineFastState.compose env13369 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13369 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13370 : List Nat := [2,4,7,0,0,0,6,4,1,4,1,1,7,1,0,2,1,1,4,1,1,1,1,3,6,1,1,1,1,1,4,1,4,1,1,1]

theorem envBound13370 : H12AffineFastState.Bounded env13370 := by
  intro p hp
  have h : env13370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13369_13370 : H12AffineEnvironment.transform 3 0 env13369 = env13370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13369 == env13370) = true)

def env13371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21929,152,21763,8328,65,100695,115151,17801,35325,119179,95530,256,98679,90323,63068]

theorem envBound13371 : H12AffineFastState.Bounded env13371 := by
  intro p hp
  have h : env13371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13355_13371 : H12AffineEnvironment.transform 16 49169 env13355 = env13371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env13355 == env13371) = true)

theorem identity13371 : scanCanonicalize (H12AffineFastState.compose env13371 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13371 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35189,1024,32769,4160,169,152,3,8328,65,100695,103631,4233,35325,99467,73770,256,98679,79315,41820]

theorem envBound13372 : H12AffineFastState.Bounded env13372 := by
  intro p hp
  have h : env13372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13371_13372 : H12AffineEnvironment.transform 13 5376 env13371 = env13372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13371 == env13372) = true)

theorem identity13372 : scanCanonicalize (H12AffineFastState.compose env13372 (packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13372 : packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env13373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33110,38161,35189,1024,32769,4160,169,152,3,8328,65,2049,5529,4233,35325,1501,41340,256,33,46213,41820]

theorem envBound13373 : H12AffineFastState.Bounded env13373 := by
  intro p hp
  have h : env13373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13372_13373 : H12AffineEnvironment.transform 15 33110 env13372 = env13373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13372 == env13373) = true)

def env13374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169401,153,21763,8328,65,215366,115151,17800,35324,119178,243002,256,98678,90322,63069]

theorem envBound13374 : H12AffineFastState.Bounded env13374 := by
  intro p hp
  have h : env13374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13354_13374 : H12AffineEnvironment.transform 21 169401 env13354 = env13374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env13354 == env13374) = true)

def env13375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21929,153,21763,8328,65,100694,115151,17800,35324,119178,95530,256,98678,90322,63069]

theorem envBound13375 : H12AffineFastState.Bounded env13375 := by
  intro p hp
  have h : env13375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13374_13375 : H12AffineEnvironment.transform 16 49168 env13374 = env13375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13374 == env13375) = true)

theorem identity13375 : scanCanonicalize (H12AffineFastState.compose env13375 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound13375 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,13388,32040,1024,29789,4160,21929,153,21763,8328,65,97546,79251,17800,32160,75222,95530,256,95530,90322,513]

theorem envBound13376 : H12AffineFastState.Bounded env13376 := by
  intro p hp
  have h : env13376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13375_13376 : H12AffineEnvironment.transform 14 29788 env13375 = env13376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env13375 == env13376) = true)

theorem identity13376 : scanCanonicalize (H12AffineFastState.compose env13376 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound13376 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env13377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,21591,13388,32040,1024,29789,4160,21929,153,21763,8328,65,10589,25028,17800,32160,29057,8573,256,8573,13445,513]

theorem envBound13377 : H12AffineFastState.Bounded env13377 := by
  intro p hp
  have h : env13377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13376_13377 : H12AffineEnvironment.transform 15 21591 env13376 = env13377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env13376 == env13377) = true)

theorem identity13377 : scanCanonicalize (H12AffineFastState.compose env13377 (packedSelected [1,5,7,8,14,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound13377 : packedSelected [1,5,7,8,14,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env13378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21897,21591,5529,23805,1024,21896,4160,21929,153,21763,349,65,2184,16401,17800,23669,20564,168,256,168,5456,513]

theorem envBound13378 : H12AffineFastState.Bounded env13378 := by
  intro p hp
  have h : env13378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13377_13378 : H12AffineEnvironment.transform 12 469 env13377 = env13378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env13377 == env13378) = true)

theorem identity13378 : scanCanonicalize (H12AffineFastState.compose env13378 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13378 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env13379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5392,23668,1024,21761,4160,21792,16,21763,349,65,2049,16401,17665,23669,20564,33,256,33,5456,513]

theorem envBound13379 : H12AffineFastState.Bounded env13379 := by
  intro p hp
  have h : env13379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13378_13379 : H12AffineEnvironment.transform 6 9 env13378 = env13379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13378 == env13379) = true)

theorem identity13379 : scanCanonicalize (H12AffineFastState.compose env13379 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound13379 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1296,1095,5392,3172,1024,1297,4160,1328,16,1299,349,65,2049,4097,5393,3173,68,33,256,33,5456,513]

theorem envBound13380 : H12AffineFastState.Bounded env13380 := by
  intro p hp
  have h : env13380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13379_13380 : H12AffineEnvironment.transform 13 4112 env13379 = env13380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env13379 == env13380) = true)

theorem identity13380 : scanCanonicalize (H12AffineFastState.compose env13380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13381 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,0,343,4096,2420,272,1,4160,32,16,3,349,65,2049,4097,4097,2421,68,33,256,33,4160,513]

theorem envBound13381 : H12AffineFastState.Bounded env13381 := by
  intro p hp
  have h : env13381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13380_13381 : H12AffineEnvironment.transform 9 272 env13380 = env13381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13380 == env13381) = true)

theorem identity13381 : scanCanonicalize (H12AffineFastState.compose env13381 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound13381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13382 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,81,348,65,0,343,81,2420,272,1,17,32,16,3,349,65,2049,80,80,2421,68,33,256,33,17,513]

theorem envBound13382 : H12AffineFastState.Bounded env13382 := by
  intro p hp
  have h : env13382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13381_13382 : H12AffineEnvironment.transform 11 81 env13381 = env13382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env13381 == env13382) = true)

theorem identity13382 : scanCanonicalize (H12AffineFastState.compose env13382 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound13382 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13383 : List Nat := [2,4,8,16,32,64,9,256,81,272,2048,81,348,65,0,343,81,2420,272,1,17,32,16,3,349,65,2049,80,80,2421,68,33,256,33,17,80]

theorem envBound13383 : H12AffineFastState.Bounded env13383 := by
  intro p hp
  have h : env13383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13382_13383 : H12AffineEnvironment.transform 8 81 env13382 = env13383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env13382 == env13383) = true)

theorem identity13383 : scanCanonicalize (H12AffineFastState.compose env13383 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13383 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13384 : List Nat := [2,4,8,16,32,16,9,256,1,272,2048,1,268,17,0,263,1,2340,272,1,17,32,16,3,269,17,2049,0,0,2341,20,33,256,33,17,0]

theorem envBound13384 : H12AffineFastState.Bounded env13384 := by
  intro p hp
  have h : env13384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13383_13384 : H12AffineEnvironment.transform 5 16 env13383 = env13384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13383 == env13384) = true)

theorem identity13384 : scanCanonicalize (H12AffineFastState.compose env13384 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound13384 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13385 : List Nat := [2,4,8,16,32,16,9,256,1,272,293,1,268,17,0,263,1,1,272,1,17,32,16,3,269,17,292,0,0,0,20,33,256,33,17,0]

theorem envBound13385 : H12AffineFastState.Bounded env13385 := by
  intro p hp
  have h : env13385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13384_13385 : H12AffineEnvironment.transform 10 293 env13384 = env13385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env13384 == env13385) = true)

theorem identity13385 : scanCanonicalize (H12AffineFastState.compose env13385 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13385 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13386 : List Nat := [2,4,8,16,0,16,9,256,1,272,261,1,268,17,0,263,1,1,272,1,17,0,16,3,269,17,260,0,0,0,20,1,256,1,17,0]

theorem envBound13386 : H12AffineFastState.Bounded env13386 := by
  intro p hp
  have h : env13386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13385_13386 : H12AffineEnvironment.transform 4 0 env13385 = env13386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13385 == env13386) = true)

theorem identity13386 : scanCanonicalize (H12AffineFastState.compose env13386 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound13386 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13387 : List Nat := [2,4,8,16,0,16,9,20,1,4,17,1,24,17,0,19,1,1,4,1,17,0,16,3,25,17,16,0,0,0,20,1,20,1,17,0]

theorem envBound13387 : H12AffineFastState.Bounded env13387 := by
  intro p hp
  have h : env13387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13386_13387 : H12AffineEnvironment.transform 7 20 env13386 = env13387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env13386 == env13387) = true)

theorem identity13387 : scanCanonicalize (H12AffineFastState.compose env13387 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13388 : List Nat := [2,4,8,0,0,0,9,4,1,4,1,1,8,1,0,3,1,1,4,1,1,0,0,3,9,1,0,0,0,0,4,1,4,1,1,0]

theorem envBound13388 : H12AffineFastState.Bounded env13388 := by
  intro p hp
  have h : env13388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13387_13388 : H12AffineEnvironment.transform 3 0 env13387 = env13388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13387 == env13388) = true)

def env13389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21928,153,21763,8328,65,100695,115151,17800,35324,119178,95531,256,98678,90322,63069]

theorem envBound13389 : H12AffineFastState.Bounded env13389 := by
  intro p hp
  have h : env13389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13374_13389 : H12AffineEnvironment.transform 16 49169 env13374 = env13389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env13374 == env13389) = true)

theorem identity13389 : scanCanonicalize (H12AffineFastState.compose env13389 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13389 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,32161,1024,29909,4160,21928,153,21763,8328,65,97667,79131,17800,32040,75102,95531,256,95650,90322,649]

theorem envBound13390 : H12AffineFastState.Bounded env13390 := by
  intro p hp
  have h : env13390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13389_13390 : H12AffineEnvironment.transform 14 29908 env13389 = env13390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13389 == env13390) = true)

theorem identity13390 : scanCanonicalize (H12AffineFastState.compose env13390 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13390 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32041,1024,29789,4160,21792,17,21763,8192,65,97547,79131,17664,32040,75102,95531,256,95530,90202,513]

theorem envBound13391 : H12AffineFastState.Bounded env13391 := by
  intro p hp
  have h : env13391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13390_13391 : H12AffineEnvironment.transform 6 8 env13390 = env13391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13390 == env13391) = true)

theorem identity13391 : scanCanonicalize (H12AffineFastState.compose env13391 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound13391 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,13389,32041,1024,29789,4160,21792,17,21763,8192,65,10589,24909,17664,32040,28936,8573,256,8572,13324,513]

theorem envBound13392 : H12AffineFastState.Bounded env13392 := by
  intro p hp
  have h : env13392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13391_13392 : H12AffineEnvironment.transform 15 21590 env13391 = env13392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env13391 == env13392) = true)

theorem identity13392 : scanCanonicalize (H12AffineFastState.compose env13392 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound13392 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,13389,2421,1024,1,4160,8572,17,8543,8192,65,10589,5393,12636,2420,1364,8573,256,8572,13324,513]

theorem envBound13393 : H12AffineFastState.Bounded env13393 := by
  intro p hp
  have h : env13393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13392_13393 : H12AffineEnvironment.transform 13 13404 env13392 = env13393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env13392 == env13393) = true)

theorem identity13393 : scanCanonicalize (H12AffineFastState.compose env13393 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13393 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13394 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,8202,13341,2341,1024,1,4112,8492,17,8463,8192,17,10509,5393,12556,2340,1284,8493,256,8492,13324,513]

theorem envBound13394 : H12AffineFastState.Bounded env13394 := by
  intro p hp
  have h : env13394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13393_13394 : H12AffineEnvironment.transform 5 16 env13393 = env13394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13393 == env13394) = true)

theorem identity13394 : scanCanonicalize (H12AffineFastState.compose env13394 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound13394 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13395 : List Nat := [2,4,8,16,32,16,8,256,512,1024,820,4096,8192,13324,0,8202,13341,529,1024,1,4112,8492,17,8463,8192,17,8761,5393,12556,528,1284,8493,256,8492,13324,513]

theorem envBound13395 : H12AffineFastState.Bounded env13395 := by
  intro p hp
  have h : env13395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13394_13395 : H12AffineEnvironment.transform 10 820 env13394 = env13395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env13394 == env13395) = true)

theorem identity13395 : scanCanonicalize (H12AffineFastState.compose env13395 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound13395 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env13396 : List Nat := [2,4,8,16,32,16,8,256,512,1024,820,4096,1305,4373,0,1299,4356,529,1024,1,4112,1077,17,1046,1305,17,1824,5393,5141,528,1284,1076,256,1077,4373,513]

theorem envBound13396 : H12AffineFastState.Bounded env13396 := by
  intro p hp
  have h : env13396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13395_13396 : H12AffineEnvironment.transform 12 1305 env13395 = env13396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env13395 == env13396) = true)

theorem identity13396 : scanCanonicalize (H12AffineFastState.compose env13396 (packedSelected [7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13396 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env13397 : List Nat := [2,4,8,16,32,16,8,256,512,21,820,4096,268,4373,0,262,4356,529,21,1,4112,32,17,3,268,17,821,4356,4096,528,273,33,256,32,4373,513]

theorem envBound13397 : H12AffineFastState.Bounded env13397 := by
  intro p hp
  have h : env13397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13396_13397 : H12AffineEnvironment.transform 9 21 env13396 = env13397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13396 == env13397) = true)

theorem identity13397 : scanCanonicalize (H12AffineFastState.compose env13397 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound13397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13398 : List Nat := [2,4,8,16,32,16,8,53,512,21,513,4096,57,4128,0,51,4145,529,21,1,4112,32,17,3,57,17,512,4145,4096,528,36,33,53,32,4128,513]

theorem envBound13398 : H12AffineFastState.Bounded env13398 := by
  intro p hp
  have h : env13398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13397_13398 : H12AffineEnvironment.transform 7 53 env13397 = env13398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env13397 == env13398) = true)

theorem identity13398 : scanCanonicalize (H12AffineFastState.compose env13398 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13398 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13399 : List Nat := [2,4,8,16,32,16,8,53,0,21,1,4096,57,4128,0,51,4145,17,21,1,4112,32,17,3,57,17,0,4145,4096,16,36,33,53,32,4128,1]

theorem envBound13399 : H12AffineFastState.Bounded env13399 := by
  intro p hp
  have h : env13399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13398_13399 : H12AffineEnvironment.transform 8 0 env13398 = env13399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13398 == env13399) = true)

theorem identity13399 : scanCanonicalize (H12AffineFastState.compose env13399 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13399 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13400 : List Nat := [2,4,8,16,17,16,8,4,0,21,1,4096,8,4113,0,2,4096,17,21,1,4112,17,17,3,8,17,0,4096,4096,16,21,16,4,17,4113,1]

theorem envBound13400 : H12AffineFastState.Bounded env13400 := by
  intro p hp
  have h : env13400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13399_13400 : H12AffineEnvironment.transform 4 17 env13399 = env13400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13399 == env13400) = true)

theorem identity13400 : scanCanonicalize (H12AffineFastState.compose env13400 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound13400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13401 : List Nat := [2,4,8,16,17,16,8,4,0,21,1,1,8,16,0,2,1,17,21,1,17,17,17,3,8,17,0,1,1,16,21,16,4,17,16,1]

theorem envBound13401 : H12AffineFastState.Bounded env13401 := by
  intro p hp
  have h : env13401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13400_13401 : H12AffineEnvironment.transform 11 1 env13400 = env13401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env13400 == env13401) = true)

theorem identity13401 : scanCanonicalize (H12AffineFastState.compose env13401 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13401 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13402 : List Nat := [2,4,2,16,17,16,2,4,0,21,1,1,2,16,0,2,1,17,21,1,17,17,17,3,2,17,0,1,1,16,21,16,4,17,16,1]

theorem envBound13402 : H12AffineFastState.Bounded env13402 := by
  intro p hp
  have h : env13402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13401_13402 : H12AffineEnvironment.transform 2 2 env13401 = env13402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13401 == env13402) = true)

def env13403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363553,21763,8328,65,215367,115151,4378672,4332612,4408370,4268163,256,4396238,4453738,4350949]

theorem envBound13403 : H12AffineFastState.Bounded env13403 := by
  intro p hp
  have h : env13403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13353_13403 : H12AffineEnvironment.transform 22 4363553 env13353 = env13403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env13353 == env13403) = true)

theorem identity13403 : scanCanonicalize (H12AffineFastState.compose env13403 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound13403 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,16,21763,8328,65,215367,115151,17665,35189,119043,243122,256,98815,90203,63188]

theorem envBound13404 : H12AffineFastState.Bounded env13404 := by
  intro p hp
  have h : env13404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13403_13404 : H12AffineEnvironment.transform 21 169265 env13403 = env13404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env13403 == env13404) = true)

def env13405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,16,21763,8192,65,215367,115015,17665,35189,119043,243002,256,98679,90203,63068]

theorem envBound13405 : H12AffineFastState.Bounded env13405 := by
  intro p hp
  have h : env13405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13404_13405 : H12AffineEnvironment.transform 6 8 env13404 = env13405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13404 == env13405) = true)

theorem identity13405 : scanCanonicalize (H12AffineFastState.compose env13405 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound13405 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56437,1024,32769,4160,32,16,21763,8192,65,121942,115015,17665,35189,119043,73771,256,98679,90203,63068]

theorem envBound13406 : H12AffineFastState.Bounded env13406 := by
  intro p hp
  have h : env13406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13405_13406 : H12AffineEnvironment.transform 16 38161 env13405 = env13406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13405 == env13406) = true)

theorem identity13406 : scanCanonicalize (H12AffineFastState.compose env13406 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13406 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env13407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,65536,38161,35108,1024,32769,4160,32,16,82,8192,65,100615,103446,4176,35189,99410,73771,256,98679,79114,41741]

theorem envBound13407 : H12AffineFastState.Bounded env13407 := by
  intro p hp
  have h : env13407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13406_13407 : H12AffineEnvironment.transform 13 5457 env13406 = env13407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13406 == env13407) = true)

theorem identity13407 : scanCanonicalize (H12AffineFastState.compose env13407 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound13407 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env13408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,40971,38161,35108,1024,32769,4160,32,16,82,8192,65,10508,13341,4176,35189,9305,32800,256,8572,38145,41741]

theorem envBound13408 : H12AffineFastState.Bounded env13408 := by
  intro p hp
  have h : env13408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13407_13408 : H12AffineEnvironment.transform 15 40971 env13407 = env13408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env13407 == env13408) = true)

theorem identity13408 : scanCanonicalize (H12AffineFastState.compose env13408 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13408 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env13409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,343,13389,10360,1024,8541,4160,32,16,82,8192,65,10508,13341,4176,10281,9305,8572,256,8572,13405,593]

theorem envBound13409 : H12AffineFastState.Bounded env13409 := by
  intro p hp
  have h : env13409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13408_13409 : H12AffineEnvironment.transform 14 8540 env13408 = env13409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13408 == env13409) = true)

theorem identity13409 : scanCanonicalize (H12AffineFastState.compose env13409 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6477) := by decide +kernel

theorem selectedBound13409 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6477,5457,6161,343,3328,4405,1024,6160,4160,32,16,82,6477,65,4161,3408,4176,4452,7444,6193,256,6193,3344,593]

theorem envBound13410 : H12AffineFastState.Bounded env13410 := by
  intro p hp
  have h : env13410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13409_13410 : H12AffineEnvironment.transform 12 6477 env13409 = env13410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6477 env13409 == env13410) = true)

theorem identity13410 : scanCanonicalize (H12AffineFastState.compose env13410 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound13410 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,269,3345,81,343,3328,2421,1024,80,2048,32,16,82,269,65,2049,3408,2064,2340,1364,113,256,113,3344,593]

theorem envBound13411 : H12AffineFastState.Bounded env13411 := by
  intro p hp
  have h : env13411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13410_13411 : H12AffineEnvironment.transform 11 2112 env13410 = env13411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env13410 == env13411) = true)

theorem identity13411 : scanCanonicalize (H12AffineFastState.compose env13411 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13411 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env13412 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2112,269,2420,81,343,2405,2421,101,80,2048,32,16,82,269,65,2049,2357,2064,2340,305,113,256,113,2421,593]

theorem envBound13412 : H12AffineFastState.Bounded env13412 := by
  intro p hp
  have h : env13412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13411_13412 : H12AffineEnvironment.transform 9 101 env13411 = env13412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13411 == env13412) = true)

theorem identity13412 : scanCanonicalize (H12AffineFastState.compose env13412 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13412 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13413 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,2112,41,2128,81,115,2113,2129,101,80,2048,32,16,82,41,65,2049,2065,2064,2048,21,113,36,113,2129,593]

theorem envBound13413 : H12AffineFastState.Bounded env13413 := by
  intro p hp
  have h : env13413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13412_13413 : H12AffineEnvironment.transform 7 36 env13412 = env13413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13412 == env13413) = true)

theorem identity13413 : scanCanonicalize (H12AffineFastState.compose env13413 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound13413 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13414 : List Nat := [2,4,8,16,32,64,8,36,512,101,81,17,41,1,81,115,16,0,101,80,81,32,16,82,41,65,80,64,65,81,21,113,36,113,0,593]

theorem envBound13414 : H12AffineFastState.Bounded env13414 := by
  intro p hp
  have h : env13414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13413_13414 : H12AffineEnvironment.transform 10 81 env13413 = env13414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env13413 == env13414) = true)

theorem identity13414 : scanCanonicalize (H12AffineFastState.compose env13414 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13414 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env13415 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,17,41,1,0,34,16,0,52,1,0,32,16,3,41,16,1,17,16,0,21,32,36,32,0,512]

theorem envBound13415 : H12AffineFastState.Bounded env13415 := by
  intro p hp
  have h : env13415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13414_13415 : H12AffineEnvironment.transform 5 17 env13414 = env13415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13414 == env13415) = true)

theorem identity13415 : scanCanonicalize (H12AffineFastState.compose env13415 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound13415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13416 : List Nat := [2,4,8,16,32,17,8,36,16,52,0,17,41,1,0,34,16,0,52,1,0,32,16,3,41,16,1,17,16,0,21,32,36,32,0,16]

theorem envBound13416 : H12AffineFastState.Bounded env13416 := by
  intro p hp
  have h : env13416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13415_13416 : H12AffineEnvironment.transform 8 16 env13415 = env13416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env13415 == env13416) = true)

theorem identity13416 : scanCanonicalize (H12AffineFastState.compose env13416 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound13416 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13417 : List Nat := [2,4,7,16,32,17,7,36,16,52,0,17,38,1,0,34,16,0,52,1,0,32,16,3,38,16,1,17,16,0,21,32,36,32,0,16]

theorem envBound13417 : H12AffineFastState.Bounded env13417 := by
  intro p hp
  have h : env13417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13416_13417 : H12AffineEnvironment.transform 2 7 env13416 = env13417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env13416 == env13417) = true)

theorem identity13417 : scanCanonicalize (H12AffineFastState.compose env13417 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13417 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13418 : List Nat := [2,4,7,16,16,17,7,20,16,4,0,17,22,1,0,18,16,0,4,1,0,16,16,3,22,16,1,17,16,0,21,16,20,16,0,16]

theorem envBound13418 : H12AffineFastState.Bounded env13418 := by
  intro p hp
  have h : env13418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13417_13418 : H12AffineEnvironment.transform 4 16 env13417 = env13418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13417 == env13418) = true)

theorem identity13418 : scanCanonicalize (H12AffineFastState.compose env13418 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13418 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13419 : List Nat := [2,4,7,0,0,1,7,4,0,4,0,1,6,1,0,2,0,0,4,1,0,0,0,3,6,0,1,1,0,0,5,0,4,0,0,0]

theorem envBound13419 : H12AffineFastState.Bounded env13419 := by
  intro p hp
  have h : env13419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13418_13419 : H12AffineEnvironment.transform 3 0 env13418 = env13419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13418 == env13419) = true)

def env13420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,16,21763,8193,65,215367,115014,17665,35189,119043,243003,256,98678,90203,63069]

theorem envBound13420 : H12AffineFastState.Bounded env13420 := by
  intro p hp
  have h : env13420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13404_13420 : H12AffineEnvironment.transform 6 9 env13404 = env13420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13404 == env13420) = true)

theorem identity13420 : scanCanonicalize (H12AffineFastState.compose env13420 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound13420 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,32040,1024,32769,4160,41341,16,21763,8193,65,97547,115014,17665,35189,119043,98679,256,98678,90203,63069]

theorem envBound13421 : H12AffineFastState.Bounded env13421 := by
  intro p hp
  have h : env13421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13420_13421 : H12AffineEnvironment.transform 16 13388 env13420 = env13421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env13420 == env13421) = true)

theorem identity13421 : scanCanonicalize (H12AffineFastState.compose env13421 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13421 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env13422 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,32768,65536,13388,31756,1024,32769,4160,41049,16,21543,8193,65,97327,114786,17445,34897,118823,98387,36,98386,90203,63069]

theorem envBound13422 : H12AffineFastState.Bounded env13422 := by
  intro p hp
  have h : env13422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13421_13422 : H12AffineEnvironment.transform 7 36 env13421 = env13422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13421 == env13422) = true)

theorem identity13422 : scanCanonicalize (H12AffineFastState.compose env13422 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound13422 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env13423 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,32768,41050,13388,31756,1024,32769,4160,41049,16,21543,8193,65,56437,24632,17445,34897,28797,8201,36,8200,49153,63069]

theorem envBound13423 : H12AffineFastState.Bounded env13423 := by
  intro p hp
  have h : env13423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13422_13423 : H12AffineEnvironment.transform 15 41050 env13422 = env13423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env13422 == env13423) = true)

theorem identity13423 : scanCanonicalize (H12AffineFastState.compose env13423 (packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound13423 : packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env13424 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8313,35,13388,31756,1024,8312,4160,32,16,21543,8193,65,31756,24632,17445,10280,28797,8201,36,8200,24696,22052]

theorem envBound13424 : H12AffineFastState.Bounded env13424 := by
  intro p hp
  have h : env13424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13423_13424 : H12AffineEnvironment.transform 14 8313 env13423 = env13424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env13423 == env13424) = true)

theorem identity13424 : scanCanonicalize (H12AffineFastState.compose env13424 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13424 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13425 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,16384,80,35,5221,23589,1024,81,4160,32,16,21543,40,65,23589,16401,17445,2049,20564,32,36,33,16465,22052]

theorem envBound13425 : H12AffineFastState.Bounded env13425 := by
  intro p hp
  have h : env13425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13424_13425 : H12AffineEnvironment.transform 12 41 env13424 = env13425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13424 == env13425) = true)

theorem identity13425 : scanCanonicalize (H12AffineFastState.compose env13425 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound13425 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13426 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,2049,80,35,5221,5156,1024,81,4160,32,16,7206,40,65,5156,2064,3108,2049,6229,32,36,33,2128,7717]

theorem envBound13426 : H12AffineFastState.Bounded env13426 := by
  intro p hp
  have h : env13426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13425_13426 : H12AffineEnvironment.transform 13 2049 env13425 = env13426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env13425 == env13426) = true)

theorem identity13426 : scanCanonicalize (H12AffineFastState.compose env13426 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13426 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env13427 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,2049,1,35,5172,5156,1024,0,4113,32,16,7206,40,16,5156,2064,3108,2049,6148,32,36,33,2049,7717]

theorem envBound13427 : H12AffineFastState.Bounded env13427 := by
  intro p hp
  have h : env13427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13426_13427 : H12AffineEnvironment.transform 5 17 env13426 = env13427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13426 == env13427) = true)

theorem identity13427 : scanCanonicalize (H12AffineFastState.compose env13427 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13427 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13428 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,16,41,2049,1,35,1060,1076,1024,0,1,32,16,3126,40,16,1076,2064,3108,2049,2068,32,36,33,2049,3637]

theorem envBound13428 : H12AffineFastState.Bounded env13428 := by
  intro p hp
  have h : env13428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13427_13428 : H12AffineEnvironment.transform 11 16 env13427 = env13428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13427 == env13428) = true)

theorem identity13428 : scanCanonicalize (H12AffineFastState.compose env13428 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13428 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13429 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,16,41,1,1,35,1060,1076,1024,0,1,32,16,1078,40,16,1076,16,1060,1,20,32,36,33,1,1589]

theorem envBound13429 : H12AffineFastState.Bounded env13429 := by
  intro p hp
  have h : env13429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13428_13429 : H12AffineEnvironment.transform 10 0 env13428 = env13429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13428 == env13429) = true)

theorem identity13429 : scanCanonicalize (H12AffineFastState.compose env13429 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound13429 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env13430 : List Nat := [2,4,8,16,32,17,9,36,512,532,0,16,41,1,1,35,560,544,532,0,1,32,16,546,40,16,544,16,560,1,20,32,36,33,1,33]

theorem envBound13430 : H12AffineFastState.Bounded env13430 := by
  intro p hp
  have h : env13430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13429_13430 : H12AffineEnvironment.transform 9 532 env13429 = env13430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env13429 == env13430) = true)

def env13431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,8388608,21762,8328,65,12704871,115151,8406288,8423781,8507666,4268163,256,8487407,8478795,8451781]

theorem envBound13431 : H12AffineFastState.Bounded env13431 := by
  intro p hp
  have h : env13431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13352_13431 : H12AffineEnvironment.transform 20 4161 env13352 = env13431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13352 == env13431) = true)

def env13432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363552,21762,8328,65,215367,115151,4378672,4332613,4408370,4268163,256,4396239,4453739,4350949]

theorem envBound13432 : H12AffineFastState.Bounded env13432 := by
  intro p hp
  have h : env13432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13431_13432 : H12AffineEnvironment.transform 22 4363552 env13431 = env13432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env13431 == env13432) = true)

theorem identity13432 : scanCanonicalize (H12AffineFastState.compose env13432 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13432 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1024,29909,4161,4194304,4350452,21762,8328,65,215367,79131,4334820,4332613,4408370,4268163,256,4396239,4391359,4350949]

theorem envBound13433 : H12AffineFastState.Bounded env13433 := by
  intro p hp
  have h : env13433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13432_13433 : H12AffineEnvironment.transform 14 29908 env13432 = env13433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13432 == env13433) = true)

def env13434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1024,29909,4161,32,156116,21762,8328,65,215367,79131,140484,138341,214034,73891,256,201967,197023,156613]

theorem envBound13434 : H12AffineFastState.Bounded env13434 := by
  intro p hp
  have h : env13434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13433_13434 : H12AffineEnvironment.transform 21 32 env13433 = env13434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13433 == env13434) = true)

def env13435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1024,29909,4161,33,156117,21762,8328,65,215367,79131,140485,138340,214035,73890,256,201966,197022,156612]

theorem envBound13435 : H12AffineFastState.Bounded env13435 := by
  intro p hp
  have h : env13435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13433_13435 : H12AffineEnvironment.transform 21 33 env13433 = env13435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13433 == env13435) = true)

theorem identity13435 : scanCanonicalize (H12AffineFastState.compose env13435 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound13435 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env13436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,131072,146744,1024,137,4161,33,136585,8542,8328,65,212251,79131,140485,138340,208975,73890,256,201966,197022,137112]

theorem envBound13436 : H12AffineFastState.Bounded env13436 := by
  intro p hp
  have h : env13436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13435_13436 : H12AffineEnvironment.transform 13 13404 env13435 = env13436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env13435 == env13436) = true)

theorem identity13436 : scanCanonicalize (H12AffineFastState.compose env13436 (packedSelected [2,3,4,6,9,11,15,17,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 2200) := by decide +kernel

theorem selectedBound13436 : packedSelected [2,3,4,6,9,11,15,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env13437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,2200,13728,1024,137,4161,33,7441,8542,8328,65,79235,79131,11357,5372,80087,73890,256,72822,67846,7936]

theorem envBound13437 : H12AffineFastState.Bounded env13437 := by
  intro p hp
  have h : env13437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13436_13437 : H12AffineEnvironment.transform 16 2200 env13436 = env13437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2200 env13436 == env13437) = true)

theorem identity13437 : scanCanonicalize (H12AffineFastState.compose env13437 (packedSelected [0,1,5,8,9,11,12,15,16,18,20,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound13437 : packedSelected [0,1,5,8,9,11,12,15,16,18,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env13438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4404,136,65536,2200,4296,1024,137,4161,33,7441,1078,1504,65,69867,69747,2357,5372,73151,67018,256,72822,67846,7936]

theorem envBound13438 : H12AffineFastState.Bounded env13438 := by
  intro p hp
  have h : env13438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13437_13438 : H12AffineEnvironment.transform 12 1384 env13437 = env13438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env13437 == env13438) = true)

theorem identity13438 : scanCanonicalize (H12AffineFastState.compose env13438 (packedSelected [0,1,2,3,5,6,7,8,9,10,11,12,15,17,18,19,22,23] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound13438 : packedSelected [0,1,2,3,5,6,7,8,9,10,11,12,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env13439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,152,1384,428,136,65536,2200,80,1024,137,217,33,3465,1078,1504,65,65651,65771,2357,1124,68903,67018,256,68846,67846,3992]

theorem envBound13439 : H12AffineFastState.Bounded env13439 := by
  intro p hp
  have h : env13439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13438_13439 : H12AffineEnvironment.transform 11 152 env13438 = env13439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env13438 == env13439) = true)

theorem identity13439 : scanCanonicalize (H12AffineFastState.compose env13439 (packedSelected [0,2,5,6,7,8,9,11,12,17,22,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound13439 : packedSelected [0,2,5,6,7,8,9,11,12,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env13440 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,152,41,428,136,65536,2200,80,321,137,217,33,2248,375,161,65,65651,65771,2357,293,67686,65675,256,68015,67846,2777]

theorem envBound13440 : H12AffineFastState.Bounded env13440 := by
  intro p hp
  have h : env13440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13439_13440 : H12AffineEnvironment.transform 9 321 env13439 = env13440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env13439 == env13440) = true)

theorem identity13440 : scanCanonicalize (H12AffineFastState.compose env13440 (packedSelected [1,3,5,8,10,14,15,16,19] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound13440 : packedSelected [1,3,5,8,10,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env13441 : List Nat := [2,4,8,16,32,64,128,256,512,321,508,152,41,428,136,65536,356,80,321,137,217,33,308,375,161,65,65651,65771,201,293,65946,65675,256,65619,65786,805]

theorem envBound13441 : H12AffineFastState.Bounded env13441 := by
  intro p hp
  have h : env13441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13440_13441 : H12AffineEnvironment.transform 10 508 env13440 = env13441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env13440 == env13441) = true)

def env13442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363553,21762,8328,65,215366,115151,4378673,4332612,4408371,4268163,256,4396238,4453738,4350948]

theorem envBound13442 : H12AffineFastState.Bounded env13442 := by
  intro p hp
  have h : env13442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13431_13442 : H12AffineEnvironment.transform 22 4363553 env13431 = env13442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env13431 == env13442) = true)

theorem identity13442 : scanCanonicalize (H12AffineFastState.compose env13442 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound13442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156133,62660,21762,8328,65,215366,115151,45524,32161,75222,213350,256,95531,103567,513]

theorem envBound13443 : H12AffineFastState.Bounded env13443 := by
  intro p hp
  have h : env13443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13442_13443 : H12AffineEnvironment.transform 21 156133 env13442 = env13443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env13442 == env13443) = true)

def env13444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156013,62540,21762,8192,65,215366,115015,45404,32041,75102,213350,256,95531,103431,513]

theorem envBound13444 : H12AffineFastState.Bounded env13444 := by
  intro p hp
  have h : env13444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13443_13444 : H12AffineEnvironment.transform 6 8 env13443 = env13444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13443 == env13444) = true)

theorem identity13444 : scanCanonicalize (H12AffineFastState.compose env13444 (packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound13444 : packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env13445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4161,41341,62540,21762,8192,65,100694,115015,45404,32041,75102,98678,256,95531,103431,513]

theorem envBound13445 : H12AffineFastState.Bounded env13445 := by
  intro p hp
  have h : env13445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13444_13445 : H12AffineEnvironment.transform 16 49168 env13444 = env13445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13444 == env13445) = true)

theorem identity13445 : scanCanonicalize (H12AffineFastState.compose env13445 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound13445 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env13446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62811,49168,35188,1024,32769,4161,41341,62540,21762,8192,65,31757,13340,45404,32041,53253,29741,256,32880,24924,513]

theorem envBound13446 : H12AffineFastState.Bounded env13446 := by
  intro p hp
  have h : env13446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13445_13446 : H12AffineEnvironment.transform 15 62811 env13445 = env13446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env13445 == env13446) = true)

theorem identity13446 : scanCanonicalize (H12AffineFastState.compose env13446 (packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13446 : packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env13447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,262,13389,32041,1024,29788,4161,21792,17,21762,8192,65,31757,13340,17665,32041,9304,29741,256,29741,24924,513]

theorem envBound13447 : H12AffineFastState.Bounded env13447 := by
  intro p hp
  have h : env13447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13446_13447 : H12AffineEnvironment.transform 14 29789 env13446 = env13447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13446 == env13447) = true)

theorem identity13447 : scanCanonicalize (H12AffineFastState.compose env13447 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound13447 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,262,13389,10361,1024,8460,4161,112,17,82,8192,65,10589,13340,4177,10361,9304,8573,256,8573,13324,513]

theorem envBound13448 : H12AffineFastState.Bounded env13448 := by
  intro p hp
  have h : env13448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13447_13448 : H12AffineEnvironment.transform 13 5456 env13447 = env13448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env13447 == env13448) = true)

theorem identity13448 : scanCanonicalize (H12AffineFastState.compose env13448 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound13448 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6476,5456,6209,262,3329,4405,1024,6208,4161,112,17,82,6476,65,4113,3408,4177,4405,7444,6193,256,6193,3392,513]

theorem envBound13449 : H12AffineFastState.Bounded env13449 := by
  intro p hp
  have h : env13449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13448_13449 : H12AffineEnvironment.transform 12 6476 env13448 = env13449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env13448 == env13449) = true)

theorem identity13449 : scanCanonicalize (H12AffineFastState.compose env13449 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13449 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13450 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,6476,4404,6209,262,2405,4405,100,6208,4161,112,17,82,6476,65,4113,2356,4177,4405,6512,6193,256,6193,2340,513]

theorem envBound13450 : H12AffineFastState.Bounded env13450 := by
  intro p hp
  have h : env13450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13449_13450 : H12AffineEnvironment.transform 9 100 env13449 = env13450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13449 == env13450) = true)

theorem identity13450 : scanCanonicalize (H12AffineFastState.compose env13450 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13450 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env13451 : List Nat := [2,4,8,16,32,64,8,256,512,100,1,4096,4429,4404,4160,262,356,4405,100,4161,4161,112,17,82,4429,65,4113,309,4177,4405,4465,4144,256,4144,293,513]

theorem envBound13451 : H12AffineFastState.Bounded env13451 := by
  intro p hp
  have h : env13451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13450_13451 : H12AffineEnvironment.transform 10 1 env13450 = env13451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13450 == env13451) = true)

theorem identity13451 : scanCanonicalize (H12AffineFastState.compose env13451 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13451 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env13452 : List Nat := [2,4,8,16,32,64,8,256,512,100,1,16,349,292,80,262,356,293,100,81,81,112,17,82,349,65,1,309,65,293,353,32,256,32,293,513]

theorem envBound13452 : H12AffineFastState.Bounded env13452 := by
  intro p hp
  have h : env13452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13451_13452 : H12AffineEnvironment.transform 11 16 env13451 = env13452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13451 == env13452) = true)

def env13453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156012,62541,21762,8193,65,215366,115014,45405,32040,75103,213350,256,95531,103430,513]

theorem envBound13453 : H12AffineFastState.Bounded env13453 := by
  intro p hp
  have h : env13453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13443_13453 : H12AffineEnvironment.transform 6 9 env13443 = env13453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13443 == env13453) = true)

theorem identity13453 : scanCanonicalize (H12AffineFastState.compose env13453 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound13453 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,76159,1024,32769,4161,65911,62541,21762,8193,65,10589,115014,45405,32040,75103,8573,256,95531,103430,513]

theorem envBound13454 : H12AffineFastState.Bounded env13454 := by
  intro p hp
  have h : env13454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13453_13454 : H12AffineEnvironment.transform 16 90139 env13453 = env13454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env13453 == env13454) = true)

theorem identity13454 : scanCanonicalize (H12AffineFastState.compose env13454 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound13454 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env13455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,76159,1024,29005,4161,65911,1281,21762,8193,65,10589,77834,16401,32040,75103,8573,256,95531,91466,513]

theorem envBound13455 : H12AffineFastState.Bounded env13455 := by
  intro p hp
  have h : env13455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13454_13455 : H12AffineEnvironment.transform 14 29004 env13454 = env13455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env13454 == env13455) = true)

theorem identity13455 : scanCanonicalize (H12AffineFastState.compose env13455 (packedSelected [1,4,5,8,9,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13455 : packedSelected [1,4,5,8,9,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env13456 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,28776,65536,90139,75867,1024,28777,4161,65619,1061,21542,8193,65,10361,77834,16401,31756,74875,8281,36,95247,91246,513]

theorem envBound13456 : H12AffineFastState.Bounded env13456 := by
  intro p hp
  have h : env13456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13455_13456 : H12AffineEnvironment.transform 7 36 env13455 = env13456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13455 == env13456) = true)

theorem identity13456 : scanCanonicalize (H12AffineFastState.compose env13456 (packedSelected [0,3,5,7,10,15,17,20,41] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound13456 : packedSelected [0,3,5,7,10,15,17,20,41] rootPS < 2^1333 := by decide +kernel

def env13457 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,28776,20530,12329,30825,1024,28777,4161,20577,1061,21542,8193,65,10361,24632,16401,31756,29769,8281,36,9277,13404,513]

theorem envBound13457 : H12AffineFastState.Bounded env13457 := by
  intro p hp
  have h : env13457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13456_13457 : H12AffineEnvironment.transform 15 20530 env13456 = env13457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env13456 == env13457) = true)

theorem identity13457 : scanCanonicalize (H12AffineFastState.compose env13457 (packedSelected [0,3,5,7,10,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13457 : packedSelected [0,3,5,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env13458 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,8192,16384,28776,20530,12329,30825,101,28777,4161,20577,64,20547,8193,65,10361,24632,16401,30825,28716,8281,36,8280,12345,513]

theorem envBound13458 : H12AffineFastState.Bounded env13458 := by
  intro p hp
  have h : env13458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13457_13458 : H12AffineEnvironment.transform 9 101 env13457 = env13458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13457 == env13458) = true)

theorem identity13458 : scanCanonicalize (H12AffineFastState.compose env13458 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13458 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13459 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,16384,28728,20530,12329,30777,53,28729,4113,20529,16,20499,8193,17,10281,24632,16401,30777,28716,8201,36,8200,12345,513]

theorem envBound13459 : H12AffineFastState.Bounded env13459 := by
  intro p hp
  have h : env13459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13458_13459 : H12AffineEnvironment.transform 5 16 env13458 = env13459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13458 == env13459) = true)

theorem identity13459 : scanCanonicalize (H12AffineFastState.compose env13459 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8760) := by decide +kernel

theorem selectedBound13459 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13460 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,8760,4608,12810,12329,6657,53,4609,4113,12809,16,12843,8193,17,10281,512,8745,6657,4628,8201,36,8200,12345,513]

theorem envBound13460 : H12AffineFastState.Bounded env13460 := by
  intro p hp
  have h : env13460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13459_13460 : H12AffineEnvironment.transform 13 8760 env13459 = env13460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8760 env13459 == env13460) = true)

theorem identity13460 : scanCanonicalize (H12AffineFastState.compose env13460 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 6712) := by decide +kernel

theorem selectedBound13460 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env13461 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,6712,6144,4608,2098,2577,6657,53,4609,4113,2097,16,2067,6713,17,4625,512,6161,6657,4628,6705,36,6704,2561,513]

theorem envBound13461 : H12AffineFastState.Bounded env13461 := by
  intro p hp
  have h : env13461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13460_13461 : H12AffineEnvironment.transform 12 6712 env13460 = env13461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6712 env13460 == env13461) = true)

theorem identity13461 : scanCanonicalize (H12AffineFastState.compose env13461 (packedSelected [0,4,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound13461 : packedSelected [0,4,5,8,12] rootPS < 2^1333 := by decide +kernel

def env13462 : List Nat := [2,4,8,16,32,16,9,36,512,53,17,4096,4649,4113,4608,35,512,4624,53,4609,4113,32,16,2,4648,17,4625,512,4096,4624,4628,4640,36,4641,528,513]

theorem envBound13462 : H12AffineFastState.Bounded env13462 := by
  intro p hp
  have h : env13462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13461_13462 : H12AffineEnvironment.transform 10 17 env13461 = env13462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13461 == env13462) = true)

theorem identity13462 : scanCanonicalize (H12AffineFastState.compose env13462 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13462 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env13463 : List Nat := [2,4,8,16,32,16,9,36,0,53,17,4096,4137,4113,4096,35,0,4112,53,4097,4113,32,16,2,4136,17,4113,0,4096,4112,4116,4128,36,4129,16,1]

theorem envBound13463 : H12AffineFastState.Bounded env13463 := by
  intro p hp
  have h : env13463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13462_13463 : H12AffineEnvironment.transform 8 0 env13462 = env13463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13462 == env13463) = true)

theorem identity13463 : scanCanonicalize (H12AffineFastState.compose env13463 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13463 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13464 : List Nat := [2,4,8,16,32,16,9,36,0,53,17,17,56,0,17,35,0,1,53,16,0,32,16,2,57,17,0,0,17,1,5,49,36,48,16,1]

theorem envBound13464 : H12AffineFastState.Bounded env13464 := by
  intro p hp
  have h : env13464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13463_13464 : H12AffineEnvironment.transform 11 17 env13463 = env13464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13463 == env13464) = true)

theorem identity13464 : scanCanonicalize (H12AffineFastState.compose env13464 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13464 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13465 : List Nat := [2,4,8,0,32,0,9,36,0,37,1,1,40,0,1,35,0,1,37,0,0,32,0,2,41,1,0,0,1,1,5,33,36,32,0,1]

theorem envBound13465 : H12AffineFastState.Bounded env13465 := by
  intro p hp
  have h : env13465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13464_13465 : H12AffineEnvironment.transform 3 0 env13464 = env13465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13464 == env13465) = true)

theorem identity13465 : scanCanonicalize (H12AffineFastState.compose env13465 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13466 : List Nat := [2,4,2,0,32,0,3,36,0,37,1,1,34,0,1,35,0,1,37,0,0,32,0,2,35,1,0,0,1,1,5,33,36,32,0,1]

theorem envBound13466 : H12AffineFastState.Bounded env13466 := by
  intro p hp
  have h : env13466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13465_13466 : H12AffineEnvironment.transform 2 2 env13465 = env13466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13465 == env13466) = true)

def env13467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797862,115150,10507601,8423780,10600786,4268162,256,8487406,8478794,10544773]

theorem envBound13467 : H12AffineFastState.Bounded env13467 := by
  intro p hp
  have h : env13467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13351_13467 : H12AffineEnvironment.transform 17 149861 env13351 = env13467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env13351 == env13467) = true)

def env13468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,8388608,21762,8328,65,12704870,115150,8406289,8423780,8507666,4268162,256,8487406,8478794,8451781]

theorem envBound13468 : H12AffineFastState.Bounded env13468 := by
  intro p hp
  have h : env13468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13467_13468 : H12AffineEnvironment.transform 20 4160 env13467 = env13468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13467 == env13468) = true)

def env13469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363552,21762,8328,65,215366,115150,4378673,4332612,4408370,4268162,256,4396238,4453738,4350949]

theorem envBound13469 : H12AffineFastState.Bounded env13469 := by
  intro p hp
  have h : env13469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13468_13469 : H12AffineEnvironment.transform 22 4363552 env13468 = env13469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env13468 == env13469) = true)

theorem identity13469 : scanCanonicalize (H12AffineFastState.compose env13469 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound13469 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149861,1024,32769,4160,4194304,4363552,21762,8328,65,171416,5392,4378673,4332612,4362476,4256860,256,4374544,4334004,4350949]

theorem envBound13470 : H12AffineFastState.Bounded env13470 := by
  intro p hp
  have h : env13470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13469_13470 : H12AffineEnvironment.transform 15 54494 env13469 = env13470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env13469 == env13470) = true)

def env13471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149861,1024,32769,4160,169400,152,21762,8328,65,171416,5392,17801,35324,1364,156132,256,21928,46092,63069]

theorem envBound13471 : H12AffineFastState.Bounded env13471 := by
  intro p hp
  have h : env13471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13470_13471 : H12AffineEnvironment.transform 21 169400 env13470 = env13471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env13470 == env13471) = true)

theorem identity13471 : scanCanonicalize (H12AffineFastState.compose env13471 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound13471 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env13472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16537,2556,1024,32769,4160,54561,152,21762,8328,65,56577,5392,17801,35324,1364,8573,256,21928,46092,63069]

theorem envBound13472 : H12AffineFastState.Bounded env13472 := by
  intro p hp
  have h : env13472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13471_13472 : H12AffineEnvironment.transform 16 16537 env13471 = env13472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env13471 == env13472) = true)

theorem identity13472 : scanCanonicalize (H12AffineFastState.compose env13472 (packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound13472 : packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8322,16537,2556,1024,29789,4160,8573,152,21762,8328,65,10589,5392,17801,32160,1364,8573,256,21928,16464,513]

theorem envBound13473 : H12AffineFastState.Bounded env13473 := by
  intro p hp
  have h : env13473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13472_13473 : H12AffineEnvironment.transform 14 29788 env13472 = env13473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env13472 == env13473) = true)

theorem identity13473 : scanCanonicalize (H12AffineFastState.compose env13473 (packedSelected [2,6,11,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13473 : packedSelected [2,6,11,32] rootPS < 2^1333 := by decide +kernel

def env13474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21761,479,16537,2556,1024,21760,4160,32,152,21762,469,65,2048,5392,17801,23805,1364,32,256,21928,16464,513]

theorem envBound13474 : H12AffineFastState.Bounded env13474 := by
  intro p hp
  have h : env13474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13473_13474 : H12AffineEnvironment.transform 12 349 env13473 = env13474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13473 == env13474) = true)

theorem identity13474 : scanCanonicalize (H12AffineFastState.compose env13474 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound13474 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,137,479,5393,2556,1024,136,4160,32,152,138,469,65,2048,5392,4097,2421,1364,32,256,32,5592,513]

theorem envBound13475 : H12AffineFastState.Bounded env13475 := by
  intro p hp
  have h : env13475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13474_13475 : H12AffineEnvironment.transform 13 5512 env13474 = env13475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env13474 == env13475) = true)

theorem identity13475 : scanCanonicalize (H12AffineFastState.compose env13475 (packedSelected [0,3,7,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound13475 : packedSelected [0,3,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,4096,349,5512,137,479,5393,1,1024,136,4160,32,152,138,469,65,509,5392,4097,136,1364,32,256,32,5592,513]

theorem envBound13476 : H12AffineFastState.Bounded env13476 := by
  intro p hp
  have h : env13476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13475_13476 : H12AffineEnvironment.transform 10 509 env13475 = env13476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env13475 == env13476) = true)

theorem identity13476 : scanCanonicalize (H12AffineFastState.compose env13476 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13476 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env13477 : List Nat := [2,4,8,16,32,64,128,256,512,272,509,4096,349,4248,137,479,4097,1,272,136,4160,32,152,138,469,65,509,4096,4097,136,68,32,256,32,4296,513]

theorem envBound13477 : H12AffineFastState.Bounded env13477 := by
  intro p hp
  have h : env13477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13476_13477 : H12AffineEnvironment.transform 9 272 env13476 = env13477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13476 == env13477) = true)

def env13478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149861,1024,32769,4160,169401,153,21762,8328,65,171416,5392,17800,35325,1365,156133,256,21929,46093,63068]

theorem envBound13478 : H12AffineFastState.Bounded env13478 := by
  intro p hp
  have h : env13478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13470_13478 : H12AffineEnvironment.transform 21 169401 env13470 = env13478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env13470 == env13478) = true)

theorem identity13478 : scanCanonicalize (H12AffineFastState.compose env13478 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13478 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env13479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,30163,131072,149861,1024,8460,4160,144564,153,21762,8328,65,146581,5392,17800,10480,1365,156133,256,21929,5376,22353]

theorem envBound13479 : H12AffineFastState.Bounded env13479 := by
  intro p hp
  have h : env13479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13478_13479 : H12AffineEnvironment.transform 14 8461 env13478 = env13479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13478 == env13479) = true)

theorem identity13479 : scanCanonicalize (H12AffineFastState.compose env13479 (packedSelected [0,1,9,10,11,15,16,18,19,20,22,23,27,28,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound13479 : packedSelected [0,1,9,10,11,15,16,18,19,20,22,23,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env13480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8461,8283,131072,138477,1024,8460,4160,144564,153,138,8328,65,146581,5392,4096,10480,1365,144493,256,33,5376,729]

theorem envBound13480 : H12AffineFastState.Bounded env13480 := by
  intro p hp
  have h : env13480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13479_13480 : H12AffineEnvironment.transform 13 5512 env13479 = env13480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env13479 == env13480) = true)

theorem identity13480 : scanCanonicalize (H12AffineFastState.compose env13480 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13480 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env13481 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,8203,131072,138429,1024,8460,4112,144564,153,138,8328,17,146581,5392,4096,10400,1285,144445,256,33,5376,649]

theorem envBound13481 : H12AffineFastState.Bounded env13481 := by
  intro p hp
  have h : env13481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13480_13481 : H12AffineEnvironment.transform 5 16 env13480 = env13481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13480 == env13481) = true)

theorem identity13481 : scanCanonicalize (H12AffineFastState.compose env13481 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound13481 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env13482 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,137,399,131072,138429,1024,136,4112,136496,153,138,268,17,138513,5392,4096,2340,1285,136633,256,33,5376,649]

theorem envBound13482 : H12AffineFastState.Bounded env13482 := by
  intro p hp
  have h : env13482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13481_13482 : H12AffineEnvironment.transform 12 388 env13481 = env13482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env13481 == env13482) = true)

def env13483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363553,21762,8328,65,215367,115150,4378672,4332613,4408371,4268162,256,4396239,4453739,4350948]

theorem envBound13483 : H12AffineFastState.Bounded env13483 := by
  intro p hp
  have h : env13483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13468_13483 : H12AffineEnvironment.transform 22 4363553 env13468 = env13483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env13468 == env13483) = true)

theorem identity13483 : scanCanonicalize (H12AffineFastState.compose env13483 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound13483 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,213487,120014,21762,8328,65,215367,115150,102879,89514,1500,156013,256,21792,46212,74251]

theorem envBound13484 : H12AffineFastState.Bounded env13484 := by
  intro p hp
  have h : env13484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13483_13484 : H12AffineEnvironment.transform 21 213487 env13483 = env13484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env13483 == env13484) = true)

def env13485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10401,1024,32769,4160,73771,120014,21762,8328,65,75907,115150,102879,89514,1500,169,256,21792,46212,74251]

theorem envBound13485 : H12AffineFastState.Bounded env13485 := by
  intro p hp
  have h : env13485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13484_13485 : H12AffineEnvironment.transform 16 25028 env13484 = env13485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env13484 == env13485) = true)

theorem identity13485 : scanCanonicalize (H12AffineFastState.compose env13485 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound13485 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env13486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,25028,10401,1024,30113,4160,73771,74094,21762,8328,65,75907,78958,91263,89514,1500,169,256,21792,16676,74251]

theorem envBound13486 : H12AffineFastState.Bounded env13486 := by
  intro p hp
  have h : env13486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13485_13486 : H12AffineEnvironment.transform 14 30112 env13485 = env13486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env13485 == env13486) = true)

theorem identity13486 : scanCanonicalize (H12AffineFastState.compose env13486 (packedSelected [0,1,6,10,11,19,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound13486 : packedSelected [0,1,6,10,11,19,27,28,32] rootPS < 2^1333 := by decide +kernel

def env13487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,428,65536,5576,10401,1024,429,4160,73771,74094,8462,8328,65,75907,78958,69747,76198,1500,169,256,8492,13608,74251]

theorem envBound13487 : H12AffineFastState.Bounded env13487 := by
  intro p hp
  have h : env13487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13486_13487 : H12AffineEnvironment.transform 13 13324 env13486 = env13487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env13486 == env13487) = true)

theorem identity13487 : scanCanonicalize (H12AffineFastState.compose env13487 (packedSelected [1,4,5,8,9,14,16,17,18,19,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound13487 : packedSelected [1,4,5,8,9,14,16,17,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5236,428,65536,5576,2265,1024,429,4160,65619,65814,374,240,65,67835,70678,69747,68062,1500,169,256,340,5456,66163]

theorem envBound13488 : H12AffineFastState.Bounded env13488 := by
  intro p hp
  have h : env13488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13487_13488 : H12AffineEnvironment.transform 12 120 env13487 = env13488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env13487 == env13488) = true)

theorem identity13488 : scanCanonicalize (H12AffineFastState.compose env13488 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13488 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13489 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,120,5236,217,65536,5309,2265,1024,216,4160,65619,65635,3,240,65,67835,70678,69747,67755,1193,169,117,33,5157,66163]

theorem envBound13489 : H12AffineFastState.Bounded env13489 := by
  intro p hp
  have h : env13489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13488_13489 : H12AffineEnvironment.transform 7 117 env13488 = env13489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13488 == env13489) = true)

theorem identity13489 : scanCanonicalize (H12AffineFastState.compose env13489 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound13489 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13490 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,120,5236,217,250,5309,2265,1024,216,4160,169,153,3,240,65,2049,5356,4233,2129,1193,169,117,33,5157,649]

theorem envBound13490 : H12AffineFastState.Bounded env13490 := by
  intro p hp
  have h : env13490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13489_13490 : H12AffineEnvironment.transform 15 250 env13489 = env13490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env13489 == env13490) = true)

theorem identity13490 : scanCanonicalize (H12AffineFastState.compose env13490 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13490 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env13491 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,80,115,5172,2128,1024,81,4160,32,16,3,121,65,2049,5221,4096,2129,1056,32,117,33,5157,512]

theorem envBound13491 : H12AffineFastState.Bounded env13491 := by
  intro p hp
  have h : env13491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13490_13491 : H12AffineEnvironment.transform 6 9 env13490 = env13491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13490 == env13491) = true)

theorem identity13491 : scanCanonicalize (H12AffineFastState.compose env13491 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound13491 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13492 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,9,5125,33,2,5172,2081,1024,32,4145,32,16,3,8,48,2049,5140,4096,2080,1056,32,4,33,5157,512]

theorem envBound13492 : H12AffineFastState.Bounded env13492 := by
  intro p hp
  have h : env13492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13491_13492 : H12AffineEnvironment.transform 5 49 env13491 = env13492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env13491 == env13492) = true)

theorem identity13492 : scanCanonicalize (H12AffineFastState.compose env13492 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13492 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13493 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,0,2,5141,2048,1024,1,4112,1,16,3,8,17,2049,5140,4096,2049,1025,1,4,0,5124,512]

theorem envBound13493 : H12AffineFastState.Bounded env13493 := by
  intro p hp
  have h : env13493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13492_13493 : H12AffineEnvironment.transform 4 1 env13492 = env13493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13492 == env13493) = true)

def env13494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10400,1024,32769,4160,73770,120014,21762,8328,65,75906,115150,102879,89514,1500,168,256,21792,46212,74251]

theorem envBound13494 : H12AffineFastState.Bounded env13494 := by
  intro p hp
  have h : env13494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13484_13494 : H12AffineEnvironment.transform 16 25029 env13484 = env13494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env13484 == env13494) = true)

theorem identity13494 : scanCanonicalize (H12AffineFastState.compose env13494 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13494 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env13495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,10400,1024,29909,4160,73770,73754,21762,8328,65,75906,79130,91403,89514,1500,168,256,21792,16464,74251]

theorem envBound13495 : H12AffineFastState.Bounded env13495 := by
  intro p hp
  have h : env13495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13494_13495 : H12AffineEnvironment.transform 14 29908 env13494 = env13495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13494 == env13495) = true)

theorem identity13495 : scanCanonicalize (H12AffineFastState.compose env13495 (packedSelected [0,1,2,5,6,10,11,12,14,15,16,20,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13495 : packedSelected [0,1,2,5,6,10,11,12,14,15,16,20,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env13496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25029,10400,1024,29909,4160,33,17,21762,8328,65,2185,5393,17664,32161,1500,168,256,21792,16464,512]

theorem envBound13496 : H12AffineFastState.Bounded env13496 := by
  intro p hp
  have h : env13496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13495_13496 : H12AffineEnvironment.transform 15 8203 env13495 = env13496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13495 == env13496) = true)

theorem identity13496 : scanCanonicalize (H12AffineFastState.compose env13496 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound13496 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2325,8192,16384,28097,8203,25029,10400,1024,28096,2389,33,17,19479,8328,65,2185,3076,17664,25780,1500,168,256,19509,16464,512]

theorem envBound13497 : H12AffineFastState.Bounded env13497 := by
  intro p hp
  have h : env13497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13496_13497 : H12AffineEnvironment.transform 11 2325 env13496 = env13497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env13496 == env13497) = true)

theorem identity13497 : scanCanonicalize (H12AffineFastState.compose env13497 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13497 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13498 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,8192,16384,27828,8203,24752,10400,1024,27829,2080,33,17,19479,8328,65,2185,3076,17525,25780,1193,168,117,19509,16464,512]

theorem envBound13498 : H12AffineFastState.Bounded env13498 := by
  intro p hp
  have h : env13498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13497_13498 : H12AffineEnvironment.transform 7 117 env13497 = env13498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13497 == env13498) = true)

theorem identity13498 : scanCanonicalize (H12AffineFastState.compose env13498 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 10401) := by decide +kernel

theorem selectedBound13498 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env13499 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,8192,10401,1045,8203,2065,10400,1024,1044,2080,33,17,9398,8328,65,2185,3076,11476,3093,1193,168,117,9364,10481,512]

theorem envBound13499 : H12AffineFastState.Bounded env13499 := by
  intro p hp
  have h : env13499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13498_13499 : H12AffineEnvironment.transform 13 10401 env13498 = env13499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10401 env13498 == env13499) = true)

theorem identity13499 : scanCanonicalize (H12AffineFastState.compose env13499 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound13499 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env13500 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,88,2297,1045,83,2065,2296,1024,1044,2080,33,17,1262,208,65,2185,3076,3212,3093,1193,168,117,1228,2217,512]

theorem envBound13500 : H12AffineFastState.Bounded env13500 := by
  intro p hp
  have h : env13500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13499_13500 : H12AffineEnvironment.transform 12 88 env13499 = env13500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env13499 == env13500) = true)

theorem identity13500 : scanCanonicalize (H12AffineFastState.compose env13500 (packedSelected [0,1,3,4,5,6,7,8,9,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound13500 : packedSelected [0,1,3,4,5,6,7,8,9,11,12,18] rootPS < 2^1333 := by decide +kernel

def env13501 : List Nat := [2,4,8,16,32,64,128,117,512,1024,113,17,88,136,1045,83,96,137,1024,1044,81,33,17,1262,208,65,248,1141,1277,1124,1193,168,117,1228,216,512]

theorem envBound13501 : H12AffineFastState.Bounded env13501 := by
  intro p hp
  have h : env13501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13500_13501 : H12AffineEnvironment.transform 10 113 env13500 = env13501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env13500 == env13501) = true)

theorem identity13501 : scanCanonicalize (H12AffineFastState.compose env13501 (packedSelected [1,2,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13501 : packedSelected [1,2,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env13502 : List Nat := [2,4,8,16,32,64,8,117,512,1024,113,17,88,0,1045,83,96,1,1024,1044,81,33,17,1126,88,65,112,1141,1141,1124,1057,32,117,1092,80,512]

theorem envBound13502 : H12AffineFastState.Bounded env13502 := by
  intro p hp
  have h : env13502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13501_13502 : H12AffineEnvironment.transform 6 8 env13501 = env13502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13501 == env13502) = true)

theorem identity13502 : scanCanonicalize (H12AffineFastState.compose env13502 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13502 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env13503 : List Nat := [2,4,8,16,32,64,8,117,512,101,113,17,88,0,112,83,96,1,101,113,81,33,17,3,88,65,112,16,16,1,68,32,117,33,80,512]

theorem envBound13503 : H12AffineFastState.Bounded env13503 := by
  intro p hp
  have h : env13503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13502_13503 : H12AffineEnvironment.transform 9 101 env13502 = env13503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13502 == env13503) = true)

theorem identity13503 : scanCanonicalize (H12AffineFastState.compose env13503 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13503 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13504 : List Nat := [2,4,8,16,32,17,8,36,512,52,32,17,9,0,33,2,49,1,52,32,0,33,17,3,9,16,33,16,16,1,21,32,36,33,1,512]

theorem envBound13504 : H12AffineFastState.Bounded env13504 := by
  intro p hp
  have h : env13504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13503_13504 : H12AffineEnvironment.transform 5 17 env13503 = env13504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13503 == env13504) = true)

theorem identity13504 : scanCanonicalize (H12AffineFastState.compose env13504 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13504 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env13505 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,0,1,2,17,1,20,0,0,1,17,3,9,16,1,16,16,1,21,0,4,1,1,512]

theorem envBound13505 : H12AffineFastState.Bounded env13505 := by
  intro p hp
  have h : env13505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13504_13505 : H12AffineEnvironment.transform 4 0 env13504 = env13505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13504 == env13505) = true)

theorem identity13505 : scanCanonicalize (H12AffineFastState.compose env13505 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound13505 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13506 : List Nat := [2,4,8,16,0,17,8,4,30,20,0,17,9,0,1,2,17,1,20,0,0,1,17,3,9,16,1,16,16,1,21,0,4,1,1,30]

theorem envBound13506 : H12AffineFastState.Bounded env13506 := by
  intro p hp
  have h : env13506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13505_13506 : H12AffineEnvironment.transform 8 30 env13505 = env13506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env13505 == env13506) = true)

def env13507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,8388608,21763,8328,65,12704871,115150,8406288,8423780,8507667,4268162,256,8487406,8478794,8451780]

theorem envBound13507 : H12AffineFastState.Bounded env13507 := by
  intro p hp
  have h : env13507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13467_13507 : H12AffineEnvironment.transform 20 4161 env13467 = env13507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13467 == env13507) = true)

def env13508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363552,21763,8328,65,215367,115150,4378672,4332612,4408371,4268162,256,4396238,4453738,4350948]

theorem envBound13508 : H12AffineFastState.Bounded env13508 := by
  intro p hp
  have h : env13508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13507_13508 : H12AffineEnvironment.transform 22 4363552 env13507 = env13508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env13507 == env13508) = true)

theorem identity13508 : scanCanonicalize (H12AffineFastState.compose env13508 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13508 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,4194304,4363552,21763,8328,65,158029,57796,4378672,4332612,4351033,4194440,256,4338884,4380000,4350948]

theorem envBound13509 : H12AffineFastState.Bounded env13509 := by
  intro p hp
  have h : env13509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13508_13509 : H12AffineEnvironment.transform 15 8202 env13508 = env13509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13508 == env13509) = true)

theorem identity13509 : scanCanonicalize (H12AffineFastState.compose env13509 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound13509 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,156133,62661,21763,8328,65,158029,57796,45525,32161,1500,156013,256,21793,46213,513]

theorem envBound13510 : H12AffineFastState.Bounded env13510 := by
  intro p hp
  have h : env13510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13509_13510 : H12AffineEnvironment.transform 21 156133 env13509 = env13510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env13509 == env13510) = true)

theorem identity13510 : scanCanonicalize (H12AffineFastState.compose env13510 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound13510 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env13511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,23804,1024,32769,4161,29820,62661,21763,8328,65,31956,57796,45525,32161,1500,29940,256,21793,46213,513]

theorem envBound13511 : H12AffineFastState.Bounded env13511 := by
  intro p hp
  have h : env13511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13510_13511 : H12AffineEnvironment.transform 16 5529 env13510 = env13511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env13510 == env13511) = true)

theorem identity13511 : scanCanonicalize (H12AffineFastState.compose env13511 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound13511 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env13512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8202,5529,23804,1024,137,4161,29820,29773,21763,8328,65,31956,24908,12637,32161,1500,29940,256,21793,13325,513]

theorem envBound13512 : H12AffineFastState.Bounded env13512 := by
  intro p hp
  have h : env13512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13511_13512 : H12AffineEnvironment.transform 14 136 env13511 = env13512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env13511 == env13512) = true)

theorem identity13512 : scanCanonicalize (H12AffineFastState.compose env13512 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound13512 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env13513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,136,8202,5529,2420,1024,137,4161,8692,8645,139,8328,65,10588,13508,12637,10281,1500,8572,256,169,13325,513]

theorem envBound13513 : H12AffineFastState.Bounded env13513 := by
  intro p hp
  have h : env13513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13512_13513 : H12AffineEnvironment.transform 13 5512 env13512 = env13513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env13512 == env13513) = true)

theorem identity13513 : scanCanonicalize (H12AffineFastState.compose env13513 (packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13513 : packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env13514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,8202,5393,2420,1024,1,4161,8572,8525,3,8192,65,10588,13388,12637,10281,1364,8572,256,33,13325,513]

theorem envBound13514 : H12AffineFastState.Bounded env13514 := by
  intro p hp
  have h : env13514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13513_13514 : H12AffineEnvironment.transform 6 8 env13513 = env13514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13513 == env13514) = true)

theorem identity13514 : scanCanonicalize (H12AffineFastState.compose env13514 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13514 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env13515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2420,1024,1,4161,33,16,3,349,65,2049,5393,4096,2420,1364,33,256,33,5456,513]

theorem envBound13515 : H12AffineFastState.Bounded env13515 := by
  intro p hp
  have h : env13515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13514_13515 : H12AffineEnvironment.transform 12 349 env13514 = env13515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13514 == env13515) = true)

theorem identity13515 : scanCanonicalize (H12AffineFastState.compose env13515 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound13515 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1060,349,292,0,343,309,2420,1024,1,1125,33,16,3,349,65,2049,309,1060,2420,1364,33,256,33,372,513]

theorem envBound13516 : H12AffineFastState.Bounded env13516 := by
  intro p hp
  have h : env13516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13515_13516 : H12AffineEnvironment.transform 11 1060 env13515 = env13516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env13515 == env13516) = true)

def env13517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363553,21763,8328,65,215366,115150,4378673,4332613,4408370,4268162,256,4396239,4453739,4350949]

theorem envBound13517 : H12AffineFastState.Bounded env13517 := by
  intro p hp
  have h : env13517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13507_13517 : H12AffineEnvironment.transform 22 4363553 env13507 = env13517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env13507 == env13517) = true)

theorem identity13517 : scanCanonicalize (H12AffineFastState.compose env13517 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound13517 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243003,73754,21763,8328,65,215366,115150,91402,108926,61705,169401,256,41460,16464,120542]

theorem envBound13518 : H12AffineFastState.Bounded env13518 := by
  intro p hp
  have h : env13518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13517_13518 : H12AffineEnvironment.transform 21 243003 env13517 = env13518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env13517 == env13518) = true)

def env13519 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243003,73754,21763,8272,65,215366,114966,91402,108926,61705,169313,256,41260,16464,120326]

theorem envBound13519 : H12AffineFastState.Bounded env13519 := by
  intro p hp
  have h : env13519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13518_13519 : H12AffineEnvironment.transform 6 88 env13518 = env13519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env13518 == env13519) = true)

theorem identity13519 : scanCanonicalize (H12AffineFastState.compose env13519 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound13519 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env13520 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,103447,122226,1024,32769,4161,8492,73754,21763,8272,65,56657,114966,91402,108926,61705,65910,256,41260,16464,120326]

theorem envBound13520 : H12AffineFastState.Bounded env13520 := by
  intro p hp
  have h : env13520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13519_13520 : H12AffineEnvironment.transform 16 103447 env13519 = env13520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env13519 == env13520) = true)

theorem identity13520 : scanCanonicalize (H12AffineFastState.compose env13520 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound13520 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env13521 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54279,16400,2421,1024,32769,4161,8492,62493,21763,8272,65,56657,5393,45325,32121,61705,54641,256,41260,16464,513]

theorem envBound13521 : H12AffineFastState.Bounded env13521 := by
  intro p hp
  have h : env13521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13520_13521 : H12AffineEnvironment.transform 15 54279 env13520 = env13521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env13520 == env13521) = true)

theorem identity13521 : scanCanonicalize (H12AffineFastState.compose env13521 (packedSelected [3,5,8,17,18,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13521 : packedSelected [3,5,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env13522 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,32768,33110,5441,2421,1024,32769,4161,8492,41292,82,8272,65,34816,5393,45325,10280,42072,32800,256,41260,5377,513]

theorem envBound13522 : H12AffineFastState.Bounded env13522 := by
  intro p hp
  have h : env13522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13521_13522 : H12AffineEnvironment.transform 13 5457 env13521 = env13522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13521 == env13522) = true)

theorem identity13522 : scanCanonicalize (H12AffineFastState.compose env13522 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13522 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env13523 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8541,8203,5441,2421,1024,8540,4161,8492,17,82,8272,65,10589,5393,4176,10280,1285,8573,256,113,5377,513]

theorem envBound13523 : H12AffineFastState.Bounded env13523 := by
  intro p hp
  have h : env13523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13522_13523 : H12AffineEnvironment.transform 14 8541 env13522 = env13523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13522 == env13523) = true)

theorem identity13523 : scanCanonicalize (H12AffineFastState.compose env13523 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound13523 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env13524 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1385,5457,1076,1378,5441,2421,1024,1077,4161,1093,17,82,1337,65,3124,5393,4176,3393,1285,1044,256,113,5377,513]

theorem envBound13524 : H12AffineFastState.Bounded env13524 := by
  intro p hp
  have h : env13524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13523_13524 : H12AffineEnvironment.transform 12 1385 env13523 = env13524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env13523 == env13524) = true)

theorem identity13524 : scanCanonicalize (H12AffineFastState.compose env13524 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13524 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13525 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,349,4453,0,342,4469,2421,52,1,4161,113,17,82,269,65,2048,4389,4176,2421,305,32,256,113,4405,513]

theorem envBound13525 : H12AffineFastState.Bounded env13525 := by
  intro p hp
  have h : env13525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13524_13525 : H12AffineEnvironment.transform 9 52 env13524 = env13525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13524 == env13525) = true)

theorem identity13525 : scanCanonicalize (H12AffineFastState.compose env13525 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13526 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,0,263,4388,2340,52,1,4112,32,17,3,269,16,2048,4389,4097,2340,305,32,256,32,4405,513]

theorem envBound13526 : H12AffineFastState.Bounded env13526 := by
  intro p hp
  have h : env13526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13525_13526 : H12AffineEnvironment.transform 5 17 env13525 = env13526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13525 == env13526) = true)

def env13527 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243003,73754,21763,8273,65,215366,114967,91402,108926,61705,169312,256,41261,16464,120327]

theorem envBound13527 : H12AffineFastState.Bounded env13527 := by
  intro p hp
  have h : env13527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13518_13527 : H12AffineEnvironment.transform 6 89 env13518 = env13527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env13518 == env13527) = true)

theorem identity13527 : scanCanonicalize (H12AffineFastState.compose env13527 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound13527 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env13528 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,40971,131072,149861,1024,32769,4161,136496,32785,21763,8273,65,190797,24860,50433,2421,61705,169312,256,41261,16464,30220]

theorem envBound13528 : H12AffineFastState.Bounded env13528 := by
  intro p hp
  have h : env13528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13527_13528 : H12AffineEnvironment.transform 15 40971 env13527 = env13528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env13527 == env13528) = true)

theorem identity13528 : scanCanonicalize (H12AffineFastState.compose env13528 (packedSelected [4,7,9,14,16,18,20,23,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13528 : packedSelected [4,7,9,14,16,18,20,23,27,35] rootPS < 2^1333 := by decide +kernel

def env13529 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,33030,131072,149861,1024,32769,4161,136496,32785,21763,348,65,182336,16401,50433,2421,53252,169312,256,32800,16464,22273]

theorem envBound13529 : H12AffineFastState.Bounded env13529 := by
  intro p hp
  have h : env13529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13528_13529 : H12AffineEnvironment.transform 12 269 env13528 = env13529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13528 == env13529) = true)

theorem identity13529 : scanCanonicalize (H12AffineFastState.compose env13529 (packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13529 : packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env13530 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21761,21511,131072,149861,1024,21760,4161,136496,21776,21763,348,65,138561,16401,4096,2421,1285,147553,256,21793,16464,22273]

theorem envBound13530 : H12AffineFastState.Bounded env13530 := by
  intro p hp
  have h : env13530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13529_13530 : H12AffineEnvironment.transform 14 21761 env13529 = env13530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13529 == env13530) = true)

theorem identity13530 : scanCanonicalize (H12AffineFastState.compose env13530 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound13530 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env13531 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21761,21511,5140,23921,1024,21760,4161,292,21776,21763,348,65,2389,16401,4096,2421,1285,21621,256,21793,16464,22273]

theorem envBound13531 : H12AffineFastState.Bounded env13531 := by
  intro p hp
  have h : env13531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13530_13531 : H12AffineEnvironment.transform 16 5140 env13530 = env13531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env13530 == env13531) = true)

theorem identity13531 : scanCanonicalize (H12AffineFastState.compose env13531 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound13531 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env13532 : List Nat := [2,4,8,16,32,64,89,85,512,1024,2048,4096,88,16384,21588,21511,5140,23588,1024,21589,4161,113,21573,21590,9,65,2048,16401,4096,2080,1104,21621,85,21620,16464,22100]

theorem envBound13532 : H12AffineFastState.Bounded env13532 := by
  intro p hp
  have h : env13532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13531_13532 : H12AffineEnvironment.transform 7 85 env13531 = env13532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env13531 == env13532) = true)

theorem identity13532 : scanCanonicalize (H12AffineFastState.compose env13532 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13532 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13533 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,21509,21511,5140,23588,1024,21508,4112,32,21524,21511,9,16,2048,16401,4096,2080,1025,21540,4,21541,16385,22021]

theorem envBound13533 : H12AffineFastState.Bounded env13533 := by
  intro p hp
  have h : env13533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13532_13533 : H12AffineEnvironment.transform 5 17 env13532 = env13533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13532 == env13533) = true)

theorem identity13533 : scanCanonicalize (H12AffineFastState.compose env13533 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13533 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13534 : List Nat := [2,4,8,16,32,17,8,4,49,1024,2048,4096,9,16384,21509,21511,5140,23588,1024,21508,4112,32,21524,21511,9,16,2048,16401,4096,2080,1025,21540,4,21541,16385,21556]

theorem envBound13534 : H12AffineFastState.Bounded env13534 := by
  intro p hp
  have h : env13534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13533_13534 : H12AffineEnvironment.transform 8 49 env13533 = env13534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13533 == env13534) = true)

theorem identity13534 : scanCanonicalize (H12AffineFastState.compose env13534 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound13534 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env13535 : List Nat := [2,4,8,16,32,17,8,4,49,1024,2048,3109,9,16384,18464,18466,2097,16385,1024,18465,3125,32,18481,18466,9,16,2048,16401,3109,2080,1025,18433,4,18432,16385,18449]

theorem envBound13535 : H12AffineFastState.Bounded env13535 := by
  intro p hp
  have h : env13535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13534_13535 : H12AffineEnvironment.transform 11 3109 env13534 = env13535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env13534 == env13535) = true)

theorem identity13535 : scanCanonicalize (H12AffineFastState.compose env13535 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound13535 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13536 : List Nat := [2,4,8,16,32,17,8,4,49,1024,1076,17,9,16384,17428,17430,1029,16385,1024,17429,1,32,17413,17430,9,16,1076,16401,17,1044,1025,17461,4,17460,16385,17445]

theorem envBound13536 : H12AffineFastState.Bounded env13536 := by
  intro p hp
  have h : env13536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13535_13536 : H12AffineEnvironment.transform 10 1076 env13535 = env13536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env13535 == env13536) = true)

theorem identity13536 : scanCanonicalize (H12AffineFastState.compose env13536 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13536 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env13537 : List Nat := [2,4,8,16,16,17,8,4,1,1024,1028,17,9,16384,17428,17430,1029,16385,1024,17429,1,16,17413,17430,9,16,1028,16401,17,1044,1025,17413,4,17412,16385,17429]

theorem envBound13537 : H12AffineFastState.Bounded env13537 := by
  intro p hp
  have h : env13537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13536_13537 : H12AffineEnvironment.transform 4 16 env13536 = env13537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13536 == env13537) = true)

theorem identity13537 : scanCanonicalize (H12AffineFastState.compose env13537 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13537 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13538 : List Nat := [2,4,8,16,16,17,8,4,1,21,17,17,9,16384,16385,16387,16,16385,21,16384,1,16,16400,16387,9,16,17,16401,17,1,20,16400,4,16401,16385,16384]

theorem envBound13538 : H12AffineFastState.Bounded env13538 := by
  intro p hp
  have h : env13538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13537_13538 : H12AffineEnvironment.transform 9 21 env13537 = env13538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13537 == env13538) = true)

theorem identity13538 : scanCanonicalize (H12AffineFastState.compose env13538 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound13538 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13539 : List Nat := [2,4,8,16,16,17,8,4,1,21,17,17,9,1,0,2,16,0,21,1,1,16,17,2,9,16,17,16,17,1,20,17,4,16,0,1]

theorem envBound13539 : H12AffineFastState.Bounded env13539 := by
  intro p hp
  have h : env13539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13538_13539 : H12AffineEnvironment.transform 13 1 env13538 = env13539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env13538 == env13539) = true)

theorem identity13539 : scanCanonicalize (H12AffineFastState.compose env13539 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13540 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,0,9,1,0,2,1,0,4,1,1,1,0,2,9,1,0,1,0,1,5,0,4,1,0,1]

theorem envBound13540 : H12AffineFastState.Bounded env13540 := by
  intro p hp
  have h : env13540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13539_13540 : H12AffineEnvironment.transform 3 1 env13539 = env13540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13539 == env13540) = true)

theorem identity13540 : scanCanonicalize (H12AffineFastState.compose env13540 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13541 : List Nat := [2,0,8,1,1,0,8,0,1,0,0,0,9,1,0,2,1,0,0,1,1,1,0,2,9,1,0,1,0,1,1,0,0,1,0,1]

theorem envBound13541 : H12AffineFastState.Bounded env13541 := by
  intro p hp
  have h : env13541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13540_13541 : H12AffineEnvironment.transform 1 0 env13540 = env13541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13540 == env13541) = true)

def env13542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound13542 : H12AffineFastState.Bounded env13542 := by
  intro p hp
  have h : env13542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13349_13542 : H12AffineEnvironment.transform 18 1025 env13349 = env13542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13349 == env13542) = true)

theorem identity13542 : scanCanonicalize (H12AffineFastState.compose env13542 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485415) := by decide +kernel

theorem selectedBound13542 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485415,16777216,8328,65,23211175,18973837,375286,2305191,19163319,23160256,257,17049610,17090991,19222369]

theorem envBound13543 : H12AffineFastState.Bounded env13543 := by
  intro p hp
  have h : env13543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13542_13543 : H12AffineEnvironment.transform 22 2485415 env13542 = env13543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485415 env13542 == env13543) = true)

def env13544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485415,16777216,8328,65,16959643,18973837,375286,2305191,19163319,16876028,257,17049610,17090991,19222369]

theorem envBound13544 : H12AffineFastState.Bounded env13544 := by
  intro p hp
  have h : env13544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13543_13544 : H12AffineEnvironment.transform 21 2155580 env13543 = env13544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env13543 == env13544) = true)

def env13545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,16777216,8192,65,16959507,18973701,375166,2305071,19163199,16875892,257,17049610,17090855,19222369]

theorem envBound13545 : H12AffineFastState.Bounded env13545 := by
  intro p hp
  have h : env13545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13544_13545 : H12AffineEnvironment.transform 6 8 env13544 = env13545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13544 == env13545) = true)

def env13546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,16777216,8192,65,16959507,18973701,102742,2305071,18890775,16875892,257,16777250,16834831,18966345]

theorem envBound13546 : H12AffineFastState.Bounded env13546 := by
  intro p hp
  have h : env13546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13545_13546 : H12AffineEnvironment.transform 17 10280 env13545 = env13546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13545 == env13546) = true)

theorem identity13546 : scanCanonicalize (H12AffineFastState.compose env13546 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound13546 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,2,8192,65,182289,2196487,102742,2305071,2113557,98678,257,32,57613,2189131]

theorem envBound13547 : H12AffineFastState.Bounded env13547 := by
  intro p hp
  have h : env13547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13546_13547 : H12AffineEnvironment.transform 23 2 env13546 = env13547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env13546 == env13547) = true)

theorem identity13547 : scanCanonicalize (H12AffineFastState.compose env13547 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound13547 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env13548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,73770,17,2,8192,65,182289,16401,102742,190521,99331,98678,257,32,57613,41821]

theorem envBound13548 : H12AffineFastState.Bounded env13548 := by
  intro p hp
  have h : env13548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13547_13548 : H12AffineEnvironment.transform 20 115734 env13547 = env13548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env13547 == env13548) = true)

theorem identity13548 : scanCanonicalize (H12AffineFastState.compose env13548 (packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 115015) := by decide +kernel

theorem selectedBound13548 : packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,115015,10280,1025,32769,115734,73770,17,2,8192,65,67926,16401,102742,76158,99331,98678,257,32,57613,41821]

theorem envBound13549 : H12AffineFastState.Bounded env13549 := by
  intro p hp
  have h : env13549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13548_13549 : H12AffineEnvironment.transform 16 115015 env13548 = env13549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115015 env13548 == env13549) = true)

theorem identity13549 : scanCanonicalize (H12AffineFastState.compose env13549 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13549 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env13550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,82247,10280,1025,1,82966,73770,17,2,8192,65,67926,16401,69974,76158,66563,65910,257,32,24845,9053]

theorem envBound13550 : H12AffineFastState.Bounded env13550 := by
  intro p hp
  have h : env13550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13549_13550 : H12AffineEnvironment.transform 14 0 env13549 = env13550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13549 == env13550) = true)

theorem identity13550 : scanCanonicalize (H12AffineFastState.compose env13550 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound13550 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env13551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8574,24633,10280,1025,1,25960,340,17,2,8192,65,10280,16401,12328,2048,9597,8200,257,32,24845,9053]

theorem envBound13551 : H12AffineFastState.Bounded env13551 := by
  intro p hp
  have h : env13551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13550_13551 : H12AffineEnvironment.transform 15 8574 env13550 = env13551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env13550 == env13551) = true)

end H12CloudChart0