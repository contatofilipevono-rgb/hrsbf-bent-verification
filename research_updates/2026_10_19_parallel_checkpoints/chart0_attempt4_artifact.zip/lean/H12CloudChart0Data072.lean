import H12CloudChart0Data071

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound18149 : H12AffineFastState.Bounded env18149 := by
  intro p hp
  have h : env18149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18148_18149 : H12AffineEnvironment.transform 5 17 env18148 = env18149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18148 == env18149) = true)

theorem identity18149 : scanCanonicalize (H12AffineFastState.compose env18149 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18150 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,40,1,1,34,16,0,52,0,0,32,16,2,41,17,1,16,16,1,21,33,37,32,0,513]

theorem envBound18150 : H12AffineFastState.Bounded env18150 := by
  intro p hp
  have h : env18150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18149_18150 : H12AffineEnvironment.transform 7 36 env18149 = env18150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18149 == env18150) = true)

theorem identity18150 : scanCanonicalize (H12AffineFastState.compose env18150 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound18150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18151 : List Nat := [2,4,8,16,32,17,9,36,58,53,1,16,40,1,1,34,16,0,52,0,0,32,16,2,41,17,1,16,16,1,21,33,37,32,0,59]

theorem envBound18151 : H12AffineFastState.Bounded env18151 := by
  intro p hp
  have h : env18151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18150_18151 : H12AffineEnvironment.transform 8 58 env18150 = env18151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env18150 == env18151) = true)

def env18152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,169371,8328,64,245138,115150,17664,262280,119043,329731,257,213350,237763,63188]

theorem envBound18152 : H12AffineFastState.Bounded env18152 := by
  intro p hp
  have h : env18152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18110_18152 : H12AffineEnvironment.transform 21 272513 env18110 = env18152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18110 == env18152) = true)

theorem identity18152 : scanCanonicalize (H12AffineFastState.compose env18152 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound18152 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58517,272513,62660,41430,8328,64,100831,115150,17664,262280,119043,329731,257,95531,103566,63188]

theorem envBound18153 : H12AffineFastState.Bounded env18153 := by
  intro p hp
  have h : env18153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18152_18153 : H12AffineEnvironment.transform 16 13389 env18152 = env18153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env18152 == env18153) = true)

def env18154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58517,169,62660,41430,8328,64,100831,115150,17664,10400,119043,73771,257,95531,103566,63188]

theorem envBound18154 : H12AffineFastState.Bounded env18154 := by
  intro p hp
  have h : env18154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18153_18154 : H12AffineEnvironment.transform 17 10280 env18153 = env18154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18153 == env18154) = true)

theorem identity18154 : scanCanonicalize (H12AffineFastState.compose env18154 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound18154 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env18155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,13389,10280,1025,32769,58517,169,62660,41430,8328,64,31836,13389,17664,10400,9344,54696,257,32936,24845,63188]

theorem envBound18155 : H12AffineFastState.Bounded env18155 := by
  intro p hp
  have h : env18155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18154_18155 : H12AffineEnvironment.transform 15 62851 env18154 = env18155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env18154 == env18155) = true)

theorem identity18155 : scanCanonicalize (H12AffineFastState.compose env18155 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18155 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env18156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,13389,10280,1025,32769,58396,32,62541,41311,8193,64,31836,13389,17664,10281,9225,54561,257,32801,24845,63069]

theorem envBound18156 : H12AffineFastState.Bounded env18156 := by
  intro p hp
  have h : env18156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18155_18156 : H12AffineEnvironment.transform 6 9 env18155 = env18156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18155 == env18156) = true)

theorem identity18156 : scanCanonicalize (H12AffineFastState.compose env18156 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18156 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,13389,10280,1025,29789,4160,32,17,21763,8193,64,31836,13389,17664,10281,9225,8573,257,29821,24845,513]

theorem envBound18157 : H12AffineFastState.Bounded env18157 := by
  intro p hp
  have h : env18157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18156_18157 : H12AffineEnvironment.transform 14 29788 env18156 = env18157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18156 == env18157) = true)

theorem identity18157 : scanCanonicalize (H12AffineFastState.compose env18157 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18157 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,342,13389,10280,1025,1,4160,32,17,8543,8193,64,2048,13389,12636,10281,9225,8573,257,33,5457,513]

theorem envBound18158 : H12AffineFastState.Bounded env18158 := by
  intro p hp
  have h : env18158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18157_18158 : H12AffineEnvironment.transform 13 13404 env18157 = env18158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18157 == env18158) = true)

theorem identity18158 : scanCanonicalize (H12AffineFastState.compose env18158 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18158 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18159 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,262,13341,10280,1025,1,4112,32,17,8463,8193,16,2048,13341,12556,10281,9225,8493,257,33,5377,513]

theorem envBound18159 : H12AffineFastState.Bounded env18159 := by
  intro p hp
  have h : env18159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18158_18159 : H12AffineEnvironment.transform 5 16 env18158 = env18159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18158 == env18159) = true)

def env18160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58517,168,62660,41430,8328,64,100831,115150,17664,10401,119043,73770,257,95531,103566,63188]

theorem envBound18160 : H12AffineFastState.Bounded env18160 := by
  intro p hp
  have h : env18160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18153_18160 : H12AffineEnvironment.transform 17 10281 env18153 = env18160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18153 == env18160) = true)

theorem identity18160 : scanCanonicalize (H12AffineFastState.compose env18160 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 41463) := by decide +kernel

theorem selectedBound18160 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env18161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41463,13389,10281,1025,32769,58517,168,62660,41430,8328,64,10280,24633,17664,10401,28916,33245,257,54492,13689,63188]

theorem envBound18161 : H12AffineFastState.Bounded env18161 := by
  intro p hp
  have h : env18161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18160_18161 : H12AffineEnvironment.transform 15 41463 env18160 = env18161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41463 env18160 == env18161) = true)

theorem identity18161 : scanCanonicalize (H12AffineFastState.compose env18161 (packedSelected [1,3,5,8,11,12,15,17,18,23,26,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12693) := by decide +kernel

theorem selectedBound18161 : packedSelected [1,3,5,8,11,12,15,17,18,23,26,31,32] rootPS < 2^1333 := by decide +kernel

def env18162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12693,32768,41463,13389,10281,1025,32769,38144,168,34129,41430,8328,64,10280,4524,13461,10401,353,33245,257,42313,13689,34625]

theorem envBound18162 : H12AffineFastState.Bounded env18162 := by
  intro p hp
  have h : env18162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18161_18162 : H12AffineEnvironment.transform 13 12693 env18161 = env18162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12693 env18161 == env18162) = true)

theorem identity18162 : scanCanonicalize (H12AffineFastState.compose env18162 (packedSelected [3,5,12,14,15,17,18,23,31,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18162 : packedSelected [3,5,12,14,15,17,18,23,31,35] rootPS < 2^1333 := by decide +kernel

def env18163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,32768,41342,13389,10281,1025,32769,38144,33,34129,41311,8193,64,10280,4389,13340,10280,353,33108,257,42313,13689,34625]

theorem envBound18163 : H12AffineFastState.Bounded env18163 := by
  intro p hp
  have h : env18163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18162_18163 : H12AffineEnvironment.transform 6 9 env18162 = env18163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18162 == env18163) = true)

def env18164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,169370,8328,64,4691218,115150,17665,262280,119042,4268162,257,213350,237763,63189]

theorem envBound18164 : H12AffineFastState.Bounded env18164 := by
  intro p hp
  have h : env18164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18109_18164 : H12AffineEnvironment.transform 20 184537 env18109 = env18164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env18109 == env18164) = true)

def env18165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,169370,8328,64,245138,115150,17665,262280,119042,329730,257,213350,237763,63189]

theorem envBound18165 : H12AffineFastState.Bounded env18165 := by
  intro p hp
  have h : env18165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18164_18165 : H12AffineEnvironment.transform 21 272512 env18164 = env18165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18164 == env18165) = true)

def env18166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180225,169234,8192,64,245018,115014,17665,262144,119042,329730,257,213350,237643,63069]

theorem envBound18166 : H12AffineFastState.Bounded env18166 := by
  intro p hp
  have h : env18166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18165_18166 : H12AffineEnvironment.transform 6 8 env18165 = env18166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18165 == env18166) = true)

def env18167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21762,8192,64,97546,115014,17665,262144,119042,329730,257,98678,90203,63069]

theorem envBound18167 : H12AffineFastState.Bounded env18167 := by
  intro p hp
  have h : env18167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18166_18167 : H12AffineEnvironment.transform 16 49168 env18166 = env18167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18166 == env18167) = true)

theorem identity18167 : scanCanonicalize (H12AffineFastState.compose env18167 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound18167 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,4161,21792,17,21762,8192,64,97546,115014,17665,32040,119042,95530,257,98678,90203,63069]

theorem envBound18168 : H12AffineFastState.Bounded env18168 := by
  intro p hp
  have h : env18168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18167_18168 : H12AffineEnvironment.transform 17 32040 env18167 = env18168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env18167 == env18168) = true)

theorem identity18168 : scanCanonicalize (H12AffineFastState.compose env18168 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound18168 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21874,49168,32040,1025,32769,4161,21792,17,21762,8192,64,10360,37940,17665,32040,33904,8280,257,54276,13609,63069]

theorem envBound18169 : H12AffineFastState.Bounded env18169 := by
  intro p hp
  have h : env18169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18168_18169 : H12AffineEnvironment.transform 15 21874 env18168 = env18169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env18168 == env18169) = true)

theorem identity18169 : scanCanonicalize (H12AffineFastState.compose env18169 (packedSelected [7,14,16,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18169 : packedSelected [7,14,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,21874,24860,32040,1025,8461,4161,21792,17,21762,8192,64,10360,13624,17665,32040,9596,8280,257,29960,13609,22353]

theorem envBound18170 : H12AffineFastState.Bounded env18170 := by
  intro p hp
  have h : env18170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18169_18170 : H12AffineEnvironment.transform 14 8460 env18169 = env18170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18169 == env18170) = true)

theorem identity18170 : scanCanonicalize (H12AffineFastState.compose env18170 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18170 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18171 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,21795,24860,32040,1025,8461,4112,21792,17,21762,8192,17,10281,13624,17665,32040,9517,8201,257,29960,13609,22272]

theorem envBound18171 : H12AffineFastState.Bounded env18171 := by
  intro p hp
  have h : env18171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18170_18171 : H12AffineEnvironment.transform 5 17 env18170 = env18171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18170 == env18171) = true)

theorem identity18171 : scanCanonicalize (H12AffineFastState.compose env18171 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18171 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env18172 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,34,13341,10281,1025,8461,4112,33,17,3,8192,17,10281,13624,4096,10281,9517,8201,257,8201,13609,513]

theorem envBound18172 : H12AffineFastState.Bounded env18172 := by
  intro p hp
  have h : env18172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18171_18172 : H12AffineEnvironment.transform 13 5377 env18171 = env18172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18171 == env18172) = true)

theorem identity18172 : scanCanonicalize (H12AffineFastState.compose env18172 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18172 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18173 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,293,34,5172,2048,1025,292,4112,33,17,3,41,17,2048,5393,4096,2048,1284,32,257,32,5376,513]

theorem envBound18173 : H12AffineFastState.Bounded env18173 := by
  intro p hp
  have h : env18173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18172_18173 : H12AffineEnvironment.transform 12 41 env18172 = env18173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18172 == env18173) = true)

theorem identity18173 : scanCanonicalize (H12AffineFastState.compose env18173 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound18173 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18174 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1028,41,261,293,34,48,2048,1025,292,1044,33,17,3,41,17,2048,277,1028,2048,1284,32,257,32,260,513]

theorem envBound18174 : H12AffineFastState.Bounded env18174 := by
  intro p hp
  have h : env18174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18173_18174 : H12AffineEnvironment.transform 11 1028 env18173 = env18174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env18173 == env18174) = true)

theorem identity18174 : scanCanonicalize (H12AffineFastState.compose env18174 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound18174 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18175 : List Nat := [2,4,8,16,32,17,8,256,261,1024,2048,1028,41,261,293,34,48,2048,1025,292,1044,33,17,3,41,17,2048,277,1028,2048,1284,32,257,32,260,260]

theorem envBound18175 : H12AffineFastState.Bounded env18175 := by
  intro p hp
  have h : env18175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18174_18175 : H12AffineEnvironment.transform 8 261 env18174 = env18175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env18174 == env18175) = true)

theorem identity18175 : scanCanonicalize (H12AffineFastState.compose env18175 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18175 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18176 : List Nat := [2,4,8,16,32,17,8,256,261,1024,1076,1028,41,261,293,34,48,1076,1025,292,1044,33,17,3,41,17,1076,277,1028,1076,1284,32,257,32,260,260]

theorem envBound18176 : H12AffineFastState.Bounded env18176 := by
  intro p hp
  have h : env18176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18175_18176 : H12AffineEnvironment.transform 10 1076 env18175 = env18176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env18175 == env18176) = true)

theorem identity18176 : scanCanonicalize (H12AffineFastState.compose env18176 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18176 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env18177 : List Nat := [2,4,8,16,32,17,8,5,0,1024,1076,1028,41,0,32,34,48,1076,1025,33,1044,33,17,3,41,17,1076,16,1028,1076,1025,32,4,32,1,1]

theorem envBound18177 : H12AffineFastState.Bounded env18177 := by
  intro p hp
  have h : env18177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18176_18177 : H12AffineEnvironment.transform 7 5 env18176 = env18177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18176 == env18177) = true)

theorem identity18177 : scanCanonicalize (H12AffineFastState.compose env18177 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18177 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18178 : List Nat := [2,4,8,16,32,17,8,5,0,20,32,16,41,0,32,34,48,32,21,33,0,33,17,3,41,17,32,16,16,32,21,32,4,32,1,1]

theorem envBound18178 : H12AffineFastState.Bounded env18178 := by
  intro p hp
  have h : env18178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18177_18178 : H12AffineEnvironment.transform 9 20 env18177 = env18178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18177 == env18178) = true)

theorem identity18178 : scanCanonicalize (H12AffineFastState.compose env18178 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18178 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18179 : List Nat := [2,4,8,16,16,17,8,5,0,20,16,16,25,0,16,18,0,16,21,17,0,17,17,3,25,17,16,16,16,16,21,16,4,16,1,1]

theorem envBound18179 : H12AffineFastState.Bounded env18179 := by
  intro p hp
  have h : env18179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18178_18179 : H12AffineEnvironment.transform 4 16 env18178 = env18179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18178 == env18179) = true)

def env18180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,16,21763,8192,64,97547,115014,17665,262144,119042,329730,257,98679,90202,63069]

theorem envBound18180 : H12AffineFastState.Bounded env18180 := by
  intro p hp
  have h : env18180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18166_18180 : H12AffineEnvironment.transform 16 49169 env18166 = env18180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18166 == env18180) = true)

theorem identity18180 : scanCanonicalize (H12AffineFastState.compose env18180 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18180 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,262144,1025,32769,4160,272392,16,2,8192,64,75786,103495,4096,262144,99331,329730,257,98679,79195,41820]

theorem envBound18181 : H12AffineFastState.Bounded env18181 := by
  intro p hp
  have h : env18181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18180_18181 : H12AffineEnvironment.transform 13 5377 env18180 = env18181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18180 == env18181) = true)

theorem identity18181 : scanCanonicalize (H12AffineFastState.compose env18181 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound18181 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env18182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10361,1025,32769,4160,113,16,2,8192,64,75786,103495,4096,10361,99331,73851,257,98679,79195,41820]

theorem envBound18182 : H12AffineFastState.Bounded env18182 := by
  intro p hp
  have h : env18182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18181_18182 : H12AffineEnvironment.transform 17 10361 env18181 = env18182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env18181 == env18182) = true)

theorem identity18182 : scanCanonicalize (H12AffineFastState.compose env18182 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound18182 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env18183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,32803,38160,10361,1025,32769,4160,113,16,2,8192,64,43049,5220,4096,10361,1056,41048,257,340,46456,41820]

theorem envBound18183 : H12AffineFastState.Bounded env18183 := by
  intro p hp
  have h : env18183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18182_18183 : H12AffineEnvironment.transform 15 32803 env18182 = env18183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env18182 == env18183) = true)

theorem identity18183 : scanCanonicalize (H12AffineFastState.compose env18183 (packedSelected [2,6,9,10,12,15,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18183 : packedSelected [2,6,9,10,12,15,16,19,22] rootPS < 2^1333 := by decide +kernel

def env18184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,35,5392,10361,1025,1,4160,113,16,2,8192,64,10281,5220,4096,10361,1056,8280,257,340,13688,9052]

theorem envBound18184 : H12AffineFastState.Bounded env18184 := by
  intro p hp
  have h : env18184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18183_18184 : H12AffineEnvironment.transform 14 0 env18183 = env18184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18183 == env18184) = true)

theorem identity18184 : scanCanonicalize (H12AffineFastState.compose env18184 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound18184 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,0,35,5392,2049,1025,1,4160,113,16,2,120,64,2129,5220,4096,2049,1056,32,257,340,5376,804]

theorem envBound18185 : H12AffineFastState.Bounded env18185 := by
  intro p hp
  have h : env18185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18184_18185 : H12AffineEnvironment.transform 12 120 env18184 = env18185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env18184 == env18185) = true)

theorem identity18185 : scanCanonicalize (H12AffineFastState.compose env18185 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18185 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env18186 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,0,35,5220,2049,1025,1,4160,113,16,2,120,64,2129,5220,4096,2049,1056,32,117,32,5236,592]

theorem envBound18186 : H12AffineFastState.Bounded env18186 := by
  intro p hp
  have h : env18186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18185_18186 : H12AffineEnvironment.transform 7 116 env18185 = env18186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18185 == env18186) = true)

theorem identity18186 : scanCanonicalize (H12AffineFastState.compose env18186 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound18186 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18187 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3108,120,2129,0,35,2112,2049,1025,1,3172,113,16,2,120,64,2129,2112,3108,2049,1056,32,117,32,2128,592]

theorem envBound18187 : H12AffineFastState.Bounded env18187 := by
  intro p hp
  have h : env18187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18186_18187 : H12AffineEnvironment.transform 11 3108 env18186 = env18187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env18186 == env18187) = true)

theorem identity18187 : scanCanonicalize (H12AffineFastState.compose env18187 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18187 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18188 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,2064,120,2129,0,35,2112,2049,53,1,2128,113,16,2,120,64,2129,2112,2064,2049,20,32,117,32,2128,592]

theorem envBound18188 : H12AffineFastState.Bounded env18188 := by
  intro p hp
  have h : env18188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18187_18188 : H12AffineEnvironment.transform 9 52 env18187 = env18188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18187 == env18188) = true)

theorem identity18188 : scanCanonicalize (H12AffineFastState.compose env18188 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18188 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18189 : List Nat := [2,4,8,16,32,64,8,116,512,52,0,16,120,81,0,35,64,1,53,1,80,113,16,2,120,64,81,64,16,1,20,32,117,32,80,592]

theorem envBound18189 : H12AffineFastState.Bounded env18189 := by
  intro p hp
  have h : env18189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18188_18189 : H12AffineEnvironment.transform 10 0 env18188 = env18189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18188 == env18189) = true)

theorem identity18189 : scanCanonicalize (H12AffineFastState.compose env18189 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound18189 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env18190 : List Nat := [2,4,8,16,32,64,8,116,97,52,0,16,120,81,0,35,64,1,53,1,80,113,16,2,120,64,81,64,16,1,20,32,117,32,80,49]

theorem envBound18190 : H12AffineFastState.Bounded env18190 := by
  intro p hp
  have h : env18190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18189_18190 : H12AffineEnvironment.transform 8 97 env18189 = env18190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env18189 == env18190) = true)

def env18191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180224,169235,8193,64,245019,115015,17665,262145,119042,329730,257,213350,237642,63068]

theorem envBound18191 : H12AffineFastState.Bounded env18191 := by
  intro p hp
  have h : env18191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18165_18191 : H12AffineEnvironment.transform 6 9 env18165 = env18191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18165 == env18191) = true)

def env18192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,16,21763,8193,64,97547,115015,17665,262145,119042,329730,257,98678,90202,63068]

theorem envBound18192 : H12AffineFastState.Bounded env18192 := by
  intro p hp
  have h : env18192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18191_18192 : H12AffineEnvironment.transform 16 49168 env18191 = env18192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18191 == env18192) = true)

theorem identity18192 : scanCanonicalize (H12AffineFastState.compose env18192 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18192 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,262144,1025,29788,4160,272393,16,21763,8193,64,97547,79130,17665,262145,75103,329730,257,95531,90202,513]

theorem envBound18193 : H12AffineFastState.Bounded env18193 := by
  intro p hp
  have h : env18193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18192_18193 : H12AffineEnvironment.transform 14 29789 env18192 = env18193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18192 == env18193) = true)

theorem identity18193 : scanCanonicalize (H12AffineFastState.compose env18193 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound18193 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18194 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,13389,262144,1025,29788,4160,272393,16,21763,8193,64,10589,24908,17665,262145,28937,285780,257,8573,13324,513]

theorem envBound18194 : H12AffineFastState.Bounded env18194 := by
  intro p hp
  have h : env18194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18193_18194 : H12AffineEnvironment.transform 15 21590 env18193 = env18194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env18193 == env18194) = true)

theorem identity18194 : scanCanonicalize (H12AffineFastState.compose env18194 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18194 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,5392,262144,1025,21761,4160,264532,16,21763,348,64,2048,16401,17665,262145,20564,285780,257,32,5457,513]

theorem envBound18195 : H12AffineFastState.Bounded env18195 := by
  intro p hp
  have h : env18195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18194_18195 : H12AffineEnvironment.transform 12 349 env18194 = env18195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18194 == env18195) = true)

theorem identity18195 : scanCanonicalize (H12AffineFastState.compose env18195 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound18195 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,5392,2420,1025,21761,4160,32,16,21763,348,64,2048,16401,17665,2421,20564,21792,257,32,5457,513]

theorem envBound18196 : H12AffineFastState.Bounded env18196 := by
  intro p hp
  have h : env18196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18195_18196 : H12AffineEnvironment.transform 17 2420 env18195 = env18196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env18195 == env18196) = true)

theorem identity18196 : scanCanonicalize (H12AffineFastState.compose env18196 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18196 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1297,1095,5392,2420,1025,1296,4160,32,16,1298,348,64,2048,4096,5392,2421,69,1329,257,32,5457,513]

theorem envBound18197 : H12AffineFastState.Bounded env18197 := by
  intro p hp
  have h : env18197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18196_18197 : H12AffineEnvironment.transform 13 4113 env18196 = env18197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env18196 == env18197) = true)

theorem identity18197 : scanCanonicalize (H12AffineFastState.compose env18197 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18197 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,349,4113,1297,1095,5392,1076,1025,1296,4160,32,16,1298,348,64,1344,4096,5392,1077,69,1329,257,32,5457,513]

theorem envBound18198 : H12AffineFastState.Bounded env18198 := by
  intro p hp
  have h : env18198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18197_18198 : H12AffineEnvironment.transform 10 1344 env18197 = env18198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env18197 == env18198) = true)

theorem identity18198 : scanCanonicalize (H12AffineFastState.compose env18198 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18198 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18199 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,4096,41,4113,1125,1095,5220,1076,1025,1124,4160,32,16,1126,40,64,1076,4096,5220,1077,69,1093,117,32,5157,513]

theorem envBound18199 : H12AffineFastState.Bounded env18199 := by
  intro p hp
  have h : env18199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18198_18199 : H12AffineEnvironment.transform 7 116 env18198 = env18199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18198 == env18199) = true)

theorem identity18199 : scanCanonicalize (H12AffineFastState.compose env18199 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound18199 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env18200 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,1061,41,1076,1125,1095,65,1076,1025,1124,1125,32,16,1126,40,64,1076,1061,65,1077,69,1093,117,32,0,513]

theorem envBound18200 : H12AffineFastState.Bounded env18200 := by
  intro p hp
  have h : env18200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18199_18200 : H12AffineEnvironment.transform 11 1061 env18199 = env18200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env18199 == env18200) = true)

theorem identity18200 : scanCanonicalize (H12AffineFastState.compose env18200 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound18200 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env18201 : List Nat := [2,4,8,16,32,64,9,116,512,548,528,513,41,528,577,611,65,528,549,576,577,32,16,578,40,64,528,513,65,529,69,609,117,32,0,513]

theorem envBound18201 : H12AffineFastState.Bounded env18201 := by
  intro p hp
  have h : env18201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18200_18201 : H12AffineEnvironment.transform 9 548 env18200 = env18201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env18200 == env18201) = true)

theorem identity18201 : scanCanonicalize (H12AffineFastState.compose env18201 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18201 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env18202 : List Nat := [2,4,8,16,32,16,9,36,512,548,528,513,41,528,529,563,17,528,549,528,529,32,16,530,40,16,528,513,17,529,21,561,37,32,0,513]

theorem envBound18202 : H12AffineFastState.Bounded env18202 := by
  intro p hp
  have h : env18202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18201_18202 : H12AffineEnvironment.transform 5 16 env18201 = env18202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18201 == env18202) = true)

theorem identity18202 : scanCanonicalize (H12AffineFastState.compose env18202 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18202 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18203 : List Nat := [2,4,8,16,32,16,9,36,16,52,0,17,41,0,1,35,17,0,53,0,1,32,16,2,40,16,0,17,17,1,21,33,37,32,0,17]

theorem envBound18203 : H12AffineFastState.Bounded env18203 := by
  intro p hp
  have h : env18203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18202_18203 : H12AffineEnvironment.transform 8 16 env18202 = env18203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18202 == env18203) = true)

def env18204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21762,8193,64,97546,115015,17665,262145,119042,329730,257,98679,90203,63068]

theorem envBound18204 : H12AffineFastState.Bounded env18204 := by
  intro p hp
  have h : env18204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18191_18204 : H12AffineEnvironment.transform 16 49169 env18191 = env18204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18191 == env18204) = true)

theorem identity18204 : scanCanonicalize (H12AffineFastState.compose env18204 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound18204 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56437,1025,32769,4161,62588,17,21762,8193,64,97546,115015,17665,56436,119042,119927,257,98679,90203,63068]

theorem envBound18205 : H12AffineFastState.Bounded env18205 := by
  intro p hp
  have h : env18205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18204_18205 : H12AffineEnvironment.transform 17 56437 env18204 = env18205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env18204 == env18205) = true)

theorem identity18205 : scanCanonicalize (H12AffineFastState.compose env18205 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18205 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49169,56437,1025,32769,4161,54640,17,21762,269,64,89094,115015,17665,56436,119042,119927,257,98679,82263,55120]

theorem envBound18206 : H12AffineFastState.Bounded env18206 := by
  intro p hp
  have h : env18206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18205_18206 : H12AffineEnvironment.transform 12 268 env18205 = env18206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18205 == env18206) = true)

theorem identity18206 : scanCanonicalize (H12AffineFastState.compose env18206 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18206 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env18207 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,49169,56357,1025,32769,4113,54560,17,21762,269,16,89094,114967,17665,56356,119042,119847,257,98599,82183,55040]

theorem envBound18207 : H12AffineFastState.Bounded env18207 := by
  intro p hp
  have h : env18207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18206_18207 : H12AffineEnvironment.transform 5 16 env18206 = env18207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18206 == env18207) = true)

theorem identity18207 : scanCanonicalize (H12AffineFastState.compose env18207 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound18207 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env18208 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,33030,49169,56357,1025,32769,4113,54560,17,21762,269,16,56576,16401,17665,56356,20484,21793,257,33,49153,55040]

theorem envBound18208 : H12AffineFastState.Bounded env18208 := by
  intro p hp
  have h : env18208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18207_18208 : H12AffineEnvironment.transform 15 33030 env18207 = env18208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env18207 == env18208) = true)

theorem identity18208 : scanCanonicalize (H12AffineFastState.compose env18208 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18208 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env18209 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16401,23589,1025,1,4113,21792,17,21762,269,16,23808,16401,17665,23588,20484,21793,257,33,16385,22272]

theorem envBound18209 : H12AffineFastState.Bounded env18209 := by
  intro p hp
  have h : env18209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18208_18209 : H12AffineEnvironment.transform 14 0 env18208 = env18209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18208 == env18209) = true)

theorem identity18209 : scanCanonicalize (H12AffineFastState.compose env18209 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound18209 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env18210 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5157,0,262,5172,2048,1025,1,4113,261,17,295,269,16,2341,5172,4388,2049,1057,260,257,33,5156,805]

theorem envBound18210 : H12AffineFastState.Bounded env18210 := by
  intro p hp
  have h : env18210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18209_18210 : H12AffineEnvironment.transform 13 5157 env18209 = env18210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env18209 == env18210) = true)

theorem identity18210 : scanCanonicalize (H12AffineFastState.compose env18210 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound18210 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18211 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,268,2048,0,262,2065,2048,1025,1,3124,261,17,295,269,16,2341,2065,3329,2049,1057,260,257,33,2049,805]

theorem envBound18211 : H12AffineFastState.Bounded env18211 := by
  intro p hp
  have h : env18211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18210_18211 : H12AffineEnvironment.transform 11 3109 env18210 = env18211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env18210 == env18211) = true)

theorem identity18211 : scanCanonicalize (H12AffineFastState.compose env18211 (packedSelected [0,3,4,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18211 : packedSelected [0,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env18212 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,268,2048,0,262,2065,2048,272,1,2341,261,17,295,269,16,2341,2065,2064,2049,304,260,257,33,2049,805]

theorem envBound18212 : H12AffineFastState.Bounded env18212 := by
  intro p hp
  have h : env18212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18211_18212 : H12AffineEnvironment.transform 9 273 env18211 = env18212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18211 == env18212) = true)

theorem identity18212 : scanCanonicalize (H12AffineFastState.compose env18212 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18213 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,2064,40,2048,0,34,2065,2048,52,1,2049,33,17,3,41,16,2049,2065,2064,2049,20,32,37,33,2049,513]

theorem envBound18213 : H12AffineFastState.Bounded env18213 := by
  intro p hp
  have h : env18213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18212_18213 : H12AffineEnvironment.transform 7 36 env18212 = env18213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18212 == env18213) = true)

theorem identity18213 : scanCanonicalize (H12AffineFastState.compose env18213 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound18213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18214 : List Nat := [2,4,8,16,32,16,9,36,512,53,17,1,40,17,0,34,0,17,52,1,16,33,17,3,41,16,16,0,1,16,20,32,37,33,16,513]

theorem envBound18214 : H12AffineFastState.Bounded env18214 := by
  intro p hp
  have h : env18214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18213_18214 : H12AffineEnvironment.transform 10 17 env18213 = env18214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env18213 == env18214) = true)

theorem identity18214 : scanCanonicalize (H12AffineFastState.compose env18214 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound18214 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18215 : List Nat := [2,4,8,16,32,16,9,36,42,53,17,1,40,17,0,34,0,17,52,1,16,33,17,3,41,16,16,0,1,16,20,32,37,33,16,43]

theorem envBound18215 : H12AffineFastState.Bounded env18215 := by
  intro p hp
  have h : env18215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18214_18215 : H12AffineEnvironment.transform 8 42 env18214 = env18215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env18214 == env18215) = true)

theorem identity18215 : scanCanonicalize (H12AffineFastState.compose env18215 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18215 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18216 : List Nat := [2,4,8,16,11,16,9,15,1,30,17,1,3,17,0,9,0,17,31,1,16,10,17,3,2,16,16,0,1,16,20,11,14,10,16,0]

theorem envBound18216 : H12AffineFastState.Bounded env18216 := by
  intro p hp
  have h : env18216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18215_18216 : H12AffineEnvironment.transform 4 11 env18215 = env18216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18215 == env18216) = true)

def env18217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,169370,8328,64,245139,115150,17665,262280,119042,329731,257,213350,237763,63189]

theorem envBound18217 : H12AffineFastState.Bounded env18217 := by
  intro p hp
  have h : env18217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18164_18217 : H12AffineEnvironment.transform 21 272513 env18164 = env18217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18164 == env18217) = true)

theorem identity18217 : scanCanonicalize (H12AffineFastState.compose env18217 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound18217 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272513,17,21762,8328,64,97547,115150,17665,262280,119042,329731,257,98814,90203,63189]

theorem envBound18218 : H12AffineFastState.Bounded env18218 := by
  intro p hp
  have h : env18218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18217_18218 : H12AffineEnvironment.transform 16 49304 env18217 = env18218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env18217 == env18218) = true)

def env18219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21762,8192,64,97547,115014,17665,262144,119042,329731,257,98678,90203,63069]

theorem envBound18219 : H12AffineFastState.Bounded env18219 := by
  intro p hp
  have h : env18219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18218_18219 : H12AffineEnvironment.transform 6 8 env18218 = env18219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18218 == env18219) = true)

theorem identity18219 : scanCanonicalize (H12AffineFastState.compose env18219 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound18219 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,4161,21793,17,21762,8192,64,97547,115014,17665,32040,119042,95531,257,98678,90203,63069]

theorem envBound18220 : H12AffineFastState.Bounded env18220 := by
  intro p hp
  have h : env18220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18219_18220 : H12AffineEnvironment.transform 17 32040 env18219 = env18220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env18219 == env18220) = true)

theorem identity18220 : scanCanonicalize (H12AffineFastState.compose env18220 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound18220 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62590,49168,32040,1025,32769,4161,21793,17,21762,8192,64,35189,13624,17665,32040,9596,33109,257,29960,37925,63069]

theorem envBound18221 : H12AffineFastState.Bounded env18221 := by
  intro p hp
  have h : env18221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18220_18221 : H12AffineEnvironment.transform 15 62590 env18220 = env18221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env18220 == env18221) = true)

theorem identity18221 : scanCanonicalize (H12AffineFastState.compose env18221 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18221 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env18222 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62590,49168,31837,1025,32769,4161,21588,17,21623,8192,64,34816,13389,17524,31837,9225,32800,116,29821,37925,63069]

theorem envBound18222 : H12AffineFastState.Bounded env18222 := by
  intro p hp
  have h : env18222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18221_18222 : H12AffineEnvironment.transform 7 117 env18221 = env18222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18221 == env18222) = true)

theorem identity18222 : scanCanonicalize (H12AffineFastState.compose env18222 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18222 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env18223 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,35,13389,31837,1025,29788,4161,21588,17,21623,8192,64,31837,13389,17524,31837,9225,29821,116,29821,24696,512]

theorem envBound18223 : H12AffineFastState.Bounded env18223 := by
  intro p hp
  have h : env18223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18222_18223 : H12AffineEnvironment.transform 14 29789 env18222 = env18223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18222 == env18223) = true)

theorem identity18223 : scanCanonicalize (H12AffineFastState.compose env18223 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13436) := by decide +kernel

theorem selectedBound18223 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18224 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13436,33,35,13389,2081,1025,32,4161,8232,17,8203,8192,64,2081,13389,12296,2081,9225,1,116,1,5124,512]

theorem envBound18224 : H12AffineFastState.Bounded env18224 := by
  intro p hp
  have h : env18224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18223_18224 : H12AffineEnvironment.transform 13 13436 env18223 = env18224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13436 env18223 == env18224) = true)

theorem identity18224 : scanCanonicalize (H12AffineFastState.compose env18224 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18224 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env18225 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,8192,13405,0,2,13389,2048,1025,1,4161,8201,17,8203,8192,64,2048,13389,12296,2048,9225,1,85,1,5124,512]

theorem envBound18225 : H12AffineFastState.Bounded env18225 := by
  intro p hp
  have h : env18225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18224_18225 : H12AffineEnvironment.transform 4 1 env18224 = env18225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18224 == env18225) = true)

theorem identity18225 : scanCanonicalize (H12AffineFastState.compose env18225 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound18225 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18226 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,8,5205,0,2,5189,2048,1025,1,4161,1,17,3,8,64,2048,5189,4096,2048,1025,1,85,1,5124,512]

theorem envBound18226 : H12AffineFastState.Bounded env18226 := by
  intro p hp
  have h : env18226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18225_18226 : H12AffineEnvironment.transform 12 8 env18225 = env18226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env18225 == env18226) = true)

theorem identity18226 : scanCanonicalize (H12AffineFastState.compose env18226 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound18226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18227 : List Nat := [2,4,8,16,1,64,8,84,512,532,2048,4096,8,4673,0,2,4689,2048,533,1,4161,1,17,3,8,64,2048,4689,4096,2048,533,1,85,1,4624,512]

theorem envBound18227 : H12AffineFastState.Bounded env18227 := by
  intro p hp
  have h : env18227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18226_18227 : H12AffineEnvironment.transform 9 532 env18226 = env18227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env18226 == env18227) = true)

theorem identity18227 : scanCanonicalize (H12AffineFastState.compose env18227 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18227 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18228 : List Nat := [2,4,8,16,1,17,8,5,512,532,2048,4096,8,4624,0,2,4608,2048,533,1,4112,1,17,3,8,17,2048,4608,4096,2048,533,1,4,1,4624,512]

theorem envBound18228 : H12AffineFastState.Bounded env18228 := by
  intro p hp
  have h : env18228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18227_18228 : H12AffineEnvironment.transform 5 17 env18227 = env18228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18227 == env18228) = true)

theorem identity18228 : scanCanonicalize (H12AffineFastState.compose env18228 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound18228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18229 : List Nat := [2,4,8,16,1,17,8,5,512,532,2048,0,8,528,0,2,512,2048,533,1,16,1,17,3,8,17,2048,512,0,2048,533,1,4,1,528,512]

theorem envBound18229 : H12AffineFastState.Bounded env18229 := by
  intro p hp
  have h : env18229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18228_18229 : H12AffineEnvironment.transform 11 0 env18228 = env18229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env18228 == env18229) = true)

theorem identity18229 : scanCanonicalize (H12AffineFastState.compose env18229 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18229 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18230 : List Nat := [2,4,8,16,1,17,8,5,512,532,0,0,8,528,0,2,512,0,533,1,16,1,17,3,8,17,0,512,0,0,533,1,4,1,528,512]

theorem envBound18230 : H12AffineFastState.Bounded env18230 := by
  intro p hp
  have h : env18230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18229_18230 : H12AffineEnvironment.transform 10 0 env18229 = env18230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18229 == env18230) = true)

theorem identity18230 : scanCanonicalize (H12AffineFastState.compose env18230 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18230 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18231 : List Nat := [2,4,8,16,1,17,8,5,17,5,0,0,8,1,0,2,17,0,4,1,16,1,17,3,8,17,0,17,0,0,4,1,4,1,1,17]

theorem envBound18231 : H12AffineFastState.Bounded env18231 := by
  intro p hp
  have h : env18231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18230_18231 : H12AffineEnvironment.transform 8 17 env18230 = env18231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18230 == env18231) = true)

theorem identity18231 : scanCanonicalize (H12AffineFastState.compose env18231 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18232 : List Nat := [2,4,8,1,1,0,8,5,0,5,0,0,8,1,0,2,0,0,4,1,1,1,0,3,8,0,0,0,0,0,4,1,4,1,1,0]

theorem envBound18232 : H12AffineFastState.Bounded env18232 := by
  intro p hp
  have h : env18232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18231_18232 : H12AffineEnvironment.transform 3 1 env18231 = env18232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18231 == env18232) = true)

theorem identity18232 : scanCanonicalize (H12AffineFastState.compose env18232 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound18232 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18233 : List Nat := [2,0,8,1,1,0,8,1,0,1,0,0,8,1,0,2,0,0,0,1,1,1,0,3,8,0,0,0,0,0,0,1,0,1,1,0]

theorem envBound18233 : H12AffineFastState.Bounded env18233 := by
  intro p hp
  have h : env18233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18232_18233 : H12AffineEnvironment.transform 1 0 env18232 = env18233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env18232 == env18233) = true)

def env18234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21762,8193,64,97547,115015,17665,262145,119042,329731,257,98679,90203,63068]

theorem envBound18234 : H12AffineFastState.Bounded env18234 := by
  intro p hp
  have h : env18234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18218_18234 : H12AffineEnvironment.transform 6 9 env18218 = env18234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18218 == env18234) = true)

theorem identity18234 : scanCanonicalize (H12AffineFastState.compose env18234 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound18234 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56437,1025,32769,4161,62589,17,21762,8193,64,97547,115015,17665,56436,119042,119926,257,98679,90203,63068]

theorem envBound18235 : H12AffineFastState.Bounded env18235 := by
  intro p hp
  have h : env18235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18234_18235 : H12AffineEnvironment.transform 17 56437 env18234 = env18235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env18234 == env18235) = true)

theorem identity18235 : scanCanonicalize (H12AffineFastState.compose env18235 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound18235 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49169,56437,1025,32769,4161,62589,17,21762,8193,64,2128,46108,17665,56436,42073,41261,257,62508,5376,63068]

theorem envBound18236 : H12AffineFastState.Bounded env18236 := by
  intro p hp
  have h : env18236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18235_18236 : H12AffineEnvironment.transform 15 30043 env18235 = env18236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env18235 == env18236) = true)

theorem identity18236 : scanCanonicalize (H12AffineFastState.compose env18236 (packedSelected [0,7,10,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18236 : packedSelected [0,7,10,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env18237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,30043,24908,32040,1025,8540,4161,21792,17,21762,8193,64,2128,5441,17665,32041,1284,112,257,21873,5376,22273]

theorem envBound18237 : H12AffineFastState.Bounded env18237 := by
  intro p hp
  have h : env18237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18236_18237 : H12AffineEnvironment.transform 14 8541 env18236 = env18237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18236 == env18237) = true)

theorem identity18237 : scanCanonicalize (H12AffineFastState.compose env18237 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18237 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env18238 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29962,24861,32040,1025,8461,4112,21792,17,21762,8193,17,2049,5392,17665,32041,1284,33,257,21792,5376,22273]

theorem envBound18238 : H12AffineFastState.Bounded env18238 := by
  intro p hp
  have h : env18238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18237_18238 : H12AffineEnvironment.transform 5 17 env18237 = env18238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18237 == env18238) = true)

theorem identity18238 : scanCanonicalize (H12AffineFastState.compose env18238 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound18238 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env18239 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,12344,8460,1330,4389,3344,1025,8461,4112,9496,17,9530,8193,17,2049,5392,13625,3345,1284,33,257,9496,5376,10041]

theorem envBound18239 : H12AffineFastState.Bounded env18239 := by
  intro p hp
  have h : env18239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18238_18239 : H12AffineEnvironment.transform 13 12344 env18238 = env18239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env18238 == env18239) = true)

theorem identity18239 : scanCanonicalize (H12AffineFastState.compose env18239 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound18239 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env18240 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,4373,33,1330,4389,3344,1025,32,4112,1077,17,1047,300,17,2049,5392,5140,3345,1284,33,257,1077,5376,1556]

theorem envBound18240 : H12AffineFastState.Bounded env18240 := by
  intro p hp
  have h : env18240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18239_18240 : H12AffineEnvironment.transform 12 301 env18239 = env18240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env18239 == env18240) = true)

theorem identity18240 : scanCanonicalize (H12AffineFastState.compose env18240 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18241 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4373,33,262,4389,2340,53,32,4112,1,17,35,300,17,2049,4388,4128,2341,304,33,257,1,4404,544]

theorem envBound18241 : H12AffineFastState.Bounded env18241 := by
  intro p hp
  have h : env18241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18240_18241 : H12AffineEnvironment.transform 9 52 env18240 = env18241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18240 == env18241) = true)

theorem identity18241 : scanCanonicalize (H12AffineFastState.compose env18241 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound18241 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18242 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,1,301,276,33,262,292,2340,53,32,17,1,17,35,300,17,2049,293,33,2341,304,33,257,1,309,544]

theorem envBound18242 : H12AffineFastState.Bounded env18242 := by
  intro p hp
  have h : env18242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18241_18242 : H12AffineEnvironment.transform 11 1 env18241 = env18242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env18241 == env18242) = true)

theorem identity18242 : scanCanonicalize (H12AffineFastState.compose env18242 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18242 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18243 : List Nat := [2,4,8,16,1,17,9,256,512,21,2048,1,268,276,0,262,261,2309,20,1,17,1,17,2,269,17,2049,260,0,2308,273,0,257,1,276,513]

theorem envBound18243 : H12AffineFastState.Bounded env18243 := by
  intro p hp
  have h : env18243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18242_18243 : H12AffineEnvironment.transform 4 1 env18242 = env18243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18242 == env18243) = true)

theorem identity18243 : scanCanonicalize (H12AffineFastState.compose env18243 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound18243 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18244 : List Nat := [2,4,8,16,1,17,9,256,260,21,2048,1,268,276,0,262,261,2309,20,1,17,1,17,2,269,17,2049,260,0,2308,273,0,257,1,276,261]

theorem envBound18244 : H12AffineFastState.Bounded env18244 := by
  intro p hp
  have h : env18244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18243_18244 : H12AffineEnvironment.transform 8 260 env18243 = env18244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env18243 == env18244) = true)

theorem identity18244 : scanCanonicalize (H12AffineFastState.compose env18244 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18244 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18245 : List Nat := [2,4,8,16,1,17,9,256,260,21,0,1,268,276,0,262,261,261,20,1,17,1,17,2,269,17,1,260,0,260,273,0,257,1,276,261]

theorem envBound18245 : H12AffineFastState.Bounded env18245 := by
  intro p hp
  have h : env18245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18244_18245 : H12AffineEnvironment.transform 10 0 env18244 = env18245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18244 == env18245) = true)

theorem identity18245 : scanCanonicalize (H12AffineFastState.compose env18245 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18245 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18246 : List Nat := [2,4,8,1,1,0,9,256,260,4,0,1,268,261,0,262,261,261,5,1,0,1,0,2,269,0,1,260,0,260,256,0,257,1,261,261]

theorem envBound18246 : H12AffineFastState.Bounded env18246 := by
  intro p hp
  have h : env18246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18245_18246 : H12AffineEnvironment.transform 3 1 env18245 = env18246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18245 == env18246) = true)

theorem identity18246 : scanCanonicalize (H12AffineFastState.compose env18246 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18247 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,1,9,0,0,3,0,0,5,1,0,1,0,2,8,0,1,1,0,1,5,0,4,1,0,0]

theorem envBound18247 : H12AffineFastState.Bounded env18247 := by
  intro p hp
  have h : env18247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18246_18247 : H12AffineEnvironment.transform 7 5 env18246 = env18247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18246 == env18247) = true)

theorem identity18247 : scanCanonicalize (H12AffineFastState.compose env18247 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18247 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18248 : List Nat := [2,4,2,1,1,0,3,5,1,4,0,1,3,0,0,3,0,0,5,1,0,1,0,2,2,0,1,1,0,1,5,0,4,1,0,0]

theorem envBound18248 : H12AffineFastState.Bounded env18248 := by
  intro p hp
  have h : env18248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18247_18248 : H12AffineEnvironment.transform 2 2 env18247 = env18248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18247 == env18248) = true)

def env18249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound18249 : H12AffineFastState.Bounded env18249 := by
  intro p hp
  have h : env18249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17797_18249 : H12AffineEnvironment.transform 26 30393345 env17797 = env18249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env17797 == env18249) = true)

def env18250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound18250 : H12AffineFastState.Bounded env18250 := by
  intro p hp
  have h : env18250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18249_18250 : H12AffineEnvironment.transform 18 1024 env18249 = env18250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18249 == env18250) = true)

theorem identity18250 : scanCanonicalize (H12AffineFastState.compose env18250 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound18250 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,138,8328,64,13090955,2196486,10507601,8830977,8488091,6382922,256,10601510,10560899,8430413]

theorem envBound18251 : H12AffineFastState.Bounded env18251 := by
  intro p hp
  have h : env18251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18250_18251 : H12AffineEnvironment.transform 23 138 env18250 = env18251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env18250 == env18251) = true)

def env18252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,138,8328,64,4554755,2196486,2233817,295049,246803,6382922,256,2327726,2319627,189381]

theorem envBound18252 : H12AffineFastState.Bounded env18252 := by
  intro p hp
  have h : env18252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18252 : H12AffineEnvironment.transform 22 147592 env18251 = env18252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env18251 == env18252) = true)

def env18253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,138,8328,64,4450483,2196486,2233817,190521,246803,6382922,256,2327726,2319627,189381]

theorem envBound18253 : H12AffineFastState.Bounded env18253 := by
  intro p hp
  have h : env18253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18252_18253 : H12AffineEnvironment.transform 17 157872 env18252 = env18253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env18252 == env18253) = true)

theorem identity18253 : scanCanonicalize (H12AffineFastState.compose env18253 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound18253 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10280,1024,32769,2097152,4194304,16,138,8328,64,4302891,2196486,2118977,43169,99467,6382922,256,2212918,2172307,41821]

theorem envBound18254 : H12AffineFastState.Bounded env18254 := by
  intro p hp
  have h : env18254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18253_18254 : H12AffineEnvironment.transform 16 16536 env18253 = env18254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env18253 == env18254) = true)

def env18255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302891,2196486,2118977,43049,99331,6382922,256,2212918,2172187,41821]

theorem envBound18255 : H12AffineFastState.Bounded env18255 := by
  intro p hp
  have h : env18255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18254_18255 : H12AffineEnvironment.transform 6 8 env18254 = env18255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18254 == env18255) = true)

theorem identity18255 : scanCanonicalize (H12AffineFastState.compose env18255 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 58728) := by decide +kernel

theorem selectedBound18255 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env18256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,58728,4194304,16,2,8192,64,4302891,90478,45097,43049,99331,4292642,256,74078,114803,41821]

theorem envBound18256 : H12AffineFastState.Bounded env18256 := by
  intro p hp
  have h : env18256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18255_18256 : H12AffineEnvironment.transform 20 58728 env18255 = env18256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58728 env18255 == env18256) = true)

theorem identity18256 : scanCanonicalize (H12AffineFastState.compose env18256 (packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18256 : packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env18257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58728,4194304,16,2,8192,64,4229153,16740,45097,43049,41993,4235304,256,340,57465,41821]

theorem envBound18257 : H12AffineFastState.Bounded env18257 := by
  intro p hp
  have h : env18257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18256_18257 : H12AffineEnvironment.transform 15 8202 env18256 = env18257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18256 == env18257) = true)

theorem identity18257 : scanCanonicalize (H12AffineFastState.compose env18257 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41049) := by decide +kernel

theorem selectedBound18257 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env18258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58728,41049,16,2,8192,64,10360,16740,45097,43049,41993,113,256,340,57465,41821]

theorem envBound18258 : H12AffineFastState.Bounded env18258 := by
  intro p hp
  have h : env18258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18257_18258 : H12AffineEnvironment.transform 21 41049 env18257 = env18258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41049 env18257 == env18258) = true)

theorem identity18258 : scanCanonicalize (H12AffineFastState.compose env18258 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound18258 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env18259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8313,8202,16400,10280,1024,8312,17681,32,16,2,8192,64,10360,16740,4176,2128,1136,113,256,340,16384,804]

theorem envBound18259 : H12AffineFastState.Bounded env18259 := by
  intro p hp
  have h : env18259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18258_18259 : H12AffineEnvironment.transform 14 8313 env18258 = env18259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env18258 == env18259) = true)

theorem identity18259 : scanCanonicalize (H12AffineFastState.compose env18259 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18259 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,80,35,16400,2049,1024,81,17681,32,16,2,41,64,2129,16740,4176,2128,1136,113,256,340,16384,804]

theorem envBound18260 : H12AffineFastState.Bounded env18260 := by
  intro p hp
  have h : env18260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18259_18260 : H12AffineEnvironment.transform 12 41 env18259 = env18260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18259 == env18260) = true)

theorem identity18260 : scanCanonicalize (H12AffineFastState.compose env18260 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18260 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18261 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,80,35,16400,2049,1024,81,17509,32,16,2,41,64,2129,16400,4176,2128,1136,113,116,32,16384,592]

theorem envBound18261 : H12AffineFastState.Bounded env18261 := by
  intro p hp
  have h : env18261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18260_18261 : H12AffineEnvironment.transform 7 116 env18260 = env18261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18260 == env18261) = true)

theorem identity18261 : scanCanonicalize (H12AffineFastState.compose env18261 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18261 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env18262 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,16384,0,35,16400,2049,1024,1,17461,32,16,2,41,16,2049,16400,4096,2048,1056,33,36,32,16384,512]

theorem envBound18262 : H12AffineFastState.Bounded env18262 := by
  intro p hp
  have h : env18262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18261_18262 : H12AffineEnvironment.transform 5 16 env18261 = env18262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18261 == env18262) = true)

theorem identity18262 : scanCanonicalize (H12AffineFastState.compose env18262 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18263 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,16384,0,3,16400,2049,1024,1,17429,0,16,2,9,16,2049,16400,4096,2048,1024,1,4,0,16384,512]

theorem envBound18263 : H12AffineFastState.Bounded env18263 := by
  intro p hp
  have h : env18263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18262_18263 : H12AffineEnvironment.transform 4 0 env18262 = env18263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18262 == env18263) = true)

theorem identity18263 : scanCanonicalize (H12AffineFastState.compose env18263 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound18263 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18264 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5125,0,3,5141,2049,1024,1,4112,0,16,2,9,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound18264 : H12AffineFastState.Bounded env18264 := by
  intro p hp
  have h : env18264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18263_18264 : H12AffineEnvironment.transform 13 5125 env18263 = env18264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env18263 == env18264) = true)

def env18265 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1045,0,3,1029,2049,1024,1,0,0,16,2,9,16,2049,1029,16,2048,1024,1,4,0,1045,512]

theorem envBound18265 : H12AffineFastState.Bounded env18265 := by
  intro p hp
  have h : env18265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18264_18265 : H12AffineEnvironment.transform 11 16 env18264 = env18265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18264 == env18265) = true)

theorem identity18265 : scanCanonicalize (H12AffineFastState.compose env18265 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18266 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,9,1045,0,3,1029,1,1024,1,0,0,16,2,9,16,1,1029,16,0,1024,1,4,0,1045,512]

theorem envBound18266 : H12AffineFastState.Bounded env18266 := by
  intro p hp
  have h : env18266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18265_18266 : H12AffineEnvironment.transform 10 0 env18265 = env18266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18265 == env18266) = true)

def env18267 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,1,0,3,17,1,20,1,0,0,16,2,9,16,1,17,16,0,20,1,4,0,1,512]

theorem envBound18267 : H12AffineFastState.Bounded env18267 := by
  intro p hp
  have h : env18267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18266_18267 : H12AffineEnvironment.transform 9 20 env18266 = env18267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18266 == env18267) = true)

theorem identity18267 : scanCanonicalize (H12AffineFastState.compose env18267 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound18267 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18268 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,9,1,0,3,17,1,20,1,0,0,16,2,9,16,1,17,16,0,20,1,4,0,1,30]

theorem envBound18268 : H12AffineFastState.Bounded env18268 := by
  intro p hp
  have h : env18268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18267_18268 : H12AffineEnvironment.transform 8 30 env18267 = env18268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env18267 == env18268) = true)

def leafEnv18268 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,9,1,0,3,17,1,20,1,0,0,16,2,20,9,1,16,1,17,16,0,20,1,4,0,4,3,1,30,1,0,0]

def active18268 : List Nat := [0,1,2,3]

def tree18268 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18268 : H12WitnessSearch.Good tree18268 := H12GlobalWitnessIndex.good

theorem leafIdentity18268 : H12AffineFastState.composeSystem env18268 rootObs = leafEnv18268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18268 rootObs == leafEnv18268) = true)

theorem terminalChecked18268 : H12PackedTerminal.terminalCheckFast leafEnv18268 active18268 tree18268 = true := by decide +kernel

def env18269 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,0,0,3,16,1,21,1,0,0,16,2,9,16,1,16,16,0,21,1,4,0,0,512]

theorem envBound18269 : H12AffineFastState.Bounded env18269 := by
  intro p hp
  have h : env18269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18266_18269 : H12AffineEnvironment.transform 9 21 env18266 = env18269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18266 == env18269) = true)

theorem identity18269 : scanCanonicalize (H12AffineFastState.compose env18269 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound18269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18270 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,0,3,5,1,0,1,0,0,5,2,9,5,1,5,5,0,0,1,4,0,0,512]

theorem envBound18270 : H12AffineFastState.Bounded env18270 := by
  intro p hp
  have h : env18270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18269_18270 : H12AffineEnvironment.transform 3 5 env18269 = env18270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env18269 == env18270) = true)

def leafEnv18270 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,0,3,5,1,0,1,0,0,5,2,0,9,1,5,1,5,5,0,0,1,4,0,4,3,0,512,1,0,0]

def active18270 : List Nat := [0,1,2,8]

def tree18270 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18270 : H12WitnessSearch.Good tree18270 := H12GlobalWitnessIndex.good

theorem leafIdentity18270 : H12AffineFastState.composeSystem env18270 rootObs = leafEnv18270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18270 rootObs == leafEnv18270) = true)

theorem terminalChecked18270 : H12PackedTerminal.terminalCheckFast leafEnv18270 active18270 tree18270 = true := by decide +kernel

def env18271 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1044,0,3,1028,2049,1024,1,1,0,16,2,9,16,2049,1028,17,2048,1024,1,4,0,1044,512]

theorem envBound18271 : H12AffineFastState.Bounded env18271 := by
  intro p hp
  have h : env18271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18264_18271 : H12AffineEnvironment.transform 11 17 env18264 = env18271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18264 == env18271) = true)

theorem identity18271 : scanCanonicalize (H12AffineFastState.compose env18271 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound18271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18272 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,17,9,1044,0,3,1028,1045,1024,1,1,0,16,2,9,16,1045,1028,17,1044,1024,1,4,0,1044,512]

theorem envBound18272 : H12AffineFastState.Bounded env18272 := by
  intro p hp
  have h : env18272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18271_18272 : H12AffineEnvironment.transform 10 1044 env18271 = env18272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env18271 == env18272) = true)

def env18273 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,0,0,3,16,1,20,1,1,0,16,2,9,16,1,16,17,0,20,1,4,0,0,512]

theorem envBound18273 : H12AffineFastState.Bounded env18273 := by
  intro p hp
  have h : env18273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18272_18273 : H12AffineEnvironment.transform 9 20 env18272 = env18273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18272 == env18273) = true)

theorem identity18273 : scanCanonicalize (H12AffineFastState.compose env18273 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound18273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18274 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,17,9,0,0,3,16,1,20,1,1,0,16,2,9,16,1,16,17,0,20,1,4,0,0,30]

theorem envBound18274 : H12AffineFastState.Bounded env18274 := by
  intro p hp
  have h : env18274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18273_18274 : H12AffineEnvironment.transform 8 30 env18273 = env18274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env18273 == env18274) = true)

def leafEnv18274 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,17,9,0,0,3,16,1,20,1,1,0,16,2,20,9,1,16,1,16,17,0,20,1,4,0,4,3,0,30,1,1,0]

def active18274 : List Nat := [0,1,2,3]

def tree18274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18274 : H12WitnessSearch.Good tree18274 := H12GlobalWitnessIndex.good

theorem leafIdentity18274 : H12AffineFastState.composeSystem env18274 rootObs = leafEnv18274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18274 rootObs == leafEnv18274) = true)

theorem terminalChecked18274 : H12PackedTerminal.terminalCheckFast leafEnv18274 active18274 tree18274 = true := by decide +kernel

def env18275 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,9,1,0,3,17,0,21,1,1,0,16,2,9,16,0,17,17,1,21,1,4,0,1,512]

theorem envBound18275 : H12AffineFastState.Bounded env18275 := by
  intro p hp
  have h : env18275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18272_18275 : H12AffineEnvironment.transform 9 21 env18272 = env18275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18272 == env18275) = true)

theorem identity18275 : scanCanonicalize (H12AffineFastState.compose env18275 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound18275 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18276 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,9,1,0,3,4,0,0,1,1,0,5,2,9,5,0,4,4,1,0,1,4,0,1,512]

theorem envBound18276 : H12AffineFastState.Bounded env18276 := by
  intro p hp
  have h : env18276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18275_18276 : H12AffineEnvironment.transform 3 5 env18275 = env18276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env18275 == env18276) = true)

def leafEnv18276 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,9,1,0,3,4,0,0,1,1,0,5,2,0,9,1,5,0,4,4,1,0,1,4,0,4,3,1,512,1,1,0]

def active18276 : List Nat := [0,1,2,8]

def tree18276 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18276 : H12WitnessSearch.Good tree18276 := H12GlobalWitnessIndex.good

theorem leafIdentity18276 : H12AffineFastState.composeSystem env18276 rootObs = leafEnv18276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18276 rootObs == leafEnv18276) = true)

theorem terminalChecked18276 : H12PackedTerminal.terminalCheckFast leafEnv18276 active18276 tree18276 = true := by decide +kernel

def env18277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4302891,2196486,2118977,43048,99330,6382922,256,2212918,2172186,41821]

theorem envBound18277 : H12AffineFastState.Bounded env18277 := by
  intro p hp
  have h : env18277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18254_18277 : H12AffineEnvironment.transform 6 9 env18254 = env18277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18254 == env18277) = true)

theorem identity18277 : scanCanonicalize (H12AffineFastState.compose env18277 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18277 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,2097152,4194304,16,3,8193,64,4262263,2172250,2118977,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound18278 : H12AffineFastState.Bounded env18278 := by
  intro p hp
  have h : env18278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18277_18278 : H12AffineEnvironment.transform 14 8540 env18277 = env18278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18277 == env18278) = true)

theorem identity18278 : scanCanonicalize (H12AffineFastState.compose env18278 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound18278 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91467,4194304,16,3,8193,64,4262263,16401,77834,2420,75102,4194305,256,33,16465,513]

theorem envBound18279 : H12AffineFastState.Bounded env18279 := by
  intro p hp
  have h : env18279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18278_18279 : H12AffineEnvironment.transform 20 91467 env18278 = env18279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env18278 == env18279) = true)

theorem identity18279 : scanCanonicalize (H12AffineFastState.compose env18279 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18279 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,65536,16401,2421,1024,0,82966,4194304,16,3,348,64,4262263,16401,69975,2420,66563,4194305,256,33,16465,513]

theorem envBound18280 : H12AffineFastState.Bounded env18280 := by
  intro p hp
  have h : env18280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18279_18280 : H12AffineEnvironment.transform 12 349 env18279 = env18280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18279 == env18280) = true)

theorem identity18280 : scanCanonicalize (H12AffineFastState.compose env18280 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18280 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,343,16401,2421,1024,0,17729,4194304,16,3,348,64,4196384,16401,4096,2420,1364,4194305,256,33,16465,513]

theorem envBound18281 : H12AffineFastState.Bounded env18281 := by
  intro p hp
  have h : env18281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18280_18281 : H12AffineEnvironment.transform 15 343 env18280 = env18281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18280 == env18281) = true)

theorem identity18281 : scanCanonicalize (H12AffineFastState.compose env18281 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18281 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18282 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1024,0,17681,4194304,16,3,268,16,4196384,16401,4096,2340,1284,4194305,256,33,16385,513]

theorem envBound18282 : H12AffineFastState.Bounded env18282 := by
  intro p hp
  have h : env18282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18281_18282 : H12AffineEnvironment.transform 5 16 env18281 = env18282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18281 == env18282) = true)

theorem identity18282 : scanCanonicalize (H12AffineFastState.compose env18282 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound18282 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18283 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,1,263,5173,2341,1024,0,4405,4194304,16,3,268,16,4196384,5173,4096,2340,1284,4194305,256,33,5157,513]

theorem envBound18283 : H12AffineFastState.Bounded env18283 := by
  intro p hp
  have h : env18283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18282_18283 : H12AffineEnvironment.transform 13 5156 env18282 = env18283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env18282 == env18283) = true)

theorem identity18283 : scanCanonicalize (H12AffineFastState.compose env18283 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound18283 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18284 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,1,263,5173,2341,1024,0,4405,33,16,3,268,16,2049,5173,4096,2340,1284,32,256,33,5157,513]

theorem envBound18284 : H12AffineFastState.Bounded env18284 := by
  intro p hp
  have h : env18284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18283_18284 : H12AffineEnvironment.transform 21 33 env18283 = env18284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18283 == env18284) = true)

theorem identity18284 : scanCanonicalize (H12AffineFastState.compose env18284 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18285 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5173,2048,1024,0,4112,33,16,3,41,16,2049,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound18285 : H12AffineFastState.Bounded env18285 := by
  intro p hp
  have h : env18285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18284_18285 : H12AffineEnvironment.transform 7 37 env18284 = env18285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18284 == env18285) = true)

theorem identity18285 : scanCanonicalize (H12AffineFastState.compose env18285 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18286 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,34,4096,2048,53,0,4112,33,16,3,41,16,2049,4096,4096,2049,20,32,37,33,4112,513]

theorem envBound18286 : H12AffineFastState.Bounded env18286 := by
  intro p hp
  have h : env18286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18285_18286 : H12AffineEnvironment.transform 9 53 env18285 = env18286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18285 == env18286) = true)

theorem identity18286 : scanCanonicalize (H12AffineFastState.compose env18286 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound18286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18287 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,32,40,49,1,34,32,2048,53,0,48,33,16,3,41,16,2049,32,32,2049,20,32,37,33,48,513]

theorem envBound18287 : H12AffineFastState.Bounded env18287 := by
  intro p hp
  have h : env18287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18286_18287 : H12AffineEnvironment.transform 11 32 env18286 = env18287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env18286 == env18287) = true)

theorem identity18287 : scanCanonicalize (H12AffineFastState.compose env18287 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18287 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18288 : List Nat := [2,4,8,16,32,16,9,37,512,53,0,32,40,49,1,34,32,0,53,0,48,33,16,3,41,16,1,32,32,1,20,32,37,33,48,513]

theorem envBound18288 : H12AffineFastState.Bounded env18288 := by
  intro p hp
  have h : env18288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18287_18288 : H12AffineEnvironment.transform 10 0 env18287 = env18288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18287 == env18288) = true)

theorem identity18288 : scanCanonicalize (H12AffineFastState.compose env18288 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18288 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18289 : List Nat := [2,4,8,16,17,16,9,20,512,4,0,17,25,0,1,19,17,0,4,0,1,16,16,3,24,16,1,17,17,1,20,17,20,16,1,513]

theorem envBound18289 : H12AffineFastState.Bounded env18289 := by
  intro p hp
  have h : env18289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18288_18289 : H12AffineEnvironment.transform 4 17 env18288 = env18289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18288 == env18289) = true)

def env18290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,138,8328,64,4450482,2196486,2233817,190520,246803,6382922,256,2327726,2319627,189381]

theorem envBound18290 : H12AffineFastState.Bounded env18290 := by
  intro p hp
  have h : env18290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18252_18290 : H12AffineEnvironment.transform 17 157873 env18252 = env18290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env18252 == env18290) = true)

def env18291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450362,2196486,2233681,190520,246803,6382922,256,2327590,2319627,189261]

theorem envBound18291 : H12AffineFastState.Bounded env18291 := by
  intro p hp
  have h : env18291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18290_18291 : H12AffineEnvironment.transform 6 8 env18290 = env18291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18290 == env18291) = true)

theorem identity18291 : scanCanonicalize (H12AffineFastState.compose env18291 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound18291 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env18292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,2097152,4194304,73755,2,8192,64,4229153,2196486,2192714,100387,41992,6382922,256,2155581,2098448,99158]

theorem envBound18292 : H12AffineFastState.Bounded env18292 := by
  intro p hp
  have h : env18292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18291_18292 : H12AffineEnvironment.transform 16 90139 env18291 = env18292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env18291 == env18292) = true)

theorem identity18292 : scanCanonicalize (H12AffineFastState.compose env18292 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound18292 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env18293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,2097152,73770,73755,2,8192,64,108555,2196486,2192714,100387,41992,2114912,256,2155581,2098448,99158]

theorem envBound18293 : H12AffineFastState.Bounded env18293 := by
  intro p hp
  have h : env18293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18292_18293 : H12AffineEnvironment.transform 21 73770 env18292 = env18293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env18292 == env18293) = true)

theorem identity18293 : scanCanonicalize (H12AffineFastState.compose env18293 (packedSelected [0,1,3,9,16,20,22,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 83015) := by decide +kernel

theorem selectedBound18293 : packedSelected [0,1,3,9,16,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env18294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,83015,73770,73755,2,8192,64,108555,49217,12557,100387,41992,65831,256,106618,82263,99158]

theorem envBound18294 : H12AffineFastState.Bounded env18294 := by
  intro p hp
  have h : env18294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18293_18294 : H12AffineEnvironment.transform 20 83015 env18293 = env18294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83015 env18293 == env18294) = true)

theorem identity18294 : scanCanonicalize (H12AffineFastState.compose env18294 (packedSelected [1,2,3,4,6,8,11,12,14,15,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound18294 : packedSelected [1,2,3,4,6,8,11,12,14,15,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env18295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,65536,90139,67618,1024,80,83015,73770,73755,2,8192,64,75866,16400,12557,67698,9305,65831,256,73771,82263,66311]

theorem envBound18295 : H12AffineFastState.Bounded env18295 := by
  intro p hp
  have h : env18295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18294_18295 : H12AffineEnvironment.transform 14 81 env18294 = env18295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env18294 == env18295) = true)

theorem identity18295 : scanCanonicalize (H12AffineFastState.compose env18295 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18295 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env18296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,65536,82198,67618,1024,80,83015,65831,65814,2,269,64,67927,16400,4096,67698,1364,65831,256,65830,82263,66311]

theorem envBound18296 : H12AffineFastState.Bounded env18296 := by
  intro p hp
  have h : env18296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18295_18296 : H12AffineEnvironment.transform 12 269 env18295 = env18296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18295 == env18296) = true)

theorem identity18296 : scanCanonicalize (H12AffineFastState.compose env18296 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound18296 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env18297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,81,65536,71011,67618,1024,80,69682,65831,65814,2,269,64,67927,5221,4096,67698,1364,65831,256,65830,70946,66311]

theorem envBound18297 : H12AffineFastState.Bounded env18297 := by
  intro p hp
  have h : env18297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18296_18297 : H12AffineEnvironment.transform 13 5237 env18296 = env18297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env18296 == env18297) = true)

theorem identity18297 : scanCanonicalize (H12AffineFastState.compose env18297 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18297 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,81,263,5220,2341,1024,80,4405,32,17,2,269,64,2128,5221,4096,2421,1364,32,256,33,5157,512]

theorem envBound18298 : H12AffineFastState.Bounded env18298 := by
  intro p hp
  have h : env18298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18297_18298 : H12AffineEnvironment.transform 15 263 env18297 = env18298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18297 == env18298) = true)

theorem identity18298 : scanCanonicalize (H12AffineFastState.compose env18298 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound18298 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,815,4096,269,5237,81,263,5220,522,1024,80,4405,32,17,2,269,64,895,5221,4096,602,1364,32,256,33,5157,512]

theorem envBound18299 : H12AffineFastState.Bounded env18299 := by
  intro p hp
  have h : env18299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18298_18299 : H12AffineEnvironment.transform 10 815 env18298 = env18299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env18298 == env18299) = true)

theorem identity18299 : scanCanonicalize (H12AffineFastState.compose env18299 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18299 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18300 : List Nat := [2,4,8,16,32,64,8,85,512,1024,634,4096,88,5237,81,82,5220,522,1024,80,4192,32,17,2,88,64,554,5221,4096,602,1025,32,85,33,5157,512]

theorem envBound18300 : H12AffineFastState.Bounded env18300 := by
  intro p hp
  have h : env18300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18299_18300 : H12AffineEnvironment.transform 7 85 env18299 = env18300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18299 == env18300) = true)

theorem identity18300 : scanCanonicalize (H12AffineFastState.compose env18300 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18300 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18301 : List Nat := [2,4,8,16,1,64,8,85,512,1024,603,4096,88,5204,81,82,5189,522,1024,80,4161,1,17,2,88,64,523,5188,4096,602,1025,1,85,0,5124,512]

theorem envBound18301 : H12AffineFastState.Bounded env18301 := by
  intro p hp
  have h : env18301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18300_18301 : H12AffineEnvironment.transform 4 1 env18300 = env18301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18300 == env18301) = true)

theorem identity18301 : scanCanonicalize (H12AffineFastState.compose env18301 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18301 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18302 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,4096,8,5124,1,2,5141,522,1024,0,4113,1,17,2,8,16,523,5140,4096,522,1025,1,5,0,5124,512]

theorem envBound18302 : H12AffineFastState.Bounded env18302 := by
  intro p hp
  have h : env18302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18301_18302 : H12AffineEnvironment.transform 5 16 env18301 = env18302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18301 == env18302) = true)

theorem identity18302 : scanCanonicalize (H12AffineFastState.compose env18302 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18303 : List Nat := [2,4,8,16,1,16,8,5,512,21,523,4096,8,4113,1,2,4096,522,21,0,4113,1,17,2,8,16,523,4097,4096,522,20,1,5,0,4113,512]

theorem envBound18303 : H12AffineFastState.Bounded env18303 := by
  intro p hp
  have h : env18303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18302_18303 : H12AffineEnvironment.transform 9 21 env18302 = env18303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18302 == env18303) = true)

theorem identity18303 : scanCanonicalize (H12AffineFastState.compose env18303 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 516) := by decide +kernel

theorem selectedBound18303 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18304 : List Nat := [2,4,8,16,1,16,8,5,512,21,523,516,8,533,1,2,516,522,21,0,533,1,17,2,8,16,523,517,516,522,20,1,5,0,533,512]

theorem envBound18304 : H12AffineFastState.Bounded env18304 := by
  intro p hp
  have h : env18304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18303_18304 : H12AffineEnvironment.transform 11 516 env18303 = env18304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 516 env18303 == env18304) = true)

theorem identity18304 : scanCanonicalize (H12AffineFastState.compose env18304 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound18304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18305 : List Nat := [2,4,8,16,1,16,8,5,18,21,25,22,8,7,1,2,22,24,21,0,7,1,17,2,8,16,25,23,22,24,20,1,5,0,7,18]

theorem envBound18305 : H12AffineFastState.Bounded env18305 := by
  intro p hp
  have h : env18305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18304_18305 : H12AffineEnvironment.transform 8 18 env18304 = env18305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env18304 == env18305) = true)

theorem identity18305 : scanCanonicalize (H12AffineFastState.compose env18305 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound18305 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18306 : List Nat := [2,4,8,15,1,15,8,5,13,10,6,9,8,7,1,2,9,7,10,0,7,1,14,2,8,15,6,8,9,7,11,1,5,0,7,13]

theorem envBound18306 : H12AffineFastState.Bounded env18306 := by
  intro p hp
  have h : env18306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18305_18306 : H12AffineEnvironment.transform 3 15 env18305 = env18306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env18305 == env18306) = true)

def env18307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,64,4450363,2196486,2233680,190520,246803,6382922,256,2327591,2319627,189260]

theorem envBound18307 : H12AffineFastState.Bounded env18307 := by
  intro p hp
  have h : env18307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18290_18307 : H12AffineEnvironment.transform 6 9 env18290 = env18307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18290 == env18307) = true)

theorem identity18307 : scanCanonicalize (H12AffineFastState.compose env18307 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound18307 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1024,32769,2097152,4194304,41292,3,8193,64,4262262,2196486,2159645,2421,75102,6382922,256,2188650,2196550,513]

theorem envBound18308 : H12AffineFastState.Bounded env18308 := by
  intro p hp
  have h : env18308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18307_18308 : H12AffineEnvironment.transform 16 57677 env18307 = env18308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env18307 == env18308) = true)

theorem identity18308 : scanCanonicalize (H12AffineFastState.compose env18308 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound18308 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env18309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1024,32769,2097152,4194304,41292,3,8193,64,4229152,2098512,2159645,2421,41992,6349852,256,2155580,2098448,513]

theorem envBound18309 : H12AffineFastState.Bounded env18309 := by
  intro p hp
  have h : env18309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18308_18309 : H12AffineEnvironment.transform 15 33110 env18308 = env18309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env18308 == env18309) = true)

theorem identity18309 : scanCanonicalize (H12AffineFastState.compose env18309 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound18309 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env18310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1024,32769,2097152,32,41292,3,8193,64,34816,2098512,2159645,2421,41992,2155580,256,2155580,2098448,513]

theorem envBound18310 : H12AffineFastState.Bounded env18310 := by
  intro p hp
  have h : env18310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18309_18310 : H12AffineEnvironment.transform 21 32 env18309 = env18310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env18309 == env18310) = true)

theorem identity18310 : scanCanonicalize (H12AffineFastState.compose env18310 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18310 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,33110,49216,35189,1024,32769,2097152,32,32833,3,268,64,34816,2098512,2151696,2421,34053,2147633,256,2147633,2098448,513]

theorem envBound18311 : H12AffineFastState.Bounded env18311 := by
  intro p hp
  have h : env18311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18310_18311 : H12AffineEnvironment.transform 12 269 env18310 = env18311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18310 == env18311) = true)

theorem identity18311 : scanCanonicalize (H12AffineFastState.compose env18311 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound18311 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env18312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33110,37940,35189,1024,32769,2097152,32,32833,3,268,64,34816,2098512,2130276,2421,34053,2134341,256,2134341,2098448,513]

theorem envBound18312 : H12AffineFastState.Bounded env18312 := by
  intro p hp
  have h : env18312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18311_18312 : H12AffineEnvironment.transform 13 5236 env18311 = env18312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env18311 == env18312) = true)

theorem identity18312 : scanCanonicalize (H12AffineFastState.compose env18312 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18312 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env18313 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33030,37940,35109,1024,32769,2097152,32,32785,3,268,16,34816,2098432,2130228,2341,34053,2134293,256,2134293,2098448,513]

theorem envBound18313 : H12AffineFastState.Bounded env18313 := by
  intro p hp
  have h : env18313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18312_18313 : H12AffineEnvironment.transform 5 16 env18312 = env18313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18312 == env18313) = true)

theorem identity18313 : scanCanonicalize (H12AffineFastState.compose env18313 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(20+1) ^^^ 37173) := by decide +kernel

theorem selectedBound18313 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env18314 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33030,37940,35109,1024,32769,37173,32,32785,3,268,16,34816,37941,4097,2341,34053,32,256,32,37925,513]

theorem envBound18314 : H12AffineFastState.Bounded env18314 := by
  intro p hp
  have h : env18314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18313_18314 : H12AffineEnvironment.transform 20 37173 env18313 = env18314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37173 env18313 == env18314) = true)

theorem identity18314 : scanCanonicalize (H12AffineFastState.compose env18314 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound18314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,1297,1047,4389,3124,1024,1296,5156,32,1280,3,268,16,3345,4388,4097,2341,20,32,256,32,4404,513]

theorem envBound18315 : H12AffineFastState.Bounded env18315 := by
  intro p hp
  have h : env18315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18314_18315 : H12AffineEnvironment.transform 14 1297 env18314 = env18315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env18314 == env18315) = true)

def env18316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,138,8328,64,4554754,2196486,2233816,295048,246802,6382922,256,2327727,2319626,189380]

theorem envBound18316 : H12AffineFastState.Bounded env18316 := by
  intro p hp
  have h : env18316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18316 : H12AffineEnvironment.transform 22 147593 env18251 = env18316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env18251 == env18316) = true)

def env18317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,138,8328,64,4450482,2196486,2233816,190520,246802,6382922,256,2327727,2319626,189380]

theorem envBound18317 : H12AffineFastState.Bounded env18317 := by
  intro p hp
  have h : env18317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18316_18317 : H12AffineEnvironment.transform 17 157872 env18316 = env18317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env18316 == env18317) = true)

theorem identity18317 : scanCanonicalize (H12AffineFastState.compose env18317 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound18317 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,4194304,41292,138,8328,64,4262263,2196486,2159645,2557,75223,6382922,256,2188650,2196687,513]

theorem envBound18318 : H12AffineFastState.Bounded env18318 := by
  intro p hp
  have h : env18318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18317_18318 : H12AffineEnvironment.transform 16 57797 env18317 = env18318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env18317 == env18318) = true)

theorem identity18318 : scanCanonicalize (H12AffineFastState.compose env18318 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound18318 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env18319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,57797,35189,1024,32769,2097152,4194304,41292,138,8328,64,4229289,2098648,2159645,2557,41993,6349972,256,2155700,2098449,513]

theorem envBound18319 : H12AffineFastState.Bounded env18319 := by
  intro p hp
  have h : env18319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18318_18319 : H12AffineEnvironment.transform 15 33246 env18318 = env18319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env18318 == env18319) = true)

def env18320 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,2097152,4194304,41244,138,8328,16,4229289,2098568,2159645,2477,41993,6349972,256,2155700,2098449,513]

theorem envBound18320 : H12AffineFastState.Bounded env18320 := by
  intro p hp
  have h : env18320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18319_18320 : H12AffineEnvironment.transform 5 16 env18319 = env18320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18319 == env18320) = true)

theorem identity18320 : scanCanonicalize (H12AffineFastState.compose env18320 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound18320 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env18321 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,2097152,41260,41244,138,8328,16,10629,2098568,2159645,2477,41993,2115000,256,2155700,2098449,513]

theorem envBound18321 : H12AffineFastState.Bounded env18321 := by
  intro p hp
  have h : env18321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18320_18321 : H12AffineEnvironment.transform 21 41260 env18320 = env18321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env18320 == env18321) = true)

theorem identity18321 : scanCanonicalize (H12AffineFastState.compose env18321 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound18321 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18322 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,58396,41260,41244,138,8328,16,10629,57748,4097,2477,41993,41380,256,168,57613,513]

theorem envBound18322 : H12AffineFastState.Bounded env18322 := by
  intro p hp
  have h : env18322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18321_18322 : H12AffineEnvironment.transform 20 58396 env18321 = env18322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env18321 == env18322) = true)

theorem identity18322 : scanCanonicalize (H12AffineFastState.compose env18322 (packedSelected [1,4,5,8,9,14,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound18322 : packedSelected [1,4,5,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env18323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,33166,49169,35109,1024,32769,50584,32936,32920,138,268,16,2049,49168,4097,2477,34189,32800,256,168,49289,513]

theorem envBound18323 : H12AffineFastState.Bounded env18323 := by
  intro p hp
  have h : env18323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18322_18323 : H12AffineEnvironment.transform 12 388 env18322 = env18323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env18322 == env18323) = true)

theorem identity18323 : scanCanonicalize (H12AffineFastState.compose env18323 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18323 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env18324 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,1,399,16400,2340,1024,0,17817,169,153,138,268,16,2049,16401,4097,2477,1420,33,256,168,16520,513]

theorem envBound18324 : H12AffineFastState.Bounded env18324 := by
  intro p hp
  have h : env18324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18323_18324 : H12AffineEnvironment.transform 14 1 env18323 = env18324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18323 == env18324) = true)

theorem identity18324 : scanCanonicalize (H12AffineFastState.compose env18324 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 7340) := by decide +kernel

theorem selectedBound18324 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18325 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,7340,1,399,7356,2340,1024,0,6453,169,153,138,268,16,2049,7357,4097,2477,1420,33,256,168,7204,513]

theorem envBound18325 : H12AffineFastState.Bounded env18325 := by
  intro p hp
  have h : env18325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18324_18325 : H12AffineEnvironment.transform 13 7340 env18324 = env18325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7340 env18324 == env18325) = true)

theorem identity18325 : scanCanonicalize (H12AffineFastState.compose env18325 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound18325 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18326 : List Nat := [2,4,8,16,32,16,128,256,512,1024,429,4096,388,5377,1,399,5393,137,1024,0,4248,169,153,138,268,16,428,5392,4097,0,1420,33,256,168,5513,513]

theorem envBound18326 : H12AffineFastState.Bounded env18326 := by
  intro p hp
  have h : env18326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18325_18326 : H12AffineEnvironment.transform 10 429 env18325 = env18326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env18325 == env18326) = true)

theorem identity18326 : scanCanonicalize (H12AffineFastState.compose env18326 (packedSelected [0,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound18326 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env18327 : List Nat := [2,4,8,16,32,16,128,256,512,1024,429,309,388,1076,1,399,1060,137,1024,0,429,169,153,138,268,16,428,1061,308,0,1420,33,256,168,1212,513]

theorem envBound18327 : H12AffineFastState.Bounded env18327 := by
  intro p hp
  have h : env18327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18326_18327 : H12AffineEnvironment.transform 11 309 env18326 = env18327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env18326 == env18327) = true)

theorem identity18327 : scanCanonicalize (H12AffineFastState.compose env18327 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18327 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env18328 : List Nat := [2,4,8,16,32,16,128,256,512,52,429,309,388,0,1,399,16,137,52,0,429,169,153,138,268,16,428,17,308,0,440,33,256,168,136,513]

theorem envBound18328 : H12AffineFastState.Bounded env18328 := by
  intro p hp
  have h : env18328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18327_18328 : H12AffineEnvironment.transform 9 52 env18327 = env18328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18327 == env18328) = true)

theorem identity18328 : scanCanonicalize (H12AffineFastState.compose env18328 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18328 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env18329 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,309,268,0,1,263,16,1,52,0,293,33,17,2,268,16,292,17,308,0,304,33,256,32,0,513]

theorem envBound18329 : H12AffineFastState.Bounded env18329 := by
  intro p hp
  have h : env18329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18328_18329 : H12AffineEnvironment.transform 6 8 env18328 = env18329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18328 == env18329) = true)

theorem identity18329 : scanCanonicalize (H12AffineFastState.compose env18329 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18330 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,1,35,16,1,52,0,1,33,17,2,40,16,0,17,16,0,20,33,36,32,0,513]

theorem envBound18330 : H12AffineFastState.Bounded env18330 := by
  intro p hp
  have h : env18330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18329_18330 : H12AffineEnvironment.transform 7 36 env18329 = env18330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18329 == env18330) = true)

theorem identity18330 : scanCanonicalize (H12AffineFastState.compose env18330 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound18330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18331 : List Nat := [2,4,8,16,32,16,8,36,32,52,1,17,40,0,1,35,16,1,52,0,1,33,17,2,40,16,0,17,16,0,20,33,36,32,0,33]

theorem envBound18331 : H12AffineFastState.Bounded env18331 := by
  intro p hp
  have h : env18331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18330_18331 : H12AffineEnvironment.transform 8 32 env18330 = env18331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env18330 == env18331) = true)

theorem identity18331 : scanCanonicalize (H12AffineFastState.compose env18331 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18331 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18332 : List Nat := [2,4,8,16,17,16,8,21,17,5,1,17,25,0,1,18,16,1,5,0,1,16,17,2,25,16,0,17,16,0,20,16,21,17,0,16]

theorem envBound18332 : H12AffineFastState.Bounded env18332 := by
  intro p hp
  have h : env18332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18331_18332 : H12AffineEnvironment.transform 4 17 env18331 = env18332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18331 == env18332) = true)

def env18333 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,2097152,4194304,41245,138,8328,17,4229289,2098569,2159645,2476,41993,6349972,256,2155700,2098449,513]

theorem envBound18333 : H12AffineFastState.Bounded env18333 := by
  intro p hp
  have h : env18333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18319_18333 : H12AffineEnvironment.transform 5 17 env18319 = env18333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18319 == env18333) = true)

def env18334 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,36624,4194304,41245,138,8328,17,4229289,35481,31501,2476,41993,4221828,256,27556,35329,513]

theorem envBound18334 : H12AffineFastState.Bounded env18334 := by
  intro p hp
  have h : env18334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18333_18334 : H12AffineEnvironment.transform 20 36624 env18333 = env18334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36624 env18333 == env18334) = true)

theorem identity18334 : scanCanonicalize (H12AffineFastState.compose env18334 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 54788) := by decide +kernel

theorem selectedBound18334 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,36624,54788,41245,138,8328,17,24237,35481,31501,2476,41993,48512,256,27556,35329,513]

theorem envBound18335 : H12AffineFastState.Bounded env18335 := by
  intro p hp
  have h : env18335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18334_18335 : H12AffineEnvironment.transform 21 54788 env18334 = env18335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54788 env18334 == env18335) = true)

def env18336 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33031,57628,35108,1024,32769,36624,54788,41245,2,8192,17,24101,35345,31501,2340,41993,48392,256,27436,35329,513]

theorem envBound18336 : H12AffineFastState.Bounded env18336 := by
  intro p hp
  have h : env18336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18335_18336 : H12AffineEnvironment.transform 6 8 env18335 = env18336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18335 == env18336) = true)

theorem identity18336 : scanCanonicalize (H12AffineFastState.compose env18336 (packedSelected [0,1,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 15656) := by decide +kernel

theorem selectedBound18336 : packedSelected [0,1,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env18337 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,15656,15407,23604,13324,1024,15657,12856,27436,7221,2,8192,17,24101,14137,31501,2340,6433,32,256,27436,14121,513]

theorem envBound18337 : H12AffineFastState.Bounded env18337 := by
  intro p hp
  have h : env18337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18336_18337 : H12AffineEnvironment.transform 14 15656 env18336 = env18337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15656 env18336 == env18337) = true)

theorem identity18337 : scanCanonicalize (H12AffineFastState.compose env18337 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 11021) := by decide +kernel

theorem selectedBound18337 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18338 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,11021,15656,15407,14137,13324,1024,15657,12856,33,7221,2,8192,17,13608,14137,4096,2340,6433,32,256,33,14121,513]

theorem envBound18338 : H12AffineFastState.Bounded env18338 := by
  intro p hp
  have h : env18338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18337_18338 : H12AffineEnvironment.transform 13 11021 env18337 = env18338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11021 env18337 == env18338) = true)

theorem identity18338 : scanCanonicalize (H12AffineFastState.compose env18338 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound18338 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18339 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,4096,8192,11021,15132,14875,12557,12856,564,15133,12856,33,6657,2,8192,17,13084,12557,4096,2340,6433,32,256,33,12573,513]

theorem envBound18339 : H12AffineFastState.Bounded env18339 := by
  intro p hp
  have h : env18339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18338_18339 : H12AffineEnvironment.transform 9 564 env18338 = env18339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env18338 == env18339) = true)

theorem identity18339 : scanCanonicalize (H12AffineFastState.compose env18339 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18339 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env18340 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,4096,268,2561,6672,6935,4097,4916,564,6673,4916,33,6657,2,268,17,4624,4097,4096,2340,6433,32,256,33,4113,513]

theorem envBound18340 : H12AffineFastState.Bounded env18340 := by
  intro p hp
  have h : env18340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18339_18340 : H12AffineEnvironment.transform 12 268 env18339 = env18340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18339 == env18340) = true)

theorem identity18340 : scanCanonicalize (H12AffineFastState.compose env18340 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18341 : List Nat := [2,4,8,16,32,17,8,256,0,52,2048,4096,268,2049,6160,6423,4097,4404,52,6161,4404,33,6145,2,268,17,4112,4097,4096,2340,6433,32,256,33,4113,1]

theorem envBound18341 : H12AffineFastState.Bounded env18341 := by
  intro p hp
  have h : env18341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18340_18341 : H12AffineEnvironment.transform 8 0 env18340 = env18341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18340 == env18341) = true)

theorem identity18341 : scanCanonicalize (H12AffineFastState.compose env18341 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound18341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18342 : List Nat := [2,4,8,16,32,17,8,256,0,52,2048,2064,268,2049,0,263,2065,2340,52,1,2340,33,17,2,268,17,2048,2065,2064,2340,305,32,256,33,2049,1]

theorem envBound18342 : H12AffineFastState.Bounded env18342 := by
  intro p hp
  have h : env18342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18341_18342 : H12AffineEnvironment.transform 11 2064 env18341 = env18342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env18341 == env18342) = true)

theorem identity18342 : scanCanonicalize (H12AffineFastState.compose env18342 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18342 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18343 : List Nat := [2,4,8,16,32,17,8,4,0,52,2048,2064,8,2049,0,3,2065,2080,52,1,2080,33,17,2,8,17,2048,2065,2064,2080,53,32,4,33,2049,1]

theorem envBound18343 : H12AffineFastState.Bounded env18343 := by
  intro p hp
  have h : env18343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18342_18343 : H12AffineEnvironment.transform 7 4 env18342 = env18343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18342 == env18343) = true)

theorem identity18343 : scanCanonicalize (H12AffineFastState.compose env18343 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound18343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18344 : List Nat := [2,4,8,16,32,17,8,4,0,52,33,49,8,32,0,3,48,1,52,1,1,33,17,2,8,17,33,48,49,1,53,32,4,33,32,1]

theorem envBound18344 : H12AffineFastState.Bounded env18344 := by
  intro p hp
  have h : env18344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18343_18344 : H12AffineEnvironment.transform 10 33 env18343 = env18344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env18343 == env18344) = true)

theorem identity18344 : scanCanonicalize (H12AffineFastState.compose env18344 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18344 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env18345 : List Nat := [2,4,8,16,1,17,8,4,0,21,0,16,8,1,0,3,17,1,21,1,1,0,17,2,8,17,0,17,16,1,20,1,4,0,1,1]

theorem envBound18345 : H12AffineFastState.Bounded env18345 := by
  intro p hp
  have h : env18345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18344_18345 : H12AffineEnvironment.transform 4 1 env18344 = env18345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18344 == env18345) = true)

theorem identity18345 : scanCanonicalize (H12AffineFastState.compose env18345 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18345 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18346 : List Nat := [2,4,8,1,1,0,8,4,0,4,0,1,8,1,0,3,0,1,4,1,1,0,0,2,8,0,0,0,1,1,5,1,4,0,1,1]

theorem envBound18346 : H12AffineFastState.Bounded env18346 := by
  intro p hp
  have h : env18346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18345_18346 : H12AffineEnvironment.transform 3 1 env18345 = env18346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18345 == env18346) = true)

def env18347 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33030,57629,35108,1024,32769,36624,54788,41245,3,8193,17,24100,35344,31501,2341,41993,48393,256,27437,35329,513]

theorem envBound18347 : H12AffineFastState.Bounded env18347 := by
  intro p hp
  have h : env18347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18335_18347 : H12AffineEnvironment.transform 6 9 env18335 = env18347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18335 == env18347) = true)

theorem identity18347 : scanCanonicalize (H12AffineFastState.compose env18347 (packedSelected [0,1,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 7205) := by decide +kernel

theorem selectedBound18347 : packedSelected [0,1,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env18348 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,7205,7459,32056,5377,1024,7204,4917,18977,15672,3,8193,17,24100,5685,31501,2341,14380,8492,256,27437,5668,513]

theorem envBound18348 : H12AffineFastState.Bounded env18348 := by
  intro p hp
  have h : env18348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18347_18348 : H12AffineEnvironment.transform 14 7205 env18347 = env18348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7205 env18347 == env18348) = true)

theorem identity18348 : scanCanonicalize (H12AffineFastState.compose env18348 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18348 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18349 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,7205,7459,23605,5377,1024,7204,4917,18977,7221,3,268,17,24100,5685,23040,2341,6433,33,256,18976,5668,513]

theorem envBound18349 : H12AffineFastState.Bounded env18349 := by
  intro p hp
  have h : env18349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18348_18349 : H12AffineEnvironment.transform 12 269 env18348 = env18349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18348 == env18349) = true)

theorem identity18349 : scanCanonicalize (H12AffineFastState.compose env18349 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2561) := by decide +kernel

theorem selectedBound18349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18350 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,2561,7205,7459,5684,5377,1024,7204,4917,32,7221,3,268,17,5157,5685,4097,2341,6433,33,256,33,5668,513]

theorem envBound18350 : H12AffineFastState.Bounded env18350 := by
  intro p hp
  have h : env18350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18349_18350 : H12AffineEnvironment.transform 13 2561 env18349 = env18350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2561 env18349 == env18350) = true)

theorem identity18350 : scanCanonicalize (H12AffineFastState.compose env18350 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound18350 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18351 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1061,4096,269,1572,4096,4358,5684,5377,1024,4097,4917,32,4112,3,268,17,5157,5685,4097,1280,5380,33,256,33,5668,513]

theorem envBound18351 : H12AffineFastState.Bounded env18351 := by
  intro p hp
  have h : env18351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18350_18351 : H12AffineEnvironment.transform 10 1061 env18350 = env18351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env18350 == env18351) = true)

theorem identity18351 : scanCanonicalize (H12AffineFastState.compose env18351 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18351 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18352 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1061,1076,269,1572,1076,1330,512,309,1024,1077,1793,32,1060,3,268,17,17,513,1077,1280,304,33,256,33,528,513]

theorem envBound18352 : H12AffineFastState.Bounded env18352 := by
  intro p hp
  have h : env18352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18351_18352 : H12AffineEnvironment.transform 11 1076 env18351 = env18352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env18351 == env18352) = true)

theorem identity18352 : scanCanonicalize (H12AffineFastState.compose env18352 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound18352 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18353 : List Nat := [2,4,8,16,32,17,9,256,512,785,820,805,269,309,805,547,512,309,785,804,16,32,821,3,268,17,17,513,804,529,304,33,256,33,528,513]

theorem envBound18353 : H12AffineFastState.Bounded env18353 := by
  intro p hp
  have h : env18353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18352_18353 : H12AffineEnvironment.transform 9 785 env18352 = env18353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env18352 == env18353) = true)

theorem identity18353 : scanCanonicalize (H12AffineFastState.compose env18353 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18353 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env18354 : List Nat := [2,4,8,16,16,17,9,256,512,785,772,789,269,261,789,531,512,261,785,788,16,16,773,3,268,17,17,513,788,529,256,17,256,17,528,513]

theorem envBound18354 : H12AffineFastState.Bounded env18354 := by
  intro p hp
  have h : env18354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18353_18354 : H12AffineEnvironment.transform 4 16 env18353 = env18354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18353 == env18354) = true)

theorem identity18354 : scanCanonicalize (H12AffineFastState.compose env18354 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound18354 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env18355 : List Nat := [2,4,8,16,16,17,9,256,276,5,16,1,269,261,1,263,276,261,5,0,16,16,17,3,268,17,17,277,0,261,256,17,256,17,260,277]

theorem envBound18355 : H12AffineFastState.Bounded env18355 := by
  intro p hp
  have h : env18355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18354_18355 : H12AffineEnvironment.transform 8 276 env18354 = env18355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env18354 == env18355) = true)

theorem identity18355 : scanCanonicalize (H12AffineFastState.compose env18355 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18356 : List Nat := [2,4,8,16,16,17,9,5,17,5,16,1,8,0,1,2,17,0,5,0,16,16,17,3,9,17,17,16,0,0,5,17,5,17,1,16]

theorem envBound18356 : H12AffineFastState.Bounded env18356 := by
  intro p hp
  have h : env18356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18355_18356 : H12AffineEnvironment.transform 7 5 env18355 = env18356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18355 == env18356) = true)

def env18357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,36625,4194304,41245,138,8328,17,4229289,35480,31500,2476,41993,4221829,256,27557,35328,513]

theorem envBound18357 : H12AffineFastState.Bounded env18357 := by
  intro p hp
  have h : env18357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18333_18357 : H12AffineEnvironment.transform 20 36625 env18333 = env18357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36625 env18333 == env18357) = true)

theorem identity18357 : scanCanonicalize (H12AffineFastState.compose env18357 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 54925) := by decide +kernel

theorem selectedBound18357 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,36625,54925,41245,138,8328,17,24100,35480,31500,2476,41993,48392,256,27557,35328,513]

theorem envBound18358 : H12AffineFastState.Bounded env18358 := by
  intro p hp
  have h : env18358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18357_18358 : H12AffineEnvironment.transform 21 54925 env18357 = env18358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54925 env18357 == env18358) = true)

theorem identity18358 : scanCanonicalize (H12AffineFastState.compose env18358 (packedSelected [0,3,8,10,17,18,20,24,27,28,41] rootPS)) = affineNative (2^(14+1) ^^^ 27525) := by decide +kernel

theorem selectedBound18358 : packedSelected [0,3,8,10,17,18,20,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env18359 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,27525,27146,2577,25249,1024,27524,25748,15624,19096,138,8328,17,24100,24861,31500,2476,20364,22157,256,27557,24965,513]

theorem envBound18359 : H12AffineFastState.Bounded env18359 := by
  intro p hp
  have h : env18359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18358_18359 : H12AffineEnvironment.transform 14 27525 env18358 = env18359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27525 env18358 == env18359) = true)

theorem identity18359 : scanCanonicalize (H12AffineFastState.compose env18359 (packedSelected [0,1,2,6,8,10,12,20,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18359 : packedSelected [0,1,2,6,8,10,12,20,23,27] rootPS < 2^1333 := by decide +kernel

def env18360 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,27405,27146,2577,25129,1024,27404,25628,15624,18960,2,8192,17,24100,24861,31500,2340,20228,22021,256,27437,24845,513]

theorem envBound18360 : H12AffineFastState.Bounded env18360 := by
  intro p hp
  have h : env18360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18359_18360 : H12AffineEnvironment.transform 6 8 env18359 = env18360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18359 == env18360) = true)

theorem identity18360 : scanCanonicalize (H12AffineFastState.compose env18360 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound18360 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env18361 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,11577,1588,1843,2577,3856,1024,1589,2341,15624,10025,2,8192,17,13085,3108,5685,2340,8765,15164,256,1556,3124,513]

theorem envBound18361 : H12AffineFastState.Bounded env18361 := by
  intro p hp
  have h : env18361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18360_18361 : H12AffineEnvironment.transform 13 11577 env18360 = env18361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env18360 == env18361) = true)

theorem identity18361 : scanCanonicalize (H12AffineFastState.compose env18361 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound18361 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env18362 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,7465,4112,1588,1843,2577,3856,1024,1589,2341,33,6656,2,7465,17,3636,3108,5685,2340,7956,1557,256,1556,3124,513]

theorem envBound18362 : H12AffineFastState.Bounded env18362 := by
  intro p hp
  have h : env18362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18361_18362 : H12AffineEnvironment.transform 12 7465 env18361 = env18362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env18361 == env18362) = true)

theorem identity18362 : scanCanonicalize (H12AffineFastState.compose env18362 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3620) := by decide +kernel

theorem selectedBound18362 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env18363 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3620,781,3636,1588,1843,2577,3856,1024,1589,2341,33,1060,2,781,17,3636,3108,2065,2340,304,1557,256,1556,3124,513]

theorem envBound18363 : H12AffineFastState.Bounded env18363 := by
  intro p hp
  have h : env18363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18362_18363 : H12AffineEnvironment.transform 11 3620 env18362 = env18363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3620 env18362 == env18363) = true)

theorem identity18363 : scanCanonicalize (H12AffineFastState.compose env18363 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18363 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env18364 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,3109,268,3125,1077,1330,2064,3345,1024,1076,2341,33,1060,2,268,17,3125,3108,2065,2340,304,1044,256,1045,3124,0]

theorem envBound18364 : H12AffineFastState.Bounded env18364 := by
  intro p hp
  have h : env18364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18363_18364 : H12AffineEnvironment.transform 8 1 env18363 = env18364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18363 == env18364) = true)

theorem identity18364 : scanCanonicalize (H12AffineFastState.compose env18364 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18364 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18365 : List Nat := [2,4,8,16,32,17,8,256,1,52,2048,2065,268,2049,1,262,2064,2341,52,0,2341,33,16,2,268,17,2049,2064,2065,2340,304,32,256,33,2048,0]

theorem envBound18365 : H12AffineFastState.Bounded env18365 := by
  intro p hp
  have h : env18365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18364_18365 : H12AffineEnvironment.transform 9 52 env18364 = env18365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18364 == env18365) = true)

theorem identity18365 : scanCanonicalize (H12AffineFastState.compose env18365 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound18365 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18366 : List Nat := [2,4,8,16,32,17,8,62,1,52,2048,2065,50,2049,1,56,2064,2075,52,0,2075,33,16,2,50,17,2049,2064,2065,2074,14,32,62,33,2048,0]

theorem envBound18366 : H12AffineFastState.Bounded env18366 := by
  intro p hp
  have h : env18366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18365_18366 : H12AffineEnvironment.transform 7 62 env18365 = env18366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env18365 == env18366) = true)

def env18367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,138,8328,64,4450483,2196486,2233816,190521,246802,6382922,256,2327727,2319626,189380]

theorem envBound18367 : H12AffineFastState.Bounded env18367 := by
  intro p hp
  have h : env18367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18316_18367 : H12AffineEnvironment.transform 17 157873 env18316 = env18367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env18316 == env18367) = true)

theorem identity18367 : scanCanonicalize (H12AffineFastState.compose env18367 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18367 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157873,1024,8541,2097152,4194304,147593,138,8328,64,4409839,2172250,2233816,149861,222542,6382922,256,2303475,2319626,148120]

theorem envBound18368 : H12AffineFastState.Bounded env18368 := by
  intro p hp
  have h : env18368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18367_18368 : H12AffineEnvironment.transform 14 8540 env18367 = env18368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18367 == env18368) = true)

theorem identity18368 : scanCanonicalize (H12AffineFastState.compose env18368 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound18368 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env18369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16537,10280,1024,8541,2097152,4194304,16,138,8328,64,4262262,2172250,2118977,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound18369 : H12AffineFastState.Bounded env18369 := by
  intro p hp
  have h : env18369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18368_18369 : H12AffineEnvironment.transform 16 16537 env18368 = env18369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env18368 == env18369) = true)

def env18370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16537,10280,1024,8541,17864,4194304,16,138,8328,64,4262262,90258,4233,2556,75223,4268162,256,73890,90203,513]

theorem envBound18370 : H12AffineFastState.Bounded env18370 := by
  intro p hp
  have h : env18370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18369_18370 : H12AffineEnvironment.transform 20 17864 env18369 = env18370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env18369 == env18370) = true)

theorem identity18370 : scanCanonicalize (H12AffineFastState.compose env18370 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18370 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16537,10280,1024,8541,17864,4194304,16,138,8328,64,4204924,16536,4233,2556,1501,4194440,256,168,16465,513]

theorem envBound18371 : H12AffineFastState.Bounded env18371 := by
  intro p hp
  have h : env18371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18370_18371 : H12AffineEnvironment.transform 15 8202 env18370 = env18371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18370 == env18371) = true)

theorem identity18371 : scanCanonicalize (H12AffineFastState.compose env18371 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound18371 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env18372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16537,10280,1024,8541,17864,248,16,138,8328,64,10628,16536,4233,2556,1501,112,256,168,16465,513]

theorem envBound18372 : H12AffineFastState.Bounded env18372 := by
  intro p hp
  have h : env18372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18371_18372 : H12AffineEnvironment.transform 21 248 env18371 = env18372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env18371 == env18372) = true)

theorem identity18372 : scanCanonicalize (H12AffineFastState.compose env18372 (packedSelected [2,4,6,9,14,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18372 : packedSelected [2,4,6,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env18373 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,8202,16537,10280,1024,8461,17816,168,16,138,8328,16,10628,16536,4233,2476,1421,32,256,168,16385,513]

theorem envBound18373 : H12AffineFastState.Bounded env18373 := by
  intro p hp
  have h : env18373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18372_18373 : H12AffineEnvironment.transform 5 16 env18372 = env18373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18372 == env18373) = true)

theorem identity18373 : scanCanonicalize (H12AffineFastState.compose env18373 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18373 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18374 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,1,263,16537,2341,1024,0,17816,168,16,138,389,16,2185,16536,4233,2476,1421,32,256,168,16385,513]

theorem envBound18374 : H12AffineFastState.Bounded env18374 := by
  intro p hp
  have h : env18374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18373_18374 : H12AffineEnvironment.transform 12 269 env18373 = env18374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18373 == env18374) = true)

theorem identity18374 : scanCanonicalize (H12AffineFastState.compose env18374 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound18374 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env18375 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5292,1,263,5173,2341,1024,0,4404,168,16,138,389,16,2185,5172,4233,2476,1421,32,256,168,5293,513]

theorem envBound18375 : H12AffineFastState.Bounded env18375 := by
  intro p hp
  have h : env18375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18374_18375 : H12AffineEnvironment.transform 13 5292 env18374 = env18375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env18374 == env18375) = true)

theorem identity18375 : scanCanonicalize (H12AffineFastState.compose env18375 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18375 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18376 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5156,1,263,5173,2341,1024,0,4404,32,16,2,269,16,2049,5172,4097,2340,1285,32,256,32,5157,513]

theorem envBound18376 : H12AffineFastState.Bounded env18376 := by
  intro p hp
  have h : env18376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18375_18376 : H12AffineEnvironment.transform 6 8 env18375 = env18376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18375 == env18376) = true)

theorem identity18376 : scanCanonicalize (H12AffineFastState.compose env18376 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18377 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,34,5173,2048,1024,0,4113,32,16,2,40,16,2049,5172,4097,2049,1056,32,37,32,5157,513]

theorem envBound18377 : H12AffineFastState.Bounded env18377 := by
  intro p hp
  have h : env18377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18376_18377 : H12AffineEnvironment.transform 7 37 env18376 = env18377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18376 == env18377) = true)

theorem identity18377 : scanCanonicalize (H12AffineFastState.compose env18377 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound18377 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18378 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,40,2049,1,34,2064,2048,1024,0,3124,32,16,2,40,16,2049,2065,3108,2049,1056,32,37,32,2048,513]

theorem envBound18378 : H12AffineFastState.Bounded env18378 := by
  intro p hp
  have h : env18378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18377_18378 : H12AffineEnvironment.transform 11 3109 env18377 = env18378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env18377 == env18378) = true)

theorem identity18378 : scanCanonicalize (H12AffineFastState.compose env18378 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18378 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18379 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,1,34,2064,2048,53,0,2049,32,16,2,40,16,2049,2065,2065,2049,21,32,37,32,2048,513]

theorem envBound18379 : H12AffineFastState.Bounded env18379 := by
  intro p hp
  have h : env18379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18378_18379 : H12AffineEnvironment.transform 9 53 env18378 = env18379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18378 == env18379) = true)

theorem identity18379 : scanCanonicalize (H12AffineFastState.compose env18379 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound18379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18380 : List Nat := [2,4,8,16,32,16,8,37,512,53,560,544,40,561,1,34,544,560,53,0,561,32,16,2,40,16,561,545,545,561,21,32,37,32,560,513]

theorem envBound18380 : H12AffineFastState.Bounded env18380 := by
  intro p hp
  have h : env18380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18379_18380 : H12AffineEnvironment.transform 10 560 env18379 = env18380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env18379 == env18380) = true)

theorem identity18380 : scanCanonicalize (H12AffineFastState.compose env18380 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18381 : List Nat := [2,4,8,16,32,16,8,37,0,53,48,32,40,49,1,34,32,48,53,0,49,32,16,2,40,16,49,33,33,49,21,32,37,32,48,1]

theorem envBound18381 : H12AffineFastState.Bounded env18381 := by
  intro p hp
  have h : env18381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18380_18381 : H12AffineEnvironment.transform 8 0 env18380 = env18381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18380 == env18381) = true)

def env18382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16537,10280,1024,8541,17865,4194304,16,138,8328,64,4262262,90259,4232,2556,75223,4268163,256,73891,90202,513]

theorem envBound18382 : H12AffineFastState.Bounded env18382 := by
  intro p hp
  have h : env18382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18369_18382 : H12AffineEnvironment.transform 20 17865 env18369 = env18382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env18369 == env18382) = true)

theorem identity18382 : scanCanonicalize (H12AffineFastState.compose env18382 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18382 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env18383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,16537,10280,1024,8541,17865,4194304,16,138,8328,64,4205044,16401,4232,2556,1365,4194305,256,33,16600,513]

theorem envBound18383 : H12AffineFastState.Bounded env18383 := by
  intro p hp
  have h : env18383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18382_18383 : H12AffineEnvironment.transform 15 8322 env18382 = env18383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18382 == env18383) = true)

theorem identity18383 : scanCanonicalize (H12AffineFastState.compose env18383 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18383 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,17728,4194304,16,3,8193,64,4204925,16401,4097,2421,1365,4194305,256,33,16465,513]

theorem envBound18384 : H12AffineFastState.Bounded env18384 := by
  intro p hp
  have h : env18384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18383_18384 : H12AffineEnvironment.transform 6 9 env18383 = env18384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18383 == env18384) = true)

theorem identity18384 : scanCanonicalize (H12AffineFastState.compose env18384 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound18384 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,17728,33,16,3,8193,64,10588,16401,4097,2421,1365,32,256,33,16465,513]

theorem envBound18385 : H12AffineFastState.Bounded env18385 := by
  intro p hp
  have h : env18385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18384_18385 : H12AffineEnvironment.transform 21 33 env18384 = env18385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18384 == env18385) = true)

theorem identity18385 : scanCanonicalize (H12AffineFastState.compose env18385 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound18385 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,32,375,16400,2388,1024,33,17728,33,16,3,381,64,2080,16401,4097,2421,1365,32,256,33,16465,513]

theorem envBound18386 : H12AffineFastState.Bounded env18386 := by
  intro p hp
  have h : env18386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18385_18386 : H12AffineEnvironment.transform 12 380 env18385 = env18386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env18385 == env18386) = true)

theorem identity18386 : scanCanonicalize (H12AffineFastState.compose env18386 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18386 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18387 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,32,294,16400,2309,1024,33,17681,33,16,3,300,17,2080,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound18387 : H12AffineFastState.Bounded env18387 := by
  intro p hp
  have h : env18387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18386_18387 : H12AffineEnvironment.transform 5 17 env18386 = env18387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18386 == env18387) = true)

theorem identity18387 : scanCanonicalize (H12AffineFastState.compose env18387 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5173) := by decide +kernel

theorem selectedBound18387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18388 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5173,32,294,5157,2309,1024,33,4388,33,16,3,300,17,2080,5156,4097,2340,1284,32,256,33,5173,513]

theorem envBound18388 : H12AffineFastState.Bounded env18388 := by
  intro p hp
  have h : env18388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18387_18388 : H12AffineEnvironment.transform 13 5173 env18387 = env18388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5173 env18387 == env18388) = true)

theorem identity18388 : scanCanonicalize (H12AffineFastState.compose env18388 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound18388 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18389 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1556,4096,301,5173,32,294,5157,1809,1024,33,4388,33,16,3,300,17,1588,5156,4097,1840,1284,32,256,33,5173,513]

theorem envBound18389 : H12AffineFastState.Bounded env18389 := by
  intro p hp
  have h : env18389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18388_18389 : H12AffineEnvironment.transform 10 1556 env18388 = env18389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env18388 == env18389) = true)

def env18390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound18390 : H12AffineFastState.Bounded env18390 := by
  intro p hp
  have h : env18390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18249_18390 : H12AffineEnvironment.transform 18 1025 env18249 = env18390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18249 == env18390) = true)

theorem identity18390 : scanCanonicalize (H12AffineFastState.compose env18390 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 253962) := by decide +kernel

theorem selectedBound18390 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,253962,16777216,8328,64,21241866,18973837,2340187,335882,16933915,23160256,257,19014823,19055875,16991180]

theorem envBound18391 : H12AffineFastState.Bounded env18391 := by
  intro p hp
  have h : env18391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18390_18391 : H12AffineEnvironment.transform 22 253962 env18390 = env18391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 253962 env18390 == env18391) = true)

def env18392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,16777216,8328,64,16959642,18973837,2340187,335882,16933915,19369296,257,19014823,19055875,16991180]

theorem envBound18392 : H12AffineFastState.Bounded env18392 := by
  intro p hp
  have h : env18392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18391_18392 : H12AffineEnvironment.transform 21 452752 env18391 = env18392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env18391 == env18392) = true)

def env18393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,242968,8328,64,97666,2240917,2340187,335882,119043,2373704,257,2199999,2191387,63188]

theorem envBound18393 : H12AffineFastState.Bounded env18393 := by
  intro p hp
  have h : env18393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18392_18393 : H12AffineEnvironment.transform 23 242968 env18392 = env18393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env18392 == env18393) = true)

def env18394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253962,242968,8328,64,97666,139733,238875,335882,119043,272392,257,98815,90203,63188]

theorem envBound18394 : H12AffineFastState.Bounded env18394 := by
  intro p hp
  have h : env18394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18393_18394 : H12AffineEnvironment.transform 20 4160 env18393 = env18394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18393 == env18394) = true)

theorem identity18394 : scanCanonicalize (H12AffineFastState.compose env18394 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18394 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,400453,201951,213453,8328,64,97666,139733,217550,335882,75222,272392,257,95530,90203,513]

theorem envBound18395 : H12AffineFastState.Bounded env18395 := by
  intro p hp
  have h : env18395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18394_18395 : H12AffineEnvironment.transform 14 29909 env18394 = env18395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18394 == env18395) = true)

def env18396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,400453,201815,213317,8192,64,97546,139613,217414,335882,75102,272392,257,95530,90203,513]

theorem envBound18396 : H12AffineFastState.Bounded env18396 := by
  intro p hp
  have h : env18396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18395_18396 : H12AffineEnvironment.transform 6 8 env18395 = env18396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18395 == env18396) = true)

theorem identity18396 : scanCanonicalize (H12AffineFastState.compose env18396 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound18396 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1025,29788,4160,156012,201815,213317,8192,64,97546,139613,217414,89379,75102,21793,257,95530,90203,513]

theorem envBound18397 : H12AffineFastState.Bounded env18397 := by
  intro p hp
  have h : env18397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18396_18397 : H12AffineEnvironment.transform 17 32041 env18396 = env18397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env18396 == env18397) = true)

theorem identity18397 : scanCanonicalize (H12AffineFastState.compose env18397 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18397 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env18398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,131072,23669,1025,21760,4160,147504,201815,213317,348,64,89174,131073,217414,89379,66562,21793,257,87158,82183,513]

theorem envBound18398 : H12AffineFastState.Bounded env18398 := by
  intro p hp
  have h : env18398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18397_18398 : H12AffineEnvironment.transform 12 348 env18397 = env18398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18397 == env18398) = true)

theorem identity18398 : scanCanonicalize (H12AffineFastState.compose env18398 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18398 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,343,131072,23669,1025,21760,4160,147504,136448,147474,348,64,23809,131073,151569,23668,1365,21793,257,21793,16464,513]

theorem envBound18399 : H12AffineFastState.Bounded env18399 := by
  intro p hp
  have h : env18399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18398_18399 : H12AffineEnvironment.transform 15 343 env18398 = env18399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18398 == env18399) = true)

theorem identity18399 : scanCanonicalize (H12AffineFastState.compose env18399 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18399 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18400 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,263,131072,23589,1025,21760,4112,147504,136448,147474,268,16,23809,131073,151569,23588,1285,21793,257,21793,16384,513]

theorem envBound18400 : H12AffineFastState.Bounded env18400 := by
  intro p hp
  have h : env18400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18399_18400 : H12AffineEnvironment.transform 5 16 env18399 = env18400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18399 == env18400) = true)

theorem identity18400 : scanCanonicalize (H12AffineFastState.compose env18400 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound18400 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env18401 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,263,16400,23589,1025,21760,4112,32,21776,2,268,16,23809,16401,4097,23588,1285,21793,257,21793,16384,513]

theorem envBound18401 : H12AffineFastState.Bounded env18401 := by
  intro p hp
  have h : env18401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18400_18401 : H12AffineEnvironment.transform 16 16400 env18400 = env18401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env18400 == env18401) = true)

theorem identity18401 : scanCanonicalize (H12AffineFastState.compose env18401 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound18401 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env18402 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,268,16384,18724,263,16400,16384,1025,18725,3125,32,18741,2,268,16,16676,16401,3108,16385,1285,18692,257,18692,16384,513]

theorem envBound18402 : H12AffineFastState.Bounded env18402 := by
  intro p hp
  have h : env18402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0