import H12CloudChart0Data123

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env31462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1025,32769,276584,272393,272441,98645,8192,65,398437,277817,4096,179512,273788,41340,257,33,46093,330274]

theorem envBound31462 : H12AffineFastState.Bounded env31462 := by
  intro p hp
  have h : env31462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31446_31462 : H12AffineEnvironment.transform 13 5377 env31446 = env31462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31446 == env31462) = true)

theorem identity31462 : scanCanonicalize (H12AffineFastState.compose env31462 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound31462 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1025,32769,77899,73770,73754,98645,8192,65,203846,79130,4096,179512,75103,41340,257,33,46093,513]

theorem envBound31463 : H12AffineFastState.Bounded env31463 := by
  intro p hp
  have h : env31463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31462_31463 : H12AffineEnvironment.transform 17 67619 env31462 = env31463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env31462 == env31463) = true)

theorem identity31463 : scanCanonicalize (H12AffineFastState.compose env31463 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31463 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31464 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,67619,1025,8540,77899,73770,73754,73736,8192,65,203846,79130,4096,138341,75103,33,257,33,5456,513]

theorem envBound31464 : H12AffineFastState.Bounded env31464 := by
  intro p hp
  have h : env31464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31463_31464 : H12AffineEnvironment.transform 14 8541 env31463 = env31464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31463 == env31464) = true)

theorem identity31464 : scanCanonicalize (H12AffineFastState.compose env31464 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31464 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,131072,67619,1025,0,69911,65910,65862,65876,348,65,203846,70726,4096,138341,66563,33,257,33,5456,513]

theorem envBound31465 : H12AffineFastState.Bounded env31465 := by
  intro p hp
  have h : env31465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31464_31465 : H12AffineEnvironment.transform 12 348 env31464 = env31465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31464 == env31465) = true)

theorem identity31465 : scanCanonicalize (H12AffineFastState.compose env31465 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound31465 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env31466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,5440,67619,1025,0,69911,65910,65862,65876,348,65,67846,70726,4096,2341,66563,33,257,33,5456,513]

theorem envBound31466 : H12AffineFastState.Bounded env31466 := by
  intro p hp
  have h : env31466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31465_31466 : H12AffineEnvironment.transform 16 5440 env31465 = env31466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env31465 == env31466) = true)

theorem identity31466 : scanCanonicalize (H12AffineFastState.compose env31466 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31466 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5440,2421,1025,0,4161,32,16,2,348,65,2128,5392,4096,2341,1365,33,257,33,5456,513]

theorem envBound31467 : H12AffineFastState.Bounded env31467 := by
  intro p hp
  have h : env31467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31466_31467 : H12AffineEnvironment.transform 15 342 env31466 = env31467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31466 == env31467) = true)

theorem identity31467 : scanCanonicalize (H12AffineFastState.compose env31467 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31467 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31468 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1025,0,4113,32,16,2,268,17,2048,5392,4096,2341,1285,33,257,33,5376,513]

theorem envBound31468 : H12AffineFastState.Bounded env31468 := by
  intro p hp
  have h : env31468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31467_31468 : H12AffineEnvironment.transform 5 16 env31467 = env31468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31467 == env31468) = true)

theorem identity31468 : scanCanonicalize (H12AffineFastState.compose env31468 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31468 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31469 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,17,268,1296,1,262,1281,2341,1025,0,0,32,16,2,268,17,2048,1281,17,2341,1285,33,257,33,1297,513]

theorem envBound31469 : H12AffineFastState.Bounded env31469 := by
  intro p hp
  have h : env31469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31468_31469 : H12AffineEnvironment.transform 11 17 env31468 = env31469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31468 == env31469) = true)

theorem identity31469 : scanCanonicalize (H12AffineFastState.compose env31469 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31469 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31470 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,17,268,292,1,262,309,2341,53,0,0,32,16,2,268,17,2048,309,17,2341,305,33,257,33,293,513]

theorem envBound31470 : H12AffineFastState.Bounded env31470 := by
  intro p hp
  have h : env31470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31469_31470 : H12AffineEnvironment.transform 9 52 env31469 = env31470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31469 == env31470) = true)

theorem identity31470 : scanCanonicalize (H12AffineFastState.compose env31470 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31470 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31471 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,17,41,1,1,35,16,2048,53,0,0,32,16,2,41,17,2048,16,17,2048,20,33,36,33,0,513]

theorem envBound31471 : H12AffineFastState.Bounded env31471 := by
  intro p hp
  have h : env31471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31470_31471 : H12AffineEnvironment.transform 7 37 env31470 = env31471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31470 == env31471) = true)

theorem identity31471 : scanCanonicalize (H12AffineFastState.compose env31471 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31472 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,17,41,1,1,35,16,49,53,0,0,32,16,2,41,17,49,16,17,49,20,33,36,33,0,513]

theorem envBound31472 : H12AffineFastState.Bounded env31472 := by
  intro p hp
  have h : env31472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31471_31472 : H12AffineEnvironment.transform 10 49 env31471 = env31472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31471 == env31472) = true)

theorem identity31472 : scanCanonicalize (H12AffineFastState.compose env31472 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31473 : List Nat := [2,4,8,16,16,16,8,21,512,4,1,17,25,1,1,19,16,1,5,0,0,16,16,2,25,17,1,16,17,1,20,17,20,17,0,513]

theorem envBound31473 : H12AffineFastState.Bounded env31473 := by
  intro p hp
  have h : env31473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31472_31473 : H12AffineEnvironment.transform 4 16 env31472 = env31473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31472 == env31473) = true)

def env31474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272392,294200,98644,8193,65,398437,288824,17665,179512,292988,41341,257,21792,46092,352035]

theorem envBound31474 : H12AffineFastState.Bounded env31474 := by
  intro p hp
  have h : env31474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31445_31474 : H12AffineEnvironment.transform 6 9 env31445 = env31474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31445 == env31474) = true)

theorem identity31474 : scanCanonicalize (H12AffineFastState.compose env31474 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound31474 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,204083,1025,32769,225370,210235,221195,98644,8193,65,67926,226571,17665,179512,222543,41341,257,21792,46092,147984]

theorem envBound31475 : H12AffineFastState.Bounded env31475 := by
  intro p hp
  have h : env31475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31474_31475 : H12AffineEnvironment.transform 17 204083 env31474 = env31475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env31474 == env31475) = true)

theorem identity31475 : scanCanonicalize (H12AffineFastState.compose env31475 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound31475 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103495,35188,1025,32769,58397,41340,62540,98644,8193,65,67926,57676,17665,76159,61704,41341,257,21792,46092,120407]

theorem envBound31476 : H12AffineFastState.Bounded env31476 := by
  intro p hp
  have h : env31476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31475_31476 : H12AffineEnvironment.transform 16 103495 env31475 = env31476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env31475 == env31476) = true)

theorem identity31476 : scanCanonicalize (H12AffineFastState.compose env31476 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound31476 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,32040,1025,29789,4161,21792,16,95496,8193,65,67926,5392,17665,76159,1364,21793,257,21792,16464,74251]

theorem envBound31477 : H12AffineFastState.Bounded env31477 := by
  intro p hp
  have h : env31477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31476_31477 : H12AffineEnvironment.transform 14 29788 env31476 = env31477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env31476 == env31477) = true)

theorem identity31477 : scanCanonicalize (H12AffineFastState.compose env31477 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16401,32040,1025,29789,4161,21792,16,21762,8193,65,10588,5392,17665,2421,1364,21793,257,21792,16464,513]

theorem envBound31478 : H12AffineFastState.Bounded env31478 := by
  intro p hp
  have h : env31478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31477_31478 : H12AffineEnvironment.transform 15 8202 env31477 = env31478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31477 == env31478) = true)

theorem identity31478 : scanCanonicalize (H12AffineFastState.compose env31478 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound31478 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,1345,8202,12556,3125,1025,1344,4161,9277,16,9247,8193,65,10588,5392,13340,2421,1364,9276,257,9277,12621,513]

theorem envBound31479 : H12AffineFastState.Bounded env31479 := by
  intro p hp
  have h : env31479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31478_31479 : H12AffineEnvironment.transform 13 12573 env31478 = env31479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env31478 == env31479) = true)

theorem identity31479 : scanCanonicalize (H12AffineFastState.compose env31479 (packedSelected [0,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound31479 : packedSelected [0,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env31480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2316,6161,1345,2310,6144,3125,1025,1344,4161,3377,16,3347,2317,65,80,5392,7440,2421,1364,3376,257,3377,6209,513]

theorem envBound31480 : H12AffineFastState.Bounded env31480 := by
  intro p hp
  have h : env31480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31479_31480 : H12AffineEnvironment.transform 12 2316 env31479 = env31480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env31479 == env31480) = true)

theorem identity31480 : scanCanonicalize (H12AffineFastState.compose env31480 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound31480 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,2316,3345,1345,2310,3328,3125,1025,1344,1345,3377,16,3347,2317,65,80,16,2064,2421,1364,3376,257,3377,3393,513]

theorem envBound31481 : H12AffineFastState.Bounded env31481 := by
  intro p hp
  have h : env31481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31480_31481 : H12AffineEnvironment.transform 11 1280 env31480 = env31481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env31480 == env31481) = true)

theorem identity31481 : scanCanonicalize (H12AffineFastState.compose env31481 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound31481 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,1280,40,1077,1345,34,1060,1297,1025,1344,1345,1045,16,1079,41,65,80,16,308,81,1364,1044,257,1045,1125,513]

theorem envBound31482 : H12AffineFastState.Bounded env31482 := by
  intro p hp
  have h : env31482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31481_31482 : H12AffineEnvironment.transform 10 292 env31481 = env31482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env31481 == env31482) = true)

theorem identity31482 : scanCanonicalize (H12AffineFastState.compose env31482 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31482 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env31483 : List Nat := [2,4,8,16,32,64,9,256,512,272,292,16,40,293,81,34,308,1,273,80,81,261,16,295,41,65,80,16,308,81,68,260,257,261,373,513]

theorem envBound31483 : H12AffineFastState.Bounded env31483 := by
  intro p hp
  have h : env31483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31482_31483 : H12AffineEnvironment.transform 9 272 env31482 = env31483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31482 == env31483) = true)

theorem identity31483 : scanCanonicalize (H12AffineFastState.compose env31483 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31483 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31484 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,16,40,80,81,34,65,1,100,80,81,112,16,82,41,65,80,16,65,81,68,113,116,112,0,513]

theorem envBound31484 : H12AffineFastState.Bounded env31484 := by
  intro p hp
  have h : env31484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31483_31484 : H12AffineEnvironment.transform 7 117 env31483 = env31484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31483 == env31484) = true)

theorem identity31484 : scanCanonicalize (H12AffineFastState.compose env31484 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31484 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31485 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,16,40,0,1,34,17,1,52,0,1,32,16,2,41,17,0,16,17,1,20,33,36,32,0,513]

theorem envBound31485 : H12AffineFastState.Bounded env31485 := by
  intro p hp
  have h : env31485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31484_31485 : H12AffineEnvironment.transform 5 16 env31484 = env31485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31484 == env31485) = true)

theorem identity31485 : scanCanonicalize (H12AffineFastState.compose env31485 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31486 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,8,0,1,2,17,1,20,0,1,0,16,2,9,17,0,16,17,1,20,1,4,0,0,513]

theorem envBound31486 : H12AffineFastState.Bounded env31486 := by
  intro p hp
  have h : env31486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31485_31486 : H12AffineEnvironment.transform 4 0 env31485 = env31486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31485 == env31486) = true)

theorem identity31486 : scanCanonicalize (H12AffineFastState.compose env31486 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound31486 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31487 : List Nat := [2,4,8,16,0,16,9,5,16,21,1,16,8,0,1,2,17,1,20,0,1,0,16,2,9,17,0,16,17,1,20,1,4,0,0,17]

theorem envBound31487 : H12AffineFastState.Bounded env31487 := by
  intro p hp
  have h : env31487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31486_31487 : H12AffineEnvironment.transform 8 16 env31486 = env31487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env31486 == env31487) = true)

def env31488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294201,2485428,8328,65,6705548,288824,2369641,179513,2102685,4491637,257,21793,46212,2175563]

theorem envBound31488 : H12AffineFastState.Bounded env31488 := by
  intro p hp
  have h : env31488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31377_31488 : H12AffineEnvironment.transform 22 294201 env31377 = env31488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294201 env31377 == env31488) = true)

def env31489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294201,98780,8328,65,4340964,288824,17665,179513,293109,4491637,257,21793,46212,352035]

theorem envBound31489 : H12AffineFastState.Bounded env31489 := by
  intro p hp
  have h : env31489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31488_31489 : H12AffineEnvironment.transform 20 290152 env31488 = env31489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env31488 == env31489) = true)

def env31490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294201,98780,8328,65,398436,288824,17665,179513,293109,41461,257,21793,46212,352035]

theorem envBound31490 : H12AffineFastState.Bounded env31490 := by
  intro p hp
  have h : env31490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31489_31490 : H12AffineEnvironment.transform 21 272512 env31489 = env31490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31489 == env31490) = true)

theorem identity31490 : scanCanonicalize (H12AffineFastState.compose env31490 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound31490 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,290152,272512,294201,21763,8328,65,398436,288824,17665,179513,293109,41461,257,21793,46212,297980]

theorem envBound31491 : H12AffineFastState.Bounded env31491 := by
  intro p hp
  have h : env31491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31490_31491 : H12AffineEnvironment.transform 15 54495 env31490 = env31491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env31490 == env31491) = true)

def env31492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146864,1025,32769,151768,136496,147593,21763,8328,65,10708,152968,17665,179513,148805,41461,257,21793,46212,177740]

theorem envBound31492 : H12AffineFastState.Bounded env31492 := by
  intro p hp
  have h : env31492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31491_31492 : H12AffineEnvironment.transform 17 146864 env31491 = env31492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env31491 == env31492) = true)

theorem identity31492 : scanCanonicalize (H12AffineFastState.compose env31492 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound31492 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46157,35325,1025,32769,58517,41341,62660,21763,8328,65,10708,57797,17665,2420,61704,41461,257,21793,46212,513]

theorem envBound31493 : H12AffineFastState.Bounded env31493 := by
  intro p hp
  have h : env31493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31492_31493 : H12AffineEnvironment.transform 16 46157 env31492 = env31493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env31492 == env31493) = true)

theorem identity31493 : scanCanonicalize (H12AffineFastState.compose env31493 (packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound31493 : packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env31494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33110,46157,35325,1025,32769,45340,41341,41293,138,8328,65,10708,46156,4232,2420,42113,41461,257,168,46212,513]

theorem envBound31494 : H12AffineFastState.Bounded env31494 := by
  intro p hp
  have h : env31494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31493_31494 : H12AffineEnvironment.transform 13 5513 env31493 = env31494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env31493 == env31494) = true)

theorem identity31494 : scanCanonicalize (H12AffineFastState.compose env31494 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound31494 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8323,5528,10280,1025,8660,4297,168,152,138,8328,65,10708,5529,4232,2420,1364,32,257,168,5457,513]

theorem envBound31495 : H12AffineFastState.Bounded env31495 := by
  intro p hp
  have h : env31495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31494_31495 : H12AffineEnvironment.transform 14 8661 env31494 = env31495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env31494 == env31495) = true)

theorem identity31495 : scanCanonicalize (H12AffineFastState.compose env31495 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31495 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10280,1025,8541,4160,33,17,3,8193,65,10589,5392,4097,2420,1364,32,257,33,5457,513]

theorem envBound31496 : H12AffineFastState.Bounded env31496 := by
  intro p hp
  have h : env31496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31495_31496 : H12AffineEnvironment.transform 6 9 env31495 = env31496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31495 == env31496) = true)

theorem identity31496 : scanCanonicalize (H12AffineFastState.compose env31496 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound31496 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,5376,341,3,5393,2081,1025,340,4160,33,17,3,8,65,2388,5392,4097,2420,1364,32,257,33,5457,513]

theorem envBound31497 : H12AffineFastState.Bounded env31497 := by
  intro p hp
  have h : env31497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31496_31497 : H12AffineEnvironment.transform 12 9 env31496 = env31497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env31496 == env31497) = true)

theorem identity31497 : scanCanonicalize (H12AffineFastState.compose env31497 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31497 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31498 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,9,4113,341,3,4096,2081,272,340,4160,33,17,3,8,65,2388,4097,4097,2420,69,32,257,33,4160,513]

theorem envBound31498 : H12AffineFastState.Bounded env31498 := by
  intro p hp
  have h : env31498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31497_31498 : H12AffineEnvironment.transform 9 273 env31497 = env31498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31497 == env31498) = true)

theorem identity31498 : scanCanonicalize (H12AffineFastState.compose env31498 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound31498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31499 : List Nat := [2,4,8,16,32,64,9,53,512,36,2048,4096,9,4113,96,3,4096,2081,37,97,4160,33,17,3,8,65,2145,4097,4097,2113,69,32,52,33,4160,513]

theorem envBound31499 : H12AffineFastState.Bounded env31499 := by
  intro p hp
  have h : env31499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31498_31499 : H12AffineEnvironment.transform 7 53 env31498 = env31499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env31498 == env31499) = true)

def env31500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146865,1025,32769,151769,136497,147592,21763,8328,65,10709,152969,17665,179513,148804,41461,257,21793,46212,177741]

theorem envBound31500 : H12AffineFastState.Bounded env31500 := by
  intro p hp
  have h : env31500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31491_31500 : H12AffineEnvironment.transform 17 146865 env31491 = env31500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env31491 == env31500) = true)

theorem identity31500 : scanCanonicalize (H12AffineFastState.compose env31500 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound31500 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46276,35189,1025,32769,58397,41461,62540,21763,8328,65,10709,57677,17665,2557,61824,41461,257,21793,46212,649]

theorem envBound31501 : H12AffineFastState.Bounded env31501 := by
  intro p hp
  have h : env31501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31500_31501 : H12AffineEnvironment.transform 16 46276 env31500 = env31501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env31500 == env31501) = true)

theorem identity31501 : scanCanonicalize (H12AffineFastState.compose env31501 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31501 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46156,35189,1025,32769,58397,41341,62540,21763,8192,65,10589,57677,17665,2421,61704,41341,257,21793,46092,513]

theorem envBound31502 : H12AffineFastState.Bounded env31502 := by
  intro p hp
  have h : env31502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31501_31502 : H12AffineEnvironment.transform 6 8 env31501 = env31502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31501 == env31502) = true)

theorem identity31502 : scanCanonicalize (H12AffineFastState.compose env31502 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31502 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env31503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33030,46156,35189,1025,32769,45388,41341,41245,82,8192,65,10589,46108,4176,2421,42073,41341,257,112,46092,513]

theorem envBound31503 : H12AffineFastState.Bounded env31503 := by
  intro p hp
  have h : env31503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31502_31503 : H12AffineEnvironment.transform 13 5457 env31502 = env31503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31502 == env31503) = true)

theorem identity31503 : scanCanonicalize (H12AffineFastState.compose env31503 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31503 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env31504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,8282,5392,10281,1025,8541,4112,33,65,82,8192,65,10589,5440,4176,2421,1285,33,257,112,5456,513]

theorem envBound31504 : H12AffineFastState.Bounded env31504 := by
  intro p hp
  have h : env31504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31503_31504 : H12AffineEnvironment.transform 14 8540 env31503 = env31504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31503 == env31504) = true)

theorem identity31504 : scanCanonicalize (H12AffineFastState.compose env31504 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31504 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31505 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8202,5392,10281,1025,8461,4112,33,17,2,8192,17,10509,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound31505 : H12AffineFastState.Bounded env31505 := by
  intro p hp
  have h : env31505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31504_31505 : H12AffineEnvironment.transform 5 16 env31504 = env31505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31504 == env31505) = true)

theorem identity31505 : scanCanonicalize (H12AffineFastState.compose env31505 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound31505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31506 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1288,5377,1028,1282,5392,3361,1025,1029,4112,33,17,2,1288,17,3077,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound31506 : H12AffineFastState.Bounded env31506 := by
  intro p hp
  have h : env31506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31505_31506 : H12AffineEnvironment.transform 12 1288 env31505 = env31506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env31505 == env31506) = true)

def env31507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294201,98780,8328,65,398437,288824,17665,179513,293109,41460,257,21793,46212,352035]

theorem envBound31507 : H12AffineFastState.Bounded env31507 := by
  intro p hp
  have h : env31507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31489_31507 : H12AffineEnvironment.transform 21 272513 env31489 = env31507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31489 == env31507) = true)

theorem identity31507 : scanCanonicalize (H12AffineFastState.compose env31507 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109047) := by decide +kernel

theorem selectedBound31507 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109047,1025,32769,115871,98678,120014,98780,8328,65,245138,115151,17665,179513,119042,41460,257,21793,46212,63188]

theorem envBound31508 : H12AffineFastState.Bounded env31508 := by
  intro p hp
  have h : env31508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31507_31508 : H12AffineEnvironment.transform 17 109047 env31507 = env31508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109047 env31507 == env31508) = true)

def env31509 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108967,1025,32769,115871,98598,119966,98700,8328,17,245138,115103,17665,179513,119042,41380,257,21793,46212,63108]

theorem envBound31509 : H12AffineFastState.Bounded env31509 := by
  intro p hp
  have h : env31509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31508_31509 : H12AffineEnvironment.transform 5 16 env31508 = env31509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31508 == env31509) = true)

theorem identity31509 : scanCanonicalize (H12AffineFastState.compose env31509 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound31509 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env31510 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46109,108967,1025,32769,115871,98598,119966,98700,8328,17,67983,115103,17665,2340,119042,41380,257,21793,46212,63108]

theorem envBound31510 : H12AffineFastState.Bounded env31510 := by
  intro p hp
  have h : env31510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31509_31510 : H12AffineEnvironment.transform 16 46109 env31509 = env31510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env31509 == env31510) = true)

theorem identity31510 : scanCanonicalize (H12AffineFastState.compose env31510 (packedSelected [1,4,5,7,8,9,14,16,17,19,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound31510 : packedSelected [1,4,5,7,8,9,14,16,17,19,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env31511 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,30083,46109,56356,1025,32769,45340,62629,41245,62479,8328,17,31756,46108,17665,2340,42113,41380,257,21793,46212,63108]

theorem envBound31511 : H12AffineFastState.Bounded env31511 := by
  intro p hp
  have h : env31511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31510_31511 : H12AffineEnvironment.transform 15 30083 env31510 = env31511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env31510 == env31511) = true)

theorem identity31511 : scanCanonicalize (H12AffineFastState.compose env31511 (packedSelected [0,1,4,7,8,9,10,12,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound31511 : packedSelected [0,1,4,7,8,9,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31512 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,30083,16400,10281,1025,29708,17681,168,21776,2,8328,17,31756,16401,17665,2340,20620,21929,257,21793,16521,649]

theorem envBound31512 : H12AffineFastState.Bounded env31512 := by
  intro p hp
  have h : env31512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31511_31512 : H12AffineEnvironment.transform 14 29709 env31511 = env31512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env31511 == env31512) = true)

theorem identity31512 : scanCanonicalize (H12AffineFastState.compose env31512 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31512 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31513 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21761,21647,16400,2341,1025,21760,17681,168,21776,2,388,17,23808,16401,17665,2340,20620,21929,257,21793,16521,649]

theorem envBound31513 : H12AffineFastState.Bounded env31513 := by
  intro p hp
  have h : env31513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31512_31513 : H12AffineEnvironment.transform 12 268 env31512 = env31513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31512 == env31513) = true)

theorem identity31513 : scanCanonicalize (H12AffineFastState.compose env31513 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31513 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31514 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,0,398,5393,2341,1025,1,4112,168,17,2,388,17,2049,5392,4096,2340,1421,168,257,32,5512,649]

theorem envBound31514 : H12AffineFastState.Bounded env31514 := by
  intro p hp
  have h : env31514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31513_31514 : H12AffineEnvironment.transform 13 5377 env31513 = env31514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31513 == env31514) = true)

theorem identity31514 : scanCanonicalize (H12AffineFastState.compose env31514 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3719) := by decide +kernel

theorem selectedBound31514 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31515 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3719,268,2950,0,398,2966,2341,1025,1,3735,168,17,2,388,17,2049,2967,3719,2340,1421,168,257,32,2831,649]

theorem envBound31515 : H12AffineFastState.Bounded env31515 := by
  intro p hp
  have h : env31515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31514_31515 : H12AffineEnvironment.transform 11 3719 env31514 = env31515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3719 env31514 == env31515) = true)

theorem identity31515 : scanCanonicalize (H12AffineFastState.compose env31515 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31515 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31516 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3599,268,2830,0,262,2846,2341,1025,1,3615,32,17,2,268,17,2049,2847,3599,2340,1285,32,257,32,2831,513]

theorem envBound31516 : H12AffineFastState.Bounded env31516 := by
  intro p hp
  have h : env31516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31515_31516 : H12AffineEnvironment.transform 6 8 env31515 = env31516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31515 == env31516) = true)

theorem identity31516 : scanCanonicalize (H12AffineFastState.compose env31516 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound31516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31517 : List Nat := [2,4,8,16,32,16,8,256,512,1024,783,1280,268,1,0,262,17,554,1025,1,1296,32,17,2,268,17,782,16,1280,555,1285,32,257,32,0,513]

theorem envBound31517 : H12AffineFastState.Bounded env31517 := by
  intro p hp
  have h : env31517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31516_31517 : H12AffineEnvironment.transform 10 783 env31516 = env31517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env31516 == env31517) = true)

theorem identity31517 : scanCanonicalize (H12AffineFastState.compose env31517 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31517 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31518 : List Nat := [2,4,8,16,32,16,8,4,512,1024,523,1028,8,1,0,2,17,554,1025,1,1044,32,17,2,8,17,522,16,1028,555,1025,32,5,32,0,513]

theorem envBound31518 : H12AffineFastState.Bounded env31518 := by
  intro p hp
  have h : env31518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31517_31518 : H12AffineEnvironment.transform 7 4 env31517 = env31518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31517 == env31518) = true)

theorem identity31518 : scanCanonicalize (H12AffineFastState.compose env31518 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound31518 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31519 : List Nat := [2,4,8,16,32,16,8,4,42,1024,33,1028,8,1,0,2,17,0,1025,1,1044,32,17,2,8,17,32,16,1028,1,1025,32,5,32,0,43]

theorem envBound31519 : H12AffineFastState.Bounded env31519 := by
  intro p hp
  have h : env31519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31518_31519 : H12AffineEnvironment.transform 8 42 env31518 = env31519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env31518 == env31519) = true)

theorem identity31519 : scanCanonicalize (H12AffineFastState.compose env31519 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound31519 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31520 : List Nat := [2,4,8,16,32,16,8,4,42,20,33,16,8,1,0,2,17,0,21,1,0,32,17,2,8,17,32,16,16,1,21,32,5,32,0,43]

theorem envBound31520 : H12AffineFastState.Bounded env31520 := by
  intro p hp
  have h : env31520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31519_31520 : H12AffineEnvironment.transform 9 20 env31519 = env31520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31519 == env31520) = true)

def env31521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108966,1025,32769,115871,98599,119967,98701,8328,16,245138,115102,17665,179513,119042,41381,257,21793,46212,63109]

theorem envBound31521 : H12AffineFastState.Bounded env31521 := by
  intro p hp
  have h : env31521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31508_31521 : H12AffineEnvironment.transform 5 17 env31508 = env31521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31508 == env31521) = true)

theorem identity31521 : scanCanonicalize (H12AffineFastState.compose env31521 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound31521 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env31522 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,103446,108966,1025,32769,115871,98599,119967,98701,8328,16,10628,115102,17665,76079,119042,41381,257,21793,46212,63109]

theorem envBound31522 : H12AffineFastState.Bounded env31522 := by
  intro p hp
  have h : env31522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31521_31522 : H12AffineEnvironment.transform 16 103446 env31521 = env31522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env31521 == env31522) = true)

theorem identity31522 : scanCanonicalize (H12AffineFastState.compose env31522 (packedSelected [5,8,10,15,24,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound31522 : packedSelected [5,8,10,15,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env31523 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21761,65536,82199,97447,1025,21760,70046,87078,65950,87180,8328,16,10628,70815,17665,76079,66563,29860,257,21793,24965,9092]

theorem envBound31523 : H12AffineFastState.Bounded env31523 := by
  intro p hp
  have h : env31523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31522_31523 : H12AffineEnvironment.transform 14 21761 env31522 = env31523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env31522 == env31523) = true)

theorem identity31523 : scanCanonicalize (H12AffineFastState.compose env31523 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound31523 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31524 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,65536,82199,89378,1025,21760,70046,87078,65950,87180,269,16,2049,70815,17665,67754,66563,21793,257,21793,16384,513]

theorem envBound31524 : H12AffineFastState.Bounded env31524 := by
  intro p hp
  have h : env31524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31523_31524 : H12AffineEnvironment.transform 12 389 env31523 = env31524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env31523 == env31524) = true)

theorem identity31524 : scanCanonicalize (H12AffineFastState.compose env31524 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound31524 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,21510,5393,2340,1025,21760,17816,32,21912,138,269,16,2049,16537,17665,23724,20485,21793,257,21793,16384,513]

theorem envBound31525 : H12AffineFastState.Bounded env31525 := by
  intro p hp
  have h : env31525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31524_31525 : H12AffineEnvironment.transform 15 21510 env31524 = env31525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env31524 == env31525) = true)

theorem identity31525 : scanCanonicalize (H12AffineFastState.compose env31525 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31525 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env31526 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,21510,5393,2340,1025,21760,17680,32,21776,2,269,16,2049,16401,17665,23588,20485,21793,257,21793,16384,513]

theorem envBound31526 : H12AffineFastState.Bounded env31526 := by
  intro p hp
  have h : env31526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31525_31526 : H12AffineEnvironment.transform 6 8 env31525 = env31526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31525 == env31526) = true)

theorem identity31526 : scanCanonicalize (H12AffineFastState.compose env31526 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31526 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31527 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1025,1,4113,32,17,2,269,16,2049,5392,4096,2341,1284,32,257,32,5377,513]

theorem envBound31527 : H12AffineFastState.Bounded env31527 := by
  intro p hp
  have h : env31527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31526_31527 : H12AffineEnvironment.transform 13 5377 env31526 = env31527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31526 == env31527) = true)

theorem identity31527 : scanCanonicalize (H12AffineFastState.compose env31527 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31528 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,17,269,1296,0,263,1280,2340,1025,1,0,32,17,2,269,16,2049,1281,17,2341,1284,32,257,32,1296,513]

theorem envBound31528 : H12AffineFastState.Bounded env31528 := by
  intro p hp
  have h : env31528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31527_31528 : H12AffineEnvironment.transform 11 17 env31527 = env31528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31527 == env31528) = true)

theorem identity31528 : scanCanonicalize (H12AffineFastState.compose env31528 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound31528 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31529 : List Nat := [2,4,8,16,32,17,8,256,512,1024,522,17,269,1296,0,263,1280,814,1025,1,0,32,17,2,269,16,523,1281,17,815,1284,32,257,32,1296,513]

theorem envBound31529 : H12AffineFastState.Bounded env31529 := by
  intro p hp
  have h : env31529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31528_31529 : H12AffineEnvironment.transform 10 522 env31528 = env31529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env31528 == env31529) = true)

theorem identity31529 : scanCanonicalize (H12AffineFastState.compose env31529 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound31529 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31530 : List Nat := [2,4,8,16,32,17,8,256,512,826,522,17,269,554,0,263,570,814,827,1,0,32,17,2,269,16,523,571,17,815,574,32,257,32,554,513]

theorem envBound31530 : H12AffineFastState.Bounded env31530 := by
  intro p hp
  have h : env31530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31529_31530 : H12AffineEnvironment.transform 9 826 env31529 = env31530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env31529 == env31530) = true)

theorem identity31530 : scanCanonicalize (H12AffineFastState.compose env31530 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31530 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31531 : List Nat := [2,4,8,16,0,17,8,256,512,794,522,17,269,522,0,263,538,782,795,1,0,0,17,2,269,16,523,539,17,783,542,0,257,0,522,513]

theorem envBound31531 : H12AffineFastState.Bounded env31531 := by
  intro p hp
  have h : env31531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31530_31531 : H12AffineEnvironment.transform 4 0 env31530 = env31531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31530 == env31531) = true)

theorem identity31531 : scanCanonicalize (H12AffineFastState.compose env31531 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound31531 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31532 : List Nat := [2,4,8,16,0,17,8,256,11,273,1,17,269,1,0,263,17,261,272,1,0,0,17,2,269,16,0,16,17,260,21,0,257,0,1,10]

theorem envBound31532 : H12AffineFastState.Bounded env31532 := by
  intro p hp
  have h : env31532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31531_31532 : H12AffineEnvironment.transform 8 11 env31531 = env31532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env31531 == env31532) = true)

def env31533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294201,98781,8328,65,4340965,288824,17664,179513,293108,4491637,257,21793,46212,352034]

theorem envBound31533 : H12AffineFastState.Bounded env31533 := by
  intro p hp
  have h : env31533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31488_31533 : H12AffineEnvironment.transform 20 290153 env31488 = env31533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env31488 == env31533) = true)

def env31534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294201,98781,8328,65,398437,288824,17664,179513,293108,41461,257,21793,46212,352034]

theorem envBound31534 : H12AffineFastState.Bounded env31534 := by
  intro p hp
  have h : env31534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31533_31534 : H12AffineEnvironment.transform 21 272512 env31533 = env31534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31533 == env31534) = true)

theorem identity31534 : scanCanonicalize (H12AffineFastState.compose env31534 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31534 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272512,294201,41430,8328,65,398437,288824,17664,179513,293108,41461,257,21793,46212,294697]

theorem envBound31535 : H12AffineFastState.Bounded env31535 := by
  intro p hp
  have h : env31535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31534_31535 : H12AffineEnvironment.transform 15 8203 env31534 = env31535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31534 == env31535) = true)

def env31536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272392,294201,41310,8192,65,398437,288824,17664,179513,292988,41341,257,21793,46092,294697]

theorem envBound31536 : H12AffineFastState.Bounded env31536 := by
  intro p hp
  have h : env31536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31535_31536 : H12AffineEnvironment.transform 6 8 env31535 = env31536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31535 == env31536) = true)

theorem identity31536 : scanCanonicalize (H12AffineFastState.compose env31536 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound31536 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,131072,262144,1025,29709,290153,272392,294201,21842,8192,65,398437,288824,17664,149813,292988,21873,257,21793,16384,294697]

theorem envBound31537 : H12AffineFastState.Bounded env31537 := by
  intro p hp
  have h : env31537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31536_31537 : H12AffineEnvironment.transform 14 29708 env31536 = env31537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env31536 == env31537) = true)

theorem identity31537 : scanCanonicalize (H12AffineFastState.compose env31537 (packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound31537 : packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env31538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,5393,262144,1025,29709,290153,272392,294201,21842,8192,65,262516,288824,17664,23588,292988,21873,257,21793,16384,294697]

theorem envBound31538 : H12AffineFastState.Bounded env31538 := by
  intro p hp
  have h : env31538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31537_31538 : H12AffineEnvironment.transform 16 5393 env31537 = env31538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env31537 == env31538) = true)

theorem identity31538 : scanCanonicalize (H12AffineFastState.compose env31538 (packedSelected [0,3,5,7,9,10,12,14,15,16,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound31538 : packedSelected [0,3,5,7,9,10,12,14,15,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env31539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,5393,32040,1025,29709,4161,21792,17,21842,8192,65,31836,5392,17664,23588,1364,21873,257,21793,16384,513]

theorem envBound31539 : H12AffineFastState.Bounded env31539 := by
  intro p hp
  have h : env31539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31538_31539 : H12AffineEnvironment.transform 17 32040 env31538 = env31539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env31538 == env31539) = true)

theorem identity31539 : scanCanonicalize (H12AffineFastState.compose env31539 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31539 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,81,8203,5393,2421,1025,80,4161,8573,17,8463,8192,65,2049,5392,12637,10361,1364,8492,257,8572,13405,513]

theorem envBound31540 : H12AffineFastState.Bounded env31540 := by
  intro p hp
  have h : env31540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31539_31540 : H12AffineEnvironment.transform 13 13405 env31539 = env31540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31539 == env31540) = true)

theorem identity31540 : scanCanonicalize (H12AffineFastState.compose env31540 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31540 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31541 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,8203,5393,2341,1025,0,4113,8493,17,8463,8192,17,2049,5392,12557,10281,1284,8492,257,8492,13325,513]

theorem envBound31541 : H12AffineFastState.Bounded env31541 := by
  intro p hp
  have h : env31541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31540_31541 : H12AffineEnvironment.transform 5 16 env31540 = env31541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31540 == env31541) = true)

def env31542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272393,294201,41311,8193,65,398437,288824,17664,179513,292989,41340,257,21793,46093,294697]

theorem envBound31542 : H12AffineFastState.Bounded env31542 := by
  intro p hp
  have h : env31542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31535_31542 : H12AffineEnvironment.transform 6 9 env31535 = env31542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31535 == env31542) = true)

theorem identity31542 : scanCanonicalize (H12AffineFastState.compose env31542 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound31542 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8203,131072,262144,1025,32769,276537,272393,272489,41311,8193,65,398437,277864,4176,179513,273709,41340,257,113,46093,273017]

theorem envBound31543 : H12AffineFastState.Bounded env31543 := by
  intro p hp
  have h : env31543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31542_31543 : H12AffineEnvironment.transform 13 5456 env31542 = env31543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env31542 == env31543) = true)

theorem identity31543 : scanCanonicalize (H12AffineFastState.compose env31543 (packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound31543 : packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8203,46108,262144,1025,32769,276537,272393,272489,41311,8193,65,303225,277864,4176,2341,273709,41340,257,113,46093,273017]

theorem envBound31544 : H12AffineFastState.Bounded env31544 := by
  intro p hp
  have h : env31544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31543_31544 : H12AffineEnvironment.transform 16 46108 env31543 = env31544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env31543 == env31544) = true)

theorem identity31544 : scanCanonicalize (H12AffineFastState.compose env31544 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31544 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env31545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8203,5440,262144,1025,8541,276537,272393,272489,3,8193,65,262437,277864,4176,2341,273709,32,257,113,5457,273017]

theorem envBound31545 : H12AffineFastState.Bounded env31545 := by
  intro p hp
  have h : env31545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31544_31545 : H12AffineEnvironment.transform 14 8540 env31544 = env31545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31544 == env31545) = true)

theorem identity31545 : scanCanonicalize (H12AffineFastState.compose env31545 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31545 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env31546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,293,114,5440,262144,1025,292,268352,264304,264208,3,120,65,262437,269585,4176,2341,265556,32,257,113,5457,264704]

theorem envBound31546 : H12AffineFastState.Bounded env31546 := by
  intro p hp
  have h : env31546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31545_31546 : H12AffineEnvironment.transform 12 121 env31545 = env31546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31545 == env31546) = true)

theorem identity31546 : scanCanonicalize (H12AffineFastState.compose env31546 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31546 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env31547 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5156,81,114,5172,262144,1025,80,268352,264304,264208,3,120,65,262225,269413,4176,2129,265248,32,117,113,5157,264704]

theorem envBound31547 : H12AffineFastState.Bounded env31547 := by
  intro p hp
  have h : env31547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31546_31547 : H12AffineEnvironment.transform 7 116 env31546 = env31547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31546 == env31547) = true)

theorem identity31547 : scanCanonicalize (H12AffineFastState.compose env31547 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound31547 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31548 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5156,81,114,5172,2049,1025,80,4161,113,17,3,120,65,2128,5220,4176,2129,1057,32,117,113,5157,513]

theorem envBound31548 : H12AffineFastState.Bounded env31548 := by
  intro p hp
  have h : env31548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31547_31548 : H12AffineEnvironment.transform 17 2049 env31547 = env31548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env31547 == env31548) = true)

def env31549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294201,98781,8328,65,398436,288824,17664,179513,293108,41460,257,21793,46212,352034]

theorem envBound31549 : H12AffineFastState.Bounded env31549 := by
  intro p hp
  have h : env31549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31533_31549 : H12AffineEnvironment.transform 21 272513 env31533 = env31549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31533 == env31549) = true)

theorem identity31549 : scanCanonicalize (H12AffineFastState.compose env31549 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound31549 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95650,73754,98781,8328,65,215367,79131,17664,179513,75223,41460,257,21793,46212,513]

theorem envBound31550 : H12AffineFastState.Bounded env31550 := by
  intro p hp
  have h : env31550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31549_31550 : H12AffineEnvironment.transform 17 89379 env31549 = env31550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env31549 == env31550) = true)

def env31551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73754,98645,8192,65,215367,79131,17664,179513,75103,41340,257,21793,46092,513]

theorem envBound31551 : H12AffineFastState.Bounded env31551 := by
  intro p hp
  have h : env31551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31550_31551 : H12AffineEnvironment.transform 6 8 env31550 = env31551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31550 == env31551) = true)

theorem identity31551 : scanCanonicalize (H12AffineFastState.compose env31551 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31551 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89379,1025,29788,77898,95530,73754,95496,8192,65,215367,79131,17664,149860,75103,21793,257,21793,16465,513]

theorem envBound31552 : H12AffineFastState.Bounded env31552 := by
  intro p hp
  have h : env31552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31551_31552 : H12AffineEnvironment.transform 14 29789 env31551 = env31552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31551 == env31552) = true)

theorem identity31552 : scanCanonicalize (H12AffineFastState.compose env31552 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound31552 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env31553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90187,89379,1025,29788,77898,95530,73754,95496,8192,65,10508,79131,17664,76079,75103,21793,257,21793,16465,513]

theorem envBound31553 : H12AffineFastState.Bounded env31553 := by
  intro p hp
  have h : env31553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31552_31553 : H12AffineEnvironment.transform 16 90187 env31552 = env31553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env31552 == env31553) = true)

theorem identity31553 : scanCanonicalize (H12AffineFastState.compose env31553 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound31553 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env31554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8283,16400,32120,1025,29788,4113,21873,65,21843,8192,65,10508,5440,17664,2420,1284,21793,257,21793,16465,513]

theorem envBound31554 : H12AffineFastState.Bounded env31554 := by
  intro p hp
  have h : env31554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31553_31554 : H12AffineEnvironment.transform 15 8283 env31553 = env31554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env31553 == env31554) = true)

theorem identity31554 : scanCanonicalize (H12AffineFastState.compose env31554 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31554 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31555 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,16400,32040,1025,29708,4113,21793,17,21763,8192,17,10508,5392,17664,2340,1284,21793,257,21793,16385,513]

theorem envBound31555 : H12AffineFastState.Bounded env31555 := by
  intro p hp
  have h : env31555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31554_31555 : H12AffineEnvironment.transform 5 16 env31554 = env31555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31554 == env31555) = true)

theorem identity31555 : scanCanonicalize (H12AffineFastState.compose env31555 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound31555 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env31556 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,16384,21793,295,16400,23556,1025,21792,4113,21793,17,21763,300,17,2080,5392,17664,2340,1284,21793,257,21793,16385,513]

theorem envBound31556 : H12AffineFastState.Bounded env31556 := by
  intro p hp
  have h : env31556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31555_31556 : H12AffineEnvironment.transform 12 300 env31555 = env31556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env31555 == env31556) = true)

theorem identity31556 : scanCanonicalize (H12AffineFastState.compose env31556 (packedSelected [0,2,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound31556 : packedSelected [0,2,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31557 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,5157,260,295,5173,2081,1025,261,4113,260,17,294,300,17,2080,5392,4389,2340,1284,260,257,260,5156,513]

theorem envBound31557 : H12AffineFastState.Bounded env31557 := by
  intro p hp
  have h : env31557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31556_31557 : H12AffineEnvironment.transform 13 5157 env31556 = env31557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env31556 == env31557) = true)

theorem identity31557 : scanCanonicalize (H12AffineFastState.compose env31557 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31557 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31558 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,9,5157,33,2,5173,2081,1025,32,4113,33,17,3,9,17,2080,5173,4096,2049,1057,33,36,33,5156,513]

theorem envBound31558 : H12AffineFastState.Bounded env31558 := by
  intro p hp
  have h : env31558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31557_31558 : H12AffineEnvironment.transform 7 37 env31557 = env31558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31557 == env31558) = true)

theorem identity31558 : scanCanonicalize (H12AffineFastState.compose env31558 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound31558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31559 : List Nat := [2,4,8,16,32,16,8,37,512,20,2048,4096,9,4145,33,2,4129,2081,21,32,4113,33,17,3,9,17,2080,4129,4096,2049,53,33,36,33,4144,513]

theorem envBound31559 : H12AffineFastState.Bounded env31559 := by
  intro p hp
  have h : env31559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31558_31559 : H12AffineEnvironment.transform 9 20 env31558 = env31559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31558 == env31559) = true)

theorem identity31559 : scanCanonicalize (H12AffineFastState.compose env31559 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31560 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,9,4112,0,2,4096,2048,21,1,4113,0,17,3,9,17,2049,4096,4096,2049,20,0,5,0,4113,513]

theorem envBound31560 : H12AffineFastState.Bounded env31560 := by
  intro p hp
  have h : env31560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31559_31560 : H12AffineEnvironment.transform 4 1 env31559 = env31560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31559 == env31560) = true)

theorem identity31560 : scanCanonicalize (H12AffineFastState.compose env31560 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound31560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31561 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,512,9,528,0,2,512,2048,21,1,529,0,17,3,9,17,2049,512,512,2049,20,0,5,0,529,513]

theorem envBound31561 : H12AffineFastState.Bounded env31561 := by
  intro p hp
  have h : env31561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31560_31561 : H12AffineEnvironment.transform 11 512 env31560 = env31561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env31560 == env31561) = true)

theorem identity31561 : scanCanonicalize (H12AffineFastState.compose env31561 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31562 : List Nat := [2,4,8,16,1,16,8,4,512,20,1,512,9,528,0,2,512,1,21,1,529,0,17,3,9,17,0,512,512,0,20,0,5,0,529,513]

theorem envBound31562 : H12AffineFastState.Bounded env31562 := by
  intro p hp
  have h : env31562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31561_31562 : H12AffineEnvironment.transform 10 1 env31561 = env31562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31561 == env31562) = true)

theorem identity31562 : scanCanonicalize (H12AffineFastState.compose env31562 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31562 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31563 : List Nat := [2,4,8,0,1,0,8,4,512,4,1,512,9,512,0,2,512,1,5,1,513,0,1,3,9,1,0,512,512,0,4,0,5,0,513,513]

theorem envBound31563 : H12AffineFastState.Bounded env31563 := by
  intro p hp
  have h : env31563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31562_31563 : H12AffineEnvironment.transform 3 0 env31562 = env31563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31562 == env31563) = true)

def env31564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95531,73754,98644,8193,65,215367,79131,17664,179513,75102,41341,257,21793,46093,513]

theorem envBound31564 : H12AffineFastState.Bounded env31564 := by
  intro p hp
  have h : env31564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31550_31564 : H12AffineEnvironment.transform 6 9 env31550 = env31564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31550 == env31564) = true)

theorem identity31564 : scanCanonicalize (H12AffineFastState.compose env31564 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31564 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31565 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,88115,273,32769,77898,94267,73754,98644,8193,65,215367,77835,16400,178217,73806,41341,257,20529,45341,513]

theorem envBound31565 : H12AffineFastState.Bounded env31565 := by
  intro p hp
  have h : env31565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31564_31565 : H12AffineEnvironment.transform 9 272 env31564 = env31565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31564 == env31565) = true)

theorem identity31565 : scanCanonicalize (H12AffineFastState.compose env31565 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound31565 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env31566 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,90139,88115,273,32769,77898,94267,73754,98644,8193,65,10588,77835,16400,120882,73806,41341,257,20529,45341,513]

theorem envBound31566 : H12AffineFastState.Bounded env31566 := by
  intro p hp
  have h : env31566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31565_31566 : H12AffineEnvironment.transform 16 90139 env31565 = env31566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env31565 == env31566) = true)

theorem identity31566 : scanCanonicalize (H12AffineFastState.compose env31566 (packedSelected [3,5,10,11,17,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound31566 : packedSelected [3,5,10,11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env31567 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,29005,65536,90139,88115,273,29004,77898,94267,73754,94233,8193,65,10588,77835,16400,76159,73806,20528,257,20529,16464,513]

theorem envBound31567 : H12AffineFastState.Bounded env31567 := by
  intro p hp
  have h : env31567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31566_31567 : H12AffineEnvironment.transform 14 29005 env31566 = env31567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env31566 == env31567) = true)

theorem identity31567 : scanCanonicalize (H12AffineFastState.compose env31567 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound31567 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31568 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8540,65536,77834,67618,273,8541,77898,73770,73754,73736,8193,65,10588,77835,4097,76159,73806,33,257,32,4161,513]

theorem envBound31568 : H12AffineFastState.Bounded env31568 := by
  intro p hp
  have h : env31568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31567_31568 : H12AffineEnvironment.transform 13 4113 env31567 = env31568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31567 == env31568) = true)

theorem identity31568 : scanCanonicalize (H12AffineFastState.compose env31568 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2397) := by decide +kernel

theorem selectedBound31568 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env31569 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,2397,4113,2049,65536,72023,67618,273,2048,71959,67959,67911,67925,2396,65,1,72022,4097,65570,67859,33,257,32,4161,513]

theorem envBound31569 : H12AffineFastState.Bounded env31569 := by
  intro p hp
  have h : env31569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31568_31569 : H12AffineEnvironment.transform 12 2397 env31568 = env31569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2397 env31568 == env31569) = true)

theorem identity31569 : scanCanonicalize (H12AffineFastState.compose env31569 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 2390) := by decide +kernel

theorem selectedBound31569 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31570 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,2397,4113,2049,2390,4097,372,273,2048,4161,33,17,3,2396,65,1,4096,4097,2420,69,33,257,32,4161,513]

theorem envBound31570 : H12AffineFastState.Bounded env31570 := by
  intro p hp
  have h : env31570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31569_31570 : H12AffineEnvironment.transform 15 2390 env31569 = env31570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2390 env31569 == env31570) = true)

theorem identity31570 : scanCanonicalize (H12AffineFastState.compose env31570 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound31570 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31571 : List Nat := [2,4,8,16,32,64,9,256,512,272,260,4096,89,4113,261,82,4097,372,273,260,4161,33,17,3,88,65,1,4096,4097,112,69,33,257,32,4161,513]

theorem envBound31571 : H12AffineFastState.Bounded env31571 := by
  intro p hp
  have h : env31571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31570_31571 : H12AffineEnvironment.transform 10 260 env31570 = env31571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env31570 == env31571) = true)

theorem identity31571 : scanCanonicalize (H12AffineFastState.compose env31571 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31571 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31572 : List Nat := [2,4,8,16,32,16,9,256,512,272,260,4096,9,4113,261,2,4097,292,273,260,4113,33,17,3,8,17,1,4096,4097,32,21,33,257,32,4113,513]

theorem envBound31572 : H12AffineFastState.Bounded env31572 := by
  intro p hp
  have h : env31572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31571_31572 : H12AffineEnvironment.transform 5 16 env31571 = env31572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31571 == env31572) = true)

theorem identity31572 : scanCanonicalize (H12AffineFastState.compose env31572 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound31572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31573 : List Nat := [2,4,8,16,32,16,9,256,512,272,260,309,9,292,261,2,308,292,273,260,292,33,17,3,8,17,1,309,308,32,21,33,257,32,292,513]

theorem envBound31573 : H12AffineFastState.Bounded env31573 := by
  intro p hp
  have h : env31573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31572_31573 : H12AffineEnvironment.transform 11 309 env31572 = env31573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env31572 == env31573) = true)

theorem identity31573 : scanCanonicalize (H12AffineFastState.compose env31573 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31573 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31574 : List Nat := [2,4,8,16,32,16,9,256,0,272,260,309,9,292,261,2,308,292,273,260,292,33,17,3,8,17,1,309,308,32,21,33,257,32,292,1]

theorem envBound31574 : H12AffineFastState.Bounded env31574 := by
  intro p hp
  have h : env31574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31573_31574 : H12AffineEnvironment.transform 8 0 env31573 = env31574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31573 == env31574) = true)

theorem identity31574 : scanCanonicalize (H12AffineFastState.compose env31574 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31575 : List Nat := [2,4,8,16,0,16,9,256,0,272,260,277,9,260,261,2,276,260,273,260,260,1,17,3,8,17,1,277,276,0,21,1,257,0,260,1]

theorem envBound31575 : H12AffineFastState.Bounded env31575 := by
  intro p hp
  have h : env31575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31574_31575 : H12AffineEnvironment.transform 4 0 env31574 = env31575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31574 == env31575) = true)

theorem identity31575 : scanCanonicalize (H12AffineFastState.compose env31575 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound31575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31576 : List Nat := [2,4,8,16,0,16,9,20,0,4,16,1,9,16,17,2,0,16,5,16,16,1,17,3,8,17,1,1,0,0,21,1,21,0,16,1]

theorem envBound31576 : H12AffineFastState.Bounded env31576 := by
  intro p hp
  have h : env31576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31575_31576 : H12AffineEnvironment.transform 7 20 env31575 = env31576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env31575 == env31576) = true)

theorem identity31576 : scanCanonicalize (H12AffineFastState.compose env31576 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31577 : List Nat := [2,4,8,11,0,11,9,15,0,4,11,1,9,11,10,2,0,11,5,11,11,1,10,3,8,10,1,1,0,0,14,1,14,0,11,1]

theorem envBound31577 : H12AffineFastState.Bounded env31577 := by
  intro p hp
  have h : env31577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31576_31577 : H12AffineEnvironment.transform 3 11 env31576 = env31577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31576 == env31577) = true)

theorem identity31577 : scanCanonicalize (H12AffineFastState.compose env31577 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31577 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env31578 : List Nat := [2,4,3,0,0,0,2,4,0,4,0,1,2,0,1,2,0,0,5,0,0,1,1,3,3,1,1,1,0,0,5,1,5,0,0,1]

theorem envBound31578 : H12AffineFastState.Bounded env31578 := by
  intro p hp
  have h : env31578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31577_31578 : H12AffineEnvironment.transform 2 3 env31577 = env31578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31577 == env31578) = true)

def env31579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound31579 : H12AffineFastState.Bounded env31579 := by
  intro p hp
  have h : env31579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31152_31579 : H12AffineEnvironment.transform 26 30393345 env31152 = env31579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env31152 == env31579) = true)

def env31580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound31580 : H12AffineFastState.Bounded env31580 := by
  intro p hp
  have h : env31580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31579_31580 : H12AffineEnvironment.transform 18 1024 env31579 = env31580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31579 == env31580) = true)

theorem identity31580 : scanCanonicalize (H12AffineFastState.compose env31580 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874484) := by decide +kernel

theorem selectedBound31580 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874484,8328,65,4237813,10939769,10507600,8830976,454116,15076404,256,2534744,2510077,510515]

theorem envBound31581 : H12AffineFastState.Bounded env31581 := by
  intro p hp
  have h : env31581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31580_31581 : H12AffineEnvironment.transform 23 8874484 env31580 = env31581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874484 env31580 == env31581) = true)

def env31582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,8388608,8874484,8328,65,4237813,8393985,8826152,8830976,454116,12645452,256,21792,46213,510515]

theorem envBound31582 : H12AffineFastState.Bounded env31582 := by
  intro p hp
  have h : env31582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31581_31582 : H12AffineEnvironment.transform 20 456824 env31581 = env31582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env31581 == env31582) = true)

def env31583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,98780,8328,65,4237813,458025,17664,10280,454116,4594788,256,21792,46213,510515]

theorem envBound31583 : H12AffineFastState.Bounded env31583 := by
  intro p hp
  have h : env31583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31582_31583 : H12AffineEnvironment.transform 22 452648 env31582 = env31583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env31582 == env31583) = true)

def env31584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,98780,8328,65,295285,458025,17664,10280,454116,144612,256,21792,46213,510515]

theorem envBound31584 : H12AffineFastState.Bounded env31584 := by
  intro p hp
  have h : env31584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31583_31584 : H12AffineEnvironment.transform 21 272512 env31583 = env31584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31583 == env31584) = true)

theorem identity31584 : scanCanonicalize (H12AffineFastState.compose env31584 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound31584 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77898,254130,73754,98780,8328,65,215367,79131,17664,10280,75222,144612,256,21792,46213,513]

theorem envBound31585 : H12AffineFastState.Bounded env31585 := by
  intro p hp
  have h : env31585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31584_31585 : H12AffineEnvironment.transform 17 247858 env31584 = env31585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env31584 == env31585) = true)

theorem identity31585 : scanCanonicalize (H12AffineFastState.compose env31585 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31585 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,180408,16,41430,8328,65,158029,5393,17664,10280,1500,144612,256,21792,46213,513]

theorem envBound31586 : H12AffineFastState.Bounded env31586 := by
  intro p hp
  have h : env31586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31585_31586 : H12AffineEnvironment.transform 15 8202 env31585 = env31586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31585 == env31586) = true)

theorem identity31586 : scanCanonicalize (H12AffineFastState.compose env31586 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31586 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32937,16,41430,8328,65,10588,5393,17664,10280,1500,29941,256,21792,46213,513]

theorem envBound31587 : H12AffineFastState.Bounded env31587 := by
  intro p hp
  have h : env31587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31586_31587 : H12AffineEnvironment.transform 16 16401 env31586 = env31587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31586 == env31587) = true)

theorem identity31587 : scanCanonicalize (H12AffineFastState.compose env31587 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31587 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env31588 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4113,32937,16,41351,8328,16,10509,5393,17664,10280,1421,29860,256,21792,46213,513]

theorem envBound31588 : H12AffineFastState.Bounded env31588 := by
  intro p hp
  have h : env31588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31587_31588 : H12AffineEnvironment.transform 5 17 env31587 = env31588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31587 == env31588) = true)

theorem identity31588 : scanCanonicalize (H12AffineFastState.compose env31588 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31588 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env31589 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4113,32801,16,41231,8192,16,10509,5393,17664,10280,1285,29740,256,21792,46093,513]

theorem envBound31589 : H12AffineFastState.Bounded env31589 := by
  intro p hp
  have h : env31589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31588_31589 : H12AffineEnvironment.transform 6 8 env31588 = env31589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31588 == env31589) = true)

theorem identity31589 : scanCanonicalize (H12AffineFastState.compose env31589 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31589 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31590 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,8202,16401,10281,1024,1,4113,33,16,8463,8192,16,10509,5393,17664,10280,1285,29740,256,21792,13325,513]

theorem envBound31590 : H12AffineFastState.Bounded env31590 := by
  intro p hp
  have h : env31590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31589_31590 : H12AffineEnvironment.transform 14 0 env31589 = env31590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31589 == env31590) = true)

theorem identity31590 : scanCanonicalize (H12AffineFastState.compose env31590 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31590 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env31591 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,0,8202,5393,10281,1024,1,4113,33,16,8463,8192,16,10509,5393,4096,10280,1285,8492,256,32,13325,513]

theorem envBound31591 : H12AffineFastState.Bounded env31591 := by
  intro p hp
  have h : env31591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31590_31591 : H12AffineEnvironment.transform 13 5376 env31590 = env31591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31590 == env31591) = true)

theorem identity31591 : scanCanonicalize (H12AffineFastState.compose env31591 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 3644) := by decide +kernel

theorem selectedBound31591 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31592 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3644,5376,0,3638,5393,1557,1024,1,4113,33,16,3891,3644,16,1841,5393,4096,1556,1285,3856,256,32,6705,513]

theorem envBound31592 : H12AffineFastState.Bounded env31592 := by
  intro p hp
  have h : env31592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31591_31592 : H12AffineEnvironment.transform 12 3644 env31591 = env31592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3644 env31591 == env31592) = true)

theorem identity31592 : scanCanonicalize (H12AffineFastState.compose env31592 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1841) := by decide +kernel

theorem selectedBound31592 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31593 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1841,4096,269,5376,0,263,5393,1557,1024,1,4113,33,16,2,269,16,1841,5393,4096,1556,1285,33,256,32,5376,513]

theorem envBound31593 : H12AffineFastState.Bounded env31593 := by
  intro p hp
  have h : env31593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31592_31593 : H12AffineEnvironment.transform 10 1841 env31592 = env31593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1841 env31592 == env31593) = true)

theorem identity31593 : scanCanonicalize (H12AffineFastState.compose env31593 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound31593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31594 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1841,1029,269,261,0,263,276,1557,1024,1,1044,33,16,2,269,16,1841,276,1029,1556,1285,33,256,32,261,513]

theorem envBound31594 : H12AffineFastState.Bounded env31594 := by
  intro p hp
  have h : env31594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31593_31594 : H12AffineEnvironment.transform 11 1029 env31593 = env31594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env31593 == env31594) = true)

theorem identity31594 : scanCanonicalize (H12AffineFastState.compose env31594 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound31594 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31595 : List Nat := [2,4,8,16,32,17,8,256,512,305,512,308,269,261,0,263,276,804,305,1,293,33,16,2,269,16,512,276,308,805,52,33,256,32,261,513]

theorem envBound31595 : H12AffineFastState.Bounded env31595 := by
  intro p hp
  have h : env31595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31594_31595 : H12AffineEnvironment.transform 9 305 env31594 = env31595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env31594 == env31595) = true)

def env31596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,98780,8328,65,295284,458025,17664,10280,454116,144613,256,21792,46213,510515]

theorem envBound31596 : H12AffineFastState.Bounded env31596 := by
  intro p hp
  have h : env31596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31583_31596 : H12AffineEnvironment.transform 21 272513 env31583 = env31596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31583 == env31596) = true)

theorem identity31596 : scanCanonicalize (H12AffineFastState.compose env31596 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31596 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272513,452648,41430,8328,65,295284,458025,17664,10280,454116,144613,256,21792,46213,453177]

theorem envBound31597 : H12AffineFastState.Bounded env31597 := by
  intro p hp
  have h : env31597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31596_31597 : H12AffineEnvironment.transform 15 8202 env31596 = env31597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31596 == env31597) = true)

def env31598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,98781,8328,65,4237813,458024,17665,10281,454116,4594789,256,21792,46213,510515]

theorem envBound31598 : H12AffineFastState.Bounded env31598 := by
  intro p hp
  have h : env31598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31582_31598 : H12AffineEnvironment.transform 22 452649 env31582 = env31598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env31582 == env31598) = true)

def env31599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,98781,8328,65,295285,458024,17665,10281,454116,144613,256,21792,46213,510515]

theorem envBound31599 : H12AffineFastState.Bounded env31599 := by
  intro p hp
  have h : env31599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31598_31599 : H12AffineEnvironment.transform 21 272512 env31598 = env31599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31598 == env31599) = true)

theorem identity31599 : scanCanonicalize (H12AffineFastState.compose env31599 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound31599 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115870,201830,120015,98781,8328,65,245139,115150,17665,10281,119042,144613,256,21792,46213,63189]

theorem envBound31600 : H12AffineFastState.Bounded env31600 := by
  intro p hp
  have h : env31600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31599_31600 : H12AffineEnvironment.transform 17 212198 env31599 = env31600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env31599 == env31600) = true)

def env31601 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115870,201782,119967,98701,8328,17,245139,115102,17665,10281,119042,144565,256,21792,46213,63109]

theorem envBound31601 : H12AffineFastState.Bounded env31601 := by
  intro p hp
  have h : env31601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31600_31601 : H12AffineEnvironment.transform 5 16 env31600 = env31601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31600 == env31601) = true)

theorem identity31601 : scanCanonicalize (H12AffineFastState.compose env31601 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115102) := by decide +kernel

theorem selectedBound31601 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env31602 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,115102,64808,1024,32769,115870,54696,119967,98701,8328,17,31757,115102,17665,10281,119042,128299,256,21792,46213,63109]

theorem envBound31602 : H12AffineFastState.Bounded env31602 := by
  intro p hp
  have h : env31602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31601_31602 : H12AffineEnvironment.transform 16 115102 env31601 = env31602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115102 env31601 == env31602) = true)

theorem identity31602 : scanCanonicalize (H12AffineFastState.compose env31602 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound31602 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env31603 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62731,13461,64808,1024,32769,12693,54696,8596,29830,8328,17,31757,13461,17665,10281,9225,32,256,21792,46213,63109]

theorem envBound31603 : H12AffineFastState.Bounded env31603 := by
  intro p hp
  have h : env31603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31602_31603 : H12AffineEnvironment.transform 15 62731 env31602 = env31603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env31602 == env31603) = true)

theorem identity31603 : scanCanonicalize (H12AffineFastState.compose env31603 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound31603 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env31604 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,33031,13461,35108,1024,32769,12693,41380,8596,138,8328,17,2049,13461,12557,10281,9225,32,256,8492,46213,33417]

theorem envBound31604 : H12AffineFastState.Bounded env31604 := by
  intro p hp
  have h : env31604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31603_31604 : H12AffineEnvironment.transform 13 13324 env31603 = env31604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env31603 == env31604) = true)

theorem identity31604 : scanCanonicalize (H12AffineFastState.compose env31604 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound31604 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env31605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8581,8322,13461,10401,1024,8580,12693,33,8596,138,8328,17,2049,13461,12557,10281,9225,32,256,8492,5376,8972]

theorem envBound31605 : H12AffineFastState.Bounded env31605 := by
  intro p hp
  have h : env31605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31604_31605 : H12AffineEnvironment.transform 14 8581 env31604 = env31605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env31604 == env31605) = true)

theorem identity31605 : scanCanonicalize (H12AffineFastState.compose env31605 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound31605 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,0,263,5392,2340,1024,1,4112,33,17,138,269,17,2049,5392,4232,2476,1420,32,256,169,5376,649]

theorem envBound31606 : H12AffineFastState.Bounded env31606 := by
  intro p hp
  have h : env31606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31605_31606 : H12AffineEnvironment.transform 12 389 env31605 = env31606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env31605 == env31606) = true)

theorem identity31606 : scanCanonicalize (H12AffineFastState.compose env31606 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound31606 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31607 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,301,5409,0,263,5392,2340,1024,1,4112,33,17,34,269,17,2049,5392,4128,2308,1316,32,256,1,5376,545]

theorem envBound31607 : H12AffineFastState.Bounded env31607 := by
  intro p hp
  have h : env31607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31606_31607 : H12AffineEnvironment.transform 6 40 env31606 = env31607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env31606 == env31607) = true)

theorem identity31607 : scanCanonicalize (H12AffineFastState.compose env31607 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31607 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31608 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5376,0,263,5392,2309,1024,1,4112,0,17,3,269,17,2049,5392,4097,2308,1285,1,256,1,5376,512]

theorem envBound31608 : H12AffineFastState.Bounded env31608 := by
  intro p hp
  have h : env31608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31607_31608 : H12AffineEnvironment.transform 4 1 env31607 = env31608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31607 == env31608) = true)

theorem identity31608 : scanCanonicalize (H12AffineFastState.compose env31608 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound31608 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31609 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,0,268,1280,0,263,1296,2309,1024,1,16,0,17,3,269,17,2049,1296,1,2308,1285,1,256,1,1280,512]

theorem envBound31609 : H12AffineFastState.Bounded env31609 := by
  intro p hp
  have h : env31609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31608_31609 : H12AffineEnvironment.transform 11 0 env31608 = env31609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env31608 == env31609) = true)

theorem identity31609 : scanCanonicalize (H12AffineFastState.compose env31609 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound31609 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31610 : List Nat := [2,4,8,16,1,16,9,256,512,1024,10,0,268,1280,0,263,1296,271,1024,1,16,0,17,3,269,17,11,1296,1,270,1285,1,256,1,1280,512]

theorem envBound31610 : H12AffineFastState.Bounded env31610 := by
  intro p hp
  have h : env31610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31609_31610 : H12AffineEnvironment.transform 10 10 env31609 = env31610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env31609 == env31610) = true)

theorem identity31610 : scanCanonicalize (H12AffineFastState.compose env31610 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31610 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31611 : List Nat := [2,4,8,16,1,16,9,256,512,4,10,0,268,260,0,263,276,271,4,1,16,0,17,3,269,17,11,276,1,270,257,1,256,1,260,512]

theorem envBound31611 : H12AffineFastState.Bounded env31611 := by
  intro p hp
  have h : env31611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31610_31611 : H12AffineEnvironment.transform 9 4 env31610 = env31611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31610 == env31611) = true)

theorem identity31611 : scanCanonicalize (H12AffineFastState.compose env31611 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound31611 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31612 : List Nat := [2,4,8,16,1,16,9,31,512,4,10,0,19,27,0,24,11,16,4,1,16,0,17,3,18,17,11,11,1,17,30,1,31,1,27,512]

theorem envBound31612 : H12AffineFastState.Bounded env31612 := by
  intro p hp
  have h : env31612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31611_31612 : H12AffineEnvironment.transform 7 31 env31611 = env31612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env31611 == env31612) = true)

def env31613 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115870,201783,119966,98700,8328,16,245139,115103,17665,10281,119042,144564,256,21792,46213,63108]

theorem envBound31613 : H12AffineFastState.Bounded env31613 := by
  intro p hp
  have h : env31613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31600_31613 : H12AffineEnvironment.transform 5 17 env31600 = env31613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31600 == env31613) = true)

theorem identity31613 : scanCanonicalize (H12AffineFastState.compose env31613 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound31613 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env31614 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76079,1024,32769,115870,65967,119966,98700,8328,16,108555,115103,17665,10281,119042,8492,256,21792,46213,63108]

theorem envBound31614 : H12AffineFastState.Bounded env31614 := by
  intro p hp
  have h : env31614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31613_31614 : H12AffineEnvironment.transform 16 5528 env31613 = env31614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env31613 == env31614) = true)

theorem identity31614 : scanCanonicalize (H12AffineFastState.compose env31614 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound31614 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env31615 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,5528,35108,1024,32769,25749,41380,29845,8583,8328,16,2048,24980,17665,10281,28937,8492,256,21792,46213,63108]

theorem envBound31615 : H12AffineFastState.Bounded env31615 := by
  intro p hp
  have h : env31615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31614_31615 : H12AffineEnvironment.transform 15 40971 env31614 = env31615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env31614 == env31615) = true)

theorem identity31615 : scanCanonicalize (H12AffineFastState.compose env31615 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31615 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31616 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,8202,5528,2341,1024,0,25749,8613,29845,8583,8328,16,2048,24980,17665,10281,28937,8492,256,21792,13444,30341]

theorem envBound31616 : H12AffineFastState.Bounded env31616 := by
  intro p hp
  have h : env31616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31615_31616 : H12AffineEnvironment.transform 14 1 env31615 = env31616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31615 == env31616) = true)

theorem identity31616 : scanCanonicalize (H12AffineFastState.compose env31616 (packedSelected [1,3,4,5,7,8,10,11,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound31616 : packedSelected [1,3,4,5,7,8,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env31617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1573,4096,8192,16384,1,8202,5528,1792,1024,0,25749,8613,29845,8583,8328,16,1573,24980,17665,9740,28937,8492,256,21792,13444,30341]

theorem envBound31617 : H12AffineFastState.Bounded env31617 := by
  intro p hp
  have h : env31617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31616_31617 : H12AffineEnvironment.transform 10 1573 env31616 = env31617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env31616 == env31617) = true)

theorem identity31617 : scanCanonicalize (H12AffineFastState.compose env31617 (packedSelected [2,3,5,7,9,10,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound31617 : packedSelected [2,3,5,7,9,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env31618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1573,4096,8192,13576,1,8202,5528,1792,1024,0,4509,8613,413,8583,8328,16,1573,5276,12297,9740,1025,8492,256,8232,13444,909]

theorem envBound31618 : H12AffineFastState.Bounded env31618 := by
  intro p hp
  have h : env31618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31617_31618 : H12AffineEnvironment.transform 13 13576 env31617 = env31618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env31617 == env31618) = true)

theorem identity31618 : scanCanonicalize (H12AffineFastState.compose env31618 (packedSelected [1,2,7,8,9,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound31618 : packedSelected [1,2,7,8,9,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env31619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1573,4096,8,5376,1,2,5528,1792,1024,0,4509,429,413,399,128,16,1573,5276,4097,1540,1025,292,256,32,5260,909]

theorem envBound31619 : H12AffineFastState.Bounded env31619 := by
  intro p hp
  have h : env31619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31618_31619 : H12AffineEnvironment.transform 12 8 env31618 = env31619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env31618 == env31619) = true)

theorem identity31619 : scanCanonicalize (H12AffineFastState.compose env31619 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31619 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env31620 : List Nat := [2,4,8,16,32,17,128,5,512,1024,1573,4096,8,5125,1,2,5277,1541,1024,0,4248,168,152,138,128,16,1573,5276,4097,1540,1025,33,5,32,5260,648]

theorem envBound31620 : H12AffineFastState.Bounded env31620 := by
  intro p hp
  have h : env31620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31619_31620 : H12AffineEnvironment.transform 7 5 env31619 = env31620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31619 == env31620) = true)

theorem identity31620 : scanCanonicalize (H12AffineFastState.compose env31620 (packedSelected [1,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31620 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env31621 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1573,4096,8,5125,1,2,5261,1541,1024,0,4232,168,136,138,128,0,1573,5260,4097,1540,1025,33,5,32,5260,648]

theorem envBound31621 : H12AffineFastState.Bounded env31621 := by
  intro p hp
  have h : env31621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31620_31621 : H12AffineEnvironment.transform 3 0 env31620 = env31621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31620 == env31621) = true)

theorem identity31621 : scanCanonicalize (H12AffineFastState.compose env31621 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound31621 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31622 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1573,544,8,1573,1,2,1709,1541,1024,0,680,168,136,138,128,0,1573,1708,545,1540,1025,33,5,32,1708,648]

theorem envBound31622 : H12AffineFastState.Bounded env31622 := by
  intro p hp
  have h : env31622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31621_31622 : H12AffineEnvironment.transform 11 544 env31621 = env31622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env31621 == env31622) = true)

theorem identity31622 : scanCanonicalize (H12AffineFastState.compose env31622 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound31622 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31623 : List Nat := [2,4,8,0,32,1,128,5,512,172,649,544,8,649,1,2,513,681,172,0,680,168,136,138,128,0,649,512,545,680,173,33,5,32,512,648]

theorem envBound31623 : H12AffineFastState.Bounded env31623 := by
  intro p hp
  have h : env31623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31622_31623 : H12AffineEnvironment.transform 9 172 env31622 = env31623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env31622 == env31623) = true)

theorem identity31623 : scanCanonicalize (H12AffineFastState.compose env31623 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31623 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31624 : List Nat := [2,4,8,0,32,1,9,5,512,37,512,544,8,512,1,2,513,544,37,0,545,33,1,3,9,0,512,512,545,545,36,33,5,32,512,513]

theorem envBound31624 : H12AffineFastState.Bounded env31624 := by
  intro p hp
  have h : env31624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31623_31624 : H12AffineEnvironment.transform 6 9 env31623 = env31624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31623 == env31624) = true)

theorem identity31624 : scanCanonicalize (H12AffineFastState.compose env31624 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31625 : List Nat := [2,4,8,0,1,1,9,5,512,4,512,513,8,512,1,2,513,513,4,0,512,0,1,3,9,0,512,512,512,512,5,0,5,1,512,513]

theorem envBound31625 : H12AffineFastState.Bounded env31625 := by
  intro p hp
  have h : env31625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31624_31625 : H12AffineEnvironment.transform 4 1 env31624 = env31625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31624 == env31625) = true)

theorem identity31625 : scanCanonicalize (H12AffineFastState.compose env31625 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31626 : List Nat := [2,4,8,0,1,1,9,5,1,4,1,0,8,1,1,2,0,0,4,0,1,0,1,3,9,0,1,1,1,1,5,0,5,1,1,0]

theorem envBound31626 : H12AffineFastState.Bounded env31626 := by
  intro p hp
  have h : env31626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31625_31626 : H12AffineEnvironment.transform 8 1 env31625 = env31626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31625 == env31626) = true)

theorem identity31626 : scanCanonicalize (H12AffineFastState.compose env31626 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31626 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31627 : List Nat := [2,4,2,0,1,1,3,5,1,4,1,0,2,1,1,2,0,0,4,0,1,0,1,3,3,0,1,1,1,1,5,0,5,1,1,0]

theorem envBound31627 : H12AffineFastState.Bounded env31627 := by
  intro p hp
  have h : env31627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31626_31627 : H12AffineEnvironment.transform 2 2 env31626 = env31627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31626 == env31627) = true)

def env31628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,98781,8328,65,295284,458024,17665,10281,454116,144612,256,21792,46213,510515]

theorem envBound31628 : H12AffineFastState.Bounded env31628 := by
  intro p hp
  have h : env31628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31598_31628 : H12AffineEnvironment.transform 21 272513 env31598 = env31628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31598 == env31628) = true)

theorem identity31628 : scanCanonicalize (H12AffineFastState.compose env31628 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound31628 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456824,272513,452649,21762,8328,65,295284,458024,17665,10281,454116,144612,256,21792,46213,401132]

theorem envBound31629 : H12AffineFastState.Bounded env31629 := by
  intro p hp
  have h : env31629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31628_31629 : H12AffineEnvironment.transform 15 54495 env31628 = env31629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env31628 == env31629) = true)

def env31630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456824,272393,452649,21762,8192,65,295284,458024,17665,10281,453996,144492,256,21792,46093,400996]

theorem envBound31630 : H12AffineFastState.Bounded env31630 := by
  intro p hp
  have h : env31630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31629_31630 : H12AffineEnvironment.transform 6 8 env31629 = env31630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31629 == env31630) = true)

theorem identity31630 : scanCanonicalize (H12AffineFastState.compose env31630 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound31630 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env31631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1024,32769,165200,21793,169217,21762,8192,65,64604,163840,17665,10281,168004,144492,256,21792,46093,156492]

theorem envBound31631 : H12AffineFastState.Bounded env31631 := by
  intro p hp
  have h : env31631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31630_31631 : H12AffineEnvironment.transform 17 32040 env31630 = env31631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env31630 == env31631) = true)

theorem identity31631 : scanCanonicalize (H12AffineFastState.compose env31631 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound31631 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env31632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30043,131072,32040,1024,8461,140380,21793,144397,21762,8192,65,23888,139532,17665,10281,143688,144492,256,21792,5377,156492]

theorem envBound31632 : H12AffineFastState.Bounded env31632 := by
  intro p hp
  have h : env31632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31631_31632 : H12AffineEnvironment.transform 14 8460 env31631 = env31632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env31631 == env31632) = true)

theorem identity31632 : scanCanonicalize (H12AffineFastState.compose env31632 (packedSelected [16,17,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound31632 : packedSelected [16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env31633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30043,24860,32040,1024,8461,17728,21793,21777,21762,8192,65,23888,16400,17665,10281,20564,21872,256,21792,5377,592]

theorem envBound31633 : H12AffineFastState.Bounded env31633 := by
  intro p hp
  have h : env31633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31632_31633 : H12AffineEnvironment.transform 16 24860 env31632 = env31633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env31632 == env31633) = true)

theorem identity31633 : scanCanonicalize (H12AffineFastState.compose env31633 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31633 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31634 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29962,24860,32040,1024,8461,17681,21793,21777,21762,8192,16,23809,16400,17665,10281,20485,21793,256,21792,5377,513]

theorem envBound31634 : H12AffineFastState.Bounded env31634 := by
  intro p hp
  have h : env31634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31633_31634 : H12AffineEnvironment.transform 5 17 env31633 = env31634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31633 == env31634) = true)

def env31635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456824,272392,452649,21762,8193,65,295284,458024,17665,10281,453997,144493,256,21792,46092,400997]

theorem envBound31635 : H12AffineFastState.Bounded env31635 := by
  intro p hp
  have h : env31635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31629_31635 : H12AffineEnvironment.transform 6 9 env31629 = env31635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31629 == env31635) = true)

theorem identity31635 : scanCanonicalize (H12AffineFastState.compose env31635 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 149569) := by decide +kernel

theorem selectedBound31635 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env31636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149569,1024,32769,45113,155721,41064,21762,8193,65,182581,46441,17665,10281,42284,144493,256,21792,46092,22052]

theorem envBound31636 : H12AffineFastState.Bounded env31636 := by
  intro p hp
  have h : env31636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31635_31636 : H12AffineEnvironment.transform 17 149569 env31635 = env31636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149569 env31635 == env31636) = true)

theorem identity31636 : scanCanonicalize (H12AffineFastState.compose env31636 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31636 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env31637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,32768,54358,131072,149569,1024,32769,36928,147504,32785,21762,120,65,182581,38160,17665,2128,34133,136212,256,21792,38005,22052]

theorem envBound31637 : H12AffineFastState.Bounded env31637 := by
  intro p hp
  have h : env31637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31636_31637 : H12AffineEnvironment.transform 12 121 env31636 = env31637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31636 == env31637) = true)

theorem identity31637 : scanCanonicalize (H12AffineFastState.compose env31637 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound31637 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env31638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21761,343,131072,149569,1024,21760,17729,147504,21776,21762,120,65,138292,16401,17665,2128,20564,136212,256,21792,16756,22052]

theorem envBound31638 : H12AffineFastState.Bounded env31638 := by
  intro p hp
  have h : env31638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31637_31638 : H12AffineEnvironment.transform 14 21761 env31637 = env31638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env31637 == env31638) = true)

theorem identity31638 : scanCanonicalize (H12AffineFastState.compose env31638 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 16693) := by decide +kernel

theorem selectedBound31638 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env31639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21761,343,16693,2420,1024,21760,17729,261,21776,21762,120,65,23809,16401,17665,2128,20564,21793,256,21792,16756,22052]

theorem envBound31639 : H12AffineFastState.Bounded env31639 := by
  intro p hp
  have h : env31639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31638_31639 : H12AffineEnvironment.transform 16 16693 env31638 = env31639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16693 env31638 == env31639) = true)

theorem identity31639 : scanCanonicalize (H12AffineFastState.compose env31639 (packedSelected [0,1,4,7,8,9,10,11,12,15,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound31639 : packedSelected [0,1,4,7,8,9,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env31640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,121,16384,19509,343,16693,2420,1024,19508,17729,261,19492,19510,120,65,17461,16401,17665,2128,18784,19477,256,19476,16756,20240]

theorem envBound31640 : H12AffineFastState.Bounded env31640 := by
  intro p hp
  have h : env31640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31639_31640 : H12AffineEnvironment.transform 11 2356 env31639 = env31640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env31639 == env31640) = true)

theorem identity31640 : scanCanonicalize (H12AffineFastState.compose env31640 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound31640 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env31641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,121,3393,372,343,3188,2420,1024,373,2048,261,357,375,120,65,2420,3408,2112,2128,1057,340,256,341,3125,593]

theorem envBound31641 : H12AffineFastState.Bounded env31641 := by
  intro p hp
  have h : env31641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31640_31641 : H12AffineEnvironment.transform 13 3393 env31640 = env31641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env31640 == env31641) = true)

theorem identity31641 : scanCanonicalize (H12AffineFastState.compose env31641 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31641 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31642 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,121,2420,372,343,2113,2420,53,373,2048,261,357,375,120,65,2420,2405,2112,2128,20,340,256,341,2048,593]

theorem envBound31642 : H12AffineFastState.Bounded env31642 := by
  intro p hp
  have h : env31642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31641_31642 : H12AffineEnvironment.transform 9 53 env31641 = env31642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31641 == env31642) = true)

theorem identity31642 : scanCanonicalize (H12AffineFastState.compose env31642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31643 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,121,2129,81,114,2113,2129,53,80,2048,32,64,82,120,65,2129,2112,2112,2128,20,113,37,112,2048,593]

theorem envBound31643 : H12AffineFastState.Bounded env31643 := by
  intro p hp
  have h : env31643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31642_31643 : H12AffineEnvironment.transform 7 37 env31642 = env31643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31642 == env31643) = true)

theorem identity31643 : scanCanonicalize (H12AffineFastState.compose env31643 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound31643 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31644 : List Nat := [2,4,8,16,32,48,9,37,512,53,2048,2065,9,2081,33,2,2097,2081,53,32,2048,32,48,34,8,49,2081,2096,2096,2080,20,1,37,0,2048,545]

theorem envBound31644 : H12AffineFastState.Bounded env31644 := by
  intro p hp
  have h : env31644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31643_31644 : H12AffineEnvironment.transform 5 48 env31643 = env31644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env31643 == env31644) = true)

theorem identity31644 : scanCanonicalize (H12AffineFastState.compose env31644 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31645 : List Nat := [2,4,8,16,32,48,9,37,512,53,49,32,9,16,33,2,0,16,53,32,49,32,48,34,8,49,16,1,1,17,20,1,37,0,49,545]

theorem envBound31645 : H12AffineFastState.Bounded env31645 := by
  intro p hp
  have h : env31645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31644_31645 : H12AffineEnvironment.transform 10 49 env31644 = env31645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31644 == env31645) = true)

def env31646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,8388608,8874484,8328,65,4237813,8393984,8826153,8830976,454116,12645453,256,21793,46212,510515]

theorem envBound31646 : H12AffineFastState.Bounded env31646 := by
  intro p hp
  have h : env31646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31581_31646 : H12AffineEnvironment.transform 20 456825 env31581 = env31646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env31581 == env31646) = true)

def env31647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,98780,8328,65,4237813,458024,17665,10280,454116,4594789,256,21793,46212,510515]

theorem envBound31647 : H12AffineFastState.Bounded env31647 := by
  intro p hp
  have h : env31647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31646_31647 : H12AffineEnvironment.transform 22 452648 env31646 = env31647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env31646 == env31647) = true)

def env31648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,98780,8328,65,295285,458024,17665,10280,454116,144613,256,21793,46212,510515]

theorem envBound31648 : H12AffineFastState.Bounded env31648 := by
  intro p hp
  have h : env31648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31647_31648 : H12AffineEnvironment.transform 21 272512 env31647 = env31648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31647 == env31648) = true)

def env31649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452648,98644,8192,65,295285,458024,17665,10280,453996,144493,256,21793,46092,510515]

theorem envBound31649 : H12AffineFastState.Bounded env31649 := by
  intro p hp
  have h : env31649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31648_31649 : H12AffineEnvironment.transform 6 8 env31648 = env31649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31648 == env31649) = true)

theorem identity31649 : scanCanonicalize (H12AffineFastState.compose env31649 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound31649 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254010,73754,98644,8192,65,215367,79130,17665,10280,75102,144493,256,21793,46092,513]

theorem envBound31650 : H12AffineFastState.Bounded env31650 := by
  intro p hp
  have h : env31650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31649_31650 : H12AffineEnvironment.transform 17 247858 env31649 = env31650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env31649 == env31650) = true)

theorem identity31650 : scanCanonicalize (H12AffineFastState.compose env31650 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound31650 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env31651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,77899,33,73754,98644,8192,65,43356,79130,17665,10280,75102,119926,256,21793,46092,513]

theorem envBound31651 : H12AffineFastState.Bounded env31651 := by
  intro p hp
  have h : env31651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31650_31651 : H12AffineEnvironment.transform 16 122907 env31650 = env31651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env31650 == env31651) = true)

theorem identity31651 : scanCanonicalize (H12AffineFastState.compose env31651 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31651 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env31652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1024,32769,4161,33,16,41310,8192,65,43356,5392,17665,10280,1364,62588,256,21793,46092,513]

theorem envBound31652 : H12AffineFastState.Bounded env31652 := by
  intro p hp
  have h : env31652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31651_31652 : H12AffineEnvironment.transform 15 8202 env31651 = env31652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31651 == env31652) = true)

theorem identity31652 : scanCanonicalize (H12AffineFastState.compose env31652 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31652 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,49169,2340,1024,32769,4161,33,16,32851,269,65,34897,5392,17665,2341,1364,54641,256,21793,38145,513]

theorem envBound31653 : H12AffineFastState.Bounded env31653 := by
  intro p hp
  have h : env31653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31652_31653 : H12AffineEnvironment.transform 12 269 env31652 = env31653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31652 == env31653) = true)

theorem identity31653 : scanCanonicalize (H12AffineFastState.compose env31653 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound31653 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,32768,263,38209,2340,1024,32769,4161,33,16,32851,269,65,34897,5392,4177,2341,1364,32801,256,113,38145,513]

theorem envBound31654 : H12AffineFastState.Bounded env31654 := by
  intro p hp
  have h : env31654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31653_31654 : H12AffineEnvironment.transform 13 5456 env31653 = env31654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env31653 == env31654) = true)

theorem identity31654 : scanCanonicalize (H12AffineFastState.compose env31654 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound31654 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,81,263,5392,2340,1024,80,4161,33,16,2,269,65,2048,5392,4177,2341,1364,112,256,113,5456,513]

theorem envBound31655 : H12AffineFastState.Bounded env31655 := by
  intro p hp
  have h : env31655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31654_31655 : H12AffineEnvironment.transform 14 81 env31654 = env31655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env31654 == env31655) = true)

theorem identity31655 : scanCanonicalize (H12AffineFastState.compose env31655 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2145) := by decide +kernel

theorem selectedBound31655 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2145,269,3377,81,263,3441,2340,1024,80,2080,33,16,2,269,65,2048,3441,2096,2341,1364,112,256,113,3377,513]

theorem envBound31656 : H12AffineFastState.Bounded env31656 := by
  intro p hp
  have h : env31656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31655_31656 : H12AffineEnvironment.transform 11 2145 env31655 = env31656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2145 env31655 == env31656) = true)

theorem identity31656 : scanCanonicalize (H12AffineFastState.compose env31656 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound31656 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31657 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,2145,269,2049,81,263,2113,2340,304,80,2080,33,16,2,269,65,2048,2113,2096,2341,100,112,256,113,2049,513]

theorem envBound31657 : H12AffineFastState.Bounded env31657 := by
  intro p hp
  have h : env31657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31656_31657 : H12AffineEnvironment.transform 9 304 env31656 = env31657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env31656 == env31657) = true)

theorem identity31657 : scanCanonicalize (H12AffineFastState.compose env31657 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31657 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31658 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,2112,269,2049,81,263,2113,2309,273,80,2049,0,16,2,269,65,2048,2113,2065,2308,69,81,256,80,2049,513]

theorem envBound31658 : H12AffineFastState.Bounded env31658 := by
  intro p hp
  have h : env31658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31657_31658 : H12AffineEnvironment.transform 4 1 env31657 = env31658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31657 == env31658) = true)

theorem identity31658 : scanCanonicalize (H12AffineFastState.compose env31658 (packedSelected [3,5,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31658 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env31659 : List Nat := [2,4,8,16,1,17,8,256,512,273,2048,2065,269,2049,0,263,2064,2309,273,1,2049,0,16,2,269,16,2048,2064,2065,2308,20,0,256,1,2049,513]

theorem envBound31659 : H12AffineFastState.Bounded env31659 := by
  intro p hp
  have h : env31659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31658_31659 : H12AffineEnvironment.transform 5 17 env31658 = env31659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31658 == env31659) = true)

theorem identity31659 : scanCanonicalize (H12AffineFastState.compose env31659 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound31659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31660 : List Nat := [2,4,8,16,1,17,8,256,512,273,260,277,269,261,0,263,276,1,273,1,261,0,16,2,269,16,260,276,277,0,20,0,256,1,261,513]

theorem envBound31660 : H12AffineFastState.Bounded env31660 := by
  intro p hp
  have h : env31660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31659_31660 : H12AffineEnvironment.transform 10 260 env31659 = env31660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env31659 == env31660) = true)

def env31661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452648,98645,8193,65,295285,458024,17665,10280,453997,144492,256,21793,46093,510515]

theorem envBound31661 : H12AffineFastState.Bounded env31661 := by
  intro p hp
  have h : env31661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31648_31661 : H12AffineEnvironment.transform 6 9 env31648 = env31661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31648 == env31661) = true)

theorem identity31661 : scanCanonicalize (H12AffineFastState.compose env31661 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31661 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,309353,272393,305208,98645,8193,65,295285,310584,17665,10280,306557,29820,256,21793,46093,363043]

theorem envBound31662 : H12AffineFastState.Bounded env31662 := by
  intro p hp
  have h : env31662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31661_31662 : H12AffineEnvironment.transform 16 16400 env31661 = env31662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31661 == env31662) = true)

theorem identity31662 : scanCanonicalize (H12AffineFastState.compose env31662 (packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound31662 : packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100387,1024,32769,77898,106538,73755,98645,8193,65,67926,79131,17665,10280,75102,29820,256,21793,46093,512]

theorem envBound31663 : H12AffineFastState.Bounded env31663 := by
  intro p hp
  have h : env31663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31662_31663 : H12AffineEnvironment.transform 17 100387 env31662 = env31663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env31662 == env31663) = true)

theorem identity31663 : scanCanonicalize (H12AffineFastState.compose env31663 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound31663 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,65536,13625,100387,1024,32769,77898,106538,73755,98645,8193,65,67926,79131,12328,10280,75102,341,256,8200,46093,512]

theorem envBound31664 : H12AffineFastState.Bounded env31664 := by
  intro p hp
  have h : env31664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31663_31664 : H12AffineEnvironment.transform 13 13609 env31663 = env31664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env31663 == env31664) = true)

theorem identity31664 : scanCanonicalize (H12AffineFastState.compose env31664 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound31664 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8200,65536,13625,75819,1024,8201,77898,65570,73755,74077,8193,65,67926,79131,12328,10280,75102,341,256,8200,5125,512]

theorem envBound31665 : H12AffineFastState.Bounded env31665 := by
  intro p hp
  have h : env31665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31664_31665 : H12AffineEnvironment.transform 14 8200 env31664 = env31665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env31664 == env31665) = true)

theorem identity31665 : scanCanonicalize (H12AffineFastState.compose env31665 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31665 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env31666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,340,65536,5221,67959,1024,341,69910,65570,65863,65537,349,65,67926,70727,4468,2420,66562,341,256,340,5125,512]

theorem envBound31666 : H12AffineFastState.Bounded env31666 := by
  intro p hp
  have h : env31666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31665_31666 : H12AffineEnvironment.transform 12 348 env31665 = env31666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31665 == env31666) = true)

theorem identity31666 : scanCanonicalize (H12AffineFastState.compose env31666 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound31666 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,340,115,5221,2308,1024,341,4453,81,308,114,349,65,2341,5172,4468,2420,1137,341,256,340,5125,512]

theorem envBound31667 : H12AffineFastState.Bounded env31667 := by
  intro p hp
  have h : env31667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31666_31667 : H12AffineEnvironment.transform 15 115 env31666 = env31667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env31666 == env31667) = true)

theorem identity31667 : scanCanonicalize (H12AffineFastState.compose env31667 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31667 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31668 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,301,5124,293,2,5140,2308,1024,292,4372,32,308,3,300,48,2341,5172,4357,2309,1024,292,256,293,5125,512]

theorem envBound31668 : H12AffineFastState.Bounded env31668 := by
  intro p hp
  have h : env31668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31667_31668 : H12AffineEnvironment.transform 5 49 env31667 = env31668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31667 == env31668) = true)

theorem identity31668 : scanCanonicalize (H12AffineFastState.compose env31668 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31668 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31669 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,41,5124,33,2,5140,2048,1024,32,4112,32,48,3,40,48,2081,5172,4097,2049,1024,32,4,33,5125,512]

theorem envBound31669 : H12AffineFastState.Bounded env31669 := by
  intro p hp
  have h : env31669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31668_31669 : H12AffineEnvironment.transform 7 4 env31668 = env31669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31668 == env31669) = true)

theorem identity31669 : scanCanonicalize (H12AffineFastState.compose env31669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31670 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,1,2,5140,2048,1024,0,4112,0,16,3,8,16,2049,5140,4097,2049,1024,0,4,1,5125,512]

theorem envBound31670 : H12AffineFastState.Bounded env31670 := by
  intro p hp
  have h : env31670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31669_31670 : H12AffineEnvironment.transform 4 0 env31669 = env31670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31669 == env31670) = true)

theorem identity31670 : scanCanonicalize (H12AffineFastState.compose env31670 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound31670 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31671 : List Nat := [2,4,8,16,0,17,9,4,512,1024,522,4096,9,5124,1,2,5140,522,1024,0,4112,0,16,3,8,16,523,5140,4097,523,1024,0,4,1,5125,512]

theorem envBound31671 : H12AffineFastState.Bounded env31671 := by
  intro p hp
  have h : env31671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31670_31671 : H12AffineEnvironment.transform 10 522 env31670 = env31671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env31670 == env31671) = true)

def env31672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,98780,8328,65,295284,458024,17665,10280,454116,144612,256,21793,46212,510515]

theorem envBound31672 : H12AffineFastState.Bounded env31672 := by
  intro p hp
  have h : env31672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31647_31672 : H12AffineEnvironment.transform 21 272513 env31647 = env31672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31647 == env31672) = true)

theorem identity31672 : scanCanonicalize (H12AffineFastState.compose env31672 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound31672 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180409,16,98780,8328,65,158028,5392,17665,10280,1500,144612,256,21793,46212,74251]

theorem envBound31673 : H12AffineFastState.Bounded env31673 := by
  intro p hp
  have h : env31673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31672_31673 : H12AffineEnvironment.transform 17 190520 env31672 = env31673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env31672 == env31673) = true)

theorem identity31673 : scanCanonicalize (H12AffineFastState.compose env31673 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31673 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,180409,16,41430,8328,65,158028,5392,17665,10280,1500,144612,256,21793,46212,513]

theorem envBound31674 : H12AffineFastState.Bounded env31674 := by
  intro p hp
  have h : env31674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31673_31674 : H12AffineEnvironment.transform 15 8202 env31673 = env31674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31673 == env31674) = true)

theorem identity31674 : scanCanonicalize (H12AffineFastState.compose env31674 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31674 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4161,32937,16,41430,8328,65,10588,5392,17665,10280,1500,29940,256,21793,46212,513]

theorem envBound31675 : H12AffineFastState.Bounded env31675 := by
  intro p hp
  have h : env31675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31674_31675 : H12AffineEnvironment.transform 16 16400 env31674 = env31675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31674 == env31675) = true)

theorem identity31675 : scanCanonicalize (H12AffineFastState.compose env31675 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound31675 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13508,43048,1024,32769,4161,32937,16,41430,8328,65,10588,5392,12757,10280,1500,32,256,8693,46212,513]

theorem envBound31676 : H12AffineFastState.Bounded env31676 := by
  intro p hp
  have h : env31676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31675_31676 : H12AffineEnvironment.transform 13 13524 env31675 = env31676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env31675 == env31676) = true)

theorem identity31676 : scanCanonicalize (H12AffineFastState.compose env31676 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31676 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env31677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8541,8202,13508,2421,1024,8540,4161,8692,16,139,8328,65,10588,5392,12757,10280,1500,32,256,8693,5593,513]

theorem envBound31677 : H12AffineFastState.Bounded env31677 := by
  intro p hp
  have h : env31677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31676_31677 : H12AffineEnvironment.transform 14 8541 env31676 = env31677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31676 == env31677) = true)

theorem identity31677 : scanCanonicalize (H12AffineFastState.compose env31677 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31677 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,478,5392,2421,1024,136,4161,32,16,139,348,65,2184,5392,4097,2556,1500,32,256,33,5593,513]

theorem envBound31678 : H12AffineFastState.Bounded env31678 := by
  intro p hp
  have h : env31678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31677_31678 : H12AffineEnvironment.transform 12 468 env31677 = env31678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31677 == env31678) = true)

theorem identity31678 : scanCanonicalize (H12AffineFastState.compose env31678 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2556) := by decide +kernel

theorem selectedBound31678 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2556,468,3324,137,478,3308,2421,1024,136,2493,32,16,139,348,65,2184,3308,2557,2556,1500,32,256,33,3109,513]

theorem envBound31679 : H12AffineFastState.Bounded env31679 := by
  intro p hp
  have h : env31679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31678_31679 : H12AffineEnvironment.transform 11 2556 env31678 = env31679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2556 env31678 == env31679) = true)

def env31680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,98781,8328,65,4237813,458025,17664,10281,454116,4594788,256,21793,46212,510515]

theorem envBound31680 : H12AffineFastState.Bounded env31680 := by
  intro p hp
  have h : env31680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31646_31680 : H12AffineEnvironment.transform 22 452649 env31646 = env31680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env31646 == env31680) = true)

def env31681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,98781,8328,65,295285,458025,17664,10281,454116,144612,256,21793,46212,510515]

theorem envBound31681 : H12AffineFastState.Bounded env31681 := by
  intro p hp
  have h : env31681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31680_31681 : H12AffineEnvironment.transform 21 272512 env31680 = env31681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31680 == env31681) = true)

theorem identity31681 : scanCanonicalize (H12AffineFastState.compose env31681 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31681 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396460,272512,400636,95496,8328,65,292256,395772,17664,10281,399665,144612,256,21793,16465,474854]

theorem envBound31682 : H12AffineFastState.Bounded env31682 := by
  intro p hp
  have h : env31682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31681_31682 : H12AffineEnvironment.transform 14 29909 env31681 = env31682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31681 == env31682) = true)

def env31683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140300,32,144476,95496,8328,65,23808,139612,17664,10281,143761,144612,256,21793,16465,202310]

theorem envBound31683 : H12AffineFastState.Bounded env31683 := by
  intro p hp
  have h : env31683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31682_31683 : H12AffineEnvironment.transform 17 10400 env31682 = env31683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31682 == env31683) = true)

theorem identity31683 : scanCanonicalize (H12AffineFastState.compose env31683 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound31683 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env31684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,5529,10400,1024,29908,12693,32,8645,95496,8328,65,23808,13509,17664,10281,9224,8573,256,21793,16465,66527]

theorem envBound31684 : H12AffineFastState.Bounded env31684 := by
  intro p hp
  have h : env31684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31683_31684 : H12AffineEnvironment.transform 16 5529 env31683 = env31684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env31683 == env31684) = true)

theorem identity31684 : scanCanonicalize (H12AffineFastState.compose env31684 (packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31684 : packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,65536,5529,10400,1024,8581,12693,32,8645,73817,8328,65,2129,13509,4177,10281,9224,8573,256,112,5376,66527]

theorem envBound31685 : H12AffineFastState.Bounded env31685 := by
  intro p hp
  have h : env31685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31684_31685 : H12AffineEnvironment.transform 13 5457 env31684 = env31685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31684 == env31685) = true)

theorem identity31685 : scanCanonicalize (H12AffineFastState.compose env31685 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31685 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,343,5529,10400,1024,8581,12693,32,8645,8462,8328,65,2129,13509,4177,10281,9224,8573,256,112,5376,648]

theorem envBound31686 : H12AffineFastState.Bounded env31686 := by
  intro p hp
  have h : env31686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31685_31686 : H12AffineEnvironment.transform 15 343 env31685 = env31686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31685 == env31686) = true)

theorem identity31686 : scanCanonicalize (H12AffineFastState.compose env31686 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound31686 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5457,429,343,5529,2185,1024,428,4540,32,492,295,161,65,2129,5356,4177,2048,1057,340,256,112,5376,648]

theorem envBound31687 : H12AffineFastState.Bounded env31687 := by
  intro p hp
  have h : env31687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31686_31687 : H12AffineEnvironment.transform 12 41 env31686 = env31687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env31686 == env31687) = true)

theorem identity31687 : scanCanonicalize (H12AffineFastState.compose env31687 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound31687 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env31688 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,41,4113,429,343,4313,2185,320,428,4540,32,492,295,161,65,2129,4524,4177,2048,353,340,256,112,4160,648]

theorem envBound31688 : H12AffineFastState.Bounded env31688 := by
  intro p hp
  have h : env31688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31687_31688 : H12AffineEnvironment.transform 9 320 env31687 = env31688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31687 == env31688) = true)

theorem identity31688 : scanCanonicalize (H12AffineFastState.compose env31688 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31688 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env31689 : List Nat := [2,4,8,16,32,64,128,116,512,52,2048,4096,41,4113,217,35,4313,2185,52,216,4296,32,152,83,161,65,2129,4312,4177,2048,21,32,116,112,4160,648]

theorem envBound31689 : H12AffineFastState.Bounded env31689 := by
  intro p hp
  have h : env31689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31688_31689 : H12AffineEnvironment.transform 7 116 env31688 = env31689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31688 == env31689) = true)

theorem identity31689 : scanCanonicalize (H12AffineFastState.compose env31689 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound31689 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31690 : List Nat := [2,4,8,16,32,64,41,116,512,52,2048,4096,41,4113,112,35,4208,2080,52,113,4193,32,49,83,8,65,2129,4209,4177,2048,21,32,116,112,4160,545]

theorem envBound31690 : H12AffineFastState.Bounded env31690 := by
  intro p hp
  have h : env31690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31689_31690 : H12AffineEnvironment.transform 6 41 env31689 = env31690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env31689 == env31690) = true)

theorem identity31690 : scanCanonicalize (H12AffineFastState.compose env31690 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound31690 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env31691 : List Nat := [2,4,8,16,32,64,41,116,512,52,2048,528,41,513,112,35,608,2080,52,113,625,32,49,83,8,65,2129,609,577,2048,21,32,116,112,592,545]

theorem envBound31691 : H12AffineFastState.Bounded env31691 := by
  intro p hp
  have h : env31691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31690_31691 : H12AffineEnvironment.transform 11 528 env31690 = env31691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env31690 == env31691) = true)

theorem identity31691 : scanCanonicalize (H12AffineFastState.compose env31691 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound31691 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31692 : List Nat := [2,4,8,16,32,64,41,116,512,52,529,528,41,513,112,35,608,561,52,113,625,32,49,83,8,65,576,609,577,529,21,32,116,112,592,545]

theorem envBound31692 : H12AffineFastState.Bounded env31692 := by
  intro p hp
  have h : env31692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31691_31692 : H12AffineEnvironment.transform 10 529 env31691 = env31692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env31691 == env31692) = true)

theorem identity31692 : scanCanonicalize (H12AffineFastState.compose env31692 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31692 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env31693 : List Nat := [2,4,8,16,1,64,8,85,512,21,529,528,8,513,81,2,577,528,21,80,592,1,16,83,8,65,576,576,577,529,21,1,85,81,592,512]

theorem envBound31693 : H12AffineFastState.Bounded env31693 := by
  intro p hp
  have h : env31693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31692_31693 : H12AffineEnvironment.transform 4 1 env31692 = env31693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31692 == env31693) = true)

theorem identity31693 : scanCanonicalize (H12AffineFastState.compose env31693 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31693 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31694 : List Nat := [2,4,8,16,1,17,8,4,512,21,529,528,8,513,0,2,528,528,21,1,513,1,16,2,8,16,529,529,528,529,21,1,4,0,513,512]

theorem envBound31694 : H12AffineFastState.Bounded env31694 := by
  intro p hp
  have h : env31694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31693_31694 : H12AffineEnvironment.transform 5 17 env31693 = env31694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31693 == env31694) = true)

theorem identity31694 : scanCanonicalize (H12AffineFastState.compose env31694 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound31694 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31695 : List Nat := [2,4,8,16,1,17,8,4,21,21,4,5,8,20,0,2,5,5,21,1,20,1,16,2,8,16,4,4,5,4,21,1,4,0,20,21]

theorem envBound31695 : H12AffineFastState.Bounded env31695 := by
  intro p hp
  have h : env31695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31694_31695 : H12AffineEnvironment.transform 8 21 env31694 = env31695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env31694 == env31695) = true)

theorem identity31695 : scanCanonicalize (H12AffineFastState.compose env31695 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound31695 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31696 : List Nat := [2,4,1,16,1,17,1,4,21,21,4,5,1,20,0,2,5,5,21,1,20,1,16,2,1,16,4,4,5,4,21,1,4,0,20,21]

theorem envBound31696 : H12AffineFastState.Bounded env31696 := by
  intro p hp
  have h : env31696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31695_31696 : H12AffineEnvironment.transform 2 1 env31695 = env31696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env31695 == env31696) = true)

theorem identity31696 : scanCanonicalize (H12AffineFastState.compose env31696 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31697 : List Nat := [2,4,1,1,1,0,1,4,4,4,4,5,1,5,0,2,5,5,4,1,5,1,1,2,1,1,4,4,5,4,4,1,4,0,5,4]

theorem envBound31697 : H12AffineFastState.Bounded env31697 := by
  intro p hp
  have h : env31697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31696_31697 : H12AffineEnvironment.transform 3 1 env31696 = env31697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31696 == env31697) = true)

theorem identity31697 : scanCanonicalize (H12AffineFastState.compose env31697 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31697 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31698 : List Nat := [1,4,1,1,1,0,1,4,4,4,4,5,1,5,0,1,5,5,4,1,5,1,1,1,1,1,4,4,5,4,4,1,4,0,5,4]

theorem envBound31698 : H12AffineFastState.Bounded env31698 := by
  intro p hp
  have h : env31698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31697_31698 : H12AffineEnvironment.transform 0 1 env31697 = env31698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31697 == env31698) = true)

def env31699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140301,33,144477,95496,8328,65,23809,139613,17664,10281,143760,144612,256,21793,16465,202311]

theorem envBound31699 : H12AffineFastState.Bounded env31699 := by
  intro p hp
  have h : env31699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31682_31699 : H12AffineEnvironment.transform 17 10401 env31682 = env31699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31682 == env31699) = true)

theorem identity31699 : scanCanonicalize (H12AffineFastState.compose env31699 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31699 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env31700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,65536,131072,10401,1024,137,140301,33,144477,65877,8328,65,10588,139613,12637,10281,143760,144612,256,8572,13324,202311]

theorem envBound31700 : H12AffineFastState.Bounded env31700 := by
  intro p hp
  have h : env31700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31699_31700 : H12AffineEnvironment.transform 13 13405 env31699 = env31700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31699 == env31700) = true)

theorem identity31700 : scanCanonicalize (H12AffineFastState.compose env31700 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound31700 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env31701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,65536,70726,10401,1024,137,77899,33,73755,65877,8328,65,10588,79131,12637,10281,75222,73890,256,8572,13324,513]

theorem envBound31701 : H12AffineFastState.Bounded env31701 := by
  intro p hp
  have h : env31701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31700_31701 : H12AffineEnvironment.transform 16 70726 env31700 = env31701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env31700 == env31701) = true)

theorem identity31701 : scanCanonicalize (H12AffineFastState.compose env31701 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31701 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,65536,70679,10401,1024,137,77850,33,73755,65796,8328,16,10509,79131,12556,10281,75143,73890,256,8493,13324,513]

theorem envBound31702 : H12AffineFastState.Bounded env31702 := by
  intro p hp
  have h : env31702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31701_31702 : H12AffineEnvironment.transform 5 17 env31701 = env31702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31701 == env31702) = true)

theorem identity31702 : scanCanonicalize (H12AffineFastState.compose env31702 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound31702 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31703 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,399,5528,10401,1024,137,12693,33,8596,139,8328,16,10509,13460,12556,10281,9224,8493,256,8493,13324,513]

theorem envBound31703 : H12AffineFastState.Bounded env31703 := by
  intro p hp
  have h : env31703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31702_31703 : H12AffineEnvironment.transform 15 399 env31702 = env31703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env31702 == env31703) = true)

theorem identity31703 : scanCanonicalize (H12AffineFastState.compose env31703 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31703 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env31704 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,263,5392,10281,1024,1,12573,33,8476,3,8192,16,10509,13340,12556,10281,9224,8493,256,8493,13324,513]

theorem envBound31704 : H12AffineFastState.Bounded env31704 := by
  intro p hp
  have h : env31704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31703_31704 : H12AffineEnvironment.transform 6 8 env31703 = env31704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31703 == env31704) = true)

def env31705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,98781,8328,65,295284,458025,17664,10281,454116,144613,256,21793,46212,510515]

theorem envBound31705 : H12AffineFastState.Bounded env31705 := by
  intro p hp
  have h : env31705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31680_31705 : H12AffineEnvironment.transform 21 272513 env31680 = env31705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31680 == env31705) = true)

theorem identity31705 : scanCanonicalize (H12AffineFastState.compose env31705 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound31705 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,58517,144493,62661,98781,8328,65,171416,57797,17664,10281,61704,144613,256,21793,46212,120543]

theorem envBound31706 : H12AffineFastState.Bounded env31706 := by
  intro p hp
  have h : env31706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31705_31706 : H12AffineEnvironment.transform 17 138476 env31705 = env31706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env31705 == env31706) = true)

def env31707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144493,62541,98645,8192,65,171280,57677,17664,10281,61704,144493,256,21793,46092,120407]

theorem envBound31707 : H12AffineFastState.Bounded env31707 := by
  intro p hp
  have h : env31707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31706_31707 : H12AffineEnvironment.transform 6 8 env31706 = env31707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31706 == env31707) = true)

theorem identity31707 : scanCanonicalize (H12AffineFastState.compose env31707 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31707 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env31708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138340,1024,32769,45341,144493,41293,98645,8192,65,171280,46157,4096,10281,41992,144493,256,33,46092,99159]

theorem envBound31708 : H12AffineFastState.Bounded env31708 := by
  intro p hp
  have h : env31708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31707_31708 : H12AffineEnvironment.transform 13 5376 env31707 = env31708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31707 == env31708) = true)

theorem identity31708 : scanCanonicalize (H12AffineFastState.compose env31708 (packedSelected [1,3,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound31708 : packedSelected [1,3,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,41050,131072,138340,1024,32769,45341,144493,41293,8463,8192,65,171280,46157,4096,10281,41992,144493,256,33,46092,8973]

theorem envBound31709 : H12AffineFastState.Bounded env31709 := by
  intro p hp
  have h : env31709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31708_31709 : H12AffineEnvironment.transform 15 41050 env31708 = env31709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env31708 == env31709) = true)

theorem identity31709 : scanCanonicalize (H12AffineFastState.compose env31709 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound31709 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env31710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,342,131072,138340,1024,8461,4113,144493,65,8463,8192,65,146460,5441,4096,10281,1284,144493,256,33,5376,8973]

theorem envBound31710 : H12AffineFastState.Bounded env31710 := by
  intro p hp
  have h : env31710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31709_31710 : H12AffineEnvironment.transform 14 8460 env31709 = env31710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env31709 == env31710) = true)

theorem identity31710 : scanCanonicalize (H12AffineFastState.compose env31710 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31710 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31711 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,263,131072,138293,1024,8461,4113,144444,16,8463,8192,16,146460,5392,4096,10281,1284,144444,256,33,5376,8973]

theorem envBound31711 : H12AffineFastState.Bounded env31711 := by
  intro p hp
  have h : env31711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31710_31711 : H12AffineEnvironment.transform 5 17 env31710 = env31711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31710 == env31711) = true)

theorem identity31711 : scanCanonicalize (H12AffineFastState.compose env31711 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31711 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31712 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,5376,8460,263,131072,138261,1024,8461,4113,144412,16,8463,8192,16,146460,5392,4096,10249,1284,144412,256,1,5376,8973]

theorem envBound31712 : H12AffineFastState.Bounded env31712 := by
  intro p hp
  have h : env31712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31711_31712 : H12AffineEnvironment.transform 4 0 env31711 = env31712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31711 == env31712) = true)

def env31713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58396,144493,62540,98644,8193,65,171281,57676,17664,10281,61704,144492,256,21793,46093,120406]

theorem envBound31713 : H12AffineFastState.Bounded env31713 := by
  intro p hp
  have h : env31713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31706_31713 : H12AffineEnvironment.transform 6 9 env31706 = env31713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31706 == env31713) = true)

theorem identity31713 : scanCanonicalize (H12AffineFastState.compose env31713 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound31713 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env31714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,131072,138341,1024,32769,58396,144493,62540,33063,8193,65,171281,57676,17664,10281,61704,144492,256,21793,46093,54821]

theorem envBound31714 : H12AffineFastState.Bounded env31714 := by
  intro p hp
  have h : env31714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31713_31714 : H12AffineEnvironment.transform 15 115 env31713 = env31714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env31713 == env31714) = true)

theorem identity31714 : scanCanonicalize (H12AffineFastState.compose env31714 (packedSelected [0,4,11,14,16,22,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound31714 : packedSelected [0,4,11,14,16,22,27,32] rootPS < 2^1333 := by decide +kernel

def env31715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,115,131072,138341,1024,29709,4112,144493,64,29995,8193,65,157981,5440,17664,10281,1284,144492,256,21793,16385,8745]

theorem envBound31715 : H12AffineFastState.Bounded env31715 := by
  intro p hp
  have h : env31715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31714_31715 : H12AffineEnvironment.transform 14 29708 env31714 = env31715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env31714 == env31715) = true)

theorem identity31715 : scanCanonicalize (H12AffineFastState.compose env31715 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound31715 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env31716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,115,5441,2340,1024,29709,4112,8492,64,29995,8193,65,31836,5440,17664,10281,1284,8493,256,21793,16385,8745]

theorem envBound31716 : H12AffineFastState.Bounded env31716 := by
  intro p hp
  have h : env31716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31715_31716 : H12AffineEnvironment.transform 16 5441 env31715 = env31716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env31715 == env31716) = true)

theorem identity31716 : scanCanonicalize (H12AffineFastState.compose env31716 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31716 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env31717 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,34,5392,2340,1024,29709,4112,8492,17,29995,8193,16,31757,5393,17664,10281,1284,8493,256,21793,16385,8745]

theorem envBound31717 : H12AffineFastState.Bounded env31717 := by
  intro p hp
  have h : env31717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31716_31717 : H12AffineEnvironment.transform 5 17 env31716 = env31717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31716 == env31717) = true)

theorem identity31717 : scanCanonicalize (H12AffineFastState.compose env31717 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31717 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env31718 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,34,5392,2340,1024,21761,4112,32,17,21543,269,16,23809,5393,17664,2341,1284,33,256,21793,16385,805]

theorem envBound31718 : H12AffineFastState.Bounded env31718 := by
  intro p hp
  have h : env31718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31717_31718 : H12AffineEnvironment.transform 12 268 env31717 = env31718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31717 == env31718) = true)

theorem identity31718 : scanCanonicalize (H12AffineFastState.compose env31718 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

end H12CloudChart0