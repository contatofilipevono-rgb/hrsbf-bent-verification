import H12CloudChart0Data198

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound50392 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50393 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4113,33,17,3,268,16,2049,5393,4097,2341,1284,33,257,33,5377,513]

theorem envBound50393 : H12AffineFastState.Bounded env50393 := by
  intro p hp
  have h : env50393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50392_50393 : H12AffineEnvironment.transform 5 16 env50392 = env50393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50392 == env50393) = true)

theorem identity50393 : scanCanonicalize (H12AffineFastState.compose env50393 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound50393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50394 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,48,268,1328,1,262,1312,2340,1025,0,33,33,17,3,268,16,2049,1313,49,2341,1284,33,257,33,1329,513]

theorem envBound50394 : H12AffineFastState.Bounded env50394 := by
  intro p hp
  have h : env50394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50393_50394 : H12AffineEnvironment.transform 11 48 env50393 = env50394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50393 == env50394) = true)

theorem identity50394 : scanCanonicalize (H12AffineFastState.compose env50394 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound50394 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50395 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1556,48,268,1328,1,262,1312,1840,1025,0,33,33,17,3,268,16,1557,1313,49,1841,1284,33,257,33,1329,513]

theorem envBound50395 : H12AffineFastState.Bounded env50395 := by
  intro p hp
  have h : env50395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50394_50395 : H12AffineEnvironment.transform 10 1556 env50394 = env50395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env50394 == env50395) = true)

theorem identity50395 : scanCanonicalize (H12AffineFastState.compose env50395 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound50395 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50396 : List Nat := [2,4,8,16,32,16,8,256,512,36,560,48,268,276,1,262,260,788,37,0,33,33,17,3,268,16,561,261,49,789,288,33,257,33,277,513]

theorem envBound50396 : H12AffineFastState.Bounded env50396 := by
  intro p hp
  have h : env50396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50395_50396 : H12AffineEnvironment.transform 9 36 env50395 = env50396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env50395 == env50396) = true)

theorem identity50396 : scanCanonicalize (H12AffineFastState.compose env50396 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound50396 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50397 : List Nat := [2,4,8,16,32,16,8,53,512,36,560,48,57,33,1,51,49,545,37,0,33,33,17,3,57,16,561,48,49,544,21,33,52,33,32,513]

theorem envBound50397 : H12AffineFastState.Bounded env50397 := by
  intro p hp
  have h : env50397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50396_50397 : H12AffineEnvironment.transform 7 53 env50396 = env50397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env50396 == env50397) = true)

theorem identity50397 : scanCanonicalize (H12AffineFastState.compose env50397 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50398 : List Nat := [2,4,2,16,32,16,2,53,512,36,560,48,51,33,1,51,49,545,37,0,33,33,17,3,51,16,561,48,49,544,21,33,52,33,32,513]

theorem envBound50398 : H12AffineFastState.Bounded env50398 := by
  intro p hp
  have h : env50398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50397_50398 : H12AffineEnvironment.transform 2 2 env50397 = env50398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50397 == env50398) = true)

theorem identity50398 : scanCanonicalize (H12AffineFastState.compose env50398 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound50398 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env50399 : List Nat := [2,4,2,16,32,16,2,53,32,36,16,48,51,33,1,51,49,1,37,0,33,33,17,3,51,16,17,48,49,0,21,33,52,33,32,33]

theorem envBound50399 : H12AffineFastState.Bounded env50399 := by
  intro p hp
  have h : env50399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50398_50399 : H12AffineEnvironment.transform 8 32 env50398 = env50399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env50398 == env50399) = true)

theorem identity50399 : scanCanonicalize (H12AffineFastState.compose env50399 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50399 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env50400 : List Nat := [2,4,2,16,17,16,2,4,17,21,16,1,2,16,1,2,0,1,20,0,16,16,17,3,2,16,17,1,0,0,21,16,5,16,17,16]

theorem envBound50400 : H12AffineFastState.Bounded env50400 := by
  intro p hp
  have h : env50400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50399_50400 : H12AffineEnvironment.transform 4 17 env50399 = env50400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50399 == env50400) = true)

def env50401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272392,2101328,98645,8193,64,2157596,2098512,17665,2377025,2102548,2411540,257,21793,46093,2175562]

theorem envBound50401 : H12AffineFastState.Bounded env50401 := by
  intro p hp
  have h : env50401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50365_50401 : H12AffineEnvironment.transform 6 9 env50365 = env50401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50365 == env50401) = true)

theorem identity50401 : scanCanonicalize (H12AffineFastState.compose env50401 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 124234) := by decide +kernel

theorem selectedBound50401 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env50402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,124234,272392,128282,98645,8193,64,67926,122906,17665,368651,127070,338270,257,21793,46093,55040]

theorem envBound50402 : H12AffineFastState.Bounded env50402 := by
  intro p hp
  have h : env50402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50401_50402 : H12AffineEnvironment.transform 20 124234 env50401 = env50402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124234 env50401 == env50402) = true)

theorem identity50402 : scanCanonicalize (H12AffineFastState.compose env50402 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound50402 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,38160,262144,1025,32769,102678,272392,98630,98645,8193,64,67926,103494,12637,368651,99330,338270,257,8573,46093,41820]

theorem envBound50403 : H12AffineFastState.Bounded env50403 := by
  intro p hp
  have h : env50403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50402_50403 : H12AffineEnvironment.transform 13 13404 env50402 = env50403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env50402 == env50403) = true)

theorem identity50403 : scanCanonicalize (H12AffineFastState.compose env50403 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50403 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,65536,13389,262144,1025,8540,77899,272392,73755,73736,8193,64,67926,79131,12637,328022,75103,338270,257,8573,5456,513]

theorem envBound50404 : H12AffineFastState.Bounded env50404 := by
  intro p hp
  have h : env50404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50403_50404 : H12AffineEnvironment.transform 14 8541 env50403 = env50404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50403 == env50404) = true)

theorem identity50404 : scanCanonicalize (H12AffineFastState.compose env50404 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 68914) := by decide +kernel

theorem selectedBound50404 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,65536,13389,68914,1025,8540,77899,75066,73755,73736,8193,64,67926,79131,12637,3172,75103,9324,257,8573,5456,513]

theorem envBound50405 : H12AffineFastState.Bounded env50405 := by
  intro p hp
  have h : env50405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50404_50405 : H12AffineEnvironment.transform 17 68914 env50404 = env50405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68914 env50404 == env50405) = true)

theorem identity50405 : scanCanonicalize (H12AffineFastState.compose env50405 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound50405 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1297,65536,4097,68914,1025,1296,70663,65910,66647,66628,1101,64,67926,69975,5393,3172,65811,32,257,1329,5456,513]

theorem envBound50406 : H12AffineFastState.Bounded env50406 := by
  intro p hp
  have h : env50406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50405_50406 : H12AffineEnvironment.transform 12 1100 env50405 = env50406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env50405 == env50406) = true)

theorem identity50406 : scanCanonicalize (H12AffineFastState.compose env50406 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50406 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50407 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4112,0,65536,4097,67619,272,1,69910,65910,65862,65877,348,64,67926,69975,4096,2421,65811,32,257,32,4161,513]

theorem envBound50407 : H12AffineFastState.Bounded env50407 := by
  intro p hp
  have h : env50407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50406_50407 : H12AffineEnvironment.transform 9 273 env50406 = env50407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50406 == env50407) = true)

theorem identity50407 : scanCanonicalize (H12AffineFastState.compose env50407 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound50407 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50408 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4112,0,342,4097,2421,272,1,4160,32,16,3,348,64,2048,4097,4096,2421,69,32,257,32,4161,513]

theorem envBound50408 : H12AffineFastState.Bounded env50408 := by
  intro p hp
  have h : env50408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50407_50408 : H12AffineEnvironment.transform 15 342 env50407 = env50408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env50407 == env50408) = true)

def env50409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound50409 : H12AffineFastState.Bounded env50409 := by
  intro p hp
  have h : env50409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49938_50409 : H12AffineEnvironment.transform 26 30393345 env49938 = env50409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env49938 == env50409) = true)

def env50410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound50410 : H12AffineFastState.Bounded env50410 := by
  intro p hp
  have h : env50410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50409_50410 : H12AffineEnvironment.transform 18 1024 env50409 = env50410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env50409 == env50410) = true)

theorem identity50410 : scanCanonicalize (H12AffineFastState.compose env50410 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50410 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8192,64,29868033,18973701,10507601,8830977,25265169,23160137,256,27378725,27337992,25207631]

theorem envBound50411 : H12AffineFastState.Bounded env50411 := by
  intro p hp
  have h : env50411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50410_50411 : H12AffineEnvironment.transform 6 8 env50410 = env50411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50410 == env50411) = true)

def env50412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,16777216,8192,64,21331969,18973701,2233681,294913,17024017,23160137,256,19104805,19096840,16966479]

theorem envBound50412 : H12AffineFastState.Bounded env50412 := by
  intro p hp
  have h : env50412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50411_50412 : H12AffineEnvironment.transform 22 147456 env50411 = env50412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env50411 == env50412) = true)

def env50413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118977,294913,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound50413 : H12AffineFastState.Bounded env50413 := by
  intro p hp
  have h : env50413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50412_50413 : H12AffineEnvironment.transform 16 16400 env50412 = env50413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50412 == env50413) = true)

def env50414 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118709,294913,16876545,23159869,116,18990133,18949228,16818731]

theorem envBound50414 : H12AffineFastState.Bounded env50414 := by
  intro p hp
  have h : env50414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50413_50414 : H12AffineEnvironment.transform 7 116 env50413 = env50414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50413 == env50414) = true)

theorem identity50414 : scanCanonicalize (H12AffineFastState.compose env50414 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound50414 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env50415 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,16777216,8192,64,21331969,17066042,374794,294913,16876545,21268482,116,17049610,17090643,16818731]

theorem envBound50415 : H12AffineFastState.Bounded env50415 := by
  intro p hp
  have h : env50415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50414_50415 : H12AffineEnvironment.transform 20 388159 env50414 = env50415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env50414 == env50415) = true)

def env50416 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,351316,8192,64,4250709,78958,374794,294913,317525,4314198,116,95326,103431,392831]

theorem envBound50416 : H12AffineFastState.Bounded env50416 := by
  intro p hp
  have h : env50416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50416 : H12AffineEnvironment.transform 23 351316 env50415 = env50416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env50415 == env50416) = true)

theorem identity50416 : scanCanonicalize (H12AffineFastState.compose env50416 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound50416 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env50417 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,130174,1024,32769,4161,4194304,16,41002,8192,64,4250709,78958,17524,97407,74795,4314198,116,95326,103431,513]

theorem envBound50417 : H12AffineFastState.Bounded env50417 := by
  intro p hp
  have h : env50417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50416_50417 : H12AffineEnvironment.transform 17 130174 env50416 = env50417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env50416 == env50417) = true)

theorem identity50417 : scanCanonicalize (H12AffineFastState.compose env50417 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound50417 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env50418 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10280,1024,32769,4161,4194304,16,41002,8192,64,4250709,57400,17524,43049,61565,4194304,116,40968,16465,513]

theorem envBound50418 : H12AffineFastState.Bounded env50418 := by
  intro p hp
  have h : env50418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50417_50418 : H12AffineEnvironment.transform 15 54358 env50417 = env50418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env50417 == env50418) = true)

theorem identity50418 : scanCanonicalize (H12AffineFastState.compose env50418 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound50418 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env50419 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29709,8283,16400,10280,1024,29708,4161,4194304,16,21543,8192,64,4204632,5173,17524,23588,1136,4194304,116,21509,16465,513]

theorem envBound50419 : H12AffineFastState.Bounded env50419 := by
  intro p hp
  have h : env50419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50418_50419 : H12AffineEnvironment.transform 14 29709 env50418 = env50419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env50418 == env50419) = true)

theorem identity50419 : scanCanonicalize (H12AffineFastState.compose env50419 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound50419 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50420 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29709,8283,16400,10280,1024,29708,4161,29820,16,21543,8192,64,23588,5173,17524,23588,1136,29820,116,21509,16465,513]

theorem envBound50420 : H12AffineFastState.Bounded env50420 := by
  intro p hp
  have h : env50420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50419_50420 : H12AffineEnvironment.transform 21 29820 env50419 = env50420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env50419 == env50420) = true)

theorem identity50420 : scanCanonicalize (H12AffineFastState.compose env50420 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50420 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50421 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,21540,114,16400,2049,1024,21541,4161,21589,16,21543,41,64,23588,5173,17524,23588,1136,21589,116,21509,16465,513]

theorem envBound50421 : H12AffineFastState.Bounded env50421 := by
  intro p hp
  have h : env50421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50420_50421 : H12AffineEnvironment.transform 12 41 env50420 = env50421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50420 == env50421) = true)

theorem identity50421 : scanCanonicalize (H12AffineFastState.compose env50421 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50421 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50422 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21540,35,16400,2049,1024,21541,4112,21508,16,21543,41,17,23588,5173,17445,23588,1057,21508,37,21509,16384,513]

theorem envBound50422 : H12AffineFastState.Bounded env50422 := by
  intro p hp
  have h : env50422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50421_50422 : H12AffineEnvironment.transform 5 17 env50421 = env50422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50421 == env50422) = true)

theorem identity50422 : scanCanonicalize (H12AffineFastState.compose env50422 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50422 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50423 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,35,5172,2049,1024,1,4112,32,16,3,41,17,2048,5173,4097,2048,1057,32,37,33,5156,513]

theorem envBound50423 : H12AffineFastState.Bounded env50423 := by
  intro p hp
  have h : env50423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50422_50423 : H12AffineEnvironment.transform 13 5156 env50422 = env50423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50422 == env50423) = true)

theorem identity50423 : scanCanonicalize (H12AffineFastState.compose env50423 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50424 : List Nat := [2,4,8,0,32,1,8,37,512,1024,2048,4096,41,5156,0,35,5156,2049,1024,1,4096,32,0,3,41,1,2048,5157,4097,2048,1057,32,37,33,5156,513]

theorem envBound50424 : H12AffineFastState.Bounded env50424 := by
  intro p hp
  have h : env50424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50423_50424 : H12AffineEnvironment.transform 3 0 env50423 = env50424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50423 == env50424) = true)

theorem identity50424 : scanCanonicalize (H12AffineFastState.compose env50424 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound50424 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50425 : List Nat := [2,4,8,0,32,1,8,37,512,1024,2048,512,41,1572,0,35,1572,2049,1024,1,512,32,0,3,41,1,2048,1573,513,2048,1057,32,37,33,1572,513]

theorem envBound50425 : H12AffineFastState.Bounded env50425 := by
  intro p hp
  have h : env50425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50424_50425 : H12AffineEnvironment.transform 11 512 env50424 = env50425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env50424 == env50425) = true)

theorem identity50425 : scanCanonicalize (H12AffineFastState.compose env50425 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50425 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50426 : List Nat := [2,4,8,0,32,1,8,37,512,1024,1,512,41,1572,0,35,1572,0,1024,1,512,32,0,3,41,1,1,1573,513,1,1057,32,37,33,1572,513]

theorem envBound50426 : H12AffineFastState.Bounded env50426 := by
  intro p hp
  have h : env50426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50425_50426 : H12AffineEnvironment.transform 10 1 env50425 = env50426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50425 == env50426) = true)

theorem identity50426 : scanCanonicalize (H12AffineFastState.compose env50426 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound50426 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50427 : List Nat := [2,4,8,0,32,1,8,37,512,36,1,512,41,512,0,35,512,0,36,1,512,32,0,3,41,1,1,513,513,1,5,32,37,33,512,513]

theorem envBound50427 : H12AffineFastState.Bounded env50427 := by
  intro p hp
  have h : env50427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50426_50427 : H12AffineEnvironment.transform 9 36 env50426 = env50427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env50426 == env50427) = true)

theorem identity50427 : scanCanonicalize (H12AffineFastState.compose env50427 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound50427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50428 : List Nat := [2,4,8,0,32,1,8,37,33,36,1,33,41,33,0,35,33,0,36,1,33,32,0,3,41,1,1,32,32,1,5,32,37,33,33,32]

theorem envBound50428 : H12AffineFastState.Bounded env50428 := by
  intro p hp
  have h : env50428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50427_50428 : H12AffineEnvironment.transform 8 33 env50427 = env50428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env50427 == env50428) = true)

theorem identity50428 : scanCanonicalize (H12AffineFastState.compose env50428 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50429 : List Nat := [2,4,8,0,1,1,8,4,0,5,1,0,8,0,0,2,0,0,5,1,0,1,0,3,8,1,1,1,1,1,5,1,4,0,0,1]

theorem envBound50429 : H12AffineFastState.Bounded env50429 := by
  intro p hp
  have h : env50429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50428_50429 : H12AffineEnvironment.transform 4 1 env50428 = env50429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50428 == env50429) = true)

def env50430 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,351317,8192,64,4250708,78959,374794,294913,317524,4314199,116,95327,103430,392830]

theorem envBound50430 : H12AffineFastState.Bounded env50430 := by
  intro p hp
  have h : env50430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50430 : H12AffineEnvironment.transform 23 351317 env50415 = env50430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env50415 == env50430) = true)

def env50431 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,115735,4194304,16,95357,8192,64,4250708,78959,102434,43049,61564,4314199,116,95327,103430,120406]

theorem envBound50431 : H12AffineFastState.Bounded env50431 := by
  intro p hp
  have h : env50431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50430_50431 : H12AffineEnvironment.transform 17 10280 env50430 = env50431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50430 == env50431) = true)

theorem identity50431 : scanCanonicalize (H12AffineFastState.compose env50431 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound50431 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50432 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10280,1024,32769,4160,4194304,16,41002,8192,64,4250708,57400,17525,43049,61564,4194304,116,40968,16465,513]

theorem envBound50432 : H12AffineFastState.Bounded env50432 := by
  intro p hp
  have h : env50432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50431_50432 : H12AffineEnvironment.transform 15 54359 env50431 = env50432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env50431 == env50432) = true)

theorem identity50432 : scanCanonicalize (H12AffineFastState.compose env50432 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound50432 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env50433 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29708,8283,16400,10280,1024,29709,4160,4194304,16,21542,8192,64,4204632,5172,17525,23589,1136,4194304,116,21508,16465,513]

theorem envBound50433 : H12AffineFastState.Bounded env50433 := by
  intro p hp
  have h : env50433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50432_50433 : H12AffineEnvironment.transform 14 29708 env50432 = env50433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env50432 == env50433) = true)

theorem identity50433 : scanCanonicalize (H12AffineFastState.compose env50433 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound50433 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50434 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29708,8283,16400,10280,1024,29709,4160,29821,16,21542,8192,64,23589,5172,17525,23589,1136,29821,116,21508,16465,513]

theorem envBound50434 : H12AffineFastState.Bounded env50434 := by
  intro p hp
  have h : env50434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50433_50434 : H12AffineEnvironment.transform 21 29821 env50433 = env50434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env50433 == env50434) = true)

theorem identity50434 : scanCanonicalize (H12AffineFastState.compose env50434 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50434 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50435 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,21541,114,16400,2049,1024,21540,4160,21588,16,21542,41,64,23589,5172,17525,23589,1136,21588,116,21508,16465,513]

theorem envBound50435 : H12AffineFastState.Bounded env50435 := by
  intro p hp
  have h : env50435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50434_50435 : H12AffineEnvironment.transform 12 41 env50434 = env50435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50434 == env50435) = true)

theorem identity50435 : scanCanonicalize (H12AffineFastState.compose env50435 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50435 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50436 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21541,35,16400,2049,1024,21540,4113,21509,16,21542,41,17,23589,5172,17444,23589,1057,21509,37,21508,16384,513]

theorem envBound50436 : H12AffineFastState.Bounded env50436 := by
  intro p hp
  have h : env50436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50435_50436 : H12AffineEnvironment.transform 5 17 env50435 = env50436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50435 == env50436) = true)

theorem identity50436 : scanCanonicalize (H12AffineFastState.compose env50436 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound50436 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50437 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,35,5173,2049,1024,1,4113,32,16,3,41,17,2048,5172,4097,2048,1057,32,37,33,5157,513]

theorem envBound50437 : H12AffineFastState.Bounded env50437 := by
  intro p hp
  have h : env50437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50436_50437 : H12AffineEnvironment.transform 13 5157 env50436 = env50437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env50436 == env50437) = true)

theorem identity50437 : scanCanonicalize (H12AffineFastState.compose env50437 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50438 : List Nat := [2,4,8,1,32,0,8,37,512,1024,2048,4096,41,5157,0,35,5156,2049,1024,1,4096,32,1,3,41,0,2048,5157,4097,2048,1057,32,37,33,5157,513]

theorem envBound50438 : H12AffineFastState.Bounded env50438 := by
  intro p hp
  have h : env50438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50437_50438 : H12AffineEnvironment.transform 3 1 env50437 = env50438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50437 == env50438) = true)

theorem identity50438 : scanCanonicalize (H12AffineFastState.compose env50438 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound50438 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50439 : List Nat := [2,4,8,1,32,0,8,37,512,1024,2048,512,41,1573,0,35,1572,2049,1024,1,512,32,1,3,41,0,2048,1573,513,2048,1057,32,37,33,1573,513]

theorem envBound50439 : H12AffineFastState.Bounded env50439 := by
  intro p hp
  have h : env50439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50438_50439 : H12AffineEnvironment.transform 11 512 env50438 = env50439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env50438 == env50439) = true)

theorem identity50439 : scanCanonicalize (H12AffineFastState.compose env50439 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50439 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50440 : List Nat := [2,4,8,1,32,0,8,37,512,1024,1,512,41,1573,0,35,1572,0,1024,1,512,32,1,3,41,0,1,1573,513,1,1057,32,37,33,1573,513]

theorem envBound50440 : H12AffineFastState.Bounded env50440 := by
  intro p hp
  have h : env50440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50439_50440 : H12AffineEnvironment.transform 10 1 env50439 = env50440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50439 == env50440) = true)

theorem identity50440 : scanCanonicalize (H12AffineFastState.compose env50440 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound50440 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50441 : List Nat := [2,4,8,1,32,0,8,37,512,36,1,512,41,513,0,35,512,0,36,1,512,32,1,3,41,0,1,513,513,1,5,32,37,33,513,513]

theorem envBound50441 : H12AffineFastState.Bounded env50441 := by
  intro p hp
  have h : env50441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50440_50441 : H12AffineEnvironment.transform 9 36 env50440 = env50441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env50440 == env50441) = true)

theorem identity50441 : scanCanonicalize (H12AffineFastState.compose env50441 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound50441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50442 : List Nat := [2,4,8,1,32,0,8,37,33,36,1,33,41,32,0,35,33,0,36,1,33,32,1,3,41,0,1,32,32,1,5,32,37,33,32,32]

theorem envBound50442 : H12AffineFastState.Bounded env50442 := by
  intro p hp
  have h : env50442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50441_50442 : H12AffineEnvironment.transform 8 33 env50441 = env50442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env50441 == env50442) = true)

theorem identity50442 : scanCanonicalize (H12AffineFastState.compose env50442 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50442 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env50443 : List Nat := [2,4,8,1,0,0,8,5,1,4,1,1,9,0,0,3,1,0,4,1,1,0,1,3,9,0,1,0,0,1,5,0,5,1,0,0]

theorem envBound50443 : H12AffineFastState.Bounded env50443 := by
  intro p hp
  have h : env50443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50442_50443 : H12AffineEnvironment.transform 4 0 env50442 = env50443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50442 == env50443) = true)

def env50444 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,115734,4194304,16,95356,8192,64,4250708,78959,102435,43048,61565,4314199,116,95327,103430,120407]

theorem envBound50444 : H12AffineFastState.Bounded env50444 := by
  intro p hp
  have h : env50444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50430_50444 : H12AffineEnvironment.transform 17 10281 env50430 = env50444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50430 == env50444) = true)

theorem identity50444 : scanCanonicalize (H12AffineFastState.compose env50444 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50444 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50445 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,58397,4194304,16,21623,8192,64,4250708,5220,45096,43048,61565,4256860,116,21588,46093,63068]

theorem envBound50445 : H12AffineFastState.Bounded env50445 := by
  intro p hp
  have h : env50445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50444_50445 : H12AffineEnvironment.transform 15 8203 env50444 = env50445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50444 == env50445) = true)

theorem identity50445 : scanCanonicalize (H12AffineFastState.compose env50445 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50445 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env50446 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,8203,16400,10281,1024,29789,4161,4194304,16,21623,8192,64,4204552,5220,17524,23668,1057,4194304,116,21588,16465,512]

theorem envBound50446 : H12AffineFastState.Bounded env50446 := by
  intro p hp
  have h : env50446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50445_50446 : H12AffineEnvironment.transform 14 29788 env50445 = env50446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50445 == env50446) = true)

theorem identity50446 : scanCanonicalize (H12AffineFastState.compose env50446 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50446 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50447 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28728,8203,16400,10281,100,28729,4161,4194304,16,20499,8192,64,4204552,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound50447 : H12AffineFastState.Bounded env50447 := by
  intro p hp
  have h : env50447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50446_50447 : H12AffineEnvironment.transform 9 100 env50446 = env50447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50446 == env50447) = true)

theorem identity50447 : scanCanonicalize (H12AffineFastState.compose env50447 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(21+1) ^^^ 18513) := by decide +kernel

theorem selectedBound50447 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env50448 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28728,8203,16400,10281,100,28729,4161,18513,16,20499,8192,64,24665,4096,16400,22544,69,18513,116,20528,16465,512]

theorem envBound50448 : H12AffineFastState.Bounded env50448 := by
  intro p hp
  have h : env50448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50447_50448 : H12AffineEnvironment.transform 21 18513 env50447 = env50448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 18513 env50447 == env50448) = true)

theorem identity50448 : scanCanonicalize (H12AffineFastState.compose env50448 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound50448 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env50449 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,2129,14441,8203,2113,10281,100,14440,4161,0,16,6210,8192,64,10248,4096,2113,4161,69,0,116,6241,2048,512]

theorem envBound50449 : H12AffineFastState.Bounded env50449 := by
  intro p hp
  have h : env50449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50448_50449 : H12AffineEnvironment.transform 13 2129 env50448 = env50449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env50448 == env50449) = true)

theorem identity50449 : scanCanonicalize (H12AffineFastState.compose env50449 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound50449 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50450 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,6248,2129,1,6243,2113,4161,100,0,4161,0,16,6210,6248,64,4192,4096,2113,4161,69,0,116,6241,2048,512]

theorem envBound50450 : H12AffineFastState.Bounded env50450 := by
  intro p hp
  have h : env50450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50449_50450 : H12AffineEnvironment.transform 12 6248 env50449 = env50450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env50449 == env50450) = true)

theorem identity50450 : scanCanonicalize (H12AffineFastState.compose env50450 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound50450 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env50451 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2096,88,2129,1,83,2113,2161,100,0,2161,0,16,114,88,64,2128,2096,2113,2161,69,0,116,81,2048,512]

theorem envBound50451 : H12AffineFastState.Bounded env50451 := by
  intro p hp
  have h : env50451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50450_50451 : H12AffineEnvironment.transform 11 2096 env50450 = env50451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env50450 == env50451) = true)

theorem identity50451 : scanCanonicalize (H12AffineFastState.compose env50451 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50451 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50452 : List Nat := [2,4,8,16,0,64,8,84,512,68,2048,2064,88,2129,1,83,2113,2129,68,0,2129,0,16,82,88,64,2128,2064,2113,2129,69,0,84,81,2048,512]

theorem envBound50452 : H12AffineFastState.Bounded env50452 := by
  intro p hp
  have h : env50452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50451_50452 : H12AffineEnvironment.transform 4 0 env50451 = env50452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50451 == env50452) = true)

theorem identity50452 : scanCanonicalize (H12AffineFastState.compose env50452 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50453 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2064,8,2049,1,3,2065,2049,20,0,2049,0,16,2,8,16,2048,2064,2065,2049,21,0,4,1,2048,512]

theorem envBound50453 : H12AffineFastState.Bounded env50453 := by
  intro p hp
  have h : env50453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50452_50453 : H12AffineEnvironment.transform 5 16 env50452 = env50453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50452 == env50453) = true)

theorem identity50453 : scanCanonicalize (H12AffineFastState.compose env50453 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50454 : List Nat := [2,4,8,16,0,16,8,4,1,20,2048,2064,8,2049,1,3,2065,2049,20,0,2049,0,16,2,8,16,2048,2064,2065,2049,21,0,4,1,2048,1]

theorem envBound50454 : H12AffineFastState.Bounded env50454 := by
  intro p hp
  have h : env50454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50453_50454 : H12AffineEnvironment.transform 8 1 env50453 = env50454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50453 == env50454) = true)

theorem identity50454 : scanCanonicalize (H12AffineFastState.compose env50454 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound50454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50455 : List Nat := [2,4,8,16,0,16,8,4,1,20,30,14,8,31,1,3,15,31,20,0,31,0,16,2,8,16,30,14,15,31,21,0,4,1,30,1]

theorem envBound50455 : H12AffineFastState.Bounded env50455 := by
  intro p hp
  have h : env50455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50454_50455 : H12AffineEnvironment.transform 10 30 env50454 = env50455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env50454 == env50455) = true)

def leafEnv50455 : List Nat := [2,4,8,16,0,16,8,4,1,20,30,14,8,31,1,3,15,31,20,0,31,0,16,2,21,8,1,16,30,14,15,31,21,0,4,1,4,3,30,1,1,30,0]

def active50455 : List Nat := [0,1,2,3]

def tree50455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50455 : H12WitnessSearch.Good tree50455 := H12GlobalWitnessIndex.good

theorem leafIdentity50455 : H12AffineFastState.composeSystem env50455 rootObs = leafEnv50455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50455 rootObs == leafEnv50455) = true)

theorem terminalChecked50455 : H12PackedTerminal.terminalCheckFast leafEnv50455 active50455 tree50455 = true := by decide +kernel

def env50456 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118708,294913,16876545,23159868,117,18990133,18949229,16818730]

theorem envBound50456 : H12AffineFastState.Bounded env50456 := by
  intro p hp
  have h : env50456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50413_50456 : H12AffineEnvironment.transform 7 117 env50413 = env50456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50413 == env50456) = true)

theorem identity50456 : scanCanonicalize (H12AffineFastState.compose env50456 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444308) := by decide +kernel

theorem selectedBound50456 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env50457 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2444308,8192,64,6343701,313361,2118708,294913,2410517,4466728,117,296993,288889,2485822]

theorem envBound50457 : H12AffineFastState.Bounded env50457 := by
  intro p hp
  have h : env50457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50456_50457 : H12AffineEnvironment.transform 23 2444308 env50456 = env50457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444308 env50456 == env50457) = true)

def env50458 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,2097152,4194304,16,2199648,8192,64,6343701,5221,2118708,23669,2102369,4256860,117,21589,46093,2175562]

theorem envBound50458 : H12AffineFastState.Bounded env50458 := by
  intro p hp
  have h : env50458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50457_50458 : H12AffineEnvironment.transform 17 56436 env50457 = env50458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env50457 == env50458) = true)

theorem identity50458 : scanCanonicalize (H12AffineFastState.compose env50458 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound50458 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env50459 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,77899,4194304,16,41003,8192,64,4324446,5221,91263,23669,74794,4256860,117,21589,46093,513]

theorem envBound50459 : H12AffineFastState.Bounded env50459 := by
  intro p hp
  have h : env50459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50458_50459 : H12AffineEnvironment.transform 20 77899 env50458 = env50459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env50458 == env50459) = true)

theorem identity50459 : scanCanonicalize (H12AffineFastState.compose env50459 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50459 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env50460 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,65536,16400,10280,1024,29789,77899,4194304,16,21623,8192,64,4261890,5221,91263,23669,74794,4194304,117,21589,16465,513]

theorem envBound50460 : H12AffineFastState.Bounded env50460 := by
  intro p hp
  have h : env50460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50459_50460 : H12AffineEnvironment.transform 14 29788 env50459 = env50460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50459 == env50460) = true)

theorem identity50460 : scanCanonicalize (H12AffineFastState.compose env50460 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound50460 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env50461 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,8283,16400,10280,1024,29789,4112,4194304,16,21623,8192,64,4204633,5221,17444,23669,1137,4194304,117,21589,16465,513]

theorem envBound50461 : H12AffineFastState.Bounded env50461 := by
  intro p hp
  have h : env50461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50460_50461 : H12AffineEnvironment.transform 15 8283 env50460 = env50461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env50460 == env50461) = true)

theorem identity50461 : scanCanonicalize (H12AffineFastState.compose env50461 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound50461 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50462 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,8283,16400,10280,1024,29789,4112,29741,16,21623,8192,64,23668,5221,17444,23669,1137,29741,117,21589,16465,513]

theorem envBound50462 : H12AffineFastState.Bounded env50462 := by
  intro p hp
  have h : env50462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50461_50462 : H12AffineEnvironment.transform 21 29741 env50461 = env50462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env50461 == env50462) = true)

theorem identity50462 : scanCanonicalize (H12AffineFastState.compose env50462 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50462 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50463 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21620,115,16400,2048,1024,21621,4112,21509,16,21623,40,64,23668,5221,17444,23669,1137,21509,117,21589,16465,513]

theorem envBound50463 : H12AffineFastState.Bounded env50463 := by
  intro p hp
  have h : env50463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50462_50463 : H12AffineEnvironment.transform 12 40 env50462 = env50463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50462 == env50463) = true)

theorem identity50463 : scanCanonicalize (H12AffineFastState.compose env50463 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50463 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50464 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,16384,21541,34,16400,2048,1024,21540,4112,21509,16,21542,40,17,23589,5172,17444,23588,1056,21509,36,21508,16384,513]

theorem envBound50464 : H12AffineFastState.Bounded env50464 := by
  intro p hp
  have h : env50464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50463_50464 : H12AffineEnvironment.transform 5 17 env50463 = env50464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50463 == env50464) = true)

theorem identity50464 : scanCanonicalize (H12AffineFastState.compose env50464 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound50464 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50465 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,34,5173,2048,1024,1,4112,32,16,3,40,17,2048,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound50465 : H12AffineFastState.Bounded env50465 := by
  intro p hp
  have h : env50465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50464_50465 : H12AffineEnvironment.transform 13 5157 env50464 = env50465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env50464 == env50465) = true)

theorem identity50465 : scanCanonicalize (H12AffineFastState.compose env50465 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50466 : List Nat := [2,4,8,1,32,0,8,36,512,1024,2048,4096,40,5157,0,34,5156,2048,1024,1,4097,32,1,3,40,0,2048,5157,4097,2049,1056,32,36,33,5157,513]

theorem envBound50466 : H12AffineFastState.Bounded env50466 := by
  intro p hp
  have h : env50466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50465_50466 : H12AffineEnvironment.transform 3 1 env50465 = env50466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50465 == env50466) = true)

theorem identity50466 : scanCanonicalize (H12AffineFastState.compose env50466 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound50466 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50467 : List Nat := [2,4,8,1,32,0,8,36,512,1024,2048,512,40,1573,0,34,1572,2048,1024,1,513,32,1,3,40,0,2048,1573,513,2049,1056,32,36,33,1573,513]

theorem envBound50467 : H12AffineFastState.Bounded env50467 := by
  intro p hp
  have h : env50467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50466_50467 : H12AffineEnvironment.transform 11 512 env50466 = env50467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env50466 == env50467) = true)

theorem identity50467 : scanCanonicalize (H12AffineFastState.compose env50467 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50467 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50468 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1,512,40,1573,0,34,1572,1,1024,1,513,32,1,3,40,0,1,1573,513,0,1056,32,36,33,1573,513]

theorem envBound50468 : H12AffineFastState.Bounded env50468 := by
  intro p hp
  have h : env50468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50467_50468 : H12AffineEnvironment.transform 10 1 env50467 = env50468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50467 == env50468) = true)

theorem identity50468 : scanCanonicalize (H12AffineFastState.compose env50468 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound50468 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50469 : List Nat := [2,4,8,1,32,0,8,36,512,36,1,512,40,513,0,34,512,1,36,1,513,32,1,3,40,0,1,513,513,0,4,32,36,33,513,513]

theorem envBound50469 : H12AffineFastState.Bounded env50469 := by
  intro p hp
  have h : env50469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50468_50469 : H12AffineEnvironment.transform 9 36 env50468 = env50469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env50468 == env50469) = true)

theorem identity50469 : scanCanonicalize (H12AffineFastState.compose env50469 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50470 : List Nat := [2,4,8,1,0,0,8,4,512,4,1,512,8,513,0,2,512,1,4,1,513,0,1,3,8,0,1,513,513,0,4,0,4,1,513,513]

theorem envBound50470 : H12AffineFastState.Bounded env50470 := by
  intro p hp
  have h : env50470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50469_50470 : H12AffineEnvironment.transform 4 0 env50469 = env50470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50469 == env50470) = true)

theorem identity50470 : scanCanonicalize (H12AffineFastState.compose env50470 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50471 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,1,8,0,0,2,1,1,4,1,0,0,1,3,8,0,1,0,0,0,4,0,4,1,0,0]

theorem envBound50471 : H12AffineFastState.Bounded env50471 := by
  intro p hp
  have h : env50471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50470_50471 : H12AffineEnvironment.transform 8 1 env50470 = env50471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50470 == env50471) = true)

def env50472 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,2097152,4194304,16,2199649,8192,64,6343701,5220,2118708,23668,2102368,4256861,117,21588,46092,2175563]

theorem envBound50472 : H12AffineFastState.Bounded env50472 := by
  intro p hp
  have h : env50472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50457_50472 : H12AffineEnvironment.transform 17 56437 env50457 = env50472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env50457 == env50472) = true)

def env50473 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,4160,4194304,16,98337,8192,64,4250709,5220,17524,23668,1056,4256861,117,21588,46092,74251]

theorem envBound50473 : H12AffineFastState.Bounded env50473 := by
  intro p hp
  have h : env50473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50472_50473 : H12AffineEnvironment.transform 20 4160 env50472 = env50473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50472 == env50473) = true)

theorem identity50473 : scanCanonicalize (H12AffineFastState.compose env50473 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound50473 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50474 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,16400,56437,1024,32769,4160,4194304,16,21622,8192,64,4250709,5220,17524,23668,1056,4256861,117,21588,46092,63068]

theorem envBound50474 : H12AffineFastState.Bounded env50474 := by
  intro p hp
  have h : env50474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50473_50474 : H12AffineEnvironment.transform 15 54359 env50473 = env50474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env50473 == env50474) = true)

theorem identity50474 : scanCanonicalize (H12AffineFastState.compose env50474 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 41049) := by decide +kernel

theorem selectedBound50474 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env50475 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,16400,56437,1024,32769,4160,41049,16,21622,8192,64,31756,5220,17524,23668,1056,21508,117,21588,46092,63068]

theorem envBound50475 : H12AffineFastState.Bounded env50475 := by
  intro p hp
  have h : env50475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50474_50475 : H12AffineEnvironment.transform 21 41049 env50474 = env50475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41049 env50474 == env50475) = true)

theorem identity50475 : scanCanonicalize (H12AffineFastState.compose env50475 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50475 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env50476 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,32768,40970,13389,43048,1024,32769,4160,41049,16,8235,8192,64,2129,5220,12329,10281,1056,8281,117,8201,46092,33281]

theorem envBound50476 : H12AffineFastState.Bounded env50476 := by
  intro p hp
  have h : env50476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50475_50476 : H12AffineEnvironment.transform 13 13405 env50475 = env50476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50475 == env50476) = true)

theorem identity50476 : scanCanonicalize (H12AffineFastState.compose env50476 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50476 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50477 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,32768,32802,5221,34816,1024,32769,4160,32881,16,3,40,64,2129,5220,4097,2049,1056,113,117,33,37924,33281]

theorem envBound50477 : H12AffineFastState.Bounded env50477 := by
  intro p hp
  have h : env50477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50476_50477 : H12AffineEnvironment.transform 12 40 env50476 = env50477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50476 == env50477) = true)

theorem identity50477 : scanCanonicalize (H12AffineFastState.compose env50477 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50477 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50478 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,34,5221,2048,1024,1,4160,113,16,3,40,64,2129,5220,4097,2049,1056,113,117,33,5156,513]

theorem envBound50478 : H12AffineFastState.Bounded env50478 := by
  intro p hp
  have h : env50478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50477_50478 : H12AffineEnvironment.transform 14 0 env50477 = env50478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50477 == env50478) = true)

theorem identity50478 : scanCanonicalize (H12AffineFastState.compose env50478 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound50478 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50479 : List Nat := [2,4,8,16,32,64,8,117,512,1024,513,4096,40,5237,0,34,5221,513,1024,1,4160,113,16,3,40,64,592,5220,4097,512,1056,113,117,33,5156,513]

theorem envBound50479 : H12AffineFastState.Bounded env50479 := by
  intro p hp
  have h : env50479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50478_50479 : H12AffineEnvironment.transform 10 513 env50478 = env50479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env50478 == env50479) = true)

theorem identity50479 : scanCanonicalize (H12AffineFastState.compose env50479 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound50479 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env50480 : List Nat := [2,4,8,16,32,64,8,117,512,612,513,4096,40,4625,0,34,4609,513,612,1,4160,113,16,3,40,64,592,4608,4097,512,580,113,117,33,4672,513]

theorem envBound50480 : H12AffineFastState.Bounded env50480 := by
  intro p hp
  have h : env50480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50479_50480 : H12AffineEnvironment.transform 9 612 env50479 = env50480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env50479 == env50480) = true)

theorem identity50480 : scanCanonicalize (H12AffineFastState.compose env50480 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50480 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50481 : List Nat := [2,4,8,16,32,64,8,117,512,612,513,16,40,513,0,34,529,513,612,1,80,113,16,3,40,64,592,528,17,512,580,113,117,33,592,513]

theorem envBound50481 : H12AffineFastState.Bounded env50481 := by
  intro p hp
  have h : env50481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50480_50481 : H12AffineEnvironment.transform 11 16 env50480 = env50481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50480 == env50481) = true)

theorem identity50481 : scanCanonicalize (H12AffineFastState.compose env50481 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound50481 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50482 : List Nat := [2,4,8,16,32,64,8,117,81,53,80,16,40,80,0,34,64,80,53,1,80,113,16,3,40,64,1,65,17,81,21,113,117,33,1,80]

theorem envBound50482 : H12AffineFastState.Bounded env50482 := by
  intro p hp
  have h : env50482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50481_50482 : H12AffineEnvironment.transform 8 81 env50481 = env50482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env50481 == env50482) = true)

theorem identity50482 : scanCanonicalize (H12AffineFastState.compose env50482 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50483 : List Nat := [2,4,8,16,32,0,8,53,17,53,16,16,40,16,0,34,0,16,53,1,16,49,16,3,40,0,1,1,17,17,21,49,53,33,1,16]

theorem envBound50483 : H12AffineFastState.Bounded env50483 := by
  intro p hp
  have h : env50483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50482_50483 : H12AffineEnvironment.transform 5 0 env50482 = env50483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50482 == env50483) = true)

def env50484 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,4161,4194304,16,98336,8192,64,4250708,5220,17525,23668,1057,4256861,117,21588,46092,74250]

theorem envBound50484 : H12AffineFastState.Bounded env50484 := by
  intro p hp
  have h : env50484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50472_50484 : H12AffineEnvironment.transform 20 4161 env50472 = env50484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50472 == env50484) = true)

theorem identity50484 : scanCanonicalize (H12AffineFastState.compose env50484 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50484 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50485 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1024,32769,4161,4194304,16,41003,8192,64,4250708,5220,17525,23668,1057,4256861,117,21588,46092,513]

theorem envBound50485 : H12AffineFastState.Bounded env50485 := by
  intro p hp
  have h : env50485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50484_50485 : H12AffineEnvironment.transform 15 8203 env50484 = env50485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50484 == env50485) = true)

theorem identity50485 : scanCanonicalize (H12AffineFastState.compose env50485 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound50485 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50486 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34816,1024,32769,4161,4194304,16,41003,8192,64,4229153,5220,4096,2049,1057,4235304,117,33,46092,513]

theorem envBound50486 : H12AffineFastState.Bounded env50486 := by
  intro p hp
  have h : env50486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50485_50486 : H12AffineEnvironment.transform 13 5237 env50485 = env50486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env50485 == env50486) = true)

theorem identity50486 : scanCanonicalize (H12AffineFastState.compose env50486 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 3103) := by decide +kernel

theorem selectedBound50486 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env50487 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34816,1024,32769,4161,3103,16,41003,8192,64,33854,5220,4096,2049,1057,44087,117,33,46092,513]

theorem envBound50487 : H12AffineFastState.Bounded env50487 := by
  intro p hp
  have h : env50487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50486_50487 : H12AffineEnvironment.transform 21 3103 env50486 = env50487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3103 env50486 == env50487) = true)

theorem identity50487 : scanCanonicalize (H12AffineFastState.compose env50487 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50487 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env50488 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,32768,35,5221,34816,1024,32769,4161,3103,16,32771,40,64,33854,5220,4096,2049,1057,35871,117,33,37924,513]

theorem envBound50488 : H12AffineFastState.Bounded env50488 := by
  intro p hp
  have h : env50488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50487_50488 : H12AffineEnvironment.transform 12 40 env50487 = env50488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50487 == env50488) = true)

theorem identity50488 : scanCanonicalize (H12AffineFastState.compose env50488 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound50488 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50489 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5237,32768,35,5221,33902,1024,32769,4161,113,16,32771,40,64,33854,5220,4096,1135,1057,32881,117,33,37924,513]

theorem envBound50489 : H12AffineFastState.Bounded env50489 := by
  intro p hp
  have h : env50489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50488_50489 : H12AffineEnvironment.transform 10 1134 env50488 = env50489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env50488 == env50489) = true)

theorem identity50489 : scanCanonicalize (H12AffineFastState.compose env50489 (packedSelected [0,4,5,7,8,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50489 : packedSelected [0,4,5,7,8,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50490 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5237,1,35,5221,1135,1024,0,4161,113,16,2,40,64,1087,5220,4096,1135,1057,112,117,33,5157,513]

theorem envBound50490 : H12AffineFastState.Bounded env50490 := by
  intro p hp
  have h : env50490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50489_50490 : H12AffineEnvironment.transform 14 1 env50489 = env50490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50489 == env50490) = true)

theorem identity50490 : scanCanonicalize (H12AffineFastState.compose env50490 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50490 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50491 : List Nat := [2,4,8,16,32,64,8,117,512,101,11,4096,40,4112,1,35,4096,10,101,0,4161,113,16,2,40,64,90,4097,4096,10,68,112,117,33,4160,513]

theorem envBound50491 : H12AffineFastState.Bounded env50491 := by
  intro p hp
  have h : env50491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50490_50491 : H12AffineEnvironment.transform 9 101 env50490 = env50491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50490 == env50491) = true)

theorem identity50491 : scanCanonicalize (H12AffineFastState.compose env50491 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 69) := by decide +kernel

theorem selectedBound50491 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50492 : List Nat := [2,4,8,16,32,64,8,117,69,101,11,4096,40,4112,1,35,4096,10,101,0,4161,113,16,2,40,64,90,4097,4096,10,68,112,117,33,4160,68]

theorem envBound50492 : H12AffineFastState.Bounded env50492 := by
  intro p hp
  have h : env50492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50491_50492 : H12AffineEnvironment.transform 8 69 env50491 = env50492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 69 env50491 == env50492) = true)

theorem identity50492 : scanCanonicalize (H12AffineFastState.compose env50492 (packedSelected [0,1,7] rootPS)) = affineNative (2^(11+1) ^^^ 93) := by decide +kernel

theorem selectedBound50492 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env50493 : List Nat := [2,4,8,16,32,64,8,117,69,101,11,93,40,77,1,35,93,10,101,0,28,113,16,2,40,64,90,92,93,10,68,112,117,33,29,68]

theorem envBound50493 : H12AffineFastState.Bounded env50493 := by
  intro p hp
  have h : env50493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50492_50493 : H12AffineEnvironment.transform 11 93 env50492 = env50493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 93 env50492 == env50493) = true)

theorem identity50493 : scanCanonicalize (H12AffineFastState.compose env50493 (packedSelected [1,9] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound50493 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env50494 : List Nat := [2,4,8,16,32,29,8,40,24,56,11,0,40,16,1,35,0,10,56,0,28,44,16,2,40,29,7,1,0,10,25,45,40,33,29,25]

theorem envBound50494 : H12AffineFastState.Bounded env50494 := by
  intro p hp
  have h : env50494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50493_50494 : H12AffineEnvironment.transform 5 29 env50493 = env50494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env50493 == env50494) = true)

theorem identity50494 : scanCanonicalize (H12AffineFastState.compose env50494 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50494 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50495 : List Nat := [2,4,8,16,0,29,8,8,24,24,11,0,8,16,1,3,0,10,24,0,28,12,16,2,8,29,7,1,0,10,25,13,8,1,29,25]

theorem envBound50495 : H12AffineFastState.Bounded env50495 := by
  intro p hp
  have h : env50495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50494_50495 : H12AffineEnvironment.transform 4 0 env50494 = env50495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50494 == env50495) = true)

theorem identity50495 : scanCanonicalize (H12AffineFastState.compose env50495 (packedSelected [1,11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50495 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env50496 : List Nat := [2,4,3,16,0,22,3,3,19,19,0,0,3,16,1,3,0,1,19,0,23,7,16,2,3,22,7,1,0,1,18,6,3,1,22,18]

theorem envBound50496 : H12AffineFastState.Bounded env50496 := by
  intro p hp
  have h : env50496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50495_50496 : H12AffineEnvironment.transform 2 3 env50495 = env50496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50495 == env50496) = true)

theorem identity50496 : scanCanonicalize (H12AffineFastState.compose env50496 (packedSelected [3,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50496 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env50497 : List Nat := [2,4,3,1,0,7,3,3,2,2,0,0,3,1,1,3,0,1,2,0,6,7,1,2,3,7,7,1,0,1,3,6,3,1,7,3]

theorem envBound50497 : H12AffineFastState.Bounded env50497 := by
  intro p hp
  have h : env50497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50496_50497 : H12AffineEnvironment.transform 3 1 env50496 = env50497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50496 == env50497) = true)

def env50498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,17,16777216,8192,64,21331969,18973701,2118976,294913,16876544,23160137,256,18990132,18949401,16819038]

theorem envBound50498 : H12AffineFastState.Bounded env50498 := by
  intro p hp
  have h : env50498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50412_50498 : H12AffineEnvironment.transform 16 16401 env50412 = env50498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50412 == env50498) = true)

theorem identity50498 : scanCanonicalize (H12AffineFastState.compose env50498 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50498 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env50499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080105,18973701,2118976,43049,16876544,23160137,256,18990132,18949401,16819038]

theorem envBound50499 : H12AffineFastState.Bounded env50499 := by
  intro p hp
  have h : env50499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50498_50499 : H12AffineEnvironment.transform 17 10280 env50498 = env50499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50498 == env50499) = true)

def env50500 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080105,18973701,2118708,43049,16876544,23159869,116,18990132,18949229,16818730]

theorem envBound50500 : H12AffineFastState.Bounded env50500 := by
  intro p hp
  have h : env50500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50499_50500 : H12AffineEnvironment.transform 7 116 env50499 = env50500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50499 == env50500) = true)

theorem identity50500 : scanCanonicalize (H12AffineFastState.compose env50500 (packedSelected [3,4,9,10,14,16,17,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 2212919) := by decide +kernel

theorem selectedBound50500 : packedSelected [3,4,9,10,14,16,17,24,26] rootPS < 2^1333 := by decide +kernel

def env50501 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,2212919,17,16777216,8192,64,18902046,18973701,2118708,43049,16876544,16818186,116,18990132,18949229,16818730]

theorem envBound50501 : H12AffineFastState.Bounded env50501 := by
  intro p hp
  have h : env50501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50500_50501 : H12AffineEnvironment.transform 21 2212919 env50500 = env50501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2212919 env50500 == env50501) = true)

theorem identity50501 : scanCanonicalize (H12AffineFastState.compose env50501 (packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50501 : packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env50502 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,2155580,17,16777216,8192,64,18902046,18916366,2118708,43049,16819211,16818186,116,18932799,18875494,16818730]

theorem envBound50502 : H12AffineFastState.Bounded env50502 := by
  intro p hp
  have h : env50502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50501_50502 : H12AffineEnvironment.transform 15 8203 env50501 = env50502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50501 == env50502) = true)

theorem identity50502 : scanCanonicalize (H12AffineFastState.compose env50502 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 2155598) := by decide +kernel

theorem selectedBound50502 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env50503 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,2155580,17,2155598,8192,64,34896,16448,2118708,43049,2113605,2114628,116,113,57384,2115172]

theorem envBound50503 : H12AffineFastState.Bounded env50503 := by
  intro p hp
  have h : env50503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50502_50503 : H12AffineEnvironment.transform 23 2155598 env50502 = env50503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155598 env50502 == env50503) = true)

theorem identity50503 : scanCanonicalize (H12AffineFastState.compose env50503 (packedSelected [0,1,2,5,6,7,8,11,16,17,18,24] rootPS)) = affineNative (2^(20+1) ^^^ 58444) := by decide +kernel

theorem selectedBound50503 : packedSelected [0,1,2,5,6,7,8,11,16,17,18,24] rootPS < 2^1333 := by decide +kernel

def env50504 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,58444,112,17,2,8192,64,34896,16448,45176,43049,41993,40968,116,113,57384,41512]

theorem envBound50504 : H12AffineFastState.Bounded env50504 := by
  intro p hp
  have h : env50504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50503_50504 : H12AffineEnvironment.transform 20 58444 env50503 = env50504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58444 env50503 == env50504) = true)

theorem identity50504 : scanCanonicalize (H12AffineFastState.compose env50504 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50504 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50505 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,0,8203,16401,10280,1024,1,25676,112,17,2,8192,64,2128,16448,12408,10281,9225,8200,116,113,24616,8744]

theorem envBound50505 : H12AffineFastState.Bounded env50505 := by
  intro p hp
  have h : env50505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50504_50505 : H12AffineEnvironment.transform 14 0 env50504 = env50505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50504 == env50505) = true)

def env50506 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080105,18973701,2118709,43049,16876544,23159868,117,18990132,18949228,16818731]

theorem envBound50506 : H12AffineFastState.Bounded env50506 := by
  intro p hp
  have h : env50506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50499_50506 : H12AffineEnvironment.transform 7 117 env50499 = env50506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50499 == env50506) = true)

theorem identity50506 : scanCanonicalize (H12AffineFastState.compose env50506 (packedSelected [3,4,9,10,14,16,17,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 6382621) := by decide +kernel

theorem selectedBound50506 : packedSelected [3,4,9,10,14,16,17,24,26] rootPS < 2^1333 := by decide +kernel

def env50507 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,6382621,8192,64,2149428,4251672,2118709,43049,6348829,33,117,4235305,4210801,6407734]

theorem envBound50507 : H12AffineFastState.Bounded env50507 := by
  intro p hp
  have h : env50507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50506_50507 : H12AffineEnvironment.transform 23 6382621 env50506 = env50507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6382621 env50506 == env50507) = true)

theorem identity50507 : scanCanonicalize (H12AffineFastState.compose env50507 (packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50507 : packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env50508 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,4194304,17,6308886,8192,64,2149428,4251672,2118709,43049,6348829,33,117,4235305,4210801,6350397]

theorem envBound50508 : H12AffineFastState.Bounded env50508 := by
  intro p hp
  have h : env50508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50507_50508 : H12AffineEnvironment.transform 15 8203 env50507 = env50508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50507 == env50508) = true)

theorem identity50508 : scanCanonicalize (H12AffineFastState.compose env50508 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41048) := by decide +kernel

theorem selectedBound50508 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env50509 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,41048,17,2155598,8192,64,2149428,16448,2118709,43049,2113605,33,117,113,57385,2115173]

theorem envBound50509 : H12AffineFastState.Bounded env50509 := by
  intro p hp
  have h : env50509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50508_50509 : H12AffineEnvironment.transform 21 41048 env50508 = env50509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41048 env50508 == env50509) = true)

theorem identity50509 : scanCanonicalize (H12AffineFastState.compose env50509 (packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS)) = affineNative (2^(20+1) ^^^ 58444) := by decide +kernel

theorem selectedBound50509 : packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS < 2^1333 := by decide +kernel

def env50510 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,58444,41048,17,2,8192,64,10360,16448,45177,43049,41993,33,117,113,57385,41513]

theorem envBound50510 : H12AffineFastState.Bounded env50510 := by
  intro p hp
  have h : env50510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50509_50510 : H12AffineEnvironment.transform 20 58444 env50509 = env50510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58444 env50509 == env50510) = true)

theorem identity50510 : scanCanonicalize (H12AffineFastState.compose env50510 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50510 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50511 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,0,8203,16401,10280,1024,1,25676,8280,17,2,8192,64,10360,16448,12409,10281,9225,33,117,113,24617,8745]

theorem envBound50511 : H12AffineFastState.Bounded env50511 := by
  intro p hp
  have h : env50511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50510_50511 : H12AffineEnvironment.transform 14 0 env50510 = env50511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50510 == env50511) = true)

theorem identity50511 : scanCanonicalize (H12AffineFastState.compose env50511 (packedSelected [3,4,5,9,10,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50511 : packedSelected [3,4,5,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env50512 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,16384,0,34,16401,2049,1024,1,17509,113,17,2,41,64,2129,16448,4176,2048,1056,33,117,113,16384,512]

theorem envBound50512 : H12AffineFastState.Bounded env50512 := by
  intro p hp
  have h : env50512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50511_50512 : H12AffineEnvironment.transform 12 41 env50511 = env50512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50511 == env50512) = true)

theorem identity50512 : scanCanonicalize (H12AffineFastState.compose env50512 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50512 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50513 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,41,16384,0,34,16401,2049,1024,1,17429,1,17,2,41,48,2081,16432,4128,2048,1056,33,5,1,16384,512]

theorem envBound50513 : H12AffineFastState.Bounded env50513 := by
  intro p hp
  have h : env50513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50512_50513 : H12AffineEnvironment.transform 5 48 env50512 = env50513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50512 == env50513) = true)

theorem identity50513 : scanCanonicalize (H12AffineFastState.compose env50513 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6715) := by decide +kernel

theorem selectedBound50513 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50514 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,41,6715,0,34,6698,2049,1024,1,7726,1,17,2,41,48,2081,6667,4128,2048,1056,33,5,1,6715,512]

theorem envBound50514 : H12AffineFastState.Bounded env50514 := by
  intro p hp
  have h : env50514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50513_50514 : H12AffineEnvironment.transform 13 6715 env50513 = env50514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6715 env50513 == env50514) = true)

theorem identity50514 : scanCanonicalize (H12AffineFastState.compose env50514 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound50514 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50515 : List Nat := [2,4,8,16,32,48,8,5,512,1024,1567,4096,41,5156,0,34,5173,1566,1024,1,4145,1,17,2,41,48,1598,5140,4128,1567,1056,33,5,1,5156,512]

theorem envBound50515 : H12AffineFastState.Bounded env50515 := by
  intro p hp
  have h : env50515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50514_50515 : H12AffineEnvironment.transform 10 1567 env50514 = env50515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env50514 == env50515) = true)

theorem identity50515 : scanCanonicalize (H12AffineFastState.compose env50515 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50515 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50516 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1567,4096,8,5125,0,3,5140,1566,1024,1,4112,1,17,2,8,17,1567,5140,4097,1567,1025,0,5,1,5125,512]

theorem envBound50516 : H12AffineFastState.Bounded env50516 := by
  intro p hp
  have h : env50516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50515_50516 : H12AffineEnvironment.transform 4 1 env50515 = env50516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50515 == env50516) = true)

theorem identity50516 : scanCanonicalize (H12AffineFastState.compose env50516 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50516 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50517 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1567,16,8,1045,0,3,1028,1566,1024,1,0,1,17,2,8,17,1567,1028,17,1567,1025,0,5,1,1045,512]

theorem envBound50517 : H12AffineFastState.Bounded env50517 := by
  intro p hp
  have h : env50517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50516_50517 : H12AffineEnvironment.transform 11 16 env50516 = env50517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50516 == env50517) = true)

theorem identity50517 : scanCanonicalize (H12AffineFastState.compose env50517 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 27) := by decide +kernel

theorem selectedBound50517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50518 : List Nat := [2,4,8,16,1,17,8,5,512,27,516,16,8,14,0,3,31,517,27,1,0,1,17,2,8,17,516,31,17,516,26,0,5,1,14,512]

theorem envBound50518 : H12AffineFastState.Bounded env50518 := by
  intro p hp
  have h : env50518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50517_50518 : H12AffineEnvironment.transform 9 27 env50517 = env50518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 27 env50517 == env50518) = true)

theorem identity50518 : scanCanonicalize (H12AffineFastState.compose env50518 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound50518 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50519 : List Nat := [2,4,8,16,1,17,8,5,14,27,10,16,8,14,0,3,31,11,27,1,0,1,17,2,8,17,10,31,17,10,26,0,5,1,14,14]

theorem envBound50519 : H12AffineFastState.Bounded env50519 := by
  intro p hp
  have h : env50519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50518_50519 : H12AffineEnvironment.transform 8 14 env50518 = env50519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env50518 == env50519) = true)

theorem identity50519 : scanCanonicalize (H12AffineFastState.compose env50519 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound50519 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50520 : List Nat := [2,4,8,5,1,4,8,5,14,14,10,5,8,14,0,3,10,11,14,1,0,1,4,2,8,4,10,10,4,10,15,0,5,1,14,14]

theorem envBound50520 : H12AffineFastState.Bounded env50520 := by
  intro p hp
  have h : env50520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50519_50520 : H12AffineEnvironment.transform 3 5 env50519 = env50520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env50519 == env50520) = true)

theorem identity50520 : scanCanonicalize (H12AffineFastState.compose env50520 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50520 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env50521 : List Nat := [2,1,8,0,1,1,8,0,11,11,10,0,8,11,0,3,10,11,11,1,0,1,1,2,8,1,10,10,1,10,10,0,0,1,11,11]

theorem envBound50521 : H12AffineFastState.Bounded env50521 := by
  intro p hp
  have h : env50521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50520_50521 : H12AffineEnvironment.transform 1 1 env50520 = env50521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50520 == env50521) = true)

theorem identity50521 : scanCanonicalize (H12AffineFastState.compose env50521 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50522 : List Nat := [1,1,8,0,1,1,8,0,8,8,9,0,8,8,0,0,9,8,8,1,0,1,1,1,8,1,9,9,1,9,9,0,0,1,8,8]

theorem envBound50522 : H12AffineFastState.Bounded env50522 := by
  intro p hp
  have h : env50522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50521_50522 : H12AffineEnvironment.transform 0 1 env50521 = env50522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50521 == env50522) = true)

def env50523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,16777216,8192,64,21331968,18973701,2233680,294912,17024016,23160137,256,19104804,19096841,16966478]

theorem envBound50523 : H12AffineFastState.Bounded env50523 := by
  intro p hp
  have h : env50523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50411_50523 : H12AffineEnvironment.transform 22 147457 env50411 = env50523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env50411 == env50523) = true)

theorem identity50523 : scanCanonicalize (H12AffineFastState.compose env50523 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound50523 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,188751,8192,64,4677967,2319690,2233680,294912,75103,6521862,256,2188651,2196550,513]

theorem envBound50524 : H12AffineFastState.Bounded env50524 := by
  intro p hp
  have h : env50524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50523_50524 : H12AffineEnvironment.transform 23 188751 env50523 = env50524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env50523 == env50524) = true)

def env50525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,41311,8192,64,4530527,2172250,2118976,294912,75103,6407190,256,2188651,2196550,513]

theorem envBound50525 : H12AffineFastState.Bounded env50525 := by
  intro p hp
  have h : env50525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50524_50525 : H12AffineEnvironment.transform 16 16400 env50524 = env50525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50524 == env50525) = true)

theorem identity50525 : scanCanonicalize (H12AffineFastState.compose env50525 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50525 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2098512,2118976,294912,1365,6349852,256,2114913,2139212,513]

theorem envBound50526 : H12AffineFastState.Bounded env50526 := by
  intro p hp
  have h : env50526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50525_50526 : H12AffineEnvironment.transform 15 8202 env50525 = env50526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50525 == env50526) = true)

theorem identity50526 : scanCanonicalize (H12AffineFastState.compose env50526 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound50526 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,2097152,32,17,41311,8192,64,262517,2098512,2118976,294912,1365,2155580,256,2114913,2139212,513]

theorem envBound50527 : H12AffineFastState.Bounded env50527 := by
  intro p hp
  have h : env50527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50526_50527 : H12AffineEnvironment.transform 21 32 env50526 = env50527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env50526 == env50527) = true)

theorem identity50527 : scanCanonicalize (H12AffineFastState.compose env50527 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50527 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,262144,1024,8540,2097152,32,17,2,8192,64,262517,2098512,2118976,270685,1365,2114913,256,2114913,2098449,513]

theorem envBound50528 : H12AffineFastState.Bounded env50528 := by
  intro p hp
  have h : env50528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50527_50528 : H12AffineEnvironment.transform 14 8541 env50527 = env50528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50527 == env50528) = true)

theorem identity50528 : scanCanonicalize (H12AffineFastState.compose env50528 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50528 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50529 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,262144,1024,8461,2097152,32,17,2,8192,17,262436,2098433,2118929,270604,1284,2114864,256,2114864,2098449,513]

theorem envBound50529 : H12AffineFastState.Bounded env50529 := by
  intro p hp
  have h : env50529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50528_50529 : H12AffineEnvironment.transform 5 17 env50528 = env50529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50528 == env50529) = true)

theorem identity50529 : scanCanonicalize (H12AffineFastState.compose env50529 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50529 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50530 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10280,1024,8461,2097152,32,17,2,8192,17,10508,2098433,2118929,2340,1284,2114864,256,2114864,2098449,513]

theorem envBound50530 : H12AffineFastState.Bounded env50530 := by
  intro p hp
  have h : env50530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50529_50530 : H12AffineEnvironment.transform 17 10280 env50529 = env50530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50529 == env50530) = true)

theorem identity50530 : scanCanonicalize (H12AffineFastState.compose env50530 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 26665) := by decide +kernel

theorem selectedBound50530 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50531 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10280,1024,8461,26665,32,17,2,8192,17,10508,27944,15672,2340,1284,11545,256,11545,27960,513]

theorem envBound50531 : H12AffineFastState.Bounded env50531 := by
  intro p hp
  have h : env50531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50530_50531 : H12AffineEnvironment.transform 20 26665 env50530 = env50531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26665 env50530 == env50531) = true)

theorem identity50531 : scanCanonicalize (H12AffineFastState.compose env50531 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound50531 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50532 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,8192,16384,8460,8202,16400,9528,1024,8461,25913,32,17,2,8192,17,9244,24632,12328,1076,1284,8201,256,8201,24616,513]

theorem envBound50532 : H12AffineFastState.Bounded env50532 := by
  intro p hp
  have h : env50532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50531_50532 : H12AffineEnvironment.transform 10 1296 env50531 = env50532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env50531 == env50532) = true)

theorem identity50532 : scanCanonicalize (H12AffineFastState.compose env50532 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50532 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50533 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,40,16384,292,34,16400,1296,1024,293,17681,32,17,2,40,17,1076,16400,4096,1076,1284,33,256,33,16384,513]

theorem envBound50533 : H12AffineFastState.Bounded env50533 := by
  intro p hp
  have h : env50533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50532_50533 : H12AffineEnvironment.transform 12 40 env50532 = env50533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50532 == env50533) = true)

theorem identity50533 : scanCanonicalize (H12AffineFastState.compose env50533 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound50533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50534 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,40,1297,292,34,1281,1296,1024,293,0,32,17,2,40,17,1076,1281,4096,1076,1284,33,256,33,1297,513]

theorem envBound50534 : H12AffineFastState.Bounded env50534 := by
  intro p hp
  have h : env50534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50533_50534 : H12AffineEnvironment.transform 13 1297 env50533 = env50534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50533 == env50534) = true)

theorem identity50534 : scanCanonicalize (H12AffineFastState.compose env50534 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound50534 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50535 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,309,40,1297,292,34,1281,1296,1024,293,0,32,17,2,40,17,1076,1281,309,1076,1284,33,256,33,1297,513]

theorem envBound50535 : H12AffineFastState.Bounded env50535 := by
  intro p hp
  have h : env50535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50534_50535 : H12AffineEnvironment.transform 11 309 env50534 = env50535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env50534 == env50535) = true)

theorem identity50535 : scanCanonicalize (H12AffineFastState.compose env50535 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50535 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50536 : List Nat := [2,4,8,16,32,17,8,256,512,273,1,309,40,0,292,34,16,1,273,293,0,32,17,2,40,17,293,16,309,293,21,33,256,33,0,513]

theorem envBound50536 : H12AffineFastState.Bounded env50536 := by
  intro p hp
  have h : env50536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50535_50536 : H12AffineEnvironment.transform 9 273 env50535 = env50536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50535 == env50536) = true)

def env50537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41310,8192,64,4530526,2172251,2118977,294912,75103,6407191,256,2188651,2196550,513]

theorem envBound50537 : H12AffineFastState.Bounded env50537 := by
  intro p hp
  have h : env50537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50524_50537 : H12AffineEnvironment.transform 16 16401 env50524 = env50537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50524 == env50537) = true)

def env50538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41310,8192,64,4530526,115015,45405,294912,75103,4268043,256,98679,90202,513]

theorem envBound50538 : H12AffineFastState.Bounded env50538 := by
  intro p hp
  have h : env50538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50537_50538 : H12AffineEnvironment.transform 20 58396 env50537 = env50538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env50537 == env50538) = true)

theorem identity50538 : scanCanonicalize (H12AffineFastState.compose env50538 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50538 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58396,4194304,16,41310,8192,64,4456789,57676,45405,294912,1364,4194304,256,41340,16465,513]

theorem envBound50539 : H12AffineFastState.Bounded env50539 := by
  intro p hp
  have h : env50539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50538_50539 : H12AffineEnvironment.transform 15 8203 env50538 = env50539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50538 == env50539) = true)

theorem identity50539 : scanCanonicalize (H12AffineFastState.compose env50539 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272472) := by decide +kernel

theorem selectedBound50539 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env50540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58396,272472,16,41310,8192,64,10509,57676,45405,294912,1364,272472,256,41340,16465,513]

theorem envBound50540 : H12AffineFastState.Bounded env50540 := by
  intro p hp
  have h : env50540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50539_50540 : H12AffineEnvironment.transform 21 272472 env50539 = env50540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272472 env50539 == env50540) = true)

theorem identity50540 : scanCanonicalize (H12AffineFastState.compose env50540 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50540 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env50541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16401,262144,1024,32769,50496,264452,16,32770,348,64,2129,49168,36865,294912,1364,264452,256,32800,16465,513]

theorem envBound50541 : H12AffineFastState.Bounded env50541 := by
  intro p hp
  have h : env50541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50540_50541 : H12AffineEnvironment.transform 12 348 env50540 = env50541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50540 == env50541) = true)

theorem identity50541 : scanCanonicalize (H12AffineFastState.compose env50541 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50541 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50542 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16401,262144,1024,32769,50449,264452,16,32770,269,17,2048,49168,36865,294912,1285,264452,256,32800,16384,513]

theorem envBound50542 : H12AffineFastState.Bounded env50542 := by
  intro p hp
  have h : env50542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50541_50542 : H12AffineEnvironment.transform 5 17 env50541 = env50542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50541 == env50542) = true)

theorem identity50542 : scanCanonicalize (H12AffineFastState.compose env50542 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound50542 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50543 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16401,35109,1024,32769,50449,32801,16,32770,269,17,2048,49168,36865,2341,1285,32801,256,32800,16384,513]

theorem envBound50543 : H12AffineFastState.Bounded env50543 := by
  intro p hp
  have h : env50543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50542_50543 : H12AffineEnvironment.transform 17 35109 env50542 = env50543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env50542 == env50543) = true)

theorem identity50543 : scanCanonicalize (H12AffineFastState.compose env50543 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50543 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env50544 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1024,1,17681,33,16,2,269,17,2048,16400,4097,2341,1285,33,256,32,16384,513]

theorem envBound50544 : H12AffineFastState.Bounded env50544 := by
  intro p hp
  have h : env50544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50543_50544 : H12AffineEnvironment.transform 14 0 env50543 = env50544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50543 == env50544) = true)

theorem identity50544 : scanCanonicalize (H12AffineFastState.compose env50544 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound50544 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50545 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5157,0,262,5172,2341,1024,1,4404,33,16,2,269,17,2048,5173,4097,2341,1285,33,256,32,5157,513]

theorem envBound50545 : H12AffineFastState.Bounded env50545 := by
  intro p hp
  have h : env50545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50544_50545 : H12AffineEnvironment.transform 13 5157 env50544 = env50545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env50544 == env50545) = true)

def env50546 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2837,0,262,2820,2341,1024,1,3588,33,16,2,269,17,2048,2821,3889,2341,1285,33,256,32,2837,513]

theorem envBound50546 : H12AffineFastState.Bounded env50546 := by
  intro p hp
  have h : env50546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50545_50546 : H12AffineEnvironment.transform 11 3888 env50545 = env50546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env50545 == env50546) = true)

def env50547 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1045,0,262,1028,1573,1024,1,260,33,16,2,269,17,1792,1029,49,1573,1285,33,256,32,1045,513]

theorem envBound50547 : H12AffineFastState.Bounded env50547 := by
  intro p hp
  have h : env50547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50546_50547 : H12AffineEnvironment.transform 10 1792 env50546 = env50547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env50546 == env50547) = true)

theorem identity50547 : scanCanonicalize (H12AffineFastState.compose env50547 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50548 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1296,48,269,1045,0,262,1028,1077,1024,1,260,33,16,2,269,17,1296,1029,49,1077,1285,33,256,32,1045,17]

theorem envBound50548 : H12AffineFastState.Bounded env50548 := by
  intro p hp
  have h : env50548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50547_50548 : H12AffineEnvironment.transform 8 16 env50547 = env50548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50547 == env50548) = true)

def env50549 : List Nat := [2,4,8,16,32,17,8,256,16,52,292,48,269,33,0,262,48,1,52,1,260,33,16,2,269,17,292,49,49,1,305,33,256,32,33,17]

theorem envBound50549 : H12AffineFastState.Bounded env50549 := by
  intro p hp
  have h : env50549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50548_50549 : H12AffineEnvironment.transform 9 52 env50548 = env50549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50548 == env50549) = true)

theorem identity50549 : scanCanonicalize (H12AffineFastState.compose env50549 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50550 : List Nat := [2,4,8,16,32,17,8,4,16,52,32,48,9,33,0,2,48,1,52,1,0,33,16,2,9,17,32,49,49,1,53,33,4,32,33,17]

theorem envBound50550 : H12AffineFastState.Bounded env50550 := by
  intro p hp
  have h : env50550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50549_50550 : H12AffineEnvironment.transform 7 4 env50549 = env50550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50549 == env50550) = true)

def leafEnv50550 : List Nat := [2,4,8,16,32,17,8,4,16,52,32,48,9,33,0,2,48,1,52,1,0,33,16,2,53,9,1,17,32,49,49,1,53,33,4,32,4,2,33,17,1,0,0]

def active50550 : List Nat := [0,1,2,3,4]

def tree50550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50550 : H12WitnessSearch.Good tree50550 := H12GlobalWitnessIndex.good

theorem leafIdentity50550 : H12AffineFastState.composeSystem env50550 rootObs = leafEnv50550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50550 rootObs == leafEnv50550) = true)

theorem terminalChecked50550 : H12PackedTerminal.terminalCheckFast leafEnv50550 active50550 tree50550 = true := by decide +kernel

def env50551 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,269,32,0,262,49,0,53,1,260,33,16,2,269,17,293,48,49,0,304,33,256,32,32,17]

theorem envBound50551 : H12AffineFastState.Bounded env50551 := by
  intro p hp
  have h : env50551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50548_50551 : H12AffineEnvironment.transform 9 53 env50548 = env50551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50548 == env50551) = true)

theorem identity50551 : scanCanonicalize (H12AffineFastState.compose env50551 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50551 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50552 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,269,32,0,262,43,0,47,1,260,33,10,2,269,11,293,42,43,0,298,33,256,32,32,11]

theorem envBound50552 : H12AffineFastState.Bounded env50552 := by
  intro p hp
  have h : env50552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50551_50552 : H12AffineEnvironment.transform 3 10 env50551 = env50552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50551 == env50552) = true)

def leafEnv50552 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,269,32,0,262,43,0,47,1,260,33,10,2,298,269,1,11,293,42,43,0,298,33,256,32,4,262,32,11,1,260,0]

def active50552 : List Nat := [0,1,2,4,7]

def tree50552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50552 : H12WitnessSearch.Good tree50552 := H12GlobalWitnessIndex.good

theorem leafIdentity50552 : H12AffineFastState.composeSystem env50552 rootObs = leafEnv50552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50552 rootObs == leafEnv50552) = true)

theorem terminalChecked50552 : H12PackedTerminal.terminalCheckFast leafEnv50552 active50552 tree50552 = true := by decide +kernel

def env50553 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1044,0,262,1029,1572,1024,1,261,33,16,2,269,17,1793,1028,48,1572,1285,33,256,32,1044,513]

theorem envBound50553 : H12AffineFastState.Bounded env50553 := by
  intro p hp
  have h : env50553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50546_50553 : H12AffineEnvironment.transform 10 1793 env50546 = env50553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env50546 == env50553) = true)

theorem identity50553 : scanCanonicalize (H12AffineFastState.compose env50553 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound50553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50554 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,49,269,789,0,262,772,293,769,1,261,33,16,2,269,17,0,773,48,293,516,33,256,32,789,513]

theorem envBound50554 : H12AffineFastState.Bounded env50554 := by
  intro p hp
  have h : env50554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50553_50554 : H12AffineEnvironment.transform 9 769 env50553 = env50554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env50553 == env50554) = true)

def env50555 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,49,269,33,0,262,48,293,53,1,261,33,16,2,269,17,0,49,48,293,304,33,256,32,33,309]

theorem envBound50555 : H12AffineFastState.Bounded env50555 := by
  intro p hp
  have h : env50555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50554_50555 : H12AffineEnvironment.transform 8 308 env50554 = env50555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env50554 == env50555) = true)

theorem identity50555 : scanCanonicalize (H12AffineFastState.compose env50555 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50556 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,269,33,0,262,43,293,46,1,261,33,11,2,269,10,0,42,43,293,299,33,256,32,33,302]

theorem envBound50556 : H12AffineFastState.Bounded env50556 := by
  intro p hp
  have h : env50556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50555_50556 : H12AffineEnvironment.transform 3 11 env50555 = env50556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50555 == env50556) = true)

def leafEnv50556 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,269,33,0,262,43,293,46,1,261,33,11,2,299,269,1,10,0,42,43,293,299,33,256,32,4,262,33,302,1,261,0]

def active50556 : List Nat := [0,1,2,4,7]

def tree50556 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50556 : H12WitnessSearch.Good tree50556 := H12GlobalWitnessIndex.good

theorem leafIdentity50556 : H12AffineFastState.composeSystem env50556 rootObs = leafEnv50556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50556 rootObs == leafEnv50556) = true)

theorem terminalChecked50556 : H12PackedTerminal.terminalCheckFast leafEnv50556 active50556 tree50556 = true := by decide +kernel

def env50557 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,269,32,0,262,49,293,52,1,261,33,16,2,269,17,0,48,48,293,305,33,256,32,32,308]

theorem envBound50557 : H12AffineFastState.Bounded env50557 := by
  intro p hp
  have h : env50557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50554_50557 : H12AffineEnvironment.transform 8 309 env50554 = env50557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env50554 == env50557) = true)

theorem identity50557 : scanCanonicalize (H12AffineFastState.compose env50557 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50558 : List Nat := [2,4,8,16,1,17,8,256,276,21,0,16,269,1,0,262,16,260,21,1,261,0,16,2,269,17,0,17,17,260,272,0,256,1,1,277]

theorem envBound50558 : H12AffineFastState.Bounded env50558 := by
  intro p hp
  have h : env50558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50557_50558 : H12AffineEnvironment.transform 4 1 env50557 = env50558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50557 == env50558) = true)

def leafEnv50558 : List Nat := [2,4,8,16,1,17,8,256,276,21,0,16,269,1,0,262,16,260,21,1,261,0,16,2,272,269,1,17,0,17,17,260,272,0,256,1,4,262,1,277,1,261,0]

def active50558 : List Nat := [0,1,2,3,7]

def tree50558 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50558 : H12WitnessSearch.Good tree50558 := H12GlobalWitnessIndex.good

theorem leafIdentity50558 : H12AffineFastState.composeSystem env50558 rootObs = leafEnv50558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50558 rootObs == leafEnv50558) = true)

theorem terminalChecked50558 : H12PackedTerminal.terminalCheckFast leafEnv50558 active50558 tree50558 = true := by decide +kernel

def env50559 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2836,0,262,2821,2341,1024,1,3589,33,16,2,269,17,2048,2820,3888,2341,1285,33,256,32,2836,513]

theorem envBound50559 : H12AffineFastState.Bounded env50559 := by
  intro p hp
  have h : env50559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50545_50559 : H12AffineEnvironment.transform 11 3889 env50545 = env50559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env50545 == env50559) = true)

def env50560 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1044,0,262,1029,1573,1024,1,261,33,16,2,269,17,1792,1028,48,1573,1285,33,256,32,1044,513]

theorem envBound50560 : H12AffineFastState.Bounded env50560 := by
  intro p hp
  have h : env50560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50559_50560 : H12AffineEnvironment.transform 10 1792 env50559 = env50560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env50559 == env50560) = true)

theorem identity50560 : scanCanonicalize (H12AffineFastState.compose env50560 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound50560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50561 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,49,269,561,0,262,544,0,549,1,261,33,16,2,269,17,293,545,48,0,800,33,256,32,561,513]

theorem envBound50561 : H12AffineFastState.Bounded env50561 := by
  intro p hp
  have h : env50561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50560_50561 : H12AffineEnvironment.transform 9 549 env50560 = env50561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env50560 == env50561) = true)

def env50562 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,49,269,33,0,262,48,0,53,1,261,33,16,2,269,17,293,49,48,0,304,33,256,32,33,17]

theorem envBound50562 : H12AffineFastState.Bounded env50562 := by
  intro p hp
  have h : env50562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50561_50562 : H12AffineEnvironment.transform 8 16 env50561 = env50562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50561 == env50562) = true)

theorem identity50562 : scanCanonicalize (H12AffineFastState.compose env50562 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50563 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,269,33,0,262,42,0,47,1,261,33,10,2,269,11,293,43,42,0,298,33,256,32,33,11]

theorem envBound50563 : H12AffineFastState.Bounded env50563 := by
  intro p hp
  have h : env50563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50562_50563 : H12AffineEnvironment.transform 3 10 env50562 = env50563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50562 == env50563) = true)

def leafEnv50563 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,269,33,0,262,42,0,47,1,261,33,10,2,298,269,1,11,293,43,42,0,298,33,256,32,4,262,33,11,1,261,0]

def active50563 : List Nat := [0,1,2,4,7]

def tree50563 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50563 : H12WitnessSearch.Good tree50563 := H12GlobalWitnessIndex.good

theorem leafIdentity50563 : H12AffineFastState.composeSystem env50563 rootObs = leafEnv50563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50563 rootObs == leafEnv50563) = true)

theorem terminalChecked50563 : H12PackedTerminal.terminalCheckFast leafEnv50563 active50563 tree50563 = true := by decide +kernel

def env50564 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,269,32,0,262,49,0,52,1,261,33,16,2,269,17,293,48,48,0,305,33,256,32,32,16]

theorem envBound50564 : H12AffineFastState.Bounded env50564 := by
  intro p hp
  have h : env50564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50561_50564 : H12AffineEnvironment.transform 8 17 env50561 = env50564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50561 == env50564) = true)

theorem identity50564 : scanCanonicalize (H12AffineFastState.compose env50564 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50565 : List Nat := [2,4,8,16,32,17,8,4,17,52,33,49,9,32,0,2,49,0,52,1,1,33,16,2,9,17,33,48,48,0,53,33,4,32,32,16]

theorem envBound50565 : H12AffineFastState.Bounded env50565 := by
  intro p hp
  have h : env50565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50564_50565 : H12AffineEnvironment.transform 7 4 env50564 = env50565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50564 == env50565) = true)

def leafEnv50565 : List Nat := [2,4,8,16,32,17,8,4,17,52,33,49,9,32,0,2,49,0,52,1,1,33,16,2,53,9,1,17,33,48,48,0,53,33,4,32,4,2,32,16,1,1,0]

def active50565 : List Nat := [0,1,2,3,4]

def tree50565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50565 : H12WitnessSearch.Good tree50565 := H12GlobalWitnessIndex.good

theorem leafIdentity50565 : H12AffineFastState.composeSystem env50565 rootObs = leafEnv50565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50565 rootObs == leafEnv50565) = true)

theorem terminalChecked50565 : H12PackedTerminal.terminalCheckFast leafEnv50565 active50565 tree50565 = true := by decide +kernel

def env50566 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1045,0,262,1028,1572,1024,1,260,33,16,2,269,17,1793,1029,49,1572,1285,33,256,32,1045,513]

theorem envBound50566 : H12AffineFastState.Bounded env50566 := by
  intro p hp
  have h : env50566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50559_50566 : H12AffineEnvironment.transform 10 1793 env50559 = env50566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env50559 == env50566) = true)

theorem identity50566 : scanCanonicalize (H12AffineFastState.compose env50566 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound50566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50567 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1077,48,269,1045,0,262,1028,1296,1024,1,260,33,16,2,269,17,1077,1029,49,1296,1285,33,256,32,1045,309]

theorem envBound50567 : H12AffineFastState.Bounded env50567 := by
  intro p hp
  have h : env50567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50566_50567 : H12AffineEnvironment.transform 8 308 env50566 = env50567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env50566 == env50567) = true)

def env50568 : List Nat := [2,4,8,16,32,17,8,256,308,52,1,48,269,33,0,262,48,292,52,1,260,33,16,2,269,17,1,49,49,292,305,33,256,32,33,309]

theorem envBound50568 : H12AffineFastState.Bounded env50568 := by
  intro p hp
  have h : env50568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50567_50568 : H12AffineEnvironment.transform 9 52 env50567 = env50568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50567 == env50568) = true)

theorem identity50568 : scanCanonicalize (H12AffineFastState.compose env50568 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50568 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50569 : List Nat := [2,4,8,16,1,17,8,256,277,21,1,17,269,0,0,262,17,261,21,1,260,0,16,2,269,17,1,16,16,261,272,0,256,1,0,276]

theorem envBound50569 : H12AffineFastState.Bounded env50569 := by
  intro p hp
  have h : env50569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50568_50569 : H12AffineEnvironment.transform 4 1 env50568 = env50569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50568 == env50569) = true)

def leafEnv50569 : List Nat := [2,4,8,16,1,17,8,256,277,21,1,17,269,0,0,262,17,261,21,1,260,0,16,2,272,269,1,17,1,16,16,261,272,0,256,1,4,262,0,276,1,260,0]

def active50569 : List Nat := [0,1,2,3,7]

def tree50569 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50569 : H12WitnessSearch.Good tree50569 := H12GlobalWitnessIndex.good

theorem leafIdentity50569 : H12AffineFastState.composeSystem env50569 rootObs = leafEnv50569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50569 rootObs == leafEnv50569) = true)

theorem terminalChecked50569 : H12PackedTerminal.terminalCheckFast leafEnv50569 active50569 tree50569 = true := by decide +kernel

def env50570 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,269,32,0,262,49,293,53,1,260,33,16,2,269,17,0,48,49,293,304,33,256,32,32,309]

theorem envBound50570 : H12AffineFastState.Bounded env50570 := by
  intro p hp
  have h : env50570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50567_50570 : H12AffineEnvironment.transform 9 53 env50567 = env50570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50567 == env50570) = true)

theorem identity50570 : scanCanonicalize (H12AffineFastState.compose env50570 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50571 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,269,32,0,262,42,293,46,1,260,33,11,2,269,10,0,43,42,293,299,33,256,32,32,302]

theorem envBound50571 : H12AffineFastState.Bounded env50571 := by
  intro p hp
  have h : env50571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50570_50571 : H12AffineEnvironment.transform 3 11 env50570 = env50571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50570 == env50571) = true)

def leafEnv50571 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,269,32,0,262,42,293,46,1,260,33,11,2,299,269,1,10,0,43,42,293,299,33,256,32,4,262,32,302,1,260,0]

def active50571 : List Nat := [0,1,2,4,7]

def tree50571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50571 : H12WitnessSearch.Good tree50571 := H12GlobalWitnessIndex.good

theorem leafIdentity50571 : H12AffineFastState.composeSystem env50571 rootObs = leafEnv50571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50571 rootObs == leafEnv50571) = true)

theorem terminalChecked50571 : H12PackedTerminal.terminalCheckFast leafEnv50571 active50571 tree50571 = true := by decide +kernel

def env50572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41310,8192,64,4530526,115014,45404,294912,75103,4268042,256,98678,90203,513]

theorem envBound50572 : H12AffineFastState.Bounded env50572 := by
  intro p hp
  have h : env50572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50537_50572 : H12AffineEnvironment.transform 20 58397 env50537 = env50572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env50537 == env50572) = true)

def env50573 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41230,8192,16,4530446,114966,45324,294912,75023,4268042,256,98598,90123,513]

theorem envBound50573 : H12AffineFastState.Bounded env50573 := by
  intro p hp
  have h : env50573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50572_50573 : H12AffineEnvironment.transform 5 16 env50572 = env50573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50572 == env50573) = true)

theorem identity50573 : scanCanonicalize (H12AffineFastState.compose env50573 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272392) := by decide +kernel

theorem selectedBound50573 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env50574 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,272392,16,41230,8192,16,67846,114966,45324,294912,75023,329730,256,98598,90123,513]

theorem envBound50574 : H12AffineFastState.Bounded env50574 := by
  intro p hp
  have h : env50574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50573_50574 : H12AffineEnvironment.transform 21 272392 env50573 = env50574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272392 env50573 == env50574) = true)

theorem identity50574 : scanCanonicalize (H12AffineFastState.compose env50574 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound50574 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env50575 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16401,262144,1024,32769,58397,272392,16,41230,8192,16,34816,16400,45324,294912,41993,297220,256,32,57613,513]

theorem envBound50575 : H12AffineFastState.Bounded env50575 := by
  intro p hp
  have h : env50575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50574_50575 : H12AffineEnvironment.transform 15 33030 env50574 = env50575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env50574 == env50575) = true)

theorem identity50575 : scanCanonicalize (H12AffineFastState.compose env50575 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound50575 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50576 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16401,2341,1024,32769,58397,8493,16,41230,8192,16,34816,16400,45324,35109,41993,32801,256,32,57613,513]

theorem envBound50576 : H12AffineFastState.Bounded env50576 := by
  intro p hp
  have h : env50576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50575_50576 : H12AffineEnvironment.transform 17 2341 env50575 = env50576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env50575 == env50576) = true)

theorem identity50576 : scanCanonicalize (H12AffineFastState.compose env50576 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50577 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,33030,16401,2341,1024,32769,50448,32,16,32771,269,16,34816,16400,36865,35109,34052,32801,256,32,49152,513]

theorem envBound50577 : H12AffineFastState.Bounded env50577 := by
  intro p hp
  have h : env50577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50576_50577 : H12AffineEnvironment.transform 12 269 env50576 = env50577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50576 == env50577) = true)

def env50578 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41231,8192,17,4530447,114967,45325,294912,75022,4268042,256,98599,90122,513]

theorem envBound50578 : H12AffineFastState.Bounded env50578 := by
  intro p hp
  have h : env50578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50572_50578 : H12AffineEnvironment.transform 5 17 env50572 = env50578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50572 == env50578) = true)

theorem identity50578 : scanCanonicalize (H12AffineFastState.compose env50578 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329730) := by decide +kernel

theorem selectedBound50578 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env50579 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,329730,16,41231,8192,17,10509,114967,45325,294912,75022,272392,256,98599,90122,513]

theorem envBound50579 : H12AffineFastState.Bounded env50579 := by
  intro p hp
  have h : env50579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50578_50579 : H12AffineEnvironment.transform 21 329730 env50578 = env50579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329730 env50578 == env50579) = true)

theorem identity50579 : scanCanonicalize (H12AffineFastState.compose env50579 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound50579 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env50580 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,43048,1024,32769,58397,106538,16,41231,8192,17,10509,114967,45325,10280,75022,32800,256,98599,90122,513]

theorem envBound50580 : H12AffineFastState.Bounded env50580 := by
  intro p hp
  have h : env50580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50579_50580 : H12AffineEnvironment.transform 17 43048 env50579 = env50580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env50579 == env50580) = true)

theorem identity50580 : scanCanonicalize (H12AffineFastState.compose env50580 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound50580 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env50581 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,43048,1024,32769,58397,33,16,41231,8192,17,10509,24860,45325,10280,34053,32800,256,8492,49153,513]

theorem envBound50581 : H12AffineFastState.Bounded env50581 := by
  intro p hp
  have h : env50581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50580_50581 : H12AffineEnvironment.transform 15 40971 env50580 = env50581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env50580 == env50581) = true)

theorem identity50581 : scanCanonicalize (H12AffineFastState.compose env50581 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50581 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50582 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33030,16401,35109,1024,32769,50448,33,16,32770,269,17,2048,16401,36864,2341,34053,32800,256,33,49153,513]

theorem envBound50582 : H12AffineFastState.Bounded env50582 := by
  intro p hp
  have h : env50582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50581_50582 : H12AffineEnvironment.transform 12 269 env50581 = env50582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50581 == env50582) = true)

theorem identity50582 : scanCanonicalize (H12AffineFastState.compose env50582 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 18724) := by decide +kernel

theorem selectedBound50582 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50583 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,18724,18466,16401,16385,1024,18725,3124,33,16,18726,269,17,2048,16401,22820,2341,19489,18692,256,33,2341,513]

theorem envBound50583 : H12AffineFastState.Bounded env50583 := by
  intro p hp
  have h : env50583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50582_50583 : H12AffineEnvironment.transform 14 18724 env50582 = env50583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18724 env50582 == env50583) = true)

theorem identity50583 : scanCanonicalize (H12AffineFastState.compose env50583 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50583 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env50584 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,16384,18433,18466,16401,16385,1024,18432,3124,33,16,18435,40,17,2048,16401,22529,2048,19489,18465,37,33,2048,513]

theorem envBound50584 : H12AffineFastState.Bounded env50584 := by
  intro p hp
  have h : env50584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50583_50584 : H12AffineEnvironment.transform 7 37 env50583 = env50584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50583 == env50584) = true)

theorem identity50584 : scanCanonicalize (H12AffineFastState.compose env50584 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50584 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env50585 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,16384,18433,18466,16401,16385,53,18432,2049,33,16,18435,40,17,2048,16401,22529,2048,18452,18465,37,33,2048,513]

theorem envBound50585 : H12AffineFastState.Bounded env50585 := by
  intro p hp
  have h : env50585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50584_50585 : H12AffineEnvironment.transform 9 53 env50584 = env50585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50584 == env50585) = true)

theorem identity50585 : scanCanonicalize (H12AffineFastState.compose env50585 (packedSelected [2,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound50585 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env50586 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,2048,1,34,2065,2049,53,0,2049,33,16,3,40,17,2048,2065,4097,2048,20,33,37,33,2048,513]

theorem envBound50586 : H12AffineFastState.Bounded env50586 := by
  intro p hp
  have h : env50586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50585_50586 : H12AffineEnvironment.transform 13 2048 env50585 = env50586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env50585 == env50586) = true)

theorem identity50586 : scanCanonicalize (H12AffineFastState.compose env50586 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50586 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50587 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,4096,40,1,1,34,16,0,53,0,0,33,16,3,40,17,1,16,4097,1,20,33,37,33,1,513]

theorem envBound50587 : H12AffineFastState.Bounded env50587 := by
  intro p hp
  have h : env50587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50586_50587 : H12AffineEnvironment.transform 10 1 env50586 = env50587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50586 == env50587) = true)

theorem identity50587 : scanCanonicalize (H12AffineFastState.compose env50587 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound50587 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50588 : List Nat := [2,4,8,16,32,17,8,37,11,53,1,4096,40,1,1,34,16,0,53,0,0,33,16,3,40,17,1,16,4097,1,20,33,37,33,1,10]

theorem envBound50588 : H12AffineFastState.Bounded env50588 := by
  intro p hp
  have h : env50588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50587_50588 : H12AffineEnvironment.transform 8 11 env50587 = env50588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env50587 == env50588) = true)

theorem identity50588 : scanCanonicalize (H12AffineFastState.compose env50588 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50588 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50589 : List Nat := [2,4,8,16,1,17,8,4,11,20,1,4096,9,1,1,3,16,0,20,0,0,0,16,3,9,17,1,16,4097,1,20,0,4,0,1,10]

theorem envBound50589 : H12AffineFastState.Bounded env50589 := by
  intro p hp
  have h : env50589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50588_50589 : H12AffineEnvironment.transform 4 1 env50588 = env50589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50588 == env50589) = true)

theorem identity50589 : scanCanonicalize (H12AffineFastState.compose env50589 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50589 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50590 : List Nat := [2,4,8,16,1,17,8,4,11,20,1,17,9,1,1,3,16,0,20,0,0,0,16,3,9,17,1,16,16,1,20,0,4,0,1,10]

theorem envBound50590 : H12AffineFastState.Bounded env50590 := by
  intro p hp
  have h : env50590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50589_50590 : H12AffineEnvironment.transform 11 17 env50589 = env50590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50589 == env50590) = true)

theorem identity50590 : scanCanonicalize (H12AffineFastState.compose env50590 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound50590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50591 : List Nat := [2,4,7,16,1,17,7,4,4,20,1,17,6,1,1,3,16,0,20,0,0,0,16,3,6,17,1,16,16,1,20,0,4,0,1,5]

theorem envBound50591 : H12AffineFastState.Bounded env50591 := by
  intro p hp
  have h : env50591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50590_50591 : H12AffineEnvironment.transform 2 7 env50590 = env50591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env50590 == env50591) = true)

theorem identity50591 : scanCanonicalize (H12AffineFastState.compose env50591 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound50591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50592 : List Nat := [2,4,7,3,1,2,7,4,4,7,1,2,6,1,1,3,3,0,7,0,0,0,3,3,6,2,1,3,3,1,7,0,4,0,1,5]

theorem envBound50592 : H12AffineFastState.Bounded env50592 := by
  intro p hp
  have h : env50592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50591_50592 : H12AffineEnvironment.transform 3 3 env50591 = env50592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env50591 == env50592) = true)

def env50593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound50593 : H12AffineFastState.Bounded env50593 := by
  intro p hp
  have h : env50593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50409_50593 : H12AffineEnvironment.transform 18 1025 env50409 = env50593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env50409 == env50593) = true)

theorem identity50593 : scanCanonicalize (H12AffineFastState.compose env50593 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642568) := by decide +kernel

theorem selectedBound50593 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642568,8328,64,4464648,10642564,10507601,8830976,156697,14845385,257,2237604,2278656,213966]

theorem envBound50594 : H12AffineFastState.Bounded env50594 := by
  intro p hp
  have h : env50594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50593_50594 : H12AffineEnvironment.transform 23 8642568 env50593 = env50594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642568 env50593 == env50594) = true)

def env50595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,8388608,8642568,8328,64,4464648,8393984,8529109,8830976,156697,12645453,257,21792,46212,213966]

theorem envBound50595 : H12AffineFastState.Bounded env50595 := by
  intro p hp
  have h : env50595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50594_50595 : H12AffineEnvironment.transform 20 160132 env50594 = env50595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160132 env50594 == env50595) = true)

def env50596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169216,95496,8328,64,4464648,163840,45525,283904,156697,4350285,257,21792,46212,213966]

theorem envBound50596 : H12AffineFastState.Bounded env50596 := by
  intro p hp
  have h : env50596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50595_50596 : H12AffineEnvironment.transform 22 169216 env50595 = env50596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env50595 == env50596) = true)

def env50597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169216,95496,8328,64,2184,163840,45525,283904,156697,412109,257,21792,46212,213966]

theorem envBound50597 : H12AffineFastState.Bounded env50597 := by
  intro p hp
  have h : env50597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50596_50597 : H12AffineEnvironment.transform 21 272512 env50596 = env50597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50596 == env50597) = true)

theorem identity50597 : scanCanonicalize (H12AffineFastState.compose env50597 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound50597 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,77899,272512,120015,95496,8328,64,2184,115151,45525,283904,75222,329730,257,21792,46212,513]

theorem envBound50598 : H12AffineFastState.Bounded env50598 := by
  intro p hp
  have h : env50598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50597_50598 : H12AffineEnvironment.transform 16 82383 env50597 = env50598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env50597 == env50598) = true)

def env50599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77899,272392,119879,95496,8192,64,2048,115015,45405,283904,75102,329730,257,21792,46092,513]

theorem envBound50599 : H12AffineFastState.Bounded env50599 := by
  intro p hp
  have h : env50599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50598_50599 : H12AffineEnvironment.transform 6 8 env50598 = env50599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50598 == env50599) = true)

theorem identity50599 : scanCanonicalize (H12AffineFastState.compose env50599 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50599 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,262144,1025,32769,69910,264533,119879,87125,349,64,2048,115015,36864,283904,66563,329730,257,21792,38225,513]

theorem envBound50600 : H12AffineFastState.Bounded env50600 := by
  intro p hp
  have h : env50600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50599_50600 : H12AffineEnvironment.transform 12 349 env50599 = env50600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50599 == env50600) = true)

theorem identity50600 : scanCanonicalize (H12AffineFastState.compose env50600 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound50600 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env50601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,56357,1025,32769,69910,54640,119879,87125,349,64,2048,115015,36864,35109,66563,119847,257,21792,38225,513]

theorem envBound50601 : H12AffineFastState.Bounded env50601 := by
  intro p hp
  have h : env50601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50600_50601 : H12AffineEnvironment.transform 17 56357 env50600 = env50601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env50600 == env50601) = true)

theorem identity50601 : scanCanonicalize (H12AffineFastState.compose env50601 (packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50601 : packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env50602 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,32768,65536,82019,56357,1025,32769,69682,54356,119879,87125,121,64,2048,114787,36864,34817,66563,119847,37,21508,38005,513]

theorem envBound50602 : H12AffineFastState.Bounded env50602 := by
  intro p hp
  have h : env50602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50601_50602 : H12AffineEnvironment.transform 7 36 env50601 = env50602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50601 == env50602) = true)

theorem identity50602 : scanCanonicalize (H12AffineFastState.compose env50602 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound50602 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env50603 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,32768,21510,5221,56357,1025,32769,17460,54356,32833,83,121,64,2048,37989,36864,34817,20485,32801,37,21508,38005,513]

theorem envBound50603 : H12AffineFastState.Bounded env50603 := by
  intro p hp
  have h : env50603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50602_50603 : H12AffineEnvironment.transform 15 21510 env50602 = env50603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env50602 == env50603) = true)

theorem identity50603 : scanCanonicalize (H12AffineFastState.compose env50603 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound50603 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50604 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,21620,21510,5221,2129,1025,21621,17460,32,21557,83,121,64,2048,16401,17524,23669,20485,21589,37,21508,16385,513]

theorem envBound50604 : H12AffineFastState.Bounded env50604 := by
  intro p hp
  have h : env50604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50603_50604 : H12AffineEnvironment.transform 14 21620 env50603 = env50604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env50603 == env50604) = true)

theorem identity50604 : scanCanonicalize (H12AffineFastState.compose env50604 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound50604 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50605 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1060,121,16384,16464,16418,65,2129,1025,16465,17460,32,16401,83,121,64,2048,16401,17524,18513,17441,16497,37,16416,16385,513]

theorem envBound50605 : H12AffineFastState.Bounded env50605 := by
  intro p hp
  have h : env50605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50604_50605 : H12AffineEnvironment.transform 11 1060 env50604 = env50605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env50604 == env50605) = true)

theorem identity50605 : scanCanonicalize (H12AffineFastState.compose env50605 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50605 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env50606 : List Nat := [2,4,8,16,32,64,8,36,512,1024,0,1060,121,16384,16464,16418,65,81,1025,16465,17460,32,16401,83,121,64,0,16401,17524,16465,17441,16497,37,16416,16385,513]

theorem envBound50606 : H12AffineFastState.Bounded env50606 := by
  intro p hp
  have h : env50606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50605_50606 : H12AffineEnvironment.transform 10 0 env50605 = env50606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50605 == env50606) = true)

theorem identity50606 : scanCanonicalize (H12AffineFastState.compose env50606 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50606 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50607 : List Nat := [2,4,8,16,32,64,8,36,512,100,0,64,121,16384,16464,16418,65,81,101,16465,16464,32,16401,83,121,64,0,16401,16400,16465,16453,16497,37,16416,16385,513]

theorem envBound50607 : H12AffineFastState.Bounded env50607 := by
  intro p hp
  have h : env50607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50606_50607 : H12AffineEnvironment.transform 9 100 env50606 = env50607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50606 == env50607) = true)

def env50608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,119878,95496,8193,64,2049,115014,45404,283904,75103,329730,257,21792,46093,513]

theorem envBound50608 : H12AffineFastState.Bounded env50608 := by
  intro p hp
  have h : env50608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50598_50608 : H12AffineEnvironment.transform 6 9 env50598 = env50608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50598 == env50608) = true)

def env50609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,77899,33,119878,95496,8193,64,2049,115014,45404,32040,75103,73770,257,21792,46093,513]

theorem envBound50609 : H12AffineFastState.Bounded env50609 := by
  intro p hp
  have h : env50609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50608_50609 : H12AffineEnvironment.transform 17 10280 env50608 = env50609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50608 == env50609) = true)

theorem identity50609 : scanCanonicalize (H12AffineFastState.compose env50609 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50609 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env50610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,82246,10280,1025,0,77899,33,87111,95496,8193,64,2049,82247,12637,32040,75103,73770,257,21792,13324,513]

theorem envBound50610 : H12AffineFastState.Bounded env50610 := by
  intro p hp
  have h : env50610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50609_50610 : H12AffineEnvironment.transform 14 1 env50609 = env50610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50609 == env50610) = true)

theorem identity50610 : scanCanonicalize (H12AffineFastState.compose env50610 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50610 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,65536,82246,2421,1025,0,69910,33,87111,87125,348,64,2049,82247,4096,23669,66562,65911,257,21792,5457,513]

theorem envBound50611 : H12AffineFastState.Bounded env50611 := by
  intro p hp
  have h : env50611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50610_50611 : H12AffineEnvironment.transform 12 349 env50610 = env50611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50610 == env50611) = true)

theorem identity50611 : scanCanonicalize (H12AffineFastState.compose env50611 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound50611 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,21510,5440,2421,1025,0,17680,33,65,83,348,64,2049,5441,4096,23669,20484,21873,257,21792,5457,513]

theorem envBound50612 : H12AffineFastState.Bounded env50612 := by
  intro p hp
  have h : env50612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50611_50612 : H12AffineEnvironment.transform 15 21510 env50611 = env50612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env50611 == env50612) = true)

theorem identity50612 : scanCanonicalize (H12AffineFastState.compose env50612 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50612 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,263,5440,2421,1025,0,4113,33,65,83,348,64,2049,5441,4096,2420,1285,112,257,33,5457,513]

theorem envBound50613 : H12AffineFastState.Bounded env50613 := by
  intro p hp
  have h : env50613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50612_50613 : H12AffineEnvironment.transform 13 5377 env50612 = env50613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50612 == env50613) = true)

theorem identity50613 : scanCanonicalize (H12AffineFastState.compose env50613 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50613 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50614 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1025,0,4113,33,17,3,268,16,2049,5393,4096,2340,1285,32,257,33,5377,513]

theorem envBound50614 : H12AffineFastState.Bounded env50614 := by
  intro p hp
  have h : env50614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50613_50614 : H12AffineEnvironment.transform 5 16 env50613 = env50614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50613 == env50614) = true)

theorem identity50614 : scanCanonicalize (H12AffineFastState.compose env50614 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50614 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50615 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,4405,1,263,4388,2341,53,0,4113,33,17,3,268,16,2049,4389,4096,2340,305,32,257,33,4405,513]

theorem envBound50615 : H12AffineFastState.Bounded env50615 := by
  intro p hp
  have h : env50615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50614_50615 : H12AffineEnvironment.transform 9 52 env50614 = env50615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50614 == env50615) = true)

theorem identity50615 : scanCanonicalize (H12AffineFastState.compose env50615 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50615 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50616 : List Nat := [2,4,8,16,32,16,9,256,512,52,523,4096,269,4405,1,263,4388,814,53,0,4113,33,17,3,268,16,522,4389,4096,815,305,32,257,33,4405,513]

theorem envBound50616 : H12AffineFastState.Bounded env50616 := by
  intro p hp
  have h : env50616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50615_50616 : H12AffineEnvironment.transform 10 523 env50615 = env50616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50615 == env50616) = true)

theorem identity50616 : scanCanonicalize (H12AffineFastState.compose env50616 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound50616 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50617 : List Nat := [2,4,8,16,32,16,9,256,512,52,523,798,269,555,1,263,570,814,53,0,783,33,17,3,268,16,522,571,798,815,305,32,257,33,555,513]

theorem envBound50617 : H12AffineFastState.Bounded env50617 := by
  intro p hp
  have h : env50617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50616_50617 : H12AffineEnvironment.transform 11 798 env50616 = env50617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env50616 == env50617) = true)

def env50618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,77899,32,119878,95496,8193,64,2049,115014,45404,32041,75103,73771,257,21792,46093,513]

theorem envBound50618 : H12AffineFastState.Bounded env50618 := by
  intro p hp
  have h : env50618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50608_50618 : H12AffineEnvironment.transform 17 10281 env50608 = env50618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50608 == env50618) = true)

theorem identity50618 : scanCanonicalize (H12AffineFastState.compose env50618 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound50618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10281,1025,32769,58397,32,16,41310,8193,64,2049,5392,45404,32041,61705,62589,257,21792,46093,513]

theorem envBound50619 : H12AffineFastState.Bounded env50619 := by
  intro p hp
  have h : env50619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50618_50619 : H12AffineEnvironment.transform 15 54358 env50618 = env50619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env50618 == env50619) = true)

theorem identity50619 : scanCanonicalize (H12AffineFastState.compose env50619 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7424) := by decide +kernel

theorem selectedBound50619 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env50620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,7424,18774,2064,10281,1025,7425,31005,32,16,15454,8193,64,2049,5392,11356,32041,27657,27005,257,21792,10509,513]

theorem envBound50620 : H12AffineFastState.Bounded env50620 := by
  intro p hp
  have h : env50620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50619_50620 : H12AffineEnvironment.transform 14 7424 env50619 = env50620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7424 env50619 == env50620) = true)

theorem identity50620 : scanCanonicalize (H12AffineFastState.compose env50620 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50620 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,7424,18774,2064,2421,1025,7425,22593,32,16,7426,349,64,2049,5392,3328,23669,19797,18465,257,21792,2129,513]

theorem envBound50621 : H12AffineFastState.Bounded env50621 := by
  intro p hp
  have h : env50621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50620_50621 : H12AffineEnvironment.transform 12 348 env50620 = env50621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50620 == env50621) = true)

theorem identity50621 : scanCanonicalize (H12AffineFastState.compose env50621 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound50621 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,1296,7424,3142,2064,2421,1025,7425,7505,32,16,7426,349,64,2049,5392,3328,6501,2117,3377,257,4144,2129,513]

theorem envBound50622 : H12AffineFastState.Bounded env50622 := by
  intro p hp
  have h : env50622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50621_50622 : H12AffineEnvironment.transform 13 1296 env50621 = env50622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50621 == env50622) = true)

theorem identity50622 : scanCanonicalize (H12AffineFastState.compose env50622 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50622 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50623 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,0,6160,2390,2064,2421,273,6161,6209,32,16,6162,349,64,2049,4096,2064,6501,2117,2081,257,4144,2129,513]

theorem envBound50623 : H12AffineFastState.Bounded env50623 := by
  intro p hp
  have h : env50623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50622_50623 : H12AffineEnvironment.transform 9 272 env50622 = env50623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50622 == env50623) = true)

theorem identity50623 : scanCanonicalize (H12AffineFastState.compose env50623 (packedSelected [3,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound50623 : packedSelected [3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env50624 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,4096,348,0,4405,115,309,80,273,4404,4452,32,16,4407,349,64,292,4096,309,4160,352,260,257,4144,372,513]

theorem envBound50624 : H12AffineFastState.Bounded env50624 := by
  intro p hp
  have h : env50624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50623_50624 : H12AffineEnvironment.transform 10 293 env50623 = env50624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env50623 == env50624) = true)

theorem identity50624 : scanCanonicalize (H12AffineFastState.compose env50624 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50624 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env50625 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,17,348,0,292,115,309,80,273,293,373,32,16,294,349,64,292,17,309,81,352,260,257,33,372,513]

theorem envBound50625 : H12AffineFastState.Bounded env50625 := by
  intro p hp
  have h : env50625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50624_50625 : H12AffineEnvironment.transform 11 17 env50624 = env50625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50624 == env50625) = true)

theorem identity50625 : scanCanonicalize (H12AffineFastState.compose env50625 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50625 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env50626 : List Nat := [2,4,8,16,32,64,9,37,512,53,0,17,121,0,1,115,16,80,52,0,80,32,16,3,120,64,1,17,16,81,69,33,36,33,81,513]

theorem envBound50626 : H12AffineFastState.Bounded env50626 := by
  intro p hp
  have h : env50626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50625_50626 : H12AffineEnvironment.transform 7 37 env50625 = env50626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50625 == env50626) = true)

theorem identity50626 : scanCanonicalize (H12AffineFastState.compose env50626 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50627 : List Nat := [2,4,8,16,32,17,9,37,512,53,0,17,40,0,1,34,16,1,52,0,1,32,16,3,41,17,1,17,16,0,20,33,36,33,0,513]

theorem envBound50627 : H12AffineFastState.Bounded env50627 := by
  intro p hp
  have h : env50627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50626_50627 : H12AffineEnvironment.transform 5 17 env50626 = env50627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50626 == env50627) = true)

theorem identity50627 : scanCanonicalize (H12AffineFastState.compose env50627 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound50627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50628 : List Nat := [2,4,8,16,32,17,9,37,33,53,0,17,40,0,1,34,16,1,52,0,1,32,16,3,41,17,1,17,16,0,20,33,36,33,0,32]

theorem envBound50628 : H12AffineFastState.Bounded env50628 := by
  intro p hp
  have h : env50628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50627_50628 : H12AffineEnvironment.transform 8 33 env50627 = env50628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env50627 == env50628) = true)

theorem identity50628 : scanCanonicalize (H12AffineFastState.compose env50628 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50629 : List Nat := [2,4,8,16,17,17,9,20,16,4,0,17,25,0,1,19,16,1,5,0,1,17,16,3,24,17,1,17,16,0,20,16,21,16,0,17]

theorem envBound50629 : H12AffineFastState.Bounded env50629 := by
  intro p hp
  have h : env50629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50628_50629 : H12AffineEnvironment.transform 4 17 env50628 = env50629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50628 == env50629) = true)

def env50630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169216,95496,8328,64,2185,163840,45525,283904,156697,412108,257,21792,46212,213966]

theorem envBound50630 : H12AffineFastState.Bounded env50630 := by
  intro p hp
  have h : env50630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50596_50630 : H12AffineEnvironment.transform 21 272513 env50596 = env50630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50596 == env50630) = true)

theorem identity50630 : scanCanonicalize (H12AffineFastState.compose env50630 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound50630 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,160132,272513,169216,41430,8328,64,2185,163840,45525,283904,156697,412108,257,21792,46212,169744]

theorem envBound50631 : H12AffineFastState.Bounded env50631 := by
  intro p hp
  have h : env50631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50630_50631 : H12AffineEnvironment.transform 15 54494 env50630 = env50631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env50630 == env50631) = true)

def env50632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160012,272393,169216,41310,8192,64,2049,163840,45405,283904,156697,411972,257,21792,46092,169744]

theorem envBound50632 : H12AffineFastState.Bounded env50632 := by
  intro p hp
  have h : env50632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50631_50632 : H12AffineEnvironment.transform 6 8 env50631 = env50632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50631 == env50632) = true)

theorem identity50632 : scanCanonicalize (H12AffineFastState.compose env50632 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(16+1) ^^^ 37989) := by decide +kernel

theorem selectedBound50632 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env50633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,37989,262144,1025,32769,58729,272393,357,41310,8192,64,2049,5221,45405,283904,61564,318753,257,21792,46092,885]

theorem envBound50633 : H12AffineFastState.Bounded env50633 := by
  intro p hp
  have h : env50633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50632_50633 : H12AffineEnvironment.transform 16 37989 env50632 = env50633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37989 env50632 == env50633) = true)

theorem identity50633 : scanCanonicalize (H12AffineFastState.compose env50633 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound50633 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env50634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,37989,34816,1025,32769,58729,40969,357,41310,8192,64,2049,5221,45405,56576,61564,21793,257,21792,46092,885]

theorem envBound50634 : H12AffineFastState.Bounded env50634 := by
  intro p hp
  have h : env50634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50633_50634 : H12AffineEnvironment.transform 17 34816 env50633 = env50634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env50633 == env50634) = true)

theorem identity50634 : scanCanonicalize (H12AffineFastState.compose env50634 (packedSelected [0,2,5,6,11,12,14,15,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound50634 : packedSelected [0,2,5,6,11,12,14,15,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,21874,5441,2340,1025,293,25677,8493,357,8314,8192,64,2049,5221,12409,23588,29016,21793,257,21792,13608,885]

theorem envBound50635 : H12AffineFastState.Bounded env50635 := by
  intro p hp
  have h : env50635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50634_50635 : H12AffineEnvironment.transform 14 292 env50634 = env50635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env50634 == env50635) = true)

theorem identity50635 : scanCanonicalize (H12AffineFastState.compose env50635 (packedSelected [2,3,4,5,6,10,11,12,15,16,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound50635 : packedSelected [2,3,4,5,6,10,11,12,15,16,22,23] rootPS < 2^1333 := by decide +kernel

def env50636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,292,8202,5441,2340,1025,293,4405,8493,357,8314,8192,64,2049,5221,12409,10588,1056,8281,257,8280,13608,885]

theorem envBound50636 : H12AffineFastState.Bounded env50636 := by
  intro p hp
  have h : env50636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50635_50636 : H12AffineEnvironment.transform 13 13688 env50635 = env50636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env50635 == env50636) = true)

theorem identity50636 : scanCanonicalize (H12AffineFastState.compose env50636 (packedSelected [1,2,3,4,5,7,8,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 3628) := by decide +kernel

theorem selectedBound50636 : packedSelected [1,2,3,4,5,7,8,10,14,16] rootPS < 2^1333 := by decide +kernel

def env50637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3628,6996,292,3622,5441,2340,1025,293,4405,3841,357,3670,3628,64,2049,5221,7765,1904,1056,3701,257,3700,6916,885]

theorem envBound50637 : H12AffineFastState.Bounded env50637 := by
  intro p hp
  have h : env50637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50636_50637 : H12AffineEnvironment.transform 12 3628 env50636 = env50637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3628 env50636 == env50637) = true)

theorem identity50637 : scanCanonicalize (H12AffineFastState.compose env50637 (packedSelected [0,1,4,6,8,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50637 : packedSelected [0,1,4,6,8,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50638 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,3628,6769,1,3622,5220,2049,1025,0,4112,3620,64,3670,3628,64,2049,5221,7765,1621,1056,3701,36,3700,6689,592]

theorem envBound50638 : H12AffineFastState.Bounded env50638 := by
  intro p hp
  have h : env50638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50637_50638 : H12AffineEnvironment.transform 7 37 env50637 = env50638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50637 == env50638) = true)

theorem identity50638 : scanCanonicalize (H12AffineFastState.compose env50638 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound50638 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50639 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,3628,6656,1,3622,5141,2049,1025,0,4112,3620,49,3623,3628,49,2049,5140,7716,1572,1056,3588,36,3589,6689,545]

theorem envBound50639 : H12AffineFastState.Bounded env50639 := by
  intro p hp
  have h : env50639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50638_50639 : H12AffineEnvironment.transform 5 49 env50638 = env50639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env50638 == env50639) = true)

theorem identity50639 : scanCanonicalize (H12AffineFastState.compose env50639 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound50639 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50640 : List Nat := [2,4,8,16,32,49,8,37,512,1024,1540,4096,40,5124,1,34,5141,1541,1025,0,4112,32,49,35,40,49,1541,5140,4128,1572,1056,0,36,1,5157,545]

theorem envBound50640 : H12AffineFastState.Bounded env50640 := by
  intro p hp
  have h : env50640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50639_50640 : H12AffineEnvironment.transform 10 1540 env50639 = env50640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env50639 == env50640) = true)

theorem identity50640 : scanCanonicalize (H12AffineFastState.compose env50640 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50640 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50641 : List Nat := [2,4,8,16,32,49,8,37,512,21,529,4096,40,4113,1,34,4096,528,20,0,4112,32,49,35,40,49,528,4097,4128,561,53,0,36,1,4144,545]

theorem envBound50641 : H12AffineFastState.Bounded env50641 := by
  intro p hp
  have h : env50641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50640_50641 : H12AffineEnvironment.transform 9 21 env50640 = env50641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50640 == env50641) = true)

end H12CloudChart0