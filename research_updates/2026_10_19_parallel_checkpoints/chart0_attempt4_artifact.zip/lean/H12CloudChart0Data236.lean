import H12CloudChart0Data235

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound59877 : H12AffineFastState.Bounded env59877 := by
  intro p hp
  have h : env59877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59876_59877 : H12AffineEnvironment.transform 15 7422 env59876 = env59877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59876 == env59877) = true)

def env59878 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,2097152,1417,65,3159,1289,16,2365812,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59878 : H12AffineFastState.Bounded env59878 := by
  intro p hp
  have h : env59878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59877_59878 : H12AffineEnvironment.transform 12 1408 env59877 = env59878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59877 == env59878) = true)

theorem identity59878 : scanCanonicalize (H12AffineFastState.compose env59878 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59878 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59879 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,1028,1417,65,3159,1289,16,269680,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59879 : H12AffineFastState.Bounded env59879 := by
  intro p hp
  have h : env59879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59878_59879 : H12AffineEnvironment.transform 20 1028 env59878 = env59879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59878 == env59879) = true)

theorem identity59879 : scanCanonicalize (H12AffineFastState.compose env59879 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59879 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59880 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,3528,1025,2128,1028,1417,65,3159,1289,16,4280,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59880 : H12AffineFastState.Bounded env59880 := by
  intro p hp
  have h : env59880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59879_59880 : H12AffineEnvironment.transform 17 3528 env59879 = env59880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59879 == env59880) = true)

theorem identity59880 : scanCanonicalize (H12AffineFastState.compose env59880 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59880 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59881 : List Nat := [2,4,8,16,32,64,128,256,1,1024,48,4096,1408,4176,96,5326,412,1528,1025,96,1028,1417,65,1127,1289,16,4280,4177,460,4508,5321,5377,256,5188,412,1]

theorem envBound59881 : H12AffineFastState.Bounded env59881 := by
  intro p hp
  have h : env59881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59880_59881 : H12AffineEnvironment.transform 10 48 env59880 = env59881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59880 == env59881) = true)

theorem identity59881 : scanCanonicalize (H12AffineFastState.compose env59881 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59881 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59882 : List Nat := [2,4,8,16,32,64,128,256,1,237,48,4096,365,4176,96,4131,412,277,236,96,233,356,65,138,484,16,4280,4177,460,4508,4132,4588,256,4265,412,1]

theorem envBound59882 : H12AffineFastState.Bounded env59882 := by
  intro p hp
  have h : env59882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59881_59882 : H12AffineEnvironment.transform 9 237 env59881 = env59882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59881 == env59882) = true)

theorem identity59882 : scanCanonicalize (H12AffineFastState.compose env59882 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59882 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env59883 : List Nat := [2,4,8,16,32,64,128,256,1,237,48,460,365,412,96,495,412,277,236,96,233,356,65,138,484,16,372,413,460,80,488,32,256,357,412,1]

theorem envBound59883 : H12AffineFastState.Bounded env59883 := by
  intro p hp
  have h : env59883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59882_59883 : H12AffineEnvironment.transform 11 460 env59882 = env59883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59882 == env59883) = true)

theorem identity59883 : scanCanonicalize (H12AffineFastState.compose env59883 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59883 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59884 : List Nat := [2,4,8,16,32,64,128,182,1,237,48,122,219,42,96,89,42,163,236,96,233,210,65,138,82,16,194,43,122,80,94,32,182,211,42,1]

theorem envBound59884 : H12AffineFastState.Bounded env59884 := by
  intro p hp
  have h : env59884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59883_59884 : H12AffineEnvironment.transform 7 182 env59883 = env59884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59883 == env59884) = true)

theorem identity59884 : scanCanonicalize (H12AffineFastState.compose env59884 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59884 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59885 : List Nat := [2,4,8,16,32,64,114,68,1,31,48,122,41,42,96,89,42,81,30,96,27,32,65,120,82,16,48,43,122,80,94,32,68,33,42,1]

theorem envBound59885 : H12AffineFastState.Bounded env59885 := by
  intro p hp
  have h : env59885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59884_59885 : H12AffineEnvironment.transform 6 114 env59884 = env59885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59884 == env59885) = true)

def env59886 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,2097152,1417,64,3159,1289,17,2365812,4177,2557,6572,7417,5377,256,7284,2477,0]

theorem envBound59886 : H12AffineFastState.Bounded env59886 := by
  intro p hp
  have h : env59886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59877_59886 : H12AffineEnvironment.transform 12 1409 env59877 = env59886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59877 == env59886) = true)

theorem identity59886 : scanCanonicalize (H12AffineFastState.compose env59886 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59886 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59887 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,6653,1417,64,3159,1289,17,262281,4177,2557,6572,7417,5377,256,7284,2477,0]

theorem envBound59887 : H12AffineFastState.Bounded env59887 := by
  intro p hp
  have h : env59887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59886_59887 : H12AffineEnvironment.transform 20 6653 env59886 = env59887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59886 == env59887) = true)

theorem identity59887 : scanCanonicalize (H12AffineFastState.compose env59887 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59887 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59888 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,4358,1109,262144,1025,1448,5125,1417,64,431,1289,17,262281,4177,1029,5204,4353,5377,256,4492,1109,0]

theorem envBound59888 : H12AffineFastState.Bounded env59888 := by
  intro p hp
  have h : env59888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59887_59888 : H12AffineEnvironment.transform 10 1528 env59887 = env59888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59887 == env59888) = true)

theorem identity59888 : scanCanonicalize (H12AffineFastState.compose env59888 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound59888 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59889 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,4358,1109,1513,1025,1448,5125,1417,64,431,1289,17,1376,4177,1029,5204,4353,5377,256,4492,1109,0]

theorem envBound59889 : H12AffineFastState.Bounded env59889 := by
  intro p hp
  have h : env59889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59888_59889 : H12AffineEnvironment.transform 17 1513 env59888 = env59889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env59888 == env59889) = true)

theorem identity59889 : scanCanonicalize (H12AffineFastState.compose env59889 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59889 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59890 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1313,1409,1393,1448,1063,1109,1513,1025,1448,292,1417,64,431,1289,17,1376,1392,1029,373,1056,32,256,1197,1109,0]

theorem envBound59890 : H12AffineFastState.Bounded env59890 := by
  intro p hp
  have h : env59890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59889_59890 : H12AffineEnvironment.transform 11 1313 env59889 = env59890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59889 == env59890) = true)

theorem identity59890 : scanCanonicalize (H12AffineFastState.compose env59890 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59890 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59891 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,1245,1149,1165,1108,1063,1109,1045,1025,1108,216,1141,64,83,1269,17,1180,1164,1029,137,1056,32,252,1197,1109,0]

theorem envBound59891 : H12AffineFastState.Bounded env59891 := by
  intro p hp
  have h : env59891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59890_59891 : H12AffineEnvironment.transform 7 252 env59890 = env59891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59890 == env59891) = true)

theorem identity59891 : scanCanonicalize (H12AffineFastState.compose env59891 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59891 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59892 : List Nat := [2,4,8,16,32,64,128,252,1,141,137,80,240,0,217,170,216,152,140,217,216,248,64,83,120,17,17,1,136,137,173,32,252,32,216,0]

theorem envBound59892 : H12AffineFastState.Bounded env59892 := by
  intro p hp
  have h : env59892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59891_59892 : H12AffineEnvironment.transform 9 141 env59891 = env59892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59891 == env59892) = true)

theorem identity59892 : scanCanonicalize (H12AffineFastState.compose env59892 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound59892 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59893 : List Nat := [2,4,8,16,32,49,128,141,1,141,137,33,129,0,168,170,169,152,140,168,169,137,49,34,9,17,17,1,136,137,173,32,141,32,169,0]

theorem envBound59893 : H12AffineFastState.Bounded env59893 := by
  intro p hp
  have h : env59893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59892_59893 : H12AffineEnvironment.transform 5 49 env59892 = env59893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env59892 == env59893) = true)

theorem identity59893 : scanCanonicalize (H12AffineFastState.compose env59893 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound59893 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59894 : List Nat := [2,4,8,16,25,8,128,141,1,141,137,24,129,0,145,147,144,152,140,145,144,137,8,27,9,17,17,1,136,137,148,25,141,25,144,0]

theorem envBound59894 : H12AffineFastState.Bounded env59894 := by
  intro p hp
  have h : env59894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59893_59894 : H12AffineEnvironment.transform 4 25 env59893 = env59894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env59893 == env59894) = true)

theorem identity59894 : scanCanonicalize (H12AffineFastState.compose env59894 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound59894 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env59895 : List Nat := [2,4,8,16,25,8,19,30,1,30,26,24,18,0,2,0,3,11,31,2,3,26,8,27,9,17,17,1,27,26,7,25,30,25,3,0]

theorem envBound59895 : H12AffineFastState.Bounded env59895 := by
  intro p hp
  have h : env59895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59894_59895 : H12AffineEnvironment.transform 6 19 env59894 = env59895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env59894 == env59895) = true)

theorem identity59895 : scanCanonicalize (H12AffineFastState.compose env59895 (packedSelected [1,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59895 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env59896 : List Nat := [1,4,8,16,25,8,16,29,1,29,25,24,17,0,1,0,0,8,28,1,0,25,8,24,9,17,17,1,24,25,4,25,29,25,0,0]

theorem envBound59896 : H12AffineFastState.Bounded env59896 := by
  intro p hp
  have h : env59896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59895_59896 : H12AffineEnvironment.transform 0 1 env59895 = env59896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59895 == env59896) = true)

theorem identity59896 : scanCanonicalize (H12AffineFastState.compose env59896 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59896 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59897 : List Nat := [1,4,1,16,16,1,16,20,1,20,16,17,17,0,1,0,0,1,21,1,0,16,1,17,0,17,17,1,17,16,4,16,20,16,0,0]

theorem envBound59897 : H12AffineFastState.Bounded env59897 := by
  intro p hp
  have h : env59897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59896_59897 : H12AffineEnvironment.transform 2 1 env59896 = env59897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59896 == env59897) = true)

theorem identity59897 : scanCanonicalize (H12AffineFastState.compose env59897 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59897 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59898 : List Nat := [1,4,1,0,0,1,0,4,1,4,0,1,1,0,1,0,0,1,5,1,0,0,1,1,0,1,1,1,1,0,4,0,4,0,0,0]

theorem envBound59898 : H12AffineFastState.Bounded env59898 := by
  intro p hp
  have h : env59898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59897_59898 : H12AffineEnvironment.transform 3 0 env59897 = env59898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59897 == env59898) = true)

def env59899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397000,8388689,6561533,4177,77954,4260570,8463814,8465982,256,4261122,78034,8389185]

theorem envBound59899 : H12AffineFastState.Bounded env59899 := by
  intro p hp
  have h : env59899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59713_59899 : H12AffineEnvironment.transform 26 6561533 env59713 = env59899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env59713 == env59899) = true)

def env59900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399767,8397000,8388689,2366325,4177,77954,67410,8463814,8465982,256,65674,78034,8389185]

theorem envBound59900 : H12AffineFastState.Bounded env59900 := by
  intro p hp
  have h : env59900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59899_59900 : H12AffineEnvironment.transform 21 1416 env59899 = env59900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59899 == env59900) = true)

def env59901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3671,1288,9617,2366325,4177,77954,67410,65542,68606,256,65674,78034,10113]

theorem envBound59901 : H12AffineFastState.Bounded env59901 := by
  intro p hp
  have h : env59901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59900_59901 : H12AffineEnvironment.transform 22 9664 env59900 = env59901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59900 == env59901) = true)

def env59902 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1288,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59902 : H12AffineFastState.Bounded env59902 := by
  intro p hp
  have h : env59902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59901_59902 : H12AffineEnvironment.transform 8 0 env59901 = env59902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59901 == env59902) = true)

theorem identity59902 : scanCanonicalize (H12AffineFastState.compose env59902 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 8580) := by decide +kernel

theorem selectedBound59902 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59903 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,8580,1416,9664,3159,1288,9617,276721,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59903 : H12AffineFastState.Bounded env59903 := by
  intro p hp
  have h : env59903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59902_59903 : H12AffineEnvironment.transform 20 8580 env59902 = env59903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 8580 env59902 == env59903) = true)

def env59904 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,1028,1416,64,3159,1288,17,269681,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound59904 : H12AffineFastState.Bounded env59904 := by
  intro p hp
  have h : env59904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59903_59904 : H12AffineEnvironment.transform 12 1408 env59903 = env59904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59903 == env59904) = true)

theorem identity59904 : scanCanonicalize (H12AffineFastState.compose env59904 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3576) := by decide +kernel

theorem selectedBound59904 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59905 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3576,1408,3496,2129,65536,67754,262144,1025,2129,1028,1416,64,3159,1288,17,262281,3497,67834,66898,65542,68094,256,65674,67754,1]

theorem envBound59905 : H12AffineFastState.Bounded env59905 := by
  intro p hp
  have h : env59905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59904_59905 : H12AffineEnvironment.transform 11 3576 env59904 = env59905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3576 env59904 == env59905) = true)

theorem identity59905 : scanCanonicalize (H12AffineFastState.compose env59905 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59905 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59906 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1449,65536,66898,262144,1025,1449,1028,1416,64,431,1288,17,262281,81,66818,66898,65542,66566,256,65674,66898,1]

theorem envBound59906 : H12AffineFastState.Bounded env59906 := by
  intro p hp
  have h : env59906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59905_59906 : H12AffineEnvironment.transform 10 1528 env59905 = env59906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59905 == env59906) = true)

theorem identity59906 : scanCanonicalize (H12AffineFastState.compose env59906 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66799) := by decide +kernel

theorem selectedBound59906 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59907 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1449,65536,66898,66799,1025,1449,1028,1416,64,431,1288,17,66662,81,66818,66898,65542,66566,256,65674,66898,1]

theorem envBound59907 : H12AffineFastState.Bounded env59907 := by
  intro p hp
  have h : env59907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59906_59907 : H12AffineEnvironment.transform 17 66799 env59906 = env59907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66799 env59906 == env59907) = true)

theorem identity59907 : scanCanonicalize (H12AffineFastState.compose env59907 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59907 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59908 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1449,1062,372,201,1025,1449,1028,1416,64,431,1288,17,64,81,292,372,1056,32,256,1196,372,1]

theorem envBound59908 : H12AffineFastState.Bounded env59908 := by
  intro p hp
  have h : env59908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59907_59908 : H12AffineEnvironment.transform 15 1062 env59907 = env59908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59907 == env59908) = true)

theorem identity59908 : scanCanonicalize (H12AffineFastState.compose env59908 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59908 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59909 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,0,1149,80,1108,1062,137,201,1025,1108,1028,1141,64,82,1269,17,64,81,217,137,1056,32,253,1196,137,1]

theorem envBound59909 : H12AffineFastState.Bounded env59909 := by
  intro p hp
  have h : env59909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59908_59909 : H12AffineEnvironment.transform 7 253 env59908 = env59909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59908 == env59909) = true)

theorem identity59909 : scanCanonicalize (H12AffineFastState.compose env59909 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59909 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59910 : List Nat := [2,4,8,16,32,64,128,253,0,140,137,0,241,80,216,170,137,201,141,216,136,249,64,82,121,17,64,81,217,137,172,32,253,32,137,1]

theorem envBound59910 : H12AffineFastState.Bounded env59910 := by
  intro p hp
  have h : env59910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59909_59910 : H12AffineEnvironment.transform 9 140 env59909 = env59910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59909 == env59910) = true)

theorem identity59910 : scanCanonicalize (H12AffineFastState.compose env59910 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59910 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59911 : List Nat := [2,4,8,16,32,64,89,36,0,85,80,0,40,80,1,115,80,16,84,1,81,32,64,82,121,17,64,81,0,80,117,32,36,32,80,1]

theorem envBound59911 : H12AffineFastState.Bounded env59911 := by
  intro p hp
  have h : env59911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59910_59911 : H12AffineEnvironment.transform 6 89 env59910 = env59911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59910 == env59911) = true)

theorem identity59911 : scanCanonicalize (H12AffineFastState.compose env59911 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59911 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59912 : List Nat := [2,4,8,16,32,1,24,36,0,20,17,0,40,17,1,50,17,16,21,1,16,32,1,19,56,17,1,16,0,17,52,32,36,32,17,1]

theorem envBound59912 : H12AffineFastState.Bounded env59912 := by
  intro p hp
  have h : env59912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59911_59912 : H12AffineEnvironment.transform 5 1 env59911 = env59912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59911 == env59912) = true)

theorem identity59912 : scanCanonicalize (H12AffineFastState.compose env59912 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59912 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59913 : List Nat := [1,4,8,16,32,1,24,36,0,20,17,0,40,17,1,49,17,16,21,1,16,32,1,16,56,17,1,16,0,17,52,32,36,32,17,1]

theorem envBound59913 : H12AffineFastState.Bounded env59913 := by
  intro p hp
  have h : env59913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59912_59913 : H12AffineEnvironment.transform 0 1 env59912 = env59913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59912 == env59913) = true)

theorem identity59913 : scanCanonicalize (H12AffineFastState.compose env59913 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59913 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59914 : List Nat := [1,4,1,16,32,1,17,36,0,20,17,0,33,17,1,49,17,16,21,1,16,32,1,16,49,17,1,16,0,17,52,32,36,32,17,1]

theorem envBound59914 : H12AffineFastState.Bounded env59914 := by
  intro p hp
  have h : env59914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59913_59914 : H12AffineEnvironment.transform 2 1 env59913 = env59914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59913 == env59914) = true)

theorem identity59914 : scanCanonicalize (H12AffineFastState.compose env59914 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59914 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59915 : List Nat := [1,4,1,16,16,1,17,20,0,20,17,0,17,17,1,1,17,16,21,1,16,16,1,16,1,17,1,16,0,17,4,16,20,16,17,1]

theorem envBound59915 : H12AffineFastState.Bounded env59915 := by
  intro p hp
  have h : env59915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59914_59915 : H12AffineEnvironment.transform 4 16 env59914 = env59915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59914 == env59915) = true)

theorem identity59915 : scanCanonicalize (H12AffineFastState.compose env59915 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59916 : List Nat := [1,4,1,0,0,1,1,4,0,4,1,0,1,1,1,1,1,0,5,1,0,0,1,0,1,1,1,0,0,1,4,0,4,0,1,1]

theorem envBound59916 : H12AffineFastState.Bounded env59916 := by
  intro p hp
  have h : env59916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59915_59916 : H12AffineEnvironment.transform 3 0 env59915 = env59916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59915 == env59916) = true)

def env59917 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,1029,1416,65,3159,1288,16,269680,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound59917 : H12AffineFastState.Bounded env59917 := by
  intro p hp
  have h : env59917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59903_59917 : H12AffineEnvironment.transform 12 1409 env59903 = env59917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59903 == env59917) = true)

theorem identity59917 : scanCanonicalize (H12AffineFastState.compose env59917 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59917 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59918 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,1029,1416,65,3159,1288,16,269680,4177,2557,6572,7416,5376,256,7284,2477,0]

theorem envBound59918 : H12AffineFastState.Bounded env59918 := by
  intro p hp
  have h : env59918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59917_59918 : H12AffineEnvironment.transform 15 7422 env59917 = env59918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59917 == env59918) = true)

theorem identity59918 : scanCanonicalize (H12AffineFastState.compose env59918 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59918 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59919 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,3529,1025,2129,1029,1416,65,3159,1288,16,4281,4177,2557,6572,7416,5376,256,7284,2477,0]

theorem envBound59919 : H12AffineFastState.Bounded env59919 := by
  intro p hp
  have h : env59919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59918_59919 : H12AffineEnvironment.transform 17 3529 env59918 = env59919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59918 == env59919) = true)

theorem identity59919 : scanCanonicalize (H12AffineFastState.compose env59919 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59919 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59920 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,4096,1409,4176,96,5327,412,1528,1025,96,1029,1416,65,1126,1288,16,4281,4177,460,4509,5321,5376,256,5189,412,0]

theorem envBound59920 : H12AffineFastState.Bounded env59920 := by
  intro p hp
  have h : env59920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59919_59920 : H12AffineEnvironment.transform 10 49 env59919 = env59920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59919 == env59920) = true)

theorem identity59920 : scanCanonicalize (H12AffineFastState.compose env59920 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound59920 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59921 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,1312,1409,1392,96,495,412,1528,1025,96,1029,1416,65,1126,1288,16,1433,1393,460,1213,489,32,256,357,412,0]

theorem envBound59921 : H12AffineFastState.Bounded env59921 := by
  intro p hp
  have h : env59921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59920_59921 : H12AffineEnvironment.transform 11 1312 env59920 = env59921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env59920 == env59921) = true)

theorem identity59921 : scanCanonicalize (H12AffineFastState.compose env59921 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59921 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59922 : List Nat := [2,4,8,16,32,64,128,256,0,236,49,460,365,412,96,495,412,276,237,96,233,356,65,138,484,16,373,413,460,81,489,32,256,357,412,0]

theorem envBound59922 : H12AffineFastState.Bounded env59922 := by
  intro p hp
  have h : env59922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59921_59922 : H12AffineEnvironment.transform 9 236 env59921 = env59922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59921 == env59922) = true)

theorem identity59922 : scanCanonicalize (H12AffineFastState.compose env59922 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59922 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59923 : List Nat := [2,4,8,16,32,64,128,182,0,236,49,122,219,42,96,89,42,162,237,96,233,210,65,138,82,16,195,43,122,81,95,32,182,211,42,0]

theorem envBound59923 : H12AffineFastState.Bounded env59923 := by
  intro p hp
  have h : env59923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59922_59923 : H12AffineEnvironment.transform 7 182 env59922 = env59923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59922 == env59923) = true)

theorem identity59923 : scanCanonicalize (H12AffineFastState.compose env59923 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59923 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59924 : List Nat := [2,4,8,16,32,64,114,68,0,30,49,122,41,42,96,89,42,80,31,96,27,32,65,120,82,16,49,43,122,81,95,32,68,33,42,0]

theorem envBound59924 : H12AffineFastState.Bounded env59924 := by
  intro p hp
  have h : env59924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59923_59924 : H12AffineEnvironment.transform 6 114 env59923 = env59924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59923 == env59924) = true)

def env59925 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1288,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59925 : H12AffineFastState.Bounded env59925 := by
  intro p hp
  have h : env59925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59901_59925 : H12AffineEnvironment.transform 8 1 env59901 = env59925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59901 == env59925) = true)

theorem identity59925 : scanCanonicalize (H12AffineFastState.compose env59925 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59926 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,1028,1416,9664,3158,1288,9617,269680,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59926 : H12AffineFastState.Bounded env59926 := by
  intro p hp
  have h : env59926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59925_59926 : H12AffineEnvironment.transform 20 1028 env59925 = env59926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59925 == env59926) = true)

def env59927 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,1028,1416,64,3158,1288,17,269680,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound59927 : H12AffineFastState.Bounded env59927 := by
  intro p hp
  have h : env59927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59926_59927 : H12AffineEnvironment.transform 12 1408 env59926 = env59927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59926 == env59927) = true)

theorem identity59927 : scanCanonicalize (H12AffineFastState.compose env59927 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3577) := by decide +kernel

theorem selectedBound59927 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59928 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3577,1408,3497,2128,65536,67755,262144,1025,2128,1028,1416,64,3158,1288,17,262281,3496,67835,66899,65542,68095,256,65674,67755,0]

theorem envBound59928 : H12AffineFastState.Bounded env59928 := by
  intro p hp
  have h : env59928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59927_59928 : H12AffineEnvironment.transform 11 3577 env59927 = env59928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3577 env59927 == env59928) = true)

theorem identity59928 : scanCanonicalize (H12AffineFastState.compose env59928 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59928 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59929 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1449,65536,66898,262144,1025,1449,1028,1416,64,431,1288,17,262281,81,66818,66899,65542,66566,256,65674,66898,0]

theorem envBound59929 : H12AffineFastState.Bounded env59929 := by
  intro p hp
  have h : env59929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59928_59929 : H12AffineEnvironment.transform 10 1529 env59928 = env59929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59928 == env59929) = true)

theorem identity59929 : scanCanonicalize (H12AffineFastState.compose env59929 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66799) := by decide +kernel

theorem selectedBound59929 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59930 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1449,65536,66898,66799,1025,1449,1028,1416,64,431,1288,17,66662,81,66818,66899,65542,66566,256,65674,66898,0]

theorem envBound59930 : H12AffineFastState.Bounded env59930 := by
  intro p hp
  have h : env59930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59929_59930 : H12AffineEnvironment.transform 17 66799 env59929 = env59930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66799 env59929 == env59930) = true)

theorem identity59930 : scanCanonicalize (H12AffineFastState.compose env59930 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59930 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59931 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1449,1062,372,201,1025,1449,1028,1416,64,431,1288,17,64,81,292,373,1056,32,256,1196,372,0]

theorem envBound59931 : H12AffineFastState.Bounded env59931 := by
  intro p hp
  have h : env59931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59930_59931 : H12AffineEnvironment.transform 15 1062 env59930 = env59931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59930 == env59931) = true)

theorem identity59931 : scanCanonicalize (H12AffineFastState.compose env59931 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59931 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59932 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,0,1148,80,1109,1062,136,201,1025,1109,1028,1140,64,83,1268,17,64,81,216,137,1056,32,252,1196,136,0]

theorem envBound59932 : H12AffineFastState.Bounded env59932 := by
  intro p hp
  have h : env59932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59931_59932 : H12AffineEnvironment.transform 7 252 env59931 = env59932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59931 == env59932) = true)

theorem identity59932 : scanCanonicalize (H12AffineFastState.compose env59932 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59932 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59933 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1029,0,1069,1,1028,1062,136,152,1025,1028,1028,1061,17,2,1189,17,17,0,137,137,1056,32,173,1196,136,0]

theorem envBound59933 : H12AffineFastState.Bounded env59933 := by
  intro p hp
  have h : env59933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59932_59933 : H12AffineEnvironment.transform 5 17 env59932 = env59933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59932 == env59933) = true)

theorem identity59933 : scanCanonicalize (H12AffineFastState.compose env59933 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound59933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59934 : List Nat := [2,4,8,16,32,17,42,7,1,1024,1029,0,1069,1,1028,1062,34,50,1025,1028,1028,1061,17,2,1039,17,17,0,35,35,1056,32,7,1030,34,0]

theorem envBound59934 : H12AffineFastState.Bounded env59934 := by
  intro p hp
  have h : env59934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59933_59934 : H12AffineEnvironment.transform 6 42 env59933 = env59934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env59933 == env59934) = true)

theorem identity59934 : scanCanonicalize (H12AffineFastState.compose env59934 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 54) := by decide +kernel

theorem selectedBound59934 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59935 : List Nat := [2,4,8,16,32,17,42,7,1,54,51,0,27,1,50,16,34,50,55,50,50,19,17,2,57,17,17,0,35,35,22,32,7,48,34,0]

theorem envBound59935 : H12AffineFastState.Bounded env59935 := by
  intro p hp
  have h : env59935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59934_59935 : H12AffineEnvironment.transform 9 54 env59934 = env59935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 54 env59934 == env59935) = true)

theorem identity59935 : scanCanonicalize (H12AffineFastState.compose env59935 (packedSelected [6,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59935 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59936 : List Nat := [1,4,8,16,32,17,41,4,1,53,48,0,24,1,49,16,33,49,52,49,49,16,17,1,57,17,17,0,32,32,21,32,4,48,33,0]

theorem envBound59936 : H12AffineFastState.Bounded env59936 := by
  intro p hp
  have h : env59936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59935_59936 : H12AffineEnvironment.transform 0 1 env59935 = env59936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59935 == env59936) = true)

theorem identity59936 : scanCanonicalize (H12AffineFastState.compose env59936 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59936 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59937 : List Nat := [1,4,0,16,32,17,33,4,1,53,48,0,16,1,49,16,33,49,52,49,49,16,17,1,49,17,17,0,32,32,21,32,4,48,33,0]

theorem envBound59937 : H12AffineFastState.Bounded env59937 := by
  intro p hp
  have h : env59937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59936_59937 : H12AffineEnvironment.transform 2 0 env59936 = env59937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59936 == env59937) = true)

theorem identity59937 : scanCanonicalize (H12AffineFastState.compose env59937 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59938 : List Nat := [1,4,0,16,17,17,16,4,1,4,1,0,16,1,0,16,16,0,5,0,0,16,17,1,0,17,17,0,17,17,21,17,4,1,16,0]

theorem envBound59938 : H12AffineFastState.Bounded env59938 := by
  intro p hp
  have h : env59938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59937_59938 : H12AffineEnvironment.transform 4 17 env59937 = env59938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59937 == env59938) = true)

def env59939 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,1028,1416,65,3158,1288,16,269680,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound59939 : H12AffineFastState.Bounded env59939 := by
  intro p hp
  have h : env59939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59926_59939 : H12AffineEnvironment.transform 12 1409 env59926 = env59939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59926 == env59939) = true)

theorem identity59939 : scanCanonicalize (H12AffineFastState.compose env59939 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59939 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59940 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,1028,1416,65,3158,1288,16,269680,4177,2557,6573,7416,5377,256,7284,2477,1]

theorem envBound59940 : H12AffineFastState.Bounded env59940 := by
  intro p hp
  have h : env59940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59939_59940 : H12AffineEnvironment.transform 15 7422 env59939 = env59940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59939 == env59940) = true)

theorem identity59940 : scanCanonicalize (H12AffineFastState.compose env59940 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59940 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59941 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,3529,1025,2128,1028,1416,65,3158,1288,16,4281,4177,2557,6573,7416,5377,256,7284,2477,1]

theorem envBound59941 : H12AffineFastState.Bounded env59941 := by
  intro p hp
  have h : env59941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59940_59941 : H12AffineEnvironment.transform 17 3529 env59940 = env59941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59940 == env59941) = true)

theorem identity59941 : scanCanonicalize (H12AffineFastState.compose env59941 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59941 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59942 : List Nat := [2,4,8,16,32,64,128,256,1,1024,48,4096,1409,4176,96,5326,413,1529,1025,96,1028,1416,65,1126,1288,16,4281,4177,461,4509,5320,5377,256,5188,413,1]

theorem envBound59942 : H12AffineFastState.Bounded env59942 := by
  intro p hp
  have h : env59942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59941_59942 : H12AffineEnvironment.transform 10 48 env59941 = env59942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59941 == env59942) = true)

theorem identity59942 : scanCanonicalize (H12AffineFastState.compose env59942 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59942 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59943 : List Nat := [2,4,8,16,32,64,128,256,1,236,48,4096,365,4176,96,4130,413,277,237,96,232,356,65,138,484,16,4281,4177,461,4509,4132,4589,256,4264,413,1]

theorem envBound59943 : H12AffineFastState.Bounded env59943 := by
  intro p hp
  have h : env59943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59942_59943 : H12AffineEnvironment.transform 9 236 env59942 = env59943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59942 == env59943) = true)

theorem identity59943 : scanCanonicalize (H12AffineFastState.compose env59943 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59943 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env59944 : List Nat := [2,4,8,16,32,64,128,256,1,236,48,461,365,413,96,495,413,277,237,96,232,356,65,138,484,16,372,412,461,80,489,32,256,357,413,1]

theorem envBound59944 : H12AffineFastState.Bounded env59944 := by
  intro p hp
  have h : env59944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59943_59944 : H12AffineEnvironment.transform 11 461 env59943 = env59944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59943 == env59944) = true)

theorem identity59944 : scanCanonicalize (H12AffineFastState.compose env59944 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59944 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59945 : List Nat := [2,4,8,16,32,64,128,182,1,236,48,123,219,43,96,89,43,163,237,96,232,210,65,138,82,16,194,42,123,80,95,32,182,211,43,1]

theorem envBound59945 : H12AffineFastState.Bounded env59945 := by
  intro p hp
  have h : env59945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59944_59945 : H12AffineEnvironment.transform 7 182 env59944 = env59945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59944 == env59945) = true)

theorem identity59945 : scanCanonicalize (H12AffineFastState.compose env59945 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59945 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59946 : List Nat := [2,4,8,16,32,64,114,68,1,30,48,123,41,43,96,89,43,81,31,96,26,32,65,120,82,16,48,42,123,80,95,32,68,33,43,1]

theorem envBound59946 : H12AffineFastState.Bounded env59946 := by
  intro p hp
  have h : env59946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59945_59946 : H12AffineEnvironment.transform 6 114 env59945 = env59946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59945 == env59946) = true)

def env59947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3670,1289,9616,2366325,4177,77954,67410,65543,68607,256,65674,78034,10112]

theorem envBound59947 : H12AffineFastState.Bounded env59947 := by
  intro p hp
  have h : env59947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59900_59947 : H12AffineEnvironment.transform 22 9665 env59900 = env59947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59900 == env59947) = true)

def env59948 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound59948 : H12AffineFastState.Bounded env59948 := by
  intro p hp
  have h : env59948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59947_59948 : H12AffineEnvironment.transform 8 0 env59947 = env59948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59947 == env59948) = true)

theorem identity59948 : scanCanonicalize (H12AffineFastState.compose env59948 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59949 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,8192,3076,2129,65536,76934,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2360609,3077,77014,66898,65543,68095,256,65674,76934,9600]

theorem envBound59949 : H12AffineFastState.Bounded env59949 := by
  intro p hp
  have h : env59949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59948_59949 : H12AffineEnvironment.transform 11 3156 env59948 = env59949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59948 == env59949) = true)

def env59950 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,2097152,1416,65,3158,1289,16,2360609,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59950 : H12AffineFastState.Bounded env59950 := by
  intro p hp
  have h : env59950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59949_59950 : H12AffineEnvironment.transform 12 1408 env59949 = env59950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59949 == env59950) = true)

theorem identity59950 : scanCanonicalize (H12AffineFastState.compose env59950 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59950 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59951 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,66734,1416,65,3158,1289,16,328079,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59951 : H12AffineFastState.Bounded env59951 := by
  intro p hp
  have h : env59951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59950_59951 : H12AffineEnvironment.transform 20 66734 env59950 = env59951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59950 == env59951) = true)

theorem identity59951 : scanCanonicalize (H12AffineFastState.compose env59951 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59951 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59952 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,68963,1025,2129,66734,1416,65,3158,1289,16,3308,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59952 : H12AffineFastState.Bounded env59952 := by
  intro p hp
  have h : env59952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59951_59952 : H12AffineEnvironment.transform 17 68963 env59951 = env59952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59951 == env59952) = true)

theorem identity59952 : scanCanonicalize (H12AffineFastState.compose env59952 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59952 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59953 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,2202,412,1529,1025,2129,3124,1416,65,3158,1289,16,3308,3077,460,3528,2205,357,256,2064,412,0]

theorem envBound59953 : H12AffineFastState.Bounded env59953 := by
  intro p hp
  have h : env59953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59952_59953 : H12AffineEnvironment.transform 15 2202 env59952 = env59953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59952 == env59953) = true)

theorem identity59953 : scanCanonicalize (H12AffineFastState.compose env59953 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59953 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59954 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,136,1408,216,1165,1094,412,1529,1025,1165,232,1416,65,138,1289,16,48,217,460,276,1089,357,256,1228,412,0]

theorem envBound59954 : H12AffineFastState.Bounded env59954 := by
  intro p hp
  have h : env59954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59953_59954 : H12AffineEnvironment.transform 10 1244 env59953 = env59954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59953 == env59954) = true)

theorem identity59954 : scanCanonicalize (H12AffineFastState.compose env59954 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59954 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59955 : List Nat := [2,4,8,16,32,64,128,256,0,424,372,136,40,216,293,494,412,81,425,293,232,32,65,138,161,16,48,217,460,276,489,357,256,356,412,0]

theorem envBound59955 : H12AffineFastState.Bounded env59955 := by
  intro p hp
  have h : env59955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59954_59955 : H12AffineEnvironment.transform 9 424 env59954 = env59955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59954 == env59955) = true)

theorem identity59955 : scanCanonicalize (H12AffineFastState.compose env59955 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59955 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59956 : List Nat := [2,4,8,16,32,64,128,69,0,237,49,136,40,216,96,171,217,81,236,96,232,32,65,138,161,16,48,217,137,81,172,32,69,33,217,0]

theorem envBound59956 : H12AffineFastState.Bounded env59956 := by
  intro p hp
  have h : env59956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59955_59956 : H12AffineEnvironment.transform 7 69 env59955 = env59956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59955 == env59956) = true)

theorem identity59956 : scanCanonicalize (H12AffineFastState.compose env59956 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound59956 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59957 : List Nat := [2,4,8,16,32,58,128,63,0,151,49,136,40,162,26,171,163,43,150,26,146,32,59,138,161,16,48,163,137,43,172,32,63,33,163,0]

theorem envBound59957 : H12AffineFastState.Bounded env59957 := by
  intro p hp
  have h : env59957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59956_59957 : H12AffineEnvironment.transform 5 58 env59956 = env59957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env59956 == env59957) = true)

def env59958 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,2097152,1416,64,3158,1289,17,2360609,3077,67927,66898,65543,68095,256,65674,67847,1]

theorem envBound59958 : H12AffineFastState.Bounded env59958 := by
  intro p hp
  have h : env59958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59949_59958 : H12AffineEnvironment.transform 12 1409 env59949 = env59958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59949 == env59958) = true)

theorem identity59958 : scanCanonicalize (H12AffineFastState.compose env59958 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59958 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59959 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,1448,1416,64,3158,1289,17,262281,3077,67927,66898,65543,68095,256,65674,67847,1]

theorem envBound59959 : H12AffineFastState.Bounded env59959 := by
  intro p hp
  have h : env59959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59958_59959 : H12AffineEnvironment.transform 20 1448 env59958 = env59959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59958 == env59959) = true)

theorem identity59959 : scanCanonicalize (H12AffineFastState.compose env59959 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59959 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59960 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1449,65536,66815,262144,1025,1449,1448,1416,64,430,1289,17,262281,509,66735,66898,65543,66567,256,65674,66815,1]

theorem envBound59960 : H12AffineFastState.Bounded env59960 := by
  intro p hp
  have h : env59960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59959_59960 : H12AffineEnvironment.transform 10 1528 env59959 = env59960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59959 == env59960) = true)

theorem identity59960 : scanCanonicalize (H12AffineFastState.compose env59960 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66882) := by decide +kernel

theorem selectedBound59960 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59961 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1449,65536,66815,66882,1025,1449,1448,1416,64,430,1289,17,67019,509,66735,66898,65543,66567,256,65674,66815,1]

theorem envBound59961 : H12AffineFastState.Bounded env59961 := by
  intro p hp
  have h : env59961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59960_59961 : H12AffineEnvironment.transform 17 66882 env59960 = env59961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66882 env59960 == env59961) = true)

theorem identity59961 : scanCanonicalize (H12AffineFastState.compose env59961 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59961 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59962 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1449,1062,217,356,1025,1449,1448,1416,64,430,1289,17,493,509,137,372,1057,33,256,1196,217,1]

theorem envBound59962 : H12AffineFastState.Bounded env59962 := by
  intro p hp
  have h : env59962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59961_59962 : H12AffineEnvironment.transform 15 1062 env59961 = env59962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59961 == env59962) = true)

theorem identity59962 : scanCanonicalize (H12AffineFastState.compose env59962 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59962 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59963 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,80,1149,0,1109,1062,217,152,1025,1109,1108,1140,64,82,1269,17,17,1,137,136,1057,33,252,1196,217,1]

theorem envBound59963 : H12AffineFastState.Bounded env59963 := by
  intro p hp
  have h : env59963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59962_59963 : H12AffineEnvironment.transform 7 252 env59962 = env59963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59962 == env59963) = true)

theorem identity59963 : scanCanonicalize (H12AffineFastState.compose env59963 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59963 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59964 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1028,1,1068,0,1028,1062,136,152,1025,1028,1029,1061,17,3,1188,17,17,1,137,136,1057,33,173,1196,136,1]

theorem envBound59964 : H12AffineFastState.Bounded env59964 := by
  intro p hp
  have h : env59964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59963_59964 : H12AffineEnvironment.transform 5 17 env59963 = env59964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59963 == env59964) = true)

theorem identity59964 : scanCanonicalize (H12AffineFastState.compose env59964 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound59964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59965 : List Nat := [2,4,8,16,3,17,128,142,0,1024,1028,1,1039,0,1028,1029,136,152,1025,1028,1029,1030,17,3,1159,17,17,1,137,136,1026,2,142,1167,136,1]

theorem envBound59965 : H12AffineFastState.Bounded env59965 := by
  intro p hp
  have h : env59965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59964_59965 : H12AffineEnvironment.transform 4 3 env59964 = env59965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env59964 == env59965) = true)

theorem identity59965 : scanCanonicalize (H12AffineFastState.compose env59965 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound59965 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59966 : List Nat := [2,4,8,16,3,17,128,142,0,156,152,1,147,0,152,153,136,152,157,152,153,154,17,3,27,17,17,1,137,136,158,2,142,19,136,1]

theorem envBound59966 : H12AffineFastState.Bounded env59966 := by
  intro p hp
  have h : env59966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59965_59966 : H12AffineEnvironment.transform 9 156 env59965 = env59966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env59965 == env59966) = true)

theorem identity59966 : scanCanonicalize (H12AffineFastState.compose env59966 (packedSelected [6,7] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound59966 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59967 : List Nat := [2,4,8,16,3,17,11,5,0,23,19,1,24,0,19,18,3,19,22,19,18,17,17,3,27,17,17,1,2,3,21,2,5,19,3,1]

theorem envBound59967 : H12AffineFastState.Bounded env59967 := by
  intro p hp
  have h : env59967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59966_59967 : H12AffineEnvironment.transform 6 11 env59966 = env59967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env59966 == env59967) = true)

theorem identity59967 : scanCanonicalize (H12AffineFastState.compose env59967 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59967 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59968 : List Nat := [2,4,0,16,3,17,3,5,0,23,19,1,16,0,19,18,3,19,22,19,18,17,17,3,19,17,17,1,2,3,21,2,5,19,3,1]

theorem envBound59968 : H12AffineFastState.Bounded env59968 := by
  intro p hp
  have h : env59968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59967_59968 : H12AffineEnvironment.transform 2 0 env59967 = env59968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59967 == env59968) = true)

theorem identity59968 : scanCanonicalize (H12AffineFastState.compose env59968 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59968 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59969 : List Nat := [2,4,0,2,3,3,3,5,0,5,1,1,2,0,1,0,3,1,4,1,0,3,3,3,1,3,3,1,2,3,7,2,5,1,3,1]

theorem envBound59969 : H12AffineFastState.Bounded env59969 := by
  intro p hp
  have h : env59969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59968_59969 : H12AffineEnvironment.transform 3 2 env59968 = env59969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59968 == env59969) = true)

def env59970 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound59970 : H12AffineFastState.Bounded env59970 := by
  intro p hp
  have h : env59970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59947_59970 : H12AffineEnvironment.transform 8 1 env59947 = env59970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59947 == env59970) = true)

theorem identity59970 : scanCanonicalize (H12AffineFastState.compose env59970 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6612) := by decide +kernel

theorem selectedBound59970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59971 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,6612,4176,2128,65536,67846,262144,1025,2128,2097152,1416,7189,3159,1289,7236,2365812,4177,67926,66899,65543,68094,256,65674,67846,7253]

theorem envBound59971 : H12AffineFastState.Bounded env59971 := by
  intro p hp
  have h : env59971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59970_59971 : H12AffineEnvironment.transform 12 6612 env59970 = env59971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6612 env59970 == env59971) = true)

def env59972 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,2097152,1416,65,3159,1289,16,2360608,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59972 : H12AffineFastState.Bounded env59972 := by
  intro p hp
  have h : env59972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59971_59972 : H12AffineEnvironment.transform 11 3156 env59971 = env59972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59971 == env59972) = true)

theorem identity59972 : scanCanonicalize (H12AffineFastState.compose env59972 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66735) := by decide +kernel

theorem selectedBound59972 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59973 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,66735,1416,65,3159,1289,16,328079,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59973 : H12AffineFastState.Bounded env59973 := by
  intro p hp
  have h : env59973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59972_59973 : H12AffineEnvironment.transform 20 66735 env59972 = env59973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66735 env59972 == env59973) = true)

theorem identity59973 : scanCanonicalize (H12AffineFastState.compose env59973 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59973 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59974 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,68963,1025,2128,66735,1416,65,3159,1289,16,3308,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59974 : H12AffineFastState.Bounded env59974 := by
  intro p hp
  have h : env59974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59973_59974 : H12AffineEnvironment.transform 17 68963 env59973 = env59974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59973 == env59974) = true)

theorem identity59974 : scanCanonicalize (H12AffineFastState.compose env59974 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59974 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59975 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,2203,413,1528,1025,2128,3124,1416,65,3159,1289,16,3308,3077,461,3528,2204,357,256,2065,413,1]

theorem envBound59975 : H12AffineFastState.Bounded env59975 := by
  intro p hp
  have h : env59975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59974_59975 : H12AffineEnvironment.transform 15 2203 env59974 = env59975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59974 == env59975) = true)

theorem identity59975 : scanCanonicalize (H12AffineFastState.compose env59975 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound59975 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59976 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1433,461,1408,413,1481,1282,413,1528,1025,1481,429,1416,65,462,1289,16,373,412,461,81,1285,357,256,1416,413,1]

theorem envBound59976 : H12AffineFastState.Bounded env59976 := by
  intro p hp
  have h : env59976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59975_59976 : H12AffineEnvironment.transform 10 1433 env59975 = env59976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env59975 == env59976) = true)

theorem identity59976 : scanCanonicalize (H12AffineFastState.compose env59976 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59976 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59977 : List Nat := [2,4,8,16,32,64,128,182,1,1024,1071,123,1078,43,1151,1204,43,1102,1025,1151,27,1086,65,120,1215,16,195,42,123,81,1203,211,182,1086,43,1]

theorem envBound59977 : H12AffineFastState.Bounded env59977 := by
  intro p hp
  have h : env59977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59976_59977 : H12AffineEnvironment.transform 7 182 env59976 = env59977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59976 == env59977) = true)

theorem identity59977 : scanCanonicalize (H12AffineFastState.compose env59977 (packedSelected [0,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59977 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env59978 : List Nat := [2,4,8,16,32,64,114,68,1,1024,1071,123,1078,43,1151,1094,43,1102,1025,1151,27,1086,65,120,1101,16,49,42,123,81,1089,33,68,1086,43,1]

theorem envBound59978 : H12AffineFastState.Bounded env59978 := by
  intro p hp
  have h : env59978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59977_59978 : H12AffineEnvironment.transform 6 114 env59977 = env59978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59977 == env59978) = true)

theorem identity59978 : scanCanonicalize (H12AffineFastState.compose env59978 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound59978 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59979 : List Nat := [2,4,8,16,32,64,114,68,1,30,49,123,40,43,97,88,43,80,31,97,27,32,65,120,83,16,49,42,123,81,95,33,68,32,43,1]

theorem envBound59979 : H12AffineFastState.Bounded env59979 := by
  intro p hp
  have h : env59979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59978_59979 : H12AffineEnvironment.transform 9 30 env59978 = env59979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env59978 == env59979) = true)

def env59980 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3157,1409,3077,2128,65536,67846,262144,1025,2128,2097152,1416,64,3159,1289,17,2360609,3076,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59980 : H12AffineFastState.Bounded env59980 := by
  intro p hp
  have h : env59980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59971_59980 : H12AffineEnvironment.transform 11 3157 env59971 = env59980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env59971 == env59980) = true)

theorem identity59980 : scanCanonicalize (H12AffineFastState.compose env59980 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59980 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59981 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3157,1409,3077,2128,65536,67846,262144,1025,2128,1448,1416,64,3159,1289,17,262281,3076,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59981 : H12AffineFastState.Bounded env59981 := by
  intro p hp
  have h : env59981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59980_59981 : H12AffineEnvironment.transform 20 1448 env59980 = env59981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59980 == env59981) = true)

theorem identity59981 : scanCanonicalize (H12AffineFastState.compose env59981 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59981 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59982 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1449,65536,66815,262144,1025,1449,1448,1416,64,430,1289,17,262281,509,66735,66899,65543,66567,256,65674,66815,0]

theorem envBound59982 : H12AffineFastState.Bounded env59982 := by
  intro p hp
  have h : env59982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59981_59982 : H12AffineEnvironment.transform 10 1529 env59981 = env59982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59981 == env59982) = true)

theorem identity59982 : scanCanonicalize (H12AffineFastState.compose env59982 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66882) := by decide +kernel

theorem selectedBound59982 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59983 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1449,65536,66815,66882,1025,1449,1448,1416,64,430,1289,17,67019,509,66735,66899,65543,66567,256,65674,66815,0]

theorem envBound59983 : H12AffineFastState.Bounded env59983 := by
  intro p hp
  have h : env59983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59982_59983 : H12AffineEnvironment.transform 17 66882 env59982 = env59983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66882 env59982 == env59983) = true)

theorem identity59983 : scanCanonicalize (H12AffineFastState.compose env59983 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59983 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59984 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1449,1062,217,356,1025,1449,1448,1416,64,430,1289,17,493,509,137,373,1057,33,256,1196,217,0]

theorem envBound59984 : H12AffineFastState.Bounded env59984 := by
  intro p hp
  have h : env59984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59983_59984 : H12AffineEnvironment.transform 15 1062 env59983 = env59984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59983 == env59984) = true)

theorem identity59984 : scanCanonicalize (H12AffineFastState.compose env59984 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59984 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59985 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,81,1148,1,1108,1062,217,153,1025,1108,1109,1141,64,83,1268,17,16,0,137,136,1057,33,253,1196,217,0]

theorem envBound59985 : H12AffineFastState.Bounded env59985 := by
  intro p hp
  have h : env59985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59984_59985 : H12AffineEnvironment.transform 7 253 env59984 = env59985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59984 == env59985) = true)

theorem identity59985 : scanCanonicalize (H12AffineFastState.compose env59985 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59985 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59986 : List Nat := [2,4,8,16,32,64,128,253,1,141,137,81,241,1,217,171,217,153,140,217,216,248,64,83,121,17,16,0,137,136,172,33,253,33,217,0]

theorem envBound59986 : H12AffineFastState.Bounded env59986 := by
  intro p hp
  have h : env59986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59985_59986 : H12AffineEnvironment.transform 9 141 env59985 = env59986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59985 == env59986) = true)

theorem identity59986 : scanCanonicalize (H12AffineFastState.compose env59986 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59986 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59987 : List Nat := [2,4,8,16,32,64,105,20,1,100,96,81,24,1,48,66,48,112,101,48,49,17,64,83,121,17,16,0,96,97,69,33,20,33,48,0]

theorem envBound59987 : H12AffineFastState.Bounded env59987 := by
  intro p hp
  have h : env59987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59986_59987 : H12AffineEnvironment.transform 6 105 env59986 = env59987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59986 == env59987) = true)

theorem identity59987 : scanCanonicalize (H12AffineFastState.compose env59987 (packedSelected [1,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59987 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env59988 : List Nat := [1,4,8,16,32,64,105,20,1,100,96,81,24,1,48,65,48,112,101,48,49,17,64,80,121,17,16,0,96,97,69,33,20,33,48,0]

theorem envBound59988 : H12AffineFastState.Bounded env59988 := by
  intro p hp
  have h : env59988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59987_59988 : H12AffineEnvironment.transform 0 1 env59987 = env59988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59987 == env59988) = true)

theorem identity59988 : scanCanonicalize (H12AffineFastState.compose env59988 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound59988 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59989 : List Nat := [1,4,8,16,32,9,32,20,1,45,41,24,24,1,48,8,48,57,44,48,49,17,9,25,48,17,16,0,41,40,12,33,20,33,48,0]

theorem envBound59989 : H12AffineFastState.Bounded env59989 := by
  intro p hp
  have h : env59989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59988_59989 : H12AffineEnvironment.transform 5 9 env59988 = env59989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env59988 == env59989) = true)

theorem identity59989 : scanCanonicalize (H12AffineFastState.compose env59989 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59989 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59990 : List Nat := [1,4,8,0,32,9,32,4,1,45,41,8,8,1,32,8,32,41,44,32,33,1,9,9,32,1,0,0,41,40,12,33,4,33,32,0]

theorem envBound59990 : H12AffineFastState.Bounded env59990 := by
  intro p hp
  have h : env59990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59989_59990 : H12AffineEnvironment.transform 3 0 env59989 = env59990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59989 == env59990) = true)

theorem identity59990 : scanCanonicalize (H12AffineFastState.compose env59990 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59990 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59991 : List Nat := [1,4,1,0,32,0,32,4,1,36,32,1,1,1,32,1,32,32,37,32,33,1,0,0,32,1,0,0,32,33,5,33,4,33,32,0]

theorem envBound59991 : H12AffineFastState.Bounded env59991 := by
  intro p hp
  have h : env59991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59990_59991 : H12AffineEnvironment.transform 2 1 env59990 = env59991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59990 == env59991) = true)

def env59992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399767,8397000,8388689,2366324,4177,77954,67411,8463814,8465982,256,65675,78034,8389185]

theorem envBound59992 : H12AffineFastState.Bounded env59992 := by
  intro p hp
  have h : env59992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59899_59992 : H12AffineEnvironment.transform 21 1417 env59899 = env59992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59899 == env59992) = true)

def env59993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3671,1288,9617,2366324,4177,77954,67411,65542,68606,256,65675,78034,10113]

theorem envBound59993 : H12AffineFastState.Bounded env59993 := by
  intro p hp
  have h : env59993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59992_59993 : H12AffineEnvironment.transform 22 9664 env59992 = env59993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59992 == env59993) = true)

def env59994 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1288,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59994 : H12AffineFastState.Bounded env59994 := by
  intro p hp
  have h : env59994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59993_59994 : H12AffineEnvironment.transform 8 0 env59993 = env59994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59993 == env59994) = true)

theorem identity59994 : scanCanonicalize (H12AffineFastState.compose env59994 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 2264) := by decide +kernel

theorem selectedBound59994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59995 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2264,1417,9664,3159,1288,9617,266668,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59995 : H12AffineFastState.Bounded env59995 := by
  intro p hp
  have h : env59995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59994_59995 : H12AffineEnvironment.transform 20 2264 env59994 = env59995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2264 env59994 == env59995) = true)

def env59996 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,2264,1417,64,3159,1288,17,266668,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound59996 : H12AffineFastState.Bounded env59996 := by
  intro p hp
  have h : env59996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59995_59996 : H12AffineEnvironment.transform 12 1408 env59995 = env59996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59995 == env59996) = true)

theorem identity59996 : scanCanonicalize (H12AffineFastState.compose env59996 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59996 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59997 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,293,1408,373,2129,65536,66679,262144,1025,2129,2264,1417,64,3159,1288,17,262281,372,66599,66899,65542,68094,256,65675,66679,1]

theorem envBound59997 : H12AffineFastState.Bounded env59997 := by
  intro p hp
  have h : env59997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59996_59997 : H12AffineEnvironment.transform 11 293 env59996 = env59997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59996 == env59997) = true)

theorem identity59997 : scanCanonicalize (H12AffineFastState.compose env59997 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59997 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59998 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1449,65536,66679,262144,1025,1449,1312,1417,64,431,1288,17,262281,372,66599,66899,65542,66566,256,65675,66679,1]

theorem envBound59998 : H12AffineFastState.Bounded env59998 := by
  intro p hp
  have h : env59998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59997_59998 : H12AffineEnvironment.transform 10 1528 env59997 = env59998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59997 == env59998) = true)

theorem identity59998 : scanCanonicalize (H12AffineFastState.compose env59998 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 67019) := by decide +kernel

theorem selectedBound59998 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59999 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1449,65536,66679,67019,1025,1449,1312,1417,64,431,1288,17,66882,372,66599,66899,65542,66566,256,65675,66679,1]

theorem envBound59999 : H12AffineFastState.Bounded env59999 := by
  intro p hp
  have h : env59999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59998_59999 : H12AffineEnvironment.transform 17 67019 env59998 = env59999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67019 env59998 == env59999) = true)

theorem identity59999 : scanCanonicalize (H12AffineFastState.compose env59999 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59999 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60000 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1449,1062,81,493,1025,1449,1312,1417,64,431,1288,17,356,372,1,373,1056,32,256,1197,81,1]

theorem envBound60000 : H12AffineFastState.Bounded env60000 := by
  intro p hp
  have h : env60000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59999_60000 : H12AffineEnvironment.transform 15 1062 env59999 = env60000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59999 == env60000) = true)

theorem identity60000 : scanCanonicalize (H12AffineFastState.compose env60000 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60000 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60001 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,216,1149,136,1108,1062,81,16,1025,1108,1245,1140,64,82,1269,17,153,137,1,136,1056,32,253,1197,81,1]

theorem envBound60001 : H12AffineFastState.Bounded env60001 := by
  intro p hp
  have h : env60001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60000_60001 : H12AffineEnvironment.transform 7 253 env60000 = env60001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60000 == env60001) = true)

theorem identity60001 : scanCanonicalize (H12AffineFastState.compose env60001 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound60001 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60002 : List Nat := [2,4,8,16,32,64,128,253,0,141,136,216,240,136,217,171,81,16,140,217,80,249,64,82,120,17,153,137,1,136,173,32,253,32,81,1]

theorem envBound60002 : H12AffineFastState.Bounded env60002 := by
  intro p hp
  have h : env60002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60001_60002 : H12AffineEnvironment.transform 9 141 env60001 = env60002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env60001 == env60002) = true)

theorem identity60002 : scanCanonicalize (H12AffineFastState.compose env60002 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60002 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env60003 : List Nat := [2,4,8,16,32,16,128,173,0,141,136,136,160,136,137,171,1,16,140,137,0,169,16,2,40,17,153,137,1,136,173,32,173,32,1,1]

theorem envBound60003 : H12AffineFastState.Bounded env60003 := by
  intro p hp
  have h : env60003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60002_60003 : H12AffineEnvironment.transform 5 16 env60002 = env60003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60002 == env60003) = true)

theorem identity60003 : scanCanonicalize (H12AffineFastState.compose env60003 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60004 : List Nat := [2,4,8,2,32,2,128,173,0,141,136,136,160,136,137,171,1,2,140,137,0,169,2,2,40,3,139,137,1,136,173,32,173,32,1,1]

theorem envBound60004 : H12AffineFastState.Bounded env60004 := by
  intro p hp
  have h : env60004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60003_60004 : H12AffineEnvironment.transform 3 2 env60003 = env60004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60003 == env60004) = true)

theorem identity60004 : scanCanonicalize (H12AffineFastState.compose env60004 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound60004 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60005 : List Nat := [2,4,8,2,32,2,43,6,0,38,35,35,11,35,34,0,1,2,39,34,0,2,2,2,40,3,32,34,1,35,6,32,6,32,1,1]

theorem envBound60005 : H12AffineFastState.Bounded env60005 := by
  intro p hp
  have h : env60005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60004_60005 : H12AffineEnvironment.transform 6 43 env60004 = env60005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env60004 == env60005) = true)

theorem identity60005 : scanCanonicalize (H12AffineFastState.compose env60005 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60005 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60006 : List Nat := [2,4,1,2,32,2,34,6,0,38,35,35,2,35,34,0,1,2,39,34,0,2,2,2,33,3,32,34,1,35,6,32,6,32,1,1]

theorem envBound60006 : H12AffineFastState.Bounded env60006 := by
  intro p hp
  have h : env60006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60005_60006 : H12AffineEnvironment.transform 2 1 env60005 = env60006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60005 == env60006) = true)

theorem identity60006 : scanCanonicalize (H12AffineFastState.compose env60006 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60006 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60007 : List Nat := [2,4,1,2,0,2,2,6,0,6,3,3,2,3,2,0,1,2,7,2,0,2,2,2,1,3,0,2,1,3,6,0,6,0,1,1]

theorem envBound60007 : H12AffineFastState.Bounded env60007 := by
  intro p hp
  have h : env60007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60006_60007 : H12AffineEnvironment.transform 4 0 env60006 = env60007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60006 == env60007) = true)

theorem identity60007 : scanCanonicalize (H12AffineFastState.compose env60007 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60007 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env60008 : List Nat := [0,4,1,0,0,0,0,4,0,4,1,1,0,1,0,0,1,0,5,0,0,0,0,0,1,1,0,0,1,1,4,0,4,0,1,1]

theorem envBound60008 : H12AffineFastState.Bounded env60008 := by
  intro p hp
  have h : env60008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60007_60008 : H12AffineEnvironment.transform 0 0 env60007 = env60008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60007 == env60008) = true)

def env60009 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,2264,1417,65,3159,1288,16,266668,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound60009 : H12AffineFastState.Bounded env60009 := by
  intro p hp
  have h : env60009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59995_60009 : H12AffineEnvironment.transform 12 1409 env59995 = env60009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59995 == env60009) = true)

theorem identity60009 : scanCanonicalize (H12AffineFastState.compose env60009 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound60009 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60010 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4131,1392,262144,1025,2129,2264,1417,65,3159,1288,16,266668,4177,1312,5488,4133,6621,256,4264,1392,0]

theorem envBound60010 : H12AffineFastState.Bounded env60010 := by
  intro p hp
  have h : env60010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60009_60010 : H12AffineEnvironment.transform 15 4131 env60009 = env60010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env60009 == env60010) = true)

theorem identity60010 : scanCanonicalize (H12AffineFastState.compose env60010 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound60010 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60011 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4131,1392,277,1025,2129,2264,1417,65,3159,1288,16,4281,4177,1312,5488,4133,6621,256,4264,1392,0]

theorem envBound60011 : H12AffineFastState.Bounded env60011 := by
  intro p hp
  have h : env60011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60010_60011 : H12AffineEnvironment.transform 17 277 env60010 = env60011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env60010 == env60011) = true)

theorem identity60011 : scanCanonicalize (H12AffineFastState.compose env60011 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound60011 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60012 : List Nat := [2,4,8,16,32,64,128,256,0,237,2048,4096,364,4176,2129,4131,413,277,236,2129,2264,356,65,2234,485,16,4281,4177,461,4509,4133,6621,256,4264,413,0]

theorem envBound60012 : H12AffineFastState.Bounded env60012 := by
  intro p hp
  have h : env60012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60011_60012 : H12AffineEnvironment.transform 9 237 env60011 = env60012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env60011 == env60012) = true)

theorem identity60012 : scanCanonicalize (H12AffineFastState.compose env60012 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2557) := by decide +kernel

theorem selectedBound60012 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60013 : List Nat := [2,4,8,16,32,64,128,256,0,237,2048,2557,364,2477,2129,2526,413,277,236,2129,2264,356,65,2234,485,16,2372,2476,461,2144,2520,32,256,2389,413,0]

theorem envBound60013 : H12AffineFastState.Bounded env60013 := by
  intro p hp
  have h : env60013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60012_60013 : H12AffineEnvironment.transform 11 2557 env60012 = env60013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2557 env60012 == env60013) = true)

theorem identity60013 : scanCanonicalize (H12AffineFastState.compose env60013 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound60013 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60014 : List Nat := [2,4,8,16,32,64,128,256,0,237,48,461,364,413,97,494,413,277,236,97,232,356,65,138,485,16,372,412,461,80,488,32,256,357,413,0]

theorem envBound60014 : H12AffineFastState.Bounded env60014 := by
  intro p hp
  have h : env60014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60013_60014 : H12AffineEnvironment.transform 10 48 env60013 = env60014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env60013 == env60014) = true)

theorem identity60014 : scanCanonicalize (H12AffineFastState.compose env60014 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60014 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60015 : List Nat := [2,4,8,16,32,64,128,182,0,237,48,123,218,43,97,88,43,163,236,97,232,210,65,138,83,16,194,42,123,80,94,32,182,211,43,0]

theorem envBound60015 : H12AffineFastState.Bounded env60015 := by
  intro p hp
  have h : env60015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60014_60015 : H12AffineEnvironment.transform 7 182 env60014 = env60015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60014 == env60015) = true)

theorem identity60015 : scanCanonicalize (H12AffineFastState.compose env60015 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60015 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60016 : List Nat := [2,4,8,16,32,64,114,68,0,31,48,123,40,43,97,88,43,81,30,97,26,32,65,120,83,16,48,42,123,80,94,32,68,33,43,0]

theorem envBound60016 : H12AffineFastState.Bounded env60016 := by
  intro p hp
  have h : env60016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60015_60016 : H12AffineEnvironment.transform 6 114 env60015 = env60016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60015 == env60016) = true)

def env60017 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1288,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60017 : H12AffineFastState.Bounded env60017 := by
  intro p hp
  have h : env60017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59993_60017 : H12AffineEnvironment.transform 8 1 env59993 = env60017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59993 == env60017) = true)

theorem identity60017 : scanCanonicalize (H12AffineFastState.compose env60017 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 11609) := by decide +kernel

theorem selectedBound60017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60018 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,11609,1417,9664,3158,1288,9617,275500,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60018 : H12AffineFastState.Bounded env60018 := by
  intro p hp
  have h : env60018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60017_60018 : H12AffineEnvironment.transform 20 11609 env60017 = env60018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11609 env60017 == env60018) = true)

def env60019 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,2265,1417,64,3158,1288,17,266668,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound60019 : H12AffineFastState.Bounded env60019 := by
  intro p hp
  have h : env60019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60018_60019 : H12AffineEnvironment.transform 12 1408 env60018 = env60019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60018 == env60019) = true)

theorem identity60019 : scanCanonicalize (H12AffineFastState.compose env60019 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound60019 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60020 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,293,1408,373,2128,65536,66679,262144,1025,2128,2265,1417,64,3158,1288,17,262281,372,66599,66898,65542,68095,256,65675,66679,0]

theorem envBound60020 : H12AffineFastState.Bounded env60020 := by
  intro p hp
  have h : env60020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60019_60020 : H12AffineEnvironment.transform 11 293 env60019 = env60020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env60019 == env60020) = true)

theorem identity60020 : scanCanonicalize (H12AffineFastState.compose env60020 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60020 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60021 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1449,65536,66679,262144,1025,1449,1312,1417,64,431,1288,17,262281,372,66599,66898,65542,66566,256,65675,66679,0]

theorem envBound60021 : H12AffineFastState.Bounded env60021 := by
  intro p hp
  have h : env60021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60020_60021 : H12AffineEnvironment.transform 10 1529 env60020 = env60021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60020 == env60021) = true)

theorem identity60021 : scanCanonicalize (H12AffineFastState.compose env60021 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 67019) := by decide +kernel

theorem selectedBound60021 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60022 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1449,65536,66679,67019,1025,1449,1312,1417,64,431,1288,17,66882,372,66599,66898,65542,66566,256,65675,66679,0]

theorem envBound60022 : H12AffineFastState.Bounded env60022 := by
  intro p hp
  have h : env60022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60021_60022 : H12AffineEnvironment.transform 17 67019 env60021 = env60022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67019 env60021 == env60022) = true)

theorem identity60022 : scanCanonicalize (H12AffineFastState.compose env60022 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound60022 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60023 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1449,1062,81,493,1025,1449,1312,1417,64,431,1288,17,356,372,1,372,1056,32,256,1197,81,0]

theorem envBound60023 : H12AffineFastState.Bounded env60023 := by
  intro p hp
  have h : env60023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60022_60023 : H12AffineEnvironment.transform 15 1062 env60022 = env60023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env60022 == env60023) = true)

theorem identity60023 : scanCanonicalize (H12AffineFastState.compose env60023 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60023 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60024 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,217,1148,137,1109,1062,81,17,1025,1109,1244,1141,64,83,1268,17,152,136,1,136,1056,32,252,1197,81,0]

theorem envBound60024 : H12AffineFastState.Bounded env60024 := by
  intro p hp
  have h : env60024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60023_60024 : H12AffineEnvironment.transform 7 252 env60023 = env60024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60023 == env60024) = true)

theorem identity60024 : scanCanonicalize (H12AffineFastState.compose env60024 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60024 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60025 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1029,136,1069,137,1028,1062,0,17,1025,1028,1165,1060,17,2,1189,17,152,136,1,136,1056,32,173,1197,0,0]

theorem envBound60025 : H12AffineFastState.Bounded env60025 := by
  intro p hp
  have h : env60025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60024_60025 : H12AffineEnvironment.transform 5 17 env60024 = env60025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60024 == env60025) = true)

theorem identity60025 : scanCanonicalize (H12AffineFastState.compose env60025 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound60025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60026 : List Nat := [2,4,8,16,32,17,43,6,1,1024,1029,35,1069,34,1028,1062,0,17,1025,1028,1062,1060,17,2,1038,17,51,35,1,35,1056,32,6,1030,0,0]

theorem envBound60026 : H12AffineFastState.Bounded env60026 := by
  intro p hp
  have h : env60026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60025_60026 : H12AffineEnvironment.transform 6 43 env60025 = env60026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env60025 == env60026) = true)

theorem identity60026 : scanCanonicalize (H12AffineFastState.compose env60026 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 38) := by decide +kernel

theorem selectedBound60026 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60027 : List Nat := [2,4,8,16,32,17,43,6,1,38,35,35,11,34,34,0,0,17,39,34,0,2,17,2,40,17,51,35,1,35,6,32,6,32,0,0]

theorem envBound60027 : H12AffineFastState.Bounded env60027 := by
  intro p hp
  have h : env60027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60026_60027 : H12AffineEnvironment.transform 9 38 env60026 = env60027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 38 env60026 == env60027) = true)

theorem identity60027 : scanCanonicalize (H12AffineFastState.compose env60027 (packedSelected [3,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60027 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60028 : List Nat := [0,4,8,16,32,17,41,4,1,36,33,33,9,32,32,0,0,17,37,32,0,0,17,0,40,17,49,33,1,33,4,32,4,32,0,0]

theorem envBound60028 : H12AffineFastState.Bounded env60028 := by
  intro p hp
  have h : env60028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60027_60028 : H12AffineEnvironment.transform 0 0 env60027 = env60028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60027 == env60028) = true)

theorem identity60028 : scanCanonicalize (H12AffineFastState.compose env60028 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60028 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60029 : List Nat := [0,4,8,16,9,17,0,4,1,13,8,8,9,9,9,0,0,17,12,9,0,0,17,0,1,17,24,8,1,8,4,9,4,9,0,0]

theorem envBound60029 : H12AffineFastState.Bounded env60029 := by
  intro p hp
  have h : env60029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60028_60029 : H12AffineEnvironment.transform 4 9 env60028 = env60029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60028 == env60029) = true)

theorem identity60029 : scanCanonicalize (H12AffineFastState.compose env60029 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60029 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60030 : List Nat := [0,4,8,1,9,0,0,4,1,13,8,8,9,9,9,0,0,0,12,9,0,0,0,0,1,0,9,8,1,8,4,9,4,9,0,0]

theorem envBound60030 : H12AffineFastState.Bounded env60030 := by
  intro p hp
  have h : env60030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60029_60030 : H12AffineEnvironment.transform 3 1 env60029 = env60030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60029 == env60030) = true)

theorem identity60030 : scanCanonicalize (H12AffineFastState.compose env60030 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60031 : List Nat := [0,4,1,1,0,0,0,4,1,4,1,1,0,0,0,0,0,0,5,0,0,0,0,0,1,0,0,1,1,1,4,0,4,0,0,0]

theorem envBound60031 : H12AffineFastState.Bounded env60031 := by
  intro p hp
  have h : env60031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60030_60031 : H12AffineEnvironment.transform 2 1 env60030 = env60031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60030 == env60031) = true)

def env60032 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,2264,1417,65,3158,1288,16,266669,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound60032 : H12AffineFastState.Bounded env60032 := by
  intro p hp
  have h : env60032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60018_60032 : H12AffineEnvironment.transform 12 1409 env60018 = env60032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60018 == env60032) = true)

theorem identity60032 : scanCanonicalize (H12AffineFastState.compose env60032 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound60032 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60033 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2264,1417,65,3158,1288,16,266669,4177,1313,5488,4132,6621,256,4265,1393,1]

theorem envBound60033 : H12AffineFastState.Bounded env60033 := by
  intro p hp
  have h : env60033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60032_60033 : H12AffineEnvironment.transform 15 4130 env60032 = env60033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env60032 == env60033) = true)

theorem identity60033 : scanCanonicalize (H12AffineFastState.compose env60033 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound60033 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60034 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,276,1025,2128,2264,1417,65,3158,1288,16,4281,4177,1313,5488,4132,6621,256,4265,1393,1]

theorem envBound60034 : H12AffineFastState.Bounded env60034 := by
  intro p hp
  have h : env60034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60033_60034 : H12AffineEnvironment.transform 17 276 env60033 = env60034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env60033 == env60034) = true)

theorem identity60034 : scanCanonicalize (H12AffineFastState.compose env60034 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound60034 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60035 : List Nat := [2,4,8,16,32,64,128,256,1,237,2048,4096,364,4176,2128,4130,412,276,236,2128,2264,356,65,2235,485,16,4281,4177,460,4509,4132,6621,256,4265,412,1]

theorem envBound60035 : H12AffineFastState.Bounded env60035 := by
  intro p hp
  have h : env60035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60034_60035 : H12AffineEnvironment.transform 9 237 env60034 = env60035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env60034 == env60035) = true)

theorem identity60035 : scanCanonicalize (H12AffineFastState.compose env60035 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound60035 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60036 : List Nat := [2,4,8,16,32,64,128,256,1,237,49,4096,364,4176,97,4130,412,276,236,97,233,356,65,138,485,16,4281,4177,460,4509,4132,4588,256,4265,412,1]

theorem envBound60036 : H12AffineFastState.Bounded env60036 := by
  intro p hp
  have h : env60036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60035_60036 : H12AffineEnvironment.transform 10 49 env60035 = env60036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env60035 == env60036) = true)

theorem identity60036 : scanCanonicalize (H12AffineFastState.compose env60036 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60036 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env60037 : List Nat := [2,4,8,16,32,64,128,256,1,237,49,460,364,412,97,494,412,276,236,97,233,356,65,138,485,16,373,413,460,81,488,32,256,357,412,1]

theorem envBound60037 : H12AffineFastState.Bounded env60037 := by
  intro p hp
  have h : env60037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60036_60037 : H12AffineEnvironment.transform 11 460 env60036 = env60037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60036 == env60037) = true)

theorem identity60037 : scanCanonicalize (H12AffineFastState.compose env60037 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60037 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60038 : List Nat := [2,4,8,16,32,64,128,182,1,237,49,122,218,42,97,88,42,162,236,97,233,210,65,138,83,16,195,43,122,81,94,32,182,211,42,1]

theorem envBound60038 : H12AffineFastState.Bounded env60038 := by
  intro p hp
  have h : env60038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60037_60038 : H12AffineEnvironment.transform 7 182 env60037 = env60038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60037 == env60038) = true)

theorem identity60038 : scanCanonicalize (H12AffineFastState.compose env60038 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60038 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60039 : List Nat := [2,4,8,16,32,64,114,68,1,31,49,122,40,42,97,88,42,80,30,97,27,32,65,120,83,16,49,43,122,81,94,32,68,33,42,1]

theorem envBound60039 : H12AffineFastState.Bounded env60039 := by
  intro p hp
  have h : env60039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60038_60039 : H12AffineEnvironment.transform 6 114 env60038 = env60039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60038 == env60039) = true)

def env60040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3670,1289,9616,2366324,4177,77954,67411,65543,68607,256,65675,78034,10112]

theorem envBound60040 : H12AffineFastState.Bounded env60040 := by
  intro p hp
  have h : env60040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59992_60040 : H12AffineEnvironment.transform 22 9665 env59992 = env60040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59992 == env60040) = true)

def env60041 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound60041 : H12AffineFastState.Bounded env60041 := by
  intro p hp
  have h : env60041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60040_60041 : H12AffineEnvironment.transform 8 0 env60040 = env60041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60040 == env60041) = true)

theorem identity60041 : scanCanonicalize (H12AffineFastState.compose env60041 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound60041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60042 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,5385,4176,2129,65536,67035,262144,1025,2129,2097152,1417,4296,3158,1289,4249,2365812,4177,66955,66899,65543,68095,256,65675,67035,4233]

theorem envBound60042 : H12AffineFastState.Bounded env60042 := by
  intro p hp
  have h : env60042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60041_60042 : H12AffineEnvironment.transform 12 5385 env60041 = env60042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env60041 == env60042) = true)

def env60043 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2097152,1417,64,3158,1289,17,2361852,217,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound60043 : H12AffineFastState.Bounded env60043 := by
  intro p hp
  have h : env60043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60042_60043 : H12AffineEnvironment.transform 11 136 env60042 = env60043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env60042 == env60043) = true)

theorem identity60043 : scanCanonicalize (H12AffineFastState.compose env60043 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2421) := by decide +kernel

theorem selectedBound60043 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60044 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2421,1417,64,3158,1289,17,262281,217,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound60044 : H12AffineFastState.Bounded env60044 := by
  intro p hp
  have h : env60044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60043_60044 : H12AffineEnvironment.transform 20 2421 env60043 = env60044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2421 env60043 == env60044) = true)

theorem identity60044 : scanCanonicalize (H12AffineFastState.compose env60044 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60044 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60045 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1449,65536,67035,262144,1025,1449,1165,1417,64,430,1289,17,262281,217,66955,66899,65543,66567,256,65675,67035,1]

theorem envBound60045 : H12AffineFastState.Bounded env60045 := by
  intro p hp
  have h : env60045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60044_60045 : H12AffineEnvironment.transform 10 1528 env60044 = env60045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60044 == env60045) = true)

theorem identity60045 : scanCanonicalize (H12AffineFastState.compose env60045 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66663) := by decide +kernel

theorem selectedBound60045 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60046 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1449,65536,67035,66663,1025,1449,1165,1417,64,430,1289,17,66798,217,66955,66899,65543,66567,256,65675,67035,1]

theorem envBound60046 : H12AffineFastState.Bounded env60046 := by
  intro p hp
  have h : env60046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60045_60046 : H12AffineEnvironment.transform 17 66663 env60045 = env60046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66663 env60045 == env60046) = true)

theorem identity60046 : scanCanonicalize (H12AffineFastState.compose env60046 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound60046 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60047 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1449,1062,509,65,1025,1449,1165,1417,64,430,1289,17,200,217,429,373,1057,33,256,1197,509,1]

theorem envBound60047 : H12AffineFastState.Bounded env60047 := by
  intro p hp
  have h : env60047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60046_60047 : H12AffineEnvironment.transform 15 1062 env60046 = env60047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env60046 == env60047) = true)

theorem identity60047 : scanCanonicalize (H12AffineFastState.compose env60047 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60047 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60048 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,136,1149,216,1109,1062,1,65,1025,1109,1165,1141,64,82,1269,17,200,217,81,137,1057,33,252,1197,1,1]

theorem envBound60048 : H12AffineFastState.Bounded env60048 := by
  intro p hp
  have h : env60048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60047_60048 : H12AffineEnvironment.transform 7 252 env60047 = env60048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60047 == env60048) = true)

theorem identity60048 : scanCanonicalize (H12AffineFastState.compose env60048 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60048 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60049 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1028,136,1068,137,1028,1062,1,16,1025,1028,1165,1060,17,3,1188,17,153,136,0,137,1057,33,173,1197,1,1]

theorem envBound60049 : H12AffineFastState.Bounded env60049 := by
  intro p hp
  have h : env60049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60048_60049 : H12AffineEnvironment.transform 5 17 env60048 = env60049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60048 == env60049) = true)

theorem identity60049 : scanCanonicalize (H12AffineFastState.compose env60049 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60050 : List Nat := [2,4,8,16,2,17,128,143,0,1024,1028,136,1038,137,1028,1028,1,16,1025,1028,1165,1030,17,3,1158,17,153,136,0,137,1027,3,143,1167,1,1]

theorem envBound60050 : H12AffineFastState.Bounded env60050 := by
  intro p hp
  have h : env60050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60049_60050 : H12AffineEnvironment.transform 4 2 env60049 = env60050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60049 == env60050) = true)

theorem identity60050 : scanCanonicalize (H12AffineFastState.compose env60050 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound60050 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60051 : List Nat := [2,4,8,16,2,17,128,143,0,140,136,136,130,137,136,136,1,16,141,136,1,138,17,3,10,17,153,136,0,137,143,3,143,3,1,1]

theorem envBound60051 : H12AffineFastState.Bounded env60051 := by
  intro p hp
  have h : env60051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60050_60051 : H12AffineEnvironment.transform 9 140 env60050 = env60051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env60050 == env60051) = true)

theorem identity60051 : scanCanonicalize (H12AffineFastState.compose env60051 (packedSelected [3,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60051 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60052 : List Nat := [0,4,8,16,0,17,128,141,0,140,136,136,128,137,136,136,1,16,141,136,1,136,17,1,8,17,153,136,0,137,141,1,141,1,1,1]

theorem envBound60052 : H12AffineFastState.Bounded env60052 := by
  intro p hp
  have h : env60052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60051_60052 : H12AffineEnvironment.transform 0 0 env60051 = env60052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60051 == env60052) = true)

theorem identity60052 : scanCanonicalize (H12AffineFastState.compose env60052 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound60052 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60053 : List Nat := [0,4,8,16,0,17,17,28,0,29,25,25,17,24,25,25,1,16,28,25,1,25,17,1,8,17,8,25,0,24,28,1,28,1,1,1]

theorem envBound60053 : H12AffineFastState.Bounded env60053 := by
  intro p hp
  have h : env60053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60052_60053 : H12AffineEnvironment.transform 6 17 env60052 = env60053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env60052 == env60053) = true)

theorem identity60053 : scanCanonicalize (H12AffineFastState.compose env60053 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60054 : List Nat := [0,4,8,0,0,1,1,12,0,13,9,9,1,8,9,9,1,0,12,9,1,9,1,1,8,1,8,9,0,8,12,1,12,1,1,1]

theorem envBound60054 : H12AffineFastState.Bounded env60054 := by
  intro p hp
  have h : env60054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60053_60054 : H12AffineEnvironment.transform 3 0 env60053 = env60054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60053 == env60054) = true)

theorem identity60054 : scanCanonicalize (H12AffineFastState.compose env60054 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60054 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60055 : List Nat := [0,4,1,0,0,1,1,5,0,4,0,0,1,1,0,0,1,0,5,0,1,0,1,1,1,1,1,0,0,1,5,1,5,1,1,1]

theorem envBound60055 : H12AffineFastState.Bounded env60055 := by
  intro p hp
  have h : env60055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60054_60055 : H12AffineEnvironment.transform 2 1 env60054 = env60055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60054 == env60055) = true)

def env60056 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2129,65536,67035,262144,1025,2129,2097152,1417,65,3158,1289,16,2361853,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound60056 : H12AffineFastState.Bounded env60056 := by
  intro p hp
  have h : env60056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60042_60056 : H12AffineEnvironment.transform 11 137 env60042 = env60056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env60042 == env60056) = true)

theorem identity60056 : scanCanonicalize (H12AffineFastState.compose env60056 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound60056 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60057 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2129,65536,67035,262144,1025,2129,67699,1417,65,3158,1289,16,328078,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound60057 : H12AffineFastState.Bounded env60057 := by
  intro p hp
  have h : env60057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60056_60057 : H12AffineEnvironment.transform 20 67699 env60056 = env60057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env60056 == env60057) = true)

theorem identity60057 : scanCanonicalize (H12AffineFastState.compose env60057 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound60057 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60058 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2129,65536,67035,65983,1025,2129,67699,1417,65,3158,1289,16,49,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound60058 : H12AffineFastState.Bounded env60058 := by
  intro p hp
  have h : env60058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60057_60058 : H12AffineEnvironment.transform 17 65983 env60057 = env60058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env60057 == env60058) = true)

theorem identity60058 : scanCanonicalize (H12AffineFastState.compose env60058 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound60058 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60059 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2129,1094,413,1529,1025,2129,3125,1417,65,3158,1289,16,49,216,461,277,1089,3513,256,1229,413,0]

theorem envBound60059 : H12AffineFastState.Bounded env60059 := by
  intro p hp
  have h : env60059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60058_60059 : H12AffineEnvironment.transform 15 1094 env60058 = env60059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env60058 == env60059) = true)

theorem identity60059 : scanCanonicalize (H12AffineFastState.compose env60059 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound60059 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60060 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,137,1408,217,1165,1094,413,1529,1025,1165,233,1417,65,138,1289,16,49,216,461,277,1089,357,256,1229,413,0]

theorem envBound60060 : H12AffineFastState.Bounded env60060 := by
  intro p hp
  have h : env60060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60059_60060 : H12AffineEnvironment.transform 10 1244 env60059 = env60060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env60059 == env60060) = true)

theorem identity60060 : scanCanonicalize (H12AffineFastState.compose env60060 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound60060 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env60061 : List Nat := [2,4,8,16,32,64,128,256,0,425,373,137,41,217,292,495,413,80,424,292,233,32,65,138,160,16,49,216,461,277,488,357,256,356,413,0]

theorem envBound60061 : H12AffineFastState.Bounded env60061 := by
  intro p hp
  have h : env60061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60060_60061 : H12AffineEnvironment.transform 9 425 env60060 = env60061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env60060 == env60061) = true)

theorem identity60061 : scanCanonicalize (H12AffineFastState.compose env60061 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60061 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60062 : List Nat := [2,4,8,16,32,64,128,69,0,236,48,137,41,217,97,170,216,80,237,97,233,32,65,138,160,16,49,216,136,80,173,32,69,33,216,0]

theorem envBound60062 : H12AffineFastState.Bounded env60062 := by
  intro p hp
  have h : env60062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60061_60062 : H12AffineEnvironment.transform 7 69 env60061 = env60062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60061 == env60062) = true)

theorem identity60062 : scanCanonicalize (H12AffineFastState.compose env60062 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60062 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60063 : List Nat := [2,4,8,16,32,58,128,63,0,150,48,137,41,163,27,170,162,42,151,27,147,32,59,138,160,16,49,162,136,42,173,32,63,33,162,0]

theorem envBound60063 : H12AffineFastState.Bounded env60063 := by
  intro p hp
  have h : env60063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60062_60063 : H12AffineEnvironment.transform 5 58 env60062 = env60063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60062 == env60063) = true)

def env60064 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound60064 : H12AffineFastState.Bounded env60064 := by
  intro p hp
  have h : env60064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60040_60064 : H12AffineEnvironment.transform 8 1 env60040 = env60064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60040 == env60064) = true)

theorem identity60064 : scanCanonicalize (H12AffineFastState.compose env60064 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound60064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60065 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,8192,216,2128,65536,73818,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2361853,217,73738,66898,65543,68094,256,65675,73818,9601]

theorem envBound60065 : H12AffineFastState.Bounded env60065 := by
  intro p hp
  have h : env60065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60064_60065 : H12AffineEnvironment.transform 11 136 env60064 = env60065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env60064 == env60065) = true)

def env60066 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2128,65536,67034,262144,1025,2128,2097152,1417,65,3159,1289,16,2361853,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound60066 : H12AffineFastState.Bounded env60066 := by
  intro p hp
  have h : env60066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60065_60066 : H12AffineEnvironment.transform 12 1408 env60065 = env60066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60065 == env60066) = true)

theorem identity60066 : scanCanonicalize (H12AffineFastState.compose env60066 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound60066 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60067 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2128,65536,67034,262144,1025,2128,67699,1417,65,3159,1289,16,328078,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound60067 : H12AffineFastState.Bounded env60067 := by
  intro p hp
  have h : env60067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60066_60067 : H12AffineEnvironment.transform 20 67699 env60066 = env60067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env60066 == env60067) = true)

theorem identity60067 : scanCanonicalize (H12AffineFastState.compose env60067 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound60067 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60068 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2128,65536,67034,65982,1025,2128,67699,1417,65,3159,1289,16,48,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound60068 : H12AffineFastState.Bounded env60068 := by
  intro p hp
  have h : env60068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60067_60068 : H12AffineEnvironment.transform 17 65982 env60067 = env60068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env60067 == env60068) = true)

theorem identity60068 : scanCanonicalize (H12AffineFastState.compose env60068 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound60068 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60069 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2128,1094,412,1528,1025,2128,3125,1417,65,3159,1289,16,48,217,460,276,1089,3512,256,1229,412,1]

theorem envBound60069 : H12AffineFastState.Bounded env60069 := by
  intro p hp
  have h : env60069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60068_60069 : H12AffineEnvironment.transform 15 1094 env60068 = env60069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env60068 == env60069) = true)

theorem identity60069 : scanCanonicalize (H12AffineFastState.compose env60069 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound60069 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60070 : List Nat := [2,4,8,16,32,64,128,68,1,1024,2048,136,1220,216,2128,1094,216,1212,1025,2128,3125,1229,65,3159,1101,16,48,217,136,80,1089,3324,68,1229,216,1]

theorem envBound60070 : H12AffineFastState.Bounded env60070 := by
  intro p hp
  have h : env60070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60069_60070 : H12AffineEnvironment.transform 7 68 env60069 = env60070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env60069 == env60070) = true)

theorem identity60070 : scanCanonicalize (H12AffineFastState.compose env60070 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60070 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60071 : List Nat := [2,4,8,16,32,64,114,68,1,1024,2048,122,1078,42,2128,1094,42,1102,1025,2128,3125,1087,65,3159,1101,16,48,43,122,80,1089,3086,68,1087,42,1]

theorem envBound60071 : H12AffineFastState.Bounded env60071 := by
  intro p hp
  have h : env60071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60070_60071 : H12AffineEnvironment.transform 6 114 env60070 = env60071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60070 == env60071) = true)

theorem identity60071 : scanCanonicalize (H12AffineFastState.compose env60071 (packedSelected [0,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound60071 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env60072 : List Nat := [2,4,8,16,32,64,114,68,1,1024,1071,122,1078,42,1151,1094,42,1102,1025,1151,26,1087,65,120,1101,16,48,43,122,80,1089,33,68,1087,42,1]

theorem envBound60072 : H12AffineFastState.Bounded env60072 := by
  intro p hp
  have h : env60072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60071_60072 : H12AffineEnvironment.transform 10 1071 env60071 = env60072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env60071 == env60072) = true)

theorem identity60072 : scanCanonicalize (H12AffineFastState.compose env60072 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound60072 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60073 : List Nat := [2,4,8,16,32,64,114,68,1,31,48,122,41,42,96,89,42,81,30,96,26,32,65,120,82,16,48,43,122,80,94,33,68,32,42,1]

theorem envBound60073 : H12AffineFastState.Bounded env60073 := by
  intro p hp
  have h : env60073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60072_60073 : H12AffineEnvironment.transform 9 31 env60072 = env60073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env60072 == env60073) = true)

def env60074 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2097152,1417,64,3159,1289,17,2361853,217,66955,66898,65543,68094,256,65675,67035,0]

theorem envBound60074 : H12AffineFastState.Bounded env60074 := by
  intro p hp
  have h : env60074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60065_60074 : H12AffineEnvironment.transform 12 1409 env60065 = env60074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60065 == env60074) = true)

theorem identity60074 : scanCanonicalize (H12AffineFastState.compose env60074 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2420) := by decide +kernel

theorem selectedBound60074 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60075 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2420,1417,64,3159,1289,17,262281,217,66955,66898,65543,68094,256,65675,67035,0]

theorem envBound60075 : H12AffineFastState.Bounded env60075 := by
  intro p hp
  have h : env60075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60074_60075 : H12AffineEnvironment.transform 20 2420 env60074 = env60075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2420 env60074 == env60075) = true)

theorem identity60075 : scanCanonicalize (H12AffineFastState.compose env60075 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60075 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60076 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1449,65536,67035,262144,1025,1449,1165,1417,64,430,1289,17,262281,217,66955,66898,65543,66567,256,65675,67035,0]

theorem envBound60076 : H12AffineFastState.Bounded env60076 := by
  intro p hp
  have h : env60076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60075_60076 : H12AffineEnvironment.transform 10 1529 env60075 = env60076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60075 == env60076) = true)

theorem identity60076 : scanCanonicalize (H12AffineFastState.compose env60076 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66663) := by decide +kernel

theorem selectedBound60076 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60077 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1449,65536,67035,66663,1025,1449,1165,1417,64,430,1289,17,66798,217,66955,66898,65543,66567,256,65675,67035,0]

theorem envBound60077 : H12AffineFastState.Bounded env60077 := by
  intro p hp
  have h : env60077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60076_60077 : H12AffineEnvironment.transform 17 66663 env60076 = env60077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66663 env60076 == env60077) = true)

theorem identity60077 : scanCanonicalize (H12AffineFastState.compose env60077 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound60077 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60078 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1449,1062,509,65,1025,1449,1165,1417,64,430,1289,17,200,217,429,372,1057,33,256,1197,509,0]

theorem envBound60078 : H12AffineFastState.Bounded env60078 := by
  intro p hp
  have h : env60078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60077_60078 : H12AffineEnvironment.transform 15 1062 env60077 = env60078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env60077 == env60078) = true)

theorem identity60078 : scanCanonicalize (H12AffineFastState.compose env60078 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60078 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60079 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,136,1148,216,1108,1062,0,65,1025,1108,1165,1140,64,83,1268,17,200,217,80,137,1057,33,253,1197,0,0]

theorem envBound60079 : H12AffineFastState.Bounded env60079 := by
  intro p hp
  have h : env60079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60078_60079 : H12AffineEnvironment.transform 7 253 env60078 = env60079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60078 == env60079) = true)

theorem identity60079 : scanCanonicalize (H12AffineFastState.compose env60079 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound60079 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60080 : List Nat := [2,4,8,16,32,64,128,253,1,140,136,136,240,216,216,170,0,65,141,216,1,248,64,83,120,17,200,217,80,137,173,33,253,33,0,0]

theorem envBound60080 : H12AffineFastState.Bounded env60080 := by
  intro p hp
  have h : env60080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60079_60080 : H12AffineEnvironment.transform 9 140 env60079 = env60080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env60079 == env60080) = true)

theorem identity60080 : scanCanonicalize (H12AffineFastState.compose env60080 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60080 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60081 : List Nat := [2,4,8,16,32,64,40,85,1,36,32,32,88,112,112,2,0,65,37,112,1,80,64,83,120,17,96,113,80,33,5,33,85,33,0,0]

theorem envBound60081 : H12AffineFastState.Bounded env60081 := by
  intro p hp
  have h : env60081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60080_60081 : H12AffineEnvironment.transform 6 40 env60080 = env60081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60080 == env60081) = true)

theorem identity60081 : scanCanonicalize (H12AffineFastState.compose env60081 (packedSelected [0,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 41) := by decide +kernel

theorem selectedBound60081 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env60082 : List Nat := [2,4,8,16,32,41,40,60,1,36,32,32,49,25,25,2,0,40,37,25,1,57,41,58,17,17,9,24,57,33,5,33,60,33,0,0]

theorem envBound60082 : H12AffineFastState.Bounded env60082 := by
  intro p hp
  have h : env60082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60081_60082 : H12AffineEnvironment.transform 5 41 env60081 = env60082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 41 env60081 == env60082) = true)

theorem identity60082 : scanCanonicalize (H12AffineFastState.compose env60082 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60082 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60083 : List Nat := [2,4,8,16,3,10,11,31,1,7,3,3,18,25,25,2,0,11,6,25,1,26,10,25,17,17,9,24,26,2,5,2,31,2,0,0]

theorem envBound60083 : H12AffineFastState.Bounded env60083 := by
  intro p hp
  have h : env60083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60082_60083 : H12AffineEnvironment.transform 4 3 env60082 = env60083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60082 == env60083) = true)

theorem identity60083 : scanCanonicalize (H12AffineFastState.compose env60083 (packedSelected [0,1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60083 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60084 : List Nat := [0,4,8,16,1,8,9,29,1,5,1,1,16,25,25,0,0,9,4,25,1,24,8,25,17,17,9,24,24,0,5,0,29,0,0,0]

theorem envBound60084 : H12AffineFastState.Bounded env60084 := by
  intro p hp
  have h : env60084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60083_60084 : H12AffineEnvironment.transform 0 0 env60083 = env60084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60083 == env60084) = true)

theorem identity60084 : scanCanonicalize (H12AffineFastState.compose env60084 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60084 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60085 : List Nat := [0,4,8,0,1,8,9,13,1,5,1,1,0,9,9,0,0,9,4,9,1,8,8,9,1,1,9,8,8,0,5,0,13,0,0,0]

theorem envBound60085 : H12AffineFastState.Bounded env60085 := by
  intro p hp
  have h : env60085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60084_60085 : H12AffineEnvironment.transform 3 0 env60084 = env60085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60084 == env60085) = true)

def env60086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397001,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,8389184]

theorem envBound60086 : H12AffineFastState.Bounded env60086 := by
  intro p hp
  have h : env60086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59712_60086 : H12AffineEnvironment.transform 24 8397001 env59712 = env60086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397001 env59712 == env60086) = true)

def env60087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397001,8388689,6561532,4177,77954,4260570,8463814,8465983,256,4261123,78034,8389184]

theorem envBound60087 : H12AffineFastState.Bounded env60087 := by
  intro p hp
  have h : env60087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60086_60087 : H12AffineEnvironment.transform 26 6561532 env60086 = env60087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env60086 == env60087) = true)

def env60088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399767,8397001,8388689,2366324,4177,77954,67410,8463814,8465983,256,65675,78034,8389184]

theorem envBound60088 : H12AffineFastState.Bounded env60088 := by
  intro p hp
  have h : env60088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60087_60088 : H12AffineEnvironment.transform 21 1416 env60087 = env60088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env60087 == env60088) = true)

def env60089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3671,1289,9617,2366324,4177,77954,67410,65542,68607,256,65675,78034,10112]

theorem envBound60089 : H12AffineFastState.Bounded env60089 := by
  intro p hp
  have h : env60089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60088_60089 : H12AffineEnvironment.transform 22 9664 env60088 = env60089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60088 == env60089) = true)

def env60090 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1289,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60090 : H12AffineFastState.Bounded env60090 := by
  intro p hp
  have h : env60090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60089_60090 : H12AffineEnvironment.transform 8 0 env60089 = env60090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60089 == env60090) = true)

theorem identity60090 : scanCanonicalize (H12AffineFastState.compose env60090 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 75251) := by decide +kernel

theorem selectedBound60090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60091 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,75251,1416,9664,3159,1289,9617,343175,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60091 : H12AffineFastState.Bounded env60091 := by
  intro p hp
  have h : env60091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60090_60091 : H12AffineEnvironment.transform 20 75251 env60090 = env60091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75251 env60090 == env60091) = true)

def env60092 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,65651,1416,64,3159,1289,17,334087,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound60092 : H12AffineFastState.Bounded env60092 := by
  intro p hp
  have h : env60092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60091_60092 : H12AffineEnvironment.transform 12 1408 env60091 = env60092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60091 == env60092) = true)

theorem identity60092 : scanCanonicalize (H12AffineFastState.compose env60092 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60092 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60093 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,65651,1416,64,3159,1289,17,328078,2264,69003,66898,65542,68095,256,65675,69083,0]

theorem envBound60093 : H12AffineFastState.Bounded env60093 := by
  intro p hp
  have h : env60093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60092_60093 : H12AffineEnvironment.transform 11 2185 env60092 = env60093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60092 == env60093) = true)

theorem identity60093 : scanCanonicalize (H12AffineFastState.compose env60093 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound60093 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60094 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,97,1025,2129,65651,1416,64,3159,1289,17,66031,2264,69003,66898,65542,68095,256,65675,69083,0]

theorem envBound60094 : H12AffineFastState.Bounded env60094 := by
  intro p hp
  have h : env60094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60093_60094 : H12AffineEnvironment.transform 17 97 env60093 = env60094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env60093 == env60094) = true)

theorem identity60094 : scanCanonicalize (H12AffineFastState.compose env60094 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60094 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60095 : List Nat := [2,4,8,16,32,64,128,256,0,408,2048,2185,24,2265,2129,65536,67651,97,409,2129,65651,16,64,2511,145,17,66031,2264,67603,65738,65542,68095,256,65675,67651,0]

theorem envBound60095 : H12AffineFastState.Bounded env60095 := by
  intro p hp
  have h : env60095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60094_60095 : H12AffineEnvironment.transform 9 408 env60094 = env60095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60094 == env60095) = true)

theorem identity60095 : scanCanonicalize (H12AffineFastState.compose env60095 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60095 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60096 : List Nat := [2,4,8,16,16,64,128,256,0,408,2048,2185,24,2265,2129,65536,67651,81,409,2129,65603,16,64,2511,145,17,66015,2264,67603,65738,65542,68047,256,65675,67651,0]

theorem envBound60096 : H12AffineFastState.Bounded env60096 := by
  intro p hp
  have h : env60096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60095_60096 : H12AffineEnvironment.transform 4 16 env60095 = env60096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60095 == env60096) = true)

theorem identity60096 : scanCanonicalize (H12AffineFastState.compose env60096 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound60096 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60097 : List Nat := [2,4,8,16,16,64,128,256,0,408,2048,2185,24,2265,2129,155,2264,81,409,2129,216,16,64,2511,145,17,324,2264,2184,81,157,2388,256,16,2264,0]

theorem envBound60097 : H12AffineFastState.Bounded env60097 := by
  intro p hp
  have h : env60097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60096_60097 : H12AffineEnvironment.transform 15 155 env60096 = env60097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env60096 == env60097) = true)

theorem identity60097 : scanCanonicalize (H12AffineFastState.compose env60097 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60097 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60098 : List Nat := [2,4,8,16,16,64,128,256,0,408,325,460,24,412,276,155,413,81,409,276,216,16,64,138,145,17,324,413,461,81,157,17,256,16,413,0]

theorem envBound60098 : H12AffineFastState.Bounded env60098 := by
  intro p hp
  have h : env60098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60097_60098 : H12AffineEnvironment.transform 10 325 env60097 = env60098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60097 == env60098) = true)

def env60099 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,65650,1416,65,3159,1289,16,334086,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound60099 : H12AffineFastState.Bounded env60099 := by
  intro p hp
  have h : env60099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60091_60099 : H12AffineEnvironment.transform 12 1409 env60091 = env60099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60091 == env60099) = true)

theorem identity60099 : scanCanonicalize (H12AffineFastState.compose env60099 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6543) := by decide +kernel

theorem selectedBound60099 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60100 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6543,3292,262144,1025,2129,6653,1416,65,3159,1289,16,262281,4177,3212,7389,6537,4208,256,6404,3292,1]

theorem envBound60100 : H12AffineFastState.Bounded env60100 := by
  intro p hp
  have h : env60100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60099_60100 : H12AffineEnvironment.transform 15 6543 env60099 = env60100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6543 env60099 == env60100) = true)

theorem identity60100 : scanCanonicalize (H12AffineFastState.compose env60100 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60100 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60101 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,5238,293,262144,1025,1448,5124,1416,65,430,1289,16,262281,4177,373,4388,5232,4208,256,5373,293,1]

theorem envBound60101 : H12AffineFastState.Bounded env60101 := by
  intro p hp
  have h : env60101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60100_60101 : H12AffineEnvironment.transform 10 1529 env60100 = env60101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60100 == env60101) = true)

theorem identity60101 : scanCanonicalize (H12AffineFastState.compose env60101 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 444) := by decide +kernel

theorem selectedBound60101 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60102 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,5238,293,444,1025,1448,5124,1416,65,430,1289,16,309,4177,373,4388,5232,4208,256,5373,293,1]

theorem envBound60102 : H12AffineFastState.Bounded env60102 := by
  intro p hp
  have h : env60102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60101_60102 : H12AffineEnvironment.transform 17 444 env60101 = env60102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 444 env60101 == env60102) = true)

theorem identity60102 : scanCanonicalize (H12AffineFastState.compose env60102 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound60102 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60103 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,80,1409,0,1448,1062,293,444,1025,1448,1108,1416,65,430,1289,16,309,1,373,372,1056,32,256,1197,293,1]

theorem envBound60103 : H12AffineFastState.Bounded env60103 := by
  intro p hp
  have h : env60103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60102_60103 : H12AffineEnvironment.transform 11 80 env60102 = env60103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env60102 == env60103) = true)

theorem identity60103 : scanCanonicalize (H12AffineFastState.compose env60103 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60103 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60104 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,80,349,0,372,250,293,444,221,372,136,340,65,430,469,16,309,1,373,372,252,32,256,113,293,1]

theorem envBound60104 : H12AffineFastState.Bounded env60104 := by
  intro p hp
  have h : env60104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60103_60104 : H12AffineEnvironment.transform 9 220 env60103 = env60104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60103 == env60104) = true)

theorem identity60104 : scanCanonicalize (H12AffineFastState.compose env60104 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60104 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60105 : List Nat := [2,4,8,16,32,64,128,172,0,220,137,80,241,0,216,250,137,16,221,216,136,248,65,2,121,16,153,1,217,216,252,32,172,113,137,1]

theorem envBound60105 : H12AffineFastState.Bounded env60105 := by
  intro p hp
  have h : env60105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60104_60105 : H12AffineEnvironment.transform 7 172 env60104 = env60105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60104 == env60105) = true)

theorem identity60105 : scanCanonicalize (H12AffineFastState.compose env60105 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60105 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60106 : List Nat := [2,4,8,16,32,33,128,172,0,189,137,49,144,0,185,155,137,16,188,185,136,153,32,2,24,16,153,1,184,185,157,32,172,16,137,1]

theorem envBound60106 : H12AffineFastState.Bounded env60106 := by
  intro p hp
  have h : env60106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60105_60106 : H12AffineEnvironment.transform 5 33 env60105 = env60106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60105 == env60106) = true)

theorem identity60106 : scanCanonicalize (H12AffineFastState.compose env60106 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound60106 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60107 : List Nat := [2,4,8,16,32,33,17,61,0,44,24,49,1,0,40,10,24,16,45,40,25,8,32,2,24,16,8,1,41,40,12,32,61,16,24,1]

theorem envBound60107 : H12AffineFastState.Bounded env60107 := by
  intro p hp
  have h : env60107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60106_60107 : H12AffineEnvironment.transform 6 17 env60106 = env60107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env60106 == env60107) = true)

theorem identity60107 : scanCanonicalize (H12AffineFastState.compose env60107 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60107 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60108 : List Nat := [0,4,8,16,32,33,17,61,0,44,24,49,1,0,40,8,24,16,45,40,25,8,32,0,24,16,8,1,41,40,12,32,61,16,24,1]

theorem envBound60108 : H12AffineFastState.Bounded env60108 := by
  intro p hp
  have h : env60108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60107_60108 : H12AffineEnvironment.transform 0 0 env60107 = env60108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60107 == env60108) = true)

theorem identity60108 : scanCanonicalize (H12AffineFastState.compose env60108 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60109 : List Nat := [0,4,8,16,0,1,17,29,0,12,24,17,1,0,8,8,24,16,13,8,25,8,0,0,24,16,8,1,9,8,12,0,29,16,24,1]

theorem envBound60109 : H12AffineFastState.Bounded env60109 := by
  intro p hp
  have h : env60109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60108_60109 : H12AffineEnvironment.transform 4 0 env60108 = env60109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60108 == env60109) = true)

theorem identity60109 : scanCanonicalize (H12AffineFastState.compose env60109 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60109 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60110 : List Nat := [0,4,8,9,0,1,8,4,0,12,1,8,1,0,8,8,1,9,13,8,0,8,0,0,1,9,8,1,9,8,12,0,4,9,1,1]

theorem envBound60110 : H12AffineFastState.Bounded env60110 := by
  intro p hp
  have h : env60110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60109_60110 : H12AffineEnvironment.transform 3 9 env60109 = env60110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60109 == env60110) = true)

theorem identity60110 : scanCanonicalize (H12AffineFastState.compose env60110 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60110 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60111 : List Nat := [0,4,1,0,0,1,1,4,0,5,1,1,1,0,1,1,1,0,4,1,0,1,0,0,1,0,1,1,0,1,5,0,4,0,1,1]

theorem envBound60111 : H12AffineFastState.Bounded env60111 := by
  intro p hp
  have h : env60111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60110_60111 : H12AffineEnvironment.transform 2 1 env60110 = env60111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60110 == env60111) = true)

def env60112 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1289,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60112 : H12AffineFastState.Bounded env60112 := by
  intro p hp
  have h : env60112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60089_60112 : H12AffineEnvironment.transform 8 1 env60089 = env60112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60089 == env60112) = true)

theorem identity60112 : scanCanonicalize (H12AffineFastState.compose env60112 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound60112 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60113 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,65650,1416,9664,3158,1289,9617,334087,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60113 : H12AffineFastState.Bounded env60113 := by
  intro p hp
  have h : env60113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60112_60113 : H12AffineEnvironment.transform 20 65650 env60112 = env60113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env60112 == env60113) = true)

def env60114 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,65650,1416,64,3158,1289,17,334087,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound60114 : H12AffineFastState.Bounded env60114 := by
  intro p hp
  have h : env60114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60113_60114 : H12AffineEnvironment.transform 12 1408 env60113 = env60114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60113 == env60114) = true)

theorem identity60114 : scanCanonicalize (H12AffineFastState.compose env60114 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60114 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60115 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,65650,1416,64,3158,1289,17,328078,2264,69003,66899,65542,68094,256,65675,69083,1]

theorem envBound60115 : H12AffineFastState.Bounded env60115 := by
  intro p hp
  have h : env60115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60114_60115 : H12AffineEnvironment.transform 11 2185 env60114 = env60115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60114 == env60115) = true)

theorem identity60115 : scanCanonicalize (H12AffineFastState.compose env60115 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound60115 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60116 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,96,1025,2128,65650,1416,64,3158,1289,17,66030,2264,69003,66899,65542,68094,256,65675,69083,1]

theorem envBound60116 : H12AffineFastState.Bounded env60116 := by
  intro p hp
  have h : env60116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60115_60116 : H12AffineEnvironment.transform 17 96 env60115 = env60116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env60115 == env60116) = true)

theorem identity60116 : scanCanonicalize (H12AffineFastState.compose env60116 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60116 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60117 : List Nat := [2,4,8,16,32,64,128,256,1,408,2048,2185,24,2265,2128,65536,67651,96,409,2128,65650,16,64,2510,145,17,66030,2264,67603,65739,65542,68094,256,65675,67651,1]

theorem envBound60117 : H12AffineFastState.Bounded env60117 := by
  intro p hp
  have h : env60117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60116_60117 : H12AffineEnvironment.transform 9 408 env60116 = env60117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60116 == env60117) = true)

theorem identity60117 : scanCanonicalize (H12AffineFastState.compose env60117 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound60117 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60118 : List Nat := [2,4,8,16,32,64,128,256,1,408,372,509,24,429,292,65536,65847,96,409,292,65650,16,64,186,145,17,66030,428,65895,65739,65542,65674,256,65675,65847,1]

theorem envBound60118 : H12AffineFastState.Bounded env60118 := by
  intro p hp
  have h : env60118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60117_60118 : H12AffineEnvironment.transform 10 372 env60117 = env60118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env60117 == env60118) = true)

theorem identity60118 : scanCanonicalize (H12AffineFastState.compose env60118 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound60118 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60119 : List Nat := [2,4,8,16,32,64,128,256,1,408,372,509,24,429,292,171,412,96,409,292,217,16,64,186,145,17,325,428,460,96,173,33,256,32,412,1]

theorem envBound60119 : H12AffineFastState.Bounded env60119 := by
  intro p hp
  have h : env60119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60118_60119 : H12AffineEnvironment.transform 15 171 env60118 = env60119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env60118 == env60119) = true)

theorem identity60119 : scanCanonicalize (H12AffineFastState.compose env60119 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60119 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60120 : List Nat := [2,4,8,16,32,64,128,110,1,246,26,147,24,195,74,171,242,96,247,74,217,16,64,186,145,17,43,194,162,96,173,33,110,32,242,1]

theorem envBound60120 : H12AffineFastState.Bounded env60120 := by
  intro p hp
  have h : env60120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60119_60120 : H12AffineEnvironment.transform 7 110 env60119 = env60120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60119 == env60120) = true)

def env60121 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,65650,1416,65,3158,1289,16,334087,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound60121 : H12AffineFastState.Bounded env60121 := by
  intro p hp
  have h : env60121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60113_60121 : H12AffineEnvironment.transform 12 1409 env60113 = env60121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60113 == env60121) = true)

theorem identity60121 : scanCanonicalize (H12AffineFastState.compose env60121 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6542) := by decide +kernel

theorem selectedBound60121 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60122 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6542,3293,262144,1025,2128,6652,1416,65,3158,1289,16,262281,4177,3213,7389,6536,4208,256,6405,3293,0]

theorem envBound60122 : H12AffineFastState.Bounded env60122 := by
  intro p hp
  have h : env60122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60121_60122 : H12AffineEnvironment.transform 15 6542 env60121 = env60122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6542 env60121 == env60122) = true)

theorem identity60122 : scanCanonicalize (H12AffineFastState.compose env60122 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60122 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60123 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,5238,293,262144,1025,1448,5124,1416,65,430,1289,16,262281,4177,373,4389,5232,4208,256,5373,293,0]

theorem envBound60123 : H12AffineFastState.Bounded env60123 := by
  intro p hp
  have h : env60123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60122_60123 : H12AffineEnvironment.transform 10 1528 env60122 = env60123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60122 == env60123) = true)

theorem identity60123 : scanCanonicalize (H12AffineFastState.compose env60123 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 444) := by decide +kernel

theorem selectedBound60123 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60124 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,5238,293,444,1025,1448,5124,1416,65,430,1289,16,309,4177,373,4389,5232,4208,256,5373,293,0]

theorem envBound60124 : H12AffineFastState.Bounded env60124 := by
  intro p hp
  have h : env60124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60123_60124 : H12AffineEnvironment.transform 17 444 env60123 = env60124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 444 env60123 == env60124) = true)

theorem identity60124 : scanCanonicalize (H12AffineFastState.compose env60124 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound60124 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60125 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,80,1409,0,1448,1062,293,444,1025,1448,1108,1416,65,430,1289,16,309,1,373,373,1056,32,256,1197,293,0]

theorem envBound60125 : H12AffineFastState.Bounded env60125 := by
  intro p hp
  have h : env60125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60124_60125 : H12AffineEnvironment.transform 11 80 env60124 = env60125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env60124 == env60125) = true)

theorem identity60125 : scanCanonicalize (H12AffineFastState.compose env60125 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60125 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60126 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,80,348,0,373,251,293,444,220,373,137,341,65,430,468,16,309,1,373,373,253,32,256,112,293,0]

theorem envBound60126 : H12AffineFastState.Bounded env60126 := by
  intro p hp
  have h : env60126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60125_60126 : H12AffineEnvironment.transform 9 221 env60125 = env60126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60125 == env60126) = true)

theorem identity60126 : scanCanonicalize (H12AffineFastState.compose env60126 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60126 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60127 : List Nat := [2,4,8,16,32,16,128,256,1,141,293,0,268,0,293,171,293,444,140,293,137,261,17,430,388,16,309,1,293,293,173,32,256,32,293,0]

theorem envBound60127 : H12AffineFastState.Bounded env60127 := by
  intro p hp
  have h : env60127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60126_60127 : H12AffineEnvironment.transform 5 16 env60126 = env60127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60126 == env60127) = true)

theorem identity60127 : scanCanonicalize (H12AffineFastState.compose env60127 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60127 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60128 : List Nat := [2,4,8,16,0,16,128,256,1,141,261,0,268,0,261,139,261,412,140,261,137,261,17,398,388,16,277,1,261,261,141,0,256,0,261,0]

theorem envBound60128 : H12AffineFastState.Bounded env60128 := by
  intro p hp
  have h : env60128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60127_60128 : H12AffineEnvironment.transform 4 0 env60127 = env60128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60127 == env60128) = true)

theorem identity60128 : scanCanonicalize (H12AffineFastState.compose env60128 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 13) := by decide +kernel

theorem selectedBound60128 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60129 : List Nat := [2,4,8,16,0,16,128,13,1,141,8,0,1,0,8,139,8,145,140,8,137,8,17,131,137,16,24,1,8,8,141,0,13,0,8,0]

theorem envBound60129 : H12AffineFastState.Bounded env60129 := by
  intro p hp
  have h : env60129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60128_60129 : H12AffineEnvironment.transform 7 13 env60128 = env60129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 13 env60128 == env60129) = true)

theorem identity60129 : scanCanonicalize (H12AffineFastState.compose env60129 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound60129 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60130 : List Nat := [2,4,8,16,0,16,11,13,1,6,8,0,1,0,8,0,8,26,7,8,2,8,17,8,2,16,24,1,8,8,6,0,13,0,8,0]

theorem envBound60130 : H12AffineFastState.Bounded env60130 := by
  intro p hp
  have h : env60130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60129_60130 : H12AffineEnvironment.transform 6 11 env60129 = env60130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env60129 == env60130) = true)

theorem identity60130 : scanCanonicalize (H12AffineFastState.compose env60130 (packedSelected [1,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60130 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60131 : List Nat := [2,4,2,16,0,16,1,7,1,6,2,0,1,0,2,0,2,16,7,2,2,2,17,2,2,16,18,1,2,2,6,0,7,0,2,0]

theorem envBound60131 : H12AffineFastState.Bounded env60131 := by
  intro p hp
  have h : env60131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60130_60131 : H12AffineEnvironment.transform 2 2 env60130 = env60131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60130 == env60131) = true)

theorem identity60131 : scanCanonicalize (H12AffineFastState.compose env60131 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60132 : List Nat := [2,4,2,3,0,3,1,7,1,6,2,0,1,0,2,0,2,3,7,2,2,2,2,2,2,3,1,1,2,2,6,0,7,0,2,0]

theorem envBound60132 : H12AffineFastState.Bounded env60132 := by
  intro p hp
  have h : env60132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60131_60132 : H12AffineEnvironment.transform 3 3 env60131 = env60132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60131 == env60132) = true)

theorem identity60132 : scanCanonicalize (H12AffineFastState.compose env60132 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60133 : List Nat := [0,4,0,1,0,1,1,5,1,4,0,0,1,0,0,0,0,1,5,0,0,0,0,0,0,1,1,1,0,0,4,0,5,0,0,0]

theorem envBound60133 : H12AffineFastState.Bounded env60133 := by
  intro p hp
  have h : env60133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60132_60133 : H12AffineEnvironment.transform 0 0 env60132 = env60133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60132 == env60133) = true)

def env60134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3670,1288,9616,2366324,4177,77954,67410,65543,68606,256,65675,78034,10113]

theorem envBound60134 : H12AffineFastState.Bounded env60134 := by
  intro p hp
  have h : env60134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60088_60134 : H12AffineEnvironment.transform 22 9665 env60088 = env60134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60088 == env60134) = true)

def env60135 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1288,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9601]

end H12CloudChart0