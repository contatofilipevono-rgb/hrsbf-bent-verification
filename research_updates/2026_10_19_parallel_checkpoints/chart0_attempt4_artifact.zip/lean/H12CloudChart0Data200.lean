import H12CloudChart0Data199

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity50641 : scanCanonicalize (H12AffineFastState.compose env50641 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50641 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50642 : List Nat := [2,4,8,16,16,1,8,21,512,21,529,4096,24,4113,1,18,4096,528,20,0,4112,16,1,19,24,1,528,4097,4112,513,5,0,20,1,4096,529]

theorem envBound50642 : H12AffineFastState.Bounded env50642 := by
  intro p hp
  have h : env50642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50641_50642 : H12AffineEnvironment.transform 4 16 env50641 = env50642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50641 == env50642) = true)

theorem identity50642 : scanCanonicalize (H12AffineFastState.compose env50642 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50642 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env50643 : List Nat := [2,4,8,1,1,1,8,4,512,4,512,4096,9,4096,1,3,4096,513,5,0,4097,1,1,2,9,1,513,4097,4097,513,5,0,5,1,4096,512]

theorem envBound50643 : H12AffineFastState.Bounded env50643 := by
  intro p hp
  have h : env50643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50642_50643 : H12AffineEnvironment.transform 3 1 env50642 = env50643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50642 == env50643) = true)

theorem identity50643 : scanCanonicalize (H12AffineFastState.compose env50643 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound50643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50644 : List Nat := [2,4,8,1,1,1,8,4,512,4,512,1,9,1,1,3,1,513,5,0,0,1,1,2,9,1,513,0,0,513,5,0,5,1,1,512]

theorem envBound50644 : H12AffineFastState.Bounded env50644 := by
  intro p hp
  have h : env50644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50643_50644 : H12AffineEnvironment.transform 11 1 env50643 = env50644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50643 == env50644) = true)

theorem identity50644 : scanCanonicalize (H12AffineFastState.compose env50644 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound50644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50645 : List Nat := [2,4,8,1,1,1,8,4,15,4,15,1,9,1,1,3,1,14,5,0,0,1,1,2,9,1,14,0,0,14,5,0,5,1,1,15]

theorem envBound50645 : H12AffineFastState.Bounded env50645 := by
  intro p hp
  have h : env50645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50644_50645 : H12AffineEnvironment.transform 8 15 env50644 = env50645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env50644 == env50645) = true)

def env50646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272392,169216,41311,8193,64,2048,163840,45404,283904,156697,411973,257,21792,46093,169744]

theorem envBound50646 : H12AffineFastState.Bounded env50646 := by
  intro p hp
  have h : env50646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50631_50646 : H12AffineEnvironment.transform 6 9 env50631 = env50646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50631 == env50646) = true)

theorem identity50646 : scanCanonicalize (H12AffineFastState.compose env50646 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound50646 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env50647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,160013,21792,169216,41311,8193,64,2048,163840,45404,10280,156697,144493,257,21792,46093,169744]

theorem envBound50647 : H12AffineFastState.Bounded env50647 := by
  intro p hp
  have h : env50647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50646_50647 : H12AffineEnvironment.transform 17 32040 env50646 = env50647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env50646 == env50647) = true)

theorem identity50647 : scanCanonicalize (H12AffineFastState.compose env50647 (packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50647 : packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env50648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,160013,21792,155996,21763,8193,64,2048,160860,17664,10280,156697,144493,257,21792,16465,156492]

theorem envBound50648 : H12AffineFastState.Bounded env50648 := by
  intro p hp
  have h : env50648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50647_50648 : H12AffineEnvironment.transform 14 29788 env50647 = env50648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50647 == env50648) = true)

theorem identity50648 : scanCanonicalize (H12AffineFastState.compose env50648 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50648 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env50649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,21621,34,131072,23809,1025,21620,151844,21792,147829,21763,40,64,2048,152693,17664,2049,148528,136260,257,21792,16465,148325]

theorem envBound50649 : H12AffineFastState.Bounded env50649 := by
  intro p hp
  have h : env50649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50648_50649 : H12AffineEnvironment.transform 12 41 env50648 = env50649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50648 == env50649) = true)

theorem identity50649 : scanCanonicalize (H12AffineFastState.compose env50649 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50649 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env50650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,372,34,131072,2048,1025,373,132133,33,136308,2,40,64,2048,131444,4097,2049,135473,136260,257,33,5456,136804]

theorem envBound50650 : H12AffineFastState.Bounded env50650 := by
  intro p hp
  have h : env50650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50649_50650 : H12AffineEnvironment.transform 13 5377 env50649 = env50650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50649 == env50650) = true)

theorem identity50650 : scanCanonicalize (H12AffineFastState.compose env50650 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound50650 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,372,34,4469,2048,1025,373,5456,33,1281,2,40,64,2048,4097,4097,2049,68,1329,257,33,5456,1809]

theorem envBound50651 : H12AffineFastState.Bounded env50651 := by
  intro p hp
  have h : env50651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50650_50651 : H12AffineEnvironment.transform 16 4469 env50650 = env50651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env50650 == env50651) = true)

theorem identity50651 : scanCanonicalize (H12AffineFastState.compose env50651 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound50651 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env50652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,41,3392,372,34,2356,2048,1025,373,3345,33,1281,2,40,64,2048,2112,2112,2049,68,1329,257,33,3345,1809]

theorem envBound50652 : H12AffineFastState.Bounded env50652 := by
  intro p hp
  have h : env50652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50651_50652 : H12AffineEnvironment.transform 11 2113 env50651 = env50652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env50651 == env50652) = true)

theorem identity50652 : scanCanonicalize (H12AffineFastState.compose env50652 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50652 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50653 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,41,2421,372,34,2356,2048,52,373,2340,33,308,2,40,64,2048,2112,2112,2049,68,260,257,33,2340,804]

theorem envBound50653 : H12AffineFastState.Bounded env50653 := by
  intro p hp
  have h : env50653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50652_50653 : H12AffineEnvironment.transform 9 53 env50652 = env50653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50652 == env50653) = true)

theorem identity50653 : scanCanonicalize (H12AffineFastState.compose env50653 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50653 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env50654 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2113,41,2049,0,34,2112,2048,52,1,2128,33,64,2,40,64,2048,2112,2112,2049,68,112,117,33,2128,592]

theorem envBound50654 : H12AffineFastState.Bounded env50654 := by
  intro p hp
  have h : env50654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50653_50654 : H12AffineEnvironment.transform 7 116 env50653 = env50654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50653 == env50654) = true)

theorem identity50654 : scanCanonicalize (H12AffineFastState.compose env50654 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50654 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50655 : List Nat := [2,4,8,16,32,48,9,4,512,53,2048,2097,41,2049,0,34,2096,2048,52,1,2080,33,48,2,40,48,2048,2096,2096,2049,52,0,5,33,2080,544]

theorem envBound50655 : H12AffineFastState.Bounded env50655 := by
  intro p hp
  have h : env50655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50654_50655 : H12AffineEnvironment.transform 5 48 env50654 = env50655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50654 == env50655) = true)

theorem identity50655 : scanCanonicalize (H12AffineFastState.compose env50655 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50655 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50656 : List Nat := [2,4,8,16,1,17,9,4,512,20,2048,2064,8,2049,0,3,2065,2048,21,1,2049,0,17,2,9,17,2048,2065,2065,2049,21,0,5,0,2049,513]

theorem envBound50656 : H12AffineFastState.Bounded env50656 := by
  intro p hp
  have h : env50656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50655_50656 : H12AffineEnvironment.transform 4 1 env50655 = env50656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50655 == env50656) = true)

theorem identity50656 : scanCanonicalize (H12AffineFastState.compose env50656 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound50656 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50657 : List Nat := [2,4,8,16,1,17,9,4,4,20,2048,2064,8,2049,0,3,2065,2048,21,1,2049,0,17,2,9,17,2048,2065,2065,2049,21,0,5,0,2049,5]

theorem envBound50657 : H12AffineFastState.Bounded env50657 := by
  intro p hp
  have h : env50657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50656_50657 : H12AffineEnvironment.transform 8 4 env50656 = env50657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env50656 == env50657) = true)

theorem identity50657 : scanCanonicalize (H12AffineFastState.compose env50657 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound50657 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50658 : List Nat := [2,4,8,2,1,3,9,4,4,6,2048,2050,8,2049,0,3,2051,2048,7,1,2049,0,3,2,9,3,2048,2051,2051,2049,7,0,5,0,2049,5]

theorem envBound50658 : H12AffineFastState.Bounded env50658 := by
  intro p hp
  have h : env50658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50657_50658 : H12AffineEnvironment.transform 3 2 env50657 = env50658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env50657 == env50658) = true)

theorem identity50658 : scanCanonicalize (H12AffineFastState.compose env50658 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50659 : List Nat := [0,4,8,0,1,1,9,4,4,4,2048,2048,8,2049,0,1,2049,2048,5,1,2049,0,1,0,9,1,2048,2049,2049,2049,5,0,5,0,2049,5]

theorem envBound50659 : H12AffineFastState.Bounded env50659 := by
  intro p hp
  have h : env50659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50658_50659 : H12AffineEnvironment.transform 0 0 env50658 = env50659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50658 == env50659) = true)

theorem identity50659 : scanCanonicalize (H12AffineFastState.compose env50659 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound50659 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50660 : List Nat := [0,4,1,0,1,1,0,4,4,4,2048,2048,1,2049,0,1,2049,2048,5,1,2049,0,1,0,0,1,2048,2049,2049,2049,5,0,5,0,2049,5]

theorem envBound50660 : H12AffineFastState.Bounded env50660 := by
  intro p hp
  have h : env50660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50659_50660 : H12AffineEnvironment.transform 2 1 env50659 = env50660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env50659 == env50660) = true)

def env50661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169217,95497,8328,64,4464648,163841,45524,283905,156697,4350284,257,21792,46212,213966]

theorem envBound50661 : H12AffineFastState.Bounded env50661 := by
  intro p hp
  have h : env50661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50595_50661 : H12AffineEnvironment.transform 22 169217 env50595 = env50661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env50595 == env50661) = true)

def env50662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169217,95497,8328,64,2184,163841,45524,283905,156697,412108,257,21792,46212,213966]

theorem envBound50662 : H12AffineFastState.Bounded env50662 := by
  intro p hp
  have h : env50662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50661_50662 : H12AffineEnvironment.transform 21 272512 env50661 = env50662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50661 == env50662) = true)

theorem identity50662 : scanCanonicalize (H12AffineFastState.compose env50662 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound50662 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,115871,272512,73754,95497,8328,64,2184,79130,45524,283905,119042,392407,257,21792,46212,63189]

theorem envBound50663 : H12AffineFastState.Bounded env50663 := by
  intro p hp
  have h : env50663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50662_50663 : H12AffineEnvironment.transform 16 111899 env50662 = env50663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env50662 == env50663) = true)

def env50664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,115871,32,73754,95497,8328,64,2184,79130,45524,32161,119042,119927,257,21792,46212,63189]

theorem envBound50664 : H12AffineFastState.Bounded env50664 := by
  intro p hp
  have h : env50664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50663_50664 : H12AffineEnvironment.transform 17 10400 env50663 = env50664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env50663 == env50664) = true)

theorem identity50664 : scanCanonicalize (H12AffineFastState.compose env50664 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound50664 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,13388,10400,1025,32769,17864,32,41293,62558,8328,64,2184,46157,45524,32161,20565,21792,257,21792,46212,63189]

theorem envBound50665 : H12AffineFastState.Bounded env50665 := by
  intro p hp
  have h : env50665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50664_50665 : H12AffineEnvironment.transform 15 33111 env50664 = env50665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env50664 == env50665) = true)

theorem identity50665 : scanCanonicalize (H12AffineFastState.compose env50665 (packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound50665 : packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env50666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,509,170,13388,10400,1025,508,17864,32,8368,30115,8328,64,2184,13744,12329,32161,20565,21792,257,21792,13689,30504]

theorem envBound50666 : H12AffineFastState.Bounded env50666 := by
  intro p hp
  have h : env50666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50665_50666 : H12AffineEnvironment.transform 14 509 env50665 = env50666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env50665 == env50666) = true)

theorem identity50666 : scanCanonicalize (H12AffineFastState.compose env50666 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50666 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env50667 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,136,170,13388,10400,1025,137,17597,32,8368,29910,8328,64,2184,13509,12329,31956,20565,21589,116,21589,13324,30301]

theorem envBound50667 : H12AffineFastState.Bounded env50667 := by
  intro p hp
  have h : env50667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50666_50667 : H12AffineEnvironment.transform 7 117 env50666 = env50667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50666 == env50667) = true)

theorem identity50667 : scanCanonicalize (H12AffineFastState.compose env50667 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound50667 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env50668 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,16384,136,170,5356,2048,1025,137,17597,32,16,21622,40,64,2184,5221,4233,23668,20565,21589,116,21589,5292,22269]

theorem envBound50668 : H12AffineFastState.Bounded env50668 := by
  intro p hp
  have h : env50668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50667_50668 : H12AffineEnvironment.transform 12 160 env50667 = env50668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env50667 == env50668) = true)

theorem identity50668 : scanCanonicalize (H12AffineFastState.compose env50668 (packedSelected [2,5,6,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50668 : packedSelected [2,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env50669 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,160,16384,136,170,4232,2048,101,137,16601,32,16,20498,40,64,2184,4097,4233,22544,20565,20529,116,20529,4296,21145]

theorem envBound50669 : H12AffineFastState.Bounded env50669 := by
  intro p hp
  have h : env50669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50668_50669 : H12AffineEnvironment.transform 9 100 env50668 = env50669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50668 == env50669) = true)

theorem identity50669 : scanCanonicalize (H12AffineFastState.compose env50669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound50669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50670 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,160,4249,136,170,4232,2048,101,137,4160,32,16,139,40,64,2184,4097,4233,2185,204,168,116,168,4296,512]

theorem envBound50670 : H12AffineFastState.Bounded env50670 := by
  intro p hp
  have h : env50670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50669_50670 : H12AffineEnvironment.transform 13 4249 env50669 = env50670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env50669 == env50670) = true)

theorem identity50670 : scanCanonicalize (H12AffineFastState.compose env50670 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound50670 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50671 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,152,160,1,136,170,16,2048,101,137,216,32,16,139,40,64,2184,153,17,2185,204,168,116,168,80,512]

theorem envBound50671 : H12AffineFastState.Bounded env50671 := by
  intro p hp
  have h : env50671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50670_50671 : H12AffineEnvironment.transform 11 152 env50670 = env50671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env50670 == env50671) = true)

theorem identity50671 : scanCanonicalize (H12AffineFastState.compose env50671 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50671 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50672 : List Nat := [2,4,8,16,1,64,128,84,512,69,2048,152,129,1,136,139,16,2048,68,137,216,1,16,139,9,64,2184,153,17,2185,204,137,85,137,80,512]

theorem envBound50672 : H12AffineFastState.Bounded env50672 := by
  intro p hp
  have h : env50672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50671_50672 : H12AffineEnvironment.transform 4 1 env50671 = env50672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50671 == env50672) = true)

theorem identity50672 : scanCanonicalize (H12AffineFastState.compose env50672 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 216) := by decide +kernel

theorem selectedBound50672 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50673 : List Nat := [2,4,8,16,1,64,128,84,512,69,216,152,129,1,136,139,16,216,68,137,216,1,16,139,9,64,80,153,17,81,204,137,85,137,80,512]

theorem envBound50673 : H12AffineFastState.Bounded env50673 := by
  intro p hp
  have h : env50673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50672_50673 : H12AffineEnvironment.transform 10 216 env50672 = env50673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env50672 == env50673) = true)

theorem identity50673 : scanCanonicalize (H12AffineFastState.compose env50673 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50673 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50674 : List Nat := [2,4,8,16,1,17,128,5,512,20,137,152,129,1,136,139,16,137,21,137,137,1,16,139,9,17,1,153,17,0,157,137,4,137,1,512]

theorem envBound50674 : H12AffineFastState.Bounded env50674 := by
  intro p hp
  have h : env50674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50673_50674 : H12AffineEnvironment.transform 5 17 env50673 = env50674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50673 == env50674) = true)

def env50675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,115871,33,73754,95497,8328,64,2184,79130,45524,32160,119042,119926,257,21792,46212,63189]

theorem envBound50675 : H12AffineFastState.Bounded env50675 := by
  intro p hp
  have h : env50675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50663_50675 : H12AffineEnvironment.transform 17 10401 env50663 = env50675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env50663 == env50675) = true)

theorem identity50675 : scanCanonicalize (H12AffineFastState.compose env50675 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50675 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10401,1025,32769,58516,33,17,21762,8328,64,2184,5393,45524,32160,61705,62589,257,21792,46212,63189]

theorem envBound50676 : H12AffineFastState.Bounded env50676 := by
  intro p hp
  have h : env50676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50675_50676 : H12AffineEnvironment.transform 15 8203 env50675 = env50676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50675 == env50676) = true)

theorem identity50676 : scanCanonicalize (H12AffineFastState.compose env50676 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50676 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env50677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10280,1025,32769,58397,33,17,21762,8193,64,2049,5393,45405,32041,61705,62589,257,21792,46093,63068]

theorem envBound50677 : H12AffineFastState.Bounded env50677 := by
  intro p hp
  have h : env50677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50676_50677 : H12AffineEnvironment.transform 6 9 env50676 = env50677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50676 == env50677) = true)

theorem identity50677 : scanCanonicalize (H12AffineFastState.compose env50677 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50677 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1025,29788,4160,33,17,21762,8193,64,2049,5393,17664,32041,1364,32,257,21792,16464,513]

theorem envBound50678 : H12AffineFastState.Bounded env50678 := by
  intro p hp
  have h : env50678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50677_50678 : H12AffineEnvironment.transform 14 29789 env50677 = env50678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50677 == env50678) = true)

theorem identity50678 : scanCanonicalize (H12AffineFastState.compose env50678 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50678 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50679 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8203,24861,10280,1025,29708,4112,33,17,21762,8193,16,2049,5393,17664,32041,1284,32,257,21792,16384,513]

theorem envBound50679 : H12AffineFastState.Bounded env50679 := by
  intro p hp
  have h : env50679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50678_50679 : H12AffineEnvironment.transform 5 16 env50678 = env50679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50678 == env50679) = true)

theorem identity50679 : scanCanonicalize (H12AffineFastState.compose env50679 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50679 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50680 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,263,16401,2340,1025,21760,4112,33,17,21762,269,16,2049,5393,17664,23589,1284,32,257,21792,16384,513]

theorem envBound50680 : H12AffineFastState.Bounded env50680 := by
  intro p hp
  have h : env50680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50679_50680 : H12AffineEnvironment.transform 12 268 env50679 = env50680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50679 == env50680) = true)

theorem identity50680 : scanCanonicalize (H12AffineFastState.compose env50680 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5685) := by decide +kernel

theorem selectedBound50680 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50681 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5685,820,263,5668,2340,1025,821,4112,33,17,823,269,16,2049,5393,4917,2576,1284,32,257,789,5685,513]

theorem envBound50681 : H12AffineFastState.Bounded env50681 := by
  intro p hp
  have h : env50681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50680_50681 : H12AffineEnvironment.transform 13 5685 env50680 = env50681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5685 env50680 == env50681) = true)

theorem identity50681 : scanCanonicalize (H12AffineFastState.compose env50681 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound50681 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50682 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,268,2309,820,263,2324,2340,1025,821,3872,33,17,823,269,16,2049,2593,3077,2576,1284,32,257,789,2309,513]

theorem envBound50682 : H12AffineFastState.Bounded env50682 := by
  intro p hp
  have h : env50682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50681_50682 : H12AffineEnvironment.transform 11 3888 env50681 = env50682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env50681 == env50682) = true)

theorem identity50682 : scanCanonicalize (H12AffineFastState.compose env50682 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound50682 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env50683 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1028,820,268,1281,820,263,1296,1312,1025,821,804,33,17,823,269,16,1029,1573,1,1556,1284,32,257,789,1281,513]

theorem envBound50683 : H12AffineFastState.Bounded env50683 := by
  intro p hp
  have h : env50683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50682_50683 : H12AffineEnvironment.transform 10 1028 env50682 = env50683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env50682 == env50683) = true)

theorem identity50683 : scanCanonicalize (H12AffineFastState.compose env50683 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound50683 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env50684 : List Nat := [2,4,8,16,32,16,9,256,308,1024,1028,0,268,1281,0,263,1296,1312,1025,1,16,33,17,3,269,16,1029,1297,1,1312,1284,32,257,33,1281,309]

theorem envBound50684 : H12AffineFastState.Bounded env50684 := by
  intro p hp
  have h : env50684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50683_50684 : H12AffineEnvironment.transform 8 308 env50683 = env50684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env50683 == env50684) = true)

theorem identity50684 : scanCanonicalize (H12AffineFastState.compose env50684 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50684 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50685 : List Nat := [2,4,8,16,32,16,9,20,32,1024,1028,0,24,1045,0,19,1028,1076,1025,1,16,33,17,3,25,16,1029,1029,1,1076,1040,32,21,33,1045,33]

theorem envBound50685 : H12AffineFastState.Bounded env50685 := by
  intro p hp
  have h : env50685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50684_50685 : H12AffineEnvironment.transform 7 20 env50684 = env50685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50684 == env50685) = true)

theorem identity50685 : scanCanonicalize (H12AffineFastState.compose env50685 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50685 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50686 : List Nat := [2,4,8,16,32,16,9,20,32,20,16,0,24,1,0,19,16,32,21,1,16,33,17,3,25,16,17,17,1,32,4,32,21,33,1,33]

theorem envBound50686 : H12AffineFastState.Bounded env50686 := by
  intro p hp
  have h : env50686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50685_50686 : H12AffineEnvironment.transform 9 20 env50685 = env50686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50685 == env50686) = true)

theorem identity50686 : scanCanonicalize (H12AffineFastState.compose env50686 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50687 : List Nat := [2,4,8,16,0,16,9,20,0,20,16,0,24,1,0,19,16,0,21,1,16,1,17,3,25,16,17,17,1,0,4,0,21,1,1,1]

theorem envBound50687 : H12AffineFastState.Bounded env50687 := by
  intro p hp
  have h : env50687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50686_50687 : H12AffineEnvironment.transform 4 0 env50686 = env50687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50686 == env50687) = true)

theorem identity50687 : scanCanonicalize (H12AffineFastState.compose env50687 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50687 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50688 : List Nat := [2,4,8,1,0,1,9,5,0,5,1,0,9,1,0,2,1,0,4,1,1,1,0,3,8,1,0,0,1,0,4,0,4,1,1,1]

theorem envBound50688 : H12AffineFastState.Bounded env50688 := by
  intro p hp
  have h : env50688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50687_50688 : H12AffineEnvironment.transform 3 1 env50687 = env50688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50687 == env50688) = true)

theorem identity50688 : scanCanonicalize (H12AffineFastState.compose env50688 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50689 : List Nat := [2,4,2,1,0,1,3,5,0,5,1,0,3,1,0,2,1,0,4,1,1,1,0,3,2,1,0,0,1,0,4,0,4,1,1,1]

theorem envBound50689 : H12AffineFastState.Bounded env50689 := by
  intro p hp
  have h : env50689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50688_50689 : H12AffineEnvironment.transform 2 2 env50688 = env50689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50688 == env50689) = true)

def env50690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169217,95497,8328,64,2185,163841,45524,283905,156697,412109,257,21792,46212,213966]

theorem envBound50690 : H12AffineFastState.Bounded env50690 := by
  intro p hp
  have h : env50690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50661_50690 : H12AffineEnvironment.transform 21 272513 env50661 = env50690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50661 == env50690) = true)

theorem identity50690 : scanCanonicalize (H12AffineFastState.compose env50690 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50690 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160132,272513,169217,21762,8328,64,2185,163841,45524,283905,156697,412109,257,21792,46212,156613]

theorem envBound50691 : H12AffineFastState.Bounded env50691 := by
  intro p hp
  have h : env50691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50690_50691 : H12AffineEnvironment.transform 15 8203 env50690 = env50691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50690 == env50691) = true)

def env50692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160012,272393,169217,21762,8192,64,2049,163841,45404,283905,156697,411973,257,21792,46092,156493]

theorem envBound50692 : H12AffineFastState.Bounded env50692 := by
  intro p hp
  have h : env50692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50691_50692 : H12AffineEnvironment.transform 6 8 env50691 = env50692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50691 == env50692) = true)

theorem identity50692 : scanCanonicalize (H12AffineFastState.compose env50692 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50692 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env50693 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,159865,272393,169076,21623,8192,64,2049,163841,45097,283764,156697,411696,116,21589,46092,156216]

theorem envBound50693 : H12AffineFastState.Bounded env50693 := by
  intro p hp
  have h : env50693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50692_50693 : H12AffineEnvironment.transform 7 117 env50692 = env50693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50692 == env50693) = true)

theorem identity50693 : scanCanonicalize (H12AffineFastState.compose env50693 (packedSelected [0,4,14,20,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound50693 : packedSelected [0,4,14,20,22,27] rootPS < 2^1333 := by decide +kernel

def env50694 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,159865,32,169076,21623,8192,64,2049,163841,45097,31837,156697,155673,116,21589,46092,156216]

theorem envBound50694 : H12AffineFastState.Bounded env50694 := by
  intro p hp
  have h : env50694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50693_50694 : H12AffineEnvironment.transform 17 10281 env50693 = env50694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50693 == env50694) = true)

theorem identity50694 : scanCanonicalize (H12AffineFastState.compose env50694 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound50694 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50695 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,32768,8203,131072,10281,1025,32769,139368,32,169076,1126,8192,64,2049,163841,45097,11340,144392,143368,116,1092,46092,143913]

theorem envBound50695 : H12AffineFastState.Bounded env50695 := by
  intro p hp
  have h : env50695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50694_50695 : H12AffineEnvironment.transform 13 4113 env50694 = env50695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env50694 == env50695) = true)

theorem identity50695 : scanCanonicalize (H12AffineFastState.compose env50695 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound50695 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50696 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,8232,8203,131072,10281,1025,8233,139368,32,144476,1126,8192,64,2049,139305,4097,11340,144392,143368,116,1092,5156,143913]

theorem envBound50696 : H12AffineFastState.Bounded env50696 := by
  intro p hp
  have h : env50696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50695_50696 : H12AffineEnvironment.transform 14 8232 env50695 = env50696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env50695 == env50696) = true)

def env50697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160013,272392,169217,21762,8193,64,2048,163841,45405,283905,156697,411972,257,21792,46093,156492]

theorem envBound50697 : H12AffineFastState.Bounded env50697 := by
  intro p hp
  have h : env50697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50691_50697 : H12AffineEnvironment.transform 6 9 env50691 = env50697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50691 == env50697) = true)

theorem identity50697 : scanCanonicalize (H12AffineFastState.compose env50697 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound50697 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env50698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,171109,1025,32769,160013,177261,169217,21762,8193,64,2048,163841,45405,182628,156697,54561,257,21792,46093,156492]

theorem envBound50698 : H12AffineFastState.Bounded env50698 := by
  intro p hp
  have h : env50698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50697_50698 : H12AffineEnvironment.transform 17 171109 env50697 = env50698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env50697 == env50698) = true)

theorem identity50698 : scanCanonicalize (H12AffineFastState.compose env50698 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound50698 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env50699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,23668,1025,32769,45340,29820,21776,21762,8193,64,2048,16400,45405,2421,41992,54561,257,21792,46093,41821]

theorem envBound50699 : H12AffineFastState.Bounded env50699 := by
  intro p hp
  have h : env50699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50698_50699 : H12AffineEnvironment.transform 16 49169 env50698 = env50699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env50698 == env50699) = true)

theorem identity50699 : scanCanonicalize (H12AffineFastState.compose env50699 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50699 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env50700 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,23668,1025,8541,4160,29820,21776,21762,8193,64,2048,16400,4097,2421,1364,29821,257,21792,5457,513]

theorem envBound50700 : H12AffineFastState.Bounded env50700 := by
  intro p hp
  have h : env50700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50699_50700 : H12AffineEnvironment.transform 14 8540 env50699 = env50700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50699 == env50700) = true)

def env50701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,8388608,8642568,8328,64,4464648,8393985,8529108,8830976,156697,12645452,257,21793,46213,213966]

theorem envBound50701 : H12AffineFastState.Bounded env50701 := by
  intro p hp
  have h : env50701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50594_50701 : H12AffineEnvironment.transform 20 160133 env50594 = env50701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160133 env50594 == env50701) = true)

def env50702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169216,95496,8328,64,4464648,163841,45524,283904,156697,4350284,257,21793,46213,213966]

theorem envBound50702 : H12AffineFastState.Bounded env50702 := by
  intro p hp
  have h : env50702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50701_50702 : H12AffineEnvironment.transform 22 169216 env50701 = env50702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env50701 == env50702) = true)

def env50703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169216,95496,8328,64,2184,163841,45524,283904,156697,412108,257,21793,46213,213966]

theorem envBound50703 : H12AffineFastState.Bounded env50703 := by
  intro p hp
  have h : env50703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50702_50703 : H12AffineEnvironment.transform 21 272512 env50702 = env50703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50702 == env50703) = true)

theorem identity50703 : scanCanonicalize (H12AffineFastState.compose env50703 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound50703 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160133,272512,156117,95496,8328,64,2184,160980,17665,283904,156697,412108,257,21793,16464,213966]

theorem envBound50704 : H12AffineFastState.Bounded env50704 := by
  intro p hp
  have h : env50704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50703_50704 : H12AffineEnvironment.transform 14 29909 env50703 = env50704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env50703 == env50704) = true)

def env50705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272392,155997,95496,8192,64,2048,160860,17665,283904,156697,411972,257,21793,16464,213830]

theorem envBound50705 : H12AffineFastState.Bounded env50705 := by
  intro p hp
  have h : env50705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50704_50705 : H12AffineEnvironment.transform 6 8 env50704 = env50705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50704 == env50705) = true)

theorem identity50705 : scanCanonicalize (H12AffineFastState.compose env50705 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 204082) := by decide +kernel

theorem selectedBound50705 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env50706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,204082,1025,29788,160013,210234,155997,95496,8192,64,2048,160860,17665,215090,156697,87158,257,21793,16464,213830]

theorem envBound50706 : H12AffineFastState.Bounded env50706 := by
  intro p hp
  have h : env50706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50705_50706 : H12AffineEnvironment.transform 17 204082 env50705 = env50706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204082 env50705 == env50706) = true)

theorem identity50706 : scanCanonicalize (H12AffineFastState.compose env50706 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound50706 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,32040,1025,29788,69911,21792,65863,95496,8192,64,2048,70726,17665,10280,66563,87158,257,21793,16464,9052]

theorem envBound50707 : H12AffineFastState.Bounded env50707 := by
  intro p hp
  have h : env50707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50706_50707 : H12AffineEnvironment.transform 16 90138 env50706 = env50707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env50706 == env50707) = true)

theorem identity50707 : scanCanonicalize (H12AffineFastState.compose env50707 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50707 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,82247,23669,1025,21761,69911,21792,65863,87125,349,64,2048,70726,17665,2421,66563,87158,257,21793,16464,513]

theorem envBound50708 : H12AffineFastState.Bounded env50708 := by
  intro p hp
  have h : env50708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50707_50708 : H12AffineEnvironment.transform 12 349 env50707 = env50708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50707 == env50708) = true)

theorem identity50708 : scanCanonicalize (H12AffineFastState.compose env50708 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50708 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,65536,70726,2420,1025,0,69911,33,65863,65876,349,64,2048,70726,4096,2421,66563,65911,257,32,5457,513]

theorem envBound50709 : H12AffineFastState.Bounded env50709 := by
  intro p hp
  have h : env50709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50708_50709 : H12AffineEnvironment.transform 13 5377 env50708 = env50709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50708 == env50709) = true)

theorem identity50709 : scanCanonicalize (H12AffineFastState.compose env50709 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50709 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50710 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,1,65536,69974,2420,273,0,69911,33,65863,65876,349,64,2048,69974,4096,2421,65811,65911,257,32,4161,513]

theorem envBound50710 : H12AffineFastState.Bounded env50710 := by
  intro p hp
  have h : env50710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50709_50710 : H12AffineEnvironment.transform 9 272 env50709 = env50710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50709 == env50710) = true)

theorem identity50710 : scanCanonicalize (H12AffineFastState.compose env50710 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 4147) := by decide +kernel

theorem selectedBound50710 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env50711 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,1,4147,357,2420,273,0,292,33,4468,4455,349,64,2048,357,4096,2421,4384,4420,257,32,4161,513]

theorem envBound50711 : H12AffineFastState.Bounded env50711 := by
  intro p hp
  have h : env50711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50710_50711 : H12AffineEnvironment.transform 15 4147 env50710 = env50711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4147 env50710 == env50711) = true)

theorem identity50711 : scanCanonicalize (H12AffineFastState.compose env50711 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound50711 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50712 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,309,349,292,1,262,357,2420,273,0,292,33,65,82,349,64,2048,357,309,2421,21,113,257,32,372,513]

theorem envBound50712 : H12AffineFastState.Bounded env50712 := by
  intro p hp
  have h : env50712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50711_50712 : H12AffineEnvironment.transform 11 309 env50711 = env50712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env50711 == env50712) = true)

theorem identity50712 : scanCanonicalize (H12AffineFastState.compose env50712 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound50712 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50713 : List Nat := [2,4,8,16,32,64,8,256,512,272,292,309,349,292,1,262,357,80,273,0,292,33,65,82,349,64,292,357,309,81,21,113,257,32,372,513]

theorem envBound50713 : H12AffineFastState.Bounded env50713 := by
  intro p hp
  have h : env50713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50712_50713 : H12AffineEnvironment.transform 10 292 env50712 = env50713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env50712 == env50713) = true)

def env50714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160012,272393,155996,95496,8193,64,2049,160861,17665,283904,156697,411973,257,21793,16464,213831]

theorem envBound50714 : H12AffineFastState.Bounded env50714 := by
  intro p hp
  have h : env50714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50704_50714 : H12AffineEnvironment.transform 6 9 env50704 = env50714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50704 == env50714) = true)

theorem identity50714 : scanCanonicalize (H12AffineFastState.compose env50714 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound50714 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env50715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1025,29789,160012,156012,155996,95496,8193,64,2049,160861,17665,138341,156697,32,257,21793,16464,213831]

theorem envBound50715 : H12AffineFastState.Bounded env50715 := by
  intro p hp
  have h : env50715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50714_50715 : H12AffineEnvironment.transform 17 149861 env50714 = env50715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env50714 == env50715) = true)

theorem identity50715 : scanCanonicalize (H12AffineFastState.compose env50715 (packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound50715 : packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env50716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,131072,149861,1025,29789,160012,156012,155996,8542,8193,64,2049,160861,17665,138341,156697,32,257,21793,16464,136977]

theorem envBound50716 : H12AffineFastState.Bounded env50716 := by
  intro p hp
  have h : env50716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50715_50716 : H12AffineEnvironment.transform 15 21590 env50715 = env50716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env50715 == env50716) = true)

theorem identity50716 : scanCanonicalize (H12AffineFastState.compose env50716 (packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound50716 : packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env50717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,16449,2340,1025,29789,12621,8493,8477,8542,8193,64,2049,13340,17665,23588,9304,32,257,21793,16464,22352]

theorem envBound50717 : H12AffineFastState.Bounded env50717 := by
  intro p hp
  have h : env50717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50716_50717 : H12AffineEnvironment.transform 16 16449 env50716 = env50717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env50716 == env50717) = true)

theorem identity50717 : scanCanonicalize (H12AffineFastState.compose env50717 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50717 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env50718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,21590,16449,2340,1025,21840,4160,32,16,83,268,64,2049,5393,17665,23588,1365,32,257,21793,16464,22352]

theorem envBound50718 : H12AffineFastState.Bounded env50718 := by
  intro p hp
  have h : env50718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50717_50718 : H12AffineEnvironment.transform 12 269 env50717 = env50718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50717 == env50718) = true)

theorem identity50718 : scanCanonicalize (H12AffineFastState.compose env50718 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound50718 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4161,1296,1047,4096,2340,1025,1297,4160,32,16,83,268,64,2049,5393,5440,3173,1365,32,257,1376,4113,1809]

theorem envBound50719 : H12AffineFastState.Bounded env50719 := by
  intro p hp
  have h : env50719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50718_50719 : H12AffineEnvironment.transform 13 4161 env50718 = env50719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env50718 == env50719) = true)

theorem identity50719 : scanCanonicalize (H12AffineFastState.compose env50719 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50719 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50720 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,269,4161,80,343,4096,2340,321,81,4160,32,16,83,268,64,2049,4177,4096,2341,21,32,257,32,4113,593]

theorem envBound50720 : H12AffineFastState.Bounded env50720 := by
  intro p hp
  have h : env50720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50719_50720 : H12AffineEnvironment.transform 9 320 env50719 = env50720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50719 == env50720) = true)

theorem identity50720 : scanCanonicalize (H12AffineFastState.compose env50720 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound50720 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50721 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,269,65,80,343,0,2340,321,81,64,32,16,83,268,64,2049,81,0,2341,21,32,257,32,17,593]

theorem envBound50721 : H12AffineFastState.Bounded env50721 := by
  intro p hp
  have h : env50721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50720_50721 : H12AffineEnvironment.transform 11 0 env50720 = env50721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50720 == env50721) = true)

theorem identity50721 : scanCanonicalize (H12AffineFastState.compose env50721 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50721 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50722 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,269,16,1,262,0,2340,272,0,17,32,16,2,268,17,2049,0,0,2341,21,32,257,32,17,512]

theorem envBound50722 : H12AffineFastState.Bounded env50722 := by
  intro p hp
  have h : env50722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50721_50722 : H12AffineEnvironment.transform 5 17 env50721 = env50722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50721 == env50722) = true)

theorem identity50722 : scanCanonicalize (H12AffineFastState.compose env50722 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50722 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50723 : List Nat := [2,4,8,1,32,0,9,256,512,256,2048,0,269,1,1,262,0,2340,257,0,0,32,1,2,268,0,2049,0,0,2341,4,32,257,32,0,512]

theorem envBound50723 : H12AffineFastState.Bounded env50723 := by
  intro p hp
  have h : env50723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50722_50723 : H12AffineEnvironment.transform 3 1 env50722 = env50723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50722 == env50723) = true)

theorem identity50723 : scanCanonicalize (H12AffineFastState.compose env50723 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 298) := by decide +kernel

theorem selectedBound50723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50724 : List Nat := [2,4,8,1,32,0,9,256,512,256,298,0,269,1,1,262,0,14,257,0,0,32,1,2,268,0,299,0,0,15,4,32,257,32,0,512]

theorem envBound50724 : H12AffineFastState.Bounded env50724 := by
  intro p hp
  have h : env50724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50723_50724 : H12AffineEnvironment.transform 10 298 env50723 = env50724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 298 env50723 == env50724) = true)

theorem identity50724 : scanCanonicalize (H12AffineFastState.compose env50724 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound50724 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50725 : List Nat := [2,4,8,1,32,0,9,256,261,256,298,0,269,1,1,262,0,14,257,0,0,32,1,2,268,0,299,0,0,15,4,32,257,32,0,261]

theorem envBound50725 : H12AffineFastState.Bounded env50725 := by
  intro p hp
  have h : env50725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50724_50725 : H12AffineEnvironment.transform 8 261 env50724 = env50725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env50724 == env50725) = true)

theorem identity50725 : scanCanonicalize (H12AffineFastState.compose env50725 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50725 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50726 : List Nat := [2,4,8,1,32,0,9,36,33,36,14,0,41,1,1,34,0,14,37,0,0,32,1,2,40,0,15,0,0,15,4,32,37,32,0,33]

theorem envBound50726 : H12AffineFastState.Bounded env50726 := by
  intro p hp
  have h : env50726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50725_50726 : H12AffineEnvironment.transform 7 36 env50725 = env50726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50725 == env50726) = true)

def env50727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169216,95496,8328,64,2185,163841,45524,283904,156697,412109,257,21793,46213,213966]

theorem envBound50727 : H12AffineFastState.Bounded env50727 := by
  intro p hp
  have h : env50727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50702_50727 : H12AffineEnvironment.transform 21 272513 env50702 = env50727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50702 == env50727) = true)

theorem identity50727 : scanCanonicalize (H12AffineFastState.compose env50727 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound50727 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,272513,62660,95496,8328,64,2185,57797,45524,283904,1501,272393,257,21793,46213,74250]

theorem envBound50728 : H12AffineFastState.Bounded env50728 := by
  intro p hp
  have h : env50728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50727_50728 : H12AffineEnvironment.transform 16 25028 env50727 = env50728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env50727 == env50728) = true)

theorem identity50728 : scanCanonicalize (H12AffineFastState.compose env50728 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50728 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,4161,272513,62660,21763,8328,64,2185,57797,45524,283904,1501,272393,257,21793,46213,513]

theorem envBound50729 : H12AffineFastState.Bounded env50729 := by
  intro p hp
  have h : env50729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50728_50729 : H12AffineEnvironment.transform 15 8203 env50728 = env50729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50728 == env50729) = true)

theorem identity50729 : scanCanonicalize (H12AffineFastState.compose env50729 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50729 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env50730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,5529,262144,1025,32769,4161,272513,32921,8542,8328,64,2185,38296,45524,270685,1501,272393,257,8572,46213,513]

theorem envBound50730 : H12AffineFastState.Bounded env50730 := by
  intro p hp
  have h : env50730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50729_50730 : H12AffineEnvironment.transform 13 13405 env50729 = env50730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50729 == env50730) = true)

theorem identity50730 : scanCanonicalize (H12AffineFastState.compose env50730 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound50730 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env50731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,5529,35325,1025,32769,4161,41340,32921,8542,8328,64,2185,38296,45524,43168,1501,41460,257,8572,46213,513]

theorem envBound50731 : H12AffineFastState.Bounded env50731 := by
  intro p hp
  have h : env50731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50730_50731 : H12AffineEnvironment.transform 17 35325 env50730 = env50731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env50730 == env50731) = true)

theorem identity50731 : scanCanonicalize (H12AffineFastState.compose env50731 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50731 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env50732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,5529,10401,1025,8541,4161,32,8645,8542,8328,64,2185,13508,4232,2556,1501,168,257,8572,5593,513]

theorem envBound50732 : H12AffineFastState.Bounded env50732 := by
  intro p hp
  have h : env50732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50731_50732 : H12AffineEnvironment.transform 14 8540 env50731 = env50732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50731 == env50732) = true)

theorem identity50732 : scanCanonicalize (H12AffineFastState.compose env50732 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound50732 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,478,5529,2420,1025,136,4161,32,16,139,349,64,2185,5393,4232,2556,1501,168,257,169,5593,513]

theorem envBound50733 : H12AffineFastState.Bounded env50733 := by
  intro p hp
  have h : env50733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50732_50733 : H12AffineEnvironment.transform 12 469 env50732 = env50733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env50732 == env50733) = true)

theorem identity50733 : scanCanonicalize (H12AffineFastState.compose env50733 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50733 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50734 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,80,263,5440,2420,1025,81,4161,32,16,82,349,64,2128,5393,4177,2341,1284,113,257,112,5376,513]

theorem envBound50734 : H12AffineFastState.Bounded env50734 := by
  intro p hp
  have h : env50734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50733_50734 : H12AffineEnvironment.transform 6 89 env50733 = env50734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50733 == env50734) = true)

theorem identity50734 : scanCanonicalize (H12AffineFastState.compose env50734 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3124) := by decide +kernel

theorem selectedBound50734 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50735 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3124,268,2405,80,263,2420,2420,1025,81,3189,32,16,82,349,64,2128,2341,3173,2341,1284,113,257,112,2356,513]

theorem envBound50735 : H12AffineFastState.Bounded env50735 := by
  intro p hp
  have h : env50735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50734_50735 : H12AffineEnvironment.transform 11 3124 env50734 = env50735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3124 env50734 == env50735) = true)

theorem identity50735 : scanCanonicalize (H12AffineFastState.compose env50735 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1873) := by decide +kernel

theorem selectedBound50735 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env50736 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1873,869,268,1588,80,263,1573,1573,1025,81,804,32,16,82,349,64,1793,1652,820,1652,1284,113,257,112,1637,513]

theorem envBound50736 : H12AffineFastState.Bounded env50736 := by
  intro p hp
  have h : env50736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50735_50736 : H12AffineEnvironment.transform 10 1873 env50735 = env50736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1873 env50735 == env50736) = true)

theorem identity50736 : scanCanonicalize (H12AffineFastState.compose env50736 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50736 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env50737 : List Nat := [2,4,8,16,32,64,89,36,512,1024,1653,577,40,1588,80,35,1573,1573,1025,81,512,32,16,82,121,64,1573,1652,528,1652,1056,113,37,112,1637,513]

theorem envBound50737 : H12AffineFastState.Bounded env50737 := by
  intro p hp
  have h : env50737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50736_50737 : H12AffineEnvironment.transform 7 36 env50736 = env50737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50736 == env50737) = true)

theorem identity50737 : scanCanonicalize (H12AffineFastState.compose env50737 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50737 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50738 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1572,528,40,1588,1,35,1573,1573,1025,0,512,32,16,3,40,17,1573,1573,528,1573,1056,32,37,33,1588,513]

theorem envBound50738 : H12AffineFastState.Bounded env50738 := by
  intro p hp
  have h : env50738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50737_50738 : H12AffineEnvironment.transform 5 17 env50737 = env50738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50737 == env50738) = true)

theorem identity50738 : scanCanonicalize (H12AffineFastState.compose env50738 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50739 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1572,513,40,1573,1,35,1573,1573,1025,0,512,32,1,3,40,0,1573,1573,513,1573,1056,32,37,33,1573,513]

theorem envBound50739 : H12AffineFastState.Bounded env50739 := by
  intro p hp
  have h : env50739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50738_50739 : H12AffineEnvironment.transform 3 1 env50738 = env50739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50738 == env50739) = true)

theorem identity50739 : scanCanonicalize (H12AffineFastState.compose env50739 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound50739 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50740 : List Nat := [2,4,8,1,32,0,8,36,512,36,512,513,40,513,1,35,513,513,37,0,512,32,1,3,40,0,513,513,513,513,4,32,37,33,513,513]

theorem envBound50740 : H12AffineFastState.Bounded env50740 := by
  intro p hp
  have h : env50740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50739_50740 : H12AffineEnvironment.transform 9 36 env50739 = env50740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env50739 == env50740) = true)

theorem identity50740 : scanCanonicalize (H12AffineFastState.compose env50740 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50741 : List Nat := [2,4,8,1,32,0,8,36,1,36,1,0,40,0,1,35,0,0,37,0,1,32,1,3,40,0,0,0,0,0,4,32,37,33,0,0]

theorem envBound50741 : H12AffineFastState.Bounded env50741 := by
  intro p hp
  have h : env50741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50740_50741 : H12AffineEnvironment.transform 8 1 env50740 = env50741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50740 == env50741) = true)

theorem identity50741 : scanCanonicalize (H12AffineFastState.compose env50741 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50741 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50742 : List Nat := [2,4,8,1,10,0,8,14,1,14,1,0,2,0,1,9,0,0,15,0,1,10,1,3,2,0,0,0,0,0,4,10,15,11,0,0]

theorem envBound50742 : H12AffineFastState.Bounded env50742 := by
  intro p hp
  have h : env50742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50741_50742 : H12AffineEnvironment.transform 4 10 env50741 = env50742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50741 == env50742) = true)

def env50743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169217,95497,8328,64,4464648,163840,45525,283905,156697,4350285,257,21793,46213,213966]

theorem envBound50743 : H12AffineFastState.Bounded env50743 := by
  intro p hp
  have h : env50743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50701_50743 : H12AffineEnvironment.transform 22 169217 env50701 = env50743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env50701 == env50743) = true)

def env50744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169217,95497,8328,64,2184,163840,45525,283905,156697,412109,257,21793,46213,213966]

theorem envBound50744 : H12AffineFastState.Bounded env50744 := by
  intro p hp
  have h : env50744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50743_50744 : H12AffineEnvironment.transform 21 272512 env50743 = env50744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50743 == env50744) = true)

def env50745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272392,169217,95497,8192,64,2048,163840,45405,283905,156697,411973,257,21793,46093,213830]

theorem envBound50745 : H12AffineFastState.Bounded env50745 := by
  intro p hp
  have h : env50745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50744_50745 : H12AffineEnvironment.transform 6 8 env50744 = env50745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50744 == env50745) = true)

def env50746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272392,17,95497,8192,64,2048,5392,45405,283905,61705,318549,257,21793,46093,120406]

theorem envBound50746 : H12AffineFastState.Bounded env50746 := by
  intro p hp
  have h : env50746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50745_50746 : H12AffineEnvironment.transform 16 38160 env50745 = env50746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env50745 == env50746) = true)

theorem identity50746 : scanCanonicalize (H12AffineFastState.compose env50746 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound50746 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35188,1025,32769,58397,41340,17,95497,8192,64,2048,5392,45405,56437,61705,21793,257,21793,46093,120406]

theorem envBound50747 : H12AffineFastState.Bounded env50747 := by
  intro p hp
  have h : env50747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50746_50747 : H12AffineEnvironment.transform 17 35188 env50746 = env50747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env50746 == env50747) = true)

theorem identity50747 : scanCanonicalize (H12AffineFastState.compose env50747 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound50747 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env50748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,65536,16693,23889,1025,21540,12344,30041,17,95497,8192,64,2048,5392,25976,2128,9516,21793,257,21793,24616,66163]

theorem envBound50748 : H12AffineFastState.Bounded env50748 := by
  intro p hp
  have h : env50748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50747_50748 : H12AffineEnvironment.transform 14 21541 env50747 = env50748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env50747 == env50748) = true)

theorem identity50748 : scanCanonicalize (H12AffineFastState.compose env50748 (packedSelected [2,3,5,6,7,9,10,11,12,15,18,19,20,22,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound50748 : packedSelected [2,3,5,6,7,9,10,11,12,15,18,19,20,22,26,27] rootPS < 2^1333 := by decide +kernel

def env50749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,30043,16693,23889,1025,21540,12344,30041,17,82,8192,64,2048,5392,25976,2128,9516,21793,257,21793,24616,30504]

theorem envBound50749 : H12AffineFastState.Bounded env50749 := by
  intro p hp
  have h : env50749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50748_50749 : H12AffineEnvironment.transform 15 30043 env50748 = env50749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env50748 == env50749) = true)

theorem identity50749 : scanCanonicalize (H12AffineFastState.compose env50749 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50749 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,292,8282,5172,2128,1025,293,12344,8280,17,82,8192,64,2048,5392,12409,2128,9516,32,257,32,13609,8745]

theorem envBound50750 : H12AffineFastState.Bounded env50750 := by
  intro p hp
  have h : env50750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50749_50750 : H12AffineEnvironment.transform 13 5377 env50749 = env50750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50749 == env50750) = true)

theorem identity50750 : scanCanonicalize (H12AffineFastState.compose env50750 (packedSelected [0,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound50750 : packedSelected [0,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env50751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7465,5377,292,7539,5172,2128,1025,293,3345,7537,17,82,7465,64,2048,5392,3408,2128,6149,32,257,32,2048,7936]

theorem envBound50751 : H12AffineFastState.Bounded env50751 := by
  intro p hp
  have h : env50751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50750_50751 : H12AffineEnvironment.transform 12 7465 env50750 = env50751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env50750 == env50751) = true)

theorem identity50751 : scanCanonicalize (H12AffineFastState.compose env50751 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50751 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env50752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,5416,5377,292,5490,5172,81,1025,293,1296,5488,17,82,5416,64,1,5392,1361,81,4100,32,257,32,1,5889]

theorem envBound50752 : H12AffineFastState.Bounded env50752 := by
  intro p hp
  have h : env50752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50751_50752 : H12AffineEnvironment.transform 10 1 env50751 = env50752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50751 == env50752) = true)

theorem identity50752 : scanCanonicalize (H12AffineFastState.compose env50752 (packedSelected [2,3,4,5,6,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound50752 : packedSelected [2,3,4,5,6,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env50753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1281,41,0,292,115,309,81,1025,293,1296,113,17,82,41,64,1,17,1361,81,1285,32,257,32,1,512]

theorem envBound50753 : H12AffineFastState.Bounded env50753 := by
  intro p hp
  have h : env50753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50752_50753 : H12AffineEnvironment.transform 11 1281 env50752 = env50753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env50752 == env50753) = true)

theorem identity50753 : scanCanonicalize (H12AffineFastState.compose env50753 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50753 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env50754 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,1281,41,0,292,35,309,1,1025,293,1296,33,17,2,41,16,1,17,1281,1,1285,32,257,32,1,512]

theorem envBound50754 : H12AffineFastState.Bounded env50754 := by
  intro p hp
  have h : env50754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50753_50754 : H12AffineEnvironment.transform 5 16 env50753 = env50754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50753 == env50754) = true)

theorem identity50754 : scanCanonicalize (H12AffineFastState.compose env50754 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50754 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50755 : List Nat := [2,4,8,16,0,16,8,256,512,1024,1,1281,9,0,260,3,277,1,1025,261,1296,1,17,2,9,16,1,17,1281,1,1285,0,257,0,1,512]

theorem envBound50755 : H12AffineFastState.Bounded env50755 := by
  intro p hp
  have h : env50755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50754_50755 : H12AffineEnvironment.transform 4 0 env50754 = env50755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50754 == env50755) = true)

theorem identity50755 : scanCanonicalize (H12AffineFastState.compose env50755 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50755 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50756 : List Nat := [2,4,8,16,0,16,8,256,512,272,1,17,9,0,260,3,277,1,273,261,0,1,17,2,9,16,1,17,17,1,21,0,257,0,1,512]

theorem envBound50756 : H12AffineFastState.Bounded env50756 := by
  intro p hp
  have h : env50756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50755_50756 : H12AffineEnvironment.transform 9 272 env50755 = env50756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50755 == env50756) = true)

def env50757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272392,16,95497,8192,64,2048,5393,45405,283905,61704,318548,257,21793,46093,120407]

theorem envBound50757 : H12AffineFastState.Bounded env50757 := by
  intro p hp
  have h : env50757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50745_50757 : H12AffineEnvironment.transform 16 38161 env50745 = env50757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env50745 == env50757) = true)

theorem identity50757 : scanCanonicalize (H12AffineFastState.compose env50757 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50757 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13388,262144,1025,8540,17729,272392,16,95497,8192,64,2048,5393,4096,283905,20565,294153,257,21793,5456,96010]

theorem envBound50758 : H12AffineFastState.Bounded env50758 := by
  intro p hp
  have h : env50758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50757_50758 : H12AffineEnvironment.transform 14 8541 env50757 = env50758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50757 == env50758) = true)

theorem identity50758 : scanCanonicalize (H12AffineFastState.compose env50758 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound50758 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env50759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13388,89379,1025,8540,17729,95531,16,95497,8192,64,2048,5393,4096,67618,20565,73770,257,21793,5456,96010]

theorem envBound50759 : H12AffineFastState.Bounded env50759 := by
  intro p hp
  have h : env50759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50758_50759 : H12AffineEnvironment.transform 17 89379 env50758 = env50759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env50758 == env50759) = true)

theorem identity50759 : scanCanonicalize (H12AffineFastState.compose env50759 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 28747) := by decide +kernel

theorem selectedBound50759 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env50760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28747,13388,11624,1025,8540,17729,1376,16,1346,8192,64,2048,5393,4096,30825,20565,20577,257,21793,5456,1857]

theorem envBound50760 : H12AffineFastState.Bounded env50760 := by
  intro p hp
  have h : env50760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50759_50760 : H12AffineEnvironment.transform 15 28747 env50759 = env50760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28747 env50759 == env50760) = true)

theorem identity50760 : scanCanonicalize (H12AffineFastState.compose env50760 (packedSelected [0,3,5,7,11,12,14,19] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound50760 : packedSelected [0,3,5,7,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env50761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,8192,16384,8541,26927,11560,11624,1025,8540,17729,1376,16,1346,8192,64,2048,3189,2404,24845,18737,18693,257,19525,3124,1857]

theorem envBound50761 : H12AffineFastState.Bounded env50761 := by
  intro p hp
  have h : env50761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50760_50761 : H12AffineEnvironment.transform 11 2404 env50760 = env50761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env50760 == env50761) = true)

theorem identity50761 : scanCanonicalize (H12AffineFastState.compose env50761 (packedSelected [1,4,8,9,10,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 8313) := by decide +kernel

theorem selectedBound50761 : packedSelected [1,4,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,8192,8313,8541,2390,11560,11624,1025,8540,9528,1376,16,1346,8192,64,2048,3189,2404,372,10568,10620,257,11324,3124,1857]

theorem envBound50762 : H12AffineFastState.Bounded env50762 := by
  intro p hp
  have h : env50762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50761_50762 : H12AffineEnvironment.transform 13 8313 env50761 = env50762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8313 env50761 == env50762) = true)

theorem identity50762 : scanCanonicalize (H12AffineFastState.compose env50762 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,23] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound50762 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,23] rootPS < 2^1333 := by decide +kernel

def env50763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,308,8192,8313,8541,262,9592,9528,1025,8540,9528,1376,16,1346,8192,64,80,1061,308,372,8472,8492,257,9324,1124,1857]

theorem envBound50763 : H12AffineFastState.Bounded env50763 := by
  intro p hp
  have h : env50763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50762_50763 : H12AffineEnvironment.transform 10 80 env50762 = env50763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env50762 == env50763) = true)

theorem identity50763 : scanCanonicalize (H12AffineFastState.compose env50763 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50763 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env50764 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,64,8192,8313,8233,114,9228,9292,1025,8232,9292,1044,16,1078,8192,64,80,1061,64,0,8300,8280,117,9324,1124,1589]

theorem envBound50764 : H12AffineFastState.Bounded env50764 := by
  intro p hp
  have h : env50764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50763_50764 : H12AffineEnvironment.transform 7 116 env50763 = env50764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50763 == env50764) = true)

theorem identity50764 : scanCanonicalize (H12AffineFastState.compose env50764 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50764 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50765 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,17,8192,8232,8233,35,9228,9245,1025,8232,9245,1044,16,1078,8192,17,1,1061,17,0,8253,8201,36,9277,1077,1589]

theorem envBound50765 : H12AffineFastState.Bounded env50765 := by
  intro p hp
  have h : env50765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50764_50765 : H12AffineEnvironment.transform 5 17 env50764 = env50765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50764 == env50765) = true)

theorem identity50765 : scanCanonicalize (H12AffineFastState.compose env50765 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50765 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50766 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,8192,8232,8233,35,8248,8233,53,8232,8233,32,16,2,8192,17,1,17,17,0,8253,8201,36,8201,1,513]

theorem envBound50766 : H12AffineFastState.Bounded env50766 := by
  intro p hp
  have h : env50766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50765_50766 : H12AffineEnvironment.transform 9 52 env50765 = env50766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50765 == env50766) = true)

theorem identity50766 : scanCanonicalize (H12AffineFastState.compose env50766 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50766 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50767 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,0,1,35,16,1,53,0,1,32,16,2,40,17,1,17,17,0,21,33,36,33,1,513]

theorem envBound50767 : H12AffineFastState.Bounded env50767 := by
  intro p hp
  have h : env50767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50766_50767 : H12AffineEnvironment.transform 12 40 env50766 = env50767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50766 == env50767) = true)

theorem identity50767 : scanCanonicalize (H12AffineFastState.compose env50767 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound50767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50768 : List Nat := [2,4,8,16,21,17,8,16,512,1,1,17,29,0,1,22,16,1,0,0,1,21,16,2,29,17,1,17,17,0,21,20,17,20,1,513]

theorem envBound50768 : H12AffineFastState.Bounded env50768 := by
  intro p hp
  have h : env50768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50767_50768 : H12AffineEnvironment.transform 4 21 env50767 = env50768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env50767 == env50768) = true)

theorem identity50768 : scanCanonicalize (H12AffineFastState.compose env50768 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound50768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50769 : List Nat := [2,4,8,8,13,9,8,8,512,1,1,9,5,0,1,14,8,1,0,0,1,13,8,2,5,9,1,9,9,0,13,12,9,12,1,513]

theorem envBound50769 : H12AffineFastState.Bounded env50769 := by
  intro p hp
  have h : env50769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50768_50769 : H12AffineEnvironment.transform 3 8 env50768 = env50769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env50768 == env50769) = true)

theorem identity50769 : scanCanonicalize (H12AffineFastState.compose env50769 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50770 : List Nat := [2,4,4,4,1,5,4,4,512,1,1,5,5,0,1,2,4,1,0,0,1,1,4,2,5,5,1,5,5,0,1,0,5,0,1,513]

theorem envBound50770 : H12AffineFastState.Bounded env50770 := by
  intro p hp
  have h : env50770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50769_50770 : H12AffineEnvironment.transform 2 4 env50769 = env50770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50769 == env50770) = true)

theorem identity50770 : scanCanonicalize (H12AffineFastState.compose env50770 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound50770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50771 : List Nat := [2,4,4,4,1,5,4,4,6,1,1,5,5,0,1,2,4,1,0,0,1,1,4,2,5,5,1,5,5,0,1,0,5,0,1,7]

theorem envBound50771 : H12AffineFastState.Bounded env50771 := by
  intro p hp
  have h : env50771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50770_50771 : H12AffineEnvironment.transform 8 6 env50770 = env50771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env50770 == env50771) = true)

theorem identity50771 : scanCanonicalize (H12AffineFastState.compose env50771 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50771 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50772 : List Nat := [2,3,3,3,1,2,3,3,1,1,1,2,2,0,1,2,3,1,0,0,1,1,3,2,2,2,1,2,2,0,1,0,2,0,1,0]

theorem envBound50772 : H12AffineFastState.Bounded env50772 := by
  intro p hp
  have h : env50772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50771_50772 : H12AffineEnvironment.transform 1 3 env50771 = env50772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50771 == env50772) = true)

theorem identity50772 : scanCanonicalize (H12AffineFastState.compose env50772 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50772 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50773 : List Nat := [1,0,0,0,1,1,0,0,1,1,1,1,1,0,1,1,0,1,0,0,1,1,0,1,1,1,1,1,1,0,1,0,1,0,1,0]

theorem envBound50773 : H12AffineFastState.Bounded env50773 := by
  intro p hp
  have h : env50773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50772_50773 : H12AffineEnvironment.transform 0 1 env50772 = env50773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50772 == env50773) = true)

def env50774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169217,95497,8193,64,2049,163840,45404,283905,156697,411972,257,21793,46092,213831]

theorem envBound50774 : H12AffineFastState.Bounded env50774 := by
  intro p hp
  have h : env50774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50744_50774 : H12AffineEnvironment.transform 6 9 env50744 = env50774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50744 == env50774) = true)

def env50775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95497,8193,64,2049,5392,45404,283905,61705,318548,257,21793,46092,120407]

theorem envBound50775 : H12AffineFastState.Bounded env50775 := by
  intro p hp
  have h : env50775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50774_50775 : H12AffineEnvironment.transform 16 38160 env50774 = env50775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env50774 == env50775) = true)

theorem identity50775 : scanCanonicalize (H12AffineFastState.compose env50775 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50775 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58396,33,17,95497,8193,64,2049,5392,45404,32041,61705,62588,257,21793,46092,120407]

theorem envBound50776 : H12AffineFastState.Bounded env50776 := by
  intro p hp
  have h : env50776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50775_50776 : H12AffineEnvironment.transform 17 10280 env50775 = env50776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50775 == env50776) = true)

theorem identity50776 : scanCanonicalize (H12AffineFastState.compose env50776 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50776 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,38160,2421,1025,32769,50497,33,17,87124,348,64,2049,5392,36865,23668,53332,54561,257,21793,38225,120407]

theorem envBound50777 : H12AffineFastState.Bounded env50777 := by
  intro p hp
  have h : env50777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50776_50777 : H12AffineEnvironment.transform 12 349 env50776 = env50777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50776 == env50777) = true)

theorem identity50777 : scanCanonicalize (H12AffineFastState.compose env50777 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50777 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env50778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,65536,38160,2421,1025,32769,36928,33,17,65877,348,64,2049,5392,36865,2421,34133,32800,257,32,38225,99158]

theorem envBound50778 : H12AffineFastState.Bounded env50778 := by
  intro p hp
  have h : env50778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50777_50778 : H12AffineEnvironment.transform 13 5377 env50777 = env50778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50777 == env50778) = true)

theorem identity50778 : scanCanonicalize (H12AffineFastState.compose env50778 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound50778 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,81,65536,5441,2421,1025,80,4113,33,17,65877,348,64,2049,5392,4176,2421,1284,113,257,32,5376,66311]

theorem envBound50779 : H12AffineFastState.Bounded env50779 := by
  intro p hp
  have h : env50779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50778_50779 : H12AffineEnvironment.transform 14 81 env50778 = env50779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env50778 == env50779) = true)

theorem identity50779 : scanCanonicalize (H12AffineFastState.compose env50779 (packedSelected [1,8,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound50779 : packedSelected [1,8,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1328,4096,349,5377,81,65536,5441,1093,1025,80,4113,33,17,65877,348,64,1329,5392,4176,1093,1284,113,257,32,5376,66311]

theorem envBound50780 : H12AffineFastState.Bounded env50780 := by
  intro p hp
  have h : env50780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50779_50780 : H12AffineEnvironment.transform 10 1328 env50779 = env50780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env50779 == env50780) = true)

def env50781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,16,95497,8193,64,2049,5393,45404,283905,61704,318549,257,21793,46092,120406]

theorem envBound50781 : H12AffineFastState.Bounded env50781 := by
  intro p hp
  have h : env50781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50774_50781 : H12AffineEnvironment.transform 16 38161 env50774 = env50781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env50774 == env50781) = true)

def env50782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,12573,272393,16,95497,8193,64,2049,5393,25692,283905,9224,264533,257,21793,24844,66390]

theorem envBound50782 : H12AffineFastState.Bounded env50782 := by
  intro p hp
  have h : env50782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50781_50782 : H12AffineEnvironment.transform 14 21760 env50781 = env50782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env50781 == env50782) = true)

theorem identity50782 : scanCanonicalize (H12AffineFastState.compose env50782 (packedSelected [1,4,8,9,12,14,16,19,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound50782 : packedSelected [1,4,8,9,12,14,16,19,38] rootPS < 2^1333 := by decide +kernel

def env50783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,32041,1025,21761,12573,21792,16,95497,8193,64,2049,5393,25692,10280,9224,29820,257,21793,24844,66390]

theorem envBound50783 : H12AffineFastState.Bounded env50783 := by
  intro p hp
  have h : env50783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50782_50783 : H12AffineEnvironment.transform 17 32041 env50782 = env50783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env50782 == env50783) = true)

theorem identity50783 : scanCanonicalize (H12AffineFastState.compose env50783 (packedSelected [4,5,9,12,14,15,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound50783 : packedSelected [4,5,9,12,14,15,16,24,26] rootPS < 2^1333 := by decide +kernel

def env50784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8282,16401,32041,1025,21761,12573,21792,16,21843,8193,64,2049,5393,25692,10280,9224,29820,257,21793,24844,8972]

theorem envBound50784 : H12AffineFastState.Bounded env50784 := by
  intro p hp
  have h : env50784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50783_50784 : H12AffineEnvironment.transform 15 8282 env50783 = env50784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env50783 == env50784) = true)

theorem identity50784 : scanCanonicalize (H12AffineFastState.compose env50784 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50784 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env50785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,8282,13341,2341,1025,8461,12573,8492,16,8543,8193,64,2049,5393,4176,10280,9224,112,257,8493,5376,8972]

theorem envBound50785 : H12AffineFastState.Bounded env50785 := by
  intro p hp
  have h : env50785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50784_50785 : H12AffineEnvironment.transform 13 13324 env50784 = env50785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50784 == env50785) = true)

theorem identity50785 : scanCanonicalize (H12AffineFastState.compose env50785 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50785 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env50786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,342,5393,2341,1025,1,4113,32,16,83,269,64,2049,5393,4176,2340,1284,112,257,33,5376,512]

theorem envBound50786 : H12AffineFastState.Bounded env50786 := by
  intro p hp
  have h : env50786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50785_50786 : H12AffineEnvironment.transform 12 268 env50785 = env50786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50785 == env50786) = true)

theorem identity50786 : scanCanonicalize (H12AffineFastState.compose env50786 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50786 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50787 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5376,0,342,5393,2308,1025,1,4113,1,16,83,269,64,2049,5393,4176,2309,1284,81,257,0,5376,512]

theorem envBound50787 : H12AffineFastState.Bounded env50787 := by
  intro p hp
  have h : env50787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50786_50787 : H12AffineEnvironment.transform 4 1 env50786 = env50787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50786 == env50787) = true)

theorem identity50787 : scanCanonicalize (H12AffineFastState.compose env50787 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50787 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50788 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,4096,268,4112,0,342,4097,2308,273,1,4113,1,16,83,269,64,2049,4097,4176,2309,20,81,257,0,4112,512]

theorem envBound50788 : H12AffineFastState.Bounded env50788 := by
  intro p hp
  have h : env50788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50787_50788 : H12AffineEnvironment.transform 9 272 env50787 = env50788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50787 == env50788) = true)

theorem identity50788 : scanCanonicalize (H12AffineFastState.compose env50788 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound50788 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50789 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,2113,268,2129,0,342,2112,2308,273,1,2128,1,16,83,269,64,2049,2112,2065,2309,20,81,257,0,2129,512]

theorem envBound50789 : H12AffineFastState.Bounded env50789 := by
  intro p hp
  have h : env50789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50788_50789 : H12AffineEnvironment.transform 11 2113 env50788 = env50789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env50788 == env50789) = true)

theorem identity50789 : scanCanonicalize (H12AffineFastState.compose env50789 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50789 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50790 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2065,268,2049,0,262,2064,2308,273,1,2048,1,16,3,269,16,2049,2064,2065,2309,20,1,257,0,2049,512]

theorem envBound50790 : H12AffineFastState.Bounded env50790 := by
  intro p hp
  have h : env50790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50789_50790 : H12AffineEnvironment.transform 5 16 env50789 = env50790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50789 == env50790) = true)

theorem identity50790 : scanCanonicalize (H12AffineFastState.compose env50790 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50791 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,2065,8,2049,0,2,2064,2048,21,1,2048,1,16,3,9,16,2049,2064,2065,2049,20,1,5,0,2049,512]

theorem envBound50791 : H12AffineFastState.Bounded env50791 := by
  intro p hp
  have h : env50791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50790_50791 : H12AffineEnvironment.transform 7 4 env50790 = env50791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50790 == env50791) = true)

def env50792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,12572,272393,16,95497,8193,64,2049,5393,25693,283905,9225,264532,257,21793,24845,66391]

theorem envBound50792 : H12AffineFastState.Bounded env50792 := by
  intro p hp
  have h : env50792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50781_50792 : H12AffineEnvironment.transform 14 21761 env50781 = env50792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env50781 == env50792) = true)

theorem identity50792 : scanCanonicalize (H12AffineFastState.compose env50792 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound50792 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,16400,262144,1025,21760,12572,272393,16,29791,8193,64,2049,5393,25693,283905,9225,264532,257,21793,24845,513]

theorem envBound50793 : H12AffineFastState.Bounded env50793 := by
  intro p hp
  have h : env50793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50792_50793 : H12AffineEnvironment.transform 15 342 env50792 = env50793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env50792 == env50793) = true)

theorem identity50793 : scanCanonicalize (H12AffineFastState.compose env50793 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound50793 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,16400,23668,1025,21760,12572,29821,16,29791,8193,64,2049,5393,25693,2421,9225,21792,257,21793,24845,513]

theorem envBound50794 : H12AffineFastState.Bounded env50794 := by
  intro p hp
  have h : env50794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50793_50794 : H12AffineEnvironment.transform 17 23668 env50793 = env50794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env50793 == env50794) = true)

theorem identity50794 : scanCanonicalize (H12AffineFastState.compose env50794 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50794 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,342,5393,2421,1025,1,12572,8572,16,8542,8193,64,2049,5393,12636,2421,9225,33,257,32,13324,513]

theorem envBound50795 : H12AffineFastState.Bounded env50795 := by
  intro p hp
  have h : env50795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50794_50795 : H12AffineEnvironment.transform 13 5377 env50794 = env50795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50794 == env50795) = true)

theorem identity50795 : scanCanonicalize (H12AffineFastState.compose env50795 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound50795 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env50796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2317,5377,0,342,5393,2421,1025,1,6161,2161,16,2131,2316,64,2049,5393,6225,2421,3332,33,257,32,7425,513]

theorem envBound50796 : H12AffineFastState.Bounded env50796 := by
  intro p hp
  have h : env50796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50795_50796 : H12AffineEnvironment.transform 12 2317 env50795 = env50796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env50795 == env50796) = true)

theorem identity50796 : scanCanonicalize (H12AffineFastState.compose env50796 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50796 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env50797 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2317,5377,0,262,5393,2341,1025,1,6161,2081,16,2051,2316,16,2049,5393,6145,2341,3332,33,257,32,7425,513]

theorem envBound50797 : H12AffineFastState.Bounded env50797 := by
  intro p hp
  have h : env50797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50796_50797 : H12AffineEnvironment.transform 5 16 env50796 = env50797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50796 == env50797) = true)

theorem identity50797 : scanCanonicalize (H12AffineFastState.compose env50797 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50797 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50798 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,4096,269,5377,0,262,5393,293,1025,1,4113,33,16,3,268,16,1,5393,4097,293,1284,33,257,32,5377,513]

theorem envBound50798 : H12AffineFastState.Bounded env50798 := by
  intro p hp
  have h : env50798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50797_50798 : H12AffineEnvironment.transform 10 0 env50797 = env50798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50797 == env50798) = true)

theorem identity50798 : scanCanonicalize (H12AffineFastState.compose env50798 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound50798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50799 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,1028,269,261,0,262,277,293,1025,1,1045,33,16,3,268,16,1,277,1029,293,1284,33,257,32,261,513]

theorem envBound50799 : H12AffineFastState.Bounded env50799 := by
  intro p hp
  have h : env50799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50798_50799 : H12AffineEnvironment.transform 11 1028 env50798 = env50799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env50798 == env50799) = true)

theorem identity50799 : scanCanonicalize (H12AffineFastState.compose env50799 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound50799 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50800 : List Nat := [2,4,8,16,32,16,9,256,43,1024,0,1028,269,261,0,262,277,293,1025,1,1045,33,16,3,268,16,1,277,1029,293,1284,33,257,32,261,42]

theorem envBound50800 : H12AffineFastState.Bounded env50800 := by
  intro p hp
  have h : env50800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50799_50800 : H12AffineEnvironment.transform 8 43 env50799 = env50800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env50799 == env50800) = true)

theorem identity50800 : scanCanonicalize (H12AffineFastState.compose env50800 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound50800 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50801 : List Nat := [2,4,8,16,32,16,9,256,43,314,0,318,269,261,0,262,277,293,315,1,303,33,16,3,268,16,1,277,319,293,62,33,257,32,261,42]

theorem envBound50801 : H12AffineFastState.Bounded env50801 := by
  intro p hp
  have h : env50801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50800_50801 : H12AffineEnvironment.transform 9 314 env50800 = env50801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env50800 == env50801) = true)

theorem identity50801 : scanCanonicalize (H12AffineFastState.compose env50801 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound50801 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50802 : List Nat := [2,4,8,16,32,16,9,62,43,4,0,0,51,59,0,56,43,27,5,1,17,33,16,3,50,16,1,43,1,27,62,33,63,32,59,42]

theorem envBound50802 : H12AffineFastState.Bounded env50802 := by
  intro p hp
  have h : env50802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50801_50802 : H12AffineEnvironment.transform 7 62 env50801 = env50802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env50801 == env50802) = true)

theorem identity50802 : scanCanonicalize (H12AffineFastState.compose env50802 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50802 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env50803 : List Nat := [2,4,8,0,32,0,9,46,43,4,0,0,35,43,0,40,43,11,5,1,1,33,0,3,34,0,1,43,1,11,46,33,47,32,43,42]

theorem envBound50803 : H12AffineFastState.Bounded env50803 := by
  intro p hp
  have h : env50803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50802_50803 : H12AffineEnvironment.transform 3 0 env50802 = env50803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50802 == env50803) = true)

theorem identity50803 : scanCanonicalize (H12AffineFastState.compose env50803 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50804 : List Nat := [2,4,0,0,32,0,1,38,35,4,0,0,35,35,0,32,35,3,5,1,1,33,0,3,34,0,1,35,1,3,38,33,39,32,35,34]

theorem envBound50804 : H12AffineFastState.Bounded env50804 := by
  intro p hp
  have h : env50804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50803_50804 : H12AffineEnvironment.transform 2 0 env50803 = env50804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50803 == env50804) = true)

theorem identity50804 : scanCanonicalize (H12AffineFastState.compose env50804 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50804 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env50805 : List Nat := [2,4,0,0,0,0,1,6,3,4,0,0,3,3,0,0,3,3,5,1,1,1,0,3,2,0,1,3,1,3,6,1,7,0,3,2]

theorem envBound50805 : H12AffineFastState.Bounded env50805 := by
  intro p hp
  have h : env50805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50804_50805 : H12AffineEnvironment.transform 4 0 env50804 = env50805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50804 == env50805) = true)

theorem identity50805 : scanCanonicalize (H12AffineFastState.compose env50805 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50806 : List Nat := [2,2,0,0,0,0,1,0,3,2,0,0,3,3,0,0,3,3,3,1,1,1,0,3,2,0,1,3,1,3,0,1,1,0,3,2]

theorem envBound50806 : H12AffineFastState.Bounded env50806 := by
  intro p hp
  have h : env50806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50805_50806 : H12AffineEnvironment.transform 1 2 env50805 = env50806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50805 == env50806) = true)

def env50807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169217,95497,8328,64,2185,163840,45525,283905,156697,412108,257,21793,46213,213966]

theorem envBound50807 : H12AffineFastState.Bounded env50807 := by
  intro p hp
  have h : env50807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50743_50807 : H12AffineEnvironment.transform 21 272513 env50743 = env50807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50743 == env50807) = true)

theorem identity50807 : scanCanonicalize (H12AffineFastState.compose env50807 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound50807 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58517,272513,17,95497,8328,64,2185,5392,45525,283905,61705,318684,257,21793,46213,120542]

theorem envBound50808 : H12AffineFastState.Bounded env50808 := by
  intro p hp
  have h : env50808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50807_50808 : H12AffineEnvironment.transform 16 38160 env50807 = env50808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env50807 == env50808) = true)

def env50809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272393,17,95497,8192,64,2049,5392,45405,283905,61705,318548,257,21793,46093,120406]

theorem envBound50809 : H12AffineFastState.Bounded env50809 := by
  intro p hp
  have h : env50809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50808_50809 : H12AffineEnvironment.transform 6 8 env50808 = env50809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50808 == env50809) = true)

theorem identity50809 : scanCanonicalize (H12AffineFastState.compose env50809 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound50809 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35188,1025,32769,58397,41341,17,95497,8192,64,2049,5392,45405,56437,61705,21792,257,21793,46093,120406]

theorem envBound50810 : H12AffineFastState.Bounded env50810 := by
  intro p hp
  have h : env50810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50809_50810 : H12AffineEnvironment.transform 17 35188 env50809 = env50810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env50809 == env50810) = true)

theorem identity50810 : scanCanonicalize (H12AffineFastState.compose env50810 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound50810 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env50811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,32768,65536,38160,35188,1025,32769,45112,41341,17,74028,8192,64,2049,5392,45405,34896,42284,261,257,260,46093,98931]

theorem envBound50811 : H12AffineFastState.Bounded env50811 := by
  intro p hp
  have h : env50811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50810_50811 : H12AffineEnvironment.transform 13 5157 env50810 = env50811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env50810 == env50811) = true)

theorem identity50811 : scanCanonicalize (H12AffineFastState.compose env50811 (packedSelected [2,3,4,6,10,11,16,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound50811 : packedSelected [2,3,4,6,10,11,16,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env50812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,81,65536,5441,2341,1025,80,12393,8492,17,74028,8192,64,2049,5392,12556,2049,9597,261,257,260,13404,66082]

theorem envBound50812 : H12AffineFastState.Bounded env50812 := by
  intro p hp
  have h : env50812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50811_50812 : H12AffineEnvironment.transform 14 81 env50811 = env50812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env50811 == env50812) = true)

theorem identity50812 : scanCanonicalize (H12AffineFastState.compose env50812 (packedSelected [2,6,9,11,14,16,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound50812 : packedSelected [2,6,9,11,14,16,20,22,23] rootPS < 2^1333 := by decide +kernel

def env50813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,81,343,5441,2341,1025,80,12393,8492,17,8315,8192,64,2049,5392,12556,2049,9597,261,257,260,13404,885]

theorem envBound50813 : H12AffineFastState.Bounded env50813 := by
  intro p hp
  have h : env50813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50812_50813 : H12AffineEnvironment.transform 15 343 env50812 = env50813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env50812 == env50813) = true)

theorem identity50813 : scanCanonicalize (H12AffineFastState.compose env50813 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound50813 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env50814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5157,81,343,5441,2341,1025,80,5377,1092,17,1299,1384,64,2049,5392,5220,2049,21,261,257,260,4404,885]

theorem envBound50814 : H12AffineFastState.Bounded env50814 := by
  intro p hp
  have h : env50814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50813_50814 : H12AffineEnvironment.transform 12 1384 env50813 = env50814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env50813 == env50814) = true)

theorem identity50814 : scanCanonicalize (H12AffineFastState.compose env50814 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50814 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env50815 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5157,81,115,5221,2049,1025,80,5157,1092,17,1079,1100,64,2049,5172,5220,2049,21,33,37,32,4112,593]

theorem envBound50815 : H12AffineFastState.Bounded env50815 := by
  intro p hp
  have h : env50815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50814_50815 : H12AffineEnvironment.transform 7 36 env50814 = env50815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50814 == env50815) = true)

theorem identity50815 : scanCanonicalize (H12AffineFastState.compose env50815 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50815 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env50816 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,120,4113,81,115,4177,2049,53,80,4113,112,17,3,120,64,2049,4096,4176,2049,21,33,37,32,4112,593]

theorem envBound50816 : H12AffineFastState.Bounded env50816 := by
  intro p hp
  have h : env50816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50815_50816 : H12AffineEnvironment.transform 9 52 env50815 = env50816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50815 == env50816) = true)

theorem identity50816 : scanCanonicalize (H12AffineFastState.compose env50816 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound50816 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50817 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,2059,120,2074,81,115,2138,2049,53,80,2074,112,17,3,120,64,2049,2059,2139,2049,21,33,37,32,2075,593]

theorem envBound50817 : H12AffineFastState.Bounded env50817 := by
  intro p hp
  have h : env50817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50816_50817 : H12AffineEnvironment.transform 11 2059 env50816 = env50817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env50816 == env50817) = true)

theorem identity50817 : scanCanonicalize (H12AffineFastState.compose env50817 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50817 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50818 : List Nat := [2,4,8,16,32,0,8,36,512,52,2048,2059,56,2074,17,51,2074,2049,53,16,2074,48,17,3,56,0,2049,2059,2075,2049,21,33,37,32,2075,529]

theorem envBound50818 : H12AffineFastState.Bounded env50818 := by
  intro p hp
  have h : env50818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50817_50818 : H12AffineEnvironment.transform 5 0 env50817 = env50818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50817 == env50818) = true)

theorem identity50818 : scanCanonicalize (H12AffineFastState.compose env50818 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound50818 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50819 : List Nat := [2,4,8,16,32,0,8,36,512,52,15,4,56,21,17,51,21,14,53,16,21,48,17,3,56,0,14,4,20,14,21,33,37,32,20,529]

theorem envBound50819 : H12AffineFastState.Bounded env50819 := by
  intro p hp
  have h : env50819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50818_50819 : H12AffineEnvironment.transform 10 15 env50818 = env50819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env50818 == env50819) = true)

theorem identity50819 : scanCanonicalize (H12AffineFastState.compose env50819 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound50819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50820 : List Nat := [2,4,8,16,32,0,8,36,61,52,15,4,56,21,17,51,21,14,53,16,21,48,17,3,56,0,14,4,20,14,21,33,37,32,20,44]

theorem envBound50820 : H12AffineFastState.Bounded env50820 := by
  intro p hp
  have h : env50820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50819_50820 : H12AffineEnvironment.transform 8 61 env50819 = env50820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env50819 == env50820) = true)

theorem identity50820 : scanCanonicalize (H12AffineFastState.compose env50820 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50820 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50821 : List Nat := [2,4,3,16,32,0,3,36,54,52,4,4,51,21,17,51,21,5,53,16,21,48,17,3,51,0,5,4,20,5,21,33,37,32,20,39]

theorem envBound50821 : H12AffineFastState.Bounded env50821 := by
  intro p hp
  have h : env50821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50820_50821 : H12AffineEnvironment.transform 2 3 env50820 = env50821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50820 == env50821) = true)

theorem identity50821 : scanCanonicalize (H12AffineFastState.compose env50821 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50821 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env50822 : List Nat := [2,4,3,1,32,0,3,36,39,37,4,4,34,4,0,34,4,5,36,1,4,33,0,3,34,0,5,4,5,5,4,33,37,32,5,39]

theorem envBound50822 : H12AffineFastState.Bounded env50822 := by
  intro p hp
  have h : env50822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50821_50822 : H12AffineEnvironment.transform 3 1 env50821 = env50822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50821 == env50822) = true)

theorem identity50822 : scanCanonicalize (H12AffineFastState.compose env50822 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50823 : List Nat := [2,4,3,1,1,0,3,5,6,4,4,4,3,4,0,3,4,5,5,1,4,0,0,3,3,0,5,4,5,5,4,0,4,1,5,6]

theorem envBound50823 : H12AffineFastState.Bounded env50823 := by
  intro p hp
  have h : env50823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50822_50823 : H12AffineEnvironment.transform 4 1 env50822 = env50823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50822 == env50823) = true)

theorem identity50823 : scanCanonicalize (H12AffineFastState.compose env50823 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50823 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50824 : List Nat := [2,0,3,1,1,0,3,1,2,0,0,0,3,0,0,3,0,1,1,1,0,0,0,3,3,0,1,0,1,1,0,0,0,1,1,2]

theorem envBound50824 : H12AffineFastState.Bounded env50824 := by
  intro p hp
  have h : env50824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50823_50824 : H12AffineEnvironment.transform 1 0 env50823 = env50824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50823 == env50824) = true)

def env50825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95497,8193,64,2048,5392,45404,283905,61705,318549,257,21793,46092,120407]

theorem envBound50825 : H12AffineFastState.Bounded env50825 := by
  intro p hp
  have h : env50825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50808_50825 : H12AffineEnvironment.transform 6 9 env50808 = env50825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50808 == env50825) = true)

theorem identity50825 : scanCanonicalize (H12AffineFastState.compose env50825 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58396,32,17,95497,8193,64,2048,5392,45404,32041,61705,62589,257,21793,46092,120407]

theorem envBound50826 : H12AffineFastState.Bounded env50826 := by
  intro p hp
  have h : env50826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50825_50826 : H12AffineEnvironment.transform 17 10280 env50825 = env50826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50825 == env50826) = true)

theorem identity50826 : scanCanonicalize (H12AffineFastState.compose env50826 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound50826 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,38160,10280,1025,32769,58396,32,17,8543,8193,64,2048,5392,45404,32041,61705,62589,257,21793,46092,33281]

theorem envBound50827 : H12AffineFastState.Bounded env50827 := by
  intro p hp
  have h : env50827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50826_50827 : H12AffineEnvironment.transform 15 21590 env50826 = env50827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env50826 == env50827) = true)

theorem identity50827 : scanCanonicalize (H12AffineFastState.compose env50827 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound50827 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,342,38160,10280,1025,32769,45340,32,17,8543,8193,64,2048,5392,45404,10281,41993,41341,257,33,46092,33281]

theorem envBound50828 : H12AffineFastState.Bounded env50828 := by
  intro p hp
  have h : env50828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50827_50828 : H12AffineEnvironment.transform 13 5376 env50827 = env50828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50827 == env50828) = true)

theorem identity50828 : scanCanonicalize (H12AffineFastState.compose env50828 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50828 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,342,38160,2341,1025,32769,36881,32,17,82,268,64,2048,5392,36945,2340,34052,32880,257,33,38145,33281]

theorem envBound50829 : H12AffineFastState.Bounded env50829 := by
  intro p hp
  have h : env50829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50828_50829 : H12AffineEnvironment.transform 12 269 env50828 = env50829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50828 == env50829) = true)

theorem identity50829 : scanCanonicalize (H12AffineFastState.compose env50829 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound50829 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,342,5441,2341,1025,80,4160,32,17,82,268,64,2048,5392,4096,2340,1365,33,257,33,5456,592]

theorem envBound50830 : H12AffineFastState.Bounded env50830 := by
  intro p hp
  have h : env50830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50829_50830 : H12AffineEnvironment.transform 14 81 env50829 = env50830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env50829 == env50830) = true)

theorem identity50830 : scanCanonicalize (H12AffineFastState.compose env50830 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound50830 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2341,269,3109,81,342,3172,2341,1025,80,2405,32,17,82,268,64,2048,3125,2341,2340,1365,33,257,33,3189,592]

theorem envBound50831 : H12AffineFastState.Bounded env50831 := by
  intro p hp
  have h : env50831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50830_50831 : H12AffineEnvironment.transform 11 2341 env50830 = env50831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env50830 == env50831) = true)

theorem identity50831 : scanCanonicalize (H12AffineFastState.compose env50831 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50831 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50832 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,2080,8,3109,81,83,3172,2080,1025,80,2144,32,17,82,9,64,2048,3125,2080,2081,1104,33,4,33,3189,592]

theorem envBound50832 : H12AffineFastState.Bounded env50832 := by
  intro p hp
  have h : env50832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50831_50832 : H12AffineEnvironment.transform 7 5 env50831 = env50832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50831 == env50832) = true)

theorem identity50832 : scanCanonicalize (H12AffineFastState.compose env50832 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound50832 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50833 : List Nat := [2,4,8,16,32,64,9,5,512,1024,1044,1076,8,49,81,83,112,1076,1025,80,1140,32,17,82,9,64,1044,33,1076,1077,1104,33,4,33,97,592]

theorem envBound50833 : H12AffineFastState.Bounded env50833 := by
  intro p hp
  have h : env50833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50832_50833 : H12AffineEnvironment.transform 10 1044 env50832 = env50833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env50832 == env50833) = true)

theorem identity50833 : scanCanonicalize (H12AffineFastState.compose env50833 (packedSelected [1,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound50833 : packedSelected [1,6,8,11] rootPS < 2^1333 := by decide +kernel

def env50834 : List Nat := [2,4,8,16,32,64,9,5,512,85,65,97,8,49,81,83,112,97,84,80,33,32,17,82,9,64,65,33,97,96,5,33,4,33,97,592]

theorem envBound50834 : H12AffineFastState.Bounded env50834 := by
  intro p hp
  have h : env50834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50833_50834 : H12AffineEnvironment.transform 9 85 env50833 = env50834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env50833 == env50834) = true)

theorem identity50834 : scanCanonicalize (H12AffineFastState.compose env50834 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50835 : List Nat := [2,4,8,0,32,64,9,5,512,69,65,97,8,33,65,67,96,97,68,64,33,32,1,66,9,64,65,33,97,96,5,33,4,33,97,576]

theorem envBound50835 : H12AffineFastState.Bounded env50835 := by
  intro p hp
  have h : env50835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50834_50835 : H12AffineEnvironment.transform 3 0 env50834 = env50835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50834 == env50835) = true)

def env50836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound50836 : H12AffineFastState.Bounded env50836 := by
  intro p hp
  have h : env50836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49937_50836 : H12AffineEnvironment.transform 25 65 env49937 = env50836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env49937 == env50836) = true)

def env50837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound50837 : H12AffineFastState.Bounded env50837 := by
  intro p hp
  have h : env50837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50836_50837 : H12AffineEnvironment.transform 26 30393344 env50836 = env50837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env50836 == env50837) = true)

def env50838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound50838 : H12AffineFastState.Bounded env50838 := by
  intro p hp
  have h : env50838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50837_50838 : H12AffineEnvironment.transform 18 1024 env50837 = env50838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env50837 == env50838) = true)

theorem identity50838 : scanCanonicalize (H12AffineFastState.compose env50838 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534760) := by decide +kernel

theorem selectedBound50838 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,16777216,8328,65,23162216,18973837,456760,2125160,19343736,23160256,256,17263044,17270880,19271343]

theorem envBound50839 : H12AffineFastState.Bounded env50839 := by
  intro p hp
  have h : env50839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50838_50839 : H12AffineEnvironment.transform 22 2534760 env50838 = env50839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534760 env50838 == env50839) = true)

def env50840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,474340,8328,65,6705548,2537577,456760,2125160,2102684,6707492,256,21792,46212,2175563]

theorem envBound50840 : H12AffineFastState.Bounded env50840 := by
  intro p hp
  have h : env50840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50839_50840 : H12AffineEnvironment.transform 23 474340 env50839 = env50840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474340 env50839 == env50840) = true)

def env50841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101328,98780,8328,65,6352052,2098513,17664,2125160,2102684,6349852,256,21792,46212,2175563]

theorem envBound50841 : H12AffineFastState.Bounded env50841 := by
  intro p hp
  have h : env50841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50840_50841 : H12AffineEnvironment.transform 17 179512 env50840 = env50841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env50840 == env50841) = true)

def env50842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98780,8328,65,4259060,5393,17664,32040,1500,4256860,256,21792,46212,74251]

theorem envBound50842 : H12AffineFastState.Bounded env50842 := by
  intro p hp
  have h : env50842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50841_50842 : H12AffineEnvironment.transform 20 4160 env50841 = env50842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50841 == env50842) = true)

theorem identity50842 : scanCanonicalize (H12AffineFastState.compose env50842 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50842 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149996,1024,29909,4160,4194304,16,95496,8328,65,4196384,5393,17664,32040,1500,4194440,256,21792,16464,74251]

theorem envBound50843 : H12AffineFastState.Bounded env50843 := by
  intro p hp
  have h : env50843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50842_50843 : H12AffineEnvironment.transform 14 29908 env50842 = env50843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50842 == env50843) = true)

def env50844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138476,1024,8661,4160,4194304,16,73736,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,74251]

theorem envBound50844 : H12AffineFastState.Bounded env50844 := by
  intro p hp
  have h : env50844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50843_50844 : H12AffineEnvironment.transform 13 5376 env50843 = env50844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50843 == env50844) = true)

theorem identity50844 : scanCanonicalize (H12AffineFastState.compose env50844 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound50844 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,10280,1024,8661,4160,4194304,16,73736,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,74251]

theorem envBound50845 : H12AffineFastState.Bounded env50845 := by
  intro p hp
  have h : env50845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50844_50845 : H12AffineEnvironment.transform 16 13508 env50844 = env50845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env50844 == env50845) = true)

theorem identity50845 : scanCanonicalize (H12AffineFastState.compose env50845 (packedSelected [0,2,4,6,9,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound50845 : packedSelected [0,2,4,6,9,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env50846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,478,13508,10280,1024,8661,4160,4194304,16,8662,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,9173]

theorem envBound50846 : H12AffineFastState.Bounded env50846 := by
  intro p hp
  have h : env50846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50845_50846 : H12AffineEnvironment.transform 15 478 env50845 = env50846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env50845 == env50846) = true)

theorem identity50846 : scanCanonicalize (H12AffineFastState.compose env50846 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50846 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env50847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,343,13389,10280,1024,8540,4160,4194304,16,8543,8193,65,4196384,5393,4096,10280,1365,4194305,256,32,5456,9052]

theorem envBound50847 : H12AffineFastState.Bounded env50847 := by
  intro p hp
  have h : env50847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50846_50847 : H12AffineEnvironment.transform 6 9 env50846 = env50847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50846 == env50847) = true)

theorem identity50847 : scanCanonicalize (H12AffineFastState.compose env50847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4160,4194304,16,2,348,65,4196384,5393,4096,2421,1365,4194305,256,32,5456,513]

theorem envBound50848 : H12AffineFastState.Bounded env50848 := by
  intro p hp
  have h : env50848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50847_50848 : H12AffineEnvironment.transform 12 349 env50847 = env50848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50847 == env50848) = true)

theorem identity50848 : scanCanonicalize (H12AffineFastState.compose env50848 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound50848 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4160,113,16,2,348,65,2129,5393,4096,2421,1365,112,256,32,5456,513]

theorem envBound50849 : H12AffineFastState.Bounded env50849 := by
  intro p hp
  have h : env50849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50848_50849 : H12AffineEnvironment.transform 21 113 env50848 = env50849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env50848 == env50849) = true)

def env50850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138477,1024,8660,4160,4194304,16,73737,8328,65,4196384,5393,4097,10281,1500,4194440,256,33,5457,74251]

theorem envBound50850 : H12AffineFastState.Bounded env50850 := by
  intro p hp
  have h : env50850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50843_50850 : H12AffineEnvironment.transform 13 5377 env50843 = env50850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50843 == env50850) = true)

theorem identity50850 : scanCanonicalize (H12AffineFastState.compose env50850 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound50850 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,10401,1024,8660,4160,4194304,16,73737,8328,65,4196384,5393,4097,10281,1500,4194440,256,33,5457,74251]

theorem envBound50851 : H12AffineFastState.Bounded env50851 := by
  intro p hp
  have h : env50851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50850_50851 : H12AffineEnvironment.transform 16 13388 env50850 = env50851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env50850 == env50851) = true)

theorem identity50851 : scanCanonicalize (H12AffineFastState.compose env50851 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound50851 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,10401,1024,8660,4160,169,16,73737,8328,65,2185,5393,4097,10281,1500,33,256,33,5457,74251]

theorem envBound50852 : H12AffineFastState.Bounded env50852 := by
  intro p hp
  have h : env50852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50851_50852 : H12AffineEnvironment.transform 21 169 env50851 = env50852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env50851 == env50852) = true)

theorem identity50852 : scanCanonicalize (H12AffineFastState.compose env50852 (packedSelected [0,2,3,5,6,10,11,12,14,15,16,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound50852 : packedSelected [0,2,3,5,6,10,11,12,14,15,16,20,23,27] rootPS < 2^1333 := by decide +kernel

def env50853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,13388,10401,1024,8660,4160,169,16,138,8328,65,2185,5393,4097,10281,1500,33,256,33,5457,648]

theorem envBound50853 : H12AffineFastState.Bounded env50853 := by
  intro p hp
  have h : env50853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50852_50853 : H12AffineEnvironment.transform 15 8323 env50852 = env50853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env50852 == env50853) = true)

theorem identity50853 : scanCanonicalize (H12AffineFastState.compose env50853 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound50853 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env50854 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,8192,5340,8200,8323,13388,10401,1024,8201,4160,169,16,138,8328,65,2185,5324,4097,10281,1025,33,221,33,5260,648]

theorem envBound50854 : H12AffineFastState.Bounded env50854 := by
  intro p hp
  have h : env50854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50853_50854 : H12AffineEnvironment.transform 7 221 env50853 = env50854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env50853 == env50854) = true)

theorem identity50854 : scanCanonicalize (H12AffineFastState.compose env50854 (packedSelected [3,4,5,6,9,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound50854 : packedSelected [3,4,5,6,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50855 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5340,137,2,5325,2080,1024,136,4160,169,16,138,9,65,2185,5324,4097,2216,1025,33,221,33,5260,648]

theorem envBound50855 : H12AffineFastState.Bounded env50855 := by
  intro p hp
  have h : env50855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50854_50855 : H12AffineEnvironment.transform 12 129 env50854 = env50855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env50854 == env50855) = true)

theorem identity50855 : scanCanonicalize (H12AffineFastState.compose env50855 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50855 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50856 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5205,0,2,5188,2080,1024,1,4160,32,16,3,9,65,2048,5189,4097,2081,1025,33,84,33,5125,513]

theorem envBound50856 : H12AffineFastState.Bounded env50856 := by
  intro p hp
  have h : env50856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50855_50856 : H12AffineEnvironment.transform 6 9 env50855 = env50856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50855 == env50856) = true)

theorem identity50856 : scanCanonicalize (H12AffineFastState.compose env50856 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1621) := by decide +kernel

theorem selectedBound50856 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50857 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,1621,8,512,0,2,529,2080,1024,1,1557,32,16,3,9,65,2048,528,1620,2081,1025,33,84,33,592,513]

theorem envBound50857 : H12AffineFastState.Bounded env50857 := by
  intro p hp
  have h : env50857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50856_50857 : H12AffineEnvironment.transform 11 1621 env50856 = env50857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1621 env50856 == env50857) = true)

theorem identity50857 : scanCanonicalize (H12AffineFastState.compose env50857 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50857 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50858 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,1540,8,512,0,2,529,2080,1024,1,1557,32,16,3,9,16,2048,528,1541,2081,1025,33,5,33,513,513]

theorem envBound50858 : H12AffineFastState.Bounded env50858 := by
  intro p hp
  have h : env50858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50857_50858 : H12AffineEnvironment.transform 5 17 env50857 = env50858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50857 == env50858) = true)

theorem identity50858 : scanCanonicalize (H12AffineFastState.compose env50858 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound50858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50859 : List Nat := [2,4,8,16,32,17,9,5,512,548,2048,32,8,512,0,2,529,2080,548,1,49,32,16,3,9,16,2048,528,33,2081,549,33,5,33,513,513]

theorem envBound50859 : H12AffineFastState.Bounded env50859 := by
  intro p hp
  have h : env50859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50858_50859 : H12AffineEnvironment.transform 9 548 env50858 = env50859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env50858 == env50859) = true)

theorem identity50859 : scanCanonicalize (H12AffineFastState.compose env50859 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50859 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50860 : List Nat := [2,4,8,16,32,17,9,5,512,548,0,32,8,512,0,2,529,32,548,1,49,32,16,3,9,16,0,528,33,33,549,33,5,33,513,513]

theorem envBound50860 : H12AffineFastState.Bounded env50860 := by
  intro p hp
  have h : env50860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50859_50860 : H12AffineEnvironment.transform 10 0 env50859 = env50860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50859 == env50860) = true)

theorem identity50860 : scanCanonicalize (H12AffineFastState.compose env50860 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50860 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50861 : List Nat := [2,4,8,16,32,17,9,5,16,52,0,32,8,16,0,2,1,32,52,1,49,32,16,3,9,16,0,0,33,33,53,33,5,33,17,17]

theorem envBound50861 : H12AffineFastState.Bounded env50861 := by
  intro p hp
  have h : env50861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50860_50861 : H12AffineEnvironment.transform 8 16 env50860 = env50861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50860 == env50861) = true)

theorem identity50861 : scanCanonicalize (H12AffineFastState.compose env50861 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50862 : List Nat := [2,4,8,0,32,1,9,5,0,36,0,32,8,0,0,2,1,32,36,1,33,32,0,3,9,0,0,0,33,33,37,33,5,33,1,1]

theorem envBound50862 : H12AffineFastState.Bounded env50862 := by
  intro p hp
  have h : env50862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50861_50862 : H12AffineEnvironment.transform 3 0 env50861 = env50862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50861 == env50862) = true)

def env50863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,17,98780,8328,65,4259061,5392,17664,32041,1501,4256861,256,21792,46212,74250]

theorem envBound50863 : H12AffineFastState.Bounded env50863 := by
  intro p hp
  have h : env50863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50841_50863 : H12AffineEnvironment.transform 20 4161 env50841 = env50863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50841 == env50863) = true)

theorem identity50863 : scanCanonicalize (H12AffineFastState.compose env50863 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound50863 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,17,98780,8328,65,171417,5392,17664,32041,1501,169265,256,21792,46212,74250]

theorem envBound50864 : H12AffineFastState.Bounded env50864 := by
  intro p hp
  have h : env50864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50863_50864 : H12AffineEnvironment.transform 21 156012 env50863 = env50864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env50863 == env50864) = true)

def env50865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,17,98644,8192,65,171281,5392,17664,32041,1365,169265,256,21792,46092,74250]

theorem envBound50865 : H12AffineFastState.Bounded env50865 := by
  intro p hp
  have h : env50865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50864_50865 : H12AffineEnvironment.transform 6 8 env50864 = env50865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50864 == env50865) = true)

theorem identity50865 : scanCanonicalize (H12AffineFastState.compose env50865 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50865 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138341,1024,8540,4161,156012,17,73737,8192,65,146508,5392,17664,32041,1365,144492,256,21792,5457,74250]

theorem envBound50866 : H12AffineFastState.Bounded env50866 := by
  intro p hp
  have h : env50866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50865_50866 : H12AffineEnvironment.transform 14 8541 env50865 = env50866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50865 == env50866) = true)

theorem identity50866 : scanCanonicalize (H12AffineFastState.compose env50866 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound50866 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env50867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,82198,89459,1024,8540,4161,73850,17,73737,8192,65,97626,5392,17664,32041,1365,95610,256,21792,5457,74250]

theorem envBound50867 : H12AffineFastState.Bounded env50867 := by
  intro p hp
  have h : env50867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50866_50867 : H12AffineEnvironment.transform 16 82198 env50866 = env50867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env50866 == env50867) = true)

theorem identity50867 : scanCanonicalize (H12AffineFastState.compose env50867 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound50867 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env50868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30042,13388,10281,1024,8540,4161,21792,17,21843,8192,65,2048,5392,17664,32041,1365,32,256,21792,5457,22352]

theorem envBound50868 : H12AffineFastState.Bounded env50868 := by
  intro p hp
  have h : env50868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50867_50868 : H12AffineEnvironment.transform 15 30042 env50867 = env50868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env50867 == env50868) = true)

theorem identity50868 : scanCanonicalize (H12AffineFastState.compose env50868 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound50868 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env50869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,8541,9499,13388,10281,1024,8540,4161,1377,17,1298,8192,65,2048,5392,5441,11624,1365,32,256,1377,5457,1809]

theorem envBound50869 : H12AffineFastState.Bounded env50869 := by
  intro p hp
  have h : env50869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50868_50869 : H12AffineEnvironment.transform 13 4161 env50868 = env50869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env50868 == env50869) = true)

theorem identity50869 : scanCanonicalize (H12AffineFastState.compose env50869 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50869 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env50870 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4161,8233,9327,13388,10281,1024,8232,4161,1045,17,1126,8192,65,2048,5220,5173,11292,1057,32,116,1045,5157,1637]

theorem envBound50870 : H12AffineFastState.Bounded env50870 := by
  intro p hp
  have h : env50870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50869_50870 : H12AffineEnvironment.transform 7 116 env50869 = env50870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50869 == env50870) = true)

theorem identity50870 : scanCanonicalize (H12AffineFastState.compose env50870 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50870 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env50871 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,4161,81,1047,5172,2129,1024,80,4161,1045,17,1126,120,65,2048,5220,5173,3172,1057,32,116,1045,5157,1637]

theorem envBound50871 : H12AffineFastState.Bounded env50871 := by
  intro p hp
  have h : env50871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50870_50871 : H12AffineEnvironment.transform 12 120 env50870 = env50871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50870 == env50871) = true)

theorem identity50871 : scanCanonicalize (H12AffineFastState.compose env50871 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50871 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50872 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,120,4161,81,114,4177,2129,101,80,4161,112,17,3,120,65,2048,4097,4176,2049,68,32,116,112,4160,512]

theorem envBound50872 : H12AffineFastState.Bounded env50872 := by
  intro p hp
  have h : env50872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50871_50872 : H12AffineEnvironment.transform 9 101 env50871 = env50872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50871 == env50872) = true)

theorem identity50872 : scanCanonicalize (H12AffineFastState.compose env50872 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50873 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,4096,88,4161,81,82,4177,2129,69,80,4161,80,17,3,88,65,2048,4097,4176,2049,68,0,84,80,4160,512]

theorem envBound50873 : H12AffineFastState.Bounded env50873 := by
  intro p hp
  have h : env50873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50872_50873 : H12AffineEnvironment.transform 4 0 env50872 = env50873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50872 == env50873) = true)

def env50874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,17,98645,8193,65,171280,5392,17664,32041,1364,169265,256,21792,46093,74250]

theorem envBound50874 : H12AffineFastState.Bounded env50874 := by
  intro p hp
  have h : env50874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50864_50874 : H12AffineEnvironment.transform 6 9 env50864 = env50874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50864 == env50874) = true)

theorem identity50874 : scanCanonicalize (H12AffineFastState.compose env50874 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound50874 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env50875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,179512,1024,32769,4161,156012,17,62558,8193,65,171280,5392,17664,32041,1364,169265,256,21792,46093,22273]

theorem envBound50875 : H12AffineFastState.Bounded env50875 := by
  intro p hp
  have h : env50875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50874_50875 : H12AffineEnvironment.transform 15 29963 env50874 = env50875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env50874 == env50875) = true)

theorem identity50875 : scanCanonicalize (H12AffineFastState.compose env50875 (packedSelected [1,16,19,20,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50875 : packedSelected [1,16,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env50876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21590,131072,171109,1024,32769,4161,147505,17,54531,348,65,171280,5392,17664,23668,1364,169265,256,21792,38224,22273]

theorem envBound50876 : H12AffineFastState.Bounded env50876 := by
  intro p hp
  have h : env50876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50875_50876 : H12AffineEnvironment.transform 12 349 env50875 = env50876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50875 == env50876) = true)

theorem identity50876 : scanCanonicalize (H12AffineFastState.compose env50876 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound50876 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env50877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,131072,149860,1024,21760,4161,147505,17,2,348,65,149521,5392,17664,23668,1364,147504,256,21792,16465,22273]

theorem envBound50877 : H12AffineFastState.Bounded env50877 := by
  intro p hp
  have h : env50877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50876_50877 : H12AffineEnvironment.transform 14 21761 env50876 = env50877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env50876 == env50877) = true)

theorem identity50877 : scanCanonicalize (H12AffineFastState.compose env50877 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound50877 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env50878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,263,131072,138293,1024,81,4161,136544,17,2,348,65,138560,5392,4177,2341,1364,136545,256,113,5376,592]

theorem envBound50878 : H12AffineFastState.Bounded env50878 := by
  intro p hp
  have h : env50878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50877_50878 : H12AffineEnvironment.transform 13 5457 env50877 = env50878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env50877 == env50878) = true)

theorem identity50878 : scanCanonicalize (H12AffineFastState.compose env50878 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50878 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50879 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,131072,138293,1024,0,4112,136497,17,2,269,16,138513,5392,4096,2341,1285,136496,256,32,5376,513]

theorem envBound50879 : H12AffineFastState.Bounded env50879 := by
  intro p hp
  have h : env50879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50878_50879 : H12AffineEnvironment.transform 5 17 env50878 = env50879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50878 == env50879) = true)

theorem identity50879 : scanCanonicalize (H12AffineFastState.compose env50879 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound50879 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50880 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4112,33,17,2,269,16,2049,5392,4096,2341,1285,32,256,32,5376,513]

theorem envBound50880 : H12AffineFastState.Bounded env50880 := by
  intro p hp
  have h : env50880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50879_50880 : H12AffineEnvironment.transform 16 5392 env50879 = env50880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50879 == env50880) = true)

theorem identity50880 : scanCanonicalize (H12AffineFastState.compose env50880 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound50880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50881 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,56,5172,1,51,5156,2065,1024,0,4112,33,17,2,57,16,2049,5156,4096,2065,1073,32,52,32,5172,513]

theorem envBound50881 : H12AffineFastState.Bounded env50881 := by
  intro p hp
  have h : env50881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50880_50881 : H12AffineEnvironment.transform 7 52 env50880 = env50881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env50880 == env50881) = true)

theorem identity50881 : scanCanonicalize (H12AffineFastState.compose env50881 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound50881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50882 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,1589,56,513,1,51,529,2065,1024,0,1573,33,17,2,57,16,2049,529,1589,2065,1073,32,52,32,513,513]

theorem envBound50882 : H12AffineFastState.Bounded env50882 := by
  intro p hp
  have h : env50882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50881_50882 : H12AffineEnvironment.transform 11 1589 env50881 = env50882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env50881 == env50882) = true)

theorem identity50882 : scanCanonicalize (H12AffineFastState.compose env50882 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50882 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50883 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,1572,41,513,1,34,512,2048,1024,0,1573,33,0,2,40,1,2049,512,1572,2048,1056,32,37,32,513,513]

theorem envBound50883 : H12AffineFastState.Bounded env50883 := by
  intro p hp
  have h : env50883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50882_50883 : H12AffineEnvironment.transform 3 1 env50882 = env50883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50882 == env50883) = true)

theorem identity50883 : scanCanonicalize (H12AffineFastState.compose env50883 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound50883 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50884 : List Nat := [2,4,8,1,32,0,9,37,512,1024,512,1572,41,513,1,34,512,512,1024,0,1573,33,0,2,40,1,513,512,1572,512,1056,32,37,32,513,513]

theorem envBound50884 : H12AffineFastState.Bounded env50884 := by
  intro p hp
  have h : env50884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50883_50884 : H12AffineEnvironment.transform 10 512 env50883 = env50884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env50883 == env50884) = true)

def env50885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101329,98781,8328,65,6352053,2098512,17665,2125160,2102684,6349853,256,21792,46212,2175563]

theorem envBound50885 : H12AffineFastState.Bounded env50885 := by
  intro p hp
  have h : env50885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50840_50885 : H12AffineEnvironment.transform 17 179513 env50840 = env50885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env50840 == env50885) = true)

def env50886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,17,98781,8328,65,4259061,5392,17665,32040,1500,4256861,256,21792,46212,74251]

theorem envBound50886 : H12AffineFastState.Bounded env50886 := by
  intro p hp
  have h : env50886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50885_50886 : H12AffineEnvironment.transform 20 4160 env50885 = env50886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50885 == env50886) = true)

theorem identity50886 : scanCanonicalize (H12AffineFastState.compose env50886 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound50886 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169401,17,98781,8328,65,158028,5392,17665,32040,1500,156132,256,21792,46212,74251]

theorem envBound50887 : H12AffineFastState.Bounded env50887 := by
  intro p hp
  have h : env50887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50886_50887 : H12AffineEnvironment.transform 21 169401 env50886 = env50887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env50886 == env50887) = true)

theorem identity50887 : scanCanonicalize (H12AffineFastState.compose env50887 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50887 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4160,169401,17,41431,8328,65,158028,5392,17665,32040,1500,156132,256,21792,46212,513]

theorem envBound50888 : H12AffineFastState.Bounded env50888 := by
  intro p hp
  have h : env50888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50887_50888 : H12AffineEnvironment.transform 15 8202 env50887 = env50888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50887 == env50888) = true)

theorem identity50888 : scanCanonicalize (H12AffineFastState.compose env50888 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound50888 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,64808,1024,32769,4160,54696,17,41431,8328,65,10589,5392,17665,32040,1500,8693,256,21792,46212,513]

theorem envBound50889 : H12AffineFastState.Bounded env50889 := by
  intro p hp
  have h : env50889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50888_50889 : H12AffineEnvironment.transform 16 16401 env50888 = env50889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50888 == env50889) = true)

theorem identity50889 : scanCanonicalize (H12AffineFastState.compose env50889 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound50889 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env50890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16401,2341,1024,29708,4160,8613,17,21978,8328,65,10589,5392,17665,32040,1500,8693,256,21792,16521,513]

theorem envBound50890 : H12AffineFastState.Bounded env50890 := by
  intro p hp
  have h : env50890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50889_50890 : H12AffineEnvironment.transform 14 29709 env50889 = env50890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env50889 == env50890) = true)

theorem identity50890 : scanCanonicalize (H12AffineFastState.compose env50890 (packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50890 : packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21760,263,16401,2341,1024,21761,4160,168,17,21978,389,65,2128,5392,17665,23589,1500,248,256,21792,16521,513]

theorem envBound50891 : H12AffineFastState.Bounded env50891 := by
  intro p hp
  have h : env50891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50890_50891 : H12AffineEnvironment.transform 12 269 env50890 = env50891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50890 == env50891) = true)

theorem identity50891 : scanCanonicalize (H12AffineFastState.compose env50891 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound50891 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env50892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,0,263,5393,2341,1024,1,4160,168,17,218,389,65,2128,5392,4097,2341,1500,248,256,32,5513,513]

theorem envBound50892 : H12AffineFastState.Bounded env50892 := by
  intro p hp
  have h : env50892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50891_50892 : H12AffineEnvironment.transform 13 5376 env50891 = env50892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50891 == env50892) = true)

theorem identity50892 : scanCanonicalize (H12AffineFastState.compose env50892 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50892 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env50893 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5376,0,263,5393,2341,1024,1,4160,113,17,3,348,65,2128,5392,4097,2341,1285,33,256,32,5456,513]

theorem envBound50893 : H12AffineFastState.Bounded env50893 := by
  intro p hp
  have h : env50893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50892_50893 : H12AffineEnvironment.transform 6 89 env50892 = env50893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50892 == env50893) = true)

theorem identity50893 : scanCanonicalize (H12AffineFastState.compose env50893 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50894 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1024,1,4160,113,17,3,120,65,2128,5172,4097,2049,1057,33,36,32,5236,513]

theorem envBound50894 : H12AffineFastState.Bounded env50894 := by
  intro p hp
  have h : env50894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50893_50894 : H12AffineEnvironment.transform 7 36 env50893 = env50894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50893 == env50894) = true)

theorem identity50894 : scanCanonicalize (H12AffineFastState.compose env50894 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50894 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50895 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1024,1,4112,33,17,3,40,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound50895 : H12AffineFastState.Bounded env50895 := by
  intro p hp
  have h : env50895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50894_50895 : H12AffineEnvironment.transform 5 16 env50894 = env50895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50894 == env50895) = true)

def env50896 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1044,0,35,1029,2049,1024,1,32,33,17,3,40,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound50896 : H12AffineFastState.Bounded env50896 := by
  intro p hp
  have h : env50896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50895_50896 : H12AffineEnvironment.transform 11 48 env50895 = env50896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50895 == env50896) = true)

theorem identity50896 : scanCanonicalize (H12AffineFastState.compose env50896 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50897 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,48,41,1,0,35,16,2049,21,1,32,33,17,3,40,17,2048,17,49,2049,52,33,36,32,1,513]

theorem envBound50897 : H12AffineFastState.Bounded env50897 := by
  intro p hp
  have h : env50897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50896_50897 : H12AffineEnvironment.transform 9 21 env50896 = env50897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50896 == env50897) = true)

def env50898 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,9,1,0,3,16,2049,21,1,0,1,17,3,8,17,2048,17,17,2049,20,1,4,0,1,513]

theorem envBound50898 : H12AffineFastState.Bounded env50898 := by
  intro p hp
  have h : env50898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0