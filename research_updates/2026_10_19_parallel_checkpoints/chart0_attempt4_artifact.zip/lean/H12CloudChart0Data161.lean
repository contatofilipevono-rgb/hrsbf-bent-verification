import H12CloudChart0Data160

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity40817 : scanCanonicalize (H12AffineFastState.compose env40817 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound40817 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,122147,1024,32769,77899,8573,62661,21762,8328,65,56712,57797,102878,109046,75223,8693,256,21793,46212,512]

theorem envBound40818 : H12AffineFastState.Bounded env40818 := by
  intro p hp
  have h : env40818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40817_40818 : H12AffineEnvironment.transform 17 122147 env40817 = env40818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env40817 == env40818) = true)

theorem identity40818 : scanCanonicalize (H12AffineFastState.compose env40818 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40818 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16400,76278,1024,29908,77899,8573,16,21762,8328,65,10589,5392,91403,89379,75223,8693,256,21793,16465,512]

theorem envBound40819 : H12AffineFastState.Bounded env40819 := by
  intro p hp
  have h : env40819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40818_40819 : H12AffineEnvironment.transform 14 29909 env40818 = env40819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40818 == env40819) = true)

theorem identity40819 : scanCanonicalize (H12AffineFastState.compose env40819 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound40819 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,34,16400,10708,1024,29908,12393,8573,16,21762,8328,65,10589,5392,25897,23809,9717,8693,256,21793,16465,512]

theorem envBound40820 : H12AffineFastState.Bounded env40820 := by
  intro p hp
  have h : env40820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40819_40820 : H12AffineEnvironment.transform 15 34 env40819 = env40820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env40819 == env40820) = true)

theorem identity40820 : scanCanonicalize (H12AffineFastState.compose env40820 (packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound40820 : packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env40821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,33,34,13540,10708,1024,32,12393,8573,16,8694,8328,65,10589,5392,4573,10741,9717,8693,256,8661,13477,512]

theorem envBound40821 : H12AffineFastState.Bounded env40821 := by
  intro p hp
  have h : env40821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40820_40821 : H12AffineEnvironment.transform 13 13556 env40820 = env40821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env40820 == env40821) = true)

theorem identity40821 : scanCanonicalize (H12AffineFastState.compose env40821 (packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound40821 : packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS < 2^1333 := by decide +kernel

def env40822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5512,33,34,5528,2216,1024,32,4373,1,16,138,500,65,2081,5392,4573,2185,1161,137,256,169,5593,512]

theorem envBound40822 : H12AffineFastState.Bounded env40822 := by
  intro p hp
  have h : env40822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40821_40822 : H12AffineEnvironment.transform 12 380 env40821 = env40822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env40821 == env40822) = true)

theorem identity40822 : scanCanonicalize (H12AffineFastState.compose env40822 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound40822 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40823 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,380,4588,33,34,4604,2216,100,32,4373,1,16,138,500,65,2081,4468,4573,2185,237,137,256,169,4541,512]

theorem envBound40823 : H12AffineFastState.Bounded env40823 := by
  intro p hp
  have h : env40823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40822_40823 : H12AffineEnvironment.transform 9 100 env40822 = env40823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env40822 == env40823) = true)

theorem identity40823 : scanCanonicalize (H12AffineFastState.compose env40823 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40823 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40824 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,8,4248,33,34,4232,2216,100,32,4193,1,16,138,128,65,2081,4096,4265,2185,237,137,116,169,4297,512]

theorem envBound40824 : H12AffineFastState.Bounded env40824 := by
  intro p hp
  have h : env40824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40823_40824 : H12AffineEnvironment.transform 7 116 env40823 = env40824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40823 == env40824) = true)

def env40825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322921,8572,338407,362529,8328,65,327850,57796,102878,109046,75222,8693,256,362498,354727,513]

theorem envBound40825 : H12AffineFastState.Bounded env40825 := by
  intro p hp
  have h : env40825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40816_40825 : H12AffineEnvironment.transform 16 16401 env40816 = env40825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40816 == env40825) = true)

theorem identity40825 : scanCanonicalize (H12AffineFastState.compose env40825 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40825 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,322921,8572,264684,305194,8328,65,270497,57796,45525,35325,1501,8693,256,305161,281004,513]

theorem envBound40826 : H12AffineFastState.Bounded env40826 := by
  intro p hp
  have h : env40826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40825_40826 : H12AffineEnvironment.transform 15 8203 env40825 = env40826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40825 == env40826) = true)

theorem identity40826 : scanCanonicalize (H12AffineFastState.compose env40826 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound40826 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10400,1024,32769,50633,8572,8524,32906,8328,65,2049,57796,45525,35325,1501,8693,256,32937,24844,513]

theorem envBound40827 : H12AffineFastState.Bounded env40827 := by
  intro p hp
  have h : env40827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40826_40827 : H12AffineEnvironment.transform 17 10400 env40826 = env40827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env40826 == env40827) = true)

theorem identity40827 : scanCanonicalize (H12AffineFastState.compose env40827 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40827 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,16401,10400,1024,0,17864,8572,8524,139,8328,65,2049,25029,12756,2556,1501,8693,256,168,24844,513]

theorem envBound40828 : H12AffineFastState.Bounded env40828 := by
  intro p hp
  have h : env40828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40827_40828 : H12AffineEnvironment.transform 14 1 env40827 = env40828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40827 == env40828) = true)

theorem identity40828 : scanCanonicalize (H12AffineFastState.compose env40828 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40828 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env40829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,1,262,16401,2477,1024,0,17864,113,65,139,389,65,2049,16584,4313,2556,1501,248,256,168,16385,513]

theorem envBound40829 : H12AffineFastState.Bounded env40829 := by
  intro p hp
  have h : env40829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40828_40829 : H12AffineEnvironment.transform 12 269 env40828 = env40829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40828 == env40829) = true)

theorem identity40829 : scanCanonicalize (H12AffineFastState.compose env40829 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40829 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env40830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1024,0,17728,113,65,3,269,65,2049,16448,4177,2420,1365,112,256,32,16385,513]

theorem envBound40830 : H12AffineFastState.Bounded env40830 := by
  intro p hp
  have h : env40830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40829_40830 : H12AffineEnvironment.transform 6 8 env40829 = env40830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40829 == env40830) = true)

theorem identity40830 : scanCanonicalize (H12AffineFastState.compose env40830 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40830 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40831 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1024,0,17681,32,16,3,269,16,2049,16401,4096,2341,1284,33,256,32,16385,513]

theorem envBound40831 : H12AffineFastState.Bounded env40831 := by
  intro p hp
  have h : env40831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40830_40831 : H12AffineEnvironment.transform 5 17 env40830 = env40831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40830 == env40831) = true)

theorem identity40831 : scanCanonicalize (H12AffineFastState.compose env40831 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound40831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40832 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,1297,1,262,1280,2341,1024,0,0,32,16,3,269,16,2049,1280,4096,2341,1284,33,256,32,1296,513]

theorem envBound40832 : H12AffineFastState.Bounded env40832 := by
  intro p hp
  have h : env40832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40831_40832 : H12AffineEnvironment.transform 13 1297 env40831 = env40832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40831 == env40832) = true)

theorem identity40832 : scanCanonicalize (H12AffineFastState.compose env40832 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound40832 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40833 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,269,1297,1,262,1280,2341,1024,0,0,32,16,3,269,16,2049,1280,308,2341,1284,33,256,32,1296,513]

theorem envBound40833 : H12AffineFastState.Bounded env40833 := by
  intro p hp
  have h : env40833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40832_40833 : H12AffineEnvironment.transform 11 308 env40832 = env40833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env40832 == env40833) = true)

theorem identity40833 : scanCanonicalize (H12AffineFastState.compose env40833 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound40833 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40834 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,308,269,1297,1,262,1280,1077,1024,0,0,32,16,3,269,16,1297,1280,308,1077,1284,33,256,32,1296,513]

theorem envBound40834 : H12AffineFastState.Bounded env40834 := by
  intro p hp
  have h : env40834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40833_40834 : H12AffineEnvironment.transform 10 1296 env40833 = env40834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env40833 == env40834) = true)

theorem identity40834 : scanCanonicalize (H12AffineFastState.compose env40834 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40834 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env40835 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,308,269,293,1,262,308,1,52,0,0,32,16,3,269,16,293,308,308,1,304,33,256,32,292,513]

theorem envBound40835 : H12AffineFastState.Bounded env40835 := by
  intro p hp
  have h : env40835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40834_40835 : H12AffineEnvironment.transform 9 52 env40834 = env40835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40834 == env40835) = true)

theorem identity40835 : scanCanonicalize (H12AffineFastState.compose env40835 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound40835 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40836 : List Nat := [2,4,8,16,32,17,8,256,261,52,292,308,269,293,1,262,308,1,52,0,0,32,16,3,269,16,293,308,308,1,304,33,256,32,292,260]

theorem envBound40836 : H12AffineFastState.Bounded env40836 := by
  intro p hp
  have h : env40836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40835_40836 : H12AffineEnvironment.transform 8 261 env40835 = env40836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env40835 == env40836) = true)

def env40837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485878,16777216,8328,65,16959642,17246709,102879,109046,17231334,17148373,256,16777250,16834951,17287729]

theorem envBound40837 : H12AffineFastState.Bounded env40837 := by
  intro p hp
  have h : env40837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40814_40837 : H12AffineEnvironment.transform 20 437625 env40814 = env40837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env40814 == env40837) = true)

theorem identity40837 : scanCanonicalize (H12AffineFastState.compose env40837 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound40837 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115871,156013,16,16777216,8328,65,16959642,16793619,102879,109046,16876544,16957491,256,16777250,16834951,16819159]

theorem envBound40838 : H12AffineFastState.Bounded env40838 := by
  intro p hp
  have h : env40838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40837_40838 : H12AffineEnvironment.transform 17 223718 env40837 = env40838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env40837 == env40838) = true)

def env40839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115871,156013,16,95496,8328,65,245138,79131,102879,109046,61704,243003,256,95530,103567,120543]

theorem envBound40839 : H12AffineFastState.Bounded env40839 := by
  intro p hp
  have h : env40839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40838_40839 : H12AffineEnvironment.transform 23 95496 env40838 = env40839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env40838 == env40839) = true)

theorem identity40839 : scanCanonicalize (H12AffineFastState.compose env40839 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40839 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179512,1024,32769,4161,156013,16,41430,8328,65,158028,57797,17665,32040,61704,156133,256,41460,16465,513]

theorem envBound40840 : H12AffineFastState.Bounded env40840 := by
  intro p hp
  have h : env40840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40839_40840 : H12AffineEnvironment.transform 15 54494 env40839 = env40840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40839 == env40840) = true)

def env40841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,156013,16,41310,8192,65,158028,57677,17665,32040,61704,156013,256,41340,16465,513]

theorem envBound40841 : H12AffineFastState.Bounded env40841 := by
  intro p hp
  have h : env40841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40840_40841 : H12AffineEnvironment.transform 6 8 env40840 = env40841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40840 == env40841) = true)

theorem identity40841 : scanCanonicalize (H12AffineFastState.compose env40841 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound40841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35189,1024,32769,4161,21792,16,41310,8192,65,23809,57677,17665,32040,61704,21792,256,41340,16465,513]

theorem envBound40842 : H12AffineFastState.Bounded env40842 := by
  intro p hp
  have h : env40842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40841_40842 : H12AffineEnvironment.transform 16 13389 env40841 = env40842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env40841 == env40842) = true)

theorem identity40842 : scanCanonicalize (H12AffineFastState.compose env40842 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound40842 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env40843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,28698,13389,11577,1024,9293,4161,21792,16,1298,8192,65,23809,17665,17665,32040,21828,21792,256,1328,16465,513]

theorem envBound40843 : H12AffineFastState.Bounded env40843 := by
  intro p hp
  have h : env40843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40842_40843 : H12AffineEnvironment.transform 14 9292 env40842 = env40843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env40842 == env40843) = true)

theorem identity40843 : scanCanonicalize (H12AffineFastState.compose env40843 (packedSelected [3,5,9,10,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound40843 : packedSelected [3,5,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env40844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1,21591,4096,2420,1024,0,4161,21792,16,1298,1101,65,23809,17665,17665,22885,21828,21792,256,1328,16465,513]

theorem envBound40844 : H12AffineFastState.Bounded env40844 := by
  intro p hp
  have h : env40844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40843_40844 : H12AffineEnvironment.transform 12 1101 env40843 = env40844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env40843 == env40844) = true)

theorem identity40844 : scanCanonicalize (H12AffineFastState.compose env40844 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40844 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4112,1,1095,4096,2420,1024,0,4161,1328,16,1298,1101,65,3345,5393,5393,2421,1364,1328,256,1328,4161,513]

theorem envBound40845 : H12AffineFastState.Bounded env40845 := by
  intro p hp
  have h : env40845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40844_40845 : H12AffineEnvironment.transform 13 4112 env40844 = env40845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env40844 == env40845) = true)

theorem identity40845 : scanCanonicalize (H12AffineFastState.compose env40845 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound40845 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40846 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4112,1,262,4096,2420,321,0,4161,113,16,83,268,65,2128,4176,4176,2421,21,113,256,113,4161,513]

theorem envBound40846 : H12AffineFastState.Bounded env40846 := by
  intro p hp
  have h : env40846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40845_40846 : H12AffineEnvironment.transform 9 321 env40845 = env40846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40845 == env40846) = true)

theorem identity40846 : scanCanonicalize (H12AffineFastState.compose env40846 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2853) := by decide +kernel

theorem selectedBound40846 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env40847 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2853,268,2869,1,262,2853,2420,321,0,2916,113,16,83,268,65,2128,2933,2933,2421,21,113,256,113,2916,513]

theorem envBound40847 : H12AffineFastState.Bounded env40847 := by
  intro p hp
  have h : env40847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40846_40847 : H12AffineEnvironment.transform 11 2853 env40846 = env40847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2853 env40846 == env40847) = true)

theorem identity40847 : scanCanonicalize (H12AffineFastState.compose env40847 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound40847 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env40848 : List Nat := [2,4,8,16,32,64,8,256,512,321,16,821,268,805,1,262,821,356,321,0,884,113,16,83,268,65,64,869,869,357,21,113,256,113,884,513]

theorem envBound40848 : H12AffineFastState.Bounded env40848 := by
  intro p hp
  have h : env40848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40847_40848 : H12AffineEnvironment.transform 10 16 env40847 = env40848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env40847 == env40848) = true)

theorem identity40848 : scanCanonicalize (H12AffineFastState.compose env40848 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound40848 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40849 : List Nat := [2,4,8,16,32,64,8,256,80,321,16,357,268,373,1,262,357,356,321,0,292,113,16,83,268,65,64,309,309,357,21,113,256,113,292,81]

theorem envBound40849 : H12AffineFastState.Bounded env40849 := by
  intro p hp
  have h : env40849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40848_40849 : H12AffineEnvironment.transform 8 80 env40848 = env40849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env40848 == env40849) = true)

theorem identity40849 : scanCanonicalize (H12AffineFastState.compose env40849 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40849 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40850 : List Nat := [2,4,8,16,32,16,8,256,0,273,16,309,268,293,1,262,309,308,273,0,292,33,16,3,268,17,16,309,309,309,21,33,256,33,292,1]

theorem envBound40850 : H12AffineFastState.Bounded env40850 := by
  intro p hp
  have h : env40850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40849_40850 : H12AffineEnvironment.transform 5 16 env40849 = env40850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40849 == env40850) = true)

theorem identity40850 : scanCanonicalize (H12AffineFastState.compose env40850 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40850 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40851 : List Nat := [2,4,8,16,32,16,8,52,0,37,16,1,56,17,1,50,1,0,37,0,16,33,16,3,56,17,16,1,1,1,21,33,52,33,16,1]

theorem envBound40851 : H12AffineFastState.Bounded env40851 := by
  intro p hp
  have h : env40851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40850_40851 : H12AffineEnvironment.transform 7 52 env40850 = env40851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40850 == env40851) = true)

theorem identity40851 : scanCanonicalize (H12AffineFastState.compose env40851 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40852 : List Nat := [2,4,8,16,16,16,8,4,0,21,16,1,8,17,1,2,1,0,21,0,16,17,16,3,8,17,16,1,1,1,21,17,4,17,16,1]

theorem envBound40852 : H12AffineFastState.Bounded env40852 := by
  intro p hp
  have h : env40852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40851_40852 : H12AffineEnvironment.transform 4 16 env40851 = env40852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40851 == env40852) = true)

theorem identity40852 : scanCanonicalize (H12AffineFastState.compose env40852 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40853 : List Nat := [2,4,8,0,0,0,8,4,0,5,0,1,8,1,1,2,1,0,5,0,0,1,0,3,8,1,0,1,1,1,5,1,4,1,0,1]

theorem envBound40853 : H12AffineFastState.Bounded env40853 := by
  intro p hp
  have h : env40853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40852_40853 : H12AffineEnvironment.transform 3 0 env40852 = env40853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40852 == env40853) = true)

def env40854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4161,156013,16,41311,8193,65,158028,57676,17665,32040,61704,156012,256,41341,16465,513]

theorem envBound40854 : H12AffineFastState.Bounded env40854 := by
  intro p hp
  have h : env40854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40840_40854 : H12AffineEnvironment.transform 6 9 env40840 = env40854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40840 == env40854) = true)

theorem identity40854 : scanCanonicalize (H12AffineFastState.compose env40854 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound40854 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1024,32769,4161,62588,16,41311,8193,65,64605,57676,17665,32040,61704,62589,256,41341,16465,513]

theorem envBound40855 : H12AffineFastState.Bounded env40855 := by
  intro p hp
  have h : env40855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40854_40855 : H12AffineEnvironment.transform 16 38161 env40854 = env40855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env40854 == env40855) = true)

theorem identity40855 : scanCanonicalize (H12AffineFastState.compose env40855 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40855 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,38161,10281,1024,32769,4161,41340,16,41311,8193,65,43357,46156,4097,10280,41992,41341,256,41341,5457,513]

theorem envBound40856 : H12AffineFastState.Bounded env40856 := by
  intro p hp
  have h : env40856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40855_40856 : H12AffineEnvironment.transform 13 5376 env40855 = env40856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40855 == env40856) = true)

theorem identity40856 : scanCanonicalize (H12AffineFastState.compose env40856 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound40856 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8233,8574,13624,10281,1024,8232,4161,341,16,374,8193,65,2420,5221,4097,10280,1057,340,256,340,5457,513]

theorem envBound40857 : H12AffineFastState.Bounded env40857 := by
  intro p hp
  have h : env40857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40856_40857 : H12AffineEnvironment.transform 14 8233 env40856 = env40857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env40856 == env40857) = true)

theorem identity40857 : scanCanonicalize (H12AffineFastState.compose env40857 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound40857 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,81,262,5440,2129,1024,80,4161,341,16,374,121,65,2420,5221,4097,2128,1057,340,256,340,5457,513]

theorem envBound40858 : H12AffineFastState.Bounded env40858 := by
  intro p hp
  have h : env40858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40857_40858 : H12AffineEnvironment.transform 12 120 env40857 = env40858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env40857 == env40858) = true)

theorem identity40858 : scanCanonicalize (H12AffineFastState.compose env40858 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40858 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40859 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,115,5173,2129,1024,80,4161,32,16,3,121,65,2049,5221,4097,2128,1057,33,117,33,5156,513]

theorem envBound40859 : H12AffineFastState.Bounded env40859 := by
  intro p hp
  have h : env40859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40858_40859 : H12AffineEnvironment.transform 7 117 env40858 = env40859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40858 == env40859) = true)

theorem identity40859 : scanCanonicalize (H12AffineFastState.compose env40859 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound40859 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40860 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,120,81,81,115,17,2129,1024,80,1125,32,16,3,121,65,2049,65,1061,2128,1057,33,117,33,0,513]

theorem envBound40860 : H12AffineFastState.Bounded env40860 := by
  intro p hp
  have h : env40860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40859_40860 : H12AffineEnvironment.transform 11 1060 env40859 = env40860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env40859 == env40860) = true)

theorem identity40860 : scanCanonicalize (H12AffineFastState.compose env40860 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40860 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40861 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1060,40,1,1,35,17,2049,1024,0,1077,32,16,3,41,17,2049,17,1061,2048,1057,33,37,33,0,513]

theorem envBound40861 : H12AffineFastState.Bounded env40861 := by
  intro p hp
  have h : env40861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40860_40861 : H12AffineEnvironment.transform 5 16 env40860 = env40861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40860 == env40861) = true)

theorem identity40861 : scanCanonicalize (H12AffineFastState.compose env40861 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound40861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40862 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,0,40,1,1,35,17,2049,36,0,17,32,16,3,41,17,2049,17,1,2048,5,33,37,33,0,513]

theorem envBound40862 : H12AffineFastState.Bounded env40862 := by
  intro p hp
  have h : env40862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40861_40862 : H12AffineEnvironment.transform 9 36 env40861 = env40862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env40861 == env40862) = true)

theorem identity40862 : scanCanonicalize (H12AffineFastState.compose env40862 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound40862 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40863 : List Nat := [2,4,8,16,32,16,9,37,512,36,11,0,40,1,1,35,17,10,36,0,17,32,16,3,41,17,10,17,1,11,5,33,37,33,0,513]

theorem envBound40863 : H12AffineFastState.Bounded env40863 := by
  intro p hp
  have h : env40863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40862_40863 : H12AffineEnvironment.transform 10 11 env40862 = env40863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env40862 == env40863) = true)

theorem identity40863 : scanCanonicalize (H12AffineFastState.compose env40863 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound40863 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40864 : List Nat := [2,4,8,16,27,16,9,30,512,31,11,0,19,1,1,24,17,10,31,0,17,27,16,3,18,17,10,17,1,11,5,26,30,26,0,513]

theorem envBound40864 : H12AffineFastState.Bounded env40864 := by
  intro p hp
  have h : env40864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40863_40864 : H12AffineEnvironment.transform 4 27 env40863 = env40864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env40863 == env40864) = true)

def env40865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115871,156013,16,95497,8328,65,245139,79130,102879,109046,61705,243002,256,95531,103566,120542]

theorem envBound40865 : H12AffineFastState.Bounded env40865 := by
  intro p hp
  have h : env40865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40838_40865 : H12AffineEnvironment.transform 23 95497 env40838 = env40865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env40838 == env40865) = true)

def env40866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115735,156013,16,95497,8192,65,245019,79130,102743,108926,61705,243002,256,95531,103430,120406]

theorem envBound40866 : H12AffineFastState.Bounded env40866 := by
  intro p hp
  have h : env40866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40865_40866 : H12AffineEnvironment.transform 6 8 env40865 = env40866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40865 == env40866) = true)

theorem identity40866 : scanCanonicalize (H12AffineFastState.compose env40866 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound40866 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35189,1024,32769,115735,98678,16,95497,8192,65,23808,79130,102743,108926,61705,21793,256,95531,103430,120406]

theorem envBound40867 : H12AffineFastState.Bounded env40867 := by
  intro p hp
  have h : env40867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40866_40867 : H12AffineEnvironment.transform 16 122907 env40866 = env40867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env40866 == env40867) = true)

theorem identity40867 : scanCanonicalize (H12AffineFastState.compose env40867 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound40867 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,46157,35189,1024,32769,36929,54560,16,8543,8192,65,23808,24908,50433,64808,61705,21793,256,8573,49232,33280]

theorem envBound40868 : H12AffineFastState.Bounded env40868 := by
  intro p hp
  have h : env40868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40867_40868 : H12AffineEnvironment.transform 15 21590 env40867 = env40868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env40867 == env40868) = true)

theorem identity40868 : scanCanonicalize (H12AffineFastState.compose env40868 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40868 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46157,35189,1024,32769,36929,41340,16,8543,8192,65,10588,5392,45405,35188,34133,8573,256,8573,46092,33280]

theorem envBound40869 : H12AffineFastState.Bounded env40869 := by
  intro p hp
  have h : env40869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40868_40869 : H12AffineEnvironment.transform 13 13404 env40868 = env40869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40868 == env40869) = true)

theorem identity40869 : scanCanonicalize (H12AffineFastState.compose env40869 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40869 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env40870 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13404,32768,8202,46157,34816,1024,32769,36929,40969,16,8234,8192,65,10281,5221,45096,34817,33824,8200,117,8200,46092,33280]

theorem envBound40870 : H12AffineFastState.Bounded env40870 := by
  intro p hp
  have h : env40870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40869_40870 : H12AffineEnvironment.transform 7 117 env40869 = env40870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40869 == env40870) = true)

theorem identity40870 : scanCanonicalize (H12AffineFastState.compose env40870 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound40870 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40871 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13404,81,8202,13340,2129,1024,80,4112,8280,16,8234,8192,65,10281,5221,12409,2128,1137,8200,117,8200,13405,593]

theorem envBound40871 : H12AffineFastState.Bounded env40871 := by
  intro p hp
  have h : env40871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40870_40871 : H12AffineEnvironment.transform 14 81 env40870 = env40871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env40870 == env40871) = true)

theorem identity40871 : scanCanonicalize (H12AffineFastState.compose env40871 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound40871 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env40872 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1636,8192,8760,81,8202,8824,2129,1024,80,1652,8280,16,8234,8192,65,10281,513,9757,2128,1137,8200,117,8200,8761,593]

theorem envBound40872 : H12AffineFastState.Bounded env40872 := by
  intro p hp
  have h : env40872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40871_40872 : H12AffineEnvironment.transform 11 1636 env40871 = env40872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env40871 == env40872) = true)

theorem identity40872 : scanCanonicalize (H12AffineFastState.compose env40872 (packedSelected [0,1,4,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1636) := by decide +kernel

theorem selectedBound40872 : packedSelected [0,1,4,5,12] rootPS < 2^1333 := by decide +kernel

def env40873 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1636,1636,8192,8760,81,8202,8824,1589,1024,80,1652,8280,16,8234,8192,65,9805,513,9757,1588,1137,8200,117,8200,8761,593]

theorem envBound40873 : H12AffineFastState.Bounded env40873 := by
  intro p hp
  have h : env40873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40872_40873 : H12AffineEnvironment.transform 10 1636 env40872 = env40873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1636 env40872 == env40873) = true)

theorem identity40873 : scanCanonicalize (H12AffineFastState.compose env40873 (packedSelected [0,1,4,5,11,14] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound40873 : packedSelected [0,1,4,5,11,14] rootPS < 2^1333 := by decide +kernel

def env40874 : List Nat := [2,4,8,16,32,64,8,117,65,1024,1061,1061,8192,8313,81,8202,8249,1140,1024,80,1077,8280,16,8234,8192,65,9228,64,9308,1141,1137,8200,117,8200,8312,16]

theorem envBound40874 : H12AffineFastState.Bounded env40874 := by
  intro p hp
  have h : env40874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40873_40874 : H12AffineEnvironment.transform 8 65 env40873 = env40874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env40873 == env40874) = true)

theorem identity40874 : scanCanonicalize (H12AffineFastState.compose env40874 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound40874 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env40875 : List Nat := [2,4,8,16,32,64,8,117,65,117,80,80,8192,8313,81,8202,8249,1,117,80,64,8280,16,8234,8192,65,8313,64,8233,0,4,8200,117,8200,8312,16]

theorem envBound40875 : H12AffineFastState.Bounded env40875 := by
  intro p hp
  have h : env40875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40874_40875 : H12AffineEnvironment.transform 9 117 env40874 = env40875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env40874 == env40875) = true)

theorem identity40875 : scanCanonicalize (H12AffineFastState.compose env40875 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound40875 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env40876 : List Nat := [2,4,8,16,32,64,8,117,65,117,80,80,120,1,81,114,65,1,117,80,64,32,16,82,120,65,1,64,81,0,4,112,117,112,0,16]

theorem envBound40876 : H12AffineFastState.Bounded env40876 := by
  intro p hp
  have h : env40876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40875_40876 : H12AffineEnvironment.transform 12 120 env40875 = env40876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env40875 == env40876) = true)

def env40877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115734,156013,16,95497,8193,65,245018,79130,102742,108927,61705,243002,256,95531,103431,120407]

theorem envBound40877 : H12AffineFastState.Bounded env40877 := by
  intro p hp
  have h : env40877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40865_40877 : H12AffineEnvironment.transform 6 9 env40865 = env40877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40865 == env40877) = true)

theorem identity40877 : scanCanonicalize (H12AffineFastState.compose env40877 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound40877 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1024,32769,115734,73771,16,95497,8193,65,64604,79130,102742,108927,61705,62588,256,95531,103431,120407]

theorem envBound40878 : H12AffineFastState.Bounded env40878 := by
  intro p hp
  have h : env40878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40877_40878 : H12AffineEnvironment.transform 16 82246 env40877 = env40878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env40877 == env40878) = true)

theorem identity40878 : scanCanonicalize (H12AffineFastState.compose env40878 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40878 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env40879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82246,2420,1024,32769,115734,65910,16,87124,348,65,56577,70727,102742,100386,53332,54561,256,87158,103431,120407]

theorem envBound40879 : H12AffineFastState.Bounded env40879 := by
  intro p hp
  have h : env40879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40878_40879 : H12AffineEnvironment.transform 12 349 env40878 = env40879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40878 == env40879) = true)

theorem identity40879 : scanCanonicalize (H12AffineFastState.compose env40879 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound40879 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env40880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,82246,2420,1024,21760,69911,65910,16,87124,348,65,2048,70727,83031,89379,1365,32,256,87158,82182,66390]

theorem envBound40880 : H12AffineFastState.Bounded env40880 := by
  intro p hp
  have h : env40880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40879_40880 : H12AffineEnvironment.transform 14 21761 env40879 = env40880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env40879 == env40880) = true)

theorem identity40880 : scanCanonicalize (H12AffineFastState.compose env40880 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound40880 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env40881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,65536,70678,2420,1024,80,69911,65910,16,65796,348,65,2048,70727,69895,67699,1365,32,256,65830,70742,66390]

theorem envBound40881 : H12AffineFastState.Bounded env40881 := by
  intro p hp
  have h : env40881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40880_40881 : H12AffineEnvironment.transform 13 5456 env40880 = env40881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env40880 == env40881) = true)

theorem identity40881 : scanCanonicalize (H12AffineFastState.compose env40881 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound40881 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env40882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,115,5221,2420,1024,80,4452,261,16,375,348,65,2048,5172,4468,2048,1365,32,256,341,5157,805]

theorem envBound40882 : H12AffineFastState.Bounded env40882 := by
  intro p hp
  have h : env40882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40881_40882 : H12AffineEnvironment.transform 15 115 env40881 = env40882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env40881 == env40882) = true)

theorem identity40882 : scanCanonicalize (H12AffineFastState.compose env40882 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40882 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env40883 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,81,115,5221,2048,1024,80,4112,113,16,3,40,65,2048,5172,4096,2048,1057,32,116,33,5157,593]

theorem envBound40883 : H12AffineFastState.Bounded env40883 := by
  intro p hp
  have h : env40883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40882_40883 : H12AffineEnvironment.transform 7 116 env40882 = env40883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40882 == env40883) = true)

theorem identity40883 : scanCanonicalize (H12AffineFastState.compose env40883 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40883 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env40884 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,4096,9,5124,81,83,5189,2048,1024,80,4112,81,16,3,8,65,2048,5140,4096,2048,1025,0,84,1,5125,593]

theorem envBound40884 : H12AffineFastState.Bounded env40884 := by
  intro p hp
  have h : env40884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40883_40884 : H12AffineEnvironment.transform 4 0 env40883 = env40884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40883 == env40884) = true)

def env40885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound40885 : H12AffineFastState.Bounded env40885 := by
  intro p hp
  have h : env40885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40724_40885 : H12AffineEnvironment.transform 18 1025 env40724 = env40885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40724 == env40885) = true)

theorem identity40885 : scanCanonicalize (H12AffineFastState.compose env40885 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297335) := by decide +kernel

theorem selectedBound40885 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8328,65,12798327,2428410,10507600,8830977,8719719,6679734,257,10833371,10857599,8661681]

theorem envBound40886 : H12AffineFastState.Bounded env40886 := by
  intro p hp
  have h : env40886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40885_40886 : H12AffineEnvironment.transform 23 297335 env40885 = env40886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297335 env40885 == env40886) = true)

def env40887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12798327,2428274,10507600,8830977,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound40887 : H12AffineFastState.Bounded env40887 := by
  intro p hp
  have h : env40887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40886_40887 : H12AffineEnvironment.transform 6 8 env40886 = env40887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40886 == env40887) = true)

def env40888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650855,2428274,10507600,8683537,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound40888 : H12AffineFastState.Bounded env40888 := by
  intro p hp
  have h : env40888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40887_40888 : H12AffineEnvironment.transform 16 16400 env40887 = env40888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40887 == env40888) = true)

theorem identity40888 : scanCanonicalize (H12AffineFastState.compose env40888 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound40888 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,297335,8192,65,4262262,2428274,2118977,294912,331126,6679614,257,2444610,2468974,272936]

theorem envBound40889 : H12AffineFastState.Bounded env40889 := by
  intro p hp
  have h : env40889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40888_40889 : H12AffineEnvironment.transform 22 17 env40888 = env40889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40888 == env40889) = true)

def env40890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,17,41311,8192,65,4262262,2172250,2118977,43048,75102,6407190,257,2188650,2196550,512]

theorem envBound40890 : H12AffineFastState.Bounded env40890 := by
  intro p hp
  have h : env40890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40889_40890 : H12AffineEnvironment.transform 17 10280 env40889 = env40890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40889 == env40890) = true)

theorem identity40890 : scanCanonicalize (H12AffineFastState.compose env40890 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 116066) := by decide +kernel

theorem selectedBound40890 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,116066,4194304,17,41311,8192,65,4262262,57400,102435,43048,75102,4194676,257,40968,16676,512]

theorem envBound40891 : H12AffineFastState.Bounded env40891 := by
  intro p hp
  have h : env40891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40890_40891 : H12AffineEnvironment.transform 20 116066 env40890 = env40891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116066 env40890 == env40891) = true)

theorem identity40891 : scanCanonicalize (H12AffineFastState.compose env40891 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound40891 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env40892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,10280,1025,32769,17460,4194304,17,41311,8192,65,4229152,57400,4469,43048,41992,4194676,257,40968,16676,512]

theorem envBound40892 : H12AffineFastState.Bounded env40892 := by
  intro p hp
  have h : env40892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40891_40892 : H12AffineEnvironment.transform 15 33110 env40891 = env40892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env40891 == env40892) = true)

theorem identity40892 : scanCanonicalize (H12AffineFastState.compose env40892 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 26665) := by decide +kernel

theorem selectedBound40892 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,10280,1025,32769,17460,26665,17,41311,8192,65,57353,57400,4469,43048,41992,26973,257,40968,16676,512]

theorem envBound40893 : H12AffineFastState.Bounded env40893 := by
  intro p hp
  have h : env40893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40892_40893 : H12AffineEnvironment.transform 21 26665 env40892 = env40893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 26665 env40892 == env40893) = true)

theorem identity40893 : scanCanonicalize (H12AffineFastState.compose env40893 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound40893 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env40894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,32768,33110,13421,10280,1025,32769,12361,7252,17,41311,8192,65,38004,37957,4469,43048,41992,7456,257,40968,13657,512]

theorem envBound40894 : H12AffineFastState.Bounded env40894 := by
  intro p hp
  have h : env40894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40893_40894 : H12AffineEnvironment.transform 13 13437 env40893 = env40894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env40893 == env40894) = true)

theorem identity40894 : scanCanonicalize (H12AffineFastState.compose env40894 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 6161) := by decide +kernel

theorem selectedBound40894 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,6161,6471,13421,10280,1025,6160,12361,7252,17,14670,8192,65,3173,3156,4469,12345,15385,7456,257,14361,13657,512]

theorem envBound40895 : H12AffineFastState.Bounded env40895 := by
  intro p hp
  have h : env40895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40894_40895 : H12AffineEnvironment.transform 14 6161 env40894 = env40895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6161 env40894 == env40895) = true)

theorem identity40895 : scanCanonicalize (H12AffineFastState.compose env40895 (packedSelected [9,14,22] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound40895 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10249,1125,1331,10265,10280,1025,1124,11325,32,17,9530,8192,65,3173,3156,3329,11341,8301,340,257,9325,10541,512]

theorem envBound40896 : H12AffineFastState.Bounded env40896 := by
  intro p hp
  have h : env40896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40895_40896 : H12AffineEnvironment.transform 11 3188 env40895 = env40896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env40895 == env40896) = true)

theorem identity40896 : scanCanonicalize (H12AffineFastState.compose env40896 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound40896 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env40897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,1352,3393,1125,1331,3409,3424,1025,1124,2421,32,17,114,1352,65,3173,3156,3329,2309,1317,340,257,293,3173,512]

theorem envBound40897 : H12AffineFastState.Bounded env40897 := by
  intro p hp
  have h : env40897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40896_40897 : H12AffineEnvironment.transform 12 1352 env40896 = env40897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env40896 == env40897) = true)

theorem identity40897 : scanCanonicalize (H12AffineFastState.compose env40897 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound40897 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env40898 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,2096,268,2309,33,375,2325,2340,69,32,2421,32,17,114,268,65,2081,2064,2373,2309,353,340,257,293,2081,512]

theorem envBound40898 : H12AffineFastState.Bounded env40898 := by
  intro p hp
  have h : env40898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40897_40898 : H12AffineEnvironment.transform 9 68 env40897 = env40898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env40897 == env40898) = true)

theorem identity40898 : scanCanonicalize (H12AffineFastState.compose env40898 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40898 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40899 : List Nat := [2,4,8,16,32,48,8,256,512,52,2048,2096,268,2309,33,263,2325,2340,53,32,2309,32,17,2,268,49,2081,2064,2357,2309,273,292,257,293,2081,512]

theorem envBound40899 : H12AffineFastState.Bounded env40899 := by
  intro p hp
  have h : env40899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40898_40899 : H12AffineEnvironment.transform 5 48 env40898 = env40899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40898 == env40899) = true)

theorem identity40899 : scanCanonicalize (H12AffineFastState.compose env40899 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40899 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40900 : List Nat := [2,4,8,16,32,48,8,4,512,52,2048,2096,8,2049,33,3,2065,2080,53,32,2049,32,17,2,8,49,2081,2064,2097,2049,21,32,5,33,2081,512]

theorem envBound40900 : H12AffineFastState.Bounded env40900 := by
  intro p hp
  have h : env40900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40899_40900 : H12AffineEnvironment.transform 7 4 env40899 = env40900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40899 == env40900) = true)

theorem identity40900 : scanCanonicalize (H12AffineFastState.compose env40900 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound40900 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40901 : List Nat := [2,4,8,16,32,48,8,4,32,52,2048,2096,8,2049,33,3,2065,2080,53,32,2049,32,17,2,8,49,2081,2064,2097,2049,21,32,5,33,2081,32]

theorem envBound40901 : H12AffineFastState.Bounded env40901 := by
  intro p hp
  have h : env40901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40900_40901 : H12AffineEnvironment.transform 8 32 env40900 = env40901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env40900 == env40901) = true)

theorem identity40901 : scanCanonicalize (H12AffineFastState.compose env40901 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40901 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40902 : List Nat := [2,4,8,16,1,17,8,4,1,21,2048,2065,8,2049,0,3,2065,2049,20,1,2049,1,17,2,8,16,2048,2064,2064,2049,21,1,5,0,2048,1]

theorem envBound40902 : H12AffineFastState.Bounded env40902 := by
  intro p hp
  have h : env40902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40901_40902 : H12AffineEnvironment.transform 4 1 env40901 = env40902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40901 == env40902) = true)

theorem identity40902 : scanCanonicalize (H12AffineFastState.compose env40902 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound40902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40903 : List Nat := [2,4,8,4,1,5,8,4,1,1,2048,2053,8,2049,0,3,2053,2049,0,1,2049,1,5,2,8,4,2048,2052,2052,2049,1,1,5,0,2048,1]

theorem envBound40903 : H12AffineFastState.Bounded env40903 := by
  intro p hp
  have h : env40903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40902_40903 : H12AffineEnvironment.transform 3 4 env40902 = env40903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env40902 == env40903) = true)

def leafEnv40903 : List Nat := [2,4,8,4,1,5,8,4,1,1,2048,2053,8,2049,0,3,2053,2049,0,1,2049,1,5,2,0,8,1,4,2048,2052,2052,2049,1,1,5,0,5,3,2048,1,1,2048,0]

def active40903 : List Nat := [0,1,2,10]

def tree40903 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40903 : H12WitnessSearch.Good tree40903 := H12GlobalWitnessIndex.good

theorem leafIdentity40903 : H12AffineFastState.composeSystem env40903 rootObs = leafEnv40903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40903 rootObs == leafEnv40903) = true)

theorem terminalChecked40903 : H12PackedTerminal.terminalCheckFast leafEnv40903 active40903 tree40903 = true := by decide +kernel

def env40904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41310,8192,65,4262262,2172251,2118977,43049,75103,6407191,257,2188651,2196551,513]

theorem envBound40904 : H12AffineFastState.Bounded env40904 := by
  intro p hp
  have h : env40904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40889_40904 : H12AffineEnvironment.transform 17 10281 env40889 = env40904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40889 == env40904) = true)

theorem identity40904 : scanCanonicalize (H12AffineFastState.compose env40904 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound40904 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env40905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115735,4194304,17,41310,8192,65,4262262,57676,102742,43049,75103,4194304,257,41340,16464,513]

theorem envBound40905 : H12AffineFastState.Bounded env40905 := by
  intro p hp
  have h : env40905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40904_40905 : H12AffineEnvironment.transform 20 115735 env40904 = env40905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env40904 == env40905) = true)

theorem identity40905 : scanCanonicalize (H12AffineFastState.compose env40905 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound40905 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env40906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115735,8573,17,41310,8192,65,75787,57676,102742,43049,75103,8573,257,41340,16464,513]

theorem envBound40906 : H12AffineFastState.Bounded env40906 := by
  intro p hp
  have h : env40906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40905_40906 : H12AffineEnvironment.transform 21 8573 env40905 = env40906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env40905 == env40906) = true)

theorem identity40906 : scanCanonicalize (H12AffineFastState.compose env40906 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound40906 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10281,1025,32769,25629,8573,17,41310,8192,65,34817,57676,12636,43049,34133,8573,257,41340,16464,513]

theorem envBound40907 : H12AffineFastState.Bounded env40907 := by
  intro p hp
  have h : env40907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40906_40907 : H12AffineEnvironment.transform 15 40970 env40906 = env40907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env40906 == env40907) = true)

theorem identity40907 : scanCanonicalize (H12AffineFastState.compose env40907 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40907 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40908 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10281,1025,32769,25629,8492,17,41231,8192,16,34817,57629,12557,43049,34052,8492,257,41261,16385,513]

theorem envBound40908 : H12AffineFastState.Bounded env40908 := by
  intro p hp
  have h : env40908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40907_40908 : H12AffineEnvironment.transform 5 17 env40907 = env40908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40907 == env40908) = true)

theorem identity40908 : scanCanonicalize (H12AffineFastState.compose env40908 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40908 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40909 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,33030,16400,2341,1025,32769,17681,32,17,32771,268,16,34817,49169,4097,35109,34052,32,257,32801,16385,513]

theorem envBound40909 : H12AffineFastState.Bounded env40909 := by
  intro p hp
  have h : env40909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40908_40909 : H12AffineEnvironment.transform 12 268 env40908 = env40909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40908 == env40909) = true)

theorem identity40909 : scanCanonicalize (H12AffineFastState.compose env40909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40910 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1025,1,17681,32,17,3,268,16,2049,16401,4097,2341,1284,32,257,33,16385,513]

theorem envBound40910 : H12AffineFastState.Bounded env40910 := by
  intro p hp
  have h : env40910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40909_40910 : H12AffineEnvironment.transform 14 0 env40909 = env40910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40909 == env40910) = true)

theorem identity40910 : scanCanonicalize (H12AffineFastState.compose env40910 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4389) := by decide +kernel

theorem selectedBound40910 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40911 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4389,0,262,4405,2341,1025,1,5172,32,17,3,268,16,2049,4404,4097,2341,1284,32,257,33,4388,513]

theorem envBound40911 : H12AffineFastState.Bounded env40911 := by
  intro p hp
  have h : env40911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40910_40911 : H12AffineEnvironment.transform 13 4389 env40910 = env40911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4389 env40910 == env40911) = true)

theorem identity40911 : scanCanonicalize (H12AffineFastState.compose env40911 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound40911 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40912 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,512,268,805,0,262,821,2341,1025,1,1588,32,17,3,268,16,2049,820,513,2341,1284,32,257,33,804,513]

theorem envBound40912 : H12AffineFastState.Bounded env40912 := by
  intro p hp
  have h : env40912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40911_40912 : H12AffineEnvironment.transform 11 512 env40911 = env40912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env40911 == env40912) = true)

theorem identity40912 : scanCanonicalize (H12AffineFastState.compose env40912 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound40912 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40913 : List Nat := [2,4,8,16,32,17,8,256,512,768,2048,512,268,805,0,262,821,2341,769,1,308,32,17,3,268,16,2049,820,513,2341,516,32,257,33,804,513]

theorem envBound40913 : H12AffineFastState.Bounded env40913 := by
  intro p hp
  have h : env40913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40912_40913 : H12AffineEnvironment.transform 9 768 env40912 = env40913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env40912 == env40913) = true)

theorem identity40913 : scanCanonicalize (H12AffineFastState.compose env40913 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound40913 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40914 : List Nat := [2,4,8,16,32,17,8,53,512,565,2048,512,57,528,0,51,512,2064,564,1,1,32,17,3,57,16,2049,513,513,2064,516,32,52,33,529,513]

theorem envBound40914 : H12AffineFastState.Bounded env40914 := by
  intro p hp
  have h : env40914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40913_40914 : H12AffineEnvironment.transform 7 53 env40913 = env40914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env40913 == env40914) = true)

theorem identity40914 : scanCanonicalize (H12AffineFastState.compose env40914 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound40914 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40915 : List Nat := [2,4,8,16,32,17,8,53,512,565,17,512,57,528,0,51,512,1,564,1,1,32,17,3,57,16,16,513,513,1,516,32,52,33,529,513]

theorem envBound40915 : H12AffineFastState.Bounded env40915 := by
  intro p hp
  have h : env40915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40914_40915 : H12AffineEnvironment.transform 10 17 env40914 = env40915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env40914 == env40915) = true)

theorem identity40915 : scanCanonicalize (H12AffineFastState.compose env40915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40916 : List Nat := [2,4,8,16,0,17,8,21,512,533,17,512,25,528,0,19,512,1,532,1,1,0,17,3,25,16,16,513,513,1,516,0,20,1,529,513]

theorem envBound40916 : H12AffineFastState.Bounded env40916 := by
  intro p hp
  have h : env40916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40915_40916 : H12AffineEnvironment.transform 4 0 env40915 = env40916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40915 == env40916) = true)

theorem identity40916 : scanCanonicalize (H12AffineFastState.compose env40916 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40917 : List Nat := [2,4,8,16,0,17,8,21,0,21,17,0,25,16,0,19,0,1,20,1,1,0,17,3,25,16,16,1,1,1,4,0,20,1,17,1]

theorem envBound40917 : H12AffineFastState.Bounded env40917 := by
  intro p hp
  have h : env40917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40916_40917 : H12AffineEnvironment.transform 8 0 env40916 = env40917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40916 == env40917) = true)

def env40918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650854,2428274,10507600,8683536,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound40918 : H12AffineFastState.Bounded env40918 := by
  intro p hp
  have h : env40918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40887_40918 : H12AffineEnvironment.transform 16 16401 env40887 = env40918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40887 == env40918) = true)

theorem identity40918 : scanCanonicalize (H12AffineFastState.compose env40918 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40918 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,8388608,41310,8192,65,12650854,2172251,10507600,8431673,8463694,6407191,257,10577274,10585174,8389136]

theorem envBound40919 : H12AffineFastState.Bounded env40919 := by
  intro p hp
  have h : env40919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40918_40919 : H12AffineEnvironment.transform 17 10281 env40918 = env40919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40918 == env40919) = true)

def env40920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,16,41310,8192,65,4262262,2172251,2118976,43049,75102,6407191,257,2188650,2196550,512]

theorem envBound40920 : H12AffineFastState.Bounded env40920 := by
  intro p hp
  have h : env40920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40919_40920 : H12AffineEnvironment.transform 22 16 env40919 = env40920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40919 == env40920) = true)

theorem identity40920 : scanCanonicalize (H12AffineFastState.compose env40920 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58729) := by decide +kernel

theorem selectedBound40920 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58729,4194304,16,41310,8192,65,4262262,114738,45097,43049,75102,4268414,257,98307,90415,512]

theorem envBound40921 : H12AffineFastState.Bounded env40921 := by
  intro p hp
  have h : env40921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40920_40921 : H12AffineEnvironment.transform 20 58729 env40920 = env40921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58729 env40920 == env40921) = true)

theorem identity40921 : scanCanonicalize (H12AffineFastState.compose env40921 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound40921 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env40922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58729,98678,16,41310,8192,65,34816,114738,45097,43049,75102,40968,257,98307,90415,512]

theorem envBound40922 : H12AffineFastState.Bounded env40922 := by
  intro p hp
  have h : env40922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40921_40922 : H12AffineEnvironment.transform 21 98678 env40921 = env40922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env40921 == env40922) = true)

theorem identity40922 : scanCanonicalize (H12AffineFastState.compose env40922 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 61498) := by decide +kernel

theorem selectedBound40922 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,61498,16401,10281,1025,32769,58729,29004,16,41310,8192,65,34816,12296,45097,43049,54628,40968,257,28729,37141,512]

theorem envBound40923 : H12AffineFastState.Bounded env40923 := by
  intro p hp
  have h : env40923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40922_40923 : H12AffineEnvironment.transform 15 61498 env40922 = env40923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61498 env40922 == env40923) = true)

theorem identity40923 : scanCanonicalize (H12AffineFastState.compose env40923 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40923 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env40924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,42298,5393,10281,1025,32769,45161,9292,16,41310,8192,65,34816,12296,45097,43049,32868,40968,257,9529,37141,512]

theorem envBound40924 : H12AffineFastState.Bounded env40924 := by
  intro p hp
  have h : env40924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40923_40924 : H12AffineEnvironment.transform 13 5376 env40923 = env40924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40923 == env40924) = true)

theorem identity40924 : scanCanonicalize (H12AffineFastState.compose env40924 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound40924 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env40925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1077,8463,5393,10281,1025,1076,13404,9292,16,9579,8192,65,3125,12296,13340,11292,1105,9277,257,9529,5408,512]

theorem envBound40925 : H12AffineFastState.Bounded env40925 := by
  intro p hp
  have h : env40925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40924_40925 : H12AffineEnvironment.transform 14 1077 env40924 = env40925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env40924 == env40925) = true)

theorem identity40925 : scanCanonicalize (H12AffineFastState.compose env40925 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound40925 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env40926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5376,1077,1126,5393,3392,1025,1076,4405,293,16,2,1385,65,3125,5473,4469,2421,1105,340,257,80,5408,512]

theorem envBound40926 : H12AffineFastState.Bounded env40926 := by
  intro p hp
  have h : env40926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40925_40926 : H12AffineEnvironment.transform 12 1385 env40925 = env40926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env40925 == env40926) = true)

theorem identity40926 : scanCanonicalize (H12AffineFastState.compose env40926 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound40926 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40927 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,40,4161,372,295,4176,2049,320,373,4405,293,16,2,40,65,2420,4128,4469,2421,272,340,257,80,4193,512]

theorem envBound40927 : H12AffineFastState.Bounded env40927 := by
  intro p hp
  have h : env40927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40926_40927 : H12AffineEnvironment.transform 9 321 env40926 = env40927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40926 == env40927) = true)

theorem identity40927 : scanCanonicalize (H12AffineFastState.compose env40927 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40927 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40928 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,40,4161,0,83,4176,2049,52,1,4161,81,16,2,40,65,2048,4128,4097,2049,100,32,117,80,4193,512]

theorem envBound40928 : H12AffineFastState.Bounded env40928 := by
  intro p hp
  have h : env40928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40927_40928 : H12AffineEnvironment.transform 7 116 env40927 = env40928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40927 == env40928) = true)

theorem identity40928 : scanCanonicalize (H12AffineFastState.compose env40928 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound40928 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40929 : List Nat := [2,4,8,16,32,49,8,5,512,53,2048,4096,40,4144,0,34,4129,2049,52,1,4144,32,16,2,40,48,2048,4128,4097,2049,21,32,4,33,4112,512]

theorem envBound40929 : H12AffineFastState.Bounded env40929 := by
  intro p hp
  have h : env40929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40928_40929 : H12AffineEnvironment.transform 5 49 env40928 = env40929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env40928 == env40929) = true)

theorem identity40929 : scanCanonicalize (H12AffineFastState.compose env40929 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound40929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40930 : List Nat := [2,4,8,16,32,49,8,5,32,53,2048,4096,40,4144,0,34,4129,2049,52,1,4144,32,16,2,40,48,2048,4128,4097,2049,21,32,4,33,4112,32]

theorem envBound40930 : H12AffineFastState.Bounded env40930 := by
  intro p hp
  have h : env40930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40929_40930 : H12AffineEnvironment.transform 8 32 env40929 = env40930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env40929 == env40930) = true)

theorem identity40930 : scanCanonicalize (H12AffineFastState.compose env40930 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound40930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40931 : List Nat := [2,4,8,16,32,49,8,5,32,53,2048,17,40,33,0,34,48,2049,52,1,33,32,16,2,40,48,2048,49,16,2049,21,32,4,33,1,32]

theorem envBound40931 : H12AffineFastState.Bounded env40931 := by
  intro p hp
  have h : env40931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40930_40931 : H12AffineEnvironment.transform 11 17 env40930 = env40931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env40930 == env40931) = true)

theorem identity40931 : scanCanonicalize (H12AffineFastState.compose env40931 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40932 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,17,9,0,0,3,17,2049,21,1,0,1,16,2,9,17,2048,16,16,2049,21,1,4,0,1,1]

theorem envBound40932 : H12AffineFastState.Bounded env40932 := by
  intro p hp
  have h : env40932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40931_40932 : H12AffineEnvironment.transform 4 1 env40931 = env40932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40931 == env40932) = true)

theorem identity40932 : scanCanonicalize (H12AffineFastState.compose env40932 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound40932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40933 : List Nat := [2,4,6,16,1,16,6,5,1,20,2048,17,7,0,0,3,17,2049,21,1,0,1,16,2,7,17,2048,16,16,2049,21,1,4,0,1,1]

theorem envBound40933 : H12AffineFastState.Bounded env40933 := by
  intro p hp
  have h : env40933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40932_40933 : H12AffineEnvironment.transform 2 6 env40932 = env40933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env40932 == env40933) = true)

theorem identity40933 : scanCanonicalize (H12AffineFastState.compose env40933 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40933 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40934 : List Nat := [2,4,6,16,1,16,6,5,1,20,0,17,7,0,0,3,17,1,21,1,0,1,16,2,7,17,0,16,16,1,21,1,4,0,1,1]

theorem envBound40934 : H12AffineFastState.Bounded env40934 := by
  intro p hp
  have h : env40934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40933_40934 : H12AffineEnvironment.transform 10 0 env40933 = env40934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40933 == env40934) = true)

def env40935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41310,8192,65,4262263,2172251,2118977,43048,75103,6407191,257,2188651,2196551,513]

theorem envBound40935 : H12AffineFastState.Bounded env40935 := by
  intro p hp
  have h : env40935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40919_40935 : H12AffineEnvironment.transform 22 17 env40919 = env40935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40919 == env40935) = true)

def env40936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41310,8192,65,4262263,115015,45405,43048,75103,4268043,257,98679,90203,513]

theorem envBound40936 : H12AffineFastState.Bounded env40936 := by
  intro p hp
  have h : env40936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40935_40936 : H12AffineEnvironment.transform 20 58396 env40935 = env40936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env40935 == env40936) = true)

theorem identity40936 : scanCanonicalize (H12AffineFastState.compose env40936 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58396,4194304,17,41310,8192,65,4204924,57676,45405,43048,1364,4194304,257,41340,16464,513]

theorem envBound40937 : H12AffineFastState.Bounded env40937 := by
  intro p hp
  have h : env40937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40936_40937 : H12AffineEnvironment.transform 15 8203 env40936 = env40937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40936 == env40937) = true)

theorem identity40937 : scanCanonicalize (H12AffineFastState.compose env40937 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound40937 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58396,33,17,41310,8192,65,10589,57676,45405,43048,1364,33,257,41340,16464,513]

theorem envBound40938 : H12AffineFastState.Bounded env40938 := by
  intro p hp
  have h : env40938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40937_40938 : H12AffineEnvironment.transform 21 33 env40937 = env40938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env40937 == env40938) = true)

theorem identity40938 : scanCanonicalize (H12AffineFastState.compose env40938 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40938 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env40939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2340,1025,32769,50449,33,17,32851,269,65,2128,49217,36944,35109,1364,33,257,32881,16464,513]

theorem envBound40939 : H12AffineFastState.Bounded env40939 := by
  intro p hp
  have h : env40939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40938_40939 : H12AffineEnvironment.transform 12 269 env40938 = env40939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40938 == env40939) = true)

theorem identity40939 : scanCanonicalize (H12AffineFastState.compose env40939 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound40939 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,262,16401,2340,1025,80,17728,33,17,2,269,65,2128,16400,4097,2420,1364,33,257,32,16464,513]

theorem envBound40940 : H12AffineFastState.Bounded env40940 := by
  intro p hp
  have h : env40940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40939_40940 : H12AffineEnvironment.transform 14 81 env40939 = env40940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env40939 == env40940) = true)

theorem identity40940 : scanCanonicalize (H12AffineFastState.compose env40940 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40940 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40941 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16401,2340,1025,0,17680,33,17,2,269,17,2048,16400,4097,2340,1284,33,257,32,16384,513]

theorem envBound40941 : H12AffineFastState.Bounded env40941 := by
  intro p hp
  have h : env40941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40940_40941 : H12AffineEnvironment.transform 5 16 env40940 = env40941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40940 == env40941) = true)

theorem identity40941 : scanCanonicalize (H12AffineFastState.compose env40941 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound40941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40942 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5156,1,262,5173,2340,1025,0,4404,33,17,2,269,17,2048,5172,4097,2340,1284,33,257,32,5156,513]

theorem envBound40942 : H12AffineFastState.Bounded env40942 := by
  intro p hp
  have h : env40942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40941_40942 : H12AffineEnvironment.transform 13 5156 env40941 = env40942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env40941 == env40942) = true)

def env40943 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2836,1,262,2821,2340,1025,0,3588,33,17,2,269,17,2048,2820,3889,2340,1284,33,257,32,2836,513]

theorem envBound40943 : H12AffineFastState.Bounded env40943 := by
  intro p hp
  have h : env40943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40942_40943 : H12AffineEnvironment.transform 11 3888 env40942 = env40943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env40942 == env40943) = true)

def env40944 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,269,1044,1,262,1029,1572,1025,0,260,33,17,2,269,17,1792,1028,49,1572,1284,33,257,32,1044,513]

theorem envBound40944 : H12AffineFastState.Bounded env40944 := by
  intro p hp
  have h : env40944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40943_40944 : H12AffineEnvironment.transform 10 1792 env40943 = env40944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40943 == env40944) = true)

theorem identity40944 : scanCanonicalize (H12AffineFastState.compose env40944 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound40944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40945 : List Nat := [2,4,8,16,32,16,8,256,512,517,261,48,269,529,1,262,512,33,516,0,260,33,17,2,269,17,261,513,49,33,769,33,257,32,529,513]

theorem envBound40945 : H12AffineFastState.Bounded env40945 := by
  intro p hp
  have h : env40945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40944_40945 : H12AffineEnvironment.transform 9 517 env40944 = env40945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env40944 == env40945) = true)

def env40946 : List Nat := [2,4,8,16,32,16,8,256,48,53,261,48,269,33,1,262,48,33,52,0,260,33,17,2,269,17,261,49,49,33,305,33,257,32,33,49]

theorem envBound40946 : H12AffineFastState.Bounded env40946 := by
  intro p hp
  have h : env40946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40945_40946 : H12AffineEnvironment.transform 8 48 env40945 = env40946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40945 == env40946) = true)

def env40947 : List Nat := [2,4,8,16,32,16,8,256,49,52,261,48,269,32,1,262,49,33,53,0,260,33,17,2,269,17,261,48,49,33,304,33,257,32,32,48]

theorem envBound40947 : H12AffineFastState.Bounded env40947 := by
  intro p hp
  have h : env40947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40945_40947 : H12AffineEnvironment.transform 8 49 env40945 = env40947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40945 == env40947) = true)

theorem identity40947 : scanCanonicalize (H12AffineFastState.compose env40947 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound40947 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40948 : List Nat := [2,4,8,16,32,16,8,63,49,52,58,48,50,32,1,57,49,33,53,0,59,33,17,2,50,17,58,48,49,33,15,33,62,32,32,48]

theorem envBound40948 : H12AffineFastState.Bounded env40948 := by
  intro p hp
  have h : env40948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40947_40948 : H12AffineEnvironment.transform 7 63 env40947 = env40948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env40947 == env40948) = true)

def leafEnv40948 : List Nat := [2,4,8,16,32,16,8,63,49,52,58,48,50,32,1,57,49,33,53,0,59,33,17,2,14,50,1,17,58,48,49,33,15,33,62,32,5,57,32,48,1,59,0]

def active40948 : List Nat := [0,1,2,3,4]

def tree40948 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40948 : H12WitnessSearch.Good tree40948 := H12GlobalWitnessIndex.good

theorem leafIdentity40948 : H12AffineFastState.composeSystem env40948 rootObs = leafEnv40948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40948 rootObs == leafEnv40948) = true)

theorem terminalChecked40948 : H12PackedTerminal.terminalCheckFast leafEnv40948 active40948 tree40948 = true := by decide +kernel

def env40949 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,269,1045,1,262,1028,1573,1025,0,261,33,17,2,269,17,1793,1029,48,1573,1284,33,257,32,1045,513]

theorem envBound40949 : H12AffineFastState.Bounded env40949 := by
  intro p hp
  have h : env40949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40943_40949 : H12AffineEnvironment.transform 10 1793 env40943 = env40949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40943 == env40949) = true)

theorem identity40949 : scanCanonicalize (H12AffineFastState.compose env40949 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound40949 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40950 : List Nat := [2,4,8,16,32,16,8,256,277,1024,1044,49,269,1045,1,262,1028,1328,1025,0,261,33,17,2,269,17,1044,1029,48,1328,1284,33,257,32,1045,276]

theorem envBound40950 : H12AffineFastState.Bounded env40950 := by
  intro p hp
  have h : env40950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40949_40950 : H12AffineEnvironment.transform 8 277 env40949 = env40950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env40949 == env40950) = true)

def env40951 : List Nat := [2,4,8,16,32,16,8,256,277,52,32,49,269,33,1,262,48,260,53,0,261,33,17,2,269,17,32,49,48,260,304,33,257,32,33,276]

theorem envBound40951 : H12AffineFastState.Bounded env40951 := by
  intro p hp
  have h : env40951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40950_40951 : H12AffineEnvironment.transform 9 52 env40950 = env40951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40950 == env40951) = true)

theorem identity40951 : scanCanonicalize (H12AffineFastState.compose env40951 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40952 : List Nat := [2,4,8,10,32,10,8,256,271,46,32,43,269,33,1,262,42,260,47,0,261,33,11,2,269,11,32,43,42,260,298,33,257,32,33,270]

theorem envBound40952 : H12AffineFastState.Bounded env40952 := by
  intro p hp
  have h : env40952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40951_40952 : H12AffineEnvironment.transform 3 10 env40951 = env40952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40951 == env40952) = true)

def leafEnv40952 : List Nat := [2,4,8,10,32,10,8,256,271,46,32,43,269,33,1,262,42,260,47,0,261,33,11,2,299,269,1,11,32,43,42,260,298,33,257,32,5,262,33,270,1,261,0]

def active40952 : List Nat := [0,1,2,4,7]

def tree40952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40952 : H12WitnessSearch.Good tree40952 := H12GlobalWitnessIndex.good

theorem leafIdentity40952 : H12AffineFastState.composeSystem env40952 rootObs = leafEnv40952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40952 rootObs == leafEnv40952) = true)

theorem terminalChecked40952 : H12PackedTerminal.terminalCheckFast leafEnv40952 active40952 tree40952 = true := by decide +kernel

def env40953 : List Nat := [2,4,8,16,32,16,8,256,277,53,33,49,269,32,1,262,49,261,52,0,261,33,17,2,269,17,33,48,48,261,305,33,257,32,32,276]

theorem envBound40953 : H12AffineFastState.Bounded env40953 := by
  intro p hp
  have h : env40953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40950_40953 : H12AffineEnvironment.transform 9 53 env40950 = env40953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40950 == env40953) = true)

def env40954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2837,1,262,2820,2340,1025,0,3589,33,17,2,269,17,2048,2821,3888,2340,1284,33,257,32,2837,513]

theorem envBound40954 : H12AffineFastState.Bounded env40954 := by
  intro p hp
  have h : env40954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40942_40954 : H12AffineEnvironment.transform 11 3889 env40942 = env40954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env40942 == env40954) = true)

def env40955 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,269,1045,1,262,1028,1572,1025,0,261,33,17,2,269,17,1792,1029,48,1572,1284,33,257,32,1045,513]

theorem envBound40955 : H12AffineFastState.Bounded env40955 := by
  intro p hp
  have h : env40955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40954_40955 : H12AffineEnvironment.transform 10 1792 env40954 = env40955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40954 == env40955) = true)

theorem identity40955 : scanCanonicalize (H12AffineFastState.compose env40955 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40956 : List Nat := [2,4,8,16,32,16,8,256,48,1024,1328,49,269,1045,1,262,1028,1044,1025,0,261,33,17,2,269,17,1328,1029,48,1044,1284,33,257,32,1045,49]

theorem envBound40956 : H12AffineFastState.Bounded env40956 := by
  intro p hp
  have h : env40956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40955_40956 : H12AffineEnvironment.transform 8 48 env40955 = env40956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40955 == env40956) = true)

def env40957 : List Nat := [2,4,8,16,32,16,8,256,48,52,260,49,269,33,1,262,48,32,53,0,261,33,17,2,269,17,260,49,48,32,304,33,257,32,33,49]

theorem envBound40957 : H12AffineFastState.Bounded env40957 := by
  intro p hp
  have h : env40957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40956_40957 : H12AffineEnvironment.transform 9 52 env40956 = env40957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40956 == env40957) = true)

theorem identity40957 : scanCanonicalize (H12AffineFastState.compose env40957 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound40957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40958 : List Nat := [2,4,8,16,32,16,8,63,48,52,59,49,50,33,1,57,48,32,53,0,58,33,17,2,50,17,59,49,48,32,15,33,62,32,33,49]

theorem envBound40958 : H12AffineFastState.Bounded env40958 := by
  intro p hp
  have h : env40958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40957_40958 : H12AffineEnvironment.transform 7 63 env40957 = env40958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env40957 == env40958) = true)

def leafEnv40958 : List Nat := [2,4,8,16,32,16,8,63,48,52,59,49,50,33,1,57,48,32,53,0,58,33,17,2,14,50,1,17,59,49,48,32,15,33,62,32,5,57,33,49,1,58,0]

def active40958 : List Nat := [0,1,2,3,4]

def tree40958 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40958 : H12WitnessSearch.Good tree40958 := H12GlobalWitnessIndex.good

theorem leafIdentity40958 : H12AffineFastState.composeSystem env40958 rootObs = leafEnv40958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40958 rootObs == leafEnv40958) = true)

theorem terminalChecked40958 : H12PackedTerminal.terminalCheckFast leafEnv40958 active40958 tree40958 = true := by decide +kernel

def env40959 : List Nat := [2,4,8,16,32,16,8,256,48,53,261,49,269,32,1,262,49,33,52,0,261,33,17,2,269,17,261,48,48,33,305,33,257,32,32,49]

theorem envBound40959 : H12AffineFastState.Bounded env40959 := by
  intro p hp
  have h : env40959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40956_40959 : H12AffineEnvironment.transform 9 53 env40956 = env40959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40956 == env40959) = true)

def env40960 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,269,1044,1,262,1029,1573,1025,0,260,33,17,2,269,17,1793,1028,49,1573,1284,33,257,32,1044,513]

theorem envBound40960 : H12AffineFastState.Bounded env40960 := by
  intro p hp
  have h : env40960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40954_40960 : H12AffineEnvironment.transform 10 1793 env40954 = env40960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40954 == env40960) = true)

theorem identity40960 : scanCanonicalize (H12AffineFastState.compose env40960 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound40960 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40961 : List Nat := [2,4,8,16,32,16,8,256,512,800,33,48,269,820,1,262,805,261,801,0,260,33,17,2,269,17,33,804,49,261,548,33,257,32,820,513]

theorem envBound40961 : H12AffineFastState.Bounded env40961 := by
  intro p hp
  have h : env40961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40960_40961 : H12AffineEnvironment.transform 9 800 env40960 = env40961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env40960 == env40961) = true)

def env40962 : List Nat := [2,4,8,16,32,16,8,256,276,52,33,48,269,32,1,262,49,261,53,0,260,33,17,2,269,17,33,48,49,261,304,33,257,32,32,277]

theorem envBound40962 : H12AffineFastState.Bounded env40962 := by
  intro p hp
  have h : env40962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40961_40962 : H12AffineEnvironment.transform 8 276 env40961 = env40962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env40961 == env40962) = true)

theorem identity40962 : scanCanonicalize (H12AffineFastState.compose env40962 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40963 : List Nat := [2,4,8,10,32,10,8,256,270,46,33,42,269,32,1,262,43,261,47,0,260,33,11,2,269,11,33,42,43,261,298,33,257,32,32,271]

theorem envBound40963 : H12AffineFastState.Bounded env40963 := by
  intro p hp
  have h : env40963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40962_40963 : H12AffineEnvironment.transform 3 10 env40962 = env40963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40962 == env40963) = true)

def leafEnv40963 : List Nat := [2,4,8,10,32,10,8,256,270,46,33,42,269,32,1,262,43,261,47,0,260,33,11,2,299,269,1,11,33,42,43,261,298,33,257,32,5,262,32,271,1,260,0]

def active40963 : List Nat := [0,1,2,4,7]

def tree40963 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40963 : H12WitnessSearch.Good tree40963 := H12GlobalWitnessIndex.good

theorem leafIdentity40963 : H12AffineFastState.composeSystem env40963 rootObs = leafEnv40963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40963 rootObs == leafEnv40963) = true)

theorem terminalChecked40963 : H12PackedTerminal.terminalCheckFast leafEnv40963 active40963 tree40963 = true := by decide +kernel

def env40964 : List Nat := [2,4,8,16,32,16,8,256,277,53,33,48,269,33,1,262,48,261,52,0,260,33,17,2,269,17,33,49,49,261,305,33,257,32,33,276]

theorem envBound40964 : H12AffineFastState.Bounded env40964 := by
  intro p hp
  have h : env40964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40961_40964 : H12AffineEnvironment.transform 8 277 env40961 = env40964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env40961 == env40964) = true)

def env40965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41310,8192,65,4262263,115014,45404,43048,75103,4268042,257,98678,90202,513]

theorem envBound40965 : H12AffineFastState.Bounded env40965 := by
  intro p hp
  have h : env40965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40935_40965 : H12AffineEnvironment.transform 20 58397 env40935 = env40965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env40935 == env40965) = true)

theorem identity40965 : scanCanonicalize (H12AffineFastState.compose env40965 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound40965 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env40966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,41340,17,41310,8192,65,108555,115014,45404,43048,75103,98678,257,98678,90202,513]

theorem envBound40966 : H12AffineFastState.Bounded env40966 := by
  intro p hp
  have h : env40966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40965_40966 : H12AffineEnvironment.transform 21 41340 env40965 = env40966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env40965 == env40966) = true)

theorem identity40966 : scanCanonicalize (H12AffineFastState.compose env40966 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40966 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58397,41340,17,41310,8192,65,34817,57676,45404,43048,1365,41340,257,41340,16464,513]

theorem envBound40967 : H12AffineFastState.Bounded env40967 := by
  intro p hp
  have h : env40967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40966_40967 : H12AffineEnvironment.transform 15 8202 env40966 = env40967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40966 == env40967) = true)

theorem identity40967 : scanCanonicalize (H12AffineFastState.compose env40967 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40967 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,16401,2421,1025,32769,50497,32800,17,32770,348,65,34817,49168,36864,35188,1365,32800,257,32800,16464,513]

theorem envBound40968 : H12AffineFastState.Bounded env40968 := by
  intro p hp
  have h : env40968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40967_40968 : H12AffineEnvironment.transform 12 348 env40967 = env40968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40967 == env40968) = true)

theorem identity40968 : scanCanonicalize (H12AffineFastState.compose env40968 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,342,16401,2421,1025,1,17729,32,17,2,348,65,2049,16400,4096,2420,1365,32,257,32,16464,513]

theorem envBound40969 : H12AffineFastState.Bounded env40969 := by
  intro p hp
  have h : env40969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40968_40969 : H12AffineEnvironment.transform 14 0 env40968 = env40969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40968 == env40969) = true)

theorem identity40969 : scanCanonicalize (H12AffineFastState.compose env40969 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound40969 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,603,4096,348,16384,0,342,16401,814,1025,1,17729,32,17,2,348,65,602,16400,4096,815,1365,32,257,32,16464,513]

theorem envBound40970 : H12AffineFastState.Bounded env40970 := by
  intro p hp
  have h : env40970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40969_40970 : H12AffineEnvironment.transform 10 603 env40969 = env40970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env40969 == env40970) = true)

theorem identity40970 : scanCanonicalize (H12AffineFastState.compose env40970 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40970 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,603,4096,348,5376,0,342,5393,814,1025,1,4161,32,17,2,348,65,602,5392,4096,815,1365,32,257,32,5456,513]

theorem envBound40971 : H12AffineFastState.Bounded env40971 := by
  intro p hp
  have h : env40971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40970_40971 : H12AffineEnvironment.transform 13 5376 env40970 = env40971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40970 == env40971) = true)

theorem identity40971 : scanCanonicalize (H12AffineFastState.compose env40971 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40971 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40972 : List Nat := [2,4,8,16,32,64,8,117,512,1024,603,4096,41,5237,0,35,5220,603,1025,1,4161,32,17,2,41,65,602,5221,4096,602,1056,32,116,32,5157,513]

theorem envBound40972 : H12AffineFastState.Bounded env40972 := by
  intro p hp
  have h : env40972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40971_40972 : H12AffineEnvironment.transform 7 117 env40971 = env40972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40971 == env40972) = true)

theorem identity40972 : scanCanonicalize (H12AffineFastState.compose env40972 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound40972 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40973 : List Nat := [2,4,8,16,32,64,8,117,512,574,603,4096,41,4683,0,35,4698,603,575,1,4161,32,17,2,41,65,602,4699,4096,602,542,32,116,32,4635,513]

theorem envBound40973 : H12AffineFastState.Bounded env40973 := by
  intro p hp
  have h : env40973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40972_40973 : H12AffineEnvironment.transform 9 574 env40972 = env40973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env40972 == env40973) = true)

theorem identity40973 : scanCanonicalize (H12AffineFastState.compose env40973 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound40973 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40974 : List Nat := [2,4,8,16,32,64,8,117,122,68,33,4096,41,4145,0,35,4128,33,69,1,4161,32,17,2,41,65,32,4129,4096,32,100,32,116,32,4193,123]

theorem envBound40974 : H12AffineFastState.Bounded env40974 := by
  intro p hp
  have h : env40974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40973_40974 : H12AffineEnvironment.transform 8 122 env40973 = env40974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env40973 == env40974) = true)

theorem identity40974 : scanCanonicalize (H12AffineFastState.compose env40974 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound40974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40975 : List Nat := [2,4,8,16,9,64,8,92,83,68,8,4096,0,4120,0,10,4105,8,69,1,4161,9,17,2,0,65,9,4104,4096,9,77,9,93,9,4168,82]

theorem envBound40975 : H12AffineFastState.Bounded env40975 := by
  intro p hp
  have h : env40975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40974_40975 : H12AffineEnvironment.transform 4 9 env40974 = env40975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env40974 == env40975) = true)

theorem identity40975 : scanCanonicalize (H12AffineFastState.compose env40975 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40975 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env40976 : List Nat := [2,4,8,16,9,16,8,12,3,20,8,4096,0,4120,0,10,4105,8,21,1,4113,9,17,2,0,17,9,4104,4096,9,29,9,13,9,4120,2]

theorem envBound40976 : H12AffineFastState.Bounded env40976 := by
  intro p hp
  have h : env40976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40975_40976 : H12AffineEnvironment.transform 5 16 env40975 = env40976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40975 == env40976) = true)

theorem identity40976 : scanCanonicalize (H12AffineFastState.compose env40976 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 25) := by decide +kernel

theorem selectedBound40976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40977 : List Nat := [2,4,8,16,9,16,8,12,3,20,8,25,0,1,0,10,16,8,21,1,8,9,17,2,0,17,9,17,25,9,29,9,13,9,1,2]

theorem envBound40977 : H12AffineFastState.Bounded env40977 := by
  intro p hp
  have h : env40977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40976_40977 : H12AffineEnvironment.transform 11 25 env40976 = env40977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 25 env40976 == env40977) = true)

theorem identity40977 : scanCanonicalize (H12AffineFastState.compose env40977 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound40977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40978 : List Nat := [2,4,6,16,7,16,6,2,3,20,6,23,0,1,0,4,16,6,21,1,6,7,17,2,0,17,7,17,23,7,19,7,3,7,1,2]

theorem envBound40978 : H12AffineFastState.Bounded env40978 := by
  intro p hp
  have h : env40978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40977_40978 : H12AffineEnvironment.transform 2 6 env40977 = env40978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env40977 == env40978) = true)

theorem identity40978 : scanCanonicalize (H12AffineFastState.compose env40978 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40978 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40979 : List Nat := [2,2,0,16,1,16,0,2,3,18,0,17,0,1,0,2,16,0,19,1,0,1,17,2,0,17,1,17,17,1,19,1,3,1,1,2]

theorem envBound40979 : H12AffineFastState.Bounded env40979 := by
  intro p hp
  have h : env40979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40978_40979 : H12AffineEnvironment.transform 1 2 env40978 = env40979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40978 == env40979) = true)

def env40980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12798327,2428275,10507600,8830977,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound40980 : H12AffineFastState.Bounded env40980 := by
  intro p hp
  have h : env40980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40886_40980 : H12AffineEnvironment.transform 6 9 env40886 = env40980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40886 == env40980) = true)

def env40981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650855,2428275,10507600,8683537,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound40981 : H12AffineFastState.Bounded env40981 := by
  intro p hp
  have h : env40981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40980_40981 : H12AffineEnvironment.transform 16 16400 env40980 = env40981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40980 == env40981) = true)

theorem identity40981 : scanCanonicalize (H12AffineFastState.compose env40981 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound40981 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,41293,297335,8193,65,4302890,2428275,2159645,270684,371754,6679615,257,2485279,2428210,297845]

theorem envBound40982 : H12AffineFastState.Bounded env40982 := by
  intro p hp
  have h : env40982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40981_40982 : H12AffineEnvironment.transform 22 41293 env40981 = env40982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env40981 == env40982) = true)

theorem identity40982 : scanCanonicalize (H12AffineFastState.compose env40982 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40982 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,2097152,4194304,41293,297335,8193,65,4229152,2370937,2159645,270684,298016,6605877,257,2411541,2370872,297845]

theorem envBound40983 : H12AffineFastState.Bounded env40983 := by
  intro p hp
  have h : env40983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40982_40983 : H12AffineEnvironment.transform 15 8202 env40982 = env40983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40982 == env40983) = true)

theorem identity40983 : scanCanonicalize (H12AffineFastState.compose env40983 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound40983 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env40984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,2097152,4194304,41293,3,8193,65,4229152,2139149,2159645,43048,1364,6309185,257,2114913,2139212,513]

theorem envBound40984 : H12AffineFastState.Bounded env40984 := by
  intro p hp
  have h : env40984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40983_40984 : H12AffineEnvironment.transform 17 35188 env40983 = env40984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env40983 == env40984) = true)

theorem identity40984 : scanCanonicalize (H12AffineFastState.compose env40984 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound40984 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,2097152,20529,41293,3,8193,65,55313,2139149,2159645,43048,1364,2102640,257,2114913,2139212,513]

theorem envBound40985 : H12AffineFastState.Bounded env40985 := by
  intro p hp
  have h : env40985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40984_40985 : H12AffineEnvironment.transform 21 20529 env40984 = env40985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env40984 == env40985) = true)

theorem identity40985 : scanCanonicalize (H12AffineFastState.compose env40985 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound40985 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,17728,20529,41293,3,8193,65,55313,57677,45405,43048,1364,20528,257,33,57612,513]

theorem envBound40986 : H12AffineFastState.Bounded env40986 := by
  intro p hp
  have h : env40986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40985_40986 : H12AffineEnvironment.transform 20 17728 env40985 = env40986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env40985 == env40986) = true)

theorem identity40986 : scanCanonicalize (H12AffineFastState.compose env40986 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound40986 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8202,16400,30776,1025,29005,17728,20529,20481,3,8193,65,10589,4097,16401,22884,1364,20528,257,33,4160,513]

theorem envBound40987 : H12AffineFastState.Bounded env40987 := by
  intro p hp
  have h : env40987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40986_40987 : H12AffineEnvironment.transform 14 29004 env40986 = env40987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env40986 == env40987) = true)

theorem identity40987 : scanCanonicalize (H12AffineFastState.compose env40987 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40987 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8202,4096,10280,1025,8541,5456,33,17,3,8193,65,10589,4097,4097,2420,1364,32,257,33,4160,513]

theorem envBound40988 : H12AffineFastState.Bounded env40988 := by
  intro p hp
  have h : env40988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40987_40988 : H12AffineEnvironment.transform 13 4112 env40987 = env40988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env40987 == env40988) = true)

theorem identity40988 : scanCanonicalize (H12AffineFastState.compose env40988 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound40988 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1305,4112,1093,1299,4096,3377,1025,1092,5456,33,17,3,1304,65,3140,4097,4097,2420,1364,32,257,33,4160,513]

theorem envBound40989 : H12AffineFastState.Bounded env40989 := by
  intro p hp
  have h : env40989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40988_40989 : H12AffineEnvironment.transform 12 1305 env40988 = env40989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env40988 == env40989) = true)

theorem identity40989 : scanCanonicalize (H12AffineFastState.compose env40989 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound40989 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,1305,2048,1093,1299,2064,3377,1025,1092,3392,33,17,3,1304,65,3140,2065,2065,2420,1364,32,257,33,2128,513]

theorem envBound40990 : H12AffineFastState.Bounded env40990 := by
  intro p hp
  have h : env40990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40989_40990 : H12AffineEnvironment.transform 11 2064 env40989 = env40990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env40989 == env40990) = true)

theorem identity40990 : scanCanonicalize (H12AffineFastState.compose env40990 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound40990 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40991 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,2064,349,2048,1,343,2064,2421,69,0,2308,33,17,3,348,65,2048,2065,2065,2420,272,32,257,33,2128,513]

theorem envBound40991 : H12AffineFastState.Bounded env40991 := by
  intro p hp
  have h : env40991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40990_40991 : H12AffineEnvironment.transform 9 68 env40990 = env40991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env40990 == env40991) = true)

theorem identity40991 : scanCanonicalize (H12AffineFastState.compose env40991 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound40991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40992 : List Nat := [2,4,8,16,32,64,9,256,512,68,545,561,349,545,1,343,561,852,69,0,805,33,17,3,348,65,545,560,560,853,272,32,257,33,625,513]

theorem envBound40992 : H12AffineFastState.Bounded env40992 := by
  intro p hp
  have h : env40992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40991_40992 : H12AffineEnvironment.transform 10 545 env40991 = env40992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env40991 == env40992) = true)

theorem identity40992 : scanCanonicalize (H12AffineFastState.compose env40992 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40992 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40993 : List Nat := [2,4,8,16,16,64,9,256,512,68,529,513,349,529,1,343,513,852,69,0,789,17,17,3,348,65,529,512,512,853,272,16,257,17,577,513]

theorem envBound40993 : H12AffineFastState.Bounded env40993 := by
  intro p hp
  have h : env40993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40992_40993 : H12AffineEnvironment.transform 4 16 env40992 = env40993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40992 == env40993) = true)

theorem identity40993 : scanCanonicalize (H12AffineFastState.compose env40993 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound40993 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env40994 : List Nat := [2,4,8,16,16,64,9,256,80,68,65,81,349,65,1,343,81,260,69,0,325,17,17,3,348,65,65,80,80,261,272,16,257,17,17,81]

theorem envBound40994 : H12AffineFastState.Bounded env40994 := by
  intro p hp
  have h : env40994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40993_40994 : H12AffineEnvironment.transform 8 80 env40993 = env40994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env40993 == env40994) = true)

theorem identity40994 : scanCanonicalize (H12AffineFastState.compose env40994 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40994 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40995 : List Nat := [2,4,8,0,0,64,9,256,64,68,65,65,333,65,1,327,65,260,69,0,325,1,1,3,332,65,65,64,64,261,256,0,257,1,1,65]

theorem envBound40995 : H12AffineFastState.Bounded env40995 := by
  intro p hp
  have h : env40995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40994_40995 : H12AffineEnvironment.transform 3 0 env40994 = env40995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40994 == env40995) = true)

theorem identity40995 : scanCanonicalize (H12AffineFastState.compose env40995 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound40995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40996 : List Nat := [2,4,8,0,0,0,9,256,0,4,1,1,269,1,1,263,1,260,5,0,261,1,1,3,268,1,1,0,0,261,256,0,257,1,1,1]

theorem envBound40996 : H12AffineFastState.Bounded env40996 := by
  intro p hp
  have h : env40996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40995_40996 : H12AffineEnvironment.transform 5 0 env40995 = env40996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40995 == env40996) = true)

def env40997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650854,2428275,10507600,8683536,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound40997 : H12AffineFastState.Bounded env40997 := by
  intro p hp
  have h : env40997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40980_40997 : H12AffineEnvironment.transform 16 16401 env40980 = env40997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40980 == env40997) = true)

theorem identity40997 : scanCanonicalize (H12AffineFastState.compose env40997 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound40997 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,8388608,3,8193,65,12650854,2196487,10507600,8391012,8487955,6382923,257,10601510,10560779,8430412]

theorem envBound40998 : H12AffineFastState.Bounded env40998 := by
  intro p hp
  have h : env40998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40997_40998 : H12AffineEnvironment.transform 17 35188 env40997 = env40998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env40997 == env40998) = true)

theorem identity40998 : scanCanonicalize (H12AffineFastState.compose env40998 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 98630) := by decide +kernel

theorem selectedBound40998 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,98630,3,8193,65,4229152,2196487,2216982,100386,1365,6382923,257,2114912,2139213,74250]

theorem envBound40999 : H12AffineFastState.Bounded env40999 := by
  intro p hp
  have h : env40999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40998_40999 : H12AffineEnvironment.transform 22 98630 env40998 = env40999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98630 env40998 == env40999) = true)

theorem identity40999 : scanCanonicalize (H12AffineFastState.compose env40999 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40999 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env41000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,4194304,41293,3,8193,65,4229152,2139148,2159645,43049,1365,6309184,257,2114912,2139213,513]

theorem envBound41000 : H12AffineFastState.Bounded env41000 := by
  intro p hp
  have h : env41000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40999_41000 : H12AffineEnvironment.transform 15 8203 env40999 = env41000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40999 == env41000) = true)

theorem identity41000 : scanCanonicalize (H12AffineFastState.compose env41000 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 61757) := by decide +kernel

theorem selectedBound41000 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env41001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,61757,41293,3,8193,65,31005,2139148,2159645,43049,1365,2143357,257,2114912,2139213,513]

theorem envBound41001 : H12AffineFastState.Bounded env41001 := by
  intro p hp
  have h : env41001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41000_41001 : H12AffineEnvironment.transform 21 61757 env41000 = env41001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61757 env41000 == env41001) = true)

theorem identity41001 : scanCanonicalize (H12AffineFastState.compose env41001 (packedSelected [0,7,11,17,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound41001 : packedSelected [0,7,11,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env41002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,17680,61757,41293,3,8193,65,31005,57628,45325,43049,1365,61805,257,112,57693,513]

theorem envBound41002 : H12AffineFastState.Bounded env41002 := by
  intro p hp
  have h : env41002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41001_41002 : H12AffineEnvironment.transform 20 17680 env41001 = env41002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env41001 == env41002) = true)

theorem identity41002 : scanCanonicalize (H12AffineFastState.compose env41002 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound41002 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30777,1025,29004,17680,112,20480,3,8193,65,31005,4177,16448,22884,1365,32,257,112,4112,513]

theorem envBound41003 : H12AffineFastState.Bounded env41003 := by
  intro p hp
  have h : env41003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41002_41003 : H12AffineEnvironment.transform 14 29005 env41002 = env41003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env41002 == env41003) = true)

theorem identity41003 : scanCanonicalize (H12AffineFastState.compose env41003 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41003 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41004 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,28956,8203,16401,30777,1025,28957,17680,33,20480,3,8193,16,31005,4096,16401,22837,1284,32,257,33,4112,513]

theorem envBound41004 : H12AffineFastState.Bounded env41004 := by
  intro p hp
  have h : env41004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41003_41004 : H12AffineEnvironment.transform 5 17 env41003 = env41004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41003 == env41004) = true)

theorem identity41004 : scanCanonicalize (H12AffineFastState.compose env41004 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound41004 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41005 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4113,8461,8203,4096,10280,1025,8460,5377,33,17,3,8193,16,10508,4096,4096,2340,1284,32,257,33,4112,513]

theorem envBound41005 : H12AffineFastState.Bounded env41005 := by
  intro p hp
  have h : env41005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41004_41005 : H12AffineEnvironment.transform 13 4113 env41004 = env41005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env41004 == env41005) = true)

theorem identity41005 : scanCanonicalize (H12AffineFastState.compose env41005 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41005 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41006 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,4113,8461,8203,4096,10280,273,8460,4113,33,17,3,8193,16,10508,4096,4096,2340,20,32,257,33,4112,513]

theorem envBound41006 : H12AffineFastState.Bounded env41006 := by
  intro p hp
  have h : env41006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41005_41006 : H12AffineEnvironment.transform 9 272 env41005 = env41006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41005 == env41006) = true)

theorem identity41006 : scanCanonicalize (H12AffineFastState.compose env41006 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41006 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41007 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,8192,4113,8232,8203,4096,10280,52,8233,4113,33,17,3,8193,16,10281,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound41007 : H12AffineFastState.Bounded env41007 := by
  intro p hp
  have h : env41007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41006_41007 : H12AffineEnvironment.transform 7 37 env41006 = env41007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41006 == env41007) = true)

theorem identity41007 : scanCanonicalize (H12AffineFastState.compose env41007 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound41007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41008 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,4105,4113,4129,4098,4096,6177,52,4128,4113,33,17,3,4104,16,6176,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound41008 : H12AffineFastState.Bounded env41008 := by
  intro p hp
  have h : env41008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41007_41008 : H12AffineEnvironment.transform 12 4105 env41007 = env41008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env41007 == env41008) = true)

theorem identity41008 : scanCanonicalize (H12AffineFastState.compose env41008 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound41008 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41009 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,4096,4105,4113,4129,4098,4096,4113,52,4128,4113,33,17,3,4104,16,4112,4096,4096,49,20,32,36,33,4112,513]

theorem envBound41009 : H12AffineFastState.Bounded env41009 := by
  intro p hp
  have h : env41009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41008_41009 : H12AffineEnvironment.transform 10 48 env41008 = env41009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env41008 == env41009) = true)

theorem identity41009 : scanCanonicalize (H12AffineFastState.compose env41009 (packedSelected [1,9] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound41009 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env41010 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,40,48,0,35,33,48,52,1,48,33,17,3,41,16,49,33,33,49,20,32,36,33,49,513]

theorem envBound41010 : H12AffineFastState.Bounded env41010 := by
  intro p hp
  have h : env41010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41009_41010 : H12AffineEnvironment.transform 11 33 env41009 = env41010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env41009 == env41010) = true)

def leafEnv41010 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,40,48,0,35,33,48,52,1,48,33,17,3,21,41,1,16,49,33,33,49,20,32,36,33,5,34,49,513,1,49,0]

def active41010 : List Nat := [0,1,2,3,4,8]

def tree41010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41010 : H12WitnessSearch.Good tree41010 := H12GlobalWitnessIndex.good

theorem leafIdentity41010 : H12AffineFastState.composeSystem env41010 rootObs = leafEnv41010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41010 rootObs == leafEnv41010) = true)

theorem terminalChecked41010 : H12PackedTerminal.terminalCheckFast leafEnv41010 active41010 tree41010 = true := by decide +kernel

def env41011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound41011 : H12AffineFastState.Bounded env41011 := by
  intro p hp
  have h : env41011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38092_41011 : H12AffineEnvironment.transform 31 145662401 env38092 = env41011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env38092 == env41011) = true)

def env41012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound41012 : H12AffineFastState.Bounded env41012 := by
  intro p hp
  have h : env41012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_41012 : H12AffineEnvironment.transform 29 155254784 env41011 = env41012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env41011 == env41012) = true)

def env41013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound41013 : H12AffineFastState.Bounded env41013 := by
  intro p hp
  have h : env41013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41012_41013 : H12AffineEnvironment.transform 25 64 env41012 = env41013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env41012 == env41013) = true)

def env41014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound41014 : H12AffineFastState.Bounded env41014 := by
  intro p hp
  have h : env41014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41013_41014 : H12AffineEnvironment.transform 26 30393344 env41013 = env41014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env41013 == env41014) = true)

def env41015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound41015 : H12AffineFastState.Bounded env41015 := by
  intro p hp
  have h : env41015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41014_41015 : H12AffineEnvironment.transform 18 1024 env41014 = env41015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env41014 == env41015) = true)

theorem identity41015 : scanCanonicalize (H12AffineFastState.compose env41015 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8429902) := by decide +kernel

theorem selectedBound41015 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8328,64,4677966,10560962,10507601,8830976,75103,14795919,256,2188771,2196550,649]

theorem envBound41016 : H12AffineFastState.Bounded env41016 := by
  intro p hp
  have h : env41016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41015_41016 : H12AffineEnvironment.transform 23 8429902 env41015 = env41016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429902 env41015 == env41016) = true)

def env41017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4677966,10560842,10507601,8830976,75103,14795783,256,2188651,2196550,513]

theorem envBound41017 : H12AffineFastState.Bounded env41017 := by
  intro p hp
  have h : env41017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41016_41017 : H12AffineEnvironment.transform 6 8 env41016 = env41017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41016 == env41017) = true)

def env41018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8192,64,4677966,2172250,2118977,442384,75103,6407191,256,2188651,2196550,513]

theorem envBound41018 : H12AffineFastState.Bounded env41018 := by
  intro p hp
  have h : env41018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41017_41018 : H12AffineEnvironment.transform 22 16 env41017 = env41018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env41017 == env41018) = true)

def env41019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677966,115014,45405,442384,75103,4268043,256,98679,90202,513]

theorem envBound41019 : H12AffineFastState.Bounded env41019 := by
  intro p hp
  have h : env41019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41018_41019 : H12AffineEnvironment.transform 20 58396 env41018 = env41019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env41018 == env41019) = true)

theorem identity41019 : scanCanonicalize (H12AffineFastState.compose env41019 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41019 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4604229,57677,45405,442384,1364,4194304,256,41340,16465,513]

theorem envBound41020 : H12AffineFastState.Bounded env41020 := by
  intro p hp
  have h : env41020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41019_41020 : H12AffineEnvironment.transform 15 8203 env41019 = env41020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41019 == env41020) = true)

theorem identity41020 : scanCanonicalize (H12AffineFastState.compose env41020 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound41020 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env41021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,419912,16,41310,8192,64,10509,57677,45405,442384,1364,419912,256,41340,16465,513]

theorem envBound41021 : H12AffineFastState.Bounded env41021 := by
  intro p hp
  have h : env41021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41020_41021 : H12AffineEnvironment.transform 21 419912 env41020 = env41021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env41020 == env41021) = true)

def env41022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58396,272392,16,41310,8192,64,10509,57677,45405,294992,1364,272392,256,41340,16465,513]

theorem envBound41022 : H12AffineFastState.Bounded env41022 := by
  intro p hp
  have h : env41022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41021_41022 : H12AffineEnvironment.transform 16 16448 env41021 = env41022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env41021 == env41022) = true)

def env41023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58396,272393,16,41310,8192,64,10509,57677,45405,294993,1364,272393,256,41340,16465,513]

theorem envBound41023 : H12AffineFastState.Bounded env41023 := by
  intro p hp
  have h : env41023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41021_41023 : H12AffineEnvironment.transform 16 16449 env41021 = env41023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env41021 == env41023) = true)

theorem identity41023 : scanCanonicalize (H12AffineFastState.compose env41023 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41023 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16449,262144,1024,32769,50449,264452,16,32851,269,64,2048,49216,36944,294993,1364,264452,256,32881,16465,513]

theorem envBound41024 : H12AffineFastState.Bounded env41024 := by
  intro p hp
  have h : env41024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41023_41024 : H12AffineEnvironment.transform 12 269 env41023 = env41024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41023 == env41024) = true)

theorem identity41024 : scanCanonicalize (H12AffineFastState.compose env41024 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound41024 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env41025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16449,35109,1024,32769,50449,32801,16,32851,269,64,2048,49216,36944,2420,1364,32801,256,32881,16465,513]

theorem envBound41025 : H12AffineFastState.Bounded env41025 := by
  intro p hp
  have h : env41025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41024_41025 : H12AffineEnvironment.transform 17 35109 env41024 = env41025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env41024 == env41025) = true)

theorem identity41025 : scanCanonicalize (H12AffineFastState.compose env41025 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41025 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env41026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,262,16449,2341,1024,1,17681,33,16,83,269,64,2048,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound41026 : H12AffineFastState.Bounded env41026 := by
  intro p hp
  have h : env41026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41025_41026 : H12AffineEnvironment.transform 14 0 env41025 = env41026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41025 == env41026) = true)

theorem identity41026 : scanCanonicalize (H12AffineFastState.compose env41026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41027 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1024,1,17681,33,16,2,269,17,2048,16401,4097,2341,1285,33,256,32,16384,513]

theorem envBound41027 : H12AffineFastState.Bounded env41027 := by
  intro p hp
  have h : env41027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41026_41027 : H12AffineEnvironment.transform 5 17 env41026 = env41027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41026 == env41027) = true)

theorem identity41027 : scanCanonicalize (H12AffineFastState.compose env41027 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41027 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41028 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,0,262,5172,2341,1024,1,4405,33,16,2,269,17,2048,5173,4097,2341,1285,33,256,32,5156,513]

theorem envBound41028 : H12AffineFastState.Bounded env41028 := by
  intro p hp
  have h : env41028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41027_41028 : H12AffineEnvironment.transform 13 5156 env41027 = env41028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41027 == env41028) = true)

def env41029 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2836,0,262,2820,2341,1024,1,3589,33,16,2,269,17,2048,2821,3889,2341,1285,33,256,32,2836,513]

theorem envBound41029 : H12AffineFastState.Bounded env41029 := by
  intro p hp
  have h : env41029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41028_41029 : H12AffineEnvironment.transform 11 3888 env41028 = env41029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env41028 == env41029) = true)

def env41030 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1044,0,262,1028,1573,1024,1,261,33,16,2,269,17,1792,1029,49,1573,1285,33,256,32,1044,513]

theorem envBound41030 : H12AffineFastState.Bounded env41030 := by
  intro p hp
  have h : env41030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41029_41030 : H12AffineEnvironment.transform 10 1792 env41029 = env41030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41029 == env41030) = true)

theorem identity41030 : scanCanonicalize (H12AffineFastState.compose env41030 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound41030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41031 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1077,48,269,1044,0,262,1028,1296,1024,1,261,33,16,2,269,17,1077,1029,49,1296,1285,33,256,32,1044,308]

theorem envBound41031 : H12AffineFastState.Bounded env41031 := by
  intro p hp
  have h : env41031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41030_41031 : H12AffineEnvironment.transform 8 309 env41030 = env41031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41030 == env41031) = true)

def env41032 : List Nat := [2,4,8,16,32,17,8,256,309,52,1,48,269,32,0,262,48,292,52,1,261,33,16,2,269,17,1,49,49,292,305,33,256,32,32,308]

theorem envBound41032 : H12AffineFastState.Bounded env41032 := by
  intro p hp
  have h : env41032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41031_41032 : H12AffineEnvironment.transform 9 52 env41031 = env41032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41031 == env41032) = true)

theorem identity41032 : scanCanonicalize (H12AffineFastState.compose env41032 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41033 : List Nat := [2,4,8,16,0,17,8,256,277,20,1,16,269,0,0,262,16,260,20,1,261,1,16,2,269,17,1,17,17,260,273,1,256,0,0,276]

theorem envBound41033 : H12AffineFastState.Bounded env41033 := by
  intro p hp
  have h : env41033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41032_41033 : H12AffineEnvironment.transform 4 0 env41032 = env41033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41032 == env41033) = true)

def leafEnv41033 : List Nat := [2,4,8,16,0,17,8,256,277,20,1,16,269,0,0,262,16,260,20,1,261,1,16,2,273,269,1,17,1,17,17,260,273,1,256,0,4,262,0,276,1,261,0]

def active41033 : List Nat := [0,1,2,3,7]

def tree41033 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41033 : H12WitnessSearch.Good tree41033 := H12GlobalWitnessIndex.good

theorem leafIdentity41033 : H12AffineFastState.composeSystem env41033 rootObs = leafEnv41033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41033 rootObs == leafEnv41033) = true)

theorem terminalChecked41033 : H12PackedTerminal.terminalCheckFast leafEnv41033 active41033 tree41033 = true := by decide +kernel

def env41034 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,269,33,0,262,49,293,53,1,261,33,16,2,269,17,0,48,49,293,304,33,256,32,33,308]

theorem envBound41034 : H12AffineFastState.Bounded env41034 := by
  intro p hp
  have h : env41034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41031_41034 : H12AffineEnvironment.transform 9 53 env41031 = env41034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41031 == env41034) = true)

theorem identity41034 : scanCanonicalize (H12AffineFastState.compose env41034 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41035 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,269,33,0,262,42,293,46,1,261,33,11,2,269,10,0,43,42,293,299,33,256,32,33,303]

theorem envBound41035 : H12AffineFastState.Bounded env41035 := by
  intro p hp
  have h : env41035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41034_41035 : H12AffineEnvironment.transform 3 11 env41034 = env41035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41034 == env41035) = true)

def leafEnv41035 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,269,33,0,262,42,293,46,1,261,33,11,2,299,269,1,10,0,43,42,293,299,33,256,32,4,262,33,303,1,261,0]

def active41035 : List Nat := [0,1,2,4,7]

def tree41035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41035 : H12WitnessSearch.Good tree41035 := H12GlobalWitnessIndex.good

theorem leafIdentity41035 : H12AffineFastState.composeSystem env41035 rootObs = leafEnv41035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41035 rootObs == leafEnv41035) = true)

theorem terminalChecked41035 : H12PackedTerminal.terminalCheckFast leafEnv41035 active41035 tree41035 = true := by decide +kernel

def env41036 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1045,0,262,1029,1572,1024,1,260,33,16,2,269,17,1793,1028,48,1572,1285,33,256,32,1045,513]

theorem envBound41036 : H12AffineFastState.Bounded env41036 := by
  intro p hp
  have h : env41036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41029_41036 : H12AffineEnvironment.transform 10 1793 env41029 = env41036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41029 == env41036) = true)

theorem identity41036 : scanCanonicalize (H12AffineFastState.compose env41036 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound41036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41037 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,49,269,561,0,262,545,0,548,1,260,33,16,2,269,17,293,544,48,0,801,33,256,32,561,513]

theorem envBound41037 : H12AffineFastState.Bounded env41037 := by
  intro p hp
  have h : env41037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41036_41037 : H12AffineEnvironment.transform 9 548 env41036 = env41037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env41036 == env41037) = true)

def env41038 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,269,33,0,262,49,0,52,1,260,33,16,2,269,17,293,48,48,0,305,33,256,32,33,17]

theorem envBound41038 : H12AffineFastState.Bounded env41038 := by
  intro p hp
  have h : env41038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41037_41038 : H12AffineEnvironment.transform 8 16 env41037 = env41038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41037 == env41038) = true)

theorem identity41038 : scanCanonicalize (H12AffineFastState.compose env41038 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41038 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41039 : List Nat := [2,4,8,16,32,17,8,5,16,52,32,49,8,33,0,3,49,0,52,1,1,33,16,2,8,17,32,48,48,0,52,33,5,32,33,17]

theorem envBound41039 : H12AffineFastState.Bounded env41039 := by
  intro p hp
  have h : env41039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41038_41039 : H12AffineEnvironment.transform 7 5 env41038 = env41039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41038 == env41039) = true)

def leafEnv41039 : List Nat := [2,4,8,16,32,17,8,5,16,52,32,49,8,33,0,3,49,0,52,1,1,33,16,2,52,8,1,17,32,48,48,0,52,33,5,32,4,3,33,17,1,1,0]

def active41039 : List Nat := [0,1,2,3,4]

def tree41039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41039 : H12WitnessSearch.Good tree41039 := H12GlobalWitnessIndex.good

theorem leafIdentity41039 : H12AffineFastState.composeSystem env41039 rootObs = leafEnv41039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41039 rootObs == leafEnv41039) = true)

theorem terminalChecked41039 : H12PackedTerminal.terminalCheckFast leafEnv41039 active41039 tree41039 = true := by decide +kernel

def env41040 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,49,269,32,0,262,48,0,53,1,260,33,16,2,269,17,293,49,48,0,304,33,256,32,32,16]

theorem envBound41040 : H12AffineFastState.Bounded env41040 := by
  intro p hp
  have h : env41040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41037_41040 : H12AffineEnvironment.transform 8 17 env41037 = env41040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41037 == env41040) = true)

theorem identity41040 : scanCanonicalize (H12AffineFastState.compose env41040 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41041 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,269,32,0,262,42,0,47,1,260,33,10,2,269,11,293,43,42,0,298,33,256,32,32,10]

theorem envBound41041 : H12AffineFastState.Bounded env41041 := by
  intro p hp
  have h : env41041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41040_41041 : H12AffineEnvironment.transform 3 10 env41040 = env41041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41040 == env41041) = true)

def leafEnv41041 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,269,32,0,262,42,0,47,1,260,33,10,2,298,269,1,11,293,43,42,0,298,33,256,32,4,262,32,10,1,260,0]

def active41041 : List Nat := [0,1,2,4,7]

def tree41041 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41041 : H12WitnessSearch.Good tree41041 := H12GlobalWitnessIndex.good

theorem leafIdentity41041 : H12AffineFastState.composeSystem env41041 rootObs = leafEnv41041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41041 rootObs == leafEnv41041) = true)

theorem terminalChecked41041 : H12PackedTerminal.terminalCheckFast leafEnv41041 active41041 tree41041 = true := by decide +kernel

def env41042 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2837,0,262,2821,2341,1024,1,3588,33,16,2,269,17,2048,2820,3888,2341,1285,33,256,32,2837,513]

theorem envBound41042 : H12AffineFastState.Bounded env41042 := by
  intro p hp
  have h : env41042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41028_41042 : H12AffineEnvironment.transform 11 3889 env41028 = env41042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env41028 == env41042) = true)

def env41043 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1045,0,262,1029,1573,1024,1,260,33,16,2,269,17,1792,1028,48,1573,1285,33,256,32,1045,513]

theorem envBound41043 : H12AffineFastState.Bounded env41043 := by
  intro p hp
  have h : env41043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41042_41043 : H12AffineEnvironment.transform 10 1792 env41042 = env41043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41042 == env41043) = true)

theorem identity41043 : scanCanonicalize (H12AffineFastState.compose env41043 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound41043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41044 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,49,269,789,0,262,773,293,768,1,260,33,16,2,269,17,0,772,48,293,517,33,256,32,789,513]

theorem envBound41044 : H12AffineFastState.Bounded env41044 := by
  intro p hp
  have h : env41044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41043_41044 : H12AffineEnvironment.transform 9 768 env41043 = env41044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env41043 == env41044) = true)

def env41045 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,269,33,0,262,49,293,52,1,260,33,16,2,269,17,0,48,48,293,305,33,256,32,33,309]

theorem envBound41045 : H12AffineFastState.Bounded env41045 := by
  intro p hp
  have h : env41045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41044_41045 : H12AffineEnvironment.transform 8 308 env41044 = env41045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env41044 == env41045) = true)

theorem identity41045 : scanCanonicalize (H12AffineFastState.compose env41045 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41046 : List Nat := [2,4,8,16,0,17,8,256,276,20,0,17,269,1,0,262,17,261,20,1,260,1,16,2,269,17,0,16,16,261,273,1,256,0,1,277]

theorem envBound41046 : H12AffineFastState.Bounded env41046 := by
  intro p hp
  have h : env41046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41045_41046 : H12AffineEnvironment.transform 4 0 env41045 = env41046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41045 == env41046) = true)

def leafEnv41046 : List Nat := [2,4,8,16,0,17,8,256,276,20,0,17,269,1,0,262,17,261,20,1,260,1,16,2,273,269,1,17,0,16,16,261,273,1,256,0,4,262,1,277,1,260,0]

def active41046 : List Nat := [0,1,2,3,7]

def tree41046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41046 : H12WitnessSearch.Good tree41046 := H12GlobalWitnessIndex.good

theorem leafIdentity41046 : H12AffineFastState.composeSystem env41046 rootObs = leafEnv41046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41046 rootObs == leafEnv41046) = true)

theorem terminalChecked41046 : H12PackedTerminal.terminalCheckFast leafEnv41046 active41046 tree41046 = true := by decide +kernel

def env41047 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,49,269,32,0,262,48,293,53,1,260,33,16,2,269,17,0,49,48,293,304,33,256,32,32,308]

theorem envBound41047 : H12AffineFastState.Bounded env41047 := by
  intro p hp
  have h : env41047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41044_41047 : H12AffineEnvironment.transform 8 309 env41044 = env41047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41044 == env41047) = true)

theorem identity41047 : scanCanonicalize (H12AffineFastState.compose env41047 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41047 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41048 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,269,32,0,262,43,293,46,1,260,33,11,2,269,10,0,42,43,293,299,33,256,32,32,303]

theorem envBound41048 : H12AffineFastState.Bounded env41048 := by
  intro p hp
  have h : env41048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41047_41048 : H12AffineEnvironment.transform 3 11 env41047 = env41048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41047 == env41048) = true)

def leafEnv41048 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,269,32,0,262,43,293,46,1,260,33,11,2,299,269,1,10,0,42,43,293,299,33,256,32,4,262,32,303,1,260,0]

def active41048 : List Nat := [0,1,2,4,7]

def tree41048 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41048 : H12WitnessSearch.Good tree41048 := H12GlobalWitnessIndex.good

theorem leafIdentity41048 : H12AffineFastState.composeSystem env41048 rootObs = leafEnv41048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41048 rootObs == leafEnv41048) = true)

theorem terminalChecked41048 : H12PackedTerminal.terminalCheckFast leafEnv41048 active41048 tree41048 = true := by decide +kernel

def env41049 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1044,0,262,1028,1572,1024,1,261,33,16,2,269,17,1793,1029,49,1572,1285,33,256,32,1044,513]

theorem envBound41049 : H12AffineFastState.Bounded env41049 := by
  intro p hp
  have h : env41049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41042_41049 : H12AffineEnvironment.transform 10 1793 env41042 = env41049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41042 == env41049) = true)

theorem identity41049 : scanCanonicalize (H12AffineFastState.compose env41049 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41050 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1296,48,269,1044,0,262,1028,1077,1024,1,261,33,16,2,269,17,1296,1029,49,1077,1285,33,256,32,1044,16]

theorem envBound41050 : H12AffineFastState.Bounded env41050 := by
  intro p hp
  have h : env41050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41049_41050 : H12AffineEnvironment.transform 8 17 env41049 = env41050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41049 == env41050) = true)

def env41051 : List Nat := [2,4,8,16,32,17,8,256,17,52,292,48,269,32,0,262,48,1,52,1,261,33,16,2,269,17,292,49,49,1,305,33,256,32,32,16]

theorem envBound41051 : H12AffineFastState.Bounded env41051 := by
  intro p hp
  have h : env41051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41050_41051 : H12AffineEnvironment.transform 9 52 env41050 = env41051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41050 == env41051) = true)

theorem identity41051 : scanCanonicalize (H12AffineFastState.compose env41051 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41052 : List Nat := [2,4,8,16,32,17,8,5,17,52,33,48,8,32,0,3,48,1,52,1,0,33,16,2,8,17,33,49,49,1,52,33,5,32,32,16]

theorem envBound41052 : H12AffineFastState.Bounded env41052 := by
  intro p hp
  have h : env41052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41051_41052 : H12AffineEnvironment.transform 7 5 env41051 = env41052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41051 == env41052) = true)

def leafEnv41052 : List Nat := [2,4,8,16,32,17,8,5,17,52,33,48,8,32,0,3,48,1,52,1,0,33,16,2,52,8,1,17,33,49,49,1,52,33,5,32,4,3,32,16,1,0,0]

def active41052 : List Nat := [0,1,2,3,4]

def tree41052 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41052 : H12WitnessSearch.Good tree41052 := H12GlobalWitnessIndex.good

theorem leafIdentity41052 : H12AffineFastState.composeSystem env41052 rootObs = leafEnv41052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41052 rootObs == leafEnv41052) = true)

theorem terminalChecked41052 : H12PackedTerminal.terminalCheckFast leafEnv41052 active41052 tree41052 = true := by decide +kernel

def env41053 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,269,33,0,262,49,0,53,1,261,33,16,2,269,17,293,48,49,0,304,33,256,32,33,16]

theorem envBound41053 : H12AffineFastState.Bounded env41053 := by
  intro p hp
  have h : env41053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41050_41053 : H12AffineEnvironment.transform 9 53 env41050 = env41053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41050 == env41053) = true)

theorem identity41053 : scanCanonicalize (H12AffineFastState.compose env41053 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41054 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,269,33,0,262,43,0,47,1,261,33,10,2,269,11,293,42,43,0,298,33,256,32,33,10]

theorem envBound41054 : H12AffineFastState.Bounded env41054 := by
  intro p hp
  have h : env41054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41053_41054 : H12AffineEnvironment.transform 3 10 env41053 = env41054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41053 == env41054) = true)

def leafEnv41054 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,269,33,0,262,43,0,47,1,261,33,10,2,298,269,1,11,293,42,43,0,298,33,256,32,4,262,33,10,1,261,0]

def active41054 : List Nat := [0,1,2,4,7]

def tree41054 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41054 : H12WitnessSearch.Good tree41054 := H12GlobalWitnessIndex.good

theorem leafIdentity41054 : H12AffineFastState.composeSystem env41054 rootObs = leafEnv41054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41054 rootObs == leafEnv41054) = true)

theorem terminalChecked41054 : H12PackedTerminal.terminalCheckFast leafEnv41054 active41054 tree41054 = true := by decide +kernel

def env41055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8192,64,4677966,115015,45404,442384,75103,4268042,256,98678,90203,513]

theorem envBound41055 : H12AffineFastState.Bounded env41055 := by
  intro p hp
  have h : env41055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41018_41055 : H12AffineEnvironment.transform 20 58397 env41018 = env41055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env41018 == env41055) = true)

def env41056 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8192,16,4677918,114967,45324,442384,75023,4268042,256,98598,90123,513]

theorem envBound41056 : H12AffineFastState.Bounded env41056 := by
  intro p hp
  have h : env41056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41055_41056 : H12AffineEnvironment.transform 5 16 env41055 = env41056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41055 == env41056) = true)

def env41057 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8192,16,4409654,114967,45324,190520,75023,4268042,256,98598,90123,513]

theorem envBound41057 : H12AffineFastState.Bounded env41057 := by
  intro p hp
  have h : env41057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41056_41057 : H12AffineEnvironment.transform 17 10280 env41056 = env41057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41056 == env41057) = true)

theorem identity41057 : scanCanonicalize (H12AffineFastState.compose env41057 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound41057 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env41058 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,65830,16,41230,8192,16,149520,114967,45324,190520,75023,8492,256,98598,90123,513]

theorem envBound41058 : H12AffineFastState.Bounded env41058 := by
  intro p hp
  have h : env41058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41057_41058 : H12AffineEnvironment.transform 21 65830 env41057 = env41058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env41057 == env41058) = true)

theorem identity41058 : scanCanonicalize (H12AffineFastState.compose env41058 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound41058 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env41059 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1024,32769,58397,65830,16,41230,8192,16,108554,114967,45324,67618,75023,8492,256,98598,90123,513]

theorem envBound41059 : H12AffineFastState.Bounded env41059 := by
  intro p hp
  have h : env41059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41058_41059 : H12AffineEnvironment.transform 16 122906 env41058 = env41059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env41058 == env41059) = true)

theorem identity41059 : scanCanonicalize (H12AffineFastState.compose env41059 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound41059 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41060 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1024,32769,58397,41261,16,41230,8192,16,2049,24860,45324,43049,34052,8492,256,8493,49152,513]

theorem envBound41060 : H12AffineFastState.Bounded env41060 := by
  intro p hp
  have h : env41060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41059_41060 : H12AffineEnvironment.transform 15 40971 env41059 = env41060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env41059 == env41060) = true)

theorem identity41060 : scanCanonicalize (H12AffineFastState.compose env41060 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41060 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env41061 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,8202,16401,10280,1024,0,25628,8492,16,8463,8192,16,2049,24860,12557,10280,1285,8492,256,8493,16385,513]

theorem envBound41061 : H12AffineFastState.Bounded env41061 := by
  intro p hp
  have h : env41061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41060_41061 : H12AffineEnvironment.transform 14 1 env41060 = env41061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41060 == env41061) = true)

def env41062 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8192,16,4409655,114967,45324,190521,75023,4268042,256,98598,90123,513]

theorem envBound41062 : H12AffineFastState.Bounded env41062 := by
  intro p hp
  have h : env41062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41056_41062 : H12AffineEnvironment.transform 17 10281 env41056 = env41062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41056 == env41062) = true)

theorem identity41062 : scanCanonicalize (H12AffineFastState.compose env41062 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound41062 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env41063 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,199939,16,41230,8192,16,17460,114967,45324,190521,75023,142601,256,98598,90123,513]

theorem envBound41063 : H12AffineFastState.Bounded env41063 := by
  intro p hp
  have h : env41063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41062_41063 : H12AffineEnvironment.transform 21 199939 env41062 = env41063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env41062 == env41063) = true)

theorem identity41063 : scanCanonicalize (H12AffineFastState.compose env41063 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41063 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env41064 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,58397,27928,16,41230,8192,16,17460,114967,45324,100386,75023,85266,256,98598,90123,513]

theorem envBound41064 : H12AffineFastState.Bounded env41064 := by
  intro p hp
  have h : env41064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41063_41064 : H12AffineEnvironment.transform 16 90139 env41063 = env41064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41063 == env41064) = true)

theorem identity41064 : scanCanonicalize (H12AffineFastState.compose env41064 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound41064 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41065 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,32768,65536,84999,1077,1024,32769,51201,16644,16,36114,3100,16,17460,114967,40208,100386,67859,85266,256,98598,85015,513]

theorem envBound41065 : H12AffineFastState.Bounded env41065 := by
  intro p hp
  have h : env41065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41064_41065 : H12AffineEnvironment.transform 12 3100 env41064 = env41065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env41064 == env41065) = true)

theorem identity41065 : scanCanonicalize (H12AffineFastState.compose env41065 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 3094) := by decide +kernel

theorem selectedBound41065 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0