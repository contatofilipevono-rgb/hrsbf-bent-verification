import H12CloudChart0Data204

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound51903 : H12AffineFastState.Bounded env51903 := by
  intro p hp
  have h : env51903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51902_51903 : H12AffineEnvironment.transform 17 223599 env51902 = env51903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env51902 == env51903) = true)

theorem identity51903 : scanCanonicalize (H12AffineFastState.compose env51903 (packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound51903 : packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90187,2340,1025,29788,69958,8492,65815,95496,8192,64,2048,70679,17664,23589,66643,73770,257,21793,16465,8972]

theorem envBound51904 : H12AffineFastState.Bounded env51904 := by
  intro p hp
  have h : env51904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51903_51904 : H12AffineEnvironment.transform 16 90187 env51903 = env51904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env51903 == env51904) = true)

theorem identity51904 : scanCanonicalize (H12AffineFastState.compose env51904 (packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51904 : packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51905 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,90139,2340,1025,29708,69910,8492,65815,95496,8192,16,2048,70679,17664,23589,66563,73770,257,21793,16385,8972]

theorem envBound51905 : H12AffineFastState.Bounded env51905 := by
  intro p hp
  have h : env51905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51904_51905 : H12AffineEnvironment.transform 5 16 env51904 = env51905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51904 == env51905) = true)

theorem identity51905 : scanCanonicalize (H12AffineFastState.compose env51905 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound51905 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env51906 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,29962,5393,2340,1025,29708,25628,8492,29725,2,8192,16,2048,24861,17664,23589,28937,21792,257,21793,16385,8972]

theorem envBound51906 : H12AffineFastState.Bounded env51906 := by
  intro p hp
  have h : env51906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51905_51906 : H12AffineEnvironment.transform 15 29962 env51905 = env51906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env51905 == env51906) = true)

theorem identity51906 : scanCanonicalize (H12AffineFastState.compose env51906 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51906 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env51907 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,5393,2340,1025,8461,12573,8492,8476,2,8192,16,2048,13340,4097,2340,9224,33,257,32,5376,8972]

theorem envBound51907 : H12AffineFastState.Bounded env51907 := by
  intro p hp
  have h : env51907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51906_51907 : H12AffineEnvironment.transform 13 5377 env51906 = env51907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51906 == env51907) = true)

theorem identity51907 : scanCanonicalize (H12AffineFastState.compose env51907 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51907 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51908 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,292,35,5393,2340,1025,293,4405,260,308,2,40,16,2048,5172,4097,2340,1056,33,257,32,5376,804]

theorem envBound51908 : H12AffineFastState.Bounded env51908 := by
  intro p hp
  have h : env51908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51907_51908 : H12AffineEnvironment.transform 12 40 env51907 = env51908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51907 == env51908) = true)

theorem identity51908 : scanCanonicalize (H12AffineFastState.compose env51908 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51908 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51909 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5173,2048,1025,1,4113,32,16,2,40,16,2048,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound51909 : H12AffineFastState.Bounded env51909 := by
  intro p hp
  have h : env51909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51908_51909 : H12AffineEnvironment.transform 7 36 env51908 = env51909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51908 == env51909) = true)

theorem identity51909 : scanCanonicalize (H12AffineFastState.compose env51909 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51909 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51910 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,0,3,5141,2048,1025,1,4113,0,16,2,8,16,2048,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound51910 : H12AffineFastState.Bounded env51910 := by
  intro p hp
  have h : env51910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51909_51910 : H12AffineEnvironment.transform 4 0 env51909 = env51910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51909 == env51910) = true)

theorem identity51910 : scanCanonicalize (H12AffineFastState.compose env51910 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound51910 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51911 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,3076,8,2049,0,3,2065,2048,1025,1,3093,0,16,2,8,16,2048,2064,3077,2048,1024,1,5,0,2048,512]

theorem envBound51911 : H12AffineFastState.Bounded env51911 := by
  intro p hp
  have h : env51911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51910_51911 : H12AffineEnvironment.transform 11 3076 env51910 = env51911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env51910 == env51911) = true)

theorem identity51911 : scanCanonicalize (H12AffineFastState.compose env51911 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51911 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51912 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2064,8,2049,0,3,2065,2048,21,1,2049,0,16,2,8,16,2048,2064,2065,2048,20,1,5,0,2048,512]

theorem envBound51912 : H12AffineFastState.Bounded env51912 := by
  intro p hp
  have h : env51912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51911_51912 : H12AffineEnvironment.transform 9 20 env51911 = env51912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51911 == env51912) = true)

theorem identity51912 : scanCanonicalize (H12AffineFastState.compose env51912 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound51912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51913 : List Nat := [2,4,8,16,0,16,8,4,512,20,4,20,8,5,0,3,21,4,21,1,5,0,16,2,8,16,4,20,21,4,20,1,5,0,4,512]

theorem envBound51913 : H12AffineFastState.Bounded env51913 := by
  intro p hp
  have h : env51913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51912_51913 : H12AffineEnvironment.transform 10 4 env51912 = env51913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env51912 == env51913) = true)

def env51914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272393,155996,95496,8193,64,2048,160860,17664,283904,156697,411973,257,21793,16465,213831]

theorem envBound51914 : H12AffineFastState.Bounded env51914 := by
  intro p hp
  have h : env51914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51901_51914 : H12AffineEnvironment.transform 6 9 env51901 = env51914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51901 == env51914) = true)

theorem identity51914 : scanCanonicalize (H12AffineFastState.compose env51914 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound51914 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env51915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,157752,1025,29789,160013,147505,155996,95496,8193,64,2048,160860,17664,146744,156697,8573,257,21793,16465,213831]

theorem envBound51915 : H12AffineFastState.Bounded env51915 := by
  intro p hp
  have h : env51915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51914_51915 : H12AffineEnvironment.transform 17 157752 env51914 = env51915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env51914 == env51915) = true)

theorem identity51915 : scanCanonicalize (H12AffineFastState.compose env51915 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51915 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env51916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5393,32041,1025,29789,25628,21792,29773,95496,8193,64,2048,24909,17664,10281,28936,8573,257,21793,16465,87638]

theorem envBound51916 : H12AffineFastState.Bounded env51916 := by
  intro p hp
  have h : env51916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51915_51916 : H12AffineEnvironment.transform 16 5393 env51915 = env51916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51915 == env51916) = true)

theorem identity51916 : scanCanonicalize (H12AffineFastState.compose env51916 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51916 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,5393,23669,1025,21761,17728,21792,21777,87124,349,64,2048,16401,17664,2421,20564,33,257,21793,16465,87638]

theorem envBound51917 : H12AffineFastState.Bounded env51917 := by
  intro p hp
  have h : env51917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51916_51917 : H12AffineEnvironment.transform 12 348 env51916 = env51917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51916 == env51917) = true)

theorem identity51917 : scanCanonicalize (H12AffineFastState.compose env51917 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound51917 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,34,5393,23669,1025,21761,17728,21792,21777,21622,349,64,2048,16401,17664,2421,20564,33,257,21793,16465,22132]

theorem envBound51918 : H12AffineFastState.Bounded env51918 := by
  intro p hp
  have h : env51918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51917_51918 : H12AffineEnvironment.transform 15 34 env51917 = env51918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env51917 == env51918) = true)

theorem identity51918 : scanCanonicalize (H12AffineFastState.compose env51918 (packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51918 : packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS < 2^1333 := by decide +kernel

def env51919 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,34,5393,23589,1025,21761,17680,21792,21777,21542,269,16,2048,16401,17664,2341,20484,33,257,21793,16385,22052]

theorem envBound51919 : H12AffineFastState.Bounded env51919 := by
  intro p hp
  have h : env51919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51918_51919 : H12AffineEnvironment.transform 5 16 env51918 = env51919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51918 == env51919) = true)

theorem identity51919 : scanCanonicalize (H12AffineFastState.compose env51919 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound51919 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env51920 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,292,34,5393,2049,1025,293,4404,260,309,2,269,16,2048,5173,4388,2341,1056,33,257,261,5157,512]

theorem envBound51920 : H12AffineFastState.Bounded env51920 := by
  intro p hp
  have h : env51920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51919_51920 : H12AffineEnvironment.transform 13 5156 env51919 = env51920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env51919 == env51920) = true)

theorem identity51920 : scanCanonicalize (H12AffineFastState.compose env51920 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51921 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5156,32,34,5141,2049,1025,33,4144,0,49,2,9,16,2048,5173,4128,2081,1056,33,5,1,5157,512]

theorem envBound51921 : H12AffineFastState.Bounded env51921 := by
  intro p hp
  have h : env51921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51920_51921 : H12AffineEnvironment.transform 7 4 env51920 = env51921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51920 == env51921) = true)

theorem identity51921 : scanCanonicalize (H12AffineFastState.compose env51921 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51921 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51922 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1029,8,33,32,34,16,2049,1025,33,1077,0,49,2,9,16,2048,48,1061,2081,1056,33,5,1,32,512]

theorem envBound51922 : H12AffineFastState.Bounded env51922 := by
  intro p hp
  have h : env51922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51921_51922 : H12AffineEnvironment.transform 11 1029 env51921 = env51922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env51921 == env51922) = true)

theorem identity51922 : scanCanonicalize (H12AffineFastState.compose env51922 (packedSelected [2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51922 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env51923 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,1029,8,1,0,2,16,2049,1025,1,1045,0,17,2,9,16,2048,16,1029,2049,1024,1,5,1,0,512]

theorem envBound51923 : H12AffineFastState.Bounded env51923 := by
  intro p hp
  have h : env51923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51922_51923 : H12AffineEnvironment.transform 4 0 env51922 = env51923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51922 == env51923) = true)

def env51924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169353,98781,8328,64,64724,163977,17664,284041,168005,411972,257,21793,46212,243602]

theorem envBound51924 : H12AffineFastState.Bounded env51924 := by
  intro p hp
  have h : env51924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51899_51924 : H12AffineEnvironment.transform 21 272513 env51899 = env51924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51899 == env51924) = true)

theorem identity51924 : scanCanonicalize (H12AffineFastState.compose env51924 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound51924 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,58517,272513,62660,98781,8328,64,64724,57796,17664,284041,61704,272393,257,21793,46212,120543]

theorem envBound51925 : H12AffineFastState.Bounded env51925 := by
  intro p hp
  have h : env51925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51924_51925 : H12AffineEnvironment.transform 16 24909 env51924 = env51925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env51924 == env51925) = true)

def env51926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,58517,169,62660,98781,8328,64,64724,57796,17664,32161,61704,33,257,21793,46212,120543]

theorem envBound51926 : H12AffineFastState.Bounded env51926 := by
  intro p hp
  have h : env51926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51925_51926 : H12AffineEnvironment.transform 17 10280 env51925 = env51926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51925 == env51926) = true)

theorem identity51926 : scanCanonicalize (H12AffineFastState.compose env51926 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29159) := by decide +kernel

theorem selectedBound51926 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29159,24909,10280,1025,32769,58517,169,62660,61498,8328,64,64724,57796,17664,32161,61704,33,257,21793,46212,42808]

theorem envBound51927 : H12AffineFastState.Bounded env51927 := by
  intro p hp
  have h : env51927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51926_51927 : H12AffineEnvironment.transform 15 29159 env51926 = env51927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29159 env51926 == env51927) = true)

theorem identity51927 : scanCanonicalize (H12AffineFastState.compose env51927 (packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound51927 : packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env51928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,16384,32768,21510,17580,3529,1025,32769,49524,169,53541,54747,1385,64,55605,50213,17664,22592,54505,33,257,21793,37221,33497]

theorem envBound51928 : H12AffineFastState.Bounded env51928 := by
  intro p hp
  have h : env51928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51927_51928 : H12AffineEnvironment.transform 12 1505 env51927 = env51928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env51927 == env51928) = true)

theorem identity51928 : scanCanonicalize (H12AffineFastState.compose env51928 (packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound51928 : packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env51929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,4540,32768,1466,5392,3529,1025,32769,37064,169,32921,33895,1385,64,34953,38297,5308,2556,34133,33,257,1181,37221,33497]

theorem envBound51929 : H12AffineFastState.Bounded env51929 := by
  intro p hp
  have h : env51929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51928_51929 : H12AffineEnvironment.transform 13 4540 env51928 = env51929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env51928 == env51929) = true)

theorem identity51929 : scanCanonicalize (H12AffineFastState.compose env51929 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound51929 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51930 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,268,4540,32768,343,4605,2340,236,32769,37064,169,32921,32906,388,64,34953,37236,4177,2556,33208,33,257,112,37221,33497]

theorem envBound51930 : H12AffineFastState.Bounded env51930 := by
  intro p hp
  have h : env51930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51929_51930 : H12AffineEnvironment.transform 9 237 env51929 = env51930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env51929 == env51930) = true)

theorem identity51930 : scanCanonicalize (H12AffineFastState.compose env51930 (packedSelected [0,1,7,8,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound51930 : packedSelected [0,1,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env51931 : List Nat := [2,4,8,16,32,64,128,256,512,237,492,4096,268,4540,32768,343,4605,200,236,32769,37064,169,32921,32906,388,64,33125,37236,4177,16,33208,33,257,112,37221,33497]

theorem envBound51931 : H12AffineFastState.Bounded env51931 := by
  intro p hp
  have h : env51931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51930_51931 : H12AffineEnvironment.transform 10 492 env51930 = env51931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env51930 == env51931) = true)

theorem identity51931 : scanCanonicalize (H12AffineFastState.compose env51931 (packedSelected [0,1,3,5,7,8,11,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound51931 : packedSelected [0,1,3,5,7,8,11,15,18] rootPS < 2^1333 := by decide +kernel

def env51932 : List Nat := [2,4,8,16,32,64,128,256,512,237,492,4096,268,4540,508,343,4605,200,236,509,4404,169,357,374,388,64,153,4232,4177,16,68,33,257,112,4249,805]

theorem envBound51932 : H12AffineFastState.Bounded env51932 := by
  intro p hp
  have h : env51932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51931_51932 : H12AffineEnvironment.transform 14 508 env51931 = env51932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env51931 == env51932) = true)

theorem identity51932 : scanCanonicalize (H12AffineFastState.compose env51932 (packedSelected [0,1,2,3,5,6,7,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51932 : packedSelected [0,1,2,3,5,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51933 : List Nat := [2,4,8,16,32,64,8,256,512,101,356,4096,268,4404,372,343,4469,64,100,373,4404,33,357,374,268,64,17,4096,4177,16,68,33,257,112,4113,805]

theorem envBound51933 : H12AffineFastState.Bounded env51933 := by
  intro p hp
  have h : env51933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51932_51933 : H12AffineEnvironment.transform 6 8 env51932 = env51933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51932 == env51933) = true)

theorem identity51933 : scanCanonicalize (H12AffineFastState.compose env51933 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51933 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51934 : List Nat := [2,4,8,16,32,64,8,117,512,101,17,4096,121,4161,1,34,4096,64,100,0,4161,33,16,3,121,64,17,4096,4177,16,68,33,116,112,4113,592]

theorem envBound51934 : H12AffineFastState.Bounded env51934 := by
  intro p hp
  have h : env51934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51933_51934 : H12AffineEnvironment.transform 7 117 env51933 = env51934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51933 == env51934) = true)

theorem identity51934 : scanCanonicalize (H12AffineFastState.compose env51934 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51934 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51935 : List Nat := [2,4,8,16,32,16,8,37,512,53,17,4096,41,4113,1,34,4096,16,52,0,4113,33,16,3,41,16,17,4096,4097,16,20,33,36,32,4113,512]

theorem envBound51935 : H12AffineFastState.Bounded env51935 := by
  intro p hp
  have h : env51935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51934_51935 : H12AffineEnvironment.transform 5 16 env51934 = env51935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51934 == env51935) = true)

theorem identity51935 : scanCanonicalize (H12AffineFastState.compose env51935 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound51935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51936 : List Nat := [2,4,8,16,32,16,8,37,20,53,17,4096,41,4113,1,34,4096,16,52,0,4113,33,16,3,41,16,17,4096,4097,16,20,33,36,32,4113,20]

theorem envBound51936 : H12AffineFastState.Bounded env51936 := by
  intro p hp
  have h : env51936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51935_51936 : H12AffineEnvironment.transform 8 20 env51935 = env51936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env51935 == env51936) = true)

theorem identity51936 : scanCanonicalize (H12AffineFastState.compose env51936 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51936 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51937 : List Nat := [0,4,8,16,32,16,8,37,20,53,17,4096,41,4113,1,32,4096,16,52,0,4113,33,16,1,41,16,17,4096,4097,16,20,33,36,32,4113,20]

theorem envBound51937 : H12AffineFastState.Bounded env51937 := by
  intro p hp
  have h : env51937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51936_51937 : H12AffineEnvironment.transform 0 0 env51936 = env51937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51936 == env51937) = true)

theorem identity51937 : scanCanonicalize (H12AffineFastState.compose env51937 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51938 : List Nat := [0,4,8,16,32,16,8,37,20,53,17,1,41,16,1,32,1,16,52,0,16,33,16,1,41,16,17,1,0,16,20,33,36,32,16,20]

theorem envBound51938 : H12AffineFastState.Bounded env51938 := by
  intro p hp
  have h : env51938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51937_51938 : H12AffineEnvironment.transform 11 1 env51937 = env51938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51937 == env51938) = true)

theorem identity51938 : scanCanonicalize (H12AffineFastState.compose env51938 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound51938 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51939 : List Nat := [0,4,8,16,24,16,8,29,20,13,17,1,17,16,1,24,1,16,12,0,16,25,16,1,17,16,17,1,0,16,20,25,28,24,16,20]

theorem envBound51939 : H12AffineFastState.Bounded env51939 := by
  intro p hp
  have h : env51939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51938_51939 : H12AffineEnvironment.transform 4 24 env51938 = env51939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env51938 == env51939) = true)

theorem identity51939 : scanCanonicalize (H12AffineFastState.compose env51939 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound51939 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51940 : List Nat := [0,4,8,4,12,4,8,9,0,13,5,1,5,4,1,12,1,4,12,0,4,13,4,1,5,4,5,1,0,4,0,13,8,12,4,0]

theorem envBound51940 : H12AffineFastState.Bounded env51940 := by
  intro p hp
  have h : env51940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51939_51940 : H12AffineEnvironment.transform 3 4 env51939 = env51940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env51939 == env51940) = true)

theorem identity51940 : scanCanonicalize (H12AffineFastState.compose env51940 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51940 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51941 : List Nat := [0,4,4,4,0,4,4,5,0,1,5,1,5,4,1,0,1,4,0,0,4,1,4,1,5,4,5,1,0,4,0,1,4,0,4,0]

theorem envBound51941 : H12AffineFastState.Bounded env51941 := by
  intro p hp
  have h : env51941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51940_51941 : H12AffineEnvironment.transform 2 4 env51940 = env51941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51940 == env51941) = true)

def env51942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,58517,168,62660,98781,8328,64,64724,57796,17664,32160,61704,32,257,21793,46212,120543]

theorem envBound51942 : H12AffineFastState.Bounded env51942 := by
  intro p hp
  have h : env51942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51925_51942 : H12AffineEnvironment.transform 17 10281 env51925 = env51942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51925 == env51942) = true)

theorem identity51942 : scanCanonicalize (H12AffineFastState.compose env51942 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound51942 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,24909,10281,1025,32769,58517,168,62660,54531,8328,64,64724,57796,17664,32160,61704,32,257,21793,46212,33281]

theorem envBound51943 : H12AffineFastState.Bounded env51943 := by
  intro p hp
  have h : env51943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51942_51943 : H12AffineEnvironment.transform 15 21726 env51942 = env51943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env51942 == env51943) = true)

theorem identity51943 : scanCanonicalize (H12AffineFastState.compose env51943 (packedSelected [0,2,6,7,8,10,11,16,17,18,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound51943 : packedSelected [0,2,6,7,8,10,11,16,17,18,28] rootPS < 2^1333 := by decide +kernel

def env51944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,21726,24909,10281,1025,21760,12692,168,8645,2,8328,64,10709,13509,17664,32160,9225,32,257,21793,24965,22272]

theorem envBound51944 : H12AffineFastState.Bounded env51944 := by
  intro p hp
  have h : env51944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51943_51944 : H12AffineEnvironment.transform 14 21761 env51943 = env51944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env51943 == env51944) = true)

theorem identity51944 : scanCanonicalize (H12AffineFastState.compose env51944 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound51944 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env51945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,136,343,13508,10281,1025,137,12692,168,8645,2,8328,64,10709,13509,4233,10281,9225,32,257,168,13324,649]

theorem envBound51945 : H12AffineFastState.Bounded env51945 := by
  intro p hp
  have h : env51945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51944_51945 : H12AffineEnvironment.transform 13 5513 env51944 = env51945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env51944 == env51945) = true)

theorem identity51945 : scanCanonicalize (H12AffineFastState.compose env51945 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound51945 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,343,5392,2557,1025,137,4160,168,17,2,348,64,2049,5393,4233,2557,1501,32,257,168,5592,649]

theorem envBound51946 : H12AffineFastState.Bounded env51946 := by
  intro p hp
  have h : env51946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51945_51946 : H12AffineEnvironment.transform 12 468 env51945 = env51946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env51945 == env51946) = true)

theorem identity51946 : scanCanonicalize (H12AffineFastState.compose env51946 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound51946 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2184,468,3329,136,343,3480,2557,1025,137,2248,168,17,2,348,64,2049,3481,2049,2557,1501,32,257,168,3408,649]

theorem envBound51947 : H12AffineFastState.Bounded env51947 := by
  intro p hp
  have h : env51947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51946_51947 : H12AffineEnvironment.transform 11 2184 env51946 = env51947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env51946 == env51947) = true)

theorem identity51947 : scanCanonicalize (H12AffineFastState.compose env51947 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51947 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51948 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2184,389,3329,136,262,3480,2476,1025,137,2201,168,17,2,269,17,2049,3481,2049,2476,1420,32,257,168,3329,649]

theorem envBound51948 : H12AffineFastState.Bounded env51948 := by
  intro p hp
  have h : env51948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51947_51948 : H12AffineEnvironment.transform 5 17 env51947 = env51948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51947 == env51948) = true)

theorem identity51948 : scanCanonicalize (H12AffineFastState.compose env51948 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound51948 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env51949 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,2184,389,2492,136,262,2341,2476,188,137,2201,168,17,2,269,17,2049,2340,2049,2476,305,32,257,168,2492,649]

theorem envBound51949 : H12AffineFastState.Bounded env51949 := by
  intro p hp
  have h : env51949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51948_51949 : H12AffineEnvironment.transform 9 189 env51948 = env51949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env51948 == env51949) = true)

theorem identity51949 : scanCanonicalize (H12AffineFastState.compose env51949 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51949 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51950 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2049,268,2357,1,262,2341,2341,53,0,2064,33,17,2,269,17,2049,2340,2049,2341,305,32,257,33,2357,512]

theorem envBound51950 : H12AffineFastState.Bounded env51950 := by
  intro p hp
  have h : env51950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51949_51950 : H12AffineEnvironment.transform 6 9 env51949 = env51950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51949 == env51950) = true)

theorem identity51950 : scanCanonicalize (H12AffineFastState.compose env51950 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51951 : List Nat := [2,4,8,16,17,17,9,256,512,5,2048,2049,268,2308,1,262,2324,2324,4,0,2064,16,17,2,269,17,2049,2325,2049,2324,256,17,257,16,2308,512]

theorem envBound51951 : H12AffineFastState.Bounded env51951 := by
  intro p hp
  have h : env51951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51950_51951 : H12AffineEnvironment.transform 4 17 env51950 = env51951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51950 == env51951) = true)

theorem identity51951 : scanCanonicalize (H12AffineFastState.compose env51951 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51951 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51952 : List Nat := [2,4,3,16,17,17,2,256,512,5,2048,2049,263,2308,1,262,2324,2324,4,0,2064,16,17,2,262,17,2049,2325,2049,2324,256,17,257,16,2308,512]

theorem envBound51952 : H12AffineFastState.Bounded env51952 := by
  intro p hp
  have h : env51952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51951_51952 : H12AffineEnvironment.transform 2 3 env51951 = env51952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51951 == env51952) = true)

theorem identity51952 : scanCanonicalize (H12AffineFastState.compose env51952 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51952 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51953 : List Nat := [2,4,3,2,3,3,2,256,512,5,2048,2049,263,2308,1,262,2310,2310,4,0,2050,2,3,2,262,3,2049,2311,2049,2310,256,3,257,2,2308,512]

theorem envBound51953 : H12AffineFastState.Bounded env51953 := by
  intro p hp
  have h : env51953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51952_51953 : H12AffineEnvironment.transform 3 2 env51952 = env51953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51952 == env51953) = true)

theorem identity51953 : scanCanonicalize (H12AffineFastState.compose env51953 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51953 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51954 : List Nat := [2,4,3,2,3,3,2,4,512,5,2048,2049,3,2048,1,2,2050,2050,4,0,2050,2,3,2,2,3,2049,2051,2049,2050,4,3,5,2,2048,512]

theorem envBound51954 : H12AffineFastState.Bounded env51954 := by
  intro p hp
  have h : env51954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51953_51954 : H12AffineEnvironment.transform 7 4 env51953 = env51954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51953 == env51954) = true)

theorem identity51954 : scanCanonicalize (H12AffineFastState.compose env51954 (packedSelected [0,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51954 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env51955 : List Nat := [1,4,0,1,0,0,1,4,512,5,2048,2049,0,2048,1,1,2049,2049,4,0,2049,1,0,1,1,0,2049,2048,2049,2049,4,0,5,1,2048,512]

theorem envBound51955 : H12AffineFastState.Bounded env51955 := by
  intro p hp
  have h : env51955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51954_51955 : H12AffineEnvironment.transform 0 1 env51954 = env51955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51954 == env51955) = true)

theorem identity51955 : scanCanonicalize (H12AffineFastState.compose env51955 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound51955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51956 : List Nat := [1,4,0,1,0,0,1,4,5,5,2048,2049,0,2048,1,1,2049,2049,4,0,2049,1,0,1,1,0,2049,2048,2049,2049,4,0,5,1,2048,5]

theorem envBound51956 : H12AffineFastState.Bounded env51956 := by
  intro p hp
  have h : env51956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51955_51956 : H12AffineEnvironment.transform 8 5 env51955 = env51956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env51955 == env51956) = true)

def env51957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,8590421,8328,64,4510804,8393985,8573065,8830976,168004,12645453,257,21792,46213,243603]

theorem envBound51957 : H12AffineFastState.Bounded env51957 := by
  intro p hp
  have h : env51957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51852_51957 : H12AffineEnvironment.transform 23 8590421 env51852 = env51957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590421 env51852 == env51957) = true)

def env51958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169352,98781,8328,64,4510804,163977,17665,284040,168004,4350405,257,21792,46213,243603]

theorem envBound51958 : H12AffineFastState.Bounded env51958 := by
  intro p hp
  have h : env51958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51957_51958 : H12AffineEnvironment.transform 22 169352 env51957 = env51958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env51957 == env51958) = true)

def env51959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169352,98781,8328,64,64724,163977,17665,284040,168004,411973,257,21792,46213,243603]

theorem envBound51959 : H12AffineFastState.Bounded env51959 := by
  intro p hp
  have h : env51959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51958_51959 : H12AffineEnvironment.transform 21 272512 env51958 = env51959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51958 == env51959) = true)

theorem identity51959 : scanCanonicalize (H12AffineFastState.compose env51959 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound51959 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115870,272512,120014,98781,8328,64,64724,115151,17665,284040,119042,329731,257,21792,46213,63189]

theorem envBound51960 : H12AffineFastState.Bounded env51960 := by
  intro p hp
  have h : env51960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51959_51960 : H12AffineEnvironment.transform 16 82246 env51959 = env51960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env51959 == env51960) = true)

def env51961 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115870,272512,119966,98701,8328,16,64644,115103,17665,284040,119042,329731,257,21792,46213,63109]

theorem envBound51961 : H12AffineFastState.Bounded env51961 := by
  intro p hp
  have h : env51961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51960_51961 : H12AffineEnvironment.transform 5 16 env51960 = env51961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51960 == env51961) = true)

theorem identity51961 : scanCanonicalize (H12AffineFastState.compose env51961 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound51961 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env51962 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,23588,1025,32769,115870,29860,119966,98701,8328,16,64644,115103,17665,2476,119042,87079,257,21792,46213,63109]

theorem envBound51962 : H12AffineFastState.Bounded env51962 := by
  intro p hp
  have h : env51962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51961_51962 : H12AffineEnvironment.transform 17 23588 env51961 = env51962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env51961 == env51962) = true)

theorem identity51962 : scanCanonicalize (H12AffineFastState.compose env51962 (packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound51962 : packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS < 2^1333 := by decide +kernel

def env51963 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,65536,82198,23588,1025,32769,115870,21793,119966,98701,269,16,56577,115103,17665,2476,119042,87079,257,21792,38144,55040]

theorem envBound51963 : H12AffineFastState.Bounded env51963 := by
  intro p hp
  have h : env51963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51962_51963 : H12AffineEnvironment.transform 12 389 env51962 = env51963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env51962 == env51963) = true)

theorem identity51963 : scanCanonicalize (H12AffineFastState.compose env51963 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound51963 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env51964 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21897,65536,82198,23588,1025,21896,69911,21793,65815,87044,269,16,2184,70678,17665,2476,66699,87079,257,21792,16521,649]

theorem envBound51964 : H12AffineFastState.Bounded env51964 := by
  intro p hp
  have h : env51964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51963_51964 : H12AffineEnvironment.transform 14 21897 env51963 = env51964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env51963 == env51964) = true)

theorem identity51964 : scanCanonicalize (H12AffineFastState.compose env51964 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound51964 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51965 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21897,398,16536,23588,1025,21896,4249,21793,153,21898,269,16,2184,5528,17665,2476,1285,21929,257,21792,16521,649]

theorem envBound51965 : H12AffineFastState.Bounded env51965 := by
  intro p hp
  have h : env51965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51964_51965 : H12AffineEnvironment.transform 15 398 env51964 = env51965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env51964 == env51965) = true)

theorem identity51965 : scanCanonicalize (H12AffineFastState.compose env51965 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound51965 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env51966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,1,398,5392,2476,1025,0,4249,169,153,2,269,16,2184,5528,4233,2476,1285,33,257,168,5377,649]

theorem envBound51966 : H12AffineFastState.Bounded env51966 := by
  intro p hp
  have h : env51966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51965_51966 : H12AffineEnvironment.transform 13 5512 env51965 = env51966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env51965 == env51966) = true)

theorem identity51966 : scanCanonicalize (H12AffineFastState.compose env51966 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51966 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env51967 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,129,5260,1,138,5140,2216,1025,0,4249,169,153,2,9,16,2184,5276,4233,2216,1025,33,5,168,5125,649]

theorem envBound51967 : H12AffineFastState.Bounded env51967 := by
  intro p hp
  have h : env51967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51966_51967 : H12AffineEnvironment.transform 7 4 env51966 = env51967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51966 == env51967) = true)

theorem identity51967 : scanCanonicalize (H12AffineFastState.compose env51967 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51967 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51968 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5125,1,3,5140,2081,1025,0,4112,32,16,2,9,16,2049,5141,4096,2081,1025,33,5,33,5125,512]

theorem envBound51968 : H12AffineFastState.Bounded env51968 := by
  intro p hp
  have h : env51968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51967_51968 : H12AffineEnvironment.transform 6 9 env51967 = env51968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51967 == env51968) = true)

theorem identity51968 : scanCanonicalize (H12AffineFastState.compose env51968 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51968 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51969 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1,8,1028,1,3,1045,2081,1025,0,17,32,16,2,9,16,2049,1044,1,2081,1025,33,5,33,1028,512]

theorem envBound51969 : H12AffineFastState.Bounded env51969 := by
  intro p hp
  have h : env51969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51968_51969 : H12AffineEnvironment.transform 11 1 env51968 = env51969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51968 == env51969) = true)

theorem identity51969 : scanCanonicalize (H12AffineFastState.compose env51969 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound51969 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51970 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1038,1,8,1028,1,3,1045,1071,1025,0,17,32,16,2,9,16,1039,1044,1,1071,1025,33,5,33,1028,512]

theorem envBound51970 : H12AffineFastState.Bounded env51970 := by
  intro p hp
  have h : env51970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51969_51970 : H12AffineEnvironment.transform 10 1038 env51969 = env51970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env51969 == env51970) = true)

theorem identity51970 : scanCanonicalize (H12AffineFastState.compose env51970 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51970 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51971 : List Nat := [2,4,8,16,11,16,9,4,512,1024,1038,1,8,1028,1,3,1045,1028,1025,0,17,11,16,2,9,16,1039,1044,1,1028,1025,10,5,10,1028,512]

theorem envBound51971 : H12AffineFastState.Bounded env51971 := by
  intro p hp
  have h : env51971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51970_51971 : H12AffineEnvironment.transform 4 11 env51970 = env51971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51970 == env51971) = true)

theorem identity51971 : scanCanonicalize (H12AffineFastState.compose env51971 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound51971 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51972 : List Nat := [2,4,8,16,11,16,9,4,512,14,0,1,8,10,1,3,27,10,15,0,17,11,16,2,9,16,1,26,1,10,15,10,5,10,10,512]

theorem envBound51972 : H12AffineFastState.Bounded env51972 := by
  intro p hp
  have h : env51972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51971_51972 : H12AffineEnvironment.transform 9 14 env51971 = env51972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env51971 == env51972) = true)

theorem identity51972 : scanCanonicalize (H12AffineFastState.compose env51972 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51972 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51973 : List Nat := [2,4,2,16,1,16,3,4,512,4,0,1,2,0,1,3,17,0,5,0,17,1,16,2,3,16,1,16,1,0,5,0,5,0,0,512]

theorem envBound51973 : H12AffineFastState.Bounded env51973 := by
  intro p hp
  have h : env51973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51972_51973 : H12AffineEnvironment.transform 2 2 env51972 = env51973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51972 == env51973) = true)

theorem identity51973 : scanCanonicalize (H12AffineFastState.compose env51973 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51974 : List Nat := [2,1,2,16,1,16,3,1,512,1,0,1,2,0,1,3,17,0,0,0,17,1,16,2,3,16,1,16,1,0,0,0,0,0,0,512]

theorem envBound51974 : H12AffineFastState.Bounded env51974 := by
  intro p hp
  have h : env51974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51973_51974 : H12AffineEnvironment.transform 1 1 env51973 = env51974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51973 == env51974) = true)

theorem identity51974 : scanCanonicalize (H12AffineFastState.compose env51974 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51974 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51975 : List Nat := [2,1,2,0,1,0,3,1,512,1,0,1,2,0,1,3,1,0,0,0,1,1,0,2,3,0,1,0,1,0,0,0,0,0,0,512]

theorem envBound51975 : H12AffineFastState.Bounded env51975 := by
  intro p hp
  have h : env51975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51974_51975 : H12AffineEnvironment.transform 3 0 env51974 = env51975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51974 == env51975) = true)

theorem identity51975 : scanCanonicalize (H12AffineFastState.compose env51975 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51976 : List Nat := [1,1,1,0,1,0,0,1,512,1,0,1,1,0,1,0,1,0,0,0,1,1,0,1,0,0,1,0,1,0,0,0,0,0,0,512]

theorem envBound51976 : H12AffineFastState.Bounded env51976 := by
  intro p hp
  have h : env51976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51975_51976 : H12AffineEnvironment.transform 0 1 env51975 = env51976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51975 == env51976) = true)

def env51977 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115870,272512,119967,98700,8328,17,64645,115102,17665,284040,119042,329731,257,21792,46213,63108]

theorem envBound51977 : H12AffineFastState.Bounded env51977 := by
  intro p hp
  have h : env51977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51960_51977 : H12AffineEnvironment.transform 5 17 env51960 = env51977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51960 == env51977) = true)

theorem identity51977 : scanCanonicalize (H12AffineFastState.compose env51977 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound51977 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env51978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,97327,1025,32769,115870,87215,119967,98700,8328,17,64645,115102,17665,76199,119042,29740,257,21792,46213,63108]

theorem envBound51978 : H12AffineFastState.Bounded env51978 := by
  intro p hp
  have h : env51978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51977_51978 : H12AffineEnvironment.transform 17 97327 env51977 = env51978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env51977 == env51978) = true)

theorem identity51978 : scanCanonicalize (H12AffineFastState.compose env51978 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound51978 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env51979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,65536,70814,76198,1025,32769,102679,65830,98582,98700,8328,17,43276,103447,4232,76199,99467,8613,257,169,46213,41741]

theorem envBound51979 : H12AffineFastState.Bounded env51979 := by
  intro p hp
  have h : env51979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51978_51979 : H12AffineEnvironment.transform 13 5513 env51978 = env51979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env51978 == env51979) = true)

theorem identity51979 : scanCanonicalize (H12AffineFastState.compose env51979 (packedSelected [3,10,16,18,20,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound51979 : packedSelected [3,10,16,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51980 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,263,5529,10401,1025,32769,36880,33,32785,32907,8328,17,43276,38160,4232,10400,34188,8613,257,169,46213,41741]

theorem envBound51980 : H12AffineFastState.Bounded env51980 := by
  intro p hp
  have h : env51980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51979_51980 : H12AffineEnvironment.transform 15 263 env51979 = env51980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env51979 == env51980) = true)

theorem identity51980 : scanCanonicalize (H12AffineFastState.compose env51980 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51980 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8461,263,5529,10401,1025,8460,12573,33,8476,8582,8328,17,2049,13341,4232,10400,9345,8613,257,169,5512,512]

theorem envBound51981 : H12AffineFastState.Bounded env51981 := by
  intro p hp
  have h : env51981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51980_51981 : H12AffineEnvironment.transform 14 8461 env51980 = env51981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env51980 == env51981) = true)

theorem identity51981 : scanCanonicalize (H12AffineFastState.compose env51981 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51981 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51982 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,5513,8461,263,5529,10369,1025,8460,12573,1,8476,8582,8328,17,2049,13341,4232,10368,9345,8581,257,137,5512,512]

theorem envBound51982 : H12AffineFastState.Bounded env51982 := by
  intro p hp
  have h : env51982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51981_51982 : H12AffineEnvironment.transform 4 0 env51981 = env51982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51981 == env51982) = true)

theorem identity51982 : scanCanonicalize (H12AffineFastState.compose env51982 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7300) := by decide +kernel

theorem selectedBound51982 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51983 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,7300,5513,7561,263,5529,5125,1025,7560,3481,1,7576,7426,7180,17,2049,2201,4232,5124,6149,7425,257,137,5512,512]

theorem envBound51983 : H12AffineFastState.Bounded env51983 := by
  intro p hp
  have h : env51983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51982_51983 : H12AffineEnvironment.transform 12 7300 env51982 = env51983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7300 env51982 == env51983) = true)

theorem identity51983 : scanCanonicalize (H12AffineFastState.compose env51983 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 412) := by decide +kernel

theorem selectedBound51983 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env51984 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,412,3352,1045,3093,263,1029,1433,1025,3092,3481,1,3076,3230,3472,17,2049,2201,276,1432,2457,3229,257,137,1044,512]

theorem envBound51984 : H12AffineFastState.Bounded env51984 := by
  intro p hp
  have h : env51984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51983_51984 : H12AffineEnvironment.transform 11 412 env51983 = env51984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 412 env51983 == env51984) = true)

theorem identity51984 : scanCanonicalize (H12AffineFastState.compose env51984 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound51984 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env51985 : List Nat := [2,4,8,16,0,17,128,256,512,1024,260,412,1052,1045,1297,263,1029,1433,1025,1296,1181,1,1280,1434,1172,17,261,413,276,1432,157,1433,257,137,1044,512]

theorem envBound51985 : H12AffineFastState.Bounded env51985 := by
  intro p hp
  have h : env51985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51984_51985 : H12AffineEnvironment.transform 10 260 env51984 = env51985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env51984 == env51985) = true)

theorem identity51985 : scanCanonicalize (H12AffineFastState.compose env51985 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51985 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env51986 : List Nat := [2,4,8,16,0,17,128,256,512,272,260,412,268,261,1,263,277,137,273,0,397,1,16,138,388,17,261,413,276,136,157,137,257,137,260,512]

theorem envBound51986 : H12AffineFastState.Bounded env51986 := by
  intro p hp
  have h : env51986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51985_51986 : H12AffineEnvironment.transform 9 272 env51985 = env51986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51985 == env51986) = true)

theorem identity51986 : scanCanonicalize (H12AffineFastState.compose env51986 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51986 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51987 : List Nat := [2,4,8,16,0,17,8,256,512,272,260,276,268,261,1,263,277,1,273,0,261,1,16,2,268,17,261,277,276,0,21,1,257,1,260,512]

theorem envBound51987 : H12AffineFastState.Bounded env51987 := by
  intro p hp
  have h : env51987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51986_51987 : H12AffineEnvironment.transform 6 8 env51986 = env51987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51986 == env51987) = true)

theorem identity51987 : scanCanonicalize (H12AffineFastState.compose env51987 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51988 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,16,8,1,1,3,17,1,21,0,1,1,16,2,8,17,1,17,16,0,21,1,5,1,0,512]

theorem envBound51988 : H12AffineFastState.Bounded env51988 := by
  intro p hp
  have h : env51988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51987_51988 : H12AffineEnvironment.transform 7 4 env51987 = env51988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51987 == env51988) = true)

theorem identity51988 : scanCanonicalize (H12AffineFastState.compose env51988 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51989 : List Nat := [2,0,8,16,0,17,8,0,512,16,0,16,8,1,1,3,17,1,17,0,1,1,16,2,8,17,1,17,16,0,17,1,1,1,0,512]

theorem envBound51989 : H12AffineFastState.Bounded env51989 := by
  intro p hp
  have h : env51989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51988_51989 : H12AffineEnvironment.transform 1 0 env51988 = env51989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51988 == env51989) = true)

def env51990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169352,98781,8328,64,64725,163977,17665,284040,168004,411972,257,21792,46213,243603]

theorem envBound51990 : H12AffineFastState.Bounded env51990 := by
  intro p hp
  have h : env51990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51958_51990 : H12AffineEnvironment.transform 21 272513 env51958 = env51990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51958 == env51990) = true)

theorem identity51990 : scanCanonicalize (H12AffineFastState.compose env51990 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound51990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,165336,272513,169352,21762,8328,64,64725,163977,17665,284040,168004,411972,257,21792,46213,156492]

theorem envBound51991 : H12AffineFastState.Bounded env51991 := by
  intro p hp
  have h : env51991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51990_51991 : H12AffineEnvironment.transform 15 54495 env51990 = env51991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env51990 == env51991) = true)

def env51992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272393,169216,21762,8192,64,64605,163841,17665,283904,168004,411972,257,21792,46093,156492]

theorem envBound51992 : H12AffineFastState.Bounded env51992 := by
  intro p hp
  have h : env51992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51991_51992 : H12AffineEnvironment.transform 6 8 env51991 = env51992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51991 == env51992) = true)

theorem identity51992 : scanCanonicalize (H12AffineFastState.compose env51992 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound51992 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env51993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,165200,32,169216,21762,8192,64,64605,163841,17665,32041,168004,156013,257,21792,46093,156492]

theorem envBound51993 : H12AffineFastState.Bounded env51993 := by
  intro p hp
  have h : env51993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51992_51993 : H12AffineEnvironment.transform 17 10281 env51992 = env51993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51992 == env51993) = true)

theorem identity51993 : scanCanonicalize (H12AffineFastState.compose env51993 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound51993 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env51994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10281,1025,32769,17728,32,21776,21762,8192,64,64605,16401,17665,32041,20564,41341,257,21792,46093,41820]

theorem envBound51994 : H12AffineFastState.Bounded env51994 := by
  intro p hp
  have h : env51994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51993_51994 : H12AffineEnvironment.transform 16 49168 env51993 = env51994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env51993 == env51994) = true)

theorem identity51994 : scanCanonicalize (H12AffineFastState.compose env51994 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51994 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,24909,10281,1025,8540,17728,32,21776,21762,8192,64,23808,16401,17665,32041,20564,32,257,21792,5456,513]

theorem envBound51995 : H12AffineFastState.Bounded env51995 := by
  intro p hp
  have h : env51995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51994_51995 : H12AffineEnvironment.transform 14 8541 env51994 = env51995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51994 == env51995) = true)

theorem identity51995 : scanCanonicalize (H12AffineFastState.compose env51995 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51995 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51996 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,29962,24861,10281,1025,8460,17680,32,21776,21762,8192,16,23808,16401,17665,32041,20484,32,257,21792,5376,513]

theorem envBound51996 : H12AffineFastState.Bounded env51996 := by
  intro p hp
  have h : env51996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51995_51996 : H12AffineEnvironment.transform 5 16 env51995 = env51996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51995 == env51996) = true)

theorem identity51996 : scanCanonicalize (H12AffineFastState.compose env51996 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51996 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51997 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,21510,16401,2341,1025,0,17680,32,21776,21762,268,16,23808,16401,17665,23589,20484,32,257,21792,5376,513]

theorem envBound51997 : H12AffineFastState.Bounded env51997 := by
  intro p hp
  have h : env51997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51996_51997 : H12AffineEnvironment.transform 12 268 env51996 = env51997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51996 == env51997) = true)

def env51998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272392,169217,21762,8193,64,64604,163840,17665,283905,168004,411972,257,21792,46092,156492]

theorem envBound51998 : H12AffineFastState.Bounded env51998 := by
  intro p hp
  have h : env51998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51991_51998 : H12AffineEnvironment.transform 6 9 env51991 = env51998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51991 == env51998) = true)

theorem identity51998 : scanCanonicalize (H12AffineFastState.compose env51998 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound51998 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env51999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,2420,1025,32769,165201,8572,169217,21762,8193,64,64604,163840,17665,23669,168004,147504,257,21792,46092,156492]

theorem envBound51999 : H12AffineFastState.Bounded env51999 := by
  intro p hp
  have h : env51999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51998_51999 : H12AffineEnvironment.transform 17 2420 env51998 = env51999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env51998 == env51999) = true)

theorem identity51999 : scanCanonicalize (H12AffineFastState.compose env51999 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound51999 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,2420,1025,32769,17729,8572,21777,21762,8193,64,64604,16400,17665,23669,20564,32800,257,21792,46092,41820]

theorem envBound52000 : H12AffineFastState.Bounded env52000 := by
  intro p hp
  have h : env52000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51999_52000 : H12AffineEnvironment.transform 16 49168 env51999 = env52000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env51999 == env52000) = true)

theorem identity52000 : scanCanonicalize (H12AffineFastState.compose env52000 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound52000 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,343,5393,2420,1025,21760,17729,8572,21777,21762,8193,64,10589,16400,17665,23669,20564,21793,257,21792,24845,30301]

theorem envBound52001 : H12AffineFastState.Bounded env52001 := by
  intro p hp
  have h : env52001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52000_52001 : H12AffineEnvironment.transform 14 21761 env52000 = env52001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52000 == env52001) = true)

theorem identity52001 : scanCanonicalize (H12AffineFastState.compose env52001 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound52001 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env52002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,343,5393,2420,1025,8540,12573,8572,8525,8542,8193,64,10589,13388,12637,10281,9224,8573,257,8572,5457,513]

theorem envBound52002 : H12AffineFastState.Bounded env52002 := by
  intro p hp
  have h : env52002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52001_52002 : H12AffineEnvironment.transform 13 13404 env52001 = env52002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env52001 == env52002) = true)

theorem identity52002 : scanCanonicalize (H12AffineFastState.compose env52002 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52003 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,262,5393,2341,1025,8461,12573,8493,8476,8463,8193,17,10508,13341,12556,10281,9224,8492,257,8493,5376,513]

theorem envBound52003 : H12AffineFastState.Bounded env52003 := by
  intro p hp
  have h : env52003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52002_52003 : H12AffineEnvironment.transform 5 17 env52002 = env52003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52002 == env52003) = true)

theorem identity52003 : scanCanonicalize (H12AffineFastState.compose env52003 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound52003 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52004 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,780,5889,512,262,5393,2341,1025,513,4625,545,528,515,781,17,2560,5905,4608,2853,1796,544,257,545,5376,513]

theorem envBound52004 : H12AffineFastState.Bounded env52004 := by
  intro p hp
  have h : env52004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52003_52004 : H12AffineEnvironment.transform 12 780 env52003 = env52004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env52003 == env52004) = true)

theorem identity52004 : scanCanonicalize (H12AffineFastState.compose env52004 (packedSelected [1,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3125) := by decide +kernel

theorem selectedBound52004 : packedSelected [1,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env52005 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3125,780,2868,512,262,2340,2341,1025,513,3620,545,528,515,781,17,2560,2852,3637,2853,1796,544,257,545,2357,513]

theorem envBound52005 : H12AffineFastState.Bounded env52005 := by
  intro p hp
  have h : env52005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52004_52005 : H12AffineEnvironment.transform 11 3125 env52004 = env52005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3125 env52004 == env52005) = true)

theorem identity52005 : scanCanonicalize (H12AffineFastState.compose env52005 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound52005 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env52006 : List Nat := [2,4,8,16,32,17,9,256,512,257,2048,2356,780,2868,512,262,2340,2341,256,513,2853,545,528,515,781,17,2560,2852,2868,2853,517,544,257,545,2357,513]

theorem envBound52006 : H12AffineFastState.Bounded env52006 := by
  intro p hp
  have h : env52006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52005_52006 : H12AffineEnvironment.transform 9 257 env52005 = env52006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env52005 == env52006) = true)

theorem identity52006 : scanCanonicalize (H12AffineFastState.compose env52006 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound52006 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env52007 : List Nat := [2,4,8,16,32,17,9,256,512,257,529,805,780,293,512,262,821,820,256,513,308,545,528,515,781,17,17,309,293,308,517,544,257,545,804,513]

theorem envBound52007 : H12AffineFastState.Bounded env52007 := by
  intro p hp
  have h : env52007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52006_52007 : H12AffineEnvironment.transform 10 529 env52006 = env52007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env52006 == env52007) = true)

theorem identity52007 : scanCanonicalize (H12AffineFastState.compose env52007 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound52007 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52008 : List Nat := [2,4,8,16,32,17,9,256,308,257,293,17,56,293,308,262,1,0,256,309,308,277,292,311,57,17,17,309,293,308,305,276,257,277,16,309]

theorem envBound52008 : H12AffineFastState.Bounded env52008 := by
  intro p hp
  have h : env52008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52007_52008 : H12AffineEnvironment.transform 8 308 env52007 = env52008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env52007 == env52008) = true)

theorem identity52008 : scanCanonicalize (H12AffineFastState.compose env52008 (packedSelected [0,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52008 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env52009 : List Nat := [2,4,8,16,32,17,9,37,17,36,0,17,56,0,17,35,1,0,37,16,17,48,1,18,57,17,17,16,0,17,20,49,36,48,16,16]

theorem envBound52009 : H12AffineFastState.Bounded env52009 := by
  intro p hp
  have h : env52009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52008_52009 : H12AffineEnvironment.transform 7 37 env52008 = env52009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52008 == env52009) = true)

theorem identity52009 : scanCanonicalize (H12AffineFastState.compose env52009 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52010 : List Nat := [2,4,8,16,16,17,9,21,17,20,0,17,8,0,17,19,1,0,21,16,17,0,1,18,9,17,17,16,0,17,20,1,20,0,16,16]

theorem envBound52010 : H12AffineFastState.Bounded env52010 := by
  intro p hp
  have h : env52010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52009_52010 : H12AffineEnvironment.transform 4 16 env52009 = env52010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52009 == env52010) = true)

theorem identity52010 : scanCanonicalize (H12AffineFastState.compose env52010 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52011 : List Nat := [2,4,8,0,0,1,9,5,1,4,0,1,8,0,1,3,1,0,5,0,1,0,1,2,9,1,1,0,0,1,4,1,4,0,0,0]

theorem envBound52011 : H12AffineFastState.Bounded env52011 := by
  intro p hp
  have h : env52011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52010_52011 : H12AffineEnvironment.transform 3 0 env52010 = env52011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52010 == env52011) = true)

def env52012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169353,98780,8328,64,4510804,163976,17664,284041,168004,4350404,257,21792,46213,243603]

theorem envBound52012 : H12AffineFastState.Bounded env52012 := by
  intro p hp
  have h : env52012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51957_52012 : H12AffineEnvironment.transform 22 169353 env51957 = env52012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env51957 == env52012) = true)

def env52013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169353,98780,8328,64,64724,163976,17664,284041,168004,411972,257,21792,46213,243603]

theorem envBound52013 : H12AffineFastState.Bounded env52013 := by
  intro p hp
  have h : env52013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52012_52013 : H12AffineEnvironment.transform 21 272512 env52012 = env52013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52012 == env52013) = true)

theorem identity52013 : scanCanonicalize (H12AffineFastState.compose env52013 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound52013 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,77898,272512,73755,98780,8328,64,64724,79130,17664,284041,75222,392406,257,21792,46213,513]

theorem envBound52014 : H12AffineFastState.Bounded env52014 := by
  intro p hp
  have h : env52014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52013_52014 : H12AffineEnvironment.transform 16 112018 env52013 = env52014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env52013 == env52014) = true)

def env52015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90258,262144,1025,21761,77898,272512,73755,87260,8328,64,10708,79130,17664,284041,75222,338390,257,21792,24965,513]

theorem envBound52015 : H12AffineFastState.Bounded env52015 := by
  intro p hp
  have h : env52015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52014_52015 : H12AffineEnvironment.transform 14 21760 env52014 = env52015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52014 == env52015) = true)

theorem identity52015 : scanCanonicalize (H12AffineFastState.compose env52015 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52015 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77898,272392,73755,87124,8192,64,10588,79130,17664,283905,75102,338270,257,21792,24845,513]

theorem envBound52016 : H12AffineFastState.Bounded env52016 := by
  intro p hp
  have h : env52016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52015_52016 : H12AffineEnvironment.transform 6 8 env52015 = env52016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52015 == env52016) = true)

theorem identity52016 : scanCanonicalize (H12AffineFastState.compose env52016 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52016 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env52017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90138,10281,1025,21761,77898,33,73755,87124,8192,64,10588,79130,17664,32040,75102,65911,257,21792,24845,513]

theorem envBound52017 : H12AffineFastState.Bounded env52017 := by
  intro p hp
  have h : env52017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52016_52017 : H12AffineEnvironment.transform 17 10281 env52016 = env52017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52016 == env52017) = true)

theorem identity52017 : scanCanonicalize (H12AffineFastState.compose env52017 (packedSelected [0,3,5,7,10,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52017 : packedSelected [0,3,5,7,10,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env52018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,82246,2421,1025,21761,69910,33,65863,87124,348,64,2048,70726,17664,23668,66562,65911,257,21792,16465,513]

theorem envBound52018 : H12AffineFastState.Bounded env52018 := by
  intro p hp
  have h : env52018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52017_52018 : H12AffineEnvironment.transform 12 348 env52017 = env52018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52017 == env52018) = true)

theorem identity52018 : scanCanonicalize (H12AffineFastState.compose env52018 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound52018 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,5392,2421,1025,21761,17728,33,21777,2,348,64,2048,16400,17664,23668,20564,21793,257,21792,16465,513]

theorem envBound52019 : H12AffineFastState.Bounded env52019 := by
  intro p hp
  have h : env52019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52018_52019 : H12AffineEnvironment.transform 15 21590 env52018 = env52019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env52018 == env52019) = true)

theorem identity52019 : scanCanonicalize (H12AffineFastState.compose env52019 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52019 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52020 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,21511,5392,2340,1025,21761,17681,33,21777,2,269,17,2048,16400,17664,23589,20485,21793,257,21792,16384,513]

theorem envBound52020 : H12AffineFastState.Bounded env52020 := by
  intro p hp
  have h : env52020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52019_52020 : H12AffineEnvironment.transform 5 17 env52019 = env52020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52019 == env52020) = true)

theorem identity52020 : scanCanonicalize (H12AffineFastState.compose env52020 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52020 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52021 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4112,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound52021 : H12AffineFastState.Bounded env52021 := by
  intro p hp
  have h : env52021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52020_52021 : H12AffineEnvironment.transform 13 5377 env52020 = env52021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52020 == env52021) = true)

theorem identity52021 : scanCanonicalize (H12AffineFastState.compose env52021 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52021 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52022 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,35,5173,2049,1025,0,4112,33,16,2,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound52022 : H12AffineFastState.Bounded env52022 := by
  intro p hp
  have h : env52022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52021_52022 : H12AffineEnvironment.transform 7 37 env52021 = env52022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52021 == env52022) = true)

def env52023 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,1,35,1029,2049,1025,0,32,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound52023 : H12AffineFastState.Bounded env52023 := by
  intro p hp
  have h : env52023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52022_52023 : H12AffineEnvironment.transform 11 48 env52022 = env52023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52022 == env52023) = true)

theorem identity52023 : scanCanonicalize (H12AffineFastState.compose env52023 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52024 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,48,40,1044,1,35,1029,2049,1025,0,32,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,17]

theorem envBound52024 : H12AffineFastState.Bounded env52024 := by
  intro p hp
  have h : env52024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52023_52024 : H12AffineEnvironment.transform 8 16 env52023 = env52024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52023 == env52024) = true)

def env52025 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,40,32,1,35,49,2049,53,0,32,33,16,2,40,17,2048,48,49,2049,21,32,36,33,32,17]

theorem envBound52025 : H12AffineFastState.Bounded env52025 := by
  intro p hp
  have h : env52025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52024_52025 : H12AffineEnvironment.transform 9 52 env52024 = env52025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52024 == env52025) = true)

theorem identity52025 : scanCanonicalize (H12AffineFastState.compose env52025 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound52025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52026 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,48,40,32,1,35,49,32,53,0,32,33,16,2,40,17,33,48,49,32,21,32,36,33,32,17]

theorem envBound52026 : H12AffineFastState.Bounded env52026 := by
  intro p hp
  have h : env52026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52025_52026 : H12AffineEnvironment.transform 10 33 env52025 = env52026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env52025 == env52026) = true)

def leafEnv52026 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,48,40,32,1,35,49,32,53,0,32,33,16,2,20,40,1,17,33,48,49,32,21,32,36,33,5,35,32,17,1,32,0]

def active52026 : List Nat := [0,1,2,3,4]

def tree52026 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52026 : H12WitnessSearch.Good tree52026 := H12GlobalWitnessIndex.good

theorem leafIdentity52026 : H12AffineFastState.composeSystem env52026 rootObs = leafEnv52026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52026 rootObs == leafEnv52026) = true)

theorem terminalChecked52026 : H12PackedTerminal.terminalCheckFast leafEnv52026 active52026 tree52026 = true := by decide +kernel

def env52027 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,40,33,1,35,48,2049,52,0,32,33,16,2,40,17,2048,49,49,2049,20,32,36,33,33,17]

theorem envBound52027 : H12AffineFastState.Bounded env52027 := by
  intro p hp
  have h : env52027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52024_52027 : H12AffineEnvironment.transform 9 53 env52024 = env52027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52024 == env52027) = true)

theorem identity52027 : scanCanonicalize (H12AffineFastState.compose env52027 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound52027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52028 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,40,33,1,35,48,27,52,0,32,33,16,2,40,17,26,49,49,27,20,32,36,33,33,17]

theorem envBound52028 : H12AffineFastState.Bounded env52028 := by
  intro p hp
  have h : env52028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52027_52028 : H12AffineEnvironment.transform 10 26 env52027 = env52028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env52027 == env52028) = true)

def leafEnv52028 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,40,33,1,35,48,27,52,0,32,33,16,2,21,40,1,17,26,49,49,27,20,32,36,33,5,35,33,17,1,32,0]

def active52028 : List Nat := [0,1,2,3,4]

def tree52028 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52028 : H12WitnessSearch.Good tree52028 := H12GlobalWitnessIndex.good

theorem leafIdentity52028 : H12AffineFastState.composeSystem env52028 rootObs = leafEnv52028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52028 rootObs == leafEnv52028) = true)

theorem terminalChecked52028 : H12PackedTerminal.terminalCheckFast leafEnv52028 active52028 tree52028 = true := by decide +kernel

def env52029 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,1,35,1028,2049,1025,0,33,33,16,2,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound52029 : H12AffineFastState.Bounded env52029 := by
  intro p hp
  have h : env52029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52022_52029 : H12AffineEnvironment.transform 11 49 env52022 = env52029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52022 == env52029) = true)

theorem identity52029 : scanCanonicalize (H12AffineFastState.compose env52029 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound52029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52030 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,49,40,560,1,35,545,2049,548,0,33,33,16,2,40,17,2048,544,48,2049,516,32,36,33,560,513]

theorem envBound52030 : H12AffineFastState.Bounded env52030 := by
  intro p hp
  have h : env52030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52029_52030 : H12AffineEnvironment.transform 9 549 env52029 = env52030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env52029 == env52030) = true)

def env52031 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,40,32,1,35,49,2049,52,0,33,33,16,2,40,17,2048,48,48,2049,20,32,36,33,32,17]

theorem envBound52031 : H12AffineFastState.Bounded env52031 := by
  intro p hp
  have h : env52031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52030_52031 : H12AffineEnvironment.transform 8 16 env52030 = env52031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52030 == env52031) = true)

theorem identity52031 : scanCanonicalize (H12AffineFastState.compose env52031 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound52031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52032 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,40,32,1,35,49,27,52,0,33,33,16,2,40,17,26,48,48,27,20,32,36,33,32,17]

theorem envBound52032 : H12AffineFastState.Bounded env52032 := by
  intro p hp
  have h : env52032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52031_52032 : H12AffineEnvironment.transform 10 26 env52031 = env52032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env52031 == env52032) = true)

def leafEnv52032 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,40,32,1,35,49,27,52,0,33,33,16,2,21,40,1,17,26,48,48,27,20,32,36,33,5,35,32,17,1,33,0]

def active52032 : List Nat := [0,1,2,3,4]

def tree52032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52032 : H12WitnessSearch.Good tree52032 := H12GlobalWitnessIndex.good

theorem leafIdentity52032 : H12AffineFastState.composeSystem env52032 rootObs = leafEnv52032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52032 rootObs == leafEnv52032) = true)

theorem terminalChecked52032 : H12PackedTerminal.terminalCheckFast leafEnv52032 active52032 tree52032 = true := by decide +kernel

def env52033 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,40,33,1,35,48,2049,53,0,33,33,16,2,40,17,2048,49,48,2049,21,32,36,33,33,16]

theorem envBound52033 : H12AffineFastState.Bounded env52033 := by
  intro p hp
  have h : env52033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52030_52033 : H12AffineEnvironment.transform 8 17 env52030 = env52033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52030 == env52033) = true)

theorem identity52033 : scanCanonicalize (H12AffineFastState.compose env52033 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52034 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,49,40,33,1,35,48,33,53,0,33,33,16,2,40,17,32,49,48,33,21,32,36,33,33,16]

theorem envBound52034 : H12AffineFastState.Bounded env52034 := by
  intro p hp
  have h : env52034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52033_52034 : H12AffineEnvironment.transform 10 32 env52033 = env52034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52033 == env52034) = true)

def leafEnv52034 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,49,40,33,1,35,48,33,53,0,33,33,16,2,20,40,1,17,32,49,48,33,21,32,36,33,5,35,33,16,1,33,0]

def active52034 : List Nat := [0,1,2,3,4]

def tree52034 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52034 : H12WitnessSearch.Good tree52034 := H12GlobalWitnessIndex.good

theorem leafIdentity52034 : H12AffineFastState.composeSystem env52034 rootObs = leafEnv52034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52034 rootObs == leafEnv52034) = true)

theorem terminalChecked52034 : H12PackedTerminal.terminalCheckFast leafEnv52034 active52034 tree52034 = true := by decide +kernel

def env52035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90259,262144,1025,21760,77898,272512,73755,87261,8328,64,10709,79130,17664,284041,75222,338391,257,21792,24964,513]

theorem envBound52035 : H12AffineFastState.Bounded env52035 := by
  intro p hp
  have h : env52035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52014_52035 : H12AffineEnvironment.transform 14 21761 env52014 = env52035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52014 == env52035) = true)

theorem identity52035 : scanCanonicalize (H12AffineFastState.compose env52035 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound52035 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env52036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8322,16401,262144,1025,21760,4296,272512,153,29791,8328,64,10709,5528,17664,284041,1364,264533,257,21792,24964,513]

theorem envBound52036 : H12AffineFastState.Bounded env52036 := by
  intro p hp
  have h : env52036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52035_52036 : H12AffineEnvironment.transform 15 8322 env52035 = env52036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env52035 == env52036) = true)

theorem identity52036 : scanCanonicalize (H12AffineFastState.compose env52036 (packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52036 : packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS < 2^1333 := by decide +kernel

def env52037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1,8322,5393,262144,1025,0,4296,272512,153,8543,8328,64,10709,5528,4096,262281,1364,264533,257,32,13444,513]

theorem envBound52037 : H12AffineFastState.Bounded env52037 := by
  intro p hp
  have h : env52037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52036_52037 : H12AffineEnvironment.transform 13 5376 env52036 = env52037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52036 == env52037) = true)

theorem identity52037 : scanCanonicalize (H12AffineFastState.compose env52037 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound52037 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env52038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,343,5393,262144,1025,0,4296,264533,153,138,349,64,2048,5528,4096,262281,1364,264533,257,32,5457,513]

theorem envBound52038 : H12AffineFastState.Bounded env52038 := by
  intro p hp
  have h : env52038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52037_52038 : H12AffineEnvironment.transform 12 469 env52037 = env52038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env52037 == env52038) = true)

theorem identity52038 : scanCanonicalize (H12AffineFastState.compose env52038 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound52038 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,343,5393,2556,1025,0,4296,169,153,138,349,64,2048,5528,4096,2421,1364,169,257,32,5457,513]

theorem envBound52039 : H12AffineFastState.Bounded env52039 := by
  intro p hp
  have h : env52039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52038_52039 : H12AffineEnvironment.transform 17 2556 env52038 = env52039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env52038 == env52039) = true)

theorem identity52039 : scanCanonicalize (H12AffineFastState.compose env52039 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52039 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env52040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2421,1025,0,4161,32,16,3,349,64,2048,5393,4096,2421,1364,32,257,32,5457,513]

theorem envBound52040 : H12AffineFastState.Bounded env52040 := by
  intro p hp
  have h : env52040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52039_52040 : H12AffineEnvironment.transform 6 9 env52039 = env52040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52039 == env52040) = true)

theorem identity52040 : scanCanonicalize (H12AffineFastState.compose env52040 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52040 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52041 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,1,343,4097,2421,273,0,4161,32,16,3,349,64,2048,4097,4096,2421,68,32,257,32,4161,513]

theorem envBound52041 : H12AffineFastState.Bounded env52041 := by
  intro p hp
  have h : env52041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52040_52041 : H12AffineEnvironment.transform 9 272 env52040 = env52041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52040 == env52041) = true)

theorem identity52041 : scanCanonicalize (H12AffineFastState.compose env52041 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52042 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4112,1,263,4097,2341,273,0,4113,32,16,3,269,16,2048,4097,4096,2341,20,32,257,32,4113,513]

theorem envBound52042 : H12AffineFastState.Bounded env52042 := by
  intro p hp
  have h : env52042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52041_52042 : H12AffineEnvironment.transform 5 16 env52041 = env52042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52041 == env52042) = true)

theorem identity52042 : scanCanonicalize (H12AffineFastState.compose env52042 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound52042 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52043 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,309,268,293,1,263,308,2341,273,0,292,32,16,3,269,16,2048,308,309,2341,20,32,257,32,292,513]

theorem envBound52043 : H12AffineFastState.Bounded env52043 := by
  intro p hp
  have h : env52043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52042_52043 : H12AffineEnvironment.transform 11 309 env52042 = env52043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env52042 == env52043) = true)

theorem identity52043 : scanCanonicalize (H12AffineFastState.compose env52043 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound52043 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52044 : List Nat := [2,4,8,16,32,16,9,256,512,272,293,309,268,293,1,263,308,0,273,0,292,32,16,3,269,16,293,308,309,0,20,32,257,32,292,513]

theorem envBound52044 : H12AffineFastState.Bounded env52044 := by
  intro p hp
  have h : env52044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52043_52044 : H12AffineEnvironment.transform 10 293 env52043 = env52044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env52043 == env52044) = true)

theorem identity52044 : scanCanonicalize (H12AffineFastState.compose env52044 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52044 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52045 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,40,1,1,35,16,0,53,0,0,32,16,3,41,16,1,16,17,0,20,32,37,32,0,513]

theorem envBound52045 : H12AffineFastState.Bounded env52045 := by
  intro p hp
  have h : env52045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52044_52045 : H12AffineEnvironment.transform 7 36 env52044 = env52045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52044 == env52045) = true)

theorem identity52045 : scanCanonicalize (H12AffineFastState.compose env52045 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52045 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52046 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,1,1,2,16,0,20,0,0,1,16,3,8,16,1,16,17,0,20,1,4,1,0,513]

theorem envBound52046 : H12AffineFastState.Bounded env52046 := by
  intro p hp
  have h : env52046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52045_52046 : H12AffineEnvironment.transform 4 1 env52045 = env52046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52045 == env52046) = true)

theorem identity52046 : scanCanonicalize (H12AffineFastState.compose env52046 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52047 : List Nat := [2,4,8,16,1,16,9,5,16,21,1,17,9,1,1,2,16,0,20,0,0,1,16,3,8,16,1,16,17,0,20,1,4,1,0,17]

theorem envBound52047 : H12AffineFastState.Bounded env52047 := by
  intro p hp
  have h : env52047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52046_52047 : H12AffineEnvironment.transform 8 16 env52046 = env52047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52046 == env52047) = true)

def env52048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169353,98780,8328,64,64725,163976,17664,284041,168004,411973,257,21792,46213,243603]

theorem envBound52048 : H12AffineFastState.Bounded env52048 := by
  intro p hp
  have h : env52048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52012_52048 : H12AffineEnvironment.transform 21 272513 env52012 = env52048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52012 == env52048) = true)

theorem identity52048 : scanCanonicalize (H12AffineFastState.compose env52048 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52048 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165336,272513,169353,41430,8328,64,64725,163976,17664,284041,168004,411973,257,21792,46213,169881]

theorem envBound52049 : H12AffineFastState.Bounded env52049 := by
  intro p hp
  have h : env52049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52048_52049 : H12AffineEnvironment.transform 15 8202 env52048 = env52049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52048 == env52049) = true)

def env52050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165200,272393,169217,41310,8192,64,64605,163840,17664,283905,168004,411973,257,21792,46093,169745]

theorem envBound52050 : H12AffineFastState.Bounded env52050 := by
  intro p hp
  have h : env52050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52049_52050 : H12AffineEnvironment.transform 6 8 env52049 = env52050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52049 == env52050) = true)

theorem identity52050 : scanCanonicalize (H12AffineFastState.compose env52050 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound52050 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1025,32769,165200,169265,169217,41310,8192,64,64605,163840,17664,190521,168004,62589,257,21792,46093,169745]

theorem envBound52051 : H12AffineFastState.Bounded env52051 := by
  intro p hp
  have h : env52051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52050_52051 : H12AffineEnvironment.transform 17 179512 env52050 = env52051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env52050 == env52051) = true)

theorem identity52051 : scanCanonicalize (H12AffineFastState.compose env52051 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound52051 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4161,32,16,41310,8192,64,64605,5393,17664,32040,1365,62589,257,21792,46093,512]

theorem envBound52052 : H12AffineFastState.Bounded env52052 := by
  intro p hp
  have h : env52052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52051_52052 : H12AffineEnvironment.transform 16 38161 env52051 = env52052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52051 == env52052) = true)

theorem identity52052 : scanCanonicalize (H12AffineFastState.compose env52052 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound52052 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,32768,8202,38161,10281,1025,32769,4161,32,16,41310,8192,64,47437,5393,16,14392,1365,45421,257,4144,46093,512]

theorem envBound52053 : H12AffineFastState.Bounded env52053 := by
  intro p hp
  have h : env52053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52052_52053 : H12AffineEnvironment.transform 13 1296 env52052 = env52053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52052 == env52053) = true)

theorem identity52053 : scanCanonicalize (H12AffineFastState.compose env52053 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12344) := by decide +kernel

theorem selectedBound52053 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,12344,8202,9513,10281,1025,12345,4161,32,16,4454,8192,64,2421,5393,16,14392,1365,341,257,4144,1077,512]

theorem envBound52054 : H12AffineFastState.Bounded env52054 := by
  intro p hp
  have h : env52054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52053_52054 : H12AffineEnvironment.transform 14 12344 env52053 = env52054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12344 env52053 == env52054) = true)

theorem identity52054 : scanCanonicalize (H12AffineFastState.compose env52054 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound52054 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,1296,4192,82,1393,2161,1025,4193,4161,32,16,4454,88,64,2421,5393,16,6240,1365,341,257,4144,1077,512]

theorem envBound52055 : H12AffineFastState.Bounded env52055 := by
  intro p hp
  have h : env52055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52054_52055 : H12AffineEnvironment.transform 12 88 env52054 = env52055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env52054 == env52055) = true)

def env52056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165201,272392,169216,41311,8193,64,64604,163841,17664,283904,168004,411973,257,21792,46092,169744]

theorem envBound52056 : H12AffineFastState.Bounded env52056 := by
  intro p hp
  have h : env52056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52049_52056 : H12AffineEnvironment.transform 6 9 env52049 = env52056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52049 == env52056) = true)

theorem identity52056 : scanCanonicalize (H12AffineFastState.compose env52056 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound52056 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138341,1025,32769,165201,144493,169216,41311,8193,64,64604,163841,17664,149861,168004,21792,257,21792,46092,169744]

theorem envBound52057 : H12AffineFastState.Bounded env52057 := by
  intro p hp
  have h : env52057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52056_52057 : H12AffineEnvironment.transform 17 138341 env52056 = env52057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env52056 == env52057) = true)

theorem identity52057 : scanCanonicalize (H12AffineFastState.compose env52057 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16741) := by decide +kernel

theorem selectedBound52057 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16741,23808,1025,32769,50228,29960,54373,41311,8193,64,64604,49508,17664,2048,53537,21792,257,21792,46092,54901]

theorem envBound52058 : H12AffineFastState.Bounded env52058 := by
  intro p hp
  have h : env52058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52057_52058 : H12AffineEnvironment.transform 16 16741 env52057 = env52058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16741 env52057 == env52058) = true)

theorem identity52058 : scanCanonicalize (H12AffineFastState.compose env52058 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52058 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env52059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,8202,5392,2421,1025,32769,36929,8573,32784,41311,8193,64,43049,38161,4469,2048,34132,341,257,341,46092,33280]

theorem envBound52059 : H12AffineFastState.Bounded env52059 := by
  intro p hp
  have h : env52059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52058_52059 : H12AffineEnvironment.transform 13 5237 env52058 = env52059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52058 == env52059) = true)

theorem identity52059 : scanCanonicalize (H12AffineFastState.compose env52059 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52059 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,1,8202,5392,2421,1025,0,4160,8573,17,8542,8193,64,10280,5392,4469,2048,1365,341,257,341,13325,513]

theorem envBound52060 : H12AffineFastState.Bounded env52060 := by
  intro p hp
  have h : env52060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52059_52060 : H12AffineEnvironment.transform 14 1 env52059 = env52060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52059 == env52060) = true)

def env52061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound52061 : H12AffineFastState.Bounded env52061 := by
  intro p hp
  have h : env52061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51620_52061 : H12AffineEnvironment.transform 26 30393345 env51620 = env52061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env51620 == env52061) = true)

def env52062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound52062 : H12AffineFastState.Bounded env52062 := by
  intro p hp
  have h : env52062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52061_52062 : H12AffineEnvironment.transform 18 1024 env52061 = env52062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env52061 == env52062) = true)

theorem identity52062 : scanCanonicalize (H12AffineFastState.compose env52062 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound52062 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,152,16777216,8328,64,21479577,18973837,2119113,442520,16876681,23160257,256,18990133,18949520,16819039]

theorem envBound52063 : H12AffineFastState.Bounded env52063 := by
  intro p hp
  have h : env52063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52062_52063 : H12AffineEnvironment.transform 22 152 env52062 = env52063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env52062 == env52063) = true)

def env52064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479441,18973701,2118977,442384,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound52064 : H12AffineFastState.Bounded env52064 := by
  intro p hp
  have h : env52064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52063_52064 : H12AffineEnvironment.transform 6 8 env52063 = env52064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52063 == env52064) = true)

def env52065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118977,294912,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound52065 : H12AffineFastState.Bounded env52065 := by
  intro p hp
  have h : env52065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52064_52065 : H12AffineEnvironment.transform 16 16400 env52064 = env52065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52064 == env52065) = true)

def env52066 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118709,294912,16876545,23159869,116,18990133,18949228,16818731]

theorem envBound52066 : H12AffineFastState.Bounded env52066 := by
  intro p hp
  have h : env52066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52065_52066 : H12AffineEnvironment.transform 7 116 env52065 = env52066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52065 == env52066) = true)

theorem identity52066 : scanCanonicalize (H12AffineFastState.compose env52066 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound52066 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52067 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,16777216,8192,64,21331969,17066043,374795,294912,16876545,21268483,116,17049611,17090642,16818731]

theorem envBound52067 : H12AffineFastState.Bounded env52067 := by
  intro p hp
  have h : env52067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52066_52067 : H12AffineEnvironment.transform 20 388158 env52066 = env52067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env52066 == env52067) = true)

def env52068 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,351316,8192,64,4250709,78959,374795,294912,317525,4314199,116,95327,103430,392831]

theorem envBound52068 : H12AffineFastState.Bounded env52068 := by
  intro p hp
  have h : env52068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52067_52068 : H12AffineEnvironment.transform 23 351316 env52067 = env52068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env52067 == env52068) = true)

def env52069 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,115734,4194304,16,95356,8192,64,4250709,78959,102435,43048,61565,4314199,116,95327,103430,120407]

theorem envBound52069 : H12AffineFastState.Bounded env52069 := by
  intro p hp
  have h : env52069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52068_52069 : H12AffineEnvironment.transform 17 10280 env52068 = env52069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52068 == env52069) = true)

theorem identity52069 : scanCanonicalize (H12AffineFastState.compose env52069 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52069 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52070 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,58397,4194304,16,21623,8192,64,4250709,5220,45096,43048,61565,4256860,116,21588,46093,63068]

theorem envBound52070 : H12AffineFastState.Bounded env52070 := by
  intro p hp
  have h : env52070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52069_52070 : H12AffineEnvironment.transform 15 8203 env52069 = env52070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52069 == env52070) = true)

theorem identity52070 : scanCanonicalize (H12AffineFastState.compose env52070 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound52070 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52071 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,8203,16400,10280,1024,29789,4161,4194304,16,21623,8192,64,4204553,5220,17524,23668,1057,4194304,116,21588,16465,512]

theorem envBound52071 : H12AffineFastState.Bounded env52071 := by
  intro p hp
  have h : env52071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52070_52071 : H12AffineEnvironment.transform 14 29788 env52070 = env52071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env52070 == env52071) = true)

theorem identity52071 : scanCanonicalize (H12AffineFastState.compose env52071 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52071 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52072 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28728,8203,16400,10280,100,28729,4161,4194304,16,20499,8192,64,4204553,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound52072 : H12AffineFastState.Bounded env52072 := by
  intro p hp
  have h : env52072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52071_52072 : H12AffineEnvironment.transform 9 100 env52071 = env52072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52071 == env52072) = true)

theorem identity52072 : scanCanonicalize (H12AffineFastState.compose env52072 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 6216) := by decide +kernel

theorem selectedBound52072 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env52073 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,6216,16384,18544,6211,16400,4192,100,18545,4161,4194304,16,20499,6216,64,4198465,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound52073 : H12AffineFastState.Bounded env52073 := by
  intro p hp
  have h : env52073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52072_52073 : H12AffineEnvironment.transform 12 6216 env52072 = env52073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6216 env52072 == env52073) = true)

theorem identity52073 : scanCanonicalize (H12AffineFastState.compose env52073 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52073 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env52074 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,89,16384,18544,82,16400,2161,100,18545,2128,4194304,16,18434,89,64,4196432,2065,16400,16385,69,4194304,116,18465,16465,512]

theorem envBound52074 : H12AffineFastState.Bounded env52074 := by
  intro p hp
  have h : env52074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52073_52074 : H12AffineEnvironment.transform 11 2065 env52073 = env52074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52073 == env52074) = true)

theorem identity52074 : scanCanonicalize (H12AffineFastState.compose env52074 (packedSelected [1,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound52074 : packedSelected [1,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52075 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,89,2080,80,82,2096,2161,100,81,2128,4194304,16,34,89,64,4196432,2065,2096,2081,69,4194304,116,1,2161,512]

theorem envBound52075 : H12AffineFastState.Bounded env52075 := by
  intro p hp
  have h : env52075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52074_52075 : H12AffineEnvironment.transform 13 2080 env52074 = env52075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env52074 == env52075) = true)

theorem identity52075 : scanCanonicalize (H12AffineFastState.compose env52075 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52075 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env52076 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,9,2080,0,2,2096,2081,52,1,2048,4194304,16,34,9,16,4196352,2065,2096,2081,21,4194304,36,1,2081,512]

theorem envBound52076 : H12AffineFastState.Bounded env52076 := by
  intro p hp
  have h : env52076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52075_52076 : H12AffineEnvironment.transform 5 16 env52075 = env52076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52075 == env52076) = true)

theorem identity52076 : scanCanonicalize (H12AffineFastState.compose env52076 (packedSelected [1,3,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52076 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env52077 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,0,2,2064,2049,20,1,2048,4194304,16,2,9,16,4196352,2065,2064,2049,21,4194304,4,1,2049,512]

theorem envBound52077 : H12AffineFastState.Bounded env52077 := by
  intro p hp
  have h : env52077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52076_52077 : H12AffineEnvironment.transform 4 0 env52076 = env52077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52076 == env52077) = true)

theorem identity52077 : scanCanonicalize (H12AffineFastState.compose env52077 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound52077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52078 : List Nat := [2,4,8,16,0,16,8,4,512,20,542,527,9,542,0,2,526,543,20,1,542,4194304,16,2,9,16,4194846,527,526,543,21,4194304,4,1,543,512]

theorem envBound52078 : H12AffineFastState.Bounded env52078 := by
  intro p hp
  have h : env52078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52077_52078 : H12AffineEnvironment.transform 10 542 env52077 = env52078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env52077 == env52078) = true)

theorem identity52078 : scanCanonicalize (H12AffineFastState.compose env52078 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 0) := by decide +kernel

theorem selectedBound52078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52079 : List Nat := [2,4,8,16,0,16,8,4,512,20,542,527,9,542,0,2,526,543,20,1,542,0,16,2,9,16,542,527,526,543,21,0,4,1,543,512]

theorem envBound52079 : H12AffineFastState.Bounded env52079 := by
  intro p hp
  have h : env52079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52078_52079 : H12AffineEnvironment.transform 21 0 env52078 = env52079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env52078 == env52079) = true)

theorem identity52079 : scanCanonicalize (H12AffineFastState.compose env52079 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52079 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52080 : List Nat := [2,4,8,16,0,16,8,4,0,20,30,15,9,30,0,2,14,31,20,1,30,0,16,2,9,16,30,15,14,31,21,0,4,1,31,0]

theorem envBound52080 : H12AffineFastState.Bounded env52080 := by
  intro p hp
  have h : env52080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52079_52080 : H12AffineEnvironment.transform 8 0 env52079 = env52080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52079 == env52080) = true)

def leafEnv52080 : List Nat := [2,4,8,16,0,16,8,4,0,20,30,15,9,30,0,2,14,31,20,1,30,0,16,2,21,9,1,16,30,15,14,31,21,0,4,1,4,2,31,0,1,31,0]

def active52080 : List Nat := [0,1,2,3]

def tree52080 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52080 : H12WitnessSearch.Good tree52080 := H12GlobalWitnessIndex.good

theorem leafIdentity52080 : H12AffineFastState.composeSystem env52080 rootObs = leafEnv52080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52080 rootObs == leafEnv52080) = true)

theorem terminalChecked52080 : H12PackedTerminal.terminalCheckFast leafEnv52080 active52080 tree52080 = true := by decide +kernel

def env52081 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,115735,4194304,16,95357,8192,64,4250709,78959,102434,43049,61564,4314199,116,95327,103430,120406]

theorem envBound52081 : H12AffineFastState.Bounded env52081 := by
  intro p hp
  have h : env52081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52068_52081 : H12AffineEnvironment.transform 17 10281 env52068 = env52081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52068 == env52081) = true)

theorem identity52081 : scanCanonicalize (H12AffineFastState.compose env52081 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound52081 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52082 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10281,1024,32769,4160,4194304,16,41002,8192,64,4250709,57400,17525,43049,61564,4194304,116,40968,16465,513]

theorem envBound52082 : H12AffineFastState.Bounded env52082 := by
  intro p hp
  have h : env52082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52081_52082 : H12AffineEnvironment.transform 15 54359 env52081 = env52082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env52081 == env52082) = true)

theorem identity52082 : scanCanonicalize (H12AffineFastState.compose env52082 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound52082 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env52083 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10281,1024,32769,4160,8201,16,41002,8192,64,64604,57400,17525,43049,61564,8201,116,40968,16465,513]

theorem envBound52083 : H12AffineFastState.Bounded env52083 := by
  intro p hp
  have h : env52083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52082_52083 : H12AffineEnvironment.transform 21 8201 env52082 = env52083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env52082 == env52083) = true)

theorem identity52083 : scanCanonicalize (H12AffineFastState.compose env52083 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound52083 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env52084 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,32768,40970,13389,10281,1024,32769,4160,8201,16,41002,8192,64,34817,37989,12328,43049,33825,8201,116,40968,13324,513]

theorem envBound52084 : H12AffineFastState.Bounded env52084 := by
  intro p hp
  have h : env52084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52083_52084 : H12AffineEnvironment.transform 13 13405 env52083 = env52084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env52083 == env52084) = true)

theorem identity52084 : scanCanonicalize (H12AffineFastState.compose env52084 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52084 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52085 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13325,32768,40970,13341,10281,1024,32769,4112,8201,16,41002,8192,16,34817,37941,12328,43049,33825,8201,36,40968,13324,513]

theorem envBound52085 : H12AffineFastState.Bounded env52085 := by
  intro p hp
  have h : env52085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52084_52085 : H12AffineEnvironment.transform 5 16 env52084 = env52085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52084 == env52085) = true)

theorem identity52085 : scanCanonicalize (H12AffineFastState.compose env52085 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound52085 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52086 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,32768,32803,5172,2048,1024,32769,4112,32,16,32771,41,16,34817,37941,4097,34816,33825,32,36,32801,5157,513]

theorem envBound52086 : H12AffineFastState.Bounded env52086 := by
  intro p hp
  have h : env52086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52085_52086 : H12AffineEnvironment.transform 12 41 env52085 = env52086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env52085 == env52086) = true)

theorem identity52086 : scanCanonicalize (H12AffineFastState.compose env52086 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52086 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52087 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,35,5172,2048,1024,1,4112,32,16,3,41,16,2049,5173,4097,2048,1057,32,36,33,5157,513]

theorem envBound52087 : H12AffineFastState.Bounded env52087 := by
  intro p hp
  have h : env52087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52086_52087 : H12AffineEnvironment.transform 14 0 env52086 = env52087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52086 == env52087) = true)

theorem identity52087 : scanCanonicalize (H12AffineFastState.compose env52087 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound52087 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52088 : List Nat := [2,4,8,16,32,16,8,36,512,37,2048,4096,41,4097,0,35,4113,2048,37,1,4112,32,16,3,41,16,2049,4112,4097,2048,4,32,36,33,4096,513]

theorem envBound52088 : H12AffineFastState.Bounded env52088 := by
  intro p hp
  have h : env52088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52087_52088 : H12AffineEnvironment.transform 9 37 env52087 = env52088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env52087 == env52088) = true)

theorem identity52088 : scanCanonicalize (H12AffineFastState.compose env52088 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound52088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52089 : List Nat := [2,4,8,16,32,16,8,36,512,37,2048,512,41,513,0,35,529,2048,37,1,528,32,16,3,41,16,2049,528,513,2048,4,32,36,33,512,513]

theorem envBound52089 : H12AffineFastState.Bounded env52089 := by
  intro p hp
  have h : env52089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52088_52089 : H12AffineEnvironment.transform 11 512 env52088 = env52089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env52088 == env52089) = true)

theorem identity52089 : scanCanonicalize (H12AffineFastState.compose env52089 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52089 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52090 : List Nat := [2,4,8,16,32,16,8,36,1,37,2048,1,41,0,0,35,16,2048,37,1,17,32,16,3,41,16,2049,17,0,2048,4,32,36,33,1,0]

theorem envBound52090 : H12AffineFastState.Bounded env52090 := by
  intro p hp
  have h : env52090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52089_52090 : H12AffineEnvironment.transform 8 1 env52089 = env52090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52089 == env52090) = true)

theorem identity52090 : scanCanonicalize (H12AffineFastState.compose env52090 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52090 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52091 : List Nat := [2,4,8,1,32,1,8,36,1,37,2048,1,41,0,0,35,1,2048,37,1,0,32,1,3,41,1,2049,0,0,2048,4,32,36,33,1,0]

theorem envBound52091 : H12AffineFastState.Bounded env52091 := by
  intro p hp
  have h : env52091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52090_52091 : H12AffineEnvironment.transform 3 1 env52090 = env52091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52090 == env52091) = true)

theorem identity52091 : scanCanonicalize (H12AffineFastState.compose env52091 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound52091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52092 : List Nat := [2,4,8,1,32,1,8,36,1,37,33,1,41,0,0,35,1,33,37,1,0,32,1,3,41,1,32,0,0,33,4,32,36,33,1,0]

theorem envBound52092 : H12AffineFastState.Bounded env52092 := by
  intro p hp
  have h : env52092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52091_52092 : H12AffineEnvironment.transform 10 33 env52091 = env52092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env52091 == env52092) = true)

theorem identity52092 : scanCanonicalize (H12AffineFastState.compose env52092 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52092 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52093 : List Nat := [2,4,8,1,0,1,8,4,1,5,1,1,9,0,0,3,1,1,5,1,0,0,1,3,9,1,0,0,0,1,4,0,4,1,1,0]

theorem envBound52093 : H12AffineFastState.Bounded env52093 := by
  intro p hp
  have h : env52093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52092_52093 : H12AffineEnvironment.transform 4 0 env52092 = env52093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52092 == env52093) = true)

def env52094 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,351317,8192,64,4250708,78958,374795,294912,317524,4314198,116,95326,103431,392830]

theorem envBound52094 : H12AffineFastState.Bounded env52094 := by
  intro p hp
  have h : env52094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52067_52094 : H12AffineEnvironment.transform 23 351317 env52067 = env52094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env52067 == env52094) = true)

theorem identity52094 : scanCanonicalize (H12AffineFastState.compose env52094 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound52094 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env52095 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,130175,1024,32769,4161,4194304,16,41002,8192,64,4250708,78958,17524,97407,74795,4314198,116,95326,103431,513]

theorem envBound52095 : H12AffineFastState.Bounded env52095 := by
  intro p hp
  have h : env52095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52094_52095 : H12AffineEnvironment.transform 17 130175 env52094 = env52095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env52094 == env52095) = true)

theorem identity52095 : scanCanonicalize (H12AffineFastState.compose env52095 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound52095 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env52096 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10281,1024,32769,4161,4194304,16,41002,8192,64,4250708,57400,17524,43049,61565,4194304,116,40968,16465,513]

theorem envBound52096 : H12AffineFastState.Bounded env52096 := by
  intro p hp
  have h : env52096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52095_52096 : H12AffineEnvironment.transform 15 54358 env52095 = env52096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env52095 == env52096) = true)

theorem identity52096 : scanCanonicalize (H12AffineFastState.compose env52096 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound52096 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env52097 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10281,1024,32769,4161,8201,16,41002,8192,64,64605,57400,17524,43049,61565,8201,116,40968,16465,513]

theorem envBound52097 : H12AffineFastState.Bounded env52097 := by
  intro p hp
  have h : env52097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52096_52097 : H12AffineEnvironment.transform 21 8201 env52096 = env52097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env52096 == env52097) = true)

theorem identity52097 : scanCanonicalize (H12AffineFastState.compose env52097 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound52097 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env52098 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13404,32768,40970,13388,10281,1024,32769,4161,8201,16,41002,8192,64,34817,37988,12328,43049,33825,8201,116,40968,13325,513]

theorem envBound52098 : H12AffineFastState.Bounded env52098 := by
  intro p hp
  have h : env52098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52097_52098 : H12AffineEnvironment.transform 13 13404 env52097 = env52098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env52097 == env52098) = true)

theorem identity52098 : scanCanonicalize (H12AffineFastState.compose env52098 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52098 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52099 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,32768,40970,13340,10281,1024,32769,4113,8201,16,41002,8192,16,34817,37940,12328,43049,33825,8201,36,40968,13325,513]

theorem envBound52099 : H12AffineFastState.Bounded env52099 := by
  intro p hp
  have h : env52099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52098_52099 : H12AffineEnvironment.transform 5 16 env52098 = env52099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52098 == env52099) = true)

theorem identity52099 : scanCanonicalize (H12AffineFastState.compose env52099 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound52099 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52100 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,32768,32803,5173,2048,1024,32769,4113,32,16,32771,41,16,34817,37940,4097,34816,33825,32,36,32801,5156,513]

theorem envBound52100 : H12AffineFastState.Bounded env52100 := by
  intro p hp
  have h : env52100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52099_52100 : H12AffineEnvironment.transform 12 41 env52099 = env52100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env52099 == env52100) = true)

theorem identity52100 : scanCanonicalize (H12AffineFastState.compose env52100 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52100 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52101 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4113,32,16,3,41,16,2049,5172,4097,2048,1057,32,36,33,5156,513]

theorem envBound52101 : H12AffineFastState.Bounded env52101 := by
  intro p hp
  have h : env52101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52100_52101 : H12AffineEnvironment.transform 14 0 env52100 = env52101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52100 == env52101) = true)

theorem identity52101 : scanCanonicalize (H12AffineFastState.compose env52101 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound52101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52102 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,4096,41,4097,0,35,4113,2048,36,1,4113,32,16,3,41,16,2049,4112,4097,2048,5,32,36,33,4096,513]

theorem envBound52102 : H12AffineFastState.Bounded env52102 := by
  intro p hp
  have h : env52102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52101_52102 : H12AffineEnvironment.transform 9 36 env52101 = env52102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env52101 == env52102) = true)

theorem identity52102 : scanCanonicalize (H12AffineFastState.compose env52102 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound52102 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52103 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,512,41,513,0,35,529,2048,36,1,529,32,16,3,41,16,2049,528,513,2048,5,32,36,33,512,513]

theorem envBound52103 : H12AffineFastState.Bounded env52103 := by
  intro p hp
  have h : env52103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52102_52103 : H12AffineEnvironment.transform 11 512 env52102 = env52103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env52102 == env52103) = true)

theorem identity52103 : scanCanonicalize (H12AffineFastState.compose env52103 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52103 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52104 : List Nat := [2,4,8,16,32,16,8,36,0,36,2048,0,41,1,0,35,17,2048,36,1,17,32,16,3,41,16,2049,16,1,2048,5,32,36,33,0,1]

theorem envBound52104 : H12AffineFastState.Bounded env52104 := by
  intro p hp
  have h : env52104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52103_52104 : H12AffineEnvironment.transform 8 0 env52103 = env52104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52103 == env52104) = true)

theorem identity52104 : scanCanonicalize (H12AffineFastState.compose env52104 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52104 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52105 : List Nat := [2,4,8,1,32,1,8,36,0,36,2048,0,41,1,0,35,0,2048,36,1,0,32,1,3,41,1,2049,1,1,2048,5,32,36,33,0,1]

theorem envBound52105 : H12AffineFastState.Bounded env52105 := by
  intro p hp
  have h : env52105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52104_52105 : H12AffineEnvironment.transform 3 1 env52104 = env52105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52104 == env52105) = true)

theorem identity52105 : scanCanonicalize (H12AffineFastState.compose env52105 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52106 : List Nat := [2,4,8,1,32,1,8,36,0,36,32,0,41,1,0,35,0,32,36,1,0,32,1,3,41,1,33,1,1,32,5,32,36,33,0,1]

theorem envBound52106 : H12AffineFastState.Bounded env52106 := by
  intro p hp
  have h : env52106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52105_52106 : H12AffineEnvironment.transform 10 32 env52105 = env52106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52105 == env52106) = true)

theorem identity52106 : scanCanonicalize (H12AffineFastState.compose env52106 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52107 : List Nat := [2,4,8,1,1,1,8,5,0,5,1,0,8,1,0,2,0,1,5,1,0,1,1,3,8,1,0,1,1,1,5,1,5,0,0,1]

theorem envBound52107 : H12AffineFastState.Bounded env52107 := by
  intro p hp
  have h : env52107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52106_52107 : H12AffineEnvironment.transform 4 1 env52106 = env52107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52106 == env52107) = true)

def env52108 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118708,294912,16876545,23159868,117,18990133,18949229,16818730]

theorem envBound52108 : H12AffineFastState.Bounded env52108 := by
  intro p hp
  have h : env52108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52065_52108 : H12AffineEnvironment.transform 7 117 env52065 = env52108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52065 == env52108) = true)

theorem identity52108 : scanCanonicalize (H12AffineFastState.compose env52108 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444309) := by decide +kernel

theorem selectedBound52108 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52109 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2444309,8192,64,6343700,313360,2118708,294912,2410516,4466729,117,296992,288888,2485823]

theorem envBound52109 : H12AffineFastState.Bounded env52109 := by
  intro p hp
  have h : env52109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52108_52109 : H12AffineEnvironment.transform 23 2444309 env52108 = env52109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444309 env52108 == env52109) = true)

def env52110 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,2097152,4194304,16,2199649,8192,64,6343700,5220,2118708,23668,2102368,4256861,117,21588,46092,2175563]

theorem envBound52110 : H12AffineFastState.Bounded env52110 := by
  intro p hp
  have h : env52110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52109_52110 : H12AffineEnvironment.transform 17 56436 env52109 = env52110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env52109 == env52110) = true)

def env52111 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,4160,4194304,16,98337,8192,64,4250708,5220,17524,23668,1056,4256861,117,21588,46092,74251]

theorem envBound52111 : H12AffineFastState.Bounded env52111 := by
  intro p hp
  have h : env52111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52110_52111 : H12AffineEnvironment.transform 20 4160 env52110 = env52111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52110 == env52111) = true)

theorem identity52111 : scanCanonicalize (H12AffineFastState.compose env52111 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound52111 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52112 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,16400,56436,1024,32769,4160,4194304,16,21622,8192,64,4250708,5220,17524,23668,1056,4256861,117,21588,46092,63068]

theorem envBound52112 : H12AffineFastState.Bounded env52112 := by
  intro p hp
  have h : env52112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52111_52112 : H12AffineEnvironment.transform 15 54359 env52111 = env52112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env52111 == env52112) = true)

theorem identity52112 : scanCanonicalize (H12AffineFastState.compose env52112 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound52112 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env52113 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,16400,56436,1024,32769,4160,8200,16,21622,8192,64,64604,5220,17524,23668,1056,54357,117,21588,46092,63068]

theorem envBound52113 : H12AffineFastState.Bounded env52113 := by
  intro p hp
  have h : env52113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52112_52113 : H12AffineEnvironment.transform 21 8200 env52112 = env52113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env52112 == env52113) = true)

theorem identity52113 : scanCanonicalize (H12AffineFastState.compose env52113 (packedSelected [2,3,4,5,6,9,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52113 : packedSelected [2,3,4,5,6,9,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52114 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,32802,5221,34817,1024,32769,4160,8200,16,3,8192,64,43049,5220,4097,2049,1056,32800,117,33,46092,41513]

theorem envBound52114 : H12AffineFastState.Bounded env52114 := by
  intro p hp
  have h : env52114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52113_52114 : H12AffineEnvironment.transform 13 5237 env52113 = env52114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52113 == env52114) = true)

theorem identity52114 : scanCanonicalize (H12AffineFastState.compose env52114 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound52114 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env52115 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,8202,5221,10281,1024,8233,4160,8200,16,3,8192,64,2049,5220,4097,2049,1056,8200,117,33,5156,513]

theorem envBound52115 : H12AffineFastState.Bounded env52115 := by
  intro p hp
  have h : env52115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52114_52115 : H12AffineEnvironment.transform 14 8232 env52114 = env52115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env52114 == env52115) = true)

theorem identity52115 : scanCanonicalize (H12AffineFastState.compose env52115 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52115 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52116 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,34,5221,2049,1024,1,4160,32,16,3,40,64,2049,5220,4097,2049,1056,32,117,33,5156,513]

theorem envBound52116 : H12AffineFastState.Bounded env52116 := by
  intro p hp
  have h : env52116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52115_52116 : H12AffineEnvironment.transform 12 40 env52115 = env52116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52115 == env52116) = true)

theorem identity52116 : scanCanonicalize (H12AffineFastState.compose env52116 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound52116 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52117 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1573,40,592,0,34,576,2049,1024,1,1637,32,16,3,40,64,2049,577,1572,2049,1056,32,117,33,513,513]

theorem envBound52117 : H12AffineFastState.Bounded env52117 := by
  intro p hp
  have h : env52117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52116_52117 : H12AffineEnvironment.transform 11 1573 env52116 = env52117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env52116 == env52117) = true)

theorem identity52117 : scanCanonicalize (H12AffineFastState.compose env52117 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound52117 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52118 : List Nat := [2,4,8,16,32,64,8,117,512,1024,576,1573,40,592,0,34,576,577,1024,1,1637,32,16,3,40,64,577,577,1572,577,1056,32,117,33,513,513]

theorem envBound52118 : H12AffineFastState.Bounded env52118 := by
  intro p hp
  have h : env52118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52117_52118 : H12AffineEnvironment.transform 10 576 env52117 = env52118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env52117 == env52118) = true)

theorem identity52118 : scanCanonicalize (H12AffineFastState.compose env52118 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52118 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52119 : List Nat := [2,4,8,0,32,64,8,101,512,1024,576,1573,40,576,0,34,576,577,1024,1,1637,32,0,3,40,64,577,577,1572,577,1056,32,101,33,513,513]

theorem envBound52119 : H12AffineFastState.Bounded env52119 := by
  intro p hp
  have h : env52119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52118_52119 : H12AffineEnvironment.transform 3 0 env52118 = env52119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52118 == env52119) = true)

theorem identity52119 : scanCanonicalize (H12AffineFastState.compose env52119 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound52119 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env52120 : List Nat := [2,4,8,0,32,64,8,101,512,101,576,576,40,576,0,34,576,577,101,1,512,32,0,3,40,64,577,577,577,577,69,32,101,33,513,513]

theorem envBound52120 : H12AffineFastState.Bounded env52120 := by
  intro p hp
  have h : env52120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52119_52120 : H12AffineEnvironment.transform 9 101 env52119 = env52120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env52119 == env52120) = true)

theorem identity52120 : scanCanonicalize (H12AffineFastState.compose env52120 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound52120 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52121 : List Nat := [2,4,8,0,32,33,8,4,512,4,545,545,40,545,0,34,545,544,4,1,512,32,0,3,40,33,544,544,544,544,36,32,4,33,513,513]

theorem envBound52121 : H12AffineFastState.Bounded env52121 := by
  intro p hp
  have h : env52121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52120_52121 : H12AffineEnvironment.transform 5 33 env52120 = env52121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env52120 == env52121) = true)

theorem identity52121 : scanCanonicalize (H12AffineFastState.compose env52121 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52121 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52122 : List Nat := [2,4,8,0,1,0,8,4,512,4,512,512,9,512,0,3,512,513,4,1,512,1,0,3,9,0,513,513,513,513,5,1,4,0,513,513]

theorem envBound52122 : H12AffineFastState.Bounded env52122 := by
  intro p hp
  have h : env52122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52121_52122 : H12AffineEnvironment.transform 4 1 env52121 = env52122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52121 == env52122) = true)

theorem identity52122 : scanCanonicalize (H12AffineFastState.compose env52122 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52123 : List Nat := [2,4,8,0,1,0,8,4,0,4,0,0,9,0,0,3,0,1,4,1,0,1,0,3,9,0,1,1,1,1,5,1,4,0,1,1]

theorem envBound52123 : H12AffineFastState.Bounded env52123 := by
  intro p hp
  have h : env52123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52122_52123 : H12AffineEnvironment.transform 8 0 env52122 = env52123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52122 == env52123) = true)

def env52124 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,4161,4194304,16,98336,8192,64,4250709,5220,17525,23668,1057,4256861,117,21588,46092,74250]

theorem envBound52124 : H12AffineFastState.Bounded env52124 := by
  intro p hp
  have h : env52124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52110_52124 : H12AffineEnvironment.transform 20 4161 env52110 = env52124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52110 == env52124) = true)

theorem identity52124 : scanCanonicalize (H12AffineFastState.compose env52124 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52124 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52125 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1024,32769,4161,4194304,16,41003,8192,64,4250709,5220,17525,23668,1057,4256861,117,21588,46092,513]

theorem envBound52125 : H12AffineFastState.Bounded env52125 := by
  intro p hp
  have h : env52125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52124_52125 : H12AffineEnvironment.transform 15 8203 env52124 = env52125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52124 == env52125) = true)

theorem identity52125 : scanCanonicalize (H12AffineFastState.compose env52125 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52125 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52126 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34817,1024,32769,4161,4194304,16,41003,8192,64,4229152,5220,4096,2049,1057,4235304,117,33,46092,513]

theorem envBound52126 : H12AffineFastState.Bounded env52126 := by
  intro p hp
  have h : env52126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52125_52126 : H12AffineEnvironment.transform 13 5237 env52125 = env52126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52125 == env52126) = true)

theorem identity52126 : scanCanonicalize (H12AffineFastState.compose env52126 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 3102) := by decide +kernel

theorem selectedBound52126 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env52127 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34817,1024,32769,4161,3102,16,41003,8192,64,33854,5220,4096,2049,1057,44086,117,33,46092,513]

theorem envBound52127 : H12AffineFastState.Bounded env52127 := by
  intro p hp
  have h : env52127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52126_52127 : H12AffineEnvironment.transform 21 3102 env52126 = env52127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3102 env52126 == env52127) = true)

theorem identity52127 : scanCanonicalize (H12AffineFastState.compose env52127 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52127 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env52128 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,0,8203,5221,2049,1024,1,4161,3102,16,8235,8192,64,1086,5220,4096,2049,1057,11318,117,33,13324,513]

theorem envBound52128 : H12AffineFastState.Bounded env52128 := by
  intro p hp
  have h : env52128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52127_52128 : H12AffineEnvironment.transform 14 0 env52127 = env52128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52127 == env52128) = true)

theorem identity52128 : scanCanonicalize (H12AffineFastState.compose env52128 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound52128 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52129 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1135,4096,8192,5237,0,8203,5221,1134,1024,1,4161,113,16,8235,8192,64,1086,5220,4096,1134,1057,8281,117,33,13324,513]

theorem envBound52129 : H12AffineFastState.Bounded env52129 := by
  intro p hp
  have h : env52129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52128_52129 : H12AffineEnvironment.transform 10 1135 env52128 = env52129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env52128 == env52129) = true)

theorem identity52129 : scanCanonicalize (H12AffineFastState.compose env52129 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52129 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52130 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1135,4096,40,5237,0,35,5221,1134,1024,1,4161,113,16,3,40,64,1086,5220,4096,1134,1057,113,117,33,5156,513]

theorem envBound52130 : H12AffineFastState.Bounded env52130 := by
  intro p hp
  have h : env52130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52129_52130 : H12AffineEnvironment.transform 12 40 env52129 = env52130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52129 == env52130) = true)

def env52131 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,2097152,4194304,16,2199648,8192,64,6343700,5221,2118708,23669,2102369,4256860,117,21589,46093,2175562]

theorem envBound52131 : H12AffineFastState.Bounded env52131 := by
  intro p hp
  have h : env52131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52109_52131 : H12AffineEnvironment.transform 17 56437 env52109 = env52131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env52109 == env52131) = true)

theorem identity52131 : scanCanonicalize (H12AffineFastState.compose env52131 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound52131 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env52132 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,77899,4194304,16,41003,8192,64,4324447,5221,91263,23669,74794,4256860,117,21589,46093,513]

theorem envBound52132 : H12AffineFastState.Bounded env52132 := by
  intro p hp
  have h : env52132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52131_52132 : H12AffineEnvironment.transform 20 77899 env52131 = env52132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env52131 == env52132) = true)

theorem identity52132 : scanCanonicalize (H12AffineFastState.compose env52132 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound52132 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env52133 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,65536,16400,10281,1024,29789,77899,4194304,16,21623,8192,64,4261891,5221,91263,23669,74794,4194304,117,21589,16465,513]

theorem envBound52133 : H12AffineFastState.Bounded env52133 := by
  intro p hp
  have h : env52133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52132_52133 : H12AffineEnvironment.transform 14 29788 env52132 = env52133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env52132 == env52133) = true)

theorem identity52133 : scanCanonicalize (H12AffineFastState.compose env52133 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound52133 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env52134 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,65536,16400,10281,1024,29789,77899,8200,16,21623,8192,64,75787,5221,91263,23669,74794,8200,117,21589,16465,513]

theorem envBound52134 : H12AffineFastState.Bounded env52134 := by
  intro p hp
  have h : env52134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52133_52134 : H12AffineEnvironment.transform 21 8200 env52133 = env52134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env52133 == env52134) = true)

theorem identity52134 : scanCanonicalize (H12AffineFastState.compose env52134 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound52134 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env52135 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,21590,16400,10281,1024,29789,25629,8200,16,21623,8192,64,31837,5221,12329,23669,28796,8200,117,21589,16465,513]

theorem envBound52135 : H12AffineFastState.Bounded env52135 := by
  intro p hp
  have h : env52135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52134_52135 : H12AffineEnvironment.transform 15 21590 env52134 = env52135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env52134 == env52135) = true)

theorem identity52135 : scanCanonicalize (H12AffineFastState.compose env52135 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52135 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52136 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,29708,21510,16400,10281,1024,29709,25629,8200,16,21543,8192,16,31757,5173,12329,23589,28716,8200,37,21509,16385,513]

theorem envBound52136 : H12AffineFastState.Bounded env52136 := by
  intro p hp
  have h : env52136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52135_52136 : H12AffineEnvironment.transform 5 16 env52135 = env52136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52135 == env52136) = true)

theorem identity52136 : scanCanonicalize (H12AffineFastState.compose env52136 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52136 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52137 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,21540,21510,16400,2049,1024,21541,17461,32,16,21543,40,16,23589,5173,4097,23589,20484,32,37,21509,16385,513]

theorem envBound52137 : H12AffineFastState.Bounded env52137 := by
  intro p hp
  have h : env52137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52136_52137 : H12AffineEnvironment.transform 12 40 env52136 = env52137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52136 == env52137) = true)

theorem identity52137 : scanCanonicalize (H12AffineFastState.compose env52137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52138 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4113,32,16,3,40,16,2049,5173,4097,2049,1056,32,37,33,5157,513]

theorem envBound52138 : H12AffineFastState.Bounded env52138 := by
  intro p hp
  have h : env52138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52137_52138 : H12AffineEnvironment.transform 13 5156 env52137 = env52138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52137 == env52138) = true)

theorem identity52138 : scanCanonicalize (H12AffineFastState.compose env52138 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound52138 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52139 : List Nat := [2,4,8,16,32,16,8,37,512,36,2048,4096,40,4096,0,34,4112,2049,36,1,4113,32,16,3,40,16,2049,4113,4097,2049,4,32,37,33,4097,513]

theorem envBound52139 : H12AffineFastState.Bounded env52139 := by
  intro p hp
  have h : env52139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52138_52139 : H12AffineEnvironment.transform 9 36 env52138 = env52139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env52138 == env52139) = true)

theorem identity52139 : scanCanonicalize (H12AffineFastState.compose env52139 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound52139 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52140 : List Nat := [2,4,8,16,32,16,8,37,512,36,2048,512,40,512,0,34,528,2049,36,1,529,32,16,3,40,16,2049,529,513,2049,4,32,37,33,513,513]

theorem envBound52140 : H12AffineFastState.Bounded env52140 := by
  intro p hp
  have h : env52140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52139_52140 : H12AffineEnvironment.transform 11 512 env52139 = env52140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env52139 == env52140) = true)

theorem identity52140 : scanCanonicalize (H12AffineFastState.compose env52140 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52140 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52141 : List Nat := [2,4,8,16,32,16,8,37,1,36,2048,1,40,1,0,34,17,2049,36,1,16,32,16,3,40,16,2049,16,0,2049,4,32,37,33,0,0]

theorem envBound52141 : H12AffineFastState.Bounded env52141 := by
  intro p hp
  have h : env52141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52140_52141 : H12AffineEnvironment.transform 8 1 env52140 = env52141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52140 == env52141) = true)

theorem identity52141 : scanCanonicalize (H12AffineFastState.compose env52141 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52141 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52142 : List Nat := [2,4,8,0,32,0,8,37,1,36,2048,1,40,1,0,34,1,2049,36,1,0,32,0,3,40,0,2049,0,0,2049,4,32,37,33,0,0]

theorem envBound52142 : H12AffineFastState.Bounded env52142 := by
  intro p hp
  have h : env52142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52141_52142 : H12AffineEnvironment.transform 3 0 env52141 = env52142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52141 == env52142) = true)

theorem identity52142 : scanCanonicalize (H12AffineFastState.compose env52142 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52143 : List Nat := [2,4,8,0,0,0,8,5,1,4,2048,1,8,1,0,2,1,2049,4,1,0,0,0,3,8,0,2049,0,0,2049,4,0,5,1,0,0]

theorem envBound52143 : H12AffineFastState.Bounded env52143 := by
  intro p hp
  have h : env52143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52142_52143 : H12AffineEnvironment.transform 4 0 env52142 = env52143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52142 == env52143) = true)

theorem identity52143 : scanCanonicalize (H12AffineFastState.compose env52143 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52144 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,8,1,0,2,1,1,4,1,0,0,0,3,8,0,1,0,0,1,4,0,5,1,0,0]

theorem envBound52144 : H12AffineFastState.Bounded env52144 := by
  intro p hp
  have h : env52144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52143_52144 : H12AffineEnvironment.transform 10 0 env52143 = env52144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52143 == env52144) = true)

def env52145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973701,2118977,294913,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound52145 : H12AffineFastState.Bounded env52145 := by
  intro p hp
  have h : env52145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52064_52145 : H12AffineEnvironment.transform 16 16401 env52064 = env52145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52064 == env52145) = true)

theorem identity52145 : scanCanonicalize (H12AffineFastState.compose env52145 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound52145 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41310,8192,64,4530526,2172251,2118977,294913,75103,6407191,256,2188651,2196550,513]

theorem envBound52146 : H12AffineFastState.Bounded env52146 := by
  intro p hp
  have h : env52146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52145_52146 : H12AffineEnvironment.transform 23 41310 env52145 = env52146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env52145 == env52146) = true)

def env52147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41310,8192,64,4530526,115015,45405,294913,75103,4268043,256,98679,90202,513]

theorem envBound52147 : H12AffineFastState.Bounded env52147 := by
  intro p hp
  have h : env52147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52146_52147 : H12AffineEnvironment.transform 20 58396 env52146 = env52147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env52146 == env52147) = true)

theorem identity52147 : scanCanonicalize (H12AffineFastState.compose env52147 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52147 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58396,4194304,16,41310,8192,64,4456789,57676,45405,294913,1364,4194304,256,41340,16465,513]

theorem envBound52148 : H12AffineFastState.Bounded env52148 := by
  intro p hp
  have h : env52148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52147_52148 : H12AffineEnvironment.transform 15 8203 env52147 = env52148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52147 == env52148) = true)

theorem identity52148 : scanCanonicalize (H12AffineFastState.compose env52148 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272473) := by decide +kernel

theorem selectedBound52148 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58396,272473,16,41310,8192,64,10508,57676,45405,294913,1364,272473,256,41340,16465,513]

theorem envBound52149 : H12AffineFastState.Bounded env52149 := by
  intro p hp
  have h : env52149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52148_52149 : H12AffineEnvironment.transform 21 272473 env52148 = env52149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272473 env52148 == env52149) = true)

theorem identity52149 : scanCanonicalize (H12AffineFastState.compose env52149 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52149 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env52150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16401,262144,1024,0,25629,272473,16,8543,8192,64,10508,24909,12636,262144,1364,272473,256,8573,16465,513]

theorem envBound52150 : H12AffineFastState.Bounded env52150 := by
  intro p hp
  have h : env52150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52149_52150 : H12AffineEnvironment.transform 14 1 env52149 = env52150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52149 == env52150) = true)

theorem identity52150 : scanCanonicalize (H12AffineFastState.compose env52150 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound52150 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16401,2420,1024,0,25629,8493,16,8543,8192,64,10508,24909,12636,2420,1364,8493,256,8573,16465,513]

theorem envBound52151 : H12AffineFastState.Bounded env52151 := by
  intro p hp
  have h : env52151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52150_52151 : H12AffineEnvironment.transform 17 2420 env52150 = env52151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env52150 == env52151) = true)

theorem identity52151 : scanCanonicalize (H12AffineFastState.compose env52151 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52151 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,16401,2420,1024,0,17728,112,16,2,349,64,2129,16400,4097,2420,1364,112,256,32,16465,513]

theorem envBound52152 : H12AffineFastState.Bounded env52152 := by
  intro p hp
  have h : env52152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52151_52152 : H12AffineEnvironment.transform 12 349 env52151 = env52152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52151 == env52152) = true)

theorem identity52152 : scanCanonicalize (H12AffineFastState.compose env52152 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52152 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52153 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1024,0,17681,33,16,2,268,17,2048,16400,4097,2341,1285,33,256,32,16384,513]

theorem envBound52153 : H12AffineFastState.Bounded env52153 := by
  intro p hp
  have h : env52153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52152_52153 : H12AffineEnvironment.transform 5 17 env52152 = env52153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52152 == env52153) = true)

end H12CloudChart0