import H12CloudChart0Data104

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound26590 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26591 : List Nat := [2,4,8,16,32,64,8,256,512,321,0,357,349,372,80,263,308,373,321,81,372,33,65,2,349,64,0,357,308,292,68,112,256,113,293,513]

theorem envBound26591 : H12AffineFastState.Bounded env26591 := by
  intro p hp
  have h : env26591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26590_26591 : H12AffineEnvironment.transform 9 321 env26590 = env26591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26590 == env26591) = true)

theorem identity26591 : scanCanonicalize (H12AffineFastState.compose env26591 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26591 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26592 : List Nat := [2,4,8,16,32,1,8,256,512,256,0,292,284,309,17,263,308,308,256,16,309,33,0,2,284,1,0,292,308,292,5,49,256,48,293,513]

theorem envBound26592 : H12AffineFastState.Bounded env26592 := by
  intro p hp
  have h : env26592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26591_26592 : H12AffineEnvironment.transform 5 1 env26591 = env26592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26591 == env26592) = true)

theorem identity26592 : scanCanonicalize (H12AffineFastState.compose env26592 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound26592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26593 : List Nat := [2,4,8,16,32,1,8,256,293,256,0,292,284,309,17,263,308,308,256,16,309,33,0,2,284,1,0,292,308,292,5,49,256,48,293,292]

theorem envBound26593 : H12AffineFastState.Bounded env26593 := by
  intro p hp
  have h : env26593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26592_26593 : H12AffineEnvironment.transform 8 293 env26592 = env26593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env26592 == env26593) = true)

theorem identity26593 : scanCanonicalize (H12AffineFastState.compose env26593 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26594 : List Nat := [2,4,8,16,32,1,8,20,49,20,0,48,8,33,17,19,32,32,20,16,33,33,0,2,8,1,0,48,32,48,5,49,20,48,49,48]

theorem envBound26594 : H12AffineFastState.Bounded env26594 := by
  intro p hp
  have h : env26594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26593_26594 : H12AffineEnvironment.transform 7 20 env26593 = env26594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26593 == env26594) = true)

theorem identity26594 : scanCanonicalize (H12AffineFastState.compose env26594 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26595 : List Nat := [2,4,8,16,1,1,8,20,16,20,0,17,8,0,17,19,1,1,20,16,0,0,0,2,8,1,0,17,1,17,5,16,20,17,16,17]

theorem envBound26595 : H12AffineFastState.Bounded env26595 := by
  intro p hp
  have h : env26595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26594_26595 : H12AffineEnvironment.transform 4 1 env26594 = env26595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26594 == env26595) = true)

theorem identity26595 : scanCanonicalize (H12AffineFastState.compose env26595 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26595 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26596 : List Nat := [2,4,8,0,1,1,8,4,0,4,0,1,8,0,1,3,1,1,4,0,0,0,0,2,8,1,0,1,1,1,5,0,4,1,0,1]

theorem envBound26596 : H12AffineFastState.Bounded env26596 := by
  intro p hp
  have h : env26596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26595_26596 : H12AffineEnvironment.transform 3 0 env26595 = env26596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26595 == env26596) = true)

def env26597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,3,8193,64,4302890,2196487,2159645,43049,75102,6382922,256,2188650,2196550,513]

theorem envBound26597 : H12AffineFastState.Bounded env26597 := by
  intro p hp
  have h : env26597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26581_26597 : H12AffineEnvironment.transform 6 9 env26581 = env26597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26581 == env26597) = true)

theorem identity26597 : scanCanonicalize (H12AffineFastState.compose env26597 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 50497) := by decide +kernel

theorem selectedBound26597 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env26598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,50497,4194304,41292,3,8193,64,4302890,82246,12636,43049,75102,4300811,256,106539,82183,513]

theorem envBound26598 : H12AffineFastState.Bounded env26598 := by
  intro p hp
  have h : env26598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26597_26598 : H12AffineEnvironment.transform 20 50497 env26597 = env26598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50497 env26597 == env26598) = true)

theorem identity26598 : scanCanonicalize (H12AffineFastState.compose env26598 (packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound26598 : packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS < 2^1333 := by decide +kernel

def env26599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57677,10280,1024,32769,50497,4194304,41292,3,8193,64,4237692,16400,12636,43049,9224,4235613,256,41341,16465,513]

theorem envBound26599 : H12AffineFastState.Bounded env26599 := by
  intro p hp
  have h : env26599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26598_26599 : H12AffineEnvironment.transform 15 342 env26598 = env26599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env26598 == env26599) = true)

theorem identity26599 : scanCanonicalize (H12AffineFastState.compose env26599 (packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound26599 : packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57677,10280,1024,32769,50497,41340,41292,3,8193,64,2048,16400,12636,43049,9224,33,256,41341,16465,513]

theorem envBound26600 : H12AffineFastState.Bounded env26600 := by
  intro p hp
  have h : env26600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26599_26600 : H12AffineEnvironment.transform 21 41340 env26599 = env26600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env26599 == env26600) = true)

theorem identity26600 : scanCanonicalize (H12AffineFastState.compose env26600 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26600 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16401,10280,1024,8541,25629,32,16,3,8193,64,2048,16400,12636,2421,9224,33,256,33,16465,513]

theorem envBound26601 : H12AffineFastState.Bounded env26601 := by
  intro p hp
  have h : env26601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26600_26601 : H12AffineEnvironment.transform 14 8540 env26600 = env26601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26600 == env26601) = true)

def env26602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41292,16777216,8328,64,21080104,18973837,2159645,43048,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound26602 : H12AffineFastState.Bounded env26602 := by
  intro p hp
  have h : env26602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26579_26602 : H12AffineEnvironment.transform 17 10281 env26579 = env26602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26579 == env26602) = true)

theorem identity26602 : scanCanonicalize (H12AffineFastState.compose env26602 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41430) := by decide +kernel

theorem selectedBound26602 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41292,41430,8328,64,4262398,2172251,2159645,43048,99467,6407190,256,2212918,2172307,41821]

theorem envBound26603 : H12AffineFastState.Bounded env26603 := by
  intro p hp
  have h : env26603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26602_26603 : H12AffineEnvironment.transform 23 41430 env26602 = env26603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41430 env26602 == env26603) = true)

def env26604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41292,41310,8192,64,4262262,2172251,2159645,43048,99331,6407190,256,2212918,2172187,41821]

theorem envBound26604 : H12AffineFastState.Bounded env26604 := by
  intro p hp
  have h : env26604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26603_26604 : H12AffineEnvironment.transform 6 8 env26603 = env26604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26603 == env26604) = true)

theorem identity26604 : scanCanonicalize (H12AffineFastState.compose env26604 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26604 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10281,1024,32769,2097152,4194304,41292,41310,8192,64,4229153,2139148,2159645,43048,1364,6309185,256,2114913,2139212,41821]

theorem envBound26605 : H12AffineFastState.Bounded env26605 := by
  intro p hp
  have h : env26605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26604_26605 : H12AffineEnvironment.transform 15 33111 env26604 = env26605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26604 == env26605) = true)

theorem identity26605 : scanCanonicalize (H12AffineFastState.compose env26605 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound26605 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env26606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10281,1024,32769,2097152,2122860,41292,41310,8192,64,2157645,2139148,2159645,43048,1364,8493,256,2114913,2139212,41821]

theorem envBound26606 : H12AffineFastState.Bounded env26606 := by
  intro p hp
  have h : env26606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26605_26606 : H12AffineEnvironment.transform 21 2122860 env26605 = env26606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env26605 == env26606) = true)

theorem identity26606 : scanCanonicalize (H12AffineFastState.compose env26606 (packedSelected [0,7,9,12,14,15,16,17,22] rootPS)) = affineNative (2^(20+1) ^^^ 49445) := by decide +kernel

theorem selectedBound26606 : packedSelected [0,7,9,12,14,15,16,17,22] rootPS < 2^1333 := by decide +kernel

def env26607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10281,1024,32769,49445,42313,41292,41310,8192,64,11624,25897,13624,43048,1364,8493,256,33860,25961,41821]

theorem envBound26607 : H12AffineFastState.Bounded env26607 := by
  intro p hp
  have h : env26607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26606_26607 : H12AffineEnvironment.transform 20 49445 env26606 = env26607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49445 env26606 == env26607) = true)

theorem identity26607 : scanCanonicalize (H12AffineFastState.compose env26607 (packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound26607 : packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env26608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,262,24860,10281,1024,80,16756,9496,8477,8463,8192,64,11624,25897,13624,10361,1364,8493,256,1045,25961,8972]

theorem envBound26608 : H12AffineFastState.Bounded env26608 := by
  intro p hp
  have h : env26608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26607_26608 : H12AffineEnvironment.transform 14 81 env26607 = env26608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env26607 == env26608) = true)

theorem identity26608 : scanCanonicalize (H12AffineFastState.compose env26608 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound26608 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env26609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12573,81,262,4097,10281,1024,80,12393,9496,8477,8463,8192,64,11624,5172,13624,10361,1364,8493,256,1045,5236,8972]

theorem envBound26609 : H12AffineFastState.Bounded env26609 := by
  intro p hp
  have h : env26609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26608_26609 : H12AffineEnvironment.transform 13 12573 env26608 = env26609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env26608 == env26609) = true)

theorem identity26609 : scanCanonicalize (H12AffineFastState.compose env26609 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26609 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26610 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12573,81,262,4097,10281,52,80,12393,8492,8477,8463,8192,64,10588,4096,12556,10361,352,8493,256,33,4160,8972]

theorem envBound26610 : H12AffineFastState.Bounded env26610 := by
  intro p hp
  have h : env26610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26609_26610 : H12AffineEnvironment.transform 9 52 env26609 = env26610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26609 == env26610) = true)

theorem identity26610 : scanCanonicalize (H12AffineFastState.compose env26610 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound26610 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env26611 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,9,4372,81,262,4097,2080,52,80,4192,293,276,262,9,64,2389,4096,4357,2160,352,292,256,33,4160,773]

theorem envBound26611 : H12AffineFastState.Bounded env26611 := by
  intro p hp
  have h : env26611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26610_26611 : H12AffineEnvironment.transform 12 9 env26610 = env26611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env26610 == env26611) = true)

theorem identity26611 : scanCanonicalize (H12AffineFastState.compose env26611 (packedSelected [3,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound26611 : packedSelected [3,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26612 : List Nat := [2,4,8,16,32,64,8,256,512,52,560,4096,9,4372,81,262,4097,528,52,80,4192,293,276,262,9,64,869,4096,4357,576,352,292,256,33,4160,773]

theorem envBound26612 : H12AffineFastState.Bounded env26612 := by
  intro p hp
  have h : env26612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26611_26612 : H12AffineEnvironment.transform 10 560 env26611 = env26612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env26611 == env26612) = true)

theorem identity26612 : scanCanonicalize (H12AffineFastState.compose env26612 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26612 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26613 : List Nat := [2,4,8,16,32,64,8,5,512,52,560,4096,9,4113,81,3,4097,528,52,80,4192,32,17,3,9,64,608,4096,4096,576,101,33,5,33,4160,512]

theorem envBound26613 : H12AffineFastState.Bounded env26613 := by
  intro p hp
  have h : env26613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26612_26613 : H12AffineEnvironment.transform 7 5 env26612 = env26613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26612 == env26613) = true)

theorem identity26613 : scanCanonicalize (H12AffineFastState.compose env26613 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound26613 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26614 : List Nat := [2,4,8,16,27,64,8,5,512,15,523,4096,9,4113,81,3,4097,528,15,80,4187,27,17,3,9,64,603,4096,4096,576,94,26,5,26,4160,512]

theorem envBound26614 : H12AffineFastState.Bounded env26614 := by
  intro p hp
  have h : env26614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26613_26614 : H12AffineEnvironment.transform 4 27 env26613 = env26614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env26613 == env26614) = true)

theorem identity26614 : scanCanonicalize (H12AffineFastState.compose env26614 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26614 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26615 : List Nat := [2,4,8,16,27,16,8,5,512,15,523,4096,9,4113,1,3,4097,528,15,0,4107,27,17,3,9,16,523,4096,4096,528,14,26,5,26,4112,512]

theorem envBound26615 : H12AffineFastState.Bounded env26615 := by
  intro p hp
  have h : env26615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26614_26615 : H12AffineEnvironment.transform 5 16 env26614 = env26615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26614 == env26615) = true)

theorem identity26615 : scanCanonicalize (H12AffineFastState.compose env26615 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound26615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26616 : List Nat := [2,4,8,16,27,16,8,5,4,15,15,4096,9,4113,1,3,4097,20,15,0,4107,27,17,3,9,16,15,4096,4096,20,14,26,5,26,4112,4]

theorem envBound26616 : H12AffineFastState.Bounded env26616 := by
  intro p hp
  have h : env26616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26615_26616 : H12AffineEnvironment.transform 8 4 env26615 = env26616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env26615 == env26616) = true)

theorem identity26616 : scanCanonicalize (H12AffineFastState.compose env26616 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound26616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26617 : List Nat := [2,4,8,16,27,16,8,5,4,15,15,22,9,7,1,3,23,20,15,0,29,27,17,3,9,16,15,22,22,20,14,26,5,26,6,4]

theorem envBound26617 : H12AffineFastState.Bounded env26617 := by
  intro p hp
  have h : env26617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26616_26617 : H12AffineEnvironment.transform 11 22 env26616 = env26617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env26616 == env26617) = true)

theorem identity26617 : scanCanonicalize (H12AffineFastState.compose env26617 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26617 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26618 : List Nat := [2,4,8,0,11,0,8,5,4,15,15,6,9,7,1,3,7,4,15,0,13,11,1,3,9,0,15,6,6,4,14,10,5,10,6,4]

theorem envBound26618 : H12AffineFastState.Bounded env26618 := by
  intro p hp
  have h : env26618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26617_26618 : H12AffineEnvironment.transform 3 0 env26617 = env26618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26617 == env26618) = true)

theorem identity26618 : scanCanonicalize (H12AffineFastState.compose env26618 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26618 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26619 : List Nat := [2,4,3,0,0,0,3,5,4,4,4,6,2,7,1,3,7,4,4,0,6,0,1,3,2,0,4,6,6,4,5,1,5,1,6,4]

theorem envBound26619 : H12AffineFastState.Bounded env26619 := by
  intro p hp
  have h : env26619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26618_26619 : H12AffineEnvironment.transform 2 3 env26618 = env26619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26618 == env26619) = true)

def env26620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41292,41311,8193,64,4262263,2172251,2159645,43048,99330,6407190,256,2212918,2172186,41821]

theorem envBound26620 : H12AffineFastState.Bounded env26620 := by
  intro p hp
  have h : env26620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26603_26620 : H12AffineEnvironment.transform 6 9 env26603 = env26620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26603 == env26620) = true)

theorem identity26620 : scanCanonicalize (H12AffineFastState.compose env26620 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26620 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57677,10281,1024,32769,2097152,4194304,41292,41311,8193,64,4204924,2098512,2159645,43048,41993,6349853,256,2155581,2098449,41821]

theorem envBound26621 : H12AffineFastState.Bounded env26621 := by
  intro p hp
  have h : env26621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26620_26621 : H12AffineEnvironment.transform 15 8203 env26620 = env26621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26620 == env26621) = true)

theorem identity26621 : scanCanonicalize (H12AffineFastState.compose env26621 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound26621 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env26622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45404,10281,1024,32769,2097152,4194304,41292,41311,8193,64,4204924,2098512,2139148,43048,41993,6337548,256,2143276,2098449,41821]

theorem envBound26622 : H12AffineFastState.Bounded env26622 := by
  intro p hp
  have h : env26622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26621_26622 : H12AffineEnvironment.transform 13 4113 env26621 = env26622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env26621 == env26622) = true)

theorem identity26622 : scanCanonicalize (H12AffineFastState.compose env26622 (packedSelected [0,1,3,4,5,7,8,10,11,16,19,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 340) := by decide +kernel

theorem selectedBound26622 : packedSelected [0,1,3,4,5,7,8,10,11,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env26623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45404,10281,1024,32769,2097152,340,41292,41311,8193,64,10280,2098512,2139148,43048,41993,2143576,256,2143276,2098449,41821]

theorem envBound26623 : H12AffineFastState.Bounded env26623 := by
  intro p hp
  have h : env26623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26622_26623 : H12AffineEnvironment.transform 21 340 env26622 = env26623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 340 env26622 == env26623) = true)

theorem identity26623 : scanCanonicalize (H12AffineFastState.compose env26623 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound26623 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45404,10281,1024,32769,5457,340,41292,41311,8193,64,10280,4097,45405,43048,41993,40969,256,41341,4160,41821]

theorem envBound26624 : H12AffineFastState.Bounded env26624 := by
  intro p hp
  have h : env26624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26623_26624 : H12AffineEnvironment.transform 20 5457 env26623 = env26624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env26623 == env26624) = true)

theorem identity26624 : scanCanonicalize (H12AffineFastState.compose env26624 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound26624 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env26625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8233,8203,4469,10281,1024,8232,5457,340,357,374,8193,64,10280,4097,4468,2049,1056,32,256,340,4160,884]

theorem envBound26625 : H12AffineFastState.Bounded env26625 := by
  intro p hp
  have h : env26625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26624_26625 : H12AffineEnvironment.transform 14 8233 env26624 = env26625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env26624 == env26625) = true)

theorem identity26625 : scanCanonicalize (H12AffineFastState.compose env26625 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound26625 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26626 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,8192,4113,8233,8203,4469,10281,320,8232,4113,340,357,374,8193,64,10280,4097,4468,2049,352,32,256,340,4160,884]

theorem envBound26626 : H12AffineFastState.Bounded env26626 := by
  intro p hp
  have h : env26626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26625_26626 : H12AffineEnvironment.transform 9 320 env26625 = env26626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26625 == env26626) = true)

theorem identity26626 : scanCanonicalize (H12AffineFastState.compose env26626 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound26626 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26627 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,356,8192,373,8233,8203,17,10281,320,8232,373,340,357,374,8193,64,10280,357,16,2049,352,32,256,340,292,884]

theorem envBound26627 : H12AffineFastState.Bounded env26627 := by
  intro p hp
  have h : env26627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26626_26627 : H12AffineEnvironment.transform 11 356 env26626 = env26627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env26626 == env26627) = true)

theorem identity26627 : scanCanonicalize (H12AffineFastState.compose env26627 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound26627 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26628 : List Nat := [2,4,8,16,32,64,9,256,512,320,80,356,8192,373,8233,8203,17,8313,320,8232,373,340,357,374,8193,64,8312,357,16,81,352,32,256,340,292,884]

theorem envBound26628 : H12AffineFastState.Bounded env26628 := by
  intro p hp
  have h : env26628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26627_26628 : H12AffineEnvironment.transform 10 80 env26627 = env26628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env26627 == env26628) = true)

theorem identity26628 : scanCanonicalize (H12AffineFastState.compose env26628 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26628 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26629 : List Nat := [2,4,8,16,32,64,9,256,512,320,80,356,348,373,373,343,17,293,320,372,373,340,357,374,349,64,292,357,16,81,352,32,256,340,292,884]

theorem envBound26629 : H12AffineFastState.Bounded env26629 := by
  intro p hp
  have h : env26629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26628_26629 : H12AffineEnvironment.transform 12 348 env26628 = env26629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26628 == env26629) = true)

theorem identity26629 : scanCanonicalize (H12AffineFastState.compose env26629 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound26629 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26630 : List Nat := [2,4,8,16,32,64,9,256,65,320,80,356,348,373,373,343,17,293,320,372,373,340,357,374,349,64,292,357,16,81,352,32,256,340,292,309]

theorem envBound26630 : H12AffineFastState.Bounded env26630 := by
  intro p hp
  have h : env26630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26629_26630 : H12AffineEnvironment.transform 8 65 env26629 = env26630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env26629 == env26630) = true)

theorem identity26630 : scanCanonicalize (H12AffineFastState.compose env26630 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26630 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26631 : List Nat := [2,4,8,16,32,16,9,256,17,272,0,308,268,293,293,263,17,293,272,292,293,260,309,294,269,16,292,309,16,1,304,32,256,260,292,309]

theorem envBound26631 : H12AffineFastState.Bounded env26631 := by
  intro p hp
  have h : env26631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26630_26631 : H12AffineEnvironment.transform 5 16 env26630 = env26631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26630 == env26631) = true)

theorem identity26631 : scanCanonicalize (H12AffineFastState.compose env26631 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26631 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env26632 : List Nat := [2,4,8,16,32,16,9,5,17,21,0,49,9,32,32,2,17,32,21,33,32,1,48,35,8,16,33,48,16,1,53,32,5,1,33,48]

theorem envBound26632 : H12AffineFastState.Bounded env26632 := by
  intro p hp
  have h : env26632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26631_26632 : H12AffineEnvironment.transform 7 5 env26631 = env26632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26631 == env26632) = true)

def env26633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound26633 : H12AffineFastState.Bounded env26633 := by
  intro p hp
  have h : env26633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26532_26633 : H12AffineEnvironment.transform 18 1025 env26532 = env26633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26532 == env26633) = true)

theorem identity26633 : scanCanonicalize (H12AffineFastState.compose env26633 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213452) := by decide +kernel

theorem selectedBound26633 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213452,8328,64,12878285,2278720,10507601,8830977,8570333,6431756,257,10650977,10642629,8643082]

theorem envBound26634 : H12AffineFastState.Bounded env26634 := by
  intro p hp
  have h : env26634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26633_26634 : H12AffineEnvironment.transform 23 213452 env26633 = env26634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213452 env26633 == env26634) = true)

def env26635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281536,213452,8328,64,6705549,2278720,165137,2363457,2102685,6431756,257,21793,46213,2175562]

theorem envBound26635 : H12AffineFastState.Bounded env26635 := by
  intro p hp
  have h : env26635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26634_26635 : H12AffineEnvironment.transform 22 2281536 env26634 = env26635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281536 env26634 == env26635) = true)

def env26636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590877,2098512,17665,2363457,2102685,6349852,257,21793,46213,2175562]

theorem envBound26636 : H12AffineFastState.Bounded env26636 := by
  intro p hp
  have h : env26636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26635_26636 : H12AffineEnvironment.transform 16 49168 env26635 = env26636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26635 == env26636) = true)

def env26637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144541,2098512,17665,2363457,2102685,2411676,257,21793,46213,2175562]

theorem envBound26637 : H12AffineFastState.Bounded env26637 := by
  intro p hp
  have h : env26637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26636_26637 : H12AffineEnvironment.transform 21 272512 env26636 = env26637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26636 == env26637) = true)

theorem identity26637 : scanCanonicalize (H12AffineFastState.compose env26637 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26637 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272512,2101328,41430,8328,64,2144541,2098512,17665,2363457,2102685,2411676,257,21793,46213,2101824]

theorem envBound26638 : H12AffineFastState.Bounded env26638 := by
  intro p hp
  have h : env26638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26637_26638 : H12AffineEnvironment.transform 15 8202 env26637 = env26638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26637 == env26638) = true)

theorem identity26638 : scanCanonicalize (H12AffineFastState.compose env26638 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 268732) := by decide +kernel

theorem selectedBound26638 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,268732,272512,264684,41430,8328,64,303265,269548,17665,2557,265249,54560,257,21793,46213,265212]

theorem envBound26639 : H12AffineFastState.Bounded env26639 := by
  intro p hp
  have h : env26639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26638_26639 : H12AffineEnvironment.transform 20 268732 env26638 = env26639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268732 env26638 == env26639) = true)

theorem identity26639 : scanCanonicalize (H12AffineFastState.compose env26639 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound26639 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env26640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35324,1025,32769,36928,41340,32784,41430,8328,64,10589,38160,17665,2557,34269,54560,257,21793,46213,33280]

theorem envBound26640 : H12AffineFastState.Bounded env26640 := by
  intro p hp
  have h : env26640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26639_26640 : H12AffineEnvironment.transform 17 35324 env26639 = env26640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env26639 == env26640) = true)

theorem identity26640 : scanCanonicalize (H12AffineFastState.compose env26640 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound26640 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8202,16537,2421,1025,136,4297,8693,153,8543,8328,64,10589,5529,17665,2557,1364,21929,257,21793,13324,649]

theorem envBound26641 : H12AffineFastState.Bounded env26641 := by
  intro p hp
  have h : env26641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26640_26641 : H12AffineEnvironment.transform 14 137 env26640 = env26641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env26640 == env26641) = true)

theorem identity26641 : scanCanonicalize (H12AffineFastState.compose env26641 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound26641 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,479,16537,2421,1025,136,4297,32,153,138,349,64,2184,5529,17665,2557,1364,21929,257,21793,5593,649]

theorem envBound26642 : H12AffineFastState.Bounded env26642 := by
  intro p hp
  have h : env26642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26641_26642 : H12AffineEnvironment.transform 12 469 env26641 = env26642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env26641 == env26642) = true)

theorem identity26642 : scanCanonicalize (H12AffineFastState.compose env26642 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26642 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env26643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,137,479,5529,2421,1025,136,4297,32,153,138,349,64,2184,5529,4097,2557,1364,169,257,33,5593,649]

theorem envBound26643 : H12AffineFastState.Bounded env26643 := by
  intro p hp
  have h : env26643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26642_26643 : H12AffineEnvironment.transform 13 5376 env26642 = env26643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26642 == env26643) = true)

theorem identity26643 : scanCanonicalize (H12AffineFastState.compose env26643 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound26643 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26644 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,40,5373,137,34,5220,2184,1025,136,4297,32,153,138,160,64,2184,5220,4097,2048,1193,169,252,33,5156,649]

theorem envBound26644 : H12AffineFastState.Bounded env26644 := by
  intro p hp
  have h : env26644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26643_26644 : H12AffineEnvironment.transform 7 253 env26643 = env26644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env26643 == env26644) = true)

theorem identity26644 : scanCanonicalize (H12AffineFastState.compose env26644 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound26644 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26645 : List Nat := [2,4,8,16,32,64,128,253,512,1024,136,4096,40,5373,137,34,5220,0,1025,136,4297,32,153,138,160,64,0,5220,4097,136,1193,169,252,33,5156,649]

theorem envBound26645 : H12AffineFastState.Bounded env26645 := by
  intro p hp
  have h : env26645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26644_26645 : H12AffineEnvironment.transform 10 136 env26644 = env26645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env26644 == env26645) = true)

theorem identity26645 : scanCanonicalize (H12AffineFastState.compose env26645 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound26645 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26646 : List Nat := [2,4,8,16,32,64,128,253,512,204,136,4096,40,4145,137,34,4264,0,205,136,4297,32,153,138,160,64,0,4264,4097,136,101,169,252,33,4328,649]

theorem envBound26646 : H12AffineFastState.Bounded env26646 := by
  intro p hp
  have h : env26646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26645_26646 : H12AffineEnvironment.transform 9 204 env26645 = env26646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env26645 == env26646) = true)

def env26647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144540,2098512,17665,2363457,2102685,2411677,257,21793,46213,2175562]

theorem envBound26647 : H12AffineFastState.Bounded env26647 := by
  intro p hp
  have h : env26647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26636_26647 : H12AffineEnvironment.transform 21 272513 env26636 = env26647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26636 == env26647) = true)

theorem identity26647 : scanCanonicalize (H12AffineFastState.compose env26647 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound26647 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272513,73755,98780,8328,64,100695,79131,17665,335882,75222,392406,257,21793,46213,513]

theorem envBound26648 : H12AffineFastState.Bounded env26648 := by
  intro p hp
  have h : env26648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26647_26648 : H12AffineEnvironment.transform 20 77899 env26647 = env26648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env26647 == env26648) = true)

def env26649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272393,73755,98644,8192,64,100695,79131,17665,335882,75102,392286,257,21793,46093,513]

theorem envBound26649 : H12AffineFastState.Bounded env26649 := by
  intro p hp
  have h : env26649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26648_26649 : H12AffineEnvironment.transform 6 8 env26648 = env26649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26648 == env26649) = true)

theorem identity26649 : scanCanonicalize (H12AffineFastState.compose env26649 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound26649 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,77899,41341,73755,98644,8192,64,100695,79131,17665,108926,75102,95530,257,21793,46093,513]

theorem envBound26650 : H12AffineFastState.Bounded env26650 := by
  intro p hp
  have h : env26650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26649_26650 : H12AffineEnvironment.transform 17 35188 env26649 = env26650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env26649 == env26650) = true)

theorem identity26650 : scanCanonicalize (H12AffineFastState.compose env26650 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26650 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32041,1025,29788,77899,21792,73755,95497,8192,64,97546,79131,17665,89379,75102,95530,257,21793,16464,513]

theorem envBound26651 : H12AffineFastState.Bounded env26651 := by
  intro p hp
  have h : env26651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26650_26651 : H12AffineEnvironment.transform 14 29789 env26650 = env26651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26650 == env26651) = true)

theorem identity26651 : scanCanonicalize (H12AffineFastState.compose env26651 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26651 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env26652 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,13340,32041,1025,29709,77850,21792,73755,95497,8192,17,97546,79131,17665,89379,75023,95530,257,21793,16385,513]

theorem envBound26652 : H12AffineFastState.Bounded env26652 := by
  intro p hp
  have h : env26652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26651_26652 : H12AffineEnvironment.transform 5 17 env26651 = env26652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26651 == env26652) = true)

theorem identity26652 : scanCanonicalize (H12AffineFastState.compose env26652 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound26652 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env26653 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,29963,13340,32041,1025,29709,17681,21792,21776,2,8192,17,2049,16400,17665,10280,20484,33,257,21793,16385,513]

theorem envBound26653 : H12AffineFastState.Bounded env26653 := by
  intro p hp
  have h : env26653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26652_26653 : H12AffineEnvironment.transform 15 29963 env26652 = env26653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env26652 == env26653) = true)

theorem identity26653 : scanCanonicalize (H12AffineFastState.compose env26653 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound26653 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26654 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12572,1296,1047,13340,3125,1025,1297,13325,9276,9228,2,8192,17,2049,12556,13341,10280,8472,33,257,9277,12573,513]

theorem envBound26654 : H12AffineFastState.Bounded env26654 := by
  intro p hp
  have h : env26654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26653_26654 : H12AffineEnvironment.transform 13 12572 env26653 = env26654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env26653 == env26654) = true)

theorem identity26654 : scanCanonicalize (H12AffineFastState.compose env26654 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound26654 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env26655 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1053,5377,1296,1047,4097,3125,1025,1297,4112,33,17,2,1053,17,2049,5393,4096,3125,1285,33,257,32,5376,513]

theorem envBound26655 : H12AffineFastState.Bounded env26655 := by
  intro p hp
  have h : env26655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26654_26655 : H12AffineEnvironment.transform 12 1053 env26654 = env26655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env26654 == env26655) = true)

theorem identity26655 : scanCanonicalize (H12AffineFastState.compose env26655 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound26655 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26656 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3076,1053,2309,1296,1047,3077,3125,1025,1297,3092,33,17,2,1053,17,2049,2325,3076,3125,1285,33,257,32,2308,513]

theorem envBound26656 : H12AffineFastState.Bounded env26656 := by
  intro p hp
  have h : env26656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26655_26656 : H12AffineEnvironment.transform 11 3076 env26655 = env26656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env26655 == env26656) = true)

theorem identity26656 : scanCanonicalize (H12AffineFastState.compose env26656 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound26656 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26657 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,2356,301,2309,32,295,2357,2309,305,33,2340,33,17,2,301,17,2049,2325,2356,2309,53,33,257,32,2308,513]

theorem envBound26657 : H12AffineFastState.Bounded env26657 := by
  intro p hp
  have h : env26657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26656_26657 : H12AffineEnvironment.transform 9 304 env26656 = env26657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env26656 == env26657) = true)

theorem identity26657 : scanCanonicalize (H12AffineFastState.compose env26657 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26657 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26658 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,2324,269,2309,0,263,2325,2309,273,1,2308,1,17,2,269,17,2049,2325,2324,2309,21,1,257,0,2308,513]

theorem envBound26658 : H12AffineFastState.Bounded env26658 := by
  intro p hp
  have h : env26658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26657_26658 : H12AffineEnvironment.transform 4 0 env26657 = env26658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26657 == env26658) = true)

theorem identity26658 : scanCanonicalize (H12AffineFastState.compose env26658 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26659 : List Nat := [2,4,8,16,0,17,8,256,512,272,1,277,269,260,0,263,276,260,273,1,261,1,17,2,269,17,0,276,277,260,21,1,257,0,261,513]

theorem envBound26659 : H12AffineFastState.Bounded env26659 := by
  intro p hp
  have h : env26659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26658_26659 : H12AffineEnvironment.transform 10 1 env26658 = env26659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26658 == env26659) = true)

def env26660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272392,73755,98645,8193,64,100695,79131,17665,335882,75103,392287,257,21793,46092,513]

theorem envBound26660 : H12AffineFastState.Bounded env26660 := by
  intro p hp
  have h : env26660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26648_26660 : H12AffineEnvironment.transform 6 9 env26648 = env26660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26648 == env26660) = true)

theorem identity26660 : scanCanonicalize (H12AffineFastState.compose env26660 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound26660 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49168,262144,1025,32769,36929,272392,32785,8543,8193,64,10589,38161,17665,294912,34133,285781,257,21793,46092,513]

theorem envBound26661 : H12AffineFastState.Bounded env26661 := by
  intro p hp
  have h : env26661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26660_26661 : H12AffineEnvironment.transform 15 40970 env26660 = env26661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env26660 == env26661) = true)

theorem identity26661 : scanCanonicalize (H12AffineFastState.compose env26661 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound26661 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1345,9547,17745,262144,1025,1344,5376,272392,1360,8543,8193,64,10589,4176,17665,263489,20,285781,257,21793,12621,513]

theorem envBound26662 : H12AffineFastState.Bounded env26662 := by
  intro p hp
  have h : env26662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26661_26662 : H12AffineEnvironment.transform 14 1345 env26661 = env26662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env26661 == env26662) = true)

theorem identity26662 : scanCanonicalize (H12AffineFastState.compose env26662 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26662 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env26663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1345,9547,4097,262144,1025,1344,5376,272392,1360,8543,8193,64,10589,4176,4177,263489,20,264453,257,113,12621,513]

theorem envBound26663 : H12AffineFastState.Bounded env26663 := by
  intro p hp
  have h : env26663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26662_26663 : H12AffineEnvironment.transform 13 5456 env26662 = env26663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26662 == env26663) = true)

theorem identity26663 : scanCanonicalize (H12AffineFastState.compose env26663 (packedSelected [17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound26663 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env26664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1345,9547,4097,2421,1025,1344,5376,8573,1360,8543,8193,64,10589,4176,4177,3124,20,112,257,113,12621,513]

theorem envBound26664 : H12AffineFastState.Bounded env26664 := by
  intro p hp
  have h : env26664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26663_26664 : H12AffineEnvironment.transform 17 2421 env26663 = env26664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env26663 == env26664) = true)

theorem identity26664 : scanCanonicalize (H12AffineFastState.compose env26664 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound26664 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26665 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,4113,0,8202,4097,2421,320,1,4161,8573,17,8543,8193,64,10589,4176,4177,2421,20,112,257,113,12621,513]

theorem envBound26665 : H12AffineFastState.Bounded env26665 := by
  intro p hp
  have h : env26665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26664_26665 : H12AffineEnvironment.transform 9 321 env26664 = env26665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26664 == env26665) = true)

theorem identity26665 : scanCanonicalize (H12AffineFastState.compose env26665 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26665 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26666 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,269,4113,0,263,4097,2421,320,1,4161,112,17,82,268,64,2128,4176,4177,2421,20,112,257,113,4160,513]

theorem envBound26666 : H12AffineFastState.Bounded env26666 := by
  intro p hp
  have h : env26666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26665_26666 : H12AffineEnvironment.transform 12 269 env26665 = env26666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26665 == env26666) = true)

theorem identity26666 : scanCanonicalize (H12AffineFastState.compose env26666 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound26666 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env26667 : List Nat := [2,4,8,16,32,64,9,256,113,321,2048,4096,269,4113,0,263,4097,2421,320,1,4161,112,17,82,268,64,2128,4176,4177,2421,20,112,257,113,4160,112]

theorem envBound26667 : H12AffineFastState.Bounded env26667 := by
  intro p hp
  have h : env26667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26666_26667 : H12AffineEnvironment.transform 8 113 env26666 = env26667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env26666 == env26667) = true)

theorem identity26667 : scanCanonicalize (H12AffineFastState.compose env26667 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26667 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env26668 : List Nat := [2,4,8,16,17,64,9,256,64,321,2048,4096,269,4113,0,263,4097,2372,320,1,4161,65,17,82,268,64,2128,4176,4177,2372,20,65,257,64,4160,65]

theorem envBound26668 : H12AffineFastState.Bounded env26668 := by
  intro p hp
  have h : env26668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26667_26668 : H12AffineEnvironment.transform 4 17 env26667 = env26668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26667 == env26668) = true)

theorem identity26668 : scanCanonicalize (H12AffineFastState.compose env26668 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound26668 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26669 : List Nat := [2,4,8,16,17,64,9,256,64,321,325,4096,269,4113,0,263,4097,1,320,1,4161,65,17,82,268,64,277,4176,4177,1,20,65,257,64,4160,65]

theorem envBound26669 : H12AffineFastState.Bounded env26669 := by
  intro p hp
  have h : env26669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26668_26669 : H12AffineEnvironment.transform 10 325 env26668 = env26669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env26668 == env26669) = true)

theorem identity26669 : scanCanonicalize (H12AffineFastState.compose env26669 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26669 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26670 : List Nat := [2,4,8,16,17,64,9,20,64,85,81,4096,25,4113,0,19,4097,1,84,1,4161,65,17,82,24,64,1,4176,4177,1,20,65,21,64,4160,65]

theorem envBound26670 : H12AffineFastState.Bounded env26670 := by
  intro p hp
  have h : env26670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26669_26670 : H12AffineEnvironment.transform 7 20 env26669 = env26670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26669 == env26670) = true)

theorem identity26670 : scanCanonicalize (H12AffineFastState.compose env26670 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 75) := by decide +kernel

theorem selectedBound26670 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26671 : List Nat := [2,4,8,16,17,64,9,20,64,85,81,75,25,90,0,19,74,1,84,1,10,65,17,82,24,64,1,27,26,1,20,65,21,64,11,65]

theorem envBound26671 : H12AffineFastState.Bounded env26671 := by
  intro p hp
  have h : env26671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26670_26671 : H12AffineEnvironment.transform 11 75 env26670 = env26671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 75 env26670 == env26671) = true)

theorem identity26671 : scanCanonicalize (H12AffineFastState.compose env26671 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound26671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26672 : List Nat := [2,4,8,16,17,10,9,20,10,31,27,1,25,16,0,19,0,1,30,1,10,11,17,24,24,10,1,27,26,1,20,11,21,10,11,11]

theorem envBound26672 : H12AffineFastState.Bounded env26672 := by
  intro p hp
  have h : env26672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26671_26672 : H12AffineEnvironment.transform 5 10 env26671 = env26672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env26671 == env26672) = true)

def env26673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590876,2098513,17664,2363457,2102685,6349853,257,21793,46213,2175562]

theorem envBound26673 : H12AffineFastState.Bounded env26673 := by
  intro p hp
  have h : env26673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26635_26673 : H12AffineEnvironment.transform 16 49169 env26635 = env26673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26635 == env26673) = true)

def env26674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144540,2098513,17664,2363457,2102685,2411677,257,21793,46213,2175562]

theorem envBound26674 : H12AffineFastState.Bounded env26674 := by
  intro p hp
  have h : env26674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26673_26674 : H12AffineEnvironment.transform 21 272512 env26673 = env26674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26673 == env26674) = true)

theorem identity26674 : scanCanonicalize (H12AffineFastState.compose env26674 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound26674 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49169,262144,1025,32769,2097152,272512,2101329,21763,8328,64,2144540,2098513,17664,2363457,2102685,2411677,257,21793,46213,2156180]

theorem envBound26675 : H12AffineFastState.Bounded env26675 := by
  intro p hp
  have h : env26675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26674_26675 : H12AffineEnvironment.transform 15 54494 env26674 = env26675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env26674 == env26675) = true)

def env26676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1025,32769,2097152,272392,2101329,21763,8192,64,2144540,2098513,17664,2363457,2102549,2411541,257,21793,46093,2156060]

theorem envBound26676 : H12AffineFastState.Bounded env26676 := by
  intro p hp
  have h : env26676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26675_26676 : H12AffineEnvironment.transform 6 8 env26675 = env26676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26675 == env26676) = true)

theorem identity26676 : scanCanonicalize (H12AffineFastState.compose env26676 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 36928) := by decide +kernel

theorem selectedBound26676 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env26677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1025,32769,36928,272392,32785,21763,8192,64,10588,38161,17664,294913,34133,285781,257,21793,46093,30300]

theorem envBound26677 : H12AffineFastState.Bounded env26677 := by
  intro p hp
  have h : env26677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26676_26677 : H12AffineEnvironment.transform 20 36928 env26676 = env26677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36928 env26676 == env26677) = true)

theorem identity26677 : scanCanonicalize (H12AffineFastState.compose env26677 (packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound26677 : packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS < 2^1333 := by decide +kernel

def env26678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,56437,1025,32769,36928,62589,32785,21763,8192,64,10588,38161,17664,23668,34133,32800,257,21793,46093,30300]

theorem envBound26678 : H12AffineFastState.Bounded env26678 := by
  intro p hp
  have h : env26678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26677_26678 : H12AffineEnvironment.transform 17 56437 env26677 = env26678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env26677 == env26678) = true)

theorem identity26678 : scanCanonicalize (H12AffineFastState.compose env26678 (packedSelected [4,8,9,10,12,14,15,16,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26678 : packedSelected [4,8,9,10,12,14,15,16,28] rootPS < 2^1333 := by decide +kernel

def env26679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54358,49169,56437,1025,32769,36928,54640,32785,21763,269,64,2129,38161,17664,23668,34133,32800,257,21793,38144,22353]

theorem envBound26679 : H12AffineFastState.Bounded env26679 := by
  intro p hp
  have h : env26679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26678_26679 : H12AffineEnvironment.transform 12 269 env26678 = env26679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26678 == env26679) = true)

theorem identity26679 : scanCanonicalize (H12AffineFastState.compose env26679 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound26679 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21760,342,5393,2421,1025,21761,17728,112,21777,21763,269,64,2129,16401,17664,23668,20565,21792,257,21793,16384,22353]

theorem envBound26680 : H12AffineFastState.Bounded env26680 := by
  intro p hp
  have h : env26680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26679_26680 : H12AffineEnvironment.transform 14 21760 env26679 = env26680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env26679 == env26680) = true)

theorem identity26680 : scanCanonicalize (H12AffineFastState.compose env26680 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26680 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26681 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21760,262,5393,2341,1025,21761,17680,32,21777,21763,269,16,2049,16401,17664,23588,20485,21792,257,21793,16384,22273]

theorem envBound26681 : H12AffineFastState.Bounded env26681 := by
  intro p hp
  have h : env26681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26680_26681 : H12AffineEnvironment.transform 5 16 env26680 = env26681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26680 == env26681) = true)

theorem identity26681 : scanCanonicalize (H12AffineFastState.compose env26681 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 7952) := by decide +kernel

theorem selectedBound26681 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env26682 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7952,2576,262,5393,2341,1025,2577,6656,32,2561,2579,269,16,2049,7937,6672,820,3861,2608,257,2609,7952,2065]

theorem envBound26682 : H12AffineFastState.Bounded env26682 := by
  intro p hp
  have h : env26682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26681_26682 : H12AffineEnvironment.transform 13 7952 env26681 = env26682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7952 env26681 == env26682) = true)

theorem identity26682 : scanCanonicalize (H12AffineFastState.compose env26682 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3345) := by decide +kernel

theorem selectedBound26682 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env26683 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3345,269,513,2576,262,2048,2341,1025,2577,1809,32,2561,2579,269,16,2049,528,1793,820,3861,2608,257,2609,513,2065]

theorem envBound26683 : H12AffineFastState.Bounded env26683 := by
  intro p hp
  have h : env26683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26682_26683 : H12AffineEnvironment.transform 11 3345 env26682 = env26683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3345 env26682 == env26683) = true)

theorem identity26683 : scanCanonicalize (H12AffineFastState.compose env26683 (packedSelected [0,1,3,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26683 : packedSelected [0,1,3,6,9] rootPS < 2^1333 := by decide +kernel

def env26684 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3345,269,513,2576,262,2048,2308,1025,2577,1809,1,2561,2579,269,16,2049,528,1793,789,3861,2577,257,2576,513,2065]

theorem envBound26684 : H12AffineFastState.Bounded env26684 := by
  intro p hp
  have h : env26684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26683_26684 : H12AffineEnvironment.transform 4 1 env26683 = env26684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26683 == env26684) = true)

theorem identity26684 : scanCanonicalize (H12AffineFastState.compose env26684 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound26684 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26685 : List Nat := [2,4,8,16,1,16,8,256,512,1024,529,1792,269,513,1,262,529,789,1025,0,1809,1,16,2,269,16,528,528,1793,789,1284,0,257,1,513,512]

theorem envBound26685 : H12AffineFastState.Bounded env26685 := by
  intro p hp
  have h : env26685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26684_26685 : H12AffineEnvironment.transform 10 529 env26684 = env26685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env26684 == env26685) = true)

def env26686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272393,2101329,21763,8193,64,2144540,2098513,17664,2363457,2102548,2411540,257,21793,46092,2156061]

theorem envBound26686 : H12AffineFastState.Bounded env26686 := by
  intro p hp
  have h : env26686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26675_26686 : H12AffineEnvironment.transform 6 9 env26675 = env26686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26675 == env26686) = true)

theorem identity26686 : scanCanonicalize (H12AffineFastState.compose env26686 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound26686 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env26687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32802,37988,262144,1025,32769,2097152,272393,2101329,374,8193,64,2144540,2098513,4469,2363457,2102548,2398305,257,340,46092,2142824]

theorem envBound26687 : H12AffineFastState.Bounded env26687 := by
  intro p hp
  have h : env26687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26686_26687 : H12AffineEnvironment.transform 13 5237 env26686 = env26687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env26686 == env26687) = true)

theorem identity26687 : scanCanonicalize (H12AffineFastState.compose env26687 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26687 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env26688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32802,37988,10280,1025,32769,2097152,33,2101329,374,8193,64,2144540,2098513,4469,2111593,2102548,2142281,257,340,46092,2142824]

theorem envBound26688 : H12AffineFastState.Bounded env26688 := by
  intro p hp
  have h : env26688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26687_26688 : H12AffineEnvironment.transform 17 10280 env26687 = env26688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26687 == env26688) = true)

theorem identity26688 : scanCanonicalize (H12AffineFastState.compose env26688 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26688 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26689 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,32802,37988,10280,1025,32769,2097152,33,2101329,3,8193,64,2144361,2098212,4096,2111593,2102369,2142281,116,33,46092,2142824]

theorem envBound26689 : H12AffineFastState.Bounded env26689 := by
  intro p hp
  have h : env26689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26688_26689 : H12AffineEnvironment.transform 7 117 env26688 = env26689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26688 == env26689) = true)

theorem identity26689 : scanCanonicalize (H12AffineFastState.compose env26689 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound26689 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env26690 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,32802,37988,10280,1025,32769,12392,33,8249,3,8193,64,34817,13388,4096,2049,9225,32801,116,33,46092,33280]

theorem envBound26690 : H12AffineFastState.Bounded env26690 := by
  intro p hp
  have h : env26690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26689_26690 : H12AffineEnvironment.transform 20 12392 env26689 = env26690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env26689 == env26690) = true)

theorem identity26690 : scanCanonicalize (H12AffineFastState.compose env26690 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26690 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env26691 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,0,34,5220,10280,1025,1,12392,33,8249,3,8193,64,2049,13388,4096,2049,9225,33,116,33,13324,512]

theorem envBound26691 : H12AffineFastState.Bounded env26691 := by
  intro p hp
  have h : env26691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26690_26691 : H12AffineEnvironment.transform 14 0 env26690 = env26691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26690 == env26691) = true)

theorem identity26691 : scanCanonicalize (H12AffineFastState.compose env26691 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26691 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26692 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,5205,0,2,5188,10248,1025,1,12360,1,8217,3,8193,64,2049,13388,4096,2049,9225,1,84,1,13324,512]

theorem envBound26692 : H12AffineFastState.Bounded env26692 := by
  intro p hp
  have h : env26692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26691_26692 : H12AffineEnvironment.transform 4 0 env26691 = env26692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26691 == env26692) = true)

theorem identity26692 : scanCanonicalize (H12AffineFastState.compose env26692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26693 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,0,2,5188,2048,1025,1,4160,1,17,3,9,64,2049,5188,4096,2049,1025,1,84,1,5124,512]

theorem envBound26693 : H12AffineFastState.Bounded env26693 := by
  intro p hp
  have h : env26693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26692_26693 : H12AffineEnvironment.transform 12 8 env26692 = env26693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26692 == env26693) = true)

theorem identity26693 : scanCanonicalize (H12AffineFastState.compose env26693 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound26693 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26694 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,8,4112,0,2,4097,2048,68,1,4160,1,17,3,9,64,2049,4097,4096,2049,68,1,84,1,4161,512]

theorem envBound26694 : H12AffineFastState.Bounded env26694 := by
  intro p hp
  have h : env26694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26693_26694 : H12AffineEnvironment.transform 9 69 env26693 = env26694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env26693 == env26694) = true)

theorem identity26694 : scanCanonicalize (H12AffineFastState.compose env26694 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound26694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26695 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,8,1,0,2,16,2048,68,1,81,1,17,3,9,64,2049,16,17,2049,68,1,84,1,80,512]

theorem envBound26695 : H12AffineFastState.Bounded env26695 := by
  intro p hp
  have h : env26695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26694_26695 : H12AffineEnvironment.transform 11 17 env26694 = env26695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26694 == env26695) = true)

theorem identity26695 : scanCanonicalize (H12AffineFastState.compose env26695 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26696 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,17,8,1,0,2,16,2048,20,1,1,1,17,3,9,16,2049,16,17,2049,20,1,4,1,0,512]

theorem envBound26696 : H12AffineFastState.Bounded env26696 := by
  intro p hp
  have h : env26696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26695_26696 : H12AffineEnvironment.transform 5 16 env26695 = env26696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26695 == env26696) = true)

theorem identity26696 : scanCanonicalize (H12AffineFastState.compose env26696 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 526) := by decide +kernel

theorem selectedBound26696 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26697 : List Nat := [2,4,8,16,0,16,9,5,512,21,526,17,8,1,0,2,16,526,20,1,1,1,17,3,9,16,527,16,17,527,20,1,4,1,0,512]

theorem envBound26697 : H12AffineFastState.Bounded env26697 := by
  intro p hp
  have h : env26697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26696_26697 : H12AffineEnvironment.transform 10 526 env26696 = env26697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 526 env26696 == env26697) = true)

def env26698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144541,2098513,17664,2363457,2102685,2411676,257,21793,46213,2175562]

theorem envBound26698 : H12AffineFastState.Bounded env26698 := by
  intro p hp
  have h : env26698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26673_26698 : H12AffineEnvironment.transform 21 272513 env26673 = env26698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26673 == env26698) = true)

theorem identity26698 : scanCanonicalize (H12AffineFastState.compose env26698 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound26698 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115870,272513,120015,98781,8328,64,97667,115151,17664,382175,119043,329730,257,21793,46213,63188]

theorem envBound26699 : H12AffineFastState.Bounded env26699 := by
  intro p hp
  have h : env26699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26698_26699 : H12AffineEnvironment.transform 20 115870 env26698 = env26699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env26698 == env26699) = true)

def env26700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115734,272393,119879,98645,8192,64,97547,115015,17664,382039,119043,329730,257,21793,46093,63068]

theorem envBound26700 : H12AffineFastState.Bounded env26700 := by
  intro p hp
  have h : env26700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26699_26700 : H12AffineEnvironment.transform 6 8 env26699 = env26700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26699 == env26700) = true)

theorem identity26700 : scanCanonicalize (H12AffineFastState.compose env26700 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26700 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env26701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,49169,262144,1025,32769,115734,264533,119879,98645,348,64,89175,115015,17664,382039,119043,329730,257,21793,38225,55040]

theorem envBound26701 : H12AffineFastState.Bounded env26701 := by
  intro p hp
  have h : env26701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26700_26701 : H12AffineEnvironment.transform 12 348 env26700 = env26701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26700 == env26701) = true)

theorem identity26701 : scanCanonicalize (H12AffineFastState.compose env26701 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound26701 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env26702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,5392,262144,1025,21760,69911,264533,65862,87124,348,64,89175,70726,17664,328022,66562,329730,257,21793,16464,513]

theorem envBound26702 : H12AffineFastState.Bounded env26702 := by
  intro p hp
  have h : env26702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26701_26702 : H12AffineEnvironment.transform 14 21761 env26701 = env26702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env26701 == env26702) = true)

theorem identity26702 : scanCanonicalize (H12AffineFastState.compose env26702 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound26702 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env26703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,5392,89379,1025,21760,69911,87158,65862,87124,348,64,89175,70726,17664,23669,66562,21793,257,21793,16464,513]

theorem envBound26703 : H12AffineFastState.Bounded env26703 := by
  intro p hp
  have h : env26703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26702_26703 : H12AffineEnvironment.transform 17 89379 env26702 = env26703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env26702 == env26703) = true)

theorem identity26703 : scanCanonicalize (H12AffineFastState.compose env26703 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26703 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,81,65536,5392,67699,1025,80,69911,65830,65862,65796,348,64,67847,70726,4176,2341,66562,113,257,113,5376,513]

theorem envBound26704 : H12AffineFastState.Bounded env26704 := by
  intro p hp
  have h : env26704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26703_26704 : H12AffineEnvironment.transform 13 5456 env26703 = env26704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26703 == env26704) = true)

theorem identity26704 : scanCanonicalize (H12AffineFastState.compose env26704 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26704 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26705 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,65536,5392,67618,1025,1,69911,65830,65815,65796,269,17,67847,70679,4097,2341,66562,32,257,32,5376,513]

theorem envBound26705 : H12AffineFastState.Bounded env26705 := by
  intro p hp
  have h : env26705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26704_26705 : H12AffineEnvironment.transform 5 17 env26704 = env26705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26704 == env26705) = true)

theorem identity26705 : scanCanonicalize (H12AffineFastState.compose env26705 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound26705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26706 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4113,32,17,2,269,17,2049,5393,4097,2341,1284,32,257,32,5376,513]

theorem envBound26706 : H12AffineFastState.Bounded env26706 := by
  intro p hp
  have h : env26706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26705_26706 : H12AffineEnvironment.transform 15 262 env26705 = env26706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env26705 == env26706) = true)

theorem identity26706 : scanCanonicalize (H12AffineFastState.compose env26706 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26707 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,269,309,0,262,292,2340,1025,1,1061,32,17,2,269,17,2049,293,1077,2341,1284,32,257,32,308,513]

theorem envBound26707 : H12AffineFastState.Bounded env26707 := by
  intro p hp
  have h : env26707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26706_26707 : H12AffineEnvironment.transform 11 1076 env26706 = env26707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env26706 == env26707) = true)

theorem identity26707 : scanCanonicalize (H12AffineFastState.compose env26707 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound26707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26708 : List Nat := [2,4,8,16,32,17,8,256,512,784,2048,804,269,309,0,262,292,2340,785,1,821,32,17,2,269,17,2049,293,805,2341,532,32,257,32,308,513]

theorem envBound26708 : H12AffineFastState.Bounded env26708 := by
  intro p hp
  have h : env26708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26707_26708 : H12AffineEnvironment.transform 9 784 env26707 = env26708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env26707 == env26708) = true)

theorem identity26708 : scanCanonicalize (H12AffineFastState.compose env26708 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound26708 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26709 : List Nat := [2,4,8,16,32,17,8,256,512,784,821,804,269,309,0,262,292,529,785,1,821,32,17,2,269,17,820,293,805,528,532,32,257,32,308,513]

theorem envBound26709 : H12AffineFastState.Bounded env26709 := by
  intro p hp
  have h : env26709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26708_26709 : H12AffineEnvironment.transform 10 821 env26708 = env26709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env26708 == env26709) = true)

def env26710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115735,272392,119878,98644,8193,64,97546,115014,17664,382038,119043,329730,257,21793,46092,63069]

theorem envBound26710 : H12AffineFastState.Bounded env26710 := by
  intro p hp
  have h : env26710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26699_26710 : H12AffineEnvironment.transform 6 9 env26699 = env26710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26699 == env26710) = true)

theorem identity26710 : scanCanonicalize (H12AffineFastState.compose env26710 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound26710 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env26711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62591,49169,262144,1025,32769,12392,272392,8249,29995,8193,64,35189,13625,17664,270377,9596,326781,257,21793,46092,63069]

theorem envBound26711 : H12AffineFastState.Bounded env26711 := by
  intro p hp
  have h : env26711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26710_26711 : H12AffineEnvironment.transform 15 62591 env26710 = env26711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env26710 == env26711) = true)

theorem identity26711 : scanCanonicalize (H12AffineFastState.compose env26711 (packedSelected [0,1,2,4,6,9,11,16,17,18,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound26711 : packedSelected [0,1,2,4,6,9,11,16,17,18,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62591,49169,56577,1025,32769,12392,62729,8249,29995,8193,64,35189,13625,17664,64808,9596,8572,257,21793,46092,63069]

theorem envBound26712 : H12AffineFastState.Bounded env26712 := by
  intro p hp
  have h : env26712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26711_26712 : H12AffineEnvironment.transform 17 56577 env26711 = env26712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env26711 == env26712) = true)

theorem identity26712 : scanCanonicalize (H12AffineFastState.compose env26712 (packedSelected [0,7,9,14,16,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26712 : packedSelected [0,7,9,14,16,17,22] rootPS < 2^1333 := by decide +kernel

def env26713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,34,13388,10588,1025,29788,12392,340,8249,29995,8193,64,32040,13625,17664,2421,9596,8572,257,21793,16465,512]

theorem envBound26713 : H12AffineFastState.Bounded env26713 := by
  intro p hp
  have h : env26713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26712_26713 : H12AffineEnvironment.transform 14 29789 env26712 = env26713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26712 == env26713) = true)

theorem identity26713 : scanCanonicalize (H12AffineFastState.compose env26713 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26713 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env26714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,34,5392,2048,1025,21760,4404,340,357,21623,349,64,23668,5221,17664,2421,1056,32,257,21793,16465,512]

theorem envBound26714 : H12AffineFastState.Bounded env26714 := by
  intro p hp
  have h : env26714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26713_26714 : H12AffineEnvironment.transform 12 348 env26713 = env26714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26713 == env26714) = true)

theorem identity26714 : scanCanonicalize (H12AffineFastState.compose env26714 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound26714 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26715 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,16384,21589,34,5188,2048,1025,21588,4192,0,49,21623,9,64,23668,5221,17492,2081,1056,32,85,21621,16465,512]

theorem envBound26715 : H12AffineFastState.Bounded env26715 := by
  intro p hp
  have h : env26715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26714_26715 : H12AffineEnvironment.transform 7 84 env26714 = env26715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env26714 == env26715) = true)

theorem identity26715 : scanCanonicalize (H12AffineFastState.compose env26715 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound26715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26716 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5236,33,34,5188,2048,1025,32,4192,0,49,3,9,64,2048,5221,4128,2081,1056,32,85,1,5157,512]

theorem envBound26716 : H12AffineFastState.Bounded env26716 := by
  intro p hp
  have h : env26716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26715_26716 : H12AffineEnvironment.transform 13 5236 env26715 = env26716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env26715 == env26716) = true)

theorem identity26716 : scanCanonicalize (H12AffineFastState.compose env26716 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound26716 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env26717 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3134,8,2122,33,34,2170,2048,1025,32,3166,0,49,3,9,64,2048,2139,3102,2081,1056,32,85,1,2075,512]

theorem envBound26717 : H12AffineFastState.Bounded env26717 := by
  intro p hp
  have h : env26717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26716_26717 : H12AffineEnvironment.transform 11 3134 env26716 = env26717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env26716 == env26717) = true)

theorem identity26717 : scanCanonicalize (H12AffineFastState.compose env26717 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 79) := by decide +kernel

theorem selectedBound26717 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env26718 : List Nat := [2,4,8,16,32,64,9,84,512,79,2048,2161,8,2122,33,34,2170,2048,78,32,2065,0,49,3,9,64,2048,2139,2129,2081,111,32,85,1,2075,512]

theorem envBound26718 : H12AffineFastState.Bounded env26718 := by
  intro p hp
  have h : env26718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26717_26718 : H12AffineEnvironment.transform 9 79 env26717 = env26718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 79 env26717 == env26718) = true)

theorem identity26718 : scanCanonicalize (H12AffineFastState.compose env26718 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound26718 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env26719 : List Nat := [2,4,8,16,32,33,9,53,512,46,2048,2064,8,2091,33,34,2075,2048,47,32,2065,0,49,3,9,33,2048,2106,2096,2081,14,32,52,1,2075,512]

theorem envBound26719 : H12AffineFastState.Bounded env26719 := by
  intro p hp
  have h : env26719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26718_26719 : H12AffineEnvironment.transform 5 33 env26718 = env26719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env26718 == env26719) = true)

theorem identity26719 : scanCanonicalize (H12AffineFastState.compose env26719 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26719 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env26720 : List Nat := [2,4,8,16,0,1,9,21,512,14,2048,2064,8,2059,1,2,2075,2048,15,0,2065,0,17,3,9,1,2048,2074,2064,2049,14,0,20,1,2075,512]

theorem envBound26720 : H12AffineFastState.Bounded env26720 := by
  intro p hp
  have h : env26720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26719_26720 : H12AffineEnvironment.transform 4 0 env26719 = env26720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26719 == env26720) = true)

theorem identity26720 : scanCanonicalize (H12AffineFastState.compose env26720 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26721 : List Nat := [2,4,8,0,0,1,9,5,512,14,2048,2048,8,2059,1,2,2059,2048,15,0,2049,0,1,3,9,1,2048,2058,2048,2049,14,0,4,1,2059,512]

theorem envBound26721 : H12AffineFastState.Bounded env26721 := by
  intro p hp
  have h : env26721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26720_26721 : H12AffineEnvironment.transform 3 0 env26720 = env26721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26720 == env26721) = true)

theorem identity26721 : scanCanonicalize (H12AffineFastState.compose env26721 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound26721 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26722 : List Nat := [2,4,8,0,0,1,9,5,512,14,513,513,8,522,1,2,522,513,15,0,512,0,1,3,9,1,513,523,513,512,14,0,4,1,522,512]

theorem envBound26722 : H12AffineFastState.Bounded env26722 := by
  intro p hp
  have h : env26722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26721_26722 : H12AffineEnvironment.transform 10 513 env26721 = env26722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env26721 == env26722) = true)

theorem identity26722 : scanCanonicalize (H12AffineFastState.compose env26722 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound26722 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26723 : List Nat := [2,4,8,0,0,1,9,5,8,14,9,9,8,2,1,2,2,9,15,0,8,0,1,3,9,1,9,3,9,8,14,0,4,1,2,8]

theorem envBound26723 : H12AffineFastState.Bounded env26723 := by
  intro p hp
  have h : env26723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26722_26723 : H12AffineEnvironment.transform 8 8 env26722 = env26723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env26722 == env26723) = true)

theorem identity26723 : scanCanonicalize (H12AffineFastState.compose env26723 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26723 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26724 : List Nat := [2,4,2,0,0,1,3,5,2,4,3,3,2,2,1,2,2,3,5,0,2,0,1,3,3,1,3,3,3,2,4,0,4,1,2,2]

theorem envBound26724 : H12AffineFastState.Bounded env26724 := by
  intro p hp
  have h : env26724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26723_26724 : H12AffineEnvironment.transform 2 2 env26723 = env26724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26723 == env26724) = true)

theorem identity26724 : scanCanonicalize (H12AffineFastState.compose env26724 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound26724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26725 : List Nat := [2,0,2,0,0,1,3,1,2,0,3,3,2,2,1,2,2,3,1,0,2,0,1,3,3,1,3,3,3,2,0,0,0,1,2,2]

theorem envBound26725 : H12AffineFastState.Bounded env26725 := by
  intro p hp
  have h : env26725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26724_26725 : H12AffineEnvironment.transform 1 0 env26724 = env26725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env26724 == env26725) = true)

def env26726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281537,213452,8328,64,6705548,2278720,165136,2363456,2102684,6431756,257,21792,46212,2175563]

theorem envBound26726 : H12AffineFastState.Bounded env26726 := by
  intro p hp
  have h : env26726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26634_26726 : H12AffineEnvironment.transform 22 2281537 env26634 = env26726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281537 env26634 == env26726) = true)

def env26727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590876,2098512,17664,2363456,2102684,6349852,257,21792,46212,2175563]

theorem envBound26727 : H12AffineFastState.Bounded env26727 := by
  intro p hp
  have h : env26727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26726_26727 : H12AffineEnvironment.transform 16 49168 env26726 = env26727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26726 == env26727) = true)

def env26728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144540,2098512,17664,2363456,2102684,2411676,257,21792,46212,2175563]

theorem envBound26728 : H12AffineFastState.Bounded env26728 := by
  intro p hp
  have h : env26728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26727_26728 : H12AffineEnvironment.transform 21 272512 env26727 = env26728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26727 == env26728) = true)

theorem identity26728 : scanCanonicalize (H12AffineFastState.compose env26728 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound26728 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272512,17,98780,8328,64,43356,5392,17664,262144,1500,318684,257,21792,46212,74251]

theorem envBound26729 : H12AffineFastState.Bounded env26729 := by
  intro p hp
  have h : env26729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26728_26729 : H12AffineEnvironment.transform 20 4160 env26728 = env26729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26728 == env26729) = true)

theorem identity26729 : scanCanonicalize (H12AffineFastState.compose env26729 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26729 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272512,17,41430,8328,64,43356,5392,17664,262144,1500,318684,257,21792,46212,513]

theorem envBound26730 : H12AffineFastState.Bounded env26730 := by
  intro p hp
  have h : env26730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26729_26730 : H12AffineEnvironment.transform 15 8202 env26729 = env26730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26729 == env26730) = true)

theorem identity26730 : scanCanonicalize (H12AffineFastState.compose env26730 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound26730 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35324,1025,32769,4160,41340,17,41430,8328,64,43356,5392,17664,35324,1500,21792,257,21792,46212,513]

theorem envBound26731 : H12AffineFastState.Bounded env26731 := by
  intro p hp
  have h : env26731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26730_26731 : H12AffineEnvironment.transform 17 35324 env26730 = env26731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env26730 == env26731) = true)

theorem identity26731 : scanCanonicalize (H12AffineFastState.compose env26731 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26731 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,24909,10401,1025,8540,4160,33,17,139,8328,64,2049,5392,17664,10401,1500,21792,257,21792,5593,513]

theorem envBound26732 : H12AffineFastState.Bounded env26732 := by
  intro p hp
  have h : env26732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26731_26732 : H12AffineEnvironment.transform 14 8541 env26731 = env26732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26731 == env26732) = true)

def env26733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144541,2098512,17664,2363456,2102684,2411677,257,21792,46212,2175563]

theorem envBound26733 : H12AffineFastState.Bounded env26733 := by
  intro p hp
  have h : env26733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26727_26733 : H12AffineEnvironment.transform 21 272513 env26727 = env26733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26727 == env26733) = true)

def env26734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101329,98644,8192,64,2144541,2098512,17664,2363456,2102548,2411541,257,21792,46092,2175563]

theorem envBound26734 : H12AffineFastState.Bounded env26734 := by
  intro p hp
  have h : env26734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26733_26734 : H12AffineEnvironment.transform 6 8 env26733 = env26734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26733 == env26734) = true)

theorem identity26734 : scanCanonicalize (H12AffineFastState.compose env26734 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound26734 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272393,73755,98644,8192,64,100695,79130,17664,335882,75102,392287,257,21792,46092,513]

theorem envBound26735 : H12AffineFastState.Bounded env26735 := by
  intro p hp
  have h : env26735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26734_26735 : H12AffineEnvironment.transform 20 77898 env26734 = env26735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env26734 == env26735) = true)

theorem identity26735 : scanCanonicalize (H12AffineFastState.compose env26735 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound26735 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,77898,41341,73755,98644,8192,64,100695,79130,17664,108926,75102,95531,257,21792,46092,513]

theorem envBound26736 : H12AffineFastState.Bounded env26736 := by
  intro p hp
  have h : env26736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26735_26736 : H12AffineEnvironment.transform 17 35188 env26735 = env26736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env26735 == env26736) = true)

theorem identity26736 : scanCanonicalize (H12AffineFastState.compose env26736 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound26736 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,32040,1025,29789,77898,21793,73755,95496,8192,64,97547,79130,17664,89378,75102,95531,257,21792,16464,513]

theorem envBound26737 : H12AffineFastState.Bounded env26737 := by
  intro p hp
  have h : env26737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26736_26737 : H12AffineEnvironment.transform 14 29788 env26736 = env26737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env26736 == env26737) = true)

theorem identity26737 : scanCanonicalize (H12AffineFastState.compose env26737 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound26737 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env26738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,65536,13388,10361,1025,8460,77898,112,73755,73817,8192,64,75866,79130,4177,67699,75102,73850,257,113,5377,513]

theorem envBound26738 : H12AffineFastState.Bounded env26738 := by
  intro p hp
  have h : env26738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26737_26738 : H12AffineEnvironment.transform 13 5457 env26737 = env26738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env26737 == env26738) = true)

theorem identity26738 : scanCanonicalize (H12AffineFastState.compose env26738 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound26738 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env26739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8283,13388,10361,1025,8460,4113,112,64,2,8192,64,2049,5441,4177,10280,1285,33,257,113,5377,513]

theorem envBound26739 : H12AffineFastState.Bounded env26739 := by
  intro p hp
  have h : env26739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26738_26739 : H12AffineEnvironment.transform 15 8283 env26738 = env26739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env26738 == env26739) = true)

theorem identity26739 : scanCanonicalize (H12AffineFastState.compose env26739 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound26739 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,5457,7285,7459,2356,5377,1025,7284,4113,112,64,2,7544,64,2049,5441,4177,5456,1285,33,257,113,5377,513]

theorem envBound26740 : H12AffineFastState.Bounded env26740 := by
  intro p hp
  have h : env26740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26739_26740 : H12AffineEnvironment.transform 12 7544 env26739 = env26740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env26739 == env26740) = true)

theorem identity26740 : scanCanonicalize (H12AffineFastState.compose env26740 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound26740 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env26741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,1101,3172,1344,1046,2356,3124,1025,1345,2340,112,64,2,1101,64,2049,3188,2404,3173,1285,33,257,113,3124,513]

theorem envBound26741 : H12AffineFastState.Bounded env26741 := by
  intro p hp
  have h : env26741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26740_26741 : H12AffineEnvironment.transform 11 2357 env26740 = env26741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env26740 == env26741) = true)

theorem identity26741 : scanCanonicalize (H12AffineFastState.compose env26741 (packedSelected [2,4,6,9,11,23] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26741 : packedSelected [2,4,6,9,11,23] rootPS < 2^1333 := by decide +kernel

def env26742 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2357,348,2421,81,263,2356,2341,272,80,2340,112,64,2,348,64,2049,2405,2404,2420,20,33,257,113,2341,513]

theorem envBound26742 : H12AffineFastState.Bounded env26742 := by
  intro p hp
  have h : env26742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26741_26742 : H12AffineEnvironment.transform 9 273 env26741 = env26742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26741 == env26742) = true)

def env26743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101329,98645,8193,64,2144541,2098512,17664,2363456,2102549,2411540,257,21792,46093,2175563]

theorem envBound26743 : H12AffineFastState.Bounded env26743 := by
  intro p hp
  have h : env26743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26733_26743 : H12AffineEnvironment.transform 6 9 env26733 = env26743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26733 == env26743) = true)

theorem identity26743 : scanCanonicalize (H12AffineFastState.compose env26743 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26743 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,16401,262144,1025,0,2097152,272392,2101329,65876,8193,64,2111772,2098512,17664,2363456,2102549,2378773,257,21792,13324,2175563]

theorem envBound26744 : H12AffineFastState.Bounded env26744 := by
  intro p hp
  have h : env26744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26743_26744 : H12AffineEnvironment.transform 14 1 env26743 = env26744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26743 == env26744) = true)

theorem identity26744 : scanCanonicalize (H12AffineFastState.compose env26744 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound26744 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env26745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,16401,262144,1025,0,12573,272392,8524,65876,8193,64,2049,13389,17664,270685,9224,294152,257,21792,13324,66390]

theorem envBound26745 : H12AffineFastState.Bounded env26745 := by
  intro p hp
  have h : env26745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26744_26745 : H12AffineEnvironment.transform 20 12573 env26744 = env26745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env26744 == env26745) = true)

theorem identity26745 : scanCanonicalize (H12AffineFastState.compose env26745 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound26745 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env26746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,16401,2421,1025,0,12573,8573,8524,65876,8193,64,2049,13389,17664,10280,9224,29821,257,21792,13324,66390]

theorem envBound26746 : H12AffineFastState.Bounded env26746 := by
  intro p hp
  have h : env26746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26745_26746 : H12AffineEnvironment.transform 17 2421 env26745 = env26746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env26745 == env26746) = true)

theorem identity26746 : scanCanonicalize (H12AffineFastState.compose env26746 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound26746 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,343,16401,2421,1025,0,12573,8573,8524,3,8193,64,2049,13389,17664,10280,9224,29821,257,21792,13324,513]

theorem envBound26747 : H12AffineFastState.Bounded env26747 := by
  intro p hp
  have h : env26747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26746_26747 : H12AffineEnvironment.transform 15 343 env26746 = env26747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env26746 == env26747) = true)

theorem identity26747 : scanCanonicalize (H12AffineFastState.compose env26747 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound26747 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,1,343,4097,2421,1025,0,12573,8573,8524,3,8193,64,2049,13389,5392,10280,9224,9325,257,1328,13324,513]

theorem envBound26748 : H12AffineFastState.Bounded env26748 := by
  intro p hp
  have h : env26748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26747_26748 : H12AffineEnvironment.transform 13 4112 env26747 = env26748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env26747 == env26748) = true)

theorem identity26748 : scanCanonicalize (H12AffineFastState.compose env26748 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound26748 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4112,1,343,4097,2421,1025,0,5456,1328,1281,3,1100,64,2049,4096,5392,3173,69,32,257,1328,4161,513]

theorem envBound26749 : H12AffineFastState.Bounded env26749 := by
  intro p hp
  have h : env26749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26748_26749 : H12AffineEnvironment.transform 12 1101 env26748 = env26749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env26748 == env26749) = true)

def env26750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590877,2098513,17665,2363456,2102684,6349853,257,21792,46212,2175563]

theorem envBound26750 : H12AffineFastState.Bounded env26750 := by
  intro p hp
  have h : env26750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26726_26750 : H12AffineEnvironment.transform 16 49169 env26726 = env26750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26726 == env26750) = true)

def env26751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144541,2098513,17665,2363456,2102684,2411677,257,21792,46212,2175563]

theorem envBound26751 : H12AffineFastState.Bounded env26751 := by
  intro p hp
  have h : env26751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26750_26751 : H12AffineEnvironment.transform 21 272512 env26750 = env26751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26750 == env26751) = true)

theorem identity26751 : scanCanonicalize (H12AffineFastState.compose env26751 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound26751 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272512,62661,98781,8328,64,23944,57796,17665,324821,61705,272392,257,21792,46212,120542]

theorem envBound26752 : H12AffineFastState.Bounded env26752 := by
  intro p hp
  have h : env26752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26751_26752 : H12AffineEnvironment.transform 20 58517 env26751 = env26752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env26751 == env26752) = true)

def env26753 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272512,62613,98701,8328,16,23944,57748,17665,324741,61705,272392,257,21792,46212,120462]

theorem envBound26753 : H12AffineFastState.Bounded env26753 := by
  intro p hp
  have h : env26753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26752_26753 : H12AffineEnvironment.transform 5 16 env26752 = env26753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26752 == env26753) = true)

theorem identity26753 : scanCanonicalize (H12AffineFastState.compose env26753 (packedSelected [10,15,17,19,26,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26753 : packedSelected [10,15,17,19,26,31,38] rootPS < 2^1333 := by decide +kernel

def env26754 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58517,168,62613,98701,8328,16,23944,57748,17665,56493,61705,32,257,21792,46212,120462]

theorem envBound26754 : H12AffineFastState.Bounded env26754 := by
  intro p hp
  have h : env26754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26753_26754 : H12AffineEnvironment.transform 17 10280 env26753 = env26754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26753 == env26754) = true)

theorem identity26754 : scanCanonicalize (H12AffineFastState.compose env26754 (packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound26754 : packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26755 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,13461,10280,1025,29829,4113,168,17,95497,8328,16,23944,5392,17665,10281,1421,32,257,21792,16384,74250]

theorem envBound26755 : H12AffineFastState.Bounded env26755 := by
  intro p hp
  have h : env26755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26754_26755 : H12AffineEnvironment.transform 14 29828 env26754 = env26755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env26754 == env26755) = true)

theorem identity26755 : scanCanonicalize (H12AffineFastState.compose env26755 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound26755 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env26756 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,65536,5393,2476,1025,21761,4113,168,17,87181,268,16,23944,5392,17665,2477,1421,32,257,21792,16384,66446]

theorem envBound26756 : H12AffineFastState.Bounded env26756 := by
  intro p hp
  have h : env26756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26755_26756 : H12AffineEnvironment.transform 12 388 env26755 = env26756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env26755 == env26756) = true)

theorem identity26756 : scanCanonicalize (H12AffineFastState.compose env26756 (packedSelected [2,4,6,11,16,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26756 : packedSelected [2,4,6,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env26757 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,65536,5393,2340,1025,21761,4113,32,17,87045,268,16,23808,5392,17665,2341,1285,32,257,21792,16384,66310]

theorem envBound26757 : H12AffineFastState.Bounded env26757 := by
  intro p hp
  have h : env26757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26756_26757 : H12AffineEnvironment.transform 6 8 env26756 = env26757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26756 == env26757) = true)

theorem identity26757 : scanCanonicalize (H12AffineFastState.compose env26757 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound26757 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26758 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,263,5393,2340,1025,21761,4113,32,17,21762,268,16,23808,5392,17665,2341,1285,32,257,21792,16384,513]

theorem envBound26758 : H12AffineFastState.Bounded env26758 := by
  intro p hp
  have h : env26758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26757_26758 : H12AffineEnvironment.transform 15 263 env26757 = env26758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env26757 == env26758) = true)

theorem identity26758 : scanCanonicalize (H12AffineFastState.compose env26758 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26758 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26759 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1025,1,4113,32,17,2,268,16,2048,5392,4097,2341,1285,32,257,32,5376,513]

theorem envBound26759 : H12AffineFastState.Bounded env26759 := by
  intro p hp
  have h : env26759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26758_26759 : H12AffineEnvironment.transform 13 5376 env26758 = env26759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26758 == env26759) = true)

theorem identity26759 : scanCanonicalize (H12AffineFastState.compose env26759 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound26759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26760 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,33,268,1313,0,263,1328,2340,1025,1,48,32,17,2,268,16,2048,1329,32,2341,1285,32,257,32,1313,513]

theorem envBound26760 : H12AffineFastState.Bounded env26760 := by
  intro p hp
  have h : env26760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26759_26760 : H12AffineEnvironment.transform 11 33 env26759 = env26760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env26759 == env26760) = true)

theorem identity26760 : scanCanonicalize (H12AffineFastState.compose env26760 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound26760 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26761 : List Nat := [2,4,8,16,32,16,8,256,512,801,2048,33,268,512,0,263,529,2340,800,1,48,32,17,2,268,16,2048,528,32,2341,548,32,257,32,512,513]

theorem envBound26761 : H12AffineFastState.Bounded env26761 := by
  intro p hp
  have h : env26761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26760_26761 : H12AffineEnvironment.transform 9 801 env26760 = env26761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env26760 == env26761) = true)

theorem identity26761 : scanCanonicalize (H12AffineFastState.compose env26761 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound26761 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26762 : List Nat := [2,4,8,16,32,16,8,256,512,801,48,33,268,512,0,263,529,276,800,1,48,32,17,2,268,16,48,528,32,277,548,32,257,32,512,513]

theorem envBound26762 : H12AffineFastState.Bounded env26762 := by
  intro p hp
  have h : env26762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26761_26762 : H12AffineEnvironment.transform 10 48 env26761 = env26762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env26761 == env26762) = true)

theorem identity26762 : scanCanonicalize (H12AffineFastState.compose env26762 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound26762 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26763 : List Nat := [2,4,8,16,32,16,8,256,16,305,48,33,268,16,0,263,1,276,304,1,48,32,17,2,268,16,48,0,32,277,52,32,257,32,16,17]

theorem envBound26763 : H12AffineFastState.Bounded env26763 := by
  intro p hp
  have h : env26763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26762_26763 : H12AffineEnvironment.transform 8 16 env26762 = env26763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env26762 == env26763) = true)

theorem identity26763 : scanCanonicalize (H12AffineFastState.compose env26763 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26763 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26764 : List Nat := [2,4,8,16,32,16,8,21,16,36,48,33,25,16,0,18,1,1,37,1,48,32,17,2,25,16,48,0,32,0,52,32,20,32,16,17]

theorem envBound26764 : H12AffineFastState.Bounded env26764 := by
  intro p hp
  have h : env26764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26763_26764 : H12AffineEnvironment.transform 7 21 env26763 = env26764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26763 == env26764) = true)

theorem identity26764 : scanCanonicalize (H12AffineFastState.compose env26764 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26764 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26765 : List Nat := [2,4,8,1,32,1,8,4,1,36,33,33,8,1,0,3,1,1,37,1,33,32,0,2,8,1,33,0,32,0,37,32,5,32,1,0]

theorem envBound26765 : H12AffineFastState.Bounded env26765 := by
  intro p hp
  have h : env26765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26764_26765 : H12AffineEnvironment.transform 3 1 env26764 = env26765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26764 == env26765) = true)

theorem identity26765 : scanCanonicalize (H12AffineFastState.compose env26765 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26765 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26766 : List Nat := [2,4,8,1,0,1,8,4,1,4,1,1,8,1,0,3,1,1,5,1,1,0,0,2,8,1,1,0,0,0,5,0,5,0,1,0]

theorem envBound26766 : H12AffineFastState.Bounded env26766 := by
  intro p hp
  have h : env26766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26765_26766 : H12AffineEnvironment.transform 4 0 env26765 = env26766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26765 == env26766) = true)

def env26767 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272512,62612,98700,8328,17,23944,57749,17665,324740,61705,272392,257,21792,46212,120463]

theorem envBound26767 : H12AffineFastState.Bounded env26767 := by
  intro p hp
  have h : env26767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26752_26767 : H12AffineEnvironment.transform 5 17 env26752 = env26767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26752 == env26767) = true)

def env26768 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,62492,98564,8192,17,23808,57629,17665,324620,61705,272392,257,21792,46092,120327]

theorem envBound26768 : H12AffineFastState.Bounded env26768 := by
  intro p hp
  have h : env26768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26767_26768 : H12AffineEnvironment.transform 6 8 env26767 = env26768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26767 == env26768) = true)

theorem identity26768 : scanCanonicalize (H12AffineFastState.compose env26768 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound26768 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env26769 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,58397,21792,62492,98564,8192,17,23808,57629,17665,35108,61705,21792,257,21792,46092,120327]

theorem envBound26769 : H12AffineFastState.Bounded env26769 := by
  intro p hp
  have h : env26769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26768_26769 : H12AffineEnvironment.transform 17 32040 env26768 = env26769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env26768 == env26769) = true)

theorem identity26769 : scanCanonicalize (H12AffineFastState.compose env26769 (packedSelected [0,4,7,17,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound26769 : packedSelected [0,4,7,17,19,22,26] rootPS < 2^1333 := by decide +kernel

def env26770 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33030,49169,32040,1025,32769,58397,21792,62492,2,8192,17,23808,57629,17665,35108,61705,21792,257,21792,46092,22273]

theorem envBound26770 : H12AffineFastState.Bounded env26770 := by
  intro p hp
  have h : env26770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26769_26770 : H12AffineEnvironment.transform 15 33030 env26769 = env26770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env26769 == env26770) = true)

theorem identity26770 : scanCanonicalize (H12AffineFastState.compose env26770 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26770 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env26771 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33030,49169,23589,1025,32769,50448,21792,54545,2,269,17,23808,49168,17665,35108,53252,21792,257,21792,38145,22273]

theorem envBound26771 : H12AffineFastState.Bounded env26771 := by
  intro p hp
  have h : env26771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26770_26771 : H12AffineEnvironment.transform 12 269 env26770 = env26771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26770 == env26771) = true)

def env26772 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,62493,98565,8193,17,23809,57628,17665,324621,61705,272392,257,21792,46093,120326]

theorem envBound26772 : H12AffineFastState.Bounded env26772 := by
  intro p hp
  have h : env26772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26767_26772 : H12AffineEnvironment.transform 6 9 env26767 = env26772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26767 == env26772) = true)

theorem identity26772 : scanCanonicalize (H12AffineFastState.compose env26772 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound26772 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env26773 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,97326,1025,32769,58396,87079,62493,98565,8193,17,23809,57628,17665,100387,61705,87078,257,21792,46093,120326]

theorem envBound26773 : H12AffineFastState.Bounded env26773 := by
  intro p hp
  have h : env26773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26772_26773 : H12AffineEnvironment.transform 17 97326 env26772 = env26773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env26772 == env26773) = true)

theorem identity26773 : scanCanonicalize (H12AffineFastState.compose env26773 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound26773 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26774 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,29963,49169,2341,1025,32769,58396,8492,62493,62478,8193,17,23809,57628,17665,64808,61705,8493,257,21792,46093,41741]

theorem envBound26774 : H12AffineFastState.Bounded env26774 := by
  intro p hp
  have h : env26774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26773_26774 : H12AffineEnvironment.transform 15 29963 env26773 = env26774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env26773 == env26774) = true)

theorem identity26774 : scanCanonicalize (H12AffineFastState.compose env26774 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound26774 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env26775 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,32768,263,46109,2341,1025,32769,36880,8492,32785,32770,8193,17,10509,38160,12557,35108,34053,8493,257,8492,46093,41741]

theorem envBound26775 : H12AffineFastState.Bounded env26775 := by
  intro p hp
  have h : env26775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26774_26775 : H12AffineEnvironment.transform 13 13324 env26774 = env26775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env26774 == env26775) = true)

theorem identity26775 : scanCanonicalize (H12AffineFastState.compose env26775 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound26775 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26776 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,292,263,13625,2341,1025,293,4404,8492,309,294,8193,17,10509,5172,12557,2048,1057,8493,257,8492,13609,8745]

theorem envBound26776 : H12AffineFastState.Bounded env26776 := by
  intro p hp
  have h : env26776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26775_26776 : H12AffineEnvironment.transform 14 292 env26775 = env26776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env26775 == env26776) = true)

def env26777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144540,2098513,17665,2363456,2102684,2411676,257,21792,46212,2175563]

theorem envBound26777 : H12AffineFastState.Bounded env26777 := by
  intro p hp
  have h : env26777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26750_26777 : H12AffineEnvironment.transform 21 272513 env26750 = env26777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26750 == env26777) = true)

theorem identity26777 : scanCanonicalize (H12AffineFastState.compose env26777 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,262144,1025,29909,2097152,272513,2101328,95497,8328,64,2117064,2098513,17665,2363456,2102684,2373704,257,21792,16464,2175563]

theorem envBound26778 : H12AffineFastState.Bounded env26778 := by
  intro p hp
  have h : env26778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26777_26778 : H12AffineEnvironment.transform 14 29908 env26777 = env26778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26777 == env26778) = true)

def env26779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,262144,1025,29789,2097152,272393,2101328,95497,8192,64,2116928,2098513,17665,2363456,2102548,2373704,257,21792,16464,2175563]

theorem envBound26779 : H12AffineFastState.Bounded env26779 := by
  intro p hp
  have h : env26779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26778_26779 : H12AffineEnvironment.transform 6 8 env26778 = env26779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26778 == env26779) = true)

theorem identity26779 : scanCanonicalize (H12AffineFastState.compose env26779 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound26779 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env26780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,2420,1025,29789,2097152,8573,2101328,95497,8192,64,2116928,2098513,17665,2103604,2102548,2109756,257,21792,16464,2175563]

theorem envBound26780 : H12AffineFastState.Bounded env26780 := by
  intro p hp
  have h : env26780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26779_26780 : H12AffineEnvironment.transform 17 2420 env26779 = env26780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env26779 == env26780) = true)

theorem identity26780 : scanCanonicalize (H12AffineFastState.compose env26780 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound26780 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env26781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,2420,1025,29789,69910,8573,65862,95497,8192,64,89174,70727,17665,67618,66562,73770,257,21792,16464,9053]

theorem envBound26781 : H12AffineFastState.Bounded env26781 := by
  intro p hp
  have h : env26781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26780_26781 : H12AffineEnvironment.transform 20 69910 env26780 = env26781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env26780 == env26781) = true)

theorem identity26781 : scanCanonicalize (H12AffineFastState.compose env26781 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26781 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env26782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,13389,2420,1025,29789,12572,8573,8524,21763,8192,64,31836,13389,17665,10280,9224,32,257,21792,16464,9053]

theorem envBound26782 : H12AffineFastState.Bounded env26782 := by
  intro p hp
  have h : env26782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26781_26782 : H12AffineEnvironment.transform 15 8202 env26781 = env26782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26781 == env26782) = true)

theorem identity26782 : scanCanonicalize (H12AffineFastState.compose env26782 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound26782 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env26783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13389,2420,1025,0,12572,8573,8524,8542,8192,64,2049,13389,12636,10280,9224,32,257,8573,13325,9053]

theorem envBound26783 : H12AffineFastState.Bounded env26783 := by
  intro p hp
  have h : env26783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26782_26783 : H12AffineEnvironment.transform 13 13405 env26782 = env26783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env26782 == env26783) = true)

theorem identity26783 : scanCanonicalize (H12AffineFastState.compose env26783 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26783 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26784 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13389,2389,1025,0,12572,8540,8524,8542,8192,64,2049,13389,12636,10249,9224,1,257,8540,13325,9053]

theorem envBound26784 : H12AffineFastState.Bounded env26784 := by
  intro p hp
  have h : env26784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26783_26784 : H12AffineEnvironment.transform 4 1 env26783 = env26784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26783 == env26784) = true)

theorem identity26784 : scanCanonicalize (H12AffineFastState.compose env26784 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26784 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26785 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5456,1,263,5440,2389,1025,0,4113,81,65,83,269,64,2049,5440,4177,2308,1285,1,257,81,5376,592]

theorem envBound26785 : H12AffineFastState.Bounded env26785 := by
  intro p hp
  have h : env26785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26784_26785 : H12AffineEnvironment.transform 12 269 env26784 = env26785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26784 == env26785) = true)

theorem identity26785 : scanCanonicalize (H12AffineFastState.compose env26785 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26785 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26786 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5376,1,263,5392,2309,1025,0,4113,1,17,3,269,16,2049,5392,4097,2308,1285,1,257,1,5376,512]

theorem envBound26786 : H12AffineFastState.Bounded env26786 := by
  intro p hp
  have h : env26786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26785_26786 : H12AffineEnvironment.transform 5 16 env26785 = env26786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26785 == env26786) = true)

theorem identity26786 : scanCanonicalize (H12AffineFastState.compose env26786 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound26786 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26787 : List Nat := [2,4,8,16,1,16,8,256,512,257,2048,4096,269,4097,1,263,4113,2309,256,0,4113,1,17,3,269,16,2049,4113,4097,2308,4,1,257,1,4097,512]

theorem envBound26787 : H12AffineFastState.Bounded env26787 := by
  intro p hp
  have h : env26787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26786_26787 : H12AffineEnvironment.transform 9 257 env26786 = env26787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env26786 == env26787) = true)

theorem identity26787 : scanCanonicalize (H12AffineFastState.compose env26787 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound26787 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26788 : List Nat := [2,4,8,16,1,16,8,256,512,257,271,4096,269,4097,1,263,4113,10,256,0,4113,1,17,3,269,16,270,4113,4097,11,4,1,257,1,4097,512]

theorem envBound26788 : H12AffineFastState.Bounded env26788 := by
  intro p hp
  have h : env26788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26787_26788 : H12AffineEnvironment.transform 10 271 env26787 = env26788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env26787 == env26788) = true)

theorem identity26788 : scanCanonicalize (H12AffineFastState.compose env26788 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 789) := by decide +kernel

theorem selectedBound26788 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26789 : List Nat := [2,4,8,16,1,16,8,256,512,257,271,789,269,788,1,263,772,10,256,0,772,1,17,3,269,16,270,772,788,11,4,1,257,1,788,512]

theorem envBound26789 : H12AffineFastState.Bounded env26789 := by
  intro p hp
  have h : env26789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26788_26789 : H12AffineEnvironment.transform 11 789 env26788 = env26789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 789 env26788 == env26789) = true)

theorem identity26789 : scanCanonicalize (H12AffineFastState.compose env26789 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound26789 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26790 : List Nat := [2,4,8,16,1,16,8,256,17,257,271,260,269,261,1,263,277,10,256,0,277,1,17,3,269,16,270,277,261,11,4,1,257,1,261,17]

theorem envBound26790 : H12AffineFastState.Bounded env26790 := by
  intro p hp
  have h : env26790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26789_26790 : H12AffineEnvironment.transform 8 17 env26789 = env26790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env26789 == env26790) = true)

theorem identity26790 : scanCanonicalize (H12AffineFastState.compose env26790 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26790 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26791 : List Nat := [2,4,8,16,1,16,8,21,17,20,26,17,24,16,1,18,0,10,21,0,0,1,17,3,24,16,27,0,16,11,4,1,20,1,16,17]

theorem envBound26791 : H12AffineFastState.Bounded env26791 := by
  intro p hp
  have h : env26791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26790_26791 : H12AffineEnvironment.transform 7 21 env26790 = env26791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26790 == env26791) = true)

theorem identity26791 : scanCanonicalize (H12AffineFastState.compose env26791 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound26791 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26792 : List Nat := [2,4,8,9,1,9,8,12,8,13,3,8,1,9,1,11,0,10,12,0,0,1,8,3,1,9,2,0,9,11,4,1,13,1,9,8]

theorem envBound26792 : H12AffineFastState.Bounded env26792 := by
  intro p hp
  have h : env26792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26791_26792 : H12AffineEnvironment.transform 3 9 env26791 = env26792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env26791 == env26792) = true)

theorem identity26792 : scanCanonicalize (H12AffineFastState.compose env26792 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26792 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env26793 : List Nat := [2,4,2,3,1,3,2,6,2,7,3,2,1,3,1,1,0,0,6,0,0,1,2,3,1,3,2,0,3,1,4,1,7,1,3,2]

theorem envBound26793 : H12AffineFastState.Bounded env26793 := by
  intro p hp
  have h : env26793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26792_26793 : H12AffineEnvironment.transform 2 2 env26792 = env26793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26792 == env26793) = true)

theorem identity26793 : scanCanonicalize (H12AffineFastState.compose env26793 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26794 : List Nat := [2,2,2,3,1,3,2,0,2,1,3,2,1,3,1,1,0,0,0,0,0,1,2,3,1,3,2,0,3,1,2,1,1,1,3,2]

theorem envBound26794 : H12AffineFastState.Bounded env26794 := by
  intro p hp
  have h : env26794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26793_26794 : H12AffineEnvironment.transform 1 2 env26793 = env26794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26793 == env26794) = true)

theorem identity26794 : scanCanonicalize (H12AffineFastState.compose env26794 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26794 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26795 : List Nat := [1,1,1,0,1,0,1,0,1,1,0,1,1,0,1,1,0,0,0,0,0,1,1,0,1,0,1,0,0,1,1,1,1,1,0,1]

theorem envBound26795 : H12AffineFastState.Bounded env26795 := by
  intro p hp
  have h : env26795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26794_26795 : H12AffineEnvironment.transform 0 1 env26794 = env26795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26794 == env26795) = true)

def env26796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,2097152,272392,2101328,95497,8193,64,2116929,2098513,17665,2363456,2102549,2373704,257,21792,16464,2175563]

theorem envBound26796 : H12AffineFastState.Bounded env26796 := by
  intro p hp
  have h : env26796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26778_26796 : H12AffineEnvironment.transform 6 9 env26778 = env26796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26778 == env26796) = true)

theorem identity26796 : scanCanonicalize (H12AffineFastState.compose env26796 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(20+1) ^^^ 347159) := by decide +kernel

theorem selectedBound26796 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env26797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,347159,272392,351303,95497,8193,64,328022,346438,17665,89175,350466,95327,257,21792,16464,294492]

theorem envBound26797 : H12AffineFastState.Bounded env26797 := by
  intro p hp
  have h : env26797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26796_26797 : H12AffineEnvironment.transform 20 347159 env26796 = env26797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347159 env26796 == env26797) = true)

theorem identity26797 : scanCanonicalize (H12AffineFastState.compose env26797 (packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97546) := by decide +kernel

theorem selectedBound26797 : packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,97546,1025,29788,12573,87298,8525,95497,8193,64,31836,13388,17665,89175,9224,95327,257,21792,16464,66390]

theorem envBound26798 : H12AffineFastState.Bounded env26798 := by
  intro p hp
  have h : env26798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26797_26798 : H12AffineEnvironment.transform 17 97546 env26797 = env26798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97546 env26797 == env26798) = true)

theorem identity26798 : scanCanonicalize (H12AffineFastState.compose env26798 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound26798 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env26799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,13388,10588,1025,29788,12573,340,8525,8543,8193,64,31836,13388,17665,2049,9224,8201,257,21792,16464,22272]

theorem envBound26799 : H12AffineFastState.Bounded env26799 := by
  intro p hp
  have h : env26799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26798_26799 : H12AffineEnvironment.transform 15 21590 env26798 = env26799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env26798 == env26799) = true)

theorem identity26799 : scanCanonicalize (H12AffineFastState.compose env26799 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26799 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env26800 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29789,21590,13388,10281,1025,29788,12392,33,8248,8234,8193,64,31836,13388,17524,2049,9224,8201,116,21589,16464,22133]

theorem envBound26800 : H12AffineFastState.Bounded env26800 := by
  intro p hp
  have h : env26800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26799_26800 : H12AffineEnvironment.transform 7 117 env26799 = env26800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26799 == env26800) = true)

theorem identity26800 : scanCanonicalize (H12AffineFastState.compose env26800 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound26800 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env26801 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4113,9292,1095,13388,10281,1025,9293,12392,33,8248,8234,8193,64,11341,13388,5221,2049,9224,8201,116,1092,4161,1636]

theorem envBound26801 : H12AffineFastState.Bounded env26801 := by
  intro p hp
  have h : env26801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26800_26801 : H12AffineEnvironment.transform 13 4113 env26800 = env26801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env26800 == env26801) = true)

theorem identity26801 : scanCanonicalize (H12AffineFastState.compose env26801 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 3084) := by decide +kernel

theorem selectedBound26801 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env26802 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,3084,4113,2112,1095,6208,1061,1025,2113,7268,33,3124,3110,3085,64,65,6208,5221,2049,2052,3077,116,1092,4161,1636]

theorem envBound26802 : H12AffineFastState.Bounded env26802 := by
  intro p hp
  have h : env26802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26801_26802 : H12AffineEnvironment.transform 12 3084 env26801 = env26802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3084 env26801 == env26802) = true)

theorem identity26802 : scanCanonicalize (H12AffineFastState.compose env26802 (packedSelected [1,2,4,6,8,9,10,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound26802 : packedSelected [1,2,4,6,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env26803 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1060,4096,40,4113,1124,1095,5220,1061,1025,1125,4160,33,16,2,41,64,65,5220,5221,1061,1056,33,116,1092,4161,1636]

theorem envBound26803 : H12AffineFastState.Bounded env26803 := by
  intro p hp
  have h : env26803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26802_26803 : H12AffineEnvironment.transform 10 1060 env26802 = env26803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env26802 == env26803) = true)

theorem identity26803 : scanCanonicalize (H12AffineFastState.compose env26803 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound26803 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26804 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1060,113,40,96,1124,1095,1045,1061,1025,1125,49,33,16,2,41,64,65,1045,1044,1061,1056,33,116,1092,48,1636]

theorem envBound26804 : H12AffineFastState.Bounded env26804 := by
  intro p hp
  have h : env26804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26803_26804 : H12AffineEnvironment.transform 11 113 env26803 = env26804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env26803 == env26804) = true)

theorem identity26804 : scanCanonicalize (H12AffineFastState.compose env26804 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound26804 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26805 : List Nat := [2,4,8,16,32,49,9,4,512,1024,1060,0,40,17,1045,1078,1045,1061,1025,1044,49,33,16,2,41,49,48,1045,1044,1061,1056,33,5,1077,48,1557]

theorem envBound26805 : H12AffineFastState.Bounded env26805 := by
  intro p hp
  have h : env26805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26804_26805 : H12AffineEnvironment.transform 5 49 env26804 = env26805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26804 == env26805) = true)

theorem identity26805 : scanCanonicalize (H12AffineFastState.compose env26805 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26805 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26806 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1028,0,8,17,1045,1046,1045,1029,1025,1044,17,1,16,2,9,17,16,1045,1044,1029,1024,1,5,1045,16,1557]

theorem envBound26806 : H12AffineFastState.Bounded env26806 := by
  intro p hp
  have h : env26806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26805_26806 : H12AffineEnvironment.transform 4 0 env26805 = env26806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26805 == env26806) = true)

def env26807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound26807 : H12AffineFastState.Bounded env26807 := by
  intro p hp
  have h : env26807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26531_26807 : H12AffineEnvironment.transform 26 30393345 env26531 = env26807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env26531 == env26807) = true)

def env26808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound26808 : H12AffineFastState.Bounded env26808 := by
  intro p hp
  have h : env26808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26807_26808 : H12AffineEnvironment.transform 18 1024 env26807 = env26808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26807 == env26808) = true)

theorem identity26808 : scanCanonicalize (H12AffineFastState.compose env26808 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601613) := by decide +kernel

theorem selectedBound26808 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601613,8328,64,6685836,8404992,10507601,8830977,2113692,12624204,256,32,57732,2189130]

theorem envBound26809 : H12AffineFastState.Bounded env26809 := by
  intro p hp
  have h : env26809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26808_26809 : H12AffineEnvironment.transform 23 10601613 env26808 = env26809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601613 env26808 == env26809) = true)

def env26810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685836,8393984,10485841,8819969,2102684,12624204,256,32,46212,2175562]

theorem envBound26810 : H12AffineFastState.Bounded env26810 := by
  intro p hp
  have h : env26810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26809_26810 : H12AffineEnvironment.transform 13 5376 env26809 = env26810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26809 == env26810) = true)

def env26811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685836,2098648,4233,2524633,2102684,6336916,256,32,46212,2175562]

theorem envBound26811 : H12AffineFastState.Bounded env26811 := by
  intro p hp
  have h : env26811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26810_26811 : H12AffineEnvironment.transform 22 2101464 env26810 = env26811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env26810 == env26811) = true)

def env26812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491564,2098648,4233,2524633,2102684,2142644,256,32,46212,2175562]

theorem envBound26812 : H12AffineFastState.Bounded env26812 := by
  intro p hp
  have h : env26812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26811_26812 : H12AffineEnvironment.transform 21 32 env26811 = env26812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26811 == env26812) = true)

theorem identity26812 : scanCanonicalize (H12AffineFastState.compose env26812 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26812 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98645,8192,64,2491428,2098512,4097,2524497,2102548,2142524,256,32,46092,2175562]

theorem envBound26813 : H12AffineFastState.Bounded env26813 := by
  intro p hp
  have h : env26813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26812_26813 : H12AffineEnvironment.transform 6 8 env26812 = env26813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26812 == env26813) = true)

def env26814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398436,5392,4097,431377,1364,41340,256,32,46092,74250]

theorem envBound26814 : H12AffineFastState.Bounded env26814 := by
  intro p hp
  have h : env26814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26813_26814 : H12AffineEnvironment.transform 20 4160 env26813 = env26814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26813 == env26814) = true)

theorem identity26814 : scanCanonicalize (H12AffineFastState.compose env26814 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26814 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41310,8192,64,398436,5392,4097,431377,1364,41340,256,32,46092,513]

theorem envBound26815 : H12AffineFastState.Bounded env26815 := by
  intro p hp
  have h : env26815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26814_26815 : H12AffineEnvironment.transform 15 8203 env26814 = env26815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26814 == env26815) = true)

theorem identity26815 : scanCanonicalize (H12AffineFastState.compose env26815 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26815 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,32,16,2,8192,64,398436,5392,4097,406605,1364,32,256,32,5456,513]

theorem envBound26816 : H12AffineFastState.Bounded env26816 := by
  intro p hp
  have h : env26816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26815_26816 : H12AffineEnvironment.transform 14 8540 env26815 = env26816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26815 == env26816) = true)

theorem identity26816 : scanCanonicalize (H12AffineFastState.compose env26816 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound26816 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146792,1024,8541,4160,32,16,2,8192,64,10508,5392,4097,2341,1364,32,256,32,5456,513]

theorem envBound26817 : H12AffineFastState.Bounded env26817 := by
  intro p hp
  have h : env26817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26816_26817 : H12AffineEnvironment.transform 17 146792 env26816 = env26817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env26816 == env26817) = true)

theorem identity26817 : scanCanonicalize (H12AffineFastState.compose env26817 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26817 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env26818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10361,1024,8541,4160,32,16,2,8192,64,10508,5392,4097,2341,1364,32,256,32,5456,513]

theorem envBound26818 : H12AffineFastState.Bounded env26818 := by
  intro p hp
  have h : env26818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26817_26818 : H12AffineEnvironment.transform 16 5393 env26817 = env26818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26817 == env26818) = true)

theorem identity26818 : scanCanonicalize (H12AffineFastState.compose env26818 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26818 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env26819 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8312,8203,5173,10361,1024,8313,4160,32,16,2,8192,64,10280,5172,4097,2049,1136,32,36,32,5236,513]

theorem envBound26819 : H12AffineFastState.Bounded env26819 := by
  intro p hp
  have h : env26819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26818_26819 : H12AffineEnvironment.transform 7 36 env26818 = env26819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26818 == env26819) = true)

def env26820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398437,5393,4097,431376,1365,41341,256,32,46092,74251]

theorem envBound26820 : H12AffineFastState.Bounded env26820 := by
  intro p hp
  have h : env26820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26813_26820 : H12AffineEnvironment.transform 20 4161 env26813 = env26820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26813 == env26820) = true)

theorem identity26820 : scanCanonicalize (H12AffineFastState.compose env26820 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound26820 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4161,32,17,98645,8192,64,203847,5393,4097,236850,1365,41341,256,32,46092,74251]

theorem envBound26821 : H12AffineFastState.Bounded env26821 := by
  intro p hp
  have h : env26821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26820_26821 : H12AffineEnvironment.transform 17 67618 env26820 = env26821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env26820 == env26821) = true)

theorem identity26821 : scanCanonicalize (H12AffineFastState.compose env26821 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26821 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10280,1024,32769,4161,32,17,41311,8192,64,146509,5393,4097,179512,1365,41341,256,32,46092,513]

theorem envBound26822 : H12AffineFastState.Bounded env26822 := by
  intro p hp
  have h : env26822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26821_26822 : H12AffineEnvironment.transform 15 8202 env26821 = env26822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26821 == env26822) = true)

theorem identity26822 : scanCanonicalize (H12AffineFastState.compose env26822 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26822 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,262,131072,2340,1024,32769,4161,32,17,32851,268,64,138561,5393,4097,171060,1365,32881,256,32,38144,513]

theorem envBound26823 : H12AffineFastState.Bounded env26823 := by
  intro p hp
  have h : env26823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26822_26823 : H12AffineEnvironment.transform 12 268 env26822 = env26823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26822 == env26823) = true)

theorem identity26823 : scanCanonicalize (H12AffineFastState.compose env26823 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound26823 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,262,5441,2340,1024,32769,4161,32,17,32851,268,64,2048,5393,4097,35189,1365,32881,256,32,38144,513]

theorem envBound26824 : H12AffineFastState.Bounded env26824 := by
  intro p hp
  have h : env26824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26823_26824 : H12AffineEnvironment.transform 16 5441 env26823 = env26824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env26823 == env26824) = true)

def env26825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491565,2098648,4233,2524633,2102684,2142645,256,32,46212,2175562]

theorem envBound26825 : H12AffineFastState.Bounded env26825 := by
  intro p hp
  have h : env26825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26811_26825 : H12AffineEnvironment.transform 21 33 env26811 = env26825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26811 == env26825) = true)

theorem identity26825 : scanCanonicalize (H12AffineFastState.compose env26825 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound26825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,152,98645,8328,64,398573,5528,4233,431513,1500,41461,256,32,46212,74250]

theorem envBound26826 : H12AffineFastState.Bounded env26826 := by
  intro p hp
  have h : env26826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26825_26826 : H12AffineEnvironment.transform 20 4160 env26825 = env26826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26825 == env26826) = true)

def env26827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398437,5392,4097,431377,1364,41341,256,32,46092,74250]

theorem envBound26827 : H12AffineFastState.Bounded env26827 := by
  intro p hp
  have h : env26827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26826_26827 : H12AffineEnvironment.transform 6 8 env26826 = env26827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26826 == env26827) = true)

theorem identity26827 : scanCanonicalize (H12AffineFastState.compose env26827 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26827 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41310,8192,64,398437,5392,4097,431377,1364,41341,256,32,46092,513]

theorem envBound26828 : H12AffineFastState.Bounded env26828 := by
  intro p hp
  have h : env26828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26827_26828 : H12AffineEnvironment.transform 15 8203 env26827 = env26828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26827 == env26828) = true)

theorem identity26828 : scanCanonicalize (H12AffineFastState.compose env26828 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26828 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,33,16,2,8192,64,398437,5392,4097,406605,1364,33,256,32,5456,513]

theorem envBound26829 : H12AffineFastState.Bounded env26829 := by
  intro p hp
  have h : env26829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26828_26829 : H12AffineEnvironment.transform 14 8540 env26828 = env26829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26828 == env26829) = true)

theorem identity26829 : scanCanonicalize (H12AffineFastState.compose env26829 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound26829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146792,1024,8541,4160,33,16,2,8192,64,10509,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound26830 : H12AffineFastState.Bounded env26830 := by
  intro p hp
  have h : env26830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26829_26830 : H12AffineEnvironment.transform 17 146792 env26829 = env26830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env26829 == env26830) = true)

theorem identity26830 : scanCanonicalize (H12AffineFastState.compose env26830 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26830 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env26831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,131072,138293,1024,0,4160,33,16,2,349,64,2128,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound26831 : H12AffineFastState.Bounded env26831 := by
  intro p hp
  have h : env26831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26830_26831 : H12AffineEnvironment.transform 12 349 env26830 = env26831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26830 == env26831) = true)

theorem identity26831 : scanCanonicalize (H12AffineFastState.compose env26831 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound26831 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5441,2420,1024,0,4160,33,16,2,349,64,2128,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound26832 : H12AffineFastState.Bounded env26832 := by
  intro p hp
  have h : env26832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26831_26832 : H12AffineEnvironment.transform 16 5441 env26831 = env26832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env26831 == env26832) = true)

theorem identity26832 : scanCanonicalize (H12AffineFastState.compose env26832 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

theorem selectedBound26832 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3157,349,2389,1,342,2324,2420,1024,0,3093,33,16,2,349,64,2128,2373,3156,2341,1364,33,256,32,2309,513]

theorem envBound26833 : H12AffineFastState.Bounded env26833 := by
  intro p hp
  have h : env26833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26832_26833 : H12AffineEnvironment.transform 11 3157 env26832 = env26833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env26832 == env26833) = true)

theorem identity26833 : scanCanonicalize (H12AffineFastState.compose env26833 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound26833 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26834 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,3157,8,2048,1,3,2113,2081,1024,0,3093,33,16,2,8,64,2128,2064,3156,2160,1025,33,85,32,2128,513]

theorem envBound26834 : H12AffineFastState.Bounded env26834 := by
  intro p hp
  have h : env26834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26833_26834 : H12AffineEnvironment.transform 7 85 env26833 = env26834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env26833 == env26834) = true)

theorem identity26834 : scanCanonicalize (H12AffineFastState.compose env26834 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound26834 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26835 : List Nat := [2,4,8,16,32,64,8,85,65,1024,2048,3157,8,2048,1,3,2113,2081,1024,0,3093,33,16,2,8,64,2128,2064,3156,2160,1025,33,85,32,2128,64]

theorem envBound26835 : H12AffineFastState.Bounded env26835 := by
  intro p hp
  have h : env26835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26834_26835 : H12AffineEnvironment.transform 8 65 env26834 = env26835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env26834 == env26835) = true)

theorem identity26835 : scanCanonicalize (H12AffineFastState.compose env26835 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26835 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env26836 : List Nat := [2,4,8,16,32,64,8,85,65,20,2048,2113,8,2048,1,3,2113,2081,20,0,2049,33,16,2,8,64,2128,2064,2112,2160,21,33,85,32,2128,64]

theorem envBound26836 : H12AffineFastState.Bounded env26836 := by
  intro p hp
  have h : env26836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26835_26836 : H12AffineEnvironment.transform 9 20 env26835 = env26836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26835 == env26836) = true)

theorem identity26836 : scanCanonicalize (H12AffineFastState.compose env26836 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26836 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env26837 : List Nat := [2,4,8,16,32,64,8,85,65,20,0,65,8,0,1,3,65,33,20,0,1,33,16,2,8,64,80,16,64,112,21,33,85,32,80,64]

theorem envBound26837 : H12AffineFastState.Bounded env26837 := by
  intro p hp
  have h : env26837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26836_26837 : H12AffineEnvironment.transform 10 0 env26836 = env26837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26836 == env26837) = true)

theorem identity26837 : scanCanonicalize (H12AffineFastState.compose env26837 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26837 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26838 : List Nat := [2,4,8,16,16,64,8,85,65,20,0,65,8,0,1,3,65,17,20,0,1,17,16,2,8,64,80,16,64,64,21,17,85,16,80,64]

theorem envBound26838 : H12AffineFastState.Bounded env26838 := by
  intro p hp
  have h : env26838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26837_26838 : H12AffineEnvironment.transform 4 16 env26837 = env26838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26837 == env26838) = true)

theorem identity26838 : scanCanonicalize (H12AffineFastState.compose env26838 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26838 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26839 : List Nat := [2,4,8,16,16,1,8,20,0,20,0,0,8,0,1,3,0,17,20,0,1,17,16,2,8,1,17,16,1,1,21,17,20,16,17,1]

theorem envBound26839 : H12AffineFastState.Bounded env26839 := by
  intro p hp
  have h : env26839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26838_26839 : H12AffineEnvironment.transform 5 1 env26838 = env26839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26838 == env26839) = true)

def env26840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,17,98645,8193,64,398436,5393,4096,431376,1365,41340,256,32,46093,74250]

theorem envBound26840 : H12AffineFastState.Bounded env26840 := by
  intro p hp
  have h : env26840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26826_26840 : H12AffineEnvironment.transform 6 9 env26826 = env26840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26826 == env26840) = true)

theorem identity26840 : scanCanonicalize (H12AffineFastState.compose env26840 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound26840 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,4160,33,17,98645,8193,64,245018,5393,4096,212078,1365,41340,256,32,46093,74250]

theorem envBound26841 : H12AffineFastState.Bounded env26841 := by
  intro p hp
  have h : env26841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26840_26841 : H12AffineEnvironment.transform 17 108926 env26840 = env26841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env26840 == env26841) = true)

theorem identity26841 : scanCanonicalize (H12AffineFastState.compose env26841 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26841 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108926,1024,32769,4160,33,17,98645,8193,64,108555,5393,4096,76159,1365,41340,256,32,46093,74250]

theorem envBound26842 : H12AffineFastState.Bounded env26842 := by
  intro p hp
  have h : env26842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26841_26842 : H12AffineEnvironment.transform 16 5393 env26841 = env26842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26841 == env26842) = true)

theorem identity26842 : scanCanonicalize (H12AffineFastState.compose env26842 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26842 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5393,35189,1024,32769,4160,33,17,41310,8193,64,34816,5393,4096,2420,1365,41340,256,32,46093,513]

theorem envBound26843 : H12AffineFastState.Bounded env26843 := by
  intro p hp
  have h : env26843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26842_26843 : H12AffineEnvironment.transform 15 8203 env26842 = env26843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26842 == env26843) = true)

theorem identity26843 : scanCanonicalize (H12AffineFastState.compose env26843 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound26843 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9292,8203,5393,11577,1024,9293,4160,33,17,1298,8193,64,11340,5393,4096,2420,1365,1328,256,32,4161,513]

theorem envBound26844 : H12AffineFastState.Bounded env26844 := by
  intro p hp
  have h : env26844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26843_26844 : H12AffineEnvironment.transform 14 9292 env26843 = env26844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env26843 == env26844) = true)

theorem identity26844 : scanCanonicalize (H12AffineFastState.compose env26844 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound26844 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,292,8192,1060,9292,8203,1077,11577,1024,9293,356,33,17,1298,8193,64,11340,1077,292,2420,1365,1328,256,32,357,513]

theorem envBound26845 : H12AffineFastState.Bounded env26845 := by
  intro p hp
  have h : env26845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26844_26845 : H12AffineEnvironment.transform 11 292 env26844 = env26845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env26844 == env26845) = true)

def env26846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685836,2098649,4232,2524632,2102684,6336917,256,32,46212,2175562]

theorem envBound26846 : H12AffineFastState.Bounded env26846 := by
  intro p hp
  have h : env26846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26810_26846 : H12AffineEnvironment.transform 22 2101465 env26810 = env26846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env26810 == env26846) = true)

def env26847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491564,2098649,4232,2524632,2102684,2142645,256,32,46212,2175562]

theorem envBound26847 : H12AffineFastState.Bounded env26847 := by
  intro p hp
  have h : env26847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26846_26847 : H12AffineEnvironment.transform 21 32 env26846 = env26847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26846 == env26847) = true)

theorem identity26847 : scanCanonicalize (H12AffineFastState.compose env26847 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26847 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,2097152,32,2101465,73736,8328,64,2491564,2098649,4232,2499716,2102684,2101481,256,32,5592,2175562]

theorem envBound26848 : H12AffineFastState.Bounded env26848 := by
  intro p hp
  have h : env26848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26847_26848 : H12AffineEnvironment.transform 14 8540 env26847 = env26848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26847 == env26848) = true)

def env26849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,2097152,32,2101465,73736,8328,64,2239500,2098649,4232,2231332,2102684,2101481,256,32,5592,2175562]

end H12CloudChart0