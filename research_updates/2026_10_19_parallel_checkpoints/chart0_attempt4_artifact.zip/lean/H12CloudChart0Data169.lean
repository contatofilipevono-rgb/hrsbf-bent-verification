import H12CloudChart0Data168

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity42823 : scanCanonicalize (H12AffineFastState.compose env42823 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound42823 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42824 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,8192,16384,8540,27006,2405,10280,273,8541,2341,33,16,2,8192,64,10589,16400,16400,16385,18736,33,256,32,16464,513]

theorem envBound42824 : H12AffineFastState.Bounded env42824 := by
  intro p hp
  have h : env42824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42823_42824 : H12AffineEnvironment.transform 11 2405 env42823 = env42824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env42823 == env42824) = true)

theorem identity42824 : scanCanonicalize (H12AffineFastState.compose env42824 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound42824 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env42825 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,8192,2048,8540,8574,2405,10280,273,8541,2341,33,16,2,8192,64,10589,2064,2064,2049,304,33,256,32,2128,513]

theorem envBound42825 : H12AffineFastState.Bounded env42825 := by
  intro p hp
  have h : env42825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42824_42825 : H12AffineEnvironment.transform 13 2048 env42824 = env42825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env42824 == env42825) = true)

theorem identity42825 : scanCanonicalize (H12AffineFastState.compose env42825 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42825 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env42826 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,269,2048,81,115,2405,2341,273,80,2341,33,16,2,269,64,2128,2064,2064,2049,304,33,256,32,2128,513]

theorem envBound42826 : H12AffineFastState.Bounded env42826 := by
  intro p hp
  have h : env42826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42825_42826 : H12AffineEnvironment.transform 12 269 env42825 = env42826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42825 == env42826) = true)

theorem identity42826 : scanCanonicalize (H12AffineFastState.compose env42826 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42826 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42827 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2112,40,2048,81,115,2112,2048,52,80,2048,33,16,2,40,64,2128,2064,2064,2049,21,33,37,32,2128,513]

theorem envBound42827 : H12AffineFastState.Bounded env42827 := by
  intro p hp
  have h : env42827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42826_42827 : H12AffineEnvironment.transform 7 37 env42826 = env42827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42826 == env42827) = true)

theorem identity42827 : scanCanonicalize (H12AffineFastState.compose env42827 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound42827 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env42828 : List Nat := [2,4,8,16,32,64,8,37,112,52,2048,2112,40,2048,81,115,2112,2048,52,80,2048,33,16,2,40,64,2128,2064,2064,2049,21,33,37,32,2128,113]

theorem envBound42828 : H12AffineFastState.Bounded env42828 := by
  intro p hp
  have h : env42828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42827_42828 : H12AffineEnvironment.transform 8 112 env42827 = env42828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env42827 == env42828) = true)

theorem identity42828 : scanCanonicalize (H12AffineFastState.compose env42828 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42828 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env42829 : List Nat := [2,4,8,16,0,64,8,5,80,20,2048,2112,8,2048,81,83,2112,2048,20,80,2048,1,16,2,8,64,2128,2064,2064,2049,21,1,5,0,2128,81]

theorem envBound42829 : H12AffineFastState.Bounded env42829 := by
  intro p hp
  have h : env42829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42828_42829 : H12AffineEnvironment.transform 4 0 env42828 = env42829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42828 == env42829) = true)

def env42830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,16,95496,8193,64,171281,79130,102742,442384,61705,392286,256,95530,103431,120406]

theorem envBound42830 : H12AffineFastState.Bounded env42830 := by
  intro p hp
  have h : env42830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42817_42830 : H12AffineEnvironment.transform 6 9 env42817 = env42830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42817 == env42830) = true)

def env42831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272392,16,95496,8193,64,56577,79130,102742,294912,61705,392286,256,95530,103431,120406]

theorem envBound42831 : H12AffineFastState.Bounded env42831 := by
  intro p hp
  have h : env42831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42830_42831 : H12AffineEnvironment.transform 16 16400 env42830 = env42831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42830 == env42831) = true)

def env42832 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272392,16,95496,8193,16,56577,79130,102662,294912,61705,392206,256,95530,103431,120326]

theorem envBound42832 : H12AffineFastState.Bounded env42832 := by
  intro p hp
  have h : env42832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42831_42832 : H12AffineEnvironment.transform 5 16 env42831 = env42832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42831 == env42832) = true)

theorem identity42832 : scanCanonicalize (H12AffineFastState.compose env42832 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42832 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env42833 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1024,21760,69910,272392,16,95496,8193,16,2048,79130,82951,283905,9224,338191,256,95530,82182,66311]

theorem envBound42833 : H12AffineFastState.Bounded env42833 := by
  intro p hp
  have h : env42833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42832_42833 : H12AffineEnvironment.transform 14 21761 env42832 = env42833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42832 == env42833) = true)

theorem identity42833 : scanCanonicalize (H12AffineFastState.compose env42833 (packedSelected [3,4,7,9,10,19,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound42833 : packedSelected [3,4,7,9,10,19,24,27] rootPS < 2^1333 := by decide +kernel

def env42834 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,65536,13340,262144,1024,8460,69910,272392,16,65796,8193,16,2048,79130,77835,270605,9224,338191,256,65830,79114,66311]

theorem envBound42834 : H12AffineFastState.Bounded env42834 := by
  intro p hp
  have h : env42834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42833_42834 : H12AffineEnvironment.transform 13 13324 env42833 = env42834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env42833 == env42834) = true)

theorem identity42834 : scanCanonicalize (H12AffineFastState.compose env42834 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound42834 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env42835 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,65536,13340,2341,1024,8460,69910,8493,16,65796,8193,16,2048,79130,77835,10280,9224,73770,256,65830,79114,66311]

theorem envBound42835 : H12AffineFastState.Bounded env42835 := by
  intro p hp
  have h : env42835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42834_42835 : H12AffineEnvironment.transform 17 2341 env42834 = env42835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env42834 == env42835) = true)

theorem identity42835 : scanCanonicalize (H12AffineFastState.compose env42835 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42835 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env42836 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,8202,13340,2341,1024,8460,12572,8493,16,8462,8193,16,2048,5392,4097,10280,9224,32,256,8492,5376,8973]

theorem envBound42836 : H12AffineFastState.Bounded env42836 := by
  intro p hp
  have h : env42836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42835_42836 : H12AffineEnvironment.transform 15 8202 env42835 = env42836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42835 == env42836) = true)

theorem identity42836 : scanCanonicalize (H12AffineFastState.compose env42836 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42836 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42837 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,13324,8233,8202,13340,2049,1024,8232,12344,8201,16,8234,8193,16,2048,5172,4097,10280,9224,32,36,8200,5156,8745]

theorem envBound42837 : H12AffineFastState.Bounded env42837 := by
  intro p hp
  have h : env42837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42836_42837 : H12AffineEnvironment.transform 7 36 env42836 = env42837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42836 == env42837) = true)

theorem identity42837 : scanCanonicalize (H12AffineFastState.compose env42837 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound42837 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env42838 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2096,8192,11324,8233,8202,11308,2049,1024,8232,10248,8201,16,8234,8193,16,2048,3076,2097,10280,9224,32,36,8200,3092,8745]

theorem envBound42838 : H12AffineFastState.Bounded env42838 := by
  intro p hp
  have h : env42838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42837_42838 : H12AffineEnvironment.transform 11 2096 env42837 = env42838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env42837 == env42838) = true)

theorem identity42838 : scanCanonicalize (H12AffineFastState.compose env42838 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42838 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42839 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,2065,8192,11293,8200,8202,11277,2049,1024,8201,10248,8201,16,8203,8193,16,2048,3076,2064,10249,9224,1,5,8200,3092,8712]

theorem envBound42839 : H12AffineFastState.Bounded env42839 := by
  intro p hp
  have h : env42839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42838_42839 : H12AffineEnvironment.transform 4 1 env42838 = env42839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42838 == env42839) = true)

theorem identity42839 : scanCanonicalize (H12AffineFastState.compose env42839 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound42839 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42840 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,2065,8,3093,0,2,3077,2049,1024,1,2048,1,16,3,9,16,2048,3076,2064,2049,1024,1,5,0,3092,512]

theorem envBound42840 : H12AffineFastState.Bounded env42840 := by
  intro p hp
  have h : env42840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42839_42840 : H12AffineEnvironment.transform 12 8 env42839 = env42840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env42839 == env42840) = true)

def env42841 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272392,16,95496,8193,17,56577,79130,102663,294912,61705,392207,256,95530,103431,120327]

theorem envBound42841 : H12AffineFastState.Bounded env42841 := by
  intro p hp
  have h : env42841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42831_42841 : H12AffineEnvironment.transform 5 17 env42831 = env42841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42831 == env42841) = true)

theorem identity42841 : scanCanonicalize (H12AffineFastState.compose env42841 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound42841 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env42842 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,122147,1024,32769,115735,128299,16,95496,8193,17,56577,79130,102663,89379,61705,8492,256,95530,103431,120327]

theorem envBound42842 : H12AffineFastState.Bounded env42842 := by
  intro p hp
  have h : env42842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42841_42842 : H12AffineEnvironment.transform 17 122147 env42841 = env42842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env42841 == env42842) = true)

theorem identity42842 : scanCanonicalize (H12AffineFastState.compose env42842 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound42842 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42843 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,16400,56356,1024,32769,50448,62508,16,29711,8193,17,56577,13341,36864,23588,61705,8492,256,29741,38144,55040]

theorem envBound42843 : H12AffineFastState.Bounded env42843 := by
  intro p hp
  have h : env42843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42842_42843 : H12AffineEnvironment.transform 15 263 env42842 = env42843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env42842 == env42843) = true)

theorem identity42843 : scanCanonicalize (H12AffineFastState.compose env42843 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42843 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42844 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,16400,56356,1024,32769,50448,54560,16,21763,269,17,56577,5393,36864,23588,53253,32,256,21793,38144,55040]

theorem envBound42844 : H12AffineFastState.Bounded env42844 := by
  intro p hp
  have h : env42844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42843_42844 : H12AffineEnvironment.transform 12 268 env42843 = env42844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42843 == env42844) = true)

theorem identity42844 : scanCanonicalize (H12AffineFastState.compose env42844 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound42844 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env42845 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,32,268,16384,32768,263,16400,52228,1024,32769,50448,50432,16,17699,269,17,52513,1329,32800,19460,49189,32,256,17665,34080,50976]

theorem envBound42845 : H12AffineFastState.Bounded env42845 := by
  intro p hp
  have h : env42845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42844_42845 : H12AffineEnvironment.transform 11 32 env42844 = env42845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env42844 == env42845) = true)

theorem identity42845 : scanCanonicalize (H12AffineFastState.compose env42845 (packedSelected [4,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 789) := by decide +kernel

theorem selectedBound42845 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env42846 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,32,268,16384,789,263,16400,20241,1024,788,17925,17941,16,17699,269,17,20020,1329,821,19460,17200,32,256,17665,1589,17461]

theorem envBound42846 : H12AffineFastState.Bounded env42846 := by
  intro p hp
  have h : env42846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42845_42846 : H12AffineEnvironment.transform 14 789 env42845 = env42846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 789 env42845 == env42846) = true)

def env42847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115735,272392,16,95496,8193,64,56576,79130,102742,294913,61705,392286,256,95530,103431,120406]

theorem envBound42847 : H12AffineFastState.Bounded env42847 := by
  intro p hp
  have h : env42847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42830_42847 : H12AffineEnvironment.transform 16 16401 env42830 = env42847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42830 == env42847) = true)

theorem identity42847 : scanCanonicalize (H12AffineFastState.compose env42847 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound42847 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,262144,1024,32769,4160,272392,16,41311,8193,64,56576,57677,17665,294913,61705,272393,256,41341,16464,513]

theorem envBound42848 : H12AffineFastState.Bounded env42848 := by
  intro p hp
  have h : env42848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42847_42848 : H12AffineEnvironment.transform 15 54359 env42847 = env42848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env42847 == env42848) = true)

theorem identity42848 : scanCanonicalize (H12AffineFastState.compose env42848 (packedSelected [0,1,7,8,12,19,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42848 : packedSelected [0,1,7,8,12,19,20,38] rootPS < 2^1333 := by decide +kernel

def env42849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1024,32769,4160,33,16,41311,8193,64,56576,57677,17665,43048,61705,32,256,41341,16464,513]

theorem envBound42849 : H12AffineFastState.Bounded env42849 := by
  intro p hp
  have h : env42849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42848_42849 : H12AffineEnvironment.transform 17 10281 env42848 = env42849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42848 == env42849) = true)

theorem identity42849 : scanCanonicalize (H12AffineFastState.compose env42849 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42849 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env42850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5392,10281,1024,32769,4160,33,16,41311,8193,64,34817,46156,4096,43048,41992,32,256,41341,5457,513]

theorem envBound42850 : H12AffineFastState.Bounded env42850 := by
  intro p hp
  have h : env42850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42849_42850 : H12AffineEnvironment.transform 13 5377 env42849 = env42850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42849 == env42850) = true)

theorem identity42850 : scanCanonicalize (H12AffineFastState.compose env42850 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42850 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5392,10281,1024,8541,4160,33,16,3,8193,64,10589,5392,4096,2420,1364,32,256,33,5457,513]

theorem envBound42851 : H12AffineFastState.Bounded env42851 := by
  intro p hp
  have h : env42851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42850_42851 : H12AffineEnvironment.transform 14 8540 env42850 = env42851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42850 == env42851) = true)

theorem identity42851 : scanCanonicalize (H12AffineFastState.compose env42851 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42851 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42852 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,5392,10281,1024,8461,4112,33,16,3,8193,16,10509,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound42852 : H12AffineFastState.Bounded env42852 := by
  intro p hp
  have h : env42852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42851_42852 : H12AffineEnvironment.transform 5 16 env42851 = env42852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42851 == env42852) = true)

theorem identity42852 : scanCanonicalize (H12AffineFastState.compose env42852 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42853 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8233,8202,5173,10281,1024,8232,4112,33,16,3,8193,16,10280,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound42853 : H12AffineFastState.Bounded env42853 := by
  intro p hp
  have h : env42853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42852_42853 : H12AffineEnvironment.transform 7 37 env42852 = env42853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42852 == env42853) = true)

def env42854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,95497,8328,64,13022472,79131,8491471,8830976,8450328,4314199,256,8484155,8492191,8509134]

theorem envBound42854 : H12AffineFastState.Bounded env42854 := by
  intro p hp
  have h : env42854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42743_42854 : H12AffineEnvironment.transform 23 95497 env42743 = env42854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env42743 == env42854) = true)

def env42855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,8388608,95497,8328,64,8560008,79131,8491471,8830976,8450328,392407,256,8484155,8492191,8509134]

theorem envBound42855 : H12AffineFastState.Bounded env42855 := by
  intro p hp
  have h : env42855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42854_42855 : H12AffineEnvironment.transform 21 272512 env42854 = env42855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42854 == env42855) = true)

theorem identity42855 : scanCanonicalize (H12AffineFastState.compose env42855 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound42855 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,120015,95497,8328,64,215367,79131,17664,464079,75223,392407,256,41460,16464,513]

theorem envBound42856 : H12AffineFastState.Bounded env42856 := by
  intro p hp
  have h : env42856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42855_42856 : H12AffineEnvironment.transform 22 120015 env42855 = env42856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env42855 == env42856) = true)

def env42857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,119879,95497,8192,64,215367,79131,17664,463943,75103,392287,256,41340,16464,513]

theorem envBound42857 : H12AffineFastState.Bounded env42857 := by
  intro p hp
  have h : env42857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42856_42857 : H12AffineEnvironment.transform 6 8 env42856 = env42857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42856 == env42857) = true)

theorem identity42857 : scanCanonicalize (H12AffineFastState.compose env42857 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42857 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,115734,272392,119879,95497,8192,64,10588,79131,17664,291932,75103,392287,256,41340,16464,513]

theorem envBound42858 : H12AffineFastState.Bounded env42858 := by
  intro p hp
  have h : env42858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42857_42858 : H12AffineEnvironment.transform 16 90139 env42857 = env42858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42857 == env42858) = true)

def env42859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,115734,32,119879,95497,8192,64,10588,79131,17664,23668,75103,119927,256,41340,16464,513]

theorem envBound42859 : H12AffineFastState.Bounded env42859 := by
  intro p hp
  have h : env42859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42858_42859 : H12AffineEnvironment.transform 17 10280 env42858 = env42859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42858 == env42859) = true)

theorem identity42859 : scanCanonicalize (H12AffineFastState.compose env42859 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42859 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,91466,32,95515,95497,8192,64,10588,79131,17664,23668,75103,95531,256,32,16464,513]

theorem envBound42860 : H12AffineFastState.Bounded env42860 := by
  intro p hp
  have h : env42860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42859_42860 : H12AffineEnvironment.transform 14 8540 env42859 = env42860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42859 == env42860) = true)

theorem identity42860 : scanCanonicalize (H12AffineFastState.compose env42860 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1379) := by decide +kernel

theorem selectedBound42860 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env42861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,1379,25976,10280,1024,8541,24617,32,28792,28778,8192,64,10588,12408,17664,23668,8252,28744,256,32,16464,513]

theorem envBound42861 : H12AffineFastState.Bounded env42861 := by
  intro p hp
  have h : env42861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42860_42861 : H12AffineEnvironment.transform 15 1379 env42860 = env42861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1379 env42860 == env42861) = true)

theorem identity42861 : scanCanonicalize (H12AffineFastState.compose env42861 (packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound42861 : packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env42862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,16384,7504,1379,22900,5156,1024,7505,23589,32,19572,19558,7180,64,5456,3188,17664,23668,7216,19524,256,32,16464,513]

theorem envBound42862 : H12AffineFastState.Bounded env42862 := by
  intro p hp
  have h : env42862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42861_42862 : H12AffineEnvironment.transform 12 7180 env42861 = env42862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env42861 == env42862) = true)

theorem identity42862 : scanCanonicalize (H12AffineFastState.compose env42862 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound42862 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env42863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,2129,7504,1379,4389,5156,1024,7505,5236,32,1061,1079,7180,64,5456,3188,3409,5157,7216,1045,256,32,2049,513]

theorem envBound42863 : H12AffineFastState.Bounded env42863 := by
  intro p hp
  have h : env42863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42862_42863 : H12AffineEnvironment.transform 13 2129 env42862 = env42863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env42862 == env42863) = true)

theorem identity42863 : scanCanonicalize (H12AffineFastState.compose env42863 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42863 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42864 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6428,2129,6208,115,4389,4404,272,6209,4452,32,309,295,6428,64,4160,2404,2113,4405,6432,261,256,32,2049,513]

theorem envBound42864 : H12AffineFastState.Bounded env42864 := by
  intro p hp
  have h : env42864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42863_42864 : H12AffineEnvironment.transform 9 272 env42863 = env42864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42863 == env42864) = true)

theorem identity42864 : scanCanonicalize (H12AffineFastState.compose env42864 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound42864 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env42865 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,120,2129,292,115,2113,2128,272,293,2048,32,309,295,120,64,2340,2404,2113,2129,68,261,256,32,2049,513]

theorem envBound42865 : H12AffineFastState.Bounded env42865 := by
  intro p hp
  have h : env42865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42864_42865 : H12AffineEnvironment.transform 11 2404 env42864 = env42865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env42864 == env42865) = true)

def env42866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,115734,33,119879,95497,8192,64,10588,79131,17664,23669,75103,119926,256,41340,16464,513]

theorem envBound42866 : H12AffineFastState.Bounded env42866 := by
  intro p hp
  have h : env42866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42858_42866 : H12AffineEnvironment.transform 17 10281 env42858 = env42866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42858 == env42866) = true)

theorem identity42866 : scanCanonicalize (H12AffineFastState.compose env42866 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound42866 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,5392,10281,1024,32769,45341,33,41292,2,8192,64,10588,16400,17664,23669,20564,41341,256,41340,16464,513]

theorem envBound42867 : H12AffineFastState.Bounded env42867 := by
  intro p hp
  have h : env42867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42866_42867 : H12AffineEnvironment.transform 15 29963 env42866 = env42867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env42866 == env42867) = true)

theorem identity42867 : scanCanonicalize (H12AffineFastState.compose env42867 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound42867 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env42868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,4112,29963,5392,10281,1024,4113,8461,33,12636,2,8192,64,10588,16400,17664,23669,20564,12653,256,12652,16464,513]

theorem envBound42868 : H12AffineFastState.Bounded env42868 := by
  intro p hp
  have h : env42868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42867_42868 : H12AffineEnvironment.transform 14 4112 env42867 = env42868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env42867 == env42868) = true)

theorem identity42868 : scanCanonicalize (H12AffineFastState.compose env42868 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound42868 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env42869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,16384,2048,27931,3328,10281,1024,2049,8461,33,10572,2,8192,64,10588,16400,17664,17509,18500,10621,256,10620,16464,513]

theorem envBound42869 : H12AffineFastState.Bounded env42869 := by
  intro p hp
  have h : env42869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42868_42869 : H12AffineEnvironment.transform 11 2064 env42868 = env42869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env42868 == env42869) = true)

theorem identity42869 : scanCanonicalize (H12AffineFastState.compose env42869 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound42869 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3148,16384,2048,16727,3328,1125,1024,2049,3393,33,1280,2,3148,64,1296,16400,17664,17509,18500,1329,256,1328,16464,513]

theorem envBound42870 : H12AffineFastState.Bounded env42870 := by
  intro p hp
  have h : env42870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42869_42870 : H12AffineEnvironment.transform 12 3148 env42869 = env42870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env42869 == env42870) = true)

theorem identity42870 : scanCanonicalize (H12AffineFastState.compose env42870 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound42870 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env42871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,64,1052,16384,80,16727,1360,1125,1024,81,1297,33,1280,2,1052,64,1296,16400,17664,17509,16404,1329,256,1328,16464,513]

theorem envBound42871 : H12AffineFastState.Bounded env42871 := by
  intro p hp
  have h : env42871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42870_42871 : H12AffineEnvironment.transform 10 80 env42870 = env42871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env42870 == env42871) = true)

theorem identity42871 : scanCanonicalize (H12AffineFastState.compose env42871 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42871 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42872 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,64,1052,16384,80,16498,1141,1125,1024,81,1076,33,1061,2,1052,64,1077,16400,17445,17509,16404,1044,37,1045,16464,513]

theorem envBound42872 : H12AffineFastState.Bounded env42872 := by
  intro p hp
  have h : env42872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42871_42872 : H12AffineEnvironment.transform 7 37 env42871 = env42872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42871 == env42872) = true)

theorem identity42872 : scanCanonicalize (H12AffineFastState.compose env42872 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound42872 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env42873 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,64,1052,80,80,34,1141,1125,1024,81,1076,33,1061,2,1052,64,1077,64,1141,1077,68,1044,37,1045,0,513]

theorem envBound42873 : H12AffineFastState.Bounded env42873 := by
  intro p hp
  have h : env42873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42872_42873 : H12AffineEnvironment.transform 13 80 env42872 = env42873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env42872 == env42873) = true)

theorem identity42873 : scanCanonicalize (H12AffineFastState.compose env42873 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound42873 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42874 : List Nat := [2,4,8,16,32,64,8,37,81,1024,80,64,1052,80,80,34,1141,1125,1024,81,1076,33,1061,2,1052,64,1077,64,1141,1077,68,1044,37,1045,0,80]

theorem envBound42874 : H12AffineFastState.Bounded env42874 := by
  intro p hp
  have h : env42874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42873_42874 : H12AffineEnvironment.transform 8 81 env42873 = env42874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env42873 == env42874) = true)

theorem identity42874 : scanCanonicalize (H12AffineFastState.compose env42874 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42875 : List Nat := [2,4,8,16,32,64,8,37,81,84,80,64,72,80,80,34,33,49,84,81,96,33,113,2,72,64,97,64,33,97,68,64,37,65,0,80]

theorem envBound42875 : H12AffineFastState.Bounded env42875 := by
  intro p hp
  have h : env42875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42874_42875 : H12AffineEnvironment.transform 9 84 env42874 = env42875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42874 == env42875) = true)

theorem identity42875 : scanCanonicalize (H12AffineFastState.compose env42875 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42875 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env42876 : List Nat := [2,4,8,16,32,1,8,37,16,21,17,1,9,17,17,34,33,49,21,16,33,33,48,2,9,1,32,1,33,32,5,1,37,0,0,17]

theorem envBound42876 : H12AffineFastState.Bounded env42876 := by
  intro p hp
  have h : env42876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42875_42876 : H12AffineEnvironment.transform 5 1 env42875 = env42876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42875 == env42876) = true)

theorem identity42876 : scanCanonicalize (H12AffineFastState.compose env42876 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42877 : List Nat := [2,4,8,0,32,1,8,37,0,5,1,1,9,1,1,34,33,33,5,0,33,33,32,2,9,1,32,1,33,32,5,1,37,0,0,1]

theorem envBound42877 : H12AffineFastState.Bounded env42877 := by
  intro p hp
  have h : env42877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42876_42877 : H12AffineEnvironment.transform 3 0 env42876 = env42877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42876 == env42877) = true)

def env42878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,119878,95497,8193,64,215367,79131,17664,463942,75102,392286,256,41341,16464,513]

theorem envBound42878 : H12AffineFastState.Bounded env42878 := by
  intro p hp
  have h : env42878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42856_42878 : H12AffineEnvironment.transform 6 9 env42856 = env42878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42856 == env42878) = true)

def env42879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115735,33,119878,95497,8193,64,215367,79131,17664,212078,75102,119926,256,41341,16464,513]

theorem envBound42879 : H12AffineFastState.Bounded env42879 := by
  intro p hp
  have h : env42879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42878_42879 : H12AffineEnvironment.transform 17 10280 env42878 = env42879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42878 == env42879) = true)

theorem identity42879 : scanCanonicalize (H12AffineFastState.compose env42879 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound42879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,4161,33,16,41311,8193,64,171281,57677,17664,190520,61704,32,256,41341,16464,513]

theorem envBound42880 : H12AffineFastState.Bounded env42880 := by
  intro p hp
  have h : env42880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42879_42880 : H12AffineEnvironment.transform 15 54358 env42879 = env42880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env42879 == env42880) = true)

theorem identity42880 : scanCanonicalize (H12AffineFastState.compose env42880 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound42880 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10280,1024,32769,4161,33,16,41311,8193,64,10588,57677,17664,23669,61704,32,256,41341,16464,513]

theorem envBound42881 : H12AffineFastState.Bounded env42881 := by
  intro p hp
  have h : env42881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42880_42881 : H12AffineEnvironment.transform 16 46157 env42880 = env42881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env42880 == env42881) = true)

theorem identity42881 : scanCanonicalize (H12AffineFastState.compose env42881 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound42881 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28699,4096,10280,1024,9292,4161,33,16,1298,8193,64,10588,17664,17664,23669,21829,32,256,1328,16464,513]

theorem envBound42882 : H12AffineFastState.Bounded env42882 := by
  intro p hp
  have h : env42882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42881_42882 : H12AffineEnvironment.transform 14 9293 env42881 = env42882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env42881 == env42882) = true)

theorem identity42882 : scanCanonicalize (H12AffineFastState.compose env42882 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound42882 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,8192,16384,9293,28699,4096,9529,1024,9292,4161,33,16,1298,8193,64,9293,17664,17664,20836,21829,32,256,1328,16464,513]

theorem envBound42883 : H12AffineFastState.Bounded env42883 := by
  intro p hp
  have h : env42883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42882_42883 : H12AffineEnvironment.transform 10 1297 env42882 = env42883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env42882 == env42883) = true)

theorem identity42883 : scanCanonicalize (H12AffineFastState.compose env42883 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound42883 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env42884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,1336,16384,373,21795,4096,1,1024,372,4161,33,16,1298,1337,64,373,17664,17664,20836,21829,32,256,1328,16464,513]

theorem envBound42884 : H12AffineFastState.Bounded env42884 := by
  intro p hp
  have h : env42884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42883_42884 : H12AffineEnvironment.transform 12 1336 env42883 = env42884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env42883 == env42884) = true)

theorem identity42884 : scanCanonicalize (H12AffineFastState.compose env42884 (packedSelected [0,11,14,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound42884 : packedSelected [0,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env42885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,1336,4452,373,1095,4096,1,1024,372,4161,33,16,1298,1337,64,373,5220,5220,0,1057,32,256,1328,4404,513]

theorem envBound42885 : H12AffineFastState.Bounded env42885 := by
  intro p hp
  have h : env42885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42884_42885 : H12AffineEnvironment.transform 13 4452 env42884 = env42885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env42884 == env42885) = true)

theorem identity42885 : scanCanonicalize (H12AffineFastState.compose env42885 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound42885 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,1336,1,373,1095,357,1,1024,372,292,33,16,1298,1337,64,373,1281,1281,0,1057,32,256,1328,81,513]

theorem envBound42886 : H12AffineFastState.Bounded env42886 := by
  intro p hp
  have h : env42886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42885_42886 : H12AffineEnvironment.transform 11 357 env42885 = env42886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env42885 == env42886) = true)

theorem identity42886 : scanCanonicalize (H12AffineFastState.compose env42886 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound42886 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42887 : List Nat := [2,4,8,16,32,64,9,256,512,320,81,357,120,1,373,263,357,1,320,372,292,33,16,82,121,64,373,65,65,0,353,32,256,112,81,513]

theorem envBound42887 : H12AffineFastState.Bounded env42887 := by
  intro p hp
  have h : env42887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42886_42887 : H12AffineEnvironment.transform 9 320 env42886 = env42887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42886 == env42887) = true)

theorem identity42887 : scanCanonicalize (H12AffineFastState.compose env42887 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound42887 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42888 : List Nat := [2,4,8,16,32,64,9,256,373,320,81,357,120,1,373,263,357,1,320,372,292,33,16,82,121,64,373,65,65,0,353,32,256,112,81,372]

theorem envBound42888 : H12AffineFastState.Bounded env42888 := by
  intro p hp
  have h : env42888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42887_42888 : H12AffineEnvironment.transform 8 373 env42887 = env42888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env42887 == env42888) = true)

def env42889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115735,32,119878,95497,8193,64,215367,79131,17664,212079,75102,119927,256,41341,16464,513]

theorem envBound42889 : H12AffineFastState.Bounded env42889 := by
  intro p hp
  have h : env42889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42878_42889 : H12AffineEnvironment.transform 17 10281 env42878 = env42889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42878 == env42889) = true)

theorem identity42889 : scanCanonicalize (H12AffineFastState.compose env42889 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound42889 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,91419,32,95562,95497,8193,64,215367,79131,17664,212079,75102,95611,256,113,16464,513]

theorem envBound42890 : H12AffineFastState.Bounded env42890 := by
  intro p hp
  have h : env42890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42889_42890 : H12AffineEnvironment.transform 14 8460 env42889 = env42890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env42889 == env42890) = true)

theorem identity42890 : scanCanonicalize (H12AffineFastState.compose env42890 (packedSelected [0,3,7,12,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound42890 : packedSelected [0,3,7,12,20,24] rootPS < 2^1333 := by decide +kernel

def env42891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,21511,131072,10281,1024,8461,12572,32,8525,8462,8193,64,138560,24860,17664,157800,29017,8572,256,113,16464,513]

theorem envBound42891 : H12AffineFastState.Bounded env42891 := by
  intro p hp
  have h : env42891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42890_42891 : H12AffineEnvironment.transform 15 21511 env42890 = env42891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env42890 == env42891) = true)

theorem identity42891 : scanCanonicalize (H12AffineFastState.compose env42891 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound42891 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env42892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,21511,13340,10281,1024,8461,12572,32,8525,8462,8193,64,10588,24860,17664,23668,29017,8572,256,113,16464,513]

theorem envBound42892 : H12AffineFastState.Bounded env42892 := by
  intro p hp
  have h : env42892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42891_42892 : H12AffineEnvironment.transform 16 13340 env42891 = env42892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env42891 == env42892) = true)

theorem identity42892 : scanCanonicalize (H12AffineFastState.compose env42892 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42892 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,21511,5392,2341,1024,1,4112,32,65,2,269,64,2128,16400,17664,23668,20565,112,256,113,16464,513]

theorem envBound42893 : H12AffineFastState.Bounded env42893 := by
  intro p hp
  have h : env42893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42892_42893 : H12AffineEnvironment.transform 12 268 env42892 = env42893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42892 == env42893) = true)

theorem identity42893 : scanCanonicalize (H12AffineFastState.compose env42893 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42893 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,0,343,5392,2341,1024,1,4112,32,65,2,269,64,2128,5440,4176,2340,1285,112,256,113,5376,513]

theorem envBound42894 : H12AffineFastState.Bounded env42894 := by
  intro p hp
  have h : env42894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42893_42894 : H12AffineEnvironment.transform 13 5456 env42893 = env42894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42893 == env42894) = true)

theorem identity42894 : scanCanonicalize (H12AffineFastState.compose env42894 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42894 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42895 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4160,0,343,4096,2341,272,1,4112,32,65,2,269,64,2128,4176,4176,2340,21,112,256,113,4112,513]

theorem envBound42895 : H12AffineFastState.Bounded env42895 := by
  intro p hp
  have h : env42895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42894_42895 : H12AffineEnvironment.transform 9 272 env42894 = env42895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42894 == env42895) = true)

theorem identity42895 : scanCanonicalize (H12AffineFastState.compose env42895 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42895 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42896 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4112,0,263,4096,2341,272,1,4112,32,17,2,269,16,2048,4096,4096,2340,21,32,256,33,4112,513]

theorem envBound42896 : H12AffineFastState.Bounded env42896 := by
  intro p hp
  have h : env42896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42895_42896 : H12AffineEnvironment.transform 5 16 env42895 = env42896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42895 == env42896) = true)

theorem identity42896 : scanCanonicalize (H12AffineFastState.compose env42896 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound42896 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42897 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,308,268,292,0,263,308,2341,272,1,292,32,17,2,269,16,2048,308,308,2340,21,32,256,33,292,513]

theorem envBound42897 : H12AffineFastState.Bounded env42897 := by
  intro p hp
  have h : env42897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42896_42897 : H12AffineEnvironment.transform 11 308 env42896 = env42897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env42896 == env42897) = true)

def env42898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,8388608,95497,8328,64,8560009,79131,8491471,8830976,8450328,392406,256,8484155,8492191,8509134]

theorem envBound42898 : H12AffineFastState.Bounded env42898 := by
  intro p hp
  have h : env42898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42854_42898 : H12AffineEnvironment.transform 21 272513 env42854 = env42898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42854 == env42898) = true)

theorem identity42898 : scanCanonicalize (H12AffineFastState.compose env42898 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound42898 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,272513,8388608,41430,8328,64,8560009,57796,8406288,8830976,8450328,272393,256,8430052,8405056,8389137]

theorem envBound42899 : H12AffineFastState.Bounded env42899 := by
  intro p hp
  have h : env42899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42898_42899 : H12AffineEnvironment.transform 15 54495 env42898 = env42899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env42898 == env42899) = true)

def env42900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272393,8388608,41310,8192,64,8559873,57676,8406288,8830976,8450328,272393,256,8429932,8405056,8389137]

theorem envBound42900 : H12AffineFastState.Bounded env42900 := by
  intro p hp
  have h : env42900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42899_42900 : H12AffineEnvironment.transform 6 8 env42899 = env42900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42899 == env42900) = true)

def env42901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272393,16,41310,8192,64,171281,57676,17664,442384,61704,272393,256,41340,16464,513]

theorem envBound42901 : H12AffineFastState.Bounded env42901 := by
  intro p hp
  have h : env42901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42900_42901 : H12AffineEnvironment.transform 22 16 env42900 = env42901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42900 == env42901) = true)

theorem identity42901 : scanCanonicalize (H12AffineFastState.compose env42901 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42901 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,262144,1024,8541,4161,272393,16,2,8192,64,146509,16400,17664,418124,20564,272393,256,32,16464,513]

theorem envBound42902 : H12AffineFastState.Bounded env42902 := by
  intro p hp
  have h : env42902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42901_42902 : H12AffineEnvironment.transform 14 8540 env42901 = env42902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42901 == env42902) = true)

theorem identity42902 : scanCanonicalize (H12AffineFastState.compose env42902 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42902 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42903 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,131072,262144,272,8541,4161,272393,16,2,8192,64,145757,16400,16400,418124,20564,272393,256,32,16464,513]

theorem envBound42903 : H12AffineFastState.Bounded env42903 := by
  intro p hp
  have h : env42903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42902_42903 : H12AffineEnvironment.transform 9 272 env42902 = env42903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42902 == env42903) = true)

theorem identity42903 : scanCanonicalize (H12AffineFastState.compose env42903 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound42903 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env42904 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,4096,262144,272,8541,4161,272393,16,2,8192,64,10589,16400,16400,291148,20564,272393,256,32,16464,513]

theorem envBound42904 : H12AffineFastState.Bounded env42904 := by
  intro p hp
  have h : env42904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42903_42904 : H12AffineEnvironment.transform 16 4096 env42903 = env42904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env42903 == env42904) = true)

theorem identity42904 : scanCanonicalize (H12AffineFastState.compose env42904 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42904 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env42905 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,4096,10280,272,8541,4161,33,16,2,8192,64,10589,16400,16400,22884,20564,33,256,32,16464,513]

theorem envBound42905 : H12AffineFastState.Bounded env42905 := by
  intro p hp
  have h : env42905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42904_42905 : H12AffineEnvironment.transform 17 10280 env42904 = env42905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42904 == env42905) = true)

theorem identity42905 : scanCanonicalize (H12AffineFastState.compose env42905 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound42905 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42906 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,8192,16384,8540,27007,2404,10280,272,8541,2341,33,16,2,8192,64,10589,16400,16400,16384,18736,33,256,32,16464,513]

theorem envBound42906 : H12AffineFastState.Bounded env42906 := by
  intro p hp
  have h : env42906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42905_42906 : H12AffineEnvironment.transform 11 2404 env42905 = env42906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env42905 == env42906) = true)

theorem identity42906 : scanCanonicalize (H12AffineFastState.compose env42906 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound42906 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env42907 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,8192,2048,8540,8575,2404,10280,272,8541,2341,33,16,2,8192,64,10589,2064,2064,2048,304,33,256,32,2128,513]

theorem envBound42907 : H12AffineFastState.Bounded env42907 := by
  intro p hp
  have h : env42907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42906_42907 : H12AffineEnvironment.transform 13 2048 env42906 = env42907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env42906 == env42907) = true)

theorem identity42907 : scanCanonicalize (H12AffineFastState.compose env42907 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42907 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env42908 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,41,2048,373,342,2404,2049,272,372,2341,33,16,2,41,64,2420,2064,2064,2048,304,33,256,32,2128,513]

theorem envBound42908 : H12AffineFastState.Bounded env42908 := by
  intro p hp
  have h : env42908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42907_42908 : H12AffineEnvironment.transform 12 41 env42907 = env42908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42907 == env42908) = true)

theorem identity42908 : scanCanonicalize (H12AffineFastState.compose env42908 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound42908 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42909 : List Nat := [2,4,8,16,32,64,8,256,512,272,97,261,41,97,373,342,261,96,272,372,324,33,16,2,41,64,277,113,113,97,304,33,256,32,49,513]

theorem envBound42909 : H12AffineFastState.Bounded env42909 := by
  intro p hp
  have h : env42909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42908_42909 : H12AffineEnvironment.transform 10 97 env42908 = env42909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env42908 == env42909) = true)

theorem identity42909 : scanCanonicalize (H12AffineFastState.compose env42909 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42909 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env42910 : List Nat := [2,4,8,16,0,64,8,256,512,272,65,261,9,65,341,342,261,64,272,340,324,1,16,2,9,64,277,81,81,65,272,1,256,0,17,513]

theorem envBound42910 : H12AffineFastState.Bounded env42910 := by
  intro p hp
  have h : env42910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42909_42910 : H12AffineEnvironment.transform 4 0 env42909 = env42910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42909 == env42910) = true)

theorem identity42910 : scanCanonicalize (H12AffineFastState.compose env42910 (packedSelected [1,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound42910 : packedSelected [1,5,7] rootPS < 2^1333 := by decide +kernel

def env42911 : List Nat := [2,4,8,16,0,64,8,85,512,69,65,80,9,65,0,3,80,64,69,1,17,1,16,2,9,64,64,81,81,65,69,1,85,0,17,513]

theorem envBound42911 : H12AffineFastState.Bounded env42911 := by
  intro p hp
  have h : env42911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42910_42911 : H12AffineEnvironment.transform 7 85 env42910 = env42911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env42910 == env42911) = true)

theorem identity42911 : scanCanonicalize (H12AffineFastState.compose env42911 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42911 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42912 : List Nat := [2,4,8,16,0,16,8,5,512,21,17,0,9,17,0,3,0,16,21,1,17,1,16,2,9,16,16,1,1,17,21,1,5,0,17,513]

theorem envBound42912 : H12AffineFastState.Bounded env42912 := by
  intro p hp
  have h : env42912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42911_42912 : H12AffineEnvironment.transform 5 16 env42911 = env42912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42911 == env42912) = true)

theorem identity42912 : scanCanonicalize (H12AffineFastState.compose env42912 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42913 : List Nat := [2,4,8,1,0,1,8,5,512,4,0,0,9,0,0,3,0,1,4,1,0,1,1,2,9,1,1,1,1,0,4,1,5,0,0,513]

theorem envBound42913 : H12AffineFastState.Bounded env42913 := by
  intro p hp
  have h : env42913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42912_42913 : H12AffineEnvironment.transform 3 1 env42912 = env42913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42912 == env42913) = true)

def env42914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272393,17,41310,8192,64,171280,57676,17665,442385,61705,272393,256,41341,16465,512]

theorem envBound42914 : H12AffineFastState.Bounded env42914 := by
  intro p hp
  have h : env42914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42900_42914 : H12AffineEnvironment.transform 22 17 env42900 = env42914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42900 == env42914) = true)

theorem identity42914 : scanCanonicalize (H12AffineFastState.compose env42914 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound42914 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56577,1024,32769,4161,62728,17,41310,8192,64,171280,57676,17665,138512,61705,62728,256,41341,16465,512]

theorem envBound42915 : H12AffineFastState.Bounded env42915 := by
  intro p hp
  have h : env42915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42914_42915 : H12AffineEnvironment.transform 17 56577 env42914 = env42915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env42914 == env42915) = true)

theorem identity42915 : scanCanonicalize (H12AffineFastState.compose env42915 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound42915 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32802,131072,35188,1024,32769,4161,41341,17,41310,8192,64,171280,46393,4468,138512,42364,41341,256,41341,5156,512]

theorem envBound42916 : H12AffineFastState.Bounded env42916 := by
  intro p hp
  have h : env42916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42915_42916 : H12AffineEnvironment.transform 13 5237 env42915 = env42916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env42915 == env42916) = true)

theorem identity42916 : scanCanonicalize (H12AffineFastState.compose env42916 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound42916 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env42917 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5237,32768,32802,131072,34849,1024,32769,4161,41000,17,40971,8192,64,171077,46188,4129,138309,42025,41000,85,41000,5156,512]

theorem envBound42917 : H12AffineFastState.Bounded env42917 := by
  intro p hp
  have h : env42917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42916_42917 : H12AffineEnvironment.transform 7 85 env42916 = env42917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env42916 == env42917) = true)

def env42918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272392,8388608,41311,8193,64,8559872,57677,8406288,8830976,8450328,272393,256,8429933,8405056,8389137]

theorem envBound42918 : H12AffineFastState.Bounded env42918 := by
  intro p hp
  have h : env42918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42899_42918 : H12AffineEnvironment.transform 6 9 env42899 = env42918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42899 == env42918) = true)

def env42919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272392,16,41311,8193,64,171280,57677,17664,442384,61704,272393,256,41341,16464,513]

theorem envBound42919 : H12AffineFastState.Bounded env42919 := by
  intro p hp
  have h : env42919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42918_42919 : H12AffineEnvironment.transform 22 16 env42918 = env42919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42918 == env42919) = true)

def env42920 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,272392,16,41231,8193,16,171280,57629,17664,442384,61704,272393,256,41261,16384,513]

theorem envBound42920 : H12AffineFastState.Bounded env42920 := by
  intro p hp
  have h : env42920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42919_42920 : H12AffineEnvironment.transform 5 16 env42919 = env42920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42919 == env42920) = true)

theorem identity42920 : scanCanonicalize (H12AffineFastState.compose env42920 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound42920 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env42921 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,262144,1024,29709,4113,272392,16,21763,8193,16,157980,5393,17664,406556,1284,272393,256,21793,16384,513]

theorem envBound42921 : H12AffineFastState.Bounded env42921 := by
  intro p hp
  have h : env42921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42920_42921 : H12AffineEnvironment.transform 14 29708 env42920 = env42921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env42920 == env42921) = true)

theorem identity42921 : scanCanonicalize (H12AffineFastState.compose env42921 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound42921 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42922 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,23588,1024,29709,4113,29740,16,21763,8193,16,157980,5393,17664,157752,1284,29741,256,21793,16384,513]

theorem envBound42922 : H12AffineFastState.Bounded env42922 := by
  intro p hp
  have h : env42922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42921_42922 : H12AffineEnvironment.transform 17 23588 env42921 = env42922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env42921 == env42922) = true)

theorem identity42922 : scanCanonicalize (H12AffineFastState.compose env42922 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42922 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env42923 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,16401,23588,1024,29709,4113,29740,16,21763,8193,16,10509,5393,17664,10281,1284,29741,256,21793,16384,513]

theorem envBound42923 : H12AffineFastState.Bounded env42923 := by
  intro p hp
  have h : env42923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42922_42923 : H12AffineEnvironment.transform 16 16401 env42922 = env42923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42922 == env42923) = true)

theorem identity42923 : scanCanonicalize (H12AffineFastState.compose env42923 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound42923 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env42924 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5157,8233,8202,5172,2049,1024,8232,4113,8201,16,294,8193,16,10509,5393,4389,10281,1284,8200,256,260,5157,513]

theorem envBound42924 : H12AffineFastState.Bounded env42924 := by
  intro p hp
  have h : env42924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42923_42924 : H12AffineEnvironment.transform 13 5157 env42923 = env42924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env42923 == env42924) = true)

theorem identity42924 : scanCanonicalize (H12AffineFastState.compose env42924 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42924 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42925 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,292,263,5172,2049,1024,293,4113,260,16,294,268,16,2048,5393,4389,2340,1284,261,256,260,5157,513]

theorem envBound42925 : H12AffineFastState.Bounded env42925 := by
  intro p hp
  have h : env42925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42924_42925 : H12AffineEnvironment.transform 12 269 env42924 = env42925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42924 == env42925) = true)

theorem identity42925 : scanCanonicalize (H12AffineFastState.compose env42925 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42925 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env42926 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5172,2049,1024,0,4113,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound42926 : H12AffineFastState.Bounded env42926 := by
  intro p hp
  have h : env42926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42925_42926 : H12AffineEnvironment.transform 7 37 env42925 = env42926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42925 == env42926) = true)

def env42927 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,1,34,1028,2049,1024,0,33,33,16,3,41,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound42927 : H12AffineFastState.Bounded env42927 := by
  intro p hp
  have h : env42927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42926_42927 : H12AffineEnvironment.transform 11 48 env42926 = env42927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42926 == env42927) = true)

theorem identity42927 : scanCanonicalize (H12AffineFastState.compose env42927 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42928 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,40,33,1,34,48,2049,52,0,33,33,16,3,41,16,2048,48,48,2049,21,32,37,33,33,513]

theorem envBound42928 : H12AffineFastState.Bounded env42928 := by
  intro p hp
  have h : env42928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42927_42928 : H12AffineEnvironment.transform 9 52 env42927 = env42928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42927 == env42928) = true)

theorem identity42928 : scanCanonicalize (H12AffineFastState.compose env42928 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42928 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42929 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,1,3,17,2049,21,0,0,0,16,3,8,16,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound42929 : H12AffineFastState.Bounded env42929 := by
  intro p hp
  have h : env42929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42928_42929 : H12AffineEnvironment.transform 4 1 env42928 = env42929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42928 == env42929) = true)

def leafEnv42929 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,1,3,17,2049,21,0,0,0,16,3,21,8,1,16,2048,17,17,2049,21,1,4,0,4,2,0,513,1,0,0]

def active42929 : List Nat := [0,1,2,3,8,10]

def tree42929 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42929 : H12WitnessSearch.Good tree42929 := H12GlobalWitnessIndex.good

theorem leafIdentity42929 : H12AffineFastState.composeSystem env42929 rootObs = leafEnv42929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42929 rootObs == leafEnv42929) = true)

theorem terminalChecked42929 : H12PackedTerminal.terminalCheckFast leafEnv42929 active42929 tree42929 = true := by decide +kernel

def env42930 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,1,34,1029,2049,1024,0,32,33,16,3,41,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound42930 : H12AffineFastState.Bounded env42930 := by
  intro p hp
  have h : env42930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42926_42930 : H12AffineEnvironment.transform 11 49 env42926 = env42930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42926 == env42930) = true)

def env42931 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,272392,16,41230,8193,17,171280,57628,17664,442384,61704,272393,256,41260,16385,513]

theorem envBound42931 : H12AffineFastState.Bounded env42931 := by
  intro p hp
  have h : env42931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42919_42931 : H12AffineEnvironment.transform 5 17 env42919 = env42931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42919 == env42931) = true)

theorem identity42931 : scanCanonicalize (H12AffineFastState.compose env42931 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound42931 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env42932 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,179512,1024,32769,4112,169264,16,41230,8193,17,171280,57628,17664,32040,61704,169265,256,41260,16385,513]

theorem envBound42932 : H12AffineFastState.Bounded env42932 := by
  intro p hp
  have h : env42932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42931_42932 : H12AffineEnvironment.transform 17 179512 env42931 = env42932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env42931 == env42932) = true)

theorem identity42932 : scanCanonicalize (H12AffineFastState.compose env42932 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound42932 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42933 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,38161,10281,1024,32769,4112,33,16,41230,8193,17,2049,57628,17664,32040,61704,32,256,41260,16385,513]

theorem envBound42933 : H12AffineFastState.Bounded env42933 := by
  intro p hp
  have h : env42933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42932_42933 : H12AffineEnvironment.transform 16 38161 env42932 = env42933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42932 == env42933) = true)

theorem identity42933 : scanCanonicalize (H12AffineFastState.compose env42933 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42933 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42934 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,54279,38161,2340,1024,32769,4112,33,16,32771,268,17,2049,49169,17664,23589,53253,32,256,32801,16385,513]

theorem envBound42934 : H12AffineFastState.Bounded env42934 := by
  intro p hp
  have h : env42934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42933_42934 : H12AffineEnvironment.transform 12 269 env42933 = env42934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42933 == env42934) = true)

theorem identity42934 : scanCanonicalize (H12AffineFastState.compose env42934 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42934 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42935 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,21511,5393,2340,1024,1,4112,33,16,3,268,17,2049,16401,17664,23589,20485,32,256,33,16385,513]

theorem envBound42935 : H12AffineFastState.Bounded env42935 := by
  intro p hp
  have h : env42935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42934_42935 : H12AffineEnvironment.transform 14 0 env42934 = env42935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42934 == env42935) = true)

theorem identity42935 : scanCanonicalize (H12AffineFastState.compose env42935 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42935 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42936 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1024,1,4112,33,16,3,268,17,2049,5392,4097,2340,1284,32,256,33,5376,513]

theorem envBound42936 : H12AffineFastState.Bounded env42936 := by
  intro p hp
  have h : env42936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42935_42936 : H12AffineEnvironment.transform 13 5377 env42935 = env42936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42935 == env42936) = true)

theorem identity42936 : scanCanonicalize (H12AffineFastState.compose env42936 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42937 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,4096,25,5141,0,18,5125,2096,1024,1,4112,33,16,3,24,17,2049,5124,4097,2096,1040,32,20,33,5140,513]

theorem envBound42937 : H12AffineFastState.Bounded env42937 := by
  intro p hp
  have h : env42937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42936_42937 : H12AffineEnvironment.transform 7 20 env42936 = env42937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42936 == env42937) = true)

theorem identity42937 : scanCanonicalize (H12AffineFastState.compose env42937 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound42937 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42938 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,1572,25,561,0,18,545,2096,1024,1,1588,33,16,3,24,17,2049,544,1573,2096,1040,32,20,33,560,513]

theorem envBound42938 : H12AffineFastState.Bounded env42938 := by
  intro p hp
  have h : env42938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42937_42938 : H12AffineEnvironment.transform 11 1572 env42937 = env42938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env42937 == env42938) = true)

theorem identity42938 : scanCanonicalize (H12AffineFastState.compose env42938 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42938 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42939 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,529,25,561,0,18,545,2096,53,1,513,33,16,3,24,17,2049,544,528,2096,37,32,20,33,560,513]

theorem envBound42939 : H12AffineFastState.Bounded env42939 := by
  intro p hp
  have h : env42939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42938_42939 : H12AffineEnvironment.transform 9 53 env42938 = env42939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42938 == env42939) = true)

theorem identity42939 : scanCanonicalize (H12AffineFastState.compose env42939 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42939 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42940 : List Nat := [2,4,8,16,0,17,9,20,512,21,2048,529,25,529,0,18,513,2064,21,1,513,1,16,3,24,17,2049,512,528,2064,5,0,20,1,528,513]

theorem envBound42940 : H12AffineFastState.Bounded env42940 := by
  intro p hp
  have h : env42940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42939_42940 : H12AffineEnvironment.transform 4 0 env42939 = env42940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42939 == env42940) = true)

theorem identity42940 : scanCanonicalize (H12AffineFastState.compose env42940 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound42940 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42941 : List Nat := [2,4,8,16,0,17,9,20,512,21,528,529,25,529,0,18,513,512,21,1,513,1,16,3,24,17,529,512,528,512,5,0,20,1,528,513]

theorem envBound42941 : H12AffineFastState.Bounded env42941 := by
  intro p hp
  have h : env42941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42940_42941 : H12AffineEnvironment.transform 10 528 env42940 = env42941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env42940 == env42941) = true)

def env42942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272392,17,41311,8193,64,171281,57677,17665,442385,61705,272393,256,41340,16465,512]

theorem envBound42942 : H12AffineFastState.Bounded env42942 := by
  intro p hp
  have h : env42942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42918_42942 : H12AffineEnvironment.transform 22 17 env42918 = env42942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42918 == env42942) = true)

theorem identity42942 : scanCanonicalize (H12AffineFastState.compose env42942 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound42942 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56577,1024,32769,4161,62729,17,41311,8193,64,171281,57677,17665,138512,61705,62728,256,41340,16465,512]

theorem envBound42943 : H12AffineFastState.Bounded env42943 := by
  intro p hp
  have h : env42943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42942_42943 : H12AffineEnvironment.transform 17 56577 env42942 = env42943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env42942 == env42943) = true)

theorem identity42943 : scanCanonicalize (H12AffineFastState.compose env42943 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound42943 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8574,131072,10281,1024,29993,4161,33,17,21623,8193,64,157753,5221,17665,138512,1057,32,256,21588,16465,512]

theorem envBound42944 : H12AffineFastState.Bounded env42944 := by
  intro p hp
  have h : env42944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42943_42944 : H12AffineEnvironment.transform 14 29992 env42943 = env42944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env42943 == env42944) = true)

theorem identity42944 : scanCanonicalize (H12AffineFastState.compose env42944 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound42944 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8574,5393,10281,1024,29993,4161,33,17,21623,8193,64,32040,5221,17665,2049,1057,32,256,21588,16465,512]

theorem envBound42945 : H12AffineFastState.Bounded env42945 := by
  intro p hp
  have h : env42945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42944_42945 : H12AffineEnvironment.transform 16 5393 env42944 = env42945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env42944 == env42945) = true)

theorem identity42945 : scanCanonicalize (H12AffineFastState.compose env42945 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound42945 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,16384,23808,2390,5393,1,1024,23809,4161,33,17,21623,2089,64,21760,5221,17665,2049,1057,32,256,21588,16465,512]

theorem envBound42946 : H12AffineFastState.Bounded env42946 := by
  intro p hp
  have h : env42946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42945_42946 : H12AffineEnvironment.transform 12 2088 env42945 = env42946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env42945 == env42946) = true)

theorem identity42946 : scanCanonicalize (H12AffineFastState.compose env42946 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 3376) := by decide +kernel

theorem selectedBound42946 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env42947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,3376,4144,2390,5393,1,1024,4145,4161,33,17,6471,2089,64,6192,5221,2097,2049,1057,32,256,6500,3425,512]

theorem envBound42947 : H12AffineFastState.Bounded env42947 := by
  intro p hp
  have h : env42947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42946_42947 : H12AffineEnvironment.transform 13 3376 env42946 = env42947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3376 env42946 == env42947) = true)

theorem identity42947 : scanCanonicalize (H12AffineFastState.compose env42947 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound42947 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,2088,3376,3376,2390,2065,1,1024,3377,3393,33,17,1095,2089,64,1328,2405,2097,2049,1057,32,256,1124,3425,512]

theorem envBound42948 : H12AffineFastState.Bounded env42948 := by
  intro p hp
  have h : env42948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42947_42948 : H12AffineEnvironment.transform 11 3328 env42947 = env42948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env42947 == env42948) = true)

theorem identity42948 : scanCanonicalize (H12AffineFastState.compose env42948 (packedSelected [0,1,2,6,7,8,10,14,15,23] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound42948 : packedSelected [0,1,2,6,7,8,10,14,15,23] rootPS < 2^1333 := by decide +kernel

def env42949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,32,1312,8,1296,1296,374,49,1,1024,1297,1377,33,17,1095,9,64,1328,325,17,33,1057,32,256,1124,1345,512]

theorem envBound42949 : H12AffineFastState.Bounded env42949 := by
  intro p hp
  have h : env42949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42948_42949 : H12AffineEnvironment.transform 10 32 env42948 = env42949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env42948 == env42949) = true)

theorem identity42949 : scanCanonicalize (H12AffineFastState.compose env42949 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42949 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env42950 : List Nat := [2,4,8,16,32,64,9,117,512,1024,32,1109,8,1125,1125,3,49,1,1024,1124,1044,33,17,1095,9,64,1093,48,17,33,1057,32,117,1124,1076,512]

theorem envBound42950 : H12AffineFastState.Bounded env42950 := by
  intro p hp
  have h : env42950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42949_42950 : H12AffineEnvironment.transform 7 117 env42949 = env42950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42949 == env42950) = true)

theorem identity42950 : scanCanonicalize (H12AffineFastState.compose env42950 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound42950 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42951 : List Nat := [2,4,8,16,32,64,9,117,512,548,32,625,8,577,577,3,49,1,548,576,560,33,17,611,9,64,609,48,17,33,517,32,117,576,528,512]

theorem envBound42951 : H12AffineFastState.Bounded env42951 := by
  intro p hp
  have h : env42951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42950_42951 : H12AffineEnvironment.transform 9 548 env42950 = env42951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env42950 == env42951) = true)

theorem identity42951 : scanCanonicalize (H12AffineFastState.compose env42951 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42951 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env42952 : List Nat := [2,4,8,0,32,64,9,101,512,548,32,609,8,577,577,3,33,1,548,576,544,33,1,611,9,64,609,32,1,33,517,32,101,576,512,512]

theorem envBound42952 : H12AffineFastState.Bounded env42952 := by
  intro p hp
  have h : env42952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42951_42952 : H12AffineEnvironment.transform 3 0 env42951 = env42952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42951 == env42952) = true)

def env42953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound42953 : H12AffineFastState.Bounded env42953 := by
  intro p hp
  have h : env42953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42741_42953 : H12AffineEnvironment.transform 18 1025 env42741 = env42953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42741 == env42953) = true)

theorem identity42953 : scanCanonicalize (H12AffineFastState.compose env42953 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626078) := by decide +kernel

theorem selectedBound42953 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626078,8328,64,6677534,8626323,10507601,8830977,2334735,12796382,257,254131,196886,2263000]

theorem envBound42954 : H12AffineFastState.Bounded env42954 := by
  intro p hp
  have h : env42954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42953_42954 : H12AffineEnvironment.transform 23 10626078 env42953 = env42954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626078 env42953 == env42954) = true)

def env42955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155996,2114882,8328,64,6677534,115151,2241549,303453,2334735,4268162,257,254131,196886,2263000]

theorem envBound42955 : H12AffineFastState.Bounded env42955 := by
  intro p hp
  have h : env42955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42954_42955 : H12AffineEnvironment.transform 22 155996 env42954 = env42955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155996 env42954 == env42955) = true)

def env42956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155996,2114882,8328,64,215366,115151,2241549,303453,2334735,2592218,257,254131,196886,2263000]

theorem envBound42956 : H12AffineFastState.Bounded env42956 := by
  intro p hp
  have h : env42956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42955_42956 : H12AffineEnvironment.transform 21 2534744 env42955 = env42956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env42955 == env42956) = true)

def env42957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,21762,8328,64,215366,115151,140365,303453,241743,499098,257,254131,196886,169880]

theorem envBound42957 : H12AffineFastState.Bounded env42957 := by
  intro p hp
  have h : env42957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42956_42957 : H12AffineEnvironment.transform 20 4160 env42956 = env42957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42956 == env42957) = true)

theorem identity42957 : scanCanonicalize (H12AffineFastState.compose env42957 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound42957 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,4160,329867,120015,21762,8328,64,64725,115151,102878,303453,1500,272393,257,21792,46213,74251]

theorem envBound42958 : H12AffineFastState.Bounded env42958 := by
  intro p hp
  have h : env42958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42957_42958 : H12AffineEnvironment.transform 16 112019 env42957 = env42958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env42957 == env42958) = true)

def env42959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10400,1025,32769,4160,73771,120015,21762,8328,64,64725,115151,102878,35325,1500,169,257,21792,46213,74251]

theorem envBound42959 : H12AffineFastState.Bounded env42959 := by
  intro p hp
  have h : env42959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42958_42959 : H12AffineEnvironment.transform 17 10400 env42958 = env42959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env42958 == env42959) = true)

theorem identity42959 : scanCanonicalize (H12AffineFastState.compose env42959 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42959 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,10400,1025,32769,4160,33,62661,21762,8328,64,64725,57797,45524,35325,1500,169,257,21792,46213,513]

theorem envBound42960 : H12AffineFastState.Bounded env42960 := by
  intro p hp
  have h : env42960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42959_42960 : H12AffineEnvironment.transform 15 8202 env42959 = env42960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42959 == env42960) = true)

theorem identity42960 : scanCanonicalize (H12AffineFastState.compose env42960 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound42960 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8202,16401,10400,1025,21897,4160,33,8525,21762,8328,64,10589,13389,25692,23669,1500,169,257,21792,24845,513]

theorem envBound42961 : H12AffineFastState.Bounded env42961 := by
  intro p hp
  have h : env42961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42960_42961 : H12AffineEnvironment.transform 14 21896 env42960 = env42961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env42960 == env42961) = true)

theorem identity42961 : scanCanonicalize (H12AffineFastState.compose env42961 (packedSelected [0,2,5,6,7,10,12,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 3324) := by decide +kernel

theorem selectedBound42961 : packedSelected [0,2,5,6,7,10,12,14,23,24] rootPS < 2^1333 := by decide +kernel

def env42962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,8192,16384,18804,8202,16401,10400,1025,18805,3260,33,8525,18942,8328,64,10589,10417,25692,16521,1500,169,257,18908,24845,513]

theorem envBound42962 : H12AffineFastState.Bounded env42962 := by
  intro p hp
  have h : env42962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42961_42962 : H12AffineEnvironment.transform 11 3324 env42961 = env42962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3324 env42961 == env42962) = true)

theorem identity42962 : scanCanonicalize (H12AffineFastState.compose env42962 (packedSelected [0,2,6,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3269) := by decide +kernel

theorem selectedBound42962 : packedSelected [0,2,6,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,3269,16384,18804,3279,16401,1125,1025,18805,3260,33,3464,18942,3149,64,1432,1140,18585,16521,1500,169,257,18908,19912,513]

theorem envBound42963 : H12AffineFastState.Bounded env42963 := by
  intro p hp
  have h : env42963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42962_42963 : H12AffineEnvironment.transform 12 3269 env42962 = env42963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3269 env42962 == env42963) = true)

theorem identity42963 : scanCanonicalize (H12AffineFastState.compose env42963 (packedSelected [0,3,5,10,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 3308) := by decide +kernel

theorem selectedBound42963 : packedSelected [0,3,5,10,14,27] rootPS < 2^1333 := by decide +kernel

def env42964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,3269,3308,1432,3279,3325,1125,1025,1433,3260,33,3464,1298,3149,64,1432,1140,1141,3173,1500,169,257,1328,292,513]

theorem envBound42964 : H12AffineFastState.Bounded env42964 := by
  intro p hp
  have h : env42964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42963_42964 : H12AffineEnvironment.transform 13 3308 env42963 = env42964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3308 env42963 == env42964) = true)

theorem identity42964 : scanCanonicalize (H12AffineFastState.compose env42964 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42964 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env42965 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3324,3269,3308,1261,3279,3325,1125,1025,1260,3260,33,3325,1127,3149,64,1261,1140,1141,3173,1193,169,116,1093,81,513]

theorem envBound42965 : H12AffineFastState.Bounded env42965 := by
  intro p hp
  have h : env42965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42964_42965 : H12AffineEnvironment.transform 7 117 env42964 = env42965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42964 == env42965) = true)

theorem identity42965 : scanCanonicalize (H12AffineFastState.compose env42965 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound42965 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42966 : List Nat := [2,4,8,16,32,64,128,117,512,236,2048,2064,2089,2048,1,2083,2065,137,237,0,2128,33,2065,139,2209,64,1,152,153,2185,69,169,116,169,81,513]

theorem envBound42966 : H12AffineFastState.Bounded env42966 := by
  intro p hp
  have h : env42966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42965_42966 : H12AffineEnvironment.transform 9 236 env42965 = env42966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env42965 == env42966) = true)

theorem identity42966 : scanCanonicalize (H12AffineFastState.compose env42966 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42966 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42967 : List Nat := [2,4,8,16,32,64,128,117,512,236,1,17,40,1,1,34,16,137,237,0,81,33,16,139,160,64,1,152,153,136,69,169,116,169,81,513]

theorem envBound42967 : H12AffineFastState.Bounded env42967 := by
  intro p hp
  have h : env42967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42966_42967 : H12AffineEnvironment.transform 10 1 env42966 = env42967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42966 == env42967) = true)

theorem identity42967 : scanCanonicalize (H12AffineFastState.compose env42967 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound42967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42968 : List Nat := [2,4,8,16,32,64,72,117,512,36,1,17,40,1,1,34,16,65,37,0,81,33,16,67,104,64,1,80,81,64,69,97,116,97,81,513]

theorem envBound42968 : H12AffineFastState.Bounded env42968 := by
  intro p hp
  have h : env42968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42967_42968 : H12AffineEnvironment.transform 6 72 env42967 = env42968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env42967 == env42968) = true)

theorem identity42968 : scanCanonicalize (H12AffineFastState.compose env42968 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42969 : List Nat := [2,4,8,16,1,64,72,84,512,5,1,17,9,1,1,3,16,65,4,0,81,0,16,67,73,64,1,80,81,64,69,64,85,64,81,513]

theorem envBound42969 : H12AffineFastState.Bounded env42969 := by
  intro p hp
  have h : env42969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42968_42969 : H12AffineEnvironment.transform 4 1 env42968 = env42969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42968 == env42969) = true)

theorem identity42969 : scanCanonicalize (H12AffineFastState.compose env42969 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42969 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42970 : List Nat := [2,4,8,16,1,64,72,84,64,5,1,17,9,1,1,3,16,65,4,0,81,0,16,67,73,64,1,80,81,64,69,64,85,64,81,65]

theorem envBound42970 : H12AffineFastState.Bounded env42970 := by
  intro p hp
  have h : env42970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42969_42970 : H12AffineEnvironment.transform 8 64 env42969 = env42970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42969 == env42970) = true)

theorem identity42970 : scanCanonicalize (H12AffineFastState.compose env42970 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42970 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env42971 : List Nat := [2,4,8,16,1,16,24,4,16,5,1,17,9,1,1,3,16,17,4,0,1,0,16,19,25,16,1,0,1,16,21,16,5,16,1,17]

theorem envBound42971 : H12AffineFastState.Bounded env42971 := by
  intro p hp
  have h : env42971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42970_42971 : H12AffineEnvironment.transform 5 16 env42970 = env42971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42970 == env42971) = true)

theorem identity42971 : scanCanonicalize (H12AffineFastState.compose env42971 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42971 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42972 : List Nat := [2,4,8,0,1,0,8,4,0,5,1,1,9,1,1,3,0,1,4,0,1,0,0,3,9,0,1,0,1,0,5,0,5,0,1,1]

theorem envBound42972 : H12AffineFastState.Bounded env42972 := by
  intro p hp
  have h : env42972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42971_42972 : H12AffineEnvironment.transform 3 0 env42971 = env42972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42971 == env42972) = true)

def env42973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10401,1025,32769,4160,73770,120015,21762,8328,64,64725,115151,102878,35324,1500,168,257,21792,46213,74251]

theorem envBound42973 : H12AffineFastState.Bounded env42973 := by
  intro p hp
  have h : env42973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42958_42973 : H12AffineEnvironment.transform 17 10401 env42958 = env42973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env42958 == env42973) = true)

theorem identity42973 : scanCanonicalize (H12AffineFastState.compose env42973 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound42973 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,65536,90138,10401,1025,21896,4160,73770,65862,21762,8328,64,10588,70726,83031,23669,1500,168,257,21792,24844,74251]

theorem envBound42974 : H12AffineFastState.Bounded env42974 := by
  intro p hp
  have h : env42974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42973_42974 : H12AffineEnvironment.transform 14 21897 env42973 = env42974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env42973 == env42974) = true)

theorem identity42974 : scanCanonicalize (H12AffineFastState.compose env42974 (packedSelected [0,1,2,6,8,12,14,19,23,27,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42974 : packedSelected [0,1,2,6,8,12,14,19,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env42975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,65536,82247,2556,1025,21896,4160,65911,65862,21762,469,64,2049,70726,83031,23669,1500,168,257,21792,16465,66390]

theorem envBound42975 : H12AffineFastState.Bounded env42975 := by
  intro p hp
  have h : env42975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42974_42975 : H12AffineEnvironment.transform 12 349 env42974 = env42975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42974 == env42975) = true)

theorem identity42975 : scanCanonicalize (H12AffineFastState.compose env42975 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound42975 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,262,16449,2556,1025,21896,4160,113,64,21762,469,64,2049,5440,17745,23669,1500,168,257,21792,16465,592]

theorem envBound42976 : H12AffineFastState.Bounded env42976 := by
  intro p hp
  have h : env42976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42975_42976 : H12AffineEnvironment.transform 15 262 env42975 = env42976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env42975 == env42976) = true)

theorem identity42976 : scanCanonicalize (H12AffineFastState.compose env42976 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42976 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env42977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,262,5441,2556,1025,136,4160,113,64,2,469,64,2049,5440,4177,2421,1500,168,257,32,5457,592]

theorem envBound42977 : H12AffineFastState.Bounded env42977 := by
  intro p hp
  have h : env42977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42976_42977 : H12AffineEnvironment.transform 13 5376 env42976 = env42977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42976 == env42977) = true)

theorem identity42977 : scanCanonicalize (H12AffineFastState.compose env42977 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound42977 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42978 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,137,250,5309,2048,1025,136,4160,113,64,2,41,64,2049,5308,4177,2185,1056,168,253,32,5293,592]

theorem envBound42978 : H12AffineFastState.Bounded env42978 := by
  intro p hp
  have h : env42978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42977_42978 : H12AffineEnvironment.transform 7 252 env42977 = env42978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env42977 == env42978) = true)

theorem identity42978 : scanCanonicalize (H12AffineFastState.compose env42978 (packedSelected [0,1,3,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound42978 : packedSelected [0,1,3,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42979 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,184,161,1092,137,250,1029,2048,1025,136,248,113,64,2,41,64,2049,1028,233,2185,1056,168,253,32,1045,592]

theorem envBound42979 : H12AffineFastState.Bounded env42979 := by
  intro p hp
  have h : env42979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42978_42979 : H12AffineEnvironment.transform 11 184 env42978 = env42979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env42978 == env42979) = true)

theorem identity42979 : scanCanonicalize (H12AffineFastState.compose env42979 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound42979 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42980 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1092,184,161,1092,137,250,1029,1092,1025,136,248,113,64,2,41,64,1093,1028,233,1229,1056,168,253,32,1045,592]

theorem envBound42980 : H12AffineFastState.Bounded env42980 := by
  intro p hp
  have h : env42980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42979_42980 : H12AffineEnvironment.transform 10 1092 env42979 = env42980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env42979 == env42980) = true)

theorem identity42980 : scanCanonicalize (H12AffineFastState.compose env42980 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound42980 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env42981 : List Nat := [2,4,8,16,32,64,128,252,512,237,169,184,161,169,137,250,232,169,236,136,248,113,64,2,41,64,168,233,233,32,205,168,253,32,248,592]

theorem envBound42981 : H12AffineFastState.Bounded env42981 := by
  intro p hp
  have h : env42981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42980_42981 : H12AffineEnvironment.transform 9 237 env42980 = env42981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env42980 == env42981) = true)

theorem identity42981 : scanCanonicalize (H12AffineFastState.compose env42981 (packedSelected [4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound42981 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env42982 : List Nat := [2,4,8,16,32,64,89,37,512,52,112,97,120,112,80,35,49,112,53,81,33,113,64,2,41,64,113,48,48,32,20,113,36,32,33,592]

theorem envBound42982 : H12AffineFastState.Bounded env42982 := by
  intro p hp
  have h : env42982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42981_42982 : H12AffineEnvironment.transform 6 89 env42981 = env42982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env42981 == env42982) = true)

theorem identity42982 : scanCanonicalize (H12AffineFastState.compose env42982 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound42982 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42983 : List Nat := [2,4,8,16,32,48,41,37,512,52,0,17,8,0,32,35,49,0,53,33,33,1,48,2,41,48,1,48,48,32,20,1,36,32,33,544]

theorem envBound42983 : H12AffineFastState.Bounded env42983 := by
  intro p hp
  have h : env42983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42982_42983 : H12AffineEnvironment.transform 5 48 env42982 = env42983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env42982 == env42983) = true)

theorem identity42983 : scanCanonicalize (H12AffineFastState.compose env42983 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42983 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42984 : List Nat := [2,4,8,16,0,16,9,5,512,20,0,17,8,0,0,3,17,0,21,1,1,1,16,2,9,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound42984 : H12AffineFastState.Bounded env42984 := by
  intro p hp
  have h : env42984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42983_42984 : H12AffineEnvironment.transform 4 0 env42983 = env42984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42983 == env42984) = true)

theorem identity42984 : scanCanonicalize (H12AffineFastState.compose env42984 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound42984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42985 : List Nat := [2,4,8,16,0,16,9,5,14,20,0,17,8,0,0,3,17,0,21,1,1,1,16,2,9,16,1,16,16,0,20,1,4,0,1,14]

theorem envBound42985 : H12AffineFastState.Bounded env42985 := by
  intro p hp
  have h : env42985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42984_42985 : H12AffineEnvironment.transform 8 14 env42984 = env42985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env42984 == env42985) = true)

def env42986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,21763,8328,64,215366,115151,140364,303453,241742,499099,257,254131,196886,169881]

theorem envBound42986 : H12AffineFastState.Bounded env42986 := by
  intro p hp
  have h : env42986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42956_42986 : H12AffineEnvironment.transform 20 4161 env42956 = env42986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42956 == env42986) = true)

theorem identity42986 : scanCanonicalize (H12AffineFastState.compose env42986 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42986 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,441625,155996,21763,8328,64,158028,57797,140364,303453,168004,441745,257,180409,139548,169881]

theorem envBound42987 : H12AffineFastState.Bounded env42987 := by
  intro p hp
  have h : env42987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42986_42987 : H12AffineEnvironment.transform 15 8202 env42986 = env42987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42986 == env42987) = true)

theorem identity42987 : scanCanonicalize (H12AffineFastState.compose env42987 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound42987 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,4161,272513,62660,21763,8328,64,64724,57797,45524,303453,1500,272393,257,21793,46212,513]

theorem envBound42988 : H12AffineFastState.Bounded env42988 := by
  intro p hp
  have h : env42988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42987_42988 : H12AffineEnvironment.transform 16 38296 env42987 = env42988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env42987 == env42988) = true)

theorem identity42988 : scanCanonicalize (H12AffineFastState.compose env42988 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound42988 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,64809,1025,32769,4161,54696,62660,21763,8328,64,64724,57797,45524,23668,1500,54560,257,21793,46212,513]

theorem envBound42989 : H12AffineFastState.Bounded env42989 := by
  intro p hp
  have h : env42989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42988_42989 : H12AffineEnvironment.transform 17 64809 env42988 = env42989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env42988 == env42989) = true)

theorem identity42989 : scanCanonicalize (H12AffineFastState.compose env42989 (packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound42989 : packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS < 2^1333 := by decide +kernel

def env42990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,24981,2340,1025,29708,4161,8613,201,21763,8328,64,2265,5576,17881,23668,1500,8493,257,21793,16521,513]

theorem envBound42990 : H12AffineFastState.Bounded env42990 := by
  intro p hp
  have h : env42990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42989_42990 : H12AffineEnvironment.transform 14 29709 env42989 = env42990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env42989 == env42990) = true)

theorem identity42990 : scanCanonicalize (H12AffineFastState.compose env42990 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound42990 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env42991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21976,479,16448,2340,1025,21977,4161,112,201,21763,349,64,2265,5576,17881,23668,1500,248,257,21793,16521,513]

theorem envBound42991 : H12AffineFastState.Bounded env42991 := by
  intro p hp
  have h : env42991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42990_42991 : H12AffineEnvironment.transform 12 469 env42990 = env42991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env42990 == env42991) = true)

def env42992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155996,2114882,8328,64,215367,115151,2241549,303453,2334735,2592219,257,254131,196886,2263000]

theorem envBound42992 : H12AffineFastState.Bounded env42992 := by
  intro p hp
  have h : env42992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42955_42992 : H12AffineEnvironment.transform 21 2534745 env42955 = env42992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env42955 == env42992) = true)

def env42993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,21762,8328,64,215367,115151,140365,303453,241743,499099,257,254131,196886,169880]

theorem envBound42993 : H12AffineFastState.Bounded env42993 := by
  intro p hp
  have h : env42993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42992_42993 : H12AffineEnvironment.transform 20 4160 env42992 = env42993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42992 == env42993) = true)

theorem identity42993 : scanCanonicalize (H12AffineFastState.compose env42993 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound42993 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,441625,155996,21762,8328,64,171417,5393,140365,303453,156817,411973,257,144493,185800,169880]

theorem envBound42994 : H12AffineFastState.Bounded env42994 := by
  intro p hp
  have h : env42994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42993_42994 : H12AffineEnvironment.transform 15 54494 env42993 = env42994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env42993 == env42994) = true)

def env42995 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441625,155916,21762,8328,16,171417,5393,140317,303373,156817,411925,257,144445,185752,169880]

theorem envBound42995 : H12AffineFastState.Bounded env42995 := by
  intro p hp
  have h : env42995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42994_42995 : H12AffineEnvironment.transform 5 16 env42994 = env42995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42994 == env42995) = true)

theorem identity42995 : scanCanonicalize (H12AffineFastState.compose env42995 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound42995 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42996 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,146744,1025,32769,4112,32801,155916,21762,8328,16,171417,5393,140317,171061,156817,29741,257,144445,185752,169880]

theorem envBound42996 : H12AffineFastState.Bounded env42996 := by
  intro p hp
  have h : env42996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42995_42996 : H12AffineEnvironment.transform 17 146744 env42995 = env42996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env42995 == env42996) = true)

theorem identity42996 : scanCanonicalize (H12AffineFastState.compose env42996 (packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42996 : packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42997 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,398,131072,146744,1025,21761,4112,21793,155916,21762,8328,16,149657,5393,140317,149813,156817,29741,257,144445,131224,148120]

theorem envBound42997 : H12AffineFastState.Bounded env42997 := by
  intro p hp
  have h : env42997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42996_42997 : H12AffineEnvironment.transform 14 21760 env42996 = env42997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42996 == env42997) = true)

theorem identity42997 : scanCanonicalize (H12AffineFastState.compose env42997 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound42997 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,398,24981,23725,1025,21761,4112,21793,153,21762,8328,16,10508,5393,17800,10400,1284,29741,257,21928,24845,8973]

theorem envBound42998 : H12AffineFastState.Bounded env42998 := by
  intro p hp
  have h : env42998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42997_42998 : H12AffineEnvironment.transform 16 24981 env42997 = env42998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env42997 == env42998) = true)

theorem identity42998 : scanCanonicalize (H12AffineFastState.compose env42998 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound42998 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,8580,398,5393,10281,1025,8581,4112,8613,153,8582,8328,16,10508,5393,12556,10400,1284,169,257,8492,5513,8973]

theorem envBound42999 : H12AffineFastState.Bounded env42999 := by
  intro p hp
  have h : env42999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42998_42999 : H12AffineEnvironment.transform 13 13444 env42998 = env42999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env42998 == env42999) = true)

theorem identity42999 : scanCanonicalize (H12AffineFastState.compose env42999 (packedSelected [0,1,3,5,7,8,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound42999 : packedSelected [0,1,3,5,7,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env43000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,8192,10629,8580,398,2064,10281,1025,8581,3345,8613,153,8582,8328,16,10508,2064,11277,10400,1284,169,257,8492,2184,8973]

theorem envBound43000 : H12AffineFastState.Bounded env43000 := by
  intro p hp
  have h : env43000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42999_43000 : H12AffineEnvironment.transform 11 3329 env42999 = env43000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env42999 == env43000) = true)

theorem identity43000 : scanCanonicalize (H12AffineFastState.compose env43000 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound43000 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env43001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,388,2049,0,398,2064,2477,1025,1,3345,33,153,2,268,16,2184,2064,3465,2340,1284,169,257,168,2184,649]

theorem envBound43001 : H12AffineFastState.Bounded env43001 := by
  intro p hp
  have h : env43001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43000_43001 : H12AffineEnvironment.transform 12 388 env43000 = env43001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env43000 == env43001) = true)

theorem identity43001 : scanCanonicalize (H12AffineFastState.compose env43001 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound43001 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43002 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,3329,301,2049,0,295,2064,2308,1025,1,3345,33,48,2,268,16,2081,2064,3360,2340,1284,0,257,1,2081,544]

theorem envBound43002 : H12AffineFastState.Bounded env43002 := by
  intro p hp
  have h : env43002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43001_43002 : H12AffineEnvironment.transform 6 41 env43001 = env43002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env43001 == env43002) = true)

theorem identity43002 : scanCanonicalize (H12AffineFastState.compose env43002 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43003 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3329,268,2049,0,262,2064,2308,1025,1,3345,0,17,2,268,16,2048,2064,3329,2309,1284,0,257,1,2048,513]

theorem envBound43003 : H12AffineFastState.Bounded env43003 := by
  intro p hp
  have h : env43003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43002_43003 : H12AffineEnvironment.transform 4 1 env43002 = env43003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43002 == env43003) = true)

theorem identity43003 : scanCanonicalize (H12AffineFastState.compose env43003 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound43003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43004 : List Nat := [2,4,8,16,1,16,8,256,512,1024,261,1028,268,260,0,262,277,1,1025,1,1044,0,17,2,268,16,261,277,1028,0,1284,0,257,1,261,513]

theorem envBound43004 : H12AffineFastState.Bounded env43004 := by
  intro p hp
  have h : env43004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43003_43004 : H12AffineEnvironment.transform 10 261 env43003 = env43004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env43003 == env43004) = true)

theorem identity43004 : scanCanonicalize (H12AffineFastState.compose env43004 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43004 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43005 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,276,268,260,0,262,277,1,273,1,260,0,17,2,268,16,261,277,276,0,20,0,257,1,261,513]

theorem envBound43005 : H12AffineFastState.Bounded env43005 := by
  intro p hp
  have h : env43005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43004_43005 : H12AffineEnvironment.transform 9 272 env43004 = env43005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43004 == env43005) = true)

theorem identity43005 : scanCanonicalize (H12AffineFastState.compose env43005 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43005 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43006 : List Nat := [2,4,8,16,1,16,8,256,0,272,261,276,268,260,0,262,277,1,273,1,260,0,17,2,268,16,261,277,276,0,20,0,257,1,261,1]

theorem envBound43006 : H12AffineFastState.Bounded env43006 := by
  intro p hp
  have h : env43006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43005_43006 : H12AffineEnvironment.transform 8 0 env43005 = env43006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43005 == env43006) = true)

theorem identity43006 : scanCanonicalize (H12AffineFastState.compose env43006 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43006 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43007 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,16,8,0,0,2,17,1,21,1,0,0,17,2,8,16,1,17,16,0,20,0,5,1,1,1]

theorem envBound43007 : H12AffineFastState.Bounded env43007 := by
  intro p hp
  have h : env43007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43006_43007 : H12AffineEnvironment.transform 7 4 env43006 = env43007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43006 == env43007) = true)

theorem identity43007 : scanCanonicalize (H12AffineFastState.compose env43007 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43007 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43008 : List Nat := [2,4,3,16,1,16,3,4,0,20,1,16,3,0,0,2,17,1,21,1,0,0,17,2,3,16,1,17,16,0,20,0,5,1,1,1]

theorem envBound43008 : H12AffineFastState.Bounded env43008 := by
  intro p hp
  have h : env43008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43007_43008 : H12AffineEnvironment.transform 2 3 env43007 = env43008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43007 == env43008) = true)

theorem identity43008 : scanCanonicalize (H12AffineFastState.compose env43008 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43008 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43009 : List Nat := [2,4,3,1,1,1,3,4,0,5,1,1,3,0,0,2,0,1,4,1,0,0,0,2,3,1,1,0,1,0,5,0,5,1,1,1]

theorem envBound43009 : H12AffineFastState.Bounded env43009 := by
  intro p hp
  have h : env43009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43008_43009 : H12AffineEnvironment.transform 3 1 env43008 = env43009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43008 == env43009) = true)

def env43010 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441625,155917,21762,8328,17,171417,5393,140316,303372,156817,411924,257,144444,185753,169880]

theorem envBound43010 : H12AffineFastState.Bounded env43010 := by
  intro p hp
  have h : env43010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42994_43010 : H12AffineEnvironment.transform 5 17 env42994 = env43010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42994 == env43010) = true)

theorem identity43010 : scanCanonicalize (H12AffineFastState.compose env43010 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182717) := by decide +kernel

theorem selectedBound43010 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43011 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,182717,1025,32769,4113,29860,155917,21762,8328,17,171417,5393,140316,157873,156817,32937,257,144444,185753,169880]

theorem envBound43011 : H12AffineFastState.Bounded env43011 := by
  intro p hp
  have h : env43011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43010_43011 : H12AffineEnvironment.transform 17 182717 env43010 = env43011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182717 env43010 == env43011) = true)

theorem identity43011 : scanCanonicalize (H12AffineFastState.compose env43011 (packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound43011 : packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env43012 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,49169,2476,1025,32769,4113,29860,41244,21762,8328,17,23944,5393,58381,43168,42112,32937,257,62509,5512,22409]

theorem envBound43012 : H12AffineFastState.Bounded env43012 := by
  intro p hp
  have h : env43012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43011_43012 : H12AffineEnvironment.transform 16 49169 env43011 = env43012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43011 == env43012) = true)

theorem identity43012 : scanCanonicalize (H12AffineFastState.compose env43012 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound43012 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env43013 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,32768,41090,46108,2476,1025,32769,4113,169,41244,8463,8328,17,10629,5393,36864,43168,42112,32937,257,32800,5512,9092]

theorem envBound43013 : H12AffineFastState.Bounded env43013 := by
  intro p hp
  have h : env43013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43012_43013 : H12AffineEnvironment.transform 13 13325 env43012 = env43013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env43012 == env43013) = true)

theorem identity43013 : scanCanonicalize (H12AffineFastState.compose env43013 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43013 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43014 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,32768,33031,38297,2476,1025,32769,4113,169,32921,138,269,17,2048,5393,36864,35109,34053,32937,257,32800,5512,513]

theorem envBound43014 : H12AffineFastState.Bounded env43014 := by
  intro p hp
  have h : env43014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43013_43014 : H12AffineEnvironment.transform 12 389 env43013 = env43014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43013 == env43014) = true)

theorem identity43014 : scanCanonicalize (H12AffineFastState.compose env43014 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43014 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43015 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,32768,33031,38161,2340,1025,32769,4113,33,32785,2,269,17,2048,5393,36864,35109,34053,32801,257,32800,5376,513]

theorem envBound43015 : H12AffineFastState.Bounded env43015 := by
  intro p hp
  have h : env43015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43014_43015 : H12AffineEnvironment.transform 6 8 env43014 = env43015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43014 == env43015) = true)

theorem identity43015 : scanCanonicalize (H12AffineFastState.compose env43015 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43015 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43016 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5376,513]

theorem envBound43016 : H12AffineFastState.Bounded env43016 := by
  intro p hp
  have h : env43016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43015_43016 : H12AffineEnvironment.transform 14 1 env43015 = env43016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43015 == env43016) = true)

theorem identity43016 : scanCanonicalize (H12AffineFastState.compose env43016 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43017 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5173,2049,1025,0,4113,33,16,2,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound43017 : H12AffineFastState.Bounded env43017 := by
  intro p hp
  have h : env43017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43016_43017 : H12AffineEnvironment.transform 7 37 env43016 = env43017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43016 == env43017) = true)

def env43018 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,1,35,1029,2049,1025,0,33,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound43018 : H12AffineFastState.Bounded env43018 := by
  intro p hp
  have h : env43018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43017_43018 : H12AffineEnvironment.transform 11 48 env43017 = env43018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43017 == env43018) = true)

theorem identity43018 : scanCanonicalize (H12AffineFastState.compose env43018 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43019 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,48,40,1045,1,35,1029,2049,1025,0,33,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,16]

theorem envBound43019 : H12AffineFastState.Bounded env43019 := by
  intro p hp
  have h : env43019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43018_43019 : H12AffineEnvironment.transform 8 17 env43018 = env43019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43018 == env43019) = true)

def env43020 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,40,33,1,35,49,2049,53,0,33,33,16,2,40,17,2048,48,49,2049,21,32,36,33,33,16]

theorem envBound43020 : H12AffineFastState.Bounded env43020 := by
  intro p hp
  have h : env43020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43019_43020 : H12AffineEnvironment.transform 9 52 env43019 = env43020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43019 == env43020) = true)

theorem identity43020 : scanCanonicalize (H12AffineFastState.compose env43020 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43021 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,48,40,33,1,35,49,33,53,0,33,33,16,2,40,17,32,48,49,33,21,32,36,33,33,16]

theorem envBound43021 : H12AffineFastState.Bounded env43021 := by
  intro p hp
  have h : env43021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43020_43021 : H12AffineEnvironment.transform 10 32 env43020 = env43021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43020 == env43021) = true)

def leafEnv43021 : List Nat := [2,4,8,16,32,17,8,37,17,52,32,48,40,33,1,35,49,33,53,0,33,33,16,2,20,40,1,17,32,48,49,33,21,32,36,33,5,35,33,16,1,33,0]

def active43021 : List Nat := [0,1,2,3,4]

def tree43021 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43021 : H12WitnessSearch.Good tree43021 := H12GlobalWitnessIndex.good

theorem leafIdentity43021 : H12AffineFastState.composeSystem env43021 rootObs = leafEnv43021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43021 rootObs == leafEnv43021) = true)

theorem terminalChecked43021 : H12PackedTerminal.terminalCheckFast leafEnv43021 active43021 tree43021 = true := by decide +kernel

def env43022 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,40,32,1,35,48,2049,52,0,33,33,16,2,40,17,2048,49,49,2049,20,32,36,33,32,16]

theorem envBound43022 : H12AffineFastState.Bounded env43022 := by
  intro p hp
  have h : env43022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43019_43022 : H12AffineEnvironment.transform 9 53 env43019 = env43022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43019 == env43022) = true)

theorem identity43022 : scanCanonicalize (H12AffineFastState.compose env43022 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound43022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43023 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,40,32,1,35,48,27,52,0,33,33,16,2,40,17,26,49,49,27,20,32,36,33,32,16]

theorem envBound43023 : H12AffineFastState.Bounded env43023 := by
  intro p hp
  have h : env43023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43022_43023 : H12AffineEnvironment.transform 10 26 env43022 = env43023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env43022 == env43023) = true)

def leafEnv43023 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,40,32,1,35,48,27,52,0,33,33,16,2,21,40,1,17,26,49,49,27,20,32,36,33,5,35,32,16,1,33,0]

def active43023 : List Nat := [0,1,2,3,4]

def tree43023 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43023 : H12WitnessSearch.Good tree43023 := H12GlobalWitnessIndex.good

theorem leafIdentity43023 : H12AffineFastState.composeSystem env43023 rootObs = leafEnv43023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43023 rootObs == leafEnv43023) = true)

theorem terminalChecked43023 : H12PackedTerminal.terminalCheckFast leafEnv43023 active43023 tree43023 = true := by decide +kernel

def env43024 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,1,35,1028,2049,1025,0,32,33,16,2,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound43024 : H12AffineFastState.Bounded env43024 := by
  intro p hp
  have h : env43024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43017_43024 : H12AffineEnvironment.transform 11 49 env43017 = env43024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43017 == env43024) = true)

theorem identity43024 : scanCanonicalize (H12AffineFastState.compose env43024 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound43024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43025 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,49,40,560,1,35,544,2049,549,0,32,33,16,2,40,17,2048,545,48,2049,517,32,36,33,560,513]

theorem envBound43025 : H12AffineFastState.Bounded env43025 := by
  intro p hp
  have h : env43025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43024_43025 : H12AffineEnvironment.transform 9 548 env43024 = env43025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env43024 == env43025) = true)

def env43026 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,40,32,1,35,48,2049,53,0,32,33,16,2,40,17,2048,49,48,2049,21,32,36,33,32,17]

theorem envBound43026 : H12AffineFastState.Bounded env43026 := by
  intro p hp
  have h : env43026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43025_43026 : H12AffineEnvironment.transform 8 16 env43025 = env43026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43025 == env43026) = true)

theorem identity43026 : scanCanonicalize (H12AffineFastState.compose env43026 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound43026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43027 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,49,40,32,1,35,48,32,53,0,32,33,16,2,40,17,33,49,48,32,21,32,36,33,32,17]

theorem envBound43027 : H12AffineFastState.Bounded env43027 := by
  intro p hp
  have h : env43027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43026_43027 : H12AffineEnvironment.transform 10 33 env43026 = env43027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env43026 == env43027) = true)

def leafEnv43027 : List Nat := [2,4,8,16,32,17,8,37,16,52,33,49,40,32,1,35,48,32,53,0,32,33,16,2,20,40,1,17,33,49,48,32,21,32,36,33,5,35,32,17,1,32,0]

def active43027 : List Nat := [0,1,2,3,4]

def tree43027 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43027 : H12WitnessSearch.Good tree43027 := H12GlobalWitnessIndex.good

theorem leafIdentity43027 : H12AffineFastState.composeSystem env43027 rootObs = leafEnv43027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43027 rootObs == leafEnv43027) = true)

theorem terminalChecked43027 : H12PackedTerminal.terminalCheckFast leafEnv43027 active43027 tree43027 = true := by decide +kernel

def env43028 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,40,33,1,35,49,2049,52,0,32,33,16,2,40,17,2048,48,48,2049,20,32,36,33,33,16]

theorem envBound43028 : H12AffineFastState.Bounded env43028 := by
  intro p hp
  have h : env43028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43025_43028 : H12AffineEnvironment.transform 8 17 env43025 = env43028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43025 == env43028) = true)

theorem identity43028 : scanCanonicalize (H12AffineFastState.compose env43028 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound43028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43029 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,40,33,1,35,49,27,52,0,32,33,16,2,40,17,26,48,48,27,20,32,36,33,33,16]

theorem envBound43029 : H12AffineFastState.Bounded env43029 := by
  intro p hp
  have h : env43029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43028_43029 : H12AffineEnvironment.transform 10 26 env43028 = env43029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env43028 == env43029) = true)

def leafEnv43029 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,40,33,1,35,49,27,52,0,32,33,16,2,21,40,1,17,26,48,48,27,20,32,36,33,5,35,33,16,1,32,0]

def active43029 : List Nat := [0,1,2,3,4]

def tree43029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43029 : H12WitnessSearch.Good tree43029 := H12GlobalWitnessIndex.good

theorem leafIdentity43029 : H12AffineFastState.composeSystem env43029 rootObs = leafEnv43029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43029 rootObs == leafEnv43029) = true)

theorem terminalChecked43029 : H12PackedTerminal.terminalCheckFast leafEnv43029 active43029 tree43029 = true := by decide +kernel

def env43030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,21763,8328,64,215367,115151,140364,303453,241742,499098,257,254131,196886,169881]

theorem envBound43030 : H12AffineFastState.Bounded env43030 := by
  intro p hp
  have h : env43030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42992_43030 : H12AffineEnvironment.transform 20 4161 env42992 = env43030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42992 == env43030) = true)

theorem identity43030 : scanCanonicalize (H12AffineFastState.compose env43030 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound43030 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,392287,73755,21763,8328,64,2048,115151,91403,303453,61705,318685,257,41460,16465,120542]

theorem envBound43031 : H12AffineFastState.Bounded env43031 := by
  intro p hp
  have h : env43031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43030_43031 : H12AffineEnvironment.transform 16 82247 env43030 = env43031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env43030 == env43031) = true)

def env43032 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,4113,392207,73755,21763,8328,16,2048,115103,91403,303373,61705,318605,257,41380,16385,120462]

theorem envBound43032 : H12AffineFastState.Bounded env43032 := by
  intro p hp
  have h : env43032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43031_43032 : H12AffineEnvironment.transform 5 16 env43031 = env43032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43031 == env43032) = true)

theorem identity43032 : scanCanonicalize (H12AffineFastState.compose env43032 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound43032 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env43033 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,136,65536,82199,262144,1025,137,4113,359559,73755,21763,8328,16,2048,82199,91403,270725,29057,285701,257,8492,16385,87558]

theorem envBound43033 : H12AffineFastState.Bounded env43033 := by
  intro p hp
  have h : env43033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43032_43033 : H12AffineEnvironment.transform 14 136 env43032 = env43033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env43032 == env43033) = true)

theorem identity43033 : scanCanonicalize (H12AffineFastState.compose env43033 (packedSelected [1,4,7,9,18,23,26,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43033 : packedSelected [1,4,7,9,18,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43034 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,136,65536,82199,262144,1025,137,4113,351490,65950,21763,269,16,2048,82199,83086,262144,20484,285701,257,169,16385,87558]

theorem envBound43034 : H12AffineFastState.Bounded env43034 := by
  intro p hp
  have h : env43034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43033_43034 : H12AffineEnvironment.transform 12 389 env43033 = env43034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43033 == env43034) = true)

theorem identity43034 : scanCanonicalize (H12AffineFastState.compose env43034 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43034 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env43035 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,136,65536,70679,262144,1025,137,4113,329730,65950,3,269,16,2048,70679,70030,262144,1284,264453,257,169,5377,66310]

theorem envBound43035 : H12AffineFastState.Bounded env43035 := by
  intro p hp
  have h : env43035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43034_43035 : H12AffineEnvironment.transform 13 5376 env43034 = env43035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43034 == env43035) = true)

theorem identity43035 : scanCanonicalize (H12AffineFastState.compose env43035 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound43035 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env43036 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,136,65536,70679,67755,1025,137,4113,169,65950,3,269,16,2048,70679,70030,67755,1284,65966,257,169,5377,66310]

theorem envBound43036 : H12AffineFastState.Bounded env43036 := by
  intro p hp
  have h : env43036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43035_43036 : H12AffineEnvironment.transform 17 67755 env43035 = env43036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env43035 == env43036) = true)

theorem identity43036 : scanCanonicalize (H12AffineFastState.compose env43036 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43036 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env43037 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,65536,70679,67618,1025,0,4113,32,65815,3,269,16,2048,70679,69895,67618,1284,65831,257,32,5377,66310]

theorem envBound43037 : H12AffineFastState.Bounded env43037 := by
  intro p hp
  have h : env43037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43036_43037 : H12AffineEnvironment.transform 6 9 env43036 = env43037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43036 == env43037) = true)

theorem identity43037 : scanCanonicalize (H12AffineFastState.compose env43037 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound43037 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43038 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,2310,7441,292,1025,0,4113,32,2065,3,269,16,2048,7441,6145,292,1284,2081,257,32,5377,2560]

theorem envBound43038 : H12AffineFastState.Bounded env43038 := by
  intro p hp
  have h : env43038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43037_43038 : H12AffineEnvironment.transform 15 2310 env43037 = env43038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env43037 == env43038) = true)

theorem identity43038 : scanCanonicalize (H12AffineFastState.compose env43038 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound43038 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env43039 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,4096,268,5376,1,34,5173,292,1025,0,4113,32,309,3,269,16,292,5173,4389,292,1284,261,257,32,5377,804]

theorem envBound43039 : H12AffineFastState.Bounded env43039 := by
  intro p hp
  have h : env43039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43038_43039 : H12AffineEnvironment.transform 10 292 env43038 = env43039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env43038 == env43039) = true)

theorem identity43039 : scanCanonicalize (H12AffineFastState.compose env43039 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound43039 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env43040 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,1280,268,0,1,34,309,292,1025,0,1297,32,309,3,269,16,292,309,1061,292,1284,261,257,32,1,804]

theorem envBound43040 : H12AffineFastState.Bounded env43040 := by
  intro p hp
  have h : env43040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43039_43040 : H12AffineEnvironment.transform 11 1280 env43039 = env43040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env43039 == env43040) = true)

theorem identity43040 : scanCanonicalize (H12AffineFastState.compose env43040 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43040 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env43041 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,17,268,0,1,34,309,292,272,0,0,32,309,3,269,16,292,309,308,292,21,261,257,32,1,804]

theorem envBound43041 : H12AffineFastState.Bounded env43041 := by
  intro p hp
  have h : env43041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43040_43041 : H12AffineEnvironment.transform 9 273 env43040 = env43041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43040 == env43041) = true)

theorem identity43041 : scanCanonicalize (H12AffineFastState.compose env43041 (packedSelected [3,5,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43041 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env43042 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,40,0,1,34,17,0,52,0,0,32,17,3,41,16,0,17,16,0,21,33,37,32,1,512]

theorem envBound43042 : H12AffineFastState.Bounded env43042 := by
  intro p hp
  have h : env43042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43041_43042 : H12AffineEnvironment.transform 7 36 env43041 = env43042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43041 == env43042) = true)

theorem identity43042 : scanCanonicalize (H12AffineFastState.compose env43042 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound43042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43043 : List Nat := [2,4,8,16,32,16,9,36,36,53,0,17,40,0,1,34,17,0,52,0,0,32,17,3,41,16,0,17,16,0,21,33,37,32,1,36]

theorem envBound43043 : H12AffineFastState.Bounded env43043 := by
  intro p hp
  have h : env43043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43042_43043 : H12AffineEnvironment.transform 8 36 env43042 = env43043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env43042 == env43043) = true)

theorem identity43043 : scanCanonicalize (H12AffineFastState.compose env43043 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound43043 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43044 : List Nat := [2,4,8,8,32,8,9,36,36,45,0,9,40,0,1,34,9,0,44,0,0,32,9,3,41,8,0,9,8,0,13,33,37,32,1,36]

theorem envBound43044 : H12AffineFastState.Bounded env43044 := by
  intro p hp
  have h : env43044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43043_43044 : H12AffineEnvironment.transform 3 8 env43043 = env43044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env43043 == env43044) = true)

theorem identity43044 : scanCanonicalize (H12AffineFastState.compose env43044 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound43044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43045 : List Nat := [2,4,8,8,8,8,9,12,12,5,0,9,0,0,1,10,9,0,4,0,0,8,9,3,1,8,0,9,8,0,13,9,13,8,1,12]

theorem envBound43045 : H12AffineFastState.Bounded env43045 := by
  intro p hp
  have h : env43045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43044_43045 : H12AffineEnvironment.transform 4 8 env43044 = env43045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env43044 == env43045) = true)

theorem identity43045 : scanCanonicalize (H12AffineFastState.compose env43045 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43045 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43046 : List Nat := [1,4,8,8,8,8,9,12,12,5,0,9,0,0,1,9,9,0,4,0,0,8,9,0,1,8,0,9,8,0,13,9,13,8,1,12]

theorem envBound43046 : H12AffineFastState.Bounded env43046 := by
  intro p hp
  have h : env43046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43045_43046 : H12AffineEnvironment.transform 0 1 env43045 = env43046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43045 == env43046) = true)

theorem identity43046 : scanCanonicalize (H12AffineFastState.compose env43046 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound43046 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43047 : List Nat := [1,4,0,0,0,0,1,4,4,5,0,1,0,0,1,1,1,0,4,0,0,0,1,0,1,0,0,1,0,0,5,1,5,0,1,4]

theorem envBound43047 : H12AffineFastState.Bounded env43047 := by
  intro p hp
  have h : env43047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43046_43047 : H12AffineEnvironment.transform 2 0 env43046 = env43047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env43046 == env43047) = true)

def env43048 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,4112,392206,73755,21763,8328,17,2048,115102,91403,303372,61705,318604,257,41381,16384,120463]

theorem envBound43048 : H12AffineFastState.Bounded env43048 := by
  intro p hp
  have h : env43048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43031_43048 : H12AffineEnvironment.transform 5 17 env43031 = env43048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43031 == env43048) = true)

theorem identity43048 : scanCanonicalize (H12AffineFastState.compose env43048 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound43048 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env43049 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,100523,1025,32769,4112,29861,73755,21763,8328,17,2048,115102,91403,76199,61705,87079,257,41381,16384,120463]

theorem envBound43049 : H12AffineFastState.Bounded env43049 := by
  intro p hp
  have h : env43049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43048_43049 : H12AffineEnvironment.transform 17 100523 env43048 = env43049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env43048 == env43049) = true)

theorem identity43049 : scanCanonicalize (H12AffineFastState.compose env43049 (packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43049 : packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env43050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,65536,82198,100523,1025,32769,4112,21792,65950,21763,269,17,2048,115102,83086,67618,53388,87079,257,32800,16384,120463]

theorem envBound43050 : H12AffineFastState.Bounded env43050 := by
  intro p hp
  have h : env43050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43049_43050 : H12AffineEnvironment.transform 12 389 env43049 = env43050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43049 == env43050) = true)

theorem identity43050 : scanCanonicalize (H12AffineFastState.compose env43050 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound43050 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env43051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,54414,38296,23589,1025,32769,4112,21792,54544,21763,269,17,2048,5392,36864,56492,53388,32937,257,32800,16384,513]

theorem envBound43051 : H12AffineFastState.Bounded env43051 := by
  intro p hp
  have h : env43051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43050_43051 : H12AffineEnvironment.transform 15 54414 env43050 = env43051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env43050 == env43051) = true)

theorem identity43051 : scanCanonicalize (H12AffineFastState.compose env43051 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound43051 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env43052 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5513,32768,33031,38296,2476,1025,32769,4112,169,32921,138,269,17,2048,5392,36864,35109,34053,32937,257,32800,5513,513]

theorem envBound43052 : H12AffineFastState.Bounded env43052 := by
  intro p hp
  have h : env43052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43051_43052 : H12AffineEnvironment.transform 13 5513 env43051 = env43052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env43051 == env43052) = true)

theorem identity43052 : scanCanonicalize (H12AffineFastState.compose env43052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43053 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33031,38160,2340,1025,32769,4112,33,32785,2,269,17,2048,5392,36864,35109,34053,32801,257,32800,5377,513]

theorem envBound43053 : H12AffineFastState.Bounded env43053 := by
  intro p hp
  have h : env43053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43052_43053 : H12AffineEnvironment.transform 6 8 env43052 = env43053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43052 == env43053) = true)

theorem identity43053 : scanCanonicalize (H12AffineFastState.compose env43053 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43053 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43054 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4112,33,16,2,269,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound43054 : H12AffineFastState.Bounded env43054 := by
  intro p hp
  have h : env43054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43053_43054 : H12AffineEnvironment.transform 14 1 env43053 = env43054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43053 == env43054) = true)

theorem identity43054 : scanCanonicalize (H12AffineFastState.compose env43054 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43055 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,1,34,5173,2048,1025,0,4112,33,16,2,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound43055 : H12AffineFastState.Bounded env43055 := by
  intro p hp
  have h : env43055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43054_43055 : H12AffineEnvironment.transform 7 36 env43054 = env43055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43054 == env43055) = true)

def env43056 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1045,1,34,1029,2048,1025,0,32,33,16,2,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound43056 : H12AffineFastState.Bounded env43056 := by
  intro p hp
  have h : env43056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43055_43056 : H12AffineEnvironment.transform 11 48 env43055 = env43056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43055 == env43056) = true)

theorem identity43056 : scanCanonicalize (H12AffineFastState.compose env43056 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound43056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43057 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,41,1045,1,34,1029,1077,1025,0,32,33,16,2,41,17,1077,1028,49,1077,1056,32,37,33,1045,513]

theorem envBound43057 : H12AffineFastState.Bounded env43057 := by
  intro p hp
  have h : env43057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43056_43057 : H12AffineEnvironment.transform 10 1077 env43056 = env43057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env43056 == env43057) = true)

def env43058 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,41,33,1,34,49,1,53,0,32,33,16,2,41,17,1,48,49,1,20,32,37,33,33,513]

theorem envBound43058 : H12AffineFastState.Bounded env43058 := by
  intro p hp
  have h : env43058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43057_43058 : H12AffineEnvironment.transform 9 52 env43057 = env43058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43057 == env43058) = true)

theorem identity43058 : scanCanonicalize (H12AffineFastState.compose env43058 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43058 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43059 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,8,0,1,3,16,1,20,0,1,0,16,2,8,17,1,17,16,1,20,1,4,0,0,513]

theorem envBound43059 : H12AffineFastState.Bounded env43059 := by
  intro p hp
  have h : env43059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43058_43059 : H12AffineEnvironment.transform 4 1 env43058 = env43059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43058 == env43059) = true)

def leafEnv43059 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,8,0,1,3,16,1,20,0,1,0,16,2,21,8,1,17,1,17,16,1,20,1,4,0,5,3,0,513,1,1,0]

def active43059 : List Nat := [0,1,2,3,8]

def tree43059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43059 : H12WitnessSearch.Good tree43059 := H12GlobalWitnessIndex.good

theorem leafIdentity43059 : H12AffineFastState.composeSystem env43059 rootObs = leafEnv43059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43059 rootObs == leafEnv43059) = true)

theorem terminalChecked43059 : H12PackedTerminal.terminalCheckFast leafEnv43059 active43059 tree43059 = true := by decide +kernel

def env43060 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,32,1,34,48,0,52,0,32,33,16,2,41,17,0,49,49,0,21,32,37,33,32,513]

theorem envBound43060 : H12AffineFastState.Bounded env43060 := by
  intro p hp
  have h : env43060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43057_43060 : H12AffineEnvironment.transform 9 53 env43057 = env43060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43057 == env43060) = true)

theorem identity43060 : scanCanonicalize (H12AffineFastState.compose env43060 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43061 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,41,32,1,34,48,0,52,0,32,33,16,2,41,17,0,49,49,0,21,32,37,33,32,11]

theorem envBound43061 : H12AffineFastState.Bounded env43061 := by
  intro p hp
  have h : env43061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43060_43061 : H12AffineEnvironment.transform 8 10 env43060 = env43061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43060 == env43061) = true)

def leafEnv43061 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,41,32,1,34,48,0,52,0,32,33,16,2,20,41,1,17,0,49,49,0,21,32,37,33,5,34,32,11,1,32,0]

def active43061 : List Nat := [0,1,2,3,4]

def tree43061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43061 : H12WitnessSearch.Good tree43061 := H12GlobalWitnessIndex.good

theorem leafIdentity43061 : H12AffineFastState.composeSystem env43061 rootObs = leafEnv43061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43061 rootObs == leafEnv43061) = true)

theorem terminalChecked43061 : H12PackedTerminal.terminalCheckFast leafEnv43061 active43061 tree43061 = true := by decide +kernel

def env43062 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1044,1,34,1028,2048,1025,0,33,33,16,2,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound43062 : H12AffineFastState.Bounded env43062 := by
  intro p hp
  have h : env43062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43055_43062 : H12AffineEnvironment.transform 11 49 env43055 = env43062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43055 == env43062) = true)

theorem identity43062 : scanCanonicalize (H12AffineFastState.compose env43062 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43062 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43063 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,41,1044,1,34,1028,0,1025,0,33,33,16,2,41,17,0,1029,48,0,1056,32,37,33,1044,513]

theorem envBound43063 : H12AffineFastState.Bounded env43063 := by
  intro p hp
  have h : env43063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43062_43063 : H12AffineEnvironment.transform 10 0 env43062 = env43063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43062 == env43063) = true)

def env43064 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,32,1,34,48,0,53,0,33,33,16,2,41,17,0,49,48,0,20,32,37,33,32,513]

theorem envBound43064 : H12AffineFastState.Bounded env43064 := by
  intro p hp
  have h : env43064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43063_43064 : H12AffineEnvironment.transform 9 52 env43063 = env43064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43063 == env43064) = true)

theorem identity43064 : scanCanonicalize (H12AffineFastState.compose env43064 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43065 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,8,1,1,3,17,0,20,0,0,0,16,2,8,17,0,16,17,0,20,1,4,0,1,513]

theorem envBound43065 : H12AffineFastState.Bounded env43065 := by
  intro p hp
  have h : env43065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43064_43065 : H12AffineEnvironment.transform 4 1 env43064 = env43065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43064 == env43065) = true)

def leafEnv43065 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,8,1,1,3,17,0,20,0,0,0,16,2,21,8,1,17,0,16,17,0,20,1,4,0,5,3,1,513,1,0,0]

def active43065 : List Nat := [0,1,2,3,8]

def tree43065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43065 : H12WitnessSearch.Good tree43065 := H12GlobalWitnessIndex.good

theorem leafIdentity43065 : H12AffineFastState.composeSystem env43065 rootObs = leafEnv43065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43065 rootObs == leafEnv43065) = true)

theorem terminalChecked43065 : H12PackedTerminal.terminalCheckFast leafEnv43065 active43065 tree43065 = true := by decide +kernel

def env43066 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,41,33,1,34,49,0,52,0,33,33,16,2,41,17,0,48,48,0,21,32,37,33,33,513]

theorem envBound43066 : H12AffineFastState.Bounded env43066 := by
  intro p hp
  have h : env43066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43063_43066 : H12AffineEnvironment.transform 9 53 env43063 = env43066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43063 == env43066) = true)

theorem identity43066 : scanCanonicalize (H12AffineFastState.compose env43066 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43066 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43067 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,41,33,1,34,49,0,52,0,33,33,16,2,41,17,0,48,48,0,21,32,37,33,33,11]

theorem envBound43067 : H12AffineFastState.Bounded env43067 := by
  intro p hp
  have h : env43067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43066_43067 : H12AffineEnvironment.transform 8 10 env43066 = env43067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43066 == env43067) = true)

def leafEnv43067 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,41,33,1,34,49,0,52,0,33,33,16,2,20,41,1,17,0,48,48,0,21,32,37,33,5,34,33,11,1,33,0]

def active43067 : List Nat := [0,1,2,3,4]

def tree43067 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43067 : H12WitnessSearch.Good tree43067 := H12GlobalWitnessIndex.good

theorem leafIdentity43067 : H12AffineFastState.composeSystem env43067 rootObs = leafEnv43067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43067 rootObs == leafEnv43067) = true)

theorem terminalChecked43067 : H12PackedTerminal.terminalCheckFast leafEnv43067 active43067 tree43067 = true := by decide +kernel

def env43068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155997,2114883,8328,64,6677534,115150,2241548,303452,2334735,4268163,257,254131,196886,2263000]

theorem envBound43068 : H12AffineFastState.Bounded env43068 := by
  intro p hp
  have h : env43068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42954_43068 : H12AffineEnvironment.transform 22 155997 env42954 = env43068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155997 env42954 == env43068) = true)

def env43069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155997,2114883,8328,64,215366,115150,2241548,303452,2334735,2592219,257,254131,196886,2263000]

theorem envBound43069 : H12AffineFastState.Bounded env43069 := by
  intro p hp
  have h : env43069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43068_43069 : H12AffineEnvironment.transform 21 2534744 env43068 = env43069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env43068 == env43069) = true)

def env43070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,21763,8328,64,215366,115150,140364,303452,241743,499099,257,254131,196886,169880]

theorem envBound43070 : H12AffineFastState.Bounded env43070 := by
  intro p hp
  have h : env43070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43069_43070 : H12AffineEnvironment.transform 20 4160 env43069 = env43070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43069 == env43070) = true)

theorem identity43070 : scanCanonicalize (H12AffineFastState.compose env43070 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound43070 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,21763,8328,64,75786,115150,17664,303452,119043,392407,257,98815,90202,63188]

theorem envBound43071 : H12AffineFastState.Bounded env43071 := by
  intro p hp
  have h : env43071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43070_43071 : H12AffineEnvironment.transform 16 24908 env43070 = env43071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env43070 == env43071) = true)

def env43072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,21763,8192,64,75786,115014,17664,303452,119043,392287,257,98679,90202,63068]

theorem envBound43072 : H12AffineFastState.Bounded env43072 := by
  intro p hp
  have h : env43072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43071_43072 : H12AffineEnvironment.transform 6 8 env43071 = env43072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43071 == env43072) = true)

theorem identity43072 : scanCanonicalize (H12AffineFastState.compose env43072 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43072 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,4160,62589,17,21763,8192,64,75786,115014,17664,35189,119043,119926,257,98679,90202,63068]

theorem envBound43073 : H12AffineFastState.Bounded env43073 := by
  intro p hp
  have h : env43073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43072_43073 : H12AffineEnvironment.transform 17 10281 env43072 = env43073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43072 == env43073) = true)

theorem identity43073 : scanCanonicalize (H12AffineFastState.compose env43073 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43073 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13389,10281,1025,32769,4160,41340,17,2,8192,64,75786,103495,4097,35189,99330,98679,257,98679,79195,41821]

theorem envBound43074 : H12AffineFastState.Bounded env43074 := by
  intro p hp
  have h : env43074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0