import H12CloudChart0Data074

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env18914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98781,8328,65,8546652,79130,8480026,8568224,8390093,98679,257,8484155,8492190,8462875]

theorem envBound18914 : H12AffineFastState.Bounded env18914 := by
  intro p hp
  have h : env18914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18884_18914 : H12AffineEnvironment.transform 21 21793 env18884 = env18914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env18884 == env18914) = true)

theorem identity18914 : scanCanonicalize (H12AffineFastState.compose env18914 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62660) := by decide +kernel

theorem selectedBound18914 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,62660,98781,8328,65,171416,79130,102878,149860,61705,98679,257,98815,90202,120543]

theorem envBound18915 : H12AffineFastState.Bounded env18915 := by
  intro p hp
  have h : env18915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18914_18915 : H12AffineEnvironment.transform 22 62660 env18914 = env18915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env18914 == env18915) = true)

def env18916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10281,1025,32769,77898,169,41292,98781,8328,65,171416,79130,102878,138476,42113,98679,257,98815,79314,99159]

theorem envBound18916 : H12AffineFastState.Bounded env18916 := by
  intro p hp
  have h : env18916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18915_18916 : H12AffineEnvironment.transform 13 5512 env18915 = env18916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env18915 == env18916) = true)

theorem identity18916 : scanCanonicalize (H12AffineFastState.compose env18916 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18916 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8322,131072,10281,1025,32769,4296,169,41292,41311,8328,65,171416,5528,45404,138476,42113,41461,257,41341,5456,41941]

theorem envBound18917 : H12AffineFastState.Bounded env18917 := by
  intro p hp
  have h : env18917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18916_18917 : H12AffineEnvironment.transform 15 8322 env18916 = env18917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18916 == env18917) = true)

theorem identity18917 : scanCanonicalize (H12AffineFastState.compose env18917 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound18917 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8322,46276,10281,1025,32769,4296,169,41292,41311,8328,65,10588,5528,45404,43048,42113,41461,257,41341,5456,41941]

theorem envBound18918 : H12AffineFastState.Bounded env18918 := by
  intro p hp
  have h : env18918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18917_18918 : H12AffineEnvironment.transform 16 46276 env18917 = env18918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env18917 == env18918) = true)

theorem identity18918 : scanCanonicalize (H12AffineFastState.compose env18918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18919 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4248,32768,8322,45524,10281,273,32769,4296,169,41292,41311,8328,65,10588,4232,45404,43048,41361,41461,257,41341,4160,41941]

theorem envBound18919 : H12AffineFastState.Bounded env18919 := by
  intro p hp
  have h : env18919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18918_18919 : H12AffineEnvironment.transform 9 272 env18918 = env18919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18918 == env18919) = true)

theorem identity18919 : scanCanonicalize (H12AffineFastState.compose env18919 (packedSelected [0,4,5,7,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound18919 : packedSelected [0,4,5,7,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18920 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4248,8660,8322,4096,10281,273,8661,4296,169,152,139,8328,65,10588,4232,4232,2556,69,33,257,169,4160,513]

theorem envBound18920 : H12AffineFastState.Bounded env18920 := by
  intro p hp
  have h : env18920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18919_18920 : H12AffineEnvironment.transform 14 8660 env18919 = env18920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env18919 == env18920) = true)

theorem identity18920 : scanCanonicalize (H12AffineFastState.compose env18920 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18921 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4248,137,479,4096,2420,273,136,4296,169,152,139,469,65,2049,4232,4232,2556,69,33,257,169,4160,513]

theorem envBound18921 : H12AffineFastState.Bounded env18921 := by
  intro p hp
  have h : env18921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18920_18921 : H12AffineEnvironment.transform 12 349 env18920 = env18921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18920 == env18921) = true)

theorem identity18921 : scanCanonicalize (H12AffineFastState.compose env18921 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound18921 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18922 : List Nat := [2,4,8,16,32,64,128,256,65,272,2048,4096,349,4248,137,479,4096,2420,273,136,4296,169,152,139,469,65,2049,4232,4232,2556,69,33,257,169,4160,64]

theorem envBound18922 : H12AffineFastState.Bounded env18922 := by
  intro p hp
  have h : env18922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18921_18922 : H12AffineEnvironment.transform 8 65 env18921 = env18922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env18921 == env18922) = true)

theorem identity18922 : scanCanonicalize (H12AffineFastState.compose env18922 (packedSelected [1,3,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18922 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env18923 : List Nat := [2,4,8,16,32,64,9,256,65,272,2048,4096,349,4113,0,342,4096,2420,273,1,4161,32,17,2,348,65,2049,4097,4097,2421,69,33,257,32,4160,64]

theorem envBound18923 : H12AffineFastState.Bounded env18923 := by
  intro p hp
  have h : env18923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18922_18923 : H12AffineEnvironment.transform 6 9 env18922 = env18923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18922 == env18923) = true)

theorem identity18923 : scanCanonicalize (H12AffineFastState.compose env18923 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18924 : List Nat := [2,4,8,16,17,64,9,256,65,272,2048,4096,349,4113,0,342,4096,2373,273,1,4161,17,17,2,348,65,2049,4097,4097,2372,69,16,257,17,4160,64]

theorem envBound18924 : H12AffineFastState.Bounded env18924 := by
  intro p hp
  have h : env18924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18923_18924 : H12AffineEnvironment.transform 4 17 env18923 = env18924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18923 == env18924) = true)

theorem identity18924 : scanCanonicalize (H12AffineFastState.compose env18924 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound18924 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18925 : List Nat := [2,4,8,16,17,64,9,84,65,68,2048,4096,9,4113,0,2,4096,2065,69,1,4161,17,17,2,8,65,2049,4097,4097,2064,69,16,85,17,4160,64]

theorem envBound18925 : H12AffineFastState.Bounded env18925 := by
  intro p hp
  have h : env18925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18924_18925 : H12AffineEnvironment.transform 7 84 env18924 = env18925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env18924 == env18925) = true)

theorem identity18925 : scanCanonicalize (H12AffineFastState.compose env18925 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18925 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18926 : List Nat := [2,4,8,16,17,64,9,84,65,68,2048,17,9,0,0,2,17,2065,69,1,80,17,17,2,8,65,2049,16,16,2064,69,16,85,17,81,64]

theorem envBound18926 : H12AffineFastState.Bounded env18926 := by
  intro p hp
  have h : env18926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18925_18926 : H12AffineEnvironment.transform 11 17 env18925 = env18926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18925 == env18926) = true)

theorem identity18926 : scanCanonicalize (H12AffineFastState.compose env18926 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound18926 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18927 : List Nat := [2,4,8,16,17,64,9,84,65,68,65,17,9,0,0,2,17,80,69,1,80,17,17,2,8,65,64,16,16,81,69,16,85,17,81,64]

theorem envBound18927 : H12AffineFastState.Bounded env18927 := by
  intro p hp
  have h : env18927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18926_18927 : H12AffineEnvironment.transform 10 65 env18926 = env18927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env18926 == env18927) = true)

theorem identity18927 : scanCanonicalize (H12AffineFastState.compose env18927 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound18927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18928 : List Nat := [2,4,8,16,17,0,9,20,1,4,1,17,9,0,0,2,17,16,5,1,16,17,17,2,8,1,0,16,16,17,5,16,21,17,17,0]

theorem envBound18928 : H12AffineFastState.Bounded env18928 := by
  intro p hp
  have h : env18928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18927_18928 : H12AffineEnvironment.transform 5 0 env18927 = env18928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env18927 == env18928) = true)

def env18929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10280,1025,32769,77898,168,41293,98781,8328,65,171416,79130,102878,138477,42112,98679,257,98815,79315,99158]

theorem envBound18929 : H12AffineFastState.Bounded env18929 := by
  intro p hp
  have h : env18929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18915_18929 : H12AffineEnvironment.transform 13 5513 env18915 = env18929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18915 == env18929) = true)

theorem identity18929 : scanCanonicalize (H12AffineFastState.compose env18929 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound18929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33111,131072,10280,1025,32769,45341,168,41293,138,8328,65,171416,46157,4233,138477,42112,32,257,168,46212,513]

theorem envBound18930 : H12AffineFastState.Bounded env18930 := by
  intro p hp
  have h : env18930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18929_18930 : H12AffineEnvironment.transform 15 33111 env18929 = env18930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env18929 == env18930) = true)

theorem identity18930 : scanCanonicalize (H12AffineFastState.compose env18930 (packedSelected [0,2,4,6,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound18930 : packedSelected [0,2,4,6,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8323,131072,10280,1025,8661,4297,168,153,138,8328,65,146508,5529,4233,138477,1364,32,257,168,5456,513]

theorem envBound18931 : H12AffineFastState.Bounded env18931 := by
  intro p hp
  have h : env18931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18930_18931 : H12AffineEnvironment.transform 14 8660 env18930 = env18931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env18930 == env18931) = true)

theorem identity18931 : scanCanonicalize (H12AffineFastState.compose env18931 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound18931 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8323,5392,10280,1025,8661,4297,168,153,138,8328,65,10588,5529,4233,2557,1364,32,257,168,5456,513]

theorem envBound18932 : H12AffineFastState.Bounded env18932 := by
  intro p hp
  have h : env18932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18931_18932 : H12AffineEnvironment.transform 16 5392 env18931 = env18932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env18931 == env18932) = true)

theorem identity18932 : scanCanonicalize (H12AffineFastState.compose env18932 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18932 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10280,1025,8541,4161,32,17,2,8192,65,10588,5393,4097,2421,1364,32,257,32,5456,513]

theorem envBound18933 : H12AffineFastState.Bounded env18933 := by
  intro p hp
  have h : env18933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18932_18933 : H12AffineEnvironment.transform 6 8 env18932 = env18933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18932 == env18933) = true)

theorem identity18933 : scanCanonicalize (H12AffineFastState.compose env18933 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound18933 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5377,341,2,5392,2081,1025,340,4161,32,17,2,9,65,2389,5393,4097,2421,1364,32,257,32,5456,513]

theorem envBound18934 : H12AffineFastState.Bounded env18934 := by
  intro p hp
  have h : env18934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18933_18934 : H12AffineEnvironment.transform 12 9 env18933 = env18934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env18933 == env18934) = true)

theorem identity18934 : scanCanonicalize (H12AffineFastState.compose env18934 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound18934 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env18935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1028,9,261,341,2,276,2081,1025,340,1093,32,17,2,9,65,2389,277,1029,2421,1364,32,257,32,340,513]

theorem envBound18935 : H12AffineFastState.Bounded env18935 := by
  intro p hp
  have h : env18935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18934_18935 : H12AffineEnvironment.transform 11 1028 env18934 = env18935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env18934 == env18935) = true)

theorem identity18935 : scanCanonicalize (H12AffineFastState.compose env18935 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound18935 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,1028,9,261,341,2,276,1,1025,340,1093,32,17,2,9,65,373,277,1029,341,1364,32,257,32,340,513]

theorem envBound18936 : H12AffineFastState.Bounded env18936 := by
  intro p hp
  have h : env18936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18935_18936 : H12AffineEnvironment.transform 10 32 env18935 = env18936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env18935 == env18936) = true)

theorem identity18936 : scanCanonicalize (H12AffineFastState.compose env18936 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound18936 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env18937 : List Nat := [2,4,8,16,32,64,8,256,512,100,32,96,9,261,341,2,276,1,101,340,33,32,17,2,9,65,373,277,97,341,304,32,257,32,340,513]

theorem envBound18937 : H12AffineFastState.Bounded env18937 := by
  intro p hp
  have h : env18937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18936_18937 : H12AffineEnvironment.transform 9 100 env18936 = env18937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env18936 == env18937) = true)

theorem identity18937 : scanCanonicalize (H12AffineFastState.compose env18937 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18937 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18938 : List Nat := [2,4,8,16,1,64,8,256,512,69,1,65,9,261,341,2,276,1,68,340,0,1,17,2,9,65,340,277,64,341,273,1,257,1,340,513]

theorem envBound18938 : H12AffineFastState.Bounded env18938 := by
  intro p hp
  have h : env18938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18937_18938 : H12AffineEnvironment.transform 4 1 env18937 = env18938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18937 == env18938) = true)

theorem identity18938 : scanCanonicalize (H12AffineFastState.compose env18938 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound18938 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18939 : List Nat := [2,4,8,16,1,64,8,256,64,69,1,65,9,261,341,2,276,1,68,340,0,1,17,2,9,65,340,277,64,341,273,1,257,1,340,65]

theorem envBound18939 : H12AffineFastState.Bounded env18939 := by
  intro p hp
  have h : env18939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18938_18939 : H12AffineEnvironment.transform 8 64 env18938 = env18939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env18938 == env18939) = true)

theorem identity18939 : scanCanonicalize (H12AffineFastState.compose env18939 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18939 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env18940 : List Nat := [2,4,8,16,1,64,8,20,64,69,1,65,9,17,65,2,0,1,68,64,0,1,17,2,9,65,64,1,64,65,5,1,21,1,64,65]

theorem envBound18940 : H12AffineFastState.Bounded env18940 := by
  intro p hp
  have h : env18940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18939_18940 : H12AffineEnvironment.transform 7 20 env18939 = env18940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18939 == env18940) = true)

theorem identity18940 : scanCanonicalize (H12AffineFastState.compose env18940 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18941 : List Nat := [2,4,8,1,1,64,8,5,64,69,1,65,9,0,65,2,0,1,68,64,0,1,0,2,9,65,64,1,64,65,5,1,4,1,64,65]

theorem envBound18941 : H12AffineFastState.Bounded env18941 := by
  intro p hp
  have h : env18941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18940_18941 : H12AffineEnvironment.transform 3 1 env18940 = env18941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18940 == env18941) = true)

theorem identity18941 : scanCanonicalize (H12AffineFastState.compose env18941 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound18941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18942 : List Nat := [2,4,8,1,1,0,8,5,0,5,1,1,9,0,1,2,0,1,4,0,0,1,0,2,9,1,0,1,0,1,5,1,4,1,0,1]

theorem envBound18942 : H12AffineFastState.Bounded env18942 := by
  intro p hp
  have h : env18942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18941_18942 : H12AffineEnvironment.transform 5 0 env18941 = env18942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env18941 == env18942) = true)

theorem identity18942 : scanCanonicalize (H12AffineFastState.compose env18942 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18943 : List Nat := [2,4,3,1,1,0,3,5,0,5,1,1,2,0,1,2,0,1,4,0,0,1,0,2,2,1,0,1,0,1,5,1,4,1,0,1]

theorem envBound18943 : H12AffineFastState.Bounded env18943 := by
  intro p hp
  have h : env18943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18942_18943 : H12AffineEnvironment.transform 2 3 env18942 = env18943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18942 == env18943) = true)

def env18944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392317,8328,65,12729468,79131,8722619,8830977,8681581,4314199,257,8484154,8492191,8740795]

theorem envBound18944 : H12AffineFastState.Bounded env18944 := by
  intro p hp
  have h : env18944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18825_18944 : H12AffineEnvironment.transform 23 392317 env18825 = env18944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392317 env18825 == env18944) = true)

def env18945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98781,8328,65,12729468,79131,8480027,8568225,8390093,4314199,257,8484154,8492191,8462875]

theorem envBound18945 : H12AffineFastState.Bounded env18945 := by
  intro p hp
  have h : env18945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18944_18945 : H12AffineEnvironment.transform 17 32160 env18944 = env18945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env18944 == env18945) = true)

def env18946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98781,8328,65,8546652,79131,8480027,8568225,8390093,98679,257,8484154,8492191,8462875]

theorem envBound18946 : H12AffineFastState.Bounded env18946 := by
  intro p hp
  have h : env18946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18945_18946 : H12AffineEnvironment.transform 21 21792 env18945 = env18946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env18945 == env18946) = true)

theorem identity18946 : scanCanonicalize (H12AffineFastState.compose env18946 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound18946 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32160,1025,32769,58516,21792,8388608,21762,8328,65,8546652,57796,8434116,8568225,8390093,21928,257,8430053,8405056,8451780]

theorem envBound18947 : H12AffineFastState.Bounded env18947 := by
  intro p hp
  have h : env18947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18946_18947 : H12AffineEnvironment.transform 15 54495 env18946 = env18947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env18946 == env18947) = true)

def env18948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58396,21792,8388608,21762,8192,65,8546652,57676,8433996,8568105,8389957,21792,257,8429933,8405056,8451660]

theorem envBound18948 : H12AffineFastState.Bounded env18948 := by
  intro p hp
  have h : env18948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18947_18948 : H12AffineEnvironment.transform 6 8 env18947 = env18948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18947 == env18948) = true)

theorem identity18948 : scanCanonicalize (H12AffineFastState.compose env18948 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 147456) := by decide +kernel

theorem selectedBound18948 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58396,21792,147456,21762,8192,65,10588,57676,192844,64809,148805,21792,257,188781,131136,177740]

theorem envBound18949 : H12AffineFastState.Bounded env18949 := by
  intro p hp
  have h : env18949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18948_18949 : H12AffineEnvironment.transform 22 147456 env18948 = env18949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env18948 == env18949) = true)

theorem identity18949 : scanCanonicalize (H12AffineFastState.compose env18949 (packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18949 : packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env18950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,131072,32040,1025,8540,17729,21792,147456,21762,8192,65,10588,16401,151569,23668,148805,21792,257,147504,131136,136977]

theorem envBound18950 : H12AffineFastState.Bounded env18950 := by
  intro p hp
  have h : env18950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18949_18950 : H12AffineEnvironment.transform 14 8541 env18949 = env18950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18949 == env18950) = true)

theorem identity18950 : scanCanonicalize (H12AffineFastState.compose env18950 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18950 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env18951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,343,131072,2421,1025,8540,12572,8573,144477,8543,8192,65,10588,13388,140364,10281,143640,8573,257,144493,131136,136977]

theorem envBound18951 : H12AffineFastState.Bounded env18951 := by
  intro p hp
  have h : env18951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18950_18951 : H12AffineEnvironment.transform 13 13405 env18950 = env18951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18950 == env18951) = true)

theorem identity18951 : scanCanonicalize (H12AffineFastState.compose env18951 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound18951 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env18952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,343,5440,2421,1025,8540,12572,8573,8477,8543,8192,65,10588,13388,12556,10281,9304,8573,257,8493,5376,593]

theorem envBound18952 : H12AffineFastState.Bounded env18952 := by
  intro p hp
  have h : env18952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18951_18952 : H12AffineEnvironment.transform 16 5440 env18951 = env18952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env18951 == env18952) = true)

theorem identity18952 : scanCanonicalize (H12AffineFastState.compose env18952 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18952 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env18953 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8232,34,5173,2048,1025,8233,12393,8200,8296,8234,8192,65,10281,13388,12409,10281,9304,8200,116,8280,5237,593]

theorem envBound18953 : H12AffineFastState.Bounded env18953 := by
  intro p hp
  have h : env18953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18952_18953 : H12AffineEnvironment.transform 7 117 env18952 = env18953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18952 == env18953) = true)

theorem identity18953 : scanCanonicalize (H12AffineFastState.compose env18953 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18953 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18954 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,34,5173,2048,1025,1,4161,32,64,2,40,65,2049,5220,4177,2049,1136,32,116,112,5237,593]

theorem envBound18954 : H12AffineFastState.Bounded env18954 := by
  intro p hp
  have h : env18954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18953_18954 : H12AffineEnvironment.transform 12 40 env18953 = env18954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18953 == env18954) = true)

def env18955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58397,21792,8388608,21762,8193,65,8546652,57677,8433997,8568104,8389956,21793,257,8429932,8405056,8451661]

theorem envBound18955 : H12AffineFastState.Bounded env18955 := by
  intro p hp
  have h : env18955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18947_18955 : H12AffineEnvironment.transform 6 9 env18947 = env18955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18947 == env18955) = true)

theorem identity18955 : scanCanonicalize (H12AffineFastState.compose env18955 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 62540) := by decide +kernel

theorem selectedBound18955 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58397,21792,62540,21762,8193,65,171280,57677,17665,149860,61704,21793,257,21792,46092,513]

theorem envBound18956 : H12AffineFastState.Bounded env18956 := by
  intro p hp
  have h : env18956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18955_18956 : H12AffineEnvironment.transform 22 62540 env18955 = env18956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env18955 == env18956) = true)

theorem identity18956 : scanCanonicalize (H12AffineFastState.compose env18956 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18956 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4160,21792,17,21762,8193,65,158029,5392,17665,149860,1365,21793,257,21792,16465,513]

theorem envBound18957 : H12AffineFastState.Bounded env18957 := by
  intro p hp
  have h : env18957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18956_18957 : H12AffineEnvironment.transform 14 29789 env18956 = env18957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18956 == env18957) = true)

theorem identity18957 : scanCanonicalize (H12AffineFastState.compose env18957 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18957 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,5393,32041,1025,29788,4160,21792,17,21762,8193,65,31836,5392,17665,23669,1365,21793,257,21792,16465,513]

theorem envBound18958 : H12AffineFastState.Bounded env18958 := by
  intro p hp
  have h : env18958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18957_18958 : H12AffineEnvironment.transform 16 5393 env18957 = env18958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18957 == env18958) = true)

theorem identity18958 : scanCanonicalize (H12AffineFastState.compose env18958 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18958 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,262,5393,23588,1025,21841,4160,21792,17,21762,268,65,23889,5392,17665,23669,1365,21793,257,21792,16465,513]

theorem envBound18959 : H12AffineFastState.Bounded env18959 := by
  intro p hp
  have h : env18959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18958_18959 : H12AffineEnvironment.transform 12 269 env18958 = env18959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18958 == env18959) = true)

theorem identity18959 : scanCanonicalize (H12AffineFastState.compose env18959 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 1541) := by decide +kernel

theorem selectedBound18959 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env18960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,1541,4949,262,5393,6689,1025,4948,4160,4901,17,4871,268,65,6996,5392,772,6768,1365,4900,257,4901,1620,513]

theorem envBound18960 : H12AffineFastState.Bounded env18960 := by
  intro p hp
  have h : env18960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18959_18960 : H12AffineEnvironment.transform 13 1541 env18959 = env18960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1541 env18959 == env18960) = true)

theorem identity18960 : scanCanonicalize (H12AffineFastState.compose env18960 (packedSelected [0,2,6,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1857) := by decide +kernel

theorem selectedBound18960 : packedSelected [0,2,6,9,10,12] rootPS < 2^1333 := by decide +kernel

def env18961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1857,269,1541,1044,262,592,3424,1025,1045,1793,1124,17,1094,268,65,3093,593,772,3377,1365,1125,257,1124,1620,513]

theorem envBound18961 : H12AffineFastState.Bounded env18961 := by
  intro p hp
  have h : env18961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18960_18961 : H12AffineEnvironment.transform 11 1857 env18960 = env18961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1857 env18960 == env18961) = true)

theorem identity18961 : scanCanonicalize (H12AffineFastState.compose env18961 (packedSelected [0,3,5,9,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound18961 : packedSelected [0,3,5,9,18] rootPS < 2^1333 := by decide +kernel

def env18962 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,804,269,608,113,262,592,2309,100,112,868,1,17,35,268,65,2160,593,772,2388,304,0,257,1,561,513]

theorem envBound18962 : H12AffineFastState.Bounded env18962 := by
  intro p hp
  have h : env18962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18961_18962 : H12AffineEnvironment.transform 9 101 env18961 = env18962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env18961 == env18962) = true)

theorem identity18962 : scanCanonicalize (H12AffineFastState.compose env18962 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 837) := by decide +kernel

theorem selectedBound18962 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env18963 : List Nat := [2,4,8,16,32,64,9,256,512,101,837,804,269,608,113,262,592,576,100,112,868,1,17,35,268,65,821,593,772,529,304,0,257,1,561,513]

theorem envBound18963 : H12AffineFastState.Bounded env18963 := by
  intro p hp
  have h : env18963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18962_18963 : H12AffineEnvironment.transform 10 837 env18962 = env18963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 837 env18962 == env18963) = true)

theorem identity18963 : scanCanonicalize (H12AffineFastState.compose env18963 (packedSelected [2,6,23] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18963 : packedSelected [2,6,23] rootPS < 2^1333 := by decide +kernel

def env18964 : List Nat := [2,4,8,16,0,64,9,256,512,69,837,772,269,576,81,262,592,576,68,80,836,1,17,3,268,65,789,593,772,529,272,0,257,1,529,513]

theorem envBound18964 : H12AffineFastState.Bounded env18964 := by
  intro p hp
  have h : env18964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18963_18964 : H12AffineEnvironment.transform 4 0 env18963 = env18964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18963 == env18964) = true)

theorem identity18964 : scanCanonicalize (H12AffineFastState.compose env18964 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound18964 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18965 : List Nat := [2,4,8,16,0,64,9,30,512,69,603,538,19,576,81,24,592,576,68,80,602,1,17,3,18,65,523,593,538,529,14,0,31,1,529,513]

theorem envBound18965 : H12AffineFastState.Bounded env18965 := by
  intro p hp
  have h : env18965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18964_18965 : H12AffineEnvironment.transform 7 30 env18964 = env18965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env18964 == env18965) = true)

theorem identity18965 : scanCanonicalize (H12AffineFastState.compose env18965 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound18965 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18966 : List Nat := [2,4,8,16,0,64,9,30,75,69,16,81,19,11,81,24,27,11,68,80,17,1,17,3,18,65,64,26,81,90,14,0,31,1,90,74]

theorem envBound18966 : H12AffineFastState.Bounded env18966 := by
  intro p hp
  have h : env18966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18965_18966 : H12AffineEnvironment.transform 8 75 env18965 = env18966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env18965 == env18966) = true)

theorem identity18966 : scanCanonicalize (H12AffineFastState.compose env18966 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound18966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18967 : List Nat := [1,4,8,16,0,64,9,29,72,69,16,81,16,8,81,24,24,8,68,80,17,1,17,0,17,65,64,25,81,89,13,0,28,1,89,73]

theorem envBound18967 : H12AffineFastState.Bounded env18967 := by
  intro p hp
  have h : env18967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18966_18967 : H12AffineEnvironment.transform 0 1 env18966 = env18967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env18966 == env18967) = true)

theorem identity18967 : scanCanonicalize (H12AffineFastState.compose env18967 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18967 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18968 : List Nat := [1,4,8,16,0,17,9,29,25,20,16,0,16,8,0,24,24,8,21,1,17,1,17,0,17,16,17,25,0,8,13,0,28,1,8,24]

theorem envBound18968 : H12AffineFastState.Bounded env18968 := by
  intro p hp
  have h : env18968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18967_18968 : H12AffineEnvironment.transform 5 17 env18967 = env18968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18967 == env18968) = true)

theorem identity18968 : scanCanonicalize (H12AffineFastState.compose env18968 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound18968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18969 : List Nat := [1,1,8,16,0,17,9,24,25,17,16,0,16,8,0,24,24,8,16,1,17,1,17,0,17,16,17,25,0,8,8,0,25,1,8,24]

theorem envBound18969 : H12AffineFastState.Bounded env18969 := by
  intro p hp
  have h : env18969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18968_18969 : H12AffineEnvironment.transform 1 1 env18968 = env18969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env18968 == env18969) = true)

theorem identity18969 : scanCanonicalize (H12AffineFastState.compose env18969 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound18969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18970 : List Nat := [1,1,1,16,0,17,0,17,16,17,16,0,16,1,0,17,17,1,16,1,17,1,17,0,17,16,17,16,0,1,1,0,16,1,1,17]

theorem envBound18970 : H12AffineFastState.Bounded env18970 := by
  intro p hp
  have h : env18970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18969_18970 : H12AffineEnvironment.transform 2 1 env18969 = env18970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env18969 == env18970) = true)

def env18971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98781,8328,65,8546653,79131,8480027,8568225,8390093,98678,257,8484154,8492191,8462875]

theorem envBound18971 : H12AffineFastState.Bounded env18971 := by
  intro p hp
  have h : env18971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18945_18971 : H12AffineEnvironment.transform 21 21793 env18945 = env18971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env18945 == env18971) = true)

theorem identity18971 : scanCanonicalize (H12AffineFastState.compose env18971 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound18971 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,120014,98781,8328,65,245139,79131,45525,223599,119043,98678,257,41460,16465,63189]

theorem envBound18972 : H12AffineFastState.Bounded env18972 := by
  intro p hp
  have h : env18972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18971_18972 : H12AffineEnvironment.transform 22 120014 env18971 = env18972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env18971 == env18972) = true)

def env18973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10400,1025,32769,77899,33,98766,98781,8328,65,245139,79131,45525,212079,99331,98678,257,41460,5457,41941]

theorem envBound18973 : H12AffineFastState.Bounded env18973 := by
  intro p hp
  have h : env18973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18972_18973 : H12AffineEnvironment.transform 13 5376 env18972 = env18973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18972 == env18973) = true)

theorem identity18973 : scanCanonicalize (H12AffineFastState.compose env18973 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound18973 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46277,10400,1025,32769,77899,33,98766,98781,8328,65,67926,79131,45525,100522,99331,98678,257,41460,5457,41941]

theorem envBound18974 : H12AffineFastState.Bounded env18974 := by
  intro p hp
  have h : env18974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18973_18974 : H12AffineEnvironment.transform 16 46277 env18973 = env18974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env18973 == env18974) = true)

theorem identity18974 : scanCanonicalize (H12AffineFastState.compose env18974 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18974 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env18975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,46277,10400,1025,32769,4160,33,41413,41430,8328,65,10589,5392,45525,43169,41992,41341,257,41460,5457,41941]

theorem envBound18975 : H12AffineFastState.Bounded env18975 := by
  intro p hp
  have h : env18975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18974_18975 : H12AffineEnvironment.transform 15 8203 env18974 = env18975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18974 == env18975) = true)

theorem identity18975 : scanCanonicalize (H12AffineFastState.compose env18975 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound18975 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,5393,10400,1025,8661,4160,33,17,2,8328,65,10589,5392,4097,2421,1500,169,257,32,5457,513]

theorem envBound18976 : H12AffineFastState.Bounded env18976 := by
  intro p hp
  have h : env18976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18975_18976 : H12AffineEnvironment.transform 14 8660 env18975 = env18976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env18975 == env18976) = true)

theorem identity18976 : scanCanonicalize (H12AffineFastState.compose env18976 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18976 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,342,5393,2557,1025,136,4160,33,17,2,469,65,2048,5392,4097,2421,1500,169,257,32,5457,513]

theorem envBound18977 : H12AffineFastState.Bounded env18977 := by
  intro p hp
  have h : env18977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18976_18977 : H12AffineEnvironment.transform 12 349 env18976 = env18977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18976 == env18977) = true)

theorem identity18977 : scanCanonicalize (H12AffineFastState.compose env18977 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(8+1) ^^^ 200) := by decide +kernel

theorem selectedBound18977 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env18978 : List Nat := [2,4,8,16,32,64,128,256,200,1024,2048,4096,349,5376,137,342,5393,2557,1025,136,4160,33,17,2,469,65,2048,5392,4097,2421,1500,169,257,32,5457,201]

theorem envBound18978 : H12AffineFastState.Bounded env18978 := by
  intro p hp
  have h : env18978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18977_18978 : H12AffineEnvironment.transform 8 200 env18977 = env18978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 200 env18977 == env18978) = true)

theorem identity18978 : scanCanonicalize (H12AffineFastState.compose env18978 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18978 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env18979 : List Nat := [2,4,8,16,32,64,128,256,200,272,2048,4096,349,4112,137,342,4097,2557,273,136,4160,33,17,2,469,65,2048,4096,4097,2421,204,169,257,32,4161,201]

theorem envBound18979 : H12AffineFastState.Bounded env18979 := by
  intro p hp
  have h : env18979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18978_18979 : H12AffineEnvironment.transform 9 272 env18978 = env18979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18978 == env18979) = true)

theorem identity18979 : scanCanonicalize (H12AffineFastState.compose env18979 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound18979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18980 : List Nat := [2,4,8,16,32,64,128,237,200,253,2048,4096,176,4112,137,187,4097,2064,252,136,4160,33,17,2,56,65,2048,4096,4097,2200,204,169,236,32,4161,201]

theorem envBound18980 : H12AffineFastState.Bounded env18980 := by
  intro p hp
  have h : env18980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18979_18980 : H12AffineEnvironment.transform 7 237 env18979 = env18980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env18979 == env18980) = true)

theorem identity18980 : scanCanonicalize (H12AffineFastState.compose env18980 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18980 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18981 : List Nat := [2,4,8,16,32,64,8,101,64,117,2048,4096,56,4112,1,51,4097,2064,116,0,4160,33,17,2,56,65,2048,4096,4097,2064,68,33,100,32,4161,65]

theorem envBound18981 : H12AffineFastState.Bounded env18981 := by
  intro p hp
  have h : env18981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18980_18981 : H12AffineEnvironment.transform 6 8 env18980 = env18981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18980 == env18981) = true)

theorem identity18981 : scanCanonicalize (H12AffineFastState.compose env18981 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18981 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18982 : List Nat := [2,4,8,16,32,17,8,52,17,36,2048,4096,56,4112,1,51,4097,2064,37,0,4113,33,17,2,56,16,2048,4096,4097,2064,21,33,53,32,4112,16]

theorem envBound18982 : H12AffineFastState.Bounded env18982 := by
  intro p hp
  have h : env18982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18981_18982 : H12AffineEnvironment.transform 5 17 env18981 = env18982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18981 == env18982) = true)

theorem identity18982 : scanCanonicalize (H12AffineFastState.compose env18982 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound18982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18983 : List Nat := [2,4,8,11,32,10,8,47,10,36,2048,4096,35,4107,1,40,4097,2059,37,0,4106,33,10,2,35,11,2048,4096,4097,2059,14,33,46,32,4107,11]

theorem envBound18983 : H12AffineFastState.Bounded env18983 := by
  intro p hp
  have h : env18983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18982_18983 : H12AffineEnvironment.transform 3 11 env18982 = env18983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env18982 == env18983) = true)

theorem identity18983 : scanCanonicalize (H12AffineFastState.compose env18983 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18984 : List Nat := [2,4,3,0,32,1,3,36,1,36,2048,4096,35,4096,1,35,4097,2048,37,0,4097,33,1,2,35,0,2048,4096,4097,2048,5,33,37,32,4096,0]

theorem envBound18984 : H12AffineFastState.Bounded env18984 := by
  intro p hp
  have h : env18984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18983_18984 : H12AffineEnvironment.transform 2 3 env18983 = env18984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18983 == env18984) = true)

theorem identity18984 : scanCanonicalize (H12AffineFastState.compose env18984 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18985 : List Nat := [2,4,3,0,32,1,3,36,1,36,0,4096,35,4096,1,35,4097,0,37,0,4097,33,1,2,35,0,0,4096,4097,0,5,33,37,32,4096,0]

theorem envBound18985 : H12AffineFastState.Bounded env18985 := by
  intro p hp
  have h : env18985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18984_18985 : H12AffineEnvironment.transform 10 0 env18984 = env18985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18984 == env18985) = true)

def env18986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1025,32769,77899,32,98767,98781,8328,65,245139,79131,45525,212078,99330,98678,257,41460,5456,41940]

theorem envBound18986 : H12AffineFastState.Bounded env18986 := by
  intro p hp
  have h : env18986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18972_18986 : H12AffineEnvironment.transform 13 5377 env18972 = env18986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18972 == env18986) = true)

theorem identity18986 : scanCanonicalize (H12AffineFastState.compose env18986 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18986 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,98630,98644,8193,65,245018,79131,45404,212078,99330,98678,257,41341,5456,41821]

theorem envBound18987 : H12AffineFastState.Bounded env18987 := by
  intro p hp
  have h : env18987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18986_18987 : H12AffineEnvironment.transform 6 9 env18986 = env18987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18986 == env18987) = true)

theorem identity18987 : scanCanonicalize (H12AffineFastState.compose env18987 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18987 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,77899,32,73754,73736,8193,65,203846,79131,4096,212078,75102,73770,257,33,5456,513]

theorem envBound18988 : H12AffineFastState.Bounded env18988 := by
  intro p hp
  have h : env18988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18987_18988 : H12AffineEnvironment.transform 14 8540 env18987 = env18988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18987 == env18988) = true)

theorem identity18988 : scanCanonicalize (H12AffineFastState.compose env18988 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18988 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,131072,2421,1025,0,69910,32,65863,65877,348,65,203846,70726,4096,204083,66563,65911,257,33,5456,513]

theorem envBound18989 : H12AffineFastState.Bounded env18989 := by
  intro p hp
  have h : env18989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18988_18989 : H12AffineEnvironment.transform 12 349 env18988 = env18989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18988 == env18989) = true)

theorem identity18989 : scanCanonicalize (H12AffineFastState.compose env18989 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound18989 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,70726,2421,1025,0,69910,32,65863,65877,348,65,2048,70726,4096,2421,66563,65911,257,33,5456,513]

theorem envBound18990 : H12AffineFastState.Bounded env18990 := by
  intro p hp
  have h : env18990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18989_18990 : H12AffineEnvironment.transform 16 70726 env18989 = env18990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env18989 == env18990) = true)

theorem identity18990 : scanCanonicalize (H12AffineFastState.compose env18990 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18990 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1025,0,4160,32,17,3,348,65,2048,5392,4096,2421,1365,33,257,33,5456,513]

theorem envBound18991 : H12AffineFastState.Bounded env18991 := by
  intro p hp
  have h : env18991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18990_18991 : H12AffineEnvironment.transform 15 342 env18990 = env18991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18990 == env18991) = true)

theorem identity18991 : scanCanonicalize (H12AffineFastState.compose env18991 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound18991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18992 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,4096,349,4625,1,342,4608,2421,785,0,4160,32,17,3,348,65,2048,4608,4096,2421,581,33,257,33,4672,513]

theorem envBound18992 : H12AffineFastState.Bounded env18992 := by
  intro p hp
  have h : env18992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18991_18992 : H12AffineEnvironment.transform 9 784 env18991 = env18992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env18991 == env18992) = true)

theorem identity18992 : scanCanonicalize (H12AffineFastState.compose env18992 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound18992 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18993 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,885,349,356,1,342,373,2421,785,0,821,32,17,3,348,65,2048,373,885,2421,581,33,257,33,309,513]

theorem envBound18993 : H12AffineFastState.Bounded env18993 := by
  intro p hp
  have h : env18993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18992_18993 : H12AffineEnvironment.transform 11 885 env18992 = env18993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env18992 == env18993) = true)

theorem identity18993 : scanCanonicalize (H12AffineFastState.compose env18993 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18993 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18994 : List Nat := [2,4,8,16,32,64,9,116,512,612,2048,513,41,16,1,34,1,2049,613,0,577,32,17,3,40,65,2048,1,513,2049,581,33,117,33,65,513]

theorem envBound18994 : H12AffineFastState.Bounded env18994 := by
  intro p hp
  have h : env18994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18993_18994 : H12AffineEnvironment.transform 7 116 env18993 = env18994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18993 == env18994) = true)

theorem identity18994 : scanCanonicalize (H12AffineFastState.compose env18994 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound18994 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18995 : List Nat := [2,4,8,16,32,64,9,116,512,612,81,513,41,16,1,34,1,80,613,0,577,32,17,3,40,65,81,1,513,80,581,33,117,33,65,513]

theorem envBound18995 : H12AffineFastState.Bounded env18995 := by
  intro p hp
  have h : env18995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18994_18995 : H12AffineEnvironment.transform 10 81 env18994 = env18995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env18994 == env18995) = true)

theorem identity18995 : scanCanonicalize (H12AffineFastState.compose env18995 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound18995 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18996 : List Nat := [2,4,8,16,32,64,9,116,81,53,81,80,41,16,1,34,1,80,52,0,16,32,17,3,40,65,81,1,80,80,20,33,117,33,65,80]

theorem envBound18996 : H12AffineFastState.Bounded env18996 := by
  intro p hp
  have h : env18996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18995_18996 : H12AffineEnvironment.transform 8 81 env18995 = env18996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env18995 == env18996) = true)

theorem identity18996 : scanCanonicalize (H12AffineFastState.compose env18996 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18997 : List Nat := [2,4,8,1,32,64,9,101,64,36,64,65,41,1,1,34,1,65,37,0,1,32,0,3,40,65,64,1,65,65,5,33,100,33,65,65]

theorem envBound18997 : H12AffineFastState.Bounded env18997 := by
  intro p hp
  have h : env18997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18996_18997 : H12AffineEnvironment.transform 3 1 env18996 = env18997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18996 == env18997) = true)

def env18998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98780,8328,65,12729468,79131,8480026,8568224,8390092,4314199,257,8484154,8492191,8462874]

theorem envBound18998 : H12AffineFastState.Bounded env18998 := by
  intro p hp
  have h : env18998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18944_18998 : H12AffineEnvironment.transform 17 32161 env18944 = env18998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env18944 == env18998) = true)

def env18999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98780,8328,65,8546652,79131,8480026,8568224,8390092,98679,257,8484154,8492191,8462874]

theorem envBound18999 : H12AffineFastState.Bounded env18999 := by
  intro p hp
  have h : env18999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18998_18999 : H12AffineEnvironment.transform 21 21792 env18998 = env18999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env18998 == env18999) = true)

theorem identity18999 : scanCanonicalize (H12AffineFastState.compose env18999 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound18999 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,73755,98780,8328,65,215367,79131,17665,236987,75223,98679,257,21793,46212,513]

theorem envBound19000 : H12AffineFastState.Bounded env19000 := by
  intro p hp
  have h : env19000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18999_19000 : H12AffineEnvironment.transform 22 73755 env18999 = env19000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env18999 == env19000) = true)

def env19001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21792,73755,98644,8192,65,215367,79131,17665,236851,75103,98679,257,21793,46092,513]

theorem envBound19001 : H12AffineFastState.Bounded env19001 := by
  intro p hp
  have h : env19001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19000_19001 : H12AffineEnvironment.transform 6 8 env19000 = env19001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19000 == env19001) = true)

theorem identity19001 : scanCanonicalize (H12AffineFastState.compose env19001 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 91403) := by decide +kernel

theorem selectedBound19001 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,91403,32041,1025,32769,77898,21792,73755,98644,8192,65,11340,79131,17665,63544,75103,98679,257,21793,46092,513]

theorem envBound19002 : H12AffineFastState.Bounded env19002 := by
  intro p hp
  have h : env19002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19001_19002 : H12AffineEnvironment.transform 16 91403 env19001 = env19002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91403 env19001 == env19002) = true)

theorem identity19002 : scanCanonicalize (H12AffineFastState.compose env19002 (packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound19002 : packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env19003 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,65536,90138,30776,272,32769,77898,20529,73755,98644,8192,65,10589,77834,16400,63544,73806,98679,257,20528,45341,513]

theorem envBound19003 : H12AffineFastState.Bounded env19003 := by
  intro p hp
  have h : env19003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19002_19003 : H12AffineEnvironment.transform 9 273 env19002 = env19003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19002 == env19003) = true)

theorem identity19003 : scanCanonicalize (H12AffineFastState.compose env19003 (packedSelected [3,5,10,12,38] rootPS)) = affineNative (2^(15+1) ^^^ 53299) := by decide +kernel

theorem selectedBound19003 : packedSelected [3,5,10,12,38] rootPS < 2^1333 := by decide +kernel

def env19004 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,53299,45097,30776,272,32769,57465,20529,61480,20839,8192,65,10589,57401,16400,63544,61565,20804,257,20528,45341,513]

theorem envBound19004 : H12AffineFastState.Bounded env19004 := by
  intro p hp
  have h : env19004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19003_19004 : H12AffineEnvironment.transform 15 53299 env19003 = env19004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53299 env19003 == env19004) = true)

theorem identity19004 : scanCanonicalize (H12AffineFastState.compose env19004 (packedSelected [3,4,5,7,9,10,17,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound19004 : packedSelected [3,4,5,7,9,10,17,23,27,32] rootPS < 2^1333 := by decide +kernel

def env19005 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12572,32768,41263,45097,2340,272,32769,37221,8493,33076,8315,8192,65,10589,37157,12556,35108,33121,8280,257,8492,45341,513]

theorem envBound19005 : H12AffineFastState.Bounded env19005 := by
  intro p hp
  have h : env19005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19004_19005 : H12AffineEnvironment.transform 13 12572 env19004 = env19005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env19004 == env19005) = true)

theorem identity19005 : scanCanonicalize (H12AffineFastState.compose env19005 (packedSelected [2,3,5,6,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19005 : packedSelected [2,3,5,6,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env19006 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,32768,32803,37157,2340,272,32769,37221,33,33076,375,268,65,2129,37157,4096,35108,33121,340,257,32,36881,513]

theorem envBound19006 : H12AffineFastState.Bounded env19006 := by
  intro p hp
  have h : env19006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19005_19006 : H12AffineEnvironment.transform 12 268 env19005 = env19006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19005 == env19006) = true)

theorem identity19006 : scanCanonicalize (H12AffineFastState.compose env19006 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6208) := by decide +kernel

theorem selectedBound19006 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19007 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,6208,6243,2405,2340,272,6209,2341,33,6516,375,268,65,2129,2405,4096,4452,6433,340,257,32,2129,513]

theorem envBound19007 : H12AffineFastState.Bounded env19007 := by
  intro p hp
  have h : env19007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19006_19007 : H12AffineEnvironment.transform 14 6208 env19006 = env19007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6208 env19006 == env19007) = true)

theorem identity19007 : scanCanonicalize (H12AffineFastState.compose env19007 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19007 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env19008 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,40,4112,6208,6243,2113,2048,52,6209,2049,33,6224,83,40,65,2129,2113,4096,4160,6149,112,37,32,2129,513]

theorem envBound19008 : H12AffineFastState.Bounded env19008 := by
  intro p hp
  have h : env19008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19007_19008 : H12AffineEnvironment.transform 7 36 env19007 = env19008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19007 == env19008) = true)

theorem identity19008 : scanCanonicalize (H12AffineFastState.compose env19008 (packedSelected [4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound19008 : packedSelected [4,5,6] rootPS < 2^1333 := by decide +kernel

def env19009 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,625,40,609,2609,2578,2113,2048,52,2608,2049,33,2593,83,40,65,2129,2113,625,561,2676,112,37,32,2129,513]

theorem envBound19009 : H12AffineFastState.Bounded env19009 := by
  intro p hp
  have h : env19009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19008_19009 : H12AffineEnvironment.transform 11 625 env19008 = env19009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env19008 == env19009) = true)

theorem identity19009 : scanCanonicalize (H12AffineFastState.compose env19009 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound19009 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19010 : List Nat := [2,4,8,16,32,64,8,36,512,53,561,625,40,609,0,35,624,561,52,1,560,33,16,83,40,65,608,624,625,561,69,112,37,32,608,513]

theorem envBound19010 : H12AffineFastState.Bounded env19010 := by
  intro p hp
  have h : env19010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19009_19010 : H12AffineEnvironment.transform 10 561 env19009 = env19010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env19009 == env19010) = true)

theorem identity19010 : scanCanonicalize (H12AffineFastState.compose env19010 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound19010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19011 : List Nat := [2,4,8,16,32,64,8,36,48,53,1,65,40,81,0,35,64,1,52,1,0,33,16,83,40,65,80,64,65,1,69,112,37,32,80,49]

theorem envBound19011 : H12AffineFastState.Bounded env19011 := by
  intro p hp
  have h : env19011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19010_19011 : H12AffineEnvironment.transform 8 48 env19010 = env19011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env19010 == env19011) = true)

theorem identity19011 : scanCanonicalize (H12AffineFastState.compose env19011 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19011 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env19012 : List Nat := [2,4,8,16,32,17,8,36,48,53,1,16,40,0,0,35,17,1,52,1,0,33,16,2,40,16,1,17,16,1,20,33,37,32,1,49]

theorem envBound19012 : H12AffineFastState.Bounded env19012 := by
  intro p hp
  have h : env19012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19011_19012 : H12AffineEnvironment.transform 5 17 env19011 = env19012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19011 == env19012) = true)

theorem identity19012 : scanCanonicalize (H12AffineFastState.compose env19012 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19013 : List Nat := [2,4,8,16,17,17,8,21,1,4,1,16,25,0,0,18,17,1,5,1,0,16,16,2,25,16,1,17,16,1,20,16,20,17,1,0]

theorem envBound19013 : H12AffineFastState.Bounded env19013 := by
  intro p hp
  have h : env19013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19012_19013 : H12AffineEnvironment.transform 4 17 env19012 = env19013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19012 == env19013) = true)

def env19014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,73755,98645,8193,65,215367,79131,17665,236850,75102,98679,257,21793,46093,513]

theorem envBound19014 : H12AffineFastState.Bounded env19014 := by
  intro p hp
  have h : env19014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19000_19014 : H12AffineEnvironment.transform 6 9 env19000 = env19014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19000 == env19014) = true)

theorem identity19014 : scanCanonicalize (H12AffineFastState.compose env19014 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19014 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58396,21792,62541,21763,8193,65,171281,57677,17665,149860,61704,21793,257,21793,46093,513]

theorem envBound19015 : H12AffineFastState.Bounded env19015 := by
  intro p hp
  have h : env19015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19014_19015 : H12AffineEnvironment.transform 15 54358 env19014 = env19015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19014 == env19015) = true)

theorem identity19015 : scanCanonicalize (H12AffineFastState.compose env19015 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound19015 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env19016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46108,32040,1025,32769,58396,21792,62541,21763,8193,65,10509,57677,17665,64888,61704,21793,257,21793,46093,513]

theorem envBound19016 : H12AffineFastState.Bounded env19016 := by
  intro p hp
  have h : env19016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19015_19016 : H12AffineEnvironment.transform 16 46108 env19015 = env19016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env19015 == env19016) = true)

theorem identity19016 : scanCanonicalize (H12AffineFastState.compose env19016 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound19016 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env19017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,8282,16400,32040,1025,29709,4112,21792,65,21763,8193,65,10509,5441,17665,2420,1284,21793,257,21793,16385,513]

theorem envBound19017 : H12AffineFastState.Bounded env19017 := by
  intro p hp
  have h : env19017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19016_19017 : H12AffineEnvironment.transform 14 29708 env19016 = env19017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env19016 == env19017) = true)

theorem identity19017 : scanCanonicalize (H12AffineFastState.compose env19017 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19017 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19018 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,16400,32040,1025,29709,4112,21792,17,21763,8193,17,10509,5393,17665,2340,1284,21793,257,21793,16385,513]

theorem envBound19018 : H12AffineFastState.Bounded env19018 := by
  intro p hp
  have h : env19018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19017_19018 : H12AffineEnvironment.transform 5 16 env19017 = env19018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19017 == env19018) = true)

theorem identity19018 : scanCanonicalize (H12AffineFastState.compose env19018 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound19018 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env19019 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,300,16384,21792,294,16400,23556,1025,21793,4112,21792,17,21763,301,17,2081,5393,17665,2340,1284,21793,257,21793,16385,513]

theorem envBound19019 : H12AffineFastState.Bounded env19019 := by
  intro p hp
  have h : env19019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19018_19019 : H12AffineEnvironment.transform 12 300 env19018 = env19019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env19018 == env19019) = true)

theorem identity19019 : scanCanonicalize (H12AffineFastState.compose env19019 (packedSelected [0,2,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19019 : packedSelected [0,2,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19020 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,9,16384,21509,3,16400,23556,1025,21508,4112,21509,17,21542,8,17,2081,5172,17444,2049,1057,21508,36,21508,16385,513]

theorem envBound19020 : H12AffineFastState.Bounded env19020 := by
  intro p hp
  have h : env19020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19019_19020 : H12AffineEnvironment.transform 7 37 env19019 = env19020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19019 == env19020) = true)

def env19021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98780,8328,65,8546653,79131,8480026,8568224,8390092,98678,257,8484154,8492191,8462874]

theorem envBound19021 : H12AffineFastState.Bounded env19021 := by
  intro p hp
  have h : env19021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18998_19021 : H12AffineEnvironment.transform 21 21793 env18998 = env19021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env18998 == env19021) = true)

theorem identity19021 : scanCanonicalize (H12AffineFastState.compose env19021 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19021 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,8388608,41430,8328,65,8546653,5393,8406288,8568224,8390092,41340,257,8410416,8434837,8389136]

theorem envBound19022 : H12AffineFastState.Bounded env19022 := by
  intro p hp
  have h : env19022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19021_19022 : H12AffineEnvironment.transform 15 8202 env19021 = env19022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19021 == env19022) = true)

def env19023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,96,41430,8328,65,158013,5393,17776,179648,1452,41340,257,21840,46325,624]

theorem envBound19023 : H12AffineFastState.Bounded env19023 := by
  intro p hp
  have h : env19023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19022_19023 : H12AffineEnvironment.transform 22 96 env19022 = env19023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 96 env19022 == env19023) = true)

theorem identity19023 : scanCanonicalize (H12AffineFastState.compose env19023 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound19023 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,131072,2421,1025,32769,4160,8693,96,41430,8328,65,138729,5393,12708,179648,1452,41340,257,8580,46325,624]

theorem envBound19024 : H12AffineFastState.Bounded env19024 := by
  intro p hp
  have h : env19024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19023_19024 : H12AffineEnvironment.transform 13 13524 env19023 = env19024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env19023 == env19024) = true)

theorem identity19024 : scanCanonicalize (H12AffineFastState.compose env19024 (packedSelected [0,1,2,4,6,7,11,12,15,16,17,18,19,20,22,23,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46189) := by decide +kernel

theorem selectedBound19024 : packedSelected [0,1,2,4,6,7,11,12,15,16,17,18,19,20,22,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,46189,2421,1025,32769,4160,8693,96,41430,8328,65,43396,5393,12708,2477,1452,41340,257,8580,46325,624]

theorem envBound19025 : H12AffineFastState.Bounded env19025 := by
  intro p hp
  have h : env19025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19024_19025 : H12AffineEnvironment.transform 16 46189 env19024 = env19025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46189 env19024 == env19025) = true)

theorem identity19025 : scanCanonicalize (H12AffineFastState.compose env19025 (packedSelected [0,4,7,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19025 : packedSelected [0,4,7,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env19026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8541,8202,5424,2421,1025,8540,4160,8693,96,139,8328,65,2265,5393,12708,2477,1452,33,257,8580,5544,624]

theorem envBound19026 : H12AffineFastState.Bounded env19026 := by
  intro p hp
  have h : env19026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19025_19026 : H12AffineEnvironment.transform 14 8541 env19025 = env19026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19025 == env19026) = true)

theorem identity19026 : scanCanonicalize (H12AffineFastState.compose env19026 (packedSelected [0,1,4,6,7,8,9,10,11,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 6216) := by decide +kernel

theorem selectedBound19026 : packedSelected [0,1,4,6,7,8,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env19027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6216,3228,6421,6210,5424,2421,1025,6420,4160,6589,96,139,6336,65,2265,5393,2540,2477,1452,33,257,6604,5544,624]

theorem envBound19027 : H12AffineFastState.Bounded env19027 := by
  intro p hp
  have h : env19027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19026_19027 : H12AffineEnvironment.transform 12 6216 env19026 = env19027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6216 env19026 == env19027) = true)

theorem identity19027 : scanCanonicalize (H12AffineFastState.compose env19027 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19027 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env19028 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,6200,3228,6421,6194,5424,2309,1025,6420,4144,6589,16,139,6320,49,2217,5393,2460,2477,1452,33,257,6588,5544,512]

theorem envBound19028 : H12AffineFastState.Bounded env19028 := by
  intro p hp
  have h : env19028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19027_19028 : H12AffineEnvironment.transform 5 48 env19027 = env19028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19027 == env19028) = true)

theorem identity19028 : scanCanonicalize (H12AffineFastState.compose env19028 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound19028 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env19029 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,2324,300,3228,1,294,3108,2309,1025,0,2340,169,16,139,420,49,2217,3077,2460,2477,1452,33,257,168,3260,512]

theorem envBound19029 : H12AffineFastState.Bounded env19029 := by
  intro p hp
  have h : env19029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19028_19029 : H12AffineEnvironment.transform 11 2324 env19028 = env19029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env19028 == env19029) = true)

theorem identity19029 : scanCanonicalize (H12AffineFastState.compose env19029 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound19029 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env19030 : List Nat := [2,4,8,16,32,48,128,256,512,304,2048,2324,300,2476,1,294,2324,2309,305,0,2340,169,16,139,420,49,2217,2357,2460,2477,156,33,257,168,2444,512]

theorem envBound19030 : H12AffineFastState.Bounded env19030 := by
  intro p hp
  have h : env19030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19029_19030 : H12AffineEnvironment.transform 9 304 env19029 = env19030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env19029 == env19030) = true)

theorem identity19030 : scanCanonicalize (H12AffineFastState.compose env19030 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19030 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env19031 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,2324,300,2341,1,294,2324,2309,305,0,2340,32,16,2,301,49,2080,2357,2325,2340,21,33,257,33,2309,512]

theorem envBound19031 : H12AffineFastState.Bounded env19031 := by
  intro p hp
  have h : env19031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19030_19031 : H12AffineEnvironment.transform 6 9 env19030 = env19031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19030 == env19031) = true)

theorem identity19031 : scanCanonicalize (H12AffineFastState.compose env19031 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19032 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,2324,269,2308,1,263,2324,2309,272,0,2309,1,16,2,268,16,2049,2324,2325,2309,21,0,257,0,2309,512]

theorem envBound19032 : H12AffineFastState.Bounded env19032 := by
  intro p hp
  have h : env19032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19031_19032 : H12AffineEnvironment.transform 4 1 env19031 = env19032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19031 == env19032) = true)

def env19033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,97,41430,8328,65,158012,5393,17777,179649,1453,41340,257,21841,46324,625]

theorem envBound19033 : H12AffineFastState.Bounded env19033 := by
  intro p hp
  have h : env19033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19022_19033 : H12AffineEnvironment.transform 22 97 env19022 = env19033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 97 env19022 == env19033) = true)

theorem identity19033 : scanCanonicalize (H12AffineFastState.compose env19033 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13476) := by decide +kernel

theorem selectedBound19033 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13476,32768,8202,131072,2309,1025,32769,4160,8581,97,41430,8328,65,138648,5393,12757,179649,1453,41340,257,8693,46324,625]

theorem envBound19034 : H12AffineFastState.Bounded env19034 := by
  intro p hp
  have h : env19034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19033_19034 : H12AffineEnvironment.transform 13 13476 env19033 = env19034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13476 env19033 == env19034) = true)

theorem identity19034 : scanCanonicalize (H12AffineFastState.compose env19034 (packedSelected [3,5,8,10,11,16,18,20,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound19034 : packedSelected [3,5,8,10,11,16,18,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13476,32768,8202,13509,2309,1025,32769,4160,8581,97,41430,8328,65,10589,5393,12757,35076,1453,41340,257,8693,46324,625]

theorem envBound19035 : H12AffineFastState.Bounded env19035 := by
  intro p hp
  have h : env19035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19034_19035 : H12AffineEnvironment.transform 16 13509 env19034 = env19035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env19034 == env19035) = true)

theorem identity19035 : scanCanonicalize (H12AffineFastState.compose env19035 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19035 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env19036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5409,32768,399,5440,2309,1025,32769,4160,0,97,32851,269,65,2264,5393,4176,35076,1453,33017,257,112,38257,625]

theorem envBound19036 : H12AffineFastState.Bounded env19036 := by
  intro p hp
  have h : env19036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19035_19036 : H12AffineEnvironment.transform 12 389 env19035 = env19036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19035 == env19036) = true)

theorem identity19036 : scanCanonicalize (H12AffineFastState.compose env19036 (packedSelected [1,5,8,16,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19036 : packedSelected [1,5,8,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5409,81,399,5440,2309,1025,80,4160,0,97,2,269,65,2264,5393,4176,2389,1453,168,257,112,5408,625]

theorem envBound19037 : H12AffineFastState.Bounded env19037 := by
  intro p hp
  have h : env19037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19036_19037 : H12AffineEnvironment.transform 14 81 env19036 = env19037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19036 == env19037) = true)

theorem identity19037 : scanCanonicalize (H12AffineFastState.compose env19037 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19037 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env19038 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,129,5157,81,139,5188,2049,1025,80,4160,0,97,2,9,65,2264,5141,4176,2129,1193,168,5,112,5156,625]

theorem envBound19038 : H12AffineFastState.Bounded env19038 := by
  intro p hp
  have h : env19038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19037_19038 : H12AffineEnvironment.transform 7 4 env19037 = env19038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19037 == env19038) = true)

theorem identity19038 : scanCanonicalize (H12AffineFastState.compose env19038 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19038 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19039 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,129,5157,0,139,5141,2049,1025,1,4113,0,48,2,9,16,2185,5141,4097,2048,1193,168,5,33,5156,544]

theorem envBound19039 : H12AffineFastState.Bounded env19039 := by
  intro p hp
  have h : env19039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19038_19039 : H12AffineEnvironment.transform 5 17 env19038 = env19039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19038 == env19039) = true)

theorem identity19039 : scanCanonicalize (H12AffineFastState.compose env19039 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19039 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19040 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,41,5157,0,35,5141,2049,1025,1,4113,0,48,2,9,16,2081,5141,4097,2048,1025,0,5,33,5156,544]

theorem envBound19040 : H12AffineFastState.Bounded env19040 := by
  intro p hp
  have h : env19040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19039_19040 : H12AffineEnvironment.transform 6 40 env19039 = env19040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19039 == env19040) = true)

theorem identity19040 : scanCanonicalize (H12AffineFastState.compose env19040 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19040 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env19041 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,5125,0,3,5141,2049,1025,1,4113,0,16,2,9,16,2049,5141,4097,2048,1025,0,5,1,5124,512]

theorem envBound19041 : H12AffineFastState.Bounded env19041 := by
  intro p hp
  have h : env19041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19040_19041 : H12AffineEnvironment.transform 4 0 env19040 = env19041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19040 == env19041) = true)

theorem identity19041 : scanCanonicalize (H12AffineFastState.compose env19041 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound19041 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19042 : List Nat := [2,4,8,16,0,17,8,4,512,1024,522,4096,9,5125,0,3,5141,523,1025,1,4113,0,16,2,9,16,523,5141,4097,522,1025,0,5,1,5124,512]

theorem envBound19042 : H12AffineFastState.Bounded env19042 := by
  intro p hp
  have h : env19042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19041_19042 : H12AffineEnvironment.transform 10 522 env19041 = env19042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env19041 == env19042) = true)

def env19043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound19043 : H12AffineFastState.Bounded env19043 := by
  intro p hp
  have h : env19043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18593_19043 : H12AffineEnvironment.transform 26 30393345 env18593 = env19043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env18593 == env19043) = true)

def env19044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound19044 : H12AffineFastState.Bounded env19044 := by
  intro p hp
  have h : env19044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19043_19044 : H12AffineEnvironment.transform 18 1024 env19043 = env19044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19043 == env19044) = true)

theorem identity19044 : scanCanonicalize (H12AffineFastState.compose env19044 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 510123) := by decide +kernel

theorem selectedBound19044 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,510123,16777216,8328,65,20973738,18973836,2596347,67754,17190075,23160256,256,19270663,19328418,17263468]

theorem envBound19045 : H12AffineFastState.Bounded env19045 := by
  intro p hp
  have h : env19045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19044_19045 : H12AffineEnvironment.transform 22 510123 env19044 = env19045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 510123 env19044 == env19045) = true)

def env19046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,16777216,8328,65,16959642,18973836,2596347,67754,17190075,19113456,256,19270663,19328418,17263468]

theorem envBound19046 : H12AffineFastState.Bounded env19046 := by
  intro p hp
  have h : env19046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19045_19046 : H12AffineEnvironment.transform 21 180272 env19045 = env19046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env19045 == env19046) = true)

def env19047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,499128,8328,65,349474,2496820,2596347,67754,119043,2373704,256,2199999,2191386,63188]

theorem envBound19047 : H12AffineFastState.Bounded env19047 := by
  intro p hp
  have h : env19047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19046_19047 : H12AffineEnvironment.transform 23 499128 env19046 = env19047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env19046 == env19047) = true)

def env19048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510123,499128,8328,65,349474,395636,495035,67754,119043,272392,256,98815,90202,63188]

theorem envBound19048 : H12AffineFastState.Bounded env19048 := by
  intro p hp
  have h : env19048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19047_19048 : H12AffineEnvironment.transform 20 4160 env19047 = env19048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19047 == env19048) = true)

theorem identity19048 : scanCanonicalize (H12AffineFastState.compose env19048 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound19048 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180272,73755,95496,8328,65,245138,57796,91403,67754,119043,180408,256,98815,90202,63188]

theorem envBound19049 : H12AffineFastState.Bounded env19049 := by
  intro p hp
  have h : env19049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19048_19049 : H12AffineEnvironment.transform 17 190640 env19048 = env19049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env19048 == env19049) = true)

def env19050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1024,32769,4160,32,73755,95496,8328,65,97666,57796,91403,67754,119043,168,256,98815,90202,63188]

theorem envBound19050 : H12AffineFastState.Bounded env19050 := by
  intro p hp
  have h : env19050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19049_19050 : H12AffineEnvironment.transform 16 49168 env19049 = env19050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env19049 == env19050) = true)

theorem identity19050 : scanCanonicalize (H12AffineFastState.compose env19050 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 62710) := by decide +kernel

theorem selectedBound19050 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env19051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62710,49168,10400,1024,32769,4160,32,54509,33278,8328,65,35188,57796,37373,64604,9717,168,256,29961,38060,63188]

theorem envBound19051 : H12AffineFastState.Bounded env19051 := by
  intro p hp
  have h : env19051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19050_19051 : H12AffineEnvironment.transform 15 62710 env19050 = env19051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62710 env19050 == env19051) = true)

theorem identity19051 : scanCanonicalize (H12AffineFastState.compose env19051 (packedSelected [0,3,5,7,9,14,16,18,22,23,31,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound19051 : packedSelected [0,3,5,7,9,14,16,18,22,23,31,38,41] rootPS < 2^1333 := by decide +kernel

def env19052 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,62710,49168,10400,1024,32769,4160,32,54509,32770,8328,65,34952,57400,36865,64604,9225,168,252,29941,38060,63188]

theorem envBound19052 : H12AffineFastState.Bounded env19052 := by
  intro p hp
  have h : env19052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19051_19052 : H12AffineEnvironment.transform 7 252 env19051 = env19052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env19051 == env19052) = true)

theorem identity19052 : scanCanonicalize (H12AffineFastState.compose env19052 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21756) := by decide +kernel

theorem selectedBound19052 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19053 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,21756,8202,5356,10400,1024,21757,4160,32,17,21758,8328,65,23668,13508,17661,10400,9225,168,252,29941,16464,8744]

theorem envBound19053 : H12AffineFastState.Bounded env19053 := by
  intro p hp
  have h : env19053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19052_19053 : H12AffineEnvironment.transform 14 21756 env19052 = env19053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21756 env19052 == env19053) = true)

theorem identity19053 : scanCanonicalize (H12AffineFastState.compose env19053 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound19053 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env19054 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5156,216,8202,5356,10400,1024,217,4160,32,17,218,8328,65,2128,13508,4313,10400,9225,168,252,8401,5236,8744]

theorem envBound19054 : H12AffineFastState.Bounded env19054 := by
  intro p hp
  have h : env19054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19053_19054 : H12AffineEnvironment.transform 13 5156 env19053 = env19054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env19053 == env19054) = true)

theorem identity19054 : scanCanonicalize (H12AffineFastState.compose env19054 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19054 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19055 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5156,136,8202,5308,10400,1024,137,4112,32,17,138,8328,17,2048,13460,4233,10400,9225,168,172,8321,5156,8744]

theorem envBound19055 : H12AffineFastState.Bounded env19055 := by
  intro p hp
  have h : env19055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19054_19055 : H12AffineEnvironment.transform 5 16 env19054 = env19055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19054 == env19055) = true)

theorem identity19055 : scanCanonicalize (H12AffineFastState.compose env19055 (packedSelected [1,2,4,8,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound19055 : packedSelected [1,2,4,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19056 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1173,5156,136,1183,5308,3125,1024,137,4112,32,17,138,1053,17,2048,4097,4233,3125,156,168,172,1044,5156,1725]

theorem envBound19056 : H12AffineFastState.Bounded env19056 := by
  intro p hp
  have h : env19056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19055_19056 : H12AffineEnvironment.transform 12 1173 env19055 = env19056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env19055 == env19056) = true)

theorem identity19056 : scanCanonicalize (H12AffineFastState.compose env19056 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19056 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19057 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,4096,161,4112,136,171,4232,2049,52,137,4112,32,17,138,41,17,2048,4097,4233,2049,156,168,172,32,4112,649]

theorem envBound19057 : H12AffineFastState.Bounded env19057 := by
  intro p hp
  have h : env19057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19056_19057 : H12AffineEnvironment.transform 9 52 env19056 = env19057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19056 == env19057) = true)

theorem identity19057 : scanCanonicalize (H12AffineFastState.compose env19057 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19057 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19058 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,0,35,4096,2049,52,1,4112,32,17,2,41,17,2048,4097,4097,2049,20,32,36,32,4112,513]

theorem envBound19058 : H12AffineFastState.Bounded env19058 := by
  intro p hp
  have h : env19058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19057_19058 : H12AffineEnvironment.transform 6 8 env19057 = env19058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19057 == env19058) = true)

theorem identity19058 : scanCanonicalize (H12AffineFastState.compose env19058 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound19058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19059 : List Nat := [2,4,8,16,32,16,8,36,16,52,2048,4096,41,4112,0,35,4096,2049,52,1,4112,32,17,2,41,17,2048,4097,4097,2049,20,32,36,32,4112,17]

theorem envBound19059 : H12AffineFastState.Bounded env19059 := by
  intro p hp
  have h : env19059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19058_19059 : H12AffineEnvironment.transform 8 16 env19058 = env19059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env19058 == env19059) = true)

theorem identity19059 : scanCanonicalize (H12AffineFastState.compose env19059 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 59) := by decide +kernel

theorem selectedBound19059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19060 : List Nat := [2,4,8,16,32,16,8,36,16,52,2048,59,41,43,0,35,59,2049,52,1,43,32,17,2,41,17,2048,58,58,2049,20,32,36,32,43,17]

theorem envBound19060 : H12AffineFastState.Bounded env19060 := by
  intro p hp
  have h : env19060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19059_19060 : H12AffineEnvironment.transform 11 59 env19059 = env19060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 59 env19059 == env19060) = true)

def env19061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1024,32769,4160,33,73755,95496,8328,65,97667,57796,91403,67754,119043,169,256,98815,90202,63188]

theorem envBound19061 : H12AffineFastState.Bounded env19061 := by
  intro p hp
  have h : env19061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19049_19061 : H12AffineEnvironment.transform 16 49169 env19049 = env19061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env19049 == env19061) = true)

theorem identity19061 : scanCanonicalize (H12AffineFastState.compose env19061 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound19061 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env19062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,46157,10401,1024,32769,4160,33,73755,65876,8328,65,68063,38296,69975,67754,107871,169,256,98815,70662,33416]

theorem envBound19062 : H12AffineFastState.Bounded env19062 := by
  intro p hp
  have h : env19062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19061_19062 : H12AffineEnvironment.transform 13 13404 env19061 = env19062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env19061 == env19062) = true)

theorem identity19062 : scanCanonicalize (H12AffineFastState.compose env19062 (packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound19062 : packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env19063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,13508,10401,1024,136,4160,33,73755,65876,8328,65,68063,5393,69975,67754,75222,169,256,65910,70662,513]

theorem envBound19063 : H12AffineFastState.Bounded env19063 := by
  intro p hp
  have h : env19063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19062_19063 : H12AffineEnvironment.transform 14 137 env19062 = env19063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env19062 == env19063) = true)

theorem identity19063 : scanCanonicalize (H12AffineFastState.compose env19063 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound19063 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env19064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,65536,5393,2420,1024,136,4160,33,65998,65876,349,65,68063,5393,69975,67754,66563,169,256,65910,70662,513]

theorem envBound19064 : H12AffineFastState.Bounded env19064 := by
  intro p hp
  have h : env19064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19063_19064 : H12AffineEnvironment.transform 12 469 env19063 = env19064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env19063 == env19064) = true)

theorem identity19064 : scanCanonicalize (H12AffineFastState.compose env19064 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound19064 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,478,5393,2420,1024,136,4160,33,16,138,349,65,2049,5393,4233,2420,1501,169,256,168,5592,513]

theorem envBound19065 : H12AffineFastState.Bounded env19065 := by
  intro p hp
  have h : env19065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19064_19065 : H12AffineEnvironment.transform 15 478 env19064 = env19065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env19064 == env19065) = true)

theorem identity19065 : scanCanonicalize (H12AffineFastState.compose env19065 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19065 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2420,1024,1,4160,33,16,3,349,65,2049,5393,4096,2420,1364,32,256,33,5457,513]

theorem envBound19066 : H12AffineFastState.Bounded env19066 := by
  intro p hp
  have h : env19066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19065_19066 : H12AffineEnvironment.transform 6 9 env19065 = env19066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19065 == env19066) = true)

theorem identity19066 : scanCanonicalize (H12AffineFastState.compose env19066 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound19066 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,292,0,343,309,2420,1024,1,1124,33,16,3,349,65,2049,309,1060,2420,1364,32,256,33,373,513]

theorem envBound19067 : H12AffineFastState.Bounded env19067 := by
  intro p hp
  have h : env19067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19066_19067 : H12AffineEnvironment.transform 11 1060 env19066 = env19067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env19066 == env19067) = true)

theorem identity19067 : scanCanonicalize (H12AffineFastState.compose env19067 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19067 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1060,348,292,0,343,309,1124,1024,1,1124,33,16,3,349,65,1297,309,1060,1124,1364,32,256,33,373,513]

theorem envBound19068 : H12AffineFastState.Bounded env19068 := by
  intro p hp
  have h : env19068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19067_19068 : H12AffineEnvironment.transform 10 1296 env19067 = env19068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env19067 == env19068) = true)

theorem identity19068 : scanCanonicalize (H12AffineFastState.compose env19068 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound19068 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19069 : List Nat := [2,4,8,16,32,32,9,256,512,1024,1296,1060,316,292,0,311,309,1028,1024,1,1028,33,16,3,317,33,1297,309,1060,1028,1332,32,256,33,277,513]

theorem envBound19069 : H12AffineFastState.Bounded env19069 := by
  intro p hp
  have h : env19069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19068_19069 : H12AffineEnvironment.transform 5 32 env19068 = env19069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env19068 == env19069) = true)

theorem identity19069 : scanCanonicalize (H12AffineFastState.compose env19069 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound19069 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env19070 : List Nat := [2,4,8,16,32,32,9,256,293,1024,1296,1060,316,292,0,311,309,1028,1024,1,1028,33,16,3,317,33,1297,309,1060,1028,1332,32,256,33,277,292]

theorem envBound19070 : H12AffineFastState.Bounded env19070 := by
  intro p hp
  have h : env19070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19069_19070 : H12AffineEnvironment.transform 8 293 env19069 = env19070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env19069 == env19070) = true)

theorem identity19070 : scanCanonicalize (H12AffineFastState.compose env19070 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19070 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19071 : List Nat := [2,4,8,16,1,1,9,256,260,1024,1296,1029,285,261,0,278,276,1028,1024,1,1028,0,16,3,284,0,1297,276,1029,1028,1301,1,256,0,277,261]

theorem envBound19071 : H12AffineFastState.Bounded env19071 := by
  intro p hp
  have h : env19071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19070_19071 : H12AffineEnvironment.transform 4 1 env19070 = env19071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19070 == env19071) = true)

theorem identity19071 : scanCanonicalize (H12AffineFastState.compose env19071 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19071 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env19072 : List Nat := [2,4,8,1,1,1,9,256,260,1024,1281,1029,268,261,0,263,261,1028,1024,1,1028,0,1,3,269,0,1280,261,1029,1028,1284,1,256,0,260,261]

theorem envBound19072 : H12AffineFastState.Bounded env19072 := by
  intro p hp
  have h : env19072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19071_19072 : H12AffineEnvironment.transform 3 1 env19071 = env19072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19071 == env19072) = true)

theorem identity19072 : scanCanonicalize (H12AffineFastState.compose env19072 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound19072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19073 : List Nat := [2,4,8,1,1,1,9,256,260,256,1,261,268,261,0,263,261,260,256,1,260,0,1,3,269,0,0,261,261,260,4,1,256,0,260,261]

theorem envBound19073 : H12AffineFastState.Bounded env19073 := by
  intro p hp
  have h : env19073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19072_19073 : H12AffineEnvironment.transform 9 256 env19072 = env19073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env19072 == env19073) = true)

theorem identity19073 : scanCanonicalize (H12AffineFastState.compose env19073 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19074 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,1,8,1,0,3,1,0,4,1,0,0,1,3,9,0,0,1,1,0,4,1,4,0,0,1]

theorem envBound19074 : H12AffineFastState.Bounded env19074 := by
  intro p hp
  have h : env19074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19073_19074 : H12AffineEnvironment.transform 7 4 env19073 = env19074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19073 == env19074) = true)

def env19075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510123,499128,8328,65,349474,395637,495034,67754,119043,272393,256,98814,90203,63188]

theorem envBound19075 : H12AffineFastState.Bounded env19075 := by
  intro p hp
  have h : env19075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19047_19075 : H12AffineEnvironment.transform 20 4161 env19047 = env19075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19047 == env19075) = true)

def env19076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,180272,253963,242968,8328,65,97666,139733,238874,67754,119043,169,256,98814,90203,63188]

theorem envBound19076 : H12AffineFastState.Bounded env19076 := by
  intro p hp
  have h : env19076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19075_19076 : H12AffineEnvironment.transform 17 10400 env19075 = env19076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19075 == env19076) = true)

def env19077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180272,253963,242968,8192,65,97546,139613,238874,67618,119043,33,256,98678,90203,63068]

theorem envBound19077 : H12AffineFastState.Bounded env19077 := by
  intro p hp
  have h : env19077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19076_19077 : H12AffineEnvironment.transform 6 8 env19076 = env19077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19076 == env19077) = true)

theorem identity19077 : scanCanonicalize (H12AffineFastState.compose env19077 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound19077 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1024,32769,4161,95530,21777,2,8192,65,97546,103495,4096,67618,119043,33,256,98678,90203,63068]

theorem envBound19078 : H12AffineFastState.Bounded env19078 := by
  intro p hp
  have h : env19078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19077_19078 : H12AffineEnvironment.transform 16 111898 env19077 = env19078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env19077 == env19078) = true)

theorem identity19078 : scanCanonicalize (H12AffineFastState.compose env19078 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19078 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,103495,2421,1024,32769,4161,87159,21777,2,349,65,89175,103495,4096,67618,119043,33,256,98678,82182,55041]

theorem envBound19079 : H12AffineFastState.Bounded env19079 := by
  intro p hp
  have h : env19079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19078_19079 : H12AffineEnvironment.transform 12 349 env19078 = env19079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19078 == env19079) = true)

theorem identity19079 : scanCanonicalize (H12AffineFastState.compose env19079 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound19079 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,38160,2421,1024,32769,4161,21792,21777,2,349,65,23808,38160,4096,2421,53332,33,256,32801,16465,55041]

theorem envBound19080 : H12AffineFastState.Bounded env19080 := by
  intro p hp
  have h : env19080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19079_19080 : H12AffineEnvironment.transform 15 343 env19079 = env19080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env19079 == env19080) = true)

theorem identity19080 : scanCanonicalize (H12AffineFastState.compose env19080 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19080 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,343,5441,2421,1024,80,4161,21792,21777,2,349,65,23808,5441,4096,2421,20485,33,256,112,16465,22352]

theorem envBound19081 : H12AffineFastState.Bounded env19081 := by
  intro p hp
  have h : env19081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19080_19081 : H12AffineEnvironment.transform 14 81 env19080 = env19081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19080 == env19081) = true)

theorem identity19081 : scanCanonicalize (H12AffineFastState.compose env19081 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19081 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19082 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,81,115,5221,2129,1024,80,4161,21508,21557,2,121,65,23588,5221,4096,2129,20485,33,36,112,16465,22132]

theorem envBound19082 : H12AffineFastState.Bounded env19082 := by
  intro p hp
  have h : env19082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19081_19082 : H12AffineEnvironment.transform 7 36 env19081 = env19082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19081 == env19082) = true)

theorem identity19082 : scanCanonicalize (H12AffineFastState.compose env19082 (packedSelected [3,5,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound19082 : packedSelected [3,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19083 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,3173,81,115,5221,2129,1024,80,4161,6241,6224,2,121,65,4161,5221,4096,2129,7264,33,36,112,3124,6673]

theorem envBound19083 : H12AffineFastState.Bounded env19083 := by
  intro p hp
  have h : env19083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19082_19083 : H12AffineEnvironment.transform 13 3173 env19082 = env19083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env19082 == env19083) = true)

theorem identity19083 : scanCanonicalize (H12AffineFastState.compose env19083 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19083 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env19084 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,121,3173,81,115,3108,2129,1024,80,2048,32,17,2,121,65,2048,3108,2113,2129,1057,33,36,112,3124,592]

theorem envBound19084 : H12AffineFastState.Bounded env19084 := by
  intro p hp
  have h : env19084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19083_19084 : H12AffineEnvironment.transform 11 2113 env19083 = env19084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19083 == env19084) = true)

theorem identity19084 : scanCanonicalize (H12AffineFastState.compose env19084 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19084 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19085 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,41,3125,1,35,3108,2049,1024,0,2048,32,17,2,41,17,2048,3108,2065,2049,1057,33,36,32,3124,512]

theorem envBound19085 : H12AffineFastState.Bounded env19085 := by
  intro p hp
  have h : env19085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19084_19085 : H12AffineEnvironment.transform 5 16 env19084 = env19085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19084 == env19085) = true)

theorem identity19085 : scanCanonicalize (H12AffineFastState.compose env19085 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound19085 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19086 : List Nat := [2,4,8,16,32,16,8,36,512,20,2048,2065,41,2081,1,35,2096,2049,20,0,2048,32,17,2,41,17,2048,2096,2065,2049,53,33,36,32,2080,512]

theorem envBound19086 : H12AffineFastState.Bounded env19086 := by
  intro p hp
  have h : env19086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19085_19086 : H12AffineEnvironment.transform 9 20 env19085 = env19086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19085 == env19086) = true)

theorem identity19086 : scanCanonicalize (H12AffineFastState.compose env19086 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19086 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19087 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2065,8,2048,1,2,2065,2049,20,0,2048,1,17,2,8,17,2048,2065,2065,2049,20,0,5,1,2049,512]

theorem envBound19087 : H12AffineFastState.Bounded env19087 := by
  intro p hp
  have h : env19087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19086_19087 : H12AffineEnvironment.transform 4 1 env19086 = env19087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19086 == env19087) = true)

theorem identity19087 : scanCanonicalize (H12AffineFastState.compose env19087 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19087 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19088 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,2065,8,2048,1,2,2065,2049,20,0,2048,1,17,2,8,17,2048,2065,2065,2049,20,0,5,1,2049,1]

theorem envBound19088 : H12AffineFastState.Bounded env19088 := by
  intro p hp
  have h : env19088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19087_19088 : H12AffineEnvironment.transform 8 1 env19087 = env19088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19087 == env19088) = true)

theorem identity19088 : scanCanonicalize (H12AffineFastState.compose env19088 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound19088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19089 : List Nat := [2,4,8,16,1,16,8,5,1,20,14,31,8,14,1,2,31,15,20,0,14,1,17,2,8,17,14,31,31,15,20,0,5,1,15,1]

theorem envBound19089 : H12AffineFastState.Bounded env19089 := by
  intro p hp
  have h : env19089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19088_19089 : H12AffineEnvironment.transform 10 14 env19088 = env19089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env19088 == env19089) = true)

def env19090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180272,253963,242968,8193,65,97547,139612,238874,67619,119043,32,256,98679,90203,63069]

theorem envBound19090 : H12AffineFastState.Bounded env19090 := by
  intro p hp
  have h : env19090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19076_19090 : H12AffineEnvironment.transform 6 9 env19076 = env19090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19076 == env19090) = true)

theorem identity19090 : scanCanonicalize (H12AffineFastState.compose env19090 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound19090 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1024,32769,4161,119926,62541,41310,8193,65,97547,79130,45404,67619,119043,32,256,98679,90203,63069]

theorem envBound19091 : H12AffineFastState.Bounded env19091 := by
  intro p hp
  have h : env19091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19090_19091 : H12AffineEnvironment.transform 16 70726 env19090 = env19091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env19090 == env19091) = true)

theorem identity19091 : scanCanonicalize (H12AffineFastState.compose env19091 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19091 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env19092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,70726,10281,1024,8541,4161,95530,21777,2,8193,65,97547,79130,4096,67619,94303,32,256,73771,90203,22273]

theorem envBound19092 : H12AffineFastState.Bounded env19092 := by
  intro p hp
  have h : env19092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19091_19092 : H12AffineEnvironment.transform 14 8540 env19091 = env19092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19091 == env19092) = true)

theorem identity19092 : scanCanonicalize (H12AffineFastState.compose env19092 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19092 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env19093 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,65536,70726,10281,1024,8541,4161,74078,357,2,8193,65,76159,79130,4096,67619,74795,32,256,73771,78895,885]

theorem envBound19093 : H12AffineFastState.Bounded env19093 := by
  intro p hp
  have h : env19093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19092_19093 : H12AffineEnvironment.transform 13 5236 env19092 = env19093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19092 == env19093) = true)

theorem identity19093 : scanCanonicalize (H12AffineFastState.compose env19093 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound19093 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env19094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,1047,4177,10281,1024,8541,4161,9545,357,2,8193,65,11624,12557,4096,3124,8252,32,256,9276,12344,885]

theorem envBound19094 : H12AffineFastState.Bounded env19094 := by
  intro p hp
  have h : env19094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19093_19094 : H12AffineEnvironment.transform 15 1047 env19093 = env19094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env19093 == env19094) = true)

theorem identity19094 : scanCanonicalize (H12AffineFastState.compose env19094 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19094 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,372,1047,4177,2049,1024,373,4161,1377,357,2,41,65,3392,4389,4096,3124,20,32,256,1044,4112,885]

theorem envBound19095 : H12AffineFastState.Bounded env19095 := by
  intro p hp
  have h : env19095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19094_19095 : H12AffineEnvironment.transform 12 40 env19094 = env19095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19094 == env19095) = true)

theorem identity19095 : scanCanonicalize (H12AffineFastState.compose env19095 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19095 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env19096 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,40,4113,372,114,4177,2049,101,373,4161,260,357,2,41,65,2341,4389,4096,2129,20,32,256,113,4112,885]

theorem envBound19096 : H12AffineFastState.Bounded env19096 := by
  intro p hp
  have h : env19096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19095_19096 : H12AffineEnvironment.transform 9 101 env19095 = env19096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19095 == env19096) = true)

theorem identity19096 : scanCanonicalize (H12AffineFastState.compose env19096 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19096 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19097 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,40,4113,0,114,4177,2049,101,1,4161,112,17,2,41,65,2129,4177,4096,2129,20,32,116,113,4112,513]

theorem envBound19097 : H12AffineFastState.Bounded env19097 := by
  intro p hp
  have h : env19097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19096_19097 : H12AffineEnvironment.transform 7 116 env19096 = env19097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19096 == env19097) = true)

theorem identity19097 : scanCanonicalize (H12AffineFastState.compose env19097 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19097 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19098 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4113,0,34,4097,2049,53,1,4113,32,17,2,41,17,2049,4097,4096,2049,20,32,36,33,4112,513]

theorem envBound19098 : H12AffineFastState.Bounded env19098 := by
  intro p hp
  have h : env19098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19097_19098 : H12AffineEnvironment.transform 5 16 env19097 = env19098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19097 == env19098) = true)

theorem identity19098 : scanCanonicalize (H12AffineFastState.compose env19098 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound19098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19099 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,544,40,561,0,34,545,2049,53,1,561,32,17,2,41,17,2049,545,544,2049,20,32,36,33,560,513]

theorem envBound19099 : H12AffineFastState.Bounded env19099 := by
  intro p hp
  have h : env19099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19098_19099 : H12AffineEnvironment.transform 11 544 env19098 = env19099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env19098 == env19099) = true)

theorem identity19099 : scanCanonicalize (H12AffineFastState.compose env19099 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound19099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19100 : List Nat := [2,4,8,16,32,16,9,36,512,53,49,544,40,561,0,34,545,48,53,1,561,32,17,2,41,17,48,545,544,48,20,32,36,33,560,513]

theorem envBound19100 : H12AffineFastState.Bounded env19100 := by
  intro p hp
  have h : env19100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19099_19100 : H12AffineEnvironment.transform 10 49 env19099 = env19100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19099 == env19100) = true)

theorem identity19100 : scanCanonicalize (H12AffineFastState.compose env19100 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound19100 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19101 : List Nat := [2,4,8,16,32,16,9,36,49,53,49,17,40,0,0,34,16,48,53,1,0,32,17,2,41,17,48,16,17,48,20,32,36,33,1,48]

theorem envBound19101 : H12AffineFastState.Bounded env19101 := by
  intro p hp
  have h : env19101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19100_19101 : H12AffineEnvironment.transform 8 49 env19100 = env19101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env19100 == env19101) = true)

theorem identity19101 : scanCanonicalize (H12AffineFastState.compose env19101 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19101 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19102 : List Nat := [2,4,8,16,16,16,9,20,1,5,1,17,24,0,0,18,16,0,5,1,0,16,17,2,25,17,0,16,17,0,20,16,20,17,1,0]

theorem envBound19102 : H12AffineFastState.Bounded env19102 := by
  intro p hp
  have h : env19102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19101_19102 : H12AffineEnvironment.transform 4 16 env19101 = env19102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19101 == env19102) = true)

def env19103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,180272,253962,242969,8328,65,97667,139732,238875,67754,119043,168,256,98814,90203,63188]

theorem envBound19103 : H12AffineFastState.Bounded env19103 := by
  intro p hp
  have h : env19103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19075_19103 : H12AffineEnvironment.transform 17 10401 env19075 = env19103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19075 == env19103) = true)

def env19104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180272,253962,242969,8192,65,97547,139612,238875,67618,119043,32,256,98678,90203,63068]

theorem envBound19104 : H12AffineFastState.Bounded env19104 := by
  intro p hp
  have h : env19104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19103_19104 : H12AffineEnvironment.transform 6 8 env19103 = env19104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19103 == env19104) = true)

theorem identity19104 : scanCanonicalize (H12AffineFastState.compose env19104 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19104 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4161,169264,242954,242969,8192,65,75787,139612,238875,67618,99331,32,256,98678,79195,41820]

theorem envBound19105 : H12AffineFastState.Bounded env19105 := by
  intro p hp
  have h : env19105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19104_19105 : H12AffineEnvironment.transform 13 5376 env19104 = env19105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19104 == env19105) = true)

theorem identity19105 : scanCanonicalize (H12AffineFastState.compose env19105 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 36944) := by decide +kernel

theorem selectedBound19105 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env19106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,36944,10281,1024,32769,4161,1376,75098,75081,8192,65,75787,45324,79179,67618,99331,32,256,98678,79195,41820]

theorem envBound19106 : H12AffineFastState.Bounded env19106 := by
  intro p hp
  have h : env19106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19105_19106 : H12AffineEnvironment.transform 16 36944 env19105 = env19106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 36944 env19105 == env19106) = true)

theorem identity19106 : scanCanonicalize (H12AffineFastState.compose env19106 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19106 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env19107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,12557,10281,1024,8540,4161,1376,75098,75081,8192,65,75787,4177,79179,67618,75102,32,256,73771,79195,513]

theorem envBound19107 : H12AffineFastState.Bounded env19107 := by
  intro p hp
  have h : env19107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19106_19107 : H12AffineEnvironment.transform 14 8541 env19106 = env19107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19106 == env19107) = true)

theorem identity19107 : scanCanonicalize (H12AffineFastState.compose env19107 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound19107 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env19108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6248,5376,6453,65536,2405,4161,1024,6452,4161,1376,73010,72993,6248,65,69731,4177,68899,67618,73014,32,256,71747,68915,513]

theorem envBound19108 : H12AffineFastState.Bounded env19108 := by
  intro p hp
  have h : env19108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19107_19108 : H12AffineEnvironment.transform 12 6248 env19107 = env19108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env19107 == env19108) = true)

theorem identity19108 : scanCanonicalize (H12AffineFastState.compose env19108 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound19108 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1053,2421,1344,65536,2405,3124,1024,1345,3124,1376,65863,65876,1053,65,68630,3108,68899,67618,65859,32,256,66614,68915,513]

theorem envBound19109 : H12AffineFastState.Bounded env19109 := by
  intro p hp
  have h : env19109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19108_19109 : H12AffineEnvironment.transform 11 3189 env19108 = env19109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env19108 == env19109) = true)

theorem identity19109 : scanCanonicalize (H12AffineFastState.compose env19109 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound19109 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env19110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1053,2421,1344,114,2405,3124,1024,1345,3124,1376,309,294,1053,65,3172,3108,3409,2128,305,32,256,1092,3393,513]

theorem envBound19110 : H12AffineFastState.Bounded env19110 := by
  intro p hp
  have h : env19110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19109_19110 : H12AffineEnvironment.transform 15 114 env19109 = env19110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env19109 == env19110) = true)

theorem identity19110 : scanCanonicalize (H12AffineFastState.compose env19110 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19110 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env19111 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,2113,41,2421,372,114,2405,2048,52,373,2048,340,309,294,41,65,2128,2064,2405,2128,305,32,256,112,2421,513]

theorem envBound19111 : H12AffineFastState.Bounded env19111 := by
  intro p hp
  have h : env19111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19110_19111 : H12AffineEnvironment.transform 9 52 env19110 = env19111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19110 == env19111) = true)

theorem identity19111 : scanCanonicalize (H12AffineFastState.compose env19111 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19111 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env19112 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,41,2340,293,35,2356,2048,52,292,2048,261,309,294,41,16,2049,2064,2356,2049,305,32,256,33,2340,513]

theorem envBound19112 : H12AffineFastState.Bounded env19112 := by
  intro p hp
  have h : env19112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19111_19112 : H12AffineEnvironment.transform 5 17 env19111 = env19112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19111 == env19112) = true)

theorem identity19112 : scanCanonicalize (H12AffineFastState.compose env19112 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound19112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19113 : List Nat := [2,4,8,16,32,17,8,256,309,52,2048,2064,41,2340,293,35,2356,2048,52,292,2048,261,309,294,41,16,2049,2064,2356,2049,305,32,256,33,2340,308]

theorem envBound19113 : H12AffineFastState.Bounded env19113 := by
  intro p hp
  have h : env19113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19112_19113 : H12AffineEnvironment.transform 8 309 env19112 = env19113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env19112 == env19113) = true)

theorem identity19113 : scanCanonicalize (H12AffineFastState.compose env19113 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19113 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env19114 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,16,41,292,293,35,308,0,52,292,0,261,309,294,41,16,1,16,308,1,305,32,256,33,292,308]

theorem envBound19114 : H12AffineFastState.Bounded env19114 := by
  intro p hp
  have h : env19114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19113_19114 : H12AffineEnvironment.transform 10 0 env19113 = env19114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19113 == env19114) = true)

theorem identity19114 : scanCanonicalize (H12AffineFastState.compose env19114 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19114 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env19115 : List Nat := [2,4,2,16,32,17,2,256,309,52,0,16,35,292,293,35,308,0,52,292,0,261,309,294,35,16,1,16,308,1,305,32,256,33,292,308]

theorem envBound19115 : H12AffineFastState.Bounded env19115 := by
  intro p hp
  have h : env19115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19114_19115 : H12AffineEnvironment.transform 2 2 env19114 = env19115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19114 == env19115) = true)

def env19116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180272,253962,242969,8193,65,97546,139613,238875,67619,119043,33,256,98679,90203,63069]

theorem envBound19116 : H12AffineFastState.Bounded env19116 := by
  intro p hp
  have h : env19116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19103_19116 : H12AffineEnvironment.transform 6 9 env19103 = env19116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19103 == env19116) = true)

theorem identity19116 : scanCanonicalize (H12AffineFastState.compose env19116 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19116 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,4161,144492,201814,213317,8193,65,97546,139613,217415,67619,75103,33,256,95531,90203,513]

theorem envBound19117 : H12AffineFastState.Bounded env19117 := by
  intro p hp
  have h : env19117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19116_19117 : H12AffineEnvironment.transform 14 29788 env19116 = env19117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19116 == env19117) = true)

theorem identity19117 : scanCanonicalize (H12AffineFastState.compose env19117 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound19117 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env19118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,131072,10280,1024,29789,4161,144492,155997,144462,8193,65,2049,139613,140364,32040,20564,33,256,32,5456,513]

theorem envBound19118 : H12AffineFastState.Bounded env19118 := by
  intro p hp
  have h : env19118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19117_19118 : H12AffineEnvironment.transform 15 29963 env19117 = env19118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env19117 == env19118) = true)

theorem identity19118 : scanCanonicalize (H12AffineFastState.compose env19118 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19118 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,131072,2421,1024,21760,4161,136497,147456,136467,348,65,2049,131072,132369,23669,20564,33,256,32,5456,513]

theorem envBound19119 : H12AffineFastState.Bounded env19119 := by
  intro p hp
  have h : env19119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19118_19119 : H12AffineEnvironment.transform 12 349 env19118 = env19119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19118 == env19119) = true)

theorem identity19119 : scanCanonicalize (H12AffineFastState.compose env19119 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19119 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,131072,2421,1024,0,4161,136497,136448,136467,348,65,2049,131072,132369,2421,1364,33,256,32,5456,513]

theorem envBound19120 : H12AffineFastState.Bounded env19120 := by
  intro p hp
  have h : env19120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19119_19120 : H12AffineEnvironment.transform 13 5376 env19119 = env19120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19119 == env19120) = true)

theorem identity19120 : scanCanonicalize (H12AffineFastState.compose env19120 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19120 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2421,1024,0,4161,33,16,3,348,65,2049,5392,4097,2421,1364,33,256,32,5456,513]

theorem envBound19121 : H12AffineFastState.Bounded env19121 := by
  intro p hp
  have h : env19121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19120_19121 : H12AffineEnvironment.transform 16 5392 env19120 = env19121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19120 == env19121) = true)

theorem identity19121 : scanCanonicalize (H12AffineFastState.compose env19121 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound19121 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3419,349,2139,1,342,2123,2421,1024,0,3354,33,16,3,348,65,2049,2123,3418,2421,1364,33,256,32,2059,513]

theorem envBound19122 : H12AffineFastState.Bounded env19122 := by
  intro p hp
  have h : env19122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19121_19122 : H12AffineEnvironment.transform 11 3419 env19121 = env19122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env19121 == env19122) = true)

theorem identity19122 : scanCanonicalize (H12AffineFastState.compose env19122 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound19122 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19123 : List Nat := [2,4,8,16,32,10,9,256,512,1024,2048,3345,279,2065,1,284,2049,2367,1024,0,3354,33,16,3,278,11,2049,2049,3344,2367,1310,33,256,32,2059,513]

theorem envBound19123 : H12AffineFastState.Bounded env19123 := by
  intro p hp
  have h : env19123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19122_19123 : H12AffineEnvironment.transform 5 10 env19122 = env19123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env19122 == env19123) = true)

theorem identity19123 : scanCanonicalize (H12AffineFastState.compose env19123 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19123 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19124 : List Nat := [2,4,8,16,0,10,9,256,512,1024,2048,3345,279,2065,1,284,2049,2335,1024,0,3354,1,16,3,278,11,2049,2049,3344,2335,1310,1,256,0,2059,513]

theorem envBound19124 : H12AffineFastState.Bounded env19124 := by
  intro p hp
  have h : env19124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19123_19124 : H12AffineEnvironment.transform 4 0 env19123 = env19124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19123 == env19124) = true)

theorem identity19124 : scanCanonicalize (H12AffineFastState.compose env19124 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound19124 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env19125 : List Nat := [2,4,8,11,0,10,9,256,512,1024,2048,3338,268,2058,1,263,2049,2308,1024,0,3329,1,11,3,269,11,2049,2049,3339,2308,1285,1,256,0,2059,513]

theorem envBound19125 : H12AffineFastState.Bounded env19125 := by
  intro p hp
  have h : env19125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19124_19125 : H12AffineEnvironment.transform 3 11 env19124 = env19125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env19124 == env19125) = true)

theorem identity19125 : scanCanonicalize (H12AffineFastState.compose env19125 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound19125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19126 : List Nat := [2,4,8,11,0,10,9,14,512,1024,2048,3076,2,2058,1,9,2049,2058,1024,0,3087,1,11,3,3,11,2049,2049,3077,2058,1035,1,14,0,2059,513]

theorem envBound19126 : H12AffineFastState.Bounded env19126 := by
  intro p hp
  have h : env19126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19125_19126 : H12AffineEnvironment.transform 7 14 env19125 = env19126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env19125 == env19126) = true)

theorem identity19126 : scanCanonicalize (H12AffineFastState.compose env19126 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound19126 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19127 : List Nat := [2,4,8,11,0,10,9,14,10,1024,2048,3076,2,2058,1,9,2049,2058,1024,0,3087,1,11,3,3,11,2049,2049,3077,2058,1035,1,14,0,2059,11]

theorem envBound19127 : H12AffineFastState.Bounded env19127 := by
  intro p hp
  have h : env19127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19126_19127 : H12AffineEnvironment.transform 8 10 env19126 = env19127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env19126 == env19127) = true)

theorem identity19127 : scanCanonicalize (H12AffineFastState.compose env19127 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound19127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19128 : List Nat := [2,4,1,2,0,3,0,7,3,1024,2048,3076,2,2051,1,0,2049,2051,1024,0,3078,1,2,3,3,2,2049,2049,3077,2051,1026,1,7,0,2050,2]

theorem envBound19128 : H12AffineFastState.Bounded env19128 := by
  intro p hp
  have h : env19128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19127_19128 : H12AffineEnvironment.transform 2 1 env19127 = env19128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env19127 == env19128) = true)

theorem identity19128 : scanCanonicalize (H12AffineFastState.compose env19128 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1030) := by decide +kernel

theorem selectedBound19128 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19129 : List Nat := [2,4,1,2,0,3,0,7,3,1024,1030,2,2,1029,1,0,1031,1029,1024,0,0,1,2,3,3,2,1031,1031,3,1029,1026,1,7,0,1028,2]

theorem envBound19129 : H12AffineFastState.Bounded env19129 := by
  intro p hp
  have h : env19129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19128_19129 : H12AffineEnvironment.transform 10 1030 env19128 = env19129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1030 env19128 == env19129) = true)

theorem identity19129 : scanCanonicalize (H12AffineFastState.compose env19129 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound19129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19130 : List Nat := [2,4,1,2,0,3,0,7,3,1,7,2,2,4,1,0,6,4,1,0,0,1,2,3,3,2,6,6,3,4,3,1,7,0,5,2]

theorem envBound19130 : H12AffineFastState.Bounded env19130 := by
  intro p hp
  have h : env19130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19129_19130 : H12AffineEnvironment.transform 9 1 env19129 = env19130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env19129 == env19130) = true)

theorem identity19130 : scanCanonicalize (H12AffineFastState.compose env19130 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound19130 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19131 : List Nat := [2,1,1,2,0,3,0,2,3,1,2,2,2,1,1,0,3,1,1,0,0,1,2,3,3,2,3,3,3,1,3,1,2,0,0,2]

theorem envBound19131 : H12AffineFastState.Bounded env19131 := by
  intro p hp
  have h : env19131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19130_19131 : H12AffineEnvironment.transform 1 1 env19130 = env19131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env19130 == env19131) = true)

def env19132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,499129,8328,65,349475,2496821,2596347,67754,119042,2373705,256,2199998,2191387,63189]

theorem envBound19132 : H12AffineFastState.Bounded env19132 := by
  intro p hp
  have h : env19132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19046_19132 : H12AffineEnvironment.transform 23 499129 env19046 = env19132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env19046 == env19132) = true)

def env19133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510123,499129,8328,65,349475,395637,495035,67754,119042,272393,256,98814,90203,63189]

theorem envBound19133 : H12AffineFastState.Bounded env19133 := by
  intro p hp
  have h : env19133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19132_19133 : H12AffineEnvironment.transform 20 4160 env19132 = env19133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19132 == env19133) = true)

theorem identity19133 : scanCanonicalize (H12AffineFastState.compose env19133 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound19133 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,144612,474239,485741,8328,65,349475,395637,489839,67754,75222,272393,256,95530,90203,513]

theorem envBound19134 : H12AffineFastState.Bounded env19134 := by
  intro p hp
  have h : env19134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19133_19134 : H12AffineEnvironment.transform 14 29908 env19133 = env19134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env19133 == env19134) = true)

def env19135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144492,474239,485741,8192,65,349475,395637,489839,67618,75102,272393,256,95530,90203,513]

theorem envBound19135 : H12AffineFastState.Bounded env19135 := by
  intro p hp
  have h : env19135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19134_19135 : H12AffineEnvironment.transform 6 8 env19134 = env19135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19134 == env19135) = true)

theorem identity19135 : scanCanonicalize (H12AffineFastState.compose env19135 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound19135 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,4160,87158,285797,264567,8192,65,349475,354671,268661,67618,75102,272393,256,95530,90203,513]

theorem envBound19136 : H12AffineFastState.Bounded env19136 := by
  intro p hp
  have h : env19136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19135_19136 : H12AffineEnvironment.transform 16 90138 env19135 = env19136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env19135 == env19136) = true)

theorem identity19136 : scanCanonicalize (H12AffineFastState.compose env19136 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound19136 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env19137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,3173,1024,29789,4160,87158,20480,1298,8192,65,88390,91402,5392,67618,75102,9324,256,95530,90203,513]

theorem envBound19137 : H12AffineFastState.Bounded env19137 := by
  intro p hp
  have h : env19137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19136_19137 : H12AffineEnvironment.transform 17 3173 env19136 = env19137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env19136 == env19137) = true)

theorem identity19137 : scanCanonicalize (H12AffineFastState.compose env19137 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19137 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env19138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,3173,1024,8540,4160,65911,1281,1298,8192,65,68679,77835,5392,67618,75102,9324,256,73771,79194,513]

theorem envBound19138 : H12AffineFastState.Bounded env19138 := by
  intro p hp
  have h : env19138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19137_19138 : H12AffineEnvironment.transform 13 5377 env19137 = env19138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19137 == env19138) = true)

theorem identity19138 : scanCanonicalize (H12AffineFastState.compose env19138 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19138 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5393,3173,1024,8540,4160,8573,1281,1298,8192,65,11341,4097,5392,10280,1364,9324,256,33,5456,513]

theorem envBound19139 : H12AffineFastState.Bounded env19139 := by
  intro p hp
  have h : env19139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19138_19139 : H12AffineEnvironment.transform 15 8202 env19138 = env19139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19138 == env19139) = true)

theorem identity19139 : scanCanonicalize (H12AffineFastState.compose env19139 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19139 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env19140 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8541,8202,4468,2048,101,8540,4160,8573,356,375,8192,65,10280,4097,4469,10280,305,8201,256,33,4405,513]

theorem envBound19140 : H12AffineFastState.Bounded env19140 := by
  intro p hp
  have h : env19140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19139_19140 : H12AffineEnvironment.transform 9 101 env19139 = env19140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19139 == env19140) = true)

theorem identity19140 : scanCanonicalize (H12AffineFastState.compose env19140 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound19140 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env19141 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,4452,293,114,4468,2048,101,292,4160,261,356,375,120,65,2128,4097,4469,2128,305,113,256,33,4405,513]

theorem envBound19141 : H12AffineFastState.Bounded env19141 := by
  intro p hp
  have h : env19141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19140_19141 : H12AffineEnvironment.transform 12 120 env19140 = env19141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env19140 == env19141) = true)

theorem identity19141 : scanCanonicalize (H12AffineFastState.compose env19141 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound19141 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env19142 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,2420,293,114,2404,2048,101,292,2128,261,356,375,120,65,2128,2065,2405,2128,305,113,256,33,2341,513]

theorem envBound19142 : H12AffineFastState.Bounded env19142 := by
  intro p hp
  have h : env19142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19141_19142 : H12AffineEnvironment.transform 11 2064 env19141 = env19142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env19141 == env19142) = true)

theorem identity19142 : scanCanonicalize (H12AffineFastState.compose env19142 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19142 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env19143 : List Nat := [2,4,8,16,32,64,8,256,512,101,0,16,120,372,293,114,356,0,101,292,80,261,356,375,120,65,80,17,357,80,305,113,256,33,293,513]

theorem envBound19143 : H12AffineFastState.Bounded env19143 := by
  intro p hp
  have h : env19143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19142_19143 : H12AffineEnvironment.transform 10 0 env19142 = env19143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19142 == env19143) = true)

theorem identity19143 : scanCanonicalize (H12AffineFastState.compose env19143 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19143 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env19144 : List Nat := [2,4,8,16,32,64,8,116,512,101,0,16,120,0,81,114,16,0,101,80,80,113,16,3,120,65,80,17,17,80,69,113,116,33,81,513]

theorem envBound19144 : H12AffineFastState.Bounded env19144 := by
  intro p hp
  have h : env19144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19143_19144 : H12AffineEnvironment.transform 7 116 env19143 = env19144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19143 == env19144) = true)

theorem identity19144 : scanCanonicalize (H12AffineFastState.compose env19144 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound19144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19145 : List Nat := [2,4,8,16,32,33,8,21,512,4,0,16,25,0,48,19,16,0,4,49,49,16,16,3,25,32,49,17,17,49,36,16,21,33,48,513]

theorem envBound19145 : H12AffineFastState.Bounded env19145 := by
  intro p hp
  have h : env19145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19144_19145 : H12AffineEnvironment.transform 5 33 env19144 = env19145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env19144 == env19145) = true)

theorem identity19145 : scanCanonicalize (H12AffineFastState.compose env19145 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound19145 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19146 : List Nat := [2,4,8,16,32,33,8,21,49,4,0,16,25,0,48,19,16,0,4,49,49,16,16,3,25,32,49,17,17,49,36,16,21,33,48,48]

theorem envBound19146 : H12AffineFastState.Bounded env19146 := by
  intro p hp
  have h : env19146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19145_19146 : H12AffineEnvironment.transform 8 49 env19145 = env19146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env19145 == env19146) = true)

theorem identity19146 : scanCanonicalize (H12AffineFastState.compose env19146 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19147 : List Nat := [2,4,8,16,1,0,8,21,16,4,0,16,25,0,17,19,16,0,4,16,16,16,16,3,25,1,16,17,17,16,5,16,21,0,17,17]

theorem envBound19147 : H12AffineFastState.Bounded env19147 := by
  intro p hp
  have h : env19147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19146_19147 : H12AffineEnvironment.transform 4 1 env19146 = env19147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19146 == env19147) = true)

theorem identity19147 : scanCanonicalize (H12AffineFastState.compose env19147 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19148 : List Nat := [2,4,8,0,1,0,8,5,0,4,0,0,9,0,1,3,0,0,4,0,0,0,0,3,9,1,0,1,1,0,5,0,5,0,1,1]

theorem envBound19148 : H12AffineFastState.Bounded env19148 := by
  intro p hp
  have h : env19148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19147_19148 : H12AffineEnvironment.transform 3 0 env19147 = env19148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19147 == env19148) = true)

def env19149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,474239,485741,8193,65,349475,395637,489839,67619,75103,272393,256,95530,90203,513]

theorem envBound19149 : H12AffineFastState.Bounded env19149 := by
  intro p hp
  have h : env19149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19134_19149 : H12AffineEnvironment.transform 6 9 env19134 = env19149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19134 == env19149) = true)

theorem identity19149 : scanCanonicalize (H12AffineFastState.compose env19149 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound19149 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env19150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1024,29788,4160,144493,213334,201796,8193,65,75786,160860,197702,67619,75103,21792,256,95530,90203,513]

theorem envBound19150 : H12AffineFastState.Bounded env19150 := by
  intro p hp
  have h : env19150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19149_19150 : H12AffineEnvironment.transform 17 32041 env19149 = env19150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env19149 == env19150) = true)

theorem identity19150 : scanCanonicalize (H12AffineFastState.compose env19150 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19150 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env19151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,131072,23669,1024,21760,4160,136497,213334,201796,349,65,67926,152832,197702,67619,66563,21792,256,87158,82183,513]

theorem envBound19151 : H12AffineFastState.Bounded env19151 := by
  intro p hp
  have h : env19151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19150_19151 : H12AffineEnvironment.transform 12 348 env19150 = env19151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19150 == env19151) = true)

theorem identity19151 : scanCanonicalize (H12AffineFastState.compose env19151 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound19151 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,82246,23669,1024,21760,4160,87159,16,21762,349,65,67926,70726,17664,67619,66563,21792,256,87158,82183,513]

theorem envBound19152 : H12AffineFastState.Bounded env19152 := by
  intro p hp
  have h : env19152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19151_19152 : H12AffineEnvironment.transform 16 82246 env19151 = env19152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env19151 == env19152) = true)

theorem identity19152 : scanCanonicalize (H12AffineFastState.compose env19152 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound19152 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19153 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5393,23669,1024,21760,4160,32,16,21762,349,65,23809,16401,17664,23668,20564,21792,256,33,5456,513]

theorem envBound19153 : H12AffineFastState.Bounded env19153 := by
  intro p hp
  have h : env19153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19152_19153 : H12AffineEnvironment.transform 15 21591 env19152 = env19153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env19152 == env19153) = true)

theorem identity19153 : scanCanonicalize (H12AffineFastState.compose env19153 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound19153 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19154 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,16384,21589,21591,5189,23669,1024,21588,4160,32,16,21590,9,65,23637,16401,17492,23668,20564,21620,84,33,5124,513]

theorem envBound19154 : H12AffineFastState.Bounded env19154 := by
  intro p hp
  have h : env19154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19153_19154 : H12AffineEnvironment.transform 7 84 env19153 = env19154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env19153 == env19154) = true)

theorem identity19154 : scanCanonicalize (H12AffineFastState.compose env19154 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound19154 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19155 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5124,81,83,5189,2161,1024,80,4160,32,16,82,9,65,2129,5141,4176,2160,1104,112,84,33,5124,513]

theorem envBound19155 : H12AffineFastState.Bounded env19155 := by
  intro p hp
  have h : env19155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19154_19155 : H12AffineEnvironment.transform 13 5124 env19154 = env19155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env19154 == env19155) = true)

theorem identity19155 : scanCanonicalize (H12AffineFastState.compose env19155 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1605) := by decide +kernel

theorem selectedBound19155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19156 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1605,4096,8,5124,81,83,5189,1588,1024,80,4160,32,16,82,9,65,1556,5141,4176,1589,1104,112,84,33,5124,513]

theorem envBound19156 : H12AffineFastState.Bounded env19156 := by
  intro p hp
  have h : env19156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19155_19156 : H12AffineEnvironment.transform 10 1605 env19155 = env19156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1605 env19155 == env19156) = true)

theorem identity19156 : scanCanonicalize (H12AffineFastState.compose env19156 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19157 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1556,4096,8,5124,0,2,5140,1588,1024,1,4113,32,16,3,9,16,1556,5141,4097,1589,1025,33,5,33,5124,513]

theorem envBound19157 : H12AffineFastState.Bounded env19157 := by
  intro p hp
  have h : env19157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19156_19157 : H12AffineEnvironment.transform 5 17 env19156 = env19157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19156 == env19157) = true)

theorem identity19157 : scanCanonicalize (H12AffineFastState.compose env19157 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound19157 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19158 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1556,33,8,1061,0,2,1077,1588,1024,1,48,32,16,3,9,16,1556,1076,32,1589,1025,33,5,33,1061,513]

theorem envBound19158 : H12AffineFastState.Bounded env19158 := by
  intro p hp
  have h : env19158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19157_19158 : H12AffineEnvironment.transform 11 33 env19157 = env19158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env19157 == env19158) = true)

theorem identity19158 : scanCanonicalize (H12AffineFastState.compose env19158 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound19158 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19159 : List Nat := [2,4,8,16,32,17,9,5,512,548,48,33,8,513,0,2,529,16,548,1,48,32,16,3,9,16,48,528,32,17,549,33,5,33,513,513]

theorem envBound19159 : H12AffineFastState.Bounded env19159 := by
  intro p hp
  have h : env19159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19158_19159 : H12AffineEnvironment.transform 9 548 env19158 = env19159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env19158 == env19159) = true)

theorem identity19159 : scanCanonicalize (H12AffineFastState.compose env19159 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound19159 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19160 : List Nat := [2,4,8,16,32,17,9,5,16,52,48,33,8,17,0,2,1,16,52,1,48,32,16,3,9,16,48,0,32,17,53,33,5,33,17,17]

theorem envBound19160 : H12AffineFastState.Bounded env19160 := by
  intro p hp
  have h : env19160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19159_19160 : H12AffineEnvironment.transform 8 16 env19159 = env19160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env19159 == env19160) = true)

theorem identity19160 : scanCanonicalize (H12AffineFastState.compose env19160 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19160 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19161 : List Nat := [2,4,8,1,32,0,9,5,1,37,33,33,8,0,0,2,1,1,37,1,33,32,1,3,9,1,33,0,32,0,36,33,5,33,0,0]

theorem envBound19161 : H12AffineFastState.Bounded env19161 := by
  intro p hp
  have h : env19161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19160_19161 : H12AffineEnvironment.transform 3 1 env19160 = env19161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19160 == env19161) = true)

def env19162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510123,499129,8328,65,349475,395636,495034,67754,119042,272392,256,98815,90202,63189]

theorem envBound19162 : H12AffineFastState.Bounded env19162 := by
  intro p hp
  have h : env19162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19132_19162 : H12AffineEnvironment.transform 20 4161 env19132 = env19162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19132 == env19162) = true)

theorem identity19162 : scanCanonicalize (H12AffineFastState.compose env19162 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound19162 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180272,120015,98781,8328,65,215367,5392,102878,67754,119042,144492,256,98815,90202,63189]

theorem envBound19163 : H12AffineFastState.Bounded env19163 := by
  intro p hp
  have h : env19163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19162_19163 : H12AffineEnvironment.transform 17 138340 env19162 = env19163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env19162 == env19163) = true)

def env19164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180272,119879,98645,8192,65,215367,5392,102742,67618,119042,144492,256,98679,90202,63069]

theorem envBound19164 : H12AffineFastState.Bounded env19164 := by
  intro p hp
  have h : env19164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19163_19164 : H12AffineEnvironment.transform 6 8 env19163 = env19164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19163 == env19164) = true)

theorem identity19164 : scanCanonicalize (H12AffineFastState.compose env19164 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound19164 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env19165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,131072,138340,1024,32769,4161,169029,98354,98645,8192,65,204082,5392,102742,67618,99703,144492,256,98679,78895,41512]

theorem envBound19165 : H12AffineFastState.Bounded env19165 := by
  intro p hp
  have h : env19165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19164_19165 : H12AffineEnvironment.transform 13 5237 env19164 = env19165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env19164 == env19165) = true)

theorem identity19165 : scanCanonicalize (H12AffineFastState.compose env19165 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound19165 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,5221,2049,1024,32769,4161,32800,98354,98645,8192,65,67927,5392,102742,67618,99703,8201,256,98679,78895,41512]

theorem envBound19166 : H12AffineFastState.Bounded env19166 := by
  intro p hp
  have h : env19166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19165_19166 : H12AffineEnvironment.transform 16 5221 env19165 = env19166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env19165 == env19166) = true)

theorem identity19166 : scanCanonicalize (H12AffineFastState.compose env19166 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19166 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,8202,5221,2049,1024,32769,4161,32800,41016,41311,8192,65,10589,5392,45404,10280,42365,8201,256,41341,5157,41512]

theorem envBound19167 : H12AffineFastState.Bounded env19167 := by
  intro p hp
  have h : env19167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19166_19167 : H12AffineEnvironment.transform 15 8202 env19166 = env19167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19166 == env19167) = true)

theorem identity19167 : scanCanonicalize (H12AffineFastState.compose env19167 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound19167 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env19168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,8202,5221,2049,1024,8232,4161,8201,17,374,8192,65,10589,5392,4469,10280,1364,8201,256,340,5157,513]

theorem envBound19168 : H12AffineFastState.Bounded env19168 := by
  intro p hp
  have h : env19168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19167_19168 : H12AffineEnvironment.transform 14 8233 env19167 = env19168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env19167 == env19168) = true)

theorem identity19168 : scanCanonicalize (H12AffineFastState.compose env19168 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

end H12CloudChart0