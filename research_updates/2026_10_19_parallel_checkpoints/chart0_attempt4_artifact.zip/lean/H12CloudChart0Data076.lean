import H12CloudChart0Data075

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound19168 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19169 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5156,8233,8202,5172,2049,1024,8232,4112,8201,17,295,8192,16,10508,5392,4388,10280,1285,8201,256,261,5157,513]

theorem envBound19169 : H12AffineFastState.Bounded env19169 := by
  intro p hp
  have h : env19169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19168_19169 : H12AffineEnvironment.transform 5 17 env19168 = env19169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19168 == env19169) = true)

theorem identity19169 : scanCanonicalize (H12AffineFastState.compose env19169 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound19169 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env19170 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1053,5156,1076,1047,5172,2049,1024,1077,4112,1044,17,295,1053,16,3345,5392,4388,3125,1285,1044,256,261,5157,513]

theorem envBound19170 : H12AffineFastState.Bounded env19170 := by
  intro p hp
  have h : env19170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19169_19170 : H12AffineEnvironment.transform 12 1053 env19169 = env19170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env19169 == env19170) = true)

theorem identity19170 : scanCanonicalize (H12AffineFastState.compose env19170 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19170 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19171 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,4404,292,263,4388,2049,272,293,4112,260,17,295,269,16,2049,4096,4388,2341,21,260,256,261,4405,513]

theorem envBound19171 : H12AffineFastState.Bounded env19171 := by
  intro p hp
  have h : env19171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19170_19171 : H12AffineEnvironment.transform 9 272 env19170 = env19171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19170 == env19171) = true)

def env19172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180272,119878,98644,8193,65,215367,5392,102743,67619,119042,144492,256,98678,90202,63068]

theorem envBound19172 : H12AffineFastState.Bounded env19172 := by
  intro p hp
  have h : env19172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19163_19172 : H12AffineEnvironment.transform 6 9 env19163 = env19172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19163 == env19172) = true)

theorem identity19172 : scanCanonicalize (H12AffineFastState.compose env19172 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound19172 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env19173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,138340,1024,32769,4161,180272,41292,62558,8193,65,146509,5392,58461,32041,41992,144492,256,62588,5456,63068]

theorem envBound19173 : H12AffineFastState.Bounded env19173 := by
  intro p hp
  have h : env19173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19172_19173 : H12AffineEnvironment.transform 15 29962 env19172 = env19173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env19172 == env19173) = true)

theorem identity19173 : scanCanonicalize (H12AffineFastState.compose env19173 (packedSelected [0,1,4,8,12,14,15,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound19173 : packedSelected [0,1,4,8,12,14,15,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env19174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,5440,2340,1024,32769,4161,54640,41292,62558,8193,65,10509,5392,58461,32041,41992,8492,256,62588,5456,63068]

theorem envBound19174 : H12AffineFastState.Bounded env19174 := by
  intro p hp
  have h : env19174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19173_19174 : H12AffineEnvironment.transform 16 5440 env19173 = env19174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env19173 == env19174) = true)

theorem identity19174 : scanCanonicalize (H12AffineFastState.compose env19174 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound19174 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,29962,5440,2340,1024,21760,4161,113,29773,8543,8193,65,10509,5392,12636,32041,28937,8492,256,8573,5456,9053]

theorem envBound19175 : H12AffineFastState.Bounded env19175 := by
  intro p hp
  have h : env19175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19174_19175 : H12AffineEnvironment.transform 14 21761 env19174 = env19175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env19174 == env19175) = true)

theorem identity19175 : scanCanonicalize (H12AffineFastState.compose env19175 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19175 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21761,21510,5440,2340,1024,21760,4161,113,21825,83,269,65,2049,5392,4176,23589,20485,32,256,113,5456,593]

theorem envBound19176 : H12AffineFastState.Bounded env19176 := by
  intro p hp
  have h : env19176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19175_19176 : H12AffineEnvironment.transform 12 268 env19175 = env19176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19175 == env19176) = true)

theorem identity19176 : scanCanonicalize (H12AffineFastState.compose env19176 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19176 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,80,343,5440,2340,1024,81,4161,113,16,83,269,65,2049,5392,4176,2420,1364,32,256,113,5456,593]

theorem envBound19177 : H12AffineFastState.Bounded env19177 := by
  intro p hp
  have h : env19177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19176_19177 : H12AffineEnvironment.transform 13 5457 env19176 = env19177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env19176 == env19177) = true)

theorem identity19177 : scanCanonicalize (H12AffineFastState.compose env19177 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound19177 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env19178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1541,4096,268,5457,80,343,5440,1825,1024,81,4161,113,16,83,269,65,1540,5392,4176,1905,1364,32,256,113,5456,593]

theorem envBound19178 : H12AffineFastState.Bounded env19178 := by
  intro p hp
  have h : env19178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19177_19178 : H12AffineEnvironment.transform 10 1541 env19177 = env19178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env19177 == env19178) = true)

theorem identity19178 : scanCanonicalize (H12AffineFastState.compose env19178 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound19178 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env19179 : List Nat := [2,4,8,16,32,64,9,256,512,305,820,4096,268,4192,80,343,4209,528,305,81,4161,113,16,83,269,65,821,4129,4176,576,101,32,256,113,4193,593]

theorem envBound19179 : H12AffineFastState.Bounded env19179 := by
  intro p hp
  have h : env19179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19178_19179 : H12AffineEnvironment.transform 9 305 env19178 = env19179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env19178 == env19179) = true)

theorem identity19179 : scanCanonicalize (H12AffineFastState.compose env19179 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19179 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19180 : List Nat := [2,4,8,16,16,64,9,256,512,257,772,4096,268,4176,80,343,4161,528,257,81,4161,65,16,83,269,65,773,4113,4176,576,85,16,256,65,4177,593]

theorem envBound19180 : H12AffineFastState.Bounded env19180 := by
  intro p hp
  have h : env19180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19179_19180 : H12AffineEnvironment.transform 4 16 env19179 = env19180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19179 == env19180) = true)

theorem identity19180 : scanCanonicalize (H12AffineFastState.compose env19180 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound19180 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19181 : List Nat := [2,4,8,16,16,64,9,256,512,257,772,325,268,277,80,343,260,528,257,81,260,65,16,83,269,65,773,340,277,576,85,16,256,65,276,593]

theorem envBound19181 : H12AffineFastState.Bounded env19181 := by
  intro p hp
  have h : env19181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19180_19181 : H12AffineEnvironment.transform 11 325 env19180 = env19181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env19180 == env19181) = true)

theorem identity19181 : scanCanonicalize (H12AffineFastState.compose env19181 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound19181 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env19182 : List Nat := [2,4,8,16,16,64,9,256,340,257,80,325,268,277,80,343,260,324,257,81,260,65,16,83,269,65,81,340,277,276,85,16,256,65,276,261]

theorem envBound19182 : H12AffineFastState.Bounded env19182 := by
  intro p hp
  have h : env19182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19181_19182 : H12AffineEnvironment.transform 8 340 env19181 = env19182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env19181 == env19182) = true)

theorem identity19182 : scanCanonicalize (H12AffineFastState.compose env19182 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19182 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19183 : List Nat := [2,4,8,16,16,17,9,256,261,257,1,276,268,277,1,262,260,277,257,0,260,16,16,2,269,16,0,261,277,276,4,16,256,16,276,261]

theorem envBound19183 : H12AffineFastState.Bounded env19183 := by
  intro p hp
  have h : env19183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19182_19183 : H12AffineEnvironment.transform 5 17 env19182 = env19183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19182 == env19183) = true)

theorem identity19183 : scanCanonicalize (H12AffineFastState.compose env19183 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19184 : List Nat := [2,4,8,1,1,0,9,256,261,257,1,261,268,260,1,262,260,260,257,0,260,1,1,2,269,1,0,261,260,261,4,1,256,1,261,261]

theorem envBound19184 : H12AffineFastState.Bounded env19184 := by
  intro p hp
  have h : env19184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19183_19184 : H12AffineEnvironment.transform 3 1 env19183 = env19184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19183 == env19184) = true)

theorem identity19184 : scanCanonicalize (H12AffineFastState.compose env19184 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19184 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19185 : List Nat := [2,4,8,1,1,0,9,4,1,5,1,1,8,0,1,2,0,0,5,0,0,1,1,2,9,1,0,1,0,1,4,1,4,1,1,1]

theorem envBound19185 : H12AffineFastState.Bounded env19185 := by
  intro p hp
  have h : env19185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19184_19185 : H12AffineEnvironment.transform 7 4 env19184 = env19185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19184 == env19185) = true)

theorem identity19185 : scanCanonicalize (H12AffineFastState.compose env19185 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound19185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19186 : List Nat := [2,4,6,1,1,0,7,4,1,5,1,1,6,0,1,2,0,0,5,0,0,1,1,2,7,1,0,1,0,1,4,1,4,1,1,1]

theorem envBound19186 : H12AffineFastState.Bounded env19186 := by
  intro p hp
  have h : env19186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19185_19186 : H12AffineEnvironment.transform 2 6 env19185 = env19186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env19185 == env19186) = true)

def env19187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,16777216,8328,65,16959643,18973836,2596347,67754,17190075,19113457,256,19270663,19328418,17263468]

theorem envBound19187 : H12AffineFastState.Bounded env19187 := by
  intro p hp
  have h : env19187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19045_19187 : H12AffineEnvironment.transform 21 180273 env19045 = env19187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env19045 == env19187) = true)

def env19188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,499128,8328,65,349475,2496820,2596347,67754,119043,2373705,256,2199999,2191386,63188]

theorem envBound19188 : H12AffineFastState.Bounded env19188 := by
  intro p hp
  have h : env19188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19187_19188 : H12AffineEnvironment.transform 23 499128 env19187 = env19188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env19187 == env19188) = true)

def env19189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510123,499128,8328,65,349475,395636,495035,67754,119043,272393,256,98815,90202,63188]

theorem envBound19189 : H12AffineFastState.Bounded env19189 := by
  intro p hp
  have h : env19189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19188_19189 : H12AffineEnvironment.transform 20 4160 env19188 = env19189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19188 == env19189) = true)

theorem identity19189 : scanCanonicalize (H12AffineFastState.compose env19189 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19189 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,180273,452768,441779,8328,65,292136,395636,437680,10401,61704,272393,256,41460,16465,63188]

theorem envBound19190 : H12AffineFastState.Bounded env19190 := by
  intro p hp
  have h : env19190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19189_19190 : H12AffineEnvironment.transform 15 8203 env19189 = env19190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19189 == env19190) = true)

theorem identity19190 : scanCanonicalize (H12AffineFastState.compose env19190 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound19190 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,146744,1024,32769,4160,180273,54680,32907,8328,65,149520,13388,37000,10401,61704,136497,256,41460,16465,63188]

theorem envBound19191 : H12AffineFastState.Bounded env19191 := by
  intro p hp
  have h : env19191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19190_19191 : H12AffineEnvironment.transform 17 146744 env19190 = env19191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env19190 == env19191) = true)

theorem identity19191 : scanCanonicalize (H12AffineFastState.compose env19191 (packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19191 : packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,146744,1024,0,4160,147504,21913,138,8328,65,149520,13388,4233,10401,28937,136497,256,8693,16465,30421]

theorem envBound19192 : H12AffineFastState.Bounded env19192 := by
  intro p hp
  have h : env19192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19191_19192 : H12AffineEnvironment.transform 14 1 env19191 = env19192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19191 == env19192) = true)

theorem identity19192 : scanCanonicalize (H12AffineFastState.compose env19192 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound19192 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env19193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,24909,23669,1024,0,4160,8573,21913,138,8328,65,10589,13388,4233,10401,28937,29820,256,8693,16465,30421]

theorem envBound19193 : H12AffineFastState.Bounded env19193 := by
  intro p hp
  have h : env19193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19192_19193 : H12AffineEnvironment.transform 16 24909 env19192 = env19193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env19192 == env19193) = true)

theorem identity19193 : scanCanonicalize (H12AffineFastState.compose env19193 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound19193 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env19194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,8203,5529,10401,1024,0,4160,8573,8525,138,8328,65,10589,13388,4233,10401,1501,168,256,8693,13445,513]

theorem envBound19194 : H12AffineFastState.Bounded env19194 := by
  intro p hp
  have h : env19194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19193_19194 : H12AffineEnvironment.transform 13 13524 env19193 = env19194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env19193 == env19194) = true)

theorem identity19194 : scanCanonicalize (H12AffineFastState.compose env19194 (packedSelected [1,3,4,5,8,9,12,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19194 : packedSelected [1,3,4,5,8,9,12,23] rootPS < 2^1333 := by decide +kernel

def env19195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5392,10280,1024,0,4160,8573,8525,3,8193,65,10589,13388,4096,10280,1364,33,256,8572,13324,513]

theorem envBound19195 : H12AffineFastState.Bounded env19195 := by
  intro p hp
  have h : env19195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19194_19195 : H12AffineEnvironment.transform 6 9 env19194 = env19195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19194 == env19195) = true)

theorem identity19195 : scanCanonicalize (H12AffineFastState.compose env19195 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19195 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2421,1024,0,4160,32,16,3,348,65,2048,5393,4096,2421,1364,33,256,33,5457,513]

theorem envBound19196 : H12AffineFastState.Bounded env19196 := by
  intro p hp
  have h : env19196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19195_19196 : H12AffineEnvironment.transform 12 349 env19195 = env19196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19195 == env19196) = true)

theorem identity19196 : scanCanonicalize (H12AffineFastState.compose env19196 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound19196 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5376,1,342,5392,1306,1024,0,4160,32,16,3,348,65,1135,5393,4096,1306,1364,33,256,33,5457,513]

theorem envBound19197 : H12AffineFastState.Bounded env19197 := by
  intro p hp
  have h : env19197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19196_19197 : H12AffineEnvironment.transform 10 1135 env19196 = env19197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env19196 == env19197) = true)

def env19198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510123,499128,8328,65,349475,395637,495034,67754,119043,272392,256,98814,90203,63188]

theorem envBound19198 : H12AffineFastState.Bounded env19198 := by
  intro p hp
  have h : env19198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19188_19198 : H12AffineEnvironment.transform 20 4161 env19188 = env19198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19188 == env19198) = true)

theorem identity19198 : scanCanonicalize (H12AffineFastState.compose env19198 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound19198 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,180273,16,21763,8328,65,171416,115150,17665,67754,119043,254131,256,98814,90203,63188]

theorem envBound19199 : H12AffineFastState.Bounded env19199 := by
  intro p hp
  have h : env19199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19198_19199 : H12AffineEnvironment.transform 17 247995 env19198 = env19199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env19198 == env19199) = true)

def env19200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180273,16,21763,8192,65,171280,115014,17665,67618,119043,254011,256,98678,90203,63068]

theorem envBound19200 : H12AffineFastState.Bounded env19200 := by
  intro p hp
  have h : env19200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19199_19200 : H12AffineEnvironment.transform 6 8 env19199 = env19200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19199 == env19200) = true)

theorem identity19200 : scanCanonicalize (H12AffineFastState.compose env19200 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound19200 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,32041,1024,32769,4161,95531,16,21763,8192,65,75786,115014,17665,67618,119043,21793,256,98678,90203,63068]

theorem envBound19201 : H12AffineFastState.Bounded env19201 := by
  intro p hp
  have h : env19201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19200_19201 : H12AffineEnvironment.transform 16 111898 env19200 = env19201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env19200 == env19201) = true)

theorem identity19201 : scanCanonicalize (H12AffineFastState.compose env19201 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound19201 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env19202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,46156,32041,1024,32769,4161,29821,16,21763,8192,65,10588,49168,17665,2420,53333,21793,256,32800,24845,63068]

theorem envBound19202 : H12AffineFastState.Bounded env19202 := by
  intro p hp
  have h : env19202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19201_19202 : H12AffineEnvironment.transform 15 342 env19201 = env19202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env19201 == env19202) = true)

theorem identity19202 : scanCanonicalize (H12AffineFastState.compose env19202 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound19202 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,342,13624,32041,1024,373,4161,29821,16,21763,8192,65,10588,16740,17665,2420,20769,21793,256,340,24845,30504]

theorem envBound19203 : H12AffineFastState.Bounded env19203 := by
  intro p hp
  have h : env19203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19202_19203 : H12AffineEnvironment.transform 14 372 env19202 = env19203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env19202 == env19203) = true)

theorem identity19203 : scanCanonicalize (H12AffineFastState.compose env19203 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19203 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,372,342,13624,10589,1024,373,4161,8201,16,375,8192,65,10588,5392,4469,2420,1365,341,256,340,13689,9052]

theorem envBound19204 : H12AffineFastState.Bounded env19204 := by
  intro p hp
  have h : env19204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19203_19204 : H12AffineEnvironment.transform 13 5236 env19203 = env19204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19203 == env19204) = true)

theorem identity19204 : scanCanonicalize (H12AffineFastState.compose env19204 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19204 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19205 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4452,372,342,12328,10589,272,373,4161,8201,16,375,8192,65,10588,4096,4469,2420,69,341,256,340,12393,9052]

theorem envBound19205 : H12AffineFastState.Bounded env19205 := by
  intro p hp
  have h : env19205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19204_19205 : H12AffineEnvironment.transform 9 272 env19204 = env19205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19204 == env19205) = true)

theorem identity19205 : scanCanonicalize (H12AffineFastState.compose env19205 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19205 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env19206 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,4112,0,34,12328,10281,100,1,4161,8201,16,3,8192,65,10280,4096,4097,2048,69,33,116,32,12393,8744]

theorem envBound19206 : H12AffineFastState.Bounded env19206 := by
  intro p hp
  have h : env19206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19205_19206 : H12AffineEnvironment.transform 7 116 env19205 = env19206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19205 == env19206) = true)

theorem identity19206 : scanCanonicalize (H12AffineFastState.compose env19206 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound19206 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19207 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,2089,4112,0,34,6145,0,100,1,4161,2080,16,3,2089,65,1,4096,4097,2048,69,33,116,32,6208,2561]

theorem envBound19207 : H12AffineFastState.Bounded env19207 := by
  intro p hp
  have h : env19207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19206_19207 : H12AffineEnvironment.transform 12 2089 env19206 = env19207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env19206 == env19207) = true)

theorem identity19207 : scanCanonicalize (H12AffineFastState.compose env19207 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19207 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env19208 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2113,2089,2129,0,34,64,0,100,1,2048,2080,16,3,2089,65,1,2113,2112,2048,69,33,116,32,1,2561]

theorem envBound19208 : H12AffineFastState.Bounded env19208 := by
  intro p hp
  have h : env19208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19207_19208 : H12AffineEnvironment.transform 11 2113 env19207 = env19208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19207 == env19208) = true)

theorem identity19208 : scanCanonicalize (H12AffineFastState.compose env19208 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19208 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19209 : List Nat := [2,4,8,16,32,64,8,116,512,100,0,65,41,81,0,34,64,0,100,1,0,32,16,3,41,65,1,65,64,0,69,33,116,32,1,513]

theorem envBound19209 : H12AffineFastState.Bounded env19209 := by
  intro p hp
  have h : env19209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19208_19209 : H12AffineEnvironment.transform 10 0 env19208 = env19209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19208 == env19209) = true)

theorem identity19209 : scanCanonicalize (H12AffineFastState.compose env19209 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound19209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19210 : List Nat := [2,4,8,16,32,64,8,116,81,100,0,65,41,81,0,34,64,0,100,1,0,32,16,3,41,65,1,65,64,0,69,33,116,32,1,80]

theorem envBound19210 : H12AffineFastState.Bounded env19210 := by
  intro p hp
  have h : env19210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19209_19210 : H12AffineEnvironment.transform 8 81 env19209 = env19210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env19209 == env19210) = true)

theorem identity19210 : scanCanonicalize (H12AffineFastState.compose env19210 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19211 : List Nat := [2,4,3,16,32,64,3,116,81,100,0,65,34,81,0,34,64,0,100,1,0,32,16,3,34,65,1,65,64,0,69,33,116,32,1,80]

theorem envBound19211 : H12AffineFastState.Bounded env19211 := by
  intro p hp
  have h : env19211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19210_19211 : H12AffineEnvironment.transform 2 3 env19210 = env19211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19210 == env19211) = true)

theorem identity19211 : scanCanonicalize (H12AffineFastState.compose env19211 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19212 : List Nat := [2,4,3,16,32,16,3,36,1,52,0,17,34,1,0,34,16,0,52,1,0,32,16,3,34,17,1,17,16,0,21,33,36,32,1,0]

theorem envBound19212 : H12AffineFastState.Bounded env19212 := by
  intro p hp
  have h : env19212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19211_19212 : H12AffineEnvironment.transform 5 16 env19211 = env19212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19211 == env19212) = true)

def env19213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180273,16,21763,8193,65,171281,115015,17665,67619,119043,254010,256,98679,90203,63069]

theorem envBound19213 : H12AffineFastState.Bounded env19213 := by
  intro p hp
  have h : env19213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19199_19213 : H12AffineEnvironment.transform 6 9 env19199 = env19213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19199 == env19213) = true)

theorem identity19213 : scanCanonicalize (H12AffineFastState.compose env19213 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound19213 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,56436,1024,32769,4161,119927,16,21763,8193,65,100695,115015,17665,67619,119043,62588,256,98679,90203,63069]

theorem envBound19214 : H12AffineFastState.Bounded env19214 := by
  intro p hp
  have h : env19214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19213_19214 : H12AffineEnvironment.transform 16 70726 env19213 = env19214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env19213 == env19214) = true)

theorem identity19214 : scanCanonicalize (H12AffineFastState.compose env19214 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound19214 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,57677,56436,1024,32769,4161,8572,16,21763,8193,65,31836,13388,17665,64808,9224,62588,256,29820,38224,63069]

theorem envBound19215 : H12AffineFastState.Bounded env19215 := by
  intro p hp
  have h : env19215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19214_19215 : H12AffineEnvironment.transform 15 62731 env19214 = env19215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env19214 == env19215) = true)

theorem identity19215 : scanCanonicalize (H12AffineFastState.compose env19215 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19215 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env19216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,41050,46108,35109,1024,32769,4161,8572,16,82,8193,65,10509,13388,4176,43129,9224,41261,256,8493,38224,41740]

theorem envBound19216 : H12AffineFastState.Bounded env19216 := by
  intro p hp
  have h : env19216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19215_19216 : H12AffineEnvironment.transform 13 5457 env19215 = env19216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env19215 == env19216) = true)

theorem identity19216 : scanCanonicalize (H12AffineFastState.compose env19216 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19216 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,263,5441,10360,1024,8540,4161,8572,16,82,8193,65,10509,13388,4176,2340,9224,112,256,8493,13325,593]

theorem envBound19217 : H12AffineFastState.Bounded env19217 := by
  intro p hp
  have h : env19217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19216_19217 : H12AffineEnvironment.transform 14 8541 env19216 = env19217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19216 == env19217) = true)

theorem identity19217 : scanCanonicalize (H12AffineFastState.compose env19217 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19217 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,1,263,5441,2340,1024,0,4161,32,16,82,349,65,2129,5392,4176,2340,1364,112,256,113,5457,593]

theorem envBound19218 : H12AffineFastState.Bounded env19218 := by
  intro p hp
  have h : env19218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19217_19218 : H12AffineEnvironment.transform 12 348 env19217 = env19218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19217 == env19218) = true)

theorem identity19218 : scanCanonicalize (H12AffineFastState.compose env19218 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19218 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env19219 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4453,1,263,4469,2340,52,0,4161,32,16,82,349,65,2129,4388,4176,2340,352,112,256,113,4453,593]

theorem envBound19219 : H12AffineFastState.Bounded env19219 := by
  intro p hp
  have h : env19219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19218_19219 : H12AffineEnvironment.transform 9 52 env19218 = env19219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19218 == env19219) = true)

def env19220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,499129,8328,65,349474,2496821,2596347,67754,119042,2373704,256,2199998,2191387,63189]

theorem envBound19220 : H12AffineFastState.Bounded env19220 := by
  intro p hp
  have h : env19220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19187_19220 : H12AffineEnvironment.transform 23 499129 env19187 = env19220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env19187 == env19220) = true)

def env19221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510123,499129,8328,65,349474,395637,495035,67754,119042,272392,256,98814,90203,63189]

theorem envBound19221 : H12AffineFastState.Bounded env19221 := by
  intro p hp
  have h : env19221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19220_19221 : H12AffineEnvironment.transform 20 4160 env19220 = env19221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19220 == env19221) = true)

theorem identity19221 : scanCanonicalize (H12AffineFastState.compose env19221 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound19221 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4160,180273,62660,41430,8328,65,158029,79130,45524,67754,119042,201831,256,98814,90203,63189]

theorem envBound19222 : H12AffineFastState.Bounded env19222 := by
  intro p hp
  have h : env19222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19221_19222 : H12AffineEnvironment.transform 17 212079 env19221 = env19222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env19221 == env19222) = true)

theorem identity19222 : scanCanonicalize (H12AffineFastState.compose env19222 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound19222 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212079,1024,29909,4160,144613,16,21762,8328,65,158029,79130,17664,67754,75222,201831,256,95530,90203,513]

theorem envBound19223 : H12AffineFastState.Bounded env19223 := by
  intro p hp
  have h : env19223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19222_19223 : H12AffineEnvironment.transform 14 29908 env19222 = env19223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env19222 == env19223) = true)

theorem identity19223 : scanCanonicalize (H12AffineFastState.compose env19223 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound19223 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env19224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,131072,146744,1024,29909,4160,144613,16,21762,8328,65,158029,13389,17664,2557,9345,136496,256,29821,24844,513]

theorem envBound19224 : H12AffineFastState.Bounded env19224 := by
  intro p hp
  have h : env19224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19223_19224 : H12AffineEnvironment.transform 15 343 env19223 = env19224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env19223 == env19224) = true)

theorem identity19224 : scanCanonicalize (H12AffineFastState.compose env19224 (packedSelected [4,5,8,9,10,14,15,17,18,20,23,24,26,28,38] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound19224 : packedSelected [4,5,8,9,10,14,15,17,18,20,23,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env19225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16537,32161,1024,29909,4160,29820,16,21762,8328,65,10708,13389,17664,2557,9345,21929,256,29821,24844,513]

theorem envBound19225 : H12AffineFastState.Bounded env19225 := by
  intro p hp
  have h : env19225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19224_19225 : H12AffineEnvironment.transform 16 16537 env19224 = env19225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env19224 == env19225) = true)

theorem identity19225 : scanCanonicalize (H12AffineFastState.compose env19225 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19225 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env19226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,16400,32040,1024,29788,4160,29820,16,21762,8193,65,10589,13389,17664,2420,9224,21792,256,29821,24844,513]

theorem envBound19226 : H12AffineFastState.Bounded env19226 := by
  intro p hp
  have h : env19226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19225_19226 : H12AffineEnvironment.transform 6 9 env19225 = env19226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19225 == env19226) = true)

theorem identity19226 : scanCanonicalize (H12AffineFastState.compose env19226 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19226 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19227 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,263,16400,32040,1024,29708,4112,29740,16,21762,8193,17,10509,13341,17664,2340,9224,21792,256,29741,24844,513]

theorem envBound19227 : H12AffineFastState.Bounded env19227 := by
  intro p hp
  have h : env19227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19226_19227 : H12AffineEnvironment.transform 5 16 env19226 = env19227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19226 == env19227) = true)

theorem identity19227 : scanCanonicalize (H12AffineFastState.compose env19227 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19227 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19228 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,263,13340,2340,1024,0,4112,32,16,8462,8193,17,10509,13341,12556,2340,9224,8492,256,33,5376,513]

theorem envBound19228 : H12AffineFastState.Bounded env19228 := by
  intro p hp
  have h : env19228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19227_19228 : H12AffineEnvironment.transform 13 13324 env19227 = env19228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19227 == env19228) = true)

theorem identity19228 : scanCanonicalize (H12AffineFastState.compose env19228 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19228 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19229 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,263,5392,2340,1024,0,4112,32,16,2,269,17,2049,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound19229 : H12AffineFastState.Bounded env19229 := by
  intro p hp
  have h : env19229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19228_19229 : H12AffineEnvironment.transform 12 268 env19228 = env19229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19228 == env19229) = true)

theorem identity19229 : scanCanonicalize (H12AffineFastState.compose env19229 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound19229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19230 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,57,5173,1,50,5157,2065,1024,0,4112,32,16,2,56,17,2049,5156,4096,2065,1073,32,53,33,5173,513]

theorem envBound19230 : H12AffineFastState.Bounded env19230 := by
  intro p hp
  have h : env19230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19229_19230 : H12AffineEnvironment.transform 7 53 env19229 = env19230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env19229 == env19230) = true)

theorem identity19230 : scanCanonicalize (H12AffineFastState.compose env19230 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound19230 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19231 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,3119,57,2074,1,50,2058,2065,1024,0,3135,32,16,2,56,17,2049,2059,3119,2065,1073,32,53,33,2074,513]

theorem envBound19231 : H12AffineFastState.Bounded env19231 := by
  intro p hp
  have h : env19231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19230_19231 : H12AffineEnvironment.transform 11 3119 env19230 = env19231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env19230 == env19231) = true)

theorem identity19231 : scanCanonicalize (H12AffineFastState.compose env19231 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound19231 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19232 : List Nat := [2,4,8,16,32,16,9,53,512,1024,1038,33,57,1044,1,50,1028,1055,1024,0,49,32,16,2,56,17,1039,1029,33,1055,1073,32,53,33,1044,513]

theorem envBound19232 : H12AffineFastState.Bounded env19232 := by
  intro p hp
  have h : env19232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19231_19232 : H12AffineEnvironment.transform 10 1038 env19231 = env19232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env19231 == env19232) = true)

theorem identity19232 : scanCanonicalize (H12AffineFastState.compose env19232 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound19232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19233 : List Nat := [2,4,8,16,32,16,9,53,512,46,32,33,57,58,1,50,42,49,46,0,49,32,16,2,56,17,33,43,33,49,31,32,53,33,58,513]

theorem envBound19233 : H12AffineFastState.Bounded env19233 := by
  intro p hp
  have h : env19233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19232_19233 : H12AffineEnvironment.transform 9 46 env19232 = env19233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env19232 == env19233) = true)

theorem identity19233 : scanCanonicalize (H12AffineFastState.compose env19233 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19233 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env19234 : List Nat := [2,4,8,10,32,10,9,47,512,46,32,33,35,32,1,40,42,43,46,0,43,32,10,2,34,11,33,43,33,43,5,32,47,33,32,513]

theorem envBound19234 : H12AffineFastState.Bounded env19234 := by
  intro p hp
  have h : env19234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19233_19234 : H12AffineEnvironment.transform 3 10 env19233 = env19234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19233 == env19234) = true)

theorem identity19234 : scanCanonicalize (H12AffineFastState.compose env19234 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound19234 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19235 : List Nat := [2,4,8,10,32,10,9,47,13,46,32,33,35,32,1,40,42,43,46,0,43,32,10,2,34,11,33,43,33,43,5,32,47,33,32,12]

theorem envBound19235 : H12AffineFastState.Bounded env19235 := by
  intro p hp
  have h : env19235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19234_19235 : H12AffineEnvironment.transform 8 13 env19234 = env19235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env19234 == env19235) = true)

def env19236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510123,499129,8328,65,349474,395636,495034,67754,119042,272393,256,98815,90202,63189]

theorem envBound19236 : H12AffineFastState.Bounded env19236 := by
  intro p hp
  have h : env19236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19220_19236 : H12AffineEnvironment.transform 20 4161 env19220 = env19236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19220 == env19236) = true)

theorem identity19236 : scanCanonicalize (H12AffineFastState.compose env19236 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound19236 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,180273,400500,412006,8328,65,295421,395636,416101,56437,1501,272393,256,21792,46213,63189]

theorem envBound19237 : H12AffineFastState.Bounded env19237 := by
  intro p hp
  have h : env19237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19236_19237 : H12AffineEnvironment.transform 15 54495 env19236 = env19237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env19236 == env19237) = true)

def env19238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180273,400500,412006,8192,65,295285,395636,416101,56437,1365,272393,256,21792,46093,63069]

theorem envBound19238 : H12AffineFastState.Bounded env19238 := by
  intro p hp
  have h : env19238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19237_19238 : H12AffineEnvironment.transform 6 8 env19237 = env19238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19237 == env19238) = true)

theorem identity19238 : scanCanonicalize (H12AffineFastState.compose env19238 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 171281) := by decide +kernel

theorem selectedBound19238 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env19239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,171281,1024,32769,4161,180273,33125,54391,8192,65,138340,37989,50292,56437,1365,177432,256,21792,46093,63069]

theorem envBound19239 : H12AffineFastState.Bounded env19239 := by
  intro p hp
  have h : env19239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19238_19239 : H12AffineEnvironment.transform 17 171281 env19238 = env19239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171281 env19238 == env19239) = true)

theorem identity19239 : scanCanonicalize (H12AffineFastState.compose env19239 (packedSelected [2,3,4,6,7,10,11,14,16,17,20,22,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound19239 : packedSelected [2,3,4,6,7,10,11,14,16,17,20,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,262,131072,149568,1024,21840,4161,136544,21556,294,8192,65,138340,16692,4389,2340,1365,155721,256,21792,24924,8972]

theorem envBound19240 : H12AffineFastState.Bounded env19240 := by
  intro p hp
  have h : env19240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19239_19240 : H12AffineEnvironment.transform 14 21841 env19239 = env19240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env19239 == env19240) = true)

theorem identity19240 : scanCanonicalize (H12AffineFastState.compose env19240 (packedSelected [2,4,6,11,17,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound19240 : packedSelected [2,4,6,11,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env19241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,262,16692,2420,1024,21840,4161,21588,21556,294,8192,65,23888,16692,4389,2340,1365,8573,256,21792,24924,8972]

theorem envBound19241 : H12AffineFastState.Bounded env19241 := by
  intro p hp
  have h : env19241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19240_19241 : H12AffineEnvironment.transform 16 16692 env19240 = env19241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env19240 == env19241) = true)

theorem identity19241 : scanCanonicalize (H12AffineFastState.compose env19241 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound19241 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21841,262,16692,2420,1024,21840,4161,21588,21556,294,120,65,23888,16692,4389,2340,1365,261,256,21792,16676,884]

theorem envBound19242 : H12AffineFastState.Bounded env19242 := by
  intro p hp
  have h : env19242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19241_19242 : H12AffineEnvironment.transform 12 120 env19241 = env19242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env19241 == env19242) = true)

theorem identity19242 : scanCanonicalize (H12AffineFastState.compose env19242 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19242 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env19243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,293,262,5440,2420,1024,292,4161,32,64,294,120,65,2340,5440,4389,2340,1365,261,256,340,5456,884]

theorem envBound19243 : H12AffineFastState.Bounded env19243 := by
  intro p hp
  have h : env19243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19242_19243 : H12AffineEnvironment.transform 13 5236 env19242 = env19243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19242 == env19243) = true)

theorem identity19243 : scanCanonicalize (H12AffineFastState.compose env19243 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19243 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env19244 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5236,1,34,5220,2128,1024,0,4161,32,64,2,120,65,2048,5220,4097,2048,1137,33,36,112,5236,592]

theorem envBound19244 : H12AffineFastState.Bounded env19244 := by
  intro p hp
  have h : env19244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19243_19244 : H12AffineEnvironment.transform 7 36 env19243 = env19244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19243 == env19244) = true)

theorem identity19244 : scanCanonicalize (H12AffineFastState.compose env19244 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19244 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19245 : List Nat := [2,4,8,16,0,64,8,4,512,1024,2048,4096,88,5204,1,2,5188,2128,1024,0,4161,0,64,2,88,65,2048,5188,4097,2048,1105,1,4,80,5204,592]

theorem envBound19245 : H12AffineFastState.Bounded env19245 := by
  intro p hp
  have h : env19245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19244_19245 : H12AffineEnvironment.transform 4 0 env19244 = env19245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19244 == env19245) = true)

theorem identity19245 : scanCanonicalize (H12AffineFastState.compose env19245 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19245 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19246 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,1,2,5140,2048,1024,0,4113,0,16,2,8,17,2048,5140,4097,2048,1025,1,4,0,5124,512]

theorem envBound19246 : H12AffineFastState.Bounded env19246 := by
  intro p hp
  have h : env19246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19245_19246 : H12AffineEnvironment.transform 5 16 env19245 = env19246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19245 == env19246) = true)

theorem identity19246 : scanCanonicalize (H12AffineFastState.compose env19246 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound19246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19247 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,8,4113,1,2,4097,2048,21,0,4113,0,16,2,8,17,2048,4097,4097,2048,20,1,4,0,4113,512]

theorem envBound19247 : H12AffineFastState.Bounded env19247 := by
  intro p hp
  have h : env19247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19246_19247 : H12AffineEnvironment.transform 9 21 env19246 = env19247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19246 == env19247) = true)

theorem identity19247 : scanCanonicalize (H12AffineFastState.compose env19247 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound19247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19248 : List Nat := [2,4,8,16,0,16,8,4,512,21,20,4096,8,4113,1,2,4097,20,21,0,4113,0,16,2,8,17,20,4097,4097,20,20,1,4,0,4113,512]

theorem envBound19248 : H12AffineFastState.Bounded env19248 := by
  intro p hp
  have h : env19248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19247_19248 : H12AffineEnvironment.transform 10 20 env19247 = env19248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env19247 == env19248) = true)

theorem identity19248 : scanCanonicalize (H12AffineFastState.compose env19248 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 19) := by decide +kernel

theorem selectedBound19248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19249 : List Nat := [2,4,8,16,0,16,8,4,512,21,20,19,8,2,1,2,18,20,21,0,2,0,16,2,8,17,20,18,18,20,20,1,4,0,2,512]

theorem envBound19249 : H12AffineFastState.Bounded env19249 := by
  intro p hp
  have h : env19249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19248_19249 : H12AffineEnvironment.transform 11 19 env19248 = env19249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 19 env19248 == env19249) = true)

theorem identity19249 : scanCanonicalize (H12AffineFastState.compose env19249 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound19249 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19250 : List Nat := [2,4,8,16,0,16,8,4,31,21,20,19,8,2,1,2,18,20,21,0,2,0,16,2,8,17,20,18,18,20,20,1,4,0,2,31]

theorem envBound19250 : H12AffineFastState.Bounded env19250 := by
  intro p hp
  have h : env19250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19249_19250 : H12AffineEnvironment.transform 8 31 env19249 = env19250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env19249 == env19250) = true)

theorem identity19250 : scanCanonicalize (H12AffineFastState.compose env19250 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound19250 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19251 : List Nat := [2,4,8,6,0,6,8,4,9,3,2,5,8,2,1,2,4,2,3,0,2,0,6,2,8,7,2,4,4,2,2,1,4,0,2,9]

theorem envBound19251 : H12AffineFastState.Bounded env19251 := by
  intro p hp
  have h : env19251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19250_19251 : H12AffineEnvironment.transform 3 6 env19250 = env19251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env19250 == env19251) = true)

def env19252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180273,400500,412006,8193,65,295284,395636,416101,56437,1364,272393,256,21792,46092,63068]

theorem envBound19252 : H12AffineFastState.Bounded env19252 := by
  intro p hp
  have h : env19252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19237_19252 : H12AffineEnvironment.transform 6 9 env19237 = env19252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19237 == env19252) = true)

theorem identity19252 : scanCanonicalize (H12AffineFastState.compose env19252 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound19252 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env19253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,182628,1024,32769,4161,180273,54544,32770,8193,65,149520,49168,36865,56437,1364,188781,256,21792,46092,63068]

theorem envBound19253 : H12AffineFastState.Bounded env19253 := by
  intro p hp
  have h : env19253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19252_19253 : H12AffineEnvironment.transform 17 182628 env19252 = env19253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env19252 == env19253) = true)

theorem identity19253 : scanCanonicalize (H12AffineFastState.compose env19253 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19253 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,146745,1024,29788,4161,144492,8525,29791,8193,65,149520,13389,25692,10280,1364,136496,256,21792,16465,513]

theorem envBound19254 : H12AffineFastState.Bounded env19254 := by
  intro p hp
  have h : env19254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19253_19254 : H12AffineEnvironment.transform 14 29789 env19253 = env19254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19253 == env19254) = true)

theorem identity19254 : scanCanonicalize (H12AffineFastState.compose env19254 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19254 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env19255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146745,1024,8541,4161,144492,8525,8542,8193,65,138513,13389,12637,10280,1364,136496,256,33,5456,513]

theorem envBound19255 : H12AffineFastState.Bounded env19255 := by
  intro p hp
  have h : env19255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19254_19255 : H12AffineEnvironment.transform 13 5377 env19254 = env19255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19254 == env19255) = true)

theorem identity19255 : scanCanonicalize (H12AffineFastState.compose env19255 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound19255 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env19256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,13388,2421,1024,8541,4161,32,8525,8542,8193,65,10589,13389,12637,10280,1364,8572,256,33,5456,513]

theorem envBound19256 : H12AffineFastState.Bounded env19256 := by
  intro p hp
  have h : env19256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19255_19256 : H12AffineEnvironment.transform 16 13388 env19255 = env19256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env19255 == env19256) = true)

theorem identity19256 : scanCanonicalize (H12AffineFastState.compose env19256 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19256 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5392,2421,1024,1,4161,32,17,2,349,65,2049,5393,4097,2420,1364,32,256,33,5456,513]

theorem envBound19257 : H12AffineFastState.Bounded env19257 := by
  intro p hp
  have h : env19257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19256_19257 : H12AffineEnvironment.transform 12 348 env19256 = env19257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19256 == env19257) = true)

theorem identity19257 : scanCanonicalize (H12AffineFastState.compose env19257 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound19257 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19258 : List Nat := [2,4,8,16,32,64,9,256,292,1024,2048,4096,348,5377,0,343,5392,2421,1024,1,4161,32,17,2,349,65,2049,5393,4097,2420,1364,32,256,33,5456,293]

theorem envBound19258 : H12AffineFastState.Bounded env19258 := by
  intro p hp
  have h : env19258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19257_19258 : H12AffineEnvironment.transform 8 292 env19257 = env19258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env19257 == env19258) = true)

theorem identity19258 : scanCanonicalize (H12AffineFastState.compose env19258 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19258 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19259 : List Nat := [2,4,8,16,32,16,9,256,292,1024,2048,4096,268,5377,0,263,5392,2341,1024,1,4113,32,17,2,269,17,2049,5393,4097,2340,1284,32,256,33,5376,293]

theorem envBound19259 : H12AffineFastState.Bounded env19259 := by
  intro p hp
  have h : env19259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19258_19259 : H12AffineEnvironment.transform 5 16 env19258 = env19259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19258 == env19259) = true)

theorem identity19259 : scanCanonicalize (H12AffineFastState.compose env19259 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19260 : List Nat := [2,4,8,16,17,16,9,256,277,1024,2048,4096,268,5377,0,263,5392,2324,1024,1,4113,17,17,2,269,17,2049,5393,4097,2325,1284,17,256,16,5376,276]

theorem envBound19260 : H12AffineFastState.Bounded env19260 := by
  intro p hp
  have h : env19260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19259_19260 : H12AffineEnvironment.transform 4 17 env19259 = env19260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19259 == env19260) = true)

theorem identity19260 : scanCanonicalize (H12AffineFastState.compose env19260 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2309) := by decide +kernel

theorem selectedBound19260 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19261 : List Nat := [2,4,8,16,17,16,9,256,277,1024,2048,2309,268,3076,0,263,3093,2324,1024,1,2324,17,17,2,269,17,2049,3092,2308,2325,1284,17,256,16,3077,276]

theorem envBound19261 : H12AffineFastState.Bounded env19261 := by
  intro p hp
  have h : env19261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19260_19261 : H12AffineEnvironment.transform 11 2309 env19260 = env19261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2309 env19260 == env19261) = true)

theorem identity19261 : scanCanonicalize (H12AffineFastState.compose env19261 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19261 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19262 : List Nat := [2,4,8,1,0,1,9,256,260,1024,2048,2309,268,3076,0,263,3076,2309,1024,1,2309,0,0,2,269,0,2049,3077,2308,2308,1284,0,256,1,3077,261]

theorem envBound19262 : H12AffineFastState.Bounded env19262 := by
  intro p hp
  have h : env19262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19261_19262 : H12AffineEnvironment.transform 3 1 env19261 = env19262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19261 == env19262) = true)

theorem identity19262 : scanCanonicalize (H12AffineFastState.compose env19262 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound19262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19263 : List Nat := [2,4,8,1,0,1,9,256,260,1024,261,0,268,1281,0,263,1281,0,1024,1,0,0,0,2,269,0,260,1280,1,1,1284,0,256,1,1280,261]

theorem envBound19263 : H12AffineFastState.Bounded env19263 := by
  intro p hp
  have h : env19263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19262_19263 : H12AffineEnvironment.transform 10 261 env19262 = env19263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env19262 == env19263) = true)

theorem identity19263 : scanCanonicalize (H12AffineFastState.compose env19263 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19263 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env19264 : List Nat := [2,4,8,1,0,1,9,4,0,1024,1,0,8,1029,0,3,1029,0,1024,1,0,0,0,2,9,0,0,1028,1,1,1024,0,4,1,1028,1]

theorem envBound19264 : H12AffineFastState.Bounded env19264 := by
  intro p hp
  have h : env19264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19263_19264 : H12AffineEnvironment.transform 7 4 env19263 = env19264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19263 == env19264) = true)

theorem identity19264 : scanCanonicalize (H12AffineFastState.compose env19264 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound19264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19265 : List Nat := [2,4,8,1,0,1,9,4,0,4,1,0,8,1,0,3,1,0,4,1,0,0,0,2,9,0,0,0,1,1,4,0,4,1,0,1]

theorem envBound19265 : H12AffineFastState.Bounded env19265 := by
  intro p hp
  have h : env19265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19264_19265 : H12AffineEnvironment.transform 9 4 env19264 = env19265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env19264 == env19265) = true)

def env19266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound19266 : H12AffineFastState.Bounded env19266 := by
  intro p hp
  have h : env19266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19043_19266 : H12AffineEnvironment.transform 18 1025 env19043 = env19266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19043 == env19266) = true)

theorem identity19266 : scanCanonicalize (H12AffineFastState.compose env19266 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound19266 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272426,8328,65,12838954,2469031,10507600,8830976,8760378,6639082,257,10873991,10816803,8686572]

theorem envBound19267 : H12AffineFastState.Bounded env19267 := by
  intro p hp
  have h : env19267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19266_19267 : H12AffineEnvironment.transform 23 272426 env19266 = env19267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env19266 == env19267) = true)

def env19268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272426,8328,65,4303010,2469031,2233816,295048,519346,6639082,257,2599951,2575787,445284]

theorem envBound19268 : H12AffineFastState.Bounded env19268 := by
  intro p hp
  have h : env19268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19267_19268 : H12AffineEnvironment.transform 22 147592 env19267 = env19268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env19267 == env19268) = true)

def env19269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303010,2469031,2119112,295048,371874,6639082,257,2485279,2428347,297844]

theorem envBound19269 : H12AffineFastState.Bounded env19269 := by
  intro p hp
  have h : env19269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19268_19269 : H12AffineEnvironment.transform 16 16400 env19268 = env19269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19268 == env19269) = true)

theorem identity19269 : scanCanonicalize (H12AffineFastState.compose env19269 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound19269 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1025,32769,2097152,4194304,152,138,8328,65,4303010,2196487,2119112,43048,99330,6382922,257,2213055,2172187,41940]

theorem envBound19270 : H12AffineFastState.Bounded env19270 := by
  intro p hp
  have h : env19270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19269_19270 : H12AffineEnvironment.transform 17 10400 env19269 = env19270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19269 == env19270) = true)

theorem identity19270 : scanCanonicalize (H12AffineFastState.compose env19270 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound19270 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env19271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16400,10400,1025,8660,2097152,4194304,152,138,8328,65,4262263,2172370,2119112,2557,75223,6382922,257,2188650,2172187,513]

theorem envBound19271 : H12AffineFastState.Bounded env19271 := by
  intro p hp
  have h : env19271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19270_19271 : H12AffineEnvironment.transform 14 8661 env19270 = env19271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env19270 == env19271) = true)

theorem identity19271 : scanCanonicalize (H12AffineFastState.compose env19271 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19271 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16400,10400,1025,8660,2097152,4194304,152,138,8328,65,4204925,2098648,2119112,2557,1501,6309184,257,2114912,2098449,513]

theorem envBound19272 : H12AffineFastState.Bounded env19272 := by
  intro p hp
  have h : env19272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19271_19272 : H12AffineEnvironment.transform 15 8202 env19271 = env19272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19271 == env19272) = true)

theorem identity19272 : scanCanonicalize (H12AffineFastState.compose env19272 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound19272 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env19273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16400,10400,1025,8660,2097152,169,152,138,8328,65,10708,2098648,2119112,2557,1501,2115049,257,2114912,2098449,513]

theorem envBound19273 : H12AffineFastState.Bounded env19273 := by
  intro p hp
  have h : env19273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19272_19273 : H12AffineEnvironment.transform 21 169 env19272 = env19273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env19272 == env19273) = true)

theorem identity19273 : scanCanonicalize (H12AffineFastState.compose env19273 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19273 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env19274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8202,16400,10400,1025,8581,2097152,169,152,138,8328,16,10629,2098569,2119065,2476,1420,2115000,257,2114865,2098449,513]

theorem envBound19274 : H12AffineFastState.Bounded env19274 := by
  intro p hp
  have h : env19274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19273_19274 : H12AffineEnvironment.transform 5 17 env19273 = env19274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19273 == env19274) = true)

theorem identity19274 : scanCanonicalize (H12AffineFastState.compose env19274 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound19274 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8202,16400,10400,1025,8581,17681,169,152,138,8328,16,10629,16536,4232,2476,1420,169,257,32,16384,513]

theorem envBound19275 : H12AffineFastState.Bounded env19275 := by
  intro p hp
  have h : env19275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19274_19275 : H12AffineEnvironment.transform 20 17681 env19274 = env19275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env19274 == env19275) = true)

def env19276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303010,2469031,2119113,295048,371875,6639082,257,2485278,2428346,297845]

theorem envBound19276 : H12AffineFastState.Bounded env19276 := by
  intro p hp
  have h : env19276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19268_19276 : H12AffineEnvironment.transform 16 16401 env19268 = env19276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19268 == env19276) = true)

theorem identity19276 : scanCanonicalize (H12AffineFastState.compose env19276 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19276 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,272426,8192,65,4302890,2468911,2118977,294912,371755,6638946,257,2485278,2428210,297845]

theorem envBound19277 : H12AffineFastState.Bounded env19277 := by
  intro p hp
  have h : env19277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19276_19277 : H12AffineEnvironment.transform 6 8 env19276 = env19277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19276 == env19277) = true)

theorem identity19277 : scanCanonicalize (H12AffineFastState.compose env19277 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound19277 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302890,2172251,2118977,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound19278 : H12AffineFastState.Bounded env19278 := by
  intro p hp
  have h : env19278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19277_19278 : H12AffineEnvironment.transform 17 35188 env19277 = env19278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env19277 == env19278) = true)

theorem identity19278 : scanCanonicalize (H12AffineFastState.compose env19278 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound19278 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115734,4194304,17,41310,8192,65,4302890,57677,102743,2420,75103,4194304,257,41340,16464,513]

theorem envBound19279 : H12AffineFastState.Bounded env19279 := by
  intro p hp
  have h : env19279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19278_19279 : H12AffineEnvironment.transform 20 115734 env19278 = env19279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env19278 == env19279) = true)

def env19280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91198,4194304,17,374,8192,65,4261890,16741,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound19280 : H12AffineFastState.Bounded env19280 := by
  intro p hp
  have h : env19280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19279_19280 : H12AffineEnvironment.transform 14 8232 env19279 = env19280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19279 == env19280) = true)

theorem identity19280 : scanCanonicalize (H12AffineFastState.compose env19280 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19280 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env19281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,373,65536,16401,2049,1025,372,83299,4194304,17,374,349,65,4261890,16741,69666,2420,66562,4194304,257,340,16464,513]

theorem envBound19281 : H12AffineFastState.Bounded env19281 := by
  intro p hp
  have h : env19281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19280_19281 : H12AffineEnvironment.transform 12 349 env19280 = env19281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19280 == env19281) = true)

theorem identity19281 : scanCanonicalize (H12AffineFastState.compose env19281 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19281 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env19282 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,65536,16401,2049,1025,0,82967,4194304,17,2,41,65,4261890,16401,69666,2048,66562,4194304,117,32,16464,513]

theorem envBound19282 : H12AffineFastState.Bounded env19282 := by
  intro p hp
  have h : env19282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19281_19282 : H12AffineEnvironment.transform 7 116 env19281 = env19282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19281 == env19282) = true)

theorem identity19282 : scanCanonicalize (H12AffineFastState.compose env19282 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound19282 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19283 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,34,16401,2049,1025,0,17461,4194304,17,2,41,65,4196384,16401,4096,2048,1056,4194304,117,32,16464,513]

theorem envBound19283 : H12AffineFastState.Bounded env19283 := by
  intro p hp
  have h : env19283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19282_19283 : H12AffineEnvironment.transform 15 34 env19282 = env19283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env19282 == env19283) = true)

theorem identity19283 : scanCanonicalize (H12AffineFastState.compose env19283 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19283 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19284 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,34,16401,2049,1025,0,17461,4194304,17,2,41,16,4196384,16401,4096,2048,1056,4194304,36,32,16385,513]

theorem envBound19284 : H12AffineFastState.Bounded env19284 := by
  intro p hp
  have h : env19284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19283_19284 : H12AffineEnvironment.transform 5 17 env19283 = env19284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19283 == env19284) = true)

theorem identity19284 : scanCanonicalize (H12AffineFastState.compose env19284 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound19284 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19285 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5172,2049,1025,0,4112,4194304,17,2,41,16,4196384,5172,4096,2048,1056,4194304,36,32,5156,513]

theorem envBound19285 : H12AffineFastState.Bounded env19285 := by
  intro p hp
  have h : env19285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19284_19285 : H12AffineEnvironment.transform 13 5157 env19284 = env19285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env19284 == env19285) = true)

theorem identity19285 : scanCanonicalize (H12AffineFastState.compose env19285 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound19285 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19286 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5172,2049,1025,0,4112,33,17,2,41,16,2049,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound19286 : H12AffineFastState.Bounded env19286 := by
  intro p hp
  have h : env19286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19285_19286 : H12AffineEnvironment.transform 21 33 env19285 = env19286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env19285 == env19286) = true)

def env19287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91199,4194304,17,375,8192,65,4261891,16740,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound19287 : H12AffineFastState.Bounded env19287 := by
  intro p hp
  have h : env19287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19279_19287 : H12AffineEnvironment.transform 14 8233 env19279 = env19287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env19279 == env19287) = true)

theorem identity19287 : scanCanonicalize (H12AffineFastState.compose env19287 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19287 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env19288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,65536,16401,2421,1025,0,82967,4194304,17,375,40,65,4261891,16740,69974,2420,66935,4194304,257,341,16464,513]

theorem envBound19288 : H12AffineFastState.Bounded env19288 := by
  intro p hp
  have h : env19288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19287_19288 : H12AffineEnvironment.transform 12 40 env19287 = env19288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19287 == env19288) = true)

theorem identity19288 : scanCanonicalize (H12AffineFastState.compose env19288 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19288 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,65536,16401,2421,1025,0,82967,32,17,375,40,65,67619,16740,69974,2420,66935,32,257,341,16464,513]

theorem envBound19289 : H12AffineFastState.Bounded env19289 := by
  intro p hp
  have h : env19289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19288_19289 : H12AffineEnvironment.transform 21 32 env19288 = env19289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19288 == env19289) = true)

theorem identity19289 : scanCanonicalize (H12AffineFastState.compose env19289 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19289 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env19290 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,65536,16401,2048,1025,0,82967,32,17,2,40,65,67619,16401,69667,2049,66562,32,116,32,16464,513]

theorem envBound19290 : H12AffineFastState.Bounded env19290 := by
  intro p hp
  have h : env19290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19289_19290 : H12AffineEnvironment.transform 7 117 env19289 = env19290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19289 == env19290) = true)

theorem identity19290 : scanCanonicalize (H12AffineFastState.compose env19290 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound19290 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19291 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,35,16401,2048,1025,0,17460,32,17,2,40,65,2048,16401,4096,2049,1057,32,116,32,16464,513]

theorem envBound19291 : H12AffineFastState.Bounded env19291 := by
  intro p hp
  have h : env19291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19290_19291 : H12AffineEnvironment.transform 15 35 env19290 = env19291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env19290 == env19291) = true)

theorem identity19291 : scanCanonicalize (H12AffineFastState.compose env19291 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound19291 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19292 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,40,16384,1,35,16401,2048,1025,0,17460,32,17,2,40,65,2048,16401,1141,2049,1057,32,116,32,16464,513]

theorem envBound19292 : H12AffineFastState.Bounded env19292 := by
  intro p hp
  have h : env19292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19291_19292 : H12AffineEnvironment.transform 11 1141 env19291 = env19292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env19291 == env19292) = true)

theorem identity19292 : scanCanonicalize (H12AffineFastState.compose env19292 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3684) := by decide +kernel

theorem selectedBound19292 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19293 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,40,3684,1,35,3701,2048,1025,0,2640,32,17,2,40,65,2048,3701,1141,2049,1057,32,116,32,3636,513]

theorem envBound19293 : H12AffineFastState.Bounded env19293 := by
  intro p hp
  have h : env19293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19292_19293 : H12AffineEnvironment.transform 13 3684 env19292 = env19293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3684 env19292 == env19293) = true)

theorem identity19293 : scanCanonicalize (H12AffineFastState.compose env19293 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19293 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19294 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1060,40,3637,1,35,3620,2048,1025,0,2561,32,17,2,40,16,2048,3620,1060,2049,1057,32,37,32,3636,513]

theorem envBound19294 : H12AffineFastState.Bounded env19294 := by
  intro p hp
  have h : env19294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19293_19294 : H12AffineEnvironment.transform 5 17 env19293 = env19294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19293 == env19294) = true)

theorem identity19294 : scanCanonicalize (H12AffineFastState.compose env19294 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19295 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1029,9,3604,1,2,3589,2048,1025,0,2561,1,17,2,9,16,2048,3589,1029,2049,1024,1,4,1,3605,513]

theorem envBound19295 : H12AffineFastState.Bounded env19295 := by
  intro p hp
  have h : env19295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19294_19295 : H12AffineEnvironment.transform 4 1 env19294 = env19295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19294 == env19295) = true)

theorem identity19295 : scanCanonicalize (H12AffineFastState.compose env19295 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound19295 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19296 : List Nat := [2,4,8,16,1,17,8,5,512,516,2048,513,9,2064,1,2,2049,2048,517,0,2561,1,17,2,9,16,2048,2049,513,2049,516,1,4,1,2065,513]

theorem envBound19296 : H12AffineFastState.Bounded env19296 := by
  intro p hp
  have h : env19296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19295_19296 : H12AffineEnvironment.transform 9 516 env19295 = env19296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env19295 == env19296) = true)

theorem identity19296 : scanCanonicalize (H12AffineFastState.compose env19296 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19296 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19297 : List Nat := [2,4,8,16,1,17,8,5,0,4,2048,1,9,2064,1,2,2049,2048,5,0,2049,1,17,2,9,16,2048,2049,1,2049,4,1,4,1,2065,1]

theorem envBound19297 : H12AffineFastState.Bounded env19297 := by
  intro p hp
  have h : env19297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19296_19297 : H12AffineEnvironment.transform 8 0 env19296 = env19297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19296 == env19297) = true)

theorem identity19297 : scanCanonicalize (H12AffineFastState.compose env19297 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19298 : List Nat := [2,4,8,16,1,17,8,5,0,4,1,1,9,17,1,2,0,1,5,0,0,1,17,2,9,16,1,0,1,0,4,1,4,1,16,1]

theorem envBound19298 : H12AffineFastState.Bounded env19298 := by
  intro p hp
  have h : env19298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19297_19298 : H12AffineEnvironment.transform 10 1 env19297 = env19298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19297 == env19298) = true)

theorem identity19298 : scanCanonicalize (H12AffineFastState.compose env19298 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19299 : List Nat := [2,4,3,16,1,17,3,5,0,4,1,1,2,17,1,2,0,1,5,0,0,1,17,2,2,16,1,0,1,0,4,1,4,1,16,1]

theorem envBound19299 : H12AffineFastState.Bounded env19299 := by
  intro p hp
  have h : env19299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19298_19299 : H12AffineEnvironment.transform 2 3 env19298 = env19299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19298 == env19299) = true)

theorem identity19299 : scanCanonicalize (H12AffineFastState.compose env19299 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19299 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19300 : List Nat := [2,4,3,0,1,1,3,5,0,4,1,1,2,1,1,2,0,1,5,0,0,1,1,2,2,0,1,0,1,0,4,1,4,1,0,1]

theorem envBound19300 : H12AffineFastState.Bounded env19300 := by
  intro p hp
  have h : env19300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19299_19300 : H12AffineEnvironment.transform 3 0 env19299 = env19300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19299 == env19300) = true)

def env19301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272426,8328,65,4303011,2469031,2233817,295049,519347,6639082,257,2599950,2575786,445285]

theorem envBound19301 : H12AffineFastState.Bounded env19301 := by
  intro p hp
  have h : env19301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19267_19301 : H12AffineEnvironment.transform 22 147593 env19267 = env19301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env19267 == env19301) = true)

def env19302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303011,2469031,2119113,295049,371875,6639082,257,2485278,2428346,297845]

theorem envBound19302 : H12AffineFastState.Bounded env19302 := by
  intro p hp
  have h : env19302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19301_19302 : H12AffineEnvironment.transform 16 16400 env19301 = env19302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19301 == env19302) = true)

theorem identity19302 : scanCanonicalize (H12AffineFastState.compose env19302 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound19302 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35324,1025,32769,2097152,4194304,153,41430,8328,65,4303011,2172251,2119113,2421,75103,6407190,257,2188770,2196550,649]

theorem envBound19303 : H12AffineFastState.Bounded env19303 := by
  intro p hp
  have h : env19303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19302_19303 : H12AffineEnvironment.transform 17 35324 env19302 = env19303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env19302 == env19303) = true)

theorem identity19303 : scanCanonicalize (H12AffineFastState.compose env19303 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19303 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302891,2172251,2118977,2421,75103,6407190,257,2188650,2196550,513]

theorem envBound19304 : H12AffineFastState.Bounded env19304 := by
  intro p hp
  have h : env19304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19303_19304 : H12AffineEnvironment.transform 6 8 env19303 = env19304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19303 == env19304) = true)

theorem identity19304 : scanCanonicalize (H12AffineFastState.compose env19304 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound19304 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env19305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115734,4194304,17,41310,8192,65,4302891,57677,102743,2421,75103,4194304,257,41340,16464,513]

theorem envBound19305 : H12AffineFastState.Bounded env19305 := by
  intro p hp
  have h : env19305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19304_19305 : H12AffineEnvironment.transform 20 115734 env19304 = env19305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env19304 == env19305) = true)

theorem identity19305 : scanCanonicalize (H12AffineFastState.compose env19305 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19305 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env19306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,91466,4194304,17,2,8192,65,4262263,16401,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound19306 : H12AffineFastState.Bounded env19306 := by
  intro p hp
  have h : env19306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19305_19306 : H12AffineEnvironment.transform 14 8540 env19305 = env19306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19305 == env19306) = true)

theorem identity19306 : scanCanonicalize (H12AffineFastState.compose env19306 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19306 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env19307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,91466,32,17,2,8192,65,67927,16401,77835,2421,75103,32,257,32,16464,513]

theorem envBound19307 : H12AffineFastState.Bounded env19307 := by
  intro p hp
  have h : env19307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19306_19307 : H12AffineEnvironment.transform 21 32 env19306 = env19307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19306 == env19307) = true)

def env19308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303011,2469031,2119112,295049,371874,6639082,257,2485279,2428347,297844]

theorem envBound19308 : H12AffineFastState.Bounded env19308 := by
  intro p hp
  have h : env19308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19301_19308 : H12AffineEnvironment.transform 16 16401 env19301 = env19308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19301 == env19308) = true)

theorem identity19308 : scanCanonicalize (H12AffineFastState.compose env19308 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound19308 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,262144,1025,8660,2097152,4194304,152,272426,8328,65,4262262,2428274,2119112,270684,331127,6639082,257,2444746,2428347,273057]

theorem envBound19309 : H12AffineFastState.Bounded env19309 := by
  intro p hp
  have h : env19309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19308_19309 : H12AffineEnvironment.transform 14 8661 env19308 = env19309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env19308 == env19309) = true)

def env19310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,10400,1025,8660,2097152,4194304,152,138,8328,65,4262262,2172370,2119112,2556,75223,6382922,257,2188650,2172187,513]

theorem envBound19310 : H12AffineFastState.Bounded env19310 := by
  intro p hp
  have h : env19310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19309_19310 : H12AffineEnvironment.transform 17 10400 env19309 = env19310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19309 == env19310) = true)

theorem identity19310 : scanCanonicalize (H12AffineFastState.compose env19310 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19310 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8203,16401,10400,1025,8660,2097152,4194304,152,138,8328,65,4204925,2098649,2119112,2556,1500,6309185,257,2114913,2098448,513]

theorem envBound19311 : H12AffineFastState.Bounded env19311 := by
  intro p hp
  have h : env19311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19310_19311 : H12AffineEnvironment.transform 15 8203 env19310 = env19311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19310 == env19311) = true)

theorem identity19311 : scanCanonicalize (H12AffineFastState.compose env19311 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2114864) := by decide +kernel

theorem selectedBound19311 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env19312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8203,16401,10400,1025,8660,2097152,2114864,152,138,8328,65,2124877,2098649,2119112,2556,1500,113,257,2114913,2098448,513]

theorem envBound19312 : H12AffineFastState.Bounded env19312 := by
  intro p hp
  have h : env19312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19311_19312 : H12AffineEnvironment.transform 21 2114864 env19311 = env19312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env19311 == env19312) = true)

theorem identity19312 : scanCanonicalize (H12AffineFastState.compose env19312 (packedSelected [4,9,11,12,14,15,17,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound19312 : packedSelected [4,9,11,12,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env19313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8203,16401,10400,1025,8660,17816,168,152,138,8328,65,10709,16449,4176,2556,1500,113,257,249,16520,513]

theorem envBound19313 : H12AffineFastState.Bounded env19313 := by
  intro p hp
  have h : env19313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19312_19313 : H12AffineEnvironment.transform 20 17816 env19312 = env19313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env19312 == env19313) = true)

theorem identity19313 : scanCanonicalize (H12AffineFastState.compose env19313 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19313 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env19314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,81,399,16401,2340,1025,80,17816,168,152,138,268,65,2129,16449,4176,2556,1500,113,257,249,16520,513]

theorem envBound19314 : H12AffineFastState.Bounded env19314 := by
  intro p hp
  have h : env19314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19313_19314 : H12AffineEnvironment.transform 12 388 env19313 = env19314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19313 == env19314) = true)

theorem identity19314 : scanCanonicalize (H12AffineFastState.compose env19314 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19314 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19315 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,81,342,16401,2340,1025,80,17729,113,65,83,268,65,2129,16449,4176,2341,1285,113,257,32,16465,513]

theorem envBound19315 : H12AffineFastState.Bounded env19315 := by
  intro p hp
  have h : env19315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19314_19315 : H12AffineEnvironment.transform 6 89 env19314 = env19315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19314 == env19315) = true)

theorem identity19315 : scanCanonicalize (H12AffineFastState.compose env19315 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19315 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env19316 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2113,349,16384,81,342,16401,2340,1025,80,17729,113,65,83,268,65,2129,16449,2065,2341,1285,113,257,32,16465,513]

theorem envBound19316 : H12AffineFastState.Bounded env19316 := by
  intro p hp
  have h : env19316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19315_19316 : H12AffineEnvironment.transform 11 2113 env19315 = env19316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19315 == env19316) = true)

theorem identity19316 : scanCanonicalize (H12AffineFastState.compose env19316 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19316 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env19317 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,269,16384,1,262,16401,2340,1025,0,17681,33,17,3,268,17,2049,16401,2065,2341,1285,33,257,32,16385,513]

theorem envBound19317 : H12AffineFastState.Bounded env19317 := by
  intro p hp
  have h : env19317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19316_19317 : H12AffineEnvironment.transform 5 16 env19316 = env19317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19316 == env19317) = true)

def env19318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,10401,1025,8660,2097152,4194304,152,139,8328,65,4262262,2172371,2119112,2557,75222,6382923,257,2188651,2172186,512]

theorem envBound19318 : H12AffineFastState.Bounded env19318 := by
  intro p hp
  have h : env19318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19309_19318 : H12AffineEnvironment.transform 17 10401 env19309 = env19318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19309 == env19318) = true)

theorem identity19318 : scanCanonicalize (H12AffineFastState.compose env19318 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19318 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,2097152,4194304,16,3,8192,65,4262262,2172251,2118976,2421,75102,6382923,257,2188651,2172186,512]

theorem envBound19319 : H12AffineFastState.Bounded env19319 := by
  intro p hp
  have h : env19319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19318_19319 : H12AffineEnvironment.transform 6 8 env19318 = env19319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19318 == env19319) = true)

theorem identity19319 : scanCanonicalize (H12AffineFastState.compose env19319 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound19319 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17460,4194304,16,3,8192,65,4262262,90479,4468,2421,75102,4268415,257,74079,90414,512]

theorem envBound19320 : H12AffineFastState.Bounded env19320 := by
  intro p hp
  have h : env19320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19319_19320 : H12AffineEnvironment.transform 20 17460 env19319 = env19320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env19319 == env19320) = true)

theorem identity19320 : scanCanonicalize (H12AffineFastState.compose env19320 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound19320 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env19321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17460,33,16,3,8192,65,67927,90479,4468,2421,75102,74078,257,74079,90414,512]

theorem envBound19321 : H12AffineFastState.Bounded env19321 := by
  intro p hp
  have h : env19321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19320_19321 : H12AffineEnvironment.transform 21 33 env19320 = env19321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env19320 == env19321) = true)

theorem identity19321 : scanCanonicalize (H12AffineFastState.compose env19321 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19810) := by decide +kernel

theorem selectedBound19321 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,19810,16401,10281,1025,8540,17460,33,16,3,8192,65,17461,11277,4468,2421,26684,27708,257,27709,11340,512]

theorem envBound19322 : H12AffineFastState.Bounded env19322 := by
  intro p hp
  have h : env19322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19321_19322 : H12AffineEnvironment.transform 15 19810 env19321 = env19322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19810 env19321 == env19322) = true)

theorem identity19322 : scanCanonicalize (H12AffineFastState.compose env19322 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound19322 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5408,8541,6210,5425,10281,1025,8540,4372,33,16,3,8192,65,4373,11277,4468,2421,15644,14620,257,14621,11340,512]

theorem envBound19323 : H12AffineFastState.Bounded env19323 := by
  intro p hp
  have h : env19323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19322_19323 : H12AffineEnvironment.transform 13 5408 env19322 = env19323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env19322 == env19323) = true)

theorem identity19323 : scanCanonicalize (H12AffineFastState.compose env19323 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound19323 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env19324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5408,1077,6210,5425,3393,1025,1076,4372,33,16,3,1384,65,4373,2405,4468,2421,6260,7284,257,7285,2340,512]

theorem envBound19324 : H12AffineFastState.Bounded env19324 := by
  intro p hp
  have h : env19324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19323_19324 : H12AffineEnvironment.transform 12 1384 env19323 = env19324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env19323 == env19324) = true)

theorem identity19324 : scanCanonicalize (H12AffineFastState.compose env19324 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound19324 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env19325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1384,3377,1077,83,3360,3393,1025,1076,2309,33,16,3,1384,65,2308,2405,2405,2421,101,1125,257,1124,2340,512]

theorem envBound19325 : H12AffineFastState.Bounded env19325 := by
  intro p hp
  have h : env19325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19324_19325 : H12AffineEnvironment.transform 11 2065 env19324 = env19325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env19324 == env19325) = true)

theorem identity19325 : scanCanonicalize (H12AffineFastState.compose env19325 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound19325 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19326 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,2065,88,2049,261,83,2064,2161,305,260,2309,33,16,3,88,65,2308,2405,2405,2421,101,341,257,340,2340,512]

theorem envBound19326 : H12AffineFastState.Bounded env19326 := by
  intro p hp
  have h : env19326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19325_19326 : H12AffineEnvironment.transform 9 304 env19325 = env19326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env19325 == env19326) = true)

theorem identity19326 : scanCanonicalize (H12AffineFastState.compose env19326 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound19326 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19327 : List Nat := [2,4,8,16,32,64,8,256,512,304,554,571,88,555,261,83,570,603,305,260,815,33,16,3,88,65,814,847,847,863,101,341,257,340,782,512]

theorem envBound19327 : H12AffineFastState.Bounded env19327 := by
  intro p hp
  have h : env19327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19326_19327 : H12AffineEnvironment.transform 10 554 env19326 = env19327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env19326 == env19327) = true)

theorem identity19327 : scanCanonicalize (H12AffineFastState.compose env19327 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19327 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19328 : List Nat := [2,4,8,16,32,64,8,36,512,20,554,571,88,555,33,83,570,603,21,32,523,33,16,3,88,65,522,619,619,635,101,113,37,112,554,512]

theorem envBound19328 : H12AffineFastState.Bounded env19328 := by
  intro p hp
  have h : env19328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19327_19328 : H12AffineEnvironment.transform 7 36 env19327 = env19328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19327 == env19328) = true)

theorem identity19328 : scanCanonicalize (H12AffineFastState.compose env19328 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound19328 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19329 : List Nat := [2,4,8,16,26,64,8,30,512,20,528,513,88,529,27,83,512,603,21,26,523,27,16,3,88,65,522,593,593,577,95,75,31,74,528,512]

theorem envBound19329 : H12AffineFastState.Bounded env19329 := by
  intro p hp
  have h : env19329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19328_19329 : H12AffineEnvironment.transform 4 26 env19328 = env19329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env19328 == env19329) = true)

theorem identity19329 : scanCanonicalize (H12AffineFastState.compose env19329 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound19329 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env19330 : List Nat := [2,4,8,16,26,64,8,30,67,20,83,66,88,82,27,83,67,24,21,26,72,27,16,3,88,65,73,18,18,2,95,75,31,74,83,67]

theorem envBound19330 : H12AffineFastState.Bounded env19330 := by
  intro p hp
  have h : env19330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19329_19330 : H12AffineEnvironment.transform 8 67 env19329 = env19330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env19329 == env19330) = true)

theorem identity19330 : scanCanonicalize (H12AffineFastState.compose env19330 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19330 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19331 : List Nat := [2,4,8,16,26,17,8,30,18,20,2,19,9,3,27,2,18,24,21,26,25,27,16,3,9,16,24,18,18,2,14,26,31,27,2,18]

theorem envBound19331 : H12AffineFastState.Bounded env19331 := by
  intro p hp
  have h : env19331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19330_19331 : H12AffineEnvironment.transform 5 17 env19330 = env19331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19330 == env19331) = true)

theorem identity19331 : scanCanonicalize (H12AffineFastState.compose env19331 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19332 : List Nat := [2,4,8,10,0,11,8,4,8,14,2,9,9,3,1,2,8,2,15,0,3,1,10,3,9,10,2,8,8,2,14,0,5,1,2,8]

theorem envBound19332 : H12AffineFastState.Bounded env19332 := by
  intro p hp
  have h : env19332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19331_19332 : H12AffineEnvironment.transform 3 10 env19331 = env19332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19331 == env19332) = true)

theorem identity19332 : scanCanonicalize (H12AffineFastState.compose env19332 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound19332 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19333 : List Nat := [2,0,8,10,0,11,8,0,8,10,2,9,9,3,1,2,8,2,11,0,3,1,10,3,9,10,2,8,8,2,10,0,1,1,2,8]

theorem envBound19333 : H12AffineFastState.Bounded env19333 := by
  intro p hp
  have h : env19333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19332_19333 : H12AffineEnvironment.transform 1 0 env19332 = env19333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env19332 == env19333) = true)

theorem identity19333 : scanCanonicalize (H12AffineFastState.compose env19333 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19334 : List Nat := [2,0,2,0,0,1,2,0,2,0,2,3,3,3,1,2,2,2,1,0,3,1,0,3,3,0,2,2,2,2,0,0,1,1,2,2]

theorem envBound19334 : H12AffineFastState.Bounded env19334 := by
  intro p hp
  have h : env19334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19333_19334 : H12AffineEnvironment.transform 2 2 env19333 = env19334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19333 == env19334) = true)

def env19335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound19335 : H12AffineFastState.Bounded env19335 := by
  intro p hp
  have h : env19335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17795_19335 : H12AffineEnvironment.transform 29 155254785 env17795 = env19335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env17795 == env19335) = true)

def env19336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound19336 : H12AffineFastState.Bounded env19336 := by
  intro p hp
  have h : env19336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19335_19336 : H12AffineEnvironment.transform 25 64 env19335 = env19336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env19335 == env19336) = true)

def env19337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound19337 : H12AffineFastState.Bounded env19337 := by
  intro p hp
  have h : env19337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19336_19337 : H12AffineEnvironment.transform 26 30393344 env19336 = env19337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env19336 == env19337) = true)

def env19338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound19338 : H12AffineFastState.Bounded env19338 := by
  intro p hp
  have h : env19338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19337_19338 : H12AffineEnvironment.transform 18 1024 env19337 = env19338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19337 == env19338) = true)

theorem identity19338 : scanCanonicalize (H12AffineFastState.compose env19338 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188635) := by decide +kernel

theorem selectedBound19338 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188635,16777216,8328,64,23504219,18973836,77834,2598234,18932042,23160257,256,16818678,16793682,18990748]

theorem envBound19339 : H12AffineFastState.Bounded env19339 := by
  intro p hp
  have h : env19339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19338_19339 : H12AffineEnvironment.transform 22 2188635 env19338 = env19339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188635 env19338 == env19339) = true)

def env19340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,16777216,8328,64,17227835,18973836,77834,2598234,18932042,16851105,256,16818678,16793682,18990748]

theorem envBound19340 : H12AffineFastState.Bounded env19340 := by
  intro p hp
  have h : env19340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19339_19340 : H12AffineEnvironment.transform 21 2114912 env19339 = env19340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env19339 == env19340) = true)

def env19341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175168,8328,64,2609403,46156,77834,2598234,119178,2101345,256,2199862,2191506,63068]

theorem envBound19341 : H12AffineFastState.Bounded env19341 := by
  intro p hp
  have h : env19341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19340_19341 : H12AffineEnvironment.transform 23 2175168 env19340 = env19341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env19340 == env19341) = true)

def env19342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73856,8328,64,508091,46156,77834,505114,119178,33,256,98678,90322,63068]

theorem envBound19342 : H12AffineFastState.Bounded env19342 := by
  intro p hp
  have h : env19342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19341_19342 : H12AffineEnvironment.transform 20 4160 env19341 = env19342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19341 == env19342) = true)

theorem identity19342 : scanCanonicalize (H12AffineFastState.compose env19342 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19342 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,21792,95515,73856,8328,64,472174,16537,77834,475599,75103,33,256,95651,90322,649]

theorem envBound19343 : H12AffineFastState.Bounded env19343 := by
  intro p hp
  have h : env19343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19342_19343 : H12AffineEnvironment.transform 14 29909 env19342 = env19343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19342 == env19343) = true)

def env19344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,21792,95515,73736,8192,64,472174,16401,77834,475463,75103,33,256,95531,90202,513]

theorem envBound19344 : H12AffineFastState.Bounded env19344 := by
  intro p hp
  have h : env19344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19343_19344 : H12AffineEnvironment.transform 6 8 env19343 = env19344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19343 == env19344) = true)

theorem identity19344 : scanCanonicalize (H12AffineFastState.compose env19344 (packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound19344 : packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env19345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138293,1024,29788,4160,21792,95515,73736,8192,64,75867,16401,77834,89458,75103,33,256,95531,90202,513]

theorem envBound19345 : H12AffineFastState.Bounded env19345 := by
  intro p hp
  have h : env19345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19344_19345 : H12AffineEnvironment.transform 17 138293 env19344 = env19345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env19344 == env19345) = true)

theorem identity19345 : scanCanonicalize (H12AffineFastState.compose env19345 (packedSelected [0,2,4,6,7,9,14,16,18,20,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound19345 : packedSelected [0,2,4,6,7,9,14,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env19346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13341,10280,1024,29788,4160,21792,95515,73736,8192,64,75867,16401,77834,89458,75103,33,256,95531,90202,513]

theorem envBound19346 : H12AffineFastState.Bounded env19346 := by
  intro p hp
  have h : env19346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19345_19346 : H12AffineEnvironment.transform 16 13341 env19345 = env19346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env19345 == env19346) = true)

theorem identity19346 : scanCanonicalize (H12AffineFastState.compose env19346 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 17478) := by decide +kernel

theorem selectedBound19346 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env19347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,17478,13341,10280,1024,29788,4160,21792,12637,25678,8192,64,27677,16401,29772,6452,24857,33,256,12653,9244,513]

theorem envBound19347 : H12AffineFastState.Bounded env19347 := by
  intro p hp
  have h : env19347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19346_19347 : H12AffineEnvironment.transform 15 17478 env19346 = env19347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17478 env19346 == env19347) = true)

theorem identity19347 : scanCanonicalize (H12AffineFastState.compose env19347 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound19347 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env19348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,8192,16384,24844,17478,8524,10280,1024,24845,1297,16497,9228,25678,8192,64,27677,16401,24861,3173,24857,33,256,9276,9244,513]

theorem envBound19348 : H12AffineFastState.Bounded env19348 := by
  intro p hp
  have h : env19348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19347_19348 : H12AffineEnvironment.transform 11 1361 env19347 = env19348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env19347 == env19348) = true)

theorem identity19348 : scanCanonicalize (H12AffineFastState.compose env19348 (packedSelected [1,2,6,8,10,11,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19348 : packedSelected [1,2,6,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env19349 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1140,8192,16384,24617,17478,8297,10280,1024,24616,1076,16497,9228,25678,8192,64,27677,16401,24632,3173,24636,33,37,9276,9244,513]

theorem envBound19349 : H12AffineFastState.Bounded env19349 := by
  intro p hp
  have h : env19349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19348_19349 : H12AffineEnvironment.transform 7 37 env19348 = env19349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19348 == env19349) = true)

theorem identity19349 : scanCanonicalize (H12AffineFastState.compose env19349 (packedSelected [0,2,4,6,7,9,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound19349 : packedSelected [0,2,4,6,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env19350 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1140,8192,16384,24617,17478,8297,8312,1024,24616,1076,16497,9228,25678,8192,64,25677,16401,24632,1077,24636,33,37,9276,9244,513]

theorem envBound19350 : H12AffineFastState.Bounded env19350 := by
  intro p hp
  have h : env19350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19349_19350 : H12AffineEnvironment.transform 10 80 env19349 = env19350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env19349 == env19350) = true)

theorem identity19350 : scanCanonicalize (H12AffineFastState.compose env19350 (packedSelected [3,5,11,12,19] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound19350 : packedSelected [3,5,11,12,19] rootPS < 2^1333 := by decide +kernel

def env19351 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1140,8192,1125,9292,35,8297,8312,1024,9293,1076,1044,9228,8235,8192,64,8232,1140,9309,1077,9305,33,37,9276,9244,513]

theorem envBound19351 : H12AffineFastState.Bounded env19351 := by
  intro p hp
  have h : env19351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19350_19351 : H12AffineEnvironment.transform 13 1125 env19350 = env19351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env19350 == env19351) = true)

theorem identity19351 : scanCanonicalize (H12AffineFastState.compose env19351 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19351 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19352 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,8192,81,8312,35,8297,8312,52,8313,0,32,8248,8235,8192,64,8232,64,8297,1,8301,33,37,8200,8232,513]

theorem envBound19352 : H12AffineFastState.Bounded env19352 := by
  intro p hp
  have h : env19352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19351_19352 : H12AffineEnvironment.transform 9 52 env19351 = env19352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19351 == env19352) = true)

theorem identity19352 : scanCanonicalize (H12AffineFastState.compose env19352 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19352 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19353 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,41,81,81,35,64,81,52,80,0,32,17,2,41,64,1,64,64,1,68,33,37,33,1,513]

theorem envBound19353 : H12AffineFastState.Bounded env19353 := by
  intro p hp
  have h : env19353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19352_19353 : H12AffineEnvironment.transform 12 41 env19352 = env19353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19352 == env19353) = true)

theorem identity19353 : scanCanonicalize (H12AffineFastState.compose env19353 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19354 : List Nat := [2,4,8,16,32,48,8,37,512,52,32,48,41,33,33,35,48,33,52,32,0,32,17,2,41,48,1,48,48,1,52,33,37,33,1,513]

theorem envBound19354 : H12AffineFastState.Bounded env19354 := by
  intro p hp
  have h : env19354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19353_19354 : H12AffineEnvironment.transform 5 48 env19353 = env19354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19353 == env19354) = true)

theorem identity19354 : scanCanonicalize (H12AffineFastState.compose env19354 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19354 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19355 : List Nat := [2,4,8,16,32,48,8,37,0,52,32,48,41,33,33,35,48,33,52,32,0,32,17,2,41,48,1,48,48,1,52,33,37,33,1,1]

theorem envBound19355 : H12AffineFastState.Bounded env19355 := by
  intro p hp
  have h : env19355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19354_19355 : H12AffineEnvironment.transform 8 0 env19354 = env19355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19354 == env19355) = true)

theorem identity19355 : scanCanonicalize (H12AffineFastState.compose env19355 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19355 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19356 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,16,9,1,1,3,16,1,20,0,0,0,17,2,9,16,1,16,16,1,20,1,5,1,1,1]

theorem envBound19356 : H12AffineFastState.Bounded env19356 := by
  intro p hp
  have h : env19356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19355_19356 : H12AffineEnvironment.transform 4 0 env19355 = env19356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19355 == env19356) = true)

theorem identity19356 : scanCanonicalize (H12AffineFastState.compose env19356 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19356 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19357 : List Nat := [2,4,2,16,0,16,2,5,0,20,0,16,3,1,1,3,16,1,20,0,0,0,17,2,3,16,1,16,16,1,20,1,5,1,1,1]

theorem envBound19357 : H12AffineFastState.Bounded env19357 := by
  intro p hp
  have h : env19357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19356_19357 : H12AffineEnvironment.transform 2 2 env19356 = env19357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19356 == env19357) = true)

theorem identity19357 : scanCanonicalize (H12AffineFastState.compose env19357 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19357 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19358 : List Nat := [2,4,2,0,0,0,2,5,0,4,0,0,3,1,1,3,0,1,4,0,0,0,1,2,3,0,1,0,0,1,4,1,5,1,1,1]

theorem envBound19358 : H12AffineFastState.Bounded env19358 := by
  intro p hp
  have h : env19358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19357_19358 : H12AffineEnvironment.transform 3 0 env19357 = env19358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19357 == env19358) = true)

def env19359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,21792,95515,73737,8193,64,472174,16400,77834,475462,75103,33,256,95530,90203,512]

theorem envBound19359 : H12AffineFastState.Bounded env19359 := by
  intro p hp
  have h : env19359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19343_19359 : H12AffineEnvironment.transform 6 9 env19343 = env19359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19343 == env19359) = true)

theorem identity19359 : scanCanonicalize (H12AffineFastState.compose env19359 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound19359 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,4160,21792,17,21763,8193,64,409956,16400,17664,406604,20565,33,256,32,5457,512]

theorem envBound19360 : H12AffineFastState.Bounded env19360 := by
  intro p hp
  have h : env19360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19359_19360 : H12AffineEnvironment.transform 15 29962 env19359 = env19360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env19359 == env19360) = true)

theorem identity19360 : scanCanonicalize (H12AffineFastState.compose env19360 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound19360 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,10588,1024,29789,4160,21792,17,21763,8193,64,157752,16400,17664,138512,20565,33,256,32,5457,512]

theorem envBound19361 : H12AffineFastState.Bounded env19361 := by
  intro p hp
  have h : env19361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19360_19361 : H12AffineEnvironment.transform 17 10588 env19360 = env19361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env19360 == env19361) = true)

theorem identity19361 : scanCanonicalize (H12AffineFastState.compose env19361 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 24648) := by decide +kernel

theorem selectedBound19361 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env19362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,24648,10588,1024,29789,4160,21792,17,21763,8193,64,2160,16400,17664,32088,20565,33,256,32,5457,512]

theorem envBound19362 : H12AffineFastState.Bounded env19362 := by
  intro p hp
  have h : env19362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19361_19362 : H12AffineEnvironment.transform 16 24648 env19361 = env19362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24648 env19361 == env19362) = true)

theorem identity19362 : scanCanonicalize (H12AffineFastState.compose env19362 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound19362 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8233,8575,13373,10588,1024,8232,4160,341,17,374,8193,64,2160,5221,4469,10541,1056,33,256,32,5457,512]

theorem envBound19363 : H12AffineFastState.Bounded env19363 := by
  intro p hp
  have h : env19363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19362_19363 : H12AffineEnvironment.transform 13 5237 env19362 = env19363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env19362 == env19363) = true)

theorem identity19363 : scanCanonicalize (H12AffineFastState.compose env19363 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19363 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env19364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,0,342,5140,2421,1024,1,4160,341,17,374,40,64,2160,5221,4469,2308,1056,33,256,32,5457,512]

theorem envBound19364 : H12AffineFastState.Bounded env19364 := by
  intro p hp
  have h : env19364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19363_19364 : H12AffineEnvironment.transform 12 41 env19363 = env19364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19363 == env19364) = true)

def env19365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73857,8328,64,508090,46156,77834,505115,119178,32,256,98679,90323,63068]

theorem envBound19365 : H12AffineFastState.Bounded env19365 := by
  intro p hp
  have h : env19365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19341_19365 : H12AffineEnvironment.transform 20 4161 env19341 = env19365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19341 == env19365) = true)

theorem identity19365 : scanCanonicalize (H12AffineFastState.compose env19365 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,4161,21793,95514,73857,8328,64,483814,5392,77834,463943,94422,32,256,73771,90323,22272]

theorem envBound19366 : H12AffineFastState.Bounded env19366 := by
  intro p hp
  have h : env19366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19365_19366 : H12AffineEnvironment.transform 14 8540 env19365 = env19366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19365 == env19366) = true)

theorem identity19366 : scanCanonicalize (H12AffineFastState.compose env19366 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19366 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4161,32,73755,73857,8328,64,472295,5392,77834,463943,75223,32,256,73771,79314,513]

theorem envBound19367 : H12AffineFastState.Bounded env19367 := by
  intro p hp
  have h : env19367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19366_19367 : H12AffineEnvironment.transform 13 5377 env19366 = env19367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19366 == env19367) = true)

theorem identity19367 : scanCanonicalize (H12AffineFastState.compose env19367 (packedSelected [0,2,4,6,11,14,15,16,21,22,27,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 204218) := by decide +kernel

theorem selectedBound19367 : packedSelected [0,2,4,6,11,14,15,16,21,22,27,32,38] rootPS < 2^1333 := by decide +kernel

def env19368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,204218,1024,8541,4161,32,73755,73857,8328,64,10589,5392,77834,2557,75223,32,256,73771,79314,513]

theorem envBound19368 : H12AffineFastState.Bounded env19368 := by
  intro p hp
  have h : env19368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19367_19368 : H12AffineEnvironment.transform 17 204218 env19367 = env19368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204218 env19367 == env19368) = true)

theorem identity19368 : scanCanonicalize (H12AffineFastState.compose env19368 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19368 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env19369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146865,1024,8541,4161,32,16,138,8328,64,10589,5392,4097,2557,1500,32,256,32,5593,513]

theorem envBound19369 : H12AffineFastState.Bounded env19369 := by
  intro p hp
  have h : env19369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19368_19369 : H12AffineEnvironment.transform 15 8203 env19368 = env19369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19368 == env19369) = true)

theorem identity19369 : scanCanonicalize (H12AffineFastState.compose env19369 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19369 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19370 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8460,8203,131072,146865,1024,8461,4113,32,16,138,8328,16,10509,5392,4097,2477,1420,32,256,32,5513,513]

theorem envBound19370 : H12AffineFastState.Bounded env19370 := by
  intro p hp
  have h : env19370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19369_19370 : H12AffineEnvironment.transform 5 16 env19369 = env19370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19369 == env19370) = true)

theorem identity19370 : scanCanonicalize (H12AffineFastState.compose env19370 (packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19370 : packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19371 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,136,399,131072,138293,1024,137,4113,32,16,138,268,16,2185,5392,4097,2477,1420,32,256,32,5513,513]

theorem envBound19371 : H12AffineFastState.Bounded env19371 := by
  intro p hp
  have h : env19371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19370_19371 : H12AffineEnvironment.transform 12 388 env19370 = env19371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19370 == env19371) = true)

theorem identity19371 : scanCanonicalize (H12AffineFastState.compose env19371 (packedSelected [0,2,3,5,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound19371 : packedSelected [0,2,3,5,7,11,14] rootPS < 2^1333 := by decide +kernel

def env19372 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3328,388,2049,136,399,131072,131381,1024,137,3345,32,16,138,268,16,2185,2064,3329,2477,1420,32,256,32,2185,513]

theorem envBound19372 : H12AffineFastState.Bounded env19372 := by
  intro p hp
  have h : env19372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19371_19372 : H12AffineEnvironment.transform 11 3328 env19371 = env19372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env19371 == env19372) = true)

theorem identity19372 : scanCanonicalize (H12AffineFastState.compose env19372 (packedSelected [2,4,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 1281) := by decide +kernel

theorem selectedBound19372 : packedSelected [2,4,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19373 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3328,388,2049,136,399,1281,1076,1024,137,3345,32,16,138,268,16,2185,2064,3329,2477,1420,32,256,32,2185,513]

theorem envBound19373 : H12AffineFastState.Bounded env19373 := by
  intro p hp
  have h : env19373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19372_19373 : H12AffineEnvironment.transform 16 1281 env19372 = env19373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1281 env19372 == env19373) = true)

theorem identity19373 : scanCanonicalize (H12AffineFastState.compose env19373 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound19373 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env19374 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,2493,388,2049,136,399,444,137,189,137,2476,32,16,138,268,16,2185,2064,2492,2477,305,32,256,32,2185,513]

theorem envBound19374 : H12AffineFastState.Bounded env19374 := by
  intro p hp
  have h : env19374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19373_19374 : H12AffineEnvironment.transform 9 189 env19373 = env19374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env19373 == env19374) = true)

theorem identity19374 : scanCanonicalize (H12AffineFastState.compose env19374 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19374 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19375 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2356,269,2049,1,262,309,0,52,0,2341,32,16,3,268,16,2048,2064,2357,2340,305,32,256,32,2048,513]

theorem envBound19375 : H12AffineFastState.Bounded env19375 := by
  intro p hp
  have h : env19375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19374_19375 : H12AffineEnvironment.transform 6 9 env19374 = env19375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19374 == env19375) = true)

theorem identity19375 : scanCanonicalize (H12AffineFastState.compose env19375 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19375 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env19376 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,309,269,0,1,262,309,0,52,0,292,32,16,3,268,16,1,17,308,293,305,32,256,32,1,513]

theorem envBound19376 : H12AffineFastState.Bounded env19376 := by
  intro p hp
  have h : env19376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19375_19376 : H12AffineEnvironment.transform 10 1 env19375 = env19376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19375 == env19376) = true)

theorem identity19376 : scanCanonicalize (H12AffineFastState.compose env19376 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19376 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env19377 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,41,0,1,34,17,0,52,0,0,32,16,3,40,16,1,17,16,1,21,32,36,32,1,513]

theorem envBound19377 : H12AffineFastState.Bounded env19377 := by
  intro p hp
  have h : env19377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19376_19377 : H12AffineEnvironment.transform 7 36 env19376 = env19377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19376 == env19377) = true)

theorem identity19377 : scanCanonicalize (H12AffineFastState.compose env19377 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound19377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19378 : List Nat := [2,4,8,16,20,16,9,16,512,0,1,17,29,0,1,22,17,0,0,0,0,20,16,3,28,16,1,17,16,1,21,20,16,20,1,513]

theorem envBound19378 : H12AffineFastState.Bounded env19378 := by
  intro p hp
  have h : env19378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19377_19378 : H12AffineEnvironment.transform 4 20 env19377 = env19378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env19377 == env19378) = true)

theorem identity19378 : scanCanonicalize (H12AffineFastState.compose env19378 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound19378 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19379 : List Nat := [2,4,8,16,20,16,9,16,9,0,1,17,29,0,1,22,17,0,0,0,0,20,16,3,28,16,1,17,16,1,21,20,16,20,1,8]

theorem envBound19379 : H12AffineFastState.Bounded env19379 := by
  intro p hp
  have h : env19379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19378_19379 : H12AffineEnvironment.transform 8 9 env19378 = env19379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env19378 == env19379) = true)

theorem identity19379 : scanCanonicalize (H12AffineFastState.compose env19379 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound19379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19380 : List Nat := [2,1,8,16,17,16,9,16,9,0,1,17,24,0,1,19,17,0,0,0,0,17,16,3,25,16,1,17,16,1,16,17,16,17,1,8]

theorem envBound19380 : H12AffineFastState.Bounded env19380 := by
  intro p hp
  have h : env19380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19379_19380 : H12AffineEnvironment.transform 1 1 env19379 = env19380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env19379 == env19380) = true)

theorem identity19380 : scanCanonicalize (H12AffineFastState.compose env19380 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19380 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19381 : List Nat := [2,1,3,16,17,16,2,16,2,0,1,17,19,0,1,19,17,0,0,0,0,17,16,3,18,16,1,17,16,1,16,17,16,17,1,3]

theorem envBound19381 : H12AffineFastState.Bounded env19381 := by
  intro p hp
  have h : env19381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19380_19381 : H12AffineEnvironment.transform 2 3 env19380 = env19381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19380 == env19381) = true)

theorem identity19381 : scanCanonicalize (H12AffineFastState.compose env19381 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound19381 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19382 : List Nat := [2,1,3,2,3,2,2,2,2,0,1,3,1,0,1,1,3,0,0,0,0,3,2,3,0,2,1,3,2,1,2,3,2,3,1,3]

theorem envBound19382 : H12AffineFastState.Bounded env19382 := by
  intro p hp
  have h : env19382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19381_19382 : H12AffineEnvironment.transform 3 2 env19381 = env19382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env19381 == env19382) = true)

theorem identity19382 : scanCanonicalize (H12AffineFastState.compose env19382 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound19382 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env19383 : List Nat := [1,1,0,1,0,1,1,1,1,0,1,0,1,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,1,1,1,0,1,0,1,0]

theorem envBound19383 : H12AffineFastState.Bounded env19383 := by
  intro p hp
  have h : env19383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19382_19383 : H12AffineEnvironment.transform 0 1 env19382 = env19383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env19382 == env19383) = true)

def env19384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175169,8328,64,2609402,46157,77834,2598234,119179,2101344,256,2199863,2191507,63069]

theorem envBound19384 : H12AffineFastState.Bounded env19384 := by
  intro p hp
  have h : env19384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19340_19384 : H12AffineEnvironment.transform 23 2175169 env19340 = env19384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env19340 == env19384) = true)

def env19385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73857,8328,64,508090,46157,77834,505114,119179,32,256,98679,90323,63069]

theorem envBound19385 : H12AffineFastState.Bounded env19385 := by
  intro p hp
  have h : env19385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19384_19385 : H12AffineEnvironment.transform 20 4160 env19384 = env19385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19384 == env19385) = true)

theorem identity19385 : scanCanonicalize (H12AffineFastState.compose env19385 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19385 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73857,8328,64,497082,46157,77834,505114,99467,32,256,98679,79315,41821]

theorem envBound19386 : H12AffineFastState.Bounded env19386 := by
  intro p hp
  have h : env19386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19385_19386 : H12AffineEnvironment.transform 13 5376 env19385 = env19386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19385 == env19386) = true)

def env19387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73737,8192,64,496946,46157,77834,505114,99331,32,256,98679,79195,41821]

theorem envBound19387 : H12AffineFastState.Bounded env19387 := by
  intro p hp
  have h : env19387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19386_19387 : H12AffineEnvironment.transform 6 8 env19386 = env19387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19386 == env19387) = true)

theorem identity19387 : scanCanonicalize (H12AffineFastState.compose env19387 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19387 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env19388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,32,73755,73737,8192,64,472174,5393,77834,463942,75103,32,256,73771,79195,513]

theorem envBound19388 : H12AffineFastState.Bounded env19388 := by
  intro p hp
  have h : env19388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19387_19388 : H12AffineEnvironment.transform 14 8540 env19387 = env19388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19387 == env19388) = true)

theorem identity19388 : scanCanonicalize (H12AffineFastState.compose env19388 (packedSelected [0,4,7,9,14,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19388 : packedSelected [0,4,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env19389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,32,16,2,8192,64,398437,5393,4097,406605,1364,32,256,32,5456,513]

theorem envBound19389 : H12AffineFastState.Bounded env19389 := by
  intro p hp
  have h : env19389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19388_19389 : H12AffineEnvironment.transform 15 8203 env19388 = env19389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19388 == env19389) = true)

theorem identity19389 : scanCanonicalize (H12AffineFastState.compose env19389 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound19389 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146792,1024,8541,4160,32,16,2,8192,64,10509,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound19390 : H12AffineFastState.Bounded env19390 := by
  intro p hp
  have h : env19390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19389_19390 : H12AffineEnvironment.transform 17 146792 env19389 = env19390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env19389 == env19390) = true)

theorem identity19390 : scanCanonicalize (H12AffineFastState.compose env19390 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19390 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10360,1024,8541,4160,32,16,2,8192,64,10509,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound19391 : H12AffineFastState.Bounded env19391 := by
  intro p hp
  have h : env19391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19390_19391 : H12AffineEnvironment.transform 16 5392 env19390 = env19391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19390 == env19391) = true)

theorem identity19391 : scanCanonicalize (H12AffineFastState.compose env19391 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19391 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19392 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,8203,5221,10360,1024,8232,4160,32,16,2,8192,64,10360,5220,4097,2128,1057,32,117,32,5157,513]

theorem envBound19392 : H12AffineFastState.Bounded env19392 := by
  intro p hp
  have h : env19392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19391_19392 : H12AffineEnvironment.transform 7 117 env19391 = env19392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19391 == env19392) = true)

theorem identity19392 : scanCanonicalize (H12AffineFastState.compose env19392 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19392 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19393 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5156,8233,8203,5172,10281,1024,8232,4113,32,16,2,8192,17,10281,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound19393 : H12AffineFastState.Bounded env19393 := by
  intro p hp
  have h : env19393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19392_19393 : H12AffineEnvironment.transform 5 17 env19392 = env19393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19392 == env19393) = true)

theorem identity19393 : scanCanonicalize (H12AffineFastState.compose env19393 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound19393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19394 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8,5156,33,3,5172,2081,1024,32,4113,32,16,2,8,17,2081,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound19394 : H12AffineFastState.Bounded env19394 := by
  intro p hp
  have h : env19394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19393_19394 : H12AffineEnvironment.transform 12 8 env19393 = env19394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env19393 == env19394) = true)

theorem identity19394 : scanCanonicalize (H12AffineFastState.compose env19394 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound19394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19395 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1045,4096,8,5156,33,3,5172,1076,1024,32,4113,32,16,2,8,17,1076,5173,4097,1044,1057,32,36,32,5157,513]

theorem envBound19395 : H12AffineFastState.Bounded env19395 := by
  intro p hp
  have h : env19395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19394_19395 : H12AffineEnvironment.transform 10 1045 env19394 = env19395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env19394 == env19395) = true)

theorem identity19395 : scanCanonicalize (H12AffineFastState.compose env19395 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19395 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19396 : List Nat := [2,4,8,16,32,17,8,36,1,1024,1045,4096,8,5156,33,3,5172,1076,1024,32,4113,32,16,2,8,17,1076,5173,4097,1044,1057,32,36,32,5157,0]

theorem envBound19396 : H12AffineFastState.Bounded env19396 := by
  intro p hp
  have h : env19396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19395_19396 : H12AffineEnvironment.transform 8 1 env19395 = env19396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19395 == env19396) = true)

def env19397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73736,8193,64,496947,46157,77834,505114,99330,32,256,98679,79194,41821]

theorem envBound19397 : H12AffineFastState.Bounded env19397 := by
  intro p hp
  have h : env19397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19386_19397 : H12AffineEnvironment.transform 6 9 env19386 = env19397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19386 == env19397) = true)

theorem identity19397 : scanCanonicalize (H12AffineFastState.compose env19397 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound19397 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env19398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,262144,1024,32769,4160,32,73755,73736,8193,64,262516,46157,77834,270685,99330,32,256,98679,79194,41821]

theorem envBound19398 : H12AffineFastState.Bounded env19398 := by
  intro p hp
  have h : env19398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19397_19398 : H12AffineEnvironment.transform 16 103495 env19397 = env19398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env19397 == env19398) = true)

theorem identity19398 : scanCanonicalize (H12AffineFastState.compose env19398 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound19398 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env19399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,67618,1024,32769,4160,32,73755,73736,8193,64,67926,46157,77834,76159,99330,32,256,98679,79194,41821]

theorem envBound19399 : H12AffineFastState.Bounded env19399 := by
  intro p hp
  have h : env19399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19398_19399 : H12AffineEnvironment.transform 17 67618 env19398 = env19399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env19398 == env19399) = true)

theorem identity19399 : scanCanonicalize (H12AffineFastState.compose env19399 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound19399 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env19400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,32803,5220,34817,1024,32769,4160,32,41016,41003,8193,64,35189,46157,45097,43356,1057,32,256,340,46457,41821]

theorem envBound19400 : H12AffineFastState.Bounded env19400 := by
  intro p hp
  have h : env19400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19399_19400 : H12AffineEnvironment.transform 15 32803 env19399 = env19400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env19399 == env19400) = true)

theorem identity19400 : scanCanonicalize (H12AffineFastState.compose env19400 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound19400 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env19401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8232,8203,5220,10281,1024,8233,4160,32,16,3,8193,64,10589,5221,4097,2420,1057,32,256,340,5457,885]

theorem envBound19401 : H12AffineFastState.Bounded env19401 := by
  intro p hp
  have h : env19401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19400_19401 : H12AffineEnvironment.transform 14 8232 env19400 = env19401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19400 == env19401) = true)

theorem identity19401 : scanCanonicalize (H12AffineFastState.compose env19401 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19401 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,293,262,5220,2340,1024,292,4160,32,16,3,268,64,2128,5221,4097,2420,1057,32,256,340,5457,885]

theorem envBound19402 : H12AffineFastState.Bounded env19402 := by
  intro p hp
  have h : env19402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19401_19402 : H12AffineEnvironment.transform 12 269 env19401 = env19402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19401 == env19402) = true)

theorem identity19402 : scanCanonicalize (H12AffineFastState.compose env19402 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19402 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env19403 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,115,5220,2129,1024,81,4160,32,16,3,121,64,2128,5221,4097,2049,1057,32,117,33,5156,512]

theorem envBound19403 : H12AffineFastState.Bounded env19403 := by
  intro p hp
  have h : env19403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19402_19403 : H12AffineEnvironment.transform 7 117 env19402 = env19403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19402 == env19403) = true)

theorem identity19403 : scanCanonicalize (H12AffineFastState.compose env19403 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19403 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19404 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,5125,32,3,5140,2081,1024,33,4144,32,16,3,9,48,2080,5141,4097,2049,1057,32,5,33,5156,512]

theorem envBound19404 : H12AffineFastState.Bounded env19404 := by
  intro p hp
  have h : env19404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19403_19404 : H12AffineEnvironment.transform 5 48 env19403 = env19404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19403 == env19404) = true)

theorem identity19404 : scanCanonicalize (H12AffineFastState.compose env19404 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19404 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env19405 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,1,3,5140,2048,1024,0,4113,1,16,3,9,17,2049,5141,4097,2049,1024,1,5,0,5125,512]

theorem envBound19405 : H12AffineFastState.Bounded env19405 := by
  intro p hp
  have h : env19405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19404_19405 : H12AffineEnvironment.transform 4 1 env19404 = env19405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19404 == env19405) = true)

def env19406 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,1,3,1028,2048,1024,0,1,1,16,3,9,17,2049,1029,17,2049,1024,1,5,0,1045,512]

theorem envBound19406 : H12AffineFastState.Bounded env19406 := by
  intro p hp
  have h : env19406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19405_19406 : H12AffineEnvironment.transform 11 16 env19405 = env19406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19405 == env19406) = true)

theorem identity19406 : scanCanonicalize (H12AffineFastState.compose env19406 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound19406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19407 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,0,1,3,17,2048,21,0,1,1,16,3,9,17,2049,16,17,2049,21,1,5,0,0,512]

theorem envBound19407 : H12AffineFastState.Bounded env19407 := by
  intro p hp
  have h : env19407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19406_19407 : H12AffineEnvironment.transform 9 21 env19406 = env19407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19406 == env19407) = true)

theorem identity19407 : scanCanonicalize (H12AffineFastState.compose env19407 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound19407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19408 : List Nat := [2,4,8,16,1,17,9,5,31,21,2048,16,8,0,1,3,17,2048,21,0,1,1,16,3,9,17,2049,16,17,2049,21,1,5,0,0,31]

theorem envBound19408 : H12AffineFastState.Bounded env19408 := by
  intro p hp
  have h : env19408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19407_19408 : H12AffineEnvironment.transform 8 31 env19407 = env19408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env19407 == env19408) = true)

def leafEnv19408 : List Nat := [2,4,8,16,1,17,9,5,31,21,2048,16,8,0,1,3,17,2048,21,0,1,1,16,3,21,9,1,17,2049,16,17,2049,21,1,5,0,4,2,0,31,1,1,0]

def active19408 : List Nat := [0,1,2,3,10]

def tree19408 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19408 : H12WitnessSearch.Good tree19408 := H12GlobalWitnessIndex.good

theorem leafIdentity19408 : H12AffineFastState.composeSystem env19408 rootObs = leafEnv19408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19408 rootObs == leafEnv19408) = true)

theorem terminalChecked19408 : H12PackedTerminal.terminalCheckFast leafEnv19408 active19408 tree19408 = true := by decide +kernel

def env19409 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1044,1,3,1029,2048,1024,0,0,1,16,3,9,17,2049,1028,16,2049,1024,1,5,0,1044,512]

theorem envBound19409 : H12AffineFastState.Bounded env19409 := by
  intro p hp
  have h : env19409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19405_19409 : H12AffineEnvironment.transform 11 17 env19405 = env19409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19405 == env19409) = true)

def env19410 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,1,3,17,2048,20,0,0,1,16,3,9,17,2049,16,16,2049,20,1,5,0,0,512]

theorem envBound19410 : H12AffineFastState.Bounded env19410 := by
  intro p hp
  have h : env19410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19409_19410 : H12AffineEnvironment.transform 9 20 env19409 = env19410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19409 == env19410) = true)

theorem identity19410 : scanCanonicalize (H12AffineFastState.compose env19410 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound19410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19411 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,4,8,0,1,3,4,2048,1,0,0,1,5,3,9,4,2049,5,5,2049,1,1,5,0,0,512]

theorem envBound19411 : H12AffineFastState.Bounded env19411 := by
  intro p hp
  have h : env19411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19410_19411 : H12AffineEnvironment.transform 3 5 env19410 = env19411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env19410 == env19411) = true)

def leafEnv19411 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,4,8,0,1,3,4,2048,1,0,0,1,5,3,1,9,1,4,2049,5,5,2049,1,1,5,0,4,2,0,512,1,0,0]

def active19411 : List Nat := [0,1,2,8,10]

def tree19411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19411 : H12WitnessSearch.Good tree19411 := H12GlobalWitnessIndex.good

theorem leafIdentity19411 : H12AffineFastState.composeSystem env19411 rootObs = leafEnv19411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19411 rootObs == leafEnv19411) = true)

theorem terminalChecked19411 : H12PackedTerminal.terminalCheckFast leafEnv19411 active19411 tree19411 = true := by decide +kernel

def env19412 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,1,1,3,16,2048,21,0,0,1,16,3,9,17,2049,17,16,2049,21,1,5,0,1,512]

theorem envBound19412 : H12AffineFastState.Bounded env19412 := by
  intro p hp
  have h : env19412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19409_19412 : H12AffineEnvironment.transform 9 21 env19409 = env19412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19409 == env19412) = true)

theorem identity19412 : scanCanonicalize (H12AffineFastState.compose env19412 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound19412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19413 : List Nat := [2,4,8,16,1,17,9,5,30,21,2048,17,8,1,1,3,16,2048,21,0,0,1,16,3,9,17,2049,17,16,2049,21,1,5,0,1,30]

theorem envBound19413 : H12AffineFastState.Bounded env19413 := by
  intro p hp
  have h : env19413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19412_19413 : H12AffineEnvironment.transform 8 30 env19412 = env19413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env19412 == env19413) = true)

def leafEnv19413 : List Nat := [2,4,8,16,1,17,9,5,30,21,2048,17,8,1,1,3,16,2048,21,0,0,1,16,3,21,9,1,17,2049,17,16,2049,21,1,5,0,4,2,1,30,1,0,0]

def active19413 : List Nat := [0,1,2,3,10]

def tree19413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19413 : H12WitnessSearch.Good tree19413 := H12GlobalWitnessIndex.good

theorem leafIdentity19413 : H12AffineFastState.composeSystem env19413 rootObs = leafEnv19413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19413 rootObs == leafEnv19413) = true)

theorem terminalChecked19413 : H12PackedTerminal.terminalCheckFast leafEnv19413 active19413 tree19413 = true := by decide +kernel

def env19414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73856,8328,64,508091,46157,77834,505115,119179,33,256,98678,90322,63069]

theorem envBound19414 : H12AffineFastState.Bounded env19414 := by
  intro p hp
  have h : env19414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19384_19414 : H12AffineEnvironment.transform 20 4161 env19384 = env19414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19384 == env19414) = true)

theorem identity19414 : scanCanonicalize (H12AffineFastState.compose env19414 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19414 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73736,8192,64,507955,46157,77834,505115,119043,33,256,98678,90202,63069]

theorem envBound19415 : H12AffineFastState.Bounded env19415 := by
  intro p hp
  have h : env19415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19414_19415 : H12AffineEnvironment.transform 6 8 env19414 = env19415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19414 == env19415) = true)

theorem identity19415 : scanCanonicalize (H12AffineFastState.compose env19415 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound19415 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,21793,95514,73736,8192,64,256026,46157,77834,236850,119043,33,256,98678,90202,63069]

theorem envBound19416 : H12AffineFastState.Bounded env19416 := by
  intro p hp
  have h : env19416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19415_19416 : H12AffineEnvironment.transform 17 10281 env19415 = env19416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19415 == env19416) = true)

theorem identity19416 : scanCanonicalize (H12AffineFastState.compose env19416 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,4161,21793,95514,73736,8192,64,203846,16401,77834,223598,75103,33,256,95530,90202,513]

theorem envBound19417 : H12AffineFastState.Bounded env19417 := by
  intro p hp
  have h : env19417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19416_19417 : H12AffineEnvironment.transform 14 29788 env19416 = env19417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19416 == env19417) = true)

theorem identity19417 : scanCanonicalize (H12AffineFastState.compose env19417 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound19417 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env19418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8283,131072,10281,1024,29789,4161,21793,21825,83,8192,64,146461,16401,4177,149813,1284,33,256,21873,16385,513]

theorem envBound19418 : H12AffineFastState.Bounded env19418 := by
  intro p hp
  have h : env19418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19417_19418 : H12AffineEnvironment.transform 15 8283 env19417 = env19418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env19417 == env19418) = true)

theorem identity19418 : scanCanonicalize (H12AffineFastState.compose env19418 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound19418 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8283,24861,10281,1024,29789,4161,21793,21825,83,8192,64,23808,16401,4177,10280,1284,33,256,21873,16385,513]

theorem envBound19419 : H12AffineFastState.Bounded env19419 := by
  intro p hp
  have h : env19419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19418_19419 : H12AffineEnvironment.transform 16 24861 env19418 = env19419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env19418 == env19419) = true)

theorem identity19419 : scanCanonicalize (H12AffineFastState.compose env19419 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19419 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19420 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8202,24861,10281,1024,29708,4112,21793,21776,2,8192,17,23808,16401,4096,10280,1284,33,256,21792,16385,513]

theorem envBound19420 : H12AffineFastState.Bounded env19420 := by
  intro p hp
  have h : env19420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19419_19420 : H12AffineEnvironment.transform 5 17 env19419 = env19420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19419 == env19420) = true)

theorem identity19420 : scanCanonicalize (H12AffineFastState.compose env19420 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19421 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10281,1024,8461,4112,32,17,2,8192,17,2049,5392,4096,10280,1284,33,256,33,5376,513]

theorem envBound19421 : H12AffineFastState.Bounded env19421 := by
  intro p hp
  have h : env19421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19420_19421 : H12AffineEnvironment.transform 13 5377 env19420 = env19421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19420 == env19421) = true)

theorem identity19421 : scanCanonicalize (H12AffineFastState.compose env19421 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound19421 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0