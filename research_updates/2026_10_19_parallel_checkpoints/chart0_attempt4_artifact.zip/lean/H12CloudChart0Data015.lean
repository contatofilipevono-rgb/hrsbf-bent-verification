import H12CloudChart0Data014

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans3689_3690 : H12AffineEnvironment.transform 21 61568 env3689 = env3690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61568 env3689 == env3690) = true)

theorem identity3690 : scanCanonicalize (H12AffineFastState.compose env3690 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 33063) := by decide +kernel

theorem selectedBound3690 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3691 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,33063,4525,43308,1024,32768,4097,61568,20741,41003,8329,20741,22956,16384,16812,22561,42252,20649,256,20480,45476,21160]

theorem envBound3691 : H12AffineFastState.Bounded env3691 := by
  intro p hp
  have h : env3691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3690_3691 : H12AffineEnvironment.transform 15 33063 env3690 = env3691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33063 env3690 == env3691) = true)

theorem identity3691 : scanCanonicalize (H12AffineFastState.compose env3691 (packedSelected [3,5,9,10,22] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3691 : packedSelected [3,5,9,10,22] rootPS < 2^1333 := by decide +kernel

def env3692 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,8192,16384,32768,33063,1824,43308,1024,32768,1676,58893,18312,41003,8329,18312,20257,16384,16812,20140,42252,17956,256,18061,42793,17445]

theorem envBound3692 : H12AffineFastState.Bounded env3692 := by
  intro p hp
  have h : env3692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3691_3692 : H12AffineEnvironment.transform 11 1677 env3691 = env3692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env3691 == env3692) = true)

theorem identity3692 : scanCanonicalize (H12AffineFastState.compose env3692 (packedSelected [0,1,2,3,7,8,10,11,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound3692 : packedSelected [0,1,2,3,7,8,10,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env3693 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,8192,16384,8460,8235,1824,2080,1024,8460,1676,18177,18312,295,8329,18312,20257,16384,16812,20140,1024,17956,256,18061,1573,17445]

theorem envBound3693 : H12AffineFastState.Bounded env3693 := by
  intro p hp
  have h : env3693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3692_3693 : H12AffineEnvironment.transform 14 8460 env3692 = env3693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env3692 == env3693) = true)

theorem identity3693 : scanCanonicalize (H12AffineFastState.compose env3693 (packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3693 : packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3694 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1677,8192,16384,8353,8235,1677,2080,1024,8353,1676,18092,17957,138,8329,17957,20108,16384,16385,20140,1024,17956,173,18061,1573,17445]

theorem envBound3694 : H12AffineFastState.Bounded env3694 := by
  intro p hp
  have h : env3694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3693_3694 : H12AffineEnvironment.transform 7 173 env3693 = env3694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3693 == env3694) = true)

theorem identity3694 : scanCanonicalize (H12AffineFastState.compose env3694 (packedSelected [0,3,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound3694 : packedSelected [0,3,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env3695 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1677,1156,16384,1061,1199,1677,2080,1024,1061,1676,18092,17957,138,1037,17957,20108,16384,16385,20140,1024,17956,173,18061,1573,17445]

theorem envBound3695 : H12AffineFastState.Bounded env3695 := by
  intro p hp
  have h : env3695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3694_3695 : H12AffineEnvironment.transform 12 1156 env3694 = env3695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env3694 == env3695) = true)

theorem identity3695 : scanCanonicalize (H12AffineFastState.compose env3695 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound3695 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env3696 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1677,1156,2090,1061,1199,1677,2080,1024,1061,1676,3718,3599,138,1037,3599,1702,2090,2091,1670,1024,3598,173,3751,1573,3087]

theorem envBound3696 : H12AffineFastState.Bounded env3696 := by
  intro p hp
  have h : env3696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3695_3696 : H12AffineEnvironment.transform 13 2090 env3695 = env3696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env3695 == env3696) = true)

theorem identity3696 : scanCanonicalize (H12AffineFastState.compose env3696 (packedSelected [0,1,2,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3696 : packedSelected [0,1,2,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env3697 : List Nat := [2,4,8,0,32,1,128,173,0,1024,2048,1165,1156,2090,1061,1199,1165,2080,1024,1061,1164,3206,3087,138,1037,3087,1190,2090,2091,1158,1024,3086,173,3239,1061,3087]

theorem envBound3697 : H12AffineFastState.Bounded env3697 := by
  intro p hp
  have h : env3697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3696_3697 : H12AffineEnvironment.transform 8 0 env3696 = env3697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3696 == env3697) = true)

theorem identity3697 : scanCanonicalize (H12AffineFastState.compose env3697 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3697 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env3698 : List Nat := [2,4,8,0,32,1,34,15,0,1024,2048,1071,1062,2090,1061,1037,1071,2080,1024,1061,1070,3108,3087,40,1037,3087,1028,2090,2091,1060,1024,3086,15,3077,1061,3087]

theorem envBound3698 : H12AffineFastState.Bounded env3698 := by
  intro p hp
  have h : env3698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3697_3698 : H12AffineEnvironment.transform 6 34 env3697 = env3698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3697 == env3698) = true)

theorem identity3698 : scanCanonicalize (H12AffineFastState.compose env3698 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound3698 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env3699 : List Nat := [2,4,8,0,32,1,34,15,0,1024,10,1071,1062,32,1061,1037,1071,42,1024,1061,1070,1070,1029,40,1037,1029,1028,32,33,1060,1024,1028,15,1039,1061,1029]

theorem envBound3699 : H12AffineFastState.Bounded env3699 := by
  intro p hp
  have h : env3699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3698_3699 : H12AffineEnvironment.transform 10 10 env3698 = env3699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env3698 == env3699) = true)

theorem identity3699 : scanCanonicalize (H12AffineFastState.compose env3699 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3699 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env3700 : List Nat := [2,4,8,0,32,1,34,15,0,4,10,43,34,32,33,9,43,42,4,33,42,42,1,40,9,1,0,32,33,32,4,0,15,11,33,1]

theorem envBound3700 : H12AffineFastState.Bounded env3700 := by
  intro p hp
  have h : env3700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3699_3700 : H12AffineEnvironment.transform 9 4 env3699 = env3700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3699 == env3700) = true)

theorem identity3700 : scanCanonicalize (H12AffineFastState.compose env3700 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3700 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3701 : List Nat := [2,4,7,0,32,1,34,0,0,4,5,36,34,32,33,6,36,37,4,33,37,37,1,39,6,1,0,32,33,32,4,0,0,4,33,1]

theorem envBound3701 : H12AffineFastState.Bounded env3701 := by
  intro p hp
  have h : env3701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3700_3701 : H12AffineEnvironment.transform 2 7 env3700 = env3701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3700 == env3701) = true)

def env3702 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43308,1024,32768,4097,61569,20741,41003,8329,20741,22956,16384,16812,22561,74795,20648,256,20480,77955,21160]

theorem envBound3702 : H12AffineFastState.Bounded env3702 := by
  intro p hp
  have h : env3702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3689_3702 : H12AffineEnvironment.transform 21 61569 env3689 = env3702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61569 env3689 == env3702) = true)

theorem identity3702 : scanCanonicalize (H12AffineFastState.compose env3702 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound3702 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3703 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,8461,65536,4525,2081,1024,8461,4097,20876,20741,294,8329,20741,22956,16384,16812,22561,74795,20648,256,20480,77955,21160]

theorem envBound3703 : H12AffineFastState.Bounded env3703 := by
  intro p hp
  have h : env3703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3702_3703 : H12AffineEnvironment.transform 14 8461 env3702 = env3703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env3702 == env3703) = true)

theorem identity3703 : scanCanonicalize (H12AffineFastState.compose env3703 (packedSelected [4,9,13,17,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 28974) := by decide +kernel

theorem selectedBound3703 : packedSelected [4,9,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env3704 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,8461,28974,4525,2081,1024,8461,4097,20876,20741,294,8329,20741,22956,16384,16812,22561,21765,20648,256,20480,16813,21160]

theorem envBound3704 : H12AffineFastState.Bounded env3704 := by
  intro p hp
  have h : env3704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3703_3704 : H12AffineEnvironment.transform 15 28974 env3703 = env3704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28974 env3703 == env3704) = true)

theorem identity3704 : scanCanonicalize (H12AffineFastState.compose env3704 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound3704 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3705 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,8192,16384,8461,26530,1825,2081,1024,8461,1677,18176,18313,294,8329,18313,20256,16384,16812,20141,17289,17956,256,18060,16813,17444]

theorem envBound3705 : H12AffineFastState.Bounded env3705 := by
  intro p hp
  have h : env3705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3704_3705 : H12AffineEnvironment.transform 11 1676 env3704 = env3705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env3704 == env3705) = true)

theorem identity3705 : scanCanonicalize (H12AffineFastState.compose env3705 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound3705 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3706 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,2348,16384,2081,20110,1825,2081,1024,2081,1677,18176,18313,294,2469,18313,20256,16384,16812,20141,17289,17956,256,18060,16813,17444]

theorem envBound3706 : H12AffineFastState.Bounded env3706 := by
  intro p hp
  have h : env3706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3705_3706 : H12AffineEnvironment.transform 12 2348 env3705 = env3706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env3705 == env3706) = true)

def env3707 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20740,41003,8329,20740,323712,16384,16812,22561,74795,4235305,256,20480,77955,21160]

theorem envBound3707 : H12AffineFastState.Bounded env3707 := by
  intro p hp
  have h : env3707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3687_3707 : H12AffineEnvironment.transform 3 1 env3687 = env3707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3687 == env3707) = true)

theorem identity3707 : scanCanonicalize (H12AffineFastState.compose env3707 (packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 338222) := by decide +kernel

theorem selectedBound3707 : packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3708 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,338222,20740,41003,8329,20740,323712,16384,16812,22561,74795,362759,256,20480,77955,21160]

theorem envBound3708 : H12AffineFastState.Bounded env3708 := by
  intro p hp
  have h : env3708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3707_3708 : H12AffineEnvironment.transform 21 338222 env3707 = env3708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 338222 env3707 == env3708) = true)

def env3709 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2184,1024,32768,4097,74150,20740,41003,8329,20740,63496,16384,16812,22561,74795,98703,256,20480,77955,21160]

theorem envBound3709 : H12AffineFastState.Bounded env3709 := by
  intro p hp
  have h : env3709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3708_3709 : H12AffineEnvironment.transform 17 2184 env3708 = env3709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3708 == env3709) = true)

theorem identity3709 : scanCanonicalize (H12AffineFastState.compose env3709 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound3709 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3710 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,28803,4525,2184,1024,32768,4097,20773,20740,41003,8329,20740,63496,16384,16812,22561,21672,61708,256,20480,16384,21160]

theorem envBound3710 : H12AffineFastState.Bounded env3710 := by
  intro p hp
  have h : env3710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3709_3710 : H12AffineEnvironment.transform 15 28803 env3709 = env3710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env3709 == env3710) = true)

theorem identity3710 : scanCanonicalize (H12AffineFastState.compose env3710 (packedSelected [0,2,3,4,5,7,10,11,13,17,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound3710 : packedSelected [0,2,3,4,5,7,10,11,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env3711 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,4097,32768,8322,4525,2184,1024,32768,4097,292,261,41003,8329,261,43017,4097,4525,2080,1193,41229,256,1,4097,681]

theorem envBound3711 : H12AffineFastState.Bounded env3711 := by
  intro p hp
  have h : env3711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3710_3711 : H12AffineEnvironment.transform 13 4097 env3710 = env3711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3710 == env3711) = true)

theorem identity3711 : scanCanonicalize (H12AffineFastState.compose env3711 (packedSelected [0,2,4,7,9,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3711 : packedSelected [0,2,4,7,9,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3712 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1573,8192,1572,32768,8322,1928,2184,1024,32768,1572,292,261,41003,8329,261,43017,1572,1928,2080,1193,41229,256,1,1572,681]

theorem envBound3712 : H12AffineFastState.Bounded env3712 := by
  intro p hp
  have h : env3712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3711_3712 : H12AffineEnvironment.transform 11 1573 env3711 = env3712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env3711 == env3712) = true)

theorem identity3712 : scanCanonicalize (H12AffineFastState.compose env3712 (packedSelected [3,4,5,9,10,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3712 : packedSelected [3,4,5,9,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3713 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1573,8192,1572,8201,8322,1928,2184,1024,8201,1572,292,261,34,8329,261,2048,1572,1928,2080,1193,260,256,1,1572,681]

theorem envBound3713 : H12AffineFastState.Bounded env3713 := by
  intro p hp
  have h : env3713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3712_3713 : H12AffineEnvironment.transform 14 8201 env3712 = env3713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3712 == env3713) = true)

theorem identity3713 : scanCanonicalize (H12AffineFastState.compose env3713 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3713 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3714 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,1573,8192,1572,8201,8234,1824,2080,1024,8201,1572,292,261,34,8225,261,2048,1572,1824,2080,1025,260,256,1,1572,513]

theorem envBound3714 : H12AffineFastState.Bounded env3714 := by
  intro p hp
  have h : env3714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3713_3714 : H12AffineEnvironment.transform 6 40 env3713 = env3714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3713 == env3714) = true)

theorem identity3714 : scanCanonicalize (H12AffineFastState.compose env3714 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3714 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3715 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1550,1573,8192,1572,8201,8234,1824,1582,1024,8201,1572,292,261,34,8225,261,1550,1572,1824,1582,1025,260,256,1,1572,513]

theorem envBound3715 : H12AffineFastState.Bounded env3715 := by
  intro p hp
  have h : env3715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3714_3715 : H12AffineEnvironment.transform 10 1550 env3714 = env3715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3714 == env3715) = true)

theorem identity3715 : scanCanonicalize (H12AffineFastState.compose env3715 (packedSelected [1,6,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3715 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env3716 : List Nat := [2,4,3,1,32,0,35,256,512,1024,1541,1573,8192,1572,8194,8225,1824,1573,1024,8194,1572,292,261,34,8225,261,1541,1572,1824,1573,1025,260,256,1,1572,513]

theorem envBound3716 : H12AffineFastState.Bounded env3716 := by
  intro p hp
  have h : env3716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3715_3716 : H12AffineEnvironment.transform 2 3 env3715 = env3716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3715 == env3716) = true)

theorem identity3716 : scanCanonicalize (H12AffineFastState.compose env3716 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3716 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env3717 : List Nat := [2,4,3,1,32,0,35,5,512,1024,1541,1573,8192,1572,8194,8225,1573,1573,1024,8194,1572,33,0,34,8225,0,1541,1572,1573,1573,1025,1,5,1,1572,513]

theorem envBound3717 : H12AffineFastState.Bounded env3717 := by
  intro p hp
  have h : env3717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3716_3717 : H12AffineEnvironment.transform 7 5 env3716 = env3717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3716 == env3717) = true)

theorem identity3717 : scanCanonicalize (H12AffineFastState.compose env3717 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3717 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3718 : List Nat := [2,4,3,1,32,0,35,5,512,1024,1541,1573,1031,1572,1029,1062,1573,1573,1024,1029,1572,33,0,34,1062,0,1541,1572,1573,1573,1025,1,5,1,1572,513]

theorem envBound3718 : H12AffineFastState.Bounded env3718 := by
  intro p hp
  have h : env3718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3717_3718 : H12AffineEnvironment.transform 12 1031 env3717 = env3718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3717 == env3718) = true)

theorem identity3718 : scanCanonicalize (H12AffineFastState.compose env3718 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound3718 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3719 : List Nat := [2,4,3,1,32,0,35,5,5,1024,1024,1056,1031,1057,1029,1062,1056,1056,1024,1029,1057,33,0,34,1062,0,1024,1057,1056,1056,1025,1,5,1,1057,4]

theorem envBound3719 : H12AffineFastState.Bounded env3719 := by
  intro p hp
  have h : env3719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3718_3719 : H12AffineEnvironment.transform 8 5 env3718 = env3719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env3718 == env3719) = true)

theorem identity3719 : scanCanonicalize (H12AffineFastState.compose env3719 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3719 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3720 : List Nat := [2,1,3,1,32,0,35,0,0,1024,1024,1056,1026,1057,1024,1059,1056,1056,1024,1024,1057,33,0,34,1059,0,1024,1057,1056,1056,1025,1,0,1,1057,1]

theorem envBound3720 : H12AffineFastState.Bounded env3720 := by
  intro p hp
  have h : env3720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3719_3720 : H12AffineEnvironment.transform 1 1 env3719 = env3720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3719 == env3720) = true)

theorem identity3720 : scanCanonicalize (H12AffineFastState.compose env3720 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3720 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3721 : List Nat := [2,1,3,1,32,0,35,0,0,32,32,0,34,1,32,3,0,0,32,32,1,33,0,34,3,0,32,1,0,0,33,1,0,1,1,1]

theorem envBound3721 : H12AffineFastState.Bounded env3721 := by
  intro p hp
  have h : env3721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3720_3721 : H12AffineEnvironment.transform 9 32 env3720 = env3721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3720 == env3721) = true)

def leafEnv3721 : List Nat := [2,1,3,1,32,0,35,0,0,32,32,0,34,1,32,3,0,0,32,32,1,33,0,34,33,3,1,0,32,1,0,0,33,1,0,1,1,34,1,1,1,1,0]

def active3721 : List Nat := [0,4]

def tree3721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3721 : H12WitnessSearch.Good tree3721 := H12GlobalWitnessIndex.good

theorem leafIdentity3721 : H12AffineFastState.composeSystem env3721 rootObs = leafEnv3721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3721 rootObs == leafEnv3721) = true)

theorem terminalChecked3721 : H12PackedTerminal.terminalCheckFast leafEnv3721 active3721 tree3721 = true := by decide +kernel

def env3722 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2185,1024,32768,4097,74151,20740,41003,8329,20740,63497,16384,16812,22561,74795,98702,256,20480,77955,21160]

theorem envBound3722 : H12AffineFastState.Bounded env3722 := by
  intro p hp
  have h : env3722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3708_3722 : H12AffineEnvironment.transform 17 2185 env3708 = env3722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env3708 == env3722) = true)

theorem identity3722 : scanCanonicalize (H12AffineFastState.compose env3722 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 29062) := by decide +kernel

theorem selectedBound3722 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3723 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,29062,4525,2185,1024,32768,4097,20513,20740,41003,8329,20740,63497,16384,16812,22561,21933,61448,256,20480,16645,21160]

theorem envBound3723 : H12AffineFastState.Bounded env3723 := by
  intro p hp
  have h : env3723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3722_3723 : H12AffineEnvironment.transform 15 29062 env3722 = env3723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29062 env3722 == env3723) = true)

theorem identity3723 : scanCanonicalize (H12AffineFastState.compose env3723 (packedSelected [0,2,4,7,11,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound3723 : packedSelected [0,2,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env3724 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,8613,29062,4525,2185,1024,8613,4097,20513,20740,398,8329,20740,22956,16384,16812,22561,21933,20909,256,20480,16645,21160]

theorem envBound3724 : H12AffineFastState.Bounded env3724 := by
  intro p hp
  have h : env3724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3723_3724 : H12AffineEnvironment.transform 14 8613 env3723 = env3724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env3723 == env3724) = true)

theorem identity3724 : scanCanonicalize (H12AffineFastState.compose env3724 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3724 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3725 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,1572,8613,14242,4525,2185,1024,8613,4097,5637,5920,398,8329,5920,8072,1572,1928,7685,5001,6025,256,5668,1825,5260]

theorem envBound3725 : H12AffineFastState.Bounded env3725 := by
  intro p hp
  have h : env3725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3724_3725 : H12AffineEnvironment.transform 13 1572 env3724 = env3725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env3724 == env3725) = true)

theorem identity3725 : scanCanonicalize (H12AffineFastState.compose env3725 (packedSelected [0,4,7,9,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3725 : packedSelected [0,4,7,9,12,15,17] rootPS < 2^1333 := by decide +kernel

def env3726 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,1572,8460,14091,4356,2080,1024,8460,4097,5637,5920,295,8224,5920,7969,1572,1825,7685,4896,5920,256,5668,1825,5157]

theorem envBound3726 : H12AffineFastState.Bounded env3726 := by
  intro p hp
  have h : env3726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3725_3726 : H12AffineEnvironment.transform 6 41 env3725 = env3726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3725 == env3726) = true)

theorem identity3726 : scanCanonicalize (H12AffineFastState.compose env3726 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3726 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env3727 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,2351,8192,1572,8460,11812,2091,2080,1024,8460,2350,3882,3599,295,8224,3599,1550,1572,1825,1834,2575,3599,256,3851,1825,3338]

theorem envBound3727 : H12AffineFastState.Bounded env3727 := by
  intro p hp
  have h : env3727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3726_3727 : H12AffineEnvironment.transform 11 2351 env3726 = env3727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env3726 == env3727) = true)

theorem identity3727 : scanCanonicalize (H12AffineFastState.compose env3727 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound3727 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3728 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,2351,2600,1572,2852,1036,2091,2080,1024,2852,2350,3882,3599,295,2568,3599,1550,1572,1825,1834,2575,3599,256,3851,1825,3338]

theorem envBound3728 : H12AffineFastState.Bounded env3728 := by
  intro p hp
  have h : env3728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3727_3728 : H12AffineEnvironment.transform 12 2600 env3727 = env3728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env3727 == env3728) = true)

def env3729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323792,16384,16893,22641,74794,12644668,257,20560,8479126,8389613]

theorem envBound3729 : H12AffineFastState.Bounded env3729 := by
  intro p hp
  have h : env3729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3674_3729 : H12AffineEnvironment.transform 18 1025 env3674 = env3729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3674 == env3729) = true)

theorem identity3729 : scanCanonicalize (H12AffineFastState.compose env3729 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound3729 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1092,8192,16384,32768,65536,1464,262144,1025,32768,1093,4194304,8388608,41003,8329,8388688,320660,16384,16893,19509,74794,12641656,257,17428,8479126,8389613]

theorem envBound3730 : H12AffineFastState.Bounded env3730 := by
  intro p hp
  have h : env3730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3729_3730 : H12AffineEnvironment.transform 11 1092 env3729 = env3730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env3729 == env3730) = true)

def env3731 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1045,4194304,8388608,41003,8329,8388608,320660,16384,16813,19509,74794,12641576,257,17428,8479126,8389565]

theorem envBound3731 : H12AffineFastState.Bounded env3731 := by
  intro p hp
  have h : env3731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3730_3731 : H12AffineEnvironment.transform 5 16 env3730 = env3731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3730 == env3731) = true)

def env3732 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1045,4194304,8388608,41003,8329,8388608,320660,16384,16401,19509,74794,12641428,189,17428,8478762,8389121]

theorem envBound3732 : H12AffineFastState.Bounded env3732 := by
  intro p hp
  have h : env3732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3731_3732 : H12AffineEnvironment.transform 7 188 env3731 = env3732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3731 == env3732) = true)

theorem identity3732 : scanCanonicalize (H12AffineFastState.compose env3732 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound3732 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3733 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1045,4194304,4194352,41003,8329,4194352,320660,16384,16401,19509,74794,58532,189,17428,4284442,4194865]

theorem envBound3733 : H12AffineFastState.Bounded env3733 := by
  intro p hp
  have h : env3733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3732_3733 : H12AffineEnvironment.transform 22 4194352 env3732 = env3733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env3732 == env3733) = true)

def env3734 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1029,4194304,4194336,41003,8329,4194336,320644,16384,16385,19493,74794,58532,173,17412,4284426,4194849]

theorem envBound3734 : H12AffineFastState.Bounded env3734 := by
  intro p hp
  have h : env3734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3733_3734 : H12AffineEnvironment.transform 3 0 env3733 = env3734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3733 == env3734) = true)

theorem identity3734 : scanCanonicalize (H12AffineFastState.compose env3734 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3734 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3735 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8201,65536,1028,262144,1025,8201,1029,4194304,4194336,34,8329,4194336,279693,16384,16385,19493,74794,17581,173,17412,4284426,4194849]

theorem envBound3735 : H12AffineFastState.Bounded env3735 := by
  intro p hp
  have h : env3735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3734_3735 : H12AffineEnvironment.transform 14 8201 env3734 = env3735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3734 == env3735) = true)

theorem identity3735 : scanCanonicalize (H12AffineFastState.compose env3735 (packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 281605) := by decide +kernel

theorem selectedBound3735 : packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env3736 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8201,65536,1028,262144,1025,8201,1029,281605,281637,34,8329,281637,279693,16384,16385,19493,74794,17581,173,17412,338959,282148]

theorem envBound3736 : H12AffineFastState.Bounded env3736 := by
  intro p hp
  have h : env3736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3735_3736 : H12AffineEnvironment.transform 21 281605 env3735 = env3736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281605 env3735 == env3736) = true)

theorem identity3736 : scanCanonicalize (H12AffineFastState.compose env3736 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound3736 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3737 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8201,25647,1028,262144,1025,8201,1029,281605,281637,34,8329,281637,279693,16384,16385,19493,16389,17581,173,17412,280608,282148]

theorem envBound3737 : H12AffineFastState.Bounded env3737 := by
  intro p hp
  have h : env3737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3736_3737 : H12AffineEnvironment.transform 15 25647 env3736 = env3737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env3736 == env3737) = true)

theorem identity3737 : scanCanonicalize (H12AffineFastState.compose env3737 (packedSelected [1,4,6,8,9,12] rootPS)) = affineNative (2^(17+1) ^^^ 16514) := by decide +kernel

theorem selectedBound3737 : packedSelected [1,4,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env3738 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8201,25647,1028,16514,1025,8201,1029,3207,3239,34,8329,3239,1039,16384,16385,19493,16389,17581,173,17412,2210,3750]

theorem envBound3738 : H12AffineFastState.Bounded env3738 := by
  intro p hp
  have h : env3738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3737_3738 : H12AffineEnvironment.transform 17 16514 env3737 = env3738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16514 env3737 == env3738) = true)

theorem identity3738 : scanCanonicalize (H12AffineFastState.compose env3738 (packedSelected [2,3,5,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 11308) := by decide +kernel

theorem selectedBound3738 : packedSelected [2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env3739 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,11308,8201,2051,1028,11438,1025,8201,1029,3207,3239,34,8329,3239,1039,11308,11309,8201,11305,10369,173,10280,2210,3750]

theorem envBound3739 : H12AffineFastState.Bounded env3739 := by
  intro p hp
  have h : env3739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3738_3739 : H12AffineEnvironment.transform 13 11308 env3738 = env3739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11308 env3738 == env3739) = true)

theorem identity3739 : scanCanonicalize (H12AffineFastState.compose env3739 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound3739 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3740 : List Nat := [2,4,8,0,32,0,128,172,168,1024,2048,1028,8192,11308,8201,2051,1028,11438,1025,8201,1029,3207,3239,34,8329,3239,1039,11308,11309,8201,11305,10369,173,10280,2210,3086]

theorem envBound3740 : H12AffineFastState.Bounded env3740 := by
  intro p hp
  have h : env3740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3739_3740 : H12AffineEnvironment.transform 8 168 env3739 = env3740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env3739 == env3740) = true)

theorem identity3740 : scanCanonicalize (H12AffineFastState.compose env3740 (packedSelected [4,7,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound3740 : packedSelected [4,7,11,13] rootPS < 2^1333 := by decide +kernel

def env3741 : List Nat := [2,4,8,0,32,0,128,172,168,1024,2048,1028,2208,1164,2217,2051,1028,1038,1025,2217,1029,3207,3239,34,2089,3239,1039,1164,1165,2217,1161,33,173,136,2210,3086]

theorem envBound3741 : H12AffineFastState.Bounded env3741 := by
  intro p hp
  have h : env3741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3740_3741 : H12AffineEnvironment.transform 12 2208 env3740 = env3741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env3740 == env3741) = true)

theorem identity3741 : scanCanonicalize (H12AffineFastState.compose env3741 (packedSelected [0,2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound3741 : packedSelected [0,2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env3742 : List Nat := [2,4,8,0,32,0,128,172,168,1024,136,1028,40,1164,33,139,1028,1038,1025,33,1029,1039,1071,34,161,1071,1039,1164,1165,33,1161,33,173,136,42,1158]

theorem envBound3742 : H12AffineFastState.Bounded env3742 := by
  intro p hp
  have h : env3742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3741_3742 : H12AffineEnvironment.transform 10 136 env3741 = env3742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env3741 == env3742) = true)

theorem identity3742 : scanCanonicalize (H12AffineFastState.compose env3742 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound3742 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3743 : List Nat := [2,4,8,0,32,0,128,172,168,173,136,169,40,33,33,139,169,163,172,33,168,162,130,34,161,130,162,33,32,33,36,33,173,136,42,43]

theorem envBound3743 : H12AffineFastState.Bounded env3743 := by
  intro p hp
  have h : env3743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3742_3743 : H12AffineEnvironment.transform 9 173 env3742 = env3743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env3742 == env3743) = true)

theorem identity3743 : scanCanonicalize (H12AffineFastState.compose env3743 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3744 : List Nat := [2,4,2,0,32,0,128,166,162,167,130,163,34,33,33,129,163,163,166,33,162,162,130,34,161,130,162,33,32,33,36,33,167,130,32,33]

theorem envBound3744 : H12AffineFastState.Bounded env3744 := by
  intro p hp
  have h : env3744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3743_3744 : H12AffineEnvironment.transform 2 2 env3743 = env3744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3743 == env3744) = true)

theorem identity3744 : scanCanonicalize (H12AffineFastState.compose env3744 (packedSelected [0,20] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3744 : packedSelected [0,20] rootPS < 2^1333 := by decide +kernel

def env3745 : List Nat := [2,4,2,0,32,0,34,4,0,5,32,1,34,33,33,35,1,1,4,33,0,0,32,34,3,32,0,33,32,33,36,33,5,32,32,33]

theorem envBound3745 : H12AffineFastState.Bounded env3745 := by
  intro p hp
  have h : env3745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3744_3745 : H12AffineEnvironment.transform 6 34 env3744 = env3745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3744 == env3745) = true)

theorem identity3745 : scanCanonicalize (H12AffineFastState.compose env3745 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3746 : List Nat := [2,4,2,0,0,0,2,4,0,5,0,1,2,1,1,3,1,1,4,1,0,0,0,2,3,0,0,1,0,1,4,1,5,0,0,1]

theorem envBound3746 : H12AffineFastState.Bounded env3746 := by
  intro p hp
  have h : env3746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3745_3746 : H12AffineEnvironment.transform 4 0 env3745 = env3746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3745 == env3746) = true)

theorem identity3746 : scanCanonicalize (H12AffineFastState.compose env3746 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3747 : List Nat := [2,0,2,0,0,0,2,0,0,1,0,1,2,1,1,3,1,1,0,1,0,0,0,2,3,0,0,1,0,1,0,1,1,0,0,1]

theorem envBound3747 : H12AffineFastState.Bounded env3747 := by
  intro p hp
  have h : env3747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3746_3747 : H12AffineEnvironment.transform 1 0 env3746 = env3747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3746 == env3747) = true)

def env3748 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41003,8329,4194337,320645,16384,16384,19492,74794,58532,172,17413,4284427,4194848]

theorem envBound3748 : H12AffineFastState.Bounded env3748 := by
  intro p hp
  have h : env3748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3733_3748 : H12AffineEnvironment.transform 3 1 env3733 = env3748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3733 == env3748) = true)

theorem identity3748 : scanCanonicalize (H12AffineFastState.compose env3748 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 50214) := by decide +kernel

theorem selectedBound3748 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3749 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50214,1028,262144,1025,32768,1028,4194304,4194337,41003,8329,4194337,320645,16384,16384,19492,57356,58532,172,17413,4236333,4194848]

theorem envBound3749 : H12AffineFastState.Bounded env3749 := by
  intro p hp
  have h : env3749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3748_3749 : H12AffineEnvironment.transform 15 50214 env3748 = env3749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50214 env3748 == env3749) = true)

theorem identity3749 : scanCanonicalize (H12AffineFastState.compose env3749 (packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound3749 : packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3750 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50214,1028,19596,1025,32768,1028,4194304,4194337,41003,8329,4194337,43017,16384,16384,19492,57356,58532,172,17413,4236333,4194848]

theorem envBound3750 : H12AffineFastState.Bounded env3750 := by
  intro p hp
  have h : env3750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3749_3750 : H12AffineEnvironment.transform 17 19596 env3749 = env3750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env3749 == env3750) = true)

theorem identity3750 : scanCanonicalize (H12AffineFastState.compose env3750 (packedSelected [0,4,7,13,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound3750 : packedSelected [0,4,7,13,21,22] rootPS < 2^1333 := by decide +kernel

def env3751 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50214,1028,19596,1025,32768,1028,41000,40969,41003,8329,40969,43017,16384,16384,19492,57356,58532,172,17413,1029,41480]

theorem envBound3751 : H12AffineFastState.Bounded env3751 := by
  intro p hp
  have h : env3751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3750_3751 : H12AffineEnvironment.transform 21 41000 env3750 = env3751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env3750 == env3751) = true)

theorem identity3751 : scanCanonicalize (H12AffineFastState.compose env3751 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound3751 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3752 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,1676,32768,33450,1028,2560,1025,32768,1028,41000,40969,41003,8329,40969,43017,1676,1676,2728,42624,41512,172,649,1029,41480]

theorem envBound3752 : H12AffineFastState.Bounded env3752 := by
  intro p hp
  have h : env3752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3751_3752 : H12AffineEnvironment.transform 13 1676 env3751 = env3752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env3751 == env3752) = true)

theorem identity3752 : scanCanonicalize (H12AffineFastState.compose env3752 (packedSelected [0,1,2,3,4,7,9,11,12,13,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound3752 : packedSelected [0,1,2,3,4,7,9,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env3753 : List Nat := [2,4,8,1,32,1,128,173,136,1024,2048,1029,8192,1028,32768,32802,1028,2184,1025,32768,1028,41000,40969,41003,8329,40969,43017,1028,1028,2080,41992,41120,172,1,1029,41088]

theorem envBound3753 : H12AffineFastState.Bounded env3753 := by
  intro p hp
  have h : env3753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3752_3753 : H12AffineEnvironment.transform 8 136 env3752 = env3753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env3752 == env3753) = true)

theorem identity3753 : scanCanonicalize (H12AffineFastState.compose env3753 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3753 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3754 : List Nat := [2,4,8,1,32,1,41,4,33,1024,2048,1029,8192,1028,32768,32802,1028,2081,1025,32768,1028,41000,40969,41003,8224,40969,43017,1028,1028,2080,41992,40969,5,1,1029,41001]

theorem envBound3754 : H12AffineFastState.Bounded env3754 := by
  intro p hp
  have h : env3754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3753_3754 : H12AffineEnvironment.transform 6 41 env3753 = env3754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3753 == env3754) = true)

theorem identity3754 : scanCanonicalize (H12AffineFastState.compose env3754 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 1068) := by decide +kernel

theorem selectedBound3754 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3755 : List Nat := [2,4,8,1,32,1,41,4,33,1024,2048,1029,1068,1028,32768,32802,1028,2081,1025,32768,1028,33796,33829,33799,1036,33829,35877,1028,1028,2080,32804,33829,5,1,1029,33797]

theorem envBound3755 : H12AffineFastState.Bounded env3755 := by
  intro p hp
  have h : env3755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3754_3755 : H12AffineEnvironment.transform 12 1068 env3754 = env3755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1068 env3754 == env3755) = true)

theorem identity3755 : scanCanonicalize (H12AffineFastState.compose env3755 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound3755 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3756 : List Nat := [2,4,8,1,32,1,41,4,33,1024,1070,1029,1068,1028,32768,32802,1028,1039,1025,32768,1028,33796,33829,33799,1036,33829,32779,1028,1028,1038,32804,33829,5,1,1029,33797]

theorem envBound3756 : H12AffineFastState.Bounded env3756 := by
  intro p hp
  have h : env3756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3755_3756 : H12AffineEnvironment.transform 10 1070 env3755 = env3756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env3755 == env3756) = true)

theorem identity3756 : scanCanonicalize (H12AffineFastState.compose env3756 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound3756 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3757 : List Nat := [2,4,8,1,32,1,41,4,33,1024,1070,1029,1068,1028,1070,1036,1028,1039,1025,1070,1028,42,11,41,1036,11,1061,1028,1028,1038,1034,11,5,1,1029,43]

theorem envBound3757 : H12AffineFastState.Bounded env3757 := by
  intro p hp
  have h : env3757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3756_3757 : H12AffineEnvironment.transform 14 1070 env3756 = env3757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env3756 == env3757) = true)

theorem identity3757 : scanCanonicalize (H12AffineFastState.compose env3757 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3757 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env3758 : List Nat := [2,4,8,1,32,1,41,4,33,46,0,43,2,42,0,34,42,33,47,0,42,42,11,41,34,11,11,42,42,32,36,11,5,1,43,43]

theorem envBound3758 : H12AffineFastState.Bounded env3758 := by
  intro p hp
  have h : env3758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3757_3758 : H12AffineEnvironment.transform 9 46 env3757 = env3758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3757 == env3758) = true)

theorem identity3758 : scanCanonicalize (H12AffineFastState.compose env3758 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3758 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3759 : List Nat := [2,4,8,1,10,1,3,4,11,4,0,1,2,0,0,8,0,11,5,0,0,0,11,3,8,11,11,0,0,10,14,11,5,1,1,1]

theorem envBound3759 : H12AffineFastState.Bounded env3759 := by
  intro p hp
  have h : env3759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3758_3759 : H12AffineEnvironment.transform 4 10 env3758 = env3759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3758 == env3759) = true)

theorem identity3759 : scanCanonicalize (H12AffineFastState.compose env3759 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3760 : List Nat := [2,4,3,1,1,1,3,4,0,4,0,1,2,0,0,3,0,0,5,0,0,0,0,3,3,0,0,0,0,1,5,0,5,1,1,1]

theorem envBound3760 : H12AffineFastState.Bounded env3760 := by
  intro p hp
  have h : env3760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3759_3760 : H12AffineEnvironment.transform 2 3 env3759 = env3760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3759 == env3760) = true)

theorem identity3760 : scanCanonicalize (H12AffineFastState.compose env3760 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3761 : List Nat := [2,1,3,1,1,1,3,1,0,1,0,1,2,0,0,3,0,0,0,0,0,0,0,3,3,0,0,0,0,1,0,0,0,1,1,1]

theorem envBound3761 : H12AffineFastState.Bounded env3761 := by
  intro p hp
  have h : env3761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3760_3761 : H12AffineEnvironment.transform 1 1 env3760 = env3761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3760 == env3761) = true)

def env3762 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1029,262144,1025,32768,1045,4194304,8388608,41003,8329,8388608,320660,16384,16400,19509,74794,12641429,188,17428,8478763,8389120]

theorem envBound3762 : H12AffineFastState.Bounded env3762 := by
  intro p hp
  have h : env3762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3731_3762 : H12AffineEnvironment.transform 7 189 env3731 = env3762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3731 == env3762) = true)

theorem identity3762 : scanCanonicalize (H12AffineFastState.compose env3762 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50318) := by decide +kernel

theorem selectedBound3762 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3763 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1045,4194304,8388608,41003,8329,8388608,320660,16384,16400,19509,57508,12641429,188,17428,8430757,8389120]

theorem envBound3763 : H12AffineFastState.Bounded env3763 := by
  intro p hp
  have h : env3763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3762_3763 : H12AffineEnvironment.transform 15 50318 env3762 = env3763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50318 env3762 == env3763) = true)

def env3764 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1045,4194304,4235392,41003,8329,4235392,320660,16384,16400,19509,57508,17429,188,17428,4195365,4235904]

theorem envBound3764 : H12AffineFastState.Bounded env3764 := by
  intro p hp
  have h : env3764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3763_3764 : H12AffineEnvironment.transform 22 4235392 env3763 = env3764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env3763 == env3764) = true)

theorem identity3764 : scanCanonicalize (H12AffineFastState.compose env3764 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3764 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3765 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50318,1029,262144,1025,32768,1029,4194304,4235392,41003,8329,4235392,320644,16384,16384,19493,57508,17413,172,17412,4195365,4235904]

theorem envBound3765 : H12AffineFastState.Bounded env3765 := by
  intro p hp
  have h : env3765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3764_3765 : H12AffineEnvironment.transform 3 0 env3764 = env3765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3764 == env3765) = true)

theorem identity3765 : scanCanonicalize (H12AffineFastState.compose env3765 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound3765 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3766 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50318,1029,262144,1025,32768,1029,41000,168,41003,8329,168,320644,16384,16384,19493,57508,17413,172,17412,41997,680]

theorem envBound3766 : H12AffineFastState.Bounded env3766 := by
  intro p hp
  have h : env3766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3765_3766 : H12AffineEnvironment.transform 21 41000 env3765 = env3766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env3765 == env3766) = true)

theorem identity3766 : scanCanonicalize (H12AffineFastState.compose env3766 (packedSelected [0,3,5,7,10,17,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 19972) := by decide +kernel

theorem selectedBound3766 : packedSelected [0,3,5,7,10,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3767 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50318,1029,19972,1025,32768,1029,41000,168,41003,8329,168,43648,16384,16384,19493,57508,17413,172,17412,41997,680]

theorem envBound3767 : H12AffineFastState.Bounded env3767 := by
  intro p hp
  have h : env3767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3766_3767 : H12AffineEnvironment.transform 17 19972 env3766 = env3767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19972 env3766 == env3767) = true)

theorem identity3767 : scanCanonicalize (H12AffineFastState.compose env3767 (packedSelected [1,3,11,13,17,23] rootPS)) = affineNative (2^(14+1) ^^^ 25733) := by decide +kernel

theorem selectedBound3767 : packedSelected [1,3,11,13,17,23] rootPS < 2^1333 := by decide +kernel

def env3768 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,25733,8203,1029,19972,1025,25733,1029,17581,168,17582,8329,168,19973,16384,16384,19493,1057,17413,172,17412,16520,680]

theorem envBound3768 : H12AffineFastState.Bounded env3768 := by
  intro p hp
  have h : env3768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3767_3768 : H12AffineEnvironment.transform 14 25733 env3767 = env3768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25733 env3767 == env3768) = true)

theorem identity3768 : scanCanonicalize (H12AffineFastState.compose env3768 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3768 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3769 : List Nat := [2,4,8,0,32,0,128,173,0,1024,2048,1028,8192,16384,25733,8203,1029,19460,1025,25733,1029,17581,168,17582,8329,168,19461,16384,16384,19493,1057,17413,172,17412,16520,168]

theorem envBound3769 : H12AffineFastState.Bounded env3769 := by
  intro p hp
  have h : env3769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3768_3769 : H12AffineEnvironment.transform 8 0 env3768 = env3769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3768 == env3769) = true)

theorem identity3769 : scanCanonicalize (H12AffineFastState.compose env3769 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound3769 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3770 : List Nat := [2,4,8,0,32,0,128,173,0,1024,2048,1028,8192,8195,1158,8203,1029,11271,1025,1158,1029,9390,168,9389,8329,168,11270,8195,8195,11302,1057,9222,172,9223,8331,168]

theorem envBound3770 : H12AffineFastState.Bounded env3770 := by
  intro p hp
  have h : env3770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3769_3770 : H12AffineEnvironment.transform 13 8195 env3769 = env3770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env3769 == env3770) = true)

theorem identity3770 : scanCanonicalize (H12AffineFastState.compose env3770 (packedSelected [0,2,3,6,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound3770 : packedSelected [0,2,3,6,8,10] rootPS < 2^1333 := by decide +kernel

def env3771 : List Nat := [2,4,8,0,32,0,128,173,0,1024,33,1028,8192,8195,1158,8203,1029,9254,1025,1158,1029,9390,168,9389,8329,168,9255,8195,8195,9223,1057,9222,172,9223,8331,168]

theorem envBound3771 : H12AffineFastState.Bounded env3771 := by
  intro p hp
  have h : env3771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3770_3771 : H12AffineEnvironment.transform 10 33 env3770 = env3771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env3770 == env3771) = true)

theorem identity3771 : scanCanonicalize (H12AffineFastState.compose env3771 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound3771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3772 : List Nat := [2,4,8,0,32,0,128,173,0,1024,33,1028,1166,1165,1158,1157,1029,168,1025,1158,1029,32,168,35,1031,168,169,1165,1165,137,1057,136,172,137,1029,168]

theorem envBound3772 : H12AffineFastState.Bounded env3772 := by
  intro p hp
  have h : env3772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3771_3772 : H12AffineEnvironment.transform 12 1166 env3771 = env3772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env3771 == env3772) = true)

def env3773 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1045,4194304,4235393,41003,8329,4235393,320660,16384,16400,19509,57508,17428,188,17428,4195364,4235905]

theorem envBound3773 : H12AffineFastState.Bounded env3773 := by
  intro p hp
  have h : env3773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3763_3773 : H12AffineEnvironment.transform 22 4235393 env3763 = env3773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env3763 == env3773) = true)

theorem identity3773 : scanCanonicalize (H12AffineFastState.compose env3773 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound3773 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3774 : List Nat := [2,4,8,16,32,16,57,4,512,1024,2048,1044,8192,16384,32768,50231,1029,262144,1025,32768,1045,4194304,4235320,41003,8240,4235320,320557,16384,16400,19509,57373,17428,5,17428,4195364,4235832]

theorem envBound3774 : H12AffineFastState.Bounded env3774 := by
  intro p hp
  have h : env3774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3773_3774 : H12AffineEnvironment.transform 6 57 env3773 = env3774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3773 == env3774) = true)

theorem identity3774 : scanCanonicalize (H12AffineFastState.compose env3774 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound3774 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3775 : List Nat := [2,4,8,16,32,16,57,4,512,1024,2048,1044,8192,16384,8216,25647,1029,262144,1025,8216,1045,4194304,4194336,51,8240,4194336,279605,16384,16400,19509,16389,17428,5,17428,4195364,4194848]

theorem envBound3775 : H12AffineFastState.Bounded env3775 := by
  intro p hp
  have h : env3775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3774_3775 : H12AffineEnvironment.transform 14 8216 env3774 = env3775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env3774 == env3775) = true)

theorem identity3775 : scanCanonicalize (H12AffineFastState.compose env3775 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3775 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3776 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8200,25647,1029,262144,1025,8200,1029,4194304,4194336,35,8224,4194336,279589,16384,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound3776 : H12AffineFastState.Bounded env3776 := by
  intro p hp
  have h : env3776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3775_3776 : H12AffineEnvironment.transform 3 0 env3775 = env3776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3775 == env3776) = true)

theorem identity3776 : scanCanonicalize (H12AffineFastState.compose env3776 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 264224) := by decide +kernel

theorem selectedBound3776 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3777 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8200,25647,1029,262144,1025,8200,1029,264224,264192,35,8224,264192,279589,16384,16384,19493,16389,17412,5,17412,265220,264704]

theorem envBound3777 : H12AffineFastState.Bounded env3777 := by
  intro p hp
  have h : env3777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3776_3777 : H12AffineEnvironment.transform 21 264224 env3776 = env3777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264224 env3776 == env3777) = true)

theorem identity3777 : scanCanonicalize (H12AffineFastState.compose env3777 (packedSelected [0,6,7] rootPS)) = affineNative (2^(17+1) ^^^ 25090) := by decide +kernel

theorem selectedBound3777 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env3778 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8200,25647,1029,25090,1025,8200,1029,27170,27138,35,8224,27138,9767,16384,16384,19493,16389,17412,5,17412,28166,26626]

theorem envBound3778 : H12AffineFastState.Bounded env3778 := by
  intro p hp
  have h : env3778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3777_3778 : H12AffineEnvironment.transform 17 25090 env3777 = env3778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25090 env3777 == env3778) = true)

theorem identity3778 : scanCanonicalize (H12AffineFastState.compose env3778 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound3778 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env3779 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8,16384,0,17447,1029,16906,1025,0,1029,18986,18954,35,40,18954,1583,16384,16384,19493,16389,17412,5,17412,19982,18442]

theorem envBound3779 : H12AffineFastState.Bounded env3779 := by
  intro p hp
  have h : env3779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3778_3779 : H12AffineEnvironment.transform 12 8 env3778 = env3779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env3778 == env3779) = true)

theorem identity3779 : scanCanonicalize (H12AffineFastState.compose env3779 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3779 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env3780 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8,2081,0,3078,1029,2603,1025,0,1029,523,555,35,40,555,1583,2081,2081,1028,2084,3109,5,3109,1583,43]

theorem envBound3780 : H12AffineFastState.Bounded env3780 := by
  intro p hp
  have h : env3780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3779_3780 : H12AffineEnvironment.transform 13 2081 env3779 = env3780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env3779 == env3780) = true)

theorem identity3780 : scanCanonicalize (H12AffineFastState.compose env3780 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound3780 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3781 : List Nat := [2,4,8,0,32,0,41,4,512,1024,1583,1028,8,1550,0,553,1029,1028,1025,0,1029,523,555,35,40,555,1583,1550,1550,1028,1547,522,5,522,1583,43]

theorem envBound3781 : H12AffineFastState.Bounded env3781 := by
  intro p hp
  have h : env3781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3780_3781 : H12AffineEnvironment.transform 10 1583 env3780 = env3781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env3780 == env3781) = true)

theorem identity3781 : scanCanonicalize (H12AffineFastState.compose env3781 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound3781 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3782 : List Nat := [2,4,8,0,32,0,41,4,512,527,32,523,8,1,0,553,522,523,526,0,522,523,555,35,40,555,32,1,1,523,4,522,5,522,32,43]

theorem envBound3782 : H12AffineFastState.Bounded env3782 := by
  intro p hp
  have h : env3782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3781_3782 : H12AffineEnvironment.transform 9 527 env3781 = env3782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env3781 == env3782) = true)

theorem identity3782 : scanCanonicalize (H12AffineFastState.compose env3782 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3782 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3783 : List Nat := [2,4,8,0,10,0,3,4,512,527,10,523,8,1,0,515,522,523,526,0,522,523,513,9,2,513,10,1,1,523,4,522,5,522,10,1]

theorem envBound3783 : H12AffineFastState.Bounded env3783 := by
  intro p hp
  have h : env3783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3782_3783 : H12AffineEnvironment.transform 4 10 env3782 = env3783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3782 == env3783) = true)

def env3784 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,8388608,41003,8329,8388609,320660,16384,16812,19509,74794,12641577,257,17428,8479126,8389564]

theorem envBound3784 : H12AffineFastState.Bounded env3784 := by
  intro p hp
  have h : env3784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3730_3784 : H12AffineEnvironment.transform 5 17 env3730 = env3784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3730 == env3784) = true)

theorem identity3784 : scanCanonicalize (H12AffineFastState.compose env3784 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3784 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3785 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,444,41003,8329,445,320660,16384,16812,19509,74794,4252821,257,17428,90154,512]

theorem envBound3785 : H12AffineFastState.Bounded env3785 := by
  intro p hp
  have h : env3785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3784_3785 : H12AffineEnvironment.transform 22 444 env3784 = env3785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3784 == env3785) = true)

theorem identity3785 : scanCanonicalize (H12AffineFastState.compose env3785 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3785 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3786 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,41349,444,41003,8329,445,320660,16384,16812,19509,74794,17680,257,17428,90154,512]

theorem envBound3786 : H12AffineFastState.Bounded env3786 := by
  intro p hp
  have h : env3786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3785_3786 : H12AffineEnvironment.transform 21 41349 env3785 = env3786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3785 == env3786) = true)

theorem identity3786 : scanCanonicalize (H12AffineFastState.compose env3786 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33711) := by decide +kernel

theorem selectedBound3786 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3787 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,33711,1464,262144,1025,32768,1044,41349,444,41003,8329,445,320660,16384,16812,19509,42885,17680,257,17428,58245,512]

theorem envBound3787 : H12AffineFastState.Bounded env3787 := by
  intro p hp
  have h : env3787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3786_3787 : H12AffineEnvironment.transform 15 33711 env3786 = env3787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33711 env3786 == env3787) = true)

theorem identity3787 : scanCanonicalize (H12AffineFastState.compose env3787 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3787 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3788 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25751,1464,262144,1025,26424,1044,18109,444,18195,8329,445,263084,16384,16812,19509,16573,17680,257,17428,1213,512]

theorem envBound3788 : H12AffineFastState.Bounded env3788 := by
  intro p hp
  have h : env3788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3787_3788 : H12AffineEnvironment.transform 14 26424 env3787 = env3788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3787 == env3788) = true)

theorem identity3788 : scanCanonicalize (H12AffineFastState.compose env3788 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound3788 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3789 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25751,1464,20157,1025,26424,1044,18109,444,18195,8329,445,19729,16384,16812,19509,16573,17680,257,17428,1213,512]

theorem envBound3789 : H12AffineFastState.Bounded env3789 := by
  intro p hp
  have h : env3789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3788_3789 : H12AffineEnvironment.transform 17 20157 env3788 = env3789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env3788 == env3789) = true)

def env3790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849105,16385,16892,547952,598059,12644668,525568,545873,8479126,8914924]

theorem envBound3790 : H12AffineFastState.Bounded env3790 := by
  intro p hp
  have h : env3790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3673_3790 : H12AffineEnvironment.transform 27 16385 env3673 = env3790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3673 == env3790) = true)

def env3791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,12644668,256,20561,8479126,8389612]

theorem envBound3791 : H12AffineFastState.Bounded env3791 := by
  intro p hp
  have h : env3791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3790_3791 : H12AffineEnvironment.transform 18 1024 env3790 = env3791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3790 == env3791) = true)

theorem identity3791 : scanCanonicalize (H12AffineFastState.compose env3791 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61908) := by decide +kernel

theorem selectedBound3791 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,61908,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,8388840,256,20561,8479126,8389612]

theorem envBound3792 : H12AffineFastState.Bounded env3792 := by
  intro p hp
  have h : env3792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3791_3792 : H12AffineEnvironment.transform 21 61908 env3791 = env3792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61908 env3791 == env3792) = true)

def env3793 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61828,8388608,41003,8329,8388609,323713,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3793 : H12AffineFastState.Bounded env3793 := by
  intro p hp
  have h : env3793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3792_3793 : H12AffineEnvironment.transform 5 16 env3792 = env3793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3792 == env3793) = true)

def env3794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,262144,1024,8352,4097,20772,8388608,139,8329,8388609,282657,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3794 : H12AffineFastState.Bounded env3794 := by
  intro p hp
  have h : env3794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3793_3794 : H12AffineEnvironment.transform 14 8352 env3793 = env3794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3793 == env3794) = true)

theorem identity3794 : scanCanonicalize (H12AffineFastState.compose env3794 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96679) := by decide +kernel

theorem selectedBound3794 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96679,1024,8352,4097,20772,8388608,139,8329,8388609,76166,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3795 : H12AffineFastState.Bounded env3795 := by
  intro p hp
  have h : env3795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3794_3795 : H12AffineEnvironment.transform 17 96679 env3794 = env3795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96679 env3794 == env3795) = true)

theorem identity3795 : scanCanonicalize (H12AffineFastState.compose env3795 (packedSelected [1,3,4,9,11,13,18,20,21,23,24,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound3795 : packedSelected [1,3,4,9,11,13,18,20,21,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env3796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96679,1024,8352,4097,20772,73874,139,8329,73875,76166,16385,16812,22560,74795,73770,256,20481,16644,74542]

theorem envBound3796 : H12AffineFastState.Bounded env3796 := by
  intro p hp
  have h : env3796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3795_3796 : H12AffineEnvironment.transform 22 73874 env3795 = env3796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env3795 == env3796) = true)

theorem identity3796 : scanCanonicalize (H12AffineFastState.compose env3796 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3796 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8352,65536,4524,76047,1024,8352,4097,396,73874,139,8329,73875,76166,4265,4356,2184,74795,73770,256,169,4524,74542]

theorem envBound3797 : H12AffineFastState.Bounded env3797 := by
  intro p hp
  have h : env3797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3796_3797 : H12AffineEnvironment.transform 13 4264 env3796 = env3797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3796 == env3797) = true)

theorem identity3797 : scanCanonicalize (H12AffineFastState.compose env3797 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 11148) := by decide +kernel

theorem selectedBound3797 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3798 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8352,11148,4524,643,1024,8352,4097,396,2846,139,8329,2847,522,4265,4356,2184,4007,2982,256,169,4524,2210]

theorem envBound3798 : H12AffineFastState.Bounded env3798 := by
  intro p hp
  have h : env3798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3797_3798 : H12AffineEnvironment.transform 15 11148 env3797 = env3798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11148 env3797 == env3798) = true)

theorem identity3798 : scanCanonicalize (H12AffineFastState.compose env3798 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 5944) := by decide +kernel

theorem selectedBound3798 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env3799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5944,4264,6040,7348,4524,643,1024,6040,4097,396,2846,139,6065,2847,522,4265,4356,2184,4007,2982,256,169,4524,2210]

theorem envBound3799 : H12AffineFastState.Bounded env3799 := by
  intro p hp
  have h : env3799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3798_3799 : H12AffineEnvironment.transform 12 5944 env3798 = env3799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5944 env3798 == env3799) = true)

theorem identity3799 : scanCanonicalize (H12AffineFastState.compose env3799 (packedSelected [0,1,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3261) := by decide +kernel

theorem selectedBound3799 : packedSelected [0,1,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env3800 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3261,2949,3093,2853,9,3345,643,1024,2853,3260,396,2846,139,2828,2847,522,3092,3513,2184,4007,2982,256,169,3345,2210]

theorem envBound3800 : H12AffineFastState.Bounded env3800 := by
  intro p hp
  have h : env3800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3799_3800 : H12AffineEnvironment.transform 11 3261 env3799 = env3800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3261 env3799 == env3800) = true)

theorem identity3800 : scanCanonicalize (H12AffineFastState.compose env3800 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound3800 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env3801 : List Nat := [2,4,8,16,32,16,128,256,512,1024,798,1955,155,1803,59,9,1551,643,1024,59,1954,396,0,139,18,1,522,1802,1703,918,1209,184,256,169,1551,956]

theorem envBound3801 : H12AffineFastState.Bounded env3801 := by
  intro p hp
  have h : env3801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3800_3801 : H12AffineEnvironment.transform 10 798 env3800 = env3801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env3800 == env3801) = true)

theorem identity3801 : scanCanonicalize (H12AffineFastState.compose env3801 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3801 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3802 : List Nat := [2,4,8,0,32,0,128,256,512,1024,782,1955,139,1803,43,9,1551,643,1024,43,1954,396,0,139,2,1,522,1802,1703,902,1193,168,256,169,1551,940]

theorem envBound3802 : H12AffineFastState.Bounded env3802 := by
  intro p hp
  have h : env3802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3801_3802 : H12AffineEnvironment.transform 3 0 env3801 = env3802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3801 == env3802) = true)

theorem identity3802 : scanCanonicalize (H12AffineFastState.compose env3802 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound3802 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3803 : List Nat := [2,4,8,0,32,0,35,256,512,1024,782,1792,40,1803,43,9,1551,544,1024,43,1793,303,0,40,2,1,522,1802,1540,805,1034,11,256,10,1551,783]

theorem envBound3803 : H12AffineFastState.Bounded env3803 := by
  intro p hp
  have h : env3803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3802_3803 : H12AffineEnvironment.transform 6 35 env3802 = env3803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env3802 == env3803) = true)

theorem identity3803 : scanCanonicalize (H12AffineFastState.compose env3803 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound3803 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3804 : List Nat := [2,4,8,0,32,0,35,46,512,1024,544,1582,40,1573,43,9,1551,544,1024,43,1583,1,0,40,2,1,522,1572,1540,523,1034,11,46,10,1551,545]

theorem envBound3804 : H12AffineFastState.Bounded env3804 := by
  intro p hp
  have h : env3804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3803_3804 : H12AffineEnvironment.transform 7 46 env3803 = env3804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env3803 == env3804) = true)

theorem identity3804 : scanCanonicalize (H12AffineFastState.compose env3804 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound3804 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3805 : List Nat := [2,4,8,0,32,0,35,46,42,1024,10,1028,40,1039,43,9,1061,10,1024,43,1029,1,0,40,2,1,32,1038,1070,33,1034,11,46,10,1061,11]

theorem envBound3805 : H12AffineFastState.Bounded env3805 := by
  intro p hp
  have h : env3805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3804_3805 : H12AffineEnvironment.transform 8 42 env3804 = env3805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env3804 == env3805) = true)

theorem identity3805 : scanCanonicalize (H12AffineFastState.compose env3805 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3805 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3806 : List Nat := [2,4,2,0,32,0,35,36,32,1024,0,1028,34,1029,33,3,1061,0,1024,33,1029,1,0,34,2,1,32,1028,1060,33,1024,1,36,0,1061,1]

theorem envBound3806 : H12AffineFastState.Bounded env3806 := by
  intro p hp
  have h : env3806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3805_3806 : H12AffineEnvironment.transform 2 2 env3805 = env3806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3805 == env3806) = true)

theorem identity3806 : scanCanonicalize (H12AffineFastState.compose env3806 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3806 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3807 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1028,3,1029,0,3,1028,0,1024,0,1029,1,0,3,2,1,1,1028,1029,0,1024,1,5,0,1028,1]

theorem envBound3807 : H12AffineFastState.Bounded env3807 := by
  intro p hp
  have h : env3807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3806_3807 : H12AffineEnvironment.transform 4 1 env3806 = env3807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3806 == env3807) = true)

def leafEnv3807 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1028,3,1029,0,3,1028,0,1024,0,1029,1,0,3,1024,2,1,1,1,1028,1029,0,1024,1,5,0,4,3,1028,1,1,1029,0]

def active3807 : List Nat := [0,1,9]

def tree3807 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3807 : H12WitnessSearch.Good tree3807 := H12GlobalWitnessIndex.good

theorem leafIdentity3807 : H12AffineFastState.composeSystem env3807 rootObs = leafEnv3807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3807 rootObs == leafEnv3807) = true)

theorem terminalChecked3807 : H12PackedTerminal.terminalCheckFast leafEnv3807 active3807 tree3807 = true := by decide +kernel

def env3808 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,262144,1024,8353,4097,20773,8388608,138,8329,8388609,282656,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3808 : H12AffineFastState.Bounded env3808 := by
  intro p hp
  have h : env3808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3793_3808 : H12AffineEnvironment.transform 14 8353 env3793 = env3808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3793 == env3808) = true)

theorem identity3808 : scanCanonicalize (H12AffineFastState.compose env3808 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound3808 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3809 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96267,1024,8353,4097,20773,8388608,138,8329,8388609,75819,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3809 : H12AffineFastState.Bounded env3809 := by
  intro p hp
  have h : env3809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3808_3809 : H12AffineEnvironment.transform 17 96267 env3808 = env3809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env3808 == env3809) = true)

theorem identity3809 : scanCanonicalize (H12AffineFastState.compose env3809 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound3809 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env3810 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96267,1024,8353,4097,20773,73875,138,8329,73874,75819,16385,16812,22560,74795,73771,256,20481,16645,74543]

theorem envBound3810 : H12AffineFastState.Bounded env3810 := by
  intro p hp
  have h : env3810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3809_3810 : H12AffineEnvironment.transform 22 73875 env3809 = env3810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env3809 == env3810) = true)

theorem identity3810 : scanCanonicalize (H12AffineFastState.compose env3810 (packedSelected [1,5,6,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound3810 : packedSelected [1,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3811 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,16384,8353,65536,2454,90161,1024,8353,2107,18719,73875,138,8329,73874,75819,16385,16812,16410,74795,73771,256,18491,16645,74543]

theorem envBound3811 : H12AffineFastState.Bounded env3811 := by
  intro p hp
  have h : env3811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3810_3811 : H12AffineEnvironment.transform 11 2106 env3810 = env3811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env3810 == env3811) = true)

theorem identity3811 : scanCanonicalize (H12AffineFastState.compose env3811 (packedSelected [2,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 27068) := by decide +kernel

theorem selectedBound3811 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env3812 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,16384,8353,27068,2454,2445,1024,8353,2107,18719,18735,138,8329,18734,16791,16385,16812,16410,19863,18839,256,18491,16645,19091]

theorem envBound3812 : H12AffineFastState.Bounded env3812 := by
  intro p hp
  have h : env3812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3811_3812 : H12AffineEnvironment.transform 15 27068 env3811 = env3812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 27068 env3811 == env3812) = true)

theorem identity3812 : scanCanonicalize (H12AffineFastState.compose env3812 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3812 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env3813 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,1693,8353,12065,2454,2445,1024,8353,2107,3970,4018,138,8329,4019,1802,1692,1841,1671,2826,3850,256,3750,1944,3086]

theorem envBound3813 : H12AffineFastState.Bounded env3813 := by
  intro p hp
  have h : env3813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3812_3813 : H12AffineEnvironment.transform 13 1693 env3812 = env3813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env3812 == env3813) = true)

theorem identity3813 : scanCanonicalize (H12AffineFastState.compose env3813 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3813 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env3814 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,2106,8192,1693,8353,11813,2194,2185,1024,8353,2107,3718,3766,138,8329,3767,1550,1692,1589,1671,2574,3598,4,3750,1692,3086]

theorem envBound3814 : H12AffineFastState.Bounded env3814 := by
  intro p hp
  have h : env3814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3813_3814 : H12AffineEnvironment.transform 7 4 env3813 = env3814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3813 == env3814) = true)

theorem identity3814 : scanCanonicalize (H12AffineFastState.compose env3814 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound3814 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3815 : List Nat := [2,4,8,16,32,16,51,4,512,1024,2048,2106,8192,1582,8210,11813,2081,2106,1024,8210,2107,3637,3589,57,8250,3588,1550,1583,1589,1588,2574,3598,4,3605,1583,3086]

theorem envBound3815 : H12AffineFastState.Bounded env3815 := by
  intro p hp
  have h : env3815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3814_3815 : H12AffineEnvironment.transform 6 51 env3814 = env3815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env3814 == env3815) = true)

theorem identity3815 : scanCanonicalize (H12AffineFastState.compose env3815 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound3815 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3816 : List Nat := [2,4,8,16,32,16,51,4,512,1024,2048,2106,2601,1582,2619,1036,2081,2106,1024,2619,2107,3637,3589,57,2579,3588,1550,1583,1589,1588,2574,3598,4,3605,1583,3086]

theorem envBound3816 : H12AffineFastState.Bounded env3816 := by
  intro p hp
  have h : env3816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3815_3816 : H12AffineEnvironment.transform 12 2601 env3815 = env3816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env3815 == env3816) = true)

theorem identity3816 : scanCanonicalize (H12AffineFastState.compose env3816 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3816 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env3817 : List Nat := [2,4,8,11,32,11,40,4,512,1024,2048,2081,2601,1582,2592,1036,2081,2081,1024,2592,2080,3630,3589,34,2568,3588,1550,1583,1582,1583,2574,3598,4,3598,1583,3086]

theorem envBound3817 : H12AffineFastState.Bounded env3817 := by
  intro p hp
  have h : env3817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3816_3817 : H12AffineEnvironment.transform 3 11 env3816 = env3817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3816 == env3817) = true)

theorem identity3817 : scanCanonicalize (H12AffineFastState.compose env3817 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3817 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3818 : List Nat := [2,4,8,11,32,11,40,4,0,1024,2048,2081,2089,1070,2080,1036,2081,2081,1024,2080,2080,3118,3077,34,2056,3076,1038,1071,1070,1071,2062,3086,4,3086,1071,3086]

theorem envBound3818 : H12AffineFastState.Bounded env3818 := by
  intro p hp
  have h : env3818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3817_3818 : H12AffineEnvironment.transform 8 0 env3817 = env3818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3817 == env3818) = true)

theorem identity3818 : scanCanonicalize (H12AffineFastState.compose env3818 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound3818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3819 : List Nat := [2,4,8,11,32,11,40,4,0,1024,33,0,8,1070,1,1036,0,0,1024,1,1,1039,1060,34,41,1061,1038,1071,1070,1071,47,1071,4,1071,1071,1071]

theorem envBound3819 : H12AffineFastState.Bounded env3819 := by
  intro p hp
  have h : env3819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3818_3819 : H12AffineEnvironment.transform 10 33 env3818 = env3819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env3818 == env3819) = true)

def env3820 : List Nat := [2,4,8,11,32,11,40,4,0,32,33,0,8,14,1,44,0,0,32,1,1,47,4,34,41,5,46,15,14,15,47,15,4,15,15,15]

theorem envBound3820 : H12AffineFastState.Bounded env3820 := by
  intro p hp
  have h : env3820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3819_3820 : H12AffineEnvironment.transform 9 32 env3819 = env3820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3819 == env3820) = true)

def env3821 : List Nat := [2,0,8,11,32,11,40,0,0,32,33,0,8,10,1,40,0,0,32,1,1,43,0,34,41,1,42,11,10,11,43,11,0,11,11,11]

theorem envBound3821 : H12AffineFastState.Bounded env3821 := by
  intro p hp
  have h : env3821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3820_3821 : H12AffineEnvironment.transform 1 0 env3820 = env3821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3820 == env3821) = true)

def env3822 : List Nat := [2,1,8,11,32,11,40,1,0,32,33,0,8,11,1,41,0,0,32,1,1,42,1,34,41,0,43,10,11,10,42,10,1,10,10,10]

theorem envBound3822 : H12AffineFastState.Bounded env3822 := by
  intro p hp
  have h : env3822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3820_3822 : H12AffineEnvironment.transform 1 1 env3820 = env3822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3820 == env3822) = true)

theorem identity3822 : scanCanonicalize (H12AffineFastState.compose env3822 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3822 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3823 : List Nat := [2,1,3,0,32,0,35,1,0,32,33,0,3,0,1,34,0,0,32,1,1,33,1,34,34,0,32,1,0,1,33,1,1,1,1,1]

theorem envBound3823 : H12AffineFastState.Bounded env3823 := by
  intro p hp
  have h : env3823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3822_3823 : H12AffineEnvironment.transform 2 3 env3822 = env3823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3822 == env3823) = true)

def leafEnv3823 : List Nat := [2,1,3,0,32,0,35,1,0,32,33,0,3,0,1,34,0,0,32,1,1,33,1,34,33,34,1,0,32,1,0,1,33,1,1,1,1,3,1,1,1,0,0]

def active3823 : List Nat := [0,4]

def tree3823 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3823 : H12WitnessSearch.Good tree3823 := H12GlobalWitnessIndex.good

theorem leafIdentity3823 : H12AffineFastState.composeSystem env3823 rootObs = leafEnv3823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3823 rootObs == leafEnv3823) = true)

theorem terminalChecked3823 : H12PackedTerminal.terminalCheckFast leafEnv3823 active3823 tree3823 = true := by decide +kernel

def env3824 : List Nat := [2,4,8,11,32,11,40,4,0,33,33,0,8,15,1,45,0,0,33,1,1,46,5,34,41,4,47,14,15,14,47,14,4,14,14,14]

theorem envBound3824 : H12AffineFastState.Bounded env3824 := by
  intro p hp
  have h : env3824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3819_3824 : H12AffineEnvironment.transform 9 33 env3819 = env3824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env3819 == env3824) = true)

theorem identity3824 : scanCanonicalize (H12AffineFastState.compose env3824 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound3824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3825 : List Nat := [2,4,6,5,32,5,38,4,0,33,33,0,6,1,1,35,0,0,33,1,1,32,5,34,39,4,33,0,1,0,33,0,4,0,0,0]

theorem envBound3825 : H12AffineFastState.Bounded env3825 := by
  intro p hp
  have h : env3825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3824_3825 : H12AffineEnvironment.transform 2 6 env3824 = env3825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env3824 == env3825) = true)

def env3826 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61829,8388608,41003,8329,8388608,323712,16385,16813,22561,74795,8388793,256,20480,8479126,8389565]

theorem envBound3826 : H12AffineFastState.Bounded env3826 := by
  intro p hp
  have h : env3826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3792_3826 : H12AffineEnvironment.transform 5 17 env3792 = env3826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3792 == env3826) = true)

theorem identity3826 : scanCanonicalize (H12AffineFastState.compose env3826 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3826 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3827 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61829,445,41003,8329,445,323712,16385,16813,22561,74795,260,256,20480,90155,512]

theorem envBound3827 : H12AffineFastState.Bounded env3827 := by
  intro p hp
  have h : env3827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3826_3827 : H12AffineEnvironment.transform 22 445 env3826 = env3827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3826 == env3827) = true)

theorem identity3827 : scanCanonicalize (H12AffineFastState.compose env3827 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound3827 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3828 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1024,32768,4097,41349,445,41003,8329,445,303232,4097,4525,2081,74795,260,256,0,77867,512]

theorem envBound3828 : H12AffineFastState.Bounded env3828 := by
  intro p hp
  have h : env3828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3827_3828 : H12AffineEnvironment.transform 13 4096 env3827 = env3828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3827 == env3828) = true)

theorem identity3828 : scanCanonicalize (H12AffineFastState.compose env3828 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3828 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3829 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,38842,4525,262144,1024,32768,4097,41349,445,41003,8329,445,303232,4097,4525,2081,45969,260,256,0,42897,512]

theorem envBound3829 : H12AffineFastState.Bounded env3829 := by
  intro p hp
  have h : env3829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3828_3829 : H12AffineEnvironment.transform 15 38842 env3828 = env3829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3828 == env3829) = true)

theorem identity3829 : scanCanonicalize (H12AffineFastState.compose env3829 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3829 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,262144,1024,14137,4097,5820,445,5906,8329,445,268217,4097,4525,2081,1192,260,256,0,4264,512]

theorem envBound3830 : H12AffineFastState.Bounded env3830 := by
  intro p hp
  have h : env3830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3829_3830 : H12AffineEnvironment.transform 14 14137 env3829 = env3830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3829 == env3830) = true)

theorem identity3830 : scanCanonicalize (H12AffineFastState.compose env3830 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound3830 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3831 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,2184,1024,14137,4097,5820,445,5906,8329,445,7985,4097,4525,2081,1192,260,256,0,4264,512]

theorem envBound3831 : H12AffineFastState.Bounded env3831 := by
  intro p hp
  have h : env3831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3830_3831 : H12AffineEnvironment.transform 17 2184 env3830 = env3831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3830 == env3831) = true)

theorem identity3831 : scanCanonicalize (H12AffineFastState.compose env3831 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3831 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env3832 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,13972,8323,4096,2184,1024,13972,4097,5820,16,5823,8329,16,7836,4097,4096,2081,1192,169,173,0,4264,512]

theorem envBound3832 : H12AffineFastState.Bounded env3832 := by
  intro p hp
  have h : env3832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3831_3832 : H12AffineEnvironment.transform 7 173 env3831 = env3832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3831 == env3832) = true)

theorem identity3832 : scanCanonicalize (H12AffineFastState.compose env3832 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound3832 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3833 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,4096,8192,4096,13972,8323,4096,642,1024,13972,4097,5820,16,5823,8329,16,5270,4097,4096,555,1192,169,173,0,4264,512]

theorem envBound3833 : H12AffineFastState.Bounded env3833 := by
  intro p hp
  have h : env3833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3832_3833 : H12AffineEnvironment.transform 10 522 env3832 = env3833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env3832 == env3833) = true)

theorem identity3833 : scanCanonicalize (H12AffineFastState.compose env3833 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3833 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3834 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,1692,8192,1692,8200,8323,1692,642,1024,8200,1693,32,16,35,8329,16,522,1693,1692,555,1192,169,173,0,1588,512]

theorem envBound3834 : H12AffineFastState.Bounded env3834 := by
  intro p hp
  have h : env3834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3833_3834 : H12AffineEnvironment.transform 11 1692 env3833 = env3834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env3833 == env3834) = true)

theorem identity3834 : scanCanonicalize (H12AffineFastState.compose env3834 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 170) := by decide +kernel

theorem selectedBound3834 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3835 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,1692,170,1692,162,41,1692,642,1024,162,1693,32,16,35,35,16,522,1693,1692,555,1192,169,173,0,1588,512]

theorem envBound3835 : H12AffineFastState.Bounded env3835 := by
  intro p hp
  have h : env3835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3834_3835 : H12AffineEnvironment.transform 12 170 env3834 = env3835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 170 env3834 == env3835) = true)

theorem identity3835 : scanCanonicalize (H12AffineFastState.compose env3835 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound3835 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3836 : List Nat := [2,4,8,16,32,17,3,46,512,1024,522,1567,41,1567,33,41,1567,513,1024,33,1566,32,16,35,35,16,522,1566,1567,555,1067,42,46,0,1588,512]

theorem envBound3836 : H12AffineFastState.Bounded env3836 := by
  intro p hp
  have h : env3836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3835_3836 : H12AffineEnvironment.transform 6 3 env3835 = env3836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env3835 == env3836) = true)

theorem identity3836 : scanCanonicalize (H12AffineFastState.compose env3836 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3836 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3837 : List Nat := [2,4,8,16,1,17,3,15,512,1024,522,1567,8,1567,0,8,1567,513,1024,0,1566,1,16,2,2,16,522,1566,1567,522,1034,11,15,0,1557,512]

theorem envBound3837 : H12AffineFastState.Bounded env3837 := by
  intro p hp
  have h : env3837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3836_3837 : H12AffineEnvironment.transform 4 1 env3836 = env3837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3836 == env3837) = true)

theorem identity3837 : scanCanonicalize (H12AffineFastState.compose env3837 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3838 : List Nat := [2,4,8,16,1,17,3,15,1,1024,11,1054,8,1054,0,8,1054,0,1024,0,1055,1,16,2,2,16,11,1055,1054,11,1034,11,15,0,1044,1]

theorem envBound3838 : H12AffineFastState.Bounded env3838 := by
  intro p hp
  have h : env3838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3837_3838 : H12AffineEnvironment.transform 8 1 env3837 = env3838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3837 == env3838) = true)

theorem identity3838 : scanCanonicalize (H12AffineFastState.compose env3838 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3838 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3839 : List Nat := [2,4,8,1,1,0,3,15,1,1024,11,1039,8,1039,0,8,1039,0,1024,0,1038,1,1,2,2,1,11,1038,1039,11,1034,11,15,0,1029,1]

theorem envBound3839 : H12AffineFastState.Bounded env3839 := by
  intro p hp
  have h : env3839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3838_3839 : H12AffineEnvironment.transform 3 1 env3838 = env3839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3838 == env3839) = true)

theorem identity3839 : scanCanonicalize (H12AffineFastState.compose env3839 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3839 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3840 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,2,1029,0,2,1029,0,1024,0,1028,1,1,2,2,1,1,1028,1029,1,1024,1,5,0,1029,1]

theorem envBound3840 : H12AffineFastState.Bounded env3840 := by
  intro p hp
  have h : env3840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3839_3840 : H12AffineEnvironment.transform 2 2 env3839 = env3840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3839 == env3840) = true)

def leafEnv3840 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,2,1029,0,2,1029,0,1024,0,1028,1,1,2,1024,2,1,1,1,1028,1029,1,1024,1,5,0,4,3,1029,1,1,1029,0]

def active3840 : List Nat := [0,1,9]

def tree3840 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3840 : H12WitnessSearch.Good tree3840 := H12GlobalWitnessIndex.good

theorem leafIdentity3840 : H12AffineFastState.composeSystem env3840 rootObs = leafEnv3840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3840 rootObs == leafEnv3840) = true)

theorem terminalChecked3840 : H12PackedTerminal.terminalCheckFast leafEnv3840 active3840 tree3840 = true := by decide +kernel

def env3841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,12644668,257,20560,8479126,8389613]

theorem envBound3841 : H12AffineFastState.Bounded env3841 := by
  intro p hp
  have h : env3841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3790_3841 : H12AffineEnvironment.transform 18 1025 env3790 = env3841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3790 == env3841) = true)

theorem identity3841 : scanCanonicalize (H12AffineFastState.compose env3841 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240597) := by decide +kernel

theorem selectedBound3841 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,4240597,41003,8329,4240517,323792,16385,16892,22641,74794,17897,257,20560,4314435,4241208]

theorem envBound3842 : H12AffineFastState.Bounded env3842 := by
  intro p hp
  have h : env3842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3841_3842 : H12AffineEnvironment.transform 22 4240597 env3841 = env3842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240597 env3841 == env3842) = true)

def env3843 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4240517,41003,8329,4240517,323712,16385,16812,22561,74794,17849,257,20480,4314387,4241208]

theorem envBound3843 : H12AffineFastState.Bounded env3843 := by
  intro p hp
  have h : env3843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3842_3843 : H12AffineEnvironment.transform 5 16 env3842 = env3843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3842 == env3843) = true)

theorem identity3843 : scanCanonicalize (H12AffineFastState.compose env3843 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 46392) := by decide +kernel

theorem selectedBound3843 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3844 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46392,445,41003,8329,445,323712,16385,16812,22561,74794,17849,257,20480,90155,512]

theorem envBound3844 : H12AffineFastState.Bounded env3844 := by
  intro p hp
  have h : env3844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3843_3844 : H12AffineEnvironment.transform 21 46392 env3843 = env3844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env3843 == env3844) = true)

theorem identity3844 : scanCanonicalize (H12AffineFastState.compose env3844 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3844 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1025,32768,1213,41348,445,41003,8329,445,320572,16385,16812,19613,74794,17849,257,17596,90155,512]

theorem envBound3845 : H12AffineFastState.Bounded env3845 := by
  intro p hp
  have h : env3845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3844_3845 : H12AffineEnvironment.transform 11 1212 env3844 = env3845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3844 == env3845) = true)

theorem identity3845 : scanCanonicalize (H12AffineFastState.compose env3845 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound3845 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3846 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33542,1296,262144,1025,32768,1213,41348,445,41003,8329,445,320572,16385,16812,19613,42796,17849,257,17596,58157,512]

theorem envBound3846 : H12AffineFastState.Bounded env3846 := by
  intro p hp
  have h : env3846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3845_3846 : H12AffineEnvironment.transform 15 33542 env3845 = env3846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env3845 == env3846) = true)

theorem identity3846 : scanCanonicalize (H12AffineFastState.compose env3846 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3846 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3847 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25663,1296,262144,1025,26425,1213,18109,445,18194,8329,445,262917,16385,16812,19613,16405,17849,257,17596,1044,512]

theorem envBound3847 : H12AffineFastState.Bounded env3847 := by
  intro p hp
  have h : env3847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3846_3847 : H12AffineEnvironment.transform 14 26425 env3846 = env3847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3846 == env3847) = true)

theorem identity3847 : scanCanonicalize (H12AffineFastState.compose env3847 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3847 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3848 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,1693,8612,8866,1296,262144,1025,8612,1213,32,445,399,8329,445,262917,1692,1841,2560,1672,804,257,545,1044,512]

theorem envBound3848 : H12AffineFastState.Bounded env3848 := by
  intro p hp
  have h : env3848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3847_3848 : H12AffineEnvironment.transform 13 1693 env3847 = env3848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env3847 == env3848) = true)

theorem identity3848 : scanCanonicalize (H12AffineFastState.compose env3848 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3848 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3849 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1045,8192,1588,8461,8715,1296,262144,1025,8461,1044,32,276,294,8224,276,262917,1589,1841,2560,1569,804,257,545,1044,512]

theorem envBound3849 : H12AffineFastState.Bounded env3849 := by
  intro p hp
  have h : env3849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3848_3849 : H12AffineEnvironment.transform 6 41 env3848 = env3849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3848 == env3849) = true)

theorem identity3849 : scanCanonicalize (H12AffineFastState.compose env3849 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 9497) := by decide +kernel

theorem selectedBound3849 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3850 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1045,8192,1588,8461,8715,1296,9497,1025,8461,1044,32,276,294,8224,276,9756,1589,1841,2560,1569,804,257,545,1044,512]

theorem envBound3850 : H12AffineFastState.Bounded env3850 := by
  intro p hp
  have h : env3850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3849_3850 : H12AffineEnvironment.transform 17 9497 env3849 = env3850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9497 env3849 == env3850) = true)

theorem identity3850 : scanCanonicalize (H12AffineFastState.compose env3850 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3850 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3851 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,1588,8201,8715,1044,9245,1025,8201,1044,32,16,34,8224,16,9756,1589,1589,2560,1569,544,5,545,1044,512]

theorem envBound3851 : H12AffineFastState.Bounded env3851 := by
  intro p hp
  have h : env3851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3850_3851 : H12AffineEnvironment.transform 7 4 env3850 = env3851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3850 == env3851) = true)

theorem identity3851 : scanCanonicalize (H12AffineFastState.compose env3851 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound3851 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3852 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1583,1045,8192,1588,8201,8715,1044,9245,1025,8201,1044,32,16,34,8224,16,9756,1589,1589,1071,1569,544,5,545,1044,512]

theorem envBound3852 : H12AffineFastState.Bounded env3852 := by
  intro p hp
  have h : env3852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3851_3852 : H12AffineEnvironment.transform 10 1583 env3851 = env3852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env3851 == env3852) = true)

theorem identity3852 : scanCanonicalize (H12AffineFastState.compose env3852 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound3852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3853 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1583,1045,562,1588,571,57,1044,1583,1025,571,1044,32,16,34,530,16,1070,1589,1589,1071,1569,544,5,545,1044,512]

theorem envBound3853 : H12AffineFastState.Bounded env3853 := by
  intro p hp
  have h : env3853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3852_3853 : H12AffineEnvironment.transform 12 562 env3852 = env3853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env3852 == env3853) = true)

theorem identity3853 : scanCanonicalize (H12AffineFastState.compose env3853 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound3853 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3854 : List Nat := [2,4,8,16,32,16,41,4,512,565,26,544,562,1,571,57,545,26,564,571,545,32,16,34,530,16,539,0,0,538,20,544,5,545,545,512]

theorem envBound3854 : H12AffineFastState.Bounded env3854 := by
  intro p hp
  have h : env3854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3853_3854 : H12AffineEnvironment.transform 9 565 env3853 = env3854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env3853 == env3854) = true)

theorem identity3854 : scanCanonicalize (H12AffineFastState.compose env3854 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound3854 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3855 : List Nat := [2,4,8,16,32,16,41,4,27,46,26,59,41,1,32,57,58,26,47,32,58,32,16,34,9,16,0,0,0,1,20,59,5,58,58,27]

theorem envBound3855 : H12AffineFastState.Bounded env3855 := by
  intro p hp
  have h : env3855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3854_3855 : H12AffineEnvironment.transform 8 27 env3854 = env3855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env3854 == env3855) = true)

theorem identity3855 : scanCanonicalize (H12AffineFastState.compose env3855 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3855 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3856 : List Nat := [2,4,8,10,32,10,41,4,1,46,0,33,41,1,32,35,32,0,47,32,32,32,10,34,9,10,0,0,0,1,14,33,5,32,32,1]

theorem envBound3856 : H12AffineFastState.Bounded env3856 := by
  intro p hp
  have h : env3856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3855_3856 : H12AffineEnvironment.transform 3 10 env3855 = env3856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3855 == env3856) = true)

theorem identity3856 : scanCanonicalize (H12AffineFastState.compose env3856 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3857 : List Nat := [2,4,8,10,1,10,8,4,1,15,0,0,8,1,1,2,1,0,14,1,1,1,10,3,9,10,0,0,0,1,14,0,5,1,1,1]

theorem envBound3857 : H12AffineFastState.Bounded env3857 := by
  intro p hp
  have h : env3857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3856_3857 : H12AffineEnvironment.transform 4 1 env3856 = env3857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3856 == env3857) = true)

def env3858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16813,22560,74794,17848,257,20481,4314386,4241208]

theorem envBound3858 : H12AffineFastState.Bounded env3858 := by
  intro p hp
  have h : env3858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3842_3858 : H12AffineEnvironment.transform 5 17 env3842 = env3858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3842 == env3858) = true)

def env3859 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16401,22560,74794,17412,189,20481,4314286,4241028]

theorem envBound3859 : H12AffineFastState.Bounded env3859 := by
  intro p hp
  have h : env3859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3858_3859 : H12AffineEnvironment.transform 7 188 env3858 = env3859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3858 == env3859) = true)

theorem identity3859 : scanCanonicalize (H12AffineFastState.compose env3859 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13492) := by decide +kernel

theorem selectedBound3859 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3860 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,13492,65536,4113,262144,1025,13492,4097,4194304,4194352,5279,8329,4194353,279605,16385,16401,22560,74794,17412,189,20481,4284442,4194864]

theorem envBound3860 : H12AffineFastState.Bounded env3860 := by
  intro p hp
  have h : env3860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3859_3860 : H12AffineEnvironment.transform 14 13492 env3859 = env3860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13492 env3859 == env3860) = true)

def env3861 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,65536,4097,262144,1025,13476,4097,4194304,4194336,5263,8329,4194337,279589,16385,16385,22560,74794,17412,173,20481,4284426,4194848]

theorem envBound3861 : H12AffineFastState.Bounded env3861 := by
  intro p hp
  have h : env3861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3860_3861 : H12AffineEnvironment.transform 3 0 env3860 = env3861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3860 == env3861) = true)

theorem identity3861 : scanCanonicalize (H12AffineFastState.compose env3861 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3861 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3862 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13324,65536,4097,262144,1025,13324,4097,4194304,4194336,5159,8225,4194337,279589,16385,16385,22560,74794,17412,5,20481,4284426,4194848]

theorem envBound3862 : H12AffineFastState.Bounded env3862 := by
  intro p hp
  have h : env3862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3861_3862 : H12AffineEnvironment.transform 6 40 env3861 = env3862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3861 == env3862) = true)

theorem identity3862 : scanCanonicalize (H12AffineFastState.compose env3862 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound3862 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3863 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13324,25647,4097,262144,1025,13324,4097,4194304,4194336,5159,8225,4194337,279589,16385,16385,22560,16389,17412,5,20481,4195365,4194848]

theorem envBound3863 : H12AffineFastState.Bounded env3863 := by
  intro p hp
  have h : env3863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3862_3863 : H12AffineEnvironment.transform 15 25647 env3862 = env3863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env3862 == env3863) = true)

theorem identity3863 : scanCanonicalize (H12AffineFastState.compose env3863 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22528) := by decide +kernel

theorem selectedBound3863 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3864 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13324,25647,4097,22528,1025,13324,4097,4194304,4194336,5159,8225,4194337,7205,16385,16385,22560,16389,17412,5,20481,4195365,4194848]

theorem envBound3864 : H12AffineFastState.Bounded env3864 := by
  intro p hp
  have h : env3864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3863_3864 : H12AffineEnvironment.transform 17 22528 env3863 = env3864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22528 env3863 == env3864) = true)

theorem identity3864 : scanCanonicalize (H12AffineFastState.compose env3864 (packedSelected [0,1,3,4,6,7,9,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 3630) := by decide +kernel

theorem selectedBound3864 : packedSelected [0,1,3,4,6,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env3865 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13324,25647,4097,22528,1025,13324,4097,3630,3598,5159,8225,3599,7205,16385,16385,22560,16389,17412,5,20481,2571,3086]

theorem envBound3865 : H12AffineFastState.Bounded env3865 := by
  intro p hp
  have h : env3865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3864_3865 : H12AffineEnvironment.transform 21 3630 env3864 = env3865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3630 env3864 == env3865) = true)

theorem identity3865 : scanCanonicalize (H12AffineFastState.compose env3865 (packedSelected [1,3,4,5,8,9,12,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 2570) := by decide +kernel

theorem selectedBound3865 : packedSelected [1,3,4,5,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env3866 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,2570,8192,16384,11782,25647,2571,16906,1025,11782,2571,3630,3598,3629,8225,3599,1583,16385,16385,16938,16389,17412,5,18955,2571,3086]

theorem envBound3866 : H12AffineFastState.Bounded env3866 := by
  intro p hp
  have h : env3866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3865_3866 : H12AffineEnvironment.transform 11 2570 env3865 = env3866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2570 env3865 == env3866) = true)

theorem identity3866 : scanCanonicalize (H12AffineFastState.compose env3866 (packedSelected [5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3866 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3867 : List Nat := [2,4,8,0,32,1,40,4,1,1024,2048,2059,8192,16384,11271,25647,2058,16395,1025,11271,2058,3119,3087,3116,8225,3086,1070,16385,16385,16427,16389,17412,5,18442,2058,3086]

theorem envBound3867 : H12AffineFastState.Bounded env3867 := by
  intro p hp
  have h : env3867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3866_3867 : H12AffineEnvironment.transform 8 1 env3866 = env3867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3866 == env3867) = true)

theorem identity3867 : scanCanonicalize (H12AffineFastState.compose env3867 (packedSelected [0,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10275) := by decide +kernel

theorem selectedBound3867 : packedSelected [0,7,9,11] rootPS < 2^1333 := by decide +kernel

def env3868 : List Nat := [2,4,8,0,32,1,40,4,1,1024,2048,2059,8192,10275,11271,3084,2058,10280,1025,11271,2058,3119,3087,3116,8225,3086,1070,10274,10274,10248,10278,11303,5,8233,2058,3086]

theorem envBound3868 : H12AffineFastState.Bounded env3868 := by
  intro p hp
  have h : env3868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3867_3868 : H12AffineEnvironment.transform 13 10275 env3867 = env3868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10275 env3867 == env3868) = true)

theorem identity3868 : scanCanonicalize (H12AffineFastState.compose env3868 (packedSelected [1,2,5,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3868 : packedSelected [1,2,5,6,12] rootPS < 2^1333 := by decide +kernel

def env3869 : List Nat := [2,4,8,0,32,1,40,4,1,1024,1039,1028,8192,9260,8200,3,1029,9255,1025,8200,1029,32,0,35,8225,1,1070,9261,9261,9223,9257,8232,5,8233,1029,1]

theorem envBound3869 : H12AffineFastState.Bounded env3869 := by
  intro p hp
  have h : env3869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3868_3869 : H12AffineEnvironment.transform 10 1039 env3868 = env3869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env3868 == env3869) = true)

theorem identity3869 : scanCanonicalize (H12AffineFastState.compose env3869 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound3869 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3870 : List Nat := [2,4,8,0,32,1,40,4,1,1024,1039,1028,1063,11,1071,3,1029,0,1025,1071,1029,32,0,35,1030,1,1070,10,10,32,14,1039,5,1038,1029,1]

theorem envBound3870 : H12AffineFastState.Bounded env3870 := by
  intro p hp
  have h : env3870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3869_3870 : H12AffineEnvironment.transform 12 1063 env3869 = env3870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env3869 == env3870) = true)

def env3871 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13477,65536,4096,262144,1025,13477,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,74794,17412,172,20481,4284427,4194849]

theorem envBound3871 : H12AffineFastState.Bounded env3871 := by
  intro p hp
  have h : env3871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3860_3871 : H12AffineEnvironment.transform 3 1 env3860 = env3871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3860 == env3871) = true)

theorem identity3871 : scanCanonicalize (H12AffineFastState.compose env3871 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3871 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3872 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13477,28802,4096,262144,1025,13477,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,21672,17412,172,20481,4198537,4194849]

theorem envBound3872 : H12AffineFastState.Bounded env3872 := by
  intro p hp
  have h : env3872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3871_3872 : H12AffineEnvironment.transform 15 28802 env3871 = env3872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3871 == env3872) = true)

theorem identity3872 : scanCanonicalize (H12AffineFastState.compose env3872 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 5261) := by decide +kernel

theorem selectedBound3872 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3873 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13477,28802,4096,262144,1025,13477,4097,5261,5292,5262,8329,5293,279588,16385,16384,22560,21672,17412,172,20481,1028,5804]

theorem envBound3873 : H12AffineFastState.Bounded env3873 := by
  intro p hp
  have h : env3873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3872_3873 : H12AffineEnvironment.transform 21 5261 env3872 = env3873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5261 env3872 == env3873) = true)

theorem identity3873 : scanCanonicalize (H12AffineFastState.compose env3873 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound3873 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3874 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1676,8192,16384,8745,26126,1676,262144,1025,8745,1677,513,544,514,8329,545,279588,16385,16384,20140,16932,17412,172,18061,1028,32]

theorem envBound3874 : H12AffineFastState.Bounded env3874 := by
  intro p hp
  have h : env3874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3873_3874 : H12AffineEnvironment.transform 11 1676 env3873 = env3874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env3873 == env3874) = true)

theorem identity3874 : scanCanonicalize (H12AffineFastState.compose env3874 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound3874 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env3875 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1197,8192,16384,8200,25647,1197,262144,1025,8200,1196,32,1,35,8329,0,279588,16385,16384,19597,16389,17412,172,17580,1028,32]

theorem envBound3875 : H12AffineFastState.Bounded env3875 := by
  intro p hp
  have h : env3875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3874_3875 : H12AffineEnvironment.transform 8 33 env3874 = env3875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3874 == env3875) = true)

theorem identity3875 : scanCanonicalize (H12AffineFastState.compose env3875 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound3875 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3876 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1197,8192,16384,8200,25647,1197,16394,1025,8200,1196,32,1,35,8329,0,1070,16385,16384,19597,16389,17412,172,17580,1028,32]

theorem envBound3876 : H12AffineFastState.Bounded env3876 := by
  intro p hp
  have h : env3876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3875_3876 : H12AffineEnvironment.transform 17 16394 env3875 = env3876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env3875 == env3876) = true)

theorem identity3876 : scanCanonicalize (H12AffineFastState.compose env3876 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3876 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env3877 : List Nat := [2,4,8,1,32,0,40,5,33,1024,2048,1029,8192,16384,8200,25647,1029,16394,1025,8200,1028,32,1,35,8225,0,1070,16385,16384,19493,16389,17412,4,17412,1028,32]

theorem envBound3877 : H12AffineFastState.Bounded env3877 := by
  intro p hp
  have h : env3877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3876_3877 : H12AffineEnvironment.transform 6 40 env3876 = env3877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3876 == env3877) = true)

theorem identity3877 : scanCanonicalize (H12AffineFastState.compose env3877 (packedSelected [5] rootPS)) = affineNative (2^(13+1) ^^^ 10285) := by decide +kernel

theorem selectedBound3877 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3878 : List Nat := [2,4,8,1,32,0,40,5,33,1024,2048,1029,8192,10285,8200,3074,1029,10279,1025,8200,1028,32,1,35,8225,0,1070,10284,10285,9224,10280,11305,4,11305,1028,32]

theorem envBound3878 : H12AffineFastState.Bounded env3878 := by
  intro p hp
  have h : env3878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3877_3878 : H12AffineEnvironment.transform 13 10285 env3877 = env3878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10285 env3877 == env3878) = true)

theorem identity3878 : scanCanonicalize (H12AffineFastState.compose env3878 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3878 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3879 : List Nat := [2,4,8,1,32,0,40,5,33,1024,1039,1029,8192,9250,8200,13,1029,9256,1025,8200,1028,32,1,35,8225,0,1070,9251,9250,9224,9255,8230,4,8230,1028,32]

theorem envBound3879 : H12AffineFastState.Bounded env3879 := by
  intro p hp
  have h : env3879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3878_3879 : H12AffineEnvironment.transform 10 1039 env3878 = env3879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env3878 == env3879) = true)

theorem identity3879 : scanCanonicalize (H12AffineFastState.compose env3879 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound3879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3880 : List Nat := [2,4,8,1,32,0,40,5,33,1024,1039,1029,1063,5,1071,13,1029,15,1025,1071,1028,32,1,35,1030,0,1070,4,5,47,0,1025,4,1025,1028,32]

theorem envBound3880 : H12AffineFastState.Bounded env3880 := by
  intro p hp
  have h : env3880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3879_3880 : H12AffineEnvironment.transform 12 1063 env3879 = env3880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env3879 == env3880) = true)

theorem identity3880 : scanCanonicalize (H12AffineFastState.compose env3880 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3881 : List Nat := [2,4,8,1,32,0,40,5,33,46,33,43,9,5,1,13,43,15,47,1,42,32,1,35,40,0,0,4,5,47,0,47,4,47,42,32]

theorem envBound3881 : H12AffineFastState.Bounded env3881 := by
  intro p hp
  have h : env3881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3880_3881 : H12AffineEnvironment.transform 9 46 env3880 = env3881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3880 == env3881) = true)

theorem identity3881 : scanCanonicalize (H12AffineFastState.compose env3881 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3881 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3882 : List Nat := [2,4,8,1,11,0,3,5,10,5,10,0,9,5,1,13,0,15,4,1,1,11,1,8,3,0,0,4,5,4,0,4,4,4,1,11]

theorem envBound3882 : H12AffineFastState.Bounded env3882 := by
  intro p hp
  have h : env3882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3881_3882 : H12AffineEnvironment.transform 4 11 env3881 = env3882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3881 == env3882) = true)

theorem identity3882 : scanCanonicalize (H12AffineFastState.compose env3882 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound3882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3883 : List Nat := [2,4,6,1,5,0,3,5,4,5,4,0,7,5,1,3,0,1,4,1,1,5,1,6,3,0,0,4,5,4,0,4,4,4,1,5]

theorem envBound3883 : H12AffineFastState.Bounded env3883 := by
  intro p hp
  have h : env3883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3882_3883 : H12AffineEnvironment.transform 2 6 env3882 = env3883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env3882 == env3883) = true)

def leafEnv3883 : List Nat := [2,4,6,1,5,0,3,5,4,5,4,0,7,5,1,3,0,1,4,1,1,5,1,6,0,3,1,0,0,4,5,4,0,4,4,4,4,6,1,5,1,4,0]

def active3883 : List Nat := [0,1]

def tree3883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3883 : H12WitnessSearch.Good tree3883 := H12GlobalWitnessIndex.good

theorem leafIdentity3883 : H12AffineFastState.composeSystem env3883 rootObs = leafEnv3883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3883 rootObs == leafEnv3883) = true)

theorem terminalChecked3883 : H12PackedTerminal.terminalCheckFast leafEnv3883 active3883 tree3883 = true := by decide +kernel

def env3884 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16400,22560,74794,17413,188,20481,4314287,4241029]

theorem envBound3884 : H12AffineFastState.Bounded env3884 := by
  intro p hp
  have h : env3884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3858_3884 : H12AffineEnvironment.transform 7 189 env3858 = env3884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3858 == env3884) = true)

theorem identity3884 : scanCanonicalize (H12AffineFastState.compose env3884 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound3884 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3885 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53402,4112,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16400,22560,62640,17413,188,20481,4195381,4241029]

theorem envBound3885 : H12AffineFastState.Bounded env3885 := by
  intro p hp
  have h : env3885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3884_3885 : H12AffineEnvironment.transform 15 53402 env3884 = env3885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env3884 == env3885) = true)

def env3886 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16384,22560,62624,17413,172,20481,4195365,4241029]

theorem envBound3886 : H12AffineFastState.Bounded env3886 := by
  intro p hp
  have h : env3886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3885_3886 : H12AffineEnvironment.transform 3 0 env3885 = env3886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3885 == env3886) = true)

theorem identity3886 : scanCanonicalize (H12AffineFastState.compose env3886 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3886 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3887 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1028,8192,16384,32768,50318,1028,262144,1025,32768,1029,4194304,4235392,41003,8329,4235393,320645,16385,16384,19492,57508,17413,172,17413,4195365,4235905]

theorem envBound3887 : H12AffineFastState.Bounded env3887 := by
  intro p hp
  have h : env3887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3886_3887 : H12AffineEnvironment.transform 11 1028 env3886 = env3887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env3886 == env3887) = true)

theorem identity3887 : scanCanonicalize (H12AffineFastState.compose env3887 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3887 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3888 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,32768,50214,1028,262144,1025,32768,1029,4194304,4235304,41003,8225,4235305,320557,16385,16384,19492,57356,17413,4,17413,4195365,4235817]

theorem envBound3888 : H12AffineFastState.Bounded env3888 := by
  intro p hp
  have h : env3888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3887_3888 : H12AffineEnvironment.transform 6 40 env3887 = env3888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3887 == env3888) = true)

theorem identity3888 : scanCanonicalize (H12AffineFastState.compose env3888 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound3888 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3889 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,32768,50214,1028,43049,1025,32768,1029,4194304,4235304,41003,8225,4235305,19460,16385,16384,19492,57356,17413,4,17413,4195365,4235817]

theorem envBound3889 : H12AffineFastState.Bounded env3889 := by
  intro p hp
  have h : env3889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3888_3889 : H12AffineEnvironment.transform 17 43049 env3888 = env3889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env3888 == env3889) = true)

theorem identity3889 : scanCanonicalize (H12AffineFastState.compose env3889 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound3889 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3890 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,8232,25614,1028,2049,1025,8232,1029,4194304,4194304,3,8225,4194305,19460,16385,16384,19492,16420,17413,4,17413,4195365,4194817]

theorem envBound3890 : H12AffineFastState.Bounded env3890 := by
  intro p hp
  have h : env3890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3889_3890 : H12AffineEnvironment.transform 14 8232 env3889 = env3890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env3889 == env3890) = true)

theorem identity3890 : scanCanonicalize (H12AffineFastState.compose env3890 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3890 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3891 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,16384,8200,25614,1028,2049,1025,8200,1029,4194304,4194304,3,8193,4194305,19460,16385,16384,19460,16388,17413,4,17413,4195333,4194817]

theorem envBound3891 : H12AffineFastState.Bounded env3891 := by
  intro p hp
  have h : env3891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3890_3891 : H12AffineEnvironment.transform 4 0 env3890 = env3891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3890 == env3891) = true)

theorem identity3891 : scanCanonicalize (H12AffineFastState.compose env3891 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound3891 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3892 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,1029,8200,8203,1028,2049,1025,8200,1029,4194304,4194304,3,8193,4194305,2049,1028,1029,2049,1025,0,4,0,4195333,4194817]

theorem envBound3892 : H12AffineFastState.Bounded env3892 := by
  intro p hp
  have h : env3892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3891_3892 : H12AffineEnvironment.transform 13 1029 env3891 = env3892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env3891 == env3892) = true)

theorem identity3892 : scanCanonicalize (H12AffineFastState.compose env3892 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3893 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,1029,8200,8203,1028,2049,1025,8200,1029,1038,1038,3,8193,1039,2049,1028,1029,2049,1025,0,4,0,11,1551]

theorem envBound3893 : H12AffineFastState.Bounded env3893 := by
  intro p hp
  have h : env3893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3892_3893 : H12AffineEnvironment.transform 21 1038 env3892 = env3893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1038 env3892 == env3893) = true)

theorem identity3893 : scanCanonicalize (H12AffineFastState.compose env3893 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound3893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3894 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,2056,1029,2048,2051,1028,2049,1025,2048,1029,1038,1038,3,2057,1039,2049,1028,1029,2049,1025,0,4,0,11,1551]

theorem envBound3894 : H12AffineFastState.Bounded env3894 := by
  intro p hp
  have h : env3894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3893_3894 : H12AffineEnvironment.transform 12 2056 env3893 = env3894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env3893 == env3894) = true)

theorem identity3894 : scanCanonicalize (H12AffineFastState.compose env3894 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound3894 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3895 : List Nat := [2,4,8,0,0,1,8,5,512,1024,1029,1028,1037,1029,1029,1030,1028,1028,1025,1029,1029,1038,1038,3,1036,1039,1028,1028,1029,1028,1025,0,4,0,11,1551]

theorem envBound3895 : H12AffineFastState.Bounded env3895 := by
  intro p hp
  have h : env3895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3894_3895 : H12AffineEnvironment.transform 10 1029 env3894 = env3895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env3894 == env3895) = true)

theorem identity3895 : scanCanonicalize (H12AffineFastState.compose env3895 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3895 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3896 : List Nat := [2,4,8,0,0,1,8,5,512,5,0,1,8,0,0,3,1,1,4,0,0,11,11,3,9,10,1,1,0,1,4,0,4,0,11,522]

theorem envBound3896 : H12AffineFastState.Bounded env3896 := by
  intro p hp
  have h : env3896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3895_3896 : H12AffineEnvironment.transform 9 5 env3895 = env3896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3895 == env3896) = true)

def env3897 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16385,22560,62625,17413,173,20481,4195364,4241029]

theorem envBound3897 : H12AffineFastState.Bounded env3897 := by
  intro p hp
  have h : env3897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3885_3897 : H12AffineEnvironment.transform 3 1 env3885 = env3897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3885 == env3897) = true)

def env3898 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,41088,5124,41003,8329,5125,323713,16385,16385,22560,62625,17413,173,20481,42148,5637]

theorem envBound3898 : H12AffineFastState.Bounded env3898 := by
  intro p hp
  have h : env3898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3897_3898 : H12AffineEnvironment.transform 21 41088 env3897 = env3898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3897 == env3898) = true)

theorem identity3898 : scanCanonicalize (H12AffineFastState.compose env3898 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 60940) := by decide +kernel

theorem selectedBound3898 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3899 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,60940,1025,32768,4097,41088,5124,41003,8329,5125,7821,16385,16385,22560,62625,17413,173,20481,42148,5637]

theorem envBound3899 : H12AffineFastState.Bounded env3899 := by
  intro p hp
  have h : env3899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3898_3899 : H12AffineEnvironment.transform 17 60940 env3898 = env3899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60940 env3898 == env3899) = true)

theorem identity3899 : scanCanonicalize (H12AffineFastState.compose env3899 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound3899 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env3900 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50214,1196,60940,1025,32768,1196,41088,169,41003,8329,168,2592,16385,16385,19597,57356,17413,173,17580,42148,680]

theorem envBound3900 : H12AffineFastState.Bounded env3900 := by
  intro p hp
  have h : env3900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3899_3900 : H12AffineEnvironment.transform 11 1197 env3899 = env3900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env3899 == env3900) = true)

theorem identity3900 : scanCanonicalize (H12AffineFastState.compose env3900 (packedSelected [1,5,10,12,13,15,21] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound3900 : packedSelected [1,5,10,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env3901 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,8352,25734,1196,20140,1025,8352,1196,32,169,139,8329,168,2592,16385,16385,19597,16556,17413,173,17580,1028,680]

theorem envBound3901 : H12AffineFastState.Bounded env3901 := by
  intro p hp
  have h : env3901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3900_3901 : H12AffineEnvironment.transform 14 8352 env3900 = env3901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3900 == env3901) = true)

theorem identity3901 : scanCanonicalize (H12AffineFastState.compose env3901 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3901 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3902 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,1572,8352,8866,1196,2184,1025,8352,1196,32,169,139,8329,168,2592,1573,1573,2729,1672,545,173,648,1028,680]

theorem envBound3902 : H12AffineFastState.Bounded env3902 := by
  intro p hp
  have h : env3902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3901_3902 : H12AffineEnvironment.transform 13 1572 env3901 = env3902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env3901 == env3902) = true)

theorem identity3902 : scanCanonicalize (H12AffineFastState.compose env3902 (packedSelected [1,2,3,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound3902 : packedSelected [1,2,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env3903 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,1574,1572,1670,1156,1196,2184,1025,1670,1196,32,169,139,1711,168,2592,1573,1573,2729,1672,545,173,648,1028,680]

theorem envBound3903 : H12AffineFastState.Bounded env3903 := by
  intro p hp
  have h : env3903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3902_3903 : H12AffineEnvironment.transform 12 1574 env3902 = env3903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env3902 == env3903) = true)

theorem identity3903 : scanCanonicalize (H12AffineFastState.compose env3903 (packedSelected [4,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound3903 : packedSelected [4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3904 : List Nat := [2,4,8,1,32,0,128,172,512,1024,1703,1197,1574,1572,1670,1156,1196,1583,1025,1670,1196,32,169,139,1711,168,1159,1573,1573,1038,1672,545,173,648,1028,680]

theorem envBound3904 : H12AffineFastState.Bounded env3904 := by
  intro p hp
  have h : env3904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3903_3904 : H12AffineEnvironment.transform 10 1703 env3903 = env3904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env3903 == env3904) = true)

theorem identity3904 : scanCanonicalize (H12AffineFastState.compose env3904 (packedSelected [1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound3904 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env3905 : List Nat := [2,4,8,1,32,0,128,172,512,134,545,43,672,674,512,2,42,681,135,512,42,32,169,139,553,168,1,675,675,136,526,545,173,648,130,680]

theorem envBound3905 : H12AffineFastState.Bounded env3905 := by
  intro p hp
  have h : env3905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3904_3905 : H12AffineEnvironment.transform 9 134 env3904 = env3905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env3904 == env3905) = true)

theorem identity3905 : scanCanonicalize (H12AffineFastState.compose env3905 (packedSelected [0,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3905 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env3906 : List Nat := [2,4,2,1,32,0,128,166,512,134,545,33,672,674,512,2,32,675,135,512,32,32,163,129,547,162,1,675,675,130,516,545,167,642,130,674]

theorem envBound3906 : H12AffineFastState.Bounded env3906 := by
  intro p hp
  have h : env3906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3905_3906 : H12AffineEnvironment.transform 2 2 env3905 = env3906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3905 == env3906) = true)

theorem identity3906 : scanCanonicalize (H12AffineFastState.compose env3906 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound3906 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3907 : List Nat := [2,4,2,1,32,0,128,166,162,134,131,33,2,0,162,2,32,1,135,162,32,32,163,129,129,162,1,1,1,130,166,131,167,32,130,0]

theorem envBound3907 : H12AffineFastState.Bounded env3907 := by
  intro p hp
  have h : env3907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3906_3907 : H12AffineEnvironment.transform 8 162 env3906 = env3907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env3906 == env3907) = true)

def env3908 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,41089,5125,41003,8329,5124,323713,16385,16385,22560,62625,17413,173,20481,42149,5636]

theorem envBound3908 : H12AffineFastState.Bounded env3908 := by
  intro p hp
  have h : env3908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3897_3908 : H12AffineEnvironment.transform 21 41089 env3897 = env3908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3897 == env3908) = true)

theorem identity3908 : scanCanonicalize (H12AffineFastState.compose env3908 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 43680) := by decide +kernel

theorem selectedBound3908 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3909 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,43680,1025,32768,4097,41089,5125,41003,8329,5124,23073,16385,16385,22560,62625,17413,173,20481,42149,5636]

theorem envBound3909 : H12AffineFastState.Bounded env3909 := by
  intro p hp
  have h : env3909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3908_3909 : H12AffineEnvironment.transform 17 43680 env3908 = env3909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43680 env3908 == env3909) = true)

theorem identity3909 : scanCanonicalize (H12AffineFastState.compose env3909 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3909 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env3910 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53282,4097,43529,1025,32768,4097,41000,5125,41003,8224,5124,23073,16385,16385,22560,62472,17413,4,20481,41996,5636]

theorem envBound3910 : H12AffineFastState.Bounded env3910 := by
  intro p hp
  have h : env3910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3909_3910 : H12AffineEnvironment.transform 6 41 env3909 = env3910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3909 == env3910) = true)

theorem identity3910 : scanCanonicalize (H12AffineFastState.compose env3910 (packedSelected [2,3,5,8,11,12,13,15,17,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3910 : packedSelected [2,3,5,8,11,12,13,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env3911 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,32768,50214,1029,43529,1025,32768,1029,41000,1,41003,8224,0,20005,16385,16385,19492,57356,17413,4,17413,41996,512]

theorem envBound3911 : H12AffineFastState.Bounded env3911 := by
  intro p hp
  have h : env3911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3910_3911 : H12AffineEnvironment.transform 11 1028 env3910 = env3911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env3910 == env3911) = true)

theorem identity3911 : scanCanonicalize (H12AffineFastState.compose env3911 (packedSelected [0,2,3,4,6,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 1068) := by decide +kernel

theorem selectedBound3911 : packedSelected [0,2,3,4,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3912 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,1068,16384,32768,50214,1029,36389,1025,32768,1029,33796,1,33799,1036,0,20005,16385,16385,19492,50208,17413,4,17413,32800,512]

theorem envBound3912 : H12AffineFastState.Bounded env3912 := by
  intro p hp
  have h : env3912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3911_3912 : H12AffineEnvironment.transform 12 1068 env3911 = env3912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1068 env3911 == env3912) = true)

theorem identity3912 : scanCanonicalize (H12AffineFastState.compose env3912 (packedSelected [3,6,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 19471) := by decide +kernel

theorem selectedBound3912 : packedSelected [3,6,8,11] rootPS < 2^1333 := by decide +kernel

def env3913 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,1068,16384,19471,2089,1029,16938,1025,19471,1029,18443,1,18440,1036,0,20005,16385,16385,19492,2095,17413,4,17413,19503,512]

theorem envBound3913 : H12AffineFastState.Bounded env3913 := by
  intro p hp
  have h : env3913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3912_3913 : H12AffineEnvironment.transform 14 19471 env3912 = env3913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19471 env3912 == env3913) = true)

theorem identity3913 : scanCanonicalize (H12AffineFastState.compose env3913 (packedSelected [0,2,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2570) := by decide +kernel

theorem selectedBound3913 : packedSelected [0,2,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env3914 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,1068,2570,1541,2089,1029,2080,1025,1541,1029,513,1,514,1036,0,1071,2571,2571,1582,2095,3599,4,3599,1573,512]

theorem envBound3914 : H12AffineFastState.Bounded env3914 := by
  intro p hp
  have h : env3914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3913_3914 : H12AffineEnvironment.transform 13 2570 env3913 = env3914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2570 env3913 == env3914) = true)

theorem identity3914 : scanCanonicalize (H12AffineFastState.compose env3914 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3914 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env3915 : List Nat := [2,4,8,1,32,0,41,5,1,1024,2048,1028,1068,2059,1028,2089,1029,2080,1025,1028,1029,0,1,3,1036,0,1071,2058,2058,1071,2095,3086,4,3086,1060,1]

theorem envBound3915 : H12AffineFastState.Bounded env3915 := by
  intro p hp
  have h : env3915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3914_3915 : H12AffineEnvironment.transform 8 1 env3914 = env3915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3914 == env3915) = true)

theorem identity3915 : scanCanonicalize (H12AffineFastState.compose env3915 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound3915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3916 : List Nat := [2,4,8,1,32,0,41,5,1,1024,1,1028,1068,10,1028,40,1029,33,1025,1028,1029,0,1,3,1036,0,1071,11,11,1071,46,1039,4,1039,1060,1]

theorem envBound3916 : H12AffineFastState.Bounded env3916 := by
  intro p hp
  have h : env3916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3915_3916 : H12AffineEnvironment.transform 10 1 env3915 = env3916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env3915 == env3916) = true)

theorem identity3916 : scanCanonicalize (H12AffineFastState.compose env3916 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3916 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3917 : List Nat := [2,4,8,1,32,0,41,5,1,14,1,10,34,10,10,40,11,33,15,10,11,0,1,3,2,0,33,11,11,33,46,1,4,1,42,1]

theorem envBound3917 : H12AffineFastState.Bounded env3917 := by
  intro p hp
  have h : env3917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3916_3917 : H12AffineEnvironment.transform 9 14 env3916 = env3917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3916 == env3917) = true)

theorem identity3917 : scanCanonicalize (H12AffineFastState.compose env3917 (packedSelected [1,6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3917 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env3918 : List Nat := [2,4,8,1,11,0,2,5,1,14,1,10,9,10,10,3,11,10,15,10,11,0,1,3,2,0,10,11,11,10,5,1,4,1,1,1]

theorem envBound3918 : H12AffineFastState.Bounded env3918 := by
  intro p hp
  have h : env3918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3917_3918 : H12AffineEnvironment.transform 4 11 env3917 = env3918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3917 == env3918) = true)

theorem identity3918 : scanCanonicalize (H12AffineFastState.compose env3918 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3919 : List Nat := [2,4,2,1,1,0,2,5,1,4,1,0,3,0,0,3,1,0,5,0,1,0,1,3,2,0,0,1,1,0,5,1,4,1,1,1]

theorem envBound3919 : H12AffineFastState.Bounded env3919 := by
  intro p hp
  have h : env3919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3918_3919 : H12AffineEnvironment.transform 2 2 env3918 = env3919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3918 == env3919) = true)

def env3920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015249,134217728,268435456,268435965,134523041,2699307,147588589,525568,134520960,143496518,8914924]

theorem envBound3920 : H12AffineFastState.Bounded env3920 := by
  intro p hp
  have h : env3920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2954_3920 : H12AffineEnvironment.transform 25 11015249 env2954 = env3920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 11015249 env2954 == env3920) = true)

def env3921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015249,849104,268435456,268435965,547953,2699307,12644669,525568,545872,8479126,8914924]

theorem envBound3921 : H12AffineFastState.Bounded env3921 := by
  intro p hp
  have h : env3921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3920_3921 : H12AffineEnvironment.transform 26 849104 env3920 = env3921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849104 env3920 == env3921) = true)

def env3922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849104,268435456,268435965,547953,598059,12644669,525568,545872,8479126,8914924]

theorem envBound3922 : H12AffineFastState.Bounded env3922 := by
  intro p hp
  have h : env3922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3921_3922 : H12AffineEnvironment.transform 20 4096 env3921 = env3922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env3921 == env3922) = true)

def env3923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849104,16384,16893,547953,598059,12644669,525568,545872,8479126,8914924]

theorem envBound3923 : H12AffineFastState.Bounded env3923 := by
  intro p hp
  have h : env3923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3922_3923 : H12AffineEnvironment.transform 27 16384 env3922 = env3923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3922 == env3923) = true)

def env3924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323792,16384,16893,22641,74795,12644669,256,20560,8479126,8389612]

theorem envBound3924 : H12AffineFastState.Bounded env3924 := by
  intro p hp
  have h : env3924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3923_3924 : H12AffineEnvironment.transform 18 1024 env3923 = env3924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3923 == env3924) = true)

theorem identity3924 : scanCanonicalize (H12AffineFastState.compose env3924 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73922) := by decide +kernel

theorem selectedBound3924 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,73922,41003,8329,73875,323792,16384,16893,22641,74795,4313599,256,20560,16724,74542]

theorem envBound3925 : H12AffineFastState.Bounded env3925 := by
  intro p hp
  have h : env3925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3924_3925 : H12AffineEnvironment.transform 22 73922 env3924 = env3925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73922 env3924 == env3925) = true)

def env3926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,73874,41003,8329,73875,323712,16384,16813,22561,74795,4313519,256,20480,16644,74542]

theorem envBound3926 : H12AffineFastState.Bounded env3926 := by
  intro p hp
  have h : env3926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3925_3926 : H12AffineEnvironment.transform 5 16 env3925 = env3926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3925 == env3926) = true)

def env3927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41088,73874,41003,8329,73875,323712,16384,16813,22561,74795,94511,256,20480,16644,74542]

theorem envBound3927 : H12AffineFastState.Bounded env3927 := by
  intro p hp
  have h : env3927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3926_3927 : H12AffineEnvironment.transform 21 41088 env3926 = env3927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3926 == env3927) = true)

theorem identity3927 : scanCanonicalize (H12AffineFastState.compose env3927 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound3927 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8235,4524,262144,1024,32768,4096,41088,185,41003,8329,184,323712,16384,16813,22561,1024,20740,256,20480,16644,773]

theorem envBound3928 : H12AffineFastState.Bounded env3928 := by
  intro p hp
  have h : env3928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3927_3928 : H12AffineEnvironment.transform 15 8235 env3927 = env3928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env3927 == env3928) = true)

theorem identity3928 : scanCanonicalize (H12AffineFastState.compose env3928 (packedSelected [0,1,5,7,8,11,15,20,24,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 61209) := by decide +kernel

theorem selectedBound3928 : packedSelected [0,1,5,7,8,11,15,20,24,32,38] rootPS < 2^1333 := by decide +kernel

def env3929 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8235,4524,61209,1024,32768,4096,41088,185,41003,8329,184,8089,16384,16813,22561,1024,20740,256,20480,16644,773]

theorem envBound3929 : H12AffineFastState.Bounded env3929 := by
  intro p hp
  have h : env3929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3928_3929 : H12AffineEnvironment.transform 17 61209 env3928 = env3929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61209 env3928 == env3929) = true)

def env3930 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,8235,4524,49073,1024,32768,4096,41088,185,41003,8329,184,8089,4264,4357,2185,1024,428,256,168,4524,773]

theorem envBound3930 : H12AffineFastState.Bounded env3930 := by
  intro p hp
  have h : env3930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3929_3930 : H12AffineEnvironment.transform 13 4264 env3929 = env3930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3929 == env3930) = true)

theorem identity3930 : scanCanonicalize (H12AffineFastState.compose env3930 (packedSelected [17,21] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound3930 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3931 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,8192,1841,32768,8235,1589,43048,1024,32768,1945,41088,185,41003,8329,184,2048,1841,1692,2185,1024,428,256,168,1589,773]

theorem envBound3931 : H12AffineFastState.Bounded env3931 := by
  intro p hp
  have h : env3931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3930_3931 : H12AffineEnvironment.transform 11 1945 env3930 = env3931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env3930 == env3931) = true)

theorem identity3931 : scanCanonicalize (H12AffineFastState.compose env3931 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound3931 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env3932 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,8192,1841,8613,8235,1589,2445,1024,8613,1945,293,185,398,8329,184,2048,1841,1692,2185,1024,428,256,168,1589,773]

theorem envBound3932 : H12AffineFastState.Bounded env3932 := by
  intro p hp
  have h : env3932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3931_3932 : H12AffineEnvironment.transform 14 8613 env3931 = env3932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env3931 == env3932) = true)

theorem identity3932 : scanCanonicalize (H12AffineFastState.compose env3932 (packedSelected [1,2,6,7,8,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound3932 : packedSelected [1,2,6,7,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env3933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,2949,1841,2592,2990,1589,2445,1024,2592,1945,293,185,398,2828,184,2048,1841,1692,2185,1024,428,256,168,1589,773]

theorem envBound3933 : H12AffineFastState.Bounded env3933 := by
  intro p hp
  have h : env3933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3932_3933 : H12AffineEnvironment.transform 12 2949 env3932 = env3933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env3932 == env3933) = true)

theorem identity3933 : scanCanonicalize (H12AffineFastState.compose env3933 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3933 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env3934 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1038,1945,1931,1841,1582,1952,1589,1411,1024,1582,1945,293,185,398,1794,184,1038,1841,1692,1159,1024,428,256,168,1589,773]

theorem envBound3934 : H12AffineFastState.Bounded env3934 := by
  intro p hp
  have h : env3934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3933_3934 : H12AffineEnvironment.transform 10 1038 env3933 = env3934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3933 == env3934) = true)

theorem identity3934 : scanCanonicalize (H12AffineFastState.compose env3934 (packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound3934 : packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS < 2^1333 := by decide +kernel

def env3935 : List Nat := [2,4,8,16,32,16,128,256,169,1024,1038,1328,1314,1432,1159,1289,1180,1411,1024,1159,1328,293,185,398,1451,184,1038,1432,1077,1159,1024,428,256,168,1180,428]

theorem envBound3935 : H12AffineFastState.Bounded env3935 := by
  intro p hp
  have h : env3935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3934_3935 : H12AffineEnvironment.transform 8 169 env3934 = env3935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env3934 == env3935) = true)

theorem identity3935 : scanCanonicalize (H12AffineFastState.compose env3935 (packedSelected [6,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound3935 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env3936 : List Nat := [2,4,8,16,32,16,128,256,169,267,261,59,41,147,396,2,407,136,267,396,59,293,185,398,160,184,261,147,318,396,267,428,256,168,407,428]

theorem envBound3936 : H12AffineFastState.Bounded env3936 := by
  intro p hp
  have h : env3936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3935_3936 : H12AffineEnvironment.transform 9 267 env3935 = env3936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env3935 == env3936) = true)

theorem identity3936 : scanCanonicalize (H12AffineFastState.compose env3936 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 151) := by decide +kernel

theorem selectedBound3936 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3937 : List Nat := [2,4,8,16,32,16,128,151,169,156,146,59,41,147,27,2,0,136,156,27,59,178,185,25,160,184,146,147,169,27,156,59,151,168,0,59]

theorem envBound3937 : H12AffineFastState.Bounded env3937 := by
  intro p hp
  have h : env3937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3936_3937 : H12AffineEnvironment.transform 7 151 env3936 = env3937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 151 env3936 == env3937) = true)

theorem identity3937 : scanCanonicalize (H12AffineFastState.compose env3937 (packedSelected [0,2,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3937 : packedSelected [0,2,10,13] rootPS < 2^1333 := by decide +kernel

def env3938 : List Nat := [2,4,8,16,32,16,19,4,58,15,1,59,41,0,27,2,0,27,15,27,59,33,42,25,51,43,1,0,58,27,15,59,4,59,0,59]

theorem envBound3938 : H12AffineFastState.Bounded env3938 := by
  intro p hp
  have h : env3938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3937_3938 : H12AffineEnvironment.transform 6 19 env3937 = env3938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3937 == env3938) = true)

theorem identity3938 : scanCanonicalize (H12AffineFastState.compose env3938 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound3938 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env3939 : List Nat := [2,4,8,16,15,16,19,4,21,15,1,20,6,0,27,2,0,27,15,27,20,14,5,25,28,4,1,0,21,27,15,20,4,20,0,20]

theorem envBound3939 : H12AffineFastState.Bounded env3939 := by
  intro p hp
  have h : env3939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3938_3939 : H12AffineEnvironment.transform 4 15 env3938 = env3939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env3938 == env3939) = true)

theorem identity3939 : scanCanonicalize (H12AffineFastState.compose env3939 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound3939 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3940 : List Nat := [2,4,8,4,15,4,7,4,1,15,1,0,6,0,15,2,0,15,15,15,0,14,5,13,8,4,1,0,1,15,15,0,4,0,0,0]

theorem envBound3940 : H12AffineFastState.Bounded env3940 := by
  intro p hp
  have h : env3940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3939_3940 : H12AffineEnvironment.transform 3 4 env3939 = env3940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env3939 == env3940) = true)

theorem identity3940 : scanCanonicalize (H12AffineFastState.compose env3940 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3940 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3941 : List Nat := [2,1,8,1,10,1,2,1,1,10,1,0,3,0,10,2,0,10,10,10,0,11,0,8,8,1,1,0,1,10,10,0,1,0,0,0]

end H12CloudChart0