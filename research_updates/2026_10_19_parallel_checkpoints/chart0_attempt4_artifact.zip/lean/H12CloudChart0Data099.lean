import H12CloudChart0Data098

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound25055 : H12AffineFastState.Bounded env25055 := by
  intro p hp
  have h : env25055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25054_25055 : H12AffineEnvironment.transform 13 8461 env25054 = env25055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8461 env25054 == env25055) = true)

theorem identity25055 : scanCanonicalize (H12AffineFastState.compose env25055 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound25055 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5213,5456,5456,5206,131072,7284,1025,5457,4161,33,17,83,5213,65,133185,5392,4177,138341,1364,32,257,112,5376,513]

theorem envBound25056 : H12AffineFastState.Bounded env25056 := by
  intro p hp
  have h : env25056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25055_25056 : H12AffineEnvironment.transform 12 5213 env25055 = env25056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env25055 == env25056) = true)

theorem identity25056 : scanCanonicalize (H12AffineFastState.compose env25056 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25056 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env25057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3149,3392,3392,3142,131072,1124,1025,3393,2129,33,17,83,3149,65,133185,3328,2113,132213,1364,32,257,112,3344,513]

theorem envBound25057 : H12AffineFastState.Bounded env25057 := by
  intro p hp
  have h : env25057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25056_25057 : H12AffineEnvironment.transform 11 2064 env25056 = env25057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25056 == env25057) = true)

theorem identity25057 : scanCanonicalize (H12AffineFastState.compose env25057 (packedSelected [4,9,18] rootPS)) = affineNative (2^(16+1) ^^^ 1061) := by decide +kernel

theorem selectedBound25057 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env25058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3149,3392,3392,3142,1061,1124,1025,3393,2129,33,17,83,3149,65,3172,3328,2113,80,1364,32,257,112,3344,513]

theorem envBound25058 : H12AffineFastState.Bounded env25058 := by
  intro p hp
  have h : env25058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25057_25058 : H12AffineEnvironment.transform 16 1061 env25057 = env25058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1061 env25057 == env25058) = true)

def env25059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444641,8193,65,6705412,313700,2394420,138341,2102548,4466728,257,21792,46092,2175563]

theorem envBound25059 : H12AffineFastState.Bounded env25059 := by
  intro p hp
  have h : env25059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24991_25059 : H12AffineEnvironment.transform 6 9 env24991 = env25059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24991 == env25059) = true)

theorem identity25059 : scanCanonicalize (H12AffineFastState.compose env25059 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound25059 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env25060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,4194304,318565,294187,8193,65,4677966,313700,375166,138341,75102,4466728,257,21792,46092,513]

theorem envBound25060 : H12AffineFastState.Bounded env25060 := by
  intro p hp
  have h : env25060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25059_25060 : H12AffineEnvironment.transform 20 77898 env25059 = env25060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env25059 == env25060) = true)

theorem identity25060 : scanCanonicalize (H12AffineFastState.compose env25060 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound25060 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77898,4194304,318565,294187,8193,65,4456788,313700,375166,97407,75102,4466728,257,21792,46092,513]

theorem envBound25061 : H12AffineFastState.Bounded env25061 := by
  intro p hp
  have h : env25061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25060_25061 : H12AffineEnvironment.transform 16 90138 env25060 = env25061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env25060 == env25061) = true)

def env25062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,4194304,62541,21763,8193,65,4204924,57676,102742,97407,75102,4194304,257,21792,46092,513]

theorem envBound25062 : H12AffineFastState.Bounded env25062 := by
  intro p hp
  have h : env25062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25061_25062 : H12AffineEnvironment.transform 17 10280 env25061 = env25062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25061 == env25062) = true)

theorem identity25062 : scanCanonicalize (H12AffineFastState.compose env25062 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound25062 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env25063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46157,10280,1025,32769,58397,4194304,62541,21763,8193,65,4204924,57676,17665,43048,61705,4194304,257,21792,46092,513]

theorem envBound25063 : H12AffineFastState.Bounded env25063 := by
  intro p hp
  have h : env25063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25062_25063 : H12AffineEnvironment.transform 15 54359 env25062 = env25063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env25062 == env25063) = true)

theorem identity25063 : scanCanonicalize (H12AffineFastState.compose env25063 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25063 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env25064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46157,10280,1025,32769,45341,4194304,41293,3,8193,65,4204924,46156,4097,43048,41993,4194304,257,32,46092,513]

theorem envBound25064 : H12AffineFastState.Bounded env25064 := by
  intro p hp
  have h : env25064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25063_25064 : H12AffineEnvironment.transform 13 5376 env25063 = env25064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25063 == env25064) = true)

theorem identity25064 : scanCanonicalize (H12AffineFastState.compose env25064 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25064 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25065 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,46109,10280,1025,32769,45341,4194304,41245,3,8193,17,4204844,46108,4097,43048,41993,4194304,257,32,46092,513]

theorem envBound25065 : H12AffineFastState.Bounded env25065 := by
  intro p hp
  have h : env25065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25064_25065 : H12AffineEnvironment.transform 5 16 env25064 = env25065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25064 == env25065) = true)

theorem identity25065 : scanCanonicalize (H12AffineFastState.compose env25065 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 7172) := by decide +kernel

theorem selectedBound25065 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env25066 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,46109,10280,1025,32769,45341,7172,41245,3,8193,17,13608,46108,4097,43048,41993,7172,257,32,46092,513]

theorem envBound25066 : H12AffineFastState.Bounded env25066 := by
  intro p hp
  have h : env25066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25065_25066 : H12AffineEnvironment.transform 21 7172 env25065 = env25066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7172 env25065 == env25066) = true)

theorem identity25066 : scanCanonicalize (H12AffineFastState.compose env25066 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound25066 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env25067 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,5376,32768,33031,33077,7424,1025,32769,33845,7172,37941,3,5417,17,0,33076,4097,40192,37153,7172,257,32,33060,513]

theorem envBound25067 : H12AffineFastState.Bounded env25067 := by
  intro p hp
  have h : env25067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25066_25067 : H12AffineEnvironment.transform 12 5416 env25066 = env25067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env25066 == env25067) = true)

theorem identity25067 : scanCanonicalize (H12AffineFastState.compose env25067 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25067 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env25068 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,5376,1,262,308,7424,1025,0,1076,7172,5172,3,5417,17,0,309,4097,7425,4384,7172,257,32,293,513]

theorem envBound25068 : H12AffineFastState.Bounded env25068 := by
  intro p hp
  have h : env25068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25067_25068 : H12AffineEnvironment.transform 14 1 env25067 = env25068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25067 == env25068) = true)

theorem identity25068 : scanCanonicalize (H12AffineFastState.compose env25068 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound25068 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25069 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,4096,5416,5376,1,262,308,5156,1025,0,1076,5408,5172,3,5417,17,0,309,4097,5157,4384,5408,257,32,293,513]

theorem envBound25069 : H12AffineFastState.Bounded env25069 := by
  intro p hp
  have h : env25069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25068_25069 : H12AffineEnvironment.transform 10 292 env25068 = env25069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env25068 == env25069) = true)

theorem identity25069 : scanCanonicalize (H12AffineFastState.compose env25069 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25069 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env25070 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,4096,4153,4113,1,262,308,4405,272,0,293,4145,4389,3,4152,17,0,309,4097,4404,4384,4145,257,32,293,513]

theorem envBound25070 : H12AffineFastState.Bounded env25070 := by
  intro p hp
  have h : env25070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25069_25070 : H12AffineEnvironment.transform 9 273 env25069 = env25070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25069 == env25070) = true)

theorem identity25070 : scanCanonicalize (H12AffineFastState.compose env25070 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound25070 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env25071 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,17,40,0,1,262,308,292,272,0,293,32,308,3,41,17,0,309,16,293,305,32,257,32,293,513]

theorem envBound25071 : H12AffineFastState.Bounded env25071 := by
  intro p hp
  have h : env25071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25070_25071 : H12AffineEnvironment.transform 11 17 env25070 = env25071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25070 == env25071) = true)

theorem identity25071 : scanCanonicalize (H12AffineFastState.compose env25071 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound25071 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25072 : List Nat := [2,4,8,16,32,16,9,256,32,273,292,17,40,0,1,262,308,292,272,0,293,32,308,3,41,17,0,309,16,293,305,32,257,32,293,33]

theorem envBound25072 : H12AffineFastState.Bounded env25072 := by
  intro p hp
  have h : env25072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25071_25072 : H12AffineEnvironment.transform 8 32 env25071 = env25072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env25071 == env25072) = true)

theorem identity25072 : scanCanonicalize (H12AffineFastState.compose env25072 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25073 : List Nat := [2,4,8,16,32,16,9,37,32,52,1,17,40,0,1,35,17,1,53,0,0,32,17,3,41,17,0,16,16,0,20,32,36,32,0,33]

theorem envBound25073 : H12AffineFastState.Bounded env25073 := by
  intro p hp
  have h : env25073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25072_25073 : H12AffineEnvironment.transform 7 37 env25072 = env25073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25072 == env25073) = true)

theorem identity25073 : scanCanonicalize (H12AffineFastState.compose env25073 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25074 : List Nat := [2,4,8,16,17,16,9,20,17,5,1,17,25,0,1,18,17,1,4,0,0,17,17,3,24,17,0,16,16,0,20,17,21,17,0,16]

theorem envBound25074 : H12AffineFastState.Bounded env25074 := by
  intro p hp
  have h : env25074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25073_25074 : H12AffineEnvironment.transform 4 17 env25073 = env25074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25073 == env25074) = true)

def env25075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,77898,4194304,62540,21762,8193,65,4204925,57677,102743,97407,75102,4194305,257,21792,46092,513]

theorem envBound25075 : H12AffineFastState.Bounded env25075 := by
  intro p hp
  have h : env25075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25061_25075 : H12AffineEnvironment.transform 17 10281 env25061 = env25075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25061 == env25075) = true)

theorem identity25075 : scanCanonicalize (H12AffineFastState.compose env25075 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 53574) := by decide +kernel

theorem selectedBound25075 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env25076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53574,45404,10281,1025,32769,57612,4194304,62540,21762,8193,65,4204925,57677,16401,44345,62488,4194305,257,21792,46092,513]

theorem envBound25076 : H12AffineFastState.Bounded env25076 := by
  intro p hp
  have h : env25076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25075_25076 : H12AffineEnvironment.transform 15 53574 env25075 = env25076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53574 env25075 == env25076) = true)

theorem identity25076 : scanCanonicalize (H12AffineFastState.compose env25076 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25076 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env25077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10281,1025,8541,16464,4194304,21776,21762,8193,65,4204925,16401,16401,3173,21828,4194305,257,21792,5456,513]

theorem envBound25077 : H12AffineFastState.Bounded env25077 := by
  intro p hp
  have h : env25077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25076_25077 : H12AffineEnvironment.transform 14 8540 env25076 = env25077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25076 == env25077) = true)

theorem identity25077 : scanCanonicalize (H12AffineFastState.compose env25077 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25077 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env25078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,20759,4096,2340,1025,80,16464,4194304,21776,21762,268,65,4196464,16401,16401,3173,21828,4194305,257,21792,5456,513]

theorem envBound25078 : H12AffineFastState.Bounded env25078 := by
  intro p hp
  have h : env25078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25077_25078 : H12AffineEnvironment.transform 12 269 env25077 = env25078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25077 == env25078) = true)

theorem identity25078 : scanCanonicalize (H12AffineFastState.compose env25078 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 20805) := by decide +kernel

theorem selectedBound25078 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,20759,4096,2340,1025,80,16464,20805,21776,21762,268,65,22837,16401,16401,3173,21828,20804,257,21792,5456,513]

theorem envBound25079 : H12AffineFastState.Bounded env25079 := by
  intro p hp
  have h : env25079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25078_25079 : H12AffineEnvironment.transform 21 20805 env25078 = env25079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20805 env25078 == env25079) = true)

theorem identity25079 : scanCanonicalize (H12AffineFastState.compose env25079 (packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound25079 : packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env25080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,2048,81,6423,4096,2340,1025,80,2128,6469,7440,7426,268,65,4405,2065,2065,3173,7492,6468,257,7456,5456,513]

theorem envBound25080 : H12AffineFastState.Bounded env25080 := by
  intro p hp
  have h : env25080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25079_25080 : H12AffineEnvironment.transform 13 2048 env25079 = env25080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env25079 == env25080) = true)

theorem identity25080 : scanCanonicalize (H12AffineFastState.compose env25080 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound25080 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env25081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,269,2048,81,1378,3189,2340,1025,80,2128,1328,357,375,268,65,3392,2065,2065,3173,305,1329,257,341,2341,513]

theorem envBound25081 : H12AffineFastState.Bounded env25081 := by
  intro p hp
  have h : env25081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25080_25081 : H12AffineEnvironment.transform 11 3189 env25080 = env25081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env25080 == env25081) = true)

theorem identity25081 : scanCanonicalize (H12AffineFastState.compose env25081 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25081 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env25082 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3189,120,2048,81,1047,3189,2129,1025,80,2128,1093,16,2,121,65,3125,2065,2065,3173,68,1092,116,32,2128,513]

theorem envBound25082 : H12AffineFastState.Bounded env25082 := by
  intro p hp
  have h : env25082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25081_25082 : H12AffineEnvironment.transform 7 117 env25081 = env25082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25081 == env25082) = true)

theorem identity25082 : scanCanonicalize (H12AffineFastState.compose env25082 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound25082 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25083 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,1061,120,80,81,1047,1061,1,1025,80,0,1093,16,2,121,65,1125,65,65,1077,68,1092,116,32,0,513]

theorem envBound25083 : H12AffineFastState.Bounded env25083 := by
  intro p hp
  have h : env25083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25082_25083 : H12AffineEnvironment.transform 10 80 env25082 = env25083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env25082 == env25083) = true)

theorem identity25083 : scanCanonicalize (H12AffineFastState.compose env25083 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound25083 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25084 : List Nat := [2,4,8,16,32,64,9,117,512,126,80,91,120,80,81,105,91,1,127,80,0,59,16,2,121,65,27,65,65,75,68,58,116,32,0,513]

theorem envBound25084 : H12AffineFastState.Bounded env25084 := by
  intro p hp
  have h : env25084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25083_25084 : H12AffineEnvironment.transform 9 126 env25083 = env25084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env25083 == env25084) = true)

theorem identity25084 : scanCanonicalize (H12AffineFastState.compose env25084 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25084 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env25085 : List Nat := [2,4,8,16,32,16,9,37,512,46,0,11,40,0,1,57,11,1,47,0,0,59,16,2,41,17,27,17,17,27,20,58,36,32,0,513]

theorem envBound25085 : H12AffineFastState.Bounded env25085 := by
  intro p hp
  have h : env25085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25084_25085 : H12AffineEnvironment.transform 5 16 env25084 = env25085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25084 == env25085) = true)

theorem identity25085 : scanCanonicalize (H12AffineFastState.compose env25085 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25085 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25086 : List Nat := [2,4,8,10,32,10,9,37,512,46,0,11,40,0,1,35,11,1,47,0,0,33,10,2,41,11,1,11,11,1,14,32,36,32,0,513]

theorem envBound25086 : H12AffineFastState.Bounded env25086 := by
  intro p hp
  have h : env25086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25085_25086 : H12AffineEnvironment.transform 3 10 env25085 = env25086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25085 == env25086) = true)

theorem identity25086 : scanCanonicalize (H12AffineFastState.compose env25086 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound25086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25087 : List Nat := [2,4,8,10,32,10,9,37,11,46,0,11,40,0,1,35,11,1,47,0,0,33,10,2,41,11,1,11,11,1,14,32,36,32,0,10]

theorem envBound25087 : H12AffineFastState.Bounded env25087 := by
  intro p hp
  have h : env25087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25086_25087 : H12AffineEnvironment.transform 8 11 env25086 = env25087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env25086 == env25087) = true)

theorem identity25087 : scanCanonicalize (H12AffineFastState.compose env25087 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound25087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25088 : List Nat := [2,4,2,0,32,0,3,37,1,36,0,1,34,0,1,35,1,1,37,0,0,33,0,2,35,1,1,1,1,1,4,32,36,32,0,0]

theorem envBound25088 : H12AffineFastState.Bounded env25088 := by
  intro p hp
  have h : env25088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25087_25088 : H12AffineEnvironment.transform 2 2 env25087 = env25088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env25087 == env25088) = true)

def env25089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound25089 : H12AffineFastState.Bounded env25089 := by
  intro p hp
  have h : env25089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23706_25089 : H12AffineEnvironment.transform 29 155254785 env23706 = env25089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env23706 == env25089) = true)

def env25090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound25090 : H12AffineFastState.Bounded env25090 := by
  intro p hp
  have h : env25090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25089_25090 : H12AffineEnvironment.transform 25 64 env25089 = env25090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env25089 == env25090) = true)

def env25091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound25091 : H12AffineFastState.Bounded env25091 := by
  intro p hp
  have h : env25091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25090_25091 : H12AffineEnvironment.transform 26 30393344 env25090 = env25091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env25090 == env25091) = true)

def env25092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound25092 : H12AffineFastState.Bounded env25092 := by
  intro p hp
  have h : env25092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25091_25092 : H12AffineEnvironment.transform 18 1024 env25091 = env25092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25091 == env25092) = true)

theorem identity25092 : scanCanonicalize (H12AffineFastState.compose env25092 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound25092 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,152,16777216,8328,64,21479576,18973837,2119112,442521,16876681,23160257,256,18990133,18949520,16819039]

theorem envBound25093 : H12AffineFastState.Bounded env25093 := by
  intro p hp
  have h : env25093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25092_25093 : H12AffineEnvironment.transform 22 152 env25092 = env25093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env25092 == env25093) = true)

def env25094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479440,18973701,2118976,442385,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound25094 : H12AffineFastState.Bounded env25094 := by
  intro p hp
  have h : env25094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25093_25094 : H12AffineEnvironment.transform 6 8 env25093 = env25094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25093 == env25094) = true)

theorem identity25094 : scanCanonicalize (H12AffineFastState.compose env25094 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound25094 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env25095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8192,64,4677966,2172251,2118976,442385,75103,6407191,256,2188651,2196550,513]

theorem envBound25095 : H12AffineFastState.Bounded env25095 := by
  intro p hp
  have h : env25095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25094_25095 : H12AffineEnvironment.transform 23 41310 env25094 = env25095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env25094 == env25095) = true)

def env25096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677966,115015,45404,442385,75103,4268043,256,98679,90202,513]

theorem envBound25096 : H12AffineFastState.Bounded env25096 := by
  intro p hp
  have h : env25096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25095_25096 : H12AffineEnvironment.transform 20 58396 env25095 = env25096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env25095 == env25096) = true)

theorem identity25096 : scanCanonicalize (H12AffineFastState.compose env25096 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25096 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4604229,57676,45404,442385,1364,4194304,256,41340,16465,513]

theorem envBound25097 : H12AffineFastState.Bounded env25097 := by
  intro p hp
  have h : env25097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25096_25097 : H12AffineEnvironment.transform 15 8203 env25096 = env25097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25096 == env25097) = true)

theorem identity25097 : scanCanonicalize (H12AffineFastState.compose env25097 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound25097 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env25098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,419913,16,41310,8192,64,10508,57676,45404,442385,1364,419913,256,41340,16465,513]

theorem envBound25098 : H12AffineFastState.Bounded env25098 := by
  intro p hp
  have h : env25098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25097_25098 : H12AffineEnvironment.transform 21 419913 env25097 = env25098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env25097 == env25098) = true)

def env25099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58396,272393,16,41310,8192,64,10508,57676,45404,294993,1364,272393,256,41340,16465,513]

theorem envBound25099 : H12AffineFastState.Bounded env25099 := by
  intro p hp
  have h : env25099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25098_25099 : H12AffineEnvironment.transform 16 16448 env25098 = env25099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env25098 == env25099) = true)

theorem identity25099 : scanCanonicalize (H12AffineFastState.compose env25099 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound25099 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,8203,16448,262144,1024,8461,17680,272393,16,82,8192,64,10508,16448,4176,270685,1364,272393,256,112,16465,513]

theorem envBound25100 : H12AffineFastState.Bounded env25100 := by
  intro p hp
  have h : env25100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25099_25100 : H12AffineEnvironment.transform 14 8460 env25099 = env25100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env25099 == env25100) = true)

theorem identity25100 : scanCanonicalize (H12AffineFastState.compose env25100 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25100 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env25101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16448,262144,1024,80,17680,264532,16,82,349,64,2129,16448,4176,262144,1364,264532,256,112,16465,513]

theorem envBound25101 : H12AffineFastState.Bounded env25101 := by
  intro p hp
  have h : env25101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25100_25101 : H12AffineEnvironment.transform 12 349 env25100 = env25101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25100 == env25101) = true)

theorem identity25101 : scanCanonicalize (H12AffineFastState.compose env25101 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound25101 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16448,2420,1024,80,17680,32,16,82,349,64,2129,16448,4176,2420,1364,32,256,112,16465,513]

theorem envBound25102 : H12AffineFastState.Bounded env25102 := by
  intro p hp
  have h : env25102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25101_25102 : H12AffineEnvironment.transform 17 2420 env25101 = env25102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env25101 == env25102) = true)

theorem identity25102 : scanCanonicalize (H12AffineFastState.compose env25102 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25102 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25103 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1024,0,17680,32,16,2,269,16,2049,16400,4096,2340,1284,32,256,32,16385,513]

theorem envBound25103 : H12AffineFastState.Bounded env25103 := by
  intro p hp
  have h : env25103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25102_25103 : H12AffineEnvironment.transform 5 16 env25102 = env25103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25102 == env25103) = true)

theorem identity25103 : scanCanonicalize (H12AffineFastState.compose env25103 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25104 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,16384,1,262,16400,2308,1024,0,17680,0,16,2,269,16,2049,16400,4096,2308,1284,0,256,0,16385,513]

theorem envBound25104 : H12AffineFastState.Bounded env25104 := by
  intro p hp
  have h : env25104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25103_25104 : H12AffineEnvironment.transform 4 0 env25103 = env25104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25103 == env25104) = true)

theorem identity25104 : scanCanonicalize (H12AffineFastState.compose env25104 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25104 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25105 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,16,269,16384,1,262,16400,2308,1024,0,17680,0,16,2,269,16,2049,16400,16,2308,1284,0,256,0,16385,513]

theorem envBound25105 : H12AffineFastState.Bounded env25105 := by
  intro p hp
  have h : env25105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25104_25105 : H12AffineEnvironment.transform 11 16 env25104 = env25105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25104 == env25105) = true)

theorem identity25105 : scanCanonicalize (H12AffineFastState.compose env25105 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound25105 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25106 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,16,269,1808,1,262,1792,2308,1024,0,512,0,16,2,269,16,2049,1792,16,2308,1284,0,256,0,1809,513]

theorem envBound25106 : H12AffineFastState.Bounded env25106 := by
  intro p hp
  have h : env25106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25105_25106 : H12AffineEnvironment.transform 13 1808 env25105 = env25106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env25105 == env25106) = true)

theorem identity25106 : scanCanonicalize (H12AffineFastState.compose env25106 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound25106 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25107 : List Nat := [2,4,8,16,0,16,8,256,512,1024,528,16,269,1808,1,262,1792,788,1024,0,512,0,16,2,269,16,529,1792,16,788,1284,0,256,0,1809,513]

theorem envBound25107 : H12AffineFastState.Bounded env25107 := by
  intro p hp
  have h : env25107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25106_25107 : H12AffineEnvironment.transform 10 528 env25106 = env25107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env25106 == env25107) = true)

theorem identity25107 : scanCanonicalize (H12AffineFastState.compose env25107 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound25107 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25108 : List Nat := [2,4,8,16,0,16,8,256,512,257,528,16,269,529,1,262,513,788,257,0,512,0,16,2,269,16,529,513,16,788,5,0,256,0,528,513]

theorem envBound25108 : H12AffineFastState.Bounded env25108 := by
  intro p hp
  have h : env25108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25107_25108 : H12AffineEnvironment.transform 9 257 env25107 = env25108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env25107 == env25108) = true)

theorem identity25108 : scanCanonicalize (H12AffineFastState.compose env25108 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound25108 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25109 : List Nat := [2,4,8,16,0,16,8,256,260,257,276,16,269,277,1,262,261,16,257,0,260,0,16,2,269,16,277,261,16,16,5,0,256,0,276,261]

theorem envBound25109 : H12AffineFastState.Bounded env25109 := by
  intro p hp
  have h : env25109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25108_25109 : H12AffineEnvironment.transform 8 260 env25108 = env25109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env25108 == env25109) = true)

def env25110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58396,272392,16,41310,8192,64,10508,57676,45404,294992,1364,272392,256,41340,16465,513]

theorem envBound25110 : H12AffineFastState.Bounded env25110 := by
  intro p hp
  have h : env25110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25098_25110 : H12AffineEnvironment.transform 16 16449 env25098 = env25110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env25098 == env25110) = true)

theorem identity25110 : scanCanonicalize (H12AffineFastState.compose env25110 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound25110 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16449,262144,1024,1,25628,272392,16,8542,8192,64,10508,24908,12636,262224,1364,272392,256,8572,16465,513]

theorem envBound25111 : H12AffineFastState.Bounded env25111 := by
  intro p hp
  have h : env25111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25110_25111 : H12AffineEnvironment.transform 14 0 env25110 = env25111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env25110 == env25111) = true)

theorem identity25111 : scanCanonicalize (H12AffineFastState.compose env25111 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound25111 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16449,10361,1024,1,25628,113,16,8542,8192,64,10508,24908,12636,10281,1364,113,256,8572,16465,513]

theorem envBound25112 : H12AffineFastState.Bounded env25112 := by
  intro p hp
  have h : env25112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25111_25112 : H12AffineEnvironment.transform 17 10361 env25111 = env25112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env25111 == env25112) = true)

theorem identity25112 : scanCanonicalize (H12AffineFastState.compose env25112 (packedSelected [11,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25112 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env25113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,262,16449,2420,1024,1,17681,113,16,83,269,64,2049,16449,4177,2340,1364,113,256,113,16465,513]

theorem envBound25113 : H12AffineFastState.Bounded env25113 := by
  intro p hp
  have h : env25113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25112_25113 : H12AffineEnvironment.transform 12 269 env25112 = env25113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25112 == env25113) = true)

theorem identity25113 : scanCanonicalize (H12AffineFastState.compose env25113 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound25113 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env25114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,81,0,262,16,2420,1024,1,1344,113,16,83,269,64,2049,16,4177,2340,1364,113,256,113,0,513]

theorem envBound25114 : H12AffineFastState.Bounded env25114 := by
  intro p hp
  have h : env25114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25113_25114 : H12AffineEnvironment.transform 13 81 env25113 = env25114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env25113 == env25114) = true)

theorem identity25114 : scanCanonicalize (H12AffineFastState.compose env25114 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25114 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env25115 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,1,0,262,16,2340,1024,1,1296,33,16,3,269,16,2049,16,4097,2340,1284,33,256,33,0,513]

theorem envBound25115 : H12AffineFastState.Bounded env25115 := by
  intro p hp
  have h : env25115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25114_25115 : H12AffineEnvironment.transform 5 16 env25114 = env25115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25114 == env25115) = true)

theorem identity25115 : scanCanonicalize (H12AffineFastState.compose env25115 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25116 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,4096,269,1,0,262,1,2340,1024,1,1281,33,1,3,269,1,2049,1,4097,2340,1284,33,256,33,0,513]

theorem envBound25116 : H12AffineFastState.Bounded env25116 := by
  intro p hp
  have h : env25116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25115_25116 : H12AffineEnvironment.transform 3 1 env25115 = env25116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25115 == env25116) = true)

theorem identity25116 : scanCanonicalize (H12AffineFastState.compose env25116 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound25116 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25117 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,2351,269,1,0,262,1,2340,1024,1,1281,33,1,3,269,1,2049,1,2350,2340,1284,33,256,33,0,513]

theorem envBound25117 : H12AffineFastState.Bounded env25117 := by
  intro p hp
  have h : env25117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25116_25117 : H12AffineEnvironment.transform 11 2351 env25116 = env25117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env25116 == env25117) = true)

theorem identity25117 : scanCanonicalize (H12AffineFastState.compose env25117 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25117 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25118 : List Nat := [2,4,8,1,32,1,8,4,512,1024,2048,2091,9,1,0,2,1,2080,1024,1,1029,33,1,3,9,1,2049,1,2090,2080,1024,33,4,33,0,513]

theorem envBound25118 : H12AffineFastState.Bounded env25118 := by
  intro p hp
  have h : env25118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25117_25118 : H12AffineEnvironment.transform 7 4 env25117 = env25118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25117 == env25118) = true)

theorem identity25118 : scanCanonicalize (H12AffineFastState.compose env25118 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound25118 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25119 : List Nat := [2,4,8,1,32,1,8,4,512,1024,1038,1061,9,1,0,2,1,1070,1024,1,1029,33,1,3,9,1,1039,1,1060,1070,1024,33,4,33,0,513]

theorem envBound25119 : H12AffineFastState.Bounded env25119 := by
  intro p hp
  have h : env25119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25118_25119 : H12AffineEnvironment.transform 10 1038 env25118 = env25119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env25118 == env25119) = true)

theorem identity25119 : scanCanonicalize (H12AffineFastState.compose env25119 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound25119 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25120 : List Nat := [2,4,8,1,10,1,8,4,512,1024,1038,1039,9,1,0,2,1,1028,1024,1,1029,11,1,3,9,1,1039,1,1038,1028,1024,11,4,11,0,513]

theorem envBound25120 : H12AffineFastState.Bounded env25120 := by
  intro p hp
  have h : env25120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25119_25120 : H12AffineEnvironment.transform 4 10 env25119 = env25120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env25119 == env25120) = true)

def env25121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8192,64,4677966,115014,45405,442385,75103,4268042,256,98678,90203,513]

theorem envBound25121 : H12AffineFastState.Bounded env25121 := by
  intro p hp
  have h : env25121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25095_25121 : H12AffineEnvironment.transform 20 58397 env25095 = env25121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env25095 == env25121) = true)

def env25122 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8192,16,4677918,114966,45325,442385,75023,4268042,256,98598,90123,513]

theorem envBound25122 : H12AffineFastState.Bounded env25122 := by
  intro p hp
  have h : env25122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25121_25122 : H12AffineEnvironment.transform 5 16 env25121 = env25122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25121 == env25122) = true)

def env25123 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8192,16,4409654,114966,45325,190521,75023,4268042,256,98598,90123,513]

theorem envBound25123 : H12AffineFastState.Bounded env25123 := by
  intro p hp
  have h : env25123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25122_25123 : H12AffineEnvironment.transform 17 10280 env25122 = env25123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25122 == env25123) = true)

theorem identity25123 : scanCanonicalize (H12AffineFastState.compose env25123 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound25123 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env25124 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118034,16,41230,8192,16,164900,114966,45325,190521,75023,60696,256,98598,90123,513]

theorem envBound25124 : H12AffineFastState.Bounded env25124 := by
  intro p hp
  have h : env25124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25123_25124 : H12AffineEnvironment.transform 21 118034 env25123 = env25124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env25123 == env25124) = true)

theorem identity25124 : scanCanonicalize (H12AffineFastState.compose env25124 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25124 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env25125 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,118034,16,41230,8192,16,123967,114966,45325,100386,75023,60696,256,98598,90123,513]

theorem envBound25125 : H12AffineFastState.Bounded env25125 := by
  intro p hp
  have h : env25125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25124_25125 : H12AffineEnvironment.transform 16 90139 env25124 = env25125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25124 == env25125) = true)

theorem identity25125 : scanCanonicalize (H12AffineFastState.compose env25125 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11293) := by decide +kernel

theorem selectedBound25125 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env25126 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11293,65536,90139,10280,1024,11292,18432,90383,16,3347,8192,16,84002,93451,7440,74815,75023,16645,256,77115,90123,513]

theorem envBound25126 : H12AffineFastState.Bounded env25126 := by
  intro p hp
  have h : env25126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25125_25126 : H12AffineEnvironment.transform 14 11293 env25125 = env25126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11293 env25125 == env25126) = true)

theorem identity25126 : scanCanonicalize (H12AffineFastState.compose env25126 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25126 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25127 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11293,8202,16401,10280,1024,11292,18432,16645,16,3347,8192,16,26664,19713,7440,1077,1285,16645,256,3377,16385,513]

theorem envBound25127 : H12AffineFastState.Bounded env25127 := by
  intro p hp
  have h : env25127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25126_25127 : H12AffineEnvironment.transform 15 8202 env25126 = env25127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25126 == env25127) = true)

theorem identity25127 : scanCanonicalize (H12AffineFastState.compose env25127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25128 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4113,11293,8202,4096,10280,1024,11292,6161,4372,16,3347,8192,16,14393,7440,7440,1077,1285,4372,256,3377,4112,513]

theorem envBound25128 : H12AffineFastState.Bounded env25128 := by
  intro p hp
  have h : env25128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25127_25128 : H12AffineEnvironment.transform 13 4113 env25127 = env25128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25127 == env25128) = true)

theorem identity25128 : scanCanonicalize (H12AffineFastState.compose env25128 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound25128 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25129 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5417,4113,6452,5411,4096,7425,1024,6453,6161,4372,16,3347,5417,16,3344,7440,7440,1077,1285,4372,256,3377,4112,513]

theorem envBound25129 : H12AffineFastState.Bounded env25129 := by
  intro p hp
  have h : env25129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25128_25129 : H12AffineEnvironment.transform 12 5417 env25128 = env25129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env25128 == env25129) = true)

theorem identity25129 : scanCanonicalize (H12AffineFastState.compose env25129 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound25129 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env25130 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,2088,3344,1077,2082,3329,0,1024,1076,1296,3093,16,3347,2088,16,3344,17,17,1077,1285,3093,256,3377,3345,513]

theorem envBound25130 : H12AffineFastState.Bounded env25130 := by
  intro p hp
  have h : env25130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25129_25130 : H12AffineEnvironment.transform 11 3329 env25129 = env25130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env25129 == env25130) = true)

theorem identity25130 : scanCanonicalize (H12AffineFastState.compose env25130 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound25130 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env25131 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1588,821,1564,804,1077,1558,821,0,1024,1076,1296,545,16,807,1564,16,804,17,17,1077,1285,545,256,773,805,513]

theorem envBound25131 : H12AffineFastState.Bounded env25131 := by
  intro p hp
  have h : env25131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25130_25131 : H12AffineEnvironment.transform 10 1588 env25130 = env25131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env25130 == env25131) = true)

theorem identity25131 : scanCanonicalize (H12AffineFastState.compose env25131 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25131 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25132 : List Nat := [2,4,8,16,32,16,8,256,512,52,512,821,552,804,1,546,821,0,52,0,292,545,16,807,552,16,804,17,17,1,305,545,256,773,805,513]

theorem envBound25132 : H12AffineFastState.Bounded env25132 := by
  intro p hp
  have h : env25132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25131_25132 : H12AffineEnvironment.transform 9 52 env25131 = env25132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25131 == env25132) = true)

theorem identity25132 : scanCanonicalize (H12AffineFastState.compose env25132 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25132 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25133 : List Nat := [2,4,8,16,32,16,8,37,512,52,512,528,552,513,1,546,528,0,52,0,1,545,16,514,552,16,513,17,17,1,20,545,37,544,512,513]

theorem envBound25133 : H12AffineFastState.Bounded env25133 := by
  intro p hp
  have h : env25133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25132_25133 : H12AffineEnvironment.transform 7 37 env25132 = env25133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25132 == env25133) = true)

theorem identity25133 : scanCanonicalize (H12AffineFastState.compose env25133 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25134 : List Nat := [2,4,8,16,16,16,8,21,512,4,512,528,536,513,1,530,528,0,4,0,1,529,16,514,536,16,513,17,17,1,20,529,21,528,512,513]

theorem envBound25134 : H12AffineFastState.Bounded env25134 := by
  intro p hp
  have h : env25134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25133_25134 : H12AffineEnvironment.transform 4 16 env25133 = env25134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25133 == env25134) = true)

theorem identity25134 : scanCanonicalize (H12AffineFastState.compose env25134 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25134 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25135 : List Nat := [2,4,8,16,16,16,8,21,0,4,0,16,24,1,1,18,16,0,4,0,1,17,16,2,24,16,1,17,17,1,20,17,21,16,0,1]

theorem envBound25135 : H12AffineFastState.Bounded env25135 := by
  intro p hp
  have h : env25135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25134_25135 : H12AffineEnvironment.transform 8 0 env25134 = env25135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25134 == env25135) = true)

theorem identity25135 : scanCanonicalize (H12AffineFastState.compose env25135 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25136 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,1,9,1,1,3,1,0,4,0,1,0,1,2,9,1,1,0,0,1,5,0,4,1,0,1]

theorem envBound25136 : H12AffineFastState.Bounded env25136 := by
  intro p hp
  have h : env25136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25135_25136 : H12AffineEnvironment.transform 3 1 env25135 = env25136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25135 == env25136) = true)

def env25137 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8192,16,4409655,114966,45325,190520,75023,4268042,256,98598,90123,513]

theorem envBound25137 : H12AffineFastState.Bounded env25137 := by
  intro p hp
  have h : env25137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25122_25137 : H12AffineEnvironment.transform 17 10281 env25122 = env25137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25122 == env25137) = true)

theorem identity25137 : scanCanonicalize (H12AffineFastState.compose env25137 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound25137 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env25138 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246071,16,41230,8192,16,34816,114966,45325,190520,75023,188733,256,98598,90123,513]

theorem envBound25138 : H12AffineFastState.Bounded env25138 := by
  intro p hp
  have h : env25138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25137_25138 : H12AffineEnvironment.transform 21 246071 env25137 = env25138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env25137 == env25138) = true)

theorem identity25138 : scanCanonicalize (H12AffineFastState.compose env25138 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound25138 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env25139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,114966,10281,1024,32769,58397,33,16,41230,8192,16,34816,114966,45325,76078,75023,73771,256,98598,90123,513]

theorem envBound25139 : H12AffineFastState.Bounded env25139 := by
  intro p hp
  have h : env25139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25138_25139 : H12AffineEnvironment.transform 16 114966 env25138 = env25139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env25138 == env25139) = true)

theorem identity25139 : scanCanonicalize (H12AffineFastState.compose env25139 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound25139 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,49169,10281,1024,32769,58397,33,16,41230,8192,16,34816,49169,45325,10281,9224,8492,256,32801,24844,513]

theorem envBound25140 : H12AffineFastState.Bounded env25140 := by
  intro p hp
  have h : env25140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25139_25140 : H12AffineEnvironment.transform 15 263 env25139 = env25140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env25139 == env25140) = true)

theorem identity25140 : scanCanonicalize (H12AffineFastState.compose env25140 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25140 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,24860,10281,1024,8460,17680,33,16,3,8192,16,10509,24860,4096,10281,9224,8492,256,8492,24844,513]

theorem envBound25141 : H12AffineFastState.Bounded env25141 := by
  intro p hp
  have h : env25141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25140_25141 : H12AffineEnvironment.transform 14 8461 env25140 = env25141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env25140 == env25141) = true)

theorem identity25141 : scanCanonicalize (H12AffineFastState.compose env25141 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25141 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16400,2341,1024,0,17680,33,16,3,268,16,2049,16400,4096,2341,1284,32,256,32,16384,513]

theorem envBound25142 : H12AffineFastState.Bounded env25142 := by
  intro p hp
  have h : env25142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25141_25142 : H12AffineEnvironment.transform 12 268 env25141 = env25142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25141 == env25142) = true)

theorem identity25142 : scanCanonicalize (H12AffineFastState.compose env25142 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25142 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25143 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,16,268,16384,1,263,16400,2341,1024,0,17680,33,16,3,268,16,2049,16400,16,2341,1284,32,256,32,16384,513]

theorem envBound25143 : H12AffineFastState.Bounded env25143 := by
  intro p hp
  have h : env25143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25142_25143 : H12AffineEnvironment.transform 11 16 env25142 = env25143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25142 == env25143) = true)

theorem identity25143 : scanCanonicalize (H12AffineFastState.compose env25143 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25143 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25144 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,16,268,16384,1,263,16400,2341,272,0,16384,33,16,3,268,16,2049,16400,16,2341,20,32,256,32,16384,513]

theorem envBound25144 : H12AffineFastState.Bounded env25144 := by
  intro p hp
  have h : env25144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25143_25144 : H12AffineEnvironment.transform 9 272 env25143 = env25144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25143 == env25144) = true)

theorem identity25144 : scanCanonicalize (H12AffineFastState.compose env25144 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25144 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25145 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,16,268,16384,1,263,16400,292,272,0,16384,33,16,3,268,16,0,16400,16,292,20,32,256,32,16384,513]

theorem envBound25145 : H12AffineFastState.Bounded env25145 := by
  intro p hp
  have h : env25145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25144_25145 : H12AffineEnvironment.transform 10 1 env25144 = env25145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25144 == env25145) = true)

theorem identity25145 : scanCanonicalize (H12AffineFastState.compose env25145 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25145 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env25146 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,16384,1,34,16400,1,53,0,16384,33,16,3,41,16,0,16400,16,1,20,32,37,32,16384,513]

theorem envBound25146 : H12AffineFastState.Bounded env25146 := by
  intro p hp
  have h : env25146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25145_25146 : H12AffineEnvironment.transform 7 37 env25145 = env25146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25145 == env25146) = true)

def env25147 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8192,17,4677919,114967,45324,442385,75022,4268042,256,98599,90122,513]

theorem envBound25147 : H12AffineFastState.Bounded env25147 := by
  intro p hp
  have h : env25147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25121_25147 : H12AffineEnvironment.transform 5 17 env25121 = env25147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25121 == env25147) = true)

theorem identity25147 : scanCanonicalize (H12AffineFastState.compose env25147 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25147 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env25148 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4409654,114967,45324,190520,75022,4268042,256,98599,90122,513]

theorem envBound25148 : H12AffineFastState.Bounded env25148 := by
  intro p hp
  have h : env25148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25147_25148 : H12AffineEnvironment.transform 17 10281 env25147 = env25148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25147 == env25148) = true)

theorem identity25148 : scanCanonicalize (H12AffineFastState.compose env25148 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound25148 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env25149 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4385084,24861,45324,190520,34052,4227072,256,8493,49152,513]

theorem envBound25149 : H12AffineFastState.Bounded env25149 := by
  intro p hp
  have h : env25149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25148_25149 : H12AffineEnvironment.transform 15 40970 env25148 = env25149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env25148 == env25149) = true)

theorem identity25149 : scanCanonicalize (H12AffineFastState.compose env25149 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound25149 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25150 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,147505,16,41231,8192,17,43277,24861,45324,190520,34052,180273,256,8493,49152,513]

theorem envBound25150 : H12AffineFastState.Bounded env25150 := by
  intro p hp
  have h : env25150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25149_25150 : H12AffineEnvironment.transform 21 147505 env25149 = env25150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env25149 == env25150) = true)

theorem identity25150 : scanCanonicalize (H12AffineFastState.compose env25150 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound25150 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25151 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,24861,10281,1024,32769,58397,8492,16,41231,8192,17,43277,24861,45324,35109,34052,41260,256,8493,49152,513]

theorem envBound25151 : H12AffineFastState.Bounded env25151 := by
  intro p hp
  have h : env25151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25150_25151 : H12AffineEnvironment.transform 16 24861 env25150 = env25151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env25150 == env25151) = true)

def env25152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,16777216,8193,64,21479441,18973700,2118977,442384,16876544,23160136,256,18990133,18949401,16819039]

theorem envBound25152 : H12AffineFastState.Bounded env25152 := by
  intro p hp
  have h : env25152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25093_25152 : H12AffineEnvironment.transform 6 9 env25093 = env25152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25093 == env25152) = true)

theorem identity25152 : scanCanonicalize (H12AffineFastState.compose env25152 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound25152 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env25153 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,272426,8193,64,4450363,2468910,2118977,442384,371754,6638946,256,2485279,2428211,297845]

theorem envBound25153 : H12AffineFastState.Bounded env25153 := by
  intro p hp
  have h : env25153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25152_25153 : H12AffineEnvironment.transform 23 272426 env25152 = env25153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env25152 == env25153) = true)

theorem identity25153 : scanCanonicalize (H12AffineFastState.compose env25153 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25153 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env25154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,272426,8193,64,4229152,2468910,2118977,368651,371754,6638946,256,2485279,2428211,297845]

theorem envBound25154 : H12AffineFastState.Bounded env25154 := by
  intro p hp
  have h : env25154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25153_25154 : H12AffineEnvironment.transform 16 90139 env25153 = env25154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25153 == env25154) = true)

def env25155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1024,32769,2097152,4194304,17,41310,8193,64,4229152,2172250,2118977,76159,75102,6407190,256,2188651,2196551,513]

theorem envBound25155 : H12AffineFastState.Bounded env25155 := by
  intro p hp
  have h : env25155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25154_25155 : H12AffineEnvironment.transform 17 35188 env25154 = env25155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env25154 == env25155) = true)

theorem identity25155 : scanCanonicalize (H12AffineFastState.compose env25155 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound25155 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30776,1024,29005,2097152,4194304,17,20498,8193,64,4225388,2172250,2118977,76159,75102,6370650,256,2188651,2192651,513]

theorem envBound25156 : H12AffineFastState.Bounded env25156 := by
  intro p hp
  have h : env25156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25155_25156 : H12AffineEnvironment.transform 14 29004 env25155 = env25156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env25155 == env25156) = true)

def env25157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30776,1024,29005,5456,4194304,17,20498,8193,64,4225388,77834,16401,76159,75102,4268042,256,94267,90203,513]

theorem envBound25157 : H12AffineFastState.Bounded env25157 := by
  intro p hp
  have h : env25157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25156_25157 : H12AffineEnvironment.transform 20 5456 env25156 = env25157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env25156 == env25157) = true)

theorem identity25157 : scanCanonicalize (H12AffineFastState.compose env25157 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound25157 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30776,1024,29005,5456,73770,17,20498,8193,64,88390,77834,16401,76159,75102,32,256,94267,90203,513]

theorem envBound25158 : H12AffineFastState.Bounded env25158 := by
  intro p hp
  have h : env25158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25157_25158 : H12AffineEnvironment.transform 21 73770 env25157 = env25158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env25157 == env25158) = true)

theorem identity25158 : scanCanonicalize (H12AffineFastState.compose env25158 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound25158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,65536,77835,10280,1024,8541,5456,73770,17,2,8193,64,67926,77834,4097,76159,75102,32,256,73771,77899,513]

theorem envBound25159 : H12AffineFastState.Bounded env25159 := by
  intro p hp
  have h : env25159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25158_25159 : H12AffineEnvironment.transform 13 4112 env25158 = env25159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env25158 == env25159) = true)

theorem identity25159 : scanCanonicalize (H12AffineFastState.compose env25159 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound25159 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env25160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,8192,3172,8540,65536,76927,10280,1024,8541,2340,73770,17,2,8193,64,67926,76926,3189,76159,75102,32,256,73771,76863,513]

theorem envBound25160 : H12AffineFastState.Bounded env25160 := by
  intro p hp
  have h : env25160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25159_25160 : H12AffineEnvironment.transform 11 3188 env25159 = env25160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env25159 == env25160) = true)

def env25161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30776,1024,29005,5457,4194304,17,20498,8193,64,4225388,77835,16400,76159,75102,4268043,256,94266,90202,513]

theorem envBound25161 : H12AffineFastState.Bounded env25161 := by
  intro p hp
  have h : env25161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25156_25161 : H12AffineEnvironment.transform 20 5457 env25156 = env25161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env25156 == env25161) = true)

theorem identity25161 : scanCanonicalize (H12AffineFastState.compose env25161 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94267) := by decide +kernel

theorem selectedBound25161 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30776,1024,29005,5457,94267,17,20498,8193,64,67927,77835,16400,76159,75102,20528,256,94266,90202,513]

theorem envBound25162 : H12AffineFastState.Bounded env25162 := by
  intro p hp
  have h : env25162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25161_25162 : H12AffineEnvironment.transform 21 94267 env25161 = env25162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94267 env25161 == env25162) = true)

theorem identity25162 : scanCanonicalize (H12AffineFastState.compose env25162 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25162 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30776,1024,29005,5457,20528,17,20498,8193,64,10588,4096,16400,2420,1365,20528,256,20529,16465,513]

theorem envBound25163 : H12AffineFastState.Bounded env25163 := by
  intro p hp
  have h : env25163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25162_25163 : H12AffineEnvironment.transform 15 8203 env25162 = env25163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25162 == env25163) = true)

theorem identity25163 : scanCanonicalize (H12AffineFastState.compose env25163 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25163 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,8203,4097,10281,1024,8540,5457,33,17,3,8193,64,10588,4096,4097,2420,1365,33,256,32,4160,513]

theorem envBound25164 : H12AffineFastState.Bounded env25164 := by
  intro p hp
  have h : env25164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25163_25164 : H12AffineEnvironment.transform 13 4113 env25163 = env25164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25163 == env25164) = true)

def env25165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1024,32769,2097152,4194304,17,41311,8193,64,4229152,2172251,2118977,76158,75103,6407191,256,2188650,2196550,512]

theorem envBound25165 : H12AffineFastState.Bounded env25165 := by
  intro p hp
  have h : env25165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25154_25165 : H12AffineEnvironment.transform 17 35189 env25154 = env25165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env25154 == env25165) = true)

theorem identity25165 : scanCanonicalize (H12AffineFastState.compose env25165 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound25165 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1024,32769,17461,4194304,17,41311,8193,64,4229152,90478,4468,76158,75103,4292642,256,74079,114803,512]

theorem envBound25166 : H12AffineFastState.Bounded env25166 := by
  intro p hp
  have h : env25166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25165_25166 : H12AffineEnvironment.transform 20 17461 env25165 = env25166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env25165 == env25166) = true)

theorem identity25166 : scanCanonicalize (H12AffineFastState.compose env25166 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound25166 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,65536,78959,35189,1024,32769,4161,4194304,17,41311,8193,64,4229152,79130,4468,76158,75103,4292642,256,74079,103431,512]

theorem envBound25167 : H12AffineFastState.Bounded env25167 := by
  intro p hp
  have h : env25167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25166_25167 : H12AffineEnvironment.transform 13 5236 env25166 = env25167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env25166 == env25167) = true)

theorem identity25167 : scanCanonicalize (H12AffineFastState.compose env25167 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound25167 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,65536,78959,35189,1024,32769,4161,73738,17,41311,8193,64,108586,79130,4468,76158,75103,41000,256,74079,103431,512]

theorem envBound25168 : H12AffineFastState.Bounded env25168 := by
  intro p hp
  have h : env25168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25167_25168 : H12AffineEnvironment.transform 21 73738 env25167 = env25168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env25167 == env25168) = true)

theorem identity25168 : scanCanonicalize (H12AffineFastState.compose env25168 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 33142) := by decide +kernel

theorem selectedBound25168 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env25169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33142,46361,35189,1024,32769,4161,41340,17,41311,8193,64,10588,46188,4468,43016,42025,41000,256,41001,5489,512]

theorem envBound25169 : H12AffineFastState.Bounded env25169 := by
  intro p hp
  have h : env25169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25168_25169 : H12AffineEnvironment.transform 15 33142 env25168 = env25169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33142 env25168 == env25169) = true)

theorem identity25169 : scanCanonicalize (H12AffineFastState.compose env25169 (packedSelected [6,14,17,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25169 : packedSelected [6,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env25170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,32768,33142,38192,35189,1024,32769,4161,33109,17,33142,40,64,2421,37957,4468,34849,33792,32769,256,32768,5489,512]

theorem envBound25170 : H12AffineFastState.Bounded env25170 := by
  intro p hp
  have h : env25170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25169_25170 : H12AffineEnvironment.transform 12 41 env25169 = env25170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25169 == env25170) = true)

theorem identity25170 : scanCanonicalize (H12AffineFastState.compose env25170 (packedSelected [3,5,6,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound25170 : packedSelected [3,5,6,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env25171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,292,82,5140,2129,1024,293,4161,113,17,82,40,64,2421,5473,4468,2309,1316,293,256,292,5489,512]

theorem envBound25171 : H12AffineFastState.Bounded env25171 := by
  intro p hp
  have h : env25171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25170_25171 : H12AffineEnvironment.transform 14 292 env25170 = env25171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env25170 == env25171) = true)

theorem identity25171 : scanCanonicalize (H12AffineFastState.compose env25171 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25171 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25172 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5236,1,82,5140,2129,1024,0,4161,113,17,82,40,64,2128,5188,4177,2080,1025,0,37,1,5204,512]

theorem envBound25172 : H12AffineFastState.Bounded env25172 := by
  intro p hp
  have h : env25172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25171_25172 : H12AffineEnvironment.transform 7 37 env25171 = env25172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25171 == env25172) = true)

theorem identity25172 : scanCanonicalize (H12AffineFastState.compose env25172 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25172 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25173 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,3,5140,2048,1024,0,4112,32,17,3,40,17,2049,5141,4096,2080,1025,0,37,1,5125,512]

theorem envBound25173 : H12AffineFastState.Bounded env25173 := by
  intro p hp
  have h : env25173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25172_25173 : H12AffineEnvironment.transform 5 17 env25172 = env25173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25172 == env25173) = true)

theorem identity25173 : scanCanonicalize (H12AffineFastState.compose env25173 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound25173 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25174 : List Nat := [2,4,8,16,32,17,9,37,512,1024,523,4096,41,5157,1,3,5140,523,1024,0,4112,32,17,3,40,17,522,5141,4096,555,1025,0,37,1,5125,512]

theorem envBound25174 : H12AffineFastState.Bounded env25174 := by
  intro p hp
  have h : env25174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25173_25174 : H12AffineEnvironment.transform 10 523 env25173 = env25174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env25173 == env25174) = true)

theorem identity25174 : scanCanonicalize (H12AffineFastState.compose env25174 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25174 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25175 : List Nat := [2,4,8,16,1,17,9,4,512,1024,523,4096,8,5124,1,3,5140,523,1024,0,4112,1,17,3,9,17,522,5141,4096,522,1025,0,4,1,5125,512]

theorem envBound25175 : H12AffineFastState.Bounded env25175 := by
  intro p hp
  have h : env25175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25174_25175 : H12AffineEnvironment.transform 4 1 env25174 = env25175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25174 == env25175) = true)

def env25176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound25176 : H12AffineFastState.Bounded env25176 := by
  intro p hp
  have h : env25176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25091_25176 : H12AffineEnvironment.transform 18 1025 env25091 = env25176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25091 == env25176) = true)

theorem identity25176 : scanCanonicalize (H12AffineFastState.compose env25176 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 253976) := by decide +kernel

theorem selectedBound25176 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,253976,8328,64,12853273,2253972,10507600,8830976,8545289,6456793,257,10626228,10667280,8602590]

theorem envBound25177 : H12AffineFastState.Bounded env25177 := by
  intro p hp
  have h : env25177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25176_25177 : H12AffineEnvironment.transform 23 253976 env25176 = env25177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 253976 env25176 == env25177) = true)

def env25178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257300,253976,8328,64,6705549,2253972,140484,2404756,2102685,6456793,257,21792,46212,2175562]

theorem envBound25178 : H12AffineFastState.Bounded env25178 := by
  intro p hp
  have h : env25178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25177_25178 : H12AffineEnvironment.transform 22 2257300 env25177 = env25178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257300 env25177 == env25178) = true)

def env25179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257300,253976,8328,64,2157597,2253972,140484,2404756,2102685,2373705,257,21792,46212,2175562]

theorem envBound25179 : H12AffineFastState.Bounded env25179 := by
  intro p hp
  have h : env25179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25178_25179 : H12AffineEnvironment.transform 21 441744 env25178 = env25179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env25178 == env25179) = true)

def env25180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,253976,8328,64,64605,160980,140484,303572,1501,272393,257,21792,46212,74250]

theorem envBound25180 : H12AffineFastState.Bounded env25180 := by
  intro p hp
  have h : env25180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25179_25180 : H12AffineEnvironment.transform 20 4160 env25179 = env25180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25179 == env25180) = true)

theorem identity25180 : scanCanonicalize (H12AffineFastState.compose env25180 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound25180 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,318549,17,98781,8328,64,64605,5393,17665,303572,1501,272393,257,21792,46212,74250]

theorem envBound25181 : H12AffineFastState.Bounded env25181 := by
  intro p hp
  have h : env25181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25180_25181 : H12AffineEnvironment.transform 16 25029 env25180 = env25181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env25180 == env25181) = true)

def env25182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,318549,17,98645,8192,64,64605,5393,17665,303452,1365,272393,257,21792,46092,74250]

theorem envBound25182 : H12AffineFastState.Bounded env25182 := by
  intro p hp
  have h : env25182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25181_25182 : H12AffineEnvironment.transform 6 8 env25181 = env25182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25181 == env25182) = true)

theorem identity25182 : scanCanonicalize (H12AffineFastState.compose env25182 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound25182 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,108926,1025,32769,4160,95531,17,98645,8192,64,64605,5393,17665,67618,1365,98679,257,21792,46092,74250]

theorem envBound25183 : H12AffineFastState.Bounded env25183 := by
  intro p hp
  have h : env25183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25182_25183 : H12AffineEnvironment.transform 17 108926 env25182 = env25183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env25182 == env25183) = true)

theorem identity25183 : scanCanonicalize (H12AffineFastState.compose env25183 (packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound25183 : packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env25184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,65536,16693,100614,1025,32769,4160,87379,17,98645,120,64,56357,5393,17665,67618,1365,98679,257,21792,38004,66162]

theorem envBound25184 : H12AffineFastState.Bounded env25184 := by
  intro p hp
  have h : env25184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25183_25184 : H12AffineEnvironment.transform 12 120 env25183 = env25184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env25183 == env25184) = true)

theorem identity25184 : scanCanonicalize (H12AffineFastState.compose env25184 (packedSelected [1,2,3,5,6,7,8,9,10,11,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound25184 : packedSelected [1,2,3,5,6,7,8,9,10,11,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env25185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,35,16693,35109,1025,32769,4160,21872,17,33142,120,64,56357,5393,17665,2049,1365,33108,257,21792,38004,593]

theorem envBound25185 : H12AffineFastState.Bounded env25185 := by
  intro p hp
  have h : env25185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25184_25185 : H12AffineEnvironment.transform 15 35 env25184 = env25185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env25184 == env25185) = true)

theorem identity25185 : scanCanonicalize (H12AffineFastState.compose env25185 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound25185 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21841,35,16693,23668,1025,21840,4160,21872,17,21543,120,64,2420,5393,17665,2049,1365,21509,257,21792,16677,593]

theorem envBound25186 : H12AffineFastState.Bounded env25186 := by
  intro p hp
  have h : env25186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25185_25186 : H12AffineEnvironment.transform 14 21841 env25185 = env25186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env25185 == env25186) = true)

theorem identity25186 : scanCanonicalize (H12AffineFastState.compose env25186 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound25186 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env25187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,293,35,5441,2048,1025,292,4160,260,17,83,120,64,2420,5393,4469,2049,1365,113,257,340,5457,593]

theorem envBound25187 : H12AffineFastState.Bounded env25187 := by
  intro p hp
  have h : env25187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25186_25187 : H12AffineEnvironment.transform 13 5236 env25186 = env25187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env25186 == env25187) = true)

theorem identity25187 : scanCanonicalize (H12AffineFastState.compose env25187 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25187 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25188 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5236,80,35,5172,2048,1025,81,4160,113,17,83,120,64,2049,5220,4096,2049,1056,113,116,33,5156,593]

theorem envBound25188 : H12AffineFastState.Bounded env25188 := by
  intro p hp
  have h : env25188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25187_25188 : H12AffineEnvironment.transform 7 117 env25187 = env25188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25187 == env25188) = true)

theorem identity25188 : scanCanonicalize (H12AffineFastState.compose env25188 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25188 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25189 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4112,33,17,3,40,16,2049,5172,4096,2049,1056,33,36,33,5156,513]

theorem envBound25189 : H12AffineFastState.Bounded env25189 := by
  intro p hp
  have h : env25189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25188_25189 : H12AffineEnvironment.transform 5 16 env25188 = env25189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25188 == env25189) = true)

theorem identity25189 : scanCanonicalize (H12AffineFastState.compose env25189 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound25189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25190 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1044,0,35,1028,2048,1025,1,32,33,17,3,40,16,2049,1028,48,2049,1056,33,36,33,1044,513]

theorem envBound25190 : H12AffineFastState.Bounded env25190 := by
  intro p hp
  have h : env25190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25189_25190 : H12AffineEnvironment.transform 11 48 env25189 = env25190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env25189 == env25190) = true)

theorem identity25190 : scanCanonicalize (H12AffineFastState.compose env25190 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound25190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25191 : List Nat := [2,4,8,16,32,16,8,37,512,517,2048,48,40,529,0,35,513,2048,516,1,32,33,17,3,40,16,2049,513,48,2049,549,33,36,33,529,513]

theorem envBound25191 : H12AffineFastState.Bounded env25191 := by
  intro p hp
  have h : env25191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25190_25191 : H12AffineEnvironment.transform 9 517 env25190 = env25191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env25190 == env25191) = true)

theorem identity25191 : scanCanonicalize (H12AffineFastState.compose env25191 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound25191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25192 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,48,40,32,0,35,48,2048,53,1,32,33,17,3,40,16,2049,48,48,2049,20,33,36,33,32,48]

theorem envBound25192 : H12AffineFastState.Bounded env25192 := by
  intro p hp
  have h : env25192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25191_25192 : H12AffineEnvironment.transform 8 49 env25191 = env25192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env25191 == env25192) = true)

theorem identity25192 : scanCanonicalize (H12AffineFastState.compose env25192 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25193 : List Nat := [2,4,8,16,17,16,8,20,0,5,2048,1,25,17,0,18,1,2048,4,1,17,16,17,3,25,16,2049,1,1,2049,20,16,21,16,17,1]

theorem envBound25193 : H12AffineFastState.Bounded env25193 := by
  intro p hp
  have h : env25193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25192_25193 : H12AffineEnvironment.transform 4 17 env25192 = env25193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25192 == env25193) = true)

theorem identity25193 : scanCanonicalize (H12AffineFastState.compose env25193 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25193 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25194 : List Nat := [2,4,8,16,17,16,8,20,0,5,0,1,25,17,0,18,1,0,4,1,17,16,17,3,25,16,1,1,1,1,20,16,21,16,17,1]

theorem envBound25194 : H12AffineFastState.Bounded env25194 := by
  intro p hp
  have h : env25194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25193_25194 : H12AffineEnvironment.transform 10 0 env25193 = env25194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25193 == env25194) = true)

theorem identity25194 : scanCanonicalize (H12AffineFastState.compose env25194 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25194 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25195 : List Nat := [2,4,8,0,1,0,8,4,0,5,0,1,9,1,0,2,1,0,4,1,1,0,1,3,9,0,1,1,1,1,4,0,5,0,1,1]

theorem envBound25195 : H12AffineFastState.Bounded env25195 := by
  intro p hp
  have h : env25195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25194_25195 : H12AffineEnvironment.transform 3 0 env25194 = env25195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25194 == env25195) = true)

def env25196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,98644,8193,64,64605,5393,17665,303453,1364,272393,257,21792,46093,74250]

theorem envBound25196 : H12AffineFastState.Bounded env25196 := by
  intro p hp
  have h : env25196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25181_25196 : H12AffineEnvironment.transform 6 9 env25181 = env25196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25181 == env25196) = true)

theorem identity25196 : scanCanonicalize (H12AffineFastState.compose env25196 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound25196 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67618,1025,32769,4160,119927,17,98644,8193,64,64605,5393,17665,108927,1364,73771,257,21792,46093,74250]

theorem envBound25197 : H12AffineFastState.Bounded env25197 := by
  intro p hp
  have h : env25197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25196_25197 : H12AffineEnvironment.transform 17 67618 env25196 = env25197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env25196 == env25197) = true)

theorem identity25197 : scanCanonicalize (H12AffineFastState.compose env25197 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound25197 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env25198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,64808,1025,32769,4160,8573,17,29790,8193,64,64605,5393,17665,23669,1364,54561,257,21792,46093,55040]

theorem envBound25198 : H12AffineFastState.Bounded env25198 := by
  intro p hp
  have h : env25198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25197_25198 : H12AffineEnvironment.transform 15 62730 env25197 = env25198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env25197 == env25198) = true)

theorem identity25198 : scanCanonicalize (H12AffineFastState.compose env25198 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25198 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,16400,56436,1025,32769,4160,33,17,21762,349,64,56577,5393,17665,23669,1364,54561,257,21792,38225,55040]

theorem envBound25199 : H12AffineFastState.Bounded env25199 := by
  intro p hp
  have h : env25199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25198_25199 : H12AffineEnvironment.transform 12 348 env25198 = env25199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25198 == env25199) = true)

theorem identity25199 : scanCanonicalize (H12AffineFastState.compose env25199 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25199 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env25200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21591,16400,23669,1025,0,4160,33,17,21762,349,64,23808,5393,17665,23669,1364,21792,257,21792,5456,22273]

theorem envBound25200 : H12AffineFastState.Bounded env25200 := by
  intro p hp
  have h : env25200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25199_25200 : H12AffineEnvironment.transform 14 1 env25199 = env25200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25199 == env25200) = true)

theorem identity25200 : scanCanonicalize (H12AffineFastState.compose env25200 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound25200 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env25201 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,9,16384,1,21591,16400,23669,1025,0,4160,33,17,21591,8,64,23637,5188,17492,23669,1025,21621,84,21621,5125,22100]

theorem envBound25201 : H12AffineFastState.Bounded env25201 := by
  intro p hp
  have h : env25201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25200_25201 : H12AffineEnvironment.transform 7 85 env25200 = env25201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env25200 == env25201) = true)

def env25202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,253976,8328,64,64604,160981,140484,303573,1500,272392,257,21792,46212,74251]

theorem envBound25202 : H12AffineFastState.Bounded env25202 := by
  intro p hp
  have h : env25202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25179_25202 : H12AffineEnvironment.transform 20 4161 env25179 = env25202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25179 == env25202) = true)

theorem identity25202 : scanCanonicalize (H12AffineFastState.compose env25202 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound25202 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,411972,156117,201932,8328,64,2184,160981,140484,283905,1500,272392,257,21792,16464,74251]

theorem envBound25203 : H12AffineFastState.Bounded env25203 := by
  intro p hp
  have h : env25203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25202_25203 : H12AffineEnvironment.transform 14 29908 env25202 = env25203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env25202 == env25203) = true)

def env25204 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,411924,156037,201884,8328,16,2184,160901,140436,283905,1420,272392,257,21792,16384,74251]

theorem envBound25204 : H12AffineFastState.Bounded env25204 := by
  intro p hp
  have h : env25204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25203_25204 : H12AffineEnvironment.transform 5 16 env25203 = env25204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25203 == env25204) = true)

theorem identity25204 : scanCanonicalize (H12AffineFastState.compose env25204 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound25204 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env25205 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,157753,1025,29829,4113,8493,156037,201884,8328,16,2184,160901,140436,146744,1420,147505,257,21792,16384,74251]

theorem envBound25205 : H12AffineFastState.Bounded env25205 := by
  intro p hp
  have h : env25205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25204_25205 : H12AffineEnvironment.transform 17 157753 env25204 = env25205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env25204 == env25205) = true)

theorem identity25205 : scanCanonicalize (H12AffineFastState.compose env25205 (packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound25205 : packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env25206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79250,89515,1025,29829,4113,8493,87063,8462,8328,16,2184,82199,69894,67754,1420,95651,257,21792,16384,74251]

theorem envBound25206 : H12AffineFastState.Bounded env25206 := by
  intro p hp
  have h : env25206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25205_25206 : H12AffineEnvironment.transform 16 79250 env25205 = env25206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env25205 == env25206) = true)

theorem identity25206 : scanCanonicalize (H12AffineFastState.compose env25206 (packedSelected [0,4,7,10,16,17,20,22,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25206 : packedSelected [0,4,7,10,16,17,20,22,31] rootPS < 2^1333 := by decide +kernel

def env25207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,79250,67755,1025,8581,4113,8493,65815,8462,8328,16,2184,70679,69894,67754,1420,73891,257,32,5376,74251]

theorem envBound25207 : H12AffineFastState.Bounded env25207 := by
  intro p hp
  have h : env25207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25206_25207 : H12AffineEnvironment.transform 13 5376 env25206 = env25207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25206 == env25207) = true)

theorem identity25207 : scanCanonicalize (H12AffineFastState.compose env25207 (packedSelected [0,2,4,6,7,9,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 5537) := by decide +kernel

theorem selectedBound25207 : packedSelected [0,2,4,6,7,9,12,16] rootPS < 2^1333 := by decide +kernel

def env25208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5537,5376,5157,65536,65587,67755,1025,5156,4113,5260,65815,5295,5417,16,2184,70679,69894,67754,1420,70914,257,32,5376,71594]

theorem envBound25208 : H12AffineFastState.Bounded env25208 := by
  intro p hp
  have h : env25208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25207_25208 : H12AffineEnvironment.transform 12 5537 env25207 = env25208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5537 env25207 == env25208) = true)

theorem identity25208 : scanCanonicalize (H12AffineFastState.compose env25208 (packedSelected [1,2,6,8,10,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2311) := by decide +kernel

theorem selectedBound25208 : packedSelected [1,2,6,8,10,17,18] rootPS < 2^1333 := by decide +kernel

def env25209 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5537,5376,5157,2311,2356,428,1025,5156,4113,5260,2064,5295,5417,16,2184,7440,6145,429,1420,7173,257,32,5376,7853]

theorem envBound25209 : H12AffineFastState.Bounded env25209 := by
  intro p hp
  have h : env25209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25208_25209 : H12AffineEnvironment.transform 15 2311 env25208 = env25209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2311 env25208 == env25209) = true)

theorem identity25209 : scanCanonicalize (H12AffineFastState.compose env25209 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25209 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env25210 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,4501,4404,4113,2311,2356,428,53,4112,4113,4280,2064,4251,4381,16,2184,6436,6145,429,440,6193,257,32,4404,6809]

theorem envBound25210 : H12AffineFastState.Bounded env25210 := by
  intro p hp
  have h : env25210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25209_25210 : H12AffineEnvironment.transform 9 52 env25209 = env25210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25209 == env25210) = true)

theorem identity25210 : scanCanonicalize (H12AffineFastState.compose env25210 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound25210 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25211 : List Nat := [2,4,8,16,32,16,128,256,512,52,136,4096,4501,4404,4113,399,444,428,53,4112,4113,4280,152,4251,4381,16,0,4524,4233,429,440,4281,257,32,4404,4625]

theorem envBound25211 : H12AffineFastState.Bounded env25211 := by
  intro p hp
  have h : env25211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25210_25211 : H12AffineEnvironment.transform 10 136 env25210 = env25211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env25210 == env25211) = true)

def env25212 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,411925,156036,201885,8328,17,2184,160900,140437,283905,1421,272392,257,21792,16385,74251]

theorem envBound25212 : H12AffineFastState.Bounded env25212 := by
  intro p hp
  have h : env25212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25203_25212 : H12AffineEnvironment.transform 5 17 env25203 = env25212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25203 == env25212) = true)

theorem identity25212 : scanCanonicalize (H12AffineFastState.compose env25212 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146865) := by decide +kernel

theorem selectedBound25212 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env25213 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,146865,1025,29828,4112,29860,156036,201885,8328,17,2184,160900,140437,157872,1421,136633,257,21792,16385,74251]

theorem envBound25213 : H12AffineFastState.Bounded env25213 := by
  intro p hp
  have h : env25213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25212_25213 : H12AffineEnvironment.transform 17 146865 env25212 = env25213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env25212 == env25213) = true)

theorem identity25213 : scanCanonicalize (H12AffineFastState.compose env25213 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound25213 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env25214 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,16401,32160,1025,29828,4112,29860,8597,87180,8328,17,2184,13461,25732,10401,1421,21928,257,21792,16385,74251]

theorem envBound25214 : H12AffineFastState.Bounded env25214 := by
  intro p hp
  have h : env25214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25213_25214 : H12AffineEnvironment.transform 16 16401 env25213 = env25214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env25213 == env25214) = true)

theorem identity25214 : scanCanonicalize (H12AffineFastState.compose env25214 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25214 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env25215 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,16401,32160,1025,29828,4112,29860,8597,29830,8328,17,2184,13461,25732,10401,1421,21928,257,21792,16385,513]

theorem envBound25215 : H12AffineFastState.Bounded env25215 := by
  intro p hp
  have h : env25215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25214_25215 : H12AffineEnvironment.transform 15 8202 env25214 = env25215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25214 == env25215) = true)

theorem identity25215 : scanCanonicalize (H12AffineFastState.compose env25215 (packedSelected [0,4,7,9,10,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound25215 : packedSelected [0,4,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env25216 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,8192,16384,28080,8202,16401,25749,1025,28081,2341,28049,8597,28083,8328,17,2184,11680,25732,10401,1421,19613,257,19477,16385,513]

theorem envBound25216 : H12AffineFastState.Bounded env25216 := by
  intro p hp
  have h : env25216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25215_25216 : H12AffineEnvironment.transform 11 2357 env25215 = env25216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env25215 == env25216) = true)

theorem identity25216 : scanCanonicalize (H12AffineFastState.compose env25216 (packedSelected [0,1,4,5,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound25216 : packedSelected [0,1,4,5,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env25217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,8192,11577,137,8202,11560,2476,1025,136,2341,168,8597,138,8328,17,2184,11680,2493,10401,1421,8612,257,8492,11576,513]

theorem envBound25217 : H12AffineFastState.Bounded env25217 := by
  intro p hp
  have h : env25217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25216_25217 : H12AffineEnvironment.transform 13 11577 env25216 = env25217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env25216 == env25217) = true)

theorem identity25217 : scanCanonicalize (H12AffineFastState.compose env25217 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound25217 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env25218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,389,3260,137,399,3245,2476,1025,136,2341,168,16,138,269,17,2184,3109,2493,2340,1421,33,257,169,3261,513]

theorem envBound25218 : H12AffineFastState.Bounded env25218 := by
  intro p hp
  have h : env25218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25217_25218 : H12AffineEnvironment.transform 12 389 env25217 = env25218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env25217 == env25218) = true)

theorem identity25218 : scanCanonicalize (H12AffineFastState.compose env25218 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25218 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25219 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2357,389,2476,137,399,2493,2476,273,136,2341,168,16,138,269,17,2184,2357,2493,2340,157,33,257,169,2477,513]

theorem envBound25219 : H12AffineFastState.Bounded env25219 := by
  intro p hp
  have h : env25219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25218_25219 : H12AffineEnvironment.transform 9 272 env25218 = env25219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25218 == env25219) = true)

theorem identity25219 : scanCanonicalize (H12AffineFastState.compose env25219 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25219 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env25220 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,2200,40,2049,137,34,2064,2049,188,136,2184,168,16,138,160,17,2184,2200,2064,2185,157,33,172,169,2048,513]

theorem envBound25220 : H12AffineFastState.Bounded env25220 := by
  intro p hp
  have h : env25220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25219_25220 : H12AffineEnvironment.transform 7 173 env25219 = env25220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25219 == env25220) = true)

theorem identity25220 : scanCanonicalize (H12AffineFastState.compose env25220 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25220 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25221 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,40,2049,1,34,2064,2049,52,0,2048,32,16,2,40,17,2048,2064,2064,2049,21,33,36,33,2048,513]

theorem envBound25221 : H12AffineFastState.Bounded env25221 := by
  intro p hp
  have h : env25221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25220_25221 : H12AffineEnvironment.transform 6 8 env25220 = env25221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25220 == env25221) = true)

theorem identity25221 : scanCanonicalize (H12AffineFastState.compose env25221 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25222 : List Nat := [2,4,8,16,32,17,8,37,0,53,2048,2064,40,2049,1,34,2064,2049,52,0,2048,32,16,2,40,17,2048,2064,2064,2049,21,33,36,33,2048,1]

theorem envBound25222 : H12AffineFastState.Bounded env25222 := by
  intro p hp
  have h : env25222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25221_25222 : H12AffineEnvironment.transform 8 0 env25221 = env25222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25221 == env25222) = true)

theorem identity25222 : scanCanonicalize (H12AffineFastState.compose env25222 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound25222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25223 : List Nat := [2,4,2,16,32,17,2,37,0,53,2048,2064,34,2049,1,34,2064,2049,52,0,2048,32,16,2,34,17,2048,2064,2064,2049,21,33,36,33,2048,1]

theorem envBound25223 : H12AffineFastState.Bounded env25223 := by
  intro p hp
  have h : env25223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25222_25223 : H12AffineEnvironment.transform 2 2 env25222 = env25223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env25222 == env25223) = true)

theorem identity25223 : scanCanonicalize (H12AffineFastState.compose env25223 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25223 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25224 : List Nat := [2,4,2,16,32,17,2,37,0,53,0,16,34,1,1,34,16,1,52,0,0,32,16,2,34,17,0,16,16,1,21,33,36,33,0,1]

theorem envBound25224 : H12AffineFastState.Bounded env25224 := by
  intro p hp
  have h : env25224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25223_25224 : H12AffineEnvironment.transform 10 0 env25223 = env25224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25223 == env25224) = true)

def env25225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257300,253976,8328,64,2157596,2253972,140484,2404756,2102685,2373704,257,21792,46212,2175562]

theorem envBound25225 : H12AffineFastState.Bounded env25225 := by
  intro p hp
  have h : env25225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25178_25225 : H12AffineEnvironment.transform 21 441745 env25178 = env25225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env25178 == env25225) = true)

def env25226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,253976,8328,64,64604,160980,140484,303572,1501,272392,257,21792,46212,74250]

theorem envBound25226 : H12AffineFastState.Bounded env25226 := by
  intro p hp
  have h : env25226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25225_25226 : H12AffineEnvironment.transform 20 4160 env25225 = env25226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25225 == env25226) = true)

def env25227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169401,156116,253976,8328,64,64604,160980,140484,35324,1501,32,257,21792,46212,74250]

theorem envBound25227 : H12AffineFastState.Bounded env25227 := by
  intro p hp
  have h : env25227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25226_25227 : H12AffineEnvironment.transform 17 10280 env25226 = env25227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25226 == env25227) = true)

def env25228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21929,41412,73736,8328,64,64604,46276,58580,35324,1501,32,257,21792,46212,74250]

theorem envBound25228 : H12AffineFastState.Bounded env25228 := by
  intro p hp
  have h : env25228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25227_25228 : H12AffineEnvironment.transform 16 49168 env25227 = env25228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25227 == env25228) = true)

theorem identity25228 : scanCanonicalize (H12AffineFastState.compose env25228 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound25228 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49168,10280,1025,32769,4160,21929,41412,41310,8328,64,64604,46276,58580,35324,1501,32,257,21792,46212,41820]

theorem envBound25229 : H12AffineFastState.Bounded env25229 := by
  intro p hp
  have h : env25229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25228_25229 : H12AffineEnvironment.transform 15 33110 env25228 = env25229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env25228 == env25229) = true)

theorem identity25229 : scanCanonicalize (H12AffineFastState.compose env25229 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25229 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env25230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,16384,32768,33110,49168,2049,1025,32769,4160,21929,33261,33143,161,64,56437,38125,50429,35324,1501,32,257,21792,38061,33653]

theorem envBound25230 : H12AffineFastState.Bounded env25230 := by
  intro p hp
  have h : env25230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25229_25230 : H12AffineEnvironment.transform 12 41 env25229 = env25230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25229 == env25230) = true)

theorem identity25230 : scanCanonicalize (H12AffineFastState.compose env25230 (packedSelected [0,1,5,7,8,9,14,16,18,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound25230 : packedSelected [0,1,5,7,8,9,14,16,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env25231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5373,32768,33110,38125,2049,1025,32769,4160,340,33261,33143,161,64,34952,38125,36864,35324,1501,32,257,477,38061,33653]

theorem envBound25231 : H12AffineFastState.Bounded env25231 := by
  intro p hp
  have h : env25231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25230_25231 : H12AffineEnvironment.transform 13 5373 env25230 = env25231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env25230 == env25231) = true)

theorem identity25231 : scanCanonicalize (H12AffineFastState.compose env25231 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound25231 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env25232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5373,373,35,5528,2049,1025,372,4160,340,152,2,161,64,2557,5528,4469,2185,1501,32,257,477,5592,512]

theorem envBound25232 : H12AffineFastState.Bounded env25232 := by
  intro p hp
  have h : env25232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25231_25232 : H12AffineEnvironment.transform 14 373 env25231 = env25232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env25231 == env25232) = true)

theorem identity25232 : scanCanonicalize (H12AffineFastState.compose env25232 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25232 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25233 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,41,4589,373,35,4232,2049,273,372,4160,340,152,2,161,64,2557,4232,4469,2185,205,32,257,477,4296,512]

theorem envBound25233 : H12AffineFastState.Bounded env25233 := by
  intro p hp
  have h : env25233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25232_25233 : H12AffineEnvironment.transform 9 272 env25232 = env25233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25232 == env25233) = true)

theorem identity25233 : scanCanonicalize (H12AffineFastState.compose env25233 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound25233 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25234 : List Nat := [2,4,8,16,32,64,128,220,512,204,2048,4096,41,4145,169,35,4232,2049,205,168,4160,136,152,2,161,64,2081,4232,4265,2185,205,32,221,1,4296,512]

theorem envBound25234 : H12AffineFastState.Bounded env25234 := by
  intro p hp
  have h : env25234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25233_25234 : H12AffineEnvironment.transform 7 220 env25233 = env25234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env25233 == env25234) = true)

theorem identity25234 : scanCanonicalize (H12AffineFastState.compose env25234 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound25234 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env25235 : List Nat := [2,4,8,16,32,49,128,173,512,189,2048,4096,41,4145,169,35,4232,2049,188,168,4145,136,152,2,161,49,2081,4232,4265,2185,188,32,172,1,4281,512]

theorem envBound25235 : H12AffineFastState.Bounded env25235 := by
  intro p hp
  have h : env25235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25234_25235 : H12AffineEnvironment.transform 5 49 env25234 = env25235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env25234 == env25235) = true)

theorem identity25235 : scanCanonicalize (H12AffineFastState.compose env25235 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound25235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25236 : List Nat := [2,4,8,16,32,49,41,4,512,20,2048,4096,41,4145,0,35,4129,2049,21,1,4145,33,49,2,8,49,2081,4129,4096,2080,21,32,5,1,4112,512]

theorem envBound25236 : H12AffineFastState.Bounded env25236 := by
  intro p hp
  have h : env25236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25235_25236 : H12AffineEnvironment.transform 6 41 env25235 = env25236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env25235 == env25236) = true)

theorem identity25236 : scanCanonicalize (H12AffineFastState.compose env25236 (packedSelected [0,3] rootPS)) = affineNative (2^(11+1) ^^^ 30) := by decide +kernel

theorem selectedBound25236 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env25237 : List Nat := [2,4,8,16,32,49,41,4,512,20,2048,30,41,47,0,35,63,2049,21,1,47,33,49,2,8,49,2081,63,30,2080,21,32,5,1,14,512]

theorem envBound25237 : H12AffineFastState.Bounded env25237 := by
  intro p hp
  have h : env25237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25236_25237 : H12AffineEnvironment.transform 11 30 env25236 = env25237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 30 env25236 == env25237) = true)

theorem identity25237 : scanCanonicalize (H12AffineFastState.compose env25237 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound25237 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env25238 : List Nat := [2,4,8,16,32,49,41,4,512,20,46,30,41,47,0,35,63,47,21,1,47,33,49,2,8,49,15,63,30,14,21,32,5,1,14,512]

theorem envBound25238 : H12AffineFastState.Bounded env25238 := by
  intro p hp
  have h : env25238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25237_25238 : H12AffineEnvironment.transform 10 46 env25237 = env25238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env25237 == env25238) = true)

theorem identity25238 : scanCanonicalize (H12AffineFastState.compose env25238 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound25238 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env25239 : List Nat := [2,4,8,16,15,30,6,4,512,20,1,30,6,0,0,12,16,0,21,1,0,14,30,2,8,30,15,16,30,14,21,15,5,1,14,512]

theorem envBound25239 : H12AffineFastState.Bounded env25239 := by
  intro p hp
  have h : env25239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25238_25239 : H12AffineEnvironment.transform 4 15 env25238 = env25239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env25238 == env25239) = true)

theorem identity25239 : scanCanonicalize (H12AffineFastState.compose env25239 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25239 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25240 : List Nat := [2,4,8,16,15,30,6,4,0,20,1,30,6,0,0,12,16,0,21,1,0,14,30,2,8,30,15,16,30,14,21,15,5,1,14,0]

theorem envBound25240 : H12AffineFastState.Bounded env25240 := by
  intro p hp
  have h : env25240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25239_25240 : H12AffineEnvironment.transform 8 0 env25239 = env25240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25239 == env25240) = true)

theorem identity25240 : scanCanonicalize (H12AffineFastState.compose env25240 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25240 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25241 : List Nat := [2,4,7,16,0,17,6,4,0,20,1,17,6,0,0,3,16,0,21,1,0,1,17,2,7,17,0,16,17,1,21,0,5,1,1,0]

theorem envBound25241 : H12AffineFastState.Bounded env25241 := by
  intro p hp
  have h : env25241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25240_25241 : H12AffineEnvironment.transform 2 7 env25240 = env25241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25240 == env25241) = true)

theorem identity25241 : scanCanonicalize (H12AffineFastState.compose env25241 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25242 : List Nat := [2,4,7,0,0,1,6,4,0,4,1,1,6,0,0,3,0,0,5,1,0,1,1,2,7,1,0,0,1,1,5,0,5,1,1,0]

theorem envBound25242 : H12AffineFastState.Bounded env25242 := by
  intro p hp
  have h : env25242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25241_25242 : H12AffineEnvironment.transform 3 0 env25241 = env25242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25241 == env25242) = true)

def env25243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21928,41413,73737,8328,64,64604,46277,58581,35324,1501,32,257,21792,46212,74250]

theorem envBound25243 : H12AffineFastState.Bounded env25243 := by
  intro p hp
  have h : env25243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25227_25243 : H12AffineEnvironment.transform 16 49169 env25227 = env25243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25227 == env25243) = true)

theorem identity25243 : scanCanonicalize (H12AffineFastState.compose env25243 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound25243 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,49169,10280,1025,32769,4160,21928,41413,41431,8328,64,64604,46277,58581,35324,1501,32,257,21792,46212,41940]

theorem envBound25244 : H12AffineFastState.Bounded env25244 := by
  intro p hp
  have h : env25244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25243_25244 : H12AffineEnvironment.transform 15 33246 env25243 = env25244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env25243 == env25244) = true)

theorem identity25244 : scanCanonicalize (H12AffineFastState.compose env25244 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 20545) := by decide +kernel

theorem selectedBound25244 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env25245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20545,20895,4176,10280,1025,20544,4160,21928,29060,29078,8328,64,11293,25732,13460,22973,1501,32,257,21792,25797,29589]

theorem envBound25245 : H12AffineFastState.Bounded env25245 := by
  intro p hp
  have h : env25245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25244_25245 : H12AffineEnvironment.transform 14 20545 env25244 = env25245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20545 env25244 == env25245) = true)

theorem identity25245 : scanCanonicalize (H12AffineFastState.compose env25245 (packedSelected [0,1,3,4,5,7,8,10,11,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound25245 : packedSelected [0,1,3,4,5,7,8,10,11,19,22,23] rootPS < 2^1333 := by decide +kernel

def env25246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,20545,20895,4176,2265,1025,20544,4160,21928,20853,20839,121,64,3308,17525,5221,22973,1501,32,257,21792,17460,21348]

theorem envBound25246 : H12AffineFastState.Bounded env25246 := by
  intro p hp
  have h : env25246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25245_25246 : H12AffineEnvironment.transform 12 241 env25245 = env25246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env25245 == env25246) = true)

theorem identity25246 : scanCanonicalize (H12AffineFastState.compose env25246 (packedSelected [0,1,2,4,6,7,8,9,11,14,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound25246 : packedSelected [0,1,2,4,6,7,8,9,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env25247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5156,1125,1467,4176,2265,1025,1124,4160,396,1361,1347,121,64,3308,4177,5221,3481,1501,32,257,260,4112,1856]

theorem envBound25247 : H12AffineFastState.Bounded env25247 := by
  intro p hp
  have h : env25247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25246_25247 : H12AffineEnvironment.transform 13 5156 env25246 = env25247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env25246 == env25247) = true)

theorem identity25247 : scanCanonicalize (H12AffineFastState.compose env25247 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound25247 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25248 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,241,4248,217,263,4176,2265,189,216,4160,396,493,511,121,64,2128,4177,4313,2341,353,32,257,260,4112,1020]

theorem envBound25248 : H12AffineFastState.Bounded env25248 := by
  intro p hp
  have h : env25248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25247_25248 : H12AffineEnvironment.transform 9 188 env25247 = env25248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env25247 == env25248) = true)

theorem identity25248 : scanCanonicalize (H12AffineFastState.compose env25248 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25248 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env25249 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,160,4248,136,263,4097,2184,189,137,4113,396,444,430,40,17,2049,4096,4232,2341,304,32,257,260,4112,941]

theorem envBound25249 : H12AffineFastState.Bounded env25249 := by
  intro p hp
  have h : env25249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25248_25249 : H12AffineEnvironment.transform 5 17 env25248 = env25249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25248 == env25249) = true)

theorem identity25249 : scanCanonicalize (H12AffineFastState.compose env25249 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25249 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25250 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,160,4248,136,34,4097,2184,189,137,4113,169,153,139,40,17,2049,4096,4232,2048,21,32,36,33,4112,648]

theorem envBound25250 : H12AffineFastState.Bounded env25250 := by
  intro p hp
  have h : env25250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25249_25250 : H12AffineEnvironment.transform 7 37 env25249 = env25250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25249 == env25250) = true)

theorem identity25250 : scanCanonicalize (H12AffineFastState.compose env25250 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound25250 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25251 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,2233,160,2081,136,34,2232,2184,189,137,2216,169,153,139,40,17,2049,2233,2097,2048,21,32,36,33,2217,648]

theorem envBound25251 : H12AffineFastState.Bounded env25251 := by
  intro p hp
  have h : env25251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25250_25251 : H12AffineEnvironment.transform 11 2233 env25250 = env25251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env25250 == env25251) = true)

theorem identity25251 : scanCanonicalize (H12AffineFastState.compose env25251 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25251 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env25252 : List Nat := [2,4,8,16,32,17,128,37,512,188,1,184,160,32,136,34,185,137,189,137,169,169,153,139,40,17,0,184,48,1,21,32,36,33,168,648]

theorem envBound25252 : H12AffineFastState.Bounded env25252 := by
  intro p hp
  have h : env25252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25251_25252 : H12AffineEnvironment.transform 10 1 env25251 = env25252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25251 == env25252) = true)

theorem identity25252 : scanCanonicalize (H12AffineFastState.compose env25252 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound25252 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env25253 : List Nat := [2,4,8,16,32,17,41,37,512,21,1,17,9,32,33,34,16,32,20,32,0,0,48,34,40,17,0,17,48,1,21,32,36,33,1,545]

theorem envBound25253 : H12AffineFastState.Bounded env25253 := by
  intro p hp
  have h : env25253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25252_25253 : H12AffineEnvironment.transform 6 41 env25252 = env25253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env25252 == env25253) = true)

theorem identity25253 : scanCanonicalize (H12AffineFastState.compose env25253 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25253 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env25254 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,0,3,16,1,20,1,0,0,17,3,9,17,0,17,17,1,21,1,5,0,1,512]

theorem envBound25254 : H12AffineFastState.Bounded env25254 := by
  intro p hp
  have h : env25254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25253_25254 : H12AffineEnvironment.transform 4 1 env25253 = env25254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25253 == env25254) = true)

theorem identity25254 : scanCanonicalize (H12AffineFastState.compose env25254 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound25254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25255 : List Nat := [2,4,8,16,1,17,8,4,5,21,1,17,9,1,0,3,16,1,20,1,0,0,17,3,9,17,0,17,17,1,21,1,5,0,1,5]

theorem envBound25255 : H12AffineFastState.Bounded env25255 := by
  intro p hp
  have h : env25255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25254_25255 : H12AffineEnvironment.transform 8 5 env25254 = env25255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env25254 == env25255) = true)

theorem identity25255 : scanCanonicalize (H12AffineFastState.compose env25255 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound25255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25256 : List Nat := [2,4,8,7,1,6,8,4,5,2,1,6,9,1,0,3,7,1,3,1,0,0,6,3,9,6,0,6,6,1,2,1,5,0,1,5]

theorem envBound25256 : H12AffineFastState.Bounded env25256 := by
  intro p hp
  have h : env25256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25255_25256 : H12AffineEnvironment.transform 3 7 env25255 = env25256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env25255 == env25256) = true)

def env25257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169400,156116,253976,8328,64,64604,160980,140484,35325,1501,33,257,21792,46212,74250]

theorem envBound25257 : H12AffineFastState.Bounded env25257 := by
  intro p hp
  have h : env25257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25226_25257 : H12AffineEnvironment.transform 17 10281 env25226 = env25257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25226 == env25257) = true)

def env25258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21928,41412,73736,8328,64,64604,46276,58580,35325,1501,33,257,21792,46212,74250]

theorem envBound25258 : H12AffineFastState.Bounded env25258 := by
  intro p hp
  have h : env25258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25257_25258 : H12AffineEnvironment.transform 16 49168 env25257 = env25258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25257 == env25258) = true)

theorem identity25258 : scanCanonicalize (H12AffineFastState.compose env25258 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound25258 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1025,32769,4160,21928,41412,138,8328,64,64604,46276,58580,35325,1501,33,257,21792,46212,648]

theorem envBound25259 : H12AffineFastState.Bounded env25259 := by
  intro p hp
  have h : env25259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25258_25259 : H12AffineEnvironment.transform 15 8322 env25258 = env25259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env25258 == env25259) = true)

theorem identity25259 : scanCanonicalize (H12AffineFastState.compose env25259 (packedSelected [10,12,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound25259 : packedSelected [10,12,18,19,23] rootPS < 2^1333 := by decide +kernel

def env25260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8581,8322,24981,10281,1025,8580,4160,21928,65,138,8328,64,24025,5441,17745,10360,1501,33,257,21792,5377,648]

theorem envBound25260 : H12AffineFastState.Bounded env25260 := by
  intro p hp
  have h : env25260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25259_25260 : H12AffineEnvironment.transform 14 8581 env25259 = env25260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env25259 == env25260) = true)

theorem identity25260 : scanCanonicalize (H12AffineFastState.compose env25260 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25260 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,217,478,16585,2421,1025,216,4160,21928,65,138,468,64,24025,5441,17745,2340,1501,33,257,21792,5377,648]

theorem envBound25261 : H12AffineFastState.Bounded env25261 := by
  intro p hp
  have h : env25261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25260_25261 : H12AffineEnvironment.transform 12 348 env25260 = env25261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25260 == env25261) = true)

theorem identity25261 : scanCanonicalize (H12AffineFastState.compose env25261 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25261 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,137,398,16537,2341,1025,136,4112,21928,17,138,388,16,23945,5393,17665,2340,1421,33,257,21792,5377,648]

theorem envBound25262 : H12AffineFastState.Bounded env25262 := by
  intro p hp
  have h : env25262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25261_25262 : H12AffineEnvironment.transform 5 16 env25261 = env25262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25261 == env25262) = true)

theorem identity25262 : scanCanonicalize (H12AffineFastState.compose env25262 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25262 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env25263 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1025,0,4112,21792,17,2,268,16,23809,5393,17665,2340,1285,33,257,21792,5377,512]

theorem envBound25263 : H12AffineFastState.Bounded env25263 := by
  intro p hp
  have h : env25263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25262_25263 : H12AffineEnvironment.transform 6 8 env25262 = env25263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25262 == env25263) = true)

theorem identity25263 : scanCanonicalize (H12AffineFastState.compose env25263 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25263 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25264 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,16384,1,262,16401,2309,1025,0,4112,21760,17,2,268,16,23809,5393,17665,2308,1285,1,257,21760,5377,512]

theorem envBound25264 : H12AffineFastState.Bounded env25264 := by
  intro p hp
  have h : env25264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25263_25264 : H12AffineEnvironment.transform 4 0 env25263 = env25264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25263 == env25264) = true)

theorem identity25264 : scanCanonicalize (H12AffineFastState.compose env25264 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound25264 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25265 : List Nat := [2,4,8,16,0,16,8,256,512,1024,523,4096,268,16384,1,262,16401,782,1025,0,4112,21760,17,2,268,16,22282,5393,17665,783,1285,1,257,21760,5377,512]

theorem envBound25265 : H12AffineFastState.Bounded env25265 := by
  intro p hp
  have h : env25265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25264_25265 : H12AffineEnvironment.transform 10 523 env25264 = env25265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env25264 == env25265) = true)

theorem identity25265 : scanCanonicalize (H12AffineFastState.compose env25265 (packedSelected [1,3,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25265 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env25266 : List Nat := [2,4,8,16,0,16,8,256,512,1024,523,4096,268,5376,1,262,5393,782,1025,0,4112,0,17,2,268,16,522,5393,4097,783,1285,1,257,0,5377,512]

theorem envBound25266 : H12AffineFastState.Bounded env25266 := by
  intro p hp
  have h : env25266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25265_25266 : H12AffineEnvironment.transform 13 5376 env25265 = env25266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25265 == env25266) = true)

theorem identity25266 : scanCanonicalize (H12AffineFastState.compose env25266 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25266 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25267 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,4096,8,5124,1,2,5141,522,1025,0,4112,0,17,2,8,16,522,5141,4097,523,1025,1,5,0,5125,512]

theorem envBound25267 : H12AffineFastState.Bounded env25267 := by
  intro p hp
  have h : env25267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25266_25267 : H12AffineEnvironment.transform 7 4 env25266 = env25267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25266 == env25267) = true)

def env25268 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,16,8,1044,1,2,1029,522,1025,0,0,0,17,2,8,16,522,1029,17,523,1025,1,5,0,1045,512]

theorem envBound25268 : H12AffineFastState.Bounded env25268 := by
  intro p hp
  have h : env25268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25267_25268 : H12AffineEnvironment.transform 11 16 env25267 = env25268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25267 == env25268) = true)

theorem identity25268 : scanCanonicalize (H12AffineFastState.compose env25268 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound25268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25269 : List Nat := [2,4,8,16,0,16,8,4,30,1024,21,16,8,1044,1,2,1029,20,1025,0,0,0,17,2,8,16,20,1029,17,21,1025,1,5,0,1045,30]

theorem envBound25269 : H12AffineFastState.Bounded env25269 := by
  intro p hp
  have h : env25269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25268_25269 : H12AffineEnvironment.transform 8 30 env25268 = env25269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env25268 == env25269) = true)

def env25270 : List Nat := [2,4,8,16,0,16,8,4,30,0,21,16,8,20,1,2,5,20,1,0,0,0,17,2,8,16,20,5,17,21,1,1,5,0,21,30]

theorem envBound25270 : H12AffineFastState.Bounded env25270 := by
  intro p hp
  have h : env25270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25269_25270 : H12AffineEnvironment.transform 9 0 env25269 = env25270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25269 == env25270) = true)

theorem identity25270 : scanCanonicalize (H12AffineFastState.compose env25270 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound25270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25271 : List Nat := [1,4,8,16,0,16,8,4,29,0,21,16,8,20,1,1,5,20,1,0,0,0,17,1,8,16,20,5,17,21,1,1,5,0,21,29]

theorem envBound25271 : H12AffineFastState.Bounded env25271 := by
  intro p hp
  have h : env25271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25270_25271 : H12AffineEnvironment.transform 0 1 env25270 = env25271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25270 == env25271) = true)

def leafEnv25271 : List Nat := [1,4,8,16,0,16,8,4,29,0,21,16,8,20,1,1,5,20,1,0,0,0,17,1,1,8,1,16,20,5,17,21,1,1,5,0,4,1,21,29,1,1,0]

def active25271 : List Nat := [1,2,3]

def tree25271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25271 : H12WitnessSearch.Good tree25271 := H12GlobalWitnessIndex.good

theorem leafIdentity25271 : H12AffineFastState.composeSystem env25271 rootObs = leafEnv25271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25271 rootObs == leafEnv25271) = true)

theorem terminalChecked25271 : H12PackedTerminal.terminalCheckFast leafEnv25271 active25271 tree25271 = true := by decide +kernel

def env25272 : List Nat := [2,4,8,16,0,16,8,4,30,1,21,16,8,21,1,2,4,20,0,0,0,0,17,2,8,16,20,4,17,21,0,1,5,0,20,30]

theorem envBound25272 : H12AffineFastState.Bounded env25272 := by
  intro p hp
  have h : env25272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25269_25272 : H12AffineEnvironment.transform 9 1 env25269 = env25272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env25269 == env25272) = true)

theorem identity25272 : scanCanonicalize (H12AffineFastState.compose env25272 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound25272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25273 : List Nat := [2,4,8,6,0,6,8,4,8,1,3,6,8,3,1,2,4,2,0,0,0,0,7,2,8,6,2,4,7,3,0,1,5,0,2,8]

theorem envBound25273 : H12AffineFastState.Bounded env25273 := by
  intro p hp
  have h : env25273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25272_25273 : H12AffineEnvironment.transform 3 6 env25272 = env25273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env25272 == env25273) = true)

def leafEnv25273 : List Nat := [2,4,8,6,0,6,8,4,8,1,3,6,8,3,1,2,4,2,0,0,0,0,7,2,0,8,1,6,2,4,7,3,0,1,5,0,4,2,2,8,1,1,0]

def active25273 : List Nat := [0,1,2]

def tree25273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25273 : H12WitnessSearch.Good tree25273 := H12GlobalWitnessIndex.good

theorem leafIdentity25273 : H12AffineFastState.composeSystem env25273 rootObs = leafEnv25273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25273 rootObs == leafEnv25273) = true)

theorem terminalChecked25273 : H12PackedTerminal.terminalCheckFast leafEnv25273 active25273 tree25273 = true := by decide +kernel

def env25274 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,17,8,1045,1,2,1028,522,1025,0,1,0,17,2,8,16,522,1028,16,523,1025,1,5,0,1044,512]

theorem envBound25274 : H12AffineFastState.Bounded env25274 := by
  intro p hp
  have h : env25274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25267_25274 : H12AffineEnvironment.transform 11 17 env25267 = env25274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25267 == env25274) = true)

theorem identity25274 : scanCanonicalize (H12AffineFastState.compose env25274 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound25274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25275 : List Nat := [2,4,8,16,0,16,8,4,512,522,523,17,8,543,1,2,526,522,523,0,1,0,17,2,8,16,522,526,16,523,523,1,5,0,542,512]

theorem envBound25275 : H12AffineFastState.Bounded env25275 := by
  intro p hp
  have h : env25275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25274_25275 : H12AffineEnvironment.transform 9 522 env25274 = env25275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env25274 == env25275) = true)

def env25276 : List Nat := [2,4,8,4,0,4,8,4,512,522,523,5,8,523,1,2,526,522,523,0,1,0,5,2,8,4,522,526,4,523,523,1,5,0,522,512]

theorem envBound25276 : H12AffineFastState.Bounded env25276 := by
  intro p hp
  have h : env25276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25275_25276 : H12AffineEnvironment.transform 3 4 env25275 = env25276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25275 == env25276) = true)

theorem identity25276 : scanCanonicalize (H12AffineFastState.compose env25276 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound25276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25277 : List Nat := [2,4,8,4,0,4,8,4,9,3,2,5,8,2,1,2,7,3,2,0,1,0,5,2,8,4,3,7,4,2,2,1,5,0,3,9]

theorem envBound25277 : H12AffineFastState.Bounded env25277 := by
  intro p hp
  have h : env25277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25276_25277 : H12AffineEnvironment.transform 8 9 env25276 = env25277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env25276 == env25277) = true)

def leafEnv25277 : List Nat := [2,4,8,4,0,4,8,4,9,3,2,5,8,2,1,2,7,3,2,0,1,0,5,2,2,8,1,4,3,7,4,2,2,1,5,0,4,2,3,9,1,0,0]

def active25277 : List Nat := [0,1,2]

def tree25277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25277 : H12WitnessSearch.Good tree25277 := H12GlobalWitnessIndex.good

theorem leafIdentity25277 : H12AffineFastState.composeSystem env25277 rootObs = leafEnv25277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25277 rootObs == leafEnv25277) = true)

theorem terminalChecked25277 : H12PackedTerminal.terminalCheckFast leafEnv25277 active25277 tree25277 = true := by decide +kernel

def env25278 : List Nat := [2,4,8,5,0,5,8,4,512,522,523,4,8,522,1,2,526,522,523,0,1,0,4,2,8,5,522,526,5,523,523,1,5,0,523,512]

theorem envBound25278 : H12AffineFastState.Bounded env25278 := by
  intro p hp
  have h : env25278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25275_25278 : H12AffineEnvironment.transform 3 5 env25275 = env25278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25275 == env25278) = true)

theorem identity25278 : scanCanonicalize (H12AffineFastState.compose env25278 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound25278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25279 : List Nat := [1,4,8,5,0,5,8,4,512,521,520,4,8,521,1,1,525,521,520,0,1,0,4,1,8,5,521,525,5,520,520,1,5,0,520,512]

theorem envBound25279 : H12AffineFastState.Bounded env25279 := by
  intro p hp
  have h : env25279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25278_25279 : H12AffineEnvironment.transform 0 1 env25278 = env25279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25278 == env25279) = true)

def leafEnv25279 : List Nat := [1,4,8,5,0,5,8,4,512,521,520,4,8,521,1,1,525,521,520,0,1,0,4,1,520,8,1,5,521,525,5,520,520,1,5,0,4,1,520,512,1,0,0]

def active25279 : List Nat := [1,2,8]

def tree25279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25279 : H12WitnessSearch.Good tree25279 := H12GlobalWitnessIndex.good

theorem leafIdentity25279 : H12AffineFastState.composeSystem env25279 rootObs = leafEnv25279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25279 rootObs == leafEnv25279) = true)

theorem terminalChecked25279 : H12PackedTerminal.terminalCheckFast leafEnv25279 active25279 tree25279 = true := by decide +kernel

def env25280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21929,41413,73737,8328,64,64604,46277,58581,35325,1501,33,257,21792,46212,74250]

theorem envBound25280 : H12AffineFastState.Bounded env25280 := by
  intro p hp
  have h : env25280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25257_25280 : H12AffineEnvironment.transform 16 49169 env25257 = env25280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25257 == env25280) = true)

theorem identity25280 : scanCanonicalize (H12AffineFastState.compose env25280 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1025,32769,4160,21929,41413,2,8328,64,64604,46277,58581,35325,1501,33,257,21792,46212,513]

theorem envBound25281 : H12AffineFastState.Bounded env25281 := by
  intro p hp
  have h : env25281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25280_25281 : H12AffineEnvironment.transform 15 8203 env25280 = env25281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25280 == env25281) = true)

theorem identity25281 : scanCanonicalize (H12AffineFastState.compose env25281 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25281 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env25282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,16400,10281,1025,0,4160,21929,8644,2,8328,64,31837,13508,25812,2556,1501,33,257,21792,13445,513]

theorem envBound25282 : H12AffineFastState.Bounded env25282 := by
  intro p hp
  have h : env25282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25281_25282 : H12AffineEnvironment.transform 14 1 env25281 = env25282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25281 == env25282) = true)

def env25283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,253976,8328,64,64605,160981,140484,303573,1500,272393,257,21792,46212,74251]

theorem envBound25283 : H12AffineFastState.Bounded env25283 := by
  intro p hp
  have h : env25283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25225_25283 : H12AffineEnvironment.transform 20 4161 env25225 = env25283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25225 == env25283) = true)

theorem identity25283 : scanCanonicalize (H12AffineFastState.compose env25283 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound25283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272513,62661,95496,8328,64,64605,57797,45524,303573,1500,272393,257,21792,46212,74251]

theorem envBound25284 : H12AffineFastState.Bounded env25284 := by
  intro p hp
  have h : env25284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25283_25284 : H12AffineEnvironment.transform 16 38160 env25283 = env25284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env25283 == env25284) = true)

theorem identity25284 : scanCanonicalize (H12AffineFastState.compose env25284 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25284 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env25285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,4161,272513,62661,21762,8328,64,64605,57797,45524,303573,1500,272393,257,21792,46212,513]

theorem envBound25285 : H12AffineFastState.Bounded env25285 := by
  intro p hp
  have h : env25285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25284_25285 : H12AffineEnvironment.transform 15 8202 env25284 = env25285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25284 == env25285) = true)

theorem identity25285 : scanCanonicalize (H12AffineFastState.compose env25285 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound25285 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env25286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,2421,1025,32769,4161,8692,62661,21762,8328,64,64605,57797,45524,43168,1500,8572,257,21792,46212,513]

theorem envBound25286 : H12AffineFastState.Bounded env25286 := by
  intro p hp
  have h : env25286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25285_25286 : H12AffineEnvironment.transform 17 2421 env25285 = env25286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env25285 == env25286) = true)

theorem identity25286 : scanCanonicalize (H12AffineFastState.compose env25286 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25286 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8202,16401,2421,1025,21760,4161,8692,8644,21762,8328,64,10588,13508,25813,32161,1500,8572,257,21792,24965,513]

theorem envBound25287 : H12AffineFastState.Bounded env25287 := by
  intro p hp
  have h : env25287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25286_25287 : H12AffineEnvironment.transform 14 21761 env25286 = env25287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25286 == env25287) = true)

theorem identity25287 : scanCanonicalize (H12AffineFastState.compose env25287 (packedSelected [2,3,5,6,8,17,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25287 : packedSelected [2,3,5,6,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env25288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16401,2421,1025,21760,4161,8573,8525,21762,8193,64,10588,13389,25692,32040,1365,8572,257,21792,24844,513]

theorem envBound25288 : H12AffineFastState.Bounded env25288 := by
  intro p hp
  have h : env25288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25287_25288 : H12AffineEnvironment.transform 6 9 env25287 = env25288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25287 == env25288) = true)

theorem identity25288 : scanCanonicalize (H12AffineFastState.compose env25288 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound25288 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env25289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8460,8202,13340,2421,1025,8461,4161,8573,8525,8463,8193,64,10588,13389,4177,2341,1365,8572,257,8493,5377,513]

theorem envBound25289 : H12AffineFastState.Bounded env25289 := by
  intro p hp
  have h : env25289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25288_25289 : H12AffineEnvironment.transform 13 13325 env25288 = env25289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env25288 == env25289) = true)

theorem identity25289 : scanCanonicalize (H12AffineFastState.compose env25289 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25289 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,343,5441,2421,1025,80,4161,32,16,82,348,64,2049,5392,4177,2341,1365,33,257,112,5377,513]

theorem envBound25290 : H12AffineFastState.Bounded env25290 := by
  intro p hp
  have h : env25290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25289_25290 : H12AffineEnvironment.transform 12 349 env25289 = env25290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25289 == env25290) = true)

theorem identity25290 : scanCanonicalize (H12AffineFastState.compose env25290 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25290 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25291 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1025,1,4112,32,16,3,269,17,2049,5392,4096,2341,1284,33,257,33,5377,513]

theorem envBound25291 : H12AffineFastState.Bounded env25291 := by
  intro p hp
  have h : env25291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25290_25291 : H12AffineEnvironment.transform 5 17 env25290 = env25291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25290 == env25291) = true)

theorem identity25291 : scanCanonicalize (H12AffineFastState.compose env25291 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25292 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,268,4404,0,262,4389,2340,52,1,4112,32,16,3,269,17,2049,4389,4096,2341,305,33,257,33,4404,513]

theorem envBound25292 : H12AffineFastState.Bounded env25292 := by
  intro p hp
  have h : env25292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25291_25292 : H12AffineEnvironment.transform 9 53 env25291 = env25292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25291 == env25292) = true)

theorem identity25292 : scanCanonicalize (H12AffineFastState.compose env25292 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25293 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,0,35,4096,2049,52,1,4112,32,16,3,40,17,2049,4096,4096,2048,20,33,36,33,4113,513]

theorem envBound25293 : H12AffineFastState.Bounded env25293 := by
  intro p hp
  have h : env25293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25292_25293 : H12AffineEnvironment.transform 7 37 env25292 = env25293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25292 == env25293) = true)

theorem identity25293 : scanCanonicalize (H12AffineFastState.compose env25293 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound25293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25294 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2576,41,2561,0,35,2576,2049,52,1,2560,32,16,3,40,17,2049,2576,2576,2048,20,33,36,33,2561,513]

theorem envBound25294 : H12AffineFastState.Bounded env25294 := by
  intro p hp
  have h : env25294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25293_25294 : H12AffineEnvironment.transform 11 2576 env25293 = env25294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env25293 == env25294) = true)

theorem identity25294 : scanCanonicalize (H12AffineFastState.compose env25294 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound25294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25295 : List Nat := [2,4,8,16,32,17,9,37,512,53,59,555,41,570,0,35,555,58,52,1,571,32,16,3,40,17,58,555,555,59,20,33,36,33,570,513]

theorem envBound25295 : H12AffineFastState.Bounded env25295 := by
  intro p hp
  have h : env25295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25294_25295 : H12AffineEnvironment.transform 10 59 env25294 = env25295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env25294 == env25295) = true)

theorem identity25295 : scanCanonicalize (H12AffineFastState.compose env25295 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound25295 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25296 : List Nat := [2,4,8,16,26,17,9,31,512,15,1,529,19,512,0,25,529,0,14,1,513,26,16,3,18,17,0,529,529,1,20,27,30,27,512,513]

theorem envBound25296 : H12AffineFastState.Bounded env25296 := by
  intro p hp
  have h : env25296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25295_25296 : H12AffineEnvironment.transform 4 26 env25295 = env25296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env25295 == env25296) = true)

theorem identity25296 : scanCanonicalize (H12AffineFastState.compose env25296 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25296 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25297 : List Nat := [2,4,8,16,26,17,9,31,0,15,1,17,19,0,0,25,17,0,14,1,1,26,16,3,18,17,0,17,17,1,20,27,30,27,0,1]

theorem envBound25297 : H12AffineFastState.Bounded env25297 := by
  intro p hp
  have h : env25297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25296_25297 : H12AffineEnvironment.transform 8 0 env25296 = env25297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25296 == env25297) = true)

def env25298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257301,253976,8328,64,6705548,2253972,140485,2404757,2102684,6456793,257,21793,46213,2175563]

theorem envBound25298 : H12AffineFastState.Bounded env25298 := by
  intro p hp
  have h : env25298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25177_25298 : H12AffineEnvironment.transform 22 2257301 env25177 = env25298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257301 env25177 == env25298) = true)

def env25299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257301,253976,8328,64,2157596,2253972,140485,2404757,2102684,2373705,257,21793,46213,2175563]

theorem envBound25299 : H12AffineFastState.Bounded env25299 := by
  intro p hp
  have h : env25299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25298_25299 : H12AffineEnvironment.transform 21 441744 env25298 = env25299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env25298 == env25299) = true)

def env25300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,253976,8328,64,64604,160980,140485,303573,1500,272393,257,21793,46213,74251]

theorem envBound25300 : H12AffineFastState.Bounded env25300 := by
  intro p hp
  have h : env25300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25299_25300 : H12AffineEnvironment.transform 20 4160 env25299 = env25300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25299 == env25300) = true)

theorem identity25300 : scanCanonicalize (H12AffineFastState.compose env25300 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound25300 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,4160,329867,120014,21763,8328,64,64604,115151,102878,303573,1500,272393,257,21793,46213,74251]

theorem envBound25301 : H12AffineFastState.Bounded env25301 := by
  intro p hp
  have h : env25301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25300_25301 : H12AffineEnvironment.transform 16 111899 env25300 = env25301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env25300 == env25301) = true)

def env25302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,4160,73771,120014,21763,8328,64,64604,115151,102878,35189,1500,169,257,21793,46213,74251]

theorem envBound25302 : H12AffineFastState.Bounded env25302 := by
  intro p hp
  have h : env25302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25301_25302 : H12AffineEnvironment.transform 17 10400 env25301 = env25302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env25301 == env25302) = true)

def env25303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,73771,119878,21763,8192,64,64604,115015,102742,35189,1364,33,257,21793,46093,74251]

theorem envBound25303 : H12AffineFastState.Bounded env25303 := by
  intro p hp
  have h : env25303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25302_25303 : H12AffineEnvironment.transform 6 8 env25302 = env25303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25302 == env25303) = true)

theorem identity25303 : scanCanonicalize (H12AffineFastState.compose env25303 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound25303 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,13388,10280,1025,32769,4160,41340,21777,21763,8192,64,64604,16400,4097,35189,1364,33,257,21793,46093,41820]

theorem envBound25304 : H12AffineFastState.Bounded env25304 := by
  intro p hp
  have h : env25304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25303_25304 : H12AffineEnvironment.transform 15 33111 env25303 = env25304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env25303 == env25304) = true)

theorem identity25304 : scanCanonicalize (H12AffineFastState.compose env25304 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25304 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env25305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,13388,10280,1025,8541,4160,32,21777,21763,8192,64,23808,16400,4097,10281,1364,33,257,21793,5457,512]

theorem envBound25305 : H12AffineFastState.Bounded env25305 := by
  intro p hp
  have h : env25305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25304_25305 : H12AffineEnvironment.transform 14 8540 env25304 = env25305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25304 == env25305) = true)

theorem identity25305 : scanCanonicalize (H12AffineFastState.compose env25305 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 15405) := by decide +kernel

theorem selectedBound25305 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15405,8540,8203,13388,10280,1025,8541,4160,32,10556,10542,8192,64,8493,15421,4097,10281,1364,33,257,10508,5457,512]

theorem envBound25306 : H12AffineFastState.Bounded env25306 := by
  intro p hp
  have h : env25306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25305_25306 : H12AffineEnvironment.transform 13 15405 env25305 = env25306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15405 env25305 == env25306) = true)

theorem identity25306 : scanCanonicalize (H12AffineFastState.compose env25306 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6461) := by decide +kernel

theorem selectedBound25306 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env25307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6461,1296,6241,6454,3441,4373,1025,6240,4160,32,4097,4115,6461,64,6160,1280,4097,4372,1364,33,257,4145,5457,512]

theorem envBound25307 : H12AffineFastState.Bounded env25307 := by
  intro p hp
  have h : env25307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25306_25307 : H12AffineEnvironment.transform 12 6461 env25306 = env25307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6461 env25306 == env25307) = true)

theorem identity25307 : scanCanonicalize (H12AffineFastState.compose env25307 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound25307 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,4121,1296,4421,4114,1109,4373,1025,4420,4160,32,4097,4115,4121,64,4404,1280,4097,4372,1364,33,257,4145,5457,512]

theorem envBound25308 : H12AffineFastState.Bounded env25308 := by
  intro p hp
  have h : env25308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25307_25308 : H12AffineEnvironment.transform 10 292 env25307 = env25308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env25307 == env25308) = true)

theorem identity25308 : scanCanonicalize (H12AffineFastState.compose env25308 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound25308 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,356,381,1296,33,374,1109,113,1025,32,292,32,357,375,381,64,80,1280,357,112,1364,33,257,341,1077,512]

theorem envBound25309 : H12AffineFastState.Bounded env25309 := by
  intro p hp
  have h : env25309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25308_25309 : H12AffineEnvironment.transform 11 356 env25308 = env25309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env25308 == env25309) = true)

theorem identity25309 : scanCanonicalize (H12AffineFastState.compose env25309 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25309 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25310 : List Nat := [2,4,8,16,32,16,8,256,512,1024,292,308,301,1296,33,294,1029,33,1025,32,292,32,309,295,301,16,0,1280,309,32,1284,33,257,261,1077,512]

theorem envBound25310 : H12AffineFastState.Bounded env25310 := by
  intro p hp
  have h : env25310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0