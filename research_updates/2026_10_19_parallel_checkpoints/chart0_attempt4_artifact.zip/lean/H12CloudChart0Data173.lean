import H12CloudChart0Data172

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity43827 : scanCanonicalize (H12AffineFastState.compose env43827 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound43827 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env43828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,8203,131072,10280,1025,292,25913,33,17,21763,8192,65,138293,5393,12408,157981,28716,30040,257,21792,13608,30585]

theorem envBound43828 : H12AffineFastState.Bounded env43828 := by
  intro p hp
  have h : env43828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43827_43828 : H12AffineEnvironment.transform 14 293 env43827 = env43828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env43827 == env43828) = true)

theorem identity43828 : scanCanonicalize (H12AffineFastState.compose env43828 (packedSelected [0,1,2,5,6,7,8,11,18,19,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound43828 : packedSelected [0,1,2,5,6,7,8,11,18,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env43829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,8203,16401,10280,1025,292,25913,33,17,21763,8192,65,23588,5393,12408,10508,28716,30040,257,21792,13608,30585]

theorem envBound43829 : H12AffineFastState.Bounded env43829 := by
  intro p hp
  have h : env43829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43828_43829 : H12AffineEnvironment.transform 16 16401 env43828 = env43829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43828 == env43829) = true)

theorem identity43829 : scanCanonicalize (H12AffineFastState.compose env43829 (packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound43829 : packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env43830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,16384,293,83,16401,2160,1025,292,17761,33,17,21763,88,65,23588,5393,4128,2388,20596,21760,257,21792,5488,22305]

theorem envBound43830 : H12AffineFastState.Bounded env43830 := by
  intro p hp
  have h : env43830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43829_43830 : H12AffineEnvironment.transform 12 88 env43829 = env43830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env43829 == env43830) = true)

theorem identity43830 : scanCanonicalize (H12AffineFastState.compose env43830 (packedSelected [0,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43830 : packedSelected [0,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env43831 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,16384,293,2,16401,2081,1025,292,17712,33,17,21763,9,16,23588,5393,4128,2309,20517,21760,257,21792,5409,22305]

theorem envBound43831 : H12AffineFastState.Bounded env43831 := by
  intro p hp
  have h : env43831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43830_43831 : H12AffineEnvironment.transform 5 17 env43830 = env43831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43830 == env43831) = true)

theorem identity43831 : scanCanonicalize (H12AffineFastState.compose env43831 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound43831 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43832 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,9,16384,293,2,16401,2081,305,292,16384,33,17,20531,9,16,22804,4129,4128,2309,20517,20528,257,20496,4113,21009]

theorem envBound43832 : H12AffineFastState.Bounded env43832 := by
  intro p hp
  have h : env43832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43831_43832 : H12AffineEnvironment.transform 9 304 env43831 = env43832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env43831 == env43832) = true)

theorem identity43832 : scanCanonicalize (H12AffineFastState.compose env43832 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound43832 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env43833 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,9,4144,293,2,4129,2081,305,292,4144,33,17,3,9,16,2340,4129,4128,2309,21,0,257,32,4113,545]

theorem envBound43833 : H12AffineFastState.Bounded env43833 := by
  intro p hp
  have h : env43833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43832_43833 : H12AffineEnvironment.transform 13 4144 env43832 = env43833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env43832 == env43833) = true)

theorem identity43833 : scanCanonicalize (H12AffineFastState.compose env43833 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43833 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43834 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,9,4144,33,2,4129,2081,53,32,4144,33,17,3,9,16,2080,4129,4128,2049,21,0,5,32,4113,545]

theorem envBound43834 : H12AffineFastState.Bounded env43834 := by
  intro p hp
  have h : env43834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43833_43834 : H12AffineEnvironment.transform 7 4 env43833 = env43834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43833 == env43834) = true)

theorem identity43834 : scanCanonicalize (H12AffineFastState.compose env43834 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound43834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43835 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,528,9,544,33,2,561,2081,53,32,544,33,17,3,9,16,2080,561,560,2049,21,0,5,32,513,545]

theorem envBound43835 : H12AffineFastState.Bounded env43835 := by
  intro p hp
  have h : env43835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43834_43835 : H12AffineEnvironment.transform 11 528 env43834 = env43835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env43834 == env43835) = true)

theorem identity43835 : scanCanonicalize (H12AffineFastState.compose env43835 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound43835 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43836 : List Nat := [2,4,8,16,32,17,8,4,512,52,528,528,9,544,33,2,561,561,53,32,544,33,17,3,9,16,560,561,560,529,21,0,5,32,513,545]

theorem envBound43836 : H12AffineFastState.Bounded env43836 := by
  intro p hp
  have h : env43836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43835_43836 : H12AffineEnvironment.transform 10 528 env43835 = env43836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env43835 == env43836) = true)

theorem identity43836 : scanCanonicalize (H12AffineFastState.compose env43836 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43836 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43837 : List Nat := [2,4,8,16,1,17,8,4,512,21,528,528,9,513,0,2,528,528,20,1,513,0,17,3,9,16,529,528,529,529,21,0,5,1,513,512]

theorem envBound43837 : H12AffineFastState.Bounded env43837 := by
  intro p hp
  have h : env43837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43836_43837 : H12AffineEnvironment.transform 4 1 env43836 = env43837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43836 == env43837) = true)

theorem identity43837 : scanCanonicalize (H12AffineFastState.compose env43837 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43838 : List Nat := [2,4,8,16,1,17,8,4,4,21,20,20,9,5,0,2,20,20,20,1,5,0,17,3,9,16,21,20,21,21,21,0,5,1,5,4]

theorem envBound43838 : H12AffineFastState.Bounded env43838 := by
  intro p hp
  have h : env43838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43837_43838 : H12AffineEnvironment.transform 8 4 env43837 = env43838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43837 == env43838) = true)

theorem identity43838 : scanCanonicalize (H12AffineFastState.compose env43838 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound43838 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43839 : List Nat := [2,4,8,13,1,12,8,4,4,8,9,9,9,5,0,2,9,9,9,1,5,0,12,3,9,13,8,9,8,8,8,0,5,1,5,4]

theorem envBound43839 : H12AffineFastState.Bounded env43839 := by
  intro p hp
  have h : env43839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43838_43839 : H12AffineEnvironment.transform 3 13 env43838 = env43839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env43838 == env43839) = true)

theorem identity43839 : scanCanonicalize (H12AffineFastState.compose env43839 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43840 : List Nat := [2,4,1,4,1,5,1,4,4,1,0,0,0,5,0,2,0,0,0,1,5,0,5,3,0,4,1,0,1,1,1,0,5,1,5,4]

theorem envBound43840 : H12AffineFastState.Bounded env43840 := by
  intro p hp
  have h : env43840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43839_43840 : H12AffineEnvironment.transform 2 1 env43839 = env43840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43839 == env43840) = true)

theorem identity43840 : scanCanonicalize (H12AffineFastState.compose env43840 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43840 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43841 : List Nat := [0,4,1,4,1,5,1,4,4,1,0,0,0,5,0,0,0,0,0,1,5,0,5,1,0,4,1,0,1,1,1,0,5,1,5,4]

theorem envBound43841 : H12AffineFastState.Bounded env43841 := by
  intro p hp
  have h : env43841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43840_43841 : H12AffineEnvironment.transform 0 0 env43840 = env43841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43840 == env43841) = true)

def env43842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,33,73754,95496,8193,65,245018,79130,45404,247858,119042,119926,257,21792,46092,63069]

theorem envBound43842 : H12AffineFastState.Bounded env43842 := by
  intro p hp
  have h : env43842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43825_43842 : H12AffineEnvironment.transform 6 9 env43825 = env43842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43825 == env43842) = true)

theorem identity43842 : scanCanonicalize (H12AffineFastState.compose env43842 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound43842 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10281,1025,32769,17729,33,41293,62559,8193,65,146509,46157,45404,149861,20565,21793,257,21792,46092,63069]

theorem envBound43843 : H12AffineFastState.Bounded env43843 := by
  intro p hp
  have h : env43843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43842_43843 : H12AffineEnvironment.transform 15 33111 env43842 = env43843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env43842 == env43843) = true)

theorem identity43843 : scanCanonicalize (H12AffineFastState.compose env43843 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound43843 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,5393,10281,1025,32769,17729,33,41293,62559,8193,65,10588,46157,45404,23668,20565,21793,257,21792,46092,63069]

theorem envBound43844 : H12AffineFastState.Bounded env43844 := by
  intro p hp
  have h : env43844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43843_43844 : H12AffineEnvironment.transform 16 5393 env43843 = env43844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43843 == env43844) = true)

def env43845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,4194304,8388608,95497,8328,65,12754344,79130,8491470,8579232,8450329,4314199,257,8484154,8492191,8509135]

theorem envBound43845 : H12AffineFastState.Bounded env43845 := by
  intro p hp
  have h : env43845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43793_43845 : H12AffineEnvironment.transform 17 10401 env43793 = env43845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43793 == env43845) = true)

def env43846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,8388608,95497,8328,65,8560008,79130,8491470,8579232,8450329,119927,257,8484154,8492191,8509135]

theorem envBound43846 : H12AffineFastState.Bounded env43846 := by
  intro p hp
  have h : env43846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43845_43846 : H12AffineEnvironment.transform 21 32 env43845 = env43846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env43845 == env43846) = true)

theorem identity43846 : scanCanonicalize (H12AffineFastState.compose env43846 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound43846 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,120014,95497,8328,65,215366,79130,17664,212078,75223,119927,257,41460,16465,513]

theorem envBound43847 : H12AffineFastState.Bounded env43847 := by
  intro p hp
  have h : env43847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43846_43847 : H12AffineEnvironment.transform 22 120014 env43846 = env43847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env43846 == env43847) = true)

def env43848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,119878,95497,8192,65,215366,79130,17664,212078,75103,119927,257,41340,16465,513]

theorem envBound43848 : H12AffineFastState.Bounded env43848 := by
  intro p hp
  have h : env43848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43847_43848 : H12AffineEnvironment.transform 6 8 env43847 = env43848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43847 == env43848) = true)

theorem identity43848 : scanCanonicalize (H12AffineFastState.compose env43848 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound43848 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1025,8460,91419,32,95563,95497,8192,65,215366,79130,17664,212078,75103,95610,257,113,16465,513]

theorem envBound43849 : H12AffineFastState.Bounded env43849 := by
  intro p hp
  have h : env43849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43848_43849 : H12AffineEnvironment.transform 14 8461 env43848 = env43849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env43848 == env43849) = true)

theorem identity43849 : scanCanonicalize (H12AffineFastState.compose env43849 (packedSelected [0,3,7,12,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound43849 : packedSelected [0,3,7,12,20,24] rootPS < 2^1333 := by decide +kernel

def env43850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21511,131072,10281,1025,8460,12572,32,8524,8462,8192,65,138561,24861,17664,157801,29016,8573,257,113,16465,513]

theorem envBound43850 : H12AffineFastState.Bounded env43850 := by
  intro p hp
  have h : env43850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43849_43850 : H12AffineEnvironment.transform 15 21511 env43849 = env43850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env43849 == env43850) = true)

theorem identity43850 : scanCanonicalize (H12AffineFastState.compose env43850 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound43850 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21511,13341,10281,1025,8460,12572,32,8524,8462,8192,65,10588,24861,17664,23668,29016,8573,257,113,16465,513]

theorem envBound43851 : H12AffineFastState.Bounded env43851 := by
  intro p hp
  have h : env43851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43850_43851 : H12AffineEnvironment.transform 16 13341 env43850 = env43851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env43850 == env43851) = true)

theorem identity43851 : scanCanonicalize (H12AffineFastState.compose env43851 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43851 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,21511,5392,2340,1025,1,4113,32,65,3,269,65,2129,16400,17664,23668,20565,112,257,113,16465,513]

theorem envBound43852 : H12AffineFastState.Bounded env43852 := by
  intro p hp
  have h : env43852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43851_43852 : H12AffineEnvironment.transform 12 269 env43851 = env43852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43851 == env43852) = true)

theorem identity43852 : scanCanonicalize (H12AffineFastState.compose env43852 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound43852 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,0,342,5392,2340,1025,1,4113,32,65,3,269,65,2129,5441,4177,2341,1284,112,257,113,5376,513]

theorem envBound43853 : H12AffineFastState.Bounded env43853 := by
  intro p hp
  have h : env43853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43852_43853 : H12AffineEnvironment.transform 13 5457 env43852 = env43853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env43852 == env43853) = true)

theorem identity43853 : scanCanonicalize (H12AffineFastState.compose env43853 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43853 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43854 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,4161,0,342,4096,2340,273,1,4113,32,65,3,269,65,2129,4177,4177,2341,20,112,257,113,4112,513]

theorem envBound43854 : H12AffineFastState.Bounded env43854 := by
  intro p hp
  have h : env43854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43853_43854 : H12AffineEnvironment.transform 9 272 env43853 = env43854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43853 == env43854) = true)

theorem identity43854 : scanCanonicalize (H12AffineFastState.compose env43854 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43854 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env43855 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,4112,0,263,4096,2340,273,1,4113,32,16,3,269,16,2048,4096,4096,2341,20,33,257,32,4112,513]

theorem envBound43855 : H12AffineFastState.Bounded env43855 := by
  intro p hp
  have h : env43855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43854_43855 : H12AffineEnvironment.transform 5 17 env43854 = env43855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43854 == env43855) = true)

theorem identity43855 : scanCanonicalize (H12AffineFastState.compose env43855 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound43855 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43856 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,308,269,292,0,263,308,2340,273,1,293,32,16,3,269,16,2048,308,308,2341,20,33,257,32,292,513]

theorem envBound43856 : H12AffineFastState.Bounded env43856 := by
  intro p hp
  have h : env43856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43855_43856 : H12AffineEnvironment.transform 11 308 env43855 = env43856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env43855 == env43856) = true)

def env43857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,119879,95497,8193,65,215366,79130,17664,212078,75102,119927,257,41341,16465,513]

theorem envBound43857 : H12AffineFastState.Bounded env43857 := by
  intro p hp
  have h : env43857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43847_43857 : H12AffineEnvironment.transform 6 9 env43847 = env43857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43847 == env43857) = true)

theorem identity43857 : scanCanonicalize (H12AffineFastState.compose env43857 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,91467,32,95515,95497,8193,65,215366,79130,17664,212078,75102,95531,257,33,16465,513]

theorem envBound43858 : H12AffineFastState.Bounded env43858 := by
  intro p hp
  have h : env43858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43857_43858 : H12AffineEnvironment.transform 14 8540 env43857 = env43858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43857 == env43858) = true)

theorem identity43858 : scanCanonicalize (H12AffineFastState.compose env43858 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 89111) := by decide +kernel

theorem selectedBound43858 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env43859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,89111,10280,1025,8541,91467,32,95515,95497,8193,65,5457,79130,17664,24697,75102,95531,257,33,16465,513]

theorem envBound43859 : H12AffineFastState.Bounded env43859 := by
  intro p hp
  have h : env43859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43858_43859 : H12AffineEnvironment.transform 16 89111 env43858 = env43859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 89111 env43858 == env43859) = true)

theorem identity43859 : scanCanonicalize (H12AffineFastState.compose env43859 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound43859 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env43860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7505,65536,89111,5157,1025,7504,88390,32,84246,84228,7180,65,5457,67863,17664,23668,72019,84262,257,33,16465,513]

theorem envBound43860 : H12AffineFastState.Bounded env43860 := by
  intro p hp
  have h : env43860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43859_43860 : H12AffineEnvironment.transform 12 7181 env43859 = env43860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env43859 == env43860) = true)

theorem identity43860 : scanCanonicalize (H12AffineFastState.compose env43860 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound43860 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env43861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7505,1378,22901,5157,1025,7504,23588,32,19572,19558,7180,65,5457,3189,17664,23668,7217,19524,257,33,16465,513]

theorem envBound43861 : H12AffineFastState.Bounded env43861 := by
  intro p hp
  have h : env43861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43860_43861 : H12AffineEnvironment.transform 15 1378 env43860 = env43861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env43860 == env43861) = true)

theorem identity43861 : scanCanonicalize (H12AffineFastState.compose env43861 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound43861 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env43862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,2128,7505,1378,4389,5157,1025,7504,5236,32,1060,1078,7180,65,5457,3189,3408,5156,7217,1044,257,33,2049,513]

theorem envBound43862 : H12AffineFastState.Bounded env43862 := by
  intro p hp
  have h : env43862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43861_43862 : H12AffineEnvironment.transform 13 2128 env43861 = env43862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env43861 == env43862) = true)

theorem identity43862 : scanCanonicalize (H12AffineFastState.compose env43862 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43862 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43863 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,6429,2128,6209,114,4389,4405,273,6208,4452,32,308,294,6428,65,4161,2405,2112,4404,6433,260,257,33,2049,513]

theorem envBound43863 : H12AffineFastState.Bounded env43863 := by
  intro p hp
  have h : env43863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43862_43863 : H12AffineEnvironment.transform 9 272 env43862 = env43863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43862 == env43863) = true)

theorem identity43863 : scanCanonicalize (H12AffineFastState.compose env43863 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound43863 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env43864 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2405,120,2128,292,114,2112,2128,273,293,2049,32,308,294,121,65,2340,2405,2112,2129,68,260,257,33,2049,513]

theorem envBound43864 : H12AffineFastState.Bounded env43864 := by
  intro p hp
  have h : env43864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43863_43864 : H12AffineEnvironment.transform 11 2405 env43863 = env43864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env43863 == env43864) = true)

theorem identity43864 : scanCanonicalize (H12AffineFastState.compose env43864 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43864 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43865 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2112,120,2128,1,114,2112,2128,52,0,2049,32,17,3,121,65,2049,2112,2112,2129,68,33,36,33,2049,513]

theorem envBound43865 : H12AffineFastState.Bounded env43865 := by
  intro p hp
  have h : env43865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43864_43865 : H12AffineEnvironment.transform 7 37 env43864 = env43865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43864 == env43865) = true)

theorem identity43865 : scanCanonicalize (H12AffineFastState.compose env43865 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43866 : List Nat := [2,4,8,0,32,64,9,37,512,37,2048,2112,104,2112,1,98,2112,2112,36,0,2049,32,1,3,105,65,2049,2112,2112,2113,68,33,36,33,2049,513]

theorem envBound43866 : H12AffineFastState.Bounded env43866 := by
  intro p hp
  have h : env43866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43865_43866 : H12AffineEnvironment.transform 3 0 env43865 = env43866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43865 == env43866) = true)

theorem identity43866 : scanCanonicalize (H12AffineFastState.compose env43866 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound43866 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43867 : List Nat := [2,4,8,0,32,64,9,37,65,37,2048,2112,104,2112,1,98,2112,2112,36,0,2049,32,1,3,105,65,2049,2112,2112,2113,68,33,36,33,2049,64]

theorem envBound43867 : H12AffineFastState.Bounded env43867 := by
  intro p hp
  have h : env43867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43866_43867 : H12AffineEnvironment.transform 8 65 env43866 = env43867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env43866 == env43867) = true)

theorem identity43867 : scanCanonicalize (H12AffineFastState.compose env43867 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound43867 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43868 : List Nat := [2,4,8,0,32,64,9,37,65,37,96,32,104,32,1,98,32,32,36,0,97,32,1,3,105,65,97,32,32,33,68,33,36,33,97,64]

theorem envBound43868 : H12AffineFastState.Bounded env43868 := by
  intro p hp
  have h : env43868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43867_43868 : H12AffineEnvironment.transform 10 96 env43867 = env43868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env43867 == env43868) = true)

theorem identity43868 : scanCanonicalize (H12AffineFastState.compose env43868 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound43868 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43869 : List Nat := [2,4,8,0,32,32,9,37,33,37,0,32,8,32,1,2,32,32,36,0,1,32,1,3,9,33,1,32,32,33,36,33,36,33,1,32]

theorem envBound43869 : H12AffineFastState.Bounded env43869 := by
  intro p hp
  have h : env43869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43868_43869 : H12AffineEnvironment.transform 5 32 env43868 = env43869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env43868 == env43869) = true)

theorem identity43869 : scanCanonicalize (H12AffineFastState.compose env43869 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43869 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43870 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,1,8,1,1,2,1,1,5,0,1,1,1,3,9,0,1,1,1,0,5,0,5,0,1,1]

theorem envBound43870 : H12AffineFastState.Bounded env43870 := by
  intro p hp
  have h : env43870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43869_43870 : H12AffineEnvironment.transform 4 1 env43869 = env43870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43869 == env43870) = true)

def env43871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,8388608,95497,8328,65,8560009,79130,8491470,8579232,8450329,119926,257,8484154,8492191,8509135]

theorem envBound43871 : H12AffineFastState.Bounded env43871 := by
  intro p hp
  have h : env43871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43845_43871 : H12AffineEnvironment.transform 21 33 env43845 = env43871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env43845 == env43871) = true)

theorem identity43871 : scanCanonicalize (H12AffineFastState.compose env43871 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound43871 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10401,1025,32769,4161,33,8388608,41430,8328,65,8560009,57797,8406289,8579232,8450329,169,257,8430053,8405056,8389136]

theorem envBound43872 : H12AffineFastState.Bounded env43872 := by
  intro p hp
  have h : env43872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43871_43872 : H12AffineEnvironment.transform 15 54495 env43871 = env43872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env43871 == env43872) = true)

def env43873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,33,8388608,41310,8192,65,8559873,57677,8406289,8579112,8450329,33,257,8429933,8405056,8389136]

theorem envBound43873 : H12AffineFastState.Bounded env43873 := by
  intro p hp
  have h : env43873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43872_43873 : H12AffineEnvironment.transform 6 8 env43872 = env43873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43872 == env43873) = true)

theorem identity43873 : scanCanonicalize (H12AffineFastState.compose env43873 (packedSelected [0,1,2,5,6,8,10,11,12,14,15,18,24,27,31] rootPS)) = affineNative (2^(22+1) ^^^ 147456) := by decide +kernel

theorem selectedBound43873 : packedSelected [0,1,2,5,6,8,10,11,12,14,15,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env43874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,33,147456,41310,8192,65,56577,57677,132369,43048,176409,33,257,188781,131136,147984]

theorem envBound43874 : H12AffineFastState.Bounded env43874 := by
  intro p hp
  have h : env43874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43873_43874 : H12AffineEnvironment.transform 22 147456 env43873 = env43874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env43873 == env43874) = true)

theorem identity43874 : scanCanonicalize (H12AffineFastState.compose env43874 (packedSelected [0,2,3,5,6,8,11,12,14,15,18,19,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound43874 : packedSelected [0,2,3,5,6,8,11,12,14,15,18,19,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1025,32769,4161,33,17,41310,8192,65,56577,57677,17664,43048,61704,33,257,41340,16465,513]

theorem envBound43875 : H12AffineFastState.Bounded env43875 := by
  intro p hp
  have h : env43875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43874_43875 : H12AffineEnvironment.transform 16 16401 env43874 = env43875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43874 == env43875) = true)

theorem identity43875 : scanCanonicalize (H12AffineFastState.compose env43875 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43875 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,10281,1025,32769,4161,33,17,41310,8192,65,34817,46157,4096,43048,41992,33,257,41340,5457,513]

theorem envBound43876 : H12AffineFastState.Bounded env43876 := by
  intro p hp
  have h : env43876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43875_43876 : H12AffineEnvironment.transform 13 5376 env43875 = env43876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43875 == env43876) = true)

theorem identity43876 : scanCanonicalize (H12AffineFastState.compose env43876 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43876 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1025,8541,4161,33,17,2,8192,65,10589,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound43877 : H12AffineFastState.Bounded env43877 := by
  intro p hp
  have h : env43877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43876_43877 : H12AffineEnvironment.transform 14 8540 env43876 = env43877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43876 == env43877) = true)

theorem identity43877 : scanCanonicalize (H12AffineFastState.compose env43877 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43877 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43878 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,5393,10281,1025,8460,4112,33,17,2,8192,16,10508,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound43878 : H12AffineFastState.Bounded env43878 := by
  intro p hp
  have h : env43878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43877_43878 : H12AffineEnvironment.transform 5 17 env43877 = env43878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43877 == env43878) = true)

theorem identity43878 : scanCanonicalize (H12AffineFastState.compose env43878 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43879 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,8232,8203,5172,10281,1025,8233,4112,33,17,2,8192,16,10281,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound43879 : H12AffineFastState.Bounded env43879 := by
  intro p hp
  have h : env43879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43878_43879 : H12AffineEnvironment.transform 7 37 env43878 = env43879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43878 == env43879) = true)

theorem identity43879 : scanCanonicalize (H12AffineFastState.compose env43879 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound43879 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43880 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5172,2048,1025,0,4112,33,17,2,41,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound43880 : H12AffineFastState.Bounded env43880 := by
  intro p hp
  have h : env43880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43879_43880 : H12AffineEnvironment.transform 12 41 env43879 = env43880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env43879 == env43880) = true)

def env43881 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,1,34,1028,2048,1025,0,32,33,17,2,41,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound43881 : H12AffineFastState.Bounded env43881 := by
  intro p hp
  have h : env43881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43880_43881 : H12AffineEnvironment.transform 11 48 env43880 = env43881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43880 == env43881) = true)

theorem identity43881 : scanCanonicalize (H12AffineFastState.compose env43881 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound43881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43882 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,41,1045,1,34,1028,1044,1025,0,32,33,17,2,41,16,1044,1028,48,1044,1056,33,36,32,1045,513]

theorem envBound43882 : H12AffineFastState.Bounded env43882 := by
  intro p hp
  have h : env43882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43881_43882 : H12AffineEnvironment.transform 10 1044 env43881 = env43882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env43881 == env43882) = true)

def env43883 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,33,1,34,48,32,53,0,32,33,17,2,41,16,32,48,48,32,20,33,36,32,33,513]

theorem envBound43883 : H12AffineFastState.Bounded env43883 := by
  intro p hp
  have h : env43883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43882_43883 : H12AffineEnvironment.transform 9 52 env43882 = env43883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43882 == env43883) = true)

theorem identity43883 : scanCanonicalize (H12AffineFastState.compose env43883 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43884 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,8,0,1,3,17,1,20,0,1,0,17,2,8,16,1,17,17,1,20,0,5,1,0,513]

theorem envBound43884 : H12AffineFastState.Bounded env43884 := by
  intro p hp
  have h : env43884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43883_43884 : H12AffineEnvironment.transform 4 1 env43883 = env43884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43883 == env43884) = true)

def leafEnv43884 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,8,0,1,3,17,1,20,0,1,0,17,2,21,8,1,16,1,17,17,1,20,0,5,1,5,3,0,513,1,1,0]

def active43884 : List Nat := [0,1,2,3,8]

def tree43884 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43884 : H12WitnessSearch.Good tree43884 := H12GlobalWitnessIndex.good

theorem leafIdentity43884 : H12AffineFastState.composeSystem env43884 rootObs = leafEnv43884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43884 rootObs == leafEnv43884) = true)

theorem terminalChecked43884 : H12PackedTerminal.terminalCheckFast leafEnv43884 active43884 tree43884 = true := by decide +kernel

def env43885 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,41,32,1,34,49,33,52,0,32,33,17,2,41,16,33,49,48,33,21,33,36,32,32,513]

theorem envBound43885 : H12AffineFastState.Bounded env43885 := by
  intro p hp
  have h : env43885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43882_43885 : H12AffineEnvironment.transform 9 53 env43882 = env43885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43882 == env43885) = true)

theorem identity43885 : scanCanonicalize (H12AffineFastState.compose env43885 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound43885 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43886 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,41,32,1,34,49,33,52,0,32,33,17,2,41,16,33,49,48,33,21,33,36,32,32,10]

theorem envBound43886 : H12AffineFastState.Bounded env43886 := by
  intro p hp
  have h : env43886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43885_43886 : H12AffineEnvironment.transform 8 11 env43885 = env43886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env43885 == env43886) = true)

def leafEnv43886 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,41,32,1,34,49,33,52,0,32,33,17,2,20,41,1,16,33,49,48,33,21,33,36,32,5,34,32,10,1,32,0]

def active43886 : List Nat := [0,1,2,3,4]

def tree43886 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43886 : H12WitnessSearch.Good tree43886 := H12GlobalWitnessIndex.good

theorem leafIdentity43886 : H12AffineFastState.composeSystem env43886 rootObs = leafEnv43886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43886 rootObs == leafEnv43886) = true)

theorem terminalChecked43886 : H12PackedTerminal.terminalCheckFast leafEnv43886 active43886 tree43886 = true := by decide +kernel

def env43887 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,1,34,1029,2048,1025,0,33,33,17,2,41,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound43887 : H12AffineFastState.Bounded env43887 := by
  intro p hp
  have h : env43887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43880_43887 : H12AffineEnvironment.transform 11 49 env43880 = env43887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43880 == env43887) = true)

theorem identity43887 : scanCanonicalize (H12AffineFastState.compose env43887 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43888 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,41,1044,1,34,1029,32,1025,0,33,33,17,2,41,16,32,1029,49,32,1056,33,36,32,1044,513]

theorem envBound43888 : H12AffineFastState.Bounded env43888 := by
  intro p hp
  have h : env43888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43887_43888 : H12AffineEnvironment.transform 10 32 env43887 = env43888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43887 == env43888) = true)

def env43889 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,41,32,1,34,49,32,53,0,33,33,17,2,41,16,32,49,49,32,20,33,36,32,32,513]

theorem envBound43889 : H12AffineFastState.Bounded env43889 := by
  intro p hp
  have h : env43889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43888_43889 : H12AffineEnvironment.transform 9 52 env43888 = env43889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43888 == env43889) = true)

theorem identity43889 : scanCanonicalize (H12AffineFastState.compose env43889 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43890 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,8,1,1,3,16,1,20,0,0,0,17,2,8,16,1,16,16,1,20,0,5,1,1,513]

theorem envBound43890 : H12AffineFastState.Bounded env43890 := by
  intro p hp
  have h : env43890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43889_43890 : H12AffineEnvironment.transform 4 1 env43889 = env43890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43889 == env43890) = true)

def leafEnv43890 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,8,1,1,3,16,1,20,0,0,0,17,2,21,8,1,16,1,16,16,1,20,0,5,1,5,3,1,513,1,0,0]

def active43890 : List Nat := [0,1,2,3,8]

def tree43890 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43890 : H12WitnessSearch.Good tree43890 := H12GlobalWitnessIndex.good

theorem leafIdentity43890 : H12AffineFastState.composeSystem env43890 rootObs = leafEnv43890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43890 rootObs == leafEnv43890) = true)

theorem terminalChecked43890 : H12PackedTerminal.terminalCheckFast leafEnv43890 active43890 tree43890 = true := by decide +kernel

def env43891 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,33,1,34,48,32,52,0,33,33,17,2,41,16,32,48,49,32,21,33,36,32,33,513]

theorem envBound43891 : H12AffineFastState.Bounded env43891 := by
  intro p hp
  have h : env43891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43888_43891 : H12AffineEnvironment.transform 9 53 env43888 = env43891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43888 == env43891) = true)

theorem identity43891 : scanCanonicalize (H12AffineFastState.compose env43891 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43891 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43892 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,41,33,1,34,48,32,52,0,33,33,17,2,41,16,32,48,49,32,21,33,36,32,33,11]

theorem envBound43892 : H12AffineFastState.Bounded env43892 := by
  intro p hp
  have h : env43892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43891_43892 : H12AffineEnvironment.transform 8 10 env43891 = env43892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43891 == env43892) = true)

def leafEnv43892 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,41,33,1,34,48,32,52,0,33,33,17,2,20,41,1,16,32,48,49,32,21,33,36,32,5,34,33,11,1,33,0]

def active43892 : List Nat := [0,1,2,3,4]

def tree43892 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43892 : H12WitnessSearch.Good tree43892 := H12GlobalWitnessIndex.good

theorem leafIdentity43892 : H12AffineFastState.composeSystem env43892 rootObs = leafEnv43892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43892 rootObs == leafEnv43892) = true)

theorem terminalChecked43892 : H12PackedTerminal.terminalCheckFast leafEnv43892 active43892 tree43892 = true := by decide +kernel

def env43893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1025,32769,4161,33,8388608,41311,8193,65,8559872,57676,8406289,8579113,8450329,32,257,8429932,8405056,8389136]

theorem envBound43893 : H12AffineFastState.Bounded env43893 := by
  intro p hp
  have h : env43893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43872_43893 : H12AffineEnvironment.transform 6 9 env43872 = env43893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43872 == env43893) = true)

theorem identity43893 : scanCanonicalize (H12AffineFastState.compose env43893 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43893 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10280,1025,8541,4161,33,8388608,3,8193,65,8535132,16400,8406289,8538485,8409157,32,257,8388656,8405056,8389136]

theorem envBound43894 : H12AffineFastState.Bounded env43894 := by
  intro p hp
  have h : env43894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43893_43894 : H12AffineEnvironment.transform 14 8540 env43893 = env43894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43893 == env43894) = true)

theorem identity43894 : scanCanonicalize (H12AffineFastState.compose env43894 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 20480) := by decide +kernel

theorem selectedBound43894 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10280,1025,8541,4161,33,20480,3,8193,65,158812,16400,5393,137589,69,32,257,20528,4160,21008]

theorem envBound43895 : H12AffineFastState.Bounded env43895 := by
  intro p hp
  have h : env43895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43894_43895 : H12AffineEnvironment.transform 22 20480 env43894 = env43895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env43894 == env43895) = true)

theorem identity43895 : scanCanonicalize (H12AffineFastState.compose env43895 (packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound43895 : packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env43896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,9499,131072,10280,1025,8541,4161,33,17,3,8193,65,146509,4097,5393,137589,69,32,257,33,4160,513]

theorem envBound43896 : H12AffineFastState.Bounded env43896 := by
  intro p hp
  have h : env43896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43895_43896 : H12AffineEnvironment.transform 13 4113 env43895 = env43896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env43895 == env43896) = true)

theorem identity43896 : scanCanonicalize (H12AffineFastState.compose env43896 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43896 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env43897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,9499,2065,10280,1025,8541,4161,33,17,3,8193,65,13404,4097,5393,4452,69,32,257,33,4160,513]

theorem envBound43897 : H12AffineFastState.Bounded env43897 := by
  intro p hp
  have h : env43897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43896_43897 : H12AffineEnvironment.transform 16 2065 env43896 = env43897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2065 env43896 == env43897) = true)

theorem identity43897 : scanCanonicalize (H12AffineFastState.compose env43897 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43897 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env43898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,0,1095,2065,2420,1025,1,4161,33,17,3,349,65,5376,4097,5393,4452,69,32,257,33,4160,513]

theorem envBound43898 : H12AffineFastState.Bounded env43898 := by
  intro p hp
  have h : env43898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43897_43898 : H12AffineEnvironment.transform 12 348 env43897 = env43898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43897 == env43898) = true)

theorem identity43898 : scanCanonicalize (H12AffineFastState.compose env43898 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43898 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,2048,0,1095,2065,2420,1025,1,2128,33,17,3,349,65,3345,2064,3328,2421,69,32,257,33,2129,513]

theorem envBound43899 : H12AffineFastState.Bounded env43899 := by
  intro p hp
  have h : env43899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43898_43899 : H12AffineEnvironment.transform 11 2065 env43898 = env43899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env43898 == env43899) = true)

theorem identity43899 : scanCanonicalize (H12AffineFastState.compose env43899 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43899 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43900 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2065,348,2048,0,343,2065,2420,273,1,2128,33,17,3,349,65,2049,2064,2064,2421,69,32,257,33,2129,513]

theorem envBound43900 : H12AffineFastState.Bounded env43900 := by
  intro p hp
  have h : env43900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43899_43900 : H12AffineEnvironment.transform 9 272 env43899 = env43900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43899 == env43900) = true)

theorem identity43900 : scanCanonicalize (H12AffineFastState.compose env43900 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43900 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43901 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,121,2048,0,114,2065,2129,52,1,2128,33,17,3,120,65,2049,2064,2064,2128,69,32,36,33,2129,513]

theorem envBound43901 : H12AffineFastState.Bounded env43901 := by
  intro p hp
  have h : env43901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43900_43901 : H12AffineEnvironment.transform 7 37 env43900 = env43901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43900 == env43901) = true)

def env43902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,351657,8328,65,12754345,79131,8763759,8830977,8706489,4314198,257,8484155,8492190,8781423]

theorem envBound43902 : H12AffineFastState.Bounded env43902 := by
  intro p hp
  have h : env43902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43792_43902 : H12AffineEnvironment.transform 23 351657 env43792 = env43902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351657 env43792 == env43902) = true)

def env43903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,4194304,8388608,95497,8328,65,12754345,79131,8491471,8579233,8450329,4314198,257,8484155,8492190,8509135]

theorem envBound43903 : H12AffineFastState.Bounded env43903 := by
  intro p hp
  have h : env43903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43902_43903 : H12AffineEnvironment.transform 17 10400 env43902 = env43903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43902 == env43903) = true)

def env43904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,8388608,95497,8328,65,8560009,79131,8491471,8579233,8450329,119926,257,8484155,8492190,8509135]

theorem envBound43904 : H12AffineFastState.Bounded env43904 := by
  intro p hp
  have h : env43904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43903_43904 : H12AffineEnvironment.transform 21 32 env43903 = env43904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env43903 == env43904) = true)

theorem identity43904 : scanCanonicalize (H12AffineFastState.compose env43904 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound43904 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,62661,95497,8328,65,158028,79131,91402,138340,1500,119926,257,98814,90203,74250]

theorem envBound43905 : H12AffineFastState.Bounded env43905 := by
  intro p hp
  have h : env43905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43904_43905 : H12AffineEnvironment.transform 22 62661 env43904 = env43905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env43904 == env43905) = true)

theorem identity43905 : scanCanonicalize (H12AffineFastState.compose env43905 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43905 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58516,32,62661,21762,8328,65,158028,5392,17665,138340,1500,62589,257,41461,16464,513]

theorem envBound43906 : H12AffineFastState.Bounded env43906 := by
  intro p hp
  have h : env43906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43905_43906 : H12AffineEnvironment.transform 15 8203 env43905 = env43906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43905 == env43906) = true)

theorem identity43906 : scanCanonicalize (H12AffineFastState.compose env43906 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound43906 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env43907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10400,1025,32769,58516,32,62661,21762,8328,65,10589,5392,17665,23669,1500,62589,257,41461,16464,513]

theorem envBound43907 : H12AffineFastState.Bounded env43907 := by
  intro p hp
  have h : env43907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43906_43907 : H12AffineEnvironment.transform 16 16401 env43906 = env43907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43906 == env43907) = true)

theorem identity43907 : scanCanonicalize (H12AffineFastState.compose env43907 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound43907 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43908 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,32768,8203,16401,10400,408,32769,57613,32,61788,20635,8328,65,10589,4233,16536,23020,69,61924,257,41461,16464,513]

theorem envBound43908 : H12AffineFastState.Bounded env43908 := by
  intro p hp
  have h : env43908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43907_43908 : H12AffineEnvironment.transform 9 409 env43907 = env43908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env43907 == env43908) = true)

theorem identity43908 : scanCanonicalize (H12AffineFastState.compose env43908 (packedSelected [0,14,17,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound43908 : packedSelected [0,14,17,27] rootPS < 2^1333 := by decide +kernel

def env43909 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,8192,16384,32768,8203,16401,10361,321,32769,57613,32,61788,20546,8273,65,10589,4176,16449,22837,69,61757,257,41260,16464,513]

theorem envBound43909 : H12AffineFastState.Bounded env43909 := by
  intro p hp
  have h : env43909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43908_43909 : H12AffineEnvironment.transform 6 89 env43908 = env43909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env43908 == env43909) = true)

theorem identity43909 : scanCanonicalize (H12AffineFastState.compose env43909 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43909 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43910 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,349,16384,32768,342,16401,2340,321,32769,49232,32,53249,20546,268,65,2048,4176,16449,22837,69,53344,257,32881,16464,513]

theorem envBound43910 : H12AffineFastState.Bounded env43910 := by
  intro p hp
  have h : env43910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43909_43910 : H12AffineEnvironment.transform 12 349 env43909 = env43910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43909 == env43910) = true)

theorem identity43910 : scanCanonicalize (H12AffineFastState.compose env43910 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 6208) := by decide +kernel

theorem selectedBound43910 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env43911 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,349,16384,6208,342,16401,2340,321,6209,22544,32,18497,20546,268,65,2048,4176,16449,22837,69,18464,257,6193,16464,513]

theorem envBound43911 : H12AffineFastState.Bounded env43911 := by
  intro p hp
  have h : env43911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43910_43911 : H12AffineEnvironment.transform 14 6208 env43910 = env43911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6208 env43910 == env43911) = true)

theorem identity43911 : scanCanonicalize (H12AffineFastState.compose env43911 (packedSelected [4,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound43911 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env43912 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,309,349,16384,2421,342,16401,2340,321,2420,18725,32,18497,16759,268,65,2048,357,16449,18432,69,18464,257,2308,16464,513]

theorem envBound43912 : H12AffineFastState.Bounded env43912 := by
  intro p hp
  have h : env43912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43911_43912 : H12AffineEnvironment.transform 11 309 env43911 = env43912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env43911 == env43912) = true)

theorem identity43912 : scanCanonicalize (H12AffineFastState.compose env43912 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound43912 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43913 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,309,349,2129,2421,342,2112,2340,321,2420,372,32,16,2342,268,65,2048,357,2064,81,69,113,257,2308,2049,513]

theorem envBound43913 : H12AffineFastState.Bounded env43913 := by
  intro p hp
  have h : env43913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43912_43913 : H12AffineEnvironment.transform 13 2129 env43912 = env43913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env43912 == env43913) = true)

theorem identity43913 : scanCanonicalize (H12AffineFastState.compose env43913 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43913 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43914 : List Nat := [2,4,8,16,32,64,89,36,512,100,2048,17,121,2129,2129,114,2112,2048,101,2128,80,32,16,2050,40,65,2048,65,2064,81,69,113,37,2080,2049,513]

theorem envBound43914 : H12AffineFastState.Bounded env43914 := by
  intro p hp
  have h : env43914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43913_43914 : H12AffineEnvironment.transform 7 36 env43913 = env43914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43913 == env43914) = true)

theorem identity43914 : scanCanonicalize (H12AffineFastState.compose env43914 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound43914 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43915 : List Nat := [2,4,8,16,32,64,89,36,512,100,512,17,121,593,593,114,576,512,101,592,80,32,16,514,40,65,512,65,528,81,69,113,37,544,513,513]

theorem envBound43915 : H12AffineFastState.Bounded env43915 := by
  intro p hp
  have h : env43915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43914_43915 : H12AffineEnvironment.transform 10 512 env43914 = env43915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env43914 == env43915) = true)

theorem identity43915 : scanCanonicalize (H12AffineFastState.compose env43915 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound43915 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43916 : List Nat := [2,4,8,16,32,1,24,36,512,37,512,17,56,528,528,51,513,512,36,529,17,32,16,514,40,0,512,0,528,16,4,48,37,544,513,513]

theorem envBound43916 : H12AffineFastState.Bounded env43916 := by
  intro p hp
  have h : env43916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43915_43916 : H12AffineEnvironment.transform 5 1 env43915 = env43916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43915 == env43916) = true)

theorem identity43916 : scanCanonicalize (H12AffineFastState.compose env43916 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43916 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43917 : List Nat := [2,4,8,1,32,1,9,36,512,37,512,0,41,513,513,34,513,512,36,512,0,32,1,514,40,0,512,0,513,1,4,33,37,544,513,513]

theorem envBound43917 : H12AffineFastState.Bounded env43917 := by
  intro p hp
  have h : env43917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43916_43917 : H12AffineEnvironment.transform 3 1 env43916 = env43917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43916 == env43917) = true)

def env43918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,8388608,95497,8328,65,8560008,79131,8491471,8579233,8450329,119927,257,8484155,8492190,8509135]

theorem envBound43918 : H12AffineFastState.Bounded env43918 := by
  intro p hp
  have h : env43918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43903_43918 : H12AffineEnvironment.transform 21 33 env43903 = env43918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env43903 == env43918) = true)

theorem identity43918 : scanCanonicalize (H12AffineFastState.compose env43918 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound43918 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1025,29909,77899,33,8388608,95497,8328,65,8546652,79131,8480027,8526965,8390093,73891,257,8484155,8478794,8462875]

theorem envBound43919 : H12AffineFastState.Bounded env43919 := by
  intro p hp
  have h : env43919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43918_43919 : H12AffineEnvironment.transform 14 29908 env43918 = env43919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env43918 == env43919) = true)

def env43920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,77899,33,8388608,73737,8328,65,8535132,79131,8466459,8526965,8390093,73891,257,8462395,8467786,8462875]

theorem envBound43920 : H12AffineFastState.Bounded env43920 := by
  intro p hp
  have h : env43920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43919_43920 : H12AffineEnvironment.transform 13 5376 env43919 = env43920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43919 == env43920) = true)

theorem identity43920 : scanCanonicalize (H12AffineFastState.compose env43920 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 153) := by decide +kernel

theorem selectedBound43920 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,77899,33,153,73737,8328,65,146629,79131,77954,138476,1364,73891,257,73890,79315,74370]

theorem envBound43921 : H12AffineFastState.Bounded env43921 := by
  intro p hp
  have h : env43921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43920_43921 : H12AffineEnvironment.transform 22 153 env43920 = env43921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env43920 == env43921) = true)

theorem identity43921 : scanCanonicalize (H12AffineFastState.compose env43921 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound43921 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5529,10400,1025,8661,77899,33,153,73737,8328,65,10588,79131,77954,2421,1364,73891,257,73890,79315,74370]

theorem envBound43922 : H12AffineFastState.Bounded env43922 := by
  intro p hp
  have h : env43922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43921_43922 : H12AffineEnvironment.transform 16 5529 env43921 = env43922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env43921 == env43922) = true)

theorem identity43922 : scanCanonicalize (H12AffineFastState.compose env43922 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43922 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env43923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,216,65536,5529,2476,1025,217,69959,33,153,65797,388,65,2128,70679,70030,2421,1364,65967,257,65966,70879,66446]

theorem envBound43923 : H12AffineFastState.Bounded env43923 := by
  intro p hp
  have h : env43923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43922_43923 : H12AffineEnvironment.transform 12 268 env43922 = env43923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43922 == env43923) = true)

theorem identity43923 : scanCanonicalize (H12AffineFastState.compose env43923 (packedSelected [0,7,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound43923 : packedSelected [0,7,11,15,20] rootPS < 2^1333 := by decide +kernel

def env43924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,216,399,5529,2476,1025,217,4296,33,153,138,388,65,2128,5528,4097,2421,1364,32,257,33,5456,513]

theorem envBound43924 : H12AffineFastState.Bounded env43924 := by
  intro p hp
  have h : env43924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43923_43924 : H12AffineEnvironment.transform 15 399 env43923 = env43924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env43923 == env43924) = true)

theorem identity43924 : scanCanonicalize (H12AffineFastState.compose env43924 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43924 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43925 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,136,399,5529,2476,1025,137,4248,33,153,138,388,17,2048,5528,4097,2341,1284,32,257,33,5376,513]

theorem envBound43925 : H12AffineFastState.Bounded env43925 := by
  intro p hp
  have h : env43925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43924_43925 : H12AffineEnvironment.transform 5 16 env43924 = env43925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43924 == env43925) = true)

theorem identity43925 : scanCanonicalize (H12AffineFastState.compose env43925 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound43925 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env43926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2200,268,3480,136,399,3329,2476,1025,137,2048,33,153,138,388,17,2048,3328,2201,2341,1284,32,257,33,3480,513]

theorem envBound43926 : H12AffineFastState.Bounded env43926 := by
  intro p hp
  have h : env43926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43925_43926 : H12AffineEnvironment.transform 11 2200 env43925 = env43926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env43925 == env43926) = true)

theorem identity43926 : scanCanonicalize (H12AffineFastState.compose env43926 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound43926 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env43927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,137,17,268,1297,136,399,1416,293,1025,137,137,33,153,138,388,17,137,1417,16,428,1284,32,257,33,1297,513]

theorem envBound43927 : H12AffineFastState.Bounded env43927 := by
  intro p hp
  have h : env43927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43926_43927 : H12AffineEnvironment.transform 10 137 env43926 = env43927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env43926 == env43927) = true)

theorem identity43927 : scanCanonicalize (H12AffineFastState.compose env43927 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43927 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43928 : List Nat := [2,4,8,16,32,16,128,172,512,1024,137,17,160,1213,136,35,1060,137,1025,137,137,33,153,138,40,17,137,1061,16,0,1192,32,173,33,1213,513]

theorem envBound43928 : H12AffineFastState.Bounded env43928 := by
  intro p hp
  have h : env43928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43927_43928 : H12AffineEnvironment.transform 7 172 env43927 = env43928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43927 == env43928) = true)

theorem identity43928 : scanCanonicalize (H12AffineFastState.compose env43928 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43928 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43929 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,17,40,1077,0,35,1060,1,1025,1,1,33,17,2,40,17,1,1061,16,0,1056,32,37,33,1077,513]

theorem envBound43929 : H12AffineFastState.Bounded env43929 := by
  intro p hp
  have h : env43929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43928_43929 : H12AffineEnvironment.transform 6 8 env43928 = env43929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43928 == env43929) = true)

theorem identity43929 : scanCanonicalize (H12AffineFastState.compose env43929 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43930 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1,17,8,1045,0,3,1028,1,1025,1,1,1,17,2,8,17,1,1029,16,0,1024,0,5,1,1045,513]

theorem envBound43930 : H12AffineFastState.Bounded env43930 := by
  intro p hp
  have h : env43930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43929_43930 : H12AffineEnvironment.transform 4 0 env43929 = env43930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43929 == env43930) = true)

theorem identity43930 : scanCanonicalize (H12AffineFastState.compose env43930 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43931 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,8,0,0,3,17,1,20,1,1,1,17,2,8,17,1,16,16,0,21,0,5,1,0,513]

theorem envBound43931 : H12AffineFastState.Bounded env43931 := by
  intro p hp
  have h : env43931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43930_43931 : H12AffineEnvironment.transform 9 21 env43930 = env43931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43930 == env43931) = true)

theorem identity43931 : scanCanonicalize (H12AffineFastState.compose env43931 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43932 : List Nat := [2,4,8,1,0,1,8,4,512,4,1,0,8,0,0,3,0,1,5,1,1,1,0,2,8,0,1,1,1,0,4,0,5,1,0,513]

theorem envBound43932 : H12AffineFastState.Bounded env43932 := by
  intro p hp
  have h : env43932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43931_43932 : H12AffineEnvironment.transform 3 1 env43931 = env43932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43931 == env43932) = true)

def env43933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,77899,33,8388608,73736,8328,65,8535133,79131,8466458,8526965,8390093,73891,257,8462394,8467787,8462875]

theorem envBound43933 : H12AffineFastState.Bounded env43933 := by
  intro p hp
  have h : env43933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43919_43933 : H12AffineEnvironment.transform 13 5377 env43919 = env43933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43919 == env43933) = true)

theorem identity43933 : scanCanonicalize (H12AffineFastState.compose env43933 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound43933 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,77899,33,17,73736,8328,65,146508,79131,77835,138340,1500,73891,257,73771,79194,74250]

theorem envBound43934 : H12AffineFastState.Bounded env43934 := by
  intro p hp
  have h : env43934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43933_43934 : H12AffineEnvironment.transform 22 17 env43933 = env43934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43933 == env43934) = true)

theorem identity43934 : scanCanonicalize (H12AffineFastState.compose env43934 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 70759) := by decide +kernel

theorem selectedBound43934 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70759,10400,1025,8660,77899,33,17,73736,8328,65,75819,79131,77835,67587,1500,73891,257,73771,79194,74250]

theorem envBound43935 : H12AffineFastState.Bounded env43935 := by
  intro p hp
  have h : env43935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43934_43935 : H12AffineEnvironment.transform 16 70759 env43934 = env43935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70759 env43934 == env43935) = true)

theorem identity43935 : scanCanonicalize (H12AffineFastState.compose env43935 (packedSelected [1,3,4,5,6,7,8,10,16,19,20,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43935 : packedSelected [1,3,4,5,6,7,8,10,16,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env43936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,70759,10280,1025,8540,77899,33,17,73736,8192,65,75819,79131,77835,67587,1364,73771,257,73771,79194,74250]

theorem envBound43936 : H12AffineFastState.Bounded env43936 := by
  intro p hp
  have h : env43936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43935_43936 : H12AffineEnvironment.transform 6 8 env43935 = env43936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43935 == env43936) = true)

theorem identity43936 : scanCanonicalize (H12AffineFastState.compose env43936 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43936 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13420,10280,1025,8540,4160,33,17,3,8192,65,2080,5392,4096,10248,1364,32,257,32,5457,513]

theorem envBound43937 : H12AffineFastState.Bounded env43937 := by
  intro p hp
  have h : env43937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43936_43937 : H12AffineEnvironment.transform 15 8203 env43936 = env43937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43936 == env43937) = true)

theorem identity43937 : scanCanonicalize (H12AffineFastState.compose env43937 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43937 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43938 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,5377,8492,8203,13341,10280,1025,8493,4145,33,17,3,8192,48,2080,5392,4096,10248,1317,32,257,32,5408,513]

theorem envBound43938 : H12AffineFastState.Bounded env43938 := by
  intro p hp
  have h : env43938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43937_43938 : H12AffineEnvironment.transform 5 49 env43937 = env43938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43937 == env43938) = true)

theorem identity43938 : scanCanonicalize (H12AffineFastState.compose env43938 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43938 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env43939 : List Nat := [2,4,8,16,32,49,8,256,512,53,2048,4096,8192,4404,8492,8203,12328,10280,52,8493,4145,33,17,3,8192,48,2080,4389,4096,10248,272,32,257,32,4373,513]

theorem envBound43939 : H12AffineFastState.Bounded env43939 := by
  intro p hp
  have h : env43939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43938_43939 : H12AffineEnvironment.transform 9 53 env43938 = env43939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43938 == env43939) = true)

theorem identity43939 : scanCanonicalize (H12AffineFastState.compose env43939 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43939 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43940 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,4096,8192,4372,8460,8203,12296,10248,20,8461,4113,1,17,3,8192,16,2048,4357,4096,10248,272,0,257,0,4373,513]

theorem envBound43940 : H12AffineFastState.Bounded env43940 := by
  intro p hp
  have h : env43940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43939_43940 : H12AffineEnvironment.transform 4 0 env43939 = env43940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43939 == env43940) = true)

theorem identity43940 : scanCanonicalize (H12AffineFastState.compose env43940 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound43940 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43941 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,4096,8,4372,260,3,4096,2048,20,261,4113,1,17,3,8,16,2048,4357,4096,2048,272,0,257,0,4373,513]

theorem envBound43941 : H12AffineFastState.Bounded env43941 := by
  intro p hp
  have h : env43941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43940_43941 : H12AffineEnvironment.transform 12 8 env43940 = env43941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env43940 == env43941) = true)

theorem identity43941 : scanCanonicalize (H12AffineFastState.compose env43941 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43941 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env43942 : List Nat := [2,4,8,16,0,17,8,256,512,21,1,4096,8,4372,260,3,4096,1,20,261,4113,1,17,3,8,16,1,4357,4096,1,272,0,257,0,4373,513]

theorem envBound43942 : H12AffineFastState.Bounded env43942 := by
  intro p hp
  have h : env43942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43941_43942 : H12AffineEnvironment.transform 10 1 env43941 = env43942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43941 == env43942) = true)

theorem identity43942 : scanCanonicalize (H12AffineFastState.compose env43942 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound43942 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43943 : List Nat := [2,4,8,16,0,17,8,256,512,21,1,260,8,16,260,3,260,1,20,261,277,1,17,3,8,16,1,1,260,1,272,0,257,0,17,513]

theorem envBound43943 : H12AffineFastState.Bounded env43943 := by
  intro p hp
  have h : env43943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43942_43943 : H12AffineEnvironment.transform 11 260 env43942 = env43943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env43942 == env43943) = true)

def env43944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,4194304,8388608,95496,8328,65,12754345,79131,8491470,8579232,8450328,4314198,257,8484155,8492190,8509134]

theorem envBound43944 : H12AffineFastState.Bounded env43944 := by
  intro p hp
  have h : env43944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43902_43944 : H12AffineEnvironment.transform 17 10401 env43902 = env43944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43902 == env43944) = true)

def env43945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,8388608,95496,8328,65,8560009,79131,8491470,8579232,8450328,119926,257,8484155,8492190,8509134]

theorem envBound43945 : H12AffineFastState.Bounded env43945 := by
  intro p hp
  have h : env43945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43944_43945 : H12AffineEnvironment.transform 21 32 env43944 = env43945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env43944 == env43945) = true)

def env43946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,8388608,95496,8192,65,8559873,79131,8491334,8579112,8450328,119926,257,8484155,8492054,8508998]

theorem envBound43946 : H12AffineFastState.Bounded env43946 := by
  intro p hp
  have h : env43946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43945_43946 : H12AffineEnvironment.transform 6 8 env43945 = env43946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43945 == env43946) = true)

theorem identity43946 : scanCanonicalize (H12AffineFastState.compose env43946 (packedSelected [4,7,9,11,14,16,18,20,23,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 119879) := by decide +kernel

theorem selectedBound43946 : packedSelected [4,7,9,11,14,16,18,20,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env43947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,119879,95496,8192,65,215366,79131,17665,212079,75103,119926,257,41340,16465,513]

theorem envBound43947 : H12AffineFastState.Bounded env43947 := by
  intro p hp
  have h : env43947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43946_43947 : H12AffineEnvironment.transform 22 119879 env43946 = env43947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 119879 env43946 == env43947) = true)

theorem identity43947 : scanCanonicalize (H12AffineFastState.compose env43947 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound43947 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1025,8460,91419,32,95562,95496,8192,65,215366,79131,17665,212079,75103,95611,257,113,16465,513]

theorem envBound43948 : H12AffineFastState.Bounded env43948 := by
  intro p hp
  have h : env43948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43947_43948 : H12AffineEnvironment.transform 14 8461 env43947 = env43948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env43947 == env43948) = true)

theorem identity43948 : scanCanonicalize (H12AffineFastState.compose env43948 (packedSelected [0,3,7,12,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound43948 : packedSelected [0,3,7,12,20,24] rootPS < 2^1333 := by decide +kernel

def env43949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21510,131072,10281,1025,8460,12573,32,8524,8462,8192,65,138560,24861,17665,157801,29017,8573,257,113,16465,513]

theorem envBound43949 : H12AffineFastState.Bounded env43949 := by
  intro p hp
  have h : env43949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43948_43949 : H12AffineEnvironment.transform 15 21510 env43948 = env43949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env43948 == env43949) = true)

theorem identity43949 : scanCanonicalize (H12AffineFastState.compose env43949 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound43949 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21510,13340,10281,1025,8460,12573,32,8524,8462,8192,65,10588,24861,17665,23669,29017,8573,257,113,16465,513]

theorem envBound43950 : H12AffineFastState.Bounded env43950 := by
  intro p hp
  have h : env43950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43949_43950 : H12AffineEnvironment.transform 16 13340 env43949 = env43950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env43949 == env43950) = true)

theorem identity43950 : scanCanonicalize (H12AffineFastState.compose env43950 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43950 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,21510,5393,2340,1025,1,4112,32,65,3,269,65,2129,16400,17665,23669,20564,112,257,113,16465,513]

theorem envBound43951 : H12AffineFastState.Bounded env43951 := by
  intro p hp
  have h : env43951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43950_43951 : H12AffineEnvironment.transform 12 269 env43950 = env43951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43950 == env43951) = true)

theorem identity43951 : scanCanonicalize (H12AffineFastState.compose env43951 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound43951 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,0,342,5393,2340,1025,1,4112,32,65,3,269,65,2129,5440,4177,2341,1284,112,257,113,5377,513]

theorem envBound43952 : H12AffineFastState.Bounded env43952 := by
  intro p hp
  have h : env43952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43951_43952 : H12AffineEnvironment.transform 13 5456 env43951 = env43952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env43951 == env43952) = true)

theorem identity43952 : scanCanonicalize (H12AffineFastState.compose env43952 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43952 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43953 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,269,4161,0,342,4096,2340,272,1,4112,32,65,3,269,65,2129,4177,4177,2341,21,112,257,113,4112,513]

theorem envBound43953 : H12AffineFastState.Bounded env43953 := by
  intro p hp
  have h : env43953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43952_43953 : H12AffineEnvironment.transform 9 273 env43952 = env43953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43952 == env43953) = true)

theorem identity43953 : scanCanonicalize (H12AffineFastState.compose env43953 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43953 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env43954 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4112,0,263,4096,2340,272,1,4112,32,16,3,269,16,2048,4096,4096,2341,21,33,257,32,4112,513]

theorem envBound43954 : H12AffineFastState.Bounded env43954 := by
  intro p hp
  have h : env43954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43953_43954 : H12AffineEnvironment.transform 5 17 env43953 = env43954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43953 == env43954) = true)

theorem identity43954 : scanCanonicalize (H12AffineFastState.compose env43954 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound43954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43955 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,308,269,292,0,263,308,2340,272,1,292,32,16,3,269,16,2048,308,308,2341,21,33,257,32,292,513]

theorem envBound43955 : H12AffineFastState.Bounded env43955 := by
  intro p hp
  have h : env43955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43954_43955 : H12AffineEnvironment.transform 11 308 env43954 = env43955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env43954 == env43955) = true)

theorem identity43955 : scanCanonicalize (H12AffineFastState.compose env43955 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43955 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43956 : List Nat := [2,4,8,16,32,17,8,256,512,273,1,308,269,292,0,263,308,293,272,1,292,32,16,3,269,16,1,308,308,292,21,33,257,32,292,513]

theorem envBound43956 : H12AffineFastState.Bounded env43956 := by
  intro p hp
  have h : env43956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43955_43956 : H12AffineEnvironment.transform 10 1 env43955 = env43956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43955 == env43956) = true)

def env43957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,8388608,95496,8193,65,8559872,79131,8491335,8579113,8450328,119926,257,8484155,8492055,8508999]

theorem envBound43957 : H12AffineFastState.Bounded env43957 := by
  intro p hp
  have h : env43957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43945_43957 : H12AffineEnvironment.transform 6 9 env43945 = env43957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43945 == env43957) = true)

theorem identity43957 : scanCanonicalize (H12AffineFastState.compose env43957 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,91467,32,8388608,95496,8193,65,8535132,79131,8466459,8538485,8409156,95530,257,8484155,8467787,8484635]

theorem envBound43958 : H12AffineFastState.Bounded env43958 := by
  intro p hp
  have h : env43958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43957_43958 : H12AffineEnvironment.transform 14 8540 env43957 = env43958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43957 == env43958) = true)

theorem identity43958 : scanCanonicalize (H12AffineFastState.compose env43958 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound43958 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,5392,10280,1025,8541,91467,32,8388608,95496,8193,65,8399180,79131,8466459,8412261,8409156,95530,257,8484155,8467787,8484635]

theorem envBound43959 : H12AffineFastState.Bounded env43959 := by
  intro p hp
  have h : env43959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43958_43959 : H12AffineEnvironment.transform 16 5392 env43958 = env43959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env43958 == env43959) = true)

theorem identity43959 : scanCanonicalize (H12AffineFastState.compose env43959 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound43959 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,5392,10280,1025,8541,91467,32,16,95496,8193,65,10588,79131,77835,23669,20564,95530,257,95531,79195,96011]

theorem envBound43960 : H12AffineFastState.Bounded env43960 := by
  intro p hp
  have h : env43960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43959_43960 : H12AffineEnvironment.transform 22 16 env43959 = env43960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43959 == env43960) = true)

theorem identity43960 : scanCanonicalize (H12AffineFastState.compose env43960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound43960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,9499,5392,10280,1025,8541,16464,32,16,20499,8193,65,10588,4096,5392,23669,20564,20529,257,20528,4160,21008]

theorem envBound43961 : H12AffineFastState.Bounded env43961 := by
  intro p hp
  have h : env43961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43960_43961 : H12AffineEnvironment.transform 15 9499 env43960 = env43961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env43960 == env43961) = true)

theorem identity43961 : scanCanonicalize (H12AffineFastState.compose env43961 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound43961 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,9499,5392,10280,1025,8541,4161,32,16,2,8193,65,10588,4096,5392,3172,69,32,257,33,4160,513]

theorem envBound43962 : H12AffineFastState.Bounded env43962 := by
  intro p hp
  have h : env43962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43961_43962 : H12AffineEnvironment.transform 13 4113 env43961 = env43962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env43961 == env43962) = true)

theorem identity43962 : scanCanonicalize (H12AffineFastState.compose env43962 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound43962 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,8192,3173,8540,9499,2404,10280,1025,8541,3125,32,16,2,8193,65,10588,3188,2404,3172,69,32,257,33,3124,513]

theorem envBound43963 : H12AffineFastState.Bounded env43963 := by
  intro p hp
  have h : env43963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43962_43963 : H12AffineEnvironment.transform 11 3188 env43962 = env43963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env43962 == env43963) = true)

theorem identity43963 : scanCanonicalize (H12AffineFastState.compose env43963 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43963 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env43964 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3188,8192,3173,8312,9279,2112,10280,1025,8313,3125,32,16,2,8193,65,10360,3188,2112,3172,69,32,37,33,3124,513]

theorem envBound43964 : H12AffineFastState.Bounded env43964 := by
  intro p hp
  have h : env43964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43963_43964 : H12AffineEnvironment.transform 7 36 env43963 = env43964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43963 == env43964) = true)

theorem identity43964 : scanCanonicalize (H12AffineFastState.compose env43964 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound43964 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43965 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3188,120,3173,0,1095,2112,2128,1025,1,3125,32,16,2,121,65,2048,3188,2112,3172,69,32,37,33,3124,513]

theorem envBound43965 : H12AffineFastState.Bounded env43965 := by
  intro p hp
  have h : env43965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43964_43965 : H12AffineEnvironment.transform 12 120 env43964 = env43965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env43964 == env43965) = true)

theorem identity43965 : scanCanonicalize (H12AffineFastState.compose env43965 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound43965 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43966 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2112,120,2129,0,115,2112,2128,53,1,2049,32,16,2,121,65,2048,2112,2112,2128,69,32,37,33,2048,513]

theorem envBound43966 : H12AffineFastState.Bounded env43966 := by
  intro p hp
  have h : env43966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43965_43966 : H12AffineEnvironment.transform 9 52 env43965 = env43966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43965 == env43966) = true)

theorem identity43966 : scanCanonicalize (H12AffineFastState.compose env43966 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound43966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43967 : List Nat := [2,4,8,16,32,64,9,36,512,52,96,32,120,49,0,115,32,48,53,1,97,32,16,2,121,65,96,32,32,48,69,32,37,33,96,513]

theorem envBound43967 : H12AffineFastState.Bounded env43967 := by
  intro p hp
  have h : env43967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43966_43967 : H12AffineEnvironment.transform 10 96 env43966 = env43967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env43966 == env43967) = true)

theorem identity43967 : scanCanonicalize (H12AffineFastState.compose env43967 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound43967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43968 : List Nat := [2,4,8,16,32,64,9,36,81,52,96,32,120,49,0,115,32,48,53,1,97,32,16,2,121,65,96,32,32,48,69,32,37,33,96,80]

theorem envBound43968 : H12AffineFastState.Bounded env43968 := by
  intro p hp
  have h : env43968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43967_43968 : H12AffineEnvironment.transform 8 81 env43967 = env43968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env43967 == env43968) = true)

theorem identity43968 : scanCanonicalize (H12AffineFastState.compose env43968 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43969 : List Nat := [2,4,8,16,0,64,9,4,81,20,64,0,88,17,0,83,0,16,21,1,65,0,16,2,89,65,64,0,0,16,69,0,5,1,64,80]

theorem envBound43969 : H12AffineFastState.Bounded env43969 := by
  intro p hp
  have h : env43969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43968_43969 : H12AffineEnvironment.transform 4 0 env43968 = env43969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43968 == env43969) = true)

theorem identity43969 : scanCanonicalize (H12AffineFastState.compose env43969 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43970 : List Nat := [2,4,2,16,0,64,3,4,81,20,64,0,82,17,0,83,0,16,21,1,65,0,16,2,83,65,64,0,0,16,69,0,5,1,64,80]

theorem envBound43970 : H12AffineFastState.Bounded env43970 := by
  intro p hp
  have h : env43970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43969_43970 : H12AffineEnvironment.transform 2 2 env43969 = env43970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43969 == env43970) = true)

def env43971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,8388608,95496,8328,65,8560008,79131,8491470,8579232,8450328,119927,257,8484155,8492190,8509134]

theorem envBound43971 : H12AffineFastState.Bounded env43971 := by
  intro p hp
  have h : env43971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43944_43971 : H12AffineEnvironment.transform 21 33 env43944 = env43971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env43944 == env43971) = true)

theorem identity43971 : scanCanonicalize (H12AffineFastState.compose env43971 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound43971 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,17,95496,8328,65,171417,79131,102879,190641,61705,119927,257,95530,103567,120543]

theorem envBound43972 : H12AffineFastState.Bounded env43972 := by
  intro p hp
  have h : env43972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43971_43972 : H12AffineEnvironment.transform 22 17 env43971 = env43972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43971 == env43972) = true)

theorem identity43972 : scanCanonicalize (H12AffineFastState.compose env43972 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound43972 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env43973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10401,1025,32769,4160,33,17,41430,8328,65,171417,57797,17665,190641,61705,169,257,41460,16465,513]

theorem envBound43973 : H12AffineFastState.Bounded env43973 := by
  intro p hp
  have h : env43973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43972_43973 : H12AffineEnvironment.transform 15 54494 env43972 = env43973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env43972 == env43973) = true)

def env43974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,33,17,41310,8192,65,171281,57677,17665,190521,61705,33,257,41340,16465,513]

theorem envBound43974 : H12AffineFastState.Bounded env43974 := by
  intro p hp
  have h : env43974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43973_43974 : H12AffineEnvironment.transform 6 8 env43973 = env43974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43973 == env43974) = true)

theorem identity43974 : scanCanonicalize (H12AffineFastState.compose env43974 (packedSelected [0,4,7,9,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound43974 : packedSelected [0,4,7,9,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env43975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5392,10281,1025,32769,4160,33,17,41310,8192,65,34817,57677,17665,64809,61705,33,257,41340,16465,513]

theorem envBound43975 : H12AffineFastState.Bounded env43975 := by
  intro p hp
  have h : env43975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43974_43975 : H12AffineEnvironment.transform 16 5392 env43974 = env43975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env43974 == env43975) = true)

theorem identity43975 : scanCanonicalize (H12AffineFastState.compose env43975 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43975 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,5392,10281,1025,0,4160,33,17,8543,8192,65,2048,24908,17665,32040,28936,33,257,8573,16465,513]

theorem envBound43976 : H12AffineFastState.Bounded env43976 := by
  intro p hp
  have h : env43976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43975_43976 : H12AffineEnvironment.transform 14 1 env43975 = env43976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43975 == env43976) = true)

theorem identity43976 : scanCanonicalize (H12AffineFastState.compose env43976 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43976 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,342,5392,10281,1025,0,4160,33,17,8543,8192,65,2048,13389,4096,10281,9225,33,257,8573,5456,513]

theorem envBound43977 : H12AffineFastState.Bounded env43977 := by
  intro p hp
  have h : env43977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43976_43977 : H12AffineEnvironment.transform 13 5377 env43976 = env43977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43976 == env43977) = true)

theorem identity43977 : scanCanonicalize (H12AffineFastState.compose env43977 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43977 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2420,1025,0,4160,33,17,2,349,65,2048,5392,4096,2420,1364,33,257,32,5456,513]

theorem envBound43978 : H12AffineFastState.Bounded env43978 := by
  intro p hp
  have h : env43978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43977_43978 : H12AffineEnvironment.transform 12 349 env43977 = env43978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43977 == env43978) = true)

def env43979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1025,32769,4160,33,17,41311,8193,65,171280,57676,17665,190520,61705,32,257,41341,16465,513]

theorem envBound43979 : H12AffineFastState.Bounded env43979 := by
  intro p hp
  have h : env43979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43973_43979 : H12AffineEnvironment.transform 6 9 env43973 = env43979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43973 == env43979) = true)

theorem identity43979 : scanCanonicalize (H12AffineFastState.compose env43979 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43979 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,131072,10280,1025,8541,4160,33,17,3,8193,65,146508,16400,17665,149860,20565,32,257,33,16465,513]

theorem envBound43980 : H12AffineFastState.Bounded env43980 := by
  intro p hp
  have h : env43980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43979_43980 : H12AffineEnvironment.transform 14 8540 env43979 = env43980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43979 == env43980) = true)

theorem identity43980 : scanCanonicalize (H12AffineFastState.compose env43980 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 22528) := by decide +kernel

theorem selectedBound43980 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env43981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,22528,10280,1025,8541,4160,33,17,3,8193,65,25676,16400,17665,4452,20565,32,257,33,16465,513]

theorem envBound43981 : H12AffineFastState.Bounded env43981 := by
  intro p hp
  have h : env43981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43980_43981 : H12AffineEnvironment.transform 16 22528 env43980 = env43981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 22528 env43980 == env43981) = true)

theorem identity43981 : scanCanonicalize (H12AffineFastState.compose env43981 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43981 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env43982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21591,22528,2420,1025,1,4160,33,17,3,349,65,17680,16400,17665,4452,20565,32,257,33,16465,513]

theorem envBound43982 : H12AffineFastState.Bounded env43982 := by
  intro p hp
  have h : env43982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43981_43982 : H12AffineEnvironment.transform 12 348 env43981 = env43982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43981 == env43982) = true)

theorem identity43982 : scanCanonicalize (H12AffineFastState.compose env43982 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound43982 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,2048,0,7255,4096,2420,1025,1,4160,33,17,3,349,65,3344,2064,3329,4452,6229,32,257,33,2129,513]

theorem envBound43983 : H12AffineFastState.Bounded env43983 := by
  intro p hp
  have h : env43983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43982_43983 : H12AffineEnvironment.transform 13 2048 env43982 = env43983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env43982 == env43983) = true)

theorem identity43983 : scanCanonicalize (H12AffineFastState.compose env43983 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound43983 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,348,2048,0,343,3328,2420,1025,1,3392,33,17,3,349,65,3344,2064,3329,3172,1365,32,257,33,2129,513]

theorem envBound43984 : H12AffineFastState.Bounded env43984 := by
  intro p hp
  have h : env43984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43983_43984 : H12AffineEnvironment.transform 11 3328 env43983 = env43984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env43983 == env43984) = true)

theorem identity43984 : scanCanonicalize (H12AffineFastState.compose env43984 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43985 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2113,348,2048,0,343,2113,2420,320,1,2049,33,17,3,349,65,2129,2064,2112,2341,20,32,257,33,2129,513]

theorem envBound43985 : H12AffineFastState.Bounded env43985 := by
  intro p hp
  have h : env43985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43984_43985 : H12AffineEnvironment.transform 9 321 env43984 = env43985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43984 == env43985) = true)

theorem identity43985 : scanCanonicalize (H12AffineFastState.compose env43985 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43985 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43986 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2064,269,2048,0,262,2064,2341,273,1,2049,33,17,3,268,16,2048,2064,2065,2341,20,32,257,33,2048,513]

theorem envBound43986 : H12AffineFastState.Bounded env43986 := by
  intro p hp
  have h : env43986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43985_43986 : H12AffineEnvironment.transform 5 17 env43985 = env43986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43985 == env43986) = true)

theorem identity43986 : scanCanonicalize (H12AffineFastState.compose env43986 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound43986 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43987 : List Nat := [2,4,8,16,32,17,9,256,512,272,17,1,269,17,0,262,1,308,273,1,16,33,17,3,268,16,17,1,0,308,20,32,257,33,17,513]

theorem envBound43987 : H12AffineFastState.Bounded env43987 := by
  intro p hp
  have h : env43987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43986_43987 : H12AffineEnvironment.transform 10 17 env43986 = env43987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env43986 == env43987) = true)

theorem identity43987 : scanCanonicalize (H12AffineFastState.compose env43987 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound43987 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43988 : List Nat := [2,4,8,16,32,17,9,63,512,47,17,1,50,17,0,57,1,11,46,1,16,33,17,3,51,16,17,1,0,11,20,32,62,33,17,513]

theorem envBound43988 : H12AffineFastState.Bounded env43988 := by
  intro p hp
  have h : env43988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43987_43988 : H12AffineEnvironment.transform 7 63 env43987 = env43988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env43987 == env43988) = true)

theorem identity43988 : scanCanonicalize (H12AffineFastState.compose env43988 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43988 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43989 : List Nat := [2,4,8,16,11,17,9,20,512,4,17,1,25,17,0,18,1,11,5,1,16,10,17,3,24,16,17,1,0,11,20,11,21,10,17,513]

theorem envBound43989 : H12AffineFastState.Bounded env43989 := by
  intro p hp
  have h : env43989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43988_43989 : H12AffineEnvironment.transform 4 11 env43988 = env43989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43988 == env43989) = true)

theorem identity43989 : scanCanonicalize (H12AffineFastState.compose env43989 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43989 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43990 : List Nat := [2,4,8,11,11,10,9,15,512,4,10,1,2,10,0,9,1,11,5,1,11,10,10,3,3,11,10,1,0,11,15,11,14,10,10,513]

theorem envBound43990 : H12AffineFastState.Bounded env43990 := by
  intro p hp
  have h : env43990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43989_43990 : H12AffineEnvironment.transform 3 11 env43989 = env43990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43989 == env43990) = true)

theorem identity43990 : scanCanonicalize (H12AffineFastState.compose env43990 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43991 : List Nat := [2,0,8,11,11,10,9,11,512,0,10,1,2,10,0,9,1,11,1,1,11,10,10,3,3,11,10,1,0,11,11,11,10,10,10,513]

theorem envBound43991 : H12AffineFastState.Bounded env43991 := by
  intro p hp
  have h : env43991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43990_43991 : H12AffineEnvironment.transform 1 0 env43990 = env43991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43990 == env43991) = true)

theorem identity43991 : scanCanonicalize (H12AffineFastState.compose env43991 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43991 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43992 : List Nat := [2,0,1,2,2,3,0,2,512,0,3,1,2,3,0,0,1,2,1,1,2,3,3,3,3,2,3,1,0,2,2,2,3,3,3,513]

theorem envBound43992 : H12AffineFastState.Bounded env43992 := by
  intro p hp
  have h : env43992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43991_43992 : H12AffineEnvironment.transform 2 1 env43991 = env43992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43991 == env43992) = true)

def env43993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,536870912,1073741824,92374097,4294967296,525568,4308116844,620851225,25733063]

theorem envBound43993 : H12AffineFastState.Bounded env43993 := by
  intro p hp
  have h : env43993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31845_43993 : H12AffineEnvironment.transform 27 19497101 env31845 = env43993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497101 env31845 == env43993) = true)

def env43994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,4294967296,525568,4308116844,27337993,25733063]

theorem envBound43994 : H12AffineFastState.Bounded env43994 := by
  intro p hp
  have h : env43994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43993_43994 : H12AffineEnvironment.transform 28 77616400 env43993 = env43994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env43993 == env43994) = true)

def env43995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound43995 : H12AffineFastState.Bounded env43995 := by
  intro p hp
  have h : env43995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43994_43995 : H12AffineEnvironment.transform 31 145662400 env43994 = env43995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env43994 == env43995) = true)

def env43996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound43996 : H12AffineFastState.Bounded env43996 := by
  intro p hp
  have h : env43996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43995_43996 : H12AffineEnvironment.transform 29 155254784 env43995 = env43996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env43995 == env43996) = true)

def env43997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound43997 : H12AffineFastState.Bounded env43997 := by
  intro p hp
  have h : env43997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43996_43997 : H12AffineEnvironment.transform 25 64 env43996 = env43997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env43996 == env43997) = true)

def env43998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound43998 : H12AffineFastState.Bounded env43998 := by
  intro p hp
  have h : env43998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43997_43998 : H12AffineEnvironment.transform 26 30393344 env43997 = env43998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env43997 == env43998) = true)

def env43999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound43999 : H12AffineFastState.Bounded env43999 := by
  intro p hp
  have h : env43999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43998_43999 : H12AffineEnvironment.transform 18 1024 env43998 = env43999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env43998 == env43999) = true)

theorem identity43999 : scanCanonicalize (H12AffineFastState.compose env43999 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41412) := by decide +kernel

theorem selectedBound43999 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21455300,18973837,2159764,418244,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound44000 : H12AffineFastState.Bounded env44000 := by
  intro p hp
  have h : env44000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43999_44000 : H12AffineEnvironment.transform 22 41412 env43999 = env44000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41412 env43999 == env44000) = true)

def env44001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21331968,18973837,2159764,294912,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound44001 : H12AffineFastState.Bounded env44001 := by
  intro p hp
  have h : env44001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44000_44001 : H12AffineEnvironment.transform 16 57796 env44000 = env44001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env44000 == env44001) = true)

theorem identity44001 : scanCanonicalize (H12AffineFastState.compose env44001 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound44001 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41412,2,8328,64,4554754,2196623,2159764,294912,75223,6383042,256,2188650,2196687,513]

theorem envBound44002 : H12AffineFastState.Bounded env44002 := by
  intro p hp
  have h : env44002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44001_44002 : H12AffineEnvironment.transform 23 2 env44001 = env44002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env44001 == env44002) = true)

def env44003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10280,1024,32769,2097152,4194304,41412,2,8328,64,4302890,2196623,2159764,43048,75223,6383042,256,2188650,2196687,513]

theorem envBound44003 : H12AffineFastState.Bounded env44003 := by
  intro p hp
  have h : env44003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44002_44003 : H12AffineEnvironment.transform 17 10280 env44002 = env44003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44002 == env44003) = true)

theorem identity44003 : scanCanonicalize (H12AffineFastState.compose env44003 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44003 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302890,2196487,2159644,43048,75103,6382922,256,2188650,2196551,513]

theorem envBound44004 : H12AffineFastState.Bounded env44004 := by
  intro p hp
  have h : env44004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44003_44004 : H12AffineEnvironment.transform 6 8 env44003 = env44004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44003 == env44004) = true)

theorem identity44004 : scanCanonicalize (H12AffineFastState.compose env44004 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44004 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env44005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,2,8192,64,4262262,2172251,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound44005 : H12AffineFastState.Bounded env44005 := by
  intro p hp
  have h : env44005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44004_44005 : H12AffineEnvironment.transform 14 8540 env44004 = env44005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44004 == env44005) = true)

theorem identity44005 : scanCanonicalize (H12AffineFastState.compose env44005 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound44005 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91466,4194304,16,2,8192,64,4262262,16401,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound44006 : H12AffineFastState.Bounded env44006 := by
  intro p hp
  have h : env44006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44005_44006 : H12AffineEnvironment.transform 20 91466 env44005 = env44006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env44005 == env44006) = true)

theorem identity44006 : scanCanonicalize (H12AffineFastState.compose env44006 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound44006 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16400,10280,1024,8541,25629,4194304,16,2,8192,64,4196385,16401,12637,2420,9224,4194304,256,32,16465,513]

theorem envBound44007 : H12AffineFastState.Bounded env44007 := by
  intro p hp
  have h : env44007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44006_44007 : H12AffineEnvironment.transform 15 343 env44006 = env44007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env44006 == env44007) = true)

theorem identity44007 : scanCanonicalize (H12AffineFastState.compose env44007 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44007 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,343,16400,2420,1024,1,17729,4194304,16,2,348,64,4196385,16401,4097,2420,1364,4194304,256,32,16465,513]

theorem envBound44008 : H12AffineFastState.Bounded env44008 := by
  intro p hp
  have h : env44008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44007_44008 : H12AffineEnvironment.transform 12 348 env44007 = env44008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44007 == env44008) = true)

theorem identity44008 : scanCanonicalize (H12AffineFastState.compose env44008 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44009 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1024,1,17680,4194304,16,2,269,17,4196385,16401,4097,2341,1285,4194304,256,32,16384,513]

theorem envBound44009 : H12AffineFastState.Bounded env44009 := by
  intro p hp
  have h : env44009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44008_44009 : H12AffineEnvironment.transform 5 17 env44008 = env44009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44008 == env44009) = true)

theorem identity44009 : scanCanonicalize (H12AffineFastState.compose env44009 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound44009 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env44010 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1024,1,17680,21508,16,2,269,17,23589,16401,4097,2341,1285,21508,256,32,16384,513]

theorem envBound44010 : H12AffineFastState.Bounded env44010 := by
  intro p hp
  have h : env44010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44009_44010 : H12AffineEnvironment.transform 21 21508 env44009 = env44010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env44009 == env44010) = true)

theorem identity44010 : scanCanonicalize (H12AffineFastState.compose env44010 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44010 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44011 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5157,0,262,5173,2341,1024,1,4405,33,16,2,269,17,2048,5172,4097,2341,1285,33,256,32,5157,513]

theorem envBound44011 : H12AffineFastState.Bounded env44011 := by
  intro p hp
  have h : env44011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44010_44011 : H12AffineEnvironment.transform 13 5157 env44010 = env44011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44010 == env44011) = true)

def env44012 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2837,0,262,2821,2341,1024,1,3589,33,16,2,269,17,2048,2820,3889,2341,1285,33,256,32,2837,513]

theorem envBound44012 : H12AffineFastState.Bounded env44012 := by
  intro p hp
  have h : env44012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44011_44012 : H12AffineEnvironment.transform 11 3888 env44011 = env44012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env44011 == env44012) = true)

def env44013 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1045,0,262,1029,1573,1024,1,261,33,16,2,269,17,1792,1028,49,1573,1285,33,256,32,1045,513]

theorem envBound44013 : H12AffineFastState.Bounded env44013 := by
  intro p hp
  have h : env44013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44012_44013 : H12AffineEnvironment.transform 10 1792 env44012 = env44013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44012 == env44013) = true)

theorem identity44013 : scanCanonicalize (H12AffineFastState.compose env44013 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound44013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44014 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,48,269,560,0,262,544,0,549,1,261,33,16,2,269,17,293,545,49,0,800,33,256,32,560,513]

theorem envBound44014 : H12AffineFastState.Bounded env44014 := by
  intro p hp
  have h : env44014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44013_44014 : H12AffineEnvironment.transform 9 549 env44013 = env44014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env44013 == env44014) = true)

def env44015 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,269,32,0,262,48,0,53,1,261,33,16,2,269,17,293,49,49,0,304,33,256,32,32,17]

theorem envBound44015 : H12AffineFastState.Bounded env44015 := by
  intro p hp
  have h : env44015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44014_44015 : H12AffineEnvironment.transform 8 16 env44014 = env44015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44014 == env44015) = true)

theorem identity44015 : scanCanonicalize (H12AffineFastState.compose env44015 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44016 : List Nat := [2,4,8,16,32,17,8,5,16,53,32,48,8,32,0,3,48,0,53,1,0,33,16,2,8,17,32,49,49,0,53,33,5,32,32,17]

theorem envBound44016 : H12AffineFastState.Bounded env44016 := by
  intro p hp
  have h : env44016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44015_44016 : H12AffineEnvironment.transform 7 5 env44015 = env44016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44015 == env44016) = true)

def leafEnv44016 : List Nat := [2,4,8,16,32,17,8,5,16,53,32,48,8,32,0,3,48,0,53,1,0,33,16,2,53,8,1,17,32,49,49,0,53,33,5,32,4,3,32,17,1,0,0]

def active44016 : List Nat := [0,1,2,3,4]

def tree44016 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44016 : H12WitnessSearch.Good tree44016 := H12GlobalWitnessIndex.good

theorem leafIdentity44016 : H12AffineFastState.composeSystem env44016 rootObs = leafEnv44016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44016 rootObs == leafEnv44016) = true)

theorem terminalChecked44016 : H12PackedTerminal.terminalCheckFast leafEnv44016 active44016 tree44016 = true := by decide +kernel

def env44017 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,48,269,33,0,262,49,0,52,1,261,33,16,2,269,17,293,48,49,0,305,33,256,32,33,16]

theorem envBound44017 : H12AffineFastState.Bounded env44017 := by
  intro p hp
  have h : env44017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44014_44017 : H12AffineEnvironment.transform 8 17 env44014 = env44017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44014 == env44017) = true)

theorem identity44017 : scanCanonicalize (H12AffineFastState.compose env44017 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44017 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44018 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,269,33,0,262,43,0,46,1,261,33,10,2,269,11,293,42,43,0,299,33,256,32,33,10]

theorem envBound44018 : H12AffineFastState.Bounded env44018 := by
  intro p hp
  have h : env44018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44017_44018 : H12AffineEnvironment.transform 3 10 env44017 = env44018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44017 == env44018) = true)

def leafEnv44018 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,269,33,0,262,43,0,46,1,261,33,10,2,299,269,1,11,293,42,43,0,299,33,256,32,4,262,33,10,1,261,0]

def active44018 : List Nat := [0,1,2,4,7]

def tree44018 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44018 : H12WitnessSearch.Good tree44018 := H12GlobalWitnessIndex.good

theorem leafIdentity44018 : H12AffineFastState.composeSystem env44018 rootObs = leafEnv44018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44018 rootObs == leafEnv44018) = true)

theorem terminalChecked44018 : H12PackedTerminal.terminalCheckFast leafEnv44018 active44018 tree44018 = true := by decide +kernel

def env44019 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1044,0,262,1028,1572,1024,1,260,33,16,2,269,17,1793,1029,48,1572,1285,33,256,32,1044,513]

theorem envBound44019 : H12AffineFastState.Bounded env44019 := by
  intro p hp
  have h : env44019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44012_44019 : H12AffineEnvironment.transform 10 1793 env44012 = env44019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44012 == env44019) = true)

theorem identity44019 : scanCanonicalize (H12AffineFastState.compose env44019 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound44019 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44020 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1076,49,269,1044,0,262,1028,1297,1024,1,260,33,16,2,269,17,1076,1029,48,1297,1285,33,256,32,1044,308]

theorem envBound44020 : H12AffineFastState.Bounded env44020 := by
  intro p hp
  have h : env44020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44019_44020 : H12AffineEnvironment.transform 8 309 env44019 = env44020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env44019 == env44020) = true)

def env44021 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,269,32,0,262,48,293,52,1,260,33,16,2,269,17,0,49,48,293,305,33,256,32,32,308]

theorem envBound44021 : H12AffineFastState.Bounded env44021 := by
  intro p hp
  have h : env44021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44020_44021 : H12AffineEnvironment.transform 9 52 env44020 = env44021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44020 == env44021) = true)

theorem identity44021 : scanCanonicalize (H12AffineFastState.compose env44021 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44022 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,269,32,0,262,43,293,47,1,260,33,11,2,269,10,0,42,43,293,298,33,256,32,32,303]

theorem envBound44022 : H12AffineFastState.Bounded env44022 := by
  intro p hp
  have h : env44022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44021_44022 : H12AffineEnvironment.transform 3 11 env44021 = env44022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44021 == env44022) = true)

def leafEnv44022 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,269,32,0,262,43,293,47,1,260,33,11,2,298,269,1,10,0,42,43,293,298,33,256,32,4,262,32,303,1,260,0]

def active44022 : List Nat := [0,1,2,4,7]

def tree44022 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44022 : H12WitnessSearch.Good tree44022 := H12GlobalWitnessIndex.good

theorem leafIdentity44022 : H12AffineFastState.composeSystem env44022 rootObs = leafEnv44022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44022 rootObs == leafEnv44022) = true)

theorem terminalChecked44022 : H12PackedTerminal.terminalCheckFast leafEnv44022 active44022 tree44022 = true := by decide +kernel

def env44023 : List Nat := [2,4,8,16,32,17,8,256,309,53,1,49,269,33,0,262,49,292,53,1,260,33,16,2,269,17,1,48,48,292,304,33,256,32,33,308]

theorem envBound44023 : H12AffineFastState.Bounded env44023 := by
  intro p hp
  have h : env44023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44020_44023 : H12AffineEnvironment.transform 9 53 env44020 = env44023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44020 == env44023) = true)

theorem identity44023 : scanCanonicalize (H12AffineFastState.compose env44023 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44024 : List Nat := [2,4,8,16,0,17,8,256,277,21,1,17,269,1,0,262,17,260,21,1,260,1,16,2,269,17,1,16,16,260,272,1,256,0,1,276]

theorem envBound44024 : H12AffineFastState.Bounded env44024 := by
  intro p hp
  have h : env44024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44023_44024 : H12AffineEnvironment.transform 4 0 env44023 = env44024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44023 == env44024) = true)

def leafEnv44024 : List Nat := [2,4,8,16,0,17,8,256,277,21,1,17,269,1,0,262,17,260,21,1,260,1,16,2,272,269,1,17,1,16,16,260,272,1,256,0,4,262,1,276,1,260,0]

def active44024 : List Nat := [0,1,2,3,7]

def tree44024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44024 : H12WitnessSearch.Good tree44024 := H12GlobalWitnessIndex.good

theorem leafIdentity44024 : H12AffineFastState.composeSystem env44024 rootObs = leafEnv44024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44024 rootObs == leafEnv44024) = true)

theorem terminalChecked44024 : H12PackedTerminal.terminalCheckFast leafEnv44024 active44024 tree44024 = true := by decide +kernel

def env44025 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2836,0,262,2820,2341,1024,1,3588,33,16,2,269,17,2048,2821,3888,2341,1285,33,256,32,2836,513]

theorem envBound44025 : H12AffineFastState.Bounded env44025 := by
  intro p hp
  have h : env44025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44011_44025 : H12AffineEnvironment.transform 11 3889 env44011 = env44025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env44011 == env44025) = true)

def env44026 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1044,0,262,1028,1573,1024,1,260,33,16,2,269,17,1792,1029,48,1573,1285,33,256,32,1044,513]

theorem envBound44026 : H12AffineFastState.Bounded env44026 := by
  intro p hp
  have h : env44026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44025_44026 : H12AffineEnvironment.transform 10 1792 env44025 = env44026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44025 == env44026) = true)

theorem identity44026 : scanCanonicalize (H12AffineFastState.compose env44026 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44027 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1297,49,269,1044,0,262,1028,1076,1024,1,260,33,16,2,269,17,1297,1029,48,1076,1285,33,256,32,1044,16]

theorem envBound44027 : H12AffineFastState.Bounded env44027 := by
  intro p hp
  have h : env44027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44026_44027 : H12AffineEnvironment.transform 8 17 env44026 = env44027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44026 == env44027) = true)

def env44028 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,269,32,0,262,48,0,52,1,260,33,16,2,269,17,293,49,48,0,305,33,256,32,32,16]

theorem envBound44028 : H12AffineFastState.Bounded env44028 := by
  intro p hp
  have h : env44028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44027_44028 : H12AffineEnvironment.transform 9 52 env44027 = env44028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44027 == env44028) = true)

theorem identity44028 : scanCanonicalize (H12AffineFastState.compose env44028 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44029 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,269,32,0,262,42,0,46,1,260,33,10,2,269,11,293,43,42,0,299,33,256,32,32,10]

theorem envBound44029 : H12AffineFastState.Bounded env44029 := by
  intro p hp
  have h : env44029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44028_44029 : H12AffineEnvironment.transform 3 10 env44028 = env44029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44028 == env44029) = true)

def leafEnv44029 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,269,32,0,262,42,0,46,1,260,33,10,2,299,269,1,11,293,43,42,0,299,33,256,32,4,262,32,10,1,260,0]

def active44029 : List Nat := [0,1,2,4,7]

def tree44029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44029 : H12WitnessSearch.Good tree44029 := H12GlobalWitnessIndex.good

theorem leafIdentity44029 : H12AffineFastState.composeSystem env44029 rootObs = leafEnv44029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44029 rootObs == leafEnv44029) = true)

theorem terminalChecked44029 : H12PackedTerminal.terminalCheckFast leafEnv44029 active44029 tree44029 = true := by decide +kernel

def env44030 : List Nat := [2,4,8,16,32,17,8,256,17,53,292,49,269,33,0,262,49,1,53,1,260,33,16,2,269,17,292,48,48,1,304,33,256,32,33,16]

theorem envBound44030 : H12AffineFastState.Bounded env44030 := by
  intro p hp
  have h : env44030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44027_44030 : H12AffineEnvironment.transform 9 53 env44027 = env44030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44027 == env44030) = true)

theorem identity44030 : scanCanonicalize (H12AffineFastState.compose env44030 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44031 : List Nat := [2,4,8,16,32,17,8,5,17,53,33,49,8,33,0,3,49,1,53,1,1,33,16,2,8,17,33,48,48,1,53,33,5,32,33,16]

theorem envBound44031 : H12AffineFastState.Bounded env44031 := by
  intro p hp
  have h : env44031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44030_44031 : H12AffineEnvironment.transform 7 5 env44030 = env44031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44030 == env44031) = true)

def leafEnv44031 : List Nat := [2,4,8,16,32,17,8,5,17,53,33,49,8,33,0,3,49,1,53,1,1,33,16,2,53,8,1,17,33,48,48,1,53,33,5,32,4,3,33,16,1,1,0]

def active44031 : List Nat := [0,1,2,3,4]

def tree44031 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44031 : H12WitnessSearch.Good tree44031 := H12GlobalWitnessIndex.good

theorem leafIdentity44031 : H12AffineFastState.composeSystem env44031 rootObs = leafEnv44031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44031 rootObs == leafEnv44031) = true)

theorem terminalChecked44031 : H12PackedTerminal.terminalCheckFast leafEnv44031 active44031 tree44031 = true := by decide +kernel

def env44032 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1045,0,262,1029,1572,1024,1,261,33,16,2,269,17,1793,1028,49,1572,1285,33,256,32,1045,513]

theorem envBound44032 : H12AffineFastState.Bounded env44032 := by
  intro p hp
  have h : env44032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44025_44032 : H12AffineEnvironment.transform 10 1793 env44025 = env44032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44025 == env44032) = true)

theorem identity44032 : scanCanonicalize (H12AffineFastState.compose env44032 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound44032 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44033 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,48,269,788,0,262,772,293,769,1,261,33,16,2,269,17,0,773,49,293,516,33,256,32,788,513]

theorem envBound44033 : H12AffineFastState.Bounded env44033 := by
  intro p hp
  have h : env44033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44032_44033 : H12AffineEnvironment.transform 9 769 env44032 = env44033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env44032 == env44033) = true)

def env44034 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,269,32,0,262,48,293,53,1,261,33,16,2,269,17,0,49,49,293,304,33,256,32,32,309]

theorem envBound44034 : H12AffineFastState.Bounded env44034 := by
  intro p hp
  have h : env44034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44033_44034 : H12AffineEnvironment.transform 8 308 env44033 = env44034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env44033 == env44034) = true)

theorem identity44034 : scanCanonicalize (H12AffineFastState.compose env44034 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44035 : List Nat := [2,4,8,16,0,17,8,256,276,21,0,16,269,0,0,262,16,261,21,1,261,1,16,2,269,17,0,17,17,261,272,1,256,0,0,277]

theorem envBound44035 : H12AffineFastState.Bounded env44035 := by
  intro p hp
  have h : env44035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44034_44035 : H12AffineEnvironment.transform 4 0 env44034 = env44035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44034 == env44035) = true)

def leafEnv44035 : List Nat := [2,4,8,16,0,17,8,256,276,21,0,16,269,0,0,262,16,261,21,1,261,1,16,2,272,269,1,17,0,17,17,261,272,1,256,0,4,262,0,277,1,261,0]

def active44035 : List Nat := [0,1,2,3,7]

def tree44035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44035 : H12WitnessSearch.Good tree44035 := H12GlobalWitnessIndex.good

theorem leafIdentity44035 : H12AffineFastState.composeSystem env44035 rootObs = leafEnv44035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44035 rootObs == leafEnv44035) = true)

theorem terminalChecked44035 : H12PackedTerminal.terminalCheckFast leafEnv44035 active44035 tree44035 = true := by decide +kernel

def env44036 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,48,269,33,0,262,49,293,52,1,261,33,16,2,269,17,0,48,49,293,305,33,256,32,33,308]

theorem envBound44036 : H12AffineFastState.Bounded env44036 := by
  intro p hp
  have h : env44036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44033_44036 : H12AffineEnvironment.transform 8 309 env44033 = env44036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env44033 == env44036) = true)

theorem identity44036 : scanCanonicalize (H12AffineFastState.compose env44036 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44036 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44037 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,269,33,0,262,42,293,47,1,261,33,11,2,269,10,0,43,42,293,298,33,256,32,33,303]

theorem envBound44037 : H12AffineFastState.Bounded env44037 := by
  intro p hp
  have h : env44037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44036_44037 : H12AffineEnvironment.transform 3 11 env44036 = env44037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44036 == env44037) = true)

def leafEnv44037 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,269,33,0,262,42,293,47,1,261,33,11,2,298,269,1,10,0,43,42,293,298,33,256,32,4,262,33,303,1,261,0]

def active44037 : List Nat := [0,1,2,4,7]

def tree44037 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44037 : H12WitnessSearch.Good tree44037 := H12GlobalWitnessIndex.good

theorem leafIdentity44037 : H12AffineFastState.composeSystem env44037 rootObs = leafEnv44037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44037 rootObs == leafEnv44037) = true)

theorem terminalChecked44037 : H12PackedTerminal.terminalCheckFast leafEnv44037 active44037 tree44037 = true := by decide +kernel

def env44038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10281,1024,32769,2097152,4194304,41412,2,8328,64,4302891,2196623,2159764,43049,75223,6383042,256,2188650,2196687,513]

theorem envBound44038 : H12AffineFastState.Bounded env44038 := by
  intro p hp
  have h : env44038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44002_44038 : H12AffineEnvironment.transform 17 10281 env44002 = env44038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44002 == env44038) = true)

theorem identity44038 : scanCanonicalize (H12AffineFastState.compose env44038 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44038 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16536,10281,1024,8541,2097152,4194304,152,2,8328,64,4262263,2172371,2119112,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound44039 : H12AffineFastState.Bounded env44039 := by
  intro p hp
  have h : env44039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44038_44039 : H12AffineEnvironment.transform 14 8540 env44038 = env44039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44038 == env44039) = true)

theorem identity44039 : scanCanonicalize (H12AffineFastState.compose env44039 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound44039 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,16536,10281,1024,8541,2097152,4194304,152,2,8328,64,4205044,2098512,2119112,2421,1364,6309185,256,2115049,2098448,513]

theorem envBound44040 : H12AffineFastState.Bounded env44040 := by
  intro p hp
  have h : env44040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44039_44040 : H12AffineEnvironment.transform 15 8323 env44039 = env44040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env44039 == env44040) = true)

theorem identity44040 : scanCanonicalize (H12AffineFastState.compose env44040 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound44040 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env44041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,8540,8323,4096,10281,1024,8541,2097152,4194304,152,2,8328,64,4205044,2098512,2098512,2421,1364,6297049,256,2102641,2098448,513]

theorem envBound44041 : H12AffineFastState.Bounded env44041 := by
  intro p hp
  have h : env44041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44040_44041 : H12AffineEnvironment.transform 13 4248 env44040 = env44041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env44040 == env44041) = true)

theorem identity44041 : scanCanonicalize (H12AffineFastState.compose env44041 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 2110589) := by decide +kernel

theorem selectedBound44041 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env44042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,8540,8323,4096,10281,1024,8541,2097152,2110589,152,2,8328,64,2104713,2098512,2098512,2421,1364,8612,256,2102641,2098448,513]

theorem envBound44042 : H12AffineFastState.Bounded env44042 := by
  intro p hp
  have h : env44042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44041_44042 : H12AffineEnvironment.transform 21 2110589 env44041 = env44042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2110589 env44041 == env44042) = true)

theorem identity44042 : scanCanonicalize (H12AffineFastState.compose env44042 (packedSelected [1,2,3,4,6,7,8,9,10,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound44042 : packedSelected [1,2,3,4,6,7,8,9,10,24,27] rootPS < 2^1333 := by decide +kernel

def env44043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4248,136,343,4096,2557,1024,137,2097152,2102697,152,2,348,64,2104713,2098512,2098512,2421,1364,112,256,2102641,2098448,513]

theorem envBound44043 : H12AffineFastState.Bounded env44043 := by
  intro p hp
  have h : env44043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44042_44043 : H12AffineEnvironment.transform 12 468 env44042 = env44043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env44042 == env44043) = true)

def env44044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21331969,18973837,2159764,294913,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound44044 : H12AffineFastState.Bounded env44044 := by
  intro p hp
  have h : env44044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44000_44044 : H12AffineEnvironment.transform 16 57797 env44000 = env44044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env44000 == env44044) = true)

def env44045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10280,1024,32769,2097152,4194304,41412,16777216,8328,64,21080105,18973837,2159764,43049,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound44045 : H12AffineFastState.Bounded env44045 := by
  intro p hp
  have h : env44045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44044_44045 : H12AffineEnvironment.transform 17 10280 env44044 = env44045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44044 == env44045) = true)

theorem identity44045 : scanCanonicalize (H12AffineFastState.compose env44045 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44045 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,16777216,8192,64,21080105,18973701,2159644,43049,16852317,23160136,256,18965864,18973765,16777731]

theorem envBound44046 : H12AffineFastState.Bounded env44046 := by
  intro p hp
  have h : env44046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44045_44046 : H12AffineEnvironment.transform 6 8 env44045 = env44046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44045 == env44046) = true)

theorem identity44046 : scanCanonicalize (H12AffineFastState.compose env44046 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound44046 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302891,2196487,2159644,43049,75103,6382922,256,2188650,2196551,513]

theorem envBound44047 : H12AffineFastState.Bounded env44047 := by
  intro p hp
  have h : env44047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44046_44047 : H12AffineEnvironment.transform 23 2 env44046 = env44047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env44046 == env44047) = true)

theorem identity44047 : scanCanonicalize (H12AffineFastState.compose env44047 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound44047 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env44048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4196384,2106380,2159644,43049,34132,6341953,256,2147681,2106444,513]

theorem envBound44048 : H12AffineFastState.Bounded env44048 := by
  intro p hp
  have h : env44048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44047_44048 : H12AffineEnvironment.transform 15 40971 env44047 = env44048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env44047 == env44048) = true)

theorem identity44048 : scanCanonicalize (H12AffineFastState.compose env44048 (packedSelected [1,2,5,6,8,11,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44048 : packedSelected [1,2,5,6,8,11,17,18,24] rootPS < 2^1333 := by decide +kernel

def env44049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,16400,10280,1024,8540,2097152,4194304,17,2,8192,64,4196384,2106380,2118977,2420,9225,6317084,256,2122812,2106444,513]

theorem envBound44049 : H12AffineFastState.Bounded env44049 := by
  intro p hp
  have h : env44049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44048_44049 : H12AffineEnvironment.transform 14 8541 env44048 = env44049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44048 == env44049) = true)

theorem identity44049 : scanCanonicalize (H12AffineFastState.compose env44049 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound44049 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,16400,10280,1024,8540,2097152,2114913,17,2,8192,64,2116929,2106380,2118977,2420,9225,8573,256,2122812,2106444,513]

theorem envBound44050 : H12AffineFastState.Bounded env44050 := by
  intro p hp
  have h : env44050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44049_44050 : H12AffineEnvironment.transform 21 2114913 env44049 = env44050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env44049 == env44050) = true)

theorem identity44050 : scanCanonicalize (H12AffineFastState.compose env44050 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound44050 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env44051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,16400,10280,1024,8540,17729,32,17,2,8192,64,2048,24909,4096,2420,9225,8573,256,8573,24845,513]

theorem envBound44051 : H12AffineFastState.Bounded env44051 := by
  intro p hp
  have h : env44051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44050_44051 : H12AffineEnvironment.transform 20 17729 env44050 = env44051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env44050 == env44051) = true)

def env44052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10281,1024,32769,2097152,4194304,41412,16777216,8328,64,21080104,18973837,2159764,43048,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound44052 : H12AffineFastState.Bounded env44052 := by
  intro p hp
  have h : env44052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44044_44052 : H12AffineEnvironment.transform 17 10281 env44044 = env44052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44044 == env44052) = true)

theorem identity44052 : scanCanonicalize (H12AffineFastState.compose env44052 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44052 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16537,10281,1024,8541,2097152,4194304,152,16777216,8328,64,21039476,18949585,2119112,2420,16852437,23160256,256,18965864,18949521,16777731]

theorem envBound44053 : H12AffineFastState.Bounded env44053 := by
  intro p hp
  have h : env44053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44052_44053 : H12AffineEnvironment.transform 14 8540 env44052 = env44053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44052 == env44053) = true)

theorem identity44053 : scanCanonicalize (H12AffineFastState.compose env44053 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound44053 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,16537,10281,1024,8541,2097152,4194304,152,16777216,8328,64,20982262,18875731,2119112,2420,16778583,23086402,256,18892266,18875667,16777731]

theorem envBound44054 : H12AffineFastState.Bounded env44054 := by
  intro p hp
  have h : env44054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44053_44054 : H12AffineEnvironment.transform 15 8322 env44053 = env44054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env44053 == env44054) = true)

theorem identity44054 : scanCanonicalize (H12AffineFastState.compose env44054 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound44054 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env44055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,16537,10281,1024,8541,2097152,4194304,152,2,8328,64,4205044,2098513,2119112,2420,1365,6309184,256,2115048,2098449,513]

theorem envBound44055 : H12AffineFastState.Bounded env44055 := by
  intro p hp
  have h : env44055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44054_44055 : H12AffineEnvironment.transform 23 2 env44054 = env44055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env44054 == env44055) = true)

theorem identity44055 : scanCanonicalize (H12AffineFastState.compose env44055 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound44055 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env44056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,16537,10281,1024,8541,5457,4194304,152,2,8328,64,4205044,4096,16537,2420,1365,4214801,256,20665,4160,513]

theorem envBound44056 : H12AffineFastState.Bounded env44056 := by
  intro p hp
  have h : env44056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44055_44056 : H12AffineEnvironment.transform 20 5457 env44055 = env44056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env44055 == env44056) = true)

theorem identity44056 : scanCanonicalize (H12AffineFastState.compose env44056 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound44056 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8322,4232,10281,1024,8541,5457,4194304,152,2,8328,64,4205044,4096,4232,2420,1365,4194304,256,168,4160,513]

theorem envBound44057 : H12AffineFastState.Bounded env44057 := by
  intro p hp
  have h : env44057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44056_44057 : H12AffineEnvironment.transform 13 4113 env44056 = env44057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env44056 == env44057) = true)

theorem identity44057 : scanCanonicalize (H12AffineFastState.compose env44057 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound44057 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env44058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8322,4232,10281,1024,8541,5457,8572,152,2,8328,64,2184,4096,4232,2420,1365,8572,256,168,4160,513]

theorem envBound44058 : H12AffineFastState.Bounded env44058 := by
  intro p hp
  have h : env44058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44057_44058 : H12AffineEnvironment.transform 21 8572 env44057 = env44058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env44057 == env44058) = true)

theorem identity44058 : scanCanonicalize (H12AffineFastState.compose env44058 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound44058 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env44059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,136,342,4232,2557,1024,137,5457,168,152,2,348,64,2184,4096,4232,2420,1365,168,256,168,4160,513]

theorem envBound44059 : H12AffineFastState.Bounded env44059 := by
  intro p hp
  have h : env44059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44058_44059 : H12AffineEnvironment.transform 12 468 env44058 = env44059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env44058 == env44059) = true)

theorem identity44059 : scanCanonicalize (H12AffineFastState.compose env44059 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44059 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4113,0,342,4096,2421,1024,1,5457,32,16,2,348,64,2048,4096,4096,2420,1365,32,256,32,4160,513]

theorem envBound44060 : H12AffineFastState.Bounded env44060 := by
  intro p hp
  have h : env44060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44059_44060 : H12AffineEnvironment.transform 6 8 env44059 = env44060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44059 == env44060) = true)

theorem identity44060 : scanCanonicalize (H12AffineFastState.compose env44060 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound44060 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1792,348,1809,0,342,1792,2421,1024,1,593,32,16,2,348,64,2048,1792,1792,2420,1365,32,256,32,1856,513]

theorem envBound44061 : H12AffineFastState.Bounded env44061 := by
  intro p hp
  have h : env44061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44060_44061 : H12AffineEnvironment.transform 11 1792 env44060 = env44061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env44060 == env44061) = true)

theorem identity44061 : scanCanonicalize (H12AffineFastState.compose env44061 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1652) := by decide +kernel

theorem selectedBound44061 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1652,1792,348,1809,0,342,1792,1793,1024,1,593,32,16,2,348,64,1652,1792,1792,1792,1365,32,256,32,1856,513]

theorem envBound44062 : H12AffineFastState.Bounded env44062 := by
  intro p hp
  have h : env44062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44061_44062 : H12AffineEnvironment.transform 10 1652 env44061 = env44062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1652 env44061 == env44062) = true)

theorem identity44062 : scanCanonicalize (H12AffineFastState.compose env44062 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44062 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env44063 : List Nat := [2,4,8,16,32,64,8,256,512,273,869,529,348,512,0,342,529,528,273,1,593,32,16,2,348,64,869,529,529,529,68,32,256,32,593,513]

theorem envBound44063 : H12AffineFastState.Bounded env44063 := by
  intro p hp
  have h : env44063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44062_44063 : H12AffineEnvironment.transform 9 273 env44062 = env44063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44062 == env44063) = true)

theorem identity44063 : scanCanonicalize (H12AffineFastState.compose env44063 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44063 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44064 : List Nat := [2,4,8,16,32,64,8,21,512,4,624,529,73,512,0,67,529,528,4,1,593,32,16,2,73,64,624,529,529,529,68,32,21,32,593,513]

theorem envBound44064 : H12AffineFastState.Bounded env44064 := by
  intro p hp
  have h : env44064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44063_44064 : H12AffineEnvironment.transform 7 21 env44063 = env44064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44063 == env44064) = true)

theorem identity44064 : scanCanonicalize (H12AffineFastState.compose env44064 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44064 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env44065 : List Nat := [2,4,8,16,1,64,8,21,512,4,593,529,73,512,0,67,529,528,4,1,593,1,16,2,73,64,593,529,529,529,68,1,21,1,593,513]

theorem envBound44065 : H12AffineFastState.Bounded env44065 := by
  intro p hp
  have h : env44065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44064_44065 : H12AffineEnvironment.transform 4 1 env44064 = env44065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44064 == env44065) = true)

theorem identity44065 : scanCanonicalize (H12AffineFastState.compose env44065 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44065 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44066 : List Nat := [2,4,8,16,1,0,8,21,512,4,529,529,9,512,0,3,529,528,4,1,529,1,16,2,9,0,529,529,529,529,4,1,21,1,529,513]

theorem envBound44066 : H12AffineFastState.Bounded env44066 := by
  intro p hp
  have h : env44066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44065_44066 : H12AffineEnvironment.transform 5 0 env44065 = env44066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44065 == env44066) = true)

theorem identity44066 : scanCanonicalize (H12AffineFastState.compose env44066 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44066 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44067 : List Nat := [2,4,8,16,1,0,8,21,16,4,1,1,9,16,0,3,1,0,4,1,1,1,16,2,9,0,1,1,1,1,4,1,21,1,1,17]

theorem envBound44067 : H12AffineFastState.Bounded env44067 := by
  intro p hp
  have h : env44067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44066_44067 : H12AffineEnvironment.transform 8 16 env44066 = env44067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44066 == env44067) = true)

theorem identity44067 : scanCanonicalize (H12AffineFastState.compose env44067 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44067 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env44068 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,1,9,1,0,3,1,0,4,1,1,1,1,2,9,0,1,1,1,1,4,1,4,1,1,0]

theorem envBound44068 : H12AffineFastState.Bounded env44068 := by
  intro p hp
  have h : env44068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44067_44068 : H12AffineEnvironment.transform 3 1 env44067 = env44068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44067 == env44068) = true)

def env44069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound44069 : H12AffineFastState.Bounded env44069 := by
  intro p hp
  have h : env44069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43998_44069 : H12AffineEnvironment.transform 18 1025 env43998 = env44069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env43998 == env44069) = true)

theorem identity44069 : scanCanonicalize (H12AffineFastState.compose env44069 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213316) := by decide +kernel

theorem selectedBound44069 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213316,8328,64,12878149,2278856,10507600,8830977,8570197,6431876,257,10651113,10642509,8643202]

theorem envBound44070 : H12AffineFastState.Bounded env44070 := by
  intro p hp
  have h : env44070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44069_44070 : H12AffineEnvironment.transform 23 213316 env44069 = env44070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213316 env44069 == env44070) = true)

def env44071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281672,213316,8328,64,6705549,2278856,165272,2363593,2102685,6431876,257,21793,46213,2175562]

theorem envBound44071 : H12AffineFastState.Bounded env44071 := by
  intro p hp
  have h : env44071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44070_44071 : H12AffineEnvironment.transform 22 2281672 env44070 = env44071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281672 env44070 == env44071) = true)

def env44072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590741,2098512,17664,2363593,2102685,6349852,257,21793,46213,2175562]

theorem envBound44072 : H12AffineFastState.Bounded env44072 := by
  intro p hp
  have h : env44072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44071_44072 : H12AffineEnvironment.transform 16 49304 env44071 = env44072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env44071 == env44072) = true)

def env44073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144661,2098512,17664,2363593,2102685,2411676,257,21793,46213,2175562]

theorem envBound44073 : H12AffineFastState.Bounded env44073 := by
  intro p hp
  have h : env44073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44072_44073 : H12AffineEnvironment.transform 21 272512 env44072 = env44073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44072 == env44073) = true)

theorem identity44073 : scanCanonicalize (H12AffineFastState.compose env44073 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound44073 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,262144,1025,29908,2097152,272512,2101328,95497,8328,64,2116928,2098512,17664,2363593,2102685,2373705,257,21793,16464,2175562]

theorem envBound44074 : H12AffineFastState.Bounded env44074 := by
  intro p hp
  have h : env44074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44073_44074 : H12AffineEnvironment.transform 14 29909 env44073 = env44074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env44073 == env44074) = true)

def env44075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,262144,1025,21540,2097152,264304,2101328,87545,120,64,2116928,2098512,17664,2363593,2102685,2365625,257,21793,16464,2167482]

theorem envBound44075 : H12AffineFastState.Bounded env44075 := by
  intro p hp
  have h : env44075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44074_44075 : H12AffineEnvironment.transform 12 240 env44074 = env44075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env44074 == env44075) = true)

theorem identity44075 : scanCanonicalize (H12AffineFastState.compose env44075 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound44075 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env44076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,2557,1025,21540,2097152,397,2101328,87545,120,64,2116928,2098512,17664,2103604,2102685,2101572,257,21793,16464,2167482]

theorem envBound44076 : H12AffineFastState.Bounded env44076 := by
  intro p hp
  have h : env44076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44075_44076 : H12AffineEnvironment.transform 17 2557 env44075 = env44076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env44075 == env44076) = true)

theorem identity44076 : scanCanonicalize (H12AffineFastState.compose env44076 (packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 4589) := by decide +kernel

end H12CloudChart0