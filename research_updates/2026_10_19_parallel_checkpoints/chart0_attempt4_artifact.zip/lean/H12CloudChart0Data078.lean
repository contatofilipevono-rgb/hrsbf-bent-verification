import H12CloudChart0Data077

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound19679 : H12AffineFastState.Bounded env19679 := by
  intro p hp
  have h : env19679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19678_19679 : H12AffineEnvironment.transform 9 320 env19678 = env19679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env19678 == env19679) = true)

theorem identity19679 : scanCanonicalize (H12AffineFastState.compose env19679 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19679 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19680 : List Nat := [2,4,8,16,32,64,89,117,512,53,2048,4096,121,4161,80,35,4177,2049,52,81,4161,32,17,2,40,64,2128,4177,4096,2128,68,32,116,32,4161,592]

theorem envBound19680 : H12AffineFastState.Bounded env19680 := by
  intro p hp
  have h : env19680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19679_19680 : H12AffineEnvironment.transform 7 117 env19679 = env19680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19679 == env19680) = true)

theorem identity19680 : scanCanonicalize (H12AffineFastState.compose env19680 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound19680 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19681 : List Nat := [2,4,8,16,32,64,89,117,512,53,2048,576,121,513,80,35,529,2049,52,81,513,32,17,2,40,64,2128,529,576,2128,68,32,116,32,513,592]

theorem envBound19681 : H12AffineFastState.Bounded env19681 := by
  intro p hp
  have h : env19681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19680_19681 : H12AffineEnvironment.transform 11 576 env19680 = env19681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env19680 == env19681) = true)

theorem identity19681 : scanCanonicalize (H12AffineFastState.compose env19681 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound19681 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env19682 : List Nat := [2,4,8,16,32,64,89,117,512,53,17,576,121,513,80,35,529,16,52,81,513,32,17,2,40,64,65,529,576,65,68,32,116,32,513,592]

theorem envBound19682 : H12AffineFastState.Bounded env19682 := by
  intro p hp
  have h : env19682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19681_19682 : H12AffineEnvironment.transform 10 17 env19681 = env19682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env19681 == env19682) = true)

theorem identity19682 : scanCanonicalize (H12AffineFastState.compose env19682 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound19682 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env19683 : List Nat := [2,4,8,16,32,64,89,117,81,53,17,17,121,80,80,35,64,16,52,81,80,32,17,2,40,64,65,64,17,65,68,32,116,32,80,1]

theorem envBound19683 : H12AffineFastState.Bounded env19683 := by
  intro p hp
  have h : env19683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19682_19683 : H12AffineEnvironment.transform 8 81 env19682 = env19683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env19682 == env19683) = true)

def env19684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543883,115151,17664,2363592,119042,4268163,257,2199999,2191386,63189]

theorem envBound19684 : H12AffineFastState.Bounded env19684 := by
  intro p hp
  have h : env19684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19646_19684 : H12AffineEnvironment.transform 22 2101329 env19646 = env19684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19646 == env19684) = true)

def env19685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97547,115151,17664,2363592,119042,329731,257,2199999,2191386,63189]

theorem envBound19685 : H12AffineFastState.Bounded env19685 := by
  intro p hp
  have h : env19685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19684_19685 : H12AffineEnvironment.transform 21 272512 env19684 = env19685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19684 == env19685) = true)

theorem identity19685 : scanCanonicalize (H12AffineFastState.compose env19685 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,23808,57796,17664,2363592,61705,272392,257,2142644,2117649,63189]

theorem envBound19686 : H12AffineFastState.Bounded env19686 := by
  intro p hp
  have h : env19686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19685_19686 : H12AffineEnvironment.transform 15 8203 env19685 = env19686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19685 == env19686) = true)

def env19687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,23808,57676,17664,2363456,61705,272392,257,2142524,2117649,63069]

theorem envBound19687 : H12AffineFastState.Bounded env19687 := by
  intro p hp
  have h : env19687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19686_19687 : H12AffineEnvironment.transform 6 8 env19686 = env19687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19686 == env19687) = true)

theorem identity19687 : scanCanonicalize (H12AffineFastState.compose env19687 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound19687 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env19688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,4161,272392,16,21763,8192,64,23808,57676,17664,262145,61705,272392,257,41341,16464,63069]

theorem envBound19688 : H12AffineFastState.Bounded env19688 := by
  intro p hp
  have h : env19688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19687_19688 : H12AffineEnvironment.transform 20 4161 env19687 = env19688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19687 == env19688) = true)

theorem identity19688 : scanCanonicalize (H12AffineFastState.compose env19688 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19688 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38160,262144,1025,32769,4161,272392,16,2,8192,64,2049,46157,4097,262145,41992,272392,257,41341,5457,41820]

theorem envBound19689 : H12AffineFastState.Bounded env19689 := by
  intro p hp
  have h : env19689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19688_19689 : H12AffineEnvironment.transform 13 5377 env19688 = env19689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19688 == env19689) = true)

theorem identity19689 : scanCanonicalize (H12AffineFastState.compose env19689 (packedSelected [0,1,5,6,7,8,14,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19689 : packedSelected [0,1,5,6,7,8,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8203,5393,262144,1025,0,4161,272392,16,2,8192,64,2049,13388,4097,262145,9225,272392,257,8572,5457,9053]

theorem envBound19690 : H12AffineFastState.Bounded env19690 := by
  intro p hp
  have h : env19690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19689_19690 : H12AffineEnvironment.transform 14 1 env19689 = env19690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19689 == env19690) = true)

theorem identity19690 : scanCanonicalize (H12AffineFastState.compose env19690 (packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound19690 : packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env19691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8203,5393,2421,1025,0,4161,8573,16,2,8192,64,2049,13388,4097,2420,9225,8573,257,8572,5457,9053]

theorem envBound19691 : H12AffineFastState.Bounded env19691 := by
  intro p hp
  have h : env19691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19690_19691 : H12AffineEnvironment.transform 17 2421 env19690 = env19691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env19690 == env19691) = true)

theorem identity19691 : scanCanonicalize (H12AffineFastState.compose env19691 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound19691 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,1,1046,5393,2421,1025,0,4161,1376,16,2,1053,64,2049,4177,4097,2420,20,1376,257,1377,5457,1856]

theorem envBound19692 : H12AffineFastState.Bounded env19692 := by
  intro p hp
  have h : env19692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19691_19692 : H12AffineEnvironment.transform 12 1053 env19691 = env19692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env19691 == env19692) = true)

theorem identity19692 : scanCanonicalize (H12AffineFastState.compose env19692 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound19692 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env19693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1060,1053,293,1,1046,309,2421,1025,0,1125,1376,16,2,1053,64,2049,1141,1061,2420,20,1376,257,1377,373,1856]

theorem envBound19693 : H12AffineFastState.Bounded env19693 := by
  intro p hp
  have h : env19693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19692_19693 : H12AffineEnvironment.transform 11 1060 env19692 = env19693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env19692 == env19693) = true)

theorem identity19693 : scanCanonicalize (H12AffineFastState.compose env19693 (packedSelected [0,1,2,3,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound19693 : packedSelected [0,1,2,3,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env19694 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,357,348,293,1,343,309,2421,320,0,292,33,16,2,348,64,2049,308,356,2420,20,33,257,32,373,513]

theorem envBound19694 : H12AffineFastState.Bounded env19694 := by
  intro p hp
  have h : env19694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19693_19694 : H12AffineEnvironment.transform 9 321 env19693 = env19694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env19693 == env19694) = true)

theorem identity19694 : scanCanonicalize (H12AffineFastState.compose env19694 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound19694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19695 : List Nat := [2,4,8,16,32,64,8,53,512,116,2048,80,105,16,1,98,0,2112,117,0,17,33,16,2,105,64,2049,1,81,2113,20,33,52,32,64,513]

theorem envBound19695 : H12AffineFastState.Bounded env19695 := by
  intro p hp
  have h : env19695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19694_19695 : H12AffineEnvironment.transform 7 53 env19694 = env19695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env19694 == env19695) = true)

theorem identity19695 : scanCanonicalize (H12AffineFastState.compose env19695 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound19695 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19696 : List Nat := [2,4,8,16,32,64,8,53,65,116,2048,80,105,16,1,98,0,2112,117,0,17,33,16,2,105,64,2049,1,81,2113,20,33,52,32,64,64]

theorem envBound19696 : H12AffineFastState.Bounded env19696 := by
  intro p hp
  have h : env19696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19695_19696 : H12AffineEnvironment.transform 8 65 env19695 = env19696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env19695 == env19696) = true)

theorem identity19696 : scanCanonicalize (H12AffineFastState.compose env19696 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19697 : List Nat := [2,4,8,16,32,16,8,53,17,36,2048,0,57,16,1,50,0,2064,37,0,17,33,16,2,57,16,2049,1,1,2065,20,33,52,32,16,16]

theorem envBound19697 : H12AffineFastState.Bounded env19697 := by
  intro p hp
  have h : env19697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19696_19697 : H12AffineEnvironment.transform 5 16 env19696 = env19697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19696 == env19697) = true)

theorem identity19697 : scanCanonicalize (H12AffineFastState.compose env19697 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound19697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19698 : List Nat := [2,4,8,16,32,16,8,53,17,36,10,0,57,16,1,50,0,26,37,0,17,33,16,2,57,16,11,1,1,27,20,33,52,32,16,16]

theorem envBound19698 : H12AffineFastState.Bounded env19698 := by
  intro p hp
  have h : env19698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19697_19698 : H12AffineEnvironment.transform 10 10 env19697 = env19698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env19697 == env19698) = true)

theorem identity19698 : scanCanonicalize (H12AffineFastState.compose env19698 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19699 : List Nat := [2,4,8,10,32,10,8,47,11,36,10,0,35,10,1,40,0,0,37,0,11,33,10,2,35,10,11,1,1,1,14,33,46,32,10,10]

theorem envBound19699 : H12AffineFastState.Bounded env19699 := by
  intro p hp
  have h : env19699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19698_19699 : H12AffineEnvironment.transform 3 10 env19698 = env19699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19698 == env19699) = true)

theorem identity19699 : scanCanonicalize (H12AffineFastState.compose env19699 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19700 : List Nat := [2,4,2,0,32,0,2,37,1,36,0,0,35,0,1,34,0,0,37,0,1,33,0,2,35,0,1,1,1,1,4,33,36,32,0,0]

theorem envBound19700 : H12AffineFastState.Bounded env19700 := by
  intro p hp
  have h : env19700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19699_19700 : H12AffineEnvironment.transform 2 2 env19699 = env19700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19699 == env19700) = true)

def env19701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,23808,57677,17664,2363457,61705,272392,257,2142525,2117649,63068]

theorem envBound19701 : H12AffineFastState.Bounded env19701 := by
  intro p hp
  have h : env19701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19686_19701 : H12AffineEnvironment.transform 6 9 env19686 = env19701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19686 == env19701) = true)

theorem identity19701 : scanCanonicalize (H12AffineFastState.compose env19701 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound19701 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env19702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,25628,272393,29773,8542,8193,64,23808,57677,17664,291933,61705,272392,257,54561,13325,63068]

theorem envBound19702 : H12AffineFastState.Bounded env19702 := by
  intro p hp
  have h : env19702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19701_19702 : H12AffineEnvironment.transform 20 25628 env19701 = env19702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env19701 == env19702) = true)

theorem identity19702 : scanCanonicalize (H12AffineFastState.compose env19702 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound19702 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env19703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1025,32769,25628,32,29773,8542,8193,64,23808,57677,17664,23668,61705,33,257,54561,13325,63068]

theorem envBound19703 : H12AffineFastState.Bounded env19703 := by
  intro p hp
  have h : env19703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19702_19703 : H12AffineEnvironment.transform 17 10281 env19702 = env19703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19702 == env19703) = true)

theorem identity19703 : scanCanonicalize (H12AffineFastState.compose env19703 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19703 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13389,10281,1025,29788,25628,32,29773,8542,8193,64,23808,5392,17664,23668,1364,33,257,8572,13325,513]

theorem envBound19704 : H12AffineFastState.Bounded env19704 := by
  intro p hp
  have h : env19704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19703_19704 : H12AffineEnvironment.transform 14 29789 env19703 = env19704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19703 == env19704) = true)

theorem identity19704 : scanCanonicalize (H12AffineFastState.compose env19704 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19704 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19705 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8203,13340,10281,1025,29709,25628,32,29724,8463,8193,17,23808,5392,17664,23589,1285,33,257,8493,13325,513]

theorem envBound19705 : H12AffineFastState.Bounded env19705 := by
  intro p hp
  have h : env19705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19704_19705 : H12AffineEnvironment.transform 5 17 env19704 = env19705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19704 == env19705) = true)

theorem identity19705 : scanCanonicalize (H12AffineFastState.compose env19705 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19705 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19706 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,13340,10281,1025,8461,12572,32,8476,8463,8193,17,2048,5392,4096,2341,1285,33,257,8493,13325,513]

theorem envBound19706 : H12AffineFastState.Bounded env19706 := by
  intro p hp
  have h : env19706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19705_19706 : H12AffineEnvironment.transform 13 5376 env19705 = env19706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19705 == env19706) = true)

def env19707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97546,115151,17664,2363592,119042,329730,257,2199999,2191386,63189]

theorem envBound19707 : H12AffineFastState.Bounded env19707 := by
  intro p hp
  have h : env19707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19684_19707 : H12AffineEnvironment.transform 21 272513 env19684 = env19707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19684 == env19707) = true)

theorem identity19707 : scanCanonicalize (H12AffineFastState.compose env19707 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound19707 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77899,272513,73754,95497,8328,64,97546,115151,17664,336003,119042,329730,257,41460,16465,63189]

theorem envBound19708 : H12AffineFastState.Bounded env19708 := by
  intro p hp
  have h : env19708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19707_19708 : H12AffineEnvironment.transform 20 77899 env19707 = env19708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env19707 == env19708) = true)

def env19709 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77851,272513,73754,95497,8328,16,97546,115103,17664,336003,119042,329730,257,41380,16385,63109]

theorem envBound19709 : H12AffineFastState.Bounded env19709 := by
  intro p hp
  have h : env19709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19708_19709 : H12AffineEnvironment.transform 5 16 env19708 = env19709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19708 == env19709) = true)

theorem identity19709 : scanCanonicalize (H12AffineFastState.compose env19709 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound19709 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env19710 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,43048,1025,32769,77851,32937,73754,95497,8328,16,97546,115103,17664,100523,119042,106538,257,41380,16385,63109]

theorem envBound19710 : H12AffineFastState.Bounded env19710 := by
  intro p hp
  have h : env19710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19709_19710 : H12AffineEnvironment.transform 17 43048 env19709 = env19710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env19709 == env19710) = true)

theorem identity19710 : scanCanonicalize (H12AffineFastState.compose env19710 (packedSelected [1,3,4,5,7,8,9,11,14,17,26,27,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound19710 : packedSelected [1,3,4,5,7,8,9,11,14,17,26,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env19711 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,49305,43048,1025,32769,45460,32937,41365,62598,8328,16,64645,16400,17664,2340,20621,8613,257,41380,16385,63109]

theorem envBound19711 : H12AffineFastState.Bounded env19711 := by
  intro p hp
  have h : env19711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19710_19711 : H12AffineEnvironment.transform 15 33167 env19710 = env19711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env19710 == env19711) = true)

theorem identity19711 : scanCanonicalize (H12AffineFastState.compose env19711 (packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19711 : packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19712 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,33167,49305,35109,1025,32769,37017,32937,32920,54667,389,16,56712,16400,17664,2340,20621,168,257,32937,16385,55176]

theorem envBound19712 : H12AffineFastState.Bounded env19712 := by
  intro p hp
  have h : env19712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19711_19712 : H12AffineEnvironment.transform 12 269 env19711 = env19712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19711 == env19712) = true)

theorem identity19712 : scanCanonicalize (H12AffineFastState.compose env19712 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19712 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env19713 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,0,399,16537,2341,1025,1,4249,169,152,21899,389,16,23944,16400,17664,2340,20621,168,257,169,16385,22408]

theorem envBound19713 : H12AffineFastState.Bounded env19713 := by
  intro p hp
  have h : env19713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19712_19713 : H12AffineEnvironment.transform 14 0 env19712 = env19713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19712 == env19713) = true)

theorem identity19713 : scanCanonicalize (H12AffineFastState.compose env19713 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19713 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19714 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,0,399,5528,2341,1025,1,4249,169,152,138,389,16,2185,5393,4097,2340,1420,168,257,169,5376,649]

theorem envBound19714 : H12AffineFastState.Bounded env19714 := by
  intro p hp
  have h : env19714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19713_19714 : H12AffineEnvironment.transform 13 5377 env19713 = env19714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19713 == env19714) = true)

theorem identity19714 : scanCanonicalize (H12AffineFastState.compose env19714 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19714 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19715 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,0,170,5309,2048,1025,1,4249,169,152,138,160,16,2185,5172,4097,2049,1193,168,36,169,5157,649]

theorem envBound19715 : H12AffineFastState.Bounded env19715 := by
  intro p hp
  have h : env19715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19714_19715 : H12AffineEnvironment.transform 7 37 env19714 = env19715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19714 == env19715) = true)

theorem identity19715 : scanCanonicalize (H12AffineFastState.compose env19715 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound19715 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19716 : List Nat := [2,4,8,16,32,16,128,37,512,189,2048,4096,40,4249,0,170,4096,2048,188,1,4249,169,152,138,160,16,2185,4233,4097,2049,20,168,36,169,4248,649]

theorem envBound19716 : H12AffineFastState.Bounded env19716 := by
  intro p hp
  have h : env19716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19715_19716 : H12AffineEnvironment.transform 9 189 env19715 = env19716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env19715 == env19716) = true)

theorem identity19716 : scanCanonicalize (H12AffineFastState.compose env19716 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound19716 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env19717 : List Nat := [2,4,8,16,32,16,128,37,512,189,2048,2201,40,2048,0,170,2201,2048,188,1,2048,169,152,138,160,16,2185,2064,2200,2049,20,168,36,169,2049,649]

theorem envBound19717 : H12AffineFastState.Bounded env19717 := by
  intro p hp
  have h : env19717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19716_19717 : H12AffineEnvironment.transform 11 2201 env19716 = env19717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env19716 == env19717) = true)

def env19718 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77850,272513,73754,95497,8328,17,97546,115102,17664,336003,119042,329730,257,41381,16384,63108]

theorem envBound19718 : H12AffineFastState.Bounded env19718 := by
  intro p hp
  have h : env19718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19708_19718 : H12AffineEnvironment.transform 5 17 env19708 = env19718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19708 == env19718) = true)

theorem identity19718 : scanCanonicalize (H12AffineFastState.compose env19718 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound19718 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env19719 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,62850,49305,262144,1025,32769,50584,272513,54680,32907,8328,17,34952,13340,17664,316673,9344,327040,257,41381,16384,63108]

theorem envBound19719 : H12AffineFastState.Bounded env19719 := by
  intro p hp
  have h : env19719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19718_19719 : H12AffineEnvironment.transform 15 62850 env19718 = env19719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env19718 == env19719) = true)

theorem identity19719 : scanCanonicalize (H12AffineFastState.compose env19719 (packedSelected [0,1,4,5,7,8,10,16,17,18,19,20,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound19719 : packedSelected [0,1,4,5,7,8,10,16,17,18,19,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env19720 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,398,13461,262144,1025,29709,12692,272513,8596,29831,8328,17,31876,13340,17664,270605,9344,264588,257,21929,16384,648]

theorem envBound19720 : H12AffineFastState.Bounded env19720 := by
  intro p hp
  have h : env19720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19719_19720 : H12AffineEnvironment.transform 14 29708 env19719 = env19720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env19719 == env19720) = true)

theorem identity19720 : scanCanonicalize (H12AffineFastState.compose env19720 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound19720 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env19721 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,1,398,13461,262144,1025,0,12692,272513,8596,138,8328,17,2185,13340,12557,270605,9344,264588,257,8612,13325,648]

theorem envBound19721 : H12AffineFastState.Bounded env19721 := by
  intro p hp
  have h : env19721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19720_19721 : H12AffineEnvironment.transform 13 13325 env19720 = env19721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env19720 == env19721) = true)

theorem identity19721 : scanCanonicalize (H12AffineFastState.compose env19721 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound19721 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env19722 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,1,398,13461,10401,1025,0,12692,32,8596,138,8328,17,2185,13340,12557,2476,9344,8493,257,8612,13325,648]

theorem envBound19722 : H12AffineFastState.Bounded env19722 := by
  intro p hp
  have h : env19722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19721_19722 : H12AffineEnvironment.transform 17 10401 env19721 = env19722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19721 == env19722) = true)

theorem identity19722 : scanCanonicalize (H12AffineFastState.compose env19722 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19722 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env19723 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,1,398,5529,2477,1025,0,4248,32,152,138,388,17,2185,5392,4097,2476,1420,33,257,168,5377,648]

theorem envBound19723 : H12AffineFastState.Bounded env19723 := by
  intro p hp
  have h : env19723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19722_19723 : H12AffineEnvironment.transform 12 268 env19722 = env19723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19722 == env19723) = true)

theorem identity19723 : scanCanonicalize (H12AffineFastState.compose env19723 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19723 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19724 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,268,5377,1,294,5425,2309,1025,0,4144,32,48,34,300,17,2081,5392,4097,2308,1316,33,257,0,5377,544]

theorem envBound19724 : H12AffineFastState.Bounded env19724 := by
  intro p hp
  have h : env19724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19723_19724 : H12AffineEnvironment.transform 6 40 env19723 = env19724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19723 == env19724) = true)

def env19725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound19725 : H12AffineFastState.Bounded env19725 := by
  intro p hp
  have h : env19725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19336_19725 : H12AffineEnvironment.transform 26 30393345 env19336 = env19725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env19336 == env19725) = true)

def env19726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound19726 : H12AffineFastState.Bounded env19726 := by
  intro p hp
  have h : env19726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19725_19726 : H12AffineEnvironment.transform 18 1024 env19725 = env19726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19725 == env19726) = true)

theorem identity19726 : scanCanonicalize (H12AffineFastState.compose env19726 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388762) := by decide +kernel

theorem selectedBound19726 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388762,8328,64,4702363,10585110,10507601,8830976,99467,14771546,256,2212918,2172307,41821]

theorem envBound19727 : H12AffineFastState.Bounded env19727 := by
  intro p hp
  have h : env19727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19726_19727 : H12AffineEnvironment.transform 23 8388762 env19726 = env19727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388762 env19726 == env19727) = true)

def env19728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147474,8328,64,4702363,2344094,2233817,295048,99467,6497746,256,2212918,2172307,41821]

theorem envBound19728 : H12AffineFastState.Bounded env19728 := by
  intro p hp
  have h : env19728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19727_19728 : H12AffineEnvironment.transform 22 147592 env19727 = env19728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env19727 == env19728) = true)

def env19729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147474,8328,64,4450363,2344094,2233817,43048,99467,6497746,256,2212918,2172307,41821]

theorem envBound19729 : H12AffineFastState.Bounded env19729 := by
  intro p hp
  have h : env19729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19728_19729 : H12AffineEnvironment.transform 17 10400 env19728 = env19729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19728 == env19729) = true)

def env19730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,4194304,147456,147474,8192,64,4450363,2343958,2233681,43048,99331,6497626,256,2212918,2172187,41821]

theorem envBound19730 : H12AffineFastState.Bounded env19730 := by
  intro p hp
  have h : env19730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19729_19730 : H12AffineEnvironment.transform 6 8 env19729 = env19730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19729 == env19730) = true)

theorem identity19730 : scanCanonicalize (H12AffineFastState.compose env19730 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound19730 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env19731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,2097152,4194304,73755,73737,8192,64,4229152,2139149,2192714,43048,99331,6309185,256,2212918,2172187,41821]

theorem envBound19731 : H12AffineFastState.Bounded env19731 := by
  intro p hp
  have h : env19731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19730_19731 : H12AffineEnvironment.transform 16 90139 env19730 = env19731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env19730 == env19731) = true)

theorem identity19731 : scanCanonicalize (H12AffineFastState.compose env19731 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound19731 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env19732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,2097152,73770,73755,73737,8192,64,108554,2139149,2192714,43048,99331,2188651,256,2212918,2172187,41821]

theorem envBound19732 : H12AffineFastState.Bounded env19732 := by
  intro p hp
  have h : env19732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19731_19732 : H12AffineEnvironment.transform 21 73770 env19731 = env19732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env19731 == env19732) = true)

theorem identity19732 : scanCanonicalize (H12AffineFastState.compose env19732 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19732 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,2097152,73770,73755,73737,8192,64,67926,2098513,2192714,2420,75103,2188651,256,2188650,2172187,513]

theorem envBound19733 : H12AffineFastState.Bounded env19733 := by
  intro p hp
  have h : env19733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19732_19733 : H12AffineEnvironment.transform 14 8540 env19732 = env19733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19732 == env19733) = true)

theorem identity19733 : scanCanonicalize (H12AffineFastState.compose env19733 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19733 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,5457,73770,73755,73737,8192,64,67926,4096,90139,2420,75103,94266,256,94267,77898,513]

theorem envBound19734 : H12AffineFastState.Bounded env19734 := by
  intro p hp
  have h : env19734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19733_19734 : H12AffineEnvironment.transform 20 5457 env19733 = env19734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env19733 == env19734) = true)

theorem identity19734 : scanCanonicalize (H12AffineFastState.compose env19734 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound19734 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,10280,1024,8541,5457,73770,73755,73737,8192,64,67926,4096,77835,2420,75103,73770,256,73771,77898,513]

theorem envBound19735 : H12AffineFastState.Bounded env19735 := by
  intro p hp
  have h : env19735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19734_19735 : H12AffineEnvironment.transform 13 4112 env19734 = env19735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env19734 == env19735) = true)

theorem identity19735 : scanCanonicalize (H12AffineFastState.compose env19735 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound19735 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4112,1076,65536,71011,3392,1024,1077,5457,66882,66931,66913,1384,64,67926,4096,71011,2420,65591,66882,256,66883,70946,513]

theorem envBound19736 : H12AffineFastState.Bounded env19736 := by
  intro p hp
  have h : env19736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19735_19736 : H12AffineEnvironment.transform 12 1384 env19735 = env19736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env19735 == env19736) = true)

theorem identity19736 : scanCanonicalize (H12AffineFastState.compose env19736 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound19736 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env19737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4112,1076,7538,2065,3392,1024,1077,5457,6192,6145,6163,1384,64,5156,4096,2065,2420,7493,6192,256,6193,2128,513]

theorem envBound19737 : H12AffineFastState.Bounded env19737 := by
  intro p hp
  have h : env19737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19736_19737 : H12AffineEnvironment.transform 15 7538 env19736 = env19737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env19736 == env19737) = true)

theorem identity19737 : scanCanonicalize (H12AffineFastState.compose env19737 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19737 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,1384,2129,1076,1331,2065,3392,1024,1077,3344,113,64,82,1384,64,3173,2113,2065,2420,1284,113,256,112,2128,513]

theorem envBound19738 : H12AffineFastState.Bounded env19738 := by
  intro p hp
  have h : env19738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19737_19738 : H12AffineEnvironment.transform 11 2113 env19737 = env19738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19737 == env19738) = true)

theorem identity19738 : scanCanonicalize (H12AffineFastState.compose env19738 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1653) := by decide +kernel

theorem selectedBound19738 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env19739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1653,1588,1384,1572,1076,1331,1636,821,1024,1077,869,113,64,82,1384,64,528,1588,1636,1793,1284,113,256,112,1573,513]

theorem envBound19739 : H12AffineFastState.Bounded env19739 := by
  intro p hp
  have h : env19739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19738_19739 : H12AffineEnvironment.transform 10 1653 env19738 = env19739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1653 env19738 == env19739) = true)

theorem identity19739 : scanCanonicalize (H12AffineFastState.compose env19739 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19739 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env19740 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1573,1588,1336,1572,1076,1331,1588,821,1024,1077,821,33,16,2,1336,16,528,1588,1588,1793,1284,33,256,32,1573,513]

theorem envBound19740 : H12AffineFastState.Bounded env19740 := by
  intro p hp
  have h : env19740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19739_19740 : H12AffineEnvironment.transform 5 16 env19739 = env19740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19739 == env19740) = true)

theorem identity19740 : scanCanonicalize (H12AffineFastState.compose env19740 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound19740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19741 : List Nat := [2,4,8,16,32,16,8,21,512,1024,1573,1588,1069,1572,1076,1062,1588,544,1024,1077,544,33,16,2,1069,16,528,1588,1588,1556,1041,33,21,32,1573,513]

theorem envBound19741 : H12AffineFastState.Bounded env19741 := by
  intro p hp
  have h : env19741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19740_19741 : H12AffineEnvironment.transform 7 21 env19740 = env19741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env19740 == env19741) = true)

theorem identity19741 : scanCanonicalize (H12AffineFastState.compose env19741 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound19741 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env19742 : List Nat := [2,4,8,16,32,16,8,21,512,517,32,49,552,33,561,547,49,544,517,560,544,33,16,2,552,16,528,49,49,17,532,33,21,32,32,513]

theorem envBound19742 : H12AffineFastState.Bounded env19742 := by
  intro p hp
  have h : env19742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19741_19742 : H12AffineEnvironment.transform 9 517 env19741 = env19742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env19741 == env19742) = true)

theorem identity19742 : scanCanonicalize (H12AffineFastState.compose env19742 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound19742 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19743 : List Nat := [2,4,8,16,32,16,8,21,49,52,32,49,25,33,0,18,49,17,52,1,17,33,16,2,25,16,33,49,49,17,37,33,21,32,32,48]

theorem envBound19743 : H12AffineFastState.Bounded env19743 := by
  intro p hp
  have h : env19743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19742_19743 : H12AffineEnvironment.transform 8 49 env19742 = env19743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env19742 == env19743) = true)

def env19744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147457,147474,8193,64,4450363,2343959,2233680,43048,99330,6497627,256,2212918,2172186,41821]

theorem envBound19744 : H12AffineFastState.Bounded env19744 := by
  intro p hp
  have h : env19744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19729_19744 : H12AffineEnvironment.transform 6 9 env19729 = env19744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19729 == env19744) = true)

theorem identity19744 : scanCanonicalize (H12AffineFastState.compose env19744 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19744 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,147474,8193,64,4409703,2319691,2233680,2420,75102,6497627,256,2188650,2172186,513]

theorem envBound19745 : H12AffineFastState.Bounded env19745 := by
  intro p hp
  have h : env19745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19744_19745 : H12AffineEnvironment.transform 14 8540 env19744 = env19745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19744 == env19745) = true)

def env19746 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147457,147474,8193,16,4409655,2319643,2233600,2340,75022,6497547,256,2188602,2172186,513]

theorem envBound19746 : H12AffineFastState.Bounded env19746 := by
  intro p hp
  have h : env19746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19745_19746 : H12AffineEnvironment.transform 5 16 env19745 = env19746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19745 == env19746) = true)

theorem identity19746 : scanCanonicalize (H12AffineFastState.compose env19746 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213302) := by decide +kernel

theorem selectedBound19746 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env19747 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,213302,147457,147474,8193,16,2049,2319643,2233600,2340,75022,2122813,256,2188602,2172186,513]

theorem envBound19747 : H12AffineFastState.Bounded env19747 := by
  intro p hp
  have h : env19747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19746_19747 : H12AffineEnvironment.transform 21 213302 env19746 = env19747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213302 env19746 == env19747) = true)

theorem identity19747 : scanCanonicalize (H12AffineFastState.compose env19747 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19747 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19748 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,2097152,213302,147457,147474,268,16,2049,2311190,2233600,2340,66563,2114864,256,2180151,2163735,513]

theorem envBound19748 : H12AffineFastState.Bounded env19748 := by
  intro p hp
  have h : env19748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19747_19748 : H12AffineEnvironment.transform 12 269 env19747 = env19748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19747 == env19748) = true)

theorem identity19748 : scanCanonicalize (H12AffineFastState.compose env19748 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound19748 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19749 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,132352,213302,147457,147474,268,16,2049,82198,4096,2340,66563,147504,256,213303,196887,513]

theorem envBound19749 : H12AffineFastState.Bounded env19749 := by
  intro p hp
  have h : env19749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19748_19749 : H12AffineEnvironment.transform 20 132352 env19748 = env19749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env19748 == env19749) = true)

theorem identity19749 : scanCanonicalize (H12AffineFastState.compose env19749 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound19749 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19750 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,16401,2340,1024,0,17681,65831,16,3,268,16,2049,82198,4096,2340,66563,33,256,65830,82182,513]

theorem envBound19750 : H12AffineFastState.Bounded env19750 := by
  intro p hp
  have h : env19750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19749_19750 : H12AffineEnvironment.transform 16 16401 env19749 = env19750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19749 == env19750) = true)

theorem identity19750 : scanCanonicalize (H12AffineFastState.compose env19750 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 7732) := by decide +kernel

theorem selectedBound19750 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env19751 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,7732,1,65536,7717,2340,1024,0,6949,65831,16,3,268,16,2049,73506,4096,2340,66563,33,256,65830,73522,513]

theorem envBound19751 : H12AffineFastState.Bounded env19751 := by
  intro p hp
  have h : env19751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19750_19751 : H12AffineEnvironment.transform 13 7732 env19750 = env19751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7732 env19750 == env19751) = true)

theorem identity19751 : scanCanonicalize (H12AffineFastState.compose env19751 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound19751 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env19752 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,7732,1,262,7717,2340,1024,0,6949,33,16,3,268,16,2049,7716,4096,2340,1285,33,256,32,7732,513]

theorem envBound19752 : H12AffineFastState.Bounded env19752 := by
  intro p hp
  have h : env19752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19751_19752 : H12AffineEnvironment.transform 15 262 env19751 = env19752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env19751 == env19752) = true)

theorem identity19752 : scanCanonicalize (H12AffineFastState.compose env19752 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound19752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19753 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,276,269,3872,1,262,3889,2340,1024,0,2609,33,16,3,268,16,2049,3888,276,2340,1285,33,256,32,3872,513]

theorem envBound19753 : H12AffineFastState.Bounded env19753 := by
  intro p hp
  have h : env19753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19752_19753 : H12AffineEnvironment.transform 11 276 env19752 = env19753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env19752 == env19753) = true)

theorem identity19753 : scanCanonicalize (H12AffineFastState.compose env19753 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 299) := by decide +kernel

theorem selectedBound19753 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19754 : List Nat := [2,4,8,16,32,16,9,256,512,299,2048,276,269,2571,1,262,2586,2340,299,0,2609,33,16,3,268,16,2049,2587,276,2340,46,33,256,32,2571,513]

theorem envBound19754 : H12AffineFastState.Bounded env19754 := by
  intro p hp
  have h : env19754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19753_19754 : H12AffineEnvironment.transform 9 299 env19753 = env19754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 299 env19753 == env19754) = true)

theorem identity19754 : scanCanonicalize (H12AffineFastState.compose env19754 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound19754 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19755 : List Nat := [2,4,8,16,32,16,9,256,58,299,2048,276,269,2097,1,262,2080,2340,299,0,2059,33,16,3,268,16,2049,2081,276,2340,46,33,256,32,2097,59]

theorem envBound19755 : H12AffineFastState.Bounded env19755 := by
  intro p hp
  have h : env19755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19754_19755 : H12AffineEnvironment.transform 8 58 env19754 = env19755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env19754 == env19755) = true)

theorem identity19755 : scanCanonicalize (H12AffineFastState.compose env19755 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19755 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19756 : List Nat := [2,4,2,16,32,16,3,256,48,289,2048,276,263,2097,1,262,2080,2340,289,0,2049,33,16,3,262,16,2049,2081,276,2340,36,33,256,32,2097,49]

theorem envBound19756 : H12AffineFastState.Bounded env19756 := by
  intro p hp
  have h : env19756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19755_19756 : H12AffineEnvironment.transform 2 2 env19755 = env19756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19755 == env19756) = true)

theorem identity19756 : scanCanonicalize (H12AffineFastState.compose env19756 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound19756 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19757 : List Nat := [2,4,2,16,32,16,3,256,48,289,49,276,263,0,1,262,17,277,289,0,48,33,16,3,262,16,48,16,276,277,36,33,256,32,0,49]

theorem envBound19757 : H12AffineFastState.Bounded env19757 := by
  intro p hp
  have h : env19757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19756_19757 : H12AffineEnvironment.transform 10 49 env19756 = env19757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19756 == env19757) = true)

theorem identity19757 : scanCanonicalize (H12AffineFastState.compose env19757 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound19757 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env19758 : List Nat := [2,4,2,16,32,16,3,21,48,52,49,1,18,0,1,19,17,0,52,0,48,33,16,3,19,16,48,16,1,0,36,33,21,32,0,49]

theorem envBound19758 : H12AffineFastState.Bounded env19758 := by
  intro p hp
  have h : env19758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19757_19758 : H12AffineEnvironment.transform 7 21 env19757 = env19758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env19757 == env19758) = true)

theorem identity19758 : scanCanonicalize (H12AffineFastState.compose env19758 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound19758 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19759 : List Nat := [2,4,2,16,23,16,3,21,7,3,6,1,18,0,1,19,17,0,3,0,7,22,16,3,19,16,7,16,1,0,19,22,21,23,0,6]

theorem envBound19759 : H12AffineFastState.Bounded env19759 := by
  intro p hp
  have h : env19759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19758_19759 : H12AffineEnvironment.transform 4 23 env19758 = env19759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env19758 == env19759) = true)

def env19760 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147457,147474,8193,17,4409654,2319642,2233601,2341,75023,6497546,256,2188603,2172186,513]

theorem envBound19760 : H12AffineFastState.Bounded env19760 := by
  intro p hp
  have h : env19760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19745_19760 : H12AffineEnvironment.transform 5 17 env19745 = env19760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19745 == env19760) = true)

theorem identity19760 : scanCanonicalize (H12AffineFastState.compose env19760 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound19760 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env19761 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,8493,147457,147474,8193,17,223259,2319642,2233601,2341,75023,2294823,256,2188603,2172186,513]

theorem envBound19761 : H12AffineFastState.Bounded env19761 := by
  intro p hp
  have h : env19761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19760_19761 : H12AffineEnvironment.transform 21 8493 env19760 = env19761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env19760 == env19761) = true)

theorem identity19761 : scanCanonicalize (H12AffineFastState.compose env19761 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197639) := by decide +kernel

theorem selectedBound19761 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19762 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,197639,8493,147457,147474,8193,17,223259,24861,69894,2341,75023,32,256,155964,139549,513]

theorem envBound19762 : H12AffineFastState.Bounded env19762 := by
  intro p hp
  have h : env19762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19761_19762 : H12AffineEnvironment.transform 20 197639 env19761 = env19762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197639 env19761 == env19762) = true)

theorem identity19762 : scanCanonicalize (H12AffineFastState.compose env19762 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound19762 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env19763 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,24860,10281,1024,8460,91419,8493,8477,8462,8193,17,67847,24861,69894,2341,75023,32,256,32,16385,513]

theorem envBound19763 : H12AffineFastState.Bounded env19763 := by
  intro p hp
  have h : env19763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19762_19763 : H12AffineEnvironment.transform 16 24860 env19762 = env19763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env19762 == env19763) = true)

theorem identity19763 : scanCanonicalize (H12AffineFastState.compose env19763 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19763 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19764 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,65536,16400,2341,1024,0,82967,33,17,2,269,17,67847,16401,69894,2341,66563,32,256,32,16385,513]

theorem envBound19764 : H12AffineFastState.Bounded env19764 := by
  intro p hp
  have h : env19764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19763_19764 : H12AffineEnvironment.transform 12 268 env19763 = env19764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19763 == env19764) = true)

theorem identity19764 : scanCanonicalize (H12AffineFastState.compose env19764 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound19764 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19765 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1024,0,17681,33,17,2,269,17,2049,16401,4096,2341,1285,32,256,32,16385,513]

theorem envBound19765 : H12AffineFastState.Bounded env19765 := by
  intro p hp
  have h : env19765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19764_19765 : H12AffineEnvironment.transform 15 262 env19764 = env19765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env19764 == env19765) = true)

theorem identity19765 : scanCanonicalize (H12AffineFastState.compose env19765 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19766 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1024,0,4113,33,17,2,269,17,2049,5393,4096,2341,1285,32,256,32,5377,513]

theorem envBound19766 : H12AffineFastState.Bounded env19766 := by
  intro p hp
  have h : env19766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19765_19766 : H12AffineEnvironment.transform 13 5376 env19765 = env19766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19765 == env19766) = true)

theorem identity19766 : scanCanonicalize (H12AffineFastState.compose env19766 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2879) := by decide +kernel

theorem selectedBound19766 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19767 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2879,268,3647,1,262,3631,2341,1024,0,2862,33,17,2,269,17,2049,3630,2879,2341,1285,32,256,32,3646,513]

theorem envBound19767 : H12AffineFastState.Bounded env19767 := by
  intro p hp
  have h : env19767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19766_19767 : H12AffineEnvironment.transform 11 2879 env19766 = env19767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2879 env19766 == env19767) = true)

theorem identity19767 : scanCanonicalize (H12AffineFastState.compose env19767 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19767 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19768 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,2618,9,3647,1,3,3631,2080,1024,0,2603,33,17,2,8,17,2049,3630,2618,2080,1024,32,5,32,3646,513]

theorem envBound19768 : H12AffineFastState.Bounded env19768 := by
  intro p hp
  have h : env19768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19767_19768 : H12AffineEnvironment.transform 7 5 env19767 = env19768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19767 == env19768) = true)

theorem identity19768 : scanCanonicalize (H12AffineFastState.compose env19768 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound19768 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19769 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1567,1061,9,32,1,3,48,1599,1024,0,1076,33,17,2,8,17,1566,49,1061,1599,1024,32,5,32,33,513]

theorem envBound19769 : H12AffineFastState.Bounded env19769 := by
  intro p hp
  have h : env19769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19768_19769 : H12AffineEnvironment.transform 10 1567 env19768 = env19769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env19768 == env19769) = true)

theorem identity19769 : scanCanonicalize (H12AffineFastState.compose env19769 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound19769 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19770 : List Nat := [2,4,8,16,32,17,9,5,512,543,0,570,9,32,1,3,48,32,543,0,555,33,17,2,8,17,1,49,570,32,543,32,5,32,33,513]

theorem envBound19770 : H12AffineFastState.Bounded env19770 := by
  intro p hp
  have h : env19770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19769_19770 : H12AffineEnvironment.transform 9 543 env19769 = env19770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env19769 == env19770) = true)

def env19771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147474,8328,64,4450362,2344094,2233817,43049,99467,6497746,256,2212918,2172307,41821]

theorem envBound19771 : H12AffineFastState.Bounded env19771 := by
  intro p hp
  have h : env19771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19728_19771 : H12AffineEnvironment.transform 17 10401 env19728 = env19771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19728 == env19771) = true)

theorem identity19771 : scanCanonicalize (H12AffineFastState.compose env19771 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound19771 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4303010,2196486,2118977,43049,99467,6382922,256,2212918,2172307,41821]

theorem envBound19772 : H12AffineFastState.Bounded env19772 := by
  intro p hp
  have h : env19772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19771_19772 : H12AffineEnvironment.transform 16 16536 env19771 = env19772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env19771 == env19772) = true)

theorem identity19772 : scanCanonicalize (H12AffineFastState.compose env19772 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound19772 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env19773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4204925,2098649,2118977,43049,1364,6349973,256,2115049,2139212,41821]

theorem envBound19773 : H12AffineFastState.Bounded env19773 := by
  intro p hp
  have h : env19773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19772_19773 : H12AffineEnvironment.transform 15 33247 env19772 = env19773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env19772 == env19773) = true)

theorem identity19773 : scanCanonicalize (H12AffineFastState.compose env19773 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19773 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,2097152,32,16,138,8328,64,10589,2098649,2118977,43049,1364,2155701,256,2115049,2139212,41821]

theorem envBound19774 : H12AffineFastState.Bounded env19774 := by
  intro p hp
  have h : env19774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19773_19774 : H12AffineEnvironment.transform 21 32 env19773 = env19774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19773 == env19774) = true)

theorem identity19774 : scanCanonicalize (H12AffineFastState.compose env19774 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound19774 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env19775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,50448,32,16,138,8328,64,10589,49353,36945,43049,1364,8613,256,33017,24924,41821]

theorem envBound19775 : H12AffineFastState.Bounded env19775 := by
  intro p hp
  have h : env19775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19774_19775 : H12AffineEnvironment.transform 20 50448 env19774 = env19775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env19774 == env19775) = true)

theorem identity19775 : scanCanonicalize (H12AffineFastState.compose env19775 (packedSelected [2,3,6,7,8,9,11,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13809) := by decide +kernel

theorem selectedBound19775 : packedSelected [2,3,6,7,8,9,11,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env19776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,32768,33247,13673,10401,1024,32769,45281,32,16,138,8328,64,10589,46392,36945,43049,1364,8613,256,33017,5293,41821]

theorem envBound19776 : H12AffineFastState.Bounded env19776 := by
  intro p hp
  have h : env19776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19775_19776 : H12AffineEnvironment.transform 13 13809 env19775 = env19776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13809 env19775 == env19776) = true)

theorem identity19776 : scanCanonicalize (H12AffineFastState.compose env19776 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound19776 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env19777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,8313,8614,13673,10401,1024,8312,4248,32,16,138,8328,64,10589,5441,12328,2128,1364,8613,256,8320,5293,804]

theorem envBound19777 : H12AffineFastState.Bounded env19777 := by
  intro p hp
  have h : env19777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19776_19777 : H12AffineEnvironment.transform 14 8313 env19776 = env19777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env19776 == env19777) = true)

theorem identity19777 : scanCanonicalize (H12AffineFastState.compose env19777 (packedSelected [2,3,4,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound19777 : packedSelected [2,3,4,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env19778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5377,137,342,5529,2129,1024,136,4248,32,16,138,120,64,2477,5441,4312,2128,1364,341,256,112,5293,804]

theorem envBound19778 : H12AffineFastState.Bounded env19778 := by
  intro p hp
  have h : env19778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19777_19778 : H12AffineEnvironment.transform 12 240 env19777 = env19778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env19777 == env19778) = true)

theorem identity19778 : scanCanonicalize (H12AffineFastState.compose env19778 (packedSelected [0,1,2,3,4,6,11,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19778 : packedSelected [0,1,2,3,4,6,11,17] rootPS < 2^1333 := by decide +kernel

def env19779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,1,342,5393,2129,1024,0,4112,32,16,2,120,64,2341,5441,4176,2128,1364,341,256,112,5157,804]

theorem envBound19779 : H12AffineFastState.Bounded env19779 := by
  intro p hp
  have h : env19779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19778_19779 : H12AffineEnvironment.transform 6 8 env19778 = env19779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19778 == env19779) = true)

theorem identity19779 : scanCanonicalize (H12AffineFastState.compose env19779 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19779 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19780 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,5377,1,342,5393,2129,1024,0,4112,0,16,2,88,64,2309,5441,4176,2128,1364,341,256,80,5125,772]

theorem envBound19780 : H12AffineFastState.Bounded env19780 := by
  intro p hp
  have h : env19780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19779_19780 : H12AffineEnvironment.transform 4 0 env19779 = env19780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19779 == env19780) = true)

theorem identity19780 : scanCanonicalize (H12AffineFastState.compose env19780 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19780 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19781 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,8,5377,1,262,5393,2049,1024,0,4112,0,16,2,8,16,2309,5393,4096,2048,1284,261,256,0,5125,772]

theorem envBound19781 : H12AffineFastState.Bounded env19781 := by
  intro p hp
  have h : env19781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19780_19781 : H12AffineEnvironment.transform 5 16 env19780 = env19781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19780 == env19781) = true)

theorem identity19781 : scanCanonicalize (H12AffineFastState.compose env19781 (packedSelected [1,2,3,4,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19781 : packedSelected [1,2,3,4,7,12] rootPS < 2^1333 := by decide +kernel

def env19782 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,1,2,5141,2049,1024,0,4112,0,16,2,8,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound19782 : H12AffineFastState.Bounded env19782 := by
  intro p hp
  have h : env19782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19781_19782 : H12AffineEnvironment.transform 7 4 env19781 = env19782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19781 == env19782) = true)

def env19783 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1045,1,2,1029,2049,1024,0,0,0,16,2,8,16,2049,1029,16,2048,1024,1,4,0,1045,512]

theorem envBound19783 : H12AffineFastState.Bounded env19783 := by
  intro p hp
  have h : env19783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19782_19783 : H12AffineEnvironment.transform 11 16 env19782 = env19783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19782 == env19783) = true)

theorem identity19783 : scanCanonicalize (H12AffineFastState.compose env19783 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19784 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1045,1,2,1029,1,1024,0,0,0,16,2,8,16,1,1029,16,0,1024,1,4,0,1045,512]

theorem envBound19784 : H12AffineFastState.Bounded env19784 := by
  intro p hp
  have h : env19784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19783_19784 : H12AffineEnvironment.transform 10 0 env19783 = env19784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19783 == env19784) = true)

def env19785 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,1,1,2,17,1,20,0,0,0,16,2,8,16,1,17,16,0,20,1,4,0,1,512]

theorem envBound19785 : H12AffineFastState.Bounded env19785 := by
  intro p hp
  have h : env19785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19784_19785 : H12AffineEnvironment.transform 9 20 env19784 = env19785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19784 == env19785) = true)

theorem identity19785 : scanCanonicalize (H12AffineFastState.compose env19785 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound19785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19786 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,8,1,1,2,17,1,20,0,0,0,16,2,8,16,1,17,16,0,20,1,4,0,1,30]

theorem envBound19786 : H12AffineFastState.Bounded env19786 := by
  intro p hp
  have h : env19786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19785_19786 : H12AffineEnvironment.transform 8 30 env19785 = env19786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env19785 == env19786) = true)

def leafEnv19786 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,8,1,1,2,17,1,20,0,0,0,16,2,20,8,1,16,1,17,16,0,20,1,4,0,4,2,1,30,1,0,0]

def active19786 : List Nat := [0,1,2,3]

def tree19786 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19786 : H12WitnessSearch.Good tree19786 := H12GlobalWitnessIndex.good

theorem leafIdentity19786 : H12AffineFastState.composeSystem env19786 rootObs = leafEnv19786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19786 rootObs == leafEnv19786) = true)

theorem terminalChecked19786 : H12PackedTerminal.terminalCheckFast leafEnv19786 active19786 tree19786 = true := by decide +kernel

def env19787 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,1,2,16,1,21,0,0,0,16,2,8,16,1,16,16,0,21,1,4,0,0,512]

theorem envBound19787 : H12AffineFastState.Bounded env19787 := by
  intro p hp
  have h : env19787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19784_19787 : H12AffineEnvironment.transform 9 21 env19784 = env19787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19784 == env19787) = true)

theorem identity19787 : scanCanonicalize (H12AffineFastState.compose env19787 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound19787 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19788 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,1,2,5,1,0,0,0,0,5,2,8,5,1,5,5,0,0,1,4,0,0,512]

theorem envBound19788 : H12AffineFastState.Bounded env19788 := by
  intro p hp
  have h : env19788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19787_19788 : H12AffineEnvironment.transform 3 5 env19787 = env19788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env19787 == env19788) = true)

def leafEnv19788 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,1,2,5,1,0,0,0,0,5,2,0,8,1,5,1,5,5,0,0,1,4,0,4,2,0,512,1,0,0]

def active19788 : List Nat := [0,1,2,8]

def tree19788 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19788 : H12WitnessSearch.Good tree19788 := H12GlobalWitnessIndex.good

theorem leafIdentity19788 : H12AffineFastState.composeSystem env19788 rootObs = leafEnv19788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19788 rootObs == leafEnv19788) = true)

theorem terminalChecked19788 : H12PackedTerminal.terminalCheckFast leafEnv19788 active19788 tree19788 = true := by decide +kernel

def env19789 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1044,1,2,1028,2049,1024,0,1,0,16,2,8,16,2049,1028,17,2048,1024,1,4,0,1044,512]

theorem envBound19789 : H12AffineFastState.Bounded env19789 := by
  intro p hp
  have h : env19789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19782_19789 : H12AffineEnvironment.transform 11 17 env19782 = env19789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19782 == env19789) = true)

theorem identity19789 : scanCanonicalize (H12AffineFastState.compose env19789 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound19789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19790 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,17,8,1044,1,2,1028,1045,1024,0,1,0,16,2,8,16,1045,1028,17,1044,1024,1,4,0,1044,512]

theorem envBound19790 : H12AffineFastState.Bounded env19790 := by
  intro p hp
  have h : env19790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19789_19790 : H12AffineEnvironment.transform 10 1044 env19789 = env19790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env19789 == env19790) = true)

def env19791 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,0,1,2,16,1,20,0,1,0,16,2,8,16,1,16,17,0,20,1,4,0,0,512]

theorem envBound19791 : H12AffineFastState.Bounded env19791 := by
  intro p hp
  have h : env19791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19790_19791 : H12AffineEnvironment.transform 9 20 env19790 = env19791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19790 == env19791) = true)

theorem identity19791 : scanCanonicalize (H12AffineFastState.compose env19791 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound19791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19792 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,17,8,0,1,2,16,1,20,0,1,0,16,2,8,16,1,16,17,0,20,1,4,0,0,30]

theorem envBound19792 : H12AffineFastState.Bounded env19792 := by
  intro p hp
  have h : env19792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19791_19792 : H12AffineEnvironment.transform 8 30 env19791 = env19792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env19791 == env19792) = true)

def leafEnv19792 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,17,8,0,1,2,16,1,20,0,1,0,16,2,20,8,1,16,1,16,17,0,20,1,4,0,4,2,0,30,1,1,0]

def active19792 : List Nat := [0,1,2,3]

def tree19792 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19792 : H12WitnessSearch.Good tree19792 := H12GlobalWitnessIndex.good

theorem leafIdentity19792 : H12AffineFastState.composeSystem env19792 rootObs = leafEnv19792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19792 rootObs == leafEnv19792) = true)

theorem terminalChecked19792 : H12PackedTerminal.terminalCheckFast leafEnv19792 active19792 tree19792 = true := by decide +kernel

def env19793 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,8,1,1,2,17,0,21,0,1,0,16,2,8,16,0,17,17,1,21,1,4,0,1,512]

theorem envBound19793 : H12AffineFastState.Bounded env19793 := by
  intro p hp
  have h : env19793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19790_19793 : H12AffineEnvironment.transform 9 21 env19790 = env19793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19790 == env19793) = true)

theorem identity19793 : scanCanonicalize (H12AffineFastState.compose env19793 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound19793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19794 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,8,1,1,2,4,0,0,0,1,0,5,2,8,5,0,4,4,1,0,1,4,0,1,512]

theorem envBound19794 : H12AffineFastState.Bounded env19794 := by
  intro p hp
  have h : env19794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19793_19794 : H12AffineEnvironment.transform 3 5 env19793 = env19794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env19793 == env19794) = true)

def leafEnv19794 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,8,1,1,2,4,0,0,0,1,0,5,2,0,8,1,5,0,4,4,1,0,1,4,0,4,2,1,512,1,1,0]

def active19794 : List Nat := [0,1,2,8]

def tree19794 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19794 : H12WitnessSearch.Good tree19794 := H12GlobalWitnessIndex.good

theorem leafIdentity19794 : H12AffineFastState.composeSystem env19794 rootObs = leafEnv19794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19794 rootObs == leafEnv19794) = true)

theorem terminalChecked19794 : H12PackedTerminal.terminalCheckFast leafEnv19794 active19794 tree19794 = true := by decide +kernel

def env19795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147475,8328,64,4702363,2344095,2233816,295049,99467,6497747,256,2212918,2172307,41821]

theorem envBound19795 : H12AffineFastState.Bounded env19795 := by
  intro p hp
  have h : env19795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19727_19795 : H12AffineEnvironment.transform 22 147593 env19727 = env19795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env19727 == env19795) = true)

def env19796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147475,8328,64,4450363,2344095,2233816,43049,99467,6497747,256,2212918,2172307,41821]

theorem envBound19796 : H12AffineFastState.Bounded env19796 := by
  intro p hp
  have h : env19796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19795_19796 : H12AffineEnvironment.transform 17 10400 env19795 = env19796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19795 == env19796) = true)

theorem identity19796 : scanCanonicalize (H12AffineFastState.compose env19796 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19796 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147593,147475,8328,64,4409703,2319811,2233816,2421,75223,6497747,256,2188650,2172307,513]

theorem envBound19797 : H12AffineFastState.Bounded env19797 := by
  intro p hp
  have h : env19797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19796_19797 : H12AffineEnvironment.transform 14 8540 env19796 = env19797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19796 == env19797) = true)

def env19798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,2097152,4194304,147457,147475,8192,64,4409703,2319691,2233680,2421,75103,6497627,256,2188650,2172187,513]

theorem envBound19798 : H12AffineFastState.Bounded env19798 := by
  intro p hp
  have h : env19798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19797_19798 : H12AffineEnvironment.transform 6 8 env19797 = env19798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19797 == env19798) = true)

theorem identity19798 : scanCanonicalize (H12AffineFastState.compose env19798 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound19798 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,2097152,4194304,73754,73736,8192,64,4204924,2098512,2192715,2421,75103,6309184,256,2188650,2172187,513]

theorem envBound19799 : H12AffineFastState.Bounded env19799 := by
  intro p hp
  have h : env19799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19798_19799 : H12AffineEnvironment.transform 16 90139 env19798 = env19799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env19798 == env19799) = true)

theorem identity19799 : scanCanonicalize (H12AffineFastState.compose env19799 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound19799 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env19800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,79195,4194304,73754,73736,8192,64,4204924,77835,16400,2421,75103,4288539,256,20529,4160,513]

theorem envBound19800 : H12AffineFastState.Bounded env19800 := by
  intro p hp
  have h : env19800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19799_19800 : H12AffineEnvironment.transform 20 79195 env19799 = env19800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env19799 == env19800) = true)

theorem identity19800 : scanCanonicalize (H12AffineFastState.compose env19800 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7253) := by decide +kernel

theorem selectedBound19800 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env19801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1024,8541,79195,7253,73754,73736,8192,64,13609,77835,16400,2421,75103,93262,256,20529,4160,513]

theorem envBound19801 : H12AffineFastState.Bounded env19801 := by
  intro p hp
  have h : env19801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19800_19801 : H12AffineEnvironment.transform 21 7253 env19800 = env19801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7253 env19800 == env19801) = true)

theorem identity19801 : scanCanonicalize (H12AffineFastState.compose env19801 (packedSelected [11,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19801 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env19802 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8540,65536,90139,10280,100,8541,78143,6193,73754,73736,8192,64,12621,77835,16400,2421,74043,92202,256,20529,4160,513]

theorem envBound19802 : H12AffineFastState.Bounded env19802 := by
  intro p hp
  have h : env19802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19801_19802 : H12AffineEnvironment.transform 9 100 env19801 = env19802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19801 == env19802) = true)

theorem identity19802 : scanCanonicalize (H12AffineFastState.compose env19802 (packedSelected [0,2,3,6,7,8,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound19802 : packedSelected [0,2,3,6,7,8,10,14,20] rootPS < 2^1333 := by decide +kernel

def env19803 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8540,65536,77835,10280,100,8541,78143,6193,73754,73736,8192,64,12621,77835,4096,2421,74043,79930,256,33,4160,513]

theorem envBound19803 : H12AffineFastState.Bounded env19803 := by
  intro p hp
  have h : env19803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19802_19803 : H12AffineEnvironment.transform 13 4112 env19802 = env19803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env19802 == env19803) = true)

theorem identity19803 : scanCanonicalize (H12AffineFastState.compose env19803 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19803 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env19804 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8540,8202,4097,10280,100,8541,4405,6193,16,2,8192,64,12621,4097,4096,2421,305,6192,256,33,4160,513]

theorem envBound19804 : H12AffineFastState.Bounded env19804 := by
  intro p hp
  have h : env19804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19803_19804 : H12AffineEnvironment.transform 15 8202 env19803 = env19804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19803 == env19804) = true)

theorem identity19804 : scanCanonicalize (H12AffineFastState.compose env19804 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19805 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,4112,8461,8202,4097,10280,53,8460,4405,6193,16,2,8192,17,12572,4097,4096,2340,305,6192,256,33,4113,513]

theorem envBound19805 : H12AffineFastState.Bounded env19805 := by
  intro p hp
  have h : env19805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19804_19805 : H12AffineEnvironment.transform 5 17 env19804 = env19805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19804 == env19805) = true)

theorem identity19805 : scanCanonicalize (H12AffineFastState.compose env19805 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 4147) := by decide +kernel

theorem selectedBound19805 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env19806 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,4147,4112,4414,4153,4097,6171,53,4415,4405,6193,16,2,4147,17,303,4097,4096,2340,305,6192,256,33,4113,513]

theorem envBound19806 : H12AffineFastState.Bounded env19806 := by
  intro p hp
  have h : env19806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19805_19806 : H12AffineEnvironment.transform 12 4147 env19805 = env19806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4147 env19805 == env19806) = true)

def env19807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147475,8193,64,4409703,2319690,2233681,2421,75102,6497626,256,2188650,2172186,513]

theorem envBound19807 : H12AffineFastState.Bounded env19807 := by
  intro p hp
  have h : env19807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19797_19807 : H12AffineEnvironment.transform 6 9 env19797 = env19807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19797 == env19807) = true)

theorem identity19807 : scanCanonicalize (H12AffineFastState.compose env19807 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound19807 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env19808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,25629,4194304,147456,147475,8193,64,4409703,196951,160076,2421,75102,4407623,256,65911,82183,513]

theorem envBound19808 : H12AffineFastState.Bounded env19808 := by
  intro p hp
  have h : env19808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19807_19808 : H12AffineEnvironment.transform 20 25629 env19807 = env19808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env19807 == env19808) = true)

theorem identity19808 : scanCanonicalize (H12AffineFastState.compose env19808 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound19808 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env19809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,25629,4194304,16,3,8193,64,4262263,82247,12636,2421,75102,4260183,256,65911,82183,513]

theorem envBound19809 : H12AffineFastState.Bounded env19809 := by
  intro p hp
  have h : env19809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19808_19809 : H12AffineEnvironment.transform 16 16400 env19808 = env19809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19808 == env19809) = true)

theorem identity19809 : scanCanonicalize (H12AffineFastState.compose env19809 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound19809 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env19810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,25629,8572,16,3,8193,64,75787,82247,12636,2421,75102,73771,256,65911,82183,513]

theorem envBound19810 : H12AffineFastState.Bounded env19810 := by
  intro p hp
  have h : env19810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19809_19810 : H12AffineEnvironment.transform 21 8572 env19809 = env19810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env19809 == env19810) = true)

theorem identity19810 : scanCanonicalize (H12AffineFastState.compose env19810 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound19810 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env19811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,343,16400,10281,1024,8541,25629,8572,16,3,8193,64,10588,16400,12636,2421,9225,8572,256,32,16464,513]

theorem envBound19811 : H12AffineFastState.Bounded env19811 := by
  intro p hp
  have h : env19811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19810_19811 : H12AffineEnvironment.transform 15 343 env19810 = env19811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env19810 == env19811) = true)

theorem identity19811 : scanCanonicalize (H12AffineFastState.compose env19811 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound19811 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,17,8540,343,1,10281,1024,8541,9228,8572,16,3,8193,64,10588,1,12636,2421,9225,8572,256,32,65,513]

theorem envBound19812 : H12AffineFastState.Bounded env19812 := by
  intro p hp
  have h : env19812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19811_19812 : H12AffineEnvironment.transform 13 17 env19811 = env19812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env19811 == env19812) = true)

theorem identity19812 : scanCanonicalize (H12AffineFastState.compose env19812 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19812 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,17,1,343,1,2420,1024,0,1361,33,16,3,348,64,2049,1,4097,2421,1364,33,256,32,65,513]

theorem envBound19813 : H12AffineFastState.Bounded env19813 := by
  intro p hp
  have h : env19813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19812_19813 : H12AffineEnvironment.transform 12 349 env19812 = env19813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19812 == env19813) = true)

theorem identity19813 : scanCanonicalize (H12AffineFastState.compose env19813 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound19813 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2351,349,17,1,343,1,2420,1024,0,1361,33,16,3,348,64,2049,1,2350,2421,1364,33,256,32,65,513]

theorem envBound19814 : H12AffineFastState.Bounded env19814 := by
  intro p hp
  have h : env19814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19813_19814 : H12AffineEnvironment.transform 11 2351 env19813 = env19814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env19813 == env19814) = true)

theorem identity19814 : scanCanonicalize (H12AffineFastState.compose env19814 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19814 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19815 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2351,268,17,1,262,1,2341,1024,0,1280,33,16,3,269,17,2049,1,2350,2340,1285,33,256,32,16,513]

theorem envBound19815 : H12AffineFastState.Bounded env19815 := by
  intro p hp
  have h : env19815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19814_19815 : H12AffineEnvironment.transform 5 17 env19814 = env19815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19814 == env19815) = true)

theorem identity19815 : scanCanonicalize (H12AffineFastState.compose env19815 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound19815 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19816 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2351,268,17,1,262,1,2341,53,0,309,33,16,3,269,17,2049,1,2350,2340,304,33,256,32,16,513]

theorem envBound19816 : H12AffineFastState.Bounded env19816 := by
  intro p hp
  have h : env19816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19815_19816 : H12AffineEnvironment.transform 9 53 env19815 = env19816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19815 == env19816) = true)

theorem identity19816 : scanCanonicalize (H12AffineFastState.compose env19816 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound19816 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19817 : List Nat := [2,4,8,16,32,17,9,35,512,53,2048,2060,47,17,1,37,1,2054,53,0,22,33,16,3,46,17,2049,1,2061,2055,19,33,35,32,16,513]

theorem envBound19817 : H12AffineFastState.Bounded env19817 := by
  intro p hp
  have h : env19817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19816_19817 : H12AffineEnvironment.transform 7 35 env19816 = env19817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env19816 == env19817) = true)

theorem identity19817 : scanCanonicalize (H12AffineFastState.compose env19817 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound19817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19818 : List Nat := [2,4,8,16,12,17,9,15,512,25,2048,2060,3,17,1,9,1,2054,25,0,22,13,16,3,2,17,2049,1,2061,2055,19,13,15,12,16,513]

theorem envBound19818 : H12AffineFastState.Bounded env19818 := by
  intro p hp
  have h : env19818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19817_19818 : H12AffineEnvironment.transform 4 12 env19817 = env19818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env19817 == env19818) = true)

theorem identity19818 : scanCanonicalize (H12AffineFastState.compose env19818 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound19818 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env19819 : List Nat := [2,4,8,12,12,13,9,15,512,5,2048,2060,3,13,1,9,1,2054,5,0,10,13,12,3,2,13,2049,1,2061,2055,15,13,15,12,12,513]

theorem envBound19819 : H12AffineFastState.Bounded env19819 := by
  intro p hp
  have h : env19819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19818_19819 : H12AffineEnvironment.transform 3 12 env19818 = env19819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env19818 == env19819) = true)

def env19820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147475,8328,64,4450362,2344095,2233816,43048,99467,6497747,256,2212918,2172307,41821]

theorem envBound19820 : H12AffineFastState.Bounded env19820 := by
  intro p hp
  have h : env19820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19795_19820 : H12AffineEnvironment.transform 17 10401 env19795 = env19820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19795 == env19820) = true)

theorem identity19820 : scanCanonicalize (H12AffineFastState.compose env19820 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound19820 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10401,1024,32769,2097152,4194304,41292,41430,8328,64,4262399,2172250,2159645,43048,99467,6407190,256,2212918,2172307,41821]

theorem envBound19821 : H12AffineFastState.Bounded env19821 := by
  intro p hp
  have h : env19821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19820_19821 : H12AffineEnvironment.transform 16 57797 env19820 = env19821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env19820 == env19821) = true)

theorem identity19821 : scanCanonicalize (H12AffineFastState.compose env19821 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound19821 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env19822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57797,10401,1024,32769,2097152,4194304,41292,41430,8328,64,4204925,2098648,2159645,43048,41993,6349972,256,2155700,2098449,41821]

theorem envBound19822 : H12AffineFastState.Bounded env19822 := by
  intro p hp
  have h : env19822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19821_19822 : H12AffineEnvironment.transform 15 8322 env19821 = env19822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env19821 == env19822) = true)

theorem identity19822 : scanCanonicalize (H12AffineFastState.compose env19822 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound19822 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57797,10401,1024,32769,2097152,41340,41292,41430,8328,64,34817,2098648,2159645,43048,41993,2115048,256,2155700,2098449,41821]

theorem envBound19823 : H12AffineFastState.Bounded env19823 := by
  intro p hp
  have h : env19823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19822_19823 : H12AffineEnvironment.transform 21 41340 env19822 = env19823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env19822 == env19823) = true)

theorem identity19823 : scanCanonicalize (H12AffineFastState.compose env19823 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound19823 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env19824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57797,10401,1024,32769,50449,41340,41292,41430,8328,64,34817,49353,12556,43048,41993,33017,256,8613,49152,41821]

theorem envBound19824 : H12AffineFastState.Bounded env19824 := by
  intro p hp
  have h : env19824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19823_19824 : H12AffineEnvironment.transform 20 50449 env19823 = env19824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env19823 == env19824) = true)

theorem identity19824 : scanCanonicalize (H12AffineFastState.compose env19824 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound19824 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,21,23] rootPS < 2^1333 := by decide +kernel

def env19825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29992,8322,5357,10401,1024,29993,12345,21588,21604,21758,8328,64,32041,13793,12556,23808,20769,30161,256,8613,13608,22133]

theorem envBound19825 : H12AffineFastState.Bounded env19825 := by
  intro p hp
  have h : env19825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19824_19825 : H12AffineEnvironment.transform 14 29992 env19824 = env19825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env19824 == env19825) = true)

theorem identity19825 : scanCanonicalize (H12AffineFastState.compose env19825 (packedSelected [1,4,8,9,10,11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound19825 : packedSelected [1,4,8,9,10,11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env19826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21977,115,5357,2128,1024,21976,4296,21588,21604,21758,121,64,24024,5392,4605,23808,20769,21792,256,340,5593,22133]

theorem envBound19826 : H12AffineFastState.Bounded env19826 := by
  intro p hp
  have h : env19826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19825_19826 : H12AffineEnvironment.transform 12 241 env19825 = env19826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env19825 == env19826) = true)

theorem identity19826 : scanCanonicalize (H12AffineFastState.compose env19826 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19826 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5236,429,115,5357,2128,1024,428,4296,32,16,138,121,64,2476,5392,4605,2420,1365,340,256,340,5593,513]

theorem envBound19827 : H12AffineFastState.Bounded env19827 := by
  intro p hp
  have h : env19827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19826_19827 : H12AffineEnvironment.transform 13 5236 env19826 = env19827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19826 == env19827) = true)

theorem identity19827 : scanCanonicalize (H12AffineFastState.compose env19827 (packedSelected [4,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19827 : packedSelected [4,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19828 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,5236,372,115,5172,2128,1024,373,4113,32,16,83,121,64,2421,5392,4388,2420,1365,340,256,340,5376,513]

theorem envBound19828 : H12AffineFastState.Bounded env19828 := by
  intro p hp
  have h : env19828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19827_19828 : H12AffineEnvironment.transform 6 89 env19827 = env19828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19827 == env19828) = true)

theorem identity19828 : scanCanonicalize (H12AffineFastState.compose env19828 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19828 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19829 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,40,5236,1,115,5172,2128,1024,0,4113,32,16,83,121,64,2048,5221,4177,2049,1056,33,117,33,5237,513]

theorem envBound19829 : H12AffineFastState.Bounded env19829 := by
  intro p hp
  have h : env19829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19828_19829 : H12AffineEnvironment.transform 7 117 env19828 = env19829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19828 == env19829) = true)

theorem identity19829 : scanCanonicalize (H12AffineFastState.compose env19829 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19829 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env19830 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,4096,40,5236,1,115,5172,81,1024,0,4113,32,16,83,121,64,1,5221,4177,0,1056,33,117,33,5237,513]

theorem envBound19830 : H12AffineFastState.Bounded env19830 := by
  intro p hp
  have h : env19830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19829_19830 : H12AffineEnvironment.transform 10 1 env19829 = env19830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19829 == env19830) = true)

theorem identity19830 : scanCanonicalize (H12AffineFastState.compose env19830 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound19830 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env19831 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,64,40,1076,1,115,1140,81,1024,0,81,32,16,83,121,64,1,1061,17,0,1056,33,117,33,1077,513]

theorem envBound19831 : H12AffineFastState.Bounded env19831 := by
  intro p hp
  have h : env19831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19830_19831 : H12AffineEnvironment.transform 11 64 env19830 = env19831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env19830 == env19831) = true)

theorem identity19831 : scanCanonicalize (H12AffineFastState.compose env19831 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19831 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env19832 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,40,81,1,115,17,81,101,0,81,32,16,83,121,64,1,64,17,0,69,33,117,33,80,513]

theorem envBound19832 : H12AffineFastState.Bounded env19832 := by
  intro p hp
  have h : env19832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19831_19832 : H12AffineEnvironment.transform 9 101 env19831 = env19832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19831 == env19832) = true)

theorem identity19832 : scanCanonicalize (H12AffineFastState.compose env19832 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound19832 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19833 : List Nat := [2,4,8,16,32,64,89,117,97,101,1,64,40,81,1,115,17,81,101,0,81,32,16,83,121,64,1,64,17,0,69,33,117,33,80,96]

theorem envBound19833 : H12AffineFastState.Bounded env19833 := by
  intro p hp
  have h : env19833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19832_19833 : H12AffineEnvironment.transform 8 97 env19832 = env19833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env19832 == env19833) = true)

theorem identity19833 : scanCanonicalize (H12AffineFastState.compose env19833 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19833 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env19834 : List Nat := [2,4,8,16,32,17,8,36,48,52,1,17,40,0,1,34,17,0,52,0,0,32,16,2,40,17,1,17,17,0,20,33,36,33,1,49]

theorem envBound19834 : H12AffineFastState.Bounded env19834 := by
  intro p hp
  have h : env19834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19833_19834 : H12AffineEnvironment.transform 5 17 env19833 = env19834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19833 == env19834) = true)

theorem identity19834 : scanCanonicalize (H12AffineFastState.compose env19834 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19835 : List Nat := [2,4,8,0,32,1,8,36,32,36,1,1,40,0,1,34,1,0,36,0,0,32,0,2,40,1,1,1,1,0,4,33,36,33,1,33]

theorem envBound19835 : H12AffineFastState.Bounded env19835 := by
  intro p hp
  have h : env19835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19834_19835 : H12AffineEnvironment.transform 3 0 env19834 = env19835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19834 == env19835) = true)

def env19836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound19836 : H12AffineFastState.Bounded env19836 := by
  intro p hp
  have h : env19836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19725_19836 : H12AffineEnvironment.transform 18 1025 env19725 = env19836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19725 == env19836) = true)

theorem identity19836 : scanCanonicalize (H12AffineFastState.compose env19836 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound19836 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630491,18973837,10507601,8724506,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound19837 : H12AffineFastState.Bounded env19837 := by
  intro p hp
  have h : env19837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19836_19837 : H12AffineEnvironment.transform 16 122907 env19836 = env19837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env19836 == env19837) = true)

def env19838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664599,8393985,10507601,8724506,2102685,12645452,257,21793,46213,2175562]

theorem envBound19838 : H12AffineFastState.Bounded env19838 := by
  intro p hp
  have h : env19838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19837_19838 : H12AffineEnvironment.transform 23 10588556 env19837 = env19838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env19837 == env19838) = true)

def env19839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664599,2098513,17665,2437194,2102685,6349852,257,21793,46213,2175562]

theorem envBound19839 : H12AffineFastState.Bounded env19839 := by
  intro p hp
  have h : env19839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19838_19839 : H12AffineEnvironment.transform 22 2101328 env19838 = env19839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19838 == env19839) = true)

def env19840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2201879,2098513,17665,2437194,2102685,2411676,257,21793,46213,2175562]

theorem envBound19840 : H12AffineFastState.Bounded env19840 := by
  intro p hp
  have h : env19840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19839_19840 : H12AffineEnvironment.transform 21 272512 env19839 = env19840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19839 == env19840) = true)

def env19841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272392,2101328,98644,8192,64,2201879,2098513,17665,2437194,2102549,2411540,257,21793,46093,2175562]

theorem envBound19841 : H12AffineFastState.Bounded env19841 := by
  intro p hp
  have h : env19841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19840_19841 : H12AffineEnvironment.transform 6 8 env19840 = env19841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19840 == env19841) = true)

theorem identity19841 : scanCanonicalize (H12AffineFastState.compose env19841 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound19841 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272392,73755,98644,8192,64,43356,79130,17665,262145,75102,392287,257,21793,46093,513]

theorem envBound19842 : H12AffineFastState.Bounded env19842 := by
  intro p hp
  have h : env19842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19841_19842 : H12AffineEnvironment.transform 20 77899 env19841 = env19842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env19841 == env19842) = true)

theorem identity19842 : scanCanonicalize (H12AffineFastState.compose env19842 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound19842 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77899,73771,73755,98644,8192,64,43356,79130,17665,67618,75102,62588,257,21793,46093,513]

theorem envBound19843 : H12AffineFastState.Bounded env19843 := by
  intro p hp
  have h : env19843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19842_19843 : H12AffineEnvironment.transform 17 67619 env19842 = env19843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env19842 == env19843) = true)

theorem identity19843 : scanCanonicalize (H12AffineFastState.compose env19843 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound19843 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env19844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,70678,67619,1025,29708,77899,73771,73755,95577,8192,64,23889,79130,17665,67618,75102,113,257,21793,16384,513]

theorem envBound19844 : H12AffineFastState.Bounded env19844 := by
  intro p hp
  have h : env19844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19843_19844 : H12AffineEnvironment.transform 14 29709 env19843 = env19844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env19843 == env19844) = true)

theorem identity19844 : scanCanonicalize (H12AffineFastState.compose env19844 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound19844 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env19845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,65536,70678,67619,1025,1,77899,73771,73755,65876,8192,64,10588,79130,12556,67618,75102,113,257,8492,13325,513]

theorem envBound19845 : H12AffineFastState.Bounded env19845 := by
  intro p hp
  have h : env19845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19844_19845 : H12AffineEnvironment.transform 13 13325 env19844 = env19845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env19844 == env19845) = true)

theorem identity19845 : scanCanonicalize (H12AffineFastState.compose env19845 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound19845 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env19846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,262,5392,2341,1025,1,12621,8493,8477,82,8192,64,10588,13340,12556,2340,9304,113,257,8492,13325,513]

theorem envBound19846 : H12AffineFastState.Bounded env19846 := by
  intro p hp
  have h : env19846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19845_19846 : H12AffineEnvironment.transform 15 262 env19845 = env19846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env19845 == env19846) = true)

theorem identity19846 : scanCanonicalize (H12AffineFastState.compose env19846 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19846 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19847 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,262,5392,2341,1025,1,12573,8493,8477,2,8192,16,10508,13340,12556,2340,9224,33,257,8492,13325,513]

theorem envBound19847 : H12AffineFastState.Bounded env19847 := by
  intro p hp
  have h : env19847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19846_19847 : H12AffineEnvironment.transform 5 16 env19846 = env19847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19846 == env19847) = true)

theorem identity19847 : scanCanonicalize (H12AffineFastState.compose env19847 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19847 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19848 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,12573,0,262,4096,2341,273,1,12573,8493,8477,2,8192,16,10508,12556,12556,2340,8472,33,257,8492,12573,513]

theorem envBound19848 : H12AffineFastState.Bounded env19848 := by
  intro p hp
  have h : env19848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19847_19848 : H12AffineEnvironment.transform 9 272 env19847 = env19848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19847 == env19848) = true)

theorem identity19848 : scanCanonicalize (H12AffineFastState.compose env19848 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19848 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19849 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4113,0,262,4096,2341,273,1,4113,33,17,2,268,16,2048,4096,4096,2340,20,33,257,32,4113,513]

theorem envBound19849 : H12AffineFastState.Bounded env19849 := by
  intro p hp
  have h : env19849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19848_19849 : H12AffineEnvironment.transform 12 268 env19848 = env19849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19848 == env19849) = true)

theorem identity19849 : scanCanonicalize (H12AffineFastState.compose env19849 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound19849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19850 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,277,268,260,0,262,277,2341,273,1,260,33,17,2,268,16,2048,277,277,2340,20,33,257,32,260,513]

theorem envBound19850 : H12AffineFastState.Bounded env19850 := by
  intro p hp
  have h : env19850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19849_19850 : H12AffineEnvironment.transform 11 277 env19849 = env19850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env19849 == env19850) = true)

theorem identity19850 : scanCanonicalize (H12AffineFastState.compose env19850 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19850 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19851 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,277,268,260,0,262,277,2308,273,1,260,0,17,2,268,16,2048,277,277,2309,20,0,257,1,260,513]

theorem envBound19851 : H12AffineFastState.Bounded env19851 := by
  intro p hp
  have h : env19851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19850_19851 : H12AffineEnvironment.transform 4 1 env19850 = env19851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19850 == env19851) = true)

theorem identity19851 : scanCanonicalize (H12AffineFastState.compose env19851 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound19851 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19852 : List Nat := [2,4,8,16,1,16,8,256,512,272,513,277,268,260,0,262,277,773,273,1,260,0,17,2,268,16,513,277,277,772,20,0,257,1,260,513]

theorem envBound19852 : H12AffineFastState.Bounded env19852 := by
  intro p hp
  have h : env19852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19851_19852 : H12AffineEnvironment.transform 10 513 env19851 = env19852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env19851 == env19852) = true)

theorem identity19852 : scanCanonicalize (H12AffineFastState.compose env19852 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19853 : List Nat := [2,4,8,0,1,0,8,256,512,256,513,261,268,260,0,262,261,773,257,1,260,0,1,2,268,0,513,261,261,772,4,0,257,1,260,513]

theorem envBound19853 : H12AffineFastState.Bounded env19853 := by
  intro p hp
  have h : env19853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19852_19853 : H12AffineEnvironment.transform 3 0 env19852 = env19853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19852 == env19853) = true)

theorem identity19853 : scanCanonicalize (H12AffineFastState.compose env19853 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19854 : List Nat := [2,4,8,0,1,0,8,5,512,5,513,0,9,1,0,3,0,512,4,1,1,0,1,2,9,0,513,0,0,513,4,0,4,1,1,513]

theorem envBound19854 : H12AffineFastState.Bounded env19854 := by
  intro p hp
  have h : env19854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19853_19854 : H12AffineEnvironment.transform 7 5 env19853 = env19854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19853 == env19854) = true)

theorem identity19854 : scanCanonicalize (H12AffineFastState.compose env19854 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19854 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19855 : List Nat := [2,4,8,0,1,0,8,5,0,5,1,0,9,1,0,3,0,0,4,1,1,0,1,2,9,0,1,0,0,1,4,0,4,1,1,1]

theorem envBound19855 : H12AffineFastState.Bounded env19855 := by
  intro p hp
  have h : env19855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19854_19855 : H12AffineEnvironment.transform 8 0 env19854 = env19855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19854 == env19855) = true)

def env19856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272393,2101328,98645,8193,64,2201879,2098513,17665,2437194,2102548,2411541,257,21793,46092,2175562]

theorem envBound19856 : H12AffineFastState.Bounded env19856 := by
  intro p hp
  have h : env19856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19840_19856 : H12AffineEnvironment.transform 6 9 env19840 = env19856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19840 == env19856) = true)

theorem identity19856 : scanCanonicalize (H12AffineFastState.compose env19856 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound19856 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,262144,1025,32769,2097152,272393,2101328,8542,8193,64,2111772,2098513,17665,2396225,2102548,2411541,257,21793,46092,2134593]

theorem envBound19857 : H12AffineFastState.Bounded env19857 := by
  intro p hp
  have h : env19857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19856_19857 : H12AffineEnvironment.transform 15 40971 env19856 = env19857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env19856 == env19857) = true)

theorem identity19857 : scanCanonicalize (H12AffineFastState.compose env19857 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound19857 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,35189,1025,32769,2097152,41340,2101328,8542,8193,64,2111772,2098513,17665,2103604,2102548,2114912,257,21793,46092,2134593]

theorem envBound19858 : H12AffineFastState.Bounded env19858 := by
  intro p hp
  have h : env19858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19857_19858 : H12AffineEnvironment.transform 17 35189 env19857 = env19858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env19857 == env19858) = true)

theorem identity19858 : scanCanonicalize (H12AffineFastState.compose env19858 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound19858 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,35189,1025,32769,4160,41340,16,8542,8193,64,10588,5393,17665,2420,1364,21792,257,21793,46092,33281]

theorem envBound19859 : H12AffineFastState.Bounded env19859 := by
  intro p hp
  have h : env19859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19858_19859 : H12AffineEnvironment.transform 20 4160 env19858 = env19859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19858 == env19859) = true)

theorem identity19859 : scanCanonicalize (H12AffineFastState.compose env19859 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19859 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33110,16400,35189,1025,32769,4160,32801,16,3,348,64,2049,5393,17665,2420,1364,21792,257,21793,38225,33281]

theorem envBound19860 : H12AffineFastState.Bounded env19860 := by
  intro p hp
  have h : env19860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19859_19860 : H12AffineEnvironment.transform 12 349 env19859 = env19860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19859 == env19860) = true)

theorem identity19860 : scanCanonicalize (H12AffineFastState.compose env19860 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound19860 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21540,21874,16400,23889,1025,21541,4160,21509,16,3,348,64,2049,5393,17665,2420,1364,21792,257,21793,16757,22053]

theorem envBound19861 : H12AffineFastState.Bounded env19861 := by
  intro p hp
  have h : env19861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19860_19861 : H12AffineEnvironment.transform 14 21540 env19860 = env19861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env19860 == env19861) = true)

theorem identity19861 : scanCanonicalize (H12AffineFastState.compose env19861 (packedSelected [1,2,3,4,5,8,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound19861 : packedSelected [1,2,3,4,5,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env19862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,2340,7424,7254,2356,5237,1025,7425,4160,7457,16,3,348,64,2049,5393,3109,2420,1364,7172,257,7173,2129,7937]

theorem envBound19862 : H12AffineFastState.Bounded env19862 := by
  intro p hp
  have h : env19862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19861_19862 : H12AffineEnvironment.transform 13 2340 env19861 = env19862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env19861 == env19862) = true)

theorem identity19862 : scanCanonicalize (H12AffineFastState.compose env19862 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19862 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19863 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,2340,7424,7175,2356,5156,1025,7425,4113,7457,16,3,269,17,2049,5393,3109,2341,1285,7172,257,7173,2048,7937]

theorem envBound19863 : H12AffineFastState.Bounded env19863 := by
  intro p hp
  have h : env19863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19862_19863 : H12AffineEnvironment.transform 5 17 env19862 = env19863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19862 == env19863) = true)

theorem identity19863 : scanCanonicalize (H12AffineFastState.compose env19863 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound19863 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env19864 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2340,293,34,2356,2049,1025,292,3124,260,16,3,269,17,2049,2356,3109,2341,1285,33,257,32,2048,804]

theorem envBound19864 : H12AffineFastState.Bounded env19864 := by
  intro p hp
  have h : env19864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19863_19864 : H12AffineEnvironment.transform 11 3109 env19863 = env19864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env19863 == env19864) = true)

theorem identity19864 : scanCanonicalize (H12AffineFastState.compose env19864 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19864 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env19865 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,41,2049,0,34,2065,2049,1025,1,3124,33,16,3,40,17,2049,2065,3109,2048,1056,33,36,32,2048,513]

theorem envBound19865 : H12AffineFastState.Bounded env19865 := by
  intro p hp
  have h : env19865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19864_19865 : H12AffineEnvironment.transform 7 37 env19864 = env19865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19864 == env19865) = true)

def env19866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2201878,2098513,17665,2437194,2102685,2411677,257,21793,46213,2175562]

theorem envBound19866 : H12AffineFastState.Bounded env19866 := by
  intro p hp
  have h : env19866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19839_19866 : H12AffineEnvironment.transform 21 272513 env19839 = env19866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19839 == env19866) = true)

theorem identity19866 : scanCanonicalize (H12AffineFastState.compose env19866 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound19866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,272513,17,98780,8328,64,100695,5392,17665,335883,1500,318684,257,21793,46213,74251]

theorem envBound19867 : H12AffineFastState.Bounded env19867 := by
  intro p hp
  have h : env19867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19866_19867 : H12AffineEnvironment.transform 20 4161 env19866 = env19867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19866 == env19867) = true)

theorem identity19867 : scanCanonicalize (H12AffineFastState.compose env19867 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19867 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272513,17,41430,8328,64,43357,5392,17665,262145,1500,318684,257,21793,46213,513]

theorem envBound19868 : H12AffineFastState.Bounded env19868 := by
  intro p hp
  have h : env19868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19867_19868 : H12AffineEnvironment.transform 15 8202 env19867 = env19868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19867 == env19868) = true)

theorem identity19868 : scanCanonicalize (H12AffineFastState.compose env19868 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound19868 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10400,1025,32769,4161,33,17,41430,8328,64,43357,5392,17665,10401,1500,62588,257,21793,46213,513]

theorem envBound19869 : H12AffineFastState.Bounded env19869 := by
  intro p hp
  have h : env19869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19868_19869 : H12AffineEnvironment.transform 17 10400 env19868 = env19869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19868 == env19869) = true)

theorem identity19869 : scanCanonicalize (H12AffineFastState.compose env19869 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19869 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env19870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16401,10400,1025,1,4161,33,17,8662,8328,64,10589,5392,17665,10401,1500,29820,257,21793,13445,513]

theorem envBound19870 : H12AffineFastState.Bounded env19870 := by
  intro p hp
  have h : env19870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19869_19870 : H12AffineEnvironment.transform 14 0 env19869 = env19870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19869 == env19870) = true)

theorem identity19870 : scanCanonicalize (H12AffineFastState.compose env19870 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound19870 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env19871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,0,8202,4097,10400,1025,1,4161,33,17,8662,8328,64,10589,5392,5393,10401,1500,9324,257,1329,13445,513]

theorem envBound19871 : H12AffineFastState.Bounded env19871 := by
  intro p hp
  have h : env19871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19870_19871 : H12AffineEnvironment.transform 13 4112 env19870 = env19871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env19870 == env19871) = true)

theorem identity19871 : scanCanonicalize (H12AffineFastState.compose env19871 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound19871 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,4112,0,1095,4097,3309,1025,1,4161,33,17,1435,1221,64,3344,5392,5393,3308,1500,33,257,1329,4296,513]

theorem envBound19872 : H12AffineFastState.Bounded env19872 := by
  intro p hp
  have h : env19872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19871_19872 : H12AffineEnvironment.transform 12 1101 env19871 = env19872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env19871 == env19872) = true)

theorem identity19872 : scanCanonicalize (H12AffineFastState.compose env19872 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound19872 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env19873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1076,4096,1101,4112,0,1095,4097,217,1025,1,4161,33,17,1435,1221,64,292,5392,5393,216,1500,33,257,1329,4296,513]

theorem envBound19873 : H12AffineFastState.Bounded env19873 := by
  intro p hp
  have h : env19873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19872_19873 : H12AffineEnvironment.transform 10 1076 env19872 = env19873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env19872 == env19873) = true)

theorem identity19873 : scanCanonicalize (H12AffineFastState.compose env19873 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound19873 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19874 : List Nat := [2,4,8,16,32,64,128,256,512,273,293,4096,348,4112,0,342,4097,217,272,1,4161,33,17,138,468,64,292,4097,4096,216,205,33,257,32,4296,513]

theorem envBound19874 : H12AffineFastState.Bounded env19874 := by
  intro p hp
  have h : env19874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19873_19874 : H12AffineEnvironment.transform 9 273 env19873 = env19874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19873 == env19874) = true)

theorem identity19874 : scanCanonicalize (H12AffineFastState.compose env19874 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound19874 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19875 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,4096,241,4112,0,251,4097,217,189,1,4161,33,17,138,121,64,137,4097,4096,216,205,33,172,32,4296,513]

theorem envBound19875 : H12AffineFastState.Bounded env19875 := by
  intro p hp
  have h : env19875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19874_19875 : H12AffineEnvironment.transform 7 173 env19874 = env19875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env19874 == env19875) = true)

theorem identity19875 : scanCanonicalize (H12AffineFastState.compose env19875 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound19875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19876 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,152,241,136,0,251,153,217,189,1,217,33,17,138,121,64,137,153,152,216,205,33,172,32,80,513]

theorem envBound19876 : H12AffineFastState.Bounded env19876 := by
  intro p hp
  have h : env19876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19875_19876 : H12AffineEnvironment.transform 11 152 env19875 = env19876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env19875 == env19876) = true)

theorem identity19876 : scanCanonicalize (H12AffineFastState.compose env19876 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19876 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19877 : List Nat := [2,4,8,16,32,16,128,173,512,188,136,152,161,136,0,171,153,137,189,1,137,33,17,138,41,16,137,153,152,136,157,33,172,32,0,513]

theorem envBound19877 : H12AffineFastState.Bounded env19877 := by
  intro p hp
  have h : env19877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19876_19877 : H12AffineEnvironment.transform 5 16 env19876 = env19877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19876 == env19877) = true)

theorem identity19877 : scanCanonicalize (H12AffineFastState.compose env19877 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19878 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,1,0,34,16,0,52,1,0,33,17,3,41,16,0,16,17,1,20,33,37,32,0,513]

theorem envBound19878 : H12AffineFastState.Bounded env19878 := by
  intro p hp
  have h : env19878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19877_19878 : H12AffineEnvironment.transform 6 9 env19877 = env19878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19877 == env19878) = true)

theorem identity19878 : scanCanonicalize (H12AffineFastState.compose env19878 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound19878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19879 : List Nat := [2,4,8,16,32,16,9,36,16,53,1,17,40,1,0,34,16,0,52,1,0,33,17,3,41,16,0,16,17,1,20,33,37,32,0,17]

theorem envBound19879 : H12AffineFastState.Bounded env19879 := by
  intro p hp
  have h : env19879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19878_19879 : H12AffineEnvironment.transform 8 16 env19878 = env19879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env19878 == env19879) = true)

theorem identity19879 : scanCanonicalize (H12AffineFastState.compose env19879 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound19879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19880 : List Nat := [2,4,8,16,26,16,9,30,16,15,1,17,18,1,0,24,16,0,14,1,0,27,17,3,19,16,0,16,17,1,20,27,31,26,0,17]

theorem envBound19880 : H12AffineFastState.Bounded env19880 := by
  intro p hp
  have h : env19880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19879_19880 : H12AffineEnvironment.transform 4 26 env19879 = env19880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env19879 == env19880) = true)

def env19881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664599,2098512,17664,2437195,2102685,6349853,257,21793,46213,2175562]

theorem envBound19881 : H12AffineFastState.Bounded env19881 := by
  intro p hp
  have h : env19881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19838_19881 : H12AffineEnvironment.transform 22 2101329 env19838 = env19881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19838 == env19881) = true)

def env19882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2201879,2098512,17664,2437195,2102685,2411677,257,21793,46213,2175562]

theorem envBound19882 : H12AffineFastState.Bounded env19882 := by
  intro p hp
  have h : env19882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19881_19882 : H12AffineEnvironment.transform 21 272512 env19881 = env19882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19881 == env19882) = true)

theorem identity19882 : scanCanonicalize (H12AffineFastState.compose env19882 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19882 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70862,262144,1025,29908,2097152,272512,2101329,95496,8328,64,2190786,2098512,17664,2437195,2102685,2373704,257,21793,16464,2175562]

theorem envBound19883 : H12AffineFastState.Bounded env19883 := by
  intro p hp
  have h : env19883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19882_19883 : H12AffineEnvironment.transform 14 29909 env19882 = env19883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19882 == env19883) = true)

def env19884 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,262144,1025,29828,2097152,272512,2101249,95496,8328,16,2190738,2098432,17664,2437147,2102685,2373656,257,21793,16384,2175514]

theorem envBound19884 : H12AffineFastState.Bounded env19884 := by
  intro p hp
  have h : env19884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19883_19884 : H12AffineEnvironment.transform 5 16 env19883 = env19884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19883 == env19884) = true)

theorem identity19884 : scanCanonicalize (H12AffineFastState.compose env19884 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound19884 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19885 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,76198,1025,29828,2097152,65830,2101249,95496,8328,16,2190738,2098432,17664,2103741,2102685,2167230,257,21793,16384,2175514]

theorem envBound19885 : H12AffineFastState.Bounded env19885 := by
  intro p hp
  have h : env19885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19884_19885 : H12AffineEnvironment.transform 17 76198 env19884 = env19885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env19884 == env19885) = true)

theorem identity19885 : scanCanonicalize (H12AffineFastState.compose env19885 (packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19885 : packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env19886 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21896,65536,70814,67755,1025,21897,2097152,65830,2101249,87045,389,16,2182303,2098432,17664,2103741,2102685,2167230,257,21793,16384,2167575]

theorem envBound19886 : H12AffineFastState.Bounded env19886 := by
  intro p hp
  have h : env19886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19885_19886 : H12AffineEnvironment.transform 12 269 env19885 = env19886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19885 == env19886) = true)

theorem identity19886 : scanCanonicalize (H12AffineFastState.compose env19886 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound19886 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env19887 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21896,399,5393,2340,1025,21897,2097152,169,2101249,21898,389,16,2116880,2098432,17664,2103741,2102685,2101297,257,21793,16384,2101912]

theorem envBound19887 : H12AffineFastState.Bounded env19887 := by
  intro p hp
  have h : env19887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19886_19887 : H12AffineEnvironment.transform 15 399 env19886 = env19887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env19886 == env19887) = true)

theorem identity19887 : scanCanonicalize (H12AffineFastState.compose env19887 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound19887 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19888 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21896,399,5393,2340,1025,21897,17816,169,21913,21898,389,16,2184,16536,17664,23589,20485,21929,257,21793,16384,22272]

theorem envBound19888 : H12AffineFastState.Bounded env19888 := by
  intro p hp
  have h : env19888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19887_19888 : H12AffineEnvironment.transform 20 17816 env19887 = env19888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env19887 == env19888) = true)

theorem identity19888 : scanCanonicalize (H12AffineFastState.compose env19888 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound19888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19889 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5513,1,399,5393,2340,1025,0,4113,169,16,3,389,16,2184,5393,4233,2476,1420,32,257,168,5513,649]

theorem envBound19889 : H12AffineFastState.Bounded env19889 := by
  intro p hp
  have h : env19889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19888_19889 : H12AffineEnvironment.transform 13 5513 env19888 = env19889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env19888 == env19889) = true)

theorem identity19889 : scanCanonicalize (H12AffineFastState.compose env19889 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound19889 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19890 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,269,5408,1,294,5393,2340,1025,0,4113,0,16,3,300,16,2081,5393,4128,2309,1317,32,257,1,5408,544]

theorem envBound19890 : H12AffineFastState.Bounded env19890 := by
  intro p hp
  have h : env19890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19889_19890 : H12AffineEnvironment.transform 6 41 env19889 = env19890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env19889 == env19890) = true)

def env19891 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70815,262144,1025,29829,2097152,272512,2101248,95496,8328,17,2190739,2098433,17664,2437146,2102685,2373657,257,21793,16385,2175515]

theorem envBound19891 : H12AffineFastState.Bounded env19891 := by
  intro p hp
  have h : env19891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19883_19891 : H12AffineEnvironment.transform 5 17 env19883 = env19891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19883 == env19891) = true)

theorem identity19891 : scanCanonicalize (H12AffineFastState.compose env19891 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound19891 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19892 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70815,2477,1025,29829,2097152,8493,2101248,95496,8328,17,2190739,2098433,17664,2177463,2102685,2109876,257,21793,16385,2175515]

theorem envBound19892 : H12AffineFastState.Bounded env19892 := by
  intro p hp
  have h : env19892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19891_19892 : H12AffineEnvironment.transform 17 2477 env19891 = env19892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env19891 == env19892) = true)

theorem identity19892 : scanCanonicalize (H12AffineFastState.compose env19892 (packedSelected [1,10,11,17,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound19892 : packedSelected [1,10,11,17,26,28,32] rootPS < 2^1333 := by decide +kernel

def env19893 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,30082,24861,2477,1025,29829,2097152,8493,2101248,138,8328,17,2103313,2098433,17664,2116661,2102685,2109876,257,21793,16385,2115481]

theorem envBound19893 : H12AffineFastState.Bounded env19893 := by
  intro p hp
  have h : env19893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19892_19893 : H12AffineEnvironment.transform 15 30082 env19892 = env19893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env19892 == env19893) = true)

theorem identity19893 : scanCanonicalize (H12AffineFastState.compose env19893 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19893 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env19894 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8460,8202,13461,2477,1025,8461,2097152,8493,2101248,138,8328,17,2103313,2098433,4232,2103741,2102685,2109876,257,169,5513,2101777]

theorem envBound19894 : H12AffineFastState.Bounded env19894 := by
  intro p hp
  have h : env19894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19893_19894 : H12AffineEnvironment.transform 13 5512 env19893 = env19894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19893 == env19894) = true)

theorem identity19894 : scanCanonicalize (H12AffineFastState.compose env19894 (packedSelected [1,2,3,4,5,6,7,8,10,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound19894 : packedSelected [1,2,3,4,5,6,7,8,10,15,16,18] rootPS < 2^1333 := by decide +kernel

def env19895 : List Nat := [2,4,8,16,32,17,128,256,512,1024,665,4096,8192,5512,8460,8202,13461,820,1025,8461,2097152,8493,2101248,138,8328,17,2101896,2098433,4232,2102052,2102685,2109876,257,169,5513,2101777]

theorem envBound19895 : H12AffineFastState.Bounded env19895 := by
  intro p hp
  have h : env19895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19894_19895 : H12AffineEnvironment.transform 10 665 env19894 = env19895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env19894 == env19895) = true)

theorem identity19895 : scanCanonicalize (H12AffineFastState.compose env19895 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 4144) := by decide +kernel

theorem selectedBound19895 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env19896 : List Nat := [2,4,8,16,32,17,128,256,512,1024,665,4096,8192,5512,8460,8202,13461,820,1025,8461,4144,8493,48,138,8328,17,696,5425,4232,788,1453,8580,257,169,5513,545]

theorem envBound19896 : H12AffineFastState.Bounded env19896 := by
  intro p hp
  have h : env19896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19895_19896 : H12AffineEnvironment.transform 20 4144 env19895 = env19896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4144 env19895 == env19896) = true)

theorem identity19896 : scanCanonicalize (H12AffineFastState.compose env19896 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19896 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19897 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,4096,8192,5377,8460,8202,13340,820,1025,8461,4144,8493,48,3,8193,17,561,5425,4097,788,1316,8461,257,32,5376,545]

theorem envBound19897 : H12AffineFastState.Bounded env19897 := by
  intro p hp
  have h : env19897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19896_19897 : H12AffineEnvironment.transform 6 9 env19896 = env19897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19896 == env19897) = true)

theorem identity19897 : scanCanonicalize (H12AffineFastState.compose env19897 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound19897 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19898 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,805,8192,1572,8460,8202,10041,820,1025,8461,789,8493,48,3,8193,17,561,1556,804,788,1316,8461,257,32,1573,545]

theorem envBound19898 : H12AffineFastState.Bounded env19898 := by
  intro p hp
  have h : env19898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19897_19898 : H12AffineEnvironment.transform 11 805 env19897 = env19898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env19897 == env19898) = true)

theorem identity19898 : scanCanonicalize (H12AffineFastState.compose env19898 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound19898 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env19899 : List Nat := [2,4,8,16,32,17,9,256,512,305,528,805,8192,789,8460,8202,8712,820,304,8461,789,8493,48,3,8193,17,561,805,804,788,21,8461,257,32,788,545]

theorem envBound19899 : H12AffineFastState.Bounded env19899 := by
  intro p hp
  have h : env19899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19898_19899 : H12AffineEnvironment.transform 9 305 env19898 = env19899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env19898 == env19899) = true)

theorem identity19899 : scanCanonicalize (H12AffineFastState.compose env19899 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19899 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19900 : List Nat := [2,4,8,16,1,17,9,256,512,272,528,772,8192,789,8460,8202,8712,789,273,8461,789,8460,17,3,8193,17,528,772,773,788,21,8461,257,1,788,512]

theorem envBound19900 : H12AffineFastState.Bounded env19900 := by
  intro p hp
  have h : env19900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19899_19900 : H12AffineEnvironment.transform 4 1 env19899 = env19900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19899 == env19900) = true)

theorem identity19900 : scanCanonicalize (H12AffineFastState.compose env19900 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19900 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19901 : List Nat := [2,4,8,16,1,17,9,256,512,272,528,772,268,789,0,262,772,789,273,1,789,0,17,3,269,17,528,772,773,788,21,1,257,1,788,512]

theorem envBound19901 : H12AffineFastState.Bounded env19901 := by
  intro p hp
  have h : env19901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19900_19901 : H12AffineEnvironment.transform 12 268 env19900 = env19901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19900 == env19901) = true)

theorem identity19901 : scanCanonicalize (H12AffineFastState.compose env19901 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 268) := by decide +kernel

theorem selectedBound19901 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19902 : List Nat := [2,4,8,16,1,17,9,256,268,272,284,8,268,25,0,262,8,25,273,1,25,0,17,3,269,17,284,8,9,24,21,1,257,1,24,268]

theorem envBound19902 : H12AffineFastState.Bounded env19902 := by
  intro p hp
  have h : env19902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19901_19902 : H12AffineEnvironment.transform 8 268 env19901 = env19902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 268 env19901 == env19902) = true)

theorem identity19902 : scanCanonicalize (H12AffineFastState.compose env19902 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19902 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19903 : List Nat := [2,4,8,1,1,0,9,256,268,257,269,8,268,8,0,262,8,8,256,1,8,0,0,3,269,0,269,8,9,9,4,1,257,1,9,268]

theorem envBound19903 : H12AffineFastState.Bounded env19903 := by
  intro p hp
  have h : env19903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19902_19903 : H12AffineEnvironment.transform 3 1 env19902 = env19903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19902 == env19903) = true)

theorem identity19903 : scanCanonicalize (H12AffineFastState.compose env19903 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound19903 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19904 : List Nat := [2,4,8,1,1,0,9,1,13,0,12,8,13,8,0,7,8,8,1,1,8,0,0,3,12,0,12,8,9,9,4,1,0,1,9,13]

theorem envBound19904 : H12AffineFastState.Bounded env19904 := by
  intro p hp
  have h : env19904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19903_19904 : H12AffineEnvironment.transform 7 1 env19903 = env19904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env19903 == env19904) = true)

theorem identity19904 : scanCanonicalize (H12AffineFastState.compose env19904 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19904 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19905 : List Nat := [2,4,3,1,1,0,2,1,6,0,7,3,6,3,0,7,3,3,1,1,3,0,0,3,7,0,7,3,2,2,4,1,0,1,2,6]

theorem envBound19905 : H12AffineFastState.Bounded env19905 := by
  intro p hp
  have h : env19905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19904_19905 : H12AffineEnvironment.transform 2 3 env19904 = env19905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19904 == env19905) = true)

theorem identity19905 : scanCanonicalize (H12AffineFastState.compose env19905 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound19905 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19906 : List Nat := [2,3,3,1,1,0,2,1,1,0,0,3,1,3,0,0,3,3,1,1,3,0,0,3,0,0,0,3,2,2,3,1,0,1,2,1]

theorem envBound19906 : H12AffineFastState.Bounded env19906 := by
  intro p hp
  have h : env19906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19905_19906 : H12AffineEnvironment.transform 1 3 env19905 = env19906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env19905 == env19906) = true)

theorem identity19906 : scanCanonicalize (H12AffineFastState.compose env19906 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound19906 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19907 : List Nat := [1,0,0,1,1,0,1,1,1,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,1,0,1,1,1]

theorem envBound19907 : H12AffineFastState.Bounded env19907 := by
  intro p hp
  have h : env19907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19906_19907 : H12AffineEnvironment.transform 0 1 env19906 = env19907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env19906 == env19907) = true)

def env19908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2201878,2098512,17664,2437195,2102685,2411676,257,21793,46213,2175562]

theorem envBound19908 : H12AffineFastState.Bounded env19908 := by
  intro p hp
  have h : env19908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19881_19908 : H12AffineEnvironment.transform 21 272513 env19881 = env19908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19881 == env19908) = true)

theorem identity19908 : scanCanonicalize (H12AffineFastState.compose env19908 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound19908 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,58517,272513,62660,98781,8328,64,97667,57797,17664,382174,61704,272393,257,21793,46213,120543]

theorem envBound19909 : H12AffineFastState.Bounded env19909 := by
  intro p hp
  have h : env19909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19908_19909 : H12AffineEnvironment.transform 20 58517 env19908 = env19909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env19908 == env19909) = true)

def env19910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,58517,169,62660,98781,8328,64,97667,57797,17664,130294,61704,33,257,21793,46213,120543]

theorem envBound19910 : H12AffineFastState.Bounded env19910 := by
  intro p hp
  have h : env19910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19909_19910 : H12AffineEnvironment.transform 17 10280 env19909 = env19910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env19909 == env19910) = true)

theorem identity19910 : scanCanonicalize (H12AffineFastState.compose env19910 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound19910 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env19911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1095,58460,10280,1025,32769,58517,169,62660,34202,8328,64,31172,57797,17664,63665,61704,33,257,21793,46213,53912]

theorem envBound19911 : H12AffineFastState.Bounded env19911 := by
  intro p hp
  have h : env19911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19910_19911 : H12AffineEnvironment.transform 15 1095 env19910 = env19911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env19910 == env19911) = true)

theorem identity19911 : scanCanonicalize (H12AffineFastState.compose env19911 (packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound19911 : packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS < 2^1333 := by decide +kernel

def env19912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12573,32768,1095,38209,10280,1025,32769,38280,169,34265,34202,8328,64,2265,37080,13341,35244,32789,33,257,9276,46213,41861]

theorem envBound19912 : H12AffineFastState.Bounded env19912 := by
  intro p hp
  have h : env19912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19911_19912 : H12AffineEnvironment.transform 13 12573 env19911 = env19912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env19911 == env19912) = true)

theorem identity19912 : scanCanonicalize (H12AffineFastState.compose env19912 (packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound19912 : packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env19913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,4452,32768,1095,38209,2129,1025,32769,38280,169,34265,34202,241,64,2265,37080,5220,35244,32789,33,257,1093,38140,33788]

theorem envBound19913 : H12AffineFastState.Bounded env19913 := by
  intro p hp
  have h : env19913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19912_19913 : H12AffineEnvironment.transform 12 121 env19912 = env19913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env19912 == env19913) = true)

theorem identity19913 : scanCanonicalize (H12AffineFastState.compose env19913 (packedSelected [3,4,5,9,10,11,12,14,15,17,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound19913 : packedSelected [3,4,5,9,10,11,12,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env19914 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,121,4452,32768,398,37000,2129,456,32769,36929,169,32784,32851,241,64,2265,37080,4525,35244,32789,33,257,396,37173,33788]

theorem envBound19914 : H12AffineFastState.Bounded env19914 := by
  intro p hp
  have h : env19914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19913_19914 : H12AffineEnvironment.transform 9 457 env19913 = env19914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env19913 == env19914) = true)

theorem identity19914 : scanCanonicalize (H12AffineFastState.compose env19914 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound19914 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19915 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,121,4452,509,398,4469,2129,456,508,4540,169,493,430,241,64,2265,4389,4525,2129,488,33,257,396,4296,513]

theorem envBound19915 : H12AffineFastState.Bounded env19915 := by
  intro p hp
  have h : env19915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19914_19915 : H12AffineEnvironment.transform 14 509 env19914 = env19915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env19914 == env19915) = true)

theorem identity19915 : scanCanonicalize (H12AffineFastState.compose env19915 (packedSelected [0,6,7,10,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19915 : packedSelected [0,6,7,10,12,14] rootPS < 2^1333 := by decide +kernel

def env19916 : List Nat := [2,4,8,16,32,64,25,256,512,336,2048,4096,121,4452,356,279,4469,2129,337,357,4389,48,372,311,104,64,2112,4389,4404,2129,369,33,257,277,4177,513]

theorem envBound19916 : H12AffineFastState.Bounded env19916 := by
  intro p hp
  have h : env19916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19915_19916 : H12AffineEnvironment.transform 6 25 env19915 = env19916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19915 == env19916) = true)

theorem identity19916 : scanCanonicalize (H12AffineFastState.compose env19916 (packedSelected [0,6,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19916 : packedSelected [0,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env19917 : List Nat := [2,4,8,16,32,64,25,37,512,117,2048,4096,121,4161,65,50,4176,2129,116,64,4096,48,81,18,104,64,2112,4096,4113,2129,84,33,36,48,4177,513]

theorem envBound19917 : H12AffineFastState.Bounded env19917 := by
  intro p hp
  have h : env19917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19916_19917 : H12AffineEnvironment.transform 7 37 env19916 = env19917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19916 == env19917) = true)

theorem identity19917 : scanCanonicalize (H12AffineFastState.compose env19917 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound19917 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19918 : List Nat := [2,4,8,16,32,0,25,37,512,53,2048,4096,57,4097,1,50,4112,2065,52,0,4096,48,17,18,40,0,2048,4096,4113,2065,20,33,36,48,4113,513]

theorem envBound19918 : H12AffineFastState.Bounded env19918 := by
  intro p hp
  have h : env19918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19917_19918 : H12AffineEnvironment.transform 5 0 env19917 = env19918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env19917 == env19918) = true)

theorem identity19918 : scanCanonicalize (H12AffineFastState.compose env19918 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19918 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19919 : List Nat := [2,4,8,16,17,0,25,20,512,4,2048,4096,8,4097,1,3,4112,2065,5,0,4096,1,17,18,25,0,2048,4096,4113,2065,20,16,21,1,4113,513]

theorem envBound19919 : H12AffineFastState.Bounded env19919 := by
  intro p hp
  have h : env19919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19918_19919 : H12AffineEnvironment.transform 4 17 env19918 = env19919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19918 == env19919) = true)

theorem identity19919 : scanCanonicalize (H12AffineFastState.compose env19919 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound19919 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19920 : List Nat := [2,4,8,16,17,0,25,20,512,4,539,4096,8,4097,1,3,4112,522,5,0,4096,1,17,18,25,0,539,4096,4113,522,20,16,21,1,4113,513]

theorem envBound19920 : H12AffineFastState.Bounded env19920 := by
  intro p hp
  have h : env19920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19919_19920 : H12AffineEnvironment.transform 10 539 env19919 = env19920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env19919 == env19920) = true)

theorem identity19920 : scanCanonicalize (H12AffineFastState.compose env19920 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound19920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19921 : List Nat := [2,4,8,16,17,0,25,20,3,4,24,4096,8,4097,1,3,4112,9,5,0,4096,1,17,18,25,0,24,4096,4113,9,20,16,21,1,4113,2]

theorem envBound19921 : H12AffineFastState.Bounded env19921 := by
  intro p hp
  have h : env19921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19920_19921 : H12AffineEnvironment.transform 8 3 env19920 = env19921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env19920 == env19921) = true)

theorem identity19921 : scanCanonicalize (H12AffineFastState.compose env19921 (packedSelected [0,5] rootPS)) = affineNative (2^(11+1) ^^^ 29) := by decide +kernel

theorem selectedBound19921 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env19922 : List Nat := [2,4,8,16,17,0,25,20,3,4,24,29,8,28,1,3,13,9,5,0,29,1,17,18,25,0,24,29,12,9,20,16,21,1,12,2]

theorem envBound19922 : H12AffineFastState.Bounded env19922 := by
  intro p hp
  have h : env19922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19921_19922 : H12AffineEnvironment.transform 11 29 env19921 = env19922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 29 env19921 == env19922) = true)

def env19923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,58517,168,62660,98781,8328,64,97667,57797,17664,130295,61704,32,257,21793,46213,120543]

theorem envBound19923 : H12AffineFastState.Bounded env19923 := by
  intro p hp
  have h : env19923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19909_19923 : H12AffineEnvironment.transform 17 10281 env19909 = env19923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19909 == env19923) = true)

theorem identity19923 : scanCanonicalize (H12AffineFastState.compose env19923 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound19923 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env19924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,65536,79251,10281,1025,21897,12573,168,8524,87125,8328,64,97667,13389,17664,76159,9344,32,257,21793,24845,66391]

theorem envBound19924 : H12AffineFastState.Bounded env19924 := by
  intro p hp
  have h : env19924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19923_19924 : H12AffineEnvironment.transform 14 21896 env19923 = env19924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env19923 == env19924) = true)

theorem identity19924 : scanCanonicalize (H12AffineFastState.compose env19924 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19924 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env19925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,79131,10281,1025,21761,12573,32,8524,87125,8192,64,97547,13389,17664,76159,9224,32,257,21793,24845,66391]

theorem envBound19925 : H12AffineFastState.Bounded env19925 := by
  intro p hp
  have h : env19925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19924_19925 : H12AffineEnvironment.transform 6 8 env19924 = env19925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19924 == env19925) = true)

theorem identity19925 : scanCanonicalize (H12AffineFastState.compose env19925 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound19925 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,342,13389,10281,1025,21761,12573,32,8524,21763,8192,64,31837,13389,17664,10281,9224,32,257,21793,24845,513]

theorem envBound19926 : H12AffineFastState.Bounded env19926 := by
  intro p hp
  have h : env19926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19925_19926 : H12AffineEnvironment.transform 15 342 env19925 = env19926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env19925 == env19926) = true)

theorem identity19926 : scanCanonicalize (H12AffineFastState.compose env19926 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19926 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env19927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21760,342,5441,2341,1025,21761,4113,32,64,21763,268,64,23889,5441,17664,2341,1284,32,257,21793,16385,513]

theorem envBound19927 : H12AffineFastState.Bounded env19927 := by
  intro p hp
  have h : env19927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19926_19927 : H12AffineEnvironment.transform 12 268 env19926 = env19927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19926 == env19927) = true)

theorem identity19927 : scanCanonicalize (H12AffineFastState.compose env19927 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19927 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,0,342,5441,2341,1025,1,4113,32,64,3,268,64,2129,5441,4096,2341,1284,32,257,33,5377,513]

theorem envBound19928 : H12AffineFastState.Bounded env19928 := by
  intro p hp
  have h : env19928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19927_19928 : H12AffineEnvironment.transform 13 5376 env19927 = env19928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19927 == env19928) = true)

theorem identity19928 : scanCanonicalize (H12AffineFastState.compose env19928 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19928 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19929 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1025,1,4113,32,17,3,268,17,2048,5392,4096,2341,1284,32,257,33,5377,513]

theorem envBound19929 : H12AffineFastState.Bounded env19929 := by
  intro p hp
  have h : env19929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19928_19929 : H12AffineEnvironment.transform 5 17 env19928 = env19929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19928 == env19929) = true)

theorem identity19929 : scanCanonicalize (H12AffineFastState.compose env19929 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound19929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19930 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,260,268,1028,0,263,1044,2341,1025,1,277,32,17,3,268,17,2048,1044,260,2341,1284,32,257,33,1029,513]

theorem envBound19930 : H12AffineFastState.Bounded env19930 := by
  intro p hp
  have h : env19930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19929_19930 : H12AffineEnvironment.transform 11 260 env19929 = env19930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env19929 == env19930) = true)

theorem identity19930 : scanCanonicalize (H12AffineFastState.compose env19930 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

end H12CloudChart0