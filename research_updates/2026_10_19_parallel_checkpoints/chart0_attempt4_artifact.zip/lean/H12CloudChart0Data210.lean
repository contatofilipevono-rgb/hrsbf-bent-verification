import H12CloudChart0Data209

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans53165_53166 : H12AffineEnvironment.transform 9 542 env53165 = env53166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env53165 == env53166) = true)

theorem identity53166 : scanCanonicalize (H12AffineFastState.compose env53166 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound53166 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53167 : List Nat := [2,4,8,16,32,17,8,256,270,272,261,309,269,292,0,263,308,33,272,1,293,32,17,3,269,16,261,308,308,32,21,32,256,33,293,271]

theorem envBound53167 : H12AffineFastState.Bounded env53167 := by
  intro p hp
  have h : env53167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53166_53167 : H12AffineEnvironment.transform 8 270 env53166 = env53167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env53166 == env53167) = true)

theorem identity53167 : scanCanonicalize (H12AffineFastState.compose env53167 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53167 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53168 : List Nat := [2,4,8,16,1,17,8,256,270,272,261,276,269,261,0,263,277,0,272,1,260,1,17,3,269,16,261,277,277,1,21,1,256,0,260,271]

theorem envBound53168 : H12AffineFastState.Bounded env53168 := by
  intro p hp
  have h : env53168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53167_53168 : H12AffineEnvironment.transform 4 1 env53167 = env53168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53167 == env53168) = true)

theorem identity53168 : scanCanonicalize (H12AffineFastState.compose env53168 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53168 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53169 : List Nat := [2,4,8,16,1,17,8,4,10,20,1,16,9,1,0,3,17,0,20,1,0,1,17,3,9,16,1,17,17,1,21,1,4,0,0,11]

theorem envBound53169 : H12AffineFastState.Bounded env53169 := by
  intro p hp
  have h : env53169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53168_53169 : H12AffineEnvironment.transform 7 4 env53168 = env53169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53168 == env53169) = true)

theorem identity53169 : scanCanonicalize (H12AffineFastState.compose env53169 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound53169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53170 : List Nat := [2,4,6,16,1,17,6,4,4,20,1,16,7,1,0,3,17,0,20,1,0,1,17,3,7,16,1,17,17,1,21,1,4,0,0,5]

theorem envBound53170 : H12AffineFastState.Bounded env53170 := by
  intro p hp
  have h : env53170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53169_53170 : H12AffineEnvironment.transform 2 6 env53169 = env53170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env53169 == env53170) = true)

theorem identity53170 : scanCanonicalize (H12AffineFastState.compose env53170 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound53170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53171 : List Nat := [2,4,6,3,1,2,6,4,4,7,1,3,7,1,0,3,2,0,7,1,0,1,2,3,7,3,1,2,2,1,6,1,4,0,0,5]

theorem envBound53171 : H12AffineFastState.Bounded env53171 := by
  intro p hp
  have h : env53171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53170_53171 : H12AffineEnvironment.transform 3 3 env53170 = env53171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env53170 == env53171) = true)

def env53172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21792,41292,73856,8328,65,64725,46156,58461,35188,1500,32,256,21792,46213,74251]

theorem envBound53172 : H12AffineFastState.Bounded env53172 := by
  intro p hp
  have h : env53172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53156_53172 : H12AffineEnvironment.transform 16 49169 env53156 = env53172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env53156 == env53172) = true)

theorem identity53172 : scanCanonicalize (H12AffineFastState.compose env53172 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound53172 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env53173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1024,32769,4161,21792,41292,2,8328,65,64725,46156,58461,35188,1500,32,256,21792,46213,649]

theorem envBound53173 : H12AffineFastState.Bounded env53173 := by
  intro p hp
  have h : env53173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53172_53173 : H12AffineEnvironment.transform 15 8322 env53172 = env53173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env53172 == env53173) = true)

theorem identity53173 : scanCanonicalize (H12AffineFastState.compose env53173 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound53173 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env53174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8322,46156,10281,1024,32769,4161,8573,41292,2,8328,65,34952,46156,36864,35188,1500,32,256,8573,46213,649]

theorem envBound53174 : H12AffineFastState.Bounded env53174 := by
  intro p hp
  have h : env53174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53173_53174 : H12AffineEnvironment.transform 13 13405 env53173 = env53174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env53173 == env53174) = true)

theorem identity53174 : scanCanonicalize (H12AffineFastState.compose env53174 (packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53174 : packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env53175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,32768,398,38208,2341,1024,32769,4161,113,32832,2,388,65,34952,38208,36864,35188,1500,32,256,113,38281,649]

theorem envBound53175 : H12AffineFastState.Bounded env53175 := by
  intro p hp
  have h : env53175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53174_53175 : H12AffineEnvironment.transform 12 268 env53174 = env53175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53174 == env53175) = true)

theorem identity53175 : scanCanonicalize (H12AffineFastState.compose env53175 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound53175 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53176 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,32768,343,38208,2341,1024,32769,4161,113,32832,2,349,65,34897,38208,36864,35188,1285,32,256,113,38224,592]

theorem envBound53176 : H12AffineFastState.Bounded env53176 := by
  intro p hp
  have h : env53176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53175_53176 : H12AffineEnvironment.transform 6 89 env53175 = env53176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env53175 == env53176) = true)

theorem identity53176 : scanCanonicalize (H12AffineFastState.compose env53176 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound53176 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53177 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,80,343,5392,2341,1024,81,4161,113,16,2,349,65,2049,5392,4176,2340,1285,32,256,113,5376,592]

theorem envBound53177 : H12AffineFastState.Bounded env53177 := by
  intro p hp
  have h : env53177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53176_53177 : H12AffineEnvironment.transform 14 80 env53176 = env53177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env53176 == env53177) = true)

theorem identity53177 : scanCanonicalize (H12AffineFastState.compose env53177 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound53177 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53178 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,0,268,1361,80,343,1296,2341,1024,81,65,113,16,2,349,65,2049,1296,80,2340,1285,32,256,113,1280,592]

theorem envBound53178 : H12AffineFastState.Bounded env53178 := by
  intro p hp
  have h : env53178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53177_53178 : H12AffineEnvironment.transform 11 0 env53177 = env53178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53177 == env53178) = true)

def env53179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound53179 : H12AffineFastState.Bounded env53179 := by
  intro p hp
  have h : env53179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52958_53179 : H12AffineEnvironment.transform 18 1025 env52958 = env53179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env52958 == env53179) = true)

theorem identity53179 : scanCanonicalize (H12AffineFastState.compose env53179 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272440) := by decide +kernel

theorem selectedBound53179 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8328,65,21227576,18973836,2391400,190521,17148968,23160257,257,19262612,19205424,17075198]

theorem envBound53180 : H12AffineFastState.Bounded env53180 := by
  intro p hp
  have h : env53180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53179_53180 : H12AffineEnvironment.transform 22 272440 env53179 = env53180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272440 env53179 == env53180) = true)

def env53181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227576,18973700,2391400,190521,17148968,23160137,257,19262492,19205424,17075062]

theorem envBound53181 : H12AffineFastState.Bounded env53181 := by
  intro p hp
  have h : env53181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53180_53181 : H12AffineEnvironment.transform 6 8 env53180 = env53181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53180 == env53181) = true)

theorem identity53181 : scanCanonicalize (H12AffineFastState.compose env53181 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53181 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env53182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1025,8541,2097152,4194304,272440,16777216,8192,65,21186916,18949464,2391400,149861,17108340,23160137,257,19221824,19205424,17050154]

theorem envBound53182 : H12AffineFastState.Bounded env53182 := by
  intro p hp
  have h : env53182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53181_53182 : H12AffineEnvironment.transform 14 8540 env53181 = env53182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53181 == env53182) = true)

def env53183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157752,1025,8541,2097152,4194304,147456,16777216,8192,65,21186916,18949464,2233680,149861,16999756,23160137,257,19080568,19096840,16925202]

theorem envBound53183 : H12AffineFastState.Bounded env53183 := by
  intro p hp
  have h : env53183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53183 : H12AffineEnvironment.transform 17 157752 env53182 = env53183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env53182 == env53183) = true)

theorem identity53183 : scanCanonicalize (H12AffineFastState.compose env53183 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound53183 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157752,1025,8541,2097152,4194304,147456,147475,8192,65,4262263,2319691,2233680,149861,75103,6497626,257,2188651,2172187,513]

theorem envBound53184 : H12AffineFastState.Bounded env53184 := by
  intro p hp
  have h : env53184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53183_53184 : H12AffineEnvironment.transform 23 147475 env53183 = env53184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env53183 == env53184) = true)

theorem identity53184 : scanCanonicalize (H12AffineFastState.compose env53184 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53184 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,67619,1025,8541,2097152,4194304,73755,73736,8192,65,4262263,2098512,2192715,76158,75103,6309185,257,2188651,2172187,513]

theorem envBound53185 : H12AffineFastState.Bounded env53185 := by
  intro p hp
  have h : env53185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53184_53185 : H12AffineEnvironment.transform 16 90139 env53184 = env53185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53184 == env53185) = true)

theorem identity53185 : scanCanonicalize (H12AffineFastState.compose env53185 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound53185 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env53186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,67619,1025,8541,25677,4194304,73755,73736,8192,65,4262263,24861,69894,76158,75103,4202764,257,65830,82262,513]

theorem envBound53186 : H12AffineFastState.Bounded env53186 := by
  intro p hp
  have h : env53186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53185_53186 : H12AffineEnvironment.transform 20 25677 env53185 = env53186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env53185 == env53186) = true)

theorem identity53186 : scanCanonicalize (H12AffineFastState.compose env53186 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound53186 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env53187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,67619,1025,8541,25677,32,73755,73736,8192,65,67927,24861,69894,76158,75103,8492,257,65830,82262,513]

theorem envBound53187 : H12AffineFastState.Bounded env53187 := by
  intro p hp
  have h : env53187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53186_53187 : H12AffineEnvironment.transform 21 32 env53186 = env53187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53186 == env53187) = true)

theorem identity53187 : scanCanonicalize (H12AffineFastState.compose env53187 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound53187 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env53188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8540,65536,78910,67619,1025,8541,12392,32,73755,73736,8192,65,67927,13624,69894,76158,75103,8492,257,65830,71027,513]

theorem envBound53188 : H12AffineFastState.Bounded env53188 := by
  intro p hp
  have h : env53188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53187_53188 : H12AffineEnvironment.transform 13 5157 env53187 = env53188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env53187 == env53188) = true)

theorem identity53188 : scanCanonicalize (H12AffineFastState.compose env53188 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound53188 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env53189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,8192,3345,8540,65536,77066,67619,1025,8541,10588,32,73755,73736,8192,65,67927,11276,67634,76158,75103,8492,257,65830,68679,513]

theorem envBound53189 : H12AffineFastState.Bounded env53189 := by
  intro p hp
  have h : env53189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53188_53189 : H12AffineEnvironment.transform 11 2356 env53188 = env53189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env53188 == env53189) = true)

theorem identity53189 : scanCanonicalize (H12AffineFastState.compose env53189 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound53189 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,8192,3345,8540,1094,10572,3173,1025,8541,10588,32,9309,9294,8192,65,3345,11276,3188,11576,8473,8492,257,1376,2049,513]

theorem envBound53190 : H12AffineFastState.Bounded env53190 := by
  intro p hp
  have h : env53190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53189_53190 : H12AffineEnvironment.transform 15 1094 env53189 = env53190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env53189 == env53190) = true)

theorem identity53190 : scanCanonicalize (H12AffineFastState.compose env53190 (packedSelected [0,1,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

theorem selectedBound53190 : packedSelected [0,1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env53191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,3149,3345,3345,1094,1281,3173,1025,3344,1297,32,2064,2051,3149,65,3345,65,3188,373,3412,3425,257,1376,2049,513]

theorem envBound53191 : H12AffineFastState.Bounded env53191 := by
  intro p hp
  have h : env53191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53190_53191 : H12AffineEnvironment.transform 12 3149 env53190 = env53191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env53190 == env53191) = true)

theorem identity53191 : scanCanonicalize (H12AffineFastState.compose env53191 (packedSelected [0,2,3,4,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53191 : packedSelected [0,2,3,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env53192 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2064,3149,3125,3125,1094,1061,3173,1025,3124,1077,32,2064,2051,3149,65,3125,65,3188,81,3184,3141,37,1092,2049,513]

theorem envBound53192 : H12AffineFastState.Bounded env53192 := by
  intro p hp
  have h : env53192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53191_53192 : H12AffineEnvironment.transform 7 36 env53191 = env53192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53191 == env53192) = true)

theorem identity53192 : scanCanonicalize (H12AffineFastState.compose env53192 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound53192 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53193 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,1061,120,0,0,1094,1061,80,1025,1,1077,32,1061,1078,120,65,0,65,65,81,69,112,37,1092,1076,513]

theorem envBound53193 : H12AffineFastState.Bounded env53193 := by
  intro p hp
  have h : env53193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53192_53193 : H12AffineEnvironment.transform 10 1077 env53192 = env53193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env53192 == env53193) = true)

theorem identity53193 : scanCanonicalize (H12AffineFastState.compose env53193 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53194 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,1061,41,0,0,1047,1061,1,1025,1,1077,32,1061,1078,41,16,0,16,16,0,20,33,37,1045,1076,513]

theorem envBound53194 : H12AffineFastState.Bounded env53194 := by
  intro p hp
  have h : env53194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53193_53194 : H12AffineEnvironment.transform 5 17 env53193 = env53194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53193 == env53194) = true)

theorem identity53194 : scanCanonicalize (H12AffineFastState.compose env53194 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53195 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,0,0,34,16,1,52,1,0,32,16,3,41,16,0,16,16,0,20,33,37,32,1,513]

theorem envBound53195 : H12AffineFastState.Bounded env53195 := by
  intro p hp
  have h : env53195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53194_53195 : H12AffineEnvironment.transform 9 53 env53194 = env53195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53194 == env53195) = true)

theorem identity53195 : scanCanonicalize (H12AffineFastState.compose env53195 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53196 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,16,41,0,0,34,16,1,52,1,0,32,16,3,41,16,0,16,16,0,20,33,37,32,1,0]

theorem envBound53196 : H12AffineFastState.Bounded env53196 := by
  intro p hp
  have h : env53196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53195_53196 : H12AffineEnvironment.transform 8 1 env53195 = env53196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53195 == env53196) = true)

theorem identity53196 : scanCanonicalize (H12AffineFastState.compose env53196 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53197 : List Nat := [2,4,8,16,10,17,8,14,1,31,0,16,3,0,0,8,16,1,30,1,0,10,16,3,3,16,0,16,16,0,20,11,15,10,1,0]

theorem envBound53197 : H12AffineFastState.Bounded env53197 := by
  intro p hp
  have h : env53197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53196_53197 : H12AffineEnvironment.transform 4 10 env53196 = env53197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53196 == env53197) = true)

def env53198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157753,1025,8541,2097152,4194304,147457,16777216,8192,65,21186916,18949464,2233681,149861,16999757,23160137,257,19080569,19096841,16925203]

theorem envBound53198 : H12AffineFastState.Bounded env53198 := by
  intro p hp
  have h : env53198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53198 : H12AffineEnvironment.transform 17 157753 env53182 = env53198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env53182 == env53198) = true)

theorem identity53198 : scanCanonicalize (H12AffineFastState.compose env53198 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound53198 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env53199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157753,1025,8541,2097152,147505,147457,16777216,8192,65,16845141,18949464,2233681,149861,16999757,19080568,257,19080569,19096841,16925203]

theorem envBound53199 : H12AffineFastState.Bounded env53199 := by
  intro p hp
  have h : env53199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53198_53199 : H12AffineEnvironment.transform 21 147505 env53198 = env53199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env53198 == env53199) = true)

theorem identity53199 : scanCanonicalize (H12AffineFastState.compose env53199 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound53199 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env53200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157753,1025,8541,2097152,147505,147457,3,8192,65,67926,2172251,2233681,149861,222542,2303355,257,2303354,2319626,147984]

theorem envBound53200 : H12AffineFastState.Bounded env53200 := by
  intro p hp
  have h : env53200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53199_53200 : H12AffineEnvironment.transform 23 3 env53199 = env53200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env53199 == env53200) = true)

theorem identity53200 : scanCanonicalize (H12AffineFastState.compose env53200 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound53200 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env53201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,65536,131072,138560,1025,8541,2097152,144712,144760,3,8192,65,67926,2172251,2233681,146460,200759,2303355,257,2303354,2297971,145257]

theorem envBound53201 : H12AffineFastState.Bounded env53201 := by
  intro p hp
  have h : env53201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53200_53201 : H12AffineEnvironment.transform 13 13689 env53200 = env53201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env53200 == env53201) = true)

theorem identity53201 : scanCanonicalize (H12AffineFastState.compose env53201 (packedSelected [2,4,6,11,16,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53201 : packedSelected [2,4,6,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env53202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8202,131072,138560,1025,8541,2097152,144712,144760,3,8192,65,10588,2098513,2233681,146460,143421,2229617,257,2229616,2240633,145257]

theorem envBound53202 : H12AffineFastState.Bounded env53202 := by
  intro p hp
  have h : env53202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53201_53202 : H12AffineEnvironment.transform 15 8202 env53201 = env53202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53201 == env53202) = true)

theorem identity53202 : scanCanonicalize (H12AffineFastState.compose env53202 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 12604) := by decide +kernel

theorem selectedBound53202 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env53203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8202,131072,138560,1025,8541,12604,144712,144760,3,8192,65,10588,13421,140397,146460,143421,144461,257,144460,131397,145257]

theorem envBound53203 : H12AffineFastState.Bounded env53203 := by
  intro p hp
  have h : env53203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53202_53203 : H12AffineEnvironment.transform 20 12604 env53202 = env53203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12604 env53202 == env53203) = true)

theorem identity53203 : scanCanonicalize (H12AffineFastState.compose env53203 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound53203 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8202,13673,10281,1025,8541,12604,33,17,3,8192,65,10588,13421,4356,2421,1364,292,257,293,13356,512]

theorem envBound53204 : H12AffineFastState.Bounded env53204 := by
  intro p hp
  have h : env53204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53203_53204 : H12AffineEnvironment.transform 16 13673 env53203 = env53204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env53203 == env53204) = true)

theorem identity53204 : scanCanonicalize (H12AffineFastState.compose env53204 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound53204 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5204,113,295,5188,2308,1025,112,4113,33,17,3,301,65,2161,5440,4356,2421,1364,292,257,293,5377,512]

theorem envBound53205 : H12AffineFastState.Bounded env53205 := by
  intro p hp
  have h : env53205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53204_53205 : H12AffineEnvironment.transform 12 301 env53204 = env53205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env53204 == env53205) = true)

theorem identity53205 : scanCanonicalize (H12AffineFastState.compose env53205 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53205 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53206 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,301,5156,1,295,5172,2308,1025,0,4113,33,17,3,301,49,2049,5424,4356,2309,1316,292,257,293,5377,512]

theorem envBound53206 : H12AffineFastState.Bounded env53206 := by
  intro p hp
  have h : env53206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53205_53206 : H12AffineEnvironment.transform 5 48 env53205 = env53206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53205 == env53206) = true)

theorem identity53206 : scanCanonicalize (H12AffineFastState.compose env53206 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53206 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53207 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,9,5156,1,3,5172,2080,1025,0,4113,33,17,3,9,49,2049,5140,4128,2081,1024,0,37,1,5157,512]

theorem envBound53207 : H12AffineFastState.Bounded env53207 := by
  intro p hp
  have h : env53207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53206_53207 : H12AffineEnvironment.transform 7 36 env53206 = env53207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53206 == env53207) = true)

theorem identity53207 : scanCanonicalize (H12AffineFastState.compose env53207 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53208 : List Nat := [2,4,8,16,32,48,8,36,512,21,2048,4096,9,4145,1,3,4129,2080,20,0,4113,33,17,3,9,49,2049,4097,4128,2081,21,0,37,1,4144,512]

theorem envBound53208 : H12AffineFastState.Bounded env53208 := by
  intro p hp
  have h : env53208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53207_53208 : H12AffineEnvironment.transform 9 21 env53207 = env53208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53207 == env53208) = true)

theorem identity53208 : scanCanonicalize (H12AffineFastState.compose env53208 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound53208 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53209 : List Nat := [2,4,8,16,32,48,8,36,512,21,2048,560,9,513,1,3,529,2080,20,0,545,33,17,3,9,49,2049,561,528,2081,21,0,37,1,512,512]

theorem envBound53209 : H12AffineFastState.Bounded env53209 := by
  intro p hp
  have h : env53209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53208_53209 : H12AffineEnvironment.transform 11 560 env53208 = env53209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env53208 == env53209) = true)

theorem identity53209 : scanCanonicalize (H12AffineFastState.compose env53209 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound53209 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53210 : List Nat := [2,4,8,16,32,48,8,36,512,21,560,560,9,513,1,3,529,528,20,0,545,33,17,3,9,49,561,561,528,529,21,0,37,1,512,512]

theorem envBound53210 : H12AffineFastState.Bounded env53210 := by
  intro p hp
  have h : env53210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53209_53210 : H12AffineEnvironment.transform 10 560 env53209 = env53210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env53209 == env53210) = true)

theorem identity53210 : scanCanonicalize (H12AffineFastState.compose env53210 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53210 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53211 : List Nat := [2,4,8,16,0,16,8,4,512,21,528,528,9,513,1,3,529,528,20,0,513,1,17,3,9,17,529,529,528,529,21,0,5,1,512,512]

theorem envBound53211 : H12AffineFastState.Bounded env53211 := by
  intro p hp
  have h : env53211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53210_53211 : H12AffineEnvironment.transform 4 0 env53210 = env53211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53210 == env53211) = true)

theorem identity53211 : scanCanonicalize (H12AffineFastState.compose env53211 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53212 : List Nat := [2,4,8,16,0,16,8,4,16,21,0,0,9,17,1,3,1,0,20,0,17,1,17,3,9,17,1,1,0,1,21,0,5,1,16,16]

theorem envBound53212 : H12AffineFastState.Bounded env53212 := by
  intro p hp
  have h : env53212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53211_53212 : H12AffineEnvironment.transform 8 16 env53211 = env53212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53211 == env53212) = true)

theorem identity53212 : scanCanonicalize (H12AffineFastState.compose env53212 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound53212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53213 : List Nat := [2,4,7,16,0,16,7,4,16,21,0,0,6,17,1,3,1,0,20,0,17,1,17,3,6,17,1,1,0,1,21,0,5,1,16,16]

theorem envBound53213 : H12AffineFastState.Bounded env53213 := by
  intro p hp
  have h : env53213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53212_53213 : H12AffineEnvironment.transform 2 7 env53212 = env53213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env53212 == env53213) = true)

def env53214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8193,65,21227576,18973701,2391400,190521,17148968,23160136,257,19262493,19205424,17075063]

theorem envBound53214 : H12AffineFastState.Bounded env53214 := by
  intro p hp
  have h : env53214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53180_53214 : H12AffineEnvironment.transform 6 9 env53180 = env53214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53180 == env53214) = true)

theorem identity53214 : scanCanonicalize (H12AffineFastState.compose env53214 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound53214 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env53215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,16777216,8193,65,21227576,18973701,2118977,190521,16876545,23160136,257,18990132,18949401,16819038]

theorem envBound53215 : H12AffineFastState.Bounded env53215 := by
  intro p hp
  have h : env53215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53214_53215 : H12AffineEnvironment.transform 17 10281 env53214 = env53215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53214 == env53215) = true)

theorem identity53215 : scanCanonicalize (H12AffineFastState.compose env53215 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound53215 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env53216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,41311,8193,65,4409703,2172250,2118977,190521,75102,6407191,257,2188651,2196550,513]

theorem envBound53216 : H12AffineFastState.Bounded env53216 := by
  intro p hp
  have h : env53216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53215_53216 : H12AffineEnvironment.transform 23 41311 env53215 = env53216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env53215 == env53216) = true)

def env53217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41311,8193,65,4409703,115014,45405,190521,75102,4268043,257,98679,90202,513]

theorem envBound53217 : H12AffineFastState.Bounded env53217 := by
  intro p hp
  have h : env53217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53216_53217 : H12AffineEnvironment.transform 20 58396 env53216 = env53217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env53216 == env53217) = true)

theorem identity53217 : scanCanonicalize (H12AffineFastState.compose env53217 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53217 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58396,4194304,17,41311,8193,65,4352365,57676,45405,190521,1364,4194305,257,41341,16464,513]

theorem envBound53218 : H12AffineFastState.Bounded env53218 := by
  intro p hp
  have h : env53218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53217_53218 : H12AffineEnvironment.transform 15 8202 env53217 = env53218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53217 == env53218) = true)

theorem identity53218 : scanCanonicalize (H12AffineFastState.compose env53218 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 147552) := by decide +kernel

theorem selectedBound53218 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env53219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58396,147552,17,41311,8193,65,10509,57676,45405,190521,1364,147553,257,41341,16464,513]

theorem envBound53219 : H12AffineFastState.Bounded env53219 := by
  intro p hp
  have h : env53219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53218_53219 : H12AffineEnvironment.transform 21 147552 env53218 = env53219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147552 env53218 == env53219) = true)

theorem identity53219 : scanCanonicalize (H12AffineFastState.compose env53219 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound53219 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24860,10281,1025,32769,58396,8572,17,41311,8193,65,10509,57676,45405,35109,1364,8573,257,41341,16464,513]

theorem envBound53220 : H12AffineFastState.Bounded env53220 := by
  intro p hp
  have h : env53220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53219_53220 : H12AffineEnvironment.transform 16 24860 env53219 = env53220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env53219 == env53220) = true)

theorem identity53220 : scanCanonicalize (H12AffineFastState.compose env53220 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53220 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,2420,1025,32769,50497,33,17,32770,348,65,2128,49169,36864,35109,1364,32,257,32800,16464,513]

theorem envBound53221 : H12AffineFastState.Bounded env53221 := by
  intro p hp
  have h : env53221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53220_53221 : H12AffineEnvironment.transform 12 349 env53220 = env53221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53220 == env53221) = true)

theorem identity53221 : scanCanonicalize (H12AffineFastState.compose env53221 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53221 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53222 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,16401,2340,1025,32769,50449,33,17,32770,268,17,2048,49169,36864,35109,1284,32,257,32800,16384,513]

theorem envBound53222 : H12AffineFastState.Bounded env53222 := by
  intro p hp
  have h : env53222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53221_53222 : H12AffineEnvironment.transform 5 16 env53221 = env53222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53221 == env53222) = true)

theorem identity53222 : scanCanonicalize (H12AffineFastState.compose env53222 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound53222 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53223 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,32768,263,5172,2340,1025,32769,37172,33,17,32770,268,17,2048,37940,36864,35109,1284,32,257,32800,5157,513]

theorem envBound53223 : H12AffineFastState.Bounded env53223 := by
  intro p hp
  have h : env53223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53222_53223 : H12AffineEnvironment.transform 13 5157 env53222 = env53223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env53222 == env53223) = true)

theorem identity53223 : scanCanonicalize (H12AffineFastState.compose env53223 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53223 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53224 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,1,263,5172,2340,1025,0,4405,33,17,3,268,17,2048,5173,4097,2340,1284,32,257,33,5157,513]

theorem envBound53224 : H12AffineFastState.Bounded env53224 := by
  intro p hp
  have h : env53224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53223_53224 : H12AffineEnvironment.transform 14 1 env53223 = env53224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53223 == env53224) = true)

def env53225 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,269,2837,1,263,2820,2340,1025,0,3589,33,17,3,268,17,2048,2821,3889,2340,1284,32,257,33,2837,513]

theorem envBound53225 : H12AffineFastState.Bounded env53225 := by
  intro p hp
  have h : env53225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53224_53225 : H12AffineEnvironment.transform 11 3888 env53224 = env53225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env53224 == env53225) = true)

def env53226 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,269,1045,1,263,1028,1572,1025,0,261,33,17,3,268,17,1792,1029,49,1572,1284,32,257,33,1045,513]

theorem envBound53226 : H12AffineFastState.Bounded env53226 := by
  intro p hp
  have h : env53226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53225_53226 : H12AffineEnvironment.transform 10 1792 env53225 = env53226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53225 == env53226) = true)

theorem identity53226 : scanCanonicalize (H12AffineFastState.compose env53226 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound53226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53227 : List Nat := [2,4,8,16,32,16,9,256,512,20,788,48,269,1,1,263,16,560,21,0,261,33,17,3,268,17,788,17,49,560,272,32,257,33,1,513]

theorem envBound53227 : H12AffineFastState.Bounded env53227 := by
  intro p hp
  have h : env53227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53226_53227 : H12AffineEnvironment.transform 9 20 env53226 = env53227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53226 == env53227) = true)

def env53228 : List Nat := [2,4,8,16,0,16,9,256,512,20,788,16,269,1,1,263,16,528,21,0,261,1,17,3,268,17,788,17,17,528,272,0,257,1,1,513]

theorem envBound53228 : H12AffineFastState.Bounded env53228 := by
  intro p hp
  have h : env53228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53227_53228 : H12AffineEnvironment.transform 4 0 env53227 = env53228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53227 == env53228) = true)

theorem identity53228 : scanCanonicalize (H12AffineFastState.compose env53228 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound53228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53229 : List Nat := [2,4,8,16,0,16,9,256,277,20,1,16,269,1,1,263,16,261,21,0,261,1,17,3,268,17,1,17,17,261,272,0,257,1,1,276]

theorem envBound53229 : H12AffineFastState.Bounded env53229 := by
  intro p hp
  have h : env53229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53228_53229 : H12AffineEnvironment.transform 8 277 env53228 = env53229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env53228 == env53229) = true)

def leafEnv53229 : List Nat := [2,4,8,16,0,16,9,256,277,20,1,16,269,1,1,263,16,261,21,0,261,1,17,3,273,268,1,17,1,17,17,261,272,0,257,1,5,262,1,276,1,261,0]

def active53229 : List Nat := [0,1,2,3,7]

def tree53229 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53229 : H12WitnessSearch.Good tree53229 := H12GlobalWitnessIndex.good

theorem leafIdentity53229 : H12AffineFastState.composeSystem env53229 rootObs = leafEnv53229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53229 rootObs == leafEnv53229) = true)

theorem terminalChecked53229 : H12PackedTerminal.terminalCheckFast leafEnv53229 active53229 tree53229 = true := by decide +kernel

def env53230 : List Nat := [2,4,8,16,1,16,9,256,512,20,788,17,269,1,1,263,16,529,21,0,261,0,17,3,268,17,788,17,16,529,272,1,257,0,1,513]

theorem envBound53230 : H12AffineFastState.Bounded env53230 := by
  intro p hp
  have h : env53230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53227_53230 : H12AffineEnvironment.transform 4 1 env53227 = env53230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53227 == env53230) = true)

theorem identity53230 : scanCanonicalize (H12AffineFastState.compose env53230 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53231 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,11,269,1,1,263,10,523,15,0,261,0,11,3,268,11,782,11,10,523,266,1,257,0,1,513]

theorem envBound53231 : H12AffineFastState.Bounded env53231 := by
  intro p hp
  have h : env53231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53230_53231 : H12AffineEnvironment.transform 3 10 env53230 = env53231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53230 == env53231) = true)

def leafEnv53231 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,11,269,1,1,263,10,523,15,0,261,0,11,3,267,268,1,11,782,11,10,523,266,1,257,0,5,262,1,513,1,261,0]

def active53231 : List Nat := [0,1,2,7,8]

def tree53231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53231 : H12WitnessSearch.Good tree53231 := H12GlobalWitnessIndex.good

theorem leafIdentity53231 : H12AffineFastState.composeSystem env53231 rootObs = leafEnv53231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53231 rootObs == leafEnv53231) = true)

theorem terminalChecked53231 : H12PackedTerminal.terminalCheckFast leafEnv53231 active53231 tree53231 = true := by decide +kernel

def env53232 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,269,1044,1,263,1029,1573,1025,0,260,33,17,3,268,17,1793,1028,48,1573,1284,32,257,33,1044,513]

theorem envBound53232 : H12AffineFastState.Bounded env53232 := by
  intro p hp
  have h : env53232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53225_53232 : H12AffineEnvironment.transform 10 1793 env53225 = env53232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53225 == env53232) = true)

theorem identity53232 : scanCanonicalize (H12AffineFastState.compose env53232 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53233 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1540,49,8,1044,1,2,1029,1573,1025,0,1,33,17,3,9,17,1540,1028,48,1573,1025,32,4,33,1044,513]

theorem envBound53233 : H12AffineFastState.Bounded env53233 := by
  intro p hp
  have h : env53233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53232_53233 : H12AffineEnvironment.transform 7 5 env53232 = env53233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53232 == env53233) = true)

def env53234 : List Nat := [2,4,8,16,32,16,9,5,512,52,560,49,8,32,1,2,49,529,53,0,1,33,17,3,9,17,560,48,48,529,53,32,4,33,32,513]

theorem envBound53234 : H12AffineFastState.Bounded env53234 := by
  intro p hp
  have h : env53234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53233_53234 : H12AffineEnvironment.transform 9 52 env53233 = env53234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53233 == env53234) = true)

theorem identity53234 : scanCanonicalize (H12AffineFastState.compose env53234 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53235 : List Nat := [2,4,8,16,32,16,9,5,16,52,32,49,8,32,1,2,49,1,53,0,1,33,17,3,9,17,32,48,48,1,53,32,4,33,32,17]

theorem envBound53235 : H12AffineFastState.Bounded env53235 := by
  intro p hp
  have h : env53235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53234_53235 : H12AffineEnvironment.transform 8 16 env53234 = env53235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53234 == env53235) = true)

def leafEnv53235 : List Nat := [2,4,8,16,32,16,9,5,16,52,32,49,8,32,1,2,49,1,53,0,1,33,17,3,52,9,1,17,32,48,48,1,53,32,4,33,5,3,32,17,1,1,0]

def active53235 : List Nat := [0,1,2,3,4]

def tree53235 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53235 : H12WitnessSearch.Good tree53235 := H12GlobalWitnessIndex.good

theorem leafIdentity53235 : H12AffineFastState.composeSystem env53235 rootObs = leafEnv53235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53235 rootObs == leafEnv53235) = true)

theorem terminalChecked53235 : H12PackedTerminal.terminalCheckFast leafEnv53235 active53235 tree53235 = true := by decide +kernel

def env53236 : List Nat := [2,4,8,16,32,16,9,5,512,53,561,49,8,33,1,2,48,528,52,0,1,33,17,3,9,17,561,49,48,528,52,32,4,33,33,513]

theorem envBound53236 : H12AffineFastState.Bounded env53236 := by
  intro p hp
  have h : env53236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53233_53236 : H12AffineEnvironment.transform 9 53 env53233 = env53236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53233 == env53236) = true)

theorem identity53236 : scanCanonicalize (H12AffineFastState.compose env53236 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53236 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53237 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,42,8,33,1,2,43,523,47,0,1,33,10,3,9,10,554,42,43,523,47,32,4,33,33,513]

theorem envBound53237 : H12AffineFastState.Bounded env53237 := by
  intro p hp
  have h : env53237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53236_53237 : H12AffineEnvironment.transform 3 11 env53236 = env53237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53236 == env53237) = true)

def leafEnv53237 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,42,8,33,1,2,43,523,47,0,1,33,10,3,46,9,1,10,554,42,43,523,47,32,4,33,5,3,33,513,1,1,0]

def active53237 : List Nat := [0,1,2,4,8]

def tree53237 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53237 : H12WitnessSearch.Good tree53237 := H12GlobalWitnessIndex.good

theorem leafIdentity53237 : H12AffineFastState.composeSystem env53237 rootObs = leafEnv53237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53237 rootObs == leafEnv53237) = true)

theorem terminalChecked53237 : H12PackedTerminal.terminalCheckFast leafEnv53237 active53237 tree53237 = true := by decide +kernel

def env53238 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,269,2836,1,263,2821,2340,1025,0,3588,33,17,3,268,17,2048,2820,3888,2340,1284,32,257,33,2836,513]

theorem envBound53238 : H12AffineFastState.Bounded env53238 := by
  intro p hp
  have h : env53238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53224_53238 : H12AffineEnvironment.transform 11 3889 env53224 = env53238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env53224 == env53238) = true)

def env53239 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,269,1044,1,263,1029,1572,1025,0,260,33,17,3,268,17,1792,1028,48,1572,1284,32,257,33,1044,513]

theorem envBound53239 : H12AffineFastState.Bounded env53239 := by
  intro p hp
  have h : env53239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53238_53239 : H12AffineEnvironment.transform 10 1792 env53238 = env53239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53238 == env53239) = true)

theorem identity53239 : scanCanonicalize (H12AffineFastState.compose env53239 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53239 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53240 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1792,17,269,1044,1,263,1029,1540,1025,0,260,1,17,3,268,17,1792,1028,16,1540,1284,0,257,1,1044,513]

theorem envBound53240 : H12AffineFastState.Bounded env53240 := by
  intro p hp
  have h : env53240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53239_53240 : H12AffineEnvironment.transform 4 0 env53239 = env53240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53239 == env53240) = true)

def env53241 : List Nat := [2,4,8,16,0,16,9,256,512,20,788,17,269,0,1,263,17,528,21,0,260,1,17,3,268,17,788,16,16,528,272,0,257,1,0,513]

theorem envBound53241 : H12AffineFastState.Bounded env53241 := by
  intro p hp
  have h : env53241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53240_53241 : H12AffineEnvironment.transform 9 20 env53240 = env53241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53240 == env53241) = true)

theorem identity53241 : scanCanonicalize (H12AffineFastState.compose env53241 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound53241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53242 : List Nat := [2,4,8,16,0,16,9,256,276,20,0,17,269,0,1,263,17,260,21,0,260,1,17,3,268,17,0,16,16,260,272,0,257,1,0,277]

theorem envBound53242 : H12AffineFastState.Bounded env53242 := by
  intro p hp
  have h : env53242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53241_53242 : H12AffineEnvironment.transform 8 276 env53241 = env53242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env53241 == env53242) = true)

def leafEnv53242 : List Nat := [2,4,8,16,0,16,9,256,276,20,0,17,269,0,1,263,17,260,21,0,260,1,17,3,273,268,1,17,0,16,16,260,272,0,257,1,5,262,0,277,1,260,0]

def active53242 : List Nat := [0,1,2,3,7]

def tree53242 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53242 : H12WitnessSearch.Good tree53242 := H12GlobalWitnessIndex.good

theorem leafIdentity53242 : H12AffineFastState.composeSystem env53242 rootObs = leafEnv53242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53242 rootObs == leafEnv53242) = true)

theorem terminalChecked53242 : H12PackedTerminal.terminalCheckFast leafEnv53242 active53242 tree53242 = true := by decide +kernel

def env53243 : List Nat := [2,4,8,16,0,16,9,256,512,21,789,17,269,1,1,263,16,529,20,0,260,1,17,3,268,17,789,17,16,529,273,0,257,1,1,513]

theorem envBound53243 : H12AffineFastState.Bounded env53243 := by
  intro p hp
  have h : env53243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53240_53243 : H12AffineEnvironment.transform 9 21 env53240 = env53243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53240 == env53243) = true)

theorem identity53243 : scanCanonicalize (H12AffineFastState.compose env53243 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53243 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53244 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,11,269,1,1,263,10,523,14,0,260,1,11,3,268,11,783,11,10,523,267,0,257,1,1,513]

theorem envBound53244 : H12AffineFastState.Bounded env53244 := by
  intro p hp
  have h : env53244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53243_53244 : H12AffineEnvironment.transform 3 10 env53243 = env53244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53243 == env53244) = true)

def leafEnv53244 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,11,269,1,1,263,10,523,14,0,260,1,11,3,266,268,1,11,783,11,10,523,267,0,257,1,5,262,1,513,1,260,0]

def active53244 : List Nat := [0,1,2,7,8]

def tree53244 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53244 : H12WitnessSearch.Good tree53244 := H12GlobalWitnessIndex.good

theorem leafIdentity53244 : H12AffineFastState.composeSystem env53244 rootObs = leafEnv53244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53244 rootObs == leafEnv53244) = true)

theorem terminalChecked53244 : H12PackedTerminal.terminalCheckFast leafEnv53244 active53244 tree53244 = true := by decide +kernel

def env53245 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,269,1045,1,263,1028,1573,1025,0,261,33,17,3,268,17,1793,1029,49,1573,1284,32,257,33,1045,513]

theorem envBound53245 : H12AffineFastState.Bounded env53245 := by
  intro p hp
  have h : env53245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53238_53245 : H12AffineEnvironment.transform 10 1793 env53238 = env53245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53238 == env53245) = true)

theorem identity53245 : scanCanonicalize (H12AffineFastState.compose env53245 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound53245 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53246 : List Nat := [2,4,8,16,32,16,9,256,512,305,560,48,269,292,1,263,309,788,304,0,261,33,17,3,268,17,560,308,49,788,53,32,257,33,292,513]

theorem envBound53246 : H12AffineFastState.Bounded env53246 := by
  intro p hp
  have h : env53246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53245_53246 : H12AffineEnvironment.transform 9 305 env53245 = env53246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env53245 == env53246) = true)

def env53247 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,48,9,32,1,3,49,528,52,0,1,33,17,3,8,17,560,48,49,528,53,32,5,33,32,513]

theorem envBound53247 : H12AffineFastState.Bounded env53247 := by
  intro p hp
  have h : env53247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53246_53247 : H12AffineEnvironment.transform 7 4 env53246 = env53247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53246 == env53247) = true)

theorem identity53247 : scanCanonicalize (H12AffineFastState.compose env53247 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53247 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53248 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,43,9,32,1,3,42,523,47,0,1,33,10,3,8,10,555,43,42,523,46,32,5,33,32,513]

theorem envBound53248 : H12AffineFastState.Bounded env53248 := by
  intro p hp
  have h : env53248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53247_53248 : H12AffineEnvironment.transform 3 11 env53247 = env53248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53247 == env53248) = true)

def leafEnv53248 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,43,9,32,1,3,42,523,47,0,1,33,10,3,47,8,1,10,555,43,42,523,46,32,5,33,5,2,32,513,1,1,0]

def active53248 : List Nat := [0,1,2,4,8]

def tree53248 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53248 : H12WitnessSearch.Good tree53248 := H12GlobalWitnessIndex.good

theorem leafIdentity53248 : H12AffineFastState.composeSystem env53248 rootObs = leafEnv53248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53248 rootObs == leafEnv53248) = true)

theorem terminalChecked53248 : H12PackedTerminal.terminalCheckFast leafEnv53248 active53248 tree53248 = true := by decide +kernel

def env53249 : List Nat := [2,4,8,16,32,16,9,5,512,52,560,48,8,33,1,2,48,529,53,0,0,33,17,3,9,17,560,49,49,529,53,32,4,33,33,513]

theorem envBound53249 : H12AffineFastState.Bounded env53249 := by
  intro p hp
  have h : env53249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53246_53249 : H12AffineEnvironment.transform 7 5 env53246 = env53249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53246 == env53249) = true)

theorem identity53249 : scanCanonicalize (H12AffineFastState.compose env53249 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound53249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53250 : List Nat := [2,4,8,16,32,16,9,5,17,52,33,48,8,33,1,2,48,0,53,0,0,33,17,3,9,17,33,49,49,0,53,32,4,33,33,16]

theorem envBound53250 : H12AffineFastState.Bounded env53250 := by
  intro p hp
  have h : env53250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53249_53250 : H12AffineEnvironment.transform 8 17 env53249 = env53250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env53249 == env53250) = true)

def leafEnv53250 : List Nat := [2,4,8,16,32,16,9,5,17,52,33,48,8,33,1,2,48,0,53,0,0,33,17,3,52,9,1,17,33,49,49,0,53,32,4,33,5,3,33,16,1,0,0]

def active53250 : List Nat := [0,1,2,3,4]

def tree53250 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53250 : H12WitnessSearch.Good tree53250 := H12GlobalWitnessIndex.good

theorem leafIdentity53250 : H12AffineFastState.composeSystem env53250 rootObs = leafEnv53250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53250 rootObs == leafEnv53250) = true)

theorem terminalChecked53250 : H12PackedTerminal.terminalCheckFast leafEnv53250 active53250 tree53250 = true := by decide +kernel

def env53251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41311,8193,65,4409703,115015,45404,190521,75102,4268042,257,98678,90203,513]

theorem envBound53251 : H12AffineFastState.Bounded env53251 := by
  intro p hp
  have h : env53251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53216_53251 : H12AffineEnvironment.transform 20 58397 env53216 = env53251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env53216 == env53251) = true)

def env53252 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41231,8193,17,4409655,114967,45324,190521,75022,4268042,257,98598,90123,513]

theorem envBound53252 : H12AffineFastState.Bounded env53252 := by
  intro p hp
  have h : env53252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53251_53252 : H12AffineEnvironment.transform 5 16 env53251 = env53252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53251 == env53252) = true)

theorem identity53252 : scanCanonicalize (H12AffineFastState.compose env53252 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound53252 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env53253 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1025,32769,58397,4194304,17,41231,8193,17,4385085,24861,45324,190521,34052,4227072,257,8492,49153,513]

theorem envBound53253 : H12AffineFastState.Bounded env53253 := by
  intro p hp
  have h : env53253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53252_53253 : H12AffineEnvironment.transform 15 40970 env53252 = env53253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env53252 == env53253) = true)

theorem identity53253 : scanCanonicalize (H12AffineFastState.compose env53253 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound53253 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53254 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1025,32769,58397,155964,17,41231,8193,17,34817,24861,45324,190521,34052,188732,257,8492,49153,513]

theorem envBound53254 : H12AffineFastState.Bounded env53254 := by
  intro p hp
  have h : env53254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53253_53254 : H12AffineEnvironment.transform 21 155964 env53253 = env53254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env53253 == env53254) = true)

theorem identity53254 : scanCanonicalize (H12AffineFastState.compose env53254 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound53254 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53255 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10281,1025,32769,58397,8492,17,41231,8193,17,34817,24861,45324,43049,34052,41260,257,8492,49153,513]

theorem envBound53255 : H12AffineFastState.Bounded env53255 := by
  intro p hp
  have h : env53255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53254_53255 : H12AffineEnvironment.transform 16 16400 env53254 = env53255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env53254 == env53255) = true)

def env53256 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41230,8193,16,4409654,114966,45325,190521,75023,4268042,257,98599,90122,513]

theorem envBound53256 : H12AffineFastState.Bounded env53256 := by
  intro p hp
  have h : env53256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53251_53256 : H12AffineEnvironment.transform 5 17 env53251 = env53256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53251 == env53256) = true)

theorem identity53256 : scanCanonicalize (H12AffineFastState.compose env53256 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound53256 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env53257 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,246071,17,41230,8193,16,34817,114966,45325,190521,75023,188733,257,98599,90122,513]

theorem envBound53257 : H12AffineFastState.Bounded env53257 := by
  intro p hp
  have h : env53257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53256_53257 : H12AffineEnvironment.transform 21 246071 env53256 = env53257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env53256 == env53257) = true)

theorem identity53257 : scanCanonicalize (H12AffineFastState.compose env53257 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53257 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env53258 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10281,1025,1,25629,213303,17,8462,8193,16,2049,82198,12557,157753,75023,155965,257,65831,90122,513]

theorem envBound53258 : H12AffineFastState.Bounded env53258 := by
  intro p hp
  have h : env53258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53257_53258 : H12AffineEnvironment.transform 14 0 env53257 = env53258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53257 == env53258) = true)

theorem identity53258 : scanCanonicalize (H12AffineFastState.compose env53258 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53258 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53259 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,263,131072,10281,1025,1,25629,147504,17,8462,8193,16,2049,16401,12557,157753,9224,155965,257,32,24845,513]

theorem envBound53259 : H12AffineFastState.Bounded env53259 := by
  intro p hp
  have h : env53259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53258_53259 : H12AffineEnvironment.transform 15 263 env53258 = env53259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53258 == env53259) = true)

theorem identity53259 : scanCanonicalize (H12AffineFastState.compose env53259 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound53259 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53260 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,263,16400,10281,1025,1,25629,32,17,8462,8193,16,2049,16401,12557,10281,9224,8493,257,32,24845,513]

theorem envBound53260 : H12AffineFastState.Bounded env53260 := by
  intro p hp
  have h : env53260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53259_53260 : H12AffineEnvironment.transform 16 16400 env53259 = env53260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env53259 == env53260) = true)

theorem identity53260 : scanCanonicalize (H12AffineFastState.compose env53260 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53260 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53261 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,263,16400,2341,1025,1,17681,32,17,2,269,16,2049,16401,4097,2341,1284,33,257,32,16385,513]

theorem envBound53261 : H12AffineFastState.Bounded env53261 := by
  intro p hp
  have h : env53261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53260_53261 : H12AffineEnvironment.transform 12 268 env53260 = env53261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53260 == env53261) = true)

theorem identity53261 : scanCanonicalize (H12AffineFastState.compose env53261 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound53261 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53262 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4388,0,263,4404,2341,1025,1,5173,32,17,2,269,16,2049,4405,4097,2341,1284,33,257,32,4389,513]

theorem envBound53262 : H12AffineFastState.Bounded env53262 := by
  intro p hp
  have h : env53262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53261_53262 : H12AffineEnvironment.transform 13 4388 env53261 = env53262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env53261 == env53262) = true)

theorem identity53262 : scanCanonicalize (H12AffineFastState.compose env53262 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound53262 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53263 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,268,805,0,263,821,2341,1025,1,1588,32,17,2,269,16,2049,820,512,2341,1284,33,257,32,804,513]

theorem envBound53263 : H12AffineFastState.Bounded env53263 := by
  intro p hp
  have h : env53263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53262_53263 : H12AffineEnvironment.transform 11 513 env53262 = env53263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env53262 == env53263) = true)

theorem identity53263 : scanCanonicalize (H12AffineFastState.compose env53263 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound53263 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53264 : List Nat := [2,4,8,16,32,17,9,256,512,768,2048,513,268,805,0,263,821,2341,769,1,308,32,17,2,269,16,2049,820,512,2341,516,33,257,32,804,513]

theorem envBound53264 : H12AffineFastState.Bounded env53264 := by
  intro p hp
  have h : env53264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53263_53264 : H12AffineEnvironment.transform 9 768 env53263 = env53264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env53263 == env53264) = true)

theorem identity53264 : scanCanonicalize (H12AffineFastState.compose env53264 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound53264 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53265 : List Nat := [2,4,8,16,32,17,9,52,512,564,2048,513,56,529,0,51,513,2065,565,1,0,32,17,2,57,16,2049,512,512,2065,516,33,53,32,528,513]

theorem envBound53265 : H12AffineFastState.Bounded env53265 := by
  intro p hp
  have h : env53265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53264_53265 : H12AffineEnvironment.transform 7 52 env53264 = env53265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env53264 == env53265) = true)

theorem identity53265 : scanCanonicalize (H12AffineFastState.compose env53265 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound53265 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53266 : List Nat := [2,4,8,16,32,17,9,52,512,564,17,513,56,529,0,51,513,0,565,1,0,32,17,2,57,16,16,512,512,0,516,33,53,32,528,513]

theorem envBound53266 : H12AffineFastState.Bounded env53266 := by
  intro p hp
  have h : env53266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53265_53266 : H12AffineEnvironment.transform 10 17 env53265 = env53266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env53265 == env53266) = true)

theorem identity53266 : scanCanonicalize (H12AffineFastState.compose env53266 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53266 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53267 : List Nat := [2,4,8,16,1,17,9,21,512,533,17,513,25,529,0,18,513,0,532,1,0,1,17,2,24,16,16,512,512,0,516,0,20,1,528,513]

theorem envBound53267 : H12AffineFastState.Bounded env53267 := by
  intro p hp
  have h : env53267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53266_53267 : H12AffineEnvironment.transform 4 1 env53266 = env53267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53266 == env53267) = true)

theorem identity53267 : scanCanonicalize (H12AffineFastState.compose env53267 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53267 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53268 : List Nat := [2,4,8,16,1,17,9,21,1,20,17,0,25,16,0,18,0,0,21,1,0,1,17,2,24,16,16,1,1,0,5,0,20,1,17,0]

theorem envBound53268 : H12AffineFastState.Bounded env53268 := by
  intro p hp
  have h : env53268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53267_53268 : H12AffineEnvironment.transform 8 1 env53267 = env53268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53267 == env53268) = true)

def env53269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound53269 : H12AffineFastState.Bounded env53269 := by
  intro p hp
  have h : env53269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49935_53269 : H12AffineEnvironment.transform 31 145662401 env49935 = env53269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env49935 == env53269) = true)

def env53270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound53270 : H12AffineFastState.Bounded env53270 := by
  intro p hp
  have h : env53270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53269_53270 : H12AffineEnvironment.transform 29 155254784 env53269 = env53270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env53269 == env53270) = true)

def env53271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound53271 : H12AffineFastState.Bounded env53271 := by
  intro p hp
  have h : env53271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53270_53271 : H12AffineEnvironment.transform 25 64 env53270 = env53271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env53270 == env53271) = true)

def env53272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound53272 : H12AffineFastState.Bounded env53272 := by
  intro p hp
  have h : env53272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53271_53272 : H12AffineEnvironment.transform 26 30393344 env53271 = env53272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env53271 == env53272) = true)

def env53273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound53273 : H12AffineFastState.Bounded env53273 := by
  intro p hp
  have h : env53273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53272_53273 : H12AffineEnvironment.transform 18 1024 env53272 = env53273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env53272 == env53273) = true)

def env53274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6705548,8393985,10507601,8830976,2102685,12645453,256,21793,46212,2175563]

theorem envBound53274 : H12AffineFastState.Bounded env53274 := by
  intro p hp
  have h : env53274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53273_53274 : H12AffineEnvironment.transform 23 10588556 env53273 = env53274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env53273 == env53274) = true)

def env53275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98780,8328,64,6705548,2098513,17665,2543696,2102685,6349853,256,21793,46212,2175563]

theorem envBound53275 : H12AffineFastState.Bounded env53275 := by
  intro p hp
  have h : env53275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53274_53275 : H12AffineEnvironment.transform 22 2101328 env53274 = env53275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env53274 == env53275) = true)

def env53276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98780,8328,64,2259212,2098513,17665,2543696,2102685,2411677,256,21793,46212,2175563]

theorem envBound53276 : H12AffineFastState.Bounded env53276 := by
  intro p hp
  have h : env53276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53275_53276 : H12AffineEnvironment.transform 21 272512 env53275 = env53276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53275 == env53276) = true)

theorem identity53276 : scanCanonicalize (H12AffineFastState.compose env53276 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53276 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272512,2101328,41430,8328,64,2259212,2098513,17665,2543696,2102685,2411677,256,21793,46212,2101825]

theorem envBound53277 : H12AffineFastState.Bounded env53277 := by
  intro p hp
  have h : env53277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53276_53277 : H12AffineEnvironment.transform 15 8202 env53276 = env53277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53276 == env53277) = true)

def env53278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272392,2101328,41310,8192,64,2259212,2098513,17665,2543696,2102549,2411541,256,21793,46092,2101825]

theorem envBound53278 : H12AffineFastState.Bounded env53278 := by
  intro p hp
  have h : env53278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53277_53278 : H12AffineEnvironment.transform 6 8 env53277 = env53278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53277 == env53278) = true)

theorem identity53278 : scanCanonicalize (H12AffineFastState.compose env53278 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound53278 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,2097152,272392,2101328,41310,8192,64,2124877,2098513,17665,2409745,2102549,2411541,256,21793,46092,2101825]

theorem envBound53279 : H12AffineFastState.Bounded env53279 := by
  intro p hp
  have h : env53279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53278_53279 : H12AffineEnvironment.transform 16 5441 env53278 = env53279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env53278 == env53279) = true)

theorem identity53279 : scanCanonicalize (H12AffineFastState.compose env53279 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 58445) := by decide +kernel

theorem selectedBound53279 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,58445,272392,62493,41310,8192,64,34816,57628,17665,270684,61784,272472,256,21793,46092,62988]

theorem envBound53280 : H12AffineFastState.Bounded env53280 := by
  intro p hp
  have h : env53280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53279_53280 : H12AffineEnvironment.transform 20 58445 env53279 = env53280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58445 env53279 == env53280) = true)

theorem identity53280 : scanCanonicalize (H12AffineFastState.compose env53280 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound53280 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env53281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,5441,262144,1024,29708,4160,272392,16,21843,8192,64,31757,5393,17665,270684,1365,272472,256,21793,16385,513]

theorem envBound53281 : H12AffineFastState.Bounded env53281 := by
  intro p hp
  have h : env53281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53280_53281 : H12AffineEnvironment.transform 14 29709 env53280 = env53281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env53280 == env53281) = true)

theorem identity53281 : scanCanonicalize (H12AffineFastState.compose env53281 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound53281 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,373,8202,5441,262144,1024,372,4160,272392,16,8235,8192,64,2421,5393,12409,270684,1365,272472,256,8281,13689,513]

theorem envBound53282 : H12AffineFastState.Bounded env53282 := by
  intro p hp
  have h : env53282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53281_53282 : H12AffineEnvironment.transform 13 13688 env53281 = env53282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env53281 == env53282) = true)

theorem identity53282 : scanCanonicalize (H12AffineFastState.compose env53282 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53282 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,373,35,5441,262144,1024,372,4160,264225,16,2,41,64,2421,5393,4176,262517,1365,264305,256,112,5456,513]

theorem envBound53283 : H12AffineFastState.Bounded env53283 := by
  intro p hp
  have h : env53283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53282_53283 : H12AffineEnvironment.transform 12 41 env53282 = env53283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53282 == env53283) = true)

theorem identity53283 : scanCanonicalize (H12AffineFastState.compose env53283 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 3392) := by decide +kernel

theorem selectedBound53283 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,373,35,5441,3392,1024,372,4160,1377,16,2,41,64,2421,5393,4176,3125,1365,1329,256,112,5456,513]

theorem envBound53284 : H12AffineFastState.Bounded env53284 := by
  intro p hp
  have h : env53284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53283_53284 : H12AffineEnvironment.transform 17 3392 env53283 = env53284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3392 env53283 == env53284) = true)

theorem identity53284 : scanCanonicalize (H12AffineFastState.compose env53284 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53284 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env53285 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4161,373,35,4177,2128,272,372,4160,113,16,2,41,64,2421,4097,4176,2341,69,33,256,112,4160,513]

theorem envBound53285 : H12AffineFastState.Bounded env53285 := by
  intro p hp
  have h : env53285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53284_53285 : H12AffineEnvironment.transform 9 272 env53284 = env53285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53284 == env53285) = true)

theorem identity53285 : scanCanonicalize (H12AffineFastState.compose env53285 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53286 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,4113,293,35,4097,2048,272,292,4112,33,16,2,41,16,2341,4097,4096,2341,21,33,256,32,4112,513]

theorem envBound53286 : H12AffineFastState.Bounded env53286 := by
  intro p hp
  have h : env53286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53285_53286 : H12AffineEnvironment.transform 5 16 env53285 = env53286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53285 == env53286) = true)

theorem identity53286 : scanCanonicalize (H12AffineFastState.compose env53286 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53286 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53287 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,1,35,4097,2048,52,0,4112,33,16,2,41,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound53287 : H12AffineFastState.Bounded env53287 := by
  intro p hp
  have h : env53287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53286_53287 : H12AffineEnvironment.transform 7 36 env53286 = env53287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53286 == env53287) = true)

theorem identity53287 : scanCanonicalize (H12AffineFastState.compose env53287 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound53287 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53288 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,529,41,512,1,35,528,2048,52,0,513,33,16,2,41,16,2049,528,529,2049,21,33,36,32,513,513]

theorem envBound53288 : H12AffineFastState.Bounded env53288 := by
  intro p hp
  have h : env53288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53287_53288 : H12AffineEnvironment.transform 11 529 env53287 = env53288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env53287 == env53288) = true)

theorem identity53288 : scanCanonicalize (H12AffineFastState.compose env53288 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53289 : List Nat := [2,4,3,16,32,16,3,36,512,52,2048,529,34,512,1,35,528,2048,52,0,513,33,16,2,34,16,2049,528,529,2049,21,33,36,32,513,513]

theorem envBound53289 : H12AffineFastState.Bounded env53289 := by
  intro p hp
  have h : env53289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53288_53289 : H12AffineEnvironment.transform 2 3 env53288 = env53289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53288 == env53289) = true)

theorem identity53289 : scanCanonicalize (H12AffineFastState.compose env53289 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound53289 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53290 : List Nat := [2,4,3,16,32,16,3,36,512,52,512,529,34,512,1,35,528,512,52,0,513,33,16,2,34,16,513,528,529,513,21,33,36,32,513,513]

theorem envBound53290 : H12AffineFastState.Bounded env53290 := by
  intro p hp
  have h : env53290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53289_53290 : H12AffineEnvironment.transform 10 512 env53289 = env53290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env53289 == env53290) = true)

def env53291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272393,2101328,41311,8193,64,2259212,2098513,17665,2543696,2102548,2411540,256,21793,46093,2101825]

theorem envBound53291 : H12AffineFastState.Bounded env53291 := by
  intro p hp
  have h : env53291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53277_53291 : H12AffineEnvironment.transform 6 9 env53277 = env53291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53277 == env53291) = true)

theorem identity53291 : scanCanonicalize (H12AffineFastState.compose env53291 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound53291 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,2097152,272393,2101328,41311,8193,64,2149649,2098513,17665,2384973,2102548,2411540,256,21793,46093,2101825]

theorem envBound53292 : H12AffineFastState.Bounded env53292 := by
  intro p hp
  have h : env53292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53291_53292 : H12AffineEnvironment.transform 16 46109 env53291 = env53292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env53291 == env53292) = true)

def env53293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4160,272393,16,41311,8193,64,56657,5393,17665,291853,1364,318548,256,21793,46093,513]

theorem envBound53293 : H12AffineFastState.Bounded env53293 := by
  intro p hp
  have h : env53293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53292_53293 : H12AffineEnvironment.transform 20 4160 env53292 = env53293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53292 == env53293) = true)

theorem identity53293 : scanCanonicalize (H12AffineFastState.compose env53293 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound53293 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env53294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16449,262144,1024,29789,4160,272393,16,21763,8193,64,10509,5393,17665,291853,1364,272392,256,21793,16465,513]

theorem envBound53294 : H12AffineFastState.Bounded env53294 := by
  intro p hp
  have h : env53294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53293_53294 : H12AffineEnvironment.transform 14 29788 env53293 = env53294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53293 == env53294) = true)

theorem identity53294 : scanCanonicalize (H12AffineFastState.compose env53294 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound53294 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16449,2341,1024,29789,4160,8492,16,21763,8193,64,10509,5393,17665,32040,1364,8493,256,21793,16465,513]

theorem envBound53295 : H12AffineFastState.Bounded env53295 := by
  intro p hp
  have h : env53295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53294_53295 : H12AffineEnvironment.transform 17 2341 env53294 = env53295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env53294 == env53295) = true)

theorem identity53295 : scanCanonicalize (H12AffineFastState.compose env53295 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53295 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16449,2341,1024,21761,4160,112,16,21763,349,64,2129,5393,17665,23668,1364,113,256,21793,16465,513]

theorem envBound53296 : H12AffineFastState.Bounded env53296 := by
  intro p hp
  have h : env53296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53295_53296 : H12AffineEnvironment.transform 12 348 env53295 = env53296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53295 == env53296) = true)

theorem identity53296 : scanCanonicalize (H12AffineFastState.compose env53296 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53296 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5441,2341,1024,1,4160,112,16,3,349,64,2129,5393,4097,2420,1364,113,256,33,5457,513]

theorem envBound53297 : H12AffineFastState.Bounded env53297 := by
  intro p hp
  have h : env53297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53296_53297 : H12AffineEnvironment.transform 13 5376 env53296 = env53297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53296 == env53297) = true)

theorem identity53297 : scanCanonicalize (H12AffineFastState.compose env53297 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53297 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53298 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,5392,2341,1024,1,4113,33,16,3,268,17,2048,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound53298 : H12AffineFastState.Bounded env53298 := by
  intro p hp
  have h : env53298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53297_53298 : H12AffineEnvironment.transform 5 17 env53297 = env53298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53297 == env53298) = true)

theorem identity53298 : scanCanonicalize (H12AffineFastState.compose env53298 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53298 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53299 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,0,34,5173,2048,1024,1,4113,33,16,3,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound53299 : H12AffineFastState.Bounded env53299 := by
  intro p hp
  have h : env53299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53298_53299 : H12AffineEnvironment.transform 7 37 env53298 = env53299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53298 == env53299) = true)

def env53300 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,0,34,1029,2048,1024,1,33,33,16,3,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound53300 : H12AffineFastState.Bounded env53300 := by
  intro p hp
  have h : env53300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53299_53300 : H12AffineEnvironment.transform 11 48 env53299 = env53300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53299 == env53300) = true)

theorem identity53300 : scanCanonicalize (H12AffineFastState.compose env53300 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound53300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53301 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,48,40,1045,0,34,1029,1573,1024,1,33,33,16,3,41,17,1573,1028,49,1573,1056,32,37,33,1045,513]

theorem envBound53301 : H12AffineFastState.Bounded env53301 := by
  intro p hp
  have h : env53301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53300_53301 : H12AffineEnvironment.transform 10 1573 env53300 = env53301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env53300 == env53301) = true)

def env53302 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,48,40,33,0,34,49,529,52,1,33,33,16,3,41,17,529,48,49,529,20,32,37,33,33,513]

theorem envBound53302 : H12AffineFastState.Bounded env53302 := by
  intro p hp
  have h : env53302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53301_53302 : H12AffineEnvironment.transform 9 52 env53301 = env53302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53301 == env53302) = true)

theorem identity53302 : scanCanonicalize (H12AffineFastState.compose env53302 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound53302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53303 : List Nat := [2,4,8,16,32,17,9,37,42,52,59,48,40,33,0,34,49,59,52,1,33,33,16,3,41,17,59,48,49,59,20,32,37,33,33,43]

theorem envBound53303 : H12AffineFastState.Bounded env53303 := by
  intro p hp
  have h : env53303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53302_53303 : H12AffineEnvironment.transform 8 42 env53302 = env53303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env53302 == env53303) = true)

def leafEnv53303 : List Nat := [2,4,8,16,32,17,9,37,42,52,59,48,40,33,0,34,49,59,52,1,33,33,16,3,20,41,1,17,59,48,49,59,20,32,37,33,4,35,33,43,1,33,0]

def active53303 : List Nat := [0,1,2,3,4]

def tree53303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53303 : H12WitnessSearch.Good tree53303 := H12GlobalWitnessIndex.good

theorem leafIdentity53303 : H12AffineFastState.composeSystem env53303 rootObs = leafEnv53303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53303 rootObs == leafEnv53303) = true)

theorem terminalChecked53303 : H12PackedTerminal.terminalCheckFast leafEnv53303 active53303 tree53303 = true := by decide +kernel

def env53304 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,48,40,32,0,34,48,528,53,1,33,33,16,3,41,17,528,49,49,528,21,32,37,33,32,513]

theorem envBound53304 : H12AffineFastState.Bounded env53304 := by
  intro p hp
  have h : env53304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53301_53304 : H12AffineEnvironment.transform 9 53 env53301 = env53304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53301 == env53304) = true)

def env53305 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,0,34,1028,2048,1024,1,32,33,16,3,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound53305 : H12AffineFastState.Bounded env53305 := by
  intro p hp
  have h : env53305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53299_53305 : H12AffineEnvironment.transform 11 49 env53299 = env53305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53299 == env53305) = true)

theorem identity53305 : scanCanonicalize (H12AffineFastState.compose env53305 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound53305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53306 : List Nat := [2,4,8,16,32,17,9,37,512,1024,529,49,40,1044,0,34,1028,529,1024,1,32,33,16,3,41,17,529,1029,48,529,1056,32,37,33,1044,513]

theorem envBound53306 : H12AffineFastState.Bounded env53306 := by
  intro p hp
  have h : env53306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53305_53306 : H12AffineEnvironment.transform 10 529 env53305 = env53306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env53305 == env53306) = true)

def env53307 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,49,40,32,0,34,48,529,52,1,32,33,16,3,41,17,529,49,48,529,20,32,37,33,32,513]

theorem envBound53307 : H12AffineFastState.Bounded env53307 := by
  intro p hp
  have h : env53307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53306_53307 : H12AffineEnvironment.transform 9 52 env53306 = env53307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53306 == env53307) = true)

theorem identity53307 : scanCanonicalize (H12AffineFastState.compose env53307 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound53307 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53308 : List Nat := [2,4,8,16,32,17,9,37,43,52,58,49,40,32,0,34,48,58,52,1,32,33,16,3,41,17,58,49,48,58,20,32,37,33,32,42]

theorem envBound53308 : H12AffineFastState.Bounded env53308 := by
  intro p hp
  have h : env53308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53307_53308 : H12AffineEnvironment.transform 8 43 env53307 = env53308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env53307 == env53308) = true)

def leafEnv53308 : List Nat := [2,4,8,16,32,17,9,37,43,52,58,49,40,32,0,34,48,58,52,1,32,33,16,3,20,41,1,17,58,49,48,58,20,32,37,33,4,35,32,42,1,32,0]

def active53308 : List Nat := [0,1,2,3,4]

def tree53308 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53308 : H12WitnessSearch.Good tree53308 := H12GlobalWitnessIndex.good

theorem leafIdentity53308 : H12AffineFastState.composeSystem env53308 rootObs = leafEnv53308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53308 rootObs == leafEnv53308) = true)

theorem terminalChecked53308 : H12PackedTerminal.terminalCheckFast leafEnv53308 active53308 tree53308 = true := by decide +kernel

def env53309 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,49,40,33,0,34,49,529,53,1,32,33,16,3,41,17,529,48,48,529,21,32,37,33,33,513]

theorem envBound53309 : H12AffineFastState.Bounded env53309 := by
  intro p hp
  have h : env53309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53306_53309 : H12AffineEnvironment.transform 9 53 env53306 = env53309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53306 == env53309) = true)

def env53310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4161,272393,17,41311,8193,64,56656,5392,17665,291852,1365,318549,256,21793,46093,512]

theorem envBound53310 : H12AffineFastState.Bounded env53310 := by
  intro p hp
  have h : env53310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53292_53310 : H12AffineEnvironment.transform 20 4161 env53292 = env53310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53292 == env53310) = true)

theorem identity53310 : scanCanonicalize (H12AffineFastState.compose env53310 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound53310 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,56577,1024,32769,4161,62728,17,41311,8193,64,56656,5392,17665,43277,1365,340,256,21793,46093,512]

theorem envBound53311 : H12AffineFastState.Bounded env53311 := by
  intro p hp
  have h : env53311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53310_53311 : H12AffineEnvironment.transform 17 56577 env53310 = env53311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env53310 == env53311) = true)

theorem identity53311 : scanCanonicalize (H12AffineFastState.compose env53311 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound53311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8202,16692,10280,1024,29992,4161,33,17,21622,8193,64,10361,5392,17665,23588,1365,340,256,21793,16676,512]

theorem envBound53312 : H12AffineFastState.Bounded env53312 := by
  intro p hp
  have h : env53312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53311_53312 : H12AffineEnvironment.transform 14 29993 env53311 = env53312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env53311 == env53312) = true)

theorem identity53312 : scanCanonicalize (H12AffineFastState.compose env53312 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 8201) := by decide +kernel

theorem selectedBound53312 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env53313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,8201,5408,8202,8509,10280,1024,5409,4161,33,17,13439,8193,64,10361,5392,9480,15405,1365,340,256,13608,8493,512]

theorem envBound53313 : H12AffineFastState.Bounded env53313 := by
  intro p hp
  have h : env53313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53312_53313 : H12AffineEnvironment.transform 13 8201 env53312 = env53313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8201 env53312 == env53313) = true)

theorem identity53313 : scanCanonicalize (H12AffineFastState.compose env53313 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 3400) := by decide +kernel

theorem selectedBound53313 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env53314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3400,3393,5408,3394,3189,1376,1024,5409,4161,33,17,6455,3401,64,1329,5392,2112,4453,1365,340,256,6240,3173,512]

theorem envBound53314 : H12AffineFastState.Bounded env53314 := by
  intro p hp
  have h : env53314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53313_53314 : H12AffineEnvironment.transform 12 3400 env53313 = env53314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3400 env53313 == env53314) = true)

theorem identity53314 : scanCanonicalize (H12AffineFastState.compose env53314 (packedSelected [0,1,4,6,7,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound53314 : packedSelected [0,1,4,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env53315 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,2089,2080,4161,2083,2324,1,353,4160,4161,33,17,6455,2088,64,80,4209,2112,4453,52,340,256,6240,2308,512]

theorem envBound53315 : H12AffineFastState.Bounded env53315 := by
  intro p hp
  have h : env53315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53314_53315 : H12AffineEnvironment.transform 9 353 env53314 = env53315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env53314 == env53315) = true)

theorem identity53315 : scanCanonicalize (H12AffineFastState.compose env53315 (packedSelected [0,6,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound53315 : packedSelected [0,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env53316 : List Nat := [2,4,8,16,32,64,9,84,512,53,2048,4096,2089,2080,4161,2083,2112,1,53,4160,4161,33,17,6243,2088,64,80,4209,2112,4145,52,0,84,6240,2128,512]

theorem envBound53316 : H12AffineFastState.Bounded env53316 := by
  intro p hp
  have h : env53316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53315_53316 : H12AffineEnvironment.transform 7 84 env53315 = env53316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env53315 == env53316) = true)

theorem identity53316 : scanCanonicalize (H12AffineFastState.compose env53316 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound53316 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53317 : List Nat := [2,4,8,16,32,64,9,84,512,53,81,4096,120,113,4161,114,17,1,53,4160,4161,33,17,4146,121,64,80,4209,17,4145,52,0,84,4145,1,512]

theorem envBound53317 : H12AffineFastState.Bounded env53317 := by
  intro p hp
  have h : env53317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53316_53317 : H12AffineEnvironment.transform 10 81 env53316 = env53317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env53316 == env53317) = true)

theorem identity53317 : scanCanonicalize (H12AffineFastState.compose env53317 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53317 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53318 : List Nat := [2,4,8,16,32,48,9,36,512,53,33,4096,8,1,4145,2,17,1,53,4144,4145,33,17,4146,9,48,32,4097,17,4145,52,0,36,4145,1,512]

theorem envBound53318 : H12AffineFastState.Bounded env53318 := by
  intro p hp
  have h : env53318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53317_53318 : H12AffineEnvironment.transform 5 48 env53317 = env53318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53317 == env53318) = true)

theorem identity53318 : scanCanonicalize (H12AffineFastState.compose env53318 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound53318 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53319 : List Nat := [2,4,8,16,32,48,9,36,512,53,33,570,8,1,523,2,17,1,53,522,523,33,17,520,9,48,32,571,17,523,52,0,36,523,1,512]

theorem envBound53319 : H12AffineFastState.Bounded env53319 := by
  intro p hp
  have h : env53319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53318_53319 : H12AffineEnvironment.transform 11 570 env53318 = env53319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env53318 == env53319) = true)

theorem identity53319 : scanCanonicalize (H12AffineFastState.compose env53319 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound53319 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53320 : List Nat := [2,4,8,16,8,24,9,12,512,29,9,530,8,1,523,2,17,1,29,522,523,9,17,520,9,24,8,531,17,523,28,0,12,523,1,512]

theorem envBound53320 : H12AffineFastState.Bounded env53320 := by
  intro p hp
  have h : env53320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53319_53320 : H12AffineEnvironment.transform 4 8 env53319 = env53320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env53319 == env53320) = true)

theorem identity53320 : scanCanonicalize (H12AffineFastState.compose env53320 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound53320 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53321 : List Nat := [2,4,8,16,8,24,9,12,3,29,9,17,8,1,8,2,17,1,29,9,8,9,17,11,9,24,8,16,17,8,28,0,12,8,1,3]

theorem envBound53321 : H12AffineFastState.Bounded env53321 := by
  intro p hp
  have h : env53321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53320_53321 : H12AffineEnvironment.transform 8 3 env53320 = env53321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env53320 == env53321) = true)

theorem identity53321 : scanCanonicalize (H12AffineFastState.compose env53321 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53322 : List Nat := [2,4,0,16,0,16,1,4,3,21,1,17,0,1,0,2,17,1,21,1,0,1,17,3,1,16,0,16,17,0,20,0,4,0,1,3]

theorem envBound53322 : H12AffineFastState.Bounded env53322 := by
  intro p hp
  have h : env53322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53321_53322 : H12AffineEnvironment.transform 2 0 env53321 = env53322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53321 == env53322) = true)

theorem identity53322 : scanCanonicalize (H12AffineFastState.compose env53322 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53323 : List Nat := [2,1,0,16,0,16,1,1,3,16,1,17,0,1,0,2,17,1,16,1,0,1,17,3,1,16,0,16,17,0,17,0,1,0,1,3]

theorem envBound53323 : H12AffineFastState.Bounded env53323 := by
  intro p hp
  have h : env53323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53322_53323 : H12AffineEnvironment.transform 1 1 env53322 = env53323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53322 == env53323) = true)

def env53324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98780,8328,64,2259213,2098513,17665,2543696,2102685,2411676,256,21793,46212,2175563]

theorem envBound53324 : H12AffineFastState.Bounded env53324 := by
  intro p hp
  have h : env53324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53275_53324 : H12AffineEnvironment.transform 21 272513 env53275 = env53324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53275 == env53324) = true)

theorem identity53324 : scanCanonicalize (H12AffineFastState.compose env53324 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound53324 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272513,73754,98780,8328,64,215367,79131,17665,516122,75223,392406,256,21793,46212,513]

theorem envBound53325 : H12AffineFastState.Bounded env53325 := by
  intro p hp
  have h : env53325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53324_53325 : H12AffineEnvironment.transform 20 77898 env53324 = env53325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env53324 == env53325) = true)

def env53326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272393,73754,98644,8192,64,215367,79131,17665,516122,75103,392286,256,21793,46092,513]

theorem envBound53326 : H12AffineFastState.Bounded env53326 := by
  intro p hp
  have h : env53326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53325_53326 : H12AffineEnvironment.transform 6 8 env53325 = env53326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53325 == env53326) = true)

theorem identity53326 : scanCanonicalize (H12AffineFastState.compose env53326 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound53326 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77898,272393,73754,98644,8192,64,10589,79131,17665,294912,75103,392286,256,21793,46092,513]

theorem envBound53327 : H12AffineFastState.Bounded env53327 := by
  intro p hp
  have h : env53327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53326_53327 : H12AffineEnvironment.transform 16 90138 env53326 = env53327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env53326 == env53327) = true)

theorem identity53327 : scanCanonicalize (H12AffineFastState.compose env53327 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53327 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env53328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,272393,17,41311,8192,64,10589,5392,17665,294912,1364,318549,256,21793,46092,513]

theorem envBound53328 : H12AffineFastState.Bounded env53328 := by
  intro p hp
  have h : env53328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53327_53328 : H12AffineEnvironment.transform 15 8203 env53327 = env53328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53327 == env53328) = true)

theorem identity53328 : scanCanonicalize (H12AffineFastState.compose env53328 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound53328 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1024,32769,4161,41340,17,41311,8192,64,10589,5392,17665,2421,1364,21792,256,21793,46092,513]

theorem envBound53329 : H12AffineFastState.Bounded env53329 := by
  intro p hp
  have h : env53329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53328_53329 : H12AffineEnvironment.transform 17 35189 env53328 = env53329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env53328 == env53329) = true)

theorem identity53329 : scanCanonicalize (H12AffineFastState.compose env53329 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound53329 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,8203,16401,3125,1024,1345,4161,9276,17,9247,8192,64,10589,5392,17665,2421,1364,21792,256,21793,12620,513]

theorem envBound53330 : H12AffineFastState.Bounded env53330 := by
  intro p hp
  have h : env53330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53329_53330 : H12AffineEnvironment.transform 14 1344 env53329 = env53330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env53329 == env53330) = true)

theorem identity53330 : scanCanonicalize (H12AffineFastState.compose env53330 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound53330 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,16384,1344,1379,16401,3125,1024,1345,4161,340,17,375,1384,64,3125,5392,17665,2421,1364,21792,256,21793,5156,513]

theorem envBound53331 : H12AffineFastState.Bounded env53331 := by
  intro p hp
  have h : env53331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53330_53331 : H12AffineEnvironment.transform 12 1384 env53330 = env53331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env53330 == env53331) = true)

theorem identity53331 : scanCanonicalize (H12AffineFastState.compose env53331 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53331 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,1384,16384,1344,1379,16401,1077,1024,1345,4161,340,17,375,1384,64,1077,5392,17665,373,1364,21792,256,21793,5156,513]

theorem envBound53332 : H12AffineFastState.Bounded env53332 := by
  intro p hp
  have h : env53332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53331_53332 : H12AffineEnvironment.transform 10 0 env53331 = env53332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53331 == env53332) = true)

theorem identity53332 : scanCanonicalize (H12AffineFastState.compose env53332 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound53332 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env53333 : List Nat := [2,4,8,16,32,64,8,256,512,100,0,4096,268,16384,292,263,16401,81,100,293,4161,340,17,375,268,64,81,4468,16741,373,304,20804,256,20805,4160,513]

theorem envBound53333 : H12AffineFastState.Bounded env53333 := by
  intro p hp
  have h : env53333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53332_53333 : H12AffineEnvironment.transform 9 100 env53332 = env53333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env53332 == env53333) = true)

theorem identity53333 : scanCanonicalize (H12AffineFastState.compose env53333 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53333 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53334 : List Nat := [2,4,8,16,32,64,8,256,512,100,0,4096,268,4113,292,263,4096,81,100,293,4161,340,17,375,268,64,81,4468,4468,373,304,341,256,340,4160,513]

theorem envBound53334 : H12AffineFastState.Bounded env53334 := by
  intro p hp
  have h : env53334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53333_53334 : H12AffineEnvironment.transform 13 4113 env53333 = env53334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53333 == env53334) = true)

theorem identity53334 : scanCanonicalize (H12AffineFastState.compose env53334 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53334 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53335 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,4096,268,4113,292,263,4096,0,53,293,4112,261,17,294,268,17,0,4389,4389,292,304,260,256,261,4113,513]

theorem envBound53335 : H12AffineFastState.Bounded env53335 := by
  intro p hp
  have h : env53335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53334_53335 : H12AffineEnvironment.transform 5 17 env53334 = env53335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53334 == env53335) = true)

theorem identity53335 : scanCanonicalize (H12AffineFastState.compose env53335 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound53335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53336 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,16,268,1,292,263,16,0,53,293,0,261,17,294,268,17,0,309,309,292,304,260,256,261,1,513]

theorem envBound53336 : H12AffineFastState.Bounded env53336 := by
  intro p hp
  have h : env53336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53335_53336 : H12AffineEnvironment.transform 11 16 env53335 = env53336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53335 == env53336) = true)

theorem identity53336 : scanCanonicalize (H12AffineFastState.compose env53336 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53336 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53337 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,1,1,34,16,0,53,0,0,32,17,3,41,17,0,16,16,1,21,33,37,32,1,513]

theorem envBound53337 : H12AffineFastState.Bounded env53337 := by
  intro p hp
  have h : env53337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53336_53337 : H12AffineEnvironment.transform 7 37 env53336 = env53337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53336 == env53337) = true)

theorem identity53337 : scanCanonicalize (H12AffineFastState.compose env53337 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53338 : List Nat := [2,4,8,0,32,1,8,37,512,37,0,0,41,1,1,34,0,0,37,0,0,32,1,3,41,1,0,0,0,1,5,33,37,32,1,513]

theorem envBound53338 : H12AffineFastState.Bounded env53338 := by
  intro p hp
  have h : env53338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53337_53338 : H12AffineEnvironment.transform 3 0 env53337 = env53338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53337 == env53338) = true)

theorem identity53338 : scanCanonicalize (H12AffineFastState.compose env53338 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound53338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53339 : List Nat := [2,4,8,0,11,1,8,14,512,14,0,0,2,1,1,9,0,0,14,0,0,11,1,3,2,1,0,0,0,1,5,10,14,11,1,513]

theorem envBound53339 : H12AffineFastState.Bounded env53339 := by
  intro p hp
  have h : env53339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53338_53339 : H12AffineEnvironment.transform 4 11 env53338 = env53339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env53338 == env53339) = true)

def env53340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272392,73754,98645,8193,64,215367,79131,17665,516122,75102,392287,256,21793,46093,513]

theorem envBound53340 : H12AffineFastState.Bounded env53340 := by
  intro p hp
  have h : env53340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53325_53340 : H12AffineEnvironment.transform 6 9 env53325 = env53340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53325 == env53340) = true)

def env53341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77898,32,73754,98645,8193,64,215367,79131,17665,247858,75102,119927,256,21793,46093,513]

theorem envBound53341 : H12AffineFastState.Bounded env53341 := by
  intro p hp
  have h : env53341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53340_53341 : H12AffineEnvironment.transform 17 10280 env53340 = env53341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53340 == env53341) = true)

def env53342 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98565,8193,16,215319,79131,17665,247858,75022,119847,256,21793,46093,513]

theorem envBound53342 : H12AffineFastState.Bounded env53342 := by
  intro p hp
  have h : env53342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53341_53342 : H12AffineEnvironment.transform 5 16 env53341 = env53342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53341 == env53342) = true)

theorem identity53342 : scanCanonicalize (H12AffineFastState.compose env53342 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53342 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53343 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10280,1024,1,77850,32,73754,65797,8193,16,215319,79131,17665,215090,75022,87079,256,21793,13325,513]

theorem envBound53343 : H12AffineFastState.Bounded env53343 := by
  intro p hp
  have h : env53343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53342_53343 : H12AffineEnvironment.transform 14 0 env53342 = env53343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53342 == env53343) = true)

theorem identity53343 : scanCanonicalize (H12AffineFastState.compose env53343 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound53343 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53344 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,5392,10280,1024,1,77850,32,73754,65797,8193,16,89095,79131,17665,89378,75022,87079,256,21793,13325,513]

theorem envBound53344 : H12AffineFastState.Bounded env53344 := by
  intro p hp
  have h : env53344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53343_53344 : H12AffineEnvironment.transform 16 5392 env53343 = env53344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env53343 == env53344) = true)

theorem identity53344 : scanCanonicalize (H12AffineFastState.compose env53344 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound53344 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53345 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,262,5392,10280,1024,1,12572,32,8476,3,8193,16,23809,13341,17665,23588,9224,21793,256,21793,13325,513]

theorem envBound53345 : H12AffineFastState.Bounded env53345 := by
  intro p hp
  have h : env53345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53344_53345 : H12AffineEnvironment.transform 15 262 env53344 = env53345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env53344 == env53345) = true)

theorem identity53345 : scanCanonicalize (H12AffineFastState.compose env53345 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound53345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53346 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,262,5392,10280,1024,1,12572,32,8476,3,8193,16,10508,13341,12556,10281,9224,8492,256,8492,13325,513]

theorem envBound53346 : H12AffineFastState.Bounded env53346 := by
  intro p hp
  have h : env53346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53345_53346 : H12AffineEnvironment.transform 13 13325 env53345 = env53346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env53345 == env53346) = true)

theorem identity53346 : scanCanonicalize (H12AffineFastState.compose env53346 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53346 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53347 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1024,1,4112,32,16,3,269,16,2048,5393,4096,2341,1284,32,256,32,5377,513]

theorem envBound53347 : H12AffineFastState.Bounded env53347 := by
  intro p hp
  have h : env53347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53346_53347 : H12AffineEnvironment.transform 12 268 env53346 = env53347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53346 == env53347) = true)

theorem identity53347 : scanCanonicalize (H12AffineFastState.compose env53347 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound53347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1313,0,262,1328,2340,1024,1,48,32,16,3,269,16,2048,1329,32,2341,1284,32,256,32,1313,513]

theorem envBound53348 : H12AffineFastState.Bounded env53348 := by
  intro p hp
  have h : env53348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53347_53348 : H12AffineEnvironment.transform 11 32 env53347 = env53348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env53347 == env53348) = true)

theorem identity53348 : scanCanonicalize (H12AffineFastState.compose env53348 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound53348 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53349 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,32,268,1313,0,262,1328,1039,1024,1,48,32,16,3,269,16,1323,1329,32,1038,1284,32,256,32,1313,513]

theorem envBound53349 : H12AffineFastState.Bounded env53349 := by
  intro p hp
  have h : env53349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53348_53349 : H12AffineEnvironment.transform 10 1323 env53348 = env53349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env53348 == env53349) = true)

theorem identity53349 : scanCanonicalize (H12AffineFastState.compose env53349 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound53349 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53350 : List Nat := [2,4,8,16,32,16,9,256,270,1024,1323,32,268,1313,0,262,1328,1039,1024,1,48,32,16,3,269,16,1323,1329,32,1038,1284,32,256,32,1313,271]

theorem envBound53350 : H12AffineFastState.Bounded env53350 := by
  intro p hp
  have h : env53350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53349_53350 : H12AffineEnvironment.transform 8 270 env53349 = env53350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env53349 == env53350) = true)

theorem identity53350 : scanCanonicalize (H12AffineFastState.compose env53350 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound53350 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53351 : List Nat := [2,4,8,16,32,16,9,31,17,1024,1076,32,19,1086,0,25,1071,1039,1024,1,48,32,16,3,18,16,1076,1070,32,1038,1051,32,31,32,1086,16]

theorem envBound53351 : H12AffineFastState.Bounded env53351 := by
  intro p hp
  have h : env53351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53350_53351 : H12AffineEnvironment.transform 7 31 env53350 = env53351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env53350 == env53351) = true)

theorem identity53351 : scanCanonicalize (H12AffineFastState.compose env53351 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound53351 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53352 : List Nat := [2,4,8,16,32,16,9,31,17,47,27,32,19,17,0,25,0,32,47,1,48,32,16,3,18,16,27,1,32,33,52,32,31,32,17,16]

theorem envBound53352 : H12AffineFastState.Bounded env53352 := by
  intro p hp
  have h : env53352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53351_53352 : H12AffineEnvironment.transform 9 47 env53351 = env53352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env53351 == env53352) = true)

theorem identity53352 : scanCanonicalize (H12AffineFastState.compose env53352 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53352 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53353 : List Nat := [2,4,8,1,32,1,9,14,0,47,10,32,2,0,0,8,0,32,47,1,33,32,1,3,3,1,10,1,32,33,37,32,14,32,0,1]

theorem envBound53353 : H12AffineFastState.Bounded env53353 := by
  intro p hp
  have h : env53353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53352_53353 : H12AffineEnvironment.transform 3 1 env53352 = env53353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53352 == env53353) = true)

theorem identity53353 : scanCanonicalize (H12AffineFastState.compose env53353 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound53353 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53354 : List Nat := [2,4,8,1,5,1,9,14,0,10,10,5,2,0,0,8,0,5,10,1,4,5,1,3,3,1,10,1,5,4,0,5,14,5,0,1]

theorem envBound53354 : H12AffineFastState.Bounded env53354 := by
  intro p hp
  have h : env53354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53353_53354 : H12AffineEnvironment.transform 4 5 env53353 = env53354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env53353 == env53354) = true)

theorem identity53354 : scanCanonicalize (H12AffineFastState.compose env53354 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53354 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env53355 : List Nat := [2,4,3,1,5,1,2,5,0,1,1,5,2,0,0,3,0,5,1,1,4,5,1,3,3,1,1,1,5,4,0,5,5,5,0,1]

theorem envBound53355 : H12AffineFastState.Bounded env53355 := by
  intro p hp
  have h : env53355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53354_53355 : H12AffineEnvironment.transform 2 3 env53354 = env53355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53354 == env53355) = true)

theorem identity53355 : scanCanonicalize (H12AffineFastState.compose env53355 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53356 : List Nat := [2,2,3,1,3,1,2,3,0,1,1,3,2,0,0,3,0,3,1,1,2,3,1,3,3,1,1,1,3,2,0,3,3,3,0,1]

theorem envBound53356 : H12AffineFastState.Bounded env53356 := by
  intro p hp
  have h : env53356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53355_53356 : H12AffineEnvironment.transform 1 2 env53355 = env53356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53355 == env53356) = true)

def env53357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98564,8193,17,215318,79131,17665,247858,75023,119846,256,21793,46093,513]

theorem envBound53357 : H12AffineFastState.Bounded env53357 := by
  intro p hp
  have h : env53357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53341_53357 : H12AffineEnvironment.transform 5 17 env53341 = env53357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53341 == env53357) = true)

theorem identity53357 : scanCanonicalize (H12AffineFastState.compose env53357 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53357 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53358 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,131072,10280,1024,32769,12572,32,8477,32771,8193,17,149521,13340,17665,182581,9224,54561,256,21793,46093,513]

theorem envBound53358 : H12AffineFastState.Bounded env53358 := by
  intro p hp
  have h : env53358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53357_53358 : H12AffineEnvironment.transform 15 263 env53357 = env53358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53357 == env53358) = true)

theorem identity53358 : scanCanonicalize (H12AffineFastState.compose env53358 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53358 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env53359 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,5393,10280,1024,32769,12572,32,8477,32771,8193,17,23808,13340,17665,56356,9224,54561,256,21793,46093,513]

theorem envBound53359 : H12AffineFastState.Bounded env53359 := by
  intro p hp
  have h : env53359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53358_53359 : H12AffineEnvironment.transform 16 5393 env53358 = env53359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53358 == env53359) = true)

theorem identity53359 : scanCanonicalize (H12AffineFastState.compose env53359 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53359 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env53360 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,263,5393,10280,1024,32769,12572,32,8477,32771,8193,17,2049,13340,4096,35109,9224,32800,256,32,46093,513]

theorem envBound53360 : H12AffineFastState.Bounded env53360 := by
  intro p hp
  have h : env53360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53359_53360 : H12AffineEnvironment.transform 13 5377 env53359 = env53360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53359 == env53360) = true)

theorem identity53360 : scanCanonicalize (H12AffineFastState.compose env53360 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53360 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53361 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,263,5393,10280,1024,0,12572,32,8477,2,8193,17,2049,13340,4096,2340,9224,33,256,32,13324,513]

theorem envBound53361 : H12AffineFastState.Bounded env53361 := by
  intro p hp
  have h : env53361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53360_53361 : H12AffineEnvironment.transform 14 1 env53360 = env53361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53360 == env53361) = true)

theorem identity53361 : scanCanonicalize (H12AffineFastState.compose env53361 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound53361 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env53362 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,8192,4357,1,263,4373,10280,4,0,12572,32,8477,2,8193,17,2049,12312,4096,2340,8204,33,256,32,12296,513]

theorem envBound53362 : H12AffineFastState.Bounded env53362 := by
  intro p hp
  have h : env53362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53361_53362 : H12AffineEnvironment.transform 9 4 env53361 = env53362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env53361 == env53362) = true)

theorem identity53362 : scanCanonicalize (H12AffineFastState.compose env53362 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound53362 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env53363 : List Nat := [2,4,8,16,32,17,9,52,512,4,2048,4096,8192,4145,1,51,4129,10280,4,0,12328,32,8233,2,8193,17,2049,12312,4096,2064,8204,33,52,32,12296,513]

theorem envBound53363 : H12AffineFastState.Bounded env53363 := by
  intro p hp
  have h : env53363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53362_53363 : H12AffineEnvironment.transform 7 52 env53362 = env53363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env53362 == env53363) = true)

theorem identity53363 : scanCanonicalize (H12AffineFastState.compose env53363 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound53363 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env53364 : List Nat := [2,4,8,16,32,17,9,52,512,4,2048,4096,57,4145,1,51,4129,2065,4,0,4113,32,16,2,56,17,2049,4129,4096,2064,53,33,52,32,4145,513]

theorem envBound53364 : H12AffineFastState.Bounded env53364 := by
  intro p hp
  have h : env53364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53363_53364 : H12AffineEnvironment.transform 12 57 env53363 = env53364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env53363 == env53364) = true)

theorem identity53364 : scanCanonicalize (H12AffineFastState.compose env53364 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53365 : List Nat := [2,4,8,1,32,0,9,37,512,4,2048,4096,40,4128,1,34,4129,2048,4,0,4096,32,1,2,41,0,2049,4129,4096,2049,36,33,37,32,4128,513]

theorem envBound53365 : H12AffineFastState.Bounded env53365 := by
  intro p hp
  have h : env53365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53364_53365 : H12AffineEnvironment.transform 3 1 env53364 = env53365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53364 == env53365) = true)

theorem identity53365 : scanCanonicalize (H12AffineFastState.compose env53365 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53365 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53366 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,4096,8,4096,1,2,4097,2048,4,0,4096,0,1,2,9,0,2049,4097,4096,2049,4,1,5,0,4096,513]

theorem envBound53366 : H12AffineFastState.Bounded env53366 := by
  intro p hp
  have h : env53366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53365_53366 : H12AffineEnvironment.transform 4 0 env53365 = env53366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53365 == env53366) = true)

theorem identity53366 : scanCanonicalize (H12AffineFastState.compose env53366 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53367 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,1,8,1,1,2,0,2048,4,0,1,0,1,2,9,0,2049,0,1,2049,4,1,5,0,1,513]

theorem envBound53367 : H12AffineFastState.Bounded env53367 := by
  intro p hp
  have h : env53367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53366_53367 : H12AffineEnvironment.transform 11 1 env53366 = env53367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53366 == env53367) = true)

theorem identity53367 : scanCanonicalize (H12AffineFastState.compose env53367 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53368 : List Nat := [2,4,8,1,0,0,9,5,512,4,10,1,8,1,1,2,0,10,4,0,1,0,1,2,9,0,11,0,1,11,4,1,5,0,1,513]

theorem envBound53368 : H12AffineFastState.Bounded env53368 := by
  intro p hp
  have h : env53368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53367_53368 : H12AffineEnvironment.transform 10 10 env53367 = env53368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53367 == env53368) = true)

theorem identity53368 : scanCanonicalize (H12AffineFastState.compose env53368 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound53368 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53369 : List Nat := [2,4,8,1,0,0,9,5,11,4,10,1,8,1,1,2,0,10,4,0,1,0,1,2,9,0,11,0,1,11,4,1,5,0,1,10]

theorem envBound53369 : H12AffineFastState.Bounded env53369 := by
  intro p hp
  have h : env53369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53368_53369 : H12AffineEnvironment.transform 8 11 env53368 = env53369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env53368 == env53369) = true)

def env53370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77898,33,73754,98645,8193,64,215367,79131,17665,247859,75102,119926,256,21793,46093,513]

theorem envBound53370 : H12AffineFastState.Bounded env53370 := by
  intro p hp
  have h : env53370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53340_53370 : H12AffineEnvironment.transform 17 10281 env53340 = env53370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53340 == env53370) = true)

theorem identity53370 : scanCanonicalize (H12AffineFastState.compose env53370 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53370 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4160,33,16,41311,8193,64,158029,5393,17665,190521,1364,62588,256,21793,46093,513]

theorem envBound53371 : H12AffineFastState.Bounded env53371 := by
  intro p hp
  have h : env53371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53370_53371 : H12AffineEnvironment.transform 15 8202 env53370 = env53371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53370 == env53371) = true)

theorem identity53371 : scanCanonicalize (H12AffineFastState.compose env53371 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27740) := by decide +kernel

theorem selectedBound53371 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27740,10281,1024,32769,4160,33,16,41311,8193,64,1297,5393,17665,33893,1364,62588,256,21793,46093,513]

theorem envBound53372 : H12AffineFastState.Bounded env53372 := by
  intro p hp
  have h : env53372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53371_53372 : H12AffineEnvironment.transform 16 27740 env53371 = env53372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27740 env53371 == env53372) = true)

theorem identity53372 : scanCanonicalize (H12AffineFastState.compose env53372 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53372 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env53373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19573,2048,1024,32769,4160,33,16,33142,40,64,1297,5393,17665,33893,1364,54357,256,21793,37924,513]

theorem envBound53373 : H12AffineFastState.Bounded env53373 := by
  intro p hp
  have h : env53373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53372_53373 : H12AffineEnvironment.transform 12 41 env53372 = env53373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53372 == env53373) = true)

theorem identity53373 : scanCanonicalize (H12AffineFastState.compose env53373 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound53373 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5409,32768,35,6484,2048,1024,32769,4160,33,16,33142,40,64,1297,5393,4128,33893,1364,33140,256,0,37924,513]

theorem envBound53374 : H12AffineFastState.Bounded env53374 := by
  intro p hp
  have h : env53374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53373_53374 : H12AffineEnvironment.transform 13 5409 env53373 = env53374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env53373 == env53374) = true)

theorem identity53374 : scanCanonicalize (H12AffineFastState.compose env53374 (packedSelected [11,23] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound53374 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env53375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1376,4096,41,5409,32768,35,5172,1376,1024,32769,4160,33,16,33142,40,64,1297,5393,4128,33893,1364,33140,256,0,37924,513]

theorem envBound53375 : H12AffineFastState.Bounded env53375 := by
  intro p hp
  have h : env53375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53374_53375 : H12AffineEnvironment.transform 10 1376 env53374 = env53375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env53374 == env53375) = true)

theorem identity53375 : scanCanonicalize (H12AffineFastState.compose env53375 (packedSelected [4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound53375 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53376 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,4096,41,4113,32768,35,4356,80,304,32769,4160,33,16,33142,40,64,33,4129,4128,33109,100,33140,256,0,37140,513]

theorem envBound53376 : H12AffineFastState.Bounded env53376 := by
  intro p hp
  have h : env53376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53375_53376 : H12AffineEnvironment.transform 9 304 env53375 = env53376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env53375 == env53376) = true)

theorem identity53376 : scanCanonicalize (H12AffineFastState.compose env53376 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53376 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env53377 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,4096,41,4113,4113,35,4356,80,304,4112,4160,33,16,4455,40,64,33,4129,4128,4420,100,4453,256,0,261,513]

theorem envBound53377 : H12AffineFastState.Bounded env53377 := by
  intro p hp
  have h : env53377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53376_53377 : H12AffineEnvironment.transform 14 4113 env53376 = env53377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env53376 == env53377) = true)

theorem identity53377 : scanCanonicalize (H12AffineFastState.compose env53377 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound53377 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53378 : List Nat := [2,4,8,16,32,64,9,256,356,304,80,4096,41,4113,4113,35,4356,80,304,4112,4160,33,16,4455,40,64,33,4129,4128,4420,100,4453,256,0,261,357]

theorem envBound53378 : H12AffineFastState.Bounded env53378 := by
  intro p hp
  have h : env53378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53377_53378 : H12AffineEnvironment.transform 8 356 env53377 = env53378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env53377 == env53378) = true)

theorem identity53378 : scanCanonicalize (H12AffineFastState.compose env53378 (packedSelected [10,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53378 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env53379 : List Nat := [2,4,8,16,32,0,9,256,292,304,16,4096,41,4113,4113,35,4356,16,304,4112,4096,33,16,4391,40,0,33,4129,4128,4356,36,4389,256,0,261,293]

theorem envBound53379 : H12AffineFastState.Bounded env53379 := by
  intro p hp
  have h : env53379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53378_53379 : H12AffineEnvironment.transform 5 0 env53378 = env53379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53378 == env53379) = true)

theorem identity53379 : scanCanonicalize (H12AffineFastState.compose env53379 (packedSelected [1,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53379 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env53380 : List Nat := [2,4,8,16,1,0,9,256,261,273,16,4096,8,4113,4113,2,4356,16,273,4112,4096,0,16,4358,9,0,0,4096,4097,4356,5,4356,256,0,261,260]

theorem envBound53380 : H12AffineFastState.Bounded env53380 := by
  intro p hp
  have h : env53380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53379_53380 : H12AffineEnvironment.transform 4 1 env53379 = env53380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53379 == env53380) = true)

theorem identity53380 : scanCanonicalize (H12AffineFastState.compose env53380 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53380 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env53381 : List Nat := [2,4,8,16,1,0,9,21,16,4,16,4096,8,4113,4113,2,4113,16,4,4112,4096,0,16,4115,9,0,0,4096,4097,4113,5,4113,21,0,16,17]

theorem envBound53381 : H12AffineFastState.Bounded env53381 := by
  intro p hp
  have h : env53381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53380_53381 : H12AffineEnvironment.transform 7 21 env53380 = env53381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53380 == env53381) = true)

theorem identity53381 : scanCanonicalize (H12AffineFastState.compose env53381 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53382 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,4096,8,4097,4097,2,4097,0,4,4096,4096,0,0,4099,9,0,0,4096,4097,4097,5,4097,5,0,0,1]

theorem envBound53382 : H12AffineFastState.Bounded env53382 := by
  intro p hp
  have h : env53382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53381_53382 : H12AffineEnvironment.transform 3 0 env53381 = env53382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53381 == env53382) = true)

def env53383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98781,8328,64,6705548,2098512,17664,2543697,2102685,6349852,256,21793,46212,2175563]

theorem envBound53383 : H12AffineFastState.Bounded env53383 := by
  intro p hp
  have h : env53383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53274_53383 : H12AffineEnvironment.transform 22 2101329 env53274 = env53383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env53274 == env53383) = true)

def env53384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98781,8328,64,2259212,2098512,17664,2543697,2102685,2411676,256,21793,46212,2175563]

theorem envBound53384 : H12AffineFastState.Bounded env53384 := by
  intro p hp
  have h : env53384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53383_53384 : H12AffineEnvironment.transform 21 272512 env53383 = env53384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53383 == env53384) = true)

theorem identity53384 : scanCanonicalize (H12AffineFastState.compose env53384 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound53384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,2097152,272512,2101329,21763,8328,64,2259212,2098512,17664,2543697,2102685,2411676,256,21793,46212,2156181]

theorem envBound53385 : H12AffineFastState.Bounded env53385 := by
  intro p hp
  have h : env53385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53384_53385 : H12AffineEnvironment.transform 15 54494 env53384 = env53385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env53384 == env53385) = true)

def env53386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,2097152,272392,2101329,21763,8192,64,2259212,2098512,17664,2543697,2102549,2411540,256,21793,46092,2156061]

theorem envBound53386 : H12AffineFastState.Bounded env53386 := by
  intro p hp
  have h : env53386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53385_53386 : H12AffineEnvironment.transform 6 8 env53385 = env53386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53385 == env53386) = true)

theorem identity53386 : scanCanonicalize (H12AffineFastState.compose env53386 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound53386 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env53387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157752,1024,32769,2097152,147504,2101329,21763,8192,64,2259212,2098512,17664,2144361,2102549,2270252,256,21793,46092,2156061]

theorem envBound53387 : H12AffineFastState.Bounded env53387 := by
  intro p hp
  have h : env53387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53386_53387 : H12AffineEnvironment.transform 17 157752 env53386 = env53387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env53386 == env53387) = true)

theorem identity53387 : scanCanonicalize (H12AffineFastState.compose env53387 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound53387 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,57677,35189,1024,32769,2097152,41341,2101329,21763,8192,64,2136129,2098512,17664,2144361,2102549,2114913,256,21793,46092,2156061]

theorem envBound53388 : H12AffineFastState.Bounded env53388 := by
  intro p hp
  have h : env53388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53387_53388 : H12AffineEnvironment.transform 16 57677 env53387 = env53388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env53387 == env53388) = true)

theorem identity53388 : scanCanonicalize (H12AffineFastState.compose env53388 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 45341) := by decide +kernel

theorem selectedBound53388 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,57677,35189,1024,32769,45341,41341,41292,21763,8192,64,10588,46157,17664,2420,41992,62588,256,21793,46092,22272]

theorem envBound53389 : H12AffineFastState.Bounded env53389 := by
  intro p hp
  have h : env53389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53388_53389 : H12AffineEnvironment.transform 20 45341 env53388 = env53389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45341 env53388 == env53389) = true)

theorem identity53389 : scanCanonicalize (H12AffineFastState.compose env53389 (packedSelected [1,4,5,9,10,12,14,15,16,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound53389 : packedSelected [1,4,5,9,10,12,14,15,16,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,41342,37989,35189,1024,32769,45341,41341,41292,8235,8192,64,10588,46157,12328,2420,41992,33108,256,8201,46092,8744]

theorem envBound53390 : H12AffineFastState.Bounded env53390 := by
  intro p hp
  have h : env53390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53389_53390 : H12AffineEnvironment.transform 13 13608 env53389 = env53390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env53389 == env53390) = true)

theorem identity53390 : scanCanonicalize (H12AffineFastState.compose env53390 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53390 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env53391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,34,13625,10281,1024,8541,4161,33,16,8235,8192,64,10588,5393,12328,2420,1364,8200,256,8201,5456,8744]

theorem envBound53391 : H12AffineFastState.Bounded env53391 := by
  intro p hp
  have h : env53391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53390_53391 : H12AffineEnvironment.transform 14 8540 env53390 = env53391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53390 == env53391) = true)

theorem identity53391 : scanCanonicalize (H12AffineFastState.compose env53391 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53391 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53392 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,8192,13576,8540,2,13593,10249,1024,8541,4161,1,16,8203,8192,64,10588,5393,12296,2388,1364,8200,256,8201,5456,8712]

theorem envBound53392 : H12AffineFastState.Bounded env53392 := by
  intro p hp
  have h : env53392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53391_53392 : H12AffineEnvironment.transform 4 0 env53391 = env53392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53391 == env53392) = true)

theorem identity53392 : scanCanonicalize (H12AffineFastState.compose env53392 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53392 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53393 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,8192,12312,8540,2,12297,10249,272,8541,4161,1,16,8203,8192,64,10588,4097,12296,2388,68,8200,256,8201,4160,8712]

theorem envBound53393 : H12AffineFastState.Bounded env53393 := by
  intro p hp
  have h : env53393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53392_53393 : H12AffineEnvironment.transform 9 272 env53392 = env53393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53392 == env53393) = true)

theorem identity53393 : scanCanonicalize (H12AffineFastState.compose env53393 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53393 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env53394 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,349,4421,1,2,4436,2388,272,0,4161,1,16,342,349,64,2049,4097,4437,2388,68,341,256,340,4160,853]

theorem envBound53394 : H12AffineFastState.Bounded env53394 := by
  intro p hp
  have h : env53394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53393_53394 : H12AffineEnvironment.transform 12 349 env53393 = env53394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53393 == env53394) = true)

theorem identity53394 : scanCanonicalize (H12AffineFastState.compose env53394 (packedSelected [0,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53394 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env53395 : List Nat := [2,4,8,16,0,64,8,4,512,20,2048,4096,89,4161,1,2,4176,2128,20,0,4161,1,16,82,89,64,2049,4097,4177,2128,68,81,4,80,4160,593]

theorem envBound53395 : H12AffineFastState.Bounded env53395 := by
  intro p hp
  have h : env53395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53394_53395 : H12AffineEnvironment.transform 7 4 env53394 = env53395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53394 == env53395) = true)

theorem identity53395 : scanCanonicalize (H12AffineFastState.compose env53395 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53395 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53396 : List Nat := [2,4,8,16,0,17,8,4,512,20,2048,4096,8,4112,1,2,4097,2049,20,0,4112,1,16,3,8,17,2049,4097,4096,2049,21,0,4,1,4113,512]

theorem envBound53396 : H12AffineFastState.Bounded env53396 := by
  intro p hp
  have h : env53396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53395_53396 : H12AffineEnvironment.transform 5 17 env53395 = env53396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53395 == env53396) = true)

theorem identity53396 : scanCanonicalize (H12AffineFastState.compose env53396 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound53396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53397 : List Nat := [2,4,8,16,0,17,8,4,512,20,2048,16,8,0,1,2,17,2049,20,0,0,1,16,3,8,17,2049,17,16,2049,21,0,4,1,1,512]

theorem envBound53397 : H12AffineFastState.Bounded env53397 := by
  intro p hp
  have h : env53397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53396_53397 : H12AffineEnvironment.transform 11 16 env53396 = env53397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53396 == env53397) = true)

theorem identity53397 : scanCanonicalize (H12AffineFastState.compose env53397 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 527) := by decide +kernel

theorem selectedBound53397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53398 : List Nat := [2,4,8,16,0,17,8,4,512,20,527,16,8,0,1,2,17,526,20,0,0,1,16,3,8,17,526,17,16,526,21,0,4,1,1,512]

theorem envBound53398 : H12AffineFastState.Bounded env53398 := by
  intro p hp
  have h : env53398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53397_53398 : H12AffineEnvironment.transform 10 527 env53397 = env53398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 527 env53397 == env53398) = true)

def env53399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,2097152,272393,2101329,21763,8193,64,2259212,2098512,17664,2543697,2102548,2411541,256,21793,46093,2156060]

theorem envBound53399 : H12AffineFastState.Bounded env53399 := by
  intro p hp
  have h : env53399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53385_53399 : H12AffineEnvironment.transform 6 9 env53385 = env53399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53385 == env53399) = true)

theorem identity53399 : scanCanonicalize (H12AffineFastState.compose env53399 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 314421) := by decide +kernel

theorem selectedBound53399 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env53400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,314421,272393,318564,21763,8193,64,439609,313701,17664,138340,317729,32,256,21793,46093,272937]

theorem envBound53400 : H12AffineFastState.Bounded env53400 := by
  intro p hp
  have h : env53400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53399_53400 : H12AffineEnvironment.transform 20 314421 env53399 = env53400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314421 env53399 == env53400) = true)

def env53401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,58397,33,62540,21763,8193,64,171281,57677,17664,138340,61705,32,256,21793,46093,513]

theorem envBound53401 : H12AffineFastState.Bounded env53401 := by
  intro p hp
  have h : env53401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53400_53401 : H12AffineEnvironment.transform 17 10280 env53400 = env53401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53400 == env53401) = true)

theorem identity53401 : scanCanonicalize (H12AffineFastState.compose env53401 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound53401 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env53402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49216,10280,1024,32769,58397,33,62540,21763,8193,64,23889,57677,17664,56356,61705,32,256,21793,46093,513]

theorem envBound53402 : H12AffineFastState.Bounded env53402 := by
  intro p hp
  have h : env53402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53401_53402 : H12AffineEnvironment.transform 16 49216 env53401 = env53402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env53401 == env53402) = true)

theorem identity53402 : scanCanonicalize (H12AffineFastState.compose env53402 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound53402 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env53403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,8283,13388,10280,1024,29709,4113,33,64,21763,8193,64,23889,5441,17664,10280,1285,32,256,21793,16385,513]

theorem envBound53403 : H12AffineFastState.Bounded env53403 := by
  intro p hp
  have h : env53403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53402_53403 : H12AffineEnvironment.transform 14 29708 env53402 = env53403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env53402 == env53403) = true)

theorem identity53403 : scanCanonicalize (H12AffineFastState.compose env53403 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound53403 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,8283,13388,10280,1024,1,4113,33,64,8463,8193,64,10589,5441,12556,10280,1285,32,256,8493,13325,513]

theorem envBound53404 : H12AffineFastState.Bounded env53404 := by
  intro p hp
  have h : env53404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53403_53404 : H12AffineEnvironment.transform 13 13324 env53403 = env53404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env53403 == env53404) = true)

theorem identity53404 : scanCanonicalize (H12AffineFastState.compose env53404 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53404 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,343,5440,2340,1024,1,4113,33,64,3,269,64,2129,5441,4096,2340,1285,32,256,33,5377,513]

theorem envBound53405 : H12AffineFastState.Bounded env53405 := by
  intro p hp
  have h : env53405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53404_53405 : H12AffineEnvironment.transform 12 268 env53404 = env53405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53404 == env53405) = true)

theorem identity53405 : scanCanonicalize (H12AffineFastState.compose env53405 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53405 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53406 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1024,1,4113,33,17,3,269,17,2048,5392,4096,2340,1285,32,256,33,5377,513]

theorem envBound53406 : H12AffineFastState.Bounded env53406 := by
  intro p hp
  have h : env53406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53405_53406 : H12AffineEnvironment.transform 5 17 env53405 = env53406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53405 == env53406) = true)

theorem identity53406 : scanCanonicalize (H12AffineFastState.compose env53406 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53407 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5173,2048,1024,1,4113,33,17,3,41,17,2048,5172,4096,2048,1057,32,36,33,5157,513]

theorem envBound53407 : H12AffineFastState.Bounded env53407 := by
  intro p hp
  have h : env53407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53406_53407 : H12AffineEnvironment.transform 7 36 env53406 = env53407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53406 == env53407) = true)

theorem identity53407 : scanCanonicalize (H12AffineFastState.compose env53407 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound53407 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53408 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5156,0,34,5173,522,1024,1,4113,33,17,3,41,17,522,5172,4096,522,1057,32,36,33,5157,513]

theorem envBound53408 : H12AffineFastState.Bounded env53408 := by
  intro p hp
  have h : env53408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53407_53408 : H12AffineEnvironment.transform 10 522 env53407 = env53408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env53407 == env53408) = true)

theorem identity53408 : scanCanonicalize (H12AffineFastState.compose env53408 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53408 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53409 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,9,5125,0,3,5140,522,1024,1,4113,0,17,3,8,17,522,5141,4096,522,1024,1,5,0,5124,513]

theorem envBound53409 : H12AffineFastState.Bounded env53409 := by
  intro p hp
  have h : env53409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53408_53409 : H12AffineEnvironment.transform 4 1 env53408 = env53409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53408 == env53409) = true)

def env53410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,58396,32,62541,21763,8193,64,171280,57676,17664,138340,61704,32,256,21793,46093,512]

theorem envBound53410 : H12AffineFastState.Bounded env53410 := by
  intro p hp
  have h : env53410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53400_53410 : H12AffineEnvironment.transform 17 10281 env53400 = env53410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53400 == env53410) = true)

theorem identity53410 : scanCanonicalize (H12AffineFastState.compose env53410 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 3092) := by decide +kernel

theorem selectedBound53410 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env53411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3092,32768,38979,131072,10281,1024,32769,43016,32,47193,6423,8193,64,171280,44376,2324,138340,48412,32,256,6453,46093,512]

theorem envBound53411 : H12AffineFastState.Bounded env53411 := by
  intro p hp
  have h : env53411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53410_53411 : H12AffineEnvironment.transform 13 3092 env53410 = env53411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3092 env53410 == env53411) = true)

theorem identity53411 : scanCanonicalize (H12AffineFastState.compose env53411 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 14409) := by decide +kernel

theorem selectedBound53411 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3092,14409,8202,131072,10281,1024,14408,4161,32,16,6423,8193,64,140633,5393,2324,138340,1365,32,256,6453,3140,512]

theorem envBound53412 : H12AffineFastState.Bounded env53412 := by
  intro p hp
  have h : env53412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53411_53412 : H12AffineEnvironment.transform 14 14409 env53411 = env53412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14409 env53411 == env53412) = true)

theorem identity53412 : scanCanonicalize (H12AffineFastState.compose env53412 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound53412 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,3092,7253,1046,131072,3125,1024,7252,4161,32,16,6423,1053,64,131397,5393,2324,138340,1365,32,256,6453,3140,512]

theorem envBound53413 : H12AffineFastState.Bounded env53413 := by
  intro p hp
  have h : env53413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53412_53413 : H12AffineEnvironment.transform 12 1052 env53412 = env53413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env53412 == env53413) = true)

theorem identity53413 : scanCanonicalize (H12AffineFastState.compose env53413 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 3441) := by decide +kernel

theorem selectedBound53413 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,3092,7253,1046,3441,3125,1024,7252,4161,32,16,6423,1053,64,3124,5393,2324,4373,1365,32,256,6453,3140,512]

theorem envBound53414 : H12AffineFastState.Bounded env53414 := by
  intro p hp
  have h : env53414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53413_53414 : H12AffineEnvironment.transform 16 3441 env53413 = env53414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3441 env53413 == env53414) = true)

theorem identity53414 : scanCanonicalize (H12AffineFastState.compose env53414 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound53414 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env53415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,1052,3092,261,1046,3441,3125,1024,260,3345,32,16,1095,1053,64,3124,2113,2324,3141,1365,32,256,1125,3140,512]

theorem envBound53415 : H12AffineFastState.Bounded env53415 := by
  intro p hp
  have h : env53415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53414_53415 : H12AffineEnvironment.transform 11 3408 env53414 = env53415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env53414 == env53415) = true)

theorem identity53415 : scanCanonicalize (H12AffineFastState.compose env53415 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53415 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env53416 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,1052,3092,112,1046,3076,3125,1024,113,3172,32,16,1095,1053,64,3124,2113,2145,3141,1056,32,117,1125,3140,512]

theorem envBound53416 : H12AffineFastState.Bounded env53416 := by
  intro p hp
  have h : env53416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0