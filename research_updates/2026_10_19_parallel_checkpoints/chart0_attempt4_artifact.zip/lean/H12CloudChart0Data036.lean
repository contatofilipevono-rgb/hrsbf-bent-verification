import H12CloudChart0Data035

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans8928_8952 : H12AffineEnvironment.transform 17 73945 env8928 = env8952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 73945 env8928 == env8952) = true)

def env8953 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,73945,4764,8200,65,112,4721,74448,8329,4097,74377,4744,4745,75786,4,73938,4764,73770,78578,73970]

theorem envBound8953 : H12AffineFastState.Bounded env8953 := by
  intro p hp
  have h : env8953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8952_8953 : H12AffineEnvironment.transform 13 560 env8952 = env8953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8952 == env8953) = true)

def env8954 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,73945,4764,8200,65,113,4721,74449,8329,4096,74376,4744,4745,75786,4,73939,4764,73770,78578,73971]

theorem envBound8954 : H12AffineFastState.Bounded env8954 := by
  intro p hp
  have h : env8954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8952_8954 : H12AffineEnvironment.transform 13 561 env8952 = env8954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8952 == env8954) = true)

theorem identity8954 : scanCanonicalize (H12AffineFastState.compose env8954 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8954 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8955 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,561,8200,65536,4096,73761,4708,8200,65,113,4721,74281,8305,4096,74352,4720,4721,75786,4,73771,4708,73770,78346,73739]

theorem envBound8955 : H12AffineFastState.Bounded env8955 := by
  intro p hp
  have h : env8955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8954_8955 : H12AffineEnvironment.transform 6 120 env8954 = env8955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8954 == env8955) = true)

theorem identity8955 : scanCanonicalize (H12AffineFastState.compose env8955 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound8955 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env8956 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2154,8192,561,8200,65536,2154,73761,2574,8200,65,113,2587,74281,8305,2154,74352,2586,2587,75786,4,73771,2574,73770,76384,73739]

theorem envBound8956 : H12AffineFastState.Bounded env8956 := by
  intro p hp
  have h : env8956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8955_8956 : H12AffineEnvironment.transform 11 2154 env8955 = env8956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env8955 == env8956) = true)

theorem identity8956 : scanCanonicalize (H12AffineFastState.compose env8956 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8956 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8957 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2154,8192,561,8200,8235,2154,10,2574,8200,65,113,2587,514,8305,2154,603,2586,2587,2081,4,0,2574,1,2635,32]

theorem envBound8957 : H12AffineFastState.Bounded env8957 := by
  intro p hp
  have h : env8957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8956_8957 : H12AffineEnvironment.transform 15 8235 env8956 = env8957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8956 == env8957) = true)

theorem identity8957 : scanCanonicalize (H12AffineFastState.compose env8957 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8957 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8958 : List Nat := [2,4,8,16,32,64,120,5,32,5,2048,2154,8192,17,8200,8235,2154,10,2094,8200,65,113,2107,34,8305,2154,123,2106,2107,2081,4,0,2094,1,2155,32]

theorem envBound8958 : H12AffineFastState.Bounded env8958 := by
  intro p hp
  have h : env8958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8957_8958 : H12AffineEnvironment.transform 8 32 env8957 = env8958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8957 == env8958) = true)

theorem identity8958 : scanCanonicalize (H12AffineFastState.compose env8958 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8958 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8959 : List Nat := [2,4,8,16,32,16,40,5,32,5,2048,2106,8192,17,8200,8235,2106,10,2094,8200,17,33,2107,34,8225,2106,43,2106,2107,2081,4,0,2094,1,2107,32]

theorem envBound8959 : H12AffineFastState.Bounded env8959 := by
  intro p hp
  have h : env8959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8958_8959 : H12AffineEnvironment.transform 5 16 env8958 = env8959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8958 == env8959) = true)

theorem identity8959 : scanCanonicalize (H12AffineFastState.compose env8959 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8959 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8960 : List Nat := [2,4,8,16,27,16,19,5,27,5,2048,2049,8192,17,8200,8208,2049,10,2069,8200,17,26,2048,25,8218,2049,16,2049,2048,2074,4,0,2069,1,2048,27]

theorem envBound8960 : H12AffineFastState.Bounded env8960 := by
  intro p hp
  have h : env8960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8959_8960 : H12AffineEnvironment.transform 4 27 env8959 = env8960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8959 == env8960) = true)

theorem identity8960 : scanCanonicalize (H12AffineFastState.compose env8960 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8960 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8961 : List Nat := [2,4,8,11,0,11,8,5,0,5,2048,2049,8192,10,8200,8203,2049,10,2062,8200,10,1,2048,2,8193,2049,11,2049,2048,2049,4,0,2062,1,2048,0]

theorem envBound8961 : H12AffineFastState.Bounded env8961 := by
  intro p hp
  have h : env8961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8960_8961 : H12AffineEnvironment.transform 3 11 env8960 = env8961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8960 == env8961) = true)

theorem identity8961 : scanCanonicalize (H12AffineFastState.compose env8961 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8962 : List Nat := [2,4,8,11,0,11,8,5,0,5,2048,2049,9,10,1,2,2049,10,2062,1,10,1,2048,2,8,2049,11,2049,2048,2049,4,0,2062,1,2048,0]

theorem envBound8962 : H12AffineFastState.Bounded env8962 := by
  intro p hp
  have h : env8962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8961_8962 : H12AffineEnvironment.transform 12 9 env8961 = env8962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8961 == env8962) = true)

theorem identity8962 : scanCanonicalize (H12AffineFastState.compose env8962 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8962 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8963 : List Nat := [2,4,8,11,0,11,8,5,0,5,1,0,9,10,1,2,0,10,15,1,10,1,1,2,8,0,11,0,1,0,4,0,15,1,1,0]

theorem envBound8963 : H12AffineFastState.Bounded env8963 := by
  intro p hp
  have h : env8963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8962_8963 : H12AffineEnvironment.transform 10 1 env8962 = env8963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8962 == env8963) = true)

def env8964 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,90337,8329,21040,807681,4735913,4735573,605034,529048,4796991,524288,602954,2695635,90942]

theorem envBound8964 : H12AffineFastState.Bounded env8964 := by
  intro p hp
  have h : env8964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8816_8964 : H12AffineEnvironment.transform 23 90337 env8816 = env8964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8816 == env8964) = true)

def env8965 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5005,90337,8329,21040,278625,4214985,4215093,75786,504,4268383,4960,73770,2175667,90942]

theorem envBound8965 : H12AffineFastState.Bounded env8965 := by
  intro p hp
  have h : env8965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8964_8965 : H12AffineEnvironment.transform 18 4960 env8964 = env8965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8964 == env8965) = true)

theorem identity8965 : scanCanonicalize (H12AffineFastState.compose env8965 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8965 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8966 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,2097152,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4765,73770,2175667,90819]

theorem envBound8966 : H12AffineFastState.Bounded env8966 := by
  intro p hp
  have h : env8966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8965_8966 : H12AffineEnvironment.transform 7 253 env8965 = env8966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8965 == env8966) = true)

def env8967 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4765,73770,78579,90819]

theorem envBound8967 : H12AffineFastState.Bounded env8967 := by
  intro p hp
  have h : env8967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8966_8967 : H12AffineEnvironment.transform 20 64 env8966 = env8967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8966 == env8967) = true)

theorem identity8967 : scanCanonicalize (H12AffineFastState.compose env8967 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 90641) := by decide +kernel

theorem selectedBound8967 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8968 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,90641,4765,8200,64,4194304,4720,90337,8329,21040,74352,4214985,4214984,75786,5,4268194,4765,73770,78579,90819]

theorem envBound8968 : H12AffineFastState.Bounded env8968 := by
  intro p hp
  have h : env8968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8967_8968 : H12AffineEnvironment.transform 17 90641 env8967 = env8968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90641 env8967 == env8968) = true)

def env8969 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,90641,4765,8200,64,16960,4720,90337,8329,21040,74352,4745,4744,75786,5,90850,4765,73770,78579,90819]

theorem envBound8969 : H12AffineFastState.Bounded env8969 := by
  intro p hp
  have h : env8969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8968_8969 : H12AffineEnvironment.transform 21 16960 env8968 = env8969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8968 == env8969) = true)

def env8970 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,73761,4765,8200,64,112,4720,74449,8329,4096,74352,4745,4744,75786,5,73938,4765,73770,78579,73971]

theorem envBound8970 : H12AffineFastState.Bounded env8970 := by
  intro p hp
  have h : env8970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8969_8970 : H12AffineEnvironment.transform 13 560 env8969 = env8970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8969 == env8970) = true)

theorem identity8970 : scanCanonicalize (H12AffineFastState.compose env8970 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8947) := by decide +kernel

theorem selectedBound8970 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8971 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,8947,4096,722,4765,8200,64,112,4720,34,8329,4096,131,4745,4744,2809,5,545,4765,729,4096,512]

theorem envBound8971 : H12AffineFastState.Bounded env8971 := by
  intro p hp
  have h : env8971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8970_8971 : H12AffineEnvironment.transform 15 8947 env8970 = env8971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8947 env8970 == env8971) = true)

theorem identity8971 : scanCanonicalize (H12AffineFastState.compose env8971 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2786) := by decide +kernel

theorem selectedBound8971 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8972 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2786,8192,560,8200,8947,2786,722,2175,8200,64,112,2194,34,8329,2786,131,2155,2154,2809,5,545,2175,729,2786,512]

theorem envBound8972 : H12AffineFastState.Bounded env8972 := by
  intro p hp
  have h : env8972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8971_8972 : H12AffineEnvironment.transform 11 2786 env8971 = env8972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2786 env8971 == env8972) = true)

theorem identity8972 : scanCanonicalize (H12AffineFastState.compose env8972 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8972 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8973 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2586,8192,560,8200,8715,2586,554,2175,8200,64,112,2154,34,8305,2586,123,2155,2154,2561,5,545,2175,545,2586,512]

theorem envBound8973 : H12AffineFastState.Bounded env8973 := by
  intro p hp
  have h : env8973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8972_8973 : H12AffineEnvironment.transform 6 120 env8972 = env8973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8972 == env8973) = true)

theorem identity8973 : scanCanonicalize (H12AffineFastState.compose env8973 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8973 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8974 : List Nat := [2,4,8,16,32,16,40,5,512,5,2048,2586,8192,560,8200,8715,2586,554,2095,8200,16,32,2106,34,8225,2586,43,2107,2106,2561,5,545,2095,545,2586,512]

theorem envBound8974 : H12AffineFastState.Bounded env8974 := by
  intro p hp
  have h : env8974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8973_8974 : H12AffineEnvironment.transform 5 16 env8973 = env8974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8973 == env8974) = true)

theorem identity8974 : scanCanonicalize (H12AffineFastState.compose env8974 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8974 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env8975 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2091,8192,1,8200,8250,2091,27,2095,8200,16,32,2106,34,8225,2091,43,2107,2106,2096,5,16,2095,16,2091,49]

theorem envBound8975 : H12AffineFastState.Bounded env8975 := by
  intro p hp
  have h : env8975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8974_8975 : H12AffineEnvironment.transform 8 49 env8974 = env8975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8974 == env8975) = true)

theorem identity8975 : scanCanonicalize (H12AffineFastState.compose env8975 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound8975 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8976 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2091,2088,1,2080,2066,2091,27,2095,2080,16,32,2106,34,2057,2091,43,2107,2106,2096,5,16,2095,16,2091,49]

theorem envBound8976 : H12AffineFastState.Bounded env8976 := by
  intro p hp
  have h : env8976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8975_8976 : H12AffineEnvironment.transform 12 2088 env8975 = env8976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env8975 == env8976) = true)

theorem identity8976 : scanCanonicalize (H12AffineFastState.compose env8976 (packedSelected [3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8976 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env8977 : List Nat := [2,4,8,16,32,16,40,5,49,5,42,1,2,1,10,56,1,27,5,10,16,32,16,34,35,1,43,17,16,26,5,16,5,16,1,49]

theorem envBound8977 : H12AffineFastState.Bounded env8977 := by
  intro p hp
  have h : env8977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8976_8977 : H12AffineEnvironment.transform 10 42 env8976 = env8977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8976 == env8977) = true)

theorem identity8977 : scanCanonicalize (H12AffineFastState.compose env8977 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8977 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env8978 : List Nat := [2,4,8,16,10,16,2,5,27,5,0,1,2,1,10,18,1,27,5,10,16,10,16,8,9,1,1,17,16,26,5,16,5,16,1,27]

theorem envBound8978 : H12AffineFastState.Bounded env8978 := by
  intro p hp
  have h : env8978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8977_8978 : H12AffineEnvironment.transform 4 10 env8977 = env8978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8977 == env8978) = true)

def env8979 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,73760,4765,8200,64,113,4720,74448,8329,4097,74352,4745,4744,75786,5,73939,4765,73770,78579,73970]

theorem envBound8979 : H12AffineFastState.Bounded env8979 := by
  intro p hp
  have h : env8979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8969_8979 : H12AffineEnvironment.transform 13 561 env8969 = env8979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8969 == env8979) = true)

theorem identity8979 : scanCanonicalize (H12AffineFastState.compose env8979 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8979 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8980 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,8715,4096,555,4765,8200,64,113,4720,219,8329,4097,123,4745,4744,2561,5,728,4765,545,4344,761]

theorem envBound8980 : H12AffineFastState.Bounded env8980 := by
  intro p hp
  have h : env8980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8979_8980 : H12AffineEnvironment.transform 15 8715 env8979 = env8980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8979 == env8980) = true)

theorem identity8980 : scanCanonicalize (H12AffineFastState.compose env8980 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound8980 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8981 : List Nat := [2,4,8,16,32,64,128,253,48,253,2048,4096,8192,1,8200,8251,4096,27,4269,8200,64,113,4160,219,8329,4097,123,4281,4280,2097,5,232,4269,17,4344,201]

theorem envBound8981 : H12AffineFastState.Bounded env8981 := by
  intro p hp
  have h : env8981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8980_8981 : H12AffineEnvironment.transform 8 48 env8980 = env8981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env8980 == env8981) = true)

theorem identity8981 : scanCanonicalize (H12AffineFastState.compose env8981 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound8981 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8982 : List Nat := [2,4,8,16,32,64,128,253,48,253,2048,2194,8192,1,8200,8251,2194,27,2111,8200,64,113,2258,219,8329,2195,123,2091,2090,2097,5,232,2111,17,2154,201]

theorem envBound8982 : H12AffineFastState.Bounded env8982 := by
  intro p hp
  have h : env8982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8981_8982 : H12AffineEnvironment.transform 11 2194 env8981 = env8982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env8981 == env8982) = true)

theorem identity8982 : scanCanonicalize (H12AffineFastState.compose env8982 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound8982 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8983 : List Nat := [2,4,8,16,32,64,57,68,48,68,2048,2091,8192,1,8200,8251,2091,27,2111,8200,64,113,2155,98,8240,2090,123,2091,2090,2097,5,81,2111,17,2154,112]

theorem envBound8983 : H12AffineFastState.Bounded env8983 := by
  intro p hp
  have h : env8983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8982_8983 : H12AffineEnvironment.transform 6 57 env8982 = env8983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8982 == env8983) = true)

theorem identity8983 : scanCanonicalize (H12AffineFastState.compose env8983 (packedSelected [1,3,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound8983 : packedSelected [1,3,13,14] rootPS < 2^1333 := by decide +kernel

def env8984 : List Nat := [2,4,8,16,32,64,57,68,48,68,2048,2091,88,1,80,99,2091,27,2111,80,64,113,2155,98,104,2090,123,2091,2090,2097,5,81,2111,17,2154,112]

theorem envBound8984 : H12AffineFastState.Bounded env8984 := by
  intro p hp
  have h : env8984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8983_8984 : H12AffineEnvironment.transform 12 88 env8983 = env8984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env8983 == env8984) = true)

theorem identity8984 : scanCanonicalize (H12AffineFastState.compose env8984 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8984 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8985 : List Nat := [2,4,8,16,32,16,57,20,48,20,2048,2091,8,1,0,51,2091,27,2111,0,16,33,2107,50,56,2090,43,2091,2090,2097,5,1,2111,17,2106,32]

theorem envBound8985 : H12AffineFastState.Bounded env8985 := by
  intro p hp
  have h : env8985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8984_8985 : H12AffineEnvironment.transform 5 16 env8984 = env8985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8984 == env8985) = true)

theorem identity8985 : scanCanonicalize (H12AffineFastState.compose env8985 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8985 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8986 : List Nat := [2,4,8,1,32,1,40,5,33,5,2048,2091,8,1,0,34,2091,10,2094,0,1,33,2090,35,41,2090,43,2091,2090,2080,5,1,2094,0,2091,32]

theorem envBound8986 : H12AffineFastState.Bounded env8986 := by
  intro p hp
  have h : env8986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8985_8986 : H12AffineEnvironment.transform 3 1 env8985 = env8986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8985 == env8986) = true)

theorem identity8986 : scanCanonicalize (H12AffineFastState.compose env8986 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound8986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8987 : List Nat := [2,4,8,1,32,1,40,5,33,5,37,14,8,1,0,34,14,10,11,0,1,33,15,35,41,15,43,14,15,5,5,1,11,0,14,32]

theorem envBound8987 : H12AffineFastState.Bounded env8987 := by
  intro p hp
  have h : env8987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8986_8987 : H12AffineEnvironment.transform 10 37 env8986 = env8987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env8986 == env8987) = true)

theorem identity8987 : scanCanonicalize (H12AffineFastState.compose env8987 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8988 : List Nat := [2,4,2,1,32,1,34,5,33,5,37,4,2,1,0,34,4,0,1,0,1,33,5,35,35,5,33,4,5,5,5,1,1,0,4,32]

theorem envBound8988 : H12AffineFastState.Bounded env8988 := by
  intro p hp
  have h : env8988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8987_8988 : H12AffineEnvironment.transform 2 2 env8987 = env8988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8987 == env8988) = true)

theorem identity8988 : scanCanonicalize (H12AffineFastState.compose env8988 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound8988 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8989 : List Nat := [2,4,2,1,5,1,7,5,4,5,0,4,2,1,0,7,4,0,1,0,1,4,5,6,6,5,4,4,5,5,5,1,1,0,4,5]

theorem envBound8989 : H12AffineFastState.Bounded env8989 := by
  intro p hp
  have h : env8989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8988_8989 : H12AffineEnvironment.transform 4 5 env8988 = env8989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env8988 == env8989) = true)

def env8990 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,90641,4765,8200,64,16961,4720,90337,8329,21040,74352,4744,4745,75786,5,90851,4765,73770,78579,90819]

theorem envBound8990 : H12AffineFastState.Bounded env8990 := by
  intro p hp
  have h : env8990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8968_8990 : H12AffineEnvironment.transform 21 16961 env8968 = env8990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8968 == env8990) = true)

def env8991 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,73761,4765,8200,64,113,4720,74449,8329,4096,74352,4744,4745,75786,5,73939,4765,73770,78579,73971]

theorem envBound8991 : H12AffineFastState.Bounded env8991 := by
  intro p hp
  have h : env8991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8990_8991 : H12AffineEnvironment.transform 13 560 env8990 = env8991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8990 == env8991) = true)

def env8992 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,664,8192,560,8200,65536,664,73761,5,8200,64,113,232,74449,8329,664,74352,16,17,75786,5,73939,5,73770,73835,73971]

theorem envBound8992 : H12AffineFastState.Bounded env8992 := by
  intro p hp
  have h : env8992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8991_8992 : H12AffineEnvironment.transform 11 664 env8991 = env8992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env8991 == env8992) = true)

theorem identity8992 : scanCanonicalize (H12AffineFastState.compose env8992 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8992 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8993 : List Nat := [2,4,8,16,32,64,128,253,33,253,2048,185,8192,17,8200,65536,185,73761,5,8200,64,113,232,73968,8329,185,73809,16,17,75786,5,73939,5,73770,73835,73971]

theorem envBound8993 : H12AffineFastState.Bounded env8993 := by
  intro p hp
  have h : env8993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8992_8993 : H12AffineEnvironment.transform 8 33 env8992 = env8993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8992 == env8993) = true)

theorem identity8993 : scanCanonicalize (H12AffineFastState.compose env8993 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 10408) := by decide +kernel

theorem selectedBound8993 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8994 : List Nat := [2,4,8,16,32,64,128,253,33,253,2048,185,8192,17,8200,10408,185,2185,5,8200,64,113,232,2136,8329,185,2297,16,17,162,5,2171,5,2178,2243,2139]

theorem envBound8994 : H12AffineFastState.Bounded env8994 := by
  intro p hp
  have h : env8994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8993_8994 : H12AffineEnvironment.transform 15 10408 env8993 = env8994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10408 env8993 == env8994) = true)

theorem identity8994 : scanCanonicalize (H12AffineFastState.compose env8994 (packedSelected [0,1,3,4,5,7,8,9,10,13,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8994 : packedSelected [0,1,3,4,5,7,8,9,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8995 : List Nat := [2,4,8,16,32,16,128,173,33,173,2048,185,8192,17,8200,10408,185,2185,5,8200,16,33,184,2056,8329,185,2217,16,17,162,5,2091,5,2178,2195,2059]

theorem envBound8995 : H12AffineFastState.Bounded env8995 := by
  intro p hp
  have h : env8995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8994_8995 : H12AffineEnvironment.transform 5 16 env8994 = env8995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8994 == env8995) = true)

theorem identity8995 : scanCanonicalize (H12AffineFastState.compose env8995 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8995 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8996 : List Nat := [2,4,8,16,32,16,41,4,33,4,2048,16,8192,17,8200,10241,16,2080,5,8200,16,33,17,2056,8224,16,2048,16,17,11,5,2091,5,2091,2106,2059]

theorem envBound8996 : H12AffineFastState.Bounded env8996 := by
  intro p hp
  have h : env8996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8995_8996 : H12AffineEnvironment.transform 6 41 env8995 = env8996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8995 == env8996) = true)

theorem identity8996 : scanCanonicalize (H12AffineFastState.compose env8996 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8996 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env8997 : List Nat := [2,4,8,16,27,16,18,4,26,4,2048,16,8192,17,8200,10241,16,2075,5,8200,16,26,17,2056,8219,16,2048,16,17,11,5,2064,5,2064,2049,2059]

theorem envBound8997 : H12AffineFastState.Bounded env8997 := by
  intro p hp
  have h : env8997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8996_8997 : H12AffineEnvironment.transform 4 27 env8996 = env8997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8996 == env8997) = true)

theorem identity8997 : scanCanonicalize (H12AffineFastState.compose env8997 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8997 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env8998 : List Nat := [2,4,8,16,27,16,18,4,26,4,2048,16,24,17,16,2073,16,2075,5,16,16,26,17,2056,3,16,2048,16,17,11,5,2064,5,2064,2049,2059]

theorem envBound8998 : H12AffineFastState.Bounded env8998 := by
  intro p hp
  have h : env8998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8997_8998 : H12AffineEnvironment.transform 12 24 env8997 = env8998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8997 == env8998) = true)

theorem identity8998 : scanCanonicalize (H12AffineFastState.compose env8998 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound8998 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8999 : List Nat := [2,4,8,16,27,16,18,4,26,4,17,16,24,17,16,8,16,10,5,16,16,26,17,25,3,16,17,16,17,11,5,1,5,1,16,26]

theorem envBound8999 : H12AffineFastState.Bounded env8999 := by
  intro p hp
  have h : env8999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8998_8999 : H12AffineEnvironment.transform 10 17 env8998 = env8999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env8998 == env8999) = true)

theorem identity8999 : scanCanonicalize (H12AffineFastState.compose env8999 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9000 : List Nat := [2,4,2,16,17,16,18,4,16,4,17,16,18,17,16,2,16,0,5,16,16,16,17,19,3,16,17,16,17,1,5,1,5,1,16,16]

theorem envBound9000 : H12AffineFastState.Bounded env9000 := by
  intro p hp
  have h : env9000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8999_9000 : H12AffineEnvironment.transform 2 2 env8999 = env9000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8999 == env9000) = true)

def env9001 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,665,8192,560,8200,65536,665,73761,4,8200,64,113,233,74449,8329,665,74352,17,16,75786,5,73939,4,73770,73834,73971]

theorem envBound9001 : H12AffineFastState.Bounded env9001 := by
  intro p hp
  have h : env9001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8991_9001 : H12AffineEnvironment.transform 11 665 env8991 = env9001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env8991 == env9001) = true)

theorem identity9001 : scanCanonicalize (H12AffineFastState.compose env9001 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound9001 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9002 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,665,8192,560,8200,8715,665,554,4,8200,64,113,233,218,8329,665,123,17,16,2561,5,728,4,545,609,760]

theorem envBound9002 : H12AffineFastState.Bounded env9002 := by
  intro p hp
  have h : env9002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9001_9002 : H12AffineEnvironment.transform 15 8715 env9001 = env9002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env9001 == env9002) = true)

theorem identity9002 : scanCanonicalize (H12AffineFastState.compose env9002 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound9002 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9003 : List Nat := [2,4,8,16,32,64,128,253,512,253,602,665,8192,560,8200,8715,665,554,4,8200,64,113,233,218,8329,665,123,17,16,91,5,728,4,545,609,760]

theorem envBound9003 : H12AffineFastState.Bounded env9003 := by
  intro p hp
  have h : env9003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9002_9003 : H12AffineEnvironment.transform 10 602 env9002 = env9003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env9002 == env9003) = true)

theorem identity9003 : scanCanonicalize (H12AffineFastState.compose env9003 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9003 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env9004 : List Nat := [2,4,8,16,32,64,128,253,33,253,123,184,8192,17,8200,8234,184,11,4,8200,64,113,233,218,8329,184,123,17,16,91,5,249,4,0,64,217]

theorem envBound9004 : H12AffineFastState.Bounded env9004 := by
  intro p hp
  have h : env9004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9003_9004 : H12AffineEnvironment.transform 8 33 env9003 = env9004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9003 == env9004) = true)

theorem identity9004 : scanCanonicalize (H12AffineFastState.compose env9004 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound9004 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env9005 : List Nat := [2,4,8,16,32,64,34,95,33,95,123,26,8192,17,8200,8234,26,11,4,8200,64,113,75,120,8235,26,123,17,16,91,5,91,4,0,64,123]

theorem envBound9005 : H12AffineFastState.Bounded env9005 := by
  intro p hp
  have h : env9005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9004_9005 : H12AffineEnvironment.transform 6 34 env9004 = env9005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env9004 == env9005) = true)

theorem identity9005 : scanCanonicalize (H12AffineFastState.compose env9005 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound9005 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env9006 : List Nat := [2,4,8,16,32,64,34,95,33,95,123,26,3,17,11,41,26,11,4,11,64,113,75,120,40,26,123,17,16,91,5,91,4,0,64,123]

theorem envBound9006 : H12AffineFastState.Bounded env9006 := by
  intro p hp
  have h : env9006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9005_9006 : H12AffineEnvironment.transform 12 3 env9005 = env9006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env9005 == env9006) = true)

theorem identity9006 : scanCanonicalize (H12AffineFastState.compose env9006 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9006 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9007 : List Nat := [2,4,8,16,32,59,34,36,33,36,0,26,3,17,11,41,26,11,4,11,59,10,48,3,40,26,0,17,16,32,5,32,4,0,59,0]

theorem envBound9007 : H12AffineFastState.Bounded env9007 := by
  intro p hp
  have h : env9007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9006_9007 : H12AffineEnvironment.transform 5 59 env9006 = env9007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9006 == env9007) = true)

theorem identity9007 : scanCanonicalize (H12AffineFastState.compose env9007 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9007 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9008 : List Nat := [2,4,8,16,26,1,24,30,27,30,0,26,3,17,11,19,26,11,4,11,1,10,10,3,18,26,0,17,16,26,5,26,4,0,1,0]

theorem envBound9008 : H12AffineFastState.Bounded env9008 := by
  intro p hp
  have h : env9008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9007_9008 : H12AffineEnvironment.transform 4 26 env9007 = env9008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9007 == env9008) = true)

theorem identity9008 : scanCanonicalize (H12AffineFastState.compose env9008 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9009 : List Nat := [2,4,8,1,11,1,9,15,10,15,0,11,3,0,11,2,11,11,4,11,1,10,10,3,3,11,0,0,1,11,5,11,4,0,1,0]

theorem envBound9009 : H12AffineFastState.Bounded env9009 := by
  intro p hp
  have h : env9009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9008_9009 : H12AffineEnvironment.transform 3 1 env9008 = env9009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9008 == env9009) = true)

theorem identity9009 : scanCanonicalize (H12AffineFastState.compose env9009 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9010 : List Nat := [2,4,2,1,1,1,3,5,0,5,0,1,3,0,1,2,1,1,4,1,1,0,0,3,3,1,0,0,1,1,5,1,4,0,1,0]

theorem envBound9010 : H12AffineFastState.Bounded env9010 := by
  intro p hp
  have h : env9010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9009_9010 : H12AffineEnvironment.transform 2 2 env9009 = env9010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9009 == env9010) = true)

def env9011 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,73760,4765,8200,64,112,4720,74448,8329,4097,74352,4744,4745,75786,5,73938,4765,73770,78579,73970]

theorem envBound9011 : H12AffineFastState.Bounded env9011 := by
  intro p hp
  have h : env9011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8990_9011 : H12AffineEnvironment.transform 13 561 env8990 = env9011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8990 == env9011) = true)

theorem identity9011 : scanCanonicalize (H12AffineFastState.compose env9011 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9011 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9012 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,561,8200,65536,4096,73760,4709,8200,64,112,4720,74280,8305,4097,74352,4720,4721,75786,5,73770,4709,73770,78347,73738]

theorem envBound9012 : H12AffineFastState.Bounded env9012 := by
  intro p hp
  have h : env9012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9011_9012 : H12AffineEnvironment.transform 6 120 env9011 = env9012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9011 == env9012) = true)

theorem identity9012 : scanCanonicalize (H12AffineFastState.compose env9012 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 14880) := by decide +kernel

theorem selectedBound9012 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9013 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,561,8200,14880,4096,6656,4709,8200,64,112,4720,6152,8305,4097,6224,4720,4721,4650,5,6666,4709,6666,2091,6698]

theorem envBound9013 : H12AffineFastState.Bounded env9013 := by
  intro p hp
  have h : env9013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9012_9013 : H12AffineEnvironment.transform 15 14880 env9012 = env9013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14880 env9012 == env9013) = true)

theorem identity9013 : scanCanonicalize (H12AffineFastState.compose env9013 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound9013 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env9014 : List Nat := [2,4,8,16,32,64,120,5,97,5,2048,4096,8192,80,8200,14401,4096,6241,4100,8200,64,112,4113,6152,8305,4097,6224,4113,4112,4171,5,6251,4100,6251,2091,6219]

theorem envBound9014 : H12AffineFastState.Bounded env9014 := by
  intro p hp
  have h : env9014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9013_9014 : H12AffineEnvironment.transform 8 97 env9013 = env9014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9013 == env9014) = true)

theorem identity9014 : scanCanonicalize (H12AffineFastState.compose env9014 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound9014 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9015 : List Nat := [2,4,8,16,32,64,120,5,97,5,2048,2090,8192,80,8200,8299,2090,75,2094,8200,64,112,2107,34,8305,2091,122,2107,2106,2145,5,65,2094,65,2091,97]

theorem envBound9015 : H12AffineFastState.Bounded env9015 := by
  intro p hp
  have h : env9015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9014_9015 : H12AffineEnvironment.transform 11 2090 env9014 = env9015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env9014 == env9015) = true)

theorem identity9015 : scanCanonicalize (H12AffineFastState.compose env9015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9016 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2090,8192,0,8200,8251,2090,27,2094,8200,16,32,2107,34,8225,2091,42,2107,2106,2097,5,17,2094,17,2091,49]

theorem envBound9016 : H12AffineFastState.Bounded env9016 := by
  intro p hp
  have h : env9016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9015_9016 : H12AffineEnvironment.transform 5 16 env9015 = env9016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9015 == env9016) = true)

theorem identity9016 : scanCanonicalize (H12AffineFastState.compose env9016 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound9016 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9017 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2090,2105,0,2097,2050,2090,27,2094,2097,16,32,2107,34,2072,2091,42,2107,2106,2097,5,17,2094,17,2091,49]

theorem envBound9017 : H12AffineFastState.Bounded env9017 := by
  intro p hp
  have h : env9017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9016_9017 : H12AffineEnvironment.transform 12 2105 env9016 = env9017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env9016 == env9017) = true)

theorem identity9017 : scanCanonicalize (H12AffineFastState.compose env9017 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9017 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9018 : List Nat := [2,4,8,16,32,16,40,5,49,5,1,43,56,0,48,3,43,27,47,48,16,32,58,34,25,42,42,58,59,48,5,17,47,17,42,49]

theorem envBound9018 : H12AffineFastState.Bounded env9018 := by
  intro p hp
  have h : env9018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9017_9018 : H12AffineEnvironment.transform 10 1 env9017 = env9018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9017 == env9018) = true)

def env9019 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4765,73770,78578,90819]

theorem envBound9019 : H12AffineFastState.Bounded env9019 := by
  intro p hp
  have h : env9019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8966_9019 : H12AffineEnvironment.transform 20 65 env8966 = env9019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8966 == env9019) = true)

theorem identity9019 : scanCanonicalize (H12AffineFastState.compose env9019 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 94321) := by decide +kernel

theorem selectedBound9019 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9020 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,94321,4765,8200,65,4194304,4720,90337,8329,21040,77840,4214985,4214984,75786,5,4268194,4765,73770,78578,90819]

theorem envBound9020 : H12AffineFastState.Bounded env9020 := by
  intro p hp
  have h : env9020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9019_9020 : H12AffineEnvironment.transform 17 94321 env9019 = env9020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94321 env9019 == env9020) = true)

def env9021 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,94321,4645,8200,65,4194304,4720,90201,8241,21040,77840,4214897,4214896,75786,5,4268058,4645,73770,78410,90747]

theorem envBound9021 : H12AffineFastState.Bounded env9021 := by
  intro p hp
  have h : env9021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9020_9021 : H12AffineEnvironment.transform 6 56 env9020 = env9021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9020 == env9021) = true)

theorem identity9021 : scanCanonicalize (H12AffineFastState.compose env9021 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 94298) := by decide +kernel

theorem selectedBound9021 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9022 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,94321,4645,8200,65,94298,4720,90201,8241,21040,77840,73771,73770,75786,5,20544,4645,73770,78410,90747]

theorem envBound9022 : H12AffineFastState.Bounded env9022 := by
  intro p hp
  have h : env9022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9021_9022 : H12AffineEnvironment.transform 21 94298 env9021 = env9022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94298 env9021 == env9022) = true)

def env9023 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,80,8192,16384,8200,65536,80,90145,629,8200,65,90122,544,90201,8241,16992,73792,73771,73770,75786,5,16400,629,73770,74266,90747]

theorem envBound9023 : H12AffineFastState.Bounded env9023 := by
  intro p hp
  have h : env9023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9022_9023 : H12AffineEnvironment.transform 11 80 env9022 = env9023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env9022 == env9023) = true)

def env9024 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,16,8192,16384,8200,65536,16,90145,565,8200,1,90122,544,90137,8241,16928,73728,73771,73770,75786,5,16400,565,73770,74266,90683]

theorem envBound9024 : H12AffineFastState.Bounded env9024 := by
  intro p hp
  have h : env9024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9023_9024 : H12AffineEnvironment.transform 5 0 env9023 = env9024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9023 == env9024) = true)

theorem identity9024 : scanCanonicalize (H12AffineFastState.compose env9024 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound9024 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9025 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,16,8192,0,8200,65536,16,73761,565,8200,1,73738,544,73753,8241,544,73728,73771,73770,75786,5,16,565,73770,74266,74299]

theorem envBound9025 : H12AffineFastState.Bounded env9025 := by
  intro p hp
  have h : env9025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9024_9025 : H12AffineEnvironment.transform 13 0 env9024 = env9025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env9024 == env9025) = true)

theorem identity9025 : scanCanonicalize (H12AffineFastState.compose env9025 (packedSelected [1,5,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9025 : packedSelected [1,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9026 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,8192,0,8200,65536,16,73761,565,8200,1,73738,544,73753,8241,544,73728,73771,73770,73776,5,16,565,73770,74266,74299]

theorem envBound9026 : H12AffineFastState.Bounded env9026 := by
  intro p hp
  have h : env9026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9025_9026 : H12AffineEnvironment.transform 10 58 env9025 = env9026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9025 == env9026) = true)

theorem identity9026 : scanCanonicalize (H12AffineFastState.compose env9026 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound9026 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9027 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,8192,0,8200,8715,16,554,565,8200,1,513,544,530,8241,544,523,544,545,571,5,16,565,545,17,48]

theorem envBound9027 : H12AffineFastState.Bounded env9027 := by
  intro p hp
  have h : env9027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9026_9027 : H12AffineEnvironment.transform 15 8715 env9026 = env9027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env9026 == env9027) = true)

theorem identity9027 : scanCanonicalize (H12AffineFastState.compose env9027 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound9027 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env9028 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,56,0,48,563,16,554,565,48,1,513,544,530,9,544,523,544,545,571,5,16,565,545,17,48]

theorem envBound9028 : H12AffineFastState.Bounded env9028 := by
  intro p hp
  have h : env9028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9027_9028 : H12AffineEnvironment.transform 12 56 env9027 = env9028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env9027 == env9028) = true)

theorem identity9028 : scanCanonicalize (H12AffineFastState.compose env9028 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound9028 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9029 : List Nat := [2,4,8,16,32,0,56,5,43,5,58,16,56,0,48,24,16,1,30,48,1,42,11,57,9,11,32,11,10,16,5,16,30,10,17,48]

theorem envBound9029 : H12AffineFastState.Bounded env9029 := by
  intro p hp
  have h : env9029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9028_9029 : H12AffineEnvironment.transform 8 43 env9028 = env9029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env9028 == env9029) = true)

theorem identity9029 : scanCanonicalize (H12AffineFastState.compose env9029 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9029 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env9030 : List Nat := [2,4,8,16,26,0,2,5,17,5,0,16,2,0,10,24,16,1,30,10,1,16,11,3,9,11,26,11,10,16,5,16,30,10,17,10]

theorem envBound9030 : H12AffineFastState.Bounded env9030 := by
  intro p hp
  have h : env9030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9029_9030 : H12AffineEnvironment.transform 4 26 env9029 = env9030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9029 == env9030) = true)

def env9031 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,17,8192,16384,8200,65536,17,90145,564,8200,0,90122,544,90136,8241,16929,73729,73771,73770,75786,5,16400,564,73770,74266,90682]

theorem envBound9031 : H12AffineFastState.Bounded env9031 := by
  intro p hp
  have h : env9031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9023_9031 : H12AffineEnvironment.transform 5 1 env9023 = env9031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9023 == env9031) = true)

theorem identity9031 : scanCanonicalize (H12AffineFastState.compose env9031 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 25099) := by decide +kernel

theorem selectedBound9031 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9032 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,17,8192,16384,8200,25099,17,554,564,8200,0,513,544,531,8241,16929,16906,16928,16929,18945,5,16400,564,16929,16401,49]

theorem envBound9032 : H12AffineFastState.Bounded env9032 := by
  intro p hp
  have h : env9032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9031_9032 : H12AffineEnvironment.transform 15 25099 env9031 = env9032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25099 env9031 == env9032) = true)

theorem identity9032 : scanCanonicalize (H12AffineFastState.compose env9032 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound9032 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9033 : List Nat := [2,4,8,16,32,1,56,4,48,4,2048,17,8192,16384,8200,24635,17,26,4,8200,0,49,16,35,8241,16401,16442,16400,16401,18481,5,16400,4,16401,16401,49]

theorem envBound9033 : H12AffineFastState.Bounded env9033 := by
  intro p hp
  have h : env9033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9032_9033 : H12AffineEnvironment.transform 8 48 env9032 = env9033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env9032 == env9033) = true)

theorem identity9033 : scanCanonicalize (H12AffineFastState.compose env9033 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound9033 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9034 : List Nat := [2,4,8,16,32,1,56,4,48,4,59,17,8192,16384,8200,24635,17,26,4,8200,0,49,16,35,8241,16401,16442,16400,16401,16394,5,16400,4,16401,16401,49]

theorem envBound9034 : H12AffineFastState.Bounded env9034 := by
  intro p hp
  have h : env9034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9033_9034 : H12AffineEnvironment.transform 10 59 env9033 = env9034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env9033 == env9034) = true)

theorem identity9034 : scanCanonicalize (H12AffineFastState.compose env9034 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 8201) := by decide +kernel

theorem selectedBound9034 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9035 : List Nat := [2,4,8,16,32,1,56,4,48,4,59,17,8192,8201,8200,50,17,26,4,8200,0,49,16,35,8241,8216,8243,8217,8216,8195,5,8217,4,8216,8216,49]

theorem envBound9035 : H12AffineFastState.Bounded env9035 := by
  intro p hp
  have h : env9035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9034_9035 : H12AffineEnvironment.transform 13 8201 env9034 = env9035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8201 env9034 == env9035) = true)

theorem identity9035 : scanCanonicalize (H12AffineFastState.compose env9035 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9035 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env9036 : List Nat := [2,1,8,16,32,1,56,1,48,1,59,17,8192,8201,8200,50,17,26,1,8200,0,49,16,35,8241,8216,8243,8217,8216,8195,0,8217,1,8216,8216,49]

theorem envBound9036 : H12AffineFastState.Bounded env9036 := by
  intro p hp
  have h : env9036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9035_9036 : H12AffineEnvironment.transform 1 1 env9035 = env9036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9035 == env9036) = true)

def env9037 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,81,8192,16384,8200,65536,81,90144,628,8200,65,90123,545,90201,8241,16993,73793,73771,73770,75786,5,16401,628,73770,74267,90747]

theorem envBound9037 : H12AffineFastState.Bounded env9037 := by
  intro p hp
  have h : env9037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9022_9037 : H12AffineEnvironment.transform 11 81 env9022 = env9037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env9022 == env9037) = true)

def env9038 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,17,8192,16384,8200,65536,17,90144,564,8200,1,90123,545,90137,8241,16929,73729,73771,73770,75786,5,16401,564,73770,74267,90683]

theorem envBound9038 : H12AffineFastState.Bounded env9038 := by
  intro p hp
  have h : env9038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9037_9038 : H12AffineEnvironment.transform 5 0 env9037 = env9038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9037 == env9038) = true)

theorem identity9038 : scanCanonicalize (H12AffineFastState.compose env9038 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound9038 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9039 : List Nat := [2,4,8,16,32,0,56,5,48,5,2048,17,8192,16384,8200,65536,17,90144,4,8200,1,90123,17,90137,8241,16401,73729,73771,73770,75786,5,16401,4,73770,73771,90123]

theorem envBound9039 : H12AffineFastState.Bounded env9039 := by
  intro p hp
  have h : env9039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9038_9039 : H12AffineEnvironment.transform 8 48 env9038 = env9039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env9038 == env9039) = true)

theorem identity9039 : scanCanonicalize (H12AffineFastState.compose env9039 (packedSelected [1,5,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9039 : packedSelected [1,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9040 : List Nat := [2,4,8,16,32,0,56,5,48,5,58,17,8192,16384,8200,65536,17,90144,4,8200,1,90123,17,90137,8241,16401,73729,73771,73770,73776,5,16401,4,73770,73771,90123]

theorem envBound9040 : H12AffineFastState.Bounded env9040 := by
  intro p hp
  have h : env9040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9039_9040 : H12AffineEnvironment.transform 10 58 env9039 = env9040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9039 == env9040) = true)

theorem identity9040 : scanCanonicalize (H12AffineFastState.compose env9040 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound9040 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env9041 : List Nat := [2,4,8,16,32,0,56,5,48,5,58,17,8192,16384,8200,8251,17,16411,4,8200,1,16432,17,16418,8241,16401,58,16,17,11,5,16401,4,17,16,16432]

theorem envBound9041 : H12AffineFastState.Bounded env9041 := by
  intro p hp
  have h : env9041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9040_9041 : H12AffineEnvironment.transform 15 8251 env9040 = env9041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env9040 == env9041) = true)

theorem identity9041 : scanCanonicalize (H12AffineFastState.compose env9041 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound9041 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env9042 : List Nat := [2,4,8,16,32,0,56,5,48,5,58,17,8192,8233,8200,8251,17,8242,4,8200,1,8217,17,8203,8241,8248,58,16,17,11,5,8248,4,17,16,8217]

theorem envBound9042 : H12AffineFastState.Bounded env9042 := by
  intro p hp
  have h : env9042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9041_9042 : H12AffineEnvironment.transform 13 8233 env9041 = env9042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env9041 == env9042) = true)

theorem identity9042 : scanCanonicalize (H12AffineFastState.compose env9042 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound9042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9043 : List Nat := [2,4,8,16,32,0,56,5,48,5,58,17,51,26,59,8,17,1,4,59,1,42,17,56,2,11,58,16,17,11,5,11,4,17,16,42]

theorem envBound9043 : H12AffineFastState.Bounded env9043 := by
  intro p hp
  have h : env9043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9042_9043 : H12AffineEnvironment.transform 12 51 env9042 = env9043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env9042 == env9043) = true)

theorem identity9043 : scanCanonicalize (H12AffineFastState.compose env9043 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9043 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env9044 : List Nat := [2,4,3,16,32,0,51,5,48,5,49,17,51,17,48,3,17,1,4,48,1,33,17,51,2,0,49,16,17,0,5,0,4,17,16,33]

theorem envBound9044 : H12AffineFastState.Bounded env9044 := by
  intro p hp
  have h : env9044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9043_9044 : H12AffineEnvironment.transform 2 3 env9043 = env9044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9043 == env9044) = true)

theorem identity9044 : scanCanonicalize (H12AffineFastState.compose env9044 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9044 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9045 : List Nat := [2,4,3,16,16,0,3,5,0,5,1,17,3,17,0,3,17,1,4,0,1,17,17,3,2,0,1,16,17,0,5,0,4,17,16,17]

theorem envBound9045 : H12AffineFastState.Bounded env9045 := by
  intro p hp
  have h : env9045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9044_9045 : H12AffineEnvironment.transform 4 16 env9044 = env9045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9044 == env9045) = true)

theorem identity9045 : scanCanonicalize (H12AffineFastState.compose env9045 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9045 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9046 : List Nat := [2,4,3,1,1,0,3,5,0,5,1,0,3,0,0,3,0,1,4,0,1,0,0,3,2,0,1,1,0,0,5,0,4,0,1,0]

theorem envBound9046 : H12AffineFastState.Bounded env9046 := by
  intro p hp
  have h : env9046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9045_9046 : H12AffineEnvironment.transform 3 1 env9045 = env9046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9045 == env9046) = true)

def env9047 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,16384,8200,65536,16,90144,565,8200,0,90123,545,90136,8241,16928,73728,73771,73770,75786,5,16401,565,73770,74267,90682]

theorem envBound9047 : H12AffineFastState.Bounded env9047 := by
  intro p hp
  have h : env9047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9037_9047 : H12AffineEnvironment.transform 5 1 env9037 = env9047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9037 == env9047) = true)

theorem identity9047 : scanCanonicalize (H12AffineFastState.compose env9047 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound9047 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9048 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,16384,8200,8251,16,16411,565,8200,0,16432,545,16419,8241,16928,59,16,17,2097,5,16401,565,17,544,16897]

theorem envBound9048 : H12AffineFastState.Bounded env9048 := by
  intro p hp
  have h : env9048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9047_9048 : H12AffineEnvironment.transform 15 8251 env9047 = env9048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env9047 == env9048) = true)

theorem identity9048 : scanCanonicalize (H12AffineFastState.compose env9048 (packedSelected [1,3,12,13,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound9048 : packedSelected [1,3,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env9049 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,0,8200,8251,16,27,565,8200,0,48,545,35,8241,544,59,16,17,2097,5,17,565,17,544,513]

theorem envBound9049 : H12AffineFastState.Bounded env9049 := by
  intro p hp
  have h : env9049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9048_9049 : H12AffineEnvironment.transform 13 0 env9048 = env9049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env9048 == env9049) = true)

theorem identity9049 : scanCanonicalize (H12AffineFastState.compose env9049 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound9049 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9050 : List Nat := [2,4,8,16,32,1,56,4,32,4,2048,16,8192,0,8200,8251,16,27,21,8200,0,48,1,35,8241,0,59,16,17,2097,5,17,21,17,0,33]

theorem envBound9050 : H12AffineFastState.Bounded env9050 := by
  intro p hp
  have h : env9050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9049_9050 : H12AffineEnvironment.transform 8 32 env9049 = env9050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9049 == env9050) = true)

theorem identity9050 : scanCanonicalize (H12AffineFastState.compose env9050 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound9050 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env9051 : List Nat := [2,4,8,16,32,1,56,4,32,4,5,16,8192,0,8200,8251,16,27,21,8200,0,48,1,35,8241,0,59,16,17,52,5,17,21,17,0,33]

theorem envBound9051 : H12AffineFastState.Bounded env9051 := by
  intro p hp
  have h : env9051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9050_9051 : H12AffineEnvironment.transform 10 5 env9050 = env9051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env9050 == env9051) = true)

theorem identity9051 : scanCanonicalize (H12AffineFastState.compose env9051 (packedSelected [2,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9051 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env9052 : List Nat := [2,4,8,11,32,1,35,4,32,4,5,11,8192,0,8200,8224,11,0,14,8200,0,43,1,35,8234,0,32,11,10,47,5,10,14,10,0,33]

theorem envBound9052 : H12AffineFastState.Bounded env9052 := by
  intro p hp
  have h : env9052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9051_9052 : H12AffineEnvironment.transform 3 11 env9051 = env9052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9051 == env9052) = true)

theorem identity9052 : scanCanonicalize (H12AffineFastState.compose env9052 (packedSelected [1,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9052 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env9053 : List Nat := [2,4,2,1,32,1,35,4,32,4,5,1,8192,0,8194,8224,1,0,4,8194,0,33,1,35,8224,0,32,1,0,37,5,0,4,0,0,33]

theorem envBound9053 : H12AffineFastState.Bounded env9053 := by
  intro p hp
  have h : env9053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9052_9053 : H12AffineEnvironment.transform 2 2 env9052 = env9053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9052 == env9053) = true)

theorem identity9053 : scanCanonicalize (H12AffineFastState.compose env9053 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 39) := by decide +kernel

theorem selectedBound9053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9054 : List Nat := [2,4,2,1,32,1,35,4,32,4,5,1,39,0,37,7,1,0,4,37,0,33,1,35,7,0,32,1,0,37,5,0,4,0,0,33]

theorem envBound9054 : H12AffineFastState.Bounded env9054 := by
  intro p hp
  have h : env9054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9053_9054 : H12AffineEnvironment.transform 12 39 env9053 = env9054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 39 env9053 == env9054) = true)

theorem identity9054 : scanCanonicalize (H12AffineFastState.compose env9054 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9055 : List Nat := [2,1,2,1,32,1,35,1,32,1,0,1,34,0,32,2,1,0,1,32,0,33,1,35,2,0,32,1,0,32,0,0,1,0,0,33]

theorem envBound9055 : H12AffineFastState.Bounded env9055 := by
  intro p hp
  have h : env9055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9054_9055 : H12AffineEnvironment.transform 1 1 env9054 = env9055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9054 == env9055) = true)

theorem identity9055 : scanCanonicalize (H12AffineFastState.compose env9055 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9055 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9056 : List Nat := [2,1,2,1,1,1,2,1,1,1,0,1,3,0,1,2,1,0,1,1,0,0,1,2,2,0,1,1,0,1,0,0,1,0,0,0]

theorem envBound9056 : H12AffineFastState.Bounded env9056 := by
  intro p hp
  have h : env9056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9055_9056 : H12AffineEnvironment.transform 4 1 env9055 = env9056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9055 == env9056) = true)

def env9057 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,94321,4644,8200,65,4194304,4720,90200,8240,21040,77840,4214896,4214897,75786,5,4268059,4644,73770,78411,90746]

theorem envBound9057 : H12AffineFastState.Bounded env9057 := by
  intro p hp
  have h : env9057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9020_9057 : H12AffineEnvironment.transform 6 57 env9020 = env9057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9020 == env9057) = true)

theorem identity9057 : scanCanonicalize (H12AffineFastState.compose env9057 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9057 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9058 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8200,65536,16,90209,564,8200,65,4194304,608,90200,8240,16928,73728,4210784,4210785,75786,5,4268059,564,73770,74331,90746]

theorem envBound9058 : H12AffineFastState.Bounded env9058 := by
  intro p hp
  have h : env9058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9057_9058 : H12AffineEnvironment.transform 11 16 env9057 = env9058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9057 == env9058) = true)

def env9059 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8200,65536,16,90209,564,8200,65,16960,608,90200,8240,16928,73728,544,545,75786,5,90715,564,73770,74331,90746]

theorem envBound9059 : H12AffineFastState.Bounded env9059 := by
  intro p hp
  have h : env9059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9058_9059 : H12AffineEnvironment.transform 21 16960 env9058 = env9059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env9058 == env9059) = true)

theorem identity9059 : scanCanonicalize (H12AffineFastState.compose env9059 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound9059 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env9060 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8200,8315,16,16410,564,8200,65,16960,608,16419,8240,16928,123,544,545,2161,5,16928,564,81,544,16897]

theorem envBound9060 : H12AffineFastState.Bounded env9060 := by
  intro p hp
  have h : env9060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9059_9060 : H12AffineEnvironment.transform 15 8315 env9059 = env9060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env9059 == env9060) = true)

theorem identity9060 : scanCanonicalize (H12AffineFastState.compose env9060 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9060 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9061 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,2106,8200,8315,16,2080,564,8200,65,2682,608,2073,8240,2586,123,544,545,2161,5,2586,564,81,544,2619]

theorem envBound9061 : H12AffineFastState.Bounded env9061 := by
  intro p hp
  have h : env9061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9060_9061 : H12AffineEnvironment.transform 13 2106 env9060 = env9061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env9060 == env9061) = true)

theorem identity9061 : scanCanonicalize (H12AffineFastState.compose env9061 (packedSelected [0,1,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound9061 : packedSelected [0,1,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9062 : List Nat := [2,4,8,16,32,64,57,68,512,68,42,16,8192,16,8200,8315,16,10,564,8200,65,592,608,51,8240,560,123,544,545,91,5,560,564,81,544,529]

theorem envBound9062 : H12AffineFastState.Bounded env9062 := by
  intro p hp
  have h : env9062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9061_9062 : H12AffineEnvironment.transform 10 42 env9061 = env9062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env9061 == env9062) = true)

theorem identity9062 : scanCanonicalize (H12AffineFastState.compose env9062 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9062 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env9063 : List Nat := [2,4,8,0,32,64,41,68,512,68,42,0,8192,0,8200,8299,0,10,548,8200,65,576,608,35,8224,544,107,544,545,75,5,544,548,65,544,513]

theorem envBound9063 : H12AffineFastState.Bounded env9063 := by
  intro p hp
  have h : env9063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9062_9063 : H12AffineEnvironment.transform 3 0 env9062 = env9063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9062 == env9063) = true)

theorem identity9063 : scanCanonicalize (H12AffineFastState.compose env9063 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 585) := by decide +kernel

theorem selectedBound9063 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9064 : List Nat := [2,4,8,0,32,64,41,68,512,68,42,0,585,0,577,546,0,10,548,577,65,576,608,35,617,544,107,544,545,75,5,544,548,65,544,513]

theorem envBound9064 : H12AffineFastState.Bounded env9064 := by
  intro p hp
  have h : env9064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9063_9064 : H12AffineEnvironment.transform 12 585 env9063 = env9064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 585 env9063 == env9064) = true)

theorem identity9064 : scanCanonicalize (H12AffineFastState.compose env9064 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound9064 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env9065 : List Nat := [2,4,8,0,32,14,41,10,512,10,42,0,519,0,527,546,0,10,548,527,15,526,558,35,551,544,37,544,545,5,5,544,548,15,544,513]

theorem envBound9065 : H12AffineFastState.Bounded env9065 := by
  intro p hp
  have h : env9065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9064_9065 : H12AffineEnvironment.transform 5 14 env9064 = env9065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env9064 == env9065) = true)

theorem identity9065 : scanCanonicalize (H12AffineFastState.compose env9065 (packedSelected [0,1,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9065 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env9066 : List Nat := [2,4,8,0,32,14,41,10,33,10,42,0,38,0,46,3,0,10,5,46,15,47,15,35,6,1,37,1,0,5,5,1,5,15,1,32]

theorem envBound9066 : H12AffineFastState.Bounded env9066 := by
  intro p hp
  have h : env9066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9065_9066 : H12AffineEnvironment.transform 8 33 env9065 = env9066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9065 == env9066) = true)

theorem identity9066 : scanCanonicalize (H12AffineFastState.compose env9066 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9066 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9067 : List Nat := [2,4,2,0,32,4,35,0,33,0,32,0,38,0,36,3,0,0,5,36,5,37,5,35,6,1,37,1,0,5,5,1,5,5,1,32]

theorem envBound9067 : H12AffineFastState.Bounded env9067 := by
  intro p hp
  have h : env9067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9066_9067 : H12AffineEnvironment.transform 2 2 env9066 = env9067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9066 == env9067) = true)

theorem identity9067 : scanCanonicalize (H12AffineFastState.compose env9067 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound9067 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env9068 : List Nat := [2,4,2,0,4,4,7,0,5,0,4,0,2,0,0,3,0,0,5,0,5,1,5,7,6,1,1,1,0,5,5,1,5,5,1,4]

theorem envBound9068 : H12AffineFastState.Bounded env9068 := by
  intro p hp
  have h : env9068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9067_9068 : H12AffineEnvironment.transform 4 4 env9067 = env9068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env9067 == env9068) = true)

theorem identity9068 : scanCanonicalize (H12AffineFastState.compose env9068 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9069 : List Nat := [2,0,2,0,0,0,3,0,1,0,0,0,2,0,0,3,0,0,1,0,1,1,1,3,2,1,1,1,0,1,1,1,1,1,1,0]

theorem envBound9069 : H12AffineFastState.Bounded env9069 := by
  intro p hp
  have h : env9069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9068_9069 : H12AffineEnvironment.transform 1 0 env9068 = env9069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9068 == env9069) = true)

def env9070 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8200,65536,16,90209,564,8200,65,16961,608,90200,8240,16928,73728,545,544,75786,5,90714,564,73770,74331,90746]

theorem envBound9070 : H12AffineFastState.Bounded env9070 := by
  intro p hp
  have h : env9070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9058_9070 : H12AffineEnvironment.transform 21 16961 env9058 = env9070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env9058 == env9070) = true)

theorem identity9070 : scanCanonicalize (H12AffineFastState.compose env9070 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound9070 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env9071 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8200,8714,16,17003,564,8200,65,16961,608,16978,8240,16928,522,545,544,2560,5,16464,564,544,81,16496]

theorem envBound9071 : H12AffineFastState.Bounded env9071 := by
  intro p hp
  have h : env9071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9070_9071 : H12AffineEnvironment.transform 15 8714 env9070 = env9071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env9070 == env9071) = true)

theorem identity9071 : scanCanonicalize (H12AffineFastState.compose env9071 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 624) := by decide +kernel

theorem selectedBound9071 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9072 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,624,8200,8714,16,27,564,8200,65,49,608,34,8240,80,522,545,544,2560,5,544,564,544,81,512]

theorem envBound9072 : H12AffineFastState.Bounded env9072 := by
  intro p hp
  have h : env9072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9071_9072 : H12AffineEnvironment.transform 13 624 env9071 = env9072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 624 env9071 == env9072) = true)

theorem identity9072 : scanCanonicalize (H12AffineFastState.compose env9072 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9072 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9073 : List Nat := [2,4,8,0,32,64,41,68,512,68,2048,0,8192,608,8200,8714,0,11,548,8200,65,33,608,34,8224,64,522,545,544,2560,5,544,548,544,65,512]

theorem envBound9073 : H12AffineFastState.Bounded env9073 := by
  intro p hp
  have h : env9073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9072_9073 : H12AffineEnvironment.transform 3 0 env9072 = env9073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9072 == env9073) = true)

theorem identity9073 : scanCanonicalize (H12AffineFastState.compose env9073 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound9073 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env9074 : List Nat := [2,4,8,0,32,64,41,68,512,68,33,0,8192,608,8200,8714,0,11,548,8200,65,33,608,34,8224,64,522,545,544,545,5,544,548,544,65,512]

theorem envBound9074 : H12AffineFastState.Bounded env9074 := by
  intro p hp
  have h : env9074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9073_9074 : H12AffineEnvironment.transform 10 33 env9073 = env9074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env9073 == env9074) = true)

theorem identity9074 : scanCanonicalize (H12AffineFastState.compose env9074 (packedSelected [1,2,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound9074 : packedSelected [1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env9075 : List Nat := [2,4,8,0,32,64,41,68,512,68,33,0,73,608,65,579,0,11,548,65,65,33,608,34,105,64,522,545,544,545,5,544,548,544,65,512]

theorem envBound9075 : H12AffineFastState.Bounded env9075 := by
  intro p hp
  have h : env9075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9074_9075 : H12AffineEnvironment.transform 12 73 env9074 = env9075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env9074 == env9075) = true)

theorem identity9075 : scanCanonicalize (H12AffineFastState.compose env9075 (packedSelected [0,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound9075 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env9076 : List Nat := [2,4,8,0,32,33,41,37,512,37,33,0,40,513,32,546,0,11,548,32,32,33,513,34,8,33,522,545,544,545,5,544,548,544,32,512]

theorem envBound9076 : H12AffineFastState.Bounded env9076 := by
  intro p hp
  have h : env9076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9075_9076 : H12AffineEnvironment.transform 5 33 env9075 = env9076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env9075 == env9076) = true)

theorem identity9076 : scanCanonicalize (H12AffineFastState.compose env9076 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound9076 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9077 : List Nat := [2,4,8,0,32,33,41,37,42,37,33,0,40,43,32,8,0,11,14,32,32,33,43,34,8,33,32,11,10,11,5,10,14,10,32,42]

theorem envBound9077 : H12AffineFastState.Bounded env9077 := by
  intro p hp
  have h : env9077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9076_9077 : H12AffineEnvironment.transform 8 42 env9076 = env9077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env9076 == env9077) = true)

def env9078 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5004,90337,8329,21040,278624,4214984,4215092,75787,505,4268382,4961,73771,2175666,90942]

theorem envBound9078 : H12AffineFastState.Bounded env9078 := by
  intro p hp
  have h : env9078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8964_9078 : H12AffineEnvironment.transform 18 4961 env8964 = env9078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8964 == env9078) = true)

theorem identity9078 : scanCanonicalize (H12AffineFastState.compose env9078 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9078 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9079 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,2097152,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4961,16616,2118257,1021]

theorem envBound9079 : H12AffineFastState.Bounded env9079 := by
  intro p hp
  have h : env9079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9078_9079 : H12AffineEnvironment.transform 15 24771 env9078 = env9079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9078 == env9079) = true)

def env9080 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,64,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4961,16616,21041,1021]

theorem envBound9080 : H12AffineFastState.Bounded env9080 := by
  intro p hp
  have h : env9080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9079_9080 : H12AffineEnvironment.transform 20 64 env9079 = env9080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9079 == env9080) = true)

theorem identity9080 : scanCanonicalize (H12AffineFastState.compose env9080 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262819) := by decide +kernel

theorem selectedBound9080 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9081 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,64,262819,5004,34,8329,21040,278624,283243,283543,18632,505,279358,4961,16616,21041,1021]

theorem envBound9081 : H12AffineFastState.Bounded env9081 := by
  intro p hp
  have h : env9081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9080_9081 : H12AffineEnvironment.transform 21 262819 env9080 = env9081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262819 env9080 == env9081) = true)

def env9082 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8693,8947,4605,262144,4961,8693,64,262819,5004,34,8329,4096,262736,266331,266663,2808,505,262414,4961,728,4097,1021]

theorem envBound9082 : H12AffineFastState.Bounded env9082 := by
  intro p hp
  have h : env9082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9081_9082 : H12AffineEnvironment.transform 13 560 env9081 = env9082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9081 == env9082) = true)

def env9083 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8235,4605,262144,4537,8693,64,262267,4436,34,8329,4096,262280,266331,266663,2080,505,262414,4537,0,4097,293]

theorem envBound9083 : H12AffineFastState.Bounded env9083 := by
  intro p hp
  have h : env9083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9082_9083 : H12AffineEnvironment.transform 8 216 env9082 = env9083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9082 == env9083) = true)

theorem identity9083 : scanCanonicalize (H12AffineFastState.compose env9083 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 423) := by decide +kernel

theorem selectedBound9083 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9084 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8235,4605,423,4537,8693,64,476,4436,34,8329,4096,303,4604,4096,2080,505,169,4537,0,4097,293]

theorem envBound9084 : H12AffineFastState.Bounded env9084 := by
  intro p hp
  have h : env9084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9083_9084 : H12AffineEnvironment.transform 17 423 env9083 = env9084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 423 env9083 == env9084) = true)

def env9085 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8234,4605,262144,4536,8693,64,262266,4437,34,8329,4096,262281,266331,266663,2081,505,262414,4536,1,4097,292]

theorem envBound9085 : H12AffineFastState.Bounded env9085 := by
  intro p hp
  have h : env9085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9082_9085 : H12AffineEnvironment.transform 8 217 env9082 = env9085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9082 == env9085) = true)

theorem identity9085 : scanCanonicalize (H12AffineFastState.compose env9085 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9085 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9086 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,233,8352,8234,4264,262144,4333,8352,64,262266,4096,34,8329,4096,262281,266331,266482,2081,172,262235,4333,1,4097,113]

theorem envBound9086 : H12AffineFastState.Bounded env9086 := by
  intro p hp
  have h : env9086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9085_9086 : H12AffineEnvironment.transform 7 85 env9085 = env9086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9085 == env9086) = true)

theorem identity9086 : scanCanonicalize (H12AffineFastState.compose env9086 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9086 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9087 : List Nat := [2,4,8,16,32,64,41,85,112,85,2048,4096,8192,64,8201,8234,4097,262144,4164,8201,64,262266,4096,34,8224,4096,262176,266331,266331,2081,5,262235,4164,1,4097,113]

theorem envBound9087 : H12AffineFastState.Bounded env9087 := by
  intro p hp
  have h : env9087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9086_9087 : H12AffineEnvironment.transform 6 41 env9086 = env9087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9086 == env9087) = true)

theorem identity9087 : scanCanonicalize (H12AffineFastState.compose env9087 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 27) := by decide +kernel

theorem selectedBound9087 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9088 : List Nat := [2,4,8,16,32,64,41,85,112,85,2048,4096,8192,64,8201,8234,4097,27,4164,8201,64,97,4096,34,8224,4096,59,4160,4160,2081,5,64,4164,1,4097,113]

theorem envBound9088 : H12AffineFastState.Bounded env9088 := by
  intro p hp
  have h : env9088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9087_9088 : H12AffineEnvironment.transform 17 27 env9087 = env9088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 27 env9087 == env9088) = true)

theorem identity9088 : scanCanonicalize (H12AffineFastState.compose env9088 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound9088 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9089 : List Nat := [2,4,8,16,32,64,41,85,112,85,2048,1,8192,64,8201,8234,0,27,69,8201,64,97,1,34,8224,1,59,65,65,2081,5,64,69,1,0,113]

theorem envBound9089 : H12AffineFastState.Bounded env9089 := by
  intro p hp
  have h : env9089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9088_9089 : H12AffineEnvironment.transform 11 1 env9088 = env9089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env9088 == env9089) = true)

theorem identity9089 : scanCanonicalize (H12AffineFastState.compose env9089 (packedSelected [0,2,4,7,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2114) := by decide +kernel

theorem selectedBound9089 : packedSelected [0,2,4,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env9090 : List Nat := [2,4,8,16,32,64,41,85,112,85,2048,1,2114,64,2123,2152,0,27,69,2123,64,97,1,34,2146,1,59,65,65,2081,5,64,69,1,0,113]

theorem envBound9090 : H12AffineFastState.Bounded env9090 := by
  intro p hp
  have h : env9090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9089_9090 : H12AffineEnvironment.transform 12 2114 env9089 = env9090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2114 env9089 == env9090) = true)

theorem identity9090 : scanCanonicalize (H12AffineFastState.compose env9090 (packedSelected [0,1,3,4,7,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound9090 : packedSelected [0,1,3,4,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env9091 : List Nat := [2,4,8,16,20,64,29,85,68,85,2048,1,2114,64,2123,2140,0,27,69,2123,64,85,1,22,2134,1,15,65,65,2069,5,64,69,1,0,69]

theorem envBound9091 : H12AffineFastState.Bounded env9091 := by
  intro p hp
  have h : env9091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9090_9091 : H12AffineEnvironment.transform 4 20 env9090 = env9091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env9090 == env9091) = true)

theorem identity9091 : scanCanonicalize (H12AffineFastState.compose env9091 (packedSelected [0,4,7,8,9,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9091 : packedSelected [0,4,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env9092 : List Nat := [2,4,8,0,4,64,13,69,68,69,2048,1,2114,64,2123,2124,0,11,69,2123,64,69,1,6,2118,1,15,65,65,2053,5,64,69,1,0,69]

theorem envBound9092 : H12AffineFastState.Bounded env9092 := by
  intro p hp
  have h : env9092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9091_9092 : H12AffineEnvironment.transform 3 0 env9091 = env9092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9091 == env9092) = true)

theorem identity9092 : scanCanonicalize (H12AffineFastState.compose env9092 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound9092 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9093 : List Nat := [2,4,7,0,4,64,2,69,68,69,2048,1,2114,64,2116,2115,0,4,69,2116,64,69,1,6,2118,1,0,65,65,2053,5,64,69,1,0,69]

theorem envBound9093 : H12AffineFastState.Bounded env9093 := by
  intro p hp
  have h : env9093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9092_9093 : H12AffineEnvironment.transform 2 7 env9092 = env9093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env9092 == env9093) = true)

theorem identity9093 : scanCanonicalize (H12AffineFastState.compose env9093 (packedSelected [1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9093 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env9094 : List Nat := [2,1,2,0,1,64,2,64,65,64,2048,1,2114,64,2113,2115,0,1,64,2113,64,64,1,3,2115,1,0,65,65,2048,0,64,64,1,0,64]

theorem envBound9094 : H12AffineFastState.Bounded env9094 := by
  intro p hp
  have h : env9094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9093_9094 : H12AffineEnvironment.transform 1 1 env9093 = env9094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9093 == env9094) = true)

theorem identity9094 : scanCanonicalize (H12AffineFastState.compose env9094 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9094 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9095 : List Nat := [2,1,2,0,1,1,2,1,0,1,2048,1,2051,1,2048,2050,0,1,1,2048,1,1,1,3,2050,1,0,0,0,2048,0,1,1,1,0,1]

theorem envBound9095 : H12AffineFastState.Bounded env9095 := by
  intro p hp
  have h : env9095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9094_9095 : H12AffineEnvironment.transform 5 1 env9094 = env9095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9094 == env9095) = true)

theorem identity9095 : scanCanonicalize (H12AffineFastState.compose env9095 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9096 : List Nat := [2,1,2,0,1,1,2,1,0,1,0,1,3,1,0,2,0,1,1,0,1,1,1,3,2,1,0,0,0,0,0,1,1,1,0,1]

theorem envBound9096 : H12AffineFastState.Bounded env9096 := by
  intro p hp
  have h : env9096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9095_9096 : H12AffineEnvironment.transform 10 0 env9095 = env9096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9095 == env9096) = true)

def env9097 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8693,8946,4605,262144,4961,8693,64,262819,5004,34,8329,4097,262737,266330,266662,2809,505,262415,4961,729,4096,1021]

theorem envBound9097 : H12AffineFastState.Bounded env9097 := by
  intro p hp
  have h : env9097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9081_9097 : H12AffineEnvironment.transform 13 561 env9081 = env9097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9081 == env9097) = true)

def env9098 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8234,4605,262144,4537,8693,64,262267,4436,34,8329,4097,262281,266330,266662,2081,505,262415,4537,1,4096,293]

theorem envBound9098 : H12AffineFastState.Bounded env9098 := by
  intro p hp
  have h : env9098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9097_9098 : H12AffineEnvironment.transform 8 216 env9097 = env9098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9097 == env9098) = true)

theorem identity9098 : scanCanonicalize (H12AffineFastState.compose env9098 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9098 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9099 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,233,8352,8234,4264,262144,4332,8352,64,262267,4097,34,8329,4097,262281,266330,266483,2081,172,262234,4332,1,4096,112]

theorem envBound9099 : H12AffineFastState.Bounded env9099 := by
  intro p hp
  have h : env9099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9098_9099 : H12AffineEnvironment.transform 7 85 env9098 = env9099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9098 == env9099) = true)

theorem identity9099 : scanCanonicalize (H12AffineFastState.compose env9099 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9099 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9100 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,233,8352,8234,4264,91,4332,8352,64,32,4097,34,8329,4097,210,4097,4264,2081,172,1,4332,1,4096,112]

theorem envBound9100 : H12AffineFastState.Bounded env9100 := by
  intro p hp
  have h : env9100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9099_9100 : H12AffineEnvironment.transform 17 91 env9099 = env9100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9099 == env9100) = true)

theorem identity9100 : scanCanonicalize (H12AffineFastState.compose env9100 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9100 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9101 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,2106,8192,233,8352,8234,2194,91,2262,8352,64,32,2107,34,8329,2107,210,2107,2194,2081,172,1,2262,1,2106,112]

theorem envBound9101 : H12AffineFastState.Bounded env9101 := by
  intro p hp
  have h : env9101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9100_9101 : H12AffineEnvironment.transform 11 2106 env9100 = env9101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env9100 == env9101) = true)

theorem identity9101 : scanCanonicalize (H12AffineFastState.compose env9101 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9101 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9102 : List Nat := [2,4,8,16,32,17,128,4,137,4,2048,2106,8192,184,8352,8234,2194,10,2183,8352,17,32,2107,34,8329,2107,131,2107,2194,2081,172,1,2183,1,2106,33]

theorem envBound9102 : H12AffineFastState.Bounded env9102 := by
  intro p hp
  have h : env9102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9101_9102 : H12AffineEnvironment.transform 5 17 env9101 = env9102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9101 == env9102) = true)

theorem identity9102 : scanCanonicalize (H12AffineFastState.compose env9102 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9102 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9103 : List Nat := [2,4,8,16,32,17,40,4,33,4,2048,2106,8192,16,8200,8234,2106,10,2095,8200,17,32,2107,34,8225,2107,43,2107,2106,2081,4,1,2095,1,2106,33]

theorem envBound9103 : H12AffineFastState.Bounded env9103 := by
  intro p hp
  have h : env9103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9102_9103 : H12AffineEnvironment.transform 6 40 env9102 = env9103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9102 == env9103) = true)

theorem identity9103 : scanCanonicalize (H12AffineFastState.compose env9103 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound9103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9104 : List Nat := [2,4,8,16,32,17,40,4,33,4,17,43,8192,16,8200,8234,43,10,62,8200,17,32,42,34,8225,42,43,42,43,48,4,1,62,1,43,33]

theorem envBound9104 : H12AffineFastState.Bounded env9104 := by
  intro p hp
  have h : env9104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9103_9104 : H12AffineEnvironment.transform 10 17 env9103 = env9104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env9103 == env9104) = true)

def env9105 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8235,4605,262144,4536,8693,64,262266,4437,34,8329,4097,262280,266330,266662,2080,505,262415,4536,0,4096,292]

theorem envBound9105 : H12AffineFastState.Bounded env9105 := by
  intro p hp
  have h : env9105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9097_9105 : H12AffineEnvironment.transform 8 217 env9097 = env9105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9097 == env9105) = true)

theorem identity9105 : scanCanonicalize (H12AffineFastState.compose env9105 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 422) := by decide +kernel

theorem selectedBound9105 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9106 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8235,4605,422,4536,8693,64,476,4437,34,8329,4097,302,4604,4096,2080,505,169,4536,0,4096,292]

theorem envBound9106 : H12AffineFastState.Bounded env9106 := by
  intro p hp
  have h : env9106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9105_9106 : H12AffineEnvironment.transform 17 422 env9105 = env9106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 422 env9105 == env9106) = true)

theorem identity9106 : scanCanonicalize (H12AffineFastState.compose env9106 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9106 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9107 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,232,8353,8235,4265,242,4332,8353,64,136,4097,34,8329,4097,122,4264,4096,2080,173,169,4332,0,4096,112]

theorem envBound9107 : H12AffineFastState.Bounded env9107 := by
  intro p hp
  have h : env9107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9106_9107 : H12AffineEnvironment.transform 7 84 env9106 = env9107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9106 == env9107) = true)

theorem identity9107 : scanCanonicalize (H12AffineFastState.compose env9107 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound9107 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9108 : List Nat := [2,4,8,16,32,64,128,84,217,84,42,4096,8192,232,8353,8235,4265,242,4332,8353,64,136,4097,34,8329,4097,122,4264,4096,10,173,169,4332,0,4096,112]

theorem envBound9108 : H12AffineFastState.Bounded env9108 := by
  intro p hp
  have h : env9108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9107_9108 : H12AffineEnvironment.transform 10 42 env9107 = env9108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env9107 == env9108) = true)

theorem identity9108 : scanCanonicalize (H12AffineFastState.compose env9108 (packedSelected [0,1,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9108 : packedSelected [0,1,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env9109 : List Nat := [2,4,8,16,32,17,128,5,136,5,42,4096,8192,185,8353,8235,4265,163,4285,8353,17,136,4097,34,8329,4097,43,4264,4096,10,173,169,4285,0,4096,33]

theorem envBound9109 : H12AffineFastState.Bounded env9109 := by
  intro p hp
  have h : env9109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9108_9109 : H12AffineEnvironment.transform 5 17 env9108 = env9109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9108 == env9109) = true)

theorem identity9109 : scanCanonicalize (H12AffineFastState.compose env9109 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9109 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9110 : List Nat := [2,4,8,16,32,17,128,5,136,5,42,16,8192,185,8353,8235,185,163,173,8353,17,136,17,34,8329,17,43,184,16,10,173,169,173,0,16,33]

theorem envBound9110 : H12AffineFastState.Bounded env9110 := by
  intro p hp
  have h : env9110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9109_9110 : H12AffineEnvironment.transform 11 16 env9109 = env9110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9109 == env9110) = true)

theorem identity9110 : scanCanonicalize (H12AffineFastState.compose env9110 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound9110 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9111 : List Nat := [2,4,8,16,32,17,18,5,26,5,42,16,8192,43,8243,8235,43,49,63,8243,17,26,17,34,8219,17,43,42,16,10,63,59,63,0,16,33]

theorem envBound9111 : H12AffineFastState.Bounded env9111 := by
  intro p hp
  have h : env9111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9110_9111 : H12AffineEnvironment.transform 6 18 env9110 = env9111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env9110 == env9111) = true)

theorem identity9111 : scanCanonicalize (H12AffineFastState.compose env9111 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9111 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9112 : List Nat := [2,4,8,0,32,1,2,5,10,5,42,0,8192,43,8227,8235,43,33,47,8227,1,10,1,34,8203,1,43,42,0,10,47,43,47,0,0,33]

theorem envBound9112 : H12AffineFastState.Bounded env9112 := by
  intro p hp
  have h : env9112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9111_9112 : H12AffineEnvironment.transform 3 0 env9111 = env9112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9111 == env9112) = true)

def env9113 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,65,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4961,16616,21040,1021]

theorem envBound9113 : H12AffineFastState.Bounded env9113 := by
  intro p hp
  have h : env9113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9079_9113 : H12AffineEnvironment.transform 20 65 env9079 = env9113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9079 == env9113) = true)

theorem identity9113 : scanCanonicalize (H12AffineFastState.compose env9113 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266434) := by decide +kernel

theorem selectedBound9113 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9114 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4961,8693,65,266434,5004,34,8329,21040,278624,278538,279030,18632,505,282975,4961,16616,21040,1021]

theorem envBound9114 : H12AffineFastState.Bounded env9114 := by
  intro p hp
  have h : env9114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9113_9114 : H12AffineEnvironment.transform 21 266434 env9113 = env9114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266434 env9113 == env9114) = true)

def env9115 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8693,8947,4605,262144,4961,8693,65,266434,5004,34,8329,4096,262736,262714,263110,2808,505,267119,4961,728,4096,1021]

theorem envBound9115 : H12AffineFastState.Bounded env9115 := by
  intro p hp
  have h : env9115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9114_9115 : H12AffineEnvironment.transform 13 560 env9114 = env9115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9114 == env9115) = true)

def env9116 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8235,4605,262144,4537,8693,65,266434,4436,34,8329,4096,262280,262370,262430,2080,505,266679,4537,0,4096,293]

theorem envBound9116 : H12AffineFastState.Bounded env9116 := by
  intro p hp
  have h : env9116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9115_9116 : H12AffineEnvironment.transform 8 216 env9115 = env9116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9115 == env9116) = true)

theorem identity9116 : scanCanonicalize (H12AffineFastState.compose env9116 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9116 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9117 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8235,4605,4383,4537,8693,65,477,4436,34,8329,4096,4503,4605,4097,2080,505,168,4537,0,4096,293]

theorem envBound9117 : H12AffineFastState.Bounded env9117 := by
  intro p hp
  have h : env9117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9116_9117 : H12AffineEnvironment.transform 17 4383 env9116 = env9117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9116 == env9117) = true)

theorem identity9117 : scanCanonicalize (H12AffineFastState.compose env9117 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound9117 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9118 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,492,8192,232,8693,8235,17,243,85,8693,65,477,184,34,8329,492,123,17,493,2080,505,168,85,0,492,293]

theorem envBound9118 : H12AffineFastState.Bounded env9118 := by
  intro p hp
  have h : env9118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9117_9118 : H12AffineEnvironment.transform 11 492 env9117 = env9118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env9117 == env9118) = true)

theorem identity9118 : scanCanonicalize (H12AffineFastState.compose env9118 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9118 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env9119 : List Nat := [2,4,8,16,32,64,128,5,216,5,2048,233,8192,232,8432,8235,17,243,85,8432,65,216,184,34,8329,233,123,17,232,2080,252,168,85,0,233,32]

theorem envBound9119 : H12AffineFastState.Bounded env9119 := by
  intro p hp
  have h : env9119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9118_9119 : H12AffineEnvironment.transform 7 5 env9118 = env9119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9118 == env9119) = true)

theorem identity9119 : scanCanonicalize (H12AffineFastState.compose env9119 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound9119 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9120 : List Nat := [2,4,8,16,32,64,128,5,216,5,211,233,8192,232,8432,8235,17,243,85,8432,65,216,184,34,8329,233,123,17,232,243,252,168,85,0,233,32]

theorem envBound9120 : H12AffineFastState.Bounded env9120 := by
  intro p hp
  have h : env9120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9119_9120 : H12AffineEnvironment.transform 10 211 env9119 = env9120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env9119 == env9120) = true)

theorem identity9120 : scanCanonicalize (H12AffineFastState.compose env9120 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9120 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9121 : List Nat := [2,4,8,16,32,64,120,5,32,5,43,17,8192,16,8200,8235,17,11,85,8200,65,32,64,34,8305,17,123,17,16,11,4,80,85,0,17,32]

theorem envBound9121 : H12AffineFastState.Bounded env9121 := by
  intro p hp
  have h : env9121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9120_9121 : H12AffineEnvironment.transform 6 120 env9120 = env9121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9120 == env9121) = true)

theorem identity9121 : scanCanonicalize (H12AffineFastState.compose env9121 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 115) := by decide +kernel

theorem selectedBound9121 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9122 : List Nat := [2,4,8,16,32,64,120,5,32,5,43,17,115,16,123,88,17,11,85,123,65,32,64,34,2,17,123,17,16,11,4,80,85,0,17,32]

theorem envBound9122 : H12AffineFastState.Bounded env9122 := by
  intro p hp
  have h : env9122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9121_9122 : H12AffineEnvironment.transform 12 115 env9121 = env9122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 115 env9121 == env9122) = true)

theorem identity9122 : scanCanonicalize (H12AffineFastState.compose env9122 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9122 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9123 : List Nat := [2,4,8,16,32,59,3,5,32,5,43,17,8,16,0,35,17,11,46,0,58,32,59,34,2,17,0,17,16,11,4,43,46,0,17,32]

theorem envBound9123 : H12AffineFastState.Bounded env9123 := by
  intro p hp
  have h : env9123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9122_9123 : H12AffineEnvironment.transform 5 59 env9122 = env9123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9122 == env9123) = true)

theorem identity9123 : scanCanonicalize (H12AffineFastState.compose env9123 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9123 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9124 : List Nat := [2,4,8,16,16,11,3,5,16,5,27,17,8,16,0,19,17,11,30,0,10,16,11,18,2,17,0,17,16,11,4,27,30,0,17,16]

theorem envBound9124 : H12AffineFastState.Bounded env9124 := by
  intro p hp
  have h : env9124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9123_9124 : H12AffineEnvironment.transform 4 16 env9123 = env9124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9123 == env9124) = true)

theorem identity9124 : scanCanonicalize (H12AffineFastState.compose env9124 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9124 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9125 : List Nat := [2,4,8,10,10,11,3,5,10,5,1,11,8,10,0,9,11,11,4,0,10,10,11,8,2,11,0,11,10,11,4,1,4,0,11,10]

theorem envBound9125 : H12AffineFastState.Bounded env9125 := by
  intro p hp
  have h : env9125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9124_9125 : H12AffineEnvironment.transform 3 10 env9124 = env9125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9124 == env9125) = true)

theorem identity9125 : scanCanonicalize (H12AffineFastState.compose env9125 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9126 : List Nat := [2,4,2,0,0,1,3,5,0,5,1,1,2,0,0,3,1,1,4,0,0,0,1,2,2,1,0,1,0,1,4,1,4,0,1,0]

theorem envBound9126 : H12AffineFastState.Bounded env9126 := by
  intro p hp
  have h : env9126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9125_9126 : H12AffineEnvironment.transform 2 2 env9125 = env9126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9125 == env9126) = true)

def leafEnv9126 : List Nat := [2,4,2,0,0,1,3,5,0,5,1,1,2,0,0,3,1,1,4,0,0,0,1,2,5,2,1,1,0,1,0,1,4,1,4,0,5,2,1,0,1,0,0]

def active9126 : List Nat := [0,1]

def tree9126 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9126 : H12WitnessSearch.Good tree9126 := H12GlobalWitnessIndex.good

theorem leafIdentity9126 : H12AffineFastState.composeSystem env9126 rootObs = leafEnv9126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9126 rootObs == leafEnv9126) = true)

theorem terminalChecked9126 : H12PackedTerminal.terminalCheckFast leafEnv9126 active9126 tree9126 = true := by decide +kernel

def env9127 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8234,4605,262144,4536,8693,65,266434,4437,34,8329,4096,262281,262371,262431,2081,505,266678,4536,1,4096,292]

theorem envBound9127 : H12AffineFastState.Bounded env9127 := by
  intro p hp
  have h : env9127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9115_9127 : H12AffineEnvironment.transform 8 217 env9115 = env9127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9115 == env9127) = true)

theorem identity9127 : scanCanonicalize (H12AffineFastState.compose env9127 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9127 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9128 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,233,8353,8234,4265,262144,4332,8353,65,266434,4097,34,8329,4096,262281,262371,262219,2081,173,266466,4332,1,4096,112]

theorem envBound9128 : H12AffineFastState.Bounded env9128 := by
  intro p hp
  have h : env9128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9127_9128 : H12AffineEnvironment.transform 7 84 env9127 = env9128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9127 == env9128) = true)

theorem identity9128 : scanCanonicalize (H12AffineFastState.compose env9128 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9128 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9129 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,233,8353,8234,4265,91,4332,8353,65,4249,4097,34,8329,4096,210,184,16,2081,173,4281,4332,1,4096,112]

theorem envBound9129 : H12AffineFastState.Bounded env9129 := by
  intro p hp
  have h : env9129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9128_9129 : H12AffineEnvironment.transform 17 91 env9128 = env9129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9128 == env9129) = true)

theorem identity9129 : scanCanonicalize (H12AffineFastState.compose env9129 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound9129 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9130 : List Nat := [2,4,8,16,32,64,128,84,217,84,130,4096,8192,233,8353,8234,4265,91,4332,8353,65,4249,4097,34,8329,4096,210,184,16,163,173,4281,4332,1,4096,112]

theorem envBound9130 : H12AffineFastState.Bounded env9130 := by
  intro p hp
  have h : env9130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9129_9130 : H12AffineEnvironment.transform 10 130 env9129 = env9130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env9129 == env9130) = true)

theorem identity9130 : scanCanonicalize (H12AffineFastState.compose env9130 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound9130 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9131 : List Nat := [2,4,8,16,32,64,128,84,217,84,130,233,8192,233,8353,8234,64,91,5,8353,65,112,232,34,8329,233,210,184,16,163,173,80,5,1,233,112]

theorem envBound9131 : H12AffineFastState.Bounded env9131 := by
  intro p hp
  have h : env9131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9130_9131 : H12AffineEnvironment.transform 11 233 env9130 = env9131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env9130 == env9131) = true)

theorem identity9131 : scanCanonicalize (H12AffineFastState.compose env9131 (packedSelected [0,1,2,4,8,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9131 : packedSelected [0,1,2,4,8,11,13] rootPS < 2^1333 := by decide +kernel

def env9132 : List Nat := [2,4,8,16,32,49,128,37,168,37,130,152,8192,152,8353,8234,49,42,5,8353,48,1,153,34,8329,152,163,184,16,163,173,33,5,1,152,1]

theorem envBound9132 : H12AffineFastState.Bounded env9132 := by
  intro p hp
  have h : env9132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9131_9132 : H12AffineEnvironment.transform 5 49 env9131 = env9132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9131 == env9132) = true)

theorem identity9132 : scanCanonicalize (H12AffineFastState.compose env9132 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9132 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env9133 : List Nat := [2,4,8,16,32,49,8,37,32,37,10,16,8192,16,8233,8234,49,42,5,8233,48,1,17,34,8193,16,43,48,16,43,37,33,5,1,16,1]

theorem envBound9133 : H12AffineFastState.Bounded env9133 := by
  intro p hp
  have h : env9133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9132_9133 : H12AffineEnvironment.transform 6 8 env9132 = env9133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9132 == env9133) = true)

theorem identity9133 : scanCanonicalize (H12AffineFastState.compose env9133 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9133 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9134 : List Nat := [2,4,8,16,17,0,8,20,17,20,10,16,8192,16,8216,8219,0,27,5,8216,1,1,17,19,8193,16,26,1,16,26,20,16,5,1,16,1]

theorem envBound9134 : H12AffineFastState.Bounded env9134 := by
  intro p hp
  have h : env9134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9133_9134 : H12AffineEnvironment.transform 4 17 env9133 = env9134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9133 == env9134) = true)

theorem identity9134 : scanCanonicalize (H12AffineFastState.compose env9134 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9134 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9135 : List Nat := [2,4,3,16,17,0,3,20,17,20,1,16,8192,16,8211,8208,0,16,5,8211,1,1,17,19,8193,16,17,1,16,17,20,16,5,1,16,1]

theorem envBound9135 : H12AffineFastState.Bounded env9135 := by
  intro p hp
  have h : env9135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9134_9135 : H12AffineEnvironment.transform 2 3 env9134 = env9135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9134 == env9135) = true)

theorem identity9135 : scanCanonicalize (H12AffineFastState.compose env9135 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound9135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9136 : List Nat := [2,4,3,16,17,0,3,20,17,20,1,16,3,16,16,19,0,16,5,16,1,1,17,19,2,16,17,1,16,17,20,16,5,1,16,1]

theorem envBound9136 : H12AffineFastState.Bounded env9136 := by
  intro p hp
  have h : env9136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9135_9136 : H12AffineEnvironment.transform 12 3 env9135 = env9136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env9135 == env9136) = true)

theorem identity9136 : scanCanonicalize (H12AffineFastState.compose env9136 (packedSelected [19] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9136 : packedSelected [19] rootPS < 2^1333 := by decide +kernel

def env9137 : List Nat := [2,4,3,0,1,0,3,4,1,4,1,0,3,0,0,3,0,0,5,0,1,1,1,3,2,0,1,1,0,1,4,0,5,1,0,1]

theorem envBound9137 : H12AffineFastState.Bounded env9137 := by
  intro p hp
  have h : env9137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9136_9137 : H12AffineEnvironment.transform 3 0 env9136 = env9137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9136 == env9137) = true)

def leafEnv9137 : List Nat := [2,4,3,0,1,0,3,4,1,4,1,0,3,0,0,3,0,0,5,0,1,1,1,3,5,2,1,0,1,1,0,1,4,0,5,1,5,3,0,1,1,0,0]

def active9137 : List Nat := [0,1]

def tree9137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9137 : H12WitnessSearch.Good tree9137 := H12GlobalWitnessIndex.good

theorem leafIdentity9137 : H12AffineFastState.composeSystem env9137 rootObs = leafEnv9137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9137 rootObs == leafEnv9137) = true)

theorem terminalChecked9137 : H12PackedTerminal.terminalCheckFast leafEnv9137 active9137 tree9137 = true := by decide +kernel

def env9138 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8693,8946,4605,262144,4961,8693,65,266434,5004,34,8329,4097,262737,262715,263111,2809,505,267118,4961,729,4097,1021]

theorem envBound9138 : H12AffineFastState.Bounded env9138 := by
  intro p hp
  have h : env9138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9114_9138 : H12AffineEnvironment.transform 13 561 env9114 = env9138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9114 == env9138) = true)

def env9139 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8234,4605,262144,4537,8693,65,266434,4436,34,8329,4097,262281,262371,262431,2081,505,266678,4537,1,4097,293]

theorem envBound9139 : H12AffineFastState.Bounded env9139 := by
  intro p hp
  have h : env9139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9138_9139 : H12AffineEnvironment.transform 8 216 env9138 = env9139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9138 == env9139) = true)

theorem identity9139 : scanCanonicalize (H12AffineFastState.compose env9139 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9139 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9140 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,233,8353,8234,4265,262144,4333,8353,65,266434,4096,34,8329,4097,262281,262371,262219,2081,173,266466,4333,1,4097,113]

theorem envBound9140 : H12AffineFastState.Bounded env9140 := by
  intro p hp
  have h : env9140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9139_9140 : H12AffineEnvironment.transform 7 84 env9139 = env9140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9139 == env9140) = true)

theorem identity9140 : scanCanonicalize (H12AffineFastState.compose env9140 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9140 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9141 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,17,8192,233,8353,8234,184,262144,252,8353,65,262355,17,34,8329,16,262281,262371,262219,2081,173,262387,252,1,16,113]

theorem envBound9141 : H12AffineFastState.Bounded env9141 := by
  intro p hp
  have h : env9141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9140_9141 : H12AffineEnvironment.transform 11 17 env9140 = env9141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9140 == env9141) = true)

theorem identity9141 : scanCanonicalize (H12AffineFastState.compose env9141 (packedSelected [13,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound9141 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9142 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,17,8192,233,8353,8234,184,2080,252,8353,65,2291,17,34,8329,16,2217,2243,2155,2081,173,2259,252,1,16,113]

theorem envBound9142 : H12AffineFastState.Bounded env9142 := by
  intro p hp
  have h : env9142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9141_9142 : H12AffineEnvironment.transform 17 2080 env9141 = env9142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env9141 == env9142) = true)

theorem identity9142 : scanCanonicalize (H12AffineFastState.compose env9142 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound9142 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env9143 : List Nat := [2,4,8,16,32,64,128,84,216,84,42,17,8192,233,8353,8234,184,10,252,8353,65,217,17,34,8329,16,131,233,65,11,173,249,252,1,16,113]

theorem envBound9143 : H12AffineFastState.Bounded env9143 := by
  intro p hp
  have h : env9143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9142_9143 : H12AffineEnvironment.transform 10 42 env9142 = env9143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env9142 == env9143) = true)

theorem identity9143 : scanCanonicalize (H12AffineFastState.compose env9143 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 115) := by decide +kernel

theorem selectedBound9143 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env9144 : List Nat := [2,4,8,16,32,64,128,84,216,84,42,17,115,233,210,89,184,10,252,210,65,217,17,34,250,16,131,233,65,11,173,249,252,1,16,113]

theorem envBound9144 : H12AffineFastState.Bounded env9144 := by
  intro p hp
  have h : env9144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9143_9144 : H12AffineEnvironment.transform 12 115 env9143 = env9144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 115 env9143 == env9144) = true)

theorem identity9144 : scanCanonicalize (H12AffineFastState.compose env9144 (packedSelected [0,4,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9144 : packedSelected [0,4,9] rootPS < 2^1333 := by decide +kernel

def env9145 : List Nat := [2,4,3,16,32,64,128,84,211,84,33,17,115,226,210,82,179,1,247,210,65,210,17,34,241,16,131,226,65,0,166,242,247,1,16,113]

theorem envBound9145 : H12AffineFastState.Bounded env9145 := by
  intro p hp
  have h : env9145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9144_9145 : H12AffineEnvironment.transform 2 3 env9144 = env9145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9144 == env9145) = true)

theorem identity9145 : scanCanonicalize (H12AffineFastState.compose env9145 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9145 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env9146 : List Nat := [2,4,3,16,0,64,128,84,211,84,1,17,83,194,210,82,147,1,215,210,65,210,17,2,209,16,131,194,65,0,134,210,215,1,16,81]

theorem envBound9146 : H12AffineFastState.Bounded env9146 := by
  intro p hp
  have h : env9146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9145_9146 : H12AffineEnvironment.transform 4 0 env9145 = env9146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9145 == env9146) = true)

theorem identity9146 : scanCanonicalize (H12AffineFastState.compose env9146 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9146 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env9147 : List Nat := [2,4,3,16,0,1,128,21,146,21,1,17,18,131,147,19,147,1,150,147,0,147,17,2,144,16,131,131,0,0,134,147,150,1,16,16]

theorem envBound9147 : H12AffineFastState.Bounded env9147 := by
  intro p hp
  have h : env9147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9146_9147 : H12AffineEnvironment.transform 5 1 env9146 = env9147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9146 == env9147) = true)

def env9148 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8235,4605,262144,4536,8693,65,266434,4437,34,8329,4097,262280,262370,262430,2080,505,266679,4536,0,4097,292]

theorem envBound9148 : H12AffineFastState.Bounded env9148 := by
  intro p hp
  have h : env9148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9138_9148 : H12AffineEnvironment.transform 8 217 env9138 = env9148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9138 == env9148) = true)

theorem identity9148 : scanCanonicalize (H12AffineFastState.compose env9148 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9148 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9149 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8235,4605,4383,4536,8693,65,477,4437,34,8329,4097,4503,4605,4097,2080,505,168,4536,0,4097,292]

theorem envBound9149 : H12AffineFastState.Bounded env9149 := by
  intro p hp
  have h : env9149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9148_9149 : H12AffineEnvironment.transform 17 4383 env9148 = env9149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9148 == env9149) = true)

theorem identity9149 : scanCanonicalize (H12AffineFastState.compose env9149 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound9149 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9150 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,185,8192,232,8693,8235,324,422,257,8693,65,477,492,34,8329,184,302,324,184,2080,505,168,257,0,184,292]

theorem envBound9150 : H12AffineFastState.Bounded env9150 := by
  intro p hp
  have h : env9150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9149_9150 : H12AffineEnvironment.transform 11 185 env9149 = env9150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env9149 == env9150) = true)

theorem identity9150 : scanCanonicalize (H12AffineFastState.compose env9150 (packedSelected [3,5,8,14,28] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound9150 : packedSelected [3,5,8,14,28] rootPS < 2^1333 := by decide +kernel

def env9151 : List Nat := [2,4,8,16,32,64,128,256,217,256,303,185,8192,232,8693,8235,324,422,257,8693,65,477,492,34,8329,184,302,324,184,271,505,168,257,0,184,292]

theorem envBound9151 : H12AffineFastState.Bounded env9151 := by
  intro p hp
  have h : env9151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9150_9151 : H12AffineEnvironment.transform 10 303 env9150 = env9151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env9150 == env9151) = true)

theorem identity9151 : scanCanonicalize (H12AffineFastState.compose env9151 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9151 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env9152 : List Nat := [2,4,8,16,32,64,128,253,217,253,210,185,8192,232,8200,8235,185,91,252,8200,65,32,17,34,8329,184,211,185,184,242,4,168,252,0,184,217]

theorem envBound9152 : H12AffineFastState.Bounded env9152 := by
  intro p hp
  have h : env9152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9151_9152 : H12AffineEnvironment.transform 7 253 env9151 = env9152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9151 == env9152) = true)

theorem identity9152 : scanCanonicalize (H12AffineFastState.compose env9152 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9152 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9153 : List Nat := [2,4,8,16,32,64,41,84,112,84,123,16,8192,65,8200,8235,16,91,85,8200,65,32,17,34,8224,17,122,16,17,91,4,1,85,0,17,112]

theorem envBound9153 : H12AffineFastState.Bounded env9153 := by
  intro p hp
  have h : env9153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9152_9153 : H12AffineEnvironment.transform 6 41 env9152 = env9153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9152 == env9153) = true)

theorem identity9153 : scanCanonicalize (H12AffineFastState.compose env9153 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound9153 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9154 : List Nat := [2,4,8,16,32,64,41,84,112,84,123,16,56,65,48,19,16,91,85,48,65,32,17,34,24,17,122,16,17,91,4,1,85,0,17,112]

theorem envBound9154 : H12AffineFastState.Bounded env9154 := by
  intro p hp
  have h : env9154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9153_9154 : H12AffineEnvironment.transform 12 56 env9153 = env9154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env9153 == env9154) = true)

theorem identity9154 : scanCanonicalize (H12AffineFastState.compose env9154 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9154 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9155 : List Nat := [2,4,8,16,17,64,24,84,65,84,74,16,9,65,1,19,16,91,85,1,65,17,17,19,24,17,75,16,17,91,4,1,85,0,17,65]

theorem envBound9155 : H12AffineFastState.Bounded env9155 := by
  intro p hp
  have h : env9155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9154_9155 : H12AffineEnvironment.transform 4 17 env9154 = env9155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9154 == env9155) = true)

theorem identity9155 : scanCanonicalize (H12AffineFastState.compose env9155 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9156 : List Nat := [2,4,8,16,17,10,24,30,11,30,0,16,9,11,1,19,16,17,31,1,11,17,17,19,24,17,1,16,17,17,4,1,31,0,17,11]

theorem envBound9156 : H12AffineFastState.Bounded env9156 := by
  intro p hp
  have h : env9156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9155_9156 : H12AffineEnvironment.transform 5 10 env9155 = env9156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9155 == env9156) = true)

theorem identity9156 : scanCanonicalize (H12AffineFastState.compose env9156 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9156 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9157 : List Nat := [2,4,8,10,11,10,2,4,11,4,0,10,9,11,1,9,10,11,5,1,11,11,11,9,2,11,1,10,11,11,4,1,5,0,11,11]

theorem envBound9157 : H12AffineFastState.Bounded env9157 := by
  intro p hp
  have h : env9157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9156_9157 : H12AffineEnvironment.transform 3 10 env9156 = env9157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9156 == env9157) = true)

def env9158 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855760,134217728,138678440,138678612,151259274,529049,155451871,524289,151257258,153358898,16778207]

theorem envBound9158 : H12AffineFastState.Bounded env9158 := by
  intro p hp
  have h : env9158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8529_9158 : H12AffineEnvironment.transform 9 257 env8529 = env9158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env8529 == env9158) = true)

def env9159 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855760,807680,4735912,4735572,17324938,529049,21517023,524289,17322922,19415346,16778207]

theorem envBound9159 : H12AffineFastState.Bounded env9159 := by
  intro p hp
  have h : env9159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9158_9159 : H12AffineEnvironment.transform 26 807680 env9158 = env9159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807680 env9158 == env9159) = true)

def env9160 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,90336,8329,21040,807680,4735912,4735572,605034,529049,4796991,524289,602954,2695634,90943]

theorem envBound9160 : H12AffineFastState.Bounded env9160 := by
  intro p hp
  have h : env9160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9159_9160 : H12AffineEnvironment.transform 23 90336 env9159 = env9160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9159 == env9160) = true)

def env9161 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5004,90336,8329,21040,278624,4214984,4215092,75786,505,4268383,4961,73770,2175666,90943]

theorem envBound9161 : H12AffineFastState.Bounded env9161 := by
  intro p hp
  have h : env9161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9160_9161 : H12AffineEnvironment.transform 18 4960 env9160 = env9161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9160 == env9161) = true)

theorem identity9161 : scanCanonicalize (H12AffineFastState.compose env9161 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9161 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9162 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,2097152,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4764,73770,2175666,90818]

theorem envBound9162 : H12AffineFastState.Bounded env9162 := by
  intro p hp
  have h : env9162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9161_9162 : H12AffineEnvironment.transform 7 253 env9161 = env9162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9161 == env9162) = true)

def env9163 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4764,73770,78578,90818]

theorem envBound9163 : H12AffineFastState.Bounded env9163 := by
  intro p hp
  have h : env9163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9162_9163 : H12AffineEnvironment.transform 20 64 env9162 = env9163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9162 == env9163) = true)

theorem identity9163 : scanCanonicalize (H12AffineFastState.compose env9163 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266299) := by decide +kernel

theorem selectedBound9163 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9164 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,266299,4721,90336,8329,21040,278624,278771,278770,75786,4,340121,4764,73770,78578,90818]

theorem envBound9164 : H12AffineFastState.Bounded env9164 := by
  intro p hp
  have h : env9164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9163_9164 : H12AffineEnvironment.transform 21 266299 env9163 = env9164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266299 env9163 == env9164) = true)

def env9165 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,94320,4765,8200,64,90187,4721,90336,8329,21040,77840,77955,77954,75786,4,16617,4764,73770,78578,90818]

theorem envBound9165 : H12AffineFastState.Bounded env9165 := by
  intro p hp
  have h : env9165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9164_9165 : H12AffineEnvironment.transform 17 94320 env9164 = env9165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94320 env9164 == env9165) = true)

theorem identity9165 : scanCanonicalize (H12AffineFastState.compose env9165 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound9165 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9166 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,8322,4096,20722,4765,8200,64,16585,4721,16482,8329,21040,4242,4097,4096,2184,4,16617,4764,168,4720,16960]

theorem envBound9166 : H12AffineFastState.Bounded env9166 := by
  intro p hp
  have h : env9166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9165_9166 : H12AffineEnvironment.transform 15 8322 env9165 = env9166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env9165 == env9166) = true)

theorem identity9166 : scanCanonicalize (H12AffineFastState.compose env9166 (packedSelected [0,2,11,13,14,17,18,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9166 : packedSelected [0,2,11,13,14,17,18,27] rootPS < 2^1333 := by decide +kernel

def env9167 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,17,8192,16384,8200,8322,17,16611,652,8200,64,16585,608,16482,8329,16929,131,16,17,2184,4,16617,653,168,609,16960]

theorem envBound9167 : H12AffineFastState.Bounded env9167 := by
  intro p hp
  have h : env9167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9166_9167 : H12AffineEnvironment.transform 11 17 env9166 = env9167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9166 == env9167) = true)

theorem identity9167 : scanCanonicalize (H12AffineFastState.compose env9167 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound9167 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9168 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,17,8192,185,8200,8322,17,90,652,8200,64,112,608,219,8329,664,131,16,17,2184,4,80,653,168,609,761]

theorem envBound9168 : H12AffineFastState.Bounded env9168 := by
  intro p hp
  have h : env9168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9167_9168 : H12AffineEnvironment.transform 13 185 env9167 = env9168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env9167 == env9168) = true)

theorem identity9168 : scanCanonicalize (H12AffineFastState.compose env9168 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9168 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9169 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,17,8192,65,8200,8314,17,90,628,8200,64,112,608,35,8305,608,123,16,17,2160,4,80,629,80,609,513]

theorem envBound9169 : H12AffineFastState.Bounded env9169 := by
  intro p hp
  have h : env9169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9168_9169 : H12AffineEnvironment.transform 6 120 env9168 = env9169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9168 == env9169) = true)

theorem identity9169 : scanCanonicalize (H12AffineFastState.compose env9169 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound9169 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9170 : List Nat := [2,4,8,16,32,64,120,5,512,4,602,17,8192,65,8200,8314,17,90,628,8200,64,112,608,35,8305,608,123,16,17,554,4,80,629,80,609,513]

theorem envBound9170 : H12AffineFastState.Bounded env9170 := by
  intro p hp
  have h : env9170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9169_9170 : H12AffineEnvironment.transform 10 602 env9169 = env9170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env9169 == env9170) = true)

theorem identity9170 : scanCanonicalize (H12AffineFastState.compose env9170 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound9170 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9171 : List Nat := [2,4,8,16,32,64,120,5,26,4,64,17,8192,65,8200,8314,17,90,110,8200,64,112,122,35,8305,122,123,16,17,48,4,80,111,80,123,27]

theorem envBound9171 : H12AffineFastState.Bounded env9171 := by
  intro p hp
  have h : env9171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9170_9171 : H12AffineEnvironment.transform 8 26 env9170 = env9171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env9170 == env9171) = true)

theorem identity9171 : scanCanonicalize (H12AffineFastState.compose env9171 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9171 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9172 : List Nat := [2,4,8,16,0,64,88,5,26,4,64,17,8192,65,8200,8282,17,90,78,8200,64,80,90,3,8273,90,91,16,17,16,4,80,79,80,91,27]

theorem envBound9172 : H12AffineFastState.Bounded env9172 := by
  intro p hp
  have h : env9172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9171_9172 : H12AffineEnvironment.transform 4 0 env9171 = env9172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9171 == env9172) = true)

theorem identity9172 : scanCanonicalize (H12AffineFastState.compose env9172 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound9172 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9173 : List Nat := [2,4,8,16,0,64,88,5,26,4,64,17,89,65,81,3,17,90,78,81,64,80,90,3,8,90,91,16,17,16,4,80,79,80,91,27]

theorem envBound9173 : H12AffineFastState.Bounded env9173 := by
  intro p hp
  have h : env9173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9172_9173 : H12AffineEnvironment.transform 12 89 env9172 = env9173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9172 == env9173) = true)

theorem identity9173 : scanCanonicalize (H12AffineFastState.compose env9173 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9173 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9174 : List Nat := [2,4,8,11,0,64,67,5,1,4,64,10,66,65,74,3,10,65,78,74,64,75,65,3,8,65,64,11,10,11,4,75,79,75,64,0]

theorem envBound9174 : H12AffineFastState.Bounded env9174 := by
  intro p hp
  have h : env9174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9173_9174 : H12AffineEnvironment.transform 3 11 env9173 = env9174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9173 == env9174) = true)

theorem identity9174 : scanCanonicalize (H12AffineFastState.compose env9174 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9175 : List Nat := [2,4,8,11,0,0,3,5,1,4,0,10,2,1,10,3,10,1,14,10,0,11,1,3,8,1,0,11,10,11,4,11,15,11,0,0]

theorem envBound9175 : H12AffineFastState.Bounded env9175 := by
  intro p hp
  have h : env9175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9174_9175 : H12AffineEnvironment.transform 5 0 env9174 = env9175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9174 == env9175) = true)

theorem identity9175 : scanCanonicalize (H12AffineFastState.compose env9175 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9175 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9176 : List Nat := [2,0,8,11,0,0,3,1,1,0,0,10,2,1,10,3,10,1,10,10,0,11,1,3,8,1,0,11,10,11,0,11,11,11,0,0]

theorem envBound9176 : H12AffineFastState.Bounded env9176 := by
  intro p hp
  have h : env9176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9175_9176 : H12AffineEnvironment.transform 1 0 env9175 = env9176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9175 == env9176) = true)

def env9177 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,94321,4765,8200,64,90186,4721,90336,8329,21040,77841,77954,77955,75786,4,16616,4764,73770,78578,90818]

theorem envBound9177 : H12AffineFastState.Bounded env9177 := by
  intro p hp
  have h : env9177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9164_9177 : H12AffineEnvironment.transform 17 94321 env9164 = env9177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94321 env9164 == env9177) = true)

theorem identity9177 : scanCanonicalize (H12AffineFastState.compose env9177 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9177 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9178 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,24770,4096,4275,4765,8200,64,136,4721,34,8329,21040,20691,20544,20545,18632,4,16616,4764,16616,21040,512]

theorem envBound9178 : H12AffineFastState.Bounded env9178 := by
  intro p hp
  have h : env9178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9177_9178 : H12AffineEnvironment.transform 15 24770 env9177 = env9178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9177 == env9178) = true)

theorem identity9178 : scanCanonicalize (H12AffineFastState.compose env9178 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9178 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9179 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,4096,8192,16384,8200,24683,4096,4122,4660,8200,64,33,4721,34,8224,21040,20602,20544,20545,18529,4,16449,4661,16449,21040,512]

theorem envBound9179 : H12AffineFastState.Bounded env9179 := by
  intro p hp
  have h : env9179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9178_9179 : H12AffineEnvironment.transform 6 41 env9178 = env9179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9178 == env9179) = true)

theorem identity9179 : scanCanonicalize (H12AffineFastState.compose env9179 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 6187) := by decide +kernel

theorem selectedBound9179 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9180 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,4096,8192,6187,8200,14400,4096,4122,4660,8200,64,33,4721,34,8224,2587,2129,2155,2154,4170,4,6250,4661,6250,2587,512]

theorem envBound9180 : H12AffineFastState.Bounded env9180 := by
  intro p hp
  have h : env9180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9179_9180 : H12AffineEnvironment.transform 13 6187 env9179 = env9180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6187 env9179 == env9180) = true)

theorem identity9180 : scanCanonicalize (H12AffineFastState.compose env9180 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound9180 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env9181 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,538,8192,2609,8200,10842,538,512,46,8200,64,33,107,34,8224,2587,2129,2155,2154,592,4,2672,47,2672,2587,512]

theorem envBound9181 : H12AffineFastState.Bounded env9181 := by
  intro p hp
  have h : env9181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9180_9181 : H12AffineEnvironment.transform 11 538 env9180 = env9181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env9180 == env9181) = true)

theorem identity9181 : scanCanonicalize (H12AffineFastState.compose env9181 (packedSelected [0,4,7,9,13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound9181 : packedSelected [0,4,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env9182 : List Nat := [2,4,8,16,32,64,41,84,512,85,544,538,8192,17,8200,8314,538,512,46,8200,64,33,107,34,8224,59,625,587,586,592,4,80,47,80,59,512]

theorem envBound9182 : H12AffineFastState.Bounded env9182 := by
  intro p hp
  have h : env9182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9181_9182 : H12AffineEnvironment.transform 10 544 env9181 = env9182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env9181 == env9182) = true)

theorem identity9182 : scanCanonicalize (H12AffineFastState.compose env9182 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound9182 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9183 : List Nat := [2,4,8,16,32,64,41,84,49,85,17,43,8192,17,8200,8314,43,49,46,8200,64,33,107,34,8224,59,64,122,123,97,4,80,47,80,59,49]

theorem envBound9183 : H12AffineFastState.Bounded env9183 := by
  intro p hp
  have h : env9183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9182_9183 : H12AffineEnvironment.transform 8 49 env9182 = env9183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env9182 == env9183) = true)

theorem identity9183 : scanCanonicalize (H12AffineFastState.compose env9183 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound9183 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9184 : List Nat := [2,4,8,16,32,64,41,84,49,85,17,43,41,17,33,83,43,49,46,33,64,33,107,34,9,59,64,122,123,97,4,80,47,80,59,49]

theorem envBound9184 : H12AffineFastState.Bounded env9184 := by
  intro p hp
  have h : env9184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9183_9184 : H12AffineEnvironment.transform 12 41 env9183 = env9184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env9183 == env9184) = true)

theorem identity9184 : scanCanonicalize (H12AffineFastState.compose env9184 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9184 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env9185 : List Nat := [2,4,8,16,32,16,41,4,49,5,17,43,41,17,33,3,43,49,46,33,16,33,59,34,9,59,16,42,43,49,4,0,47,0,59,49]

theorem envBound9185 : H12AffineFastState.Bounded env9185 := by
  intro p hp
  have h : env9185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9184_9185 : H12AffineEnvironment.transform 5 16 env9184 = env9185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9184 == env9185) = true)

theorem identity9185 : scanCanonicalize (H12AffineFastState.compose env9185 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9186 : List Nat := [2,4,8,16,0,16,9,4,17,5,17,11,9,17,1,3,11,17,14,1,16,1,27,2,9,27,16,10,11,17,4,0,15,0,27,17]

theorem envBound9186 : H12AffineFastState.Bounded env9186 := by
  intro p hp
  have h : env9186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9185_9186 : H12AffineEnvironment.transform 4 0 env9185 = env9186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9185 == env9186) = true)

def env9187 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4764,73770,78579,90818]

theorem envBound9187 : H12AffineFastState.Bounded env9187 := by
  intro p hp
  have h : env9187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9162_9187 : H12AffineEnvironment.transform 20 65 env9162 = env9187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9162 == env9187) = true)

theorem identity9187 : scanCanonicalize (H12AffineFastState.compose env9187 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262746) := by decide +kernel

theorem selectedBound9187 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9188 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,262746,4721,90336,8329,21040,278624,283282,283283,75786,4,336632,4764,73770,78579,90818]

theorem envBound9188 : H12AffineFastState.Bounded env9188 := by
  intro p hp
  have h : env9188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9187_9188 : H12AffineEnvironment.transform 21 262746 env9187 = env9188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262746 env9187 == env9188) = true)

def env9189 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8200,65536,4096,90856,4765,8200,65,90290,4721,90336,8329,21040,74376,77946,77947,75786,4,16400,4764,73770,78579,90818]

theorem envBound9189 : H12AffineFastState.Bounded env9189 := by
  intro p hp
  have h : env9189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9188_9189 : H12AffineEnvironment.transform 17 90856 env9188 = env9189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90856 env9188 == env9189) = true)

def env9190 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8200,65536,4096,73944,4765,8200,65,74370,4721,74448,8329,4096,74376,77946,77947,75786,4,544,4764,73770,78579,73970]

theorem envBound9190 : H12AffineFastState.Bounded env9190 := by
  intro p hp
  have h : env9190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9189_9190 : H12AffineEnvironment.transform 13 560 env9189 = env9190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9189 == env9190) = true)

theorem identity9190 : scanCanonicalize (H12AffineFastState.compose env9190 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9190 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9191 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,560,8200,65536,4096,73760,4709,8200,65,74362,4721,74280,8305,4096,74352,77946,77947,75786,4,544,4708,73770,78347,73738]

theorem envBound9191 : H12AffineFastState.Bounded env9191 := by
  intro p hp
  have h : env9191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9190_9191 : H12AffineEnvironment.transform 6 120 env9190 = env9191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9190 == env9191) = true)

theorem identity9191 : scanCanonicalize (H12AffineFastState.compose env9191 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound9191 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9192 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,560,8200,8251,4096,27,4709,8200,65,577,4721,531,8305,4096,587,4161,4160,2097,4,544,4708,17,4656,49]

theorem envBound9192 : H12AffineFastState.Bounded env9192 := by
  intro p hp
  have h : env9192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9191_9192 : H12AffineEnvironment.transform 15 8251 env9191 = env9192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env9191 == env9192) = true)

theorem identity9192 : scanCanonicalize (H12AffineFastState.compose env9192 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound9192 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9193 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,2586,8192,560,8200,8251,2586,27,2175,8200,65,577,2155,531,8305,2586,587,2651,2650,2097,4,544,2174,17,2090,49]

theorem envBound9193 : H12AffineFastState.Bounded env9193 := by
  intro p hp
  have h : env9193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9192_9193 : H12AffineEnvironment.transform 11 2586 env9192 = env9193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env9192 == env9193) = true)

theorem identity9193 : scanCanonicalize (H12AffineFastState.compose env9193 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound9193 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9194 : List Nat := [2,4,8,16,32,64,120,5,49,4,2048,2091,8192,1,8200,8251,2091,27,2175,8200,65,112,2155,34,8305,2091,122,2154,2155,2097,4,17,2174,17,2090,49]

theorem envBound9194 : H12AffineFastState.Bounded env9194 := by
  intro p hp
  have h : env9194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9193_9194 : H12AffineEnvironment.transform 8 49 env9193 = env9194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env9193 == env9194) = true)

theorem identity9194 : scanCanonicalize (H12AffineFastState.compose env9194 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9194 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9195 : List Nat := [2,4,8,16,32,16,40,5,49,4,2048,2091,8192,1,8200,8251,2091,27,2095,8200,17,32,2107,34,8225,2091,42,2106,2107,2097,4,17,2094,17,2090,49]

theorem envBound9195 : H12AffineFastState.Bounded env9195 := by
  intro p hp
  have h : env9195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9194_9195 : H12AffineEnvironment.transform 5 16 env9194 = env9195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9194 == env9195) = true)

theorem identity9195 : scanCanonicalize (H12AffineFastState.compose env9195 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound9195 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9196 : List Nat := [2,4,8,16,32,16,40,5,49,4,2048,2091,2088,1,2080,2067,2091,27,2095,2080,17,32,2107,34,2057,2091,42,2106,2107,2097,4,17,2094,17,2090,49]

theorem envBound9196 : H12AffineFastState.Bounded env9196 := by
  intro p hp
  have h : env9196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9195_9196 : H12AffineEnvironment.transform 12 2088 env9195 = env9196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env9195 == env9196) = true)

theorem identity9196 : scanCanonicalize (H12AffineFastState.compose env9196 (packedSelected [3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound9196 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env9197 : List Nat := [2,4,8,16,32,16,40,5,49,4,42,1,2,1,10,57,1,27,5,10,17,32,17,34,35,1,42,16,17,27,4,17,4,17,0,49]

theorem envBound9197 : H12AffineFastState.Bounded env9197 := by
  intro p hp
  have h : env9197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9196_9197 : H12AffineEnvironment.transform 10 42 env9196 = env9197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env9196 == env9197) = true)

theorem identity9197 : scanCanonicalize (H12AffineFastState.compose env9197 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9198 : List Nat := [2,4,8,0,32,0,40,5,33,4,42,1,2,1,10,41,1,11,5,10,1,32,1,34,35,1,42,0,1,11,4,1,4,1,0,33]

theorem envBound9198 : H12AffineFastState.Bounded env9198 := by
  intro p hp
  have h : env9198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9197_9198 : H12AffineEnvironment.transform 3 0 env9197 = env9198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9197 == env9198) = true)

theorem identity9198 : scanCanonicalize (H12AffineFastState.compose env9198 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9198 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9199 : List Nat := [2,4,8,0,1,0,9,5,0,4,11,1,2,1,10,8,1,11,5,10,1,1,1,3,2,1,11,0,1,11,4,1,4,1,0,0]

theorem envBound9199 : H12AffineFastState.Bounded env9199 := by
  intro p hp
  have h : env9199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9198_9199 : H12AffineEnvironment.transform 4 1 env9198 = env9199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9198 == env9199) = true)

theorem identity9199 : scanCanonicalize (H12AffineFastState.compose env9199 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9200 : List Nat := [2,4,2,0,1,0,3,5,0,4,1,1,2,1,0,2,1,1,5,0,1,1,1,3,2,1,1,0,1,1,4,1,4,1,0,0]

theorem envBound9200 : H12AffineFastState.Bounded env9200 := by
  intro p hp
  have h : env9200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9199_9200 : H12AffineEnvironment.transform 2 2 env9199 = env9200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9199 == env9200) = true)

def env9201 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8200,65536,4096,73945,4765,8200,65,74371,4721,74449,8329,4097,74376,77946,77947,75786,4,545,4764,73770,78579,73971]

theorem envBound9201 : H12AffineFastState.Bounded env9201 := by
  intro p hp
  have h : env9201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9189_9201 : H12AffineEnvironment.transform 13 561 env9189 = env9201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9189 == env9201) = true)

def env9202 : List Nat := [2,4,8,16,32,64,128,253,216,252,2048,4096,8192,233,8200,65536,4096,73945,4165,8200,65,73819,4265,73737,8329,4097,73808,77946,77947,75786,4,249,4164,73770,77867,73971]

theorem envBound9202 : H12AffineFastState.Bounded env9202 := by
  intro p hp
  have h : env9202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9201_9202 : H12AffineEnvironment.transform 8 216 env9201 = env9202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9201 == env9202) = true)

theorem identity9202 : scanCanonicalize (H12AffineFastState.compose env9202 (packedSelected [14] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9202 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9203 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,4096,8192,16,8200,65536,4096,73760,4165,8200,65,73819,4176,73737,8304,4097,73808,77946,77947,75786,4,0,4164,73770,77867,73738]

theorem envBound9203 : H12AffineFastState.Bounded env9203 := by
  intro p hp
  have h : env9203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9202_9203 : H12AffineEnvironment.transform 6 121 env9202 = env9203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9202 == env9203) = true)

theorem identity9203 : scanCanonicalize (H12AffineFastState.compose env9203 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9203 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9204 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,4096,8192,16,8200,14401,4096,6241,4165,8200,65,6170,4176,6216,8304,4097,6161,2107,2106,4171,4,0,4164,6251,2154,6219]

theorem envBound9204 : H12AffineFastState.Bounded env9204 := by
  intro p hp
  have h : env9204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9203_9204 : H12AffineEnvironment.transform 15 14401 env9203 = env9204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9203 == env9204) = true)

theorem identity9204 : scanCanonicalize (H12AffineFastState.compose env9204 (packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9204 : packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env9205 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,2106,8192,16,8200,8315,2106,91,2175,8200,65,32,2154,114,8304,2107,43,2107,2106,2161,4,0,2174,81,2154,113]

theorem envBound9205 : H12AffineFastState.Bounded env9205 := by
  intro p hp
  have h : env9205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9204_9205 : H12AffineEnvironment.transform 11 2106 env9204 = env9205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env9204 == env9205) = true)

theorem identity9205 : scanCanonicalize (H12AffineFastState.compose env9205 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9205 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9206 : List Nat := [2,4,8,16,27,64,66,4,26,5,2048,2049,8192,16,8200,8256,2049,91,2116,8200,65,27,2129,73,8267,2048,16,2048,2049,2122,4,0,2117,81,2129,74]

theorem envBound9206 : H12AffineFastState.Bounded env9206 := by
  intro p hp
  have h : env9206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9205_9206 : H12AffineEnvironment.transform 4 27 env9205 = env9206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9205 == env9206) = true)

theorem identity9206 : scanCanonicalize (H12AffineFastState.compose env9206 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound9206 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9207 : List Nat := [2,4,8,16,27,64,66,4,26,5,65,64,8192,16,8200,8256,64,91,5,8200,65,27,16,73,8267,65,16,65,64,11,4,0,4,81,16,74]

theorem envBound9207 : H12AffineFastState.Bounded env9207 := by
  intro p hp
  have h : env9207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9206_9207 : H12AffineEnvironment.transform 10 65 env9206 = env9207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env9206 == env9207) = true)

theorem identity9207 : scanCanonicalize (H12AffineFastState.compose env9207 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound9207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9208 : List Nat := [2,4,8,16,27,64,66,4,26,5,65,64,89,16,81,25,64,91,5,81,65,27,16,73,18,65,16,65,64,11,4,0,4,81,16,74]

theorem envBound9208 : H12AffineFastState.Bounded env9208 := by
  intro p hp
  have h : env9208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9207_9208 : H12AffineEnvironment.transform 12 89 env9207 = env9208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9207 == env9208) = true)

theorem identity9208 : scanCanonicalize (H12AffineFastState.compose env9208 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9208 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9209 : List Nat := [2,4,8,16,27,16,18,4,26,5,17,16,9,16,1,25,16,11,5,1,17,27,16,25,18,17,16,17,16,11,4,0,4,1,16,26]

theorem envBound9209 : H12AffineFastState.Bounded env9209 := by
  intro p hp
  have h : env9209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9208_9209 : H12AffineEnvironment.transform 5 16 env9208 = env9209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9208 == env9209) = true)

theorem identity9209 : scanCanonicalize (H12AffineFastState.compose env9209 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9210 : List Nat := [2,4,2,16,17,16,18,4,16,5,17,16,3,16,1,19,16,1,5,1,17,17,16,19,18,17,16,17,16,1,4,0,4,1,16,16]

theorem envBound9210 : H12AffineFastState.Bounded env9210 := by
  intro p hp
  have h : env9210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0