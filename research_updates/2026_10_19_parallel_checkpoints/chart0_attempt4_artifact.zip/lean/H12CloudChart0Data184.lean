import H12CloudChart0Data183

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound46593 : H12AffineFastState.Bounded env46593 := by
  intro p hp
  have h : env46593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46592_46593 : H12AffineEnvironment.transform 9 52 env46592 = env46593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46592 == env46593) = true)

theorem identity46593 : scanCanonicalize (H12AffineFastState.compose env46593 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound46593 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46594 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,10,19,26,1,25,10,522,14,0,26,27,17,3,18,17,522,11,11,522,20,27,31,26,26,513]

theorem envBound46594 : H12AffineFastState.Bounded env46594 := by
  intro p hp
  have h : env46594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46593_46594 : H12AffineEnvironment.transform 4 26 env46593 = env46594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env46593 == env46594) = true)

def leafEnv46594 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,10,19,26,1,25,10,522,14,0,26,27,17,3,20,18,1,17,522,11,11,522,20,27,31,26,4,24,26,513,1,26,0]

def active46594 : List Nat := [0,1,2,3,8]

def tree46594 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46594 : H12WitnessSearch.Good tree46594 := H12GlobalWitnessIndex.good

theorem leafIdentity46594 : H12AffineFastState.composeSystem env46594 rootObs = leafEnv46594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46594 rootObs == leafEnv46594) = true)

theorem terminalChecked46594 : H12PackedTerminal.terminalCheckFast leafEnv46594 active46594 tree46594 = true := by decide +kernel

def env46595 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,41,33,1,35,49,561,53,0,32,33,17,3,40,17,561,48,49,561,21,33,37,32,33,513]

theorem envBound46595 : H12AffineFastState.Bounded env46595 := by
  intro p hp
  have h : env46595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46592_46595 : H12AffineEnvironment.transform 9 53 env46592 = env46595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46592 == env46595) = true)

theorem identity46595 : scanCanonicalize (H12AffineFastState.compose env46595 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46596 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,48,41,33,1,35,49,33,53,0,32,33,17,3,40,17,33,48,49,33,21,33,37,32,33,17]

theorem envBound46596 : H12AffineFastState.Bounded env46596 := by
  intro p hp
  have h : env46596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46595_46596 : H12AffineEnvironment.transform 8 16 env46595 = env46596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46595 == env46596) = true)

def leafEnv46596 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,48,41,33,1,35,49,33,53,0,32,33,17,3,21,40,1,17,33,48,49,33,21,33,37,32,4,34,33,17,1,32,0]

def active46596 : List Nat := [0,1,2,3,4]

def tree46596 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46596 : H12WitnessSearch.Good tree46596 := H12GlobalWitnessIndex.good

theorem leafIdentity46596 : H12AffineFastState.composeSystem env46596 rootObs = leafEnv46596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46596 rootObs == leafEnv46596) = true)

theorem terminalChecked46596 : H12PackedTerminal.terminalCheckFast leafEnv46596 active46596 tree46596 = true := by decide +kernel

def env46597 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,1,35,1029,2048,1024,0,33,33,17,3,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound46597 : H12AffineFastState.Bounded env46597 := by
  intro p hp
  have h : env46597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46590_46597 : H12AffineEnvironment.transform 11 49 env46590 = env46597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46590 == env46597) = true)

theorem identity46597 : scanCanonicalize (H12AffineFastState.compose env46597 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound46597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46598 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,49,41,1045,1,35,1029,561,1024,0,33,33,17,3,40,17,561,1028,48,561,1056,33,37,32,1045,513]

theorem envBound46598 : H12AffineFastState.Bounded env46598 := by
  intro p hp
  have h : env46598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46597_46598 : H12AffineEnvironment.transform 10 561 env46597 = env46598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env46597 == env46598) = true)

def env46599 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,41,33,1,35,49,561,52,0,33,33,17,3,40,17,561,48,48,561,20,33,37,32,33,513]

theorem envBound46599 : H12AffineFastState.Bounded env46599 := by
  intro p hp
  have h : env46599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46598_46599 : H12AffineEnvironment.transform 9 52 env46598 = env46599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46598 == env46599) = true)

theorem identity46599 : scanCanonicalize (H12AffineFastState.compose env46599 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound46599 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46600 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,10,18,26,1,24,10,522,15,0,26,26,17,3,19,17,522,11,11,522,20,26,30,27,26,513]

theorem envBound46600 : H12AffineFastState.Bounded env46600 := by
  intro p hp
  have h : env46600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46599_46600 : H12AffineEnvironment.transform 4 27 env46599 = env46600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env46599 == env46600) = true)

def leafEnv46600 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,10,18,26,1,24,10,522,15,0,26,26,17,3,20,19,1,17,522,11,11,522,20,26,30,27,4,25,26,513,1,26,0]

def active46600 : List Nat := [0,1,2,3,8]

def tree46600 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46600 : H12WitnessSearch.Good tree46600 := H12GlobalWitnessIndex.good

theorem leafIdentity46600 : H12AffineFastState.composeSystem env46600 rootObs = leafEnv46600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46600 rootObs == leafEnv46600) = true)

theorem terminalChecked46600 : H12PackedTerminal.terminalCheckFast leafEnv46600 active46600 tree46600 = true := by decide +kernel

def env46601 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,41,32,1,35,48,561,53,0,33,33,17,3,40,17,561,49,48,561,21,33,37,32,32,513]

theorem envBound46601 : H12AffineFastState.Bounded env46601 := by
  intro p hp
  have h : env46601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46598_46601 : H12AffineEnvironment.transform 9 53 env46598 = env46601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46598 == env46601) = true)

theorem identity46601 : scanCanonicalize (H12AffineFastState.compose env46601 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46602 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,49,41,32,1,35,48,32,53,0,33,33,17,3,40,17,32,49,48,32,21,33,37,32,32,16]

theorem envBound46602 : H12AffineFastState.Bounded env46602 := by
  intro p hp
  have h : env46602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46601_46602 : H12AffineEnvironment.transform 8 17 env46601 = env46602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46601 == env46602) = true)

def leafEnv46602 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,49,41,32,1,35,48,32,53,0,33,33,17,3,21,40,1,17,32,49,48,32,21,33,37,32,4,34,32,16,1,33,0]

def active46602 : List Nat := [0,1,2,3,4]

def tree46602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46602 : H12WitnessSearch.Good tree46602 := H12GlobalWitnessIndex.good

theorem leafIdentity46602 : H12AffineFastState.composeSystem env46602 rootObs = leafEnv46602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46602 rootObs == leafEnv46602) = true)

theorem terminalChecked46602 : H12PackedTerminal.terminalCheckFast leafEnv46602 active46602 tree46602 = true := by decide +kernel

def env46603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400500,499129,8328,65,295420,395637,416100,56436,1501,272393,256,21793,46213,74250]

theorem envBound46603 : H12AffineFastState.Bounded env46603 := by
  intro p hp
  have h : env46603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46576_46603 : H12AffineEnvironment.transform 20 4161 env46576 = env46603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46576 == env46603) = true)

theorem identity46603 : scanCanonicalize (H12AffineFastState.compose env46603 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound46603 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4161,180272,73755,41430,8328,65,245139,79130,91403,56436,1501,201830,256,21793,46213,74250]

theorem envBound46604 : H12AffineFastState.Bounded env46604 := by
  intro p hp
  have h : env46604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46603_46604 : H12AffineEnvironment.transform 17 212079 env46603 = env46604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env46603 == env46604) = true)

def env46605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212031,1024,32769,4113,180272,73755,41350,8328,17,245139,79130,91403,56356,1421,201782,256,21793,46213,74250]

theorem envBound46605 : H12AffineFastState.Bounded env46605 := by
  intro p hp
  have h : env46605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46604_46605 : H12AffineEnvironment.transform 5 16 env46604 = env46605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46604 == env46605) = true)

theorem identity46605 : scanCanonicalize (H12AffineFastState.compose env46605 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound46605 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env46606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,32041,1024,32769,4113,98598,73755,41350,8328,17,64645,79130,91403,56356,1421,21792,256,21793,46213,74250]

theorem envBound46606 : H12AffineFastState.Bounded env46606 := by
  intro p hp
  have h : env46606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46605_46606 : H12AffineEnvironment.transform 16 82198 env46605 = env46606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env46605 == env46606) = true)

theorem identity46606 : scanCanonicalize (H12AffineFastState.compose env46606 (packedSelected [1,3,4,7,9,17,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound46606 : packedSelected [1,3,4,7,9,17,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,32041,1024,32769,4113,21928,62613,41350,8328,17,64645,57748,45445,56356,1421,21792,256,21793,46213,63108]

theorem envBound46607 : H12AffineFastState.Bounded env46607 := by
  intro p hp
  have h : env46607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46606_46607 : H12AffineEnvironment.transform 15 54414 env46606 = env46607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env46606 == env46607) = true)

theorem identity46607 : scanCanonicalize (H12AffineFastState.compose env46607 (packedSelected [0,3,5,6,7,10,14,15,20,23] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound46607 : packedSelected [0,3,5,6,7,10,14,15,20,23] rootPS < 2^1333 := by decide +kernel

def env46608 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,8192,16384,32768,53694,37032,30745,304,32769,4113,20632,61861,41350,8328,17,63925,57748,45445,55572,189,20496,256,20497,45493,62388]

theorem envBound46608 : H12AffineFastState.Bounded env46608 := by
  intro p hp
  have h : env46608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46607_46608 : H12AffineEnvironment.transform 9 304 env46607 = env46608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env46607 == env46608) = true)

theorem identity46608 : scanCanonicalize (H12AffineFastState.compose env46608 (packedSelected [5,9,11,14,15,19,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound46608 : packedSelected [5,9,11,14,15,19,22,24] rootPS < 2^1333 := by decide +kernel

def env46609 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,300,16384,32768,53694,37032,22837,304,32769,4113,20632,53385,32938,420,17,55449,49336,37033,55572,189,20496,256,20497,37017,53912]

theorem envBound46609 : H12AffineFastState.Bounded env46609 := by
  intro p hp
  have h : env46609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46608_46609 : H12AffineEnvironment.transform 12 300 env46608 = env46609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env46608 == env46609) = true)

theorem identity46609 : scanCanonicalize (H12AffineFastState.compose env46609 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4280) := by decide +kernel

theorem selectedBound46609 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env46610 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,300,4280,32768,33030,37032,2445,304,32769,4113,32,32817,32938,420,17,34849,36864,37033,35244,189,168,256,169,37017,33312]

theorem envBound46610 : H12AffineFastState.Bounded env46610 := by
  intro p hp
  have h : env46610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46609_46610 : H12AffineEnvironment.transform 13 4280 env46609 = env46610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4280 env46609 == env46610) = true)

theorem identity46610 : scanCanonicalize (H12AffineFastState.compose env46610 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46610 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46611 : List Nat := [2,4,8,16,32,16,128,4,512,52,2048,4096,40,4280,32768,32770,37032,2185,52,32769,4113,32,32817,32938,160,17,34849,36864,37033,34984,189,168,4,169,37017,33312]

theorem envBound46611 : H12AffineFastState.Bounded env46611 := by
  intro p hp
  have h : env46611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46610_46611 : H12AffineEnvironment.transform 7 4 env46610 = env46611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46610 == env46611) = true)

theorem identity46611 : scanCanonicalize (H12AffineFastState.compose env46611 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound46611 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46612 : List Nat := [2,4,8,16,32,16,128,4,512,52,2048,4096,40,4280,1,3,4265,2185,52,0,4113,32,48,171,160,17,2080,4097,4264,2217,189,168,4,169,4248,545]

theorem envBound46612 : H12AffineFastState.Bounded env46612 := by
  intro p hp
  have h : env46612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46611_46612 : H12AffineEnvironment.transform 14 1 env46611 = env46612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46611 == env46612) = true)

theorem identity46612 : scanCanonicalize (H12AffineFastState.compose env46612 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound46612 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46613 : List Nat := [2,4,8,16,32,16,40,4,512,52,2048,4096,40,4112,1,3,4097,2081,52,0,4113,32,48,3,8,17,2080,4097,4096,2049,21,0,4,1,4144,545]

theorem envBound46613 : H12AffineFastState.Bounded env46613 := by
  intro p hp
  have h : env46613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46612_46613 : H12AffineEnvironment.transform 6 40 env46612 = env46613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env46612 == env46613) = true)

theorem identity46613 : scanCanonicalize (H12AffineFastState.compose env46613 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound46613 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46614 : List Nat := [2,4,8,16,32,16,40,4,512,52,2048,2096,40,2080,1,3,2097,2081,52,0,2081,32,48,3,8,17,2080,2097,2096,2049,21,0,4,1,2048,545]

theorem envBound46614 : H12AffineFastState.Bounded env46614 := by
  intro p hp
  have h : env46614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46613_46614 : H12AffineEnvironment.transform 11 2096 env46613 = env46614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env46613 == env46614) = true)

theorem identity46614 : scanCanonicalize (H12AffineFastState.compose env46614 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46614 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46615 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2065,9,2049,1,3,2064,2048,21,0,2048,1,17,3,8,17,2049,2064,2065,2049,21,0,4,1,2048,512]

theorem envBound46615 : H12AffineFastState.Bounded env46615 := by
  intro p hp
  have h : env46615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46614_46615 : H12AffineEnvironment.transform 4 1 env46614 = env46615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46614 == env46615) = true)

def env46616 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212030,1024,32769,4112,180272,73755,41351,8328,16,245139,79130,91403,56357,1420,201783,256,21793,46213,74250]

theorem envBound46616 : H12AffineFastState.Bounded env46616 := by
  intro p hp
  have h : env46616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46604_46616 : H12AffineEnvironment.transform 5 17 env46604 = env46616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46604 == env46616) = true)

theorem identity46616 : scanCanonicalize (H12AffineFastState.compose env46616 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound46616 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env46617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,56493,1024,32769,4112,73891,73755,41351,8328,16,23808,79130,91403,56357,1420,62628,256,21793,46213,74250]

theorem envBound46617 : H12AffineFastState.Bounded env46617 := by
  intro p hp
  have h : env46617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46616_46617 : H12AffineEnvironment.transform 16 123027 env46616 = env46617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env46616 == env46617) = true)

theorem identity46617 : scanCanonicalize (H12AffineFastState.compose env46617 (packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound46617 : packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env46618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,56493,1024,32769,4112,62508,62612,41351,8328,16,23808,57749,45444,56357,1420,62628,256,21793,46213,63109]

theorem envBound46618 : H12AffineFastState.Bounded env46618 := by
  intro p hp
  have h : env46618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46617_46618 : H12AffineEnvironment.transform 15 54415 env46617 = env46618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env46617 == env46618) = true)

theorem identity46618 : scanCanonicalize (H12AffineFastState.compose env46618 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound46618 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env46619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,13340,10280,1024,29828,4112,169,17,21762,8328,16,23808,5392,17665,10400,1420,33,256,21793,16384,512]

theorem envBound46619 : H12AffineFastState.Bounded env46619 := by
  intro p hp
  have h : env46619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46618_46619 : H12AffineEnvironment.transform 14 29829 env46618 = env46619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env46618 == env46619) = true)

theorem identity46619 : scanCanonicalize (H12AffineFastState.compose env46619 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46619 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46620 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29829,8202,13340,10280,1024,29828,4112,169,17,21678,8328,16,23724,5308,17581,10400,1056,33,172,21645,16384,512]

theorem envBound46620 : H12AffineFastState.Bounded env46620 := by
  intro p hp
  have h : env46620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46619_46620 : H12AffineEnvironment.transform 7 172 env46619 = env46620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46619 == env46620) = true)

theorem identity46620 : scanCanonicalize (H12AffineFastState.compose env46620 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound46620 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46621 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,20632,1047,4097,3125,1024,20633,4112,169,17,21678,1173,16,23724,5308,17581,3261,1056,33,172,21645,16384,512]

theorem envBound46621 : H12AffineFastState.Bounded env46621 := by
  intro p hp
  have h : env46621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46620_46621 : H12AffineEnvironment.transform 12 1053 env46620 = env46621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env46620 == env46621) = true)

theorem identity46621 : scanCanonicalize (H12AffineFastState.compose env46621 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound46621 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env46622 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,4248,0,1047,4097,3125,1024,1,4112,169,17,1078,1173,16,3124,5308,5173,3261,1056,33,172,1045,4248,512]

theorem envBound46622 : H12AffineFastState.Bounded env46622 := by
  intro p hp
  have h : env46622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46621_46622 : H12AffineEnvironment.transform 13 4248 env46621 = env46622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env46621 == env46622) = true)

theorem identity46622 : scanCanonicalize (H12AffineFastState.compose env46622 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound46622 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46623 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2097,1053,2217,0,1047,2096,3125,1024,1,2081,169,17,1078,1173,16,3124,3213,3076,3261,1056,33,172,1045,2217,512]

theorem envBound46623 : H12AffineFastState.Bounded env46623 := by
  intro p hp
  have h : env46623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46622_46623 : H12AffineEnvironment.transform 11 2097 env46622 = env46623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env46622 == env46623) = true)

theorem identity46623 : scanCanonicalize (H12AffineFastState.compose env46623 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46623 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env46624 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1212,1165,1053,1045,0,1047,1164,137,1024,1,1181,169,17,1078,1173,16,136,49,184,1,1056,33,172,1045,1045,512]

theorem envBound46624 : H12AffineFastState.Bounded env46624 := by
  intro p hp
  have h : env46624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46623_46624 : H12AffineEnvironment.transform 10 1212 env46623 = env46624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env46623 == env46624) = true)

theorem identity46624 : scanCanonicalize (H12AffineFastState.compose env46624 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46624 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46625 : List Nat := [2,4,8,16,1,17,128,141,512,1024,1181,1165,1053,1045,0,1047,1164,137,1024,1,1181,136,17,1047,1173,16,136,16,153,1,1025,0,141,1045,1045,512]

theorem envBound46625 : H12AffineFastState.Bounded env46625 := by
  intro p hp
  have h : env46625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46624_46625 : H12AffineEnvironment.transform 4 1 env46624 = env46625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46624 == env46625) = true)

theorem identity46625 : scanCanonicalize (H12AffineFastState.compose env46625 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound46625 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46626 : List Nat := [2,4,8,16,1,17,128,141,512,21,136,152,8,0,0,2,153,137,21,1,136,136,17,2,128,16,136,16,153,1,20,0,141,0,0,512]

theorem envBound46626 : H12AffineFastState.Bounded env46626 := by
  intro p hp
  have h : env46626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46625_46626 : H12AffineEnvironment.transform 9 21 env46625 = env46626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env46625 == env46626) = true)

def env46627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493493,499129,8328,65,2396604,2496820,416100,2149429,2102684,2373705,256,21793,46213,2175563]

theorem envBound46627 : H12AffineFastState.Bounded env46627 := by
  intro p hp
  have h : env46627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46575_46627 : H12AffineEnvironment.transform 21 180273 env46575 = env46627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env46575 == env46627) = true)

def env46628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400501,499129,8328,65,295420,395636,416100,56437,1500,272393,256,21793,46213,74251]

theorem envBound46628 : H12AffineFastState.Bounded env46628 := by
  intro p hp
  have h : env46628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46627_46628 : H12AffineEnvironment.transform 20 4160 env46627 = env46628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46627 == env46628) = true)

theorem identity46628 : scanCanonicalize (H12AffineFastState.compose env46628 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound46628 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,180273,120015,21763,8328,65,215366,115150,102878,56437,1500,254131,256,21793,46213,74251]

theorem envBound46629 : H12AffineFastState.Bounded env46629 := by
  intro p hp
  have h : env46629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46628_46629 : H12AffineEnvironment.transform 17 247994 env46628 = env46629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env46628 == env46629) = true)

def env46630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130174,1024,32769,4160,62709,120015,21763,8328,65,97666,115150,102878,56437,1500,119927,256,21793,46213,74251]

theorem envBound46630 : H12AffineFastState.Bounded env46630 := by
  intro p hp
  have h : env46630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46629_46630 : H12AffineEnvironment.transform 16 13508 env46629 = env46630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env46629 == env46630) = true)

def env46631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4160,62589,119879,21763,8192,65,97546,115014,102742,56437,1364,119927,256,21793,46093,74251]

theorem envBound46631 : H12AffineFastState.Bounded env46631 := by
  intro p hp
  have h : env46631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46630_46631 : H12AffineEnvironment.transform 6 8 env46630 = env46631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46630 == env46631) = true)

theorem identity46631 : scanCanonicalize (H12AffineFastState.compose env46631 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound46631 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,13388,35189,1024,32769,4160,62589,41292,21763,8192,65,2049,46157,58461,56437,1364,41340,256,21793,46093,22272]

theorem envBound46632 : H12AffineFastState.Bounded env46632 := by
  intro p hp
  have h : env46632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46631_46632 : H12AffineEnvironment.transform 15 29963 env46631 = env46632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env46631 == env46632) = true)

theorem identity46632 : scanCanonicalize (H12AffineFastState.compose env46632 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46632 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env46633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21590,5393,35189,1024,32769,4160,54560,32785,21763,349,65,2049,38160,50432,56437,1364,32801,256,21793,38224,22272]

theorem envBound46633 : H12AffineFastState.Bounded env46633 := by
  intro p hp
  have h : env46633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46632_46633 : H12AffineEnvironment.transform 12 349 env46632 = env46633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46632 == env46633) = true)

theorem identity46633 : scanCanonicalize (H12AffineFastState.compose env46633 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46633 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env46634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21590,5393,2421,1024,1,4160,21792,17,21763,349,65,2049,5392,17664,23669,1364,33,256,21793,5456,22272]

theorem envBound46634 : H12AffineFastState.Bounded env46634 := by
  intro p hp
  have h : env46634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46633_46634 : H12AffineEnvironment.transform 14 0 env46633 = env46634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46633 == env46634) = true)

theorem identity46634 : scanCanonicalize (H12AffineFastState.compose env46634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound46634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,0,1094,5393,2421,1024,1,4160,1328,17,1299,349,65,2049,5392,5392,3173,1364,33,256,1329,5456,1808]

theorem envBound46635 : H12AffineFastState.Bounded env46635 := by
  intro p hp
  have h : env46635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46634_46635 : H12AffineEnvironment.transform 13 4112 env46634 = env46635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env46634 == env46635) = true)

theorem identity46635 : scanCanonicalize (H12AffineFastState.compose env46635 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46635 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env46636 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,349,4112,0,263,4176,2421,321,1,4160,113,17,82,349,65,2049,4177,4177,2340,21,33,256,112,4113,593]

theorem envBound46636 : H12AffineFastState.Bounded env46636 := by
  intro p hp
  have h : env46636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46635_46636 : H12AffineEnvironment.transform 9 321 env46635 = env46636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46635 == env46636) = true)

theorem identity46636 : scanCanonicalize (H12AffineFastState.compose env46636 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound46636 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46637 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,349,2129,0,263,2065,2421,321,1,2049,113,17,82,349,65,2049,2064,2064,2340,21,33,256,112,2128,593]

theorem envBound46637 : H12AffineFastState.Bounded env46637 := by
  intro p hp
  have h : env46637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46636_46637 : H12AffineEnvironment.transform 11 2113 env46636 = env46637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env46636 == env46637) = true)

def env46638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4160,62588,119878,21763,8193,65,97547,115015,102743,56437,1365,119927,256,21793,46092,74251]

theorem envBound46638 : H12AffineFastState.Bounded env46638 := by
  intro p hp
  have h : env46638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46630_46638 : H12AffineEnvironment.transform 6 9 env46630 = env46638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46630 == env46638) = true)

theorem identity46638 : scanCanonicalize (H12AffineFastState.compose env46638 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound46638 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,10281,1024,32769,4160,62588,17,21763,8193,65,43356,5392,17664,56437,1365,32,256,21793,46092,63068]

theorem envBound46639 : H12AffineFastState.Bounded env46639 := by
  intro p hp
  have h : env46639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46638_46639 : H12AffineEnvironment.transform 15 54359 env46638 = env46639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env46638 == env46639) = true)

def env46640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130175,1024,32769,4160,62708,120015,21763,8328,65,97667,115150,102878,56437,1500,119926,256,21793,46213,74251]

theorem envBound46640 : H12AffineFastState.Bounded env46640 := by
  intro p hp
  have h : env46640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46629_46640 : H12AffineEnvironment.transform 16 13509 env46629 = env46640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env46629 == env46640) = true)

def env46641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4160,62588,119879,21763,8192,65,97547,115014,102742,56437,1364,119926,256,21793,46093,74251]

theorem envBound46641 : H12AffineFastState.Bounded env46641 := by
  intro p hp
  have h : env46641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46640_46641 : H12AffineEnvironment.transform 6 8 env46640 = env46641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46640 == env46641) = true)

theorem identity46641 : scanCanonicalize (H12AffineFastState.compose env46641 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46641 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13389,89378,1024,8540,4160,21793,95514,21763,8192,65,97547,90139,77835,32040,1364,95531,256,21793,5456,74251]

theorem envBound46642 : H12AffineFastState.Bounded env46642 := by
  intro p hp
  have h : env46642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46641_46642 : H12AffineEnvironment.transform 14 8541 env46641 = env46642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46641 == env46642) = true)

theorem identity46642 : scanCanonicalize (H12AffineFastState.compose env46642 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46642 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env46643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,34,13389,23808,1024,8540,4160,21793,30008,21763,8192,65,32041,24633,12329,32040,1364,29961,256,21793,5456,8745]

theorem envBound46643 : H12AffineFastState.Bounded env46643 := by
  intro p hp
  have h : env46643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46642_46643 : H12AffineEnvironment.transform 15 34 env46642 = env46643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46642 == env46643) = true)

theorem identity46643 : scanCanonicalize (H12AffineFastState.compose env46643 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46643 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env46644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,34,5393,23808,1024,0,4160,21793,21604,21763,348,65,23669,16741,4469,23668,1364,21589,256,21793,5456,885]

theorem envBound46644 : H12AffineFastState.Bounded env46644 := by
  intro p hp
  have h : env46644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46643_46644 : H12AffineEnvironment.transform 12 348 env46643 = env46644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46643 == env46644) = true)

theorem identity46644 : scanCanonicalize (H12AffineFastState.compose env46644 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46644 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46645 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,34,5393,23808,1024,0,4113,21793,21557,21763,269,16,23588,16692,4388,23589,1285,21508,256,21793,5377,804]

theorem envBound46645 : H12AffineFastState.Bounded env46645 := by
  intro p hp
  have h : env46645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46644_46645 : H12AffineEnvironment.transform 5 17 env46644 = env46645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46644 == env46645) = true)

theorem identity46645 : scanCanonicalize (H12AffineFastState.compose env46645 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46645 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46646 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,16384,1,34,5172,23589,1024,0,4113,21508,21557,21542,40,16,23588,16401,4097,23589,1056,21508,37,21508,5156,513]

theorem envBound46646 : H12AffineFastState.Bounded env46646 := by
  intro p hp
  have h : env46646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46645_46646 : H12AffineEnvironment.transform 7 37 env46645 = env46646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46645 == env46646) = true)

theorem identity46646 : scanCanonicalize (H12AffineFastState.compose env46646 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound46646 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env46647 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4113,32,17,2,40,16,2048,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound46647 : H12AffineFastState.Bounded env46647 := by
  intro p hp
  have h : env46647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46646_46647 : H12AffineEnvironment.transform 13 5156 env46646 = env46647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env46646 == env46647) = true)

def env46648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4160,62589,119878,21763,8193,65,97546,115015,102743,56437,1365,119926,256,21793,46092,74251]

theorem envBound46648 : H12AffineFastState.Bounded env46648 := by
  intro p hp
  have h : env46648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46640_46648 : H12AffineEnvironment.transform 6 9 env46640 = env46648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46640 == env46648) = true)

theorem identity46648 : scanCanonicalize (H12AffineFastState.compose env46648 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound46648 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env46649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,10281,1024,32769,4160,62589,16,21763,8193,65,43356,5393,17665,56437,1365,32,256,21793,46092,63069]

theorem envBound46649 : H12AffineFastState.Bounded env46649 := by
  intro p hp
  have h : env46649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46648_46649 : H12AffineEnvironment.transform 15 54358 env46648 = env46649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env46648 == env46649) = true)

theorem identity46649 : scanCanonicalize (H12AffineFastState.compose env46649 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46649 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13388,10281,1024,29789,4160,33,16,21763,8193,65,23808,5393,17665,10281,1365,32,256,21793,16464,513]

theorem envBound46650 : H12AffineFastState.Bounded env46650 := by
  intro p hp
  have h : env46650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46649_46650 : H12AffineEnvironment.transform 14 29788 env46649 = env46650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46649 == env46650) = true)

theorem identity46650 : scanCanonicalize (H12AffineFastState.compose env46650 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound46650 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env46651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8202,13388,10281,1024,81,4160,33,16,8463,8193,65,10508,5393,12557,10281,1365,32,256,8493,13404,513]

theorem envBound46651 : H12AffineFastState.Bounded env46651 := by
  intro p hp
  have h : env46651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46650_46651 : H12AffineEnvironment.transform 13 13324 env46650 = env46651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env46650 == env46651) = true)

theorem identity46651 : scanCanonicalize (H12AffineFastState.compose env46651 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46651 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46652 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,13341,10281,1024,0,4113,33,16,8463,8193,16,10508,5393,12557,10281,1284,32,256,8493,13325,513]

theorem envBound46652 : H12AffineFastState.Bounded env46652 := by
  intro p hp
  have h : env46652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46651_46652 : H12AffineEnvironment.transform 5 17 env46651 = env46652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46651 == env46652) = true)

theorem identity46652 : scanCanonicalize (H12AffineFastState.compose env46652 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46652 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46653 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,13324,1,8202,13341,10281,1024,0,4113,33,16,8203,8193,16,10248,5141,12297,10281,1024,32,4,8233,13325,513]

theorem envBound46653 : H12AffineFastState.Bounded env46653 := by
  intro p hp
  have h : env46653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46652_46653 : H12AffineEnvironment.transform 7 4 env46652 = env46653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46652 == env46653) = true)

theorem identity46653 : scanCanonicalize (H12AffineFastState.compose env46653 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound46653 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46654 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,5124,1,2,5141,2081,1024,0,4113,33,16,3,9,16,2048,5141,4097,2081,1024,32,4,33,5125,513]

theorem envBound46654 : H12AffineFastState.Bounded env46654 := by
  intro p hp
  have h : env46654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46653_46654 : H12AffineEnvironment.transform 12 8 env46653 = env46654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env46653 == env46654) = true)

theorem identity46654 : scanCanonicalize (H12AffineFastState.compose env46654 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46655 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,1,2,5141,2048,1024,0,4113,0,16,3,9,16,2048,5141,4097,2048,1024,1,4,0,5125,513]

theorem envBound46655 : H12AffineFastState.Bounded env46655 := by
  intro p hp
  have h : env46655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46654_46655 : H12AffineEnvironment.transform 4 1 env46654 = env46655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46654 == env46655) = true)

theorem identity46655 : scanCanonicalize (H12AffineFastState.compose env46655 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46655 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46656 : List Nat := [2,4,8,16,1,17,9,4,512,1024,522,4096,8,5124,1,2,5141,522,1024,0,4113,0,16,3,9,16,522,5141,4097,522,1024,1,4,0,5125,513]

theorem envBound46656 : H12AffineFastState.Bounded env46656 := by
  intro p hp
  have h : env46656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46655_46656 : H12AffineEnvironment.transform 10 522 env46655 = env46656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46655 == env46656) = true)

def env46657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400500,499129,8328,65,295421,395637,416100,56436,1501,272392,256,21793,46213,74250]

theorem envBound46657 : H12AffineFastState.Bounded env46657 := by
  intro p hp
  have h : env46657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46627_46657 : H12AffineEnvironment.transform 20 4161 env46627 = env46657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46627 == env46657) = true)

theorem identity46657 : scanCanonicalize (H12AffineFastState.compose env46657 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46657 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,180273,400500,441778,8328,65,295421,395637,416100,56436,1501,272392,256,21793,46213,513]

theorem envBound46658 : H12AffineFastState.Bounded env46658 := by
  intro p hp
  have h : env46658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46657_46658 : H12AffineEnvironment.transform 15 8203 env46657 = env46658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46657 == env46658) = true)

def env46659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4161,32801,285796,327074,8328,65,295421,280933,268660,56436,1501,272392,256,21793,46213,513]

theorem envBound46659 : H12AffineFastState.Bounded env46659 := by
  intro p hp
  have h : env46659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46658_46659 : H12AffineEnvironment.transform 16 16400 env46658 = env46659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46658 == env46659) = true)

theorem identity46659 : scanCanonicalize (H12AffineFastState.compose env46659 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound46659 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,23668,1024,32769,4161,32801,16,41430,8328,65,56713,5393,17664,56436,1501,29820,256,21793,46213,513]

theorem envBound46660 : H12AffineFastState.Bounded env46660 := by
  intro p hp
  have h : env46660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46659_46660 : H12AffineEnvironment.transform 17 23668 env46659 = env46660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env46659 == env46660) = true)

theorem identity46660 : scanCanonicalize (H12AffineFastState.compose env46660 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound46660 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8203,16400,23668,1024,137,4161,169,16,8542,8328,65,23809,5393,17664,23804,1501,29820,256,21793,13325,513]

theorem envBound46661 : H12AffineFastState.Bounded env46661 := by
  intro p hp
  have h : env46661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46660_46661 : H12AffineEnvironment.transform 14 136 env46660 = env46661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env46660 == env46661) = true)

theorem identity46661 : scanCanonicalize (H12AffineFastState.compose env46661 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound46661 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env46662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,479,16400,23668,1024,137,4161,169,16,138,348,65,23809,5393,17664,23804,1501,21928,256,21793,5593,513]

theorem envBound46662 : H12AffineFastState.Bounded env46662 := by
  intro p hp
  have h : env46662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46661_46662 : H12AffineEnvironment.transform 12 468 env46661 = env46662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env46661 == env46662) = true)

theorem identity46662 : scanCanonicalize (H12AffineFastState.compose env46662 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound46662 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,479,5529,2557,1024,137,4161,169,16,138,348,65,2184,5393,4233,2421,1501,33,256,168,5593,513]

theorem envBound46663 : H12AffineFastState.Bounded env46663 := by
  intro p hp
  have h : env46663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46662_46663 : H12AffineEnvironment.transform 13 5513 env46662 = env46663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env46662 == env46663) = true)

theorem identity46663 : scanCanonicalize (H12AffineFastState.compose env46663 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound46663 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,508,468,1141,136,479,1125,2557,1024,137,445,169,16,138,348,65,2184,1261,373,2421,1501,33,256,168,1061,513]

theorem envBound46664 : H12AffineFastState.Bounded env46664 := by
  intro p hp
  have h : env46664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46663_46664 : H12AffineEnvironment.transform 11 508 env46663 = env46664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env46663 == env46664) = true)

theorem identity46664 : scanCanonicalize (H12AffineFastState.compose env46664 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46664 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env46665 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,0,40,1141,136,35,1125,2049,1024,137,65,169,16,138,160,65,2184,1261,137,2185,1057,33,252,168,1061,513]

theorem envBound46665 : H12AffineFastState.Bounded env46665 := by
  intro p hp
  have h : env46665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46664_46665 : H12AffineEnvironment.transform 7 252 env46664 = env46665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46664 == env46665) = true)

def env46666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,32800,285797,327075,8328,65,295421,280932,268661,56436,1501,272392,256,21793,46213,513]

theorem envBound46666 : H12AffineFastState.Bounded env46666 := by
  intro p hp
  have h : env46666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46658_46666 : H12AffineEnvironment.transform 16 16401 env46658 = env46666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46658 == env46666) = true)

def env46667 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4113,32800,285749,327075,8328,17,295341,280884,268581,56356,1421,272392,256,21793,46213,513]

theorem envBound46667 : H12AffineFastState.Bounded env46667 := by
  intro p hp
  have h : env46667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46666_46667 : H12AffineEnvironment.transform 5 16 env46666 = env46667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46666 == env46667) = true)

theorem identity46667 : scanCanonicalize (H12AffineFastState.compose env46667 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound46667 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env46668 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56357,1024,32769,4113,32800,32784,8582,8328,17,23944,38161,50432,56356,1421,62509,256,21793,46213,513]

theorem envBound46668 : H12AffineFastState.Bounded env46668 := by
  intro p hp
  have h : env46668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46667_46668 : H12AffineEnvironment.transform 17 56357 env46667 = env46668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env46667 == env46668) = true)

theorem identity46668 : scanCanonicalize (H12AffineFastState.compose env46668 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46668 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env46669 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56357,1024,32769,4113,32800,32784,8462,8192,17,23808,38161,50432,56356,1285,62509,256,21793,46093,513]

theorem envBound46669 : H12AffineFastState.Bounded env46669 := by
  intro p hp
  have h : env46669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46668_46669 : H12AffineEnvironment.transform 6 8 env46668 = env46669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46668 == env46669) = true)

theorem identity46669 : scanCanonicalize (H12AffineFastState.compose env46669 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound46669 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46670 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,16384,32768,1046,16401,56357,1024,32769,4113,32800,32784,1299,1053,17,23808,38161,50432,56356,1285,53296,256,21793,36880,513]

theorem envBound46670 : H12AffineFastState.Bounded env46670 := by
  intro p hp
  have h : env46670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46669_46670 : H12AffineEnvironment.transform 12 1053 env46669 = env46670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env46669 == env46670) = true)

theorem identity46670 : scanCanonicalize (H12AffineFastState.compose env46670 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46670 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env46671 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,16384,32768,34,16401,55313,52,32769,4113,32800,32784,295,41,17,22836,37157,49460,55312,305,53296,256,20757,36880,513]

theorem envBound46671 : H12AffineFastState.Bounded env46671 := by
  intro p hp
  have h : env46671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46670_46671 : H12AffineEnvironment.transform 9 52 env46670 = env46671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46670 == env46671) = true)

theorem identity46671 : scanCanonicalize (H12AffineFastState.compose env46671 (packedSelected [3,5,10,11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound46671 : packedSelected [3,5,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env46672 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,16384,20497,34,16401,2048,52,20496,4113,20529,20481,295,41,17,22836,16692,4389,2049,305,33,256,20757,16385,513]

theorem envBound46672 : H12AffineFastState.Bounded env46672 := by
  intro p hp
  have h : env46672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46671_46672 : H12AffineEnvironment.transform 14 20497 env46671 = env46672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env46671 == env46672) = true)

theorem identity46672 : scanCanonicalize (H12AffineFastState.compose env46672 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound46672 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46673 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,512,4625,34,529,2048,52,4624,4113,4657,4609,295,41,17,6964,820,4389,2049,305,33,256,4885,513,513]

theorem envBound46673 : H12AffineFastState.Bounded env46673 := by
  intro p hp
  have h : env46673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46672_46673 : H12AffineEnvironment.transform 13 512 env46672 = env46673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env46672 == env46673) = true)

theorem identity46673 : scanCanonicalize (H12AffineFastState.compose env46673 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound46673 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46674 : List Nat := [2,4,8,16,32,16,8,256,512,52,820,4096,41,512,4625,34,529,820,52,4624,4113,4657,4609,295,41,17,4096,820,4389,821,305,33,256,4885,513,513]

theorem envBound46674 : H12AffineFastState.Bounded env46674 := by
  intro p hp
  have h : env46674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46673_46674 : H12AffineEnvironment.transform 10 820 env46673 = env46674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env46673 == env46674) = true)

theorem identity46674 : scanCanonicalize (H12AffineFastState.compose env46674 (packedSelected [3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46674 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env46675 : List Nat := [2,4,8,16,17,16,8,256,512,5,773,4096,24,512,4625,19,529,773,5,4624,4113,4608,4609,278,24,17,4096,773,4372,772,256,16,256,4885,513,513]

theorem envBound46675 : H12AffineFastState.Bounded env46675 := by
  intro p hp
  have h : env46675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46674_46675 : H12AffineEnvironment.transform 4 17 env46674 = env46675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46674 == env46675) = true)

theorem identity46675 : scanCanonicalize (H12AffineFastState.compose env46675 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound46675 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46676 : List Nat := [2,4,8,16,17,16,8,256,512,5,773,772,24,512,277,19,529,773,5,276,789,260,261,278,24,17,772,773,528,772,256,16,256,17,513,513]

theorem envBound46676 : H12AffineFastState.Bounded env46676 := by
  intro p hp
  have h : env46676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46675_46676 : H12AffineEnvironment.transform 11 772 env46675 = env46676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env46675 == env46676) = true)

theorem identity46676 : scanCanonicalize (H12AffineFastState.compose env46676 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46676 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46677 : List Nat := [2,4,8,0,1,0,8,256,512,5,773,772,8,512,261,3,513,773,5,260,773,260,261,262,8,1,772,773,512,772,256,0,256,1,513,513]

theorem envBound46677 : H12AffineFastState.Bounded env46677 := by
  intro p hp
  have h : env46677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46676_46677 : H12AffineEnvironment.transform 3 0 env46676 = env46677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46676 == env46677) = true)

theorem identity46677 : scanCanonicalize (H12AffineFastState.compose env46677 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46677 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46678 : List Nat := [2,4,8,0,1,0,8,5,512,5,512,513,8,512,0,3,513,512,5,1,512,1,0,3,8,1,513,512,512,513,5,0,5,1,513,513]

theorem envBound46678 : H12AffineFastState.Bounded env46678 := by
  intro p hp
  have h : env46678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46677_46678 : H12AffineEnvironment.transform 7 5 env46677 = env46678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46677 == env46678) = true)

theorem identity46678 : scanCanonicalize (H12AffineFastState.compose env46678 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46678 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46679 : List Nat := [2,4,8,0,1,0,8,5,1,5,1,0,8,1,0,3,0,1,5,1,1,1,0,3,8,1,0,1,1,0,5,0,5,1,0,0]

theorem envBound46679 : H12AffineFastState.Bounded env46679 := by
  intro p hp
  have h : env46679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46678_46679 : H12AffineEnvironment.transform 8 1 env46678 = env46679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46678 == env46679) = true)

def env46680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4112,32800,285748,327075,8328,16,295340,280885,268580,56357,1420,272392,256,21793,46213,513]

theorem envBound46680 : H12AffineFastState.Bounded env46680 := by
  intro p hp
  have h : env46680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46666_46680 : H12AffineEnvironment.transform 5 17 env46666 = env46680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46666 == env46680) = true)

theorem identity46680 : scanCanonicalize (H12AffineFastState.compose env46680 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46680 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env46681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,5392,262144,1024,32769,4112,32800,264501,305314,8328,16,295340,269364,268580,35108,1420,272392,256,32,46213,513]

theorem envBound46681 : H12AffineFastState.Bounded env46681 := by
  intro p hp
  have h : env46681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46680_46681 : H12AffineEnvironment.transform 13 5377 env46680 = env46681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46680 == env46681) = true)

theorem identity46681 : scanCanonicalize (H12AffineFastState.compose env46681 (packedSelected [1,5,7,8,11,14,17,20,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound46681 : packedSelected [1,5,7,8,11,14,17,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env46682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,5392,10280,1024,32769,4112,32800,8477,32906,8328,16,43396,13340,12556,35108,1420,32,256,32,46213,513]

theorem envBound46682 : H12AffineFastState.Bounded env46682 := by
  intro p hp
  have h : env46682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46681_46682 : H12AffineEnvironment.transform 17 10280 env46681 = env46682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46681 == env46682) = true)

theorem identity46682 : scanCanonicalize (H12AffineFastState.compose env46682 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound46682 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env46683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,5377,32768,1047,5392,3124,1024,32769,4112,32800,1281,32906,1172,16,36248,4096,5392,35108,1420,32,256,32,37017,513]

theorem envBound46683 : H12AffineFastState.Bounded env46683 := by
  intro p hp
  have h : env46683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46682_46683 : H12AffineEnvironment.transform 12 1052 env46682 = env46683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env46682 == env46683) = true)

theorem identity46683 : scanCanonicalize (H12AffineFastState.compose env46683 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound46683 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env46684 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,5377,7425,1047,5392,3124,1024,7424,4112,7457,1281,7563,1172,16,4249,4096,5392,5157,1420,32,256,32,3480,513]

theorem envBound46684 : H12AffineFastState.Bounded env46684 := by
  intro p hp
  have h : env46684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46683_46684 : H12AffineEnvironment.transform 14 7425 env46683 = env46684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env46683 == env46684) = true)

theorem identity46684 : scanCanonicalize (H12AffineFastState.compose env46684 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound46684 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env46685 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,4249,6297,399,4232,2476,408,6296,4112,6329,153,6163,268,16,4249,4096,4232,4541,20,32,256,32,2048,513]

theorem envBound46685 : H12AffineFastState.Bounded env46685 := by
  intro p hp
  have h : env46685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46684_46685 : H12AffineEnvironment.transform 9 408 env46684 = env46685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env46684 == env46685) = true)

def env46686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound46686 : H12AffineFastState.Bounded env46686 := by
  intro p hp
  have h : env46686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46450_46686 : H12AffineEnvironment.transform 18 1025 env46450 = env46686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46450 == env46686) = true)

theorem identity46686 : scanCanonicalize (H12AffineFastState.compose env46686 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485428) := by decide +kernel

theorem selectedBound46686 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485428,8328,65,14822580,288824,10507601,8830977,10774692,4491637,257,8661016,8702397,10833778]

theorem envBound46687 : H12AffineFastState.Bounded env46687 := by
  intro p hp
  have h : env46687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46686_46687 : H12AffineEnvironment.transform 23 2485428 env46686 = env46687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485428 env46686 == env46687) = true)

def env46688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294200,2485428,8328,65,6705548,288824,2369641,179513,2102684,4491637,257,21792,46213,2175562]

theorem envBound46688 : H12AffineFastState.Bounded env46688 := by
  intro p hp
  have h : env46688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46687_46688 : H12AffineEnvironment.transform 22 294200 env46687 = env46688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294200 env46687 == env46688) = true)

def env46689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294200,98780,8328,65,4340964,288824,17665,179513,293108,4491637,257,21792,46213,352034]

theorem envBound46689 : H12AffineFastState.Bounded env46689 := by
  intro p hp
  have h : env46689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46688_46689 : H12AffineEnvironment.transform 20 290152 env46688 = env46689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env46688 == env46689) = true)

def env46690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294200,98780,8328,65,398436,288824,17665,179513,293108,41461,257,21792,46213,352034]

theorem envBound46690 : H12AffineFastState.Bounded env46690 := by
  intro p hp
  have h : env46690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46689_46690 : H12AffineEnvironment.transform 21 272512 env46689 = env46690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46689 == env46690) = true)

theorem identity46690 : scanCanonicalize (H12AffineFastState.compose env46690 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound46690 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,290152,272512,294200,21762,8328,65,398436,288824,17665,179513,293108,41461,257,21792,46213,297980]

theorem envBound46691 : H12AffineFastState.Bounded env46691 := by
  intro p hp
  have h : env46691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46690_46691 : H12AffineEnvironment.transform 15 54494 env46690 = env46691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env46690 == env46691) = true)

def env46692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146864,1025,32769,151768,136496,147592,21762,8328,65,10708,152968,17665,179513,148804,41461,257,21792,46213,177740]

theorem envBound46692 : H12AffineFastState.Bounded env46692 := by
  intro p hp
  have h : env46692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46691_46692 : H12AffineEnvironment.transform 17 146864 env46691 = env46692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env46691 == env46692) = true)

theorem identity46692 : scanCanonicalize (H12AffineFastState.compose env46692 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound46692 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46157,35325,1025,32769,58517,41341,62661,21762,8328,65,10708,57797,17665,2420,61705,41461,257,21792,46213,513]

theorem envBound46693 : H12AffineFastState.Bounded env46693 := by
  intro p hp
  have h : env46693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46692_46693 : H12AffineEnvironment.transform 16 46157 env46692 = env46693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env46692 == env46693) = true)

theorem identity46693 : scanCanonicalize (H12AffineFastState.compose env46693 (packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound46693 : packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env46694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33110,46157,35325,1025,32769,45341,41341,41293,138,8328,65,10708,46157,4233,2420,42113,41461,257,168,46213,513]

theorem envBound46694 : H12AffineFastState.Bounded env46694 := by
  intro p hp
  have h : env46694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46693_46694 : H12AffineEnvironment.transform 13 5512 env46693 = env46694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env46693 == env46694) = true)

theorem identity46694 : scanCanonicalize (H12AffineFastState.compose env46694 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46694 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,5392,10400,1025,8540,4160,32,16,138,8328,65,10708,5392,4233,2420,1500,168,257,168,5592,513]

theorem envBound46695 : H12AffineFastState.Bounded env46695 := by
  intro p hp
  have h : env46695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46694_46695 : H12AffineEnvironment.transform 14 8541 env46694 = env46695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46694 == env46695) = true)

theorem identity46695 : scanCanonicalize (H12AffineFastState.compose env46695 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46695 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1025,8540,4160,32,16,3,8193,65,10589,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound46696 : H12AffineFastState.Bounded env46696 := by
  intro p hp
  have h : env46696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46695_46696 : H12AffineEnvironment.transform 6 9 env46695 = env46696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46695 == env46696) = true)

theorem identity46696 : scanCanonicalize (H12AffineFastState.compose env46696 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound46696 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,292,114,5392,2128,1025,293,4160,32,16,3,120,65,2340,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound46697 : H12AffineFastState.Bounded env46697 := by
  intro p hp
  have h : env46697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46696_46697 : H12AffineEnvironment.transform 12 121 env46696 = env46697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env46696 == env46697) = true)

theorem identity46697 : scanCanonicalize (H12AffineFastState.compose env46697 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1808) := by decide +kernel

theorem selectedBound46697 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1808,121,529,292,114,512,2128,1025,293,1872,32,16,3,120,65,2340,512,1808,2420,1365,33,257,33,577,513]

theorem envBound46698 : H12AffineFastState.Bounded env46698 := by
  intro p hp
  have h : env46698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46697_46698 : H12AffineEnvironment.transform 11 1808 env46697 = env46698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1808 env46697 == env46698) = true)

def env46699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146865,1025,32769,151769,136497,147593,21762,8328,65,10709,152969,17665,179513,148805,41461,257,21792,46213,177741]

theorem envBound46699 : H12AffineFastState.Bounded env46699 := by
  intro p hp
  have h : env46699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46691_46699 : H12AffineEnvironment.transform 17 146865 env46691 = env46699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env46691 == env46699) = true)

theorem identity46699 : scanCanonicalize (H12AffineFastState.compose env46699 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound46699 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46276,35189,1025,32769,58397,41461,62541,21762,8328,65,10709,57677,17665,2557,61825,41461,257,21792,46213,649]

theorem envBound46700 : H12AffineFastState.Bounded env46700 := by
  intro p hp
  have h : env46700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46699_46700 : H12AffineEnvironment.transform 16 46276 env46699 = env46700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env46699 == env46700) = true)

theorem identity46700 : scanCanonicalize (H12AffineFastState.compose env46700 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46700 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env46701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46156,35189,1025,32769,58397,41341,62541,21762,8192,65,10589,57677,17665,2421,61705,41341,257,21792,46093,513]

theorem envBound46701 : H12AffineFastState.Bounded env46701 := by
  intro p hp
  have h : env46701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46700_46701 : H12AffineEnvironment.transform 6 8 env46700 = env46701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46700 == env46701) = true)

theorem identity46701 : scanCanonicalize (H12AffineFastState.compose env46701 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound46701 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env46702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30042,5440,10361,1025,8461,17681,113,21825,21762,8192,65,10589,16449,17665,2421,20485,113,257,21792,5377,513]

theorem envBound46702 : H12AffineFastState.Bounded env46702 := by
  intro p hp
  have h : env46702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46701_46702 : H12AffineEnvironment.transform 14 8460 env46701 = env46702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env46701 == env46702) = true)

theorem identity46702 : scanCanonicalize (H12AffineFastState.compose env46702 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46702 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8202,5440,10361,1025,8461,4161,113,17,82,8192,65,10589,5393,4177,2421,1365,113,257,112,5377,513]

theorem envBound46703 : H12AffineFastState.Bounded env46703 := by
  intro p hp
  have h : env46703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46702_46703 : H12AffineEnvironment.transform 13 5456 env46702 = env46703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46702 == env46703) = true)

theorem identity46703 : scanCanonicalize (H12AffineFastState.compose env46703 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound46703 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46704 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,4096,8192,5221,8249,8202,5237,10361,1025,8248,4161,113,17,82,8192,65,10344,5156,4177,2112,1120,113,52,112,5172,513]

theorem envBound46704 : H12AffineFastState.Bounded env46704 := by
  intro p hp
  have h : env46704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46703_46704 : H12AffineEnvironment.transform 7 53 env46703 = env46704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env46703 == env46704) = true)

theorem identity46704 : scanCanonicalize (H12AffineFastState.compose env46704 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 3661) := by decide +kernel

theorem selectedBound46704 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env46705 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,4096,3661,5221,3700,3655,5237,1588,1025,3701,4161,113,17,82,3661,65,1573,5156,4177,2112,1120,113,52,112,5172,513]

theorem envBound46705 : H12AffineFastState.Bounded env46705 := by
  intro p hp
  have h : env46705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46704_46705 : H12AffineEnvironment.transform 12 3661 env46704 = env46705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3661 env46704 == env46705) = true)

theorem identity46705 : scanCanonicalize (H12AffineFastState.compose env46705 (packedSelected [14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46705 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env46706 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,4096,3612,5172,3621,3606,5156,1588,1025,3620,4112,32,17,3,3612,16,1573,5156,4096,2065,1073,32,52,33,5172,513]

theorem envBound46706 : H12AffineFastState.Bounded env46706 := by
  intro p hp
  have h : env46706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46705_46706 : H12AffineEnvironment.transform 5 17 env46705 = env46706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46705 == env46706) = true)

theorem identity46706 : scanCanonicalize (H12AffineFastState.compose env46706 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46707 : List Nat := [2,4,8,16,16,17,8,5,512,1024,2048,4096,3612,5124,3605,3606,5140,1540,1025,3604,4112,16,17,3,3612,16,1557,5140,4096,2065,1025,16,4,17,5124,513]

theorem envBound46707 : H12AffineFastState.Bounded env46707 := by
  intro p hp
  have h : env46707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46706_46707 : H12AffineEnvironment.transform 4 16 env46706 = env46707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46706 == env46707) = true)

theorem identity46707 : scanCanonicalize (H12AffineFastState.compose env46707 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound46707 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46708 : List Nat := [2,4,8,16,16,17,8,5,512,1024,1557,4096,9,5124,0,3,5140,1540,1025,1,4112,16,17,3,9,16,1557,5140,4096,1540,1025,16,4,17,5124,513]

theorem envBound46708 : H12AffineFastState.Bounded env46708 := by
  intro p hp
  have h : env46708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46707_46708 : H12AffineEnvironment.transform 10 1557 env46707 = env46708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env46707 == env46708) = true)

theorem identity46708 : scanCanonicalize (H12AffineFastState.compose env46708 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound46708 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46709 : List Nat := [2,4,8,16,16,17,8,5,512,532,1,4096,9,4624,0,3,4608,16,533,1,4112,16,17,3,9,16,1,4608,4096,16,533,16,4,17,4624,513]

theorem envBound46709 : H12AffineFastState.Bounded env46709 := by
  intro p hp
  have h : env46709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46708_46709 : H12AffineEnvironment.transform 9 532 env46708 = env46709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env46708 == env46709) = true)

theorem identity46709 : scanCanonicalize (H12AffineFastState.compose env46709 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46709 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46710 : List Nat := [2,4,8,16,16,17,8,5,0,20,1,4096,9,4112,0,3,4096,16,21,1,4112,16,17,3,9,16,1,4096,4096,16,21,16,4,17,4112,1]

theorem envBound46710 : H12AffineFastState.Bounded env46710 := by
  intro p hp
  have h : env46710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46709_46710 : H12AffineEnvironment.transform 8 0 env46709 = env46710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46709 == env46710) = true)

theorem identity46710 : scanCanonicalize (H12AffineFastState.compose env46710 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46711 : List Nat := [2,4,8,16,16,17,8,5,0,20,1,1,9,17,0,3,1,16,21,1,17,16,17,3,9,16,1,1,1,16,21,16,4,17,17,1]

theorem envBound46711 : H12AffineFastState.Bounded env46711 := by
  intro p hp
  have h : env46711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46710_46711 : H12AffineEnvironment.transform 11 1 env46710 = env46711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46710 == env46711) = true)

def env46712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294200,98780,8328,65,398437,288824,17665,179513,293108,41460,257,21792,46213,352034]

theorem envBound46712 : H12AffineFastState.Bounded env46712 := by
  intro p hp
  have h : env46712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46689_46712 : H12AffineEnvironment.transform 21 272513 env46689 = env46712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46689 == env46712) = true)

theorem identity46712 : scanCanonicalize (H12AffineFastState.compose env46712 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109047) := by decide +kernel

theorem selectedBound46712 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109047,1025,32769,115871,98678,120015,98780,8328,65,245138,115151,17665,179513,119043,41460,257,21792,46213,63189]

theorem envBound46713 : H12AffineFastState.Bounded env46713 := by
  intro p hp
  have h : env46713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46712_46713 : H12AffineEnvironment.transform 17 109047 env46712 = env46713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109047 env46712 == env46713) = true)

def env46714 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108967,1025,32769,115871,98598,119967,98700,8328,17,245138,115103,17665,179513,119043,41380,257,21792,46213,63109]

theorem envBound46714 : H12AffineFastState.Bounded env46714 := by
  intro p hp
  have h : env46714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46713_46714 : H12AffineEnvironment.transform 5 16 env46713 = env46714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46713 == env46714) = true)

theorem identity46714 : scanCanonicalize (H12AffineFastState.compose env46714 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound46714 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46715 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46108,108967,1025,32769,115871,98598,119967,98700,8328,17,67982,115103,17665,2341,119043,41380,257,21792,46213,63109]

theorem envBound46715 : H12AffineFastState.Bounded env46715 := by
  intro p hp
  have h : env46715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46714_46715 : H12AffineEnvironment.transform 16 46108 env46714 = env46715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env46714 == env46715) = true)

theorem identity46715 : scanCanonicalize (H12AffineFastState.compose env46715 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound46715 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env46716 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8322,46108,35109,1025,32769,58397,41380,62493,41230,8328,17,10508,57629,17665,2341,61825,41380,257,21792,46213,63109]

theorem envBound46716 : H12AffineFastState.Bounded env46716 := by
  intro p hp
  have h : env46716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46715_46716 : H12AffineEnvironment.transform 15 8322 env46715 = env46716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env46715 == env46716) = true)

theorem identity46716 : scanCanonicalize (H12AffineFastState.compose env46716 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46716 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46717 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,399,38161,35109,1025,32769,50448,32937,54544,32771,389,17,2049,49168,17665,2341,53388,32937,257,21792,38280,55176]

theorem envBound46717 : H12AffineFastState.Bounded env46717 := by
  intro p hp
  have h : env46717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46716_46717 : H12AffineEnvironment.transform 12 269 env46716 = env46717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46716 == env46717) = true)

theorem identity46717 : scanCanonicalize (H12AffineFastState.compose env46717 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound46717 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46718 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21761,399,16400,23588,1025,21760,4113,21928,17,21762,389,17,2049,5393,17665,2341,1421,21928,257,21792,16521,649]

theorem envBound46718 : H12AffineFastState.Bounded env46718 := by
  intro p hp
  have h : env46718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46717_46718 : H12AffineEnvironment.transform 14 21761 env46717 = env46718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env46717 == env46718) = true)

theorem identity46718 : scanCanonicalize (H12AffineFastState.compose env46718 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound46718 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46719 : List Nat := [2,4,8,16,32,16,128,256,512,565,2048,4096,269,16384,21300,399,16400,23057,564,21301,4113,21405,17,21303,389,17,2049,4900,17204,2341,952,21405,257,21269,16521,649]

theorem envBound46719 : H12AffineFastState.Bounded env46719 := by
  intro p hp
  have h : env46719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46718_46719 : H12AffineEnvironment.transform 9 565 env46718 = env46719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env46718 == env46719) = true)

theorem identity46719 : scanCanonicalize (H12AffineFastState.compose env46719 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5052) := by decide +kernel

theorem selectedBound46719 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46720 : List Nat := [2,4,8,16,32,16,128,256,512,565,2048,4096,269,5052,136,399,5036,2477,564,137,4113,33,17,139,389,17,2049,4900,4232,2341,952,33,257,169,4917,649]

theorem envBound46720 : H12AffineFastState.Bounded env46720 := by
  intro p hp
  have h : env46720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46719_46720 : H12AffineEnvironment.transform 13 5052 env46719 = env46720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5052 env46719 == env46720) = true)

theorem identity46720 : scanCanonicalize (H12AffineFastState.compose env46720 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound46720 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46721 : List Nat := [2,4,8,16,32,16,128,256,292,273,2048,4096,269,4248,136,399,4232,2477,272,137,4113,33,17,139,389,17,2049,4096,4232,2341,156,33,257,169,4113,429]

theorem envBound46721 : H12AffineFastState.Bounded env46721 := by
  intro p hp
  have h : env46721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46720_46721 : H12AffineEnvironment.transform 8 292 env46720 = env46721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env46720 == env46721) = true)

theorem identity46721 : scanCanonicalize (H12AffineFastState.compose env46721 (packedSelected [0,1,2,5,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound46721 : packedSelected [0,1,2,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env46722 : List Nat := [2,4,8,16,32,16,128,256,292,273,2048,429,269,309,136,399,293,2477,272,137,444,33,17,139,389,17,2049,429,293,2341,156,33,257,169,444,429]

theorem envBound46722 : H12AffineFastState.Bounded env46722 := by
  intro p hp
  have h : env46722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46721_46722 : H12AffineEnvironment.transform 11 429 env46721 = env46722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env46721 == env46722) = true)

theorem identity46722 : scanCanonicalize (H12AffineFastState.compose env46722 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46722 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env46723 : List Nat := [2,4,8,16,32,16,8,256,292,273,2048,293,269,309,0,263,293,2341,272,1,308,33,17,3,269,17,2049,293,293,2341,20,33,257,33,308,293]

theorem envBound46723 : H12AffineFastState.Bounded env46723 := by
  intro p hp
  have h : env46723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46722_46723 : H12AffineEnvironment.transform 6 8 env46722 = env46723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46722 == env46723) = true)

theorem identity46723 : scanCanonicalize (H12AffineFastState.compose env46723 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound46723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46724 : List Nat := [2,4,8,16,32,16,8,53,17,36,2048,16,56,0,0,50,16,2064,37,1,1,33,17,3,56,17,2049,16,16,2064,20,33,52,33,1,16]

theorem envBound46724 : H12AffineFastState.Bounded env46724 := by
  intro p hp
  have h : env46724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46723_46724 : H12AffineEnvironment.transform 7 53 env46723 = env46724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env46723 == env46724) = true)

theorem identity46724 : scanCanonicalize (H12AffineFastState.compose env46724 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound46724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46725 : List Nat := [2,4,8,16,32,16,8,53,17,36,48,16,56,0,0,50,16,32,37,1,1,33,17,3,56,17,49,16,16,32,20,33,52,33,1,16]

theorem envBound46725 : H12AffineFastState.Bounded env46725 := by
  intro p hp
  have h : env46725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46724_46725 : H12AffineEnvironment.transform 10 48 env46724 = env46725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env46724 == env46725) = true)

theorem identity46725 : scanCanonicalize (H12AffineFastState.compose env46725 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46726 : List Nat := [2,4,8,1,32,1,8,36,0,36,33,1,41,0,0,35,1,32,37,1,1,33,0,3,41,0,32,1,1,32,5,33,37,33,1,1]

theorem envBound46726 : H12AffineFastState.Bounded env46726 := by
  intro p hp
  have h : env46726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46725_46726 : H12AffineEnvironment.transform 3 1 env46725 = env46726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46725 == env46726) = true)

theorem identity46726 : scanCanonicalize (H12AffineFastState.compose env46726 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46727 : List Nat := [2,4,8,1,1,1,8,5,0,5,0,1,8,0,0,2,1,1,4,1,1,0,0,3,8,0,1,1,1,1,5,0,4,0,1,1]

theorem envBound46727 : H12AffineFastState.Bounded env46727 := by
  intro p hp
  have h : env46727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46726_46727 : H12AffineEnvironment.transform 4 1 env46726 = env46727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46726 == env46727) = true)

def env46728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108966,1025,32769,115871,98599,119966,98701,8328,16,245138,115102,17665,179513,119043,41381,257,21792,46213,63108]

theorem envBound46728 : H12AffineFastState.Bounded env46728 := by
  intro p hp
  have h : env46728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46713_46728 : H12AffineEnvironment.transform 5 17 env46713 = env46728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46713 == env46728) = true)

theorem identity46728 : scanCanonicalize (H12AffineFastState.compose env46728 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound46728 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46729 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,103447,108966,1025,32769,115871,98599,119966,98701,8328,16,10629,115102,17665,76078,119043,41381,257,21792,46213,63108]

theorem envBound46729 : H12AffineFastState.Bounded env46729 := by
  intro p hp
  have h : env46729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46728_46729 : H12AffineEnvironment.transform 16 103447 env46728 = env46729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env46728 == env46729) = true)

theorem identity46729 : scanCanonicalize (H12AffineFastState.compose env46729 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46729 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46730 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,103447,108846,1025,32769,115735,98599,119830,98565,8192,16,10509,114966,17665,76078,119043,41261,257,21792,46093,62988]

theorem envBound46730 : H12AffineFastState.Bounded env46730 := by
  intro p hp
  have h : env46730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46729_46730 : H12AffineEnvironment.transform 6 8 env46729 = env46730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46729 == env46730) = true)

theorem identity46730 : scanCanonicalize (H12AffineFastState.compose env46730 (packedSelected [3,5,7,10,12,14,15,17,18,20,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound46730 : packedSelected [3,5,7,10,12,14,15,17,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env46731 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21760,65536,82199,97326,1025,21761,69911,87079,65814,87045,8192,16,10509,70678,17665,76078,66563,29741,257,21792,24845,8972]

theorem envBound46731 : H12AffineFastState.Bounded env46731 := by
  intro p hp
  have h : env46731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46730_46731 : H12AffineEnvironment.transform 14 21760 env46730 = env46731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env46730 == env46731) = true)

theorem identity46731 : scanCanonicalize (H12AffineFastState.compose env46731 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound46731 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env46732 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21760,21510,5393,10280,1025,21761,17681,33,21776,3,8192,16,10509,16400,17665,32040,20485,29741,257,21792,24845,8972]

theorem envBound46732 : H12AffineFastState.Bounded env46732 := by
  intro p hp
  have h : env46732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46731_46732 : H12AffineEnvironment.transform 15 21510 env46731 = env46732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env46731 == env46732) = true)

theorem identity46732 : scanCanonicalize (H12AffineFastState.compose env46732 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46732 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46733 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,8192,16384,20497,20759,4096,10280,272,20496,16384,33,20481,3,8192,16,10509,16400,16400,30777,20485,28988,257,20529,24845,8972]

theorem envBound46733 : H12AffineFastState.Bounded env46733 := by
  intro p hp
  have h : env46733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46732_46733 : H12AffineEnvironment.transform 9 273 env46732 = env46733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46732 == env46733) = true)

theorem identity46733 : scanCanonicalize (H12AffineFastState.compose env46733 (packedSelected [1,3,4,5,8,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound46733 : packedSelected [1,3,4,5,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46734 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,8192,12573,8460,8202,4096,10280,272,8461,12573,33,8476,3,8192,16,10509,12557,12557,2340,8472,33,257,8492,4112,8972]

theorem envBound46734 : H12AffineFastState.Bounded env46734 := by
  intro p hp
  have h : env46734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46733_46734 : H12AffineEnvironment.transform 13 12573 env46733 = env46734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env46733 == env46734) = true)

theorem identity46734 : scanCanonicalize (H12AffineFastState.compose env46734 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound46734 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46735 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,6429,2048,6161,6423,4096,4405,272,6160,2048,33,6145,3,6429,16,4112,2064,2064,2340,6149,33,257,6193,4112,6673]

theorem envBound46735 : H12AffineFastState.Bounded env46735 := by
  intro p hp
  have h : env46735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46734_46735 : H12AffineEnvironment.transform 12 6429 env46734 = env46735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env46734 == env46735) = true)

theorem identity46735 : scanCanonicalize (H12AffineFastState.compose env46735 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46735 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46736 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,2064,269,2048,1,263,2064,2341,272,0,2048,33,17,3,269,16,2048,2064,2064,2340,21,33,257,33,2048,513]

theorem envBound46736 : H12AffineFastState.Bounded env46736 := by
  intro p hp
  have h : env46736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46735_46736 : H12AffineEnvironment.transform 11 2064 env46735 = env46736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46735 == env46736) = true)

theorem identity46736 : scanCanonicalize (H12AffineFastState.compose env46736 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound46736 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46737 : List Nat := [2,4,8,16,32,17,8,52,512,37,2048,2064,57,2048,1,51,2064,2065,36,0,2048,33,17,3,57,16,2048,2064,2064,2064,21,33,53,33,2048,513]

theorem envBound46737 : H12AffineFastState.Bounded env46737 := by
  intro p hp
  have h : env46737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46736_46737 : H12AffineEnvironment.transform 7 52 env46736 = env46737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env46736 == env46737) = true)

theorem identity46737 : scanCanonicalize (H12AffineFastState.compose env46737 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46738 : List Nat := [2,4,8,16,17,17,8,5,512,20,2048,2064,8,2048,1,2,2064,2065,21,0,2048,16,17,3,8,16,2048,2064,2064,2064,21,16,4,16,2048,513]

theorem envBound46738 : H12AffineFastState.Bounded env46738 := by
  intro p hp
  have h : env46738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46737_46738 : H12AffineEnvironment.transform 4 17 env46737 = env46738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46737 == env46738) = true)

theorem identity46738 : scanCanonicalize (H12AffineFastState.compose env46738 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound46738 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46739 : List Nat := [2,4,8,16,17,17,8,5,512,20,512,528,8,512,1,2,528,529,21,0,512,16,17,3,8,16,512,528,528,528,21,16,4,16,512,513]

theorem envBound46739 : H12AffineFastState.Bounded env46739 := by
  intro p hp
  have h : env46739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46738_46739 : H12AffineEnvironment.transform 10 512 env46738 = env46739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env46738 == env46739) = true)

theorem identity46739 : scanCanonicalize (H12AffineFastState.compose env46739 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46740 : List Nat := [2,4,8,16,17,17,8,5,16,20,16,0,8,16,1,2,0,1,21,0,16,16,17,3,8,16,16,0,0,0,21,16,4,16,16,17]

theorem envBound46740 : H12AffineFastState.Bounded env46740 := by
  intro p hp
  have h : env46740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46739_46740 : H12AffineEnvironment.transform 8 16 env46739 = env46740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46739 == env46740) = true)

def env46741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294200,98781,8328,65,4340965,288824,17664,179513,293109,4491637,257,21792,46213,352035]

theorem envBound46741 : H12AffineFastState.Bounded env46741 := by
  intro p hp
  have h : env46741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46688_46741 : H12AffineEnvironment.transform 20 290153 env46688 = env46741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env46688 == env46741) = true)

def env46742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294200,98781,8328,65,398437,288824,17664,179513,293109,41461,257,21792,46213,352035]

theorem envBound46742 : H12AffineFastState.Bounded env46742 := by
  intro p hp
  have h : env46742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46741_46742 : H12AffineEnvironment.transform 21 272512 env46741 = env46742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46741 == env46742) = true)

theorem identity46742 : scanCanonicalize (H12AffineFastState.compose env46742 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46742 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272512,294200,41430,8328,65,398437,288824,17664,179513,293109,41461,257,21792,46213,294696]

theorem envBound46743 : H12AffineFastState.Bounded env46743 := by
  intro p hp
  have h : env46743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46742_46743 : H12AffineEnvironment.transform 15 8203 env46742 = env46743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46742 == env46743) = true)

def env46744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272392,294200,41310,8192,65,398437,288824,17664,179513,292989,41341,257,21792,46093,294696]

theorem envBound46744 : H12AffineFastState.Bounded env46744 := by
  intro p hp
  have h : env46744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46743_46744 : H12AffineEnvironment.transform 6 8 env46743 = env46744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46743 == env46744) = true)

theorem identity46744 : scanCanonicalize (H12AffineFastState.compose env46744 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound46744 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,131072,262144,1025,29708,290153,272392,294200,21843,8192,65,398437,288824,17664,149812,292989,21872,257,21792,16384,294696]

theorem envBound46745 : H12AffineFastState.Bounded env46745 := by
  intro p hp
  have h : env46745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46744_46745 : H12AffineEnvironment.transform 14 29709 env46744 = env46745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env46744 == env46745) = true)

theorem identity46745 : scanCanonicalize (H12AffineFastState.compose env46745 (packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound46745 : packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env46746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,131072,157801,1025,29708,132352,147553,136529,21843,8192,65,31756,131153,17664,149812,135188,21872,257,21792,16384,137025]

theorem envBound46746 : H12AffineFastState.Bounded env46746 := by
  intro p hp
  have h : env46746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46745_46746 : H12AffineEnvironment.transform 17 157801 env46745 = env46746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env46745 == env46746) = true)

theorem identity46746 : scanCanonicalize (H12AffineFastState.compose env46746 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound46746 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env46747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,8203,131072,138292,1025,81,132352,144444,136529,8462,8192,65,2129,131153,12637,146793,135188,8493,257,8573,13405,137025]

theorem envBound46747 : H12AffineFastState.Bounded env46747 := by
  intro p hp
  have h : env46747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46746_46747 : H12AffineEnvironment.transform 13 13405 env46746 = env46747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env46746 == env46747) = true)

theorem identity46747 : scanCanonicalize (H12AffineFastState.compose env46747 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound46747 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env46748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,8203,13388,10360,1025,81,12620,112,8477,8462,8192,65,2129,13341,12637,2341,9304,8493,257,8573,13405,8973]

theorem envBound46748 : H12AffineFastState.Bounded env46748 := by
  intro p hp
  have h : env46748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46747_46748 : H12AffineEnvironment.transform 16 13388 env46747 = env46748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env46747 == env46748) = true)

theorem identity46748 : scanCanonicalize (H12AffineFastState.compose env46748 (packedSelected [0,2,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46748 : packedSelected [0,2,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,80,34,5221,2129,1025,81,4453,112,308,295,41,65,2129,5172,4468,2341,1137,260,257,340,5236,804]

theorem envBound46749 : H12AffineFastState.Bounded env46749 := by
  intro p hp
  have h : env46749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46748_46749 : H12AffineEnvironment.transform 12 41 env46748 = env46749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46748 == env46749) = true)

theorem identity46749 : scanCanonicalize (H12AffineFastState.compose env46749 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46749 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env46750 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5236,80,34,5221,2129,1025,81,4113,112,64,83,41,65,2129,5172,4096,2129,1137,112,117,32,5236,592]

theorem envBound46750 : H12AffineFastState.Bounded env46750 := by
  intro p hp
  have h : env46750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46749_46750 : H12AffineEnvironment.transform 7 116 env46749 = env46750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46749 == env46750) = true)

def env46751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272393,294200,41311,8193,65,398437,288824,17664,179513,292988,41340,257,21792,46092,294696]

theorem envBound46751 : H12AffineFastState.Bounded env46751 := by
  intro p hp
  have h : env46751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46743_46751 : H12AffineEnvironment.transform 6 9 env46743 = env46751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46743 == env46751) = true)

theorem identity46751 : scanCanonicalize (H12AffineFastState.compose env46751 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46751 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8203,131072,262144,1025,32769,276536,272393,272489,41311,8193,65,398437,277865,4177,179513,273709,41340,257,113,46092,273017]

theorem envBound46752 : H12AffineFastState.Bounded env46752 := by
  intro p hp
  have h : env46752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46751_46752 : H12AffineEnvironment.transform 13 5457 env46751 = env46752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46751 == env46752) = true)

theorem identity46752 : scanCanonicalize (H12AffineFastState.compose env46752 (packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound46752 : packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8203,46108,262144,1025,32769,276536,272393,272489,41311,8193,65,303225,277865,4177,2341,273709,41340,257,113,46092,273017]

theorem envBound46753 : H12AffineFastState.Bounded env46753 := by
  intro p hp
  have h : env46753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46752_46753 : H12AffineEnvironment.transform 16 46108 env46752 = env46753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env46752 == env46753) = true)

theorem identity46753 : scanCanonicalize (H12AffineFastState.compose env46753 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46753 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env46754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,8203,5440,262144,1025,8541,276536,272393,272489,3,8193,65,262437,277865,4177,2341,273709,32,257,113,5456,273017]

theorem envBound46754 : H12AffineFastState.Bounded env46754 := by
  intro p hp
  have h : env46754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46753_46754 : H12AffineEnvironment.transform 14 8540 env46753 = env46754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46753 == env46754) = true)

theorem identity46754 : scanCanonicalize (H12AffineFastState.compose env46754 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46754 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env46755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,372,35,5440,262144,1025,373,268304,264225,264257,3,41,65,262437,269633,4177,2341,265477,32,257,113,5456,264785]

theorem envBound46755 : H12AffineFastState.Bounded env46755 := by
  intro p hp
  have h : env46755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46754_46755 : H12AffineEnvironment.transform 12 40 env46754 = env46755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46754 == env46755) = true)

theorem identity46755 : scanCanonicalize (H12AffineFastState.compose env46755 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound46755 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,372,35,5440,2049,1025,373,4113,32,64,3,41,65,2340,5440,4177,2341,1284,32,257,113,5456,592]

theorem envBound46756 : H12AffineFastState.Bounded env46756 := by
  intro p hp
  have h : env46756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46755_46756 : H12AffineEnvironment.transform 17 2049 env46755 = env46756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env46755 == env46756) = true)

theorem identity46756 : scanCanonicalize (H12AffineFastState.compose env46756 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46757 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,40,4160,372,35,4177,2049,272,373,4113,32,64,3,41,65,2340,4177,4177,2341,21,32,257,113,4161,592]

theorem envBound46757 : H12AffineFastState.Bounded env46757 := by
  intro p hp
  have h : env46757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46756_46757 : H12AffineEnvironment.transform 9 273 env46756 = env46757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46756 == env46757) = true)

theorem identity46757 : scanCanonicalize (H12AffineFastState.compose env46757 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46757 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46758 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,40,4112,292,35,4097,2049,272,293,4113,32,16,3,41,17,2340,4097,4097,2341,21,32,257,33,4113,512]

theorem envBound46758 : H12AffineFastState.Bounded env46758 := by
  intro p hp
  have h : env46758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46757_46758 : H12AffineEnvironment.transform 5 16 env46757 = env46758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46757 == env46758) = true)

theorem identity46758 : scanCanonicalize (H12AffineFastState.compose env46758 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46758 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46759 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,9,4112,261,2,4097,2049,272,260,4113,1,16,3,8,17,2309,4097,4097,2308,21,1,257,0,4113,512]

theorem envBound46759 : H12AffineFastState.Bounded env46759 := by
  intro p hp
  have h : env46759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46758_46759 : H12AffineEnvironment.transform 4 1 env46758 = env46759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46758 == env46759) = true)

theorem identity46759 : scanCanonicalize (H12AffineFastState.compose env46759 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46759 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46760 : List Nat := [2,4,8,16,1,16,9,256,512,273,522,4096,9,4112,261,2,4097,523,272,260,4113,1,16,3,8,17,783,4097,4097,782,21,1,257,0,4113,512]

theorem envBound46760 : H12AffineFastState.Bounded env46760 := by
  intro p hp
  have h : env46760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46759_46760 : H12AffineEnvironment.transform 10 522 env46759 = env46760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46759 == env46760) = true)

theorem identity46760 : scanCanonicalize (H12AffineFastState.compose env46760 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46760 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46761 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,4096,9,4112,0,2,4097,523,21,1,4113,1,16,3,8,17,522,4097,4097,523,21,1,4,0,4113,512]

theorem envBound46761 : H12AffineFastState.Bounded env46761 := by
  intro p hp
  have h : env46761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46760_46761 : H12AffineEnvironment.transform 7 5 env46760 = env46761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46760 == env46761) = true)

theorem identity46761 : scanCanonicalize (H12AffineFastState.compose env46761 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 21) := by decide +kernel

theorem selectedBound46761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46762 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,21,9,5,0,2,20,523,21,1,4,1,16,3,8,17,522,20,20,523,21,1,4,0,4,512]

theorem envBound46762 : H12AffineFastState.Bounded env46762 := by
  intro p hp
  have h : env46762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46761_46762 : H12AffineEnvironment.transform 11 21 env46761 = env46762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 21 env46761 == env46762) = true)

theorem identity46762 : scanCanonicalize (H12AffineFastState.compose env46762 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound46762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46763 : List Nat := [2,4,8,16,1,16,9,5,28,20,22,21,9,5,0,2,20,23,21,1,4,1,16,3,8,17,22,20,20,23,21,1,4,0,4,28]

theorem envBound46763 : H12AffineFastState.Bounded env46763 := by
  intro p hp
  have h : env46763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46762_46763 : H12AffineEnvironment.transform 8 28 env46762 = env46763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env46762 == env46763) = true)

theorem identity46763 : scanCanonicalize (H12AffineFastState.compose env46763 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46763 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46764 : List Nat := [2,4,8,6,1,6,9,5,10,2,0,3,9,5,0,2,2,1,3,1,4,1,6,3,8,7,0,2,2,1,3,1,4,0,4,10]

theorem envBound46764 : H12AffineFastState.Bounded env46764 := by
  intro p hp
  have h : env46764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46763_46764 : H12AffineEnvironment.transform 3 6 env46763 = env46764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46763 == env46764) = true)

theorem identity46764 : scanCanonicalize (H12AffineFastState.compose env46764 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46764 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46765 : List Nat := [2,0,8,2,1,2,9,1,10,2,0,3,9,1,0,2,2,1,3,1,0,1,2,3,8,3,0,2,2,1,3,1,0,0,0,10]

theorem envBound46765 : H12AffineFastState.Bounded env46765 := by
  intro p hp
  have h : env46765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46764_46765 : H12AffineEnvironment.transform 1 0 env46764 = env46765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46764 == env46765) = true)

def env46766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294200,98781,8328,65,398436,288824,17664,179513,293109,41460,257,21792,46213,352035]

theorem envBound46766 : H12AffineFastState.Bounded env46766 := by
  intro p hp
  have h : env46766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46741_46766 : H12AffineEnvironment.transform 21 272513 env46741 = env46766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46741 == env46766) = true)

theorem identity46766 : scanCanonicalize (H12AffineFastState.compose env46766 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound46766 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95651,73754,98781,8328,65,215366,79130,17664,179513,75223,41460,257,21792,46213,513]

theorem envBound46767 : H12AffineFastState.Bounded env46767 := by
  intro p hp
  have h : env46767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46766_46767 : H12AffineEnvironment.transform 17 89378 env46766 = env46767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env46766 == env46767) = true)

def env46768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95531,73754,98645,8192,65,215366,79130,17664,179513,75103,41340,257,21792,46093,513]

theorem envBound46768 : H12AffineFastState.Bounded env46768 := by
  intro p hp
  have h : env46768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46767_46768 : H12AffineEnvironment.transform 6 8 env46767 = env46768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46767 == env46768) = true)

theorem identity46768 : scanCanonicalize (H12AffineFastState.compose env46768 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound46768 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35189,1025,32769,58396,41340,62541,21762,8192,65,171281,57677,17664,179513,61704,41340,257,21792,46093,513]

theorem envBound46769 : H12AffineFastState.Bounded env46769 := by
  intro p hp
  have h : env46769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46768_46769 : H12AffineEnvironment.transform 15 54359 env46768 = env46769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env46768 == env46769) = true)

theorem identity46769 : scanCanonicalize (H12AffineFastState.compose env46769 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46769 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env46770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,35189,1025,32769,45340,41340,41293,2,8192,65,171281,46157,4096,179513,41992,41340,257,32,46093,513]

theorem envBound46770 : H12AffineFastState.Bounded env46770 := by
  intro p hp
  have h : env46770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46769_46770 : H12AffineEnvironment.transform 13 5376 env46769 = env46770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46769 == env46770) = true)

theorem identity46770 : scanCanonicalize (H12AffineFastState.compose env46770 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound46770 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8282,131072,10360,1025,8460,4113,113,64,2,8192,65,146460,5440,4096,138292,1285,113,257,32,5376,513]

theorem envBound46771 : H12AffineFastState.Bounded env46771 := by
  intro p hp
  have h : env46771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46770_46771 : H12AffineEnvironment.transform 14 8461 env46770 = env46771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env46770 == env46771) = true)

theorem identity46771 : scanCanonicalize (H12AffineFastState.compose env46771 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46771 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46772 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,131072,10281,1025,8460,4113,32,17,2,8192,16,146460,5393,4096,138292,1285,32,257,32,5376,513]

theorem envBound46772 : H12AffineFastState.Bounded env46772 := by
  intro p hp
  have h : env46772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46771_46772 : H12AffineEnvironment.transform 5 17 env46771 = env46772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46771 == env46772) = true)

theorem identity46772 : scanCanonicalize (H12AffineFastState.compose env46772 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13592) := by decide +kernel

theorem selectedBound46772 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46773 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,13592,10281,1025,8460,4113,32,17,2,8192,16,2308,5393,4096,10540,1285,32,257,32,5376,513]

theorem envBound46773 : H12AffineFastState.Bounded env46773 := by
  intro p hp
  have h : env46773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46772_46773 : H12AffineEnvironment.transform 16 13592 env46772 = env46773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13592 env46772 == env46773) = true)

def env46774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95530,73754,98644,8193,65,215366,79130,17664,179513,75102,41341,257,21792,46092,513]

theorem envBound46774 : H12AffineFastState.Bounded env46774 := by
  intro p hp
  have h : env46774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46767_46774 : H12AffineEnvironment.transform 6 9 env46767 = env46774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46767 == env46774) = true)

theorem identity46774 : scanCanonicalize (H12AffineFastState.compose env46774 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound46774 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,9499,131072,30777,1025,32769,5456,20529,1281,42063,8193,65,158813,4097,17664,179513,69,41341,257,21792,46092,513]

theorem envBound46775 : H12AffineFastState.Bounded env46775 := by
  intro p hp
  have h : env46775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46774_46775 : H12AffineEnvironment.transform 15 9499 env46774 = env46775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env46774 == env46775) = true)

theorem identity46775 : scanCanonicalize (H12AffineFastState.compose env46775 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound46775 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env46776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,9499,17665,30777,1025,32769,5456,20529,1281,42063,8193,65,10588,4097,17664,63544,69,41341,257,21792,46092,513]

theorem envBound46776 : H12AffineFastState.Bounded env46776 := by
  intro p hp
  have h : env46776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46775_46776 : H12AffineEnvironment.transform 16 17665 env46775 = env46776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env46775 == env46776) = true)

theorem identity46776 : scanCanonicalize (H12AffineFastState.compose env46776 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46776 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env46777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,9499,17665,30777,1025,8540,5456,20529,1281,1298,8193,65,10588,4097,17664,22885,69,32,257,21792,5457,513]

theorem envBound46777 : H12AffineFastState.Bounded env46777 := by
  intro p hp
  have h : env46777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46776_46777 : H12AffineEnvironment.transform 14 8541 env46776 = env46777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46776 == env46777) = true)

theorem identity46777 : scanCanonicalize (H12AffineFastState.compose env46777 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46777 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46778 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8541,8203,16401,30777,273,8540,4160,20529,17,2,8193,65,10588,4097,16400,22885,69,32,257,20528,4161,513]

theorem envBound46778 : H12AffineFastState.Bounded env46778 := by
  intro p hp
  have h : env46778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46777_46778 : H12AffineEnvironment.transform 9 272 env46777 = env46778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46777 == env46778) = true)

theorem identity46778 : scanCanonicalize (H12AffineFastState.compose env46778 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46779 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,8192,16384,8541,8203,16401,30745,273,8540,4160,20497,17,2,8193,65,10588,4097,16400,22853,69,0,257,20496,4161,513]

theorem envBound46779 : H12AffineFastState.Bounded env46779 := by
  intro p hp
  have h : env46779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46778_46779 : H12AffineEnvironment.transform 4 0 env46778 = env46779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46778 == env46779) = true)

theorem identity46779 : scanCanonicalize (H12AffineFastState.compose env46779 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46779 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46780 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,268,16384,81,263,16401,22805,273,80,4160,20497,17,2,269,65,2128,4097,16400,22853,69,0,257,20496,4161,513]

theorem envBound46780 : H12AffineFastState.Bounded env46780 := by
  intro p hp
  have h : env46780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46779_46780 : H12AffineEnvironment.transform 12 268 env46779 = env46780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46779 == env46780) = true)

theorem identity46780 : scanCanonicalize (H12AffineFastState.compose env46780 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46780 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46781 : List Nat := [2,4,8,16,0,17,9,256,512,272,2048,4096,268,16384,0,263,16401,22805,273,1,4113,20497,17,2,269,16,2049,4097,16400,22804,20,0,257,20496,4112,513]

theorem envBound46781 : H12AffineFastState.Bounded env46781 := by
  intro p hp
  have h : env46781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46780_46781 : H12AffineEnvironment.transform 5 17 env46780 = env46781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46780 == env46781) = true)

theorem identity46781 : scanCanonicalize (H12AffineFastState.compose env46781 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound46781 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46782 : List Nat := [2,4,8,16,0,17,9,256,512,272,2048,4096,268,4373,0,263,4356,2048,273,1,4113,260,17,2,269,16,2049,4097,4357,2049,20,0,257,261,4112,513]

theorem envBound46782 : H12AffineFastState.Bounded env46782 := by
  intro p hp
  have h : env46782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46781_46782 : H12AffineEnvironment.transform 13 4373 env46781 = env46782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env46781 == env46782) = true)

theorem identity46782 : scanCanonicalize (H12AffineFastState.compose env46782 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46782 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46783 : List Nat := [2,4,8,16,0,17,9,5,512,21,2048,4096,9,4112,0,2,4097,2048,20,1,4113,1,17,2,8,16,2049,4097,4096,2049,20,0,4,0,4112,513]

theorem envBound46783 : H12AffineFastState.Bounded env46783 := by
  intro p hp
  have h : env46783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46782_46783 : H12AffineEnvironment.transform 7 5 env46782 = env46783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46782 == env46783) = true)

theorem identity46783 : scanCanonicalize (H12AffineFastState.compose env46783 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46784 : List Nat := [2,4,8,0,0,1,9,5,512,5,2048,4096,9,4096,0,2,4097,2048,4,1,4097,1,1,2,8,0,2049,4097,4096,2049,4,0,4,0,4096,513]

theorem envBound46784 : H12AffineFastState.Bounded env46784 := by
  intro p hp
  have h : env46784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46783_46784 : H12AffineEnvironment.transform 3 0 env46783 = env46784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46783 == env46784) = true)

theorem identity46784 : scanCanonicalize (H12AffineFastState.compose env46784 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound46784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46785 : List Nat := [2,4,8,0,0,1,9,5,512,5,2048,11,9,11,0,2,10,2048,4,1,10,1,1,2,8,0,2049,10,11,2049,4,0,4,0,11,513]

theorem envBound46785 : H12AffineFastState.Bounded env46785 := by
  intro p hp
  have h : env46785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46784_46785 : H12AffineEnvironment.transform 11 11 env46784 = env46785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env46784 == env46785) = true)

theorem identity46785 : scanCanonicalize (H12AffineFastState.compose env46785 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound46785 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46786 : List Nat := [2,4,8,0,0,1,9,5,512,5,512,11,9,11,0,2,10,512,4,1,10,1,1,2,8,0,513,10,11,513,4,0,4,0,11,513]

theorem envBound46786 : H12AffineFastState.Bounded env46786 := by
  intro p hp
  have h : env46786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46785_46786 : H12AffineEnvironment.transform 10 512 env46785 = env46786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env46785 == env46786) = true)

theorem identity46786 : scanCanonicalize (H12AffineFastState.compose env46786 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound46786 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env46787 : List Nat := [2,4,2,0,0,1,3,5,512,5,512,1,3,1,0,2,0,512,4,1,0,1,1,2,2,0,513,0,1,513,4,0,4,0,1,513]

theorem envBound46787 : H12AffineFastState.Bounded env46787 := by
  intro p hp
  have h : env46787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46786_46787 : H12AffineEnvironment.transform 2 2 env46786 = env46787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env46786 == env46787) = true)

theorem identity46787 : scanCanonicalize (H12AffineFastState.compose env46787 (packedSelected [12] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46787 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env46788 : List Nat := [2,4,2,0,0,1,3,5,0,5,0,1,3,1,0,2,0,0,4,1,0,1,1,2,2,0,1,0,1,1,4,0,4,0,1,1]

theorem envBound46788 : H12AffineFastState.Bounded env46788 := by
  intro p hp
  have h : env46788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46787_46788 : H12AffineEnvironment.transform 8 0 env46787 = env46788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46787 == env46788) = true)

def env46789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294201,2485428,8328,65,6705549,288824,2369640,179512,2102685,4491637,257,21793,46212,2175563]

theorem envBound46789 : H12AffineFastState.Bounded env46789 := by
  intro p hp
  have h : env46789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46687_46789 : H12AffineEnvironment.transform 22 294201 env46687 = env46789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294201 env46687 == env46789) = true)

def env46790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294201,98780,8328,65,4340965,288824,17664,179512,293109,4491637,257,21793,46212,352035]

theorem envBound46790 : H12AffineFastState.Bounded env46790 := by
  intro p hp
  have h : env46790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46789_46790 : H12AffineEnvironment.transform 20 290152 env46789 = env46790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env46789 == env46790) = true)

def env46791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294201,98780,8328,65,398437,288824,17664,179512,293109,41461,257,21793,46212,352035]

theorem envBound46791 : H12AffineFastState.Bounded env46791 := by
  intro p hp
  have h : env46791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46790_46791 : H12AffineEnvironment.transform 21 272512 env46790 = env46791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46790 == env46791) = true)

theorem identity46791 : scanCanonicalize (H12AffineFastState.compose env46791 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound46791 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,58517,41341,62660,98780,8328,65,171416,57797,17664,179512,61704,41461,257,21793,46212,120542]

theorem envBound46792 : H12AffineFastState.Bounded env46792 := by
  intro p hp
  have h : env46792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46791_46792 : H12AffineEnvironment.transform 17 35325 env46791 = env46792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env46791 == env46792) = true)

def env46793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35325,1025,32769,45461,41341,41412,98780,8328,65,171416,46277,4096,179512,41992,41461,257,33,46212,99294]

theorem envBound46793 : H12AffineFastState.Bounded env46793 := by
  intro p hp
  have h : env46793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46792_46793 : H12AffineEnvironment.transform 13 5376 env46792 = env46793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46792 == env46793) = true)

def env46794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46276,35325,1025,32769,45461,41341,41412,98780,8328,65,10588,46277,4096,2556,41992,41461,257,33,46212,99294]

theorem envBound46794 : H12AffineFastState.Bounded env46794 := by
  intro p hp
  have h : env46794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46793_46794 : H12AffineEnvironment.transform 16 46276 env46793 = env46794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env46793 == env46794) = true)

theorem identity46794 : scanCanonicalize (H12AffineFastState.compose env46794 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46794 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5528,10401,1025,8541,4297,33,152,73856,8328,65,10588,5529,4096,2556,1364,169,257,33,5592,74370]

theorem envBound46795 : H12AffineFastState.Bounded env46795 := by
  intro p hp
  have h : env46795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46794_46795 : H12AffineEnvironment.transform 14 8540 env46794 = env46795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46794 == env46795) = true)

theorem identity46795 : scanCanonicalize (H12AffineFastState.compose env46795 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46795 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5528,10401,1025,8541,4297,33,152,139,8328,65,10588,5529,4096,2556,1364,169,257,33,5592,649]

theorem envBound46796 : H12AffineFastState.Bounded env46796 := by
  intro p hp
  have h : env46796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46795_46796 : H12AffineEnvironment.transform 15 8203 env46795 = env46796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46795 == env46796) = true)

theorem identity46796 : scanCanonicalize (H12AffineFastState.compose env46796 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46796 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46797 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,8312,8203,5308,10401,1025,8313,4297,33,152,139,8328,65,10360,5309,4096,2264,1136,169,37,33,5372,649]

theorem envBound46797 : H12AffineFastState.Bounded env46797 := by
  intro p hp
  have h : env46797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46796_46797 : H12AffineEnvironment.transform 7 36 env46796 = env46797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46796 == env46797) = true)

theorem identity46797 : scanCanonicalize (H12AffineFastState.compose env46797 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound46797 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env46798 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,121,5156,1,114,5308,2264,1025,0,4297,33,152,139,241,65,2049,5309,4096,2264,1136,169,37,33,5372,649]

theorem envBound46798 : H12AffineFastState.Bounded env46798 := by
  intro p hp
  have h : env46798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46797_46798 : H12AffineEnvironment.transform 12 121 env46797 = env46798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env46797 == env46798) = true)

theorem identity46798 : scanCanonicalize (H12AffineFastState.compose env46798 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1276) := by decide +kernel

theorem selectedBound46798 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env46799 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,1276,121,216,1,114,64,2264,1025,0,1077,33,152,139,241,65,2049,65,1276,2264,1136,169,37,33,0,649]

theorem envBound46799 : H12AffineFastState.Bounded env46799 := by
  intro p hp
  have h : env46799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46798_46799 : H12AffineEnvironment.transform 11 1276 env46798 = env46799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1276 env46798 == env46799) = true)

theorem identity46799 : scanCanonicalize (H12AffineFastState.compose env46799 (packedSelected [3,4,5,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46799 : packedSelected [3,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env46800 : List Nat := [2,4,8,16,32,64,128,36,512,20,2048,232,121,216,1,114,64,2264,21,0,33,33,152,139,241,65,2049,65,232,2264,100,169,37,33,0,649]

theorem envBound46800 : H12AffineFastState.Bounded env46800 := by
  intro p hp
  have h : env46800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46799_46800 : H12AffineEnvironment.transform 9 20 env46799 = env46800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46799 == env46800) = true)

theorem identity46800 : scanCanonicalize (H12AffineFastState.compose env46800 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46800 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46801 : List Nat := [2,4,8,16,32,17,128,36,512,20,2048,185,40,137,1,35,17,2185,21,0,33,33,152,139,160,16,2049,16,185,2185,53,169,37,33,0,649]

theorem envBound46801 : H12AffineFastState.Bounded env46801 := by
  intro p hp
  have h : env46801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46800_46801 : H12AffineEnvironment.transform 5 17 env46800 = env46801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46800 == env46801) = true)

theorem identity46801 : scanCanonicalize (H12AffineFastState.compose env46801 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound46801 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env46802 : List Nat := [2,4,8,16,32,17,13,36,512,20,2048,52,40,4,1,35,17,2052,21,0,33,33,21,6,45,16,2049,16,52,2052,53,36,37,33,0,516]

theorem envBound46802 : H12AffineFastState.Bounded env46802 := by
  intro p hp
  have h : env46802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46801_46802 : H12AffineEnvironment.transform 6 13 env46801 = env46802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env46801 == env46802) = true)

theorem identity46802 : scanCanonicalize (H12AffineFastState.compose env46802 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound46802 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env46803 : List Nat := [2,4,8,16,4,17,13,0,512,20,2048,16,12,4,1,7,17,2052,21,0,5,5,21,6,9,16,2049,16,16,2052,17,0,1,5,0,516]

theorem envBound46803 : H12AffineFastState.Bounded env46803 := by
  intro p hp
  have h : env46803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46802_46803 : H12AffineEnvironment.transform 4 4 env46802 = env46803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env46802 == env46803) = true)

theorem identity46803 : scanCanonicalize (H12AffineFastState.compose env46803 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46803 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env46804 : List Nat := [2,0,8,16,0,17,9,0,512,16,2048,16,8,0,1,3,17,2048,17,0,1,1,17,2,9,16,2049,16,16,2048,17,0,1,1,0,512]

theorem envBound46804 : H12AffineFastState.Bounded env46804 := by
  intro p hp
  have h : env46804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46803_46804 : H12AffineEnvironment.transform 1 0 env46803 = env46804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46803 == env46804) = true)

theorem identity46804 : scanCanonicalize (H12AffineFastState.compose env46804 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound46804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46805 : List Nat := [2,0,8,16,0,17,9,0,512,16,17,16,8,0,1,3,17,17,17,0,1,1,17,2,9,16,16,16,16,17,17,0,1,1,0,512]

theorem envBound46805 : H12AffineFastState.Bounded env46805 := by
  intro p hp
  have h : env46805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46804_46805 : H12AffineEnvironment.transform 10 17 env46804 = env46805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env46804 == env46805) = true)

theorem identity46805 : scanCanonicalize (H12AffineFastState.compose env46805 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46805 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46806 : List Nat := [1,0,8,16,0,17,9,0,512,16,17,16,8,0,1,0,17,17,17,0,1,1,17,1,9,16,16,16,16,17,17,0,1,1,0,512]

theorem envBound46806 : H12AffineFastState.Bounded env46806 := by
  intro p hp
  have h : env46806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46805_46806 : H12AffineEnvironment.transform 0 1 env46805 = env46806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46805 == env46806) = true)

theorem identity46806 : scanCanonicalize (H12AffineFastState.compose env46806 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46807 : List Nat := [1,0,8,1,0,0,9,0,512,1,0,1,8,0,1,0,0,0,0,0,1,1,0,1,9,1,1,1,1,0,0,0,1,1,0,512]

theorem envBound46807 : H12AffineFastState.Bounded env46807 := by
  intro p hp
  have h : env46807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46806_46807 : H12AffineEnvironment.transform 3 1 env46806 = env46807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46806 == env46807) = true)

theorem identity46807 : scanCanonicalize (H12AffineFastState.compose env46807 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound46807 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46808 : List Nat := [1,0,1,1,0,0,0,0,512,1,0,1,1,0,1,0,0,0,0,0,1,1,0,1,0,1,1,1,1,0,0,0,1,1,0,512]

theorem envBound46808 : H12AffineFastState.Bounded env46808 := by
  intro p hp
  have h : env46808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46807_46808 : H12AffineEnvironment.transform 2 1 env46807 = env46808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env46807 == env46808) = true)

def env46809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46277,35325,1025,32769,45461,41341,41412,98780,8328,65,10589,46277,4096,2557,41992,41461,257,33,46212,99294]

theorem envBound46809 : H12AffineFastState.Bounded env46809 := by
  intro p hp
  have h : env46809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46793_46809 : H12AffineEnvironment.transform 16 46277 env46793 = env46809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env46793 == env46809) = true)

def env46810 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5372,32768,65536,46277,34817,1025,32769,45161,41089,41016,98336,8328,65,10401,46277,4096,2049,41992,40969,253,33,46212,98850]

theorem envBound46810 : H12AffineFastState.Bounded env46810 := by
  intro p hp
  have h : env46810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46809_46810 : H12AffineEnvironment.transform 7 252 env46809 = env46810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46809 == env46810) = true)

theorem identity46810 : scanCanonicalize (H12AffineFastState.compose env46810 (packedSelected [1,4,5,9,10,11,14,15,20,24,28,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound46810 : packedSelected [1,4,5,9,10,11,14,15,20,24,28,32,41] rootPS < 2^1333 := by decide +kernel

def env46811 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5372,32768,170,46277,34817,1025,32769,45161,41089,41016,32906,8328,65,10401,46277,4096,2049,41992,40969,253,33,46212,33416]

theorem envBound46811 : H12AffineFastState.Bounded env46811 := by
  intro p hp
  have h : env46811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46810_46811 : H12AffineEnvironment.transform 15 170 env46810 = env46811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env46810 == env46811) = true)

theorem identity46811 : scanCanonicalize (H12AffineFastState.compose env46811 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound46811 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env46812 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,32768,170,37988,34817,1025,32769,37064,32800,32921,32906,41,65,2048,37988,4096,2049,33961,32936,253,33,37925,33416]

theorem envBound46812 : H12AffineFastState.Bounded env46812 := by
  intro p hp
  have h : env46812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46811_46812 : H12AffineEnvironment.transform 12 161 env46811 = env46812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env46811 == env46812) = true)

theorem identity46812 : scanCanonicalize (H12AffineFastState.compose env46812 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound46812 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46813 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,80,170,5172,2129,1025,81,4248,112,201,218,41,65,2048,5172,4096,2049,1273,248,253,33,5237,728]

theorem envBound46813 : H12AffineFastState.Bounded env46813 := by
  intro p hp
  have h : env46813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46812_46813 : H12AffineEnvironment.transform 14 80 env46812 = env46813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env46812 == env46813) = true)

theorem identity46813 : scanCanonicalize (H12AffineFastState.compose env46813 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46813 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env46814 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5236,80,34,5172,2129,1025,81,4112,112,65,82,41,65,2048,5172,4096,2049,1137,112,117,33,5237,592]

theorem envBound46814 : H12AffineFastState.Bounded env46814 := by
  intro p hp
  have h : env46814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46813_46814 : H12AffineEnvironment.transform 6 8 env46813 = env46814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46813 == env46814) = true)

theorem identity46814 : scanCanonicalize (H12AffineFastState.compose env46814 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46814 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env46815 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2064,41,3172,80,34,3108,2129,1025,81,2048,112,65,82,41,65,2048,3108,2064,2049,1137,112,117,33,3173,592]

theorem envBound46815 : H12AffineFastState.Bounded env46815 := by
  intro p hp
  have h : env46815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46814_46815 : H12AffineEnvironment.transform 11 2064 env46814 = env46815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46814 == env46815) = true)

theorem identity46815 : scanCanonicalize (H12AffineFastState.compose env46815 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46815 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env46816 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2064,41,3124,0,34,3108,2049,1025,1,2048,32,17,2,41,17,2048,3108,2064,2049,1057,32,37,33,3125,512]

theorem envBound46816 : H12AffineFastState.Bounded env46816 := by
  intro p hp
  have h : env46816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46815_46816 : H12AffineEnvironment.transform 5 16 env46815 = env46816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46815 == env46816) = true)

theorem identity46816 : scanCanonicalize (H12AffineFastState.compose env46816 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46816 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46817 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,2064,8,3093,0,3,3077,2049,1025,1,2048,1,17,2,8,17,2048,3077,2064,2049,1024,1,4,0,3092,512]

theorem envBound46817 : H12AffineFastState.Bounded env46817 := by
  intro p hp
  have h : env46817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46816_46817 : H12AffineEnvironment.transform 4 1 env46816 = env46817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46816 == env46817) = true)

theorem identity46817 : scanCanonicalize (H12AffineFastState.compose env46817 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound46817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46818 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,2064,8,2048,0,3,2064,2049,20,1,2048,1,17,2,8,17,2048,2064,2064,2049,21,1,4,0,2049,512]

theorem envBound46818 : H12AffineFastState.Bounded env46818 := by
  intro p hp
  have h : env46818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46817_46818 : H12AffineEnvironment.transform 9 21 env46817 = env46818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env46817 == env46818) = true)

theorem identity46818 : scanCanonicalize (H12AffineFastState.compose env46818 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46819 : List Nat := [2,4,8,16,1,16,8,5,0,21,2048,2064,8,2048,0,3,2064,2049,20,1,2048,1,17,2,8,17,2048,2064,2064,2049,21,1,4,0,2049,0]

theorem envBound46819 : H12AffineFastState.Bounded env46819 := by
  intro p hp
  have h : env46819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46818_46819 : H12AffineEnvironment.transform 8 0 env46818 = env46819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46818 == env46819) = true)

theorem identity46819 : scanCanonicalize (H12AffineFastState.compose env46819 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound46819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46820 : List Nat := [2,4,8,5,1,5,8,5,0,0,2048,2053,8,2048,0,3,2053,2049,1,1,2048,1,4,2,8,4,2048,2053,2053,2049,0,1,4,0,2049,0]

theorem envBound46820 : H12AffineFastState.Bounded env46820 := by
  intro p hp
  have h : env46820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46819_46820 : H12AffineEnvironment.transform 3 5 env46819 = env46820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env46819 == env46820) = true)

def leafEnv46820 : List Nat := [2,4,8,5,1,5,8,5,0,0,2048,2053,8,2048,0,3,2053,2049,1,1,2048,1,4,2,1,8,1,4,2048,2053,2053,2049,0,1,4,0,5,3,2049,0,1,2049,0]

def active46820 : List Nat := [0,1,2,10]

def tree46820 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46820 : H12WitnessSearch.Good tree46820 := H12GlobalWitnessIndex.good

theorem leafIdentity46820 : H12AffineFastState.composeSystem env46820 rootObs = leafEnv46820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46820 rootObs == leafEnv46820) = true)

theorem terminalChecked46820 : H12PackedTerminal.terminalCheckFast leafEnv46820 active46820 tree46820 = true := by decide +kernel

def env46821 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,32768,65536,46277,34816,1025,32769,45160,41088,41017,98337,8328,65,10400,46277,4096,2048,41992,40968,252,33,46212,98851]

theorem envBound46821 : H12AffineFastState.Bounded env46821 := by
  intro p hp
  have h : env46821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46809_46821 : H12AffineEnvironment.transform 7 253 env46809 = env46821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env46809 == env46821) = true)

theorem identity46821 : scanCanonicalize (H12AffineFastState.compose env46821 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound46821 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46822 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,32768,32802,46277,34816,1025,32769,45160,41088,41017,3,8328,65,10400,46277,4096,2048,41992,40968,252,33,46212,513]

theorem envBound46822 : H12AffineFastState.Bounded env46822 := by
  intro p hp
  have h : env46822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46821_46822 : H12AffineEnvironment.transform 15 32802 env46821 = env46822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env46821 == env46822) = true)

theorem identity46822 : scanCanonicalize (H12AffineFastState.compose env46822 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound46822 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env46823 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,80,114,13461,2128,1025,81,12344,8400,8297,3,8328,65,10400,13461,4096,2048,9304,8280,252,33,13524,513]

theorem envBound46823 : H12AffineFastState.Bounded env46823 := by
  intro p hp
  have h : env46823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46822_46823 : H12AffineEnvironment.transform 14 80 env46822 = env46823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env46822 == env46823) = true)

theorem identity46823 : scanCanonicalize (H12AffineFastState.compose env46823 (packedSelected [0,1,2,3,5,6,7,8,12,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound46823 : packedSelected [0,1,2,3,5,6,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env46824 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,4096,8192,4312,80,114,12464,2128,36,81,12344,8400,8297,3,8328,65,10400,12464,4096,2048,8317,8280,252,33,12529,513]

theorem envBound46824 : H12AffineFastState.Bounded env46824 := by
  intro p hp
  have h : env46824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46823_46824 : H12AffineEnvironment.transform 9 37 env46823 = env46824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env46823 == env46824) = true)

theorem identity46824 : scanCanonicalize (H12AffineFastState.compose env46824 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46824 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46825 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,4096,40,4312,80,114,4248,2128,36,81,4112,248,65,3,160,65,2184,4248,4096,2048,85,112,252,33,4313,513]

theorem envBound46825 : H12AffineFastState.Bounded env46825 := by
  intro p hp
  have h : env46825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46824_46825 : H12AffineEnvironment.transform 12 40 env46824 = env46825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46824 == env46825) = true)

theorem identity46825 : scanCanonicalize (H12AffineFastState.compose env46825 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46825 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env46826 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,2064,40,2248,80,114,2184,2128,36,81,2048,248,65,3,160,65,2184,2184,2064,2048,85,112,252,33,2249,513]

theorem envBound46826 : H12AffineFastState.Bounded env46826 := by
  intro p hp
  have h : env46826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46825_46826 : H12AffineEnvironment.transform 11 2064 env46825 = env46826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46825 == env46826) = true)

theorem identity46826 : scanCanonicalize (H12AffineFastState.compose env46826 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound46826 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env46827 : List Nat := [2,4,8,16,32,64,128,253,512,37,665,649,40,593,80,114,529,713,36,81,665,248,65,3,160,65,529,529,649,665,85,112,252,33,592,513]

theorem envBound46827 : H12AffineFastState.Bounded env46827 := by
  intro p hp
  have h : env46827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46826_46827 : H12AffineEnvironment.transform 10 665 env46826 = env46827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env46826 == env46827) = true)

theorem identity46827 : scanCanonicalize (H12AffineFastState.compose env46827 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46827 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env46828 : List Nat := [2,4,8,16,32,16,128,173,512,37,665,649,40,513,0,34,529,665,36,1,665,168,17,3,160,17,529,529,649,665,5,32,172,33,512,513]

theorem envBound46828 : H12AffineFastState.Bounded env46828 := by
  intro p hp
  have h : env46828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46827_46828 : H12AffineEnvironment.transform 5 16 env46827 = env46828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46827 == env46828) = true)

theorem identity46828 : scanCanonicalize (H12AffineFastState.compose env46828 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46828 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46829 : List Nat := [2,4,8,16,32,16,8,37,512,37,529,513,40,513,0,34,529,529,36,1,529,32,17,3,40,17,529,529,513,529,5,32,36,33,512,513]

theorem envBound46829 : H12AffineFastState.Bounded env46829 := by
  intro p hp
  have h : env46829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46828_46829 : H12AffineEnvironment.transform 6 8 env46828 = env46829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46828 == env46829) = true)

theorem identity46829 : scanCanonicalize (H12AffineFastState.compose env46829 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46830 : List Nat := [2,4,8,16,0,16,8,5,512,5,529,513,8,513,0,2,529,529,4,1,529,0,17,3,8,17,529,529,513,529,5,0,4,1,512,513]

theorem envBound46830 : H12AffineFastState.Bounded env46830 := by
  intro p hp
  have h : env46830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46829_46830 : H12AffineEnvironment.transform 4 0 env46829 = env46830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46829 == env46830) = true)

theorem identity46830 : scanCanonicalize (H12AffineFastState.compose env46830 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46831 : List Nat := [2,4,8,16,0,16,8,5,17,5,0,16,8,16,0,2,0,0,4,1,0,0,17,3,8,17,0,0,16,0,5,0,4,1,17,16]

theorem envBound46831 : H12AffineFastState.Bounded env46831 := by
  intro p hp
  have h : env46831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46830_46831 : H12AffineEnvironment.transform 8 17 env46830 = env46831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46830 == env46831) = true)

theorem identity46831 : scanCanonicalize (H12AffineFastState.compose env46831 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46832 : List Nat := [2,4,8,1,0,1,8,5,0,5,0,1,8,1,0,2,0,0,4,1,0,0,0,3,8,0,0,0,1,0,5,0,4,1,0,1]

theorem envBound46832 : H12AffineFastState.Bounded env46832 := by
  intro p hp
  have h : env46832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46831_46832 : H12AffineEnvironment.transform 3 1 env46831 = env46832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46831 == env46832) = true)

theorem identity46832 : scanCanonicalize (H12AffineFastState.compose env46832 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound46832 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46833 : List Nat := [2,4,2,1,0,1,2,5,0,5,0,1,2,1,0,2,0,0,4,1,0,0,0,3,2,0,0,0,1,0,5,0,4,1,0,1]

theorem envBound46833 : H12AffineFastState.Bounded env46833 := by
  intro p hp
  have h : env46833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46832_46833 : H12AffineEnvironment.transform 2 2 env46832 = env46833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env46832 == env46833) = true)

def env46834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35325,1025,32769,45460,41341,41413,98780,8328,65,171416,46276,4097,179512,41993,41461,257,32,46212,99295]

theorem envBound46834 : H12AffineFastState.Bounded env46834 := by
  intro p hp
  have h : env46834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46792_46834 : H12AffineEnvironment.transform 13 5377 env46792 = env46834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46792 == env46834) = true)

theorem identity46834 : scanCanonicalize (H12AffineFastState.compose env46834 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46834 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10401,1025,8541,4296,33,153,73856,8328,65,146628,5528,4097,138340,1365,169,257,32,5592,74371]

theorem envBound46835 : H12AffineFastState.Bounded env46835 := by
  intro p hp
  have h : env46835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46834_46835 : H12AffineEnvironment.transform 14 8540 env46834 = env46835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46834 == env46835) = true)

theorem identity46835 : scanCanonicalize (H12AffineFastState.compose env46835 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound46835 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,10401,1025,8541,4296,33,153,2,8328,65,146628,5528,4097,138340,1365,169,257,32,5592,513]

theorem envBound46836 : H12AffineFastState.Bounded env46836 := by
  intro p hp
  have h : env46836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46835_46836 : H12AffineEnvironment.transform 15 8322 env46835 = env46836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env46835 == env46836) = true)

theorem identity46836 : scanCanonicalize (H12AffineFastState.compose env46836 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46836 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env46837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,13341,10401,1025,8541,4296,33,153,2,8328,65,2265,5528,4097,10361,1365,169,257,32,5592,513]

theorem envBound46837 : H12AffineFastState.Bounded env46837 := by
  intro p hp
  have h : env46837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46836_46837 : H12AffineEnvironment.transform 16 13341 env46836 = env46837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env46836 == env46837) = true)

theorem identity46837 : scanCanonicalize (H12AffineFastState.compose env46837 (packedSelected [4,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound46837 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env46838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,342,5577,2421,1025,137,4296,33,153,2,348,65,2265,5528,4097,2477,1365,169,257,32,5592,513]

theorem envBound46838 : H12AffineFastState.Bounded env46838 := by
  intro p hp
  have h : env46838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46837_46838 : H12AffineEnvironment.transform 12 468 env46837 = env46838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env46837 == env46838) = true)

theorem identity46838 : scanCanonicalize (H12AffineFastState.compose env46838 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46838 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env46839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5440,2421,1025,0,4161,33,16,2,348,65,2128,5393,4097,2340,1365,32,257,32,5457,513]

theorem envBound46839 : H12AffineFastState.Bounded env46839 := by
  intro p hp
  have h : env46839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46838_46839 : H12AffineEnvironment.transform 6 9 env46838 = env46839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46838 == env46839) = true)

theorem identity46839 : scanCanonicalize (H12AffineFastState.compose env46839 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound46839 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,349,2129,1,342,2064,2421,1025,0,3345,33,16,2,348,65,2128,2113,3409,2340,1365,32,257,32,2049,513]

theorem envBound46840 : H12AffineFastState.Bounded env46840 := by
  intro p hp
  have h : env46840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46839_46840 : H12AffineEnvironment.transform 11 3408 env46839 = env46840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env46839 == env46840) = true)

theorem identity46840 : scanCanonicalize (H12AffineFastState.compose env46840 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound46840 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1281,349,0,1,342,65,292,1025,0,1344,33,16,2,348,65,1,16,1280,373,1365,32,257,32,80,513]

theorem envBound46841 : H12AffineFastState.Bounded env46841 := by
  intro p hp
  have h : env46841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46840_46841 : H12AffineEnvironment.transform 10 81 env46840 = env46841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env46840 == env46841) = true)

theorem identity46841 : scanCanonicalize (H12AffineFastState.compose env46841 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46841 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46842 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1281,268,0,1,263,16,292,1025,0,1297,33,16,2,269,16,1,16,1280,292,1284,32,257,32,1,513]

theorem envBound46842 : H12AffineFastState.Bounded env46842 := by
  intro p hp
  have h : env46842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46841_46842 : H12AffineEnvironment.transform 5 17 env46841 = env46842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46841 == env46842) = true)

theorem identity46842 : scanCanonicalize (H12AffineFastState.compose env46842 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46843 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,309,268,0,1,263,16,292,53,0,293,33,16,2,269,16,1,16,308,292,304,32,257,32,1,513]

theorem envBound46843 : H12AffineFastState.Bounded env46843 := by
  intro p hp
  have h : env46843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46842_46843 : H12AffineEnvironment.transform 9 52 env46842 = env46843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46842 == env46843) = true)

theorem identity46843 : scanCanonicalize (H12AffineFastState.compose env46843 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46843 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46844 : List Nat := [2,4,8,16,32,17,9,256,10,52,0,309,268,0,1,263,16,292,53,0,293,33,16,2,269,16,1,16,308,292,304,32,257,32,1,11]

theorem envBound46844 : H12AffineFastState.Bounded env46844 := by
  intro p hp
  have h : env46844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46843_46844 : H12AffineEnvironment.transform 8 10 env46843 = env46844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46843 == env46844) = true)

theorem identity46844 : scanCanonicalize (H12AffineFastState.compose env46844 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46844 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46845 : List Nat := [2,4,8,16,1,17,9,256,10,21,0,276,268,0,1,263,16,261,20,0,260,0,16,2,269,16,1,16,277,261,273,1,257,1,1,11]

end H12CloudChart0