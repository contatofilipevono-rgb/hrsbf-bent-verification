import H12CloudChart0Data047

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env12014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,262,5392,10281,1024,0,4161,32,16,8542,8193,65,10509,13341,12637,2420,9305,8493,256,112,5377,513]

theorem envBound12014 : H12AffineFastState.Bounded env12014 := by
  intro p hp
  have h : env12014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12013_12014 : H12AffineEnvironment.transform 13 13405 env12013 = env12014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12013 == env12014) = true)

theorem identity12014 : scanCanonicalize (H12AffineFastState.compose env12014 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12014 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,1,262,5392,2341,1024,0,4161,32,16,82,269,65,2049,5393,4177,2420,1365,33,256,112,5377,513]

theorem envBound12015 : H12AffineFastState.Bounded env12015 := by
  intro p hp
  have h : env12015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12014_12015 : H12AffineEnvironment.transform 12 268 env12014 = env12015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12014 == env12015) = true)

theorem identity12015 : scanCanonicalize (H12AffineFastState.compose env12015 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12015 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12016 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4113,32,16,2,269,17,2049,5393,4097,2340,1285,33,256,32,5377,513]

theorem envBound12016 : H12AffineFastState.Bounded env12016 := by
  intro p hp
  have h : env12016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12015_12016 : H12AffineEnvironment.transform 5 16 env12015 = env12016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12015 == env12016) = true)

theorem identity12016 : scanCanonicalize (H12AffineFastState.compose env12016 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound12016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12017 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1045,268,276,1,262,261,2341,1024,0,1028,32,16,2,269,17,2049,260,1044,2340,1285,33,256,32,276,513]

theorem envBound12017 : H12AffineFastState.Bounded env12017 := by
  intro p hp
  have h : env12017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12016_12017 : H12AffineEnvironment.transform 11 1045 env12016 = env12017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env12016 == env12017) = true)

theorem identity12017 : scanCanonicalize (H12AffineFastState.compose env12017 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound12017 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12018 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,772,268,276,1,262,261,2341,785,0,789,32,16,2,269,17,2049,260,773,2340,532,33,256,32,276,513]

theorem envBound12018 : H12AffineFastState.Bounded env12018 := by
  intro p hp
  have h : env12018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12017_12018 : H12AffineEnvironment.transform 9 785 env12017 = env12018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env12017 == env12018) = true)

theorem identity12018 : scanCanonicalize (H12AffineFastState.compose env12018 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound12018 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12019 : List Nat := [2,4,8,16,32,16,9,256,512,785,804,772,268,276,1,262,261,513,785,0,789,32,16,2,269,17,805,260,773,512,532,33,256,32,276,513]

theorem envBound12019 : H12AffineFastState.Bounded env12019 := by
  intro p hp
  have h : env12019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12018_12019 : H12AffineEnvironment.transform 10 804 env12018 = env12019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env12018 == env12019) = true)

theorem identity12019 : scanCanonicalize (H12AffineFastState.compose env12019 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12019 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12020 : List Nat := [2,4,8,0,32,0,9,256,512,769,804,772,268,260,1,262,261,513,769,0,773,32,0,2,269,1,805,260,773,512,516,33,256,32,260,513]

theorem envBound12020 : H12AffineFastState.Bounded env12020 := by
  intro p hp
  have h : env12020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12019_12020 : H12AffineEnvironment.transform 3 0 env12019 = env12020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12019 == env12020) = true)

theorem identity12020 : scanCanonicalize (H12AffineFastState.compose env12020 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound12020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12021 : List Nat := [2,4,8,0,32,0,9,256,293,36,1,33,268,260,1,262,261,292,36,0,32,32,0,2,269,1,0,260,32,293,289,33,256,32,260,292]

theorem envBound12021 : H12AffineFastState.Bounded env12021 := by
  intro p hp
  have h : env12021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12020_12021 : H12AffineEnvironment.transform 8 293 env12020 = env12021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env12020 == env12021) = true)

theorem identity12021 : scanCanonicalize (H12AffineFastState.compose env12021 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12021 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12022 : List Nat := [2,4,8,0,0,0,9,256,261,4,1,1,268,260,1,262,261,260,4,0,0,0,0,2,269,1,0,260,0,261,257,1,256,0,260,260]

theorem envBound12022 : H12AffineFastState.Bounded env12022 := by
  intro p hp
  have h : env12022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12021_12022 : H12AffineEnvironment.transform 4 0 env12021 = env12022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12021 == env12022) = true)

def env12023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound12023 : H12AffineFastState.Bounded env12023 := by
  intro p hp
  have h : env12023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11781_12023 : H12AffineEnvironment.transform 18 1025 env11781 = env12023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11781 == env12023) = true)

theorem identity12023 : scanCanonicalize (H12AffineFastState.compose env12023 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound12023 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,16777216,8328,65,29868033,17066162,8763758,8830976,25265168,21268991,257,25438354,25479479,25207750]

theorem envBound12024 : H12AffineFastState.Bounded env12024 := by
  intro p hp
  have h : env12024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12023_12024 : H12AffineEnvironment.transform 20 388159 env12023 = env12024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env12023 == env12024) = true)

def env12025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,351656,8328,65,12754345,79130,8763758,8830976,8706488,4314199,257,8484154,8492191,8781422]

theorem envBound12025 : H12AffineFastState.Bounded env12025 := by
  intro p hp
  have h : env12025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12024_12025 : H12AffineEnvironment.transform 23 351656 env12024 = env12025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351656 env12024 == env12025) = true)

def env12026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,4194304,8388608,95496,8328,65,12754345,79130,8491470,8579232,8450328,4314199,257,8484154,8492191,8509134]

theorem envBound12026 : H12AffineFastState.Bounded env12026 := by
  intro p hp
  have h : env12026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12025_12026 : H12AffineEnvironment.transform 17 10400 env12025 = env12026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env12025 == env12026) = true)

def env12027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,8388608,95496,8328,65,8560009,79130,8491470,8579232,8450328,119927,257,8484154,8492191,8509134]

theorem envBound12027 : H12AffineFastState.Bounded env12027 := by
  intro p hp
  have h : env12027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12026_12027 : H12AffineEnvironment.transform 21 32 env12026 = env12027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12026 == env12027) = true)

theorem identity12027 : scanCanonicalize (H12AffineFastState.compose env12027 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62660) := by decide +kernel

theorem selectedBound12027 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,62660,95496,8328,65,158029,79130,91402,138340,1500,119927,257,98814,90203,74250]

theorem envBound12028 : H12AffineFastState.Bounded env12028 := by
  intro p hp
  have h : env12028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12027_12028 : H12AffineEnvironment.transform 22 62660 env12027 = env12028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env12027 == env12028) = true)

theorem identity12028 : scanCanonicalize (H12AffineFastState.compose env12028 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12028 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env12029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58516,32,62660,21763,8328,65,158029,5393,17665,138340,1500,62588,257,41461,16464,513]

theorem envBound12029 : H12AffineFastState.Bounded env12029 := by
  intro p hp
  have h : env12029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12028_12029 : H12AffineEnvironment.transform 15 8203 env12028 = env12029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12028 == env12029) = true)

theorem identity12029 : scanCanonicalize (H12AffineFastState.compose env12029 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound12029 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env12030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1025,32769,58516,32,62660,21763,8328,65,10589,5393,17665,23668,1500,62588,257,41461,16464,513]

theorem envBound12030 : H12AffineFastState.Bounded env12030 := by
  intro p hp
  have h : env12030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12029_12030 : H12AffineEnvironment.transform 16 16400 env12029 = env12030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12029 == env12030) = true)

theorem identity12030 : scanCanonicalize (H12AffineFastState.compose env12030 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound12030 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env12031 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,32768,8203,16400,10400,409,32769,57612,32,61788,20635,8328,65,10589,4233,16537,23020,68,61924,257,41461,16464,513]

theorem envBound12031 : H12AffineFastState.Bounded env12031 := by
  intro p hp
  have h : env12031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12030_12031 : H12AffineEnvironment.transform 9 408 env12030 = env12031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env12030 == env12031) = true)

theorem identity12031 : scanCanonicalize (H12AffineFastState.compose env12031 (packedSelected [0,14,17,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12031 : packedSelected [0,14,17,27] rootPS < 2^1333 := by decide +kernel

def env12032 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,16384,32768,8203,16400,10400,409,32769,57612,32,61709,20635,8328,16,10508,4233,16537,22973,21,61877,257,41380,16385,513]

theorem envBound12032 : H12AffineFastState.Bounded env12032 := by
  intro p hp
  have h : env12032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12031_12032 : H12AffineEnvironment.transform 5 17 env12031 = env12032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12031 == env12032) = true)

theorem identity12032 : scanCanonicalize (H12AffineFastState.compose env12032 (packedSelected [1,2,4,6,8,9,10,11,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 18433) := by decide +kernel

theorem selectedBound12032 : packedSelected [1,2,4,6,8,9,10,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env12033 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,16384,18433,8203,16400,10400,409,18432,10509,32,14604,20635,8328,16,10508,4233,16537,22973,21,14772,257,27045,16385,513]

theorem envBound12033 : H12AffineFastState.Bounded env12033 := by
  intro p hp
  have h : env12033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12032_12033 : H12AffineEnvironment.transform 14 18433 env12032 = env12033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18433 env12032 == env12033) = true)

theorem identity12033 : scanCanonicalize (H12AffineFastState.compose env12033 (packedSelected [0,3,5,7,10,11,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound12033 : packedSelected [0,3,5,7,10,11,14,17] rootPS < 2^1333 := by decide +kernel

def env12034 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,1,2048,8203,17,10400,409,2049,10509,32,14604,4250,8328,16,10508,4233,152,6588,21,14772,257,10660,0,513]

theorem envBound12034 : H12AffineFastState.Bounded env12034 := by
  intro p hp
  have h : env12034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12033_12034 : H12AffineEnvironment.transform 13 1 env12033 = env12034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env12033 == env12034) = true)

theorem identity12034 : scanCanonicalize (H12AffineFastState.compose env12034 (packedSelected [6,7,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound12034 : packedSelected [6,7,9,15] rootPS < 2^1333 := by decide +kernel

def env12035 : List Nat := [2,4,8,16,32,17,128,256,512,408,293,4096,8192,1,293,8203,17,8581,409,292,8232,32,12329,4250,8328,16,8233,4233,152,4249,21,12433,257,8321,0,513]

theorem envBound12035 : H12AffineFastState.Bounded env12035 := by
  intro p hp
  have h : env12035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12034_12035 : H12AffineEnvironment.transform 10 293 env12034 = env12035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env12034 == env12035) = true)

theorem identity12035 : scanCanonicalize (H12AffineFastState.compose env12035 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound12035 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env12036 : List Nat := [2,4,8,16,32,17,128,173,512,53,136,4096,8192,1,136,8203,17,8232,52,137,8232,32,12329,4250,8328,16,8233,4233,152,4249,21,12433,172,8321,0,513]

theorem envBound12036 : H12AffineFastState.Bounded env12036 := by
  intro p hp
  have h : env12036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12035_12036 : H12AffineEnvironment.transform 7 173 env12035 = env12036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env12035 == env12036) = true)

theorem identity12036 : scanCanonicalize (H12AffineFastState.compose env12036 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12036 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env12037 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,8192,1,1,8203,17,8232,52,0,8232,32,12329,4115,8193,16,8233,4096,17,4112,21,12312,37,8200,0,513]

theorem envBound12037 : H12AffineFastState.Bounded env12037 := by
  intro p hp
  have h : env12037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12036_12037 : H12AffineEnvironment.transform 6 9 env12036 = env12037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12036 == env12037) = true)

theorem identity12037 : scanCanonicalize (H12AffineFastState.compose env12037 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12037 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12038 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,40,1,1,35,17,0,52,0,0,32,4097,4115,41,16,1,4096,17,4112,21,4144,37,32,0,513]

theorem envBound12038 : H12AffineFastState.Bounded env12038 := by
  intro p hp
  have h : env12038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12037_12038 : H12AffineEnvironment.transform 12 40 env12037 = env12038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12037 == env12038) = true)

theorem identity12038 : scanCanonicalize (H12AffineFastState.compose env12038 (packedSelected [0,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound12038 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env12039 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,40,1,1,35,17,0,52,0,0,32,16,2,41,16,1,17,17,1,21,33,37,32,0,513]

theorem envBound12039 : H12AffineFastState.Bounded env12039 := by
  intro p hp
  have h : env12039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12038_12039 : H12AffineEnvironment.transform 11 17 env12038 = env12039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12038 == env12039) = true)

theorem identity12039 : scanCanonicalize (H12AffineFastState.compose env12039 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12040 : List Nat := [2,4,8,0,32,1,9,36,512,37,1,1,40,1,1,35,1,0,36,0,0,32,0,2,41,0,1,1,1,1,5,33,37,32,0,513]

theorem envBound12040 : H12AffineFastState.Bounded env12040 := by
  intro p hp
  have h : env12040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12039_12040 : H12AffineEnvironment.transform 3 0 env12039 = env12040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12039 == env12040) = true)

theorem identity12040 : scanCanonicalize (H12AffineFastState.compose env12040 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound12040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12041 : List Nat := [2,4,8,0,32,1,9,36,10,37,1,1,40,1,1,35,1,0,36,0,0,32,0,2,41,0,1,1,1,1,5,33,37,32,0,11]

theorem envBound12041 : H12AffineFastState.Bounded env12041 := by
  intro p hp
  have h : env12041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12040_12041 : H12AffineEnvironment.transform 8 10 env12040 = env12041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env12040 == env12041) = true)

theorem identity12041 : scanCanonicalize (H12AffineFastState.compose env12041 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12041 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12042 : List Nat := [2,4,2,0,32,1,3,36,0,37,1,1,34,1,1,35,1,0,36,0,0,32,0,2,35,0,1,1,1,1,5,33,37,32,0,1]

theorem envBound12042 : H12AffineFastState.Bounded env12042 := by
  intro p hp
  have h : env12042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12041_12042 : H12AffineEnvironment.transform 2 2 env12041 = env12042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12041 == env12042) = true)

def env12043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,8388608,95496,8328,65,8560008,79130,8491470,8579232,8450328,119926,257,8484154,8492191,8509134]

theorem envBound12043 : H12AffineFastState.Bounded env12043 := by
  intro p hp
  have h : env12043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12026_12043 : H12AffineEnvironment.transform 21 33 env12026 = env12043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12026 == env12043) = true)

theorem identity12043 : scanCanonicalize (H12AffineFastState.compose env12043 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound12043 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1025,29908,77898,33,8388608,95496,8328,65,8546653,79130,8480027,8526965,8390093,73891,257,8484154,8478794,8462875]

theorem envBound12044 : H12AffineFastState.Bounded env12044 := by
  intro p hp
  have h : env12044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12043_12044 : H12AffineEnvironment.transform 14 29909 env12043 = env12044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env12043 == env12044) = true)

def env12045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1025,8660,77898,33,8388608,73736,8328,65,8535133,79130,8466459,8526965,8390093,73891,257,8462394,8467786,8462875]

theorem envBound12045 : H12AffineFastState.Bounded env12045 := by
  intro p hp
  have h : env12045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12044_12045 : H12AffineEnvironment.transform 13 5376 env12044 = env12045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12044 == env12045) = true)

theorem identity12045 : scanCanonicalize (H12AffineFastState.compose env12045 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12045 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,131072,10400,1025,8660,4161,33,8388608,3,8328,65,8535133,5393,8392720,8526965,8390093,168,257,8388657,8394049,8389136]

theorem envBound12046 : H12AffineFastState.Bounded env12046 := by
  intro p hp
  have h : env12046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12045_12046 : H12AffineEnvironment.transform 15 8203 env12045 = env12046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12045 == env12046) = true)

theorem identity12046 : scanCanonicalize (H12AffineFastState.compose env12046 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(22+1) ^^^ 136449) := by decide +kernel

theorem selectedBound12046 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env12047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,131072,10400,1025,8660,4161,33,136449,3,8328,65,10588,5393,132369,2420,135372,168,257,136496,131136,136977]

theorem envBound12047 : H12AffineFastState.Bounded env12047 := by
  intro p hp
  have h : env12047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12046_12047 : H12AffineEnvironment.transform 22 136449 env12046 = env12047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env12046 == env12047) = true)

theorem identity12047 : scanCanonicalize (H12AffineFastState.compose env12047 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12047 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12048 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,8232,8203,131072,10400,1025,8233,4161,33,136444,3,8328,65,10401,5356,132332,2185,135372,168,252,136397,131136,136940]

theorem envBound12048 : H12AffineFastState.Bounded env12048 := by
  intro p hp
  have h : env12048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12047_12048 : H12AffineEnvironment.transform 7 253 env12047 = env12048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12047 == env12048) = true)

theorem identity12048 : scanCanonicalize (H12AffineFastState.compose env12048 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12048 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env12049 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5340,8201,8203,131072,10369,1025,8200,4161,0,136413,3,8328,65,10368,5325,132301,2185,135372,137,221,136397,131136,136909]

theorem envBound12049 : H12AffineFastState.Bounded env12049 := by
  intro p hp
  have h : env12049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12048_12049 : H12AffineEnvironment.transform 4 1 env12048 = env12049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12048 == env12049) = true)

theorem identity12049 : scanCanonicalize (H12AffineFastState.compose env12049 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5324) := by decide +kernel

theorem selectedBound12049 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12050 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5340,8201,8203,5324,10369,1025,8200,4161,0,17,3,8328,65,10368,5325,4097,2185,1024,137,221,1,5260,513]

theorem envBound12050 : H12AffineFastState.Bounded env12050 := by
  intro p hp
  have h : env12050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12049_12050 : H12AffineEnvironment.transform 16 5324 env12049 = env12050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5324 env12049 == env12050) = true)

theorem identity12050 : scanCanonicalize (H12AffineFastState.compose env12050 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound12050 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12051 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,128,5340,137,139,5324,2049,1025,136,4161,0,17,3,8,65,2048,5325,4097,2185,1024,137,221,1,5260,513]

theorem envBound12051 : H12AffineFastState.Bounded env12051 := by
  intro p hp
  have h : env12051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12050_12051 : H12AffineEnvironment.transform 12 128 env12050 = env12051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env12050 == env12051) = true)

theorem identity12051 : scanCanonicalize (H12AffineFastState.compose env12051 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12051 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12052 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,4096,128,5260,137,139,5276,2049,1025,136,4113,0,17,3,8,17,2048,5277,4097,2185,1024,137,141,1,5260,513]

theorem envBound12052 : H12AffineFastState.Bounded env12052 := by
  intro p hp
  have h : env12052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12051_12052 : H12AffineEnvironment.transform 5 16 env12051 = env12052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12051 == env12052) = true)

theorem identity12052 : scanCanonicalize (H12AffineFastState.compose env12052 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound12052 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12053 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,0,128,1164,137,139,1180,2049,1025,136,17,0,17,3,8,17,2048,1181,1,2185,1024,137,141,1,1164,513]

theorem envBound12053 : H12AffineFastState.Bounded env12053 := by
  intro p hp
  have h : env12053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12052_12053 : H12AffineEnvironment.transform 11 0 env12052 = env12053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env12052 == env12053) = true)

theorem identity12053 : scanCanonicalize (H12AffineFastState.compose env12053 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12053 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12054 : List Nat := [2,4,8,16,1,16,128,140,0,1024,2048,0,128,1164,137,139,1180,2049,1025,136,17,0,17,3,8,17,2048,1181,1,2185,1024,137,141,1,1164,1]

theorem envBound12054 : H12AffineFastState.Bounded env12054 := by
  intro p hp
  have h : env12054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12053_12054 : H12AffineEnvironment.transform 8 0 env12053 = env12054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12053 == env12054) = true)

theorem identity12054 : scanCanonicalize (H12AffineFastState.compose env12054 (packedSelected [3,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12054 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env12055 : List Nat := [2,4,8,16,1,16,128,140,0,20,2048,0,128,152,137,139,136,2049,21,136,17,0,17,3,8,17,2048,137,1,2185,20,137,141,1,152,1]

theorem envBound12055 : H12AffineFastState.Bounded env12055 := by
  intro p hp
  have h : env12055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12054_12055 : H12AffineEnvironment.transform 9 20 env12054 = env12055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12054 == env12055) = true)

theorem identity12055 : scanCanonicalize (H12AffineFastState.compose env12055 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12055 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env12056 : List Nat := [2,4,8,16,1,16,9,5,0,20,2048,0,9,17,0,2,1,2049,21,1,17,0,17,3,8,17,2048,0,1,2048,20,0,4,1,17,1]

theorem envBound12056 : H12AffineFastState.Bounded env12056 := by
  intro p hp
  have h : env12056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12055_12056 : H12AffineEnvironment.transform 6 9 env12055 = env12056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12055 == env12056) = true)

theorem identity12056 : scanCanonicalize (H12AffineFastState.compose env12056 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12057 : List Nat := [2,4,8,16,1,16,9,5,0,20,0,0,9,17,0,2,1,1,21,1,17,0,17,3,8,17,0,0,1,0,20,0,4,1,17,1]

theorem envBound12057 : H12AffineFastState.Bounded env12057 := by
  intro p hp
  have h : env12057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12056_12057 : H12AffineEnvironment.transform 10 0 env12056 = env12057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12056 == env12057) = true)

theorem identity12057 : scanCanonicalize (H12AffineFastState.compose env12057 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12057 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12058 : List Nat := [2,4,8,10,1,10,9,5,0,14,0,0,9,11,0,2,1,1,15,1,11,0,11,3,8,11,0,0,1,0,14,0,4,1,11,1]

theorem envBound12058 : H12AffineFastState.Bounded env12058 := by
  intro p hp
  have h : env12058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12057_12058 : H12AffineEnvironment.transform 3 10 env12057 = env12058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12057 == env12058) = true)

theorem identity12058 : scanCanonicalize (H12AffineFastState.compose env12058 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12058 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12059 : List Nat := [2,4,3,1,1,1,2,5,0,5,0,0,2,0,0,2,1,1,4,1,0,0,0,3,3,0,0,0,1,0,5,0,4,1,0,1]

theorem envBound12059 : H12AffineFastState.Bounded env12059 := by
  intro p hp
  have h : env12059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12058_12059 : H12AffineEnvironment.transform 2 3 env12058 = env12059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12058 == env12059) = true)

def env12060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1025,8661,77898,33,8388608,73737,8328,65,8535132,79130,8466458,8526965,8390093,73891,257,8462395,8467787,8462875]

theorem envBound12060 : H12AffineFastState.Bounded env12060 := by
  intro p hp
  have h : env12060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12044_12060 : H12AffineEnvironment.transform 13 5377 env12044 = env12060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12044 == env12060) = true)

theorem identity12060 : scanCanonicalize (H12AffineFastState.compose env12060 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound12060 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,131072,10400,1025,8661,4297,33,8388608,138,8328,65,8535132,5529,8392857,8526965,8390093,32,257,8388792,8394184,8389272]

theorem envBound12061 : H12AffineFastState.Bounded env12061 := by
  intro p hp
  have h : env12061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12060_12061 : H12AffineEnvironment.transform 15 8323 env12060 = env12061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env12060 == env12061) = true)

theorem identity12061 : scanCanonicalize (H12AffineFastState.compose env12061 (packedSelected [3,4,7,9,19,24,27,31] rootPS)) = affineNative (2^(22+1) ^^^ 136448) := by decide +kernel

theorem selectedBound12061 : packedSelected [3,4,7,9,19,24,27,31] rootPS < 2^1333 := by decide +kernel

def env12062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,131072,10400,1025,8661,4297,33,136448,138,8328,65,10588,5529,132505,2421,135373,32,257,136632,131272,137112]

theorem envBound12062 : H12AffineFastState.Bounded env12062 := by
  intro p hp
  have h : env12062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12061_12062 : H12AffineEnvironment.transform 22 136448 env12061 = env12062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env12061 == env12062) = true)

theorem identity12062 : scanCanonicalize (H12AffineFastState.compose env12062 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound12062 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,5529,10400,1025,8661,4297,33,153,138,8328,65,10588,5529,4096,2421,1364,32,257,33,5457,513]

theorem envBound12063 : H12AffineFastState.Bounded env12063 := by
  intro p hp
  have h : env12063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12062_12063 : H12AffineEnvironment.transform 16 5529 env12062 = env12063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env12062 == env12063) = true)

theorem identity12063 : scanCanonicalize (H12AffineFastState.compose env12063 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12063 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12064 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8323,5529,10400,1025,8580,4248,33,153,138,8328,16,10509,5529,4096,2340,1285,32,257,33,5376,513]

theorem envBound12064 : H12AffineFastState.Bounded env12064 := by
  intro p hp
  have h : env12064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12063_12064 : H12AffineEnvironment.transform 5 17 env12063 = env12064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12063 == env12064) = true)

theorem identity12064 : scanCanonicalize (H12AffineFastState.compose env12064 (packedSelected [0,1,3,4,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound12064 : packedSelected [0,1,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env12065 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4380,5377,4249,4511,5529,6588,1025,4248,4248,33,153,138,4500,16,6161,5529,4096,2340,1285,32,257,33,5376,513]

theorem envBound12065 : H12AffineFastState.Bounded env12065 := by
  intro p hp
  have h : env12065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12064_12065 : H12AffineEnvironment.transform 12 4380 env12064 = env12065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env12064 == env12065) = true)

theorem identity12065 : scanCanonicalize (H12AffineFastState.compose env12065 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12065 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12066 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,4153,5156,4249,4282,5308,6297,1025,4248,4248,33,153,138,4273,16,6161,5308,4096,2049,1056,32,36,33,5157,513]

theorem envBound12066 : H12AffineFastState.Bounded env12066 := by
  intro p hp
  have h : env12066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12065_12066 : H12AffineEnvironment.transform 7 37 env12065 = env12066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12065 == env12066) = true)

theorem identity12066 : scanCanonicalize (H12AffineFastState.compose env12066 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound12066 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env12067 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,3108,3101,2048,3261,3230,2200,1213,1025,3260,3260,33,153,138,3221,16,1077,2200,3108,2049,1056,32,36,33,2049,513]

theorem envBound12067 : H12AffineFastState.Bounded env12067 := by
  intro p hp
  have h : env12067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12066_12067 : H12AffineEnvironment.transform 11 3108 env12066 = env12067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env12066 == env12067) = true)

theorem identity12067 : scanCanonicalize (H12AffineFastState.compose env12067 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound12067 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env12068 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,2200,2209,2048,2049,2082,2200,1,189,2048,2048,33,153,138,2089,16,137,2200,2200,2049,156,32,36,33,2049,513]

theorem envBound12068 : H12AffineFastState.Bounded env12068 := by
  intro p hp
  have h : env12068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12067_12068 : H12AffineEnvironment.transform 9 188 env12067 = env12068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env12067 == env12068) = true)

theorem identity12068 : scanCanonicalize (H12AffineFastState.compose env12068 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12068 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12069 : List Nat := [2,4,8,16,32,17,128,37,512,188,1,153,160,1,0,35,153,1,189,1,1,33,153,138,40,16,137,153,153,0,156,32,36,33,0,513]

theorem envBound12069 : H12AffineFastState.Bounded env12069 := by
  intro p hp
  have h : env12069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12068_12069 : H12AffineEnvironment.transform 10 1 env12068 = env12069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12068 == env12069) = true)

theorem identity12069 : scanCanonicalize (H12AffineFastState.compose env12069 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12069 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env12070 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,1,0,35,16,1,52,1,1,33,16,3,40,16,0,16,16,0,21,32,36,33,0,513]

theorem envBound12070 : H12AffineFastState.Bounded env12070 := by
  intro p hp
  have h : env12070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12069_12070 : H12AffineEnvironment.transform 6 9 env12069 = env12070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12069 == env12070) = true)

theorem identity12070 : scanCanonicalize (H12AffineFastState.compose env12070 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound12070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12071 : List Nat := [2,4,8,16,32,17,9,37,43,53,1,16,41,1,0,35,16,1,52,1,1,33,16,3,40,16,0,16,16,0,21,32,36,33,0,42]

theorem envBound12071 : H12AffineFastState.Bounded env12071 := by
  intro p hp
  have h : env12071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12070_12071 : H12AffineEnvironment.transform 8 43 env12070 = env12071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env12070 == env12071) = true)

def env12072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,4194304,8388608,95497,8328,65,12754345,79130,8491471,8579233,8450329,4314199,257,8484154,8492191,8509135]

theorem envBound12072 : H12AffineFastState.Bounded env12072 := by
  intro p hp
  have h : env12072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12025_12072 : H12AffineEnvironment.transform 17 10401 env12025 = env12072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env12025 == env12072) = true)

def env12073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,8388608,95497,8328,65,8560009,79130,8491471,8579233,8450329,119927,257,8484154,8492191,8509135]

theorem envBound12073 : H12AffineFastState.Bounded env12073 := by
  intro p hp
  have h : env12073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12072_12073 : H12AffineEnvironment.transform 21 32 env12072 = env12073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12072 == env12073) = true)

def env12074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,8388608,95497,8192,65,8559873,79130,8491335,8579113,8450329,119927,257,8484154,8492055,8508999]

theorem envBound12074 : H12AffineFastState.Bounded env12074 := by
  intro p hp
  have h : env12074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12073_12074 : H12AffineEnvironment.transform 6 8 env12073 = env12074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12073 == env12074) = true)

theorem identity12074 : scanCanonicalize (H12AffineFastState.compose env12074 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 119878) := by decide +kernel

theorem selectedBound12074 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,119878,95497,8192,65,215367,79130,17665,212079,75103,119927,257,41340,16465,513]

theorem envBound12075 : H12AffineFastState.Bounded env12075 := by
  intro p hp
  have h : env12075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12074_12075 : H12AffineEnvironment.transform 22 119878 env12074 = env12075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 119878 env12074 == env12075) = true)

theorem identity12075 : scanCanonicalize (H12AffineFastState.compose env12075 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound12075 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env12076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57628,10281,1025,32769,115734,32,119878,95497,8192,65,108635,79130,17665,122227,75103,119927,257,41340,16465,513]

theorem envBound12076 : H12AffineFastState.Bounded env12076 := by
  intro p hp
  have h : env12076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12075_12076 : H12AffineEnvironment.transform 16 57628 env12075 = env12076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env12075 == env12076) = true)

theorem identity12076 : scanCanonicalize (H12AffineFastState.compose env12076 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound12076 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env12077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41050,57628,10281,1025,32769,25676,32,29724,54611,8192,65,2049,38208,17665,32041,34053,29741,257,41340,16465,513]

theorem envBound12077 : H12AffineFastState.Bounded env12077 := by
  intro p hp
  have h : env12077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12076_12077 : H12AffineEnvironment.transform 15 41050 env12076 = env12077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env12076 == env12077) = true)

theorem identity12077 : scanCanonicalize (H12AffineFastState.compose env12077 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12077 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,343,16401,10281,1025,8460,25676,32,29724,29790,8192,65,2049,13389,17665,32041,9224,29741,257,113,16465,513]

theorem envBound12078 : H12AffineFastState.Bounded env12078 := by
  intro p hp
  have h : env12078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12077_12078 : H12AffineEnvironment.transform 14 8461 env12077 = env12078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12077 == env12078) = true)

theorem identity12078 : scanCanonicalize (H12AffineFastState.compose env12078 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12078 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,343,16401,2420,1025,81,17681,32,21825,21763,349,65,2049,5392,17665,23668,1365,21872,257,113,16465,513]

theorem envBound12079 : H12AffineFastState.Bounded env12079 := by
  intro p hp
  have h : env12079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12078_12079 : H12AffineEnvironment.transform 12 349 env12078 = env12079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12078 == env12079) = true)

theorem identity12079 : scanCanonicalize (H12AffineFastState.compose env12079 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12079 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,343,5441,2420,1025,81,4161,32,17,83,349,65,2049,5392,4177,2340,1365,32,257,113,5377,513]

theorem envBound12080 : H12AffineFastState.Bounded env12080 := by
  intro p hp
  have h : env12080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12079_12080 : H12AffineEnvironment.transform 13 5456 env12079 = env12080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12079 == env12080) = true)

theorem identity12080 : scanCanonicalize (H12AffineFastState.compose env12080 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3684) := by decide +kernel

theorem selectedBound12080 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env12081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3684,349,2868,80,343,2853,2420,1025,81,3621,32,17,83,349,65,2049,2932,3637,2340,1365,32,257,113,2917,513]

theorem envBound12081 : H12AffineFastState.Bounded env12081 := by
  intro p hp
  have h : env12081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12080_12081 : H12AffineEnvironment.transform 11 3684 env12080 = env12081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3684 env12080 == env12081) = true)

theorem identity12081 : scanCanonicalize (H12AffineFastState.compose env12081 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound12081 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env12082 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,3345,349,2113,80,343,2128,2420,1025,81,3408,32,17,83,349,65,2049,2049,3392,2340,1365,32,257,113,2064,372]

theorem envBound12082 : H12AffineFastState.Bounded env12082 := by
  intro p hp
  have h : env12082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12081_12082 : H12AffineEnvironment.transform 8 373 env12081 = env12082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env12081 == env12082) = true)

theorem identity12082 : scanCanonicalize (H12AffineFastState.compose env12082 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound12082 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env12083 : List Nat := [2,4,8,16,32,64,8,101,16,1024,2048,3188,56,2113,80,50,2128,2065,1025,81,3125,32,17,83,56,65,2049,2049,3109,2113,1072,32,100,113,2064,17]

theorem envBound12083 : H12AffineFastState.Bounded env12083 := by
  intro p hp
  have h : env12083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12082_12083 : H12AffineEnvironment.transform 7 101 env12082 = env12083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env12082 == env12083) = true)

theorem identity12083 : scanCanonicalize (H12AffineFastState.compose env12083 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound12083 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env12084 : List Nat := [2,4,8,16,32,64,8,101,16,117,2048,2049,56,2113,80,50,2128,2065,116,81,2112,32,17,83,56,65,2049,2049,2128,2113,69,32,100,113,2064,17]

theorem envBound12084 : H12AffineFastState.Bounded env12084 := by
  intro p hp
  have h : env12084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12083_12084 : H12AffineEnvironment.transform 9 117 env12083 = env12084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env12083 == env12084) = true)

theorem identity12084 : scanCanonicalize (H12AffineFastState.compose env12084 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound12084 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12085 : List Nat := [2,4,8,16,32,64,8,101,16,117,16,17,56,81,80,50,64,1,116,81,80,32,17,83,56,65,17,17,64,81,69,32,100,113,0,17]

theorem envBound12085 : H12AffineFastState.Bounded env12085 := by
  intro p hp
  have h : env12085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12084_12085 : H12AffineEnvironment.transform 10 16 env12084 = env12085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env12084 == env12085) = true)

def env12086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,8388608,95497,8193,65,8559872,79130,8491334,8579112,8450329,119927,257,8484154,8492054,8508998]

theorem envBound12086 : H12AffineFastState.Bounded env12086 := by
  intro p hp
  have h : env12086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12073_12086 : H12AffineEnvironment.transform 6 9 env12073 = env12086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12073 == env12086) = true)

theorem identity12086 : scanCanonicalize (H12AffineFastState.compose env12086 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 95515) := by decide +kernel

theorem selectedBound12086 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,95515,95497,8193,65,256027,79130,58461,236851,99330,119927,257,33,57613,41821]

theorem envBound12087 : H12AffineFastState.Bounded env12087 := by
  intro p hp
  have h : env12087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12086_12087 : H12AffineEnvironment.transform 22 95515 env12086 = env12087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 95515 env12086 == env12087) = true)

theorem identity12087 : scanCanonicalize (H12AffineFastState.compose env12087 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound12087 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env12088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46156,10280,1025,32769,115735,32,95515,95497,8193,65,89175,79130,58461,76159,99330,119927,257,33,57613,41821]

theorem envBound12088 : H12AffineFastState.Bounded env12088 := by
  intro p hp
  have h : env12088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12087_12088 : H12AffineEnvironment.transform 16 46156 env12087 = env12088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env12087 == env12088) = true)

theorem identity12088 : scanCanonicalize (H12AffineFastState.compose env12088 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound12088 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10280,1025,32769,4160,32,41292,41310,8193,65,34816,57677,58461,64808,20565,32,257,33,57613,41821]

theorem envBound12089 : H12AffineFastState.Bounded env12089 := by
  intro p hp
  have h : env12089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12088_12089 : H12AffineEnvironment.transform 15 54359 env12088 = env12089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env12088 == env12089) = true)

theorem identity12089 : scanCanonicalize (H12AffineFastState.compose env12089 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12089 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,5392,10280,1025,8541,4160,32,16,2,8193,65,10588,16401,17665,23668,20565,32,257,33,16465,513]

theorem envBound12090 : H12AffineFastState.Bounded env12090 := by
  intro p hp
  have h : env12090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12089_12090 : H12AffineEnvironment.transform 14 8540 env12089 = env12090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12089 == env12090) = true)

theorem identity12090 : scanCanonicalize (H12AffineFastState.compose env12090 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound12090 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,9498,5392,10280,1025,8541,4160,32,16,2,8193,65,10588,4096,5392,3173,68,32,257,33,4160,513]

theorem envBound12091 : H12AffineFastState.Bounded env12091 := by
  intro p hp
  have h : env12091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12090_12091 : H12AffineEnvironment.transform 13 4113 env12090 = env12091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env12090 == env12091) = true)

theorem identity12091 : scanCanonicalize (H12AffineFastState.compose env12091 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound12091 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2405,8192,2420,8540,9498,3189,10280,1025,8541,2341,32,16,2,8193,65,10588,2405,3189,3173,68,32,257,33,2341,513]

theorem envBound12092 : H12AffineFastState.Bounded env12092 := by
  intro p hp
  have h : env12092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12091_12092 : H12AffineEnvironment.transform 11 2405 env12091 = env12092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env12091 == env12092) = true)

theorem identity12092 : scanCanonicalize (H12AffineFastState.compose env12092 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12092 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env12093 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2113,8192,2128,8312,9278,3189,10280,1025,8313,2049,32,16,2,8193,65,10360,2113,3189,3173,68,32,37,33,2049,513]

theorem envBound12093 : H12AffineFastState.Bounded env12093 := by
  intro p hp
  have h : env12093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12092_12093 : H12AffineEnvironment.transform 7 36 env12092 = env12093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12092 == env12093) = true)

theorem identity12093 : scanCanonicalize (H12AffineFastState.compose env12093 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12093 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env12094 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2113,8192,2128,8312,8203,2112,10280,52,8313,2049,32,16,2,8193,65,10360,2113,2112,2128,68,32,37,33,2049,513]

theorem envBound12094 : H12AffineFastState.Bounded env12094 := by
  intro p hp
  have h : env12094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12093_12094 : H12AffineEnvironment.transform 9 53 env12093 = env12094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12093 == env12094) = true)

theorem identity12094 : scanCanonicalize (H12AffineFastState.compose env12094 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound12094 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12095 : List Nat := [2,4,8,16,32,64,9,36,512,53,49,112,8192,97,8312,8203,113,8217,52,8313,48,32,16,2,8193,65,8265,112,113,97,68,32,37,33,48,513]

theorem envBound12095 : H12AffineFastState.Bounded env12095 := by
  intro p hp
  have h : env12095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12094_12095 : H12AffineEnvironment.transform 10 49 env12094 = env12095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env12094 == env12095) = true)

theorem identity12095 : scanCanonicalize (H12AffineFastState.compose env12095 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 601) := by decide +kernel

theorem selectedBound12095 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12096 : List Nat := [2,4,8,16,32,64,9,36,512,53,49,112,601,97,545,594,113,576,52,544,48,32,16,2,600,65,528,112,113,97,68,32,37,33,48,513]

theorem envBound12096 : H12AffineFastState.Bounded env12096 := by
  intro p hp
  have h : env12096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12095_12096 : H12AffineEnvironment.transform 12 601 env12095 = env12096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 601 env12095 == env12096) = true)

theorem identity12096 : scanCanonicalize (H12AffineFastState.compose env12096 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12096 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12097 : List Nat := [2,4,8,16,32,64,9,36,33,53,49,112,120,97,0,115,113,97,52,1,48,32,16,2,121,65,49,112,113,97,68,32,37,33,48,32]

theorem envBound12097 : H12AffineFastState.Bounded env12097 := by
  intro p hp
  have h : env12097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12096_12097 : H12AffineEnvironment.transform 8 33 env12096 = env12097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12096 == env12097) = true)

theorem identity12097 : scanCanonicalize (H12AffineFastState.compose env12097 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound12097 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12098 : List Nat := [2,4,8,16,32,1,9,36,33,53,49,49,57,32,0,50,48,32,52,1,48,32,16,2,56,0,49,49,48,32,5,32,37,33,48,32]

theorem envBound12098 : H12AffineFastState.Bounded env12098 := by
  intro p hp
  have h : env12098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12097_12098 : H12AffineEnvironment.transform 5 1 env12097 = env12098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env12097 == env12098) = true)

theorem identity12098 : scanCanonicalize (H12AffineFastState.compose env12098 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12098 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env12099 : List Nat := [2,4,8,16,0,1,9,4,1,21,17,17,25,0,0,18,16,0,20,1,16,0,16,2,24,0,17,17,16,0,5,0,5,1,16,0]

theorem envBound12099 : H12AffineFastState.Bounded env12099 := by
  intro p hp
  have h : env12099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12098_12099 : H12AffineEnvironment.transform 4 0 env12098 = env12099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12098 == env12099) = true)

theorem identity12099 : scanCanonicalize (H12AffineFastState.compose env12099 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12099 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12100 : List Nat := [2,4,8,0,0,1,9,4,1,5,1,1,9,0,0,2,0,0,4,1,0,0,0,2,8,0,1,1,0,0,5,0,5,1,0,0]

theorem envBound12100 : H12AffineFastState.Bounded env12100 := by
  intro p hp
  have h : env12100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12099_12100 : H12AffineEnvironment.transform 3 0 env12099 = env12100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12099 == env12100) = true)

def env12101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,8388608,95497,8328,65,8560008,79130,8491471,8579233,8450329,119926,257,8484154,8492191,8509135]

theorem envBound12101 : H12AffineFastState.Bounded env12101 := by
  intro p hp
  have h : env12101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12072_12101 : H12AffineEnvironment.transform 21 33 env12072 = env12101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12072 == env12101) = true)

theorem identity12101 : scanCanonicalize (H12AffineFastState.compose env12101 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12101 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,17,95497,8328,65,171417,79130,102878,190640,61704,119926,257,95531,103566,120542]

theorem envBound12102 : H12AffineFastState.Bounded env12102 := by
  intro p hp
  have h : env12102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12101_12102 : H12AffineEnvironment.transform 22 17 env12101 = env12102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12101 == env12102) = true)

theorem identity12102 : scanCanonicalize (H12AffineFastState.compose env12102 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound12102 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env12103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10401,1025,32769,4161,33,17,41430,8328,65,171417,57797,17665,190640,61704,169,257,41460,16465,513]

theorem envBound12103 : H12AffineFastState.Bounded env12103 := by
  intro p hp
  have h : env12103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12102_12103 : H12AffineEnvironment.transform 15 54495 env12102 = env12103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env12102 == env12103) = true)

def env12104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,33,17,41310,8192,65,171281,57677,17665,190520,61704,33,257,41340,16465,513]

theorem envBound12104 : H12AffineFastState.Bounded env12104 := by
  intro p hp
  have h : env12104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12103_12104 : H12AffineEnvironment.transform 6 8 env12103 = env12104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12103 == env12104) = true)

theorem identity12104 : scanCanonicalize (H12AffineFastState.compose env12104 (packedSelected [0,4,7,9,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound12104 : packedSelected [0,4,7,9,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env12105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5392,10281,1025,32769,4161,33,17,41310,8192,65,34817,57677,17665,64808,61704,33,257,41340,16465,513]

theorem envBound12105 : H12AffineFastState.Bounded env12105 := by
  intro p hp
  have h : env12105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12104_12105 : H12AffineEnvironment.transform 16 5392 env12104 = env12105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env12104 == env12105) = true)

theorem identity12105 : scanCanonicalize (H12AffineFastState.compose env12105 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12105 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,5392,10281,1025,32769,4161,33,17,41310,8192,65,34817,38160,12636,35189,34133,33,257,41340,13324,513]

theorem envBound12106 : H12AffineFastState.Bounded env12106 := by
  intro p hp
  have h : env12106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12105_12106 : H12AffineEnvironment.transform 13 13405 env12105 = env12106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12105 == env12106) = true)

theorem identity12106 : scanCanonicalize (H12AffineFastState.compose env12106 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12106 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env12107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,342,5392,10281,1025,8541,4161,33,17,2,8192,65,10589,13388,12636,10281,9225,33,257,32,13324,513]

theorem envBound12107 : H12AffineFastState.Bounded env12107 := by
  intro p hp
  have h : env12107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12106_12107 : H12AffineEnvironment.transform 14 8540 env12106 = env12107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12106 == env12107) = true)

theorem identity12107 : scanCanonicalize (H12AffineFastState.compose env12107 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12107 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,81,342,5392,2340,1025,80,4161,33,17,2,269,65,2128,5441,4177,2340,1284,33,257,32,5377,513]

theorem envBound12108 : H12AffineFastState.Bounded env12108 := by
  intro p hp
  have h : env12108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12107_12108 : H12AffineEnvironment.transform 12 269 env12107 = env12108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12107 == env12108) = true)

theorem identity12108 : scanCanonicalize (H12AffineFastState.compose env12108 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12108 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12109 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,33,17,2,269,17,2048,5393,4097,2340,1284,33,257,32,5377,513]

theorem envBound12109 : H12AffineFastState.Bounded env12109 := by
  intro p hp
  have h : env12109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12108_12109 : H12AffineEnvironment.transform 5 16 env12108 = env12109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12108 == env12109) = true)

theorem identity12109 : scanCanonicalize (H12AffineFastState.compose env12109 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12110 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5172,2048,1025,0,4113,33,17,2,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound12110 : H12AffineFastState.Bounded env12110 := by
  intro p hp
  have h : env12110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12109_12110 : H12AffineEnvironment.transform 7 36 env12109 = env12110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12109 == env12110) = true)

theorem identity12110 : scanCanonicalize (H12AffineFastState.compose env12110 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound12110 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12111 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,17,41,1077,1,34,1061,2048,1025,0,0,33,17,2,41,17,2048,1060,16,2048,1056,33,37,32,1076,513]

theorem envBound12111 : H12AffineFastState.Bounded env12111 := by
  intro p hp
  have h : env12111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12110_12111 : H12AffineEnvironment.transform 11 17 env12110 = env12111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12110 == env12111) = true)

theorem identity12111 : scanCanonicalize (H12AffineFastState.compose env12111 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12111 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12112 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,17,41,1077,1,34,1061,0,1025,0,0,33,17,2,41,17,0,1060,16,0,1056,33,37,32,1076,513]

theorem envBound12112 : H12AffineFastState.Bounded env12112 := by
  intro p hp
  have h : env12112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12111_12112 : H12AffineEnvironment.transform 10 0 env12111 = env12112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12111 == env12112) = true)

theorem identity12112 : scanCanonicalize (H12AffineFastState.compose env12112 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12112 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12113 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,41,0,1,34,16,0,52,0,0,33,17,2,41,17,0,17,16,0,21,33,37,32,1,513]

theorem envBound12113 : H12AffineFastState.Bounded env12113 := by
  intro p hp
  have h : env12113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12112_12113 : H12AffineEnvironment.transform 9 53 env12112 = env12113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12112 == env12113) = true)

theorem identity12113 : scanCanonicalize (H12AffineFastState.compose env12113 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12114 : List Nat := [2,4,3,16,32,16,3,36,512,53,0,17,34,0,1,34,16,0,52,0,0,33,17,2,34,17,0,17,16,0,21,33,37,32,1,513]

theorem envBound12114 : H12AffineFastState.Bounded env12114 := by
  intro p hp
  have h : env12114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12113_12114 : H12AffineEnvironment.transform 2 3 env12113 = env12114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12113 == env12114) = true)

def env12115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1025,32769,4161,33,17,41311,8193,65,171280,57676,17665,190521,61704,32,257,41341,16465,513]

theorem envBound12115 : H12AffineFastState.Bounded env12115 := by
  intro p hp
  have h : env12115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12103_12115 : H12AffineEnvironment.transform 6 9 env12103 = env12115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12103 == env12115) = true)

theorem identity12115 : scanCanonicalize (H12AffineFastState.compose env12115 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12115 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10280,1025,8541,4161,33,17,3,8193,65,146508,16400,17665,149861,20564,32,257,33,16465,513]

theorem envBound12116 : H12AffineFastState.Bounded env12116 := by
  intro p hp
  have h : env12116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12115_12116 : H12AffineEnvironment.transform 14 8540 env12115 = env12116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12115 == env12116) = true)

theorem identity12116 : scanCanonicalize (H12AffineFastState.compose env12116 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12116 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env12117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,8192,16384,8540,27931,131072,10280,1025,8541,2128,33,17,3,8193,65,140381,16400,17665,149861,18501,32,257,33,16465,513]

theorem envBound12117 : H12AffineFastState.Bounded env12117 := by
  intro p hp
  have h : env12117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12116_12117 : H12AffineEnvironment.transform 11 2065 env12116 = env12117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env12116 == env12117) = true)

theorem identity12117 : scanCanonicalize (H12AffineFastState.compose env12117 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12117 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,0,19527,131072,2420,1025,1,2128,33,17,3,349,65,132353,16400,17665,149861,18501,32,257,33,16465,513]

theorem envBound12118 : H12AffineFastState.Bounded env12118 := by
  intro p hp
  have h : env12118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12117_12118 : H12AffineEnvironment.transform 12 348 env12117 = env12118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12117 == env12118) = true)

theorem identity12118 : scanCanonicalize (H12AffineFastState.compose env12118 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12118 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,0,19527,2065,2420,1025,1,2128,33,17,3,349,65,3344,16400,17665,16756,18501,32,257,33,16465,513]

theorem envBound12119 : H12AffineFastState.Bounded env12119 := by
  intro p hp
  have h : env12119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12118_12119 : H12AffineEnvironment.transform 16 2065 env12118 = env12119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2065 env12118 == env12119) = true)

theorem identity12119 : scanCanonicalize (H12AffineFastState.compose env12119 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12119 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env12120 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2065,348,16384,0,18775,2065,2420,273,1,2128,33,17,3,349,65,2048,16400,16401,16756,18501,32,257,33,16465,513]

theorem envBound12120 : H12AffineFastState.Bounded env12120 := by
  intro p hp
  have h : env12120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12119_12120 : H12AffineEnvironment.transform 9 272 env12119 = env12120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12119 == env12120) = true)

theorem identity12120 : scanCanonicalize (H12AffineFastState.compose env12120 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2123) := by decide +kernel

theorem selectedBound12120 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env12121 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2065,348,2123,0,284,2065,2420,273,1,2128,33,17,3,349,65,2048,2139,2138,2367,14,32,257,33,2074,513]

theorem envBound12121 : H12AffineFastState.Bounded env12121 := by
  intro p hp
  have h : env12121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12120_12121 : H12AffineEnvironment.transform 13 2123 env12120 = env12121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2123 env12120 == env12121) = true)

theorem identity12121 : scanCanonicalize (H12AffineFastState.compose env12121 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12121 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env12122 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2065,269,2074,0,284,2065,2341,273,1,2049,33,17,3,268,16,2048,2058,2059,2367,14,32,257,33,2074,513]

theorem envBound12122 : H12AffineFastState.Bounded env12122 := by
  intro p hp
  have h : env12122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12121_12122 : H12AffineEnvironment.transform 5 17 env12121 = env12122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12121 == env12122) = true)

theorem identity12122 : scanCanonicalize (H12AffineFastState.compose env12122 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound12122 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12123 : List Nat := [2,4,8,16,32,17,9,20,512,4,2048,2065,25,2074,0,8,2065,2097,5,1,2049,33,17,3,24,16,2048,2058,2059,2091,14,32,21,33,2074,513]

theorem envBound12123 : H12AffineFastState.Bounded env12123 := by
  intro p hp
  have h : env12123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12122_12123 : H12AffineEnvironment.transform 7 20 env12122 = env12123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env12122 == env12123) = true)

theorem identity12123 : scanCanonicalize (H12AffineFastState.compose env12123 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12123 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12124 : List Nat := [2,4,8,10,32,11,9,14,512,4,2048,2059,3,2048,0,8,2059,2091,5,1,2049,33,11,3,2,10,2048,2058,2059,2091,14,32,15,33,2048,513]

theorem envBound12124 : H12AffineFastState.Bounded env12124 := by
  intro p hp
  have h : env12124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12123_12124 : H12AffineEnvironment.transform 3 10 env12123 = env12124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12123 == env12124) = true)

theorem identity12124 : scanCanonicalize (H12AffineFastState.compose env12124 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound12124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12125 : List Nat := [2,4,8,10,32,11,9,14,512,4,10,1,3,10,0,8,1,33,5,1,11,33,11,3,2,10,10,0,1,33,14,32,15,33,10,513]

theorem envBound12125 : H12AffineFastState.Bounded env12125 := by
  intro p hp
  have h : env12125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12124_12125 : H12AffineEnvironment.transform 10 10 env12124 = env12125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env12124 == env12125) = true)

theorem identity12125 : scanCanonicalize (H12AffineFastState.compose env12125 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound12125 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12126 : List Nat := [2,4,8,10,11,11,9,14,512,4,10,1,3,10,0,8,1,10,5,1,11,10,11,3,2,10,10,0,1,10,14,11,15,10,10,513]

theorem envBound12126 : H12AffineFastState.Bounded env12126 := by
  intro p hp
  have h : env12126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12125_12126 : H12AffineEnvironment.transform 4 11 env12125 = env12126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env12125 == env12126) = true)

theorem identity12126 : scanCanonicalize (H12AffineFastState.compose env12126 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound12126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12127 : List Nat := [2,4,8,10,11,11,9,14,14,4,10,1,3,10,0,8,1,10,5,1,11,10,11,3,2,10,10,0,1,10,14,11,15,10,10,15]

theorem envBound12127 : H12AffineFastState.Bounded env12127 := by
  intro p hp
  have h : env12127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12126_12127 : H12AffineEnvironment.transform 8 14 env12126 = env12127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env12126 == env12127) = true)

theorem identity12127 : scanCanonicalize (H12AffineFastState.compose env12127 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound12127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12128 : List Nat := [2,4,0,2,3,3,1,6,6,4,2,1,3,2,0,0,1,2,5,1,3,2,3,3,2,2,2,0,1,2,6,3,7,2,2,7]

theorem envBound12128 : H12AffineFastState.Bounded env12128 := by
  intro p hp
  have h : env12128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12127_12128 : H12AffineEnvironment.transform 2 0 env12127 = env12128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env12127 == env12128) = true)

def env12129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,4194304,8388608,351657,8328,65,12754344,79131,8763758,8830976,8706489,4314198,257,8484155,8492190,8781423]

theorem envBound12129 : H12AffineFastState.Bounded env12129 := by
  intro p hp
  have h : env12129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12024_12129 : H12AffineEnvironment.transform 23 351657 env12024 = env12129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351657 env12024 == env12129) = true)

def env12130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,4194304,8388608,95497,8328,65,12754344,79131,8491470,8579232,8450329,4314198,257,8484155,8492190,8509135]

theorem envBound12130 : H12AffineFastState.Bounded env12130 := by
  intro p hp
  have h : env12130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12129_12130 : H12AffineEnvironment.transform 17 10400 env12129 = env12130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env12129 == env12130) = true)

def env12131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,32,8388608,95497,8328,65,8560008,79131,8491470,8579232,8450329,119926,257,8484155,8492190,8509135]

theorem envBound12131 : H12AffineFastState.Bounded env12131 := by
  intro p hp
  have h : env12131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12130_12131 : H12AffineEnvironment.transform 21 32 env12130 = env12131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12130 == env12131) = true)

theorem identity12131 : scanCanonicalize (H12AffineFastState.compose env12131 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12131 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58516,32,8388608,21762,8328,65,8560008,5392,8434117,8579232,8450329,62589,257,8410416,8434837,8451780]

theorem envBound12132 : H12AffineFastState.Bounded env12132 := by
  intro p hp
  have h : env12132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12131_12132 : H12AffineEnvironment.transform 15 8203 env12131 = env12132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12131 == env12132) = true)

def env12133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58396,32,8388608,21762,8192,65,8559872,5392,8433997,8579112,8450329,62589,257,8410416,8434717,8451660]

theorem envBound12133 : H12AffineFastState.Bounded env12133 := by
  intro p hp
  have h : env12133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12132_12133 : H12AffineEnvironment.transform 6 8 env12132 = env12133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12132 == env12133) = true)

theorem identity12133 : scanCanonicalize (H12AffineFastState.compose env12133 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound12133 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10280,1025,29789,4160,32,8388608,21762,8192,65,8546652,5392,8406289,8526964,8389957,33,257,8410416,8405057,8389136]

theorem envBound12134 : H12AffineFastState.Bounded env12134 := by
  intro p hp
  have h : env12134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12133_12134 : H12AffineEnvironment.transform 14 29788 env12133 = env12134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env12133 == env12134) = true)

theorem identity12134 : scanCanonicalize (H12AffineFastState.compose env12134 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(22+1) ^^^ 309) := by decide +kernel

theorem selectedBound12134 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env12135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10280,1025,29789,4160,32,309,21762,8192,65,157801,5392,17444,138561,1136,33,257,21509,16756,805]

theorem envBound12135 : H12AffineFastState.Bounded env12135 := by
  intro p hp
  have h : env12135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12134_12135 : H12AffineEnvironment.transform 22 309 env12134 = env12135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 309 env12134 == env12135) = true)

theorem identity12135 : scanCanonicalize (H12AffineFastState.compose env12135 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12135 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env12136 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29788,8203,131072,10280,1025,29789,4160,32,17,21542,8192,65,157801,5172,17444,138341,1136,33,37,21509,16464,513]

theorem envBound12136 : H12AffineFastState.Bounded env12136 := by
  intro p hp
  have h : env12136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12135_12136 : H12AffineEnvironment.transform 7 36 env12135 = env12136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12135 == env12136) = true)

theorem identity12136 : scanCanonicalize (H12AffineFastState.compose env12136 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound12136 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12137 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,16384,16465,5126,131072,7205,1025,16464,4160,32,17,21542,5133,65,154724,5172,17444,138341,1136,33,37,21509,16464,513]

theorem envBound12137 : H12AffineFastState.Bounded env12137 := by
  intro p hp
  have h : env12137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12136_12137 : H12AffineEnvironment.transform 12 5133 env12136 = env12137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env12136 == env12137) = true)

theorem identity12137 : scanCanonicalize (H12AffineFastState.compose env12137 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 21556) := by decide +kernel

theorem selectedBound12137 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12138 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,16384,16465,5126,21556,7205,1025,16464,4160,32,17,21542,5133,65,2128,5172,17444,18513,1136,33,37,21509,16464,513]

theorem envBound12138 : H12AffineFastState.Bounded env12138 := by
  intro p hp
  have h : env12138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12137_12138 : H12AffineEnvironment.transform 16 21556 env12137 = env12138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21556 env12137 == env12138) = true)

theorem identity12138 : scanCanonicalize (H12AffineFastState.compose env12138 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound12138 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12139 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,7204,7285,5126,2064,7205,1025,7284,4160,32,17,2050,5133,65,2128,5172,6144,5237,1136,33,37,2081,7284,513]

theorem envBound12139 : H12AffineFastState.Bounded env12139 := by
  intro p hp
  have h : env12139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12138_12139 : H12AffineEnvironment.transform 13 7204 env12138 = env12139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env12138 == env12139) = true)

theorem identity12139 : scanCanonicalize (H12AffineFastState.compose env12139 (packedSelected [0,1,2,3,5,6,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12139 : packedSelected [0,1,2,3,5,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12140 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,4096,5133,4113,4160,5126,1061,4112,1025,4161,4160,32,17,1079,5133,65,1125,5172,5173,5237,1136,33,37,1044,4161,513]

theorem envBound12140 : H12AffineFastState.Bounded env12140 := by
  intro p hp
  have h : env12140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12139_12140 : H12AffineEnvironment.transform 10 1077 env12139 = env12140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env12139 == env12140) = true)

theorem identity12140 : scanCanonicalize (H12AffineFastState.compose env12140 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound12140 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env12141 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,65,1100,80,1,1095,1061,81,1025,0,1,32,17,1079,1100,65,1125,1141,1140,1076,1136,33,37,1044,0,513]

theorem envBound12141 : H12AffineFastState.Bounded env12141 := by
  intro p hp
  have h : env12141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12140_12141 : H12AffineEnvironment.transform 11 65 env12140 = env12141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env12140 == env12141) = true)

theorem identity12141 : scanCanonicalize (H12AffineFastState.compose env12141 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12141 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12142 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,17,1052,0,1,1047,1061,1,1025,0,1,32,17,1079,1052,17,1077,1061,1060,1076,1056,33,37,1044,0,513]

theorem envBound12142 : H12AffineFastState.Bounded env12142 := by
  intro p hp
  have h : env12142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12141_12142 : H12AffineEnvironment.transform 5 16 env12141 = env12142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12141 == env12142) = true)

def env12143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58397,32,8388608,21762,8193,65,8559873,5392,8433996,8579113,8450329,62589,257,8410416,8434716,8451661]

theorem envBound12143 : H12AffineFastState.Bounded env12143 := by
  intro p hp
  have h : env12143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12132_12143 : H12AffineEnvironment.transform 6 9 env12132 = env12143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12132 == env12143) = true)

theorem identity12143 : scanCanonicalize (H12AffineFastState.compose env12143 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12143 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10281,1025,32769,45340,32,8388608,3,8193,65,8559873,5392,8433996,8568104,8430616,41340,257,8388657,8434716,8430412]

theorem envBound12144 : H12AffineFastState.Bounded env12144 := by
  intro p hp
  have h : env12144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12143_12144 : H12AffineEnvironment.transform 13 5377 env12143 = env12144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12143 == env12144) = true)

theorem identity12144 : scanCanonicalize (H12AffineFastState.compose env12144 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 144396) := by decide +kernel

theorem selectedBound12144 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env12145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10281,1025,32769,45340,32,144396,3,8193,65,43277,5392,165184,35108,167956,41340,257,144445,163856,169792]

theorem envBound12145 : H12AffineFastState.Bounded env12145 := by
  intro p hp
  have h : env12145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12144_12145 : H12AffineEnvironment.transform 22 144396 env12144 = env12145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 144396 env12144 == env12145) = true)

theorem identity12145 : scanCanonicalize (H12AffineFastState.compose env12145 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12145 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env12146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8203,131072,10281,1025,0,12573,32,144396,3,8193,65,10508,5392,132417,2341,135189,8573,257,144445,131089,137025]

theorem envBound12146 : H12AffineFastState.Bounded env12146 := by
  intro p hp
  have h : env12146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12145_12146 : H12AffineEnvironment.transform 14 1 env12145 = env12146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12145 == env12146) = true)

theorem identity12146 : scanCanonicalize (H12AffineFastState.compose env12146 (packedSelected [0,1,6,7,8,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound12146 : packedSelected [0,1,6,7,8,14,16,19] rootPS < 2^1333 := by decide +kernel

def env12147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8203,5221,10281,1025,0,12573,32,8297,3,8193,65,10508,5392,4388,2341,1136,8573,257,8280,5236,804]

theorem envBound12147 : H12AffineFastState.Bounded env12147 := by
  intro p hp
  have h : env12147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12146_12147 : H12AffineEnvironment.transform 16 5221 env12146 = env12147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env12146 == env12147) = true)

theorem identity12147 : scanCanonicalize (H12AffineFastState.compose env12147 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12147 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env12148 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,1,8203,5221,10281,1025,0,12344,32,8297,3,8193,65,10281,5173,4097,2048,1136,8280,36,8280,5236,513]

theorem envBound12148 : H12AffineFastState.Bounded env12148 := by
  intro p hp
  have h : env12148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12147_12148 : H12AffineEnvironment.transform 7 37 env12147 = env12148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12147 == env12148) = true)

theorem identity12148 : scanCanonicalize (H12AffineFastState.compose env12148 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12148 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12149 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,5156,1,1046,5221,3124,1025,0,5157,32,1140,3,1052,65,3124,5173,4097,2048,1136,1093,36,1093,5236,513]

theorem envBound12149 : H12AffineFastState.Bounded env12149 := by
  intro p hp
  have h : env12149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12148_12149 : H12AffineEnvironment.transform 12 1053 env12148 = env12149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12148 == env12149) = true)

theorem identity12149 : scanCanonicalize (H12AffineFastState.compose env12149 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12149 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env12150 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,40,4113,1,35,4176,2049,52,0,4112,32,65,3,41,65,2049,4096,4097,2048,69,112,36,112,4161,513]

theorem envBound12150 : H12AffineFastState.Bounded env12150 := by
  intro p hp
  have h : env12150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12149_12150 : H12AffineEnvironment.transform 9 53 env12149 = env12150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12149 == env12150) = true)

theorem identity12150 : scanCanonicalize (H12AffineFastState.compose env12150 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound12150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12151 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,0,40,17,1,35,80,2049,52,0,16,32,65,3,41,65,2049,0,1,2048,69,112,36,112,65,513]

theorem envBound12151 : H12AffineFastState.Bounded env12151 := by
  intro p hp
  have h : env12151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12150_12151 : H12AffineEnvironment.transform 11 0 env12150 = env12151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env12150 == env12151) = true)

theorem identity12151 : scanCanonicalize (H12AffineFastState.compose env12151 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12151 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12152 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,0,40,17,1,35,0,2049,52,0,16,32,17,3,41,17,2049,0,1,2048,21,32,36,32,17,513]

theorem envBound12152 : H12AffineFastState.Bounded env12152 := by
  intro p hp
  have h : env12152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12151_12152 : H12AffineEnvironment.transform 5 16 env12151 = env12152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12151 == env12152) = true)

theorem identity12152 : scanCanonicalize (H12AffineFastState.compose env12152 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 564) := by decide +kernel

theorem selectedBound12152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12153 : List Nat := [2,4,8,16,32,16,9,37,512,53,564,0,40,17,1,35,0,565,52,0,16,32,17,3,41,17,565,0,1,564,21,32,36,32,17,513]

theorem envBound12153 : H12AffineFastState.Bounded env12153 := by
  intro p hp
  have h : env12153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12152_12153 : H12AffineEnvironment.transform 10 564 env12152 = env12153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 564 env12152 == env12153) = true)

theorem identity12153 : scanCanonicalize (H12AffineFastState.compose env12153 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound12153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12154 : List Nat := [2,4,8,16,32,16,9,37,45,53,25,0,40,17,1,35,0,24,52,0,16,32,17,3,41,17,24,0,1,25,21,32,36,32,17,44]

theorem envBound12154 : H12AffineFastState.Bounded env12154 := by
  intro p hp
  have h : env12154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12153_12154 : H12AffineEnvironment.transform 8 45 env12153 = env12154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env12153 == env12154) = true)

theorem identity12154 : scanCanonicalize (H12AffineFastState.compose env12154 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound12154 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12155 : List Nat := [2,4,8,3,32,3,9,37,45,38,10,0,40,2,1,35,0,11,39,0,3,32,2,3,41,2,11,0,1,10,6,32,36,32,2,44]

theorem envBound12155 : H12AffineFastState.Bounded env12155 := by
  intro p hp
  have h : env12155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12154_12155 : H12AffineEnvironment.transform 3 3 env12154 = env12155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env12154 == env12155) = true)

theorem identity12155 : scanCanonicalize (H12AffineFastState.compose env12155 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound12155 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12156 : List Nat := [2,4,8,3,8,3,9,13,5,14,10,0,0,2,1,11,0,11,15,0,3,8,2,3,1,2,11,0,1,10,6,8,12,8,2,4]

theorem envBound12156 : H12AffineFastState.Bounded env12156 := by
  intro p hp
  have h : env12156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12155_12156 : H12AffineEnvironment.transform 4 8 env12155 = env12156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env12155 == env12156) = true)

def env12157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,8388608,95497,8328,65,8560009,79131,8491470,8579232,8450329,119927,257,8484155,8492190,8509135]

theorem envBound12157 : H12AffineFastState.Bounded env12157 := by
  intro p hp
  have h : env12157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12130_12157 : H12AffineEnvironment.transform 21 33 env12130 = env12157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12130 == env12157) = true)

theorem identity12157 : scanCanonicalize (H12AffineFastState.compose env12157 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound12157 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115871,33,73754,95497,8328,65,245139,79131,45524,247994,119043,119927,257,21793,46212,63189]

theorem envBound12158 : H12AffineFastState.Bounded env12158 := by
  intro p hp
  have h : env12158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12157_12158 : H12AffineEnvironment.transform 22 73754 env12157 = env12158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env12157 == env12158) = true)

def env12159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,33,73754,95497,8192,65,245019,79131,45404,247858,119043,119927,257,21793,46092,63069]

theorem envBound12159 : H12AffineFastState.Bounded env12159 := by
  intro p hp
  have h : env12159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12158_12159 : H12AffineEnvironment.transform 6 8 env12158 = env12159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12158 == env12159) = true)

theorem identity12159 : scanCanonicalize (H12AffineFastState.compose env12159 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound12159 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1025,32769,4160,33,62541,41310,8192,65,158028,57676,45404,138341,1364,32,257,21793,46092,63069]

theorem envBound12160 : H12AffineFastState.Bounded env12160 := by
  intro p hp
  have h : env12160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12159_12160 : H12AffineEnvironment.transform 15 54359 env12159 = env12160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env12159 == env12160) = true)

theorem identity12160 : scanCanonicalize (H12AffineFastState.compose env12160 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound12160 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env12161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,41050,131072,10280,1025,32769,4160,33,32832,41310,8192,65,138561,38209,45404,138341,1364,32,257,8492,46092,33360]

theorem envBound12161 : H12AffineFastState.Bounded env12161 := by
  intro p hp
  have h : env12161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12160_12161 : H12AffineEnvironment.transform 13 13325 env12160 = env12161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env12160 == env12161) = true)

theorem identity12161 : scanCanonicalize (H12AffineFastState.compose env12161 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12161 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env12162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4112,32768,33863,131072,3125,1025,32769,4160,33,32832,34115,1053,65,138561,38209,38209,138341,1364,32,257,1329,36881,33360]

theorem envBound12162 : H12AffineFastState.Bounded env12162 := by
  intro p hp
  have h : env12162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12161_12162 : H12AffineEnvironment.transform 12 1053 env12161 = env12162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12161 == env12162) = true)

theorem identity12162 : scanCanonicalize (H12AffineFastState.compose env12162 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound12162 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env12163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4112,32768,33863,4096,3125,1025,32769,4160,33,32832,34115,1053,65,3393,38209,38209,3173,1364,32,257,1329,36881,33360]

theorem envBound12163 : H12AffineFastState.Bounded env12163 := by
  intro p hp
  have h : env12163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12162_12163 : H12AffineEnvironment.transform 16 4096 env12162 = env12163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env12162 == env12163) = true)

theorem identity12163 : scanCanonicalize (H12AffineFastState.compose env12163 (packedSelected [3,4,5,9,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12163 : packedSelected [3,4,5,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env12164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,4096,1053,4112,32768,33863,4096,0,1025,32769,4160,33,32832,34115,1053,65,372,38209,38209,80,1364,32,257,1329,36881,33360]

theorem envBound12164 : H12AffineFastState.Bounded env12164 := by
  intro p hp
  have h : env12164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12163_12164 : H12AffineEnvironment.transform 10 1077 env12163 = env12164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env12163 == env12164) = true)

theorem identity12164 : scanCanonicalize (H12AffineFastState.compose env12164 (packedSelected [0,1,2,6,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound12164 : packedSelected [0,1,2,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env12165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,1360,1053,1344,32768,33863,1360,0,1025,32769,1296,33,32832,34115,1053,65,372,32785,32785,80,1364,32,257,1329,34113,33360]

theorem envBound12165 : H12AffineFastState.Bounded env12165 := by
  intro p hp
  have h : env12165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12164_12165 : H12AffineEnvironment.transform 11 1360 env12164 = env12165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env12164 == env12165) = true)

theorem identity12165 : scanCanonicalize (H12AffineFastState.compose env12165 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound12165 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12166 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1077,1029,1053,1045,32768,33863,1029,0,1025,32769,1093,33,32832,33814,1053,65,33,32785,32785,80,1025,32,84,1124,33812,33360]

theorem envBound12166 : H12AffineFastState.Bounded env12166 := by
  intro p hp
  have h : env12166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12165_12166 : H12AffineEnvironment.transform 7 85 env12165 = env12166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env12165 == env12166) = true)

theorem identity12166 : scanCanonicalize (H12AffineFastState.compose env12166 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12166 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12167 : List Nat := [2,4,8,16,32,64,8,85,512,101,80,96,120,112,32768,32802,96,0,100,32769,32,33,32832,32883,120,65,33,32785,32785,80,100,32,84,1,32881,33360]

theorem envBound12167 : H12AffineFastState.Bounded env12167 := by
  intro p hp
  have h : env12167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12166_12167 : H12AffineEnvironment.transform 9 101 env12166 = env12167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12166 == env12167) = true)

theorem identity12167 : scanCanonicalize (H12AffineFastState.compose env12167 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12167 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env12168 : List Nat := [2,4,8,16,32,48,8,37,512,21,32,16,8,0,32768,32802,16,0,20,32769,32,33,32816,32771,8,49,33,32785,32785,32,20,32,36,1,32769,33312]

theorem envBound12168 : H12AffineFastState.Bounded env12168 := by
  intro p hp
  have h : env12168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12167_12168 : H12AffineEnvironment.transform 5 48 env12167 = env12168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12167 == env12168) = true)

def env12169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,33,73754,95497,8193,65,245018,79131,45405,247859,119043,119927,257,21793,46093,63068]

theorem envBound12169 : H12AffineFastState.Bounded env12169 := by
  intro p hp
  have h : env12169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12158_12169 : H12AffineEnvironment.transform 6 9 env12158 = env12169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12158 == env12169) = true)

theorem identity12169 : scanCanonicalize (H12AffineFastState.compose env12169 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound12169 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10281,1025,32769,45340,33,21776,3,8193,65,182288,16401,45405,179513,41993,41341,257,21793,46093,63068]

theorem envBound12170 : H12AffineFastState.Bounded env12170 := by
  intro p hp
  have h : env12170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12169_12170 : H12AffineEnvironment.transform 15 29962 env12169 = env12170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env12169 == env12170) = true)

theorem identity12170 : scanCanonicalize (H12AffineFastState.compose env12170 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound12170 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,5393,10281,1025,32769,45340,33,21776,3,8193,65,56577,16401,45405,43048,41993,41341,257,21793,46093,63068]

theorem envBound12171 : H12AffineFastState.Bounded env12171 := by
  intro p hp
  have h : env12171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12170_12171 : H12AffineEnvironment.transform 16 5393 env12170 = env12171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env12170 == env12171) = true)

theorem identity12171 : scanCanonicalize (H12AffineFastState.compose env12171 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound12171 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env12172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,29962,5393,10281,1025,29993,17460,33,21776,3,8193,65,10281,16401,17525,23808,20769,21589,257,21793,16677,884]

theorem envBound12172 : H12AffineFastState.Bounded env12172 := by
  intro p hp
  have h : env12172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12171_12172 : H12AffineEnvironment.transform 14 29992 env12171 = env12172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env12171 == env12172) = true)

theorem identity12172 : scanCanonicalize (H12AffineFastState.compose env12172 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12172 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env12173 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29789,29823,5220,10281,1025,29788,17460,33,21605,3,8193,65,10281,16401,17525,23669,20564,21589,116,21588,16464,513]

theorem envBound12173 : H12AffineFastState.Bounded env12173 := by
  intro p hp
  have h : env12173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12172_12173 : H12AffineEnvironment.transform 7 117 env12172 = env12173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12172 == env12173) = true)

theorem identity12173 : scanCanonicalize (H12AffineFastState.compose env12173 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound12173 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12174 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5156,8313,8283,5220,10281,1025,8312,4112,33,65,3,8193,65,10281,5173,4177,2129,1136,113,116,112,5236,513]

theorem envBound12174 : H12AffineFastState.Bounded env12174 := by
  intro p hp
  have h : env12174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12173_12174 : H12AffineEnvironment.transform 13 5156 env12173 = env12174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env12173 == env12174) = true)

theorem identity12174 : scanCanonicalize (H12AffineFastState.compose env12174 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12174 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12175 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8233,8203,5172,10281,1025,8232,4112,33,17,3,8193,17,10281,5173,4097,2049,1056,33,36,32,5156,513]

theorem envBound12175 : H12AffineFastState.Bounded env12175 := by
  intro p hp
  have h : env12175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12174_12175 : H12AffineEnvironment.transform 5 16 env12174 = env12175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12174 == env12175) = true)

theorem identity12175 : scanCanonicalize (H12AffineFastState.compose env12175 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound12175 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12176 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,1084,5156,1045,1079,5172,3093,1025,1044,4112,33,17,3,1085,17,3093,5173,4097,2049,1056,33,36,32,5156,513]

theorem envBound12176 : H12AffineFastState.Bounded env12176 := by
  intro p hp
  have h : env12176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12175_12176 : H12AffineEnvironment.transform 12 1084 env12175 = env12176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env12175 == env12176) = true)

theorem identity12176 : scanCanonicalize (H12AffineFastState.compose env12176 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound12176 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12177 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,4096,1084,5156,1045,1079,5172,1077,1025,1044,4112,33,17,3,1085,17,1077,5173,4097,33,1056,33,36,32,5156,513]

theorem envBound12177 : H12AffineFastState.Bounded env12177 := by
  intro p hp
  have h : env12177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12176_12177 : H12AffineEnvironment.transform 10 32 env12176 = env12177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env12176 == env12177) = true)

theorem identity12177 : scanCanonicalize (H12AffineFastState.compose env12177 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound12177 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12178 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,1572,1084,512,1045,1079,528,1077,1025,1044,1588,33,17,3,1085,17,1077,529,1573,33,1056,33,36,32,512,513]

theorem envBound12178 : H12AffineFastState.Bounded env12178 := by
  intro p hp
  have h : env12178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12177_12178 : H12AffineEnvironment.transform 11 1572 env12177 = env12178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env12177 == env12178) = true)

theorem identity12178 : scanCanonicalize (H12AffineFastState.compose env12178 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12178 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12179 : List Nat := [2,4,8,16,32,16,9,37,512,53,32,529,9,512,32,2,528,0,52,33,513,33,17,3,8,17,0,529,528,33,21,33,36,32,512,513]

theorem envBound12179 : H12AffineFastState.Bounded env12179 := by
  intro p hp
  have h : env12179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12178_12179 : H12AffineEnvironment.transform 9 53 env12178 = env12179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12178 == env12179) = true)

theorem identity12179 : scanCanonicalize (H12AffineFastState.compose env12179 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound12179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12180 : List Nat := [2,4,8,16,32,16,9,37,48,53,32,33,9,48,32,2,32,0,52,33,49,33,17,3,8,17,0,33,32,33,21,33,36,32,48,49]

theorem envBound12180 : H12AffineFastState.Bounded env12180 := by
  intro p hp
  have h : env12180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12179_12180 : H12AffineEnvironment.transform 8 48 env12179 = env12180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env12179 == env12180) = true)

theorem identity12180 : scanCanonicalize (H12AffineFastState.compose env12180 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12180 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12181 : List Nat := [2,4,8,0,32,0,9,37,32,37,32,33,9,32,32,2,32,0,36,33,33,33,1,3,8,1,0,33,32,33,5,33,36,32,32,33]

theorem envBound12181 : H12AffineFastState.Bounded env12181 := by
  intro p hp
  have h : env12181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12180_12181 : H12AffineEnvironment.transform 3 0 env12180 = env12181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12180 == env12181) = true)

theorem identity12181 : scanCanonicalize (H12AffineFastState.compose env12181 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12181 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12182 : List Nat := [2,4,2,0,32,0,3,37,32,37,32,33,3,32,32,2,32,0,36,33,33,33,1,3,2,1,0,33,32,33,5,33,36,32,32,33]

theorem envBound12182 : H12AffineFastState.Bounded env12182 := by
  intro p hp
  have h : env12182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12181_12182 : H12AffineEnvironment.transform 2 2 env12181 = env12182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12181 == env12182) = true)

theorem identity12182 : scanCanonicalize (H12AffineFastState.compose env12182 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12182 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12183 : List Nat := [2,4,2,0,1,0,3,4,1,4,1,0,3,1,1,2,1,0,5,0,0,0,1,3,2,1,0,0,1,0,5,0,5,1,1,0]

theorem envBound12183 : H12AffineFastState.Bounded env12183 := by
  intro p hp
  have h : env12183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12182_12183 : H12AffineEnvironment.transform 4 1 env12182 = env12183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12182 == env12183) = true)

def env12184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,4194304,8388608,95496,8328,65,12754344,79131,8491471,8579233,8450328,4314198,257,8484155,8492190,8509134]

theorem envBound12184 : H12AffineFastState.Bounded env12184 := by
  intro p hp
  have h : env12184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12129_12184 : H12AffineEnvironment.transform 17 10401 env12129 = env12184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env12129 == env12184) = true)

def env12185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,8388608,95496,8328,65,8560008,79131,8491471,8579233,8450328,119926,257,8484155,8492190,8509134]

theorem envBound12185 : H12AffineFastState.Bounded env12185 := by
  intro p hp
  have h : env12185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12184_12185 : H12AffineEnvironment.transform 21 32 env12184 = env12185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12184 == env12185) = true)

theorem identity12185 : scanCanonicalize (H12AffineFastState.compose env12185 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound12185 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,32,120015,95496,8328,65,215367,79131,17664,212078,75223,119926,257,41460,16465,513]

theorem envBound12186 : H12AffineFastState.Bounded env12186 := by
  intro p hp
  have h : env12186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12185_12186 : H12AffineEnvironment.transform 22 120015 env12185 = env12186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env12185 == env12186) = true)

def env12187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,32,119879,95496,8192,65,215367,79131,17664,212078,75103,119926,257,41340,16465,513]

theorem envBound12187 : H12AffineFastState.Bounded env12187 := by
  intro p hp
  have h : env12187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12186_12187 : H12AffineEnvironment.transform 6 8 env12186 = env12187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12186 == env12187) = true)

theorem identity12187 : scanCanonicalize (H12AffineFastState.compose env12187 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound12187 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env12188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57628,10281,1025,32769,115734,32,119879,95496,8192,65,108635,79131,17664,122226,75103,119926,257,41340,16465,513]

theorem envBound12188 : H12AffineFastState.Bounded env12188 := by
  intro p hp
  have h : env12188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12187_12188 : H12AffineEnvironment.transform 16 57628 env12187 = env12188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env12187 == env12188) = true)

theorem identity12188 : scanCanonicalize (H12AffineFastState.compose env12188 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound12188 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env12189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41050,57628,10281,1025,32769,25676,32,29725,54610,8192,65,2049,38209,17664,32040,34053,29740,257,41340,16465,513]

theorem envBound12189 : H12AffineFastState.Bounded env12189 := by
  intro p hp
  have h : env12189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12188_12189 : H12AffineEnvironment.transform 15 41050 env12188 = env12189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env12188 == env12189) = true)

theorem identity12189 : scanCanonicalize (H12AffineFastState.compose env12189 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12189 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,343,16401,10281,1025,8460,25676,32,29725,29791,8192,65,2049,13388,17664,32040,9224,29740,257,113,16465,513]

theorem envBound12190 : H12AffineFastState.Bounded env12190 := by
  intro p hp
  have h : env12190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12189_12190 : H12AffineEnvironment.transform 14 8461 env12189 = env12190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12189 == env12190) = true)

theorem identity12190 : scanCanonicalize (H12AffineFastState.compose env12190 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12190 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,343,16401,2420,1025,81,17681,32,21824,21762,349,65,2049,5393,17664,23669,1365,21873,257,113,16465,513]

theorem envBound12191 : H12AffineFastState.Bounded env12191 := by
  intro p hp
  have h : env12191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12190_12191 : H12AffineEnvironment.transform 12 349 env12190 = env12191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12190 == env12191) = true)

theorem identity12191 : scanCanonicalize (H12AffineFastState.compose env12191 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound12191 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,80,343,5440,2420,1025,81,4160,32,17,83,349,65,2049,5393,4177,2340,1365,32,257,113,5376,513]

theorem envBound12192 : H12AffineFastState.Bounded env12192 := by
  intro p hp
  have h : env12192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12191_12192 : H12AffineEnvironment.transform 13 5457 env12191 = env12192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env12191 == env12192) = true)

theorem identity12192 : scanCanonicalize (H12AffineFastState.compose env12192 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3637) := by decide +kernel

theorem selectedBound12192 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env12193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3637,349,2916,80,343,2933,2420,1025,81,3701,32,17,83,349,65,2049,2852,3684,2340,1365,32,257,113,2869,513]

theorem envBound12193 : H12AffineFastState.Bounded env12193 := by
  intro p hp
  have h : env12193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12192_12193 : H12AffineEnvironment.transform 11 3637 env12192 = env12193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3637 env12192 == env12193) = true)

theorem identity12193 : scanCanonicalize (H12AffineFastState.compose env12193 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound12193 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env12194 : List Nat := [2,4,8,16,32,64,8,256,293,1024,2048,3344,349,2113,80,343,2128,2420,1025,81,3408,32,17,83,349,65,2049,2049,3393,2340,1365,32,257,113,2064,292]

theorem envBound12194 : H12AffineFastState.Bounded env12194 := by
  intro p hp
  have h : env12194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12193_12194 : H12AffineEnvironment.transform 8 293 env12193 = env12194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env12193 == env12194) = true)

theorem identity12194 : scanCanonicalize (H12AffineFastState.compose env12194 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound12194 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env12195 : List Nat := [2,4,8,16,32,64,8,101,64,1024,2048,3189,56,2113,80,50,2128,2065,1025,81,3125,32,17,83,56,65,2049,2049,3108,2113,1072,32,100,113,2064,65]

theorem envBound12195 : H12AffineFastState.Bounded env12195 := by
  intro p hp
  have h : env12195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12194_12195 : H12AffineEnvironment.transform 7 101 env12194 = env12195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env12194 == env12195) = true)

theorem identity12195 : scanCanonicalize (H12AffineFastState.compose env12195 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound12195 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env12196 : List Nat := [2,4,8,16,32,64,8,101,64,36,2048,2129,56,2113,80,50,2128,2065,37,81,2065,32,17,83,56,65,2049,2049,2048,2113,20,32,100,113,2064,65]

theorem envBound12196 : H12AffineFastState.Bounded env12196 := by
  intro p hp
  have h : env12196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12195_12196 : H12AffineEnvironment.transform 9 36 env12195 = env12196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env12195 == env12196) = true)

theorem identity12196 : scanCanonicalize (H12AffineFastState.compose env12196 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound12196 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12197 : List Nat := [2,4,8,16,32,64,8,101,64,36,17,64,56,80,80,50,65,0,37,81,0,32,17,83,56,65,16,16,17,80,20,32,100,113,1,65]

theorem envBound12197 : H12AffineFastState.Bounded env12197 := by
  intro p hp
  have h : env12197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12196_12197 : H12AffineEnvironment.transform 10 17 env12196 = env12197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env12196 == env12197) = true)

def env12198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,119878,95496,8193,65,215367,79131,17664,212078,75102,119926,257,41341,16465,513]

theorem envBound12198 : H12AffineFastState.Bounded env12198 := by
  intro p hp
  have h : env12198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12186_12198 : H12AffineEnvironment.transform 6 9 env12186 = env12198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12186 == env12198) = true)

theorem identity12198 : scanCanonicalize (H12AffineFastState.compose env12198 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,91467,32,95514,95496,8193,65,215367,79131,17664,212078,75102,95530,257,33,16465,513]

theorem envBound12199 : H12AffineFastState.Bounded env12199 := by
  intro p hp
  have h : env12199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12198_12199 : H12AffineEnvironment.transform 14 8540 env12198 = env12199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12198 == env12199) = true)

theorem identity12199 : scanCanonicalize (H12AffineFastState.compose env12199 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 89110) := by decide +kernel

theorem selectedBound12199 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env12200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,89110,10280,1025,8541,91467,32,95514,95496,8193,65,5457,79131,17664,24696,75102,95530,257,33,16465,513]

theorem envBound12200 : H12AffineFastState.Bounded env12200 := by
  intro p hp
  have h : env12200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12199_12200 : H12AffineEnvironment.transform 16 89110 env12199 = env12200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 89110 env12199 == env12200) = true)

theorem identity12200 : scanCanonicalize (H12AffineFastState.compose env12200 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound12200 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env12201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7505,65536,89110,5157,1025,7504,88390,32,84247,84229,7180,65,5457,67862,17664,23669,72019,84263,257,33,16465,513]

theorem envBound12201 : H12AffineFastState.Bounded env12201 := by
  intro p hp
  have h : env12201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12200_12201 : H12AffineEnvironment.transform 12 7181 env12200 = env12201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env12200 == env12201) = true)

theorem identity12201 : scanCanonicalize (H12AffineFastState.compose env12201 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1379) := by decide +kernel

theorem selectedBound12201 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env12202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7505,1379,22901,5157,1025,7504,23589,32,19572,19558,7180,65,5457,3189,17664,23669,7216,19524,257,33,16465,513]

theorem envBound12202 : H12AffineFastState.Bounded env12202 := by
  intro p hp
  have h : env12202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12201_12202 : H12AffineEnvironment.transform 15 1379 env12201 = env12202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1379 env12201 == env12202) = true)

theorem identity12202 : scanCanonicalize (H12AffineFastState.compose env12202 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12202 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env12203 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,6200,16384,6500,342,22901,4112,52,6501,22544,32,18497,18515,6201,65,4452,2112,16693,22592,6149,18545,257,33,16465,513]

theorem envBound12203 : H12AffineFastState.Bounded env12203 := by
  intro p hp
  have h : env12203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12202_12203 : H12AffineEnvironment.transform 9 53 env12202 = env12203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12202 == env12203) = true)

theorem identity12203 : scanCanonicalize (H12AffineFastState.compose env12203 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12203 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12204 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,6200,16384,6452,262,22821,4112,52,6453,22544,32,18449,18435,6201,17,4404,2064,16693,22544,6149,18465,257,33,16385,513]

theorem envBound12204 : H12AffineFastState.Bounded env12204 := by
  intro p hp
  have h : env12204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12203_12204 : H12AffineEnvironment.transform 5 16 env12203 = env12204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12203 == env12204) = true)

theorem identity12204 : scanCanonicalize (H12AffineFastState.compose env12204 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound12204 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12205 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,6200,2048,6452,262,4389,4112,52,6453,4112,32,17,3,6201,17,4404,2064,2357,4112,6149,33,257,33,2049,513]

theorem envBound12205 : H12AffineFastState.Bounded env12205 := by
  intro p hp
  have h : env12205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12204_12205 : H12AffineEnvironment.transform 13 2048 env12204 = env12205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env12204 == env12205) = true)

theorem identity12205 : scanCanonicalize (H12AffineFastState.compose env12205 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound12205 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12206 : List Nat := [2,4,8,16,32,16,9,256,309,53,2048,4096,6200,2048,6452,262,4389,4112,52,6453,4112,32,17,3,6201,17,4404,2064,2357,4112,6149,33,257,33,2049,308]

theorem envBound12206 : H12AffineFastState.Bounded env12206 := by
  intro p hp
  have h : env12206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12205_12206 : H12AffineEnvironment.transform 8 309 env12205 = env12206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env12205 == env12206) = true)

theorem identity12206 : scanCanonicalize (H12AffineFastState.compose env12206 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound12206 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env12207 : List Nat := [2,4,8,16,32,16,9,256,309,53,308,4096,4364,308,4096,262,4389,4112,52,4097,4112,32,17,3,4365,17,4404,292,1,4112,4401,33,257,33,309,308]

theorem envBound12207 : H12AffineFastState.Bounded env12207 := by
  intro p hp
  have h : env12207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12206_12207 : H12AffineEnvironment.transform 10 308 env12206 = env12207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env12206 == env12207) = true)

theorem identity12207 : scanCanonicalize (H12AffineFastState.compose env12207 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12207 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env12208 : List Nat := [2,4,8,16,32,16,9,37,16,53,17,4096,4137,17,4096,35,4096,4112,52,4097,4112,32,17,3,4136,17,4113,1,1,4112,4116,33,36,33,16,17]

theorem envBound12208 : H12AffineFastState.Bounded env12208 := by
  intro p hp
  have h : env12208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12207_12208 : H12AffineEnvironment.transform 7 37 env12207 = env12208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12207 == env12208) = true)

theorem identity12208 : scanCanonicalize (H12AffineFastState.compose env12208 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound12208 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12209 : List Nat := [2,4,8,16,32,16,9,37,16,53,17,32,9,17,32,35,32,48,52,33,48,32,17,3,8,17,49,1,1,48,52,33,36,33,16,17]

theorem envBound12209 : H12AffineFastState.Bounded env12209 := by
  intro p hp
  have h : env12209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12208_12209 : H12AffineEnvironment.transform 11 32 env12208 = env12209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env12208 == env12209) = true)

theorem identity12209 : scanCanonicalize (H12AffineFastState.compose env12209 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12209 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env12210 : List Nat := [2,4,8,0,32,0,9,37,0,37,1,32,9,1,32,35,32,32,36,33,32,32,1,3,8,1,33,1,1,32,36,33,36,33,0,1]

theorem envBound12210 : H12AffineFastState.Bounded env12210 := by
  intro p hp
  have h : env12210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12209_12210 : H12AffineEnvironment.transform 3 0 env12209 = env12210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12209 == env12210) = true)

theorem identity12210 : scanCanonicalize (H12AffineFastState.compose env12210 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12211 : List Nat := [2,4,8,0,1,0,9,4,0,4,1,1,9,1,1,2,1,1,5,0,1,1,1,3,8,1,0,1,1,1,5,0,5,0,0,1]

theorem envBound12211 : H12AffineFastState.Bounded env12211 := by
  intro p hp
  have h : env12211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12210_12211 : H12AffineEnvironment.transform 4 1 env12210 = env12211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12210 == env12211) = true)

def env12212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115870,33,8388608,95496,8328,65,8560009,79131,8491471,8579233,8450328,119927,257,8484155,8492190,8509134]

theorem envBound12212 : H12AffineFastState.Bounded env12212 := by
  intro p hp
  have h : env12212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12184_12212 : H12AffineEnvironment.transform 21 33 env12184 = env12212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12184 == env12212) = true)

theorem identity12212 : scanCanonicalize (H12AffineFastState.compose env12212 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12212 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10401,1025,32769,4160,33,8388608,41430,8328,65,8560009,57797,8406289,8579233,8450328,169,257,8430053,8405056,8389136]

theorem envBound12213 : H12AffineFastState.Bounded env12213 := by
  intro p hp
  have h : env12213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12212_12213 : H12AffineEnvironment.transform 15 54494 env12212 = env12213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12212 == env12213) = true)

theorem identity12213 : scanCanonicalize (H12AffineFastState.compose env12213 (packedSelected [3,10,11,17,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12213 : packedSelected [3,10,11,17,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env12214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10401,1025,32769,4160,33,17,41430,8328,65,171416,57797,17664,190640,61705,169,257,41460,16465,513]

theorem envBound12214 : H12AffineFastState.Bounded env12214 := by
  intro p hp
  have h : env12214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12213_12214 : H12AffineEnvironment.transform 22 17 env12213 = env12214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12213 == env12214) = true)

def env12215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,33,17,41310,8192,65,171280,57677,17664,190520,61705,33,257,41340,16465,513]

theorem envBound12215 : H12AffineFastState.Bounded env12215 := by
  intro p hp
  have h : env12215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12214_12215 : H12AffineEnvironment.transform 6 8 env12214 = env12215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12214 == env12215) = true)

theorem identity12215 : scanCanonicalize (H12AffineFastState.compose env12215 (packedSelected [0,4,7,9,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound12215 : packedSelected [0,4,7,9,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env12216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5393,10281,1025,32769,4160,33,17,41310,8192,65,34817,57677,17664,64809,61705,33,257,41340,16465,513]

theorem envBound12216 : H12AffineFastState.Bounded env12216 := by
  intro p hp
  have h : env12216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12215_12216 : H12AffineEnvironment.transform 16 5393 env12215 = env12216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env12215 == env12216) = true)

theorem identity12216 : scanCanonicalize (H12AffineFastState.compose env12216 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound12216 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40970,5393,10281,1025,32769,4160,33,17,41310,8192,65,34817,38161,12636,35189,34133,33,257,41340,13325,513]

theorem envBound12217 : H12AffineFastState.Bounded env12217 := by
  intro p hp
  have h : env12217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12216_12217 : H12AffineEnvironment.transform 13 13404 env12216 = env12217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env12216 == env12217) = true)

theorem identity12217 : scanCanonicalize (H12AffineFastState.compose env12217 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12217 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env12218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,342,5393,10281,1025,8541,4160,33,17,2,8192,65,10589,13389,12636,10281,9225,33,257,32,13325,513]

theorem envBound12218 : H12AffineFastState.Bounded env12218 := by
  intro p hp
  have h : env12218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12217_12218 : H12AffineEnvironment.transform 14 8540 env12217 = env12218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12217 == env12218) = true)

theorem identity12218 : scanCanonicalize (H12AffineFastState.compose env12218 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12218 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,81,342,5393,2340,1025,80,4160,33,17,2,269,65,2128,5440,4177,2340,1284,33,257,32,5376,513]

theorem envBound12219 : H12AffineFastState.Bounded env12219 := by
  intro p hp
  have h : env12219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12218_12219 : H12AffineEnvironment.transform 12 269 env12218 = env12219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12218 == env12219) = true)

theorem identity12219 : scanCanonicalize (H12AffineFastState.compose env12219 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12219 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12220 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4112,33,17,2,269,17,2048,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound12220 : H12AffineFastState.Bounded env12220 := by
  intro p hp
  have h : env12220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12219_12220 : H12AffineEnvironment.transform 5 16 env12219 = env12220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12219 == env12220) = true)

theorem identity12220 : scanCanonicalize (H12AffineFastState.compose env12220 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12221 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,35,5172,2049,1025,0,4112,33,17,2,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound12221 : H12AffineFastState.Bounded env12221 := by
  intro p hp
  have h : env12221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12220_12221 : H12AffineEnvironment.transform 7 37 env12220 = env12221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12220 == env12221) = true)

theorem identity12221 : scanCanonicalize (H12AffineFastState.compose env12221 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12221 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12222 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,16,40,1076,1,35,1060,2049,1025,0,0,33,17,2,40,17,2048,1061,17,2049,1057,33,36,32,1077,513]

theorem envBound12222 : H12AffineFastState.Bounded env12222 := by
  intro p hp
  have h : env12222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12221_12222 : H12AffineEnvironment.transform 11 16 env12221 = env12222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12221 == env12222) = true)

theorem identity12222 : scanCanonicalize (H12AffineFastState.compose env12222 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12222 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12223 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,16,40,1076,1,35,1060,1,1025,0,0,33,17,2,40,17,0,1061,17,1,1057,33,36,32,1077,513]

theorem envBound12223 : H12AffineFastState.Bounded env12223 := by
  intro p hp
  have h : env12223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12222_12223 : H12AffineEnvironment.transform 10 0 env12222 = env12223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12222 == env12223) = true)

theorem identity12223 : scanCanonicalize (H12AffineFastState.compose env12223 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12223 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12224 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,40,1,1,35,17,1,52,0,0,33,17,2,40,17,0,16,17,1,20,33,36,32,0,513]

theorem envBound12224 : H12AffineFastState.Bounded env12224 := by
  intro p hp
  have h : env12224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12223_12224 : H12AffineEnvironment.transform 9 53 env12223 = env12224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12223 == env12224) = true)

theorem identity12224 : scanCanonicalize (H12AffineFastState.compose env12224 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound12224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12225 : List Nat := [2,4,8,16,32,16,8,37,16,53,0,16,40,1,1,35,17,1,52,0,0,33,17,2,40,17,0,16,17,1,20,33,36,32,0,17]

theorem envBound12225 : H12AffineFastState.Bounded env12225 := by
  intro p hp
  have h : env12225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12224_12225 : H12AffineEnvironment.transform 8 16 env12224 = env12225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env12224 == env12225) = true)

theorem identity12225 : scanCanonicalize (H12AffineFastState.compose env12225 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12226 : List Nat := [2,4,3,16,32,16,3,37,16,53,0,16,35,1,1,35,17,1,52,0,0,33,17,2,35,17,0,16,17,1,20,33,36,32,0,17]

theorem envBound12226 : H12AffineFastState.Bounded env12226 := by
  intro p hp
  have h : env12226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12225_12226 : H12AffineEnvironment.transform 2 3 env12225 = env12226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12225 == env12226) = true)

def env12227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1025,32769,4160,33,17,41311,8193,65,171281,57676,17664,190521,61705,32,257,41341,16465,513]

theorem envBound12227 : H12AffineFastState.Bounded env12227 := by
  intro p hp
  have h : env12227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12214_12227 : H12AffineEnvironment.transform 6 9 env12214 = env12227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12214 == env12227) = true)

theorem identity12227 : scanCanonicalize (H12AffineFastState.compose env12227 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12227 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,131072,10280,1025,8541,4160,33,17,3,8193,65,146509,16400,17664,149861,20565,32,257,33,16465,513]

theorem envBound12228 : H12AffineFastState.Bounded env12228 := by
  intro p hp
  have h : env12228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12227_12228 : H12AffineEnvironment.transform 14 8540 env12227 = env12228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12227 == env12228) = true)

theorem identity12228 : scanCanonicalize (H12AffineFastState.compose env12228 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12228 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env12229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,8192,16384,8540,27930,131072,10280,1025,8541,2129,33,17,3,8193,65,140380,16400,17664,149861,18500,32,257,33,16465,513]

theorem envBound12229 : H12AffineFastState.Bounded env12229 := by
  intro p hp
  have h : env12229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12228_12229 : H12AffineEnvironment.transform 11 2065 env12228 = env12229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env12228 == env12229) = true)

theorem identity12229 : scanCanonicalize (H12AffineFastState.compose env12229 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12229 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,0,19526,131072,2420,1025,1,2129,33,17,3,349,65,132352,16400,17664,149861,18500,32,257,33,16465,513]

theorem envBound12230 : H12AffineFastState.Bounded env12230 := by
  intro p hp
  have h : env12230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12229_12230 : H12AffineEnvironment.transform 12 348 env12229 = env12230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12229 == env12230) = true)

theorem identity12230 : scanCanonicalize (H12AffineFastState.compose env12230 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12230 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,0,19526,2065,2420,1025,1,2129,33,17,3,349,65,3345,16400,17664,16756,18500,32,257,33,16465,513]

theorem envBound12231 : H12AffineFastState.Bounded env12231 := by
  intro p hp
  have h : env12231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12230_12231 : H12AffineEnvironment.transform 16 2065 env12230 = env12231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2065 env12230 == env12231) = true)

theorem identity12231 : scanCanonicalize (H12AffineFastState.compose env12231 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12231 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env12232 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,16384,0,18775,2065,2420,272,1,2129,33,17,3,349,65,2048,16400,16401,16756,18500,32,257,33,16465,513]

theorem envBound12232 : H12AffineFastState.Bounded env12232 := by
  intro p hp
  have h : env12232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12231_12232 : H12AffineEnvironment.transform 9 273 env12231 = env12232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12231 == env12232) = true)

theorem identity12232 : scanCanonicalize (H12AffineFastState.compose env12232 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2075) := by decide +kernel

theorem selectedBound12232 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env12233 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,2075,0,332,2065,2420,272,1,2129,33,17,3,349,65,2048,2059,2058,2415,95,32,257,33,2122,513]

theorem envBound12233 : H12AffineFastState.Bounded env12233 := by
  intro p hp
  have h : env12233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12232_12233 : H12AffineEnvironment.transform 13 2075 env12232 = env12233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2075 env12232 == env12233) = true)

theorem identity12233 : scanCanonicalize (H12AffineFastState.compose env12233 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12233 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12234 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2065,40,2075,0,56,2065,2048,100,1,2129,33,17,3,41,65,2048,2059,2058,2075,95,32,117,33,2122,513]

theorem envBound12234 : H12AffineFastState.Bounded env12234 := by
  intro p hp
  have h : env12234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12233_12234 : H12AffineEnvironment.transform 7 116 env12233 = env12234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12233 == env12234) = true)

theorem identity12234 : scanCanonicalize (H12AffineFastState.compose env12234 (packedSelected [0,1,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound12234 : packedSelected [0,1,2,6] rootPS < 2^1333 := by decide +kernel

def env12235 : List Nat := [2,4,8,12,32,64,9,104,512,101,2048,2061,40,2055,0,36,2061,2048,100,1,2125,33,13,3,41,65,2048,2059,2058,2055,67,32,105,33,2122,513]

theorem envBound12235 : H12AffineFastState.Bounded env12235 := by
  intro p hp
  have h : env12235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12234_12235 : H12AffineEnvironment.transform 3 12 env12234 = env12235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env12234 == env12235) = true)

theorem identity12235 : scanCanonicalize (H12AffineFastState.compose env12235 (packedSelected [0,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound12235 : packedSelected [0,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12236 : List Nat := [2,4,8,12,32,10,9,34,512,47,2048,2061,40,2055,0,36,2061,2048,46,1,2055,33,13,3,41,11,2048,2059,2058,2055,9,32,35,33,2048,513]

theorem envBound12236 : H12AffineFastState.Bounded env12236 := by
  intro p hp
  have h : env12236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12235_12236 : H12AffineEnvironment.transform 5 10 env12235 = env12236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env12235 == env12236) = true)

theorem identity12236 : scanCanonicalize (H12AffineFastState.compose env12236 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound12236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12237 : List Nat := [2,4,8,12,32,10,9,34,46,47,2048,2061,40,2055,0,36,2061,2048,46,1,2055,33,13,3,41,11,2048,2059,2058,2055,9,32,35,33,2048,47]

theorem envBound12237 : H12AffineFastState.Bounded env12237 := by
  intro p hp
  have h : env12237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12236_12237 : H12AffineEnvironment.transform 8 46 env12236 = env12237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env12236 == env12237) = true)

theorem identity12237 : scanCanonicalize (H12AffineFastState.compose env12237 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound12237 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12238 : List Nat := [2,3,8,11,32,10,9,34,41,40,2048,2058,40,2048,0,35,2058,2048,41,1,2048,33,10,3,41,11,2048,2059,2058,2048,9,32,35,33,2048,40]

theorem envBound12238 : H12AffineFastState.Bounded env12238 := by
  intro p hp
  have h : env12238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12237_12238 : H12AffineEnvironment.transform 1 3 env12237 = env12238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env12237 == env12238) = true)

theorem identity12238 : scanCanonicalize (H12AffineFastState.compose env12238 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound12238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12239 : List Nat := [2,3,8,11,32,10,9,34,41,40,10,0,40,10,0,35,0,10,41,1,10,33,10,3,41,11,10,1,0,10,9,32,35,33,10,40]

theorem envBound12239 : H12AffineFastState.Bounded env12239 := by
  intro p hp
  have h : env12239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12238_12239 : H12AffineEnvironment.transform 10 10 env12238 = env12239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env12238 == env12239) = true)

def env12240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound12240 : H12AffineFastState.Bounded env12240 := by
  intro p hp
  have h : env12240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11780_12240 : H12AffineEnvironment.transform 26 30393345 env11780 = env12240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env11780 == env12240) = true)

def env12241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound12241 : H12AffineFastState.Bounded env12241 := by
  intro p hp
  have h : env12241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12240_12241 : H12AffineEnvironment.transform 18 1024 env12240 = env12241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12240 == env12241) = true)

theorem identity12241 : scanCanonicalize (H12AffineFastState.compose env12241 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485758) := by decide +kernel

theorem selectedBound12241 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485758,16777216,8328,65,21014911,18973836,2571311,108926,17231214,23160257,256,19312083,19287158,17287865]

theorem envBound12242 : H12AffineFastState.Bounded env12242 := by
  intro p hp
  have h : env12242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12241_12242 : H12AffineEnvironment.transform 22 485758 env12241 = env12242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485758 env12241 == env12242) = true)

def env12243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156132,485758,16777216,8328,65,16959643,18973836,2571311,108926,17231214,19072037,256,19312083,19287158,17287865]

theorem envBound12243 : H12AffineFastState.Bounded env12243 := by
  intro p hp
  have h : env12243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12242_12243 : H12AffineEnvironment.transform 21 156132 env12242 = env12243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env12242 == env12243) = true)

def env12244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156132,485758,16777216,8328,65,16959643,17246588,102879,108926,17231214,17148373,256,16777251,16834950,17287865]

theorem envBound12244 : H12AffineFastState.Bounded env12244 := by
  intro p hp
  have h : env12244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12243_12244 : H12AffineEnvironment.transform 20 437744 env12243 = env12244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env12243 == env12244) = true)

theorem identity12244 : scanCanonicalize (H12AffineFastState.compose env12244 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound12244 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env12245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156132,485758,188871,8328,65,10588,379067,102879,108926,265385,477202,256,188900,131137,338814]

theorem envBound12245 : H12AffineFastState.Bounded env12245 := by
  intro p hp
  have h : env12245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12244_12245 : H12AffineEnvironment.transform 23 188871 env12244 = env12245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env12244 == env12245) = true)

def env12246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,156132,120014,188871,8328,65,10588,226571,102879,108926,176409,128418,256,188900,131137,235214]

theorem envBound12246 : H12AffineFastState.Bounded env12246 := by
  intro p hp
  have h : env12246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12245_12246 : H12AffineEnvironment.transform 17 179632 env12245 = env12246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env12245 == env12246) = true)

theorem identity12246 : scanCanonicalize (H12AffineFastState.compose env12246 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound12246 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1024,29909,4160,156132,73754,136467,8328,65,10588,226571,91403,89514,148941,65910,256,136496,131137,221722]

theorem envBound12247 : H12AffineFastState.Bounded env12247 := by
  intro p hp
  have h : env12247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12246_12247 : H12AffineEnvironment.transform 14 29908 env12246 = env12247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env12246 == env12247) = true)

theorem identity12247 : scanCanonicalize (H12AffineFastState.compose env12247 (packedSelected [0,1,4,5,7,8,14,15,16,17,20,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12247 : packedSelected [0,1,4,5,7,8,14,15,16,17,20,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env12248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,131072,149860,1024,29909,4160,156132,17,136467,8328,65,10588,152832,17664,32161,148941,8573,256,136496,131137,147985]

theorem envBound12248 : H12AffineFastState.Bounded env12248 := by
  intro p hp
  have h : env12248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12247_12248 : H12AffineEnvironment.transform 15 8203 env12247 = env12248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12247 == env12248) = true)

theorem identity12248 : scanCanonicalize (H12AffineFastState.compose env12248 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12248 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env12249 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,8203,131072,149860,1024,29708,4160,155965,17,136467,8273,65,10588,152832,17664,32120,148756,8573,256,136496,131137,147985]

theorem envBound12249 : H12AffineFastState.Bounded env12249 := by
  intro p hp
  have h : env12249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12248_12249 : H12AffineEnvironment.transform 6 89 env12248 = env12249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12248 == env12249) = true)

theorem identity12249 : scanCanonicalize (H12AffineFastState.compose env12249 (packedSelected [1,2,7,8,9,11,12,14,15,16,17,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound12249 : packedSelected [1,2,7,8,9,11,12,14,15,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env12250 : List Nat := [2,4,8,16,32,64,89,256,512,1024,373,4096,8192,16384,29709,8203,131072,147473,1024,29708,4160,155965,17,136467,8273,65,8233,152832,17664,29709,148756,8573,256,136496,131137,147985]

theorem envBound12250 : H12AffineFastState.Bounded env12250 := by
  intro p hp
  have h : env12250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12249_12250 : H12AffineEnvironment.transform 10 373 env12249 = env12250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env12249 == env12250) = true)

theorem identity12250 : scanCanonicalize (H12AffineFastState.compose env12250 (packedSelected [0,1,2,4,8,9,11,12,14,15,17,18,19,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound12250 : packedSelected [0,1,2,4,8,9,11,12,14,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env12251 : List Nat := [2,4,8,16,32,64,89,256,512,1024,373,4096,8192,16384,29709,8203,24908,8541,1024,29708,4160,113,17,29791,8273,65,8233,13388,17664,29709,9304,8573,256,29820,24845,9053]

theorem envBound12251 : H12AffineFastState.Bounded env12251 := by
  intro p hp
  have h : env12251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12250_12251 : H12AffineEnvironment.transform 16 24908 env12250 = env12251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env12250 == env12251) = true)

theorem identity12251 : scanCanonicalize (H12AffineFastState.compose env12251 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12251 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12252 : List Nat := [2,4,8,16,32,64,89,256,512,1024,373,4096,1053,16384,20496,1046,17745,1344,1024,20497,4160,113,17,20546,1100,65,1076,4177,17664,20496,69,1376,256,20577,17680,1856]

theorem envBound12252 : H12AffineFastState.Bounded env12252 := by
  intro p hp
  have h : env12252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12251_12252 : H12AffineEnvironment.transform 12 1053 env12251 = env12252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12251 == env12252) = true)

theorem identity12252 : scanCanonicalize (H12AffineFastState.compose env12252 (packedSelected [0,1,2,3,6,7,12] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound12252 : packedSelected [0,1,2,3,6,7,12] rootPS < 2^1333 := by decide +kernel

def env12253 : List Nat := [2,4,8,16,32,64,89,256,512,1024,373,4096,1053,1344,5456,1046,17,1344,1024,5457,4160,113,17,5378,1100,65,1076,4177,64,5456,69,1376,256,5409,80,1856]

theorem envBound12253 : H12AffineFastState.Bounded env12253 := by
  intro p hp
  have h : env12253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12252_12253 : H12AffineEnvironment.transform 13 1344 env12252 = env12253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12252 == env12253) = true)

theorem identity12253 : scanCanonicalize (H12AffineFastState.compose env12253 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12253 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env12254 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,4096,1053,1296,5376,1046,17,1296,1024,5377,4112,33,17,5378,1052,17,1076,4097,16,5376,21,1328,256,5409,0,1808]

theorem envBound12254 : H12AffineFastState.Bounded env12254 := by
  intro p hp
  have h : env12254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12253_12254 : H12AffineEnvironment.transform 5 16 env12253 = env12254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12253 == env12254) = true)

theorem identity12254 : scanCanonicalize (H12AffineFastState.compose env12254 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12254 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12255 : List Nat := [2,4,8,16,32,16,9,256,512,272,293,4096,269,0,4112,262,17,0,272,4113,4112,33,17,4114,268,17,292,4097,16,4112,21,32,256,4145,0,512]

theorem envBound12255 : H12AffineFastState.Bounded env12255 := by
  intro p hp
  have h : env12255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12254_12255 : H12AffineEnvironment.transform 9 272 env12254 = env12255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12254 == env12255) = true)

theorem identity12255 : scanCanonicalize (H12AffineFastState.compose env12255 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12255 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12256 : List Nat := [2,4,8,16,0,16,9,256,512,272,261,4096,269,0,4112,262,17,0,272,4113,4112,1,17,4114,268,17,260,4097,16,4112,21,0,256,4113,0,512]

theorem envBound12256 : H12AffineFastState.Bounded env12256 := by
  intro p hp
  have h : env12256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12255_12256 : H12AffineEnvironment.transform 4 0 env12255 = env12256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12255 == env12256) = true)

theorem identity12256 : scanCanonicalize (H12AffineFastState.compose env12256 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound12256 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12257 : List Nat := [2,4,8,16,0,16,9,256,512,272,261,276,269,0,260,262,17,0,272,261,260,1,17,262,268,17,260,277,16,260,21,0,256,261,0,512]

theorem envBound12257 : H12AffineFastState.Bounded env12257 := by
  intro p hp
  have h : env12257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12256_12257 : H12AffineEnvironment.transform 11 276 env12256 = env12257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env12256 == env12257) = true)

theorem identity12257 : scanCanonicalize (H12AffineFastState.compose env12257 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12258 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,0,0,2,17,0,20,1,0,1,17,2,8,17,0,17,16,0,21,0,4,1,0,512]

theorem envBound12258 : H12AffineFastState.Bounded env12258 := by
  intro p hp
  have h : env12258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12257_12258 : H12AffineEnvironment.transform 7 4 env12257 = env12258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12257 == env12258) = true)

theorem identity12258 : scanCanonicalize (H12AffineFastState.compose env12258 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound12258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12259 : List Nat := [2,4,8,16,0,16,9,4,17,20,1,16,9,0,0,2,17,0,20,1,0,1,17,2,8,17,0,17,16,0,21,0,4,1,0,17]

theorem envBound12259 : H12AffineFastState.Bounded env12259 := by
  intro p hp
  have h : env12259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12258_12259 : H12AffineEnvironment.transform 8 17 env12258 = env12259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env12258 == env12259) = true)

theorem identity12259 : scanCanonicalize (H12AffineFastState.compose env12259 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound12259 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12260 : List Nat := [2,4,8,4,0,4,9,4,5,0,1,4,9,0,0,2,5,0,0,1,0,1,5,2,8,5,0,5,4,0,1,0,4,1,0,5]

theorem envBound12260 : H12AffineFastState.Bounded env12260 := by
  intro p hp
  have h : env12260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12259_12260 : H12AffineEnvironment.transform 3 4 env12259 = env12260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env12259 == env12260) = true)

def env12261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,156132,120015,188871,8328,65,10588,226570,102879,108926,176408,128419,256,188900,131137,235215]

theorem envBound12261 : H12AffineFastState.Bounded env12261 := by
  intro p hp
  have h : env12261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12245_12261 : H12AffineEnvironment.transform 17 179633 env12245 = env12261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env12245 == env12261) = true)

theorem identity12261 : scanCanonicalize (H12AffineFastState.compose env12261 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12261 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122282,1024,32769,4161,66047,120015,98780,8328,65,10588,5393,102879,108926,119043,128419,256,98815,90202,63188]

theorem envBound12262 : H12AffineFastState.Bounded env12262 := by
  intro p hp
  have h : env12262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12261_12262 : H12AffineEnvironment.transform 16 90139 env12261 = env12262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12261 == env12262) = true)

theorem identity12262 : scanCanonicalize (H12AffineFastState.compose env12262 (packedSelected [1,4,5,7,8,9,15,16,17,20,24,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12262 : packedSelected [1,4,5,7,8,9,15,16,17,20,24,27,38] rootPS < 2^1333 := by decide +kernel

def env12263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64929,1024,32769,4161,8692,62660,41431,8328,65,10588,5393,45524,35189,61704,54696,256,41460,16465,63188]

theorem envBound12263 : H12AffineFastState.Bounded env12263 := by
  intro p hp
  have h : env12263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12262_12263 : H12AffineEnvironment.transform 15 8203 env12262 = env12263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12262 == env12263) = true)

theorem identity12263 : scanCanonicalize (H12AffineFastState.compose env12263 (packedSelected [4,7,9,11,18,23,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound12263 : packedSelected [4,7,9,11,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env12264 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64889,1024,32769,4161,8492,62492,41231,8272,65,10588,5393,45324,35189,61704,54640,256,41260,16465,62988]

theorem envBound12264 : H12AffineFastState.Bounded env12264 := by
  intro p hp
  have h : env12264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12263_12264 : H12AffineEnvironment.transform 6 88 env12263 = env12264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env12263 == env12264) = true)

theorem identity12264 : scanCanonicalize (H12AffineFastState.compose env12264 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12264 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env12265 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,262,16400,56436,1024,32769,4161,33,54545,32770,349,65,2129,5393,36865,35189,53253,54640,256,32801,16465,55041]

theorem envBound12265 : H12AffineFastState.Bounded env12265 := by
  intro p hp
  have h : env12265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12264_12265 : H12AffineEnvironment.transform 12 269 env12264 = env12265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12264 == env12265) = true)

theorem identity12265 : scanCanonicalize (H12AffineFastState.compose env12265 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound12265 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env12266 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,21761,262,16400,2421,1024,21760,4161,33,16,21763,349,65,2129,5393,17664,23668,1284,113,256,21792,16465,512]

theorem envBound12266 : H12AffineFastState.Bounded env12266 := by
  intro p hp
  have h : env12266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12265_12266 : H12AffineEnvironment.transform 14 21761 env12265 = env12266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env12265 == env12266) = true)

theorem identity12266 : scanCanonicalize (H12AffineFastState.compose env12266 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound12266 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12267 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5409,32,262,5425,2421,1024,33,4161,33,16,34,349,65,2129,5393,4129,2389,1284,113,256,1,5488,512]

theorem envBound12267 : H12AffineFastState.Bounded env12267 := by
  intro p hp
  have h : env12267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12266_12267 : H12AffineEnvironment.transform 13 5409 env12266 = env12267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env12266 == env12267) = true)

theorem identity12267 : scanCanonicalize (H12AffineFastState.compose env12267 (packedSelected [0,3,4,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 107) := by decide +kernel

theorem selectedBound12267 : packedSelected [0,3,4,8,10,11] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0