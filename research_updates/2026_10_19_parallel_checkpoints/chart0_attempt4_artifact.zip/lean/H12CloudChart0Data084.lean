import H12CloudChart0Data083

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans21215_21216 : H12AffineEnvironment.transform 16 13373 env21215 = env21216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env21215 == env21216) = true)

theorem identity21216 : scanCanonicalize (H12AffineFastState.compose env21216 (packedSelected [2,6,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21216 : packedSelected [2,6,16,20] rootPS < 2^1333 := by decide +kernel

def env21217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,294,13373,2308,1024,8540,4160,8461,17,8494,8192,64,2161,5392,4097,2420,1365,8460,256,33,5457,9005]

theorem envBound21217 : H12AffineFastState.Bounded env21217 := by
  intro p hp
  have h : env21217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21216_21217 : H12AffineEnvironment.transform 6 8 env21216 = env21217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21216 == env21217) = true)

theorem identity21217 : scanCanonicalize (H12AffineFastState.compose env21217 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound21217 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5376,112,294,5392,2308,1024,113,4160,32,17,3,301,64,2161,5392,4097,2420,1365,33,256,33,5457,512]

theorem envBound21218 : H12AffineFastState.Bounded env21218 := by
  intro p hp
  have h : env21218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21217_21218 : H12AffineEnvironment.transform 12 301 env21217 = env21218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env21217 == env21218) = true)

theorem identity21218 : scanCanonicalize (H12AffineFastState.compose env21218 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound21218 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21219 : List Nat := [2,4,8,16,32,64,8,256,512,353,2048,4096,301,4193,112,294,4209,2308,353,113,4160,32,17,3,301,64,2161,4209,4097,2420,52,33,256,33,4144,512]

theorem envBound21219 : H12AffineFastState.Bounded env21219 := by
  intro p hp
  have h : env21219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21218_21219 : H12AffineEnvironment.transform 9 353 env21218 = env21219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env21218 == env21219) = true)

theorem identity21219 : scanCanonicalize (H12AffineFastState.compose env21219 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound21219 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21220 : List Nat := [2,4,8,16,32,64,8,256,512,353,2048,2350,301,2383,112,294,2399,2308,353,113,2414,32,17,3,301,64,2161,2399,2351,2420,52,33,256,33,2334,512]

theorem envBound21220 : H12AffineFastState.Bounded env21220 := by
  intro p hp
  have h : env21220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21219_21220 : H12AffineEnvironment.transform 11 2350 env21219 = env21220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env21219 == env21220) = true)

theorem identity21220 : scanCanonicalize (H12AffineFastState.compose env21220 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound21220 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env21221 : List Nat := [2,4,8,16,32,64,8,256,512,353,80,382,301,287,112,294,271,340,353,113,318,32,17,3,301,64,33,271,383,292,52,33,256,33,334,512]

theorem envBound21221 : H12AffineFastState.Bounded env21221 := by
  intro p hp
  have h : env21221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21220_21221 : H12AffineEnvironment.transform 10 80 env21220 = env21221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env21220 == env21221) = true)

theorem identity21221 : scanCanonicalize (H12AffineFastState.compose env21221 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound21221 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21222 : List Nat := [2,4,8,16,32,64,8,78,512,47,80,48,99,81,112,104,65,26,47,113,112,32,17,3,99,64,33,65,49,106,52,33,78,33,0,512]

theorem envBound21222 : H12AffineFastState.Bounded env21222 := by
  intro p hp
  have h : env21222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21221_21222 : H12AffineEnvironment.transform 7 78 env21221 = env21222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env21221 == env21222) = true)

theorem identity21222 : scanCanonicalize (H12AffineFastState.compose env21222 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound21222 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21223 : List Nat := [2,4,8,16,32,32,8,46,512,47,48,48,3,49,16,8,33,26,47,17,16,32,17,3,3,32,33,33,49,10,52,33,46,33,0,512]

theorem envBound21223 : H12AffineFastState.Bounded env21223 := by
  intro p hp
  have h : env21223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21222_21223 : H12AffineEnvironment.transform 5 32 env21222 = env21223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env21222 == env21223) = true)

theorem identity21223 : scanCanonicalize (H12AffineFastState.compose env21223 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21223 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env21224 : List Nat := [2,4,8,1,32,32,8,46,512,47,33,33,3,32,1,8,33,11,47,0,1,32,0,3,3,32,33,33,32,10,37,33,46,33,0,512]

theorem envBound21224 : H12AffineFastState.Bounded env21224 := by
  intro p hp
  have h : env21224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21223_21224 : H12AffineEnvironment.transform 3 1 env21223 = env21224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21223 == env21224) = true)

theorem identity21224 : scanCanonicalize (H12AffineFastState.compose env21224 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound21224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21225 : List Nat := [2,2,8,1,32,32,8,40,512,41,33,33,3,32,1,8,33,11,41,0,1,32,0,3,3,32,33,33,32,10,35,33,40,33,0,512]

theorem envBound21225 : H12AffineFastState.Bounded env21225 := by
  intro p hp
  have h : env21225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21224_21225 : H12AffineEnvironment.transform 1 2 env21224 = env21225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env21224 == env21225) = true)

theorem identity21225 : scanCanonicalize (H12AffineFastState.compose env21225 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21226 : List Nat := [2,2,8,1,1,1,8,9,512,8,0,0,3,1,1,8,0,11,8,0,1,1,0,3,3,1,0,0,1,10,2,0,9,0,0,512]

theorem envBound21226 : H12AffineFastState.Bounded env21226 := by
  intro p hp
  have h : env21226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21225_21226 : H12AffineEnvironment.transform 4 1 env21225 = env21226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21225 == env21226) = true)

theorem identity21226 : scanCanonicalize (H12AffineFastState.compose env21226 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21226 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21227 : List Nat := [2,2,3,1,1,1,3,2,512,3,0,0,3,1,1,3,0,0,3,0,1,1,0,3,3,1,0,0,1,1,2,0,2,0,0,512]

theorem envBound21227 : H12AffineFastState.Bounded env21227 := by
  intro p hp
  have h : env21227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21226_21227 : H12AffineEnvironment.transform 2 3 env21226 = env21227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21226 == env21227) = true)

theorem identity21227 : scanCanonicalize (H12AffineFastState.compose env21227 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound21227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21228 : List Nat := [0,0,1,1,1,1,1,0,512,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0,1,1,0,0,0,0,0,512]

theorem envBound21228 : H12AffineFastState.Bounded env21228 := by
  intro p hp
  have h : env21228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21227_21228 : H12AffineEnvironment.transform 0 0 env21227 = env21228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env21227 == env21228) = true)

def env21229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,4161,272513,16,73736,8328,64,146509,5393,4097,406724,1500,272393,256,33,5457,74250]

theorem envBound21229 : H12AffineFastState.Bounded env21229 := by
  intro p hp
  have h : env21229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21212_21229 : H12AffineEnvironment.transform 20 4161 env21212 = env21229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21212 == env21229) = true)

theorem identity21229 : scanCanonicalize (H12AffineFastState.compose env21229 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound21229 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8322,131072,262144,1024,8660,4161,272513,16,138,8328,64,146509,5393,4097,406724,1500,272393,256,33,5457,648]

theorem envBound21230 : H12AffineFastState.Bounded env21230 := by
  intro p hp
  have h : env21230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21229_21230 : H12AffineEnvironment.transform 15 8322 env21229 = env21230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env21229 == env21230) = true)

theorem identity21230 : scanCanonicalize (H12AffineFastState.compose env21230 (packedSelected [2,9,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound21230 : packedSelected [2,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8322,131072,2185,1024,8660,4161,8200,16,138,8328,64,146509,5393,4097,146509,1500,8320,256,33,5457,648]

theorem envBound21231 : H12AffineFastState.Bounded env21231 := by
  intro p hp
  have h : env21231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21230_21231 : H12AffineEnvironment.transform 17 2185 env21230 = env21231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env21230 == env21231) = true)

theorem identity21231 : scanCanonicalize (H12AffineFastState.compose env21231 (packedSelected [6,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound21231 : packedSelected [6,11,14,23] rootPS < 2^1333 := by decide +kernel

def env21232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5376,372,35,131072,2185,1024,373,4161,169,16,138,41,64,138476,5393,4097,138476,1500,33,256,33,5457,648]

theorem envBound21232 : H12AffineFastState.Bounded env21232 := by
  intro p hp
  have h : env21232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21231_21232 : H12AffineEnvironment.transform 12 161 env21231 = env21232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env21231 == env21232) = true)

theorem identity21232 : scanCanonicalize (H12AffineFastState.compose env21232 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21232 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,35,131072,2048,1024,373,4161,32,16,3,41,64,138341,5393,4097,138341,1365,33,256,33,5457,513]

theorem envBound21233 : H12AffineFastState.Bounded env21233 := by
  intro p hp
  have h : env21233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21232_21233 : H12AffineEnvironment.transform 6 9 env21232 = env21233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21232 == env21233) = true)

theorem identity21233 : scanCanonicalize (H12AffineFastState.compose env21233 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound21233 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,35,5393,2048,1024,373,4161,32,16,3,41,64,2420,5393,4097,2420,1365,33,256,33,5457,513]

theorem envBound21234 : H12AffineFastState.Bounded env21234 := by
  intro p hp
  have h : env21234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21233_21234 : H12AffineEnvironment.transform 16 5393 env21233 = env21234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env21233 == env21234) = true)

theorem identity21234 : scanCanonicalize (H12AffineFastState.compose env21234 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21234 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21235 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,40,4453,372,35,4468,2048,101,373,4161,32,16,3,41,64,2420,4468,4097,2420,304,33,256,33,4404,513]

theorem envBound21235 : H12AffineFastState.Bounded env21235 := by
  intro p hp
  have h : env21235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21234_21235 : H12AffineEnvironment.transform 9 101 env21234 = env21235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21234 == env21235) = true)

theorem identity21235 : scanCanonicalize (H12AffineFastState.compose env21235 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2926) := by decide +kernel

theorem selectedBound21235 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21236 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2926,40,2571,372,35,2586,2048,101,373,2863,32,16,3,41,64,2420,2586,2927,2420,304,33,256,33,2650,513]

theorem envBound21236 : H12AffineFastState.Bounded env21236 := by
  intro p hp
  have h : env21236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21235_21236 : H12AffineEnvironment.transform 11 2926 env21235 = env21236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2926 env21235 == env21236) = true)

theorem identity21236 : scanCanonicalize (H12AffineFastState.compose env21236 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound21236 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env21237 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,539,40,894,372,35,879,373,101,373,602,32,16,3,41,64,1,879,538,1,304,33,256,33,815,513]

theorem envBound21237 : H12AffineFastState.Bounded env21237 := by
  intro p hp
  have h : env21237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21236_21237 : H12AffineEnvironment.transform 10 373 env21236 = env21237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env21236 == env21237) = true)

theorem identity21237 : scanCanonicalize (H12AffineFastState.compose env21237 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21237 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env21238 : List Nat := [2,4,8,16,32,64,9,116,512,101,1,539,40,522,0,35,539,1,101,1,602,32,16,3,41,64,1,539,538,1,68,33,116,33,603,513]

theorem envBound21238 : H12AffineFastState.Bounded env21238 := by
  intro p hp
  have h : env21238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21237_21238 : H12AffineEnvironment.transform 7 116 env21237 = env21238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21237 == env21238) = true)

theorem identity21238 : scanCanonicalize (H12AffineFastState.compose env21238 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound21238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21239 : List Nat := [2,4,0,16,32,64,1,116,512,101,1,531,32,514,0,35,531,1,101,1,594,32,16,3,33,64,1,531,530,1,68,33,116,33,595,513]

theorem envBound21239 : H12AffineFastState.Bounded env21239 := by
  intro p hp
  have h : env21239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21238_21239 : H12AffineEnvironment.transform 2 0 env21238 = env21239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env21238 == env21239) = true)

theorem identity21239 : scanCanonicalize (H12AffineFastState.compose env21239 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound21239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21240 : List Nat := [2,4,0,16,32,64,1,116,3,101,1,16,32,1,0,35,16,1,101,1,81,32,16,3,33,64,1,16,17,1,68,33,116,33,80,2]

theorem envBound21240 : H12AffineFastState.Bounded env21240 := by
  intro p hp
  have h : env21240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21239_21240 : H12AffineEnvironment.transform 8 3 env21239 = env21240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env21239 == env21240) = true)

theorem identity21240 : scanCanonicalize (H12AffineFastState.compose env21240 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound21240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21241 : List Nat := [2,4,0,16,22,64,1,66,3,83,1,16,22,1,0,21,16,1,83,1,81,22,16,3,23,64,1,16,17,1,68,23,66,23,80,2]

theorem envBound21241 : H12AffineFastState.Bounded env21241 := by
  intro p hp
  have h : env21241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21240_21241 : H12AffineEnvironment.transform 4 22 env21240 = env21241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env21240 == env21241) = true)

theorem identity21241 : scanCanonicalize (H12AffineFastState.compose env21241 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound21241 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21242 : List Nat := [2,4,0,7,1,64,1,66,3,68,1,7,1,1,0,2,7,1,68,1,70,1,7,3,0,64,1,7,6,1,68,0,66,0,71,2]

theorem envBound21242 : H12AffineFastState.Bounded env21242 := by
  intro p hp
  have h : env21242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21241_21242 : H12AffineEnvironment.transform 3 7 env21241 = env21242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env21241 == env21242) = true)

def env21243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272513,2101329,73737,8328,64,2239501,2098512,4096,2499717,2102685,2373704,256,32,5456,2175563]

theorem envBound21243 : H12AffineFastState.Bounded env21243 := by
  intro p hp
  have h : env21243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21211_21243 : H12AffineEnvironment.transform 13 5377 env21211 = env21243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21211 == env21243) = true)

def env21244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,4160,272513,17,73737,8328,64,146509,5392,4096,406725,1501,272392,256,32,5456,74251]

theorem envBound21244 : H12AffineFastState.Bounded env21244 := by
  intro p hp
  have h : env21244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21243_21244 : H12AffineEnvironment.transform 20 4160 env21243 = env21244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21243 == env21244) = true)

theorem identity21244 : scanCanonicalize (H12AffineFastState.compose env21244 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound21244 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,67755,1024,8661,4160,73770,17,73737,8328,64,146509,5392,4096,212078,1501,73891,256,32,5456,74251]

theorem envBound21245 : H12AffineFastState.Bounded env21245 := by
  intro p hp
  have h : env21245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21244_21245 : H12AffineEnvironment.transform 17 67755 env21244 = env21245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env21244 == env21245) = true)

theorem identity21245 : scanCanonicalize (H12AffineFastState.compose env21245 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound21245 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5377,396,65536,131072,67755,1024,397,4160,65650,17,65617,208,64,138261,5392,4096,203830,1501,65787,256,32,5456,66131]

theorem envBound21246 : H12AffineFastState.Bounded env21246 := by
  intro p hp
  have h : env21246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21245_21246 : H12AffineEnvironment.transform 12 88 env21245 = env21246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env21245 == env21246) = true)

theorem identity21246 : scanCanonicalize (H12AffineFastState.compose env21246 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound21246 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env21247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5377,396,65536,5392,67755,1024,397,4160,65650,17,65617,208,64,2309,5392,4096,67878,1501,65787,256,32,5456,66131]

theorem envBound21247 : H12AffineFastState.Bounded env21247 := by
  intro p hp
  have h : env21247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21246_21247 : H12AffineEnvironment.transform 16 5392 env21246 = env21247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env21246 == env21247) = true)

theorem identity21247 : scanCanonicalize (H12AffineFastState.compose env21247 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21247 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,261,65536,5392,67618,1024,260,4160,65650,17,65617,89,64,2309,5392,4096,67878,1364,65650,256,32,5456,66131]

theorem envBound21248 : H12AffineFastState.Bounded env21248 := by
  intro p hp
  have h : env21248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21247_21248 : H12AffineEnvironment.transform 6 9 env21247 = env21248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21247 == env21248) = true)

theorem identity21248 : scanCanonicalize (H12AffineFastState.compose env21248 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21248 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,261,262,5392,2340,1024,260,4160,372,17,343,89,64,2309,5392,4096,2080,1364,372,256,32,5456,853]

theorem envBound21249 : H12AffineFastState.Bounded env21249 := by
  intro p hp
  have h : env21249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21248_21249 : H12AffineEnvironment.transform 15 262 env21248 = env21249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21248 == env21249) = true)

theorem identity21249 : scanCanonicalize (H12AffineFastState.compose env21249 (packedSelected [2,4,5,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21249 : packedSelected [2,4,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21250 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,88,4452,261,262,4469,2340,101,260,4160,372,17,343,89,64,2309,4469,4096,2080,305,372,256,32,4405,853]

theorem envBound21250 : H12AffineFastState.Bounded env21250 := by
  intro p hp
  have h : env21250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21249_21250 : H12AffineEnvironment.transform 9 101 env21249 = env21250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21249 == env21250) = true)

theorem identity21250 : scanCanonicalize (H12AffineFastState.compose env21250 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound21250 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21251 : List Nat := [2,4,8,16,32,64,9,85,512,101,2048,4096,88,4145,80,83,4128,2161,101,81,4160,33,17,2,89,64,2128,4128,4096,2080,100,33,85,32,4192,512]

theorem envBound21251 : H12AffineFastState.Bounded env21251 := by
  intro p hp
  have h : env21251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21250_21251 : H12AffineEnvironment.transform 7 85 env21250 = env21251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env21250 == env21251) = true)

theorem identity21251 : scanCanonicalize (H12AffineFastState.compose env21251 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21251 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21252 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,88,4113,80,83,4096,2129,69,81,4160,1,17,2,89,64,2128,4096,4096,2048,68,1,85,0,4160,512]

theorem envBound21252 : H12AffineFastState.Bounded env21252 := by
  intro p hp
  have h : env21252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21251_21252 : H12AffineEnvironment.transform 4 0 env21251 = env21252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21251 == env21252) = true)

theorem identity21252 : scanCanonicalize (H12AffineFastState.compose env21252 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21253 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,88,0,80,83,17,2129,69,81,81,1,17,2,89,64,2128,17,17,2048,68,1,85,0,81,512]

theorem envBound21253 : H12AffineFastState.Bounded env21253 := by
  intro p hp
  have h : env21253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21252_21253 : H12AffineEnvironment.transform 11 17 env21252 = env21253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21252 == env21253) = true)

theorem identity21253 : scanCanonicalize (H12AffineFastState.compose env21253 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21254 : List Nat := [2,4,8,16,0,64,9,85,512,69,1,17,88,0,80,83,17,80,69,81,81,1,17,2,89,64,81,17,17,1,68,1,85,0,81,512]

theorem envBound21254 : H12AffineFastState.Bounded env21254 := by
  intro p hp
  have h : env21254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21253_21254 : H12AffineEnvironment.transform 10 1 env21253 = env21254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21253 == env21254) = true)

theorem identity21254 : scanCanonicalize (H12AffineFastState.compose env21254 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 94) := by decide +kernel

theorem selectedBound21254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21255 : List Nat := [2,4,8,16,0,64,9,85,94,69,1,17,88,0,80,83,17,80,69,81,81,1,17,2,89,64,81,17,17,1,68,1,85,0,81,94]

theorem envBound21255 : H12AffineFastState.Bounded env21255 := by
  intro p hp
  have h : env21255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21254_21255 : H12AffineEnvironment.transform 8 94 env21254 = env21255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 94 env21254 == env21255) = true)

def env21256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,4161,272513,16,73737,8328,64,146508,5393,4096,406724,1500,272393,256,32,5456,74250]

theorem envBound21256 : H12AffineFastState.Bounded env21256 := by
  intro p hp
  have h : env21256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21243_21256 : H12AffineEnvironment.transform 20 4161 env21243 = env21256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21243 == env21256) = true)

theorem identity21256 : scanCanonicalize (H12AffineFastState.compose env21256 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21256 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,131072,262144,1024,8661,4161,272513,16,2,8328,64,146508,5393,4096,406724,1500,272393,256,32,5456,513]

theorem envBound21257 : H12AffineFastState.Bounded env21257 := by
  intro p hp
  have h : env21257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21256_21257 : H12AffineEnvironment.transform 15 8203 env21256 = env21257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21256 == env21257) = true)

theorem identity21257 : scanCanonicalize (H12AffineFastState.compose env21257 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound21257 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env21258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,131072,146745,1024,8661,4161,136632,16,2,8328,64,146508,5393,4096,2557,1500,136496,256,32,5456,513]

theorem envBound21258 : H12AffineFastState.Bounded env21258 := by
  intro p hp
  have h : env21258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21257_21258 : H12AffineEnvironment.transform 17 146745 env21257 = env21258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env21257 == env21258) = true)

theorem identity21258 : scanCanonicalize (H12AffineFastState.compose env21258 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound21258 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,5393,10280,1024,8661,4161,169,16,2,8328,64,10589,5393,4096,2557,1500,33,256,32,5456,513]

theorem envBound21259 : H12AffineFastState.Bounded env21259 := by
  intro p hp
  have h : env21259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21258_21259 : H12AffineEnvironment.transform 16 5393 env21258 = env21259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env21258 == env21259) = true)

theorem identity21259 : scanCanonicalize (H12AffineFastState.compose env21259 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21259 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,342,5393,2421,1024,136,4161,169,16,2,469,64,2048,5393,4096,2557,1500,33,256,32,5456,513]

theorem envBound21260 : H12AffineFastState.Bounded env21260 := by
  intro p hp
  have h : env21260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21259_21260 : H12AffineEnvironment.transform 12 349 env21259 = env21260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21259 == env21260) = true)

theorem identity21260 : scanCanonicalize (H12AffineFastState.compose env21260 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21260 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5393,2421,1024,0,4161,33,16,2,349,64,2048,5393,4096,2421,1364,33,256,32,5456,513]

theorem envBound21261 : H12AffineFastState.Bounded env21261 := by
  intro p hp
  have h : env21261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21260_21261 : H12AffineEnvironment.transform 6 8 env21260 = env21261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21260 == env21261) = true)

theorem identity21261 : scanCanonicalize (H12AffineFastState.compose env21261 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21261 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21262 : List Nat := [2,4,8,16,32,64,8,256,0,1024,2048,4096,349,5377,1,342,5393,2421,1024,0,4161,33,16,2,349,64,2048,5393,4096,2421,1364,33,256,32,5456,1]

theorem envBound21262 : H12AffineFastState.Bounded env21262 := by
  intro p hp
  have h : env21262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21261_21262 : H12AffineEnvironment.transform 8 0 env21261 = env21262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21261 == env21262) = true)

theorem identity21262 : scanCanonicalize (H12AffineFastState.compose env21262 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound21262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21263 : List Nat := [2,4,8,16,32,64,8,256,0,1024,2048,1124,349,357,1,342,373,2421,1024,0,1061,33,16,2,349,64,2048,373,1124,2421,1364,33,256,32,308,1]

theorem envBound21263 : H12AffineFastState.Bounded env21263 := by
  intro p hp
  have h : env21263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21262_21263 : H12AffineEnvironment.transform 11 1124 env21262 = env21263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env21262 == env21263) = true)

theorem identity21263 : scanCanonicalize (H12AffineFastState.compose env21263 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound21263 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env21264 : List Nat := [2,4,8,16,32,64,8,101,0,1024,2048,1124,56,0,1,51,16,2064,1024,0,1061,33,16,2,56,64,2048,16,1124,2064,1073,33,101,32,81,1]

theorem envBound21264 : H12AffineFastState.Bounded env21264 := by
  intro p hp
  have h : env21264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21263_21264 : H12AffineEnvironment.transform 7 101 env21263 = env21264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env21263 == env21264) = true)

theorem identity21264 : scanCanonicalize (H12AffineFastState.compose env21264 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21264 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21265 : List Nat := [2,4,8,16,32,64,8,101,0,101,2048,1,56,0,1,51,16,2064,101,0,64,33,16,2,56,64,2048,16,1,2064,84,33,101,32,81,1]

theorem envBound21265 : H12AffineFastState.Bounded env21265 := by
  intro p hp
  have h : env21265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21264_21265 : H12AffineEnvironment.transform 9 101 env21264 = env21265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21264 == env21265) = true)

theorem identity21265 : scanCanonicalize (H12AffineFastState.compose env21265 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21265 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env21266 : List Nat := [2,4,8,16,32,64,8,101,0,101,0,1,56,0,1,51,16,16,101,0,64,33,16,2,56,64,0,16,1,16,84,33,101,32,81,1]

theorem envBound21266 : H12AffineFastState.Bounded env21266 := by
  intro p hp
  have h : env21266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21265_21266 : H12AffineEnvironment.transform 10 0 env21265 = env21266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21265 == env21266) = true)

theorem identity21266 : scanCanonicalize (H12AffineFastState.compose env21266 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21266 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21267 : List Nat := [2,4,8,16,32,17,8,52,0,52,0,1,56,0,1,51,16,16,52,0,17,33,16,2,56,17,0,16,1,16,5,33,52,32,0,1]

theorem envBound21267 : H12AffineFastState.Bounded env21267 := by
  intro p hp
  have h : env21267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21266_21267 : H12AffineEnvironment.transform 5 17 env21266 = env21267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21266 == env21267) = true)

theorem identity21267 : scanCanonicalize (H12AffineFastState.compose env21267 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21267 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env21268 : List Nat := [2,4,8,1,32,0,8,37,0,37,0,1,41,0,1,34,1,1,37,0,0,33,1,2,41,0,0,1,1,1,5,33,37,32,0,1]

theorem envBound21268 : H12AffineFastState.Bounded env21268 := by
  intro p hp
  have h : env21268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21267_21268 : H12AffineEnvironment.transform 3 1 env21267 = env21268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21267 == env21268) = true)

theorem identity21268 : scanCanonicalize (H12AffineFastState.compose env21268 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21269 : List Nat := [2,4,8,1,1,0,8,4,0,4,0,1,8,0,1,3,1,1,4,0,0,0,1,2,8,0,0,1,1,1,5,0,4,1,0,1]

theorem envBound21269 : H12AffineFastState.Bounded env21269 := by
  intro p hp
  have h : env21269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21268_21269 : H12AffineEnvironment.transform 4 1 env21268 = env21269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21268 == env21269) = true)

def env21270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6705548,8393984,10507600,8830977,2102684,12645452,256,21792,46213,2175562]

theorem envBound21270 : H12AffineFastState.Bounded env21270 := by
  intro p hp
  have h : env21270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21128_21270 : H12AffineEnvironment.transform 23 10588557 env21128 = env21270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env21128 == env21270) = true)

def env21271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98781,8328,64,6705548,2098512,17664,2543697,2102684,6349852,256,21792,46213,2175562]

theorem envBound21271 : H12AffineFastState.Bounded env21271 := by
  intro p hp
  have h : env21271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21270_21271 : H12AffineEnvironment.transform 22 2101328 env21270 = env21271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21270 == env21271) = true)

def env21272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98781,8328,64,2259212,2098512,17664,2543697,2102684,2411676,256,21792,46213,2175562]

theorem envBound21272 : H12AffineFastState.Bounded env21272 := by
  intro p hp
  have h : env21272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21271_21272 : H12AffineEnvironment.transform 21 272512 env21271 = env21272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21271 == env21272) = true)

theorem identity21272 : scanCanonicalize (H12AffineFastState.compose env21272 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound21272 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,2097152,272512,2101328,21762,8328,64,2259212,2098512,17664,2543697,2102684,2411676,256,21792,46213,2156181]

theorem envBound21273 : H12AffineFastState.Bounded env21273 := by
  intro p hp
  have h : env21273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21272_21273 : H12AffineEnvironment.transform 15 54495 env21272 = env21273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env21272 == env21273) = true)

def env21274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,2097152,272392,2101328,21762,8192,64,2259212,2098512,17664,2543697,2102548,2411540,256,21792,46093,2156061]

theorem envBound21274 : H12AffineFastState.Bounded env21274 := by
  intro p hp
  have h : env21274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21273_21274 : H12AffineEnvironment.transform 6 8 env21273 = env21274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21273 == env21274) = true)

theorem identity21274 : scanCanonicalize (H12AffineFastState.compose env21274 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 429093) := by decide +kernel

theorem selectedBound21274 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env21275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,429093,272392,433269,21762,8192,64,324905,428405,17664,23668,432433,147505,256,21792,46093,420408]

theorem envBound21275 : H12AffineFastState.Bounded env21275 := by
  intro p hp
  have h : env21275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21274_21275 : H12AffineEnvironment.transform 20 429093 env21274 = env21275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 429093 env21274 == env21275) = true)

theorem identity21275 : scanCanonicalize (H12AffineFastState.compose env21275 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound21275 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35189,1024,32769,132432,41341,136448,21762,8192,64,31836,131072,17664,23668,135236,147505,256,21792,46093,189261]

theorem envBound21276 : H12AffineFastState.Bounded env21276 := by
  intro p hp
  have h : env21276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21275_21276 : H12AffineEnvironment.transform 17 35189 env21275 = env21276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env21275 == env21276) = true)

theorem identity21276 : scanCanonicalize (H12AffineFastState.compose env21276 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21276 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,35189,1024,32769,132432,41341,136448,2,8192,64,10588,131072,4096,2420,135236,136497,256,32,46093,177741]

theorem envBound21277 : H12AffineFastState.Bounded env21277 := by
  intro p hp
  have h : env21277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21276_21277 : H12AffineEnvironment.transform 13 5376 env21276 = env21277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21276 == env21277) = true)

theorem identity21277 : scanCanonicalize (H12AffineFastState.compose env21277 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound21277 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env21278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,372,35,131072,2049,1024,373,132432,8201,136448,2,8192,64,10588,131072,4096,2420,135236,136497,256,32,13689,145209]

theorem envBound21278 : H12AffineFastState.Bounded env21278 := by
  intro p hp
  have h : env21278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21277_21278 : H12AffineEnvironment.transform 14 372 env21277 = env21278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env21277 == env21278) = true)

theorem identity21278 : scanCanonicalize (H12AffineFastState.compose env21278 (packedSelected [0,2,4,6,9,11,16,17,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound21278 : packedSelected [0,2,4,6,9,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env21279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,372,35,5392,2049,1024,373,4160,8201,16,2,8192,64,10588,5392,4096,2420,1364,33,256,32,13689,8745]

theorem envBound21279 : H12AffineFastState.Bounded env21279 := by
  intro p hp
  have h : env21279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21278_21279 : H12AffineEnvironment.transform 16 5392 env21278 = env21279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env21278 == env21279) = true)

theorem identity21279 : scanCanonicalize (H12AffineFastState.compose env21279 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound21279 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,5376,372,35,5392,2049,1024,373,4160,80,16,2,89,64,2309,5392,4096,2420,1364,33,256,32,5408,624]

theorem envBound21280 : H12AffineFastState.Bounded env21280 := by
  intro p hp
  have h : env21280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21279_21280 : H12AffineEnvironment.transform 12 89 env21279 = env21280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env21279 == env21280) = true)

theorem identity21280 : scanCanonicalize (H12AffineFastState.compose env21280 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21281 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,41,5376,260,35,5392,2049,1024,261,4144,32,16,2,41,48,2309,5392,4096,2308,1316,33,256,32,5408,512]

theorem envBound21281 : H12AffineFastState.Bounded env21281 := by
  intro p hp
  have h : env21281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21280_21281 : H12AffineEnvironment.transform 5 48 env21280 = env21281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21280 == env21281) = true)

theorem identity21281 : scanCanonicalize (H12AffineFastState.compose env21281 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21281 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21282 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,41,5156,32,35,5172,2049,1024,33,4144,32,16,2,41,48,2081,5172,4096,2080,1024,33,36,32,5124,512]

theorem envBound21282 : H12AffineFastState.Bounded env21282 := by
  intro p hp
  have h : env21282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21281_21282 : H12AffineEnvironment.transform 7 36 env21281 = env21282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21281 == env21282) = true)

theorem identity21282 : scanCanonicalize (H12AffineFastState.compose env21282 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21282 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21283 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,0,3,5140,2049,1024,1,4112,0,16,2,9,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound21283 : H12AffineFastState.Bounded env21283 := by
  intro p hp
  have h : env21283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21282_21283 : H12AffineEnvironment.transform 4 0 env21282 = env21283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21282 == env21283) = true)

def env21284 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1044,0,3,1028,2049,1024,1,0,0,16,2,9,16,2049,1028,16,2048,1024,1,4,0,1044,512]

theorem envBound21284 : H12AffineFastState.Bounded env21284 := by
  intro p hp
  have h : env21284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21283_21284 : H12AffineEnvironment.transform 11 16 env21283 = env21284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21283 == env21284) = true)

theorem identity21284 : scanCanonicalize (H12AffineFastState.compose env21284 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound21284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21285 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,16,9,1044,0,3,1028,1044,1024,1,0,0,16,2,9,16,1044,1028,16,1045,1024,1,4,0,1044,512]

theorem envBound21285 : H12AffineFastState.Bounded env21285 := by
  intro p hp
  have h : env21285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21284_21285 : H12AffineEnvironment.transform 10 1045 env21284 = env21285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env21284 == env21285) = true)

def env21286 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,9,0,0,3,16,0,20,1,0,0,16,2,9,16,0,16,16,1,20,1,4,0,0,512]

theorem envBound21286 : H12AffineFastState.Bounded env21286 := by
  intro p hp
  have h : env21286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21285_21286 : H12AffineEnvironment.transform 9 20 env21285 = env21286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21285 == env21286) = true)

theorem identity21286 : scanCanonicalize (H12AffineFastState.compose env21286 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound21286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21287 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,9,0,0,3,4,0,0,1,0,0,4,2,9,4,0,4,4,1,0,1,4,0,0,512]

theorem envBound21287 : H12AffineFastState.Bounded env21287 := by
  intro p hp
  have h : env21287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21286_21287 : H12AffineEnvironment.transform 3 4 env21286 = env21287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env21286 == env21287) = true)

def leafEnv21287 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,9,0,0,3,4,0,0,1,0,0,4,2,0,9,1,4,0,4,4,1,0,1,4,0,4,3,0,512,1,0,0]

def active21287 : List Nat := [0,1,2,8]

def tree21287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21287 : H12WitnessSearch.Good tree21287 := H12GlobalWitnessIndex.good

theorem leafIdentity21287 : H12AffineFastState.composeSystem env21287 rootObs = leafEnv21287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21287 rootObs == leafEnv21287) = true)

theorem terminalChecked21287 : H12PackedTerminal.terminalCheckFast leafEnv21287 active21287 tree21287 = true := by decide +kernel

def env21288 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,1,0,3,17,1,21,1,0,0,16,2,9,16,1,17,16,0,21,1,4,0,1,512]

theorem envBound21288 : H12AffineFastState.Bounded env21288 := by
  intro p hp
  have h : env21288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21285_21288 : H12AffineEnvironment.transform 9 21 env21285 = env21288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21285 == env21288) = true)

theorem identity21288 : scanCanonicalize (H12AffineFastState.compose env21288 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound21288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21289 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,16,9,1,0,3,17,1,21,1,0,0,16,2,9,16,1,17,16,0,21,1,4,0,1,31]

theorem envBound21289 : H12AffineFastState.Bounded env21289 := by
  intro p hp
  have h : env21289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21288_21289 : H12AffineEnvironment.transform 8 31 env21288 = env21289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env21288 == env21289) = true)

def leafEnv21289 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,16,9,1,0,3,17,1,21,1,0,0,16,2,21,9,1,16,1,17,16,0,21,1,4,0,4,3,1,31,1,0,0]

def active21289 : List Nat := [0,1,2,3]

def tree21289 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21289 : H12WitnessSearch.Good tree21289 := H12GlobalWitnessIndex.good

theorem leafIdentity21289 : H12AffineFastState.composeSystem env21289 rootObs = leafEnv21289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21289 rootObs == leafEnv21289) = true)

theorem terminalChecked21289 : H12PackedTerminal.terminalCheckFast leafEnv21289 active21289 tree21289 = true := by decide +kernel

def env21290 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1045,0,3,1029,2049,1024,1,1,0,16,2,9,16,2049,1029,17,2048,1024,1,4,0,1045,512]

theorem envBound21290 : H12AffineFastState.Bounded env21290 := by
  intro p hp
  have h : env21290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21283_21290 : H12AffineEnvironment.transform 11 17 env21283 = env21290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21283 == env21290) = true)

theorem identity21290 : scanCanonicalize (H12AffineFastState.compose env21290 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21291 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,9,1045,0,3,1029,1,1024,1,1,0,16,2,9,16,1,1029,17,0,1024,1,4,0,1045,512]

theorem envBound21291 : H12AffineFastState.Bounded env21291 := by
  intro p hp
  have h : env21291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21290_21291 : H12AffineEnvironment.transform 10 0 env21290 = env21291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21290 == env21291) = true)

def env21292 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,1,0,3,17,1,20,1,1,0,16,2,9,16,1,17,17,0,20,1,4,0,1,512]

theorem envBound21292 : H12AffineFastState.Bounded env21292 := by
  intro p hp
  have h : env21292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21291_21292 : H12AffineEnvironment.transform 9 20 env21291 = env21292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21291 == env21292) = true)

theorem identity21292 : scanCanonicalize (H12AffineFastState.compose env21292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound21292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21293 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,0,3,5,1,0,1,1,0,4,2,9,4,1,5,5,0,0,1,4,0,1,512]

theorem envBound21293 : H12AffineFastState.Bounded env21293 := by
  intro p hp
  have h : env21293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21292_21293 : H12AffineEnvironment.transform 3 4 env21292 = env21293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env21292 == env21293) = true)

def leafEnv21293 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,0,3,5,1,0,1,1,0,4,2,0,9,1,4,1,5,5,0,0,1,4,0,4,3,1,512,1,1,0]

def active21293 : List Nat := [0,1,2,8]

def tree21293 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21293 : H12WitnessSearch.Good tree21293 := H12GlobalWitnessIndex.good

theorem leafIdentity21293 : H12AffineFastState.composeSystem env21293 rootObs = leafEnv21293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21293 rootObs == leafEnv21293) = true)

theorem terminalChecked21293 : H12PackedTerminal.terminalCheckFast leafEnv21293 active21293 tree21293 = true := by decide +kernel

def env21294 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,0,0,3,16,1,21,1,1,0,16,2,9,16,1,16,17,0,21,1,4,0,0,512]

theorem envBound21294 : H12AffineFastState.Bounded env21294 := by
  intro p hp
  have h : env21294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21291_21294 : H12AffineEnvironment.transform 9 21 env21291 = env21294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21291 == env21294) = true)

theorem identity21294 : scanCanonicalize (H12AffineFastState.compose env21294 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound21294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21295 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,9,0,0,3,16,1,21,1,1,0,16,2,9,16,1,16,17,0,21,1,4,0,0,31]

theorem envBound21295 : H12AffineFastState.Bounded env21295 := by
  intro p hp
  have h : env21295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21294_21295 : H12AffineEnvironment.transform 8 31 env21294 = env21295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env21294 == env21295) = true)

def leafEnv21295 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,9,0,0,3,16,1,21,1,1,0,16,2,21,9,1,16,1,16,17,0,21,1,4,0,4,3,0,31,1,1,0]

def active21295 : List Nat := [0,1,2,3]

def tree21295 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21295 : H12WitnessSearch.Good tree21295 := H12GlobalWitnessIndex.good

theorem leafIdentity21295 : H12AffineFastState.composeSystem env21295 rootObs = leafEnv21295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21295 rootObs == leafEnv21295) = true)

theorem terminalChecked21295 : H12PackedTerminal.terminalCheckFast leafEnv21295 active21295 tree21295 = true := by decide +kernel

def env21296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,2097152,272393,2101328,21762,8193,64,2259212,2098512,17664,2543697,2102549,2411541,256,21792,46092,2156060]

theorem envBound21296 : H12AffineFastState.Bounded env21296 := by
  intro p hp
  have h : env21296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21273_21296 : H12AffineEnvironment.transform 6 9 env21273 = env21296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21273 == env21296) = true)

theorem identity21296 : scanCanonicalize (H12AffineFastState.compose env21296 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21296 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env21297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,2097152,33,2101328,21762,8193,64,2259212,2098512,17664,2291833,2102549,2155581,256,21792,46092,2156060]

theorem envBound21297 : H12AffineFastState.Bounded env21297 := by
  intro p hp
  have h : env21297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21296_21297 : H12AffineEnvironment.transform 17 10280 env21296 = env21297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21296 == env21297) = true)

theorem identity21297 : scanCanonicalize (H12AffineFastState.compose env21297 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound21297 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,58397,33,62541,21762,8193,64,171281,57677,17664,138340,61704,32,256,21792,46092,513]

theorem envBound21298 : H12AffineFastState.Bounded env21298 := by
  intro p hp
  have h : env21298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21297_21298 : H12AffineEnvironment.transform 20 58397 env21297 = env21298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env21297 == env21298) = true)

theorem identity21298 : scanCanonicalize (H12AffineFastState.compose env21298 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound21298 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env21299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49217,10280,1024,32769,58397,33,62541,21762,8193,64,23888,57677,17664,56357,61704,32,256,21792,46092,513]

theorem envBound21299 : H12AffineFastState.Bounded env21299 := by
  intro p hp
  have h : env21299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21298_21299 : H12AffineEnvironment.transform 16 49217 env21298 = env21299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env21298 == env21299) = true)

theorem identity21299 : scanCanonicalize (H12AffineFastState.compose env21299 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21299 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env21300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,16449,10280,1024,1,25629,33,29773,21762,8193,64,23888,24909,17664,23589,28936,32,256,21792,13324,513]

theorem envBound21300 : H12AffineFastState.Bounded env21300 := by
  intro p hp
  have h : env21300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21299_21300 : H12AffineEnvironment.transform 14 0 env21299 = env21300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21299 == env21300) = true)

theorem identity21300 : scanCanonicalize (H12AffineFastState.compose env21300 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound21300 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,13341,10280,1024,1,4161,33,17,8542,8193,64,10508,5393,12636,10361,1364,32,256,8572,13324,513]

theorem envBound21301 : H12AffineFastState.Bounded env21301 := by
  intro p hp
  have h : env21301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21300_21301 : H12AffineEnvironment.transform 13 13404 env21300 = env21301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env21300 == env21301) = true)

theorem identity21301 : scanCanonicalize (H12AffineFastState.compose env21301 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21301 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21302 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1024,1,4112,33,17,8463,8193,17,10508,5393,12557,10280,1285,32,256,8493,13324,513]

theorem envBound21302 : H12AffineFastState.Bounded env21302 := by
  intro p hp
  have h : env21302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21301_21302 : H12AffineEnvironment.transform 5 17 env21301 = env21302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21301 == env21302) = true)

theorem identity21302 : scanCanonicalize (H12AffineFastState.compose env21302 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound21302 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21303 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5124,0,3,5140,2081,1024,1,4112,33,17,262,8,17,2309,5393,4356,2081,1285,32,256,292,5125,513]

theorem envBound21303 : H12AffineFastState.Bounded env21303 := by
  intro p hp
  have h : env21303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21302_21303 : H12AffineEnvironment.transform 12 9 env21302 = env21303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env21302 == env21303) = true)

theorem identity21303 : scanCanonicalize (H12AffineFastState.compose env21303 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound21303 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env21304 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1819,4096,9,5124,0,3,5140,1850,1024,1,4112,33,17,262,8,17,1566,5393,4356,1850,1285,32,256,292,5125,513]

theorem envBound21304 : H12AffineFastState.Bounded env21304 := by
  intro p hp
  have h : env21304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21303_21304 : H12AffineEnvironment.transform 10 1819 env21303 = env21304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env21303 == env21304) = true)

theorem identity21304 : scanCanonicalize (H12AffineFastState.compose env21304 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21304 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21305 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1598,4096,9,5124,0,3,5140,1567,1024,1,4112,33,17,35,8,17,1566,5172,4129,1567,1056,32,37,1,5125,513]

theorem envBound21305 : H12AffineFastState.Bounded env21305 := by
  intro p hp
  have h : env21305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21304_21305 : H12AffineEnvironment.transform 7 37 env21304 = env21305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21304 == env21305) = true)

def env21306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98781,8328,64,2259213,2098512,17664,2543697,2102684,2411677,256,21792,46213,2175562]

theorem envBound21306 : H12AffineFastState.Bounded env21306 := by
  intro p hp
  have h : env21306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21271_21306 : H12AffineEnvironment.transform 21 272513 env21271 = env21306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21271 == env21306) = true)

theorem identity21306 : scanCanonicalize (H12AffineFastState.compose env21306 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound21306 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,120015,98781,8328,64,245138,115151,17664,464078,119043,329730,256,21792,46213,63189]

theorem envBound21307 : H12AffineFastState.Bounded env21307 := by
  intro p hp
  have h : env21307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21306_21307 : H12AffineEnvironment.transform 20 115871 env21306 = env21307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env21306 == env21307) = true)

def env21308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,119879,98645,8192,64,245018,115015,17664,463942,119043,329730,256,21792,46093,63069]

theorem envBound21308 : H12AffineFastState.Bounded env21308 := by
  intro p hp
  have h : env21308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21307_21308 : H12AffineEnvironment.transform 6 8 env21307 = env21308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21307 == env21308) = true)

theorem identity21308 : scanCanonicalize (H12AffineFastState.compose env21308 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound21308 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,115735,147505,119879,98645,8192,64,245018,115015,17664,97406,119043,221242,256,21792,46093,63069]

theorem envBound21309 : H12AffineFastState.Bounded env21309 := by
  intro p hp
  have h : env21309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21308_21309 : H12AffineEnvironment.transform 17 157752 env21308 = env21309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env21308 == env21309) = true)

theorem identity21309 : scanCanonicalize (H12AffineFastState.compose env21309 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21309 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,146744,1024,32769,102679,136497,98631,98645,8192,64,245018,103495,4096,76158,99331,210234,256,32,46093,41821]

theorem envBound21310 : H12AffineFastState.Bounded env21310 := by
  intro p hp
  have h : env21310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21309_21310 : H12AffineEnvironment.transform 13 5376 env21309 = env21310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21309 == env21310) = true)

theorem identity21310 : scanCanonicalize (H12AffineFastState.compose env21310 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound21310 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,67619,1024,32769,102679,73770,98631,98645,8192,64,34817,103495,4096,76158,99331,33,256,32,46093,41821]

theorem envBound21311 : H12AffineFastState.Bounded env21311 := by
  intro p hp
  have h : env21311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21310_21311 : H12AffineEnvironment.transform 16 79131 env21310 = env21311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env21310 == env21311) = true)

theorem identity21311 : scanCanonicalize (H12AffineFastState.compose env21311 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21311 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79131,67619,1024,8541,77899,73770,73755,73737,8192,64,10589,79131,4096,76158,75103,33,256,32,5457,513]

theorem envBound21312 : H12AffineFastState.Bounded env21312 := by
  intro p hp
  have h : env21312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21311_21312 : H12AffineEnvironment.transform 14 8540 env21311 = env21312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21311 == env21312) = true)

theorem identity21312 : scanCanonicalize (H12AffineFastState.compose env21312 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound21312 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,1094,12637,3173,1024,8541,13325,9324,9309,9295,8192,64,10589,12637,4096,11576,8473,33,256,32,5457,513]

theorem envBound21313 : H12AffineFastState.Bounded env21313 := by
  intro p hp
  have h : env21313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21312_21313 : H12AffineEnvironment.transform 15 1094 env21312 = env21313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env21312 == env21313) = true)

theorem identity21313 : scanCanonicalize (H12AffineFastState.compose env21313 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound21313 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1297,1094,5392,3173,1024,1296,4160,33,16,2,1101,64,3344,5392,4096,2421,1364,33,256,32,5457,513]

theorem envBound21314 : H12AffineFastState.Bounded env21314 := by
  intro p hp
  have h : env21314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21313_21314 : H12AffineEnvironment.transform 12 1101 env21313 = env21314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env21313 == env21314) = true)

theorem identity21314 : scanCanonicalize (H12AffineFastState.compose env21314 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 628) := by decide +kernel

theorem selectedBound21314 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21315 : List Nat := [2,4,8,16,32,64,8,256,512,628,2048,4096,569,4980,869,562,4964,2577,628,868,4160,33,16,2,569,64,2916,4964,4096,2421,800,33,256,32,4901,513]

theorem envBound21315 : H12AffineFastState.Bounded env21315 := by
  intro p hp
  have h : env21315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21314_21315 : H12AffineEnvironment.transform 9 628 env21314 = env21315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 628 env21314 == env21315) = true)

theorem identity21315 : scanCanonicalize (H12AffineFastState.compose env21315 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound21315 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21316 : List Nat := [2,4,8,16,32,64,8,256,356,272,2048,4096,349,4112,1,342,4096,2421,272,0,4160,33,16,2,349,64,2048,4096,4096,2421,68,33,256,32,4161,357]

theorem envBound21316 : H12AffineFastState.Bounded env21316 := by
  intro p hp
  have h : env21316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21315_21316 : H12AffineEnvironment.transform 8 356 env21315 = env21316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env21315 == env21316) = true)

theorem identity21316 : scanCanonicalize (H12AffineFastState.compose env21316 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound21316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21317 : List Nat := [2,4,8,16,32,64,8,101,1,117,2048,4096,56,4112,1,51,4096,2064,117,0,4160,33,16,2,56,64,2048,4096,4096,2064,68,33,101,32,4161,0]

theorem envBound21317 : H12AffineFastState.Bounded env21317 := by
  intro p hp
  have h : env21317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21316_21317 : H12AffineEnvironment.transform 7 101 env21316 = env21317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env21316 == env21317) = true)

theorem identity21317 : scanCanonicalize (H12AffineFastState.compose env21317 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21317 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21318 : List Nat := [2,4,8,1,32,64,8,101,1,100,2048,4096,41,4097,1,34,4096,2049,100,0,4160,33,1,2,41,64,2048,4096,4096,2049,68,33,101,32,4161,0]

theorem envBound21318 : H12AffineFastState.Bounded env21318 := by
  intro p hp
  have h : env21318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21317_21318 : H12AffineEnvironment.transform 3 1 env21317 = env21318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21317 == env21318) = true)

theorem identity21318 : scanCanonicalize (H12AffineFastState.compose env21318 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound21318 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21319 : List Nat := [2,4,8,1,32,33,8,4,1,5,2048,4096,41,4097,1,34,4096,2049,5,0,4129,33,1,2,41,33,2048,4096,4096,2049,37,33,4,32,4128,0]

theorem envBound21319 : H12AffineFastState.Bounded env21319 := by
  intro p hp
  have h : env21319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21318_21319 : H12AffineEnvironment.transform 5 33 env21318 = env21319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env21318 == env21319) = true)

theorem identity21319 : scanCanonicalize (H12AffineFastState.compose env21319 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound21319 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21320 : List Nat := [2,4,8,1,32,33,8,4,1,5,2048,1,41,0,1,34,1,2049,5,0,32,33,1,2,41,33,2048,1,1,2049,37,33,4,32,33,0]

theorem envBound21320 : H12AffineFastState.Bounded env21320 := by
  intro p hp
  have h : env21320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21319_21320 : H12AffineEnvironment.transform 11 1 env21319 = env21320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env21319 == env21320) = true)

theorem identity21320 : scanCanonicalize (H12AffineFastState.compose env21320 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21320 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21321 : List Nat := [2,4,8,1,1,0,8,4,1,5,2048,1,8,0,1,3,1,2049,5,0,1,0,1,2,8,0,2048,1,1,2049,4,0,4,1,0,0]

theorem envBound21321 : H12AffineFastState.Bounded env21321 := by
  intro p hp
  have h : env21321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21320_21321 : H12AffineEnvironment.transform 4 1 env21320 = env21321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21320 == env21321) = true)

theorem identity21321 : scanCanonicalize (H12AffineFastState.compose env21321 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21322 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,1,8,0,1,3,1,0,5,0,1,0,1,2,8,0,1,1,1,0,4,0,4,1,0,0]

theorem envBound21322 : H12AffineFastState.Bounded env21322 := by
  intro p hp
  have h : env21322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21321_21322 : H12AffineEnvironment.transform 10 1 env21321 = env21322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21321 == env21322) = true)

def env21323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,119878,98644,8193,64,245019,115014,17664,463943,119043,329730,256,21792,46092,63068]

theorem envBound21323 : H12AffineFastState.Bounded env21323 := by
  intro p hp
  have h : env21323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21307_21323 : H12AffineEnvironment.transform 6 9 env21307 = env21323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21307 == env21323) = true)

theorem identity21323 : scanCanonicalize (H12AffineFastState.compose env21323 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound21323 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1024,32769,115734,62589,119878,98644,8193,64,245019,115014,17664,247858,119043,119927,256,21792,46092,63068]

theorem envBound21324 : H12AffineFastState.Bounded env21324 := by
  intro p hp
  have h : env21324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21323_21324 : H12AffineEnvironment.transform 17 56437 env21323 = env21324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env21323 == env21324) = true)

def env21325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,77898,33,73754,95496,8193,64,215367,79130,17664,212078,75103,73771,256,21792,16464,512]

theorem envBound21325 : H12AffineFastState.Bounded env21325 := by
  intro p hp
  have h : env21325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21324_21325 : H12AffineEnvironment.transform 14 29788 env21324 = env21325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21324 == env21325) = true)

theorem identity21325 : scanCanonicalize (H12AffineFastState.compose env21325 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 90399) := by decide +kernel

theorem selectedBound21325 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env21326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90399,10281,1024,29789,77898,33,73754,95496,8193,64,10328,79130,17664,23921,75103,73771,256,21792,16464,512]

theorem envBound21326 : H12AffineFastState.Bounded env21326 := by
  intro p hp
  have h : env21326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21325_21326 : H12AffineEnvironment.transform 16 90399 env21325 = env21326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90399 env21325 == env21326) = true)

theorem identity21326 : scanCanonicalize (H12AffineFastState.compose env21326 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16660,10281,1024,29789,4161,33,17,21763,8193,64,10328,5393,17664,23921,1364,32,256,21792,16464,512]

theorem envBound21327 : H12AffineFastState.Bounded env21327 := by
  intro p hp
  have h : env21327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21326_21327 : H12AffineEnvironment.transform 15 8203 env21326 = env21327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21326 == env21327) = true)

theorem identity21327 : scanCanonicalize (H12AffineFastState.compose env21327 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound21327 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2129,15373,8203,2373,10281,1024,15372,4161,33,17,7506,8193,64,10328,5393,3409,5408,1364,32,256,7537,2049,512]

theorem envBound21328 : H12AffineFastState.Bounded env21328 := by
  intro p hp
  have h : env21328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21327_21328 : H12AffineEnvironment.transform 13 2129 env21327 = env21328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env21327 == env21328) = true)

theorem identity21328 : scanCanonicalize (H12AffineFastState.compose env21328 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound21328 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,2129,6501,1379,2373,3393,1024,6500,4161,33,17,7506,1385,64,3376,5393,3409,5408,1364,32,256,7537,2049,512]

theorem envBound21329 : H12AffineFastState.Bounded env21329 := by
  intro p hp
  have h : env21329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21328_21329 : H12AffineEnvironment.transform 12 1384 env21328 = env21329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env21328 == env21329) = true)

theorem identity21329 : scanCanonicalize (H12AffineFastState.compose env21329 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21329 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env21330 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1052,2129,6161,1047,2097,3125,1024,6160,4161,33,17,7206,1053,64,3140,5221,3109,5204,1056,32,116,7173,2049,512]

theorem envBound21330 : H12AffineFastState.Bounded env21330 := by
  intro p hp
  have h : env21330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21329_21330 : H12AffineEnvironment.transform 7 116 env21329 = env21330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21329 == env21330) = true)

theorem identity21330 : scanCanonicalize (H12AffineFastState.compose env21330 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound21330 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env21331 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,1052,2129,1,1047,2097,3125,1024,0,2129,33,17,1078,1053,64,3140,3189,3109,3140,1056,32,116,1045,2049,512]

theorem envBound21331 : H12AffineFastState.Bounded env21331 := by
  intro p hp
  have h : env21331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21330_21331 : H12AffineEnvironment.transform 11 2064 env21330 = env21331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env21330 == env21331) = true)

theorem identity21331 : scanCanonicalize (H12AffineFastState.compose env21331 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21332 : List Nat := [2,4,8,16,32,48,9,4,512,1024,2048,2064,1052,2081,1,1047,2097,3125,1024,0,2081,33,17,1078,1053,48,3124,3077,3109,3124,1056,32,4,1045,2049,512]

theorem envBound21332 : H12AffineFastState.Bounded env21332 := by
  intro p hp
  have h : env21332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21331_21332 : H12AffineEnvironment.transform 5 48 env21331 = env21332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21331 == env21332) = true)

theorem identity21332 : scanCanonicalize (H12AffineFastState.compose env21332 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21332 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21333 : List Nat := [2,4,3,16,32,48,2,4,512,1024,2048,2064,1047,2081,1,1047,2097,3125,1024,0,2081,33,17,1078,1046,48,3124,3077,3109,3124,1056,32,4,1045,2049,512]

theorem envBound21333 : H12AffineFastState.Bounded env21333 := by
  intro p hp
  have h : env21333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21332_21333 : H12AffineEnvironment.transform 2 3 env21332 = env21333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21332 == env21333) = true)

theorem identity21333 : scanCanonicalize (H12AffineFastState.compose env21333 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21333 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env21334 : List Nat := [2,4,3,0,32,32,2,4,512,1024,2048,2048,1031,2081,1,1031,2081,3109,1024,0,2081,33,1,1062,1030,32,3108,3077,3109,3108,1056,32,4,1029,2049,512]

theorem envBound21334 : H12AffineFastState.Bounded env21334 := by
  intro p hp
  have h : env21334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21333_21334 : H12AffineEnvironment.transform 3 0 env21333 = env21334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21333 == env21334) = true)

theorem identity21334 : scanCanonicalize (H12AffineFastState.compose env21334 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound21334 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21335 : List Nat := [2,4,3,0,4,4,2,4,512,1024,2048,2048,1031,2053,1,1031,2053,3073,1024,0,2053,5,1,1026,1030,4,3072,3077,3073,3072,1028,4,4,1029,2049,512]

theorem envBound21335 : H12AffineFastState.Bounded env21335 := by
  intro p hp
  have h : env21335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21334_21335 : H12AffineEnvironment.transform 4 4 env21334 = env21335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env21334 == env21335) = true)

theorem identity21335 : scanCanonicalize (H12AffineFastState.compose env21335 (packedSelected [0,1,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound21335 : packedSelected [0,1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env21336 : List Nat := [2,4,3,0,4,4,2,4,512,0,2048,2048,7,2053,1,7,2053,2049,0,0,2053,5,1,2,6,4,2048,2053,2049,2048,4,4,4,5,2049,512]

theorem envBound21336 : H12AffineFastState.Bounded env21336 := by
  intro p hp
  have h : env21336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21335_21336 : H12AffineEnvironment.transform 9 0 env21335 = env21336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env21335 == env21336) = true)

def env21337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,77899,32,73755,95497,8193,64,215366,79131,17664,212079,75102,73770,256,21792,16465,513]

theorem envBound21337 : H12AffineFastState.Bounded env21337 := by
  intro p hp
  have h : env21337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21324_21337 : H12AffineEnvironment.transform 14 29789 env21324 = env21337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env21324 == env21337) = true)

theorem identity21337 : scanCanonicalize (H12AffineFastState.compose env21337 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21337 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env21338 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,65536,131072,10280,1024,29709,77850,32,73755,95497,8193,17,215319,79131,17664,212030,75023,73770,256,21792,16384,513]

theorem envBound21338 : H12AffineFastState.Bounded env21338 := by
  intro p hp
  have h : env21338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21337_21338 : H12AffineEnvironment.transform 5 17 env21337 = env21338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21337 == env21338) = true)

theorem identity21338 : scanCanonicalize (H12AffineFastState.compose env21338 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound21338 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env21339 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,65536,5393,10280,1024,29709,77850,32,73755,95497,8193,17,89094,79131,17664,76079,75023,73770,256,21792,16384,513]

theorem envBound21339 : H12AffineFastState.Bounded env21339 := by
  intro p hp
  have h : env21339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21338_21339 : H12AffineEnvironment.transform 16 5393 env21338 = env21339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env21338 == env21339) = true)

theorem identity21339 : scanCanonicalize (H12AffineFastState.compose env21339 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21339 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env21340 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,65536,5393,2341,1024,21760,69911,32,65814,87044,268,17,89094,70678,17664,67618,66562,65831,256,21792,16384,513]

theorem envBound21340 : H12AffineFastState.Bounded env21340 := by
  intro p hp
  have h : env21340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21339_21340 : H12AffineEnvironment.transform 12 269 env21339 = env21340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21339 == env21340) = true)

def env21341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98780,8328,64,6705548,2098513,17665,2543696,2102684,6349853,256,21792,46213,2175562]

theorem envBound21341 : H12AffineFastState.Bounded env21341 := by
  intro p hp
  have h : env21341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21270_21341 : H12AffineEnvironment.transform 22 2101329 env21270 = env21341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21270 == env21341) = true)

def env21342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98780,8328,64,2259212,2098513,17665,2543696,2102684,2411677,256,21792,46213,2175562]

theorem envBound21342 : H12AffineFastState.Bounded env21342 := by
  intro p hp
  have h : env21342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21341_21342 : H12AffineEnvironment.transform 21 272512 env21341 = env21342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21341 == env21342) = true)

theorem identity21342 : scanCanonicalize (H12AffineFastState.compose env21342 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21342 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272512,2101329,41430,8328,64,2259212,2098513,17665,2543696,2102684,2411677,256,21792,46213,2101824]

theorem envBound21343 : H12AffineFastState.Bounded env21343 := by
  intro p hp
  have h : env21343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21342_21343 : H12AffineEnvironment.transform 15 8202 env21342 = env21343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21342 == env21343) = true)

def env21344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272392,2101329,41310,8192,64,2259212,2098513,17665,2543696,2102548,2411541,256,21792,46093,2101824]

theorem envBound21344 : H12AffineFastState.Bounded env21344 := by
  intro p hp
  have h : env21344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21343_21344 : H12AffineEnvironment.transform 6 8 env21343 = env21344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21343 == env21344) = true)

theorem identity21344 : scanCanonicalize (H12AffineFastState.compose env21344 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound21344 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,2097152,272392,2101329,41310,8192,64,2124877,2098513,17665,2409745,2102548,2411541,256,21792,46093,2101824]

theorem envBound21345 : H12AffineFastState.Bounded env21345 := by
  intro p hp
  have h : env21345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21344_21345 : H12AffineEnvironment.transform 16 5441 env21344 = env21345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env21344 == env21345) = true)

theorem identity21345 : scanCanonicalize (H12AffineFastState.compose env21345 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound21345 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env21346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,5441,262144,1024,29709,2097152,272392,2101329,21842,8192,64,2124877,2098513,17665,2371869,2102548,2373657,256,21792,16385,2101824]

theorem envBound21346 : H12AffineFastState.Bounded env21346 := by
  intro p hp
  have h : env21346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21345_21346 : H12AffineEnvironment.transform 14 29708 env21345 = env21346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env21345 == env21346) = true)

theorem identity21346 : scanCanonicalize (H12AffineFastState.compose env21346 (packedSelected [1,5,8,11,17,18,19,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21346 : packedSelected [1,5,8,11,17,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env21347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,8202,5441,262144,1024,8541,2097152,272392,2101329,2,8192,64,2111773,2098513,4177,2371869,2102548,2373657,256,112,5457,2101824]

theorem envBound21347 : H12AffineFastState.Bounded env21347 := by
  intro p hp
  have h : env21347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21346_21347 : H12AffineEnvironment.transform 13 5456 env21346 = env21347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21346 == env21347) = true)

theorem identity21347 : scanCanonicalize (H12AffineFastState.compose env21347 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 268353) := by decide +kernel

theorem selectedBound21347 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env21348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,8202,5441,262144,1024,8541,268353,272392,264208,2,8192,64,270684,269584,4177,10588,265557,8280,256,112,5457,264705]

theorem envBound21348 : H12AffineFastState.Bounded env21348 := by
  intro p hp
  have h : env21348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21347_21348 : H12AffineEnvironment.transform 20 268353 env21347 = env21348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268353 env21347 == env21348) = true)

theorem identity21348 : scanCanonicalize (H12AffineFastState.compose env21348 (packedSelected [2,3,4,5,9,10,12,14,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound21348 : packedSelected [2,3,4,5,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env21349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,8202,5441,2129,1024,8541,4112,8281,65,2,8192,64,10509,5441,4177,10588,1284,8280,256,112,5457,592]

theorem envBound21349 : H12AffineFastState.Bounded env21349 := by
  intro p hp
  have h : env21349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21348_21349 : H12AffineEnvironment.transform 17 2129 env21348 = env21349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env21348 == env21349) = true)

theorem identity21349 : scanCanonicalize (H12AffineFastState.compose env21349 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21349 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5456,372,34,5441,2129,1024,373,4112,113,65,2,40,64,2341,5441,4177,2420,1284,112,256,112,5457,592]

theorem envBound21350 : H12AffineFastState.Bounded env21350 := by
  intro p hp
  have h : env21350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21349_21350 : H12AffineEnvironment.transform 12 40 env21349 = env21350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21349 == env21350) = true)

theorem identity21350 : scanCanonicalize (H12AffineFastState.compose env21350 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21350 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env21351 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,40,4452,372,34,4469,2129,52,373,4112,113,65,2,40,64,2341,4469,4177,2420,304,112,256,112,4453,592]

theorem envBound21351 : H12AffineFastState.Bounded env21351 := by
  intro p hp
  have h : env21351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21350_21351 : H12AffineEnvironment.transform 9 52 env21350 = env21351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21350 == env21351) = true)

def env21352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272393,2101329,41311,8193,64,2259212,2098513,17665,2543696,2102549,2411540,256,21792,46092,2101824]

theorem envBound21352 : H12AffineFastState.Bounded env21352 := by
  intro p hp
  have h : env21352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21343_21352 : H12AffineEnvironment.transform 6 9 env21343 = env21352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21343 == env21352) = true)

theorem identity21352 : scanCanonicalize (H12AffineFastState.compose env21352 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound21352 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,2097152,272393,2101329,41311,8193,64,2149649,2098513,17665,2384973,2102549,2411540,256,21792,46092,2101824]

theorem envBound21353 : H12AffineFastState.Bounded env21353 := by
  intro p hp
  have h : env21353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21352_21353 : H12AffineEnvironment.transform 16 46109 env21352 = env21353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env21352 == env21353) = true)

theorem identity21353 : scanCanonicalize (H12AffineFastState.compose env21353 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound21353 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env21354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4161,272393,16,41311,8193,64,56656,5392,17665,291852,1364,318549,256,21792,46092,513]

theorem envBound21354 : H12AffineFastState.Bounded env21354 := by
  intro p hp
  have h : env21354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21353_21354 : H12AffineEnvironment.transform 20 4161 env21353 = env21354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21353 == env21354) = true)

theorem identity21354 : scanCanonicalize (H12AffineFastState.compose env21354 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound21354 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env21355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16448,262144,1024,29788,4161,272393,16,21762,8193,64,10509,5392,17665,291852,1364,272392,256,21792,16465,513]

theorem envBound21355 : H12AffineFastState.Bounded env21355 := by
  intro p hp
  have h : env21355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21354_21355 : H12AffineEnvironment.transform 14 29789 env21354 = env21355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env21354 == env21355) = true)

theorem identity21355 : scanCanonicalize (H12AffineFastState.compose env21355 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound21355 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16448,2421,1024,29788,4161,8572,16,21762,8193,64,10509,5392,17665,32121,1364,8573,256,21792,16465,513]

theorem envBound21356 : H12AffineFastState.Bounded env21356 := by
  intro p hp
  have h : env21356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21355_21356 : H12AffineEnvironment.transform 17 2421 env21355 = env21356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env21355 == env21356) = true)

theorem identity21356 : scanCanonicalize (H12AffineFastState.compose env21356 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21356 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,262,16448,2421,1024,21840,4161,112,16,21762,269,64,2049,5392,17665,23669,1364,113,256,21792,16465,513]

theorem envBound21357 : H12AffineFastState.Bounded env21357 := by
  intro p hp
  have h : env21357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21356_21357 : H12AffineEnvironment.transform 12 268 env21356 = env21357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21356 == env21357) = true)

theorem identity21357 : scanCanonicalize (H12AffineFastState.compose env21357 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21357 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21358 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,262,16401,2340,1024,21761,4112,33,16,21762,269,17,2049,5392,17665,23588,1285,32,256,21792,16384,513]

theorem envBound21358 : H12AffineFastState.Bounded env21358 := by
  intro p hp
  have h : env21358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21357_21358 : H12AffineEnvironment.transform 5 17 env21357 = env21358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21357 == env21358) = true)

def env21359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98780,8328,64,2259213,2098513,17665,2543696,2102684,2411676,256,21792,46213,2175562]

theorem envBound21359 : H12AffineFastState.Bounded env21359 := by
  intro p hp
  have h : env21359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21341_21359 : H12AffineEnvironment.transform 21 272513 env21341 = env21359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21341 == env21359) = true)

theorem identity21359 : scanCanonicalize (H12AffineFastState.compose env21359 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound21359 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272513,73754,98780,8328,64,215366,79130,17665,516123,75223,392407,256,21792,46213,513]

theorem envBound21360 : H12AffineFastState.Bounded env21360 := by
  intro p hp
  have h : env21360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21359_21360 : H12AffineEnvironment.transform 20 77899 env21359 = env21360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env21359 == env21360) = true)

def env21361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272393,73754,98644,8192,64,215366,79130,17665,516123,75103,392287,256,21792,46093,513]

theorem envBound21361 : H12AffineFastState.Bounded env21361 := by
  intro p hp
  have h : env21361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21360_21361 : H12AffineEnvironment.transform 6 8 env21360 = env21361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21360 == env21361) = true)

theorem identity21361 : scanCanonicalize (H12AffineFastState.compose env21361 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound21361 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,77899,272393,73754,98644,8192,64,10589,79130,17665,294912,75103,392287,256,21792,46093,513]

theorem envBound21362 : H12AffineFastState.Bounded env21362 := by
  intro p hp
  have h : env21362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21361_21362 : H12AffineEnvironment.transform 16 90139 env21361 = env21362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env21361 == env21362) = true)

theorem identity21362 : scanCanonicalize (H12AffineFastState.compose env21362 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21362 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env21363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,272393,17,41311,8192,64,10589,5393,17665,294912,1364,318548,256,21792,46093,513]

theorem envBound21363 : H12AffineFastState.Bounded env21363 := by
  intro p hp
  have h : env21363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21362_21363 : H12AffineEnvironment.transform 15 8203 env21362 = env21363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21362 == env21363) = true)

theorem identity21363 : scanCanonicalize (H12AffineFastState.compose env21363 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound21363 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1024,32769,4160,41340,17,41311,8192,64,10589,5393,17665,2421,1364,21793,256,21792,46093,513]

theorem envBound21364 : H12AffineFastState.Bounded env21364 := by
  intro p hp
  have h : env21364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21363_21364 : H12AffineEnvironment.transform 17 35189 env21363 = env21364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env21363 == env21364) = true)

theorem identity21364 : scanCanonicalize (H12AffineFastState.compose env21364 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound21364 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,8203,16400,3125,1024,1345,4160,9276,17,9247,8192,64,10589,5393,17665,2421,1364,21793,256,21792,12621,513]

theorem envBound21365 : H12AffineFastState.Bounded env21365 := by
  intro p hp
  have h : env21365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21364_21365 : H12AffineEnvironment.transform 14 1344 env21364 = env21365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env21364 == env21365) = true)

theorem identity21365 : scanCanonicalize (H12AffineFastState.compose env21365 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21365 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,1344,8203,5221,3125,1024,1345,4160,9276,17,9247,8192,64,10589,5393,4468,2421,1364,340,256,341,12621,513]

theorem envBound21366 : H12AffineFastState.Bounded env21366 := by
  intro p hp
  have h : env21366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21365_21366 : H12AffineEnvironment.transform 13 5237 env21365 = env21366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21365 == env21366) = true)

theorem identity21366 : scanCanonicalize (H12AffineFastState.compose env21366 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21366 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21367 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4113,292,8203,4097,2129,100,293,4160,8280,17,8315,8192,64,10589,4469,4468,2421,304,340,256,341,12621,513]

theorem envBound21367 : H12AffineFastState.Bounded env21367 := by
  intro p hp
  have h : env21367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21366_21367 : H12AffineEnvironment.transform 9 100 env21366 = env21367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21366 == env21367) = true)

theorem identity21367 : scanCanonicalize (H12AffineFastState.compose env21367 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound21367 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21368 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,64,8192,81,292,8203,65,2129,100,293,0,8280,17,8315,8192,64,10589,309,308,2421,304,340,256,341,8461,513]

theorem envBound21368 : H12AffineFastState.Bounded env21368 := by
  intro p hp
  have h : env21368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21367_21368 : H12AffineEnvironment.transform 11 64 env21367 = env21368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env21367 == env21368) = true)

theorem identity21368 : scanCanonicalize (H12AffineFastState.compose env21368 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21368 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21369 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,17,8192,0,292,8203,16,2048,53,293,0,8201,17,8234,8192,17,10508,309,308,2340,304,261,256,260,8461,513]

theorem envBound21369 : H12AffineFastState.Bounded env21369 := by
  intro p hp
  have h : env21369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21368_21369 : H12AffineEnvironment.transform 5 17 env21368 = env21369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21368 == env21369) = true)

theorem identity21369 : scanCanonicalize (H12AffineFastState.compose env21369 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21370 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,17,41,0,292,34,16,2048,53,293,0,32,17,3,41,17,2341,309,308,2340,304,261,256,260,292,513]

theorem envBound21370 : H12AffineFastState.Bounded env21370 := by
  intro p hp
  have h : env21370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21369_21370 : H12AffineEnvironment.transform 12 41 env21369 = env21370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21369 == env21370) = true)

theorem identity21370 : scanCanonicalize (H12AffineFastState.compose env21370 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21370 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21371 : List Nat := [2,4,8,16,32,17,8,256,512,53,1,17,41,0,292,34,16,1,53,293,0,32,17,3,41,17,292,309,308,293,304,261,256,260,292,513]

theorem envBound21371 : H12AffineFastState.Bounded env21371 := by
  intro p hp
  have h : env21371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21370_21371 : H12AffineEnvironment.transform 10 1 env21370 = env21371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21370 == env21371) = true)

def env21372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272392,73754,98645,8193,64,215366,79130,17665,516123,75102,392286,256,21792,46092,513]

theorem envBound21372 : H12AffineFastState.Bounded env21372 := by
  intro p hp
  have h : env21372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21360_21372 : H12AffineEnvironment.transform 6 9 env21360 = env21372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21360 == env21372) = true)

def env21373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,32,73754,98645,8193,64,215366,79130,17665,247859,75102,119926,256,21792,46092,513]

theorem envBound21373 : H12AffineFastState.Bounded env21373 := by
  intro p hp
  have h : env21373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21372_21373 : H12AffineEnvironment.transform 17 10280 env21372 = env21373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21372 == env21373) = true)

def env21374 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98565,8193,16,215318,79130,17665,247859,75022,119846,256,21792,46092,513]

theorem envBound21374 : H12AffineFastState.Bounded env21374 := by
  intro p hp
  have h : env21374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21373_21374 : H12AffineEnvironment.transform 5 16 env21373 = env21374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21373 == env21374) = true)

theorem identity21374 : scanCanonicalize (H12AffineFastState.compose env21374 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound21374 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21375 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1024,32769,77851,32,73754,98565,8193,16,43276,79130,17665,10281,75022,119846,256,21792,46092,513]

theorem envBound21375 : H12AffineFastState.Bounded env21375 := by
  intro p hp
  have h : env21375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21374_21375 : H12AffineEnvironment.transform 16 122906 env21374 = env21375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env21374 == env21375) = true)

theorem identity21375 : scanCanonicalize (H12AffineFastState.compose env21375 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21375 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env21376 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,65536,103446,10280,1024,32769,77851,32,73754,98565,8193,16,43276,79130,12557,10281,75022,106538,256,8492,46092,513]

theorem envBound21376 : H12AffineFastState.Bounded env21376 := by
  intro p hp
  have h : env21376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21375_21376 : H12AffineEnvironment.transform 13 13324 env21375 = env21376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21375 == env21376) = true)

theorem identity21376 : scanCanonicalize (H12AffineFastState.compose env21376 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21376 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env21377 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8203,46109,10280,1024,32769,4112,32,17,41230,8193,16,43276,5393,12557,10281,1285,32801,256,8492,46092,513]

theorem envBound21377 : H12AffineFastState.Bounded env21377 := by
  intro p hp
  have h : env21377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21376_21377 : H12AffineEnvironment.transform 15 8203 env21376 = env21377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21376 == env21377) = true)

theorem identity21377 : scanCanonicalize (H12AffineFastState.compose env21377 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21377 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21378 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,262,38160,2341,1024,32769,4112,32,17,32771,268,16,34817,5393,4096,2340,1285,32801,256,33,38145,513]

theorem envBound21378 : H12AffineFastState.Bounded env21378 := by
  intro p hp
  have h : env21378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21377_21378 : H12AffineEnvironment.transform 12 269 env21377 = env21378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21377 == env21378) = true)

theorem identity21378 : scanCanonicalize (H12AffineFastState.compose env21378 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21378 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21379 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5393,2341,1024,0,4112,32,17,2,268,16,2048,5393,4096,2340,1285,32,256,33,5376,513]

theorem envBound21379 : H12AffineFastState.Bounded env21379 := by
  intro p hp
  have h : env21379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21378_21379 : H12AffineEnvironment.transform 14 1 env21378 = env21379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21378 == env21379) = true)

theorem identity21379 : scanCanonicalize (H12AffineFastState.compose env21379 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound21379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21380 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1061,269,292,1,262,308,2341,1024,0,1077,32,17,2,268,16,2048,308,1061,2340,1285,32,256,33,293,513]

theorem envBound21380 : H12AffineFastState.Bounded env21380 := by
  intro p hp
  have h : env21380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21379_21380 : H12AffineEnvironment.transform 11 1061 env21379 = env21380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env21379 == env21380) = true)

theorem identity21380 : scanCanonicalize (H12AffineFastState.compose env21380 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21381 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,308,269,292,1,262,308,2341,273,0,292,32,17,2,268,16,2048,308,308,2340,20,32,256,33,293,513]

theorem envBound21381 : H12AffineFastState.Bounded env21381 := by
  intro p hp
  have h : env21381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21380_21381 : H12AffineEnvironment.transform 9 273 env21380 = env21381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21380 == env21381) = true)

theorem identity21381 : scanCanonicalize (H12AffineFastState.compose env21381 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21381 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21382 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,308,269,292,1,262,308,1,273,0,292,32,17,2,268,16,292,308,308,0,20,32,256,33,293,513]

theorem envBound21382 : H12AffineFastState.Bounded env21382 := by
  intro p hp
  have h : env21382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21381_21382 : H12AffineEnvironment.transform 10 292 env21381 = env21382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21381 == env21382) = true)

def env21383 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98564,8193,17,215319,79130,17665,247859,75023,119847,256,21792,46092,513]

theorem envBound21383 : H12AffineFastState.Bounded env21383 := by
  intro p hp
  have h : env21383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21373_21383 : H12AffineEnvironment.transform 5 17 env21373 = env21383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21373 == env21383) = true)

theorem identity21383 : scanCanonicalize (H12AffineFastState.compose env21383 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound21383 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21384 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1024,32769,77850,32,73754,98564,8193,17,75786,79130,17665,108846,75023,119847,256,21792,46092,513]

theorem envBound21384 : H12AffineFastState.Bounded env21384 := by
  intro p hp
  have h : env21384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21383_21384 : H12AffineEnvironment.transform 16 24861 env21383 = env21384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env21383 == env21384) = true)

theorem identity21384 : scanCanonicalize (H12AffineFastState.compose env21384 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21384 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21385 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,13340,10280,1024,32769,77850,32,73754,98564,8193,17,75786,79130,4096,108846,75023,98598,256,33,46092,513]

theorem envBound21385 : H12AffineFastState.Bounded env21385 := by
  intro p hp
  have h : env21385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21384_21385 : H12AffineEnvironment.transform 13 5377 env21384 = env21385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21384 == env21385) = true)

theorem identity21385 : scanCanonicalize (H12AffineFastState.compose env21385 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound21385 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21386 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,13340,10280,1024,32769,45340,32,41244,2,8193,17,43276,46108,4096,10280,41993,32,256,33,46092,513]

theorem envBound21386 : H12AffineFastState.Bounded env21386 := by
  intro p hp
  have h : env21386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21385_21386 : H12AffineEnvironment.transform 15 33030 env21385 = env21386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env21385 == env21386) = true)

def env21387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,33,73754,98645,8193,64,215366,79130,17665,247858,75102,119927,256,21792,46092,513]

theorem envBound21387 : H12AffineFastState.Bounded env21387 := by
  intro p hp
  have h : env21387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21372_21387 : H12AffineEnvironment.transform 17 10281 env21372 = env21387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21372 == env21387) = true)

theorem identity21387 : scanCanonicalize (H12AffineFastState.compose env21387 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21387 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4161,33,16,41311,8193,64,158028,5392,17665,190520,1364,62589,256,21792,46092,513]

theorem envBound21388 : H12AffineFastState.Bounded env21388 := by
  intro p hp
  have h : env21388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21387_21388 : H12AffineEnvironment.transform 15 8202 env21387 = env21388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21387 == env21388) = true)

theorem identity21388 : scanCanonicalize (H12AffineFastState.compose env21388 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27741) := by decide +kernel

theorem selectedBound21388 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27741,10281,1024,32769,4161,33,16,41311,8193,64,1297,5392,17665,33893,1364,62589,256,21792,46092,513]

theorem envBound21389 : H12AffineFastState.Bounded env21389 := by
  intro p hp
  have h : env21389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21388_21389 : H12AffineEnvironment.transform 16 27741 env21388 = env21389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27741 env21388 == env21389) = true)

theorem identity21389 : scanCanonicalize (H12AffineFastState.compose env21389 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21389 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env21390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19572,2048,1024,32769,4161,33,16,33142,40,64,1297,5392,17665,33893,1364,54356,256,21792,37925,513]

theorem envBound21390 : H12AffineFastState.Bounded env21390 := by
  intro p hp
  have h : env21390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21389_21390 : H12AffineEnvironment.transform 12 41 env21389 = env21390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21389 == env21390) = true)

theorem identity21390 : scanCanonicalize (H12AffineFastState.compose env21390 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 3377) := by decide +kernel

theorem selectedBound21390 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env21391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,3377,35,19572,2048,1024,3376,4161,33,16,3143,40,64,1297,5392,17665,2388,1364,22885,256,21792,6420,513]

theorem envBound21391 : H12AffineFastState.Bounded env21391 := by
  intro p hp
  have h : env21391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21390_21391 : H12AffineEnvironment.transform 14 3377 env21390 = env21391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3377 env21390 == env21391) = true)

theorem identity21391 : scanCanonicalize (H12AffineFastState.compose env21391 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 6208) := by decide +kernel

theorem selectedBound21391 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env21392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,6208,3377,35,5172,2048,1024,3376,4161,33,16,3143,40,64,1297,5392,7489,2388,1364,293,256,3424,6420,513]

theorem envBound21392 : H12AffineFastState.Bounded env21392 := by
  intro p hp
  have h : env21392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21391_21392 : H12AffineEnvironment.transform 13 6208 env21391 = env21392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6208 env21391 == env21392) = true)

theorem identity21392 : scanCanonicalize (H12AffineFastState.compose env21392 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound21392 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,41,4112,1377,35,5172,80,1024,1376,4161,33,16,1047,40,64,1297,5392,5393,260,1364,293,256,1328,4420,513]

theorem envBound21393 : H12AffineFastState.Bounded env21393 := by
  intro p hp
  have h : env21393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21392_21393 : H12AffineEnvironment.transform 10 80 env21392 = env21393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env21392 == env21393) = true)

theorem identity21393 : scanCanonicalize (H12AffineFastState.compose env21393 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound21393 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env21394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,324,41,340,1377,35,1392,80,1024,1376,261,33,16,1047,40,64,1297,1108,1109,260,1364,293,256,1328,0,513]

theorem envBound21394 : H12AffineFastState.Bounded env21394 := by
  intro p hp
  have h : env21394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21393_21394 : H12AffineEnvironment.transform 11 324 env21393 = env21394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env21393 == env21394) = true)

theorem identity21394 : scanCanonicalize (H12AffineFastState.compose env21394 (packedSelected [6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound21394 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env21395 : List Nat := [2,4,8,16,32,64,9,256,32,1024,80,324,41,340,1377,35,1392,80,1024,1376,261,33,16,1047,40,64,1297,1108,1109,260,1364,293,256,1328,0,33]

theorem envBound21395 : H12AffineFastState.Bounded env21395 := by
  intro p hp
  have h : env21395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21394_21395 : H12AffineEnvironment.transform 8 32 env21394 = env21395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env21394 == env21395) = true)

theorem identity21395 : scanCanonicalize (H12AffineFastState.compose env21395 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound21395 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21396 : List Nat := [2,4,8,16,32,64,9,85,32,1024,80,17,41,1,1076,35,1061,80,1024,1077,80,33,16,1047,40,64,1092,1108,1109,81,1025,112,85,1125,0,33]

theorem envBound21396 : H12AffineFastState.Bounded env21396 := by
  intro p hp
  have h : env21396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21395_21396 : H12AffineEnvironment.transform 7 85 env21395 = env21396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env21395 == env21396) = true)

def env21397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound21397 : H12AffineFastState.Bounded env21397 := by
  intro p hp
  have h : env21397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21127_21397 : H12AffineEnvironment.transform 18 1025 env21127 = env21397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21127 == env21397) = true)

theorem identity21397 : scanCanonicalize (H12AffineFastState.compose env21397 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642688) := by decide +kernel

theorem selectedBound21397 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642688,8328,64,4464768,10642444,10507600,8830976,156817,14845249,257,2237484,2278792,213830]

theorem envBound21398 : H12AffineFastState.Bounded env21398 := by
  intro p hp
  have h : env21398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21397_21398 : H12AffineEnvironment.transform 23 8642688 env21397 = env21398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642688 env21397 == env21398) = true)

def env21399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,8388608,8642688,8328,64,4464768,8393984,8528988,8830976,156817,12645453,257,21792,46212,213830]

theorem envBound21399 : H12AffineFastState.Bounded env21399 := by
  intro p hp
  have h : env21399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21398_21399 : H12AffineEnvironment.transform 20 160012 env21398 = env21399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160012 env21398 == env21399) = true)

def env21400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169352,95496,8328,64,4464768,163976,45524,284040,156817,4350405,257,21792,46212,213830]

theorem envBound21400 : H12AffineFastState.Bounded env21400 := by
  intro p hp
  have h : env21400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21399_21400 : H12AffineEnvironment.transform 22 169352 env21399 = env21400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env21399 == env21400) = true)

def env21401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169352,95496,8328,64,2048,163976,45524,284040,156817,411973,257,21792,46212,213830]

theorem envBound21401 : H12AffineFastState.Bounded env21401 := by
  intro p hp
  have h : env21401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21400_21401 : H12AffineEnvironment.transform 21 272512 env21400 = env21401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21400 == env21401) = true)

theorem identity21401 : scanCanonicalize (H12AffineFastState.compose env21401 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound21401 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272512,62661,95496,8328,64,2048,57797,45524,284040,1500,272392,257,21792,46212,74251]

theorem envBound21402 : H12AffineFastState.Bounded env21402 := by
  intro p hp
  have h : env21402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21401_21402 : H12AffineEnvironment.transform 16 24909 env21401 = env21402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env21401 == env21402) = true)

theorem identity21402 : scanCanonicalize (H12AffineFastState.compose env21402 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21402 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,4161,272512,62661,21762,8328,64,2048,57797,45524,284040,1500,272392,257,21792,46212,513]

theorem envBound21403 : H12AffineFastState.Bounded env21403 := by
  intro p hp
  have h : env21403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21402_21403 : H12AffineEnvironment.transform 15 8202 env21402 = env21403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21402 == env21403) = true)

theorem identity21403 : scanCanonicalize (H12AffineFastState.compose env21403 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound21403 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env21404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,23669,1025,32769,4161,29941,62661,21762,8328,64,2048,57797,45524,2557,1500,29821,257,21792,46212,513]

theorem envBound21404 : H12AffineFastState.Bounded env21404 := by
  intro p hp
  have h : env21404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21403_21404 : H12AffineEnvironment.transform 17 23669 env21403 = env21404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env21403 == env21404) = true)

theorem identity21404 : scanCanonicalize (H12AffineFastState.compose env21404 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound21404 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env21405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8202,24909,23669,1025,21896,4161,29941,8524,21762,8328,64,2048,13388,25693,2557,1500,29821,257,21792,24845,513]

theorem envBound21405 : H12AffineFastState.Bounded env21405 := by
  intro p hp
  have h : env21405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21404_21405 : H12AffineEnvironment.transform 14 21897 env21404 = env21405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env21404 == env21405) = true)

theorem identity21405 : scanCanonicalize (H12AffineFastState.compose env21405 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21405 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env21406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,1,8202,13509,2557,1025,0,4161,8573,8524,138,8328,64,2048,13388,12757,2557,1500,8693,257,168,13445,513]

theorem envBound21406 : H12AffineFastState.Bounded env21406 := by
  intro p hp
  have h : env21406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21405_21406 : H12AffineEnvironment.transform 13 5512 env21405 = env21406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21405 == env21406) = true)

theorem identity21406 : scanCanonicalize (H12AffineFastState.compose env21406 (packedSelected [0,2,6,7,17] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound21406 : packedSelected [0,2,6,7,17] rootPS < 2^1333 := by decide +kernel

def env21407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,357,1,8202,8232,2557,1025,0,1196,8573,8524,138,8328,64,2048,8353,9528,2557,1500,8693,257,168,8296,513]

theorem envBound21407 : H12AffineFastState.Bounded env21407 := by
  intro p hp
  have h : env21407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21406_21407 : H12AffineEnvironment.transform 11 1261 env21406 = env21407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env21406 == env21407) = true)

theorem identity21407 : scanCanonicalize (H12AffineFastState.compose env21407 (packedSelected [3,4,5,6,9,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21407 : packedSelected [3,4,5,6,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env21408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,40,357,1,34,0,2557,1025,0,1196,341,356,138,160,64,2048,137,1296,2557,1500,477,257,168,64,513]

theorem envBound21408 : H12AffineFastState.Bounded env21408 := by
  intro p hp
  have h : env21408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21407_21408 : H12AffineEnvironment.transform 12 40 env21407 = env21408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21407 == env21408) = true)

theorem identity21408 : scanCanonicalize (H12AffineFastState.compose env21408 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound21408 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21409 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1261,40,152,1,34,0,2048,1025,0,1196,168,153,138,160,64,2048,137,1261,2048,1057,32,252,168,64,513]

theorem envBound21409 : H12AffineFastState.Bounded env21409 := by
  intro p hp
  have h : env21409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21408_21409 : H12AffineEnvironment.transform 7 253 env21408 = env21409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env21408 == env21409) = true)

theorem identity21409 : scanCanonicalize (H12AffineFastState.compose env21409 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound21409 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21410 : List Nat := [2,4,8,16,32,64,128,253,512,1024,137,1261,40,152,1,34,0,137,1025,0,1196,168,153,138,160,64,137,137,1261,137,1057,32,252,168,64,513]

theorem envBound21410 : H12AffineFastState.Bounded env21410 := by
  intro p hp
  have h : env21410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21409_21410 : H12AffineEnvironment.transform 10 137 env21409 = env21410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env21409 == env21410) = true)

theorem identity21410 : scanCanonicalize (H12AffineFastState.compose env21410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21411 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1,1125,40,16,1,34,0,1,1025,0,1060,32,17,2,40,64,1,1,1125,1,1057,32,116,32,64,513]

theorem envBound21411 : H12AffineFastState.Bounded env21411 := by
  intro p hp
  have h : env21411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21410_21411 : H12AffineEnvironment.transform 6 8 env21410 = env21411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21410 == env21411) = true)

theorem identity21411 : scanCanonicalize (H12AffineFastState.compose env21411 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound21411 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21412 : List Nat := [2,4,8,16,32,64,8,117,512,111,1,10,40,16,1,34,0,1,110,0,75,32,17,2,40,64,1,1,10,1,78,32,116,32,64,513]

theorem envBound21412 : H12AffineFastState.Bounded env21412 := by
  intro p hp
  have h : env21412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21411_21412 : H12AffineEnvironment.transform 9 111 env21411 = env21412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env21411 == env21412) = true)

theorem identity21412 : scanCanonicalize (H12AffineFastState.compose env21412 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound21412 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21413 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,10,2,16,1,8,0,1,68,0,75,10,17,2,2,64,1,1,10,1,78,10,94,10,64,513]

theorem envBound21413 : H12AffineFastState.Bounded env21413 := by
  intro p hp
  have h : env21413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21412_21413 : H12AffineEnvironment.transform 4 10 env21412 = env21413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env21412 == env21413) = true)

theorem identity21413 : scanCanonicalize (H12AffineFastState.compose env21413 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21413 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env21414 : List Nat := [2,4,8,16,10,16,8,15,512,21,1,10,2,16,1,8,0,1,20,0,27,10,17,2,2,16,1,1,10,1,30,10,14,10,16,513]

theorem envBound21414 : H12AffineFastState.Bounded env21414 := by
  intro p hp
  have h : env21414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21413_21414 : H12AffineEnvironment.transform 5 16 env21413 = env21414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21413 == env21414) = true)

theorem identity21414 : scanCanonicalize (H12AffineFastState.compose env21414 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21414 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21415 : List Nat := [2,4,8,10,10,10,8,15,512,15,1,10,2,10,1,8,0,1,14,0,1,10,11,2,2,10,1,1,10,1,4,10,14,10,10,513]

theorem envBound21415 : H12AffineFastState.Bounded env21415 := by
  intro p hp
  have h : env21415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21414_21415 : H12AffineEnvironment.transform 3 10 env21414 = env21415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21414 == env21415) = true)

theorem identity21415 : scanCanonicalize (H12AffineFastState.compose env21415 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound21415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21416 : List Nat := [2,1,8,10,10,10,8,10,512,10,1,10,2,10,1,8,0,1,11,0,1,10,11,2,2,10,1,1,10,1,1,10,11,10,10,513]

theorem envBound21416 : H12AffineFastState.Bounded env21416 := by
  intro p hp
  have h : env21416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21415_21416 : H12AffineEnvironment.transform 1 1 env21415 = env21416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env21415 == env21416) = true)

def env21417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169352,95496,8328,64,2049,163976,45524,284040,156817,411972,257,21792,46212,213830]

theorem envBound21417 : H12AffineFastState.Bounded env21417 := by
  intro p hp
  have h : env21417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21400_21417 : H12AffineEnvironment.transform 21 272513 env21400 = env21417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21400 == env21417) = true)

theorem identity21417 : scanCanonicalize (H12AffineFastState.compose env21417 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21417 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160012,272513,155996,95496,8328,64,2049,160860,17664,284040,156817,411972,257,21792,16464,213830]

theorem envBound21418 : H12AffineFastState.Bounded env21418 := by
  intro p hp
  have h : env21418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21417_21418 : H12AffineEnvironment.transform 14 29908 env21417 = env21418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21417 == env21418) = true)

theorem identity21418 : scanCanonicalize (H12AffineFastState.compose env21418 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound21418 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env21419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149861,1025,29909,160012,156132,155996,95496,8328,64,2049,160860,17664,138477,156817,33,257,21792,16464,213830]

theorem envBound21419 : H12AffineFastState.Bounded env21419 := by
  intro p hp
  have h : env21419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21418_21419 : H12AffineEnvironment.transform 17 149861 env21418 = env21419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env21418 == env21419) = true)

def env21420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1025,29789,160012,156012,155996,95496,8192,64,2049,160860,17664,138341,156697,33,257,21792,16464,213830]

theorem envBound21420 : H12AffineFastState.Bounded env21420 := by
  intro p hp
  have h : env21420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21419_21420 : H12AffineEnvironment.transform 6 8 env21419 = env21420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21419 == env21420) = true)

theorem identity21420 : scanCanonicalize (H12AffineFastState.compose env21420 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound21420 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,82247,67618,1025,29789,77899,73771,73755,95496,8192,64,2049,79131,17664,89378,75102,33,257,21792,16464,513]

theorem envBound21421 : H12AffineFastState.Bounded env21421 := by
  intro p hp
  have h : env21421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21420_21421 : H12AffineEnvironment.transform 16 82247 env21420 = env21421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env21420 == env21421) = true)

theorem identity21421 : scanCanonicalize (H12AffineFastState.compose env21421 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21421 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,343,16400,2421,1025,29789,12572,8572,8524,29791,8192,64,2049,13388,17664,23669,9225,33,257,21792,16464,513]

theorem envBound21422 : H12AffineFastState.Bounded env21422 := by
  intro p hp
  have h : env21422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21421_21422 : H12AffineEnvironment.transform 15 343 env21421 = env21422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21421 == env21422) = true)

theorem identity21422 : scanCanonicalize (H12AffineFastState.compose env21422 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21422 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,343,5393,2421,1025,8540,12572,8572,8524,8542,8192,64,2049,13388,4097,2420,9225,33,257,33,5457,513]

theorem envBound21423 : H12AffineFastState.Bounded env21423 := by
  intro p hp
  have h : env21423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21422_21423 : H12AffineEnvironment.transform 13 5377 env21422 = env21423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21422 == env21423) = true)

theorem identity21423 : scanCanonicalize (H12AffineFastState.compose env21423 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21423 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env21424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5393,2421,1025,0,4160,32,16,2,348,64,2049,5392,4097,2420,1365,33,257,33,5457,513]

theorem envBound21424 : H12AffineFastState.Bounded env21424 := by
  intro p hp
  have h : env21424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21423_21424 : H12AffineEnvironment.transform 12 348 env21423 = env21424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21423 == env21424) = true)

theorem identity21424 : scanCanonicalize (H12AffineFastState.compose env21424 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21424 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21425 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,348,4404,1,343,4388,2421,52,0,4160,32,16,2,348,64,2049,4389,4097,2420,352,33,257,33,4452,513]

theorem envBound21425 : H12AffineFastState.Bounded env21425 := by
  intro p hp
  have h : env21425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21424_21425 : H12AffineEnvironment.transform 9 53 env21424 = env21425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21424 == env21425) = true)

theorem identity21425 : scanCanonicalize (H12AffineFastState.compose env21425 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21425 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21426 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,41,4161,1,34,4177,2048,52,0,4160,32,16,2,41,64,2049,4176,4097,2049,21,33,116,33,4113,513]

theorem envBound21426 : H12AffineFastState.Bounded env21426 := by
  intro p hp
  have h : env21426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21425_21426 : H12AffineEnvironment.transform 7 117 env21425 = env21426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21425 == env21426) = true)

def env21427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1025,29788,160012,156013,155996,95496,8193,64,2049,160860,17664,138340,156696,33,257,21792,16464,213830]

theorem envBound21427 : H12AffineFastState.Bounded env21427 := by
  intro p hp
  have h : env21427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21419_21427 : H12AffineEnvironment.transform 6 9 env21419 = env21427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21419 == env21427) = true)

theorem identity21427 : scanCanonicalize (H12AffineFastState.compose env21427 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound21427 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,131072,149861,1025,29788,160012,156013,155996,3,8193,64,2049,160860,17664,138340,156696,33,257,21792,16464,144973]

theorem envBound21428 : H12AffineFastState.Bounded env21428 := by
  intro p hp
  have h : env21428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21427_21428 : H12AffineEnvironment.transform 15 29963 env21427 = env21428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env21427 == env21428) = true)

theorem identity21428 : scanCanonicalize (H12AffineFastState.compose env21428 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21428 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env21429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,131072,138341,1025,8540,140300,144493,144476,3,8193,64,2049,139612,4096,138340,143640,33,257,32,5456,144973]

theorem envBound21429 : H12AffineFastState.Bounded env21429 := by
  intro p hp
  have h : env21429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21428_21429 : H12AffineEnvironment.transform 13 5376 env21428 = env21429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21428 == env21429) = true)

theorem identity21429 : scanCanonicalize (H12AffineFastState.compose env21429 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21429 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env21430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,35,131072,138341,1025,372,132132,136261,136308,3,41,64,2049,131444,4096,138340,135472,33,257,32,5456,136805]

theorem envBound21430 : H12AffineFastState.Bounded env21430 := by
  intro p hp
  have h : env21430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21429_21430 : H12AffineEnvironment.transform 12 40 env21429 = env21430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21429 == env21430) = true)

theorem identity21430 : scanCanonicalize (H12AffineFastState.compose env21430 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21430 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env21431 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,80,35,131072,138341,1025,81,132132,136261,136308,3,41,64,2049,131153,4096,138340,135189,33,36,32,5237,136805]

theorem envBound21431 : H12AffineFastState.Bounded env21431 := by
  intro p hp
  have h : env21431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21430_21431 : H12AffineEnvironment.transform 7 37 env21430 = env21431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21430 == env21431) = true)

theorem identity21431 : scanCanonicalize (H12AffineFastState.compose env21431 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound21431 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env21432 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,80,35,2113,5156,1025,81,3173,7172,7221,3,41,64,2049,2064,4096,5157,6228,33,36,32,5237,7716]

theorem envBound21432 : H12AffineFastState.Bounded env21432 := by
  intro p hp
  have h : env21432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21431_21432 : H12AffineEnvironment.transform 16 2113 env21431 = env21432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env21431 == env21432) = true)

theorem identity21432 : scanCanonicalize (H12AffineFastState.compose env21432 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21432 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21433 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,35,2065,5156,1025,1,3125,7172,7221,3,41,16,2049,2064,4096,5157,6148,33,36,32,5157,7716]

theorem envBound21433 : H12AffineFastState.Bounded env21433 := by
  intro p hp
  have h : env21433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21432_21433 : H12AffineEnvironment.transform 5 16 env21432 = env21433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21432 == env21433) = true)

theorem identity21433 : scanCanonicalize (H12AffineFastState.compose env21433 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21433 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21434 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,0,35,2065,4112,53,1,2049,6192,6145,3,41,16,2049,2064,4096,4113,6148,33,36,32,4113,6672]

theorem envBound21434 : H12AffineFastState.Bounded env21434 := by
  intro p hp
  have h : env21434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21433_21434 : H12AffineEnvironment.transform 9 52 env21433 = env21434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21433 == env21434) = true)

theorem identity21434 : scanCanonicalize (H12AffineFastState.compose env21434 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2590) := by decide +kernel

theorem selectedBound21434 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env21435 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2590,40,2575,0,35,2065,2574,53,1,2049,558,543,3,41,16,2049,2064,2590,2575,538,33,36,32,2575,14]

theorem envBound21435 : H12AffineFastState.Bounded env21435 := by
  intro p hp
  have h : env21435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21434_21435 : H12AffineEnvironment.transform 11 2590 env21434 = env21435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2590 env21434 == env21435) = true)

theorem identity21435 : scanCanonicalize (H12AffineFastState.compose env21435 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound21435 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21436 : List Nat := [2,4,8,16,32,16,9,37,14,52,2048,2064,40,2049,0,35,2065,2048,53,1,2049,32,17,3,41,16,2049,2064,2064,2049,20,33,36,32,2049,14]

theorem envBound21436 : H12AffineFastState.Bounded env21436 := by
  intro p hp
  have h : env21436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21435_21436 : H12AffineEnvironment.transform 8 14 env21435 = env21436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env21435 == env21436) = true)

theorem identity21436 : scanCanonicalize (H12AffineFastState.compose env21436 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound21436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21437 : List Nat := [2,4,8,16,32,16,9,37,14,52,4,20,40,5,0,35,21,4,53,1,5,32,17,3,41,16,5,20,20,5,20,33,36,32,5,14]

theorem envBound21437 : H12AffineFastState.Bounded env21437 := by
  intro p hp
  have h : env21437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21436_21437 : H12AffineEnvironment.transform 10 4 env21436 = env21437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env21436 == env21437) = true)

theorem identity21437 : scanCanonicalize (H12AffineFastState.compose env21437 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound21437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21438 : List Nat := [2,4,8,8,32,8,9,37,14,44,4,12,40,5,0,35,13,4,45,1,5,32,9,3,41,8,5,12,12,5,12,33,36,32,5,14]

theorem envBound21438 : H12AffineFastState.Bounded env21438 := by
  intro p hp
  have h : env21438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21437_21438 : H12AffineEnvironment.transform 3 8 env21437 = env21438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env21437 == env21438) = true)

theorem identity21438 : scanCanonicalize (H12AffineFastState.compose env21438 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21439 : List Nat := [2,4,8,8,1,8,9,4,14,13,4,12,9,5,0,2,13,4,12,1,5,1,9,3,8,8,5,12,12,5,12,0,5,1,5,14]

theorem envBound21439 : H12AffineFastState.Bounded env21439 := by
  intro p hp
  have h : env21439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21438_21439 : H12AffineEnvironment.transform 4 1 env21438 = env21439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21438 == env21439) = true)

theorem identity21439 : scanCanonicalize (H12AffineFastState.compose env21439 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21439 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21440 : List Nat := [2,0,8,8,1,8,9,0,10,9,0,8,9,1,0,2,9,0,8,1,1,1,9,3,8,8,1,8,8,1,8,0,1,1,1,10]

theorem envBound21440 : H12AffineFastState.Bounded env21440 := by
  intro p hp
  have h : env21440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21439_21440 : H12AffineEnvironment.transform 1 0 env21439 = env21440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21439 == env21440) = true)

def env21441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169353,95497,8328,64,4464768,163977,45525,284041,156817,4350404,257,21792,46212,213830]

theorem envBound21441 : H12AffineFastState.Bounded env21441 := by
  intro p hp
  have h : env21441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21399_21441 : H12AffineEnvironment.transform 22 169353 env21399 = env21441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env21399 == env21441) = true)

def env21442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169353,95497,8328,64,2048,163977,45525,284041,156817,411972,257,21792,46212,213830]

theorem envBound21442 : H12AffineFastState.Bounded env21442 := by
  intro p hp
  have h : env21442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21441_21442 : H12AffineEnvironment.transform 21 272512 env21441 = env21442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21441 == env21442) = true)

theorem identity21442 : scanCanonicalize (H12AffineFastState.compose env21442 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound21442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,58516,272512,17,95497,8328,64,2048,5393,45525,284041,61705,318684,257,21792,46212,120542]

theorem envBound21443 : H12AffineFastState.Bounded env21443 := by
  intro p hp
  have h : env21443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21442_21443 : H12AffineEnvironment.transform 16 38296 env21442 = env21443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env21442 == env21443) = true)

def env21444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95497,8192,64,2048,5393,45405,283905,61705,318548,257,21792,46092,120406]

theorem envBound21444 : H12AffineFastState.Bounded env21444 := by
  intro p hp
  have h : env21444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21443_21444 : H12AffineEnvironment.transform 6 8 env21443 = env21444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21443 == env21444) = true)

theorem identity21444 : scanCanonicalize (H12AffineFastState.compose env21444 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound21444 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1025,32769,58396,119927,17,95497,8192,64,2048,5393,45405,108926,61705,73771,257,21792,46092,120406]

theorem envBound21445 : H12AffineFastState.Bounded env21445 := by
  intro p hp
  have h : env21445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21444_21445 : H12AffineEnvironment.transform 17 130175 env21444 = env21445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env21444 == env21445) = true)

theorem identity21445 : scanCanonicalize (H12AffineFastState.compose env21445 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound21445 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env21446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,38160,43049,1025,32769,58396,32801,17,8543,8192,64,2048,5393,45405,64808,61705,29821,257,21792,46092,33280]

theorem envBound21446 : H12AffineFastState.Bounded env21446 := by
  intro p hp
  have h : env21446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21445_21446 : H12AffineEnvironment.transform 15 21590 env21445 = env21446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env21445 == env21446) = true)

theorem identity21446 : scanCanonicalize (H12AffineFastState.compose env21446 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21446 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env21447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,343,38160,43049,1025,32769,45341,32801,17,8543,8192,64,2048,5393,45405,43049,41992,8572,257,33,46092,33280]

theorem envBound21447 : H12AffineFastState.Bounded env21447 := by
  intro p hp
  have h : env21447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21446_21447 : H12AffineEnvironment.transform 13 5377 env21446 = env21447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21446 == env21447) = true)

theorem identity21447 : scanCanonicalize (H12AffineFastState.compose env21447 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21447 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env21448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,343,13388,2421,1025,8541,4161,8573,17,8543,8192,64,2048,5393,4097,2421,1364,8572,257,33,5456,9052]

theorem envBound21448 : H12AffineFastState.Bounded env21448 := by
  intro p hp
  have h : env21448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21447_21448 : H12AffineEnvironment.transform 14 8540 env21447 = env21448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21447 == env21448) = true)

theorem identity21448 : scanCanonicalize (H12AffineFastState.compose env21448 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound21448 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5432,5377,5220,343,372,2421,1025,5221,4161,5189,17,5223,5432,64,2048,5393,4097,2421,1364,5188,257,33,5456,5732]

theorem envBound21449 : H12AffineFastState.Bounded env21449 := by
  intro p hp
  have h : env21449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21448_21449 : H12AffineEnvironment.transform 12 5432 env21448 = env21449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env21448 == env21449) = true)

theorem identity21449 : scanCanonicalize (H12AffineFastState.compose env21449 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21449 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,41,16,373,343,372,2421,1025,372,1360,340,17,374,41,64,2048,0,1296,2421,1364,341,257,33,65,885]

theorem envBound21450 : H12AffineFastState.Bounded env21450 := by
  intro p hp
  have h : env21450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21449_21450 : H12AffineEnvironment.transform 11 1297 env21449 = env21450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21449 == env21450) = true)

theorem identity21450 : scanCanonicalize (H12AffineFastState.compose env21450 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21450 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21451 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1124,41,16,0,34,1,2048,1025,1,1061,33,17,3,41,64,2048,0,1125,2048,1057,32,116,33,65,512]

theorem envBound21451 : H12AffineFastState.Bounded env21451 := by
  intro p hp
  have h : env21451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21450_21451 : H12AffineEnvironment.transform 7 117 env21450 = env21451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21450 == env21451) = true)

theorem identity21451 : scanCanonicalize (H12AffineFastState.compose env21451 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound21451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21452 : List Nat := [2,4,8,16,32,64,8,117,112,1024,2048,1124,41,16,0,34,1,2048,1025,1,1061,33,17,3,41,64,2048,0,1125,2048,1057,32,116,33,65,112]

theorem envBound21452 : H12AffineFastState.Bounded env21452 := by
  intro p hp
  have h : env21452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21451_21452 : H12AffineEnvironment.transform 8 112 env21451 = env21452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env21451 == env21452) = true)

theorem identity21452 : scanCanonicalize (H12AffineFastState.compose env21452 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21453 : List Nat := [2,4,8,16,32,48,8,5,0,1024,2048,1044,41,16,0,34,1,2048,1025,1,1061,33,17,3,41,48,2048,0,1045,2048,1057,32,4,33,49,0]

theorem envBound21453 : H12AffineFastState.Bounded env21453 := by
  intro p hp
  have h : env21453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21452_21453 : H12AffineEnvironment.transform 5 48 env21452 = env21453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21452 == env21453) = true)

theorem identity21453 : scanCanonicalize (H12AffineFastState.compose env21453 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21453 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21454 : List Nat := [2,4,8,16,1,17,8,5,0,1024,2048,1044,8,16,0,3,1,2048,1025,1,1028,0,17,3,8,17,2048,0,1045,2048,1024,1,4,0,16,0]

theorem envBound21454 : H12AffineFastState.Bounded env21454 := by
  intro p hp
  have h : env21454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21453_21454 : H12AffineEnvironment.transform 4 1 env21453 = env21454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21453 == env21454) = true)

theorem identity21454 : scanCanonicalize (H12AffineFastState.compose env21454 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21455 : List Nat := [2,4,8,16,1,17,8,5,0,20,2048,0,8,16,0,3,1,2048,21,1,16,0,17,3,8,17,2048,0,1,2048,20,1,4,0,16,0]

theorem envBound21455 : H12AffineFastState.Bounded env21455 := by
  intro p hp
  have h : env21455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21454_21455 : H12AffineEnvironment.transform 9 20 env21454 = env21455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21454 == env21455) = true)

theorem identity21455 : scanCanonicalize (H12AffineFastState.compose env21455 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21455 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21456 : List Nat := [2,4,8,16,1,17,8,5,0,20,1,0,8,16,0,3,1,1,21,1,16,0,17,3,8,17,1,0,1,1,20,1,4,0,16,0]

theorem envBound21456 : H12AffineFastState.Bounded env21456 := by
  intro p hp
  have h : env21456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21455_21456 : H12AffineEnvironment.transform 10 1 env21455 = env21456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21455 == env21456) = true)

theorem identity21456 : scanCanonicalize (H12AffineFastState.compose env21456 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound21456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21457 : List Nat := [2,4,6,16,1,17,6,5,0,20,1,0,6,16,0,3,1,1,21,1,16,0,17,3,6,17,1,0,1,1,20,1,4,0,16,0]

theorem envBound21457 : H12AffineFastState.Bounded env21457 := by
  intro p hp
  have h : env21457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21456_21457 : H12AffineEnvironment.transform 2 6 env21456 = env21457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env21456 == env21457) = true)

def env21458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95497,8193,64,2048,5393,45404,283904,61705,318549,257,21792,46093,120407]

theorem envBound21458 : H12AffineFastState.Bounded env21458 := by
  intro p hp
  have h : env21458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21443_21458 : H12AffineEnvironment.transform 6 9 env21443 = env21458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21443 == env21458) = true)

theorem identity21458 : scanCanonicalize (H12AffineFastState.compose env21458 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound21458 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89378,1025,32769,58397,95531,17,95497,8193,64,2048,5393,45404,67618,61705,98679,257,21792,46093,120407]

theorem envBound21459 : H12AffineFastState.Bounded env21459 := by
  intro p hp
  have h : env21459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21458_21459 : H12AffineEnvironment.transform 17 89378 env21458 = env21459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env21458 == env21459) = true)

theorem identity21459 : scanCanonicalize (H12AffineFastState.compose env21459 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound21459 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env21460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29823,38161,10589,1025,32769,58397,340,17,374,8193,64,2048,5393,45404,31837,61705,62728,257,21792,46093,41512]

theorem envBound21460 : H12AffineFastState.Bounded env21460 := by
  intro p hp
  have h : env21460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21459_21460 : H12AffineEnvironment.transform 15 29823 env21459 = env21460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env21459 == env21460) = true)

theorem identity21460 : scanCanonicalize (H12AffineFastState.compose env21460 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21460 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env21461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21795,38161,2049,1025,32769,50497,340,17,374,349,64,2048,5393,36864,23809,53333,54356,257,21792,38225,33652]

theorem envBound21461 : H12AffineFastState.Bounded env21461 := by
  intro p hp
  have h : env21461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21460_21461 : H12AffineEnvironment.transform 12 348 env21460 = env21461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21460 == env21461) = true)

theorem identity21461 : scanCanonicalize (H12AffineFastState.compose env21461 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound21461 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,373,21795,5220,2049,1025,372,17460,340,17,374,349,64,2048,5393,4469,23809,20768,21793,257,21792,5156,513]

theorem envBound21462 : H12AffineFastState.Bounded env21462 := by
  intro p hp
  have h : env21462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21461_21462 : H12AffineEnvironment.transform 14 373 env21461 = env21462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env21461 == env21462) = true)

theorem identity21462 : scanCanonicalize (H12AffineFastState.compose env21462 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21462 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,373,342,5220,2049,1025,372,4161,340,17,374,349,64,2048,5393,4469,2420,1365,340,257,341,5156,513]

theorem envBound21463 : H12AffineFastState.Bounded env21463 := by
  intro p hp
  have h : env21463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21462_21463 : H12AffineEnvironment.transform 13 5237 env21462 = env21463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21462 == env21463) = true)

def env21464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169353,95497,8328,64,2049,163977,45525,284041,156817,411973,257,21792,46212,213830]

theorem envBound21464 : H12AffineFastState.Bounded env21464 := by
  intro p hp
  have h : env21464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21441_21464 : H12AffineEnvironment.transform 21 272513 env21441 = env21464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21441 == env21464) = true)

def env21465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169217,95497,8192,64,2049,163841,45405,283905,156697,411973,257,21792,46092,213830]

theorem envBound21465 : H12AffineFastState.Bounded env21465 := by
  intro p hp
  have h : env21465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21464_21465 : H12AffineEnvironment.transform 6 8 env21464 = env21465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21464 == env21465) = true)

def env21466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95497,8192,64,2049,5393,45405,283905,61705,318549,257,21792,46092,120406]

theorem envBound21466 : H12AffineFastState.Bounded env21466 := by
  intro p hp
  have h : env21466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21465_21466 : H12AffineEnvironment.transform 16 38160 env21465 = env21466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21465 == env21466) = true)

theorem identity21466 : scanCanonicalize (H12AffineFastState.compose env21466 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound21466 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1025,32769,58396,119926,17,95497,8192,64,2049,5393,45405,108926,61705,73770,257,21792,46092,120406]

theorem envBound21467 : H12AffineFastState.Bounded env21467 := by
  intro p hp
  have h : env21467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21466_21467 : H12AffineEnvironment.transform 17 130175 env21466 = env21467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env21466 == env21467) = true)

theorem identity21467 : scanCanonicalize (H12AffineFastState.compose env21467 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound21467 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env21468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,38160,43129,1025,32769,58396,32880,17,8463,8192,64,2049,5393,45405,64888,61705,29740,257,21792,46092,33360]

theorem envBound21468 : H12AffineFastState.Bounded env21468 := by
  intro p hp
  have h : env21468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21467_21468 : H12AffineEnvironment.transform 15 21510 env21467 = env21468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env21467 == env21468) = true)

theorem identity21468 : scanCanonicalize (H12AffineFastState.compose env21468 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound21468 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env21469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,343,38160,43129,1025,32769,45389,32880,17,8463,8192,64,2049,5393,45405,43049,42072,8573,257,113,46092,33360]

theorem envBound21469 : H12AffineFastState.Bounded env21469 := by
  intro p hp
  have h : env21469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21468_21469 : H12AffineEnvironment.transform 13 5457 env21468 = env21469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env21468 == env21469) = true)

end H12CloudChart0