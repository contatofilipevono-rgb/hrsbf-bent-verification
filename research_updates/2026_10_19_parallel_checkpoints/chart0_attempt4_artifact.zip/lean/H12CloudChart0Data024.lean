import H12CloudChart0Data023

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env5944 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,1542,16384,1550,22060,4096,2080,1025,1550,4097,20512,20496,34,1574,20497,22529,16385,16384,22560,21504,20481,5,20481,16384,20993]

theorem envBound5944 : H12AffineFastState.Bounded env5944 := by
  intro p hp
  have h : env5944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5943_5944 : H12AffineEnvironment.transform 12 1542 env5943 = env5944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env5943 == env5944) = true)

theorem identity5944 : scanCanonicalize (H12AffineFastState.compose env5944 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound5944 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5945 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,2602,1542,16384,1550,19462,2602,2080,1025,1550,2603,18954,19002,34,1574,19003,16939,16385,16384,16906,20010,18987,5,18987,16384,18475]

theorem envBound5945 : H12AffineFastState.Bounded env5945 := by
  intro p hp
  have h : env5945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5944_5945 : H12AffineEnvironment.transform 11 2602 env5944 = env5945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env5944 == env5945) = true)

theorem identity5945 : scanCanonicalize (H12AffineFastState.compose env5945 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5945 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5946 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,2602,1542,1573,1550,2595,2602,2080,1025,1550,2603,3119,3103,34,1574,3102,1038,1572,1573,1071,2063,3086,5,3086,1573,3598]

theorem envBound5946 : H12AffineFastState.Bounded env5946 := by
  intro p hp
  have h : env5946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5945_5946 : H12AffineEnvironment.transform 13 1573 env5945 = env5946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env5945 == env5946) = true)

theorem identity5946 : scanCanonicalize (H12AffineFastState.compose env5946 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound5946 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5947 : List Nat := [2,4,8,16,32,16,41,4,48,1024,2048,2074,1078,1045,1086,2067,2074,2080,1025,1086,2075,3119,3103,34,1046,3102,1038,1044,1045,1071,2063,3086,5,3086,1045,3134]

theorem envBound5947 : H12AffineFastState.Bounded env5947 := by
  intro p hp
  have h : env5947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5946_5947 : H12AffineEnvironment.transform 8 48 env5946 = env5947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env5946 == env5947) = true)

theorem identity5947 : scanCanonicalize (H12AffineFastState.compose env5947 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5947 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5948 : List Nat := [2,4,8,16,32,16,41,4,48,36,2048,2074,18,49,26,2067,2074,2080,37,26,2075,2059,2107,34,50,2106,42,48,49,11,2063,2090,5,2090,49,2074]

theorem envBound5948 : H12AffineFastState.Bounded env5948 := by
  intro p hp
  have h : env5948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5947_5948 : H12AffineEnvironment.transform 9 36 env5947 = env5948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5947 == env5948) = true)

theorem identity5948 : scanCanonicalize (H12AffineFastState.compose env5948 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound5948 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5949 : List Nat := [2,4,8,16,32,16,41,4,48,36,43,49,18,49,26,56,49,11,37,26,48,32,16,34,50,17,42,48,49,11,36,1,5,1,49,49]

theorem envBound5949 : H12AffineFastState.Bounded env5949 := by
  intro p hp
  have h : env5949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5948_5949 : H12AffineEnvironment.transform 10 43 env5948 = env5949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env5948 == env5949) = true)

theorem identity5949 : scanCanonicalize (H12AffineFastState.compose env5949 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5950 : List Nat := [2,0,8,16,32,16,41,0,48,32,43,49,18,49,26,56,49,11,33,26,48,32,16,34,50,17,42,48,49,11,32,1,1,1,49,49]

theorem envBound5950 : H12AffineFastState.Bounded env5950 := by
  intro p hp
  have h : env5950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5949_5950 : H12AffineEnvironment.transform 1 0 env5949 = env5950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5949 == env5950) = true)

theorem identity5950 : scanCanonicalize (H12AffineFastState.compose env5950 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound5950 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env5951 : List Nat := [2,0,8,16,16,16,25,0,0,16,27,1,18,1,26,8,1,11,17,26,0,16,16,18,2,17,26,0,1,11,16,1,1,1,1,1]

theorem envBound5951 : H12AffineFastState.Bounded env5951 := by
  intro p hp
  have h : env5951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5950_5951 : H12AffineEnvironment.transform 4 16 env5950 = env5951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env5950 == env5951) = true)

theorem identity5951 : scanCanonicalize (H12AffineFastState.compose env5951 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5952 : List Nat := [2,0,3,16,16,16,18,0,0,16,16,1,18,1,17,3,1,0,17,17,0,16,16,18,2,17,17,0,1,0,16,1,1,1,1,1]

theorem envBound5952 : H12AffineFastState.Bounded env5952 := by
  intro p hp
  have h : env5952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5951_5952 : H12AffineEnvironment.transform 2 3 env5951 = env5952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5951 == env5952) = true)

theorem identity5952 : scanCanonicalize (H12AffineFastState.compose env5952 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5952 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env5953 : List Nat := [2,0,3,0,0,0,2,0,0,0,0,1,2,1,1,3,1,0,1,1,0,0,0,2,2,1,1,0,1,0,0,1,1,1,1,1]

theorem envBound5953 : H12AffineFastState.Bounded env5953 := by
  intro p hp
  have h : env5953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5952_5953 : H12AffineEnvironment.transform 3 0 env5952 = env5953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5952 == env5953) = true)

def env5954 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98475,8388608,41002,8329,8388608,323713,16385,16812,22561,74794,8483222,257,20480,77866,8389565]

theorem envBound5954 : H12AffineFastState.Bounded env5954 := by
  intro p hp
  have h : env5954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5920_5954 : H12AffineEnvironment.transform 5 17 env5920 = env5954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5920 == env5954) = true)

theorem identity5954 : scanCanonicalize (H12AffineFastState.compose env5954 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5954 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98475,445,41002,8329,445,323713,16385,16812,22561,74794,94251,257,20480,77866,512]

theorem envBound5955 : H12AffineFastState.Bounded env5955 := by
  intro p hp
  have h : env5955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5954_5955 : H12AffineEnvironment.transform 22 445 env5954 = env5955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5954 == env5955) = true)

theorem identity5955 : scanCanonicalize (H12AffineFastState.compose env5955 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound5955 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5956 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1025,32768,4097,41348,445,41002,8329,445,323713,16385,16812,22561,1285,20740,257,20480,4357,512]

theorem envBound5956 : H12AffineFastState.Bounded env5956 := by
  intro p hp
  have h : env5956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5955_5956 : H12AffineEnvironment.transform 15 8495 env5955 = env5956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env5955 == env5956) = true)

theorem identity5956 : scanCanonicalize (H12AffineFastState.compose env5956 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5956 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1025,26261,4097,18193,445,18111,8329,445,267796,16385,16812,22561,1285,20740,257,20480,4357,512]

theorem envBound5957 : H12AffineFastState.Bounded env5957 := by
  intro p hp
  have h : env5957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5956_5957 : H12AffineEnvironment.transform 14 26261 env5956 = env5957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5956 == env5957) = true)

theorem identity5957 : scanCanonicalize (H12AffineFastState.compose env5957 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound5957 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,262144,1025,14136,4097,5820,445,5906,8329,445,267796,4524,4097,2444,1285,169,257,429,4357,512]

theorem envBound5958 : H12AffineFastState.Bounded env5958 := by
  intro p hp
  have h : env5958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5957_5958 : H12AffineEnvironment.transform 13 4525 env5957 = env5958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env5957 == env5958) = true)

theorem identity5958 : scanCanonicalize (H12AffineFastState.compose env5958 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound5958 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5959 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,2184,1025,14136,4097,5820,445,5906,8329,445,7836,4524,4097,2444,1285,169,257,429,4357,512]

theorem envBound5959 : H12AffineFastState.Bounded env5959 := by
  intro p hp
  have h : env5959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5958_5959 : H12AffineEnvironment.transform 17 2184 env5958 = env5959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env5958 == env5959) = true)

theorem identity5959 : scanCanonicalize (H12AffineFastState.compose env5959 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5959 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env5960 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4356,14136,8495,4357,2081,1025,14136,4097,5653,276,5906,8224,276,7733,4357,4097,2341,1285,0,257,260,4357,512]

theorem envBound5960 : H12AffineFastState.Bounded env5960 := by
  intro p hp
  have h : env5960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5959_5960 : H12AffineEnvironment.transform 6 41 env5959 = env5960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5959 == env5960) = true)

theorem identity5960 : scanCanonicalize (H12AffineFastState.compose env5960 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5960 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5961 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,8192,4097,13885,8234,4096,2081,1025,13885,4097,5653,17,5655,8224,17,7733,4096,4097,2080,1024,0,4,1,4096,512]

theorem envBound5961 : H12AffineFastState.Bounded env5961 := by
  intro p hp
  have h : env5961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5960_5961 : H12AffineEnvironment.transform 7 5 env5960 = env5961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5960 == env5961) = true)

theorem identity5961 : scanCanonicalize (H12AffineFastState.compose env5961 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 7741) := by decide +kernel

theorem selectedBound5961 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5962 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,7741,4097,2048,7703,4096,2081,1025,2048,4097,5653,17,5655,7709,17,7733,4096,4097,2080,1024,0,4,1,4096,512]

theorem envBound5962 : H12AffineFastState.Bounded env5962 := by
  intro p hp
  have h : env5962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5961_5962 : H12AffineEnvironment.transform 12 7741 env5961 = env5962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7741 env5961 == env5962) = true)

theorem identity5962 : scanCanonicalize (H12AffineFastState.compose env5962 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5963 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1550,4096,4147,4097,1550,4121,4096,1583,1025,1550,4097,5653,17,5655,4115,17,4155,4096,4097,1582,1024,0,4,1,4096,512]

theorem envBound5963 : H12AffineFastState.Bounded env5963 := by
  intro p hp
  have h : env5963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5962_5963 : H12AffineEnvironment.transform 10 1550 env5962 = env5963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env5962 == env5963) = true)

theorem identity5963 : scanCanonicalize (H12AffineFastState.compose env5963 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5963 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env5964 : List Nat := [2,4,8,16,32,17,41,5,32,1024,1070,4096,4147,4097,1070,4121,4096,1039,1025,1070,4097,5173,17,5175,4115,17,4155,4096,4097,1038,1024,0,4,1,4096,32]

theorem envBound5964 : H12AffineFastState.Bounded env5964 := by
  intro p hp
  have h : env5964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5963_5964 : H12AffineEnvironment.transform 8 32 env5963 = env5964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5963 == env5964) = true)

theorem identity5964 : scanCanonicalize (H12AffineFastState.compose env5964 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5964 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5965 : List Nat := [2,4,8,16,32,17,41,5,32,15,33,4096,4147,4097,33,4121,4096,0,14,33,4097,4154,17,4152,4115,17,4155,4096,4097,1,15,0,4,1,4096,32]

theorem envBound5965 : H12AffineFastState.Bounded env5965 := by
  intro p hp
  have h : env5965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5964_5965 : H12AffineEnvironment.transform 9 15 env5964 = env5965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5964 == env5965) = true)

theorem identity5965 : scanCanonicalize (H12AffineFastState.compose env5965 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound5965 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5966 : List Nat := [2,4,8,16,32,17,41,5,32,15,33,33,18,32,33,56,33,0,14,33,32,27,17,25,50,17,26,33,32,1,15,0,4,1,33,32]

theorem envBound5966 : H12AffineFastState.Bounded env5966 := by
  intro p hp
  have h : env5966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5965_5966 : H12AffineEnvironment.transform 11 33 env5965 = env5966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env5965 == env5966) = true)

theorem identity5966 : scanCanonicalize (H12AffineFastState.compose env5966 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5967 : List Nat := [2,4,8,16,0,17,9,5,0,15,1,1,18,0,1,24,1,0,14,1,0,27,17,25,18,17,26,1,0,1,15,0,4,1,1,0]

theorem envBound5967 : H12AffineFastState.Bounded env5967 := by
  intro p hp
  have h : env5967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5966_5967 : H12AffineEnvironment.transform 4 0 env5966 = env5967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5966 == env5967) = true)

def env5968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914001,2942161,16384,16892,2641009,598058,14737725,525568,2638928,6332545,8914925]

theorem envBound5968 : H12AffineFastState.Bounded env5968 := by
  intro p hp
  have h : env5968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5716_5968 : H12AffineEnvironment.transform 25 8914001 env5716 = env5968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env5716 == env5968) = true)

def env5969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849105,16384,16892,547953,598058,12644669,525568,545872,4239489,8914925]

theorem envBound5969 : H12AffineFastState.Bounded env5969 := by
  intro p hp
  have h : env5969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5968_5969 : H12AffineEnvironment.transform 20 4096 env5968 = env5969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5968 == env5969) = true)

def env5970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323793,16384,16892,22641,74794,12644669,256,20560,4239489,8389613]

theorem envBound5970 : H12AffineFastState.Bounded env5970 := by
  intro p hp
  have h : env5970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5969_5970 : H12AffineEnvironment.transform 18 1024 env5969 = env5970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5969 == env5970) = true)

theorem identity5970 : scanCanonicalize (H12AffineFastState.compose env5970 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73922) := by decide +kernel

theorem selectedBound5970 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,73922,41002,8329,73875,323793,16384,16892,22641,74794,4313599,256,20560,4239489,74543]

theorem envBound5971 : H12AffineFastState.Bounded env5971 := by
  intro p hp
  have h : env5971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5970_5971 : H12AffineEnvironment.transform 22 73922 env5970 = env5971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73922 env5970 == env5971) = true)

def env5972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,73874,41002,8329,73875,323713,16384,16812,22561,74794,4313519,256,20480,4239489,74543]

theorem envBound5972 : H12AffineFastState.Bounded env5972 := by
  intro p hp
  have h : env5972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5971_5972 : H12AffineEnvironment.transform 5 16 env5971 = env5972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5971 == env5972) = true)

def env5973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41088,73874,41002,8329,73875,323713,16384,16812,22561,74794,94511,256,20480,4097,74543]

theorem envBound5973 : H12AffineFastState.Bounded env5973 := by
  intro p hp
  have h : env5973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5972_5973 : H12AffineEnvironment.transform 21 41088 env5972 = env5973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5972 == env5973) = true)

theorem identity5973 : scanCanonicalize (H12AffineFastState.compose env5973 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5973 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5974 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4096,41088,73874,41002,8329,73875,323713,16384,16552,22561,74794,94251,4,20480,4097,74283]

theorem envBound5974 : H12AffineFastState.Bounded env5974 := by
  intro p hp
  have h : env5974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5973_5974 : H12AffineEnvironment.transform 7 4 env5973 = env5974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5973 == env5974) = true)

theorem identity5974 : scanCanonicalize (H12AffineFastState.compose env5974 (packedSelected [0,3,5,7,8,10,11,13,17,18,20,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5974 : packedSelected [0,3,5,7,8,10,11,13,17,18,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5975 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,26260,65536,4265,262144,1024,26260,4096,17940,73874,18110,8329,73875,267797,16384,16552,22561,74794,94251,4,20480,4097,74283]

theorem envBound5975 : H12AffineFastState.Bounded env5975 := by
  intro p hp
  have h : env5975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5974_5975 : H12AffineEnvironment.transform 14 26260 env5974 = env5975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5974 == env5975) = true)

def env5976 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,65536,4265,262144,1024,13972,4096,5652,73874,5822,8329,73875,267797,4096,4264,2081,74794,73771,4,0,4097,74283]

theorem envBound5976 : H12AffineFastState.Bounded env5976 := by
  intro p hp
  have h : env5976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5975_5976 : H12AffineEnvironment.transform 13 4096 env5975 = env5976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5975 == env5976) = true)

theorem identity5976 : scanCanonicalize (H12AffineFastState.compose env5976 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 13838) := by decide +kernel

theorem selectedBound5976 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env5977 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,13838,4265,262144,1024,13972,4096,5652,5788,5822,8329,5789,267797,4096,4264,2081,4644,5669,4,0,4097,5157]

theorem envBound5977 : H12AffineFastState.Bounded env5977 := by
  intro p hp
  have h : env5977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5976_5977 : H12AffineEnvironment.transform 15 13838 env5976 = env5977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13838 env5976 == env5977) = true)

theorem identity5977 : scanCanonicalize (H12AffineFastState.compose env5977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5978 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,4096,8192,4096,13957,13838,4265,262144,1024,13957,4096,5637,5773,5807,8329,5772,267780,4096,4264,2081,4644,5669,4,0,4097,5157]

theorem envBound5978 : H12AffineFastState.Bounded env5978 := by
  intro p hp
  have h : env5978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5977_5978 : H12AffineEnvironment.transform 3 1 env5977 = env5978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5977 == env5978) = true)

theorem identity5978 : scanCanonicalize (H12AffineFastState.compose env5978 (packedSelected [6,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound5978 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env5979 : List Nat := [2,4,8,1,32,1,128,4,512,1024,675,4096,8192,4096,13957,13838,4265,262144,1024,13957,4096,5637,5773,5807,8329,5772,267780,4096,4264,642,4644,5669,4,0,4097,5157]

theorem envBound5979 : H12AffineFastState.Bounded env5979 := by
  intro p hp
  have h : env5979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5978_5979 : H12AffineEnvironment.transform 10 675 env5978 = env5979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env5978 == env5979) = true)

theorem identity5979 : scanCanonicalize (H12AffineFastState.compose env5979 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5979 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env5980 : List Nat := [2,4,8,1,32,1,40,4,512,1024,523,4096,8192,4096,13869,13838,4097,262144,1024,13869,4096,5637,5669,5639,8225,5668,267780,4096,4096,554,4644,5669,4,0,4097,5157]

theorem envBound5980 : H12AffineFastState.Bounded env5980 := by
  intro p hp
  have h : env5980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5979_5980 : H12AffineEnvironment.transform 6 40 env5979 = env5980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5979 == env5980) = true)

theorem identity5980 : scanCanonicalize (H12AffineFastState.compose env5980 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 5134) := by decide +kernel

theorem selectedBound5980 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5981 : List Nat := [2,4,8,1,32,1,40,4,512,1024,523,4096,8192,4096,13869,13838,4097,5134,1024,13869,4096,5637,5669,5639,8225,5668,522,4096,4096,554,4644,5669,4,0,4097,5157]

theorem envBound5981 : H12AffineFastState.Bounded env5981 := by
  intro p hp
  have h : env5981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5980_5981 : H12AffineEnvironment.transform 17 5134 env5980 = env5981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5134 env5980 == env5981) = true)

theorem identity5981 : scanCanonicalize (H12AffineFastState.compose env5981 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5981 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5982 : List Nat := [2,4,8,1,32,1,40,4,512,1024,523,1540,8192,1540,8233,8202,1541,522,1024,8233,1540,1,33,3,8225,32,522,1540,1540,554,1056,33,4,0,1541,545]

theorem envBound5982 : H12AffineFastState.Bounded env5982 := by
  intro p hp
  have h : env5982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5981_5982 : H12AffineEnvironment.transform 11 1540 env5981 = env5982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env5981 == env5982) = true)

theorem identity5982 : scanCanonicalize (H12AffineFastState.compose env5982 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound5982 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env5983 : List Nat := [2,4,8,1,32,1,40,4,512,1024,523,1540,1575,1540,1550,1581,1541,522,1024,1550,1540,1,33,3,1542,32,522,1540,1540,554,1056,33,4,0,1541,545]

theorem envBound5983 : H12AffineFastState.Bounded env5983 := by
  intro p hp
  have h : env5983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5982_5983 : H12AffineEnvironment.transform 12 1575 env5982 = env5983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env5982 == env5983) = true)

theorem identity5983 : scanCanonicalize (H12AffineFastState.compose env5983 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound5983 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env5984 : List Nat := [2,4,8,1,32,1,40,4,512,47,523,555,520,555,545,514,554,522,47,545,555,1,33,3,553,32,522,555,555,554,15,33,4,0,554,545]

theorem envBound5984 : H12AffineFastState.Bounded env5984 := by
  intro p hp
  have h : env5984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5983_5984 : H12AffineEnvironment.transform 9 47 env5983 = env5984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env5983 == env5984) = true)

theorem identity5984 : scanCanonicalize (H12AffineFastState.compose env5984 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5984 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env5985 : List Nat := [2,4,8,1,32,1,40,4,1,47,10,42,9,42,32,3,43,11,47,32,42,1,33,3,40,32,11,42,42,43,15,33,4,0,43,32]

theorem envBound5985 : H12AffineFastState.Bounded env5985 := by
  intro p hp
  have h : env5985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5984_5985 : H12AffineEnvironment.transform 8 1 env5984 = env5985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5984 == env5985) = true)

theorem identity5985 : scanCanonicalize (H12AffineFastState.compose env5985 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5986 : List Nat := [2,4,2,1,32,1,34,4,1,37,0,32,3,32,32,3,33,1,37,32,32,1,33,3,34,32,1,32,32,33,5,33,4,0,33,32]

theorem envBound5986 : H12AffineFastState.Bounded env5986 := by
  intro p hp
  have h : env5986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5985_5986 : H12AffineEnvironment.transform 2 2 env5985 = env5986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5985 == env5986) = true)

theorem identity5986 : scanCanonicalize (H12AffineFastState.compose env5986 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5987 : List Nat := [2,4,2,1,1,1,3,4,1,4,0,1,3,1,1,3,0,1,4,1,1,1,0,3,3,1,1,1,1,0,5,0,4,0,0,1]

theorem envBound5987 : H12AffineFastState.Bounded env5987 := by
  intro p hp
  have h : env5987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5986_5987 : H12AffineEnvironment.transform 4 1 env5986 = env5987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5986 == env5987) = true)

def env5988 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,65536,4265,262144,1024,13973,4096,5653,73874,5823,8329,73875,267797,4097,4265,2080,74794,73770,4,1,4097,74283]

theorem envBound5988 : H12AffineFastState.Bounded env5988 := by
  intro p hp
  have h : env5988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5975_5988 : H12AffineEnvironment.transform 13 4097 env5975 = env5988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5975 == env5988) = true)

theorem identity5988 : scanCanonicalize (H12AffineFastState.compose env5988 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 14006) := by decide +kernel

theorem selectedBound5988 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env5989 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,14006,4265,262144,1024,13973,4096,5653,5668,5823,8329,5669,267797,4097,4265,2080,4764,5788,4,1,4097,5277]

theorem envBound5989 : H12AffineFastState.Bounded env5989 := by
  intro p hp
  have h : env5989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5988_5989 : H12AffineEnvironment.transform 15 14006 env5988 = env5989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14006 env5988 == env5989) = true)

theorem identity5989 : scanCanonicalize (H12AffineFastState.compose env5989 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1670) := by decide +kernel

theorem selectedBound5989 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5990 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,14006,4265,1670,1024,13973,4096,5653,5668,5823,8329,5669,4243,4097,4265,2080,4764,5788,4,1,4097,5277]

theorem envBound5990 : H12AffineFastState.Bounded env5990 := by
  intro p hp
  have h : env5990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5989_5990 : H12AffineEnvironment.transform 17 1670 env5989 = env5990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1670 env5989 == env5990) = true)

theorem identity5990 : scanCanonicalize (H12AffineFastState.compose env5990 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5990 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5991 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1551,4096,8192,4097,13973,14006,4265,1670,1024,13973,4096,5653,5668,5823,8329,5669,4243,4097,4265,1583,4764,5788,4,1,4097,5277]

theorem envBound5991 : H12AffineFastState.Bounded env5991 := by
  intro p hp
  have h : env5991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5990_5991 : H12AffineEnvironment.transform 10 1551 env5990 = env5991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5990 == env5991) = true)

theorem identity5991 : scanCanonicalize (H12AffineFastState.compose env5991 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5991 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5992 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1551,1589,8192,1588,8352,8323,1692,1670,1024,8352,1589,32,17,138,8329,16,1702,1588,1692,1583,1193,169,4,1,1588,680]

theorem envBound5992 : H12AffineFastState.Bounded env5992 := by
  intro p hp
  have h : env5992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5991_5992 : H12AffineEnvironment.transform 11 1589 env5991 = env5992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env5991 == env5992) = true)

theorem identity5992 : scanCanonicalize (H12AffineFastState.compose env5992 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5993 : List Nat := [2,4,8,11,32,11,128,4,512,1024,1551,1582,8192,1583,8352,8323,1671,1670,1024,8352,1582,32,10,138,8329,11,1702,1583,1671,1583,1193,169,4,1,1583,680]

theorem envBound5993 : H12AffineFastState.Bounded env5993 := by
  intro p hp
  have h : env5993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5992_5993 : H12AffineEnvironment.transform 3 11 env5992 = env5993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5992 == env5993) = true)

theorem identity5993 : scanCanonicalize (H12AffineFastState.compose env5993 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1198) := by decide +kernel

theorem selectedBound5993 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5994 : List Nat := [2,4,8,11,32,11,128,4,512,1024,1551,1582,1198,1583,1038,1069,1671,1670,1024,1038,1582,32,10,138,1063,11,1702,1583,1671,1583,1193,169,4,1,1583,680]

theorem envBound5994 : H12AffineFastState.Bounded env5994 := by
  intro p hp
  have h : env5994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5993_5994 : H12AffineEnvironment.transform 12 1198 env5993 = env5994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1198 env5993 == env5994) = true)

theorem identity5994 : scanCanonicalize (H12AffineFastState.compose env5994 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5994 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env5995 : List Nat := [2,4,8,11,32,11,40,4,512,1024,1551,1582,1030,1583,1038,1069,1583,1582,1024,1038,1582,32,10,34,1063,11,1550,1583,1583,1583,1025,1,4,1,1583,512]

theorem envBound5995 : H12AffineFastState.Bounded env5995 := by
  intro p hp
  have h : env5995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5994_5995 : H12AffineEnvironment.transform 6 40 env5994 = env5995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5994 == env5995) = true)

theorem identity5995 : scanCanonicalize (H12AffineFastState.compose env5995 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5995 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5996 : List Nat := [2,4,8,11,32,11,40,4,1,1024,1038,1071,1030,1070,1038,1069,1070,1071,1024,1038,1071,32,10,34,1063,11,1039,1070,1070,1070,1025,1,4,1,1070,1]

theorem envBound5996 : H12AffineFastState.Bounded env5996 := by
  intro p hp
  have h : env5996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5995_5996 : H12AffineEnvironment.transform 8 1 env5995 = env5996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5995 == env5996) = true)

theorem identity5996 : scanCanonicalize (H12AffineFastState.compose env5996 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5997 : List Nat := [2,4,8,11,32,11,40,4,1,15,1,32,9,33,1,34,33,32,15,1,32,32,10,34,40,11,0,33,33,33,14,1,4,1,33,1]

theorem envBound5997 : H12AffineFastState.Bounded env5997 := by
  intro p hp
  have h : env5997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5996_5997 : H12AffineEnvironment.transform 9 15 env5996 = env5997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5996 == env5997) = true)

def env5998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41089,73874,41002,8329,73875,323713,16384,16812,22561,74794,94510,256,20480,4096,74543]

theorem envBound5998 : H12AffineFastState.Bounded env5998 := by
  intro p hp
  have h : env5998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5972_5998 : H12AffineEnvironment.transform 21 41089 env5972 = env5998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5972 == env5998) = true)

theorem identity5998 : scanCanonicalize (H12AffineFastState.compose env5998 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound5998 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8234,4525,262144,1024,32768,4096,41089,184,41002,8329,185,323713,16384,16812,22561,1024,20740,256,20480,4096,773]

theorem envBound5999 : H12AffineFastState.Bounded env5999 := by
  intro p hp
  have h : env5999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5998_5999 : H12AffineEnvironment.transform 15 8234 env5998 = env5999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env5998 == env5999) = true)

theorem identity5999 : scanCanonicalize (H12AffineFastState.compose env5999 (packedSelected [0,3,5,7,8,13,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound5999 : packedSelected [0,3,5,7,8,13,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env6000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8234,4525,7868,1024,32768,4096,41089,184,41002,8329,185,60989,16384,16812,22561,1024,20740,256,20480,4096,773]

theorem envBound6000 : H12AffineFastState.Bounded env6000 := by
  intro p hp
  have h : env6000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5999_6000 : H12AffineEnvironment.transform 17 7868 env5999 = env6000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env5999 == env6000) = true)

def env6001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,8234,4525,7868,1024,32768,4096,41089,184,41002,8329,185,48789,4264,4356,2185,1024,428,256,168,4096,773]

theorem envBound6001 : H12AffineFastState.Bounded env6001 := by
  intro p hp
  have h : env6001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6000_6001 : H12AffineEnvironment.transform 13 4264 env6000 = env6001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env6000 == env6001) = true)

theorem identity6001 : scanCanonicalize (H12AffineFastState.compose env6001 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6001 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6002 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4264,32768,8234,4097,7868,1024,32768,4096,41089,184,41002,8329,185,48789,4264,4264,2185,1024,0,172,168,4096,681]

theorem envBound6002 : H12AffineFastState.Bounded env6002 := by
  intro p hp
  have h : env6002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6001_6002 : H12AffineEnvironment.transform 7 172 env6001 = env6002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6001 == env6002) = true)

theorem identity6002 : scanCanonicalize (H12AffineFastState.compose env6002 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6002 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6003 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,4096,32768,8234,4097,7700,1024,32768,4096,41001,16,41002,8225,17,48701,4096,4096,2081,1024,0,4,0,4096,513]

theorem envBound6003 : H12AffineFastState.Bounded env6003 := by
  intro p hp
  have h : env6003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6002_6003 : H12AffineEnvironment.transform 6 40 env6002 = env6003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6002 == env6003) = true)

theorem identity6003 : scanCanonicalize (H12AffineFastState.compose env6003 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6003 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6004 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1550,4096,8192,4096,32768,8234,4097,4122,1024,32768,4096,41001,16,41002,8225,17,45107,4096,4096,1583,1024,0,4,0,4096,513]

theorem envBound6004 : H12AffineFastState.Bounded env6004 := by
  intro p hp
  have h : env6004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6003_6004 : H12AffineEnvironment.transform 10 1550 env6003 = env6004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6003 == env6004) = true)

theorem identity6004 : scanCanonicalize (H12AffineFastState.compose env6004 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 1039) := by decide +kernel

theorem selectedBound6004 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6005 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1550,4096,8192,4096,1039,8234,4097,4122,1024,1039,4096,9254,16,9253,8225,17,13372,4096,4096,1583,1024,0,4,0,4096,513]

theorem envBound6005 : H12AffineFastState.Bounded env6005 := by
  intro p hp
  have h : env6005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6004_6005 : H12AffineEnvironment.transform 14 1039 env6004 = env6005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1039 env6004 == env6005) = true)

theorem identity6005 : scanCanonicalize (H12AffineFastState.compose env6005 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6005 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6006 : List Nat := [2,4,8,1,32,1,40,4,512,1024,1550,4096,8192,4096,1039,8234,4097,4107,1024,1039,4096,9254,1,9253,8225,0,13357,4096,4096,1583,1024,0,4,0,4096,513]

theorem envBound6006 : H12AffineFastState.Bounded env6006 := by
  intro p hp
  have h : env6006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6005_6006 : H12AffineEnvironment.transform 3 1 env6005 = env6006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6005 == env6006) = true)

theorem identity6006 : scanCanonicalize (H12AffineFastState.compose env6006 (packedSelected [1,2,9,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound6006 : packedSelected [1,2,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6007 : List Nat := [2,4,8,1,32,1,40,4,14,1024,1024,4096,8192,4096,1039,8234,4097,4107,1024,1039,4096,9254,1,9253,8225,0,13357,4096,4096,1057,1024,0,4,0,4096,15]

theorem envBound6007 : H12AffineFastState.Bounded env6007 := by
  intro p hp
  have h : env6007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6006_6007 : H12AffineEnvironment.transform 8 14 env6006 = env6007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env6006 == env6007) = true)

theorem identity6007 : scanCanonicalize (H12AffineFastState.compose env6007 (packedSelected [1,2,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1066) := by decide +kernel

theorem selectedBound6007 : packedSelected [1,2,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env6008 : List Nat := [2,4,8,1,32,1,40,4,14,1024,1024,1066,8192,1066,1039,8234,1067,1057,1024,1039,1066,9254,1,9253,8225,0,8199,1066,1066,1057,1024,0,4,0,1066,15]

theorem envBound6008 : H12AffineFastState.Bounded env6008 := by
  intro p hp
  have h : env6008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6007_6008 : H12AffineEnvironment.transform 11 1066 env6007 = env6008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1066 env6007 == env6008) = true)

theorem identity6008 : scanCanonicalize (H12AffineFastState.compose env6008 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6008 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env6009 : List Nat := [2,4,2,1,32,1,34,4,4,1024,1024,1056,8192,1056,1029,8224,1057,1057,1024,1029,1056,9254,1,9253,8225,0,8199,1056,1056,1057,1024,0,4,0,1056,5]

theorem envBound6009 : H12AffineFastState.Bounded env6009 := by
  intro p hp
  have h : env6009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6008_6009 : H12AffineEnvironment.transform 2 2 env6008 = env6009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6008 == env6009) = true)

theorem identity6009 : scanCanonicalize (H12AffineFastState.compose env6009 (packedSelected [1,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound6009 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env6010 : List Nat := [2,4,2,1,32,1,34,4,4,1024,1024,1056,1031,1056,1029,1063,1057,1057,1024,1029,1056,33,1,34,1062,0,1024,1056,1056,1057,1024,0,4,0,1056,5]

theorem envBound6010 : H12AffineFastState.Bounded env6010 := by
  intro p hp
  have h : env6010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6009_6010 : H12AffineEnvironment.transform 12 1031 env6009 = env6010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env6009 == env6010) = true)

theorem identity6010 : scanCanonicalize (H12AffineFastState.compose env6010 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6010 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6011 : List Nat := [2,1,2,1,32,1,34,1,1,1024,1024,1056,1026,1056,1024,1058,1057,1057,1024,1024,1056,33,1,34,1059,0,1024,1056,1056,1057,1024,0,1,0,1056,0]

theorem envBound6011 : H12AffineFastState.Bounded env6011 := by
  intro p hp
  have h : env6011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6010_6011 : H12AffineEnvironment.transform 1 1 env6010 = env6011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6010 == env6011) = true)

theorem identity6011 : scanCanonicalize (H12AffineFastState.compose env6011 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound6011 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6012 : List Nat := [2,1,2,1,32,1,34,1,1,32,32,0,34,0,32,2,1,1,32,32,0,33,1,34,3,0,32,0,0,1,32,0,1,0,0,0]

theorem envBound6012 : H12AffineFastState.Bounded env6012 := by
  intro p hp
  have h : env6012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6011_6012 : H12AffineEnvironment.transform 9 32 env6011 = env6012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env6011 == env6012) = true)

def leafEnv6012 : List Nat := [2,1,2,1,32,1,34,1,1,32,32,0,34,0,32,2,1,1,32,32,0,33,1,34,32,3,1,0,32,0,0,1,32,0,1,0,1,35,0,0,1,0,0]

def active6012 : List Nat := [0,4]

def tree6012 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6012 : H12WitnessSearch.Good tree6012 := H12GlobalWitnessIndex.good

theorem leafIdentity6012 : H12AffineFastState.composeSystem env6012 rootObs = leafEnv6012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6012 rootObs == leafEnv6012) = true)

theorem terminalChecked6012 : H12PackedTerminal.terminalCheckFast leafEnv6012 active6012 tree6012 = true := by decide +kernel

def env6013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,8234,4525,7868,1024,32768,4096,41089,184,41002,8329,185,48788,4265,4357,2184,1024,429,256,169,4096,773]

theorem envBound6013 : H12AffineFastState.Bounded env6013 := by
  intro p hp
  have h : env6013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6000_6013 : H12AffineEnvironment.transform 13 4265 env6000 = env6013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env6000 == env6013) = true)

theorem identity6013 : scanCanonicalize (H12AffineFastState.compose env6013 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6013 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6014 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1945,32768,8234,1693,2444,1024,32768,1840,41089,184,41002,8329,185,43428,1945,1589,2184,1024,429,256,169,1840,773]

theorem envBound6014 : H12AffineFastState.Bounded env6014 := by
  intro p hp
  have h : env6014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6013_6014 : H12AffineEnvironment.transform 11 1840 env6013 = env6014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env6013 == env6014) = true)

theorem identity6014 : scanCanonicalize (H12AffineFastState.compose env6014 (packedSelected [4,9,17,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound6014 : packedSelected [4,9,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6015 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1945,8461,8234,1693,2444,1024,8461,1840,396,184,295,8329,185,2217,1945,1589,2184,1024,429,256,169,1840,773]

theorem envBound6015 : H12AffineFastState.Bounded env6015 := by
  intro p hp
  have h : env6015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6014_6015 : H12AffineEnvironment.transform 14 8461 env6014 = env6015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env6014 == env6015) = true)

theorem identity6015 : scanCanonicalize (H12AffineFastState.compose env6015 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6015 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6016 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,8192,1840,8461,8234,1588,2341,1024,8461,1840,293,17,295,8224,16,2048,1840,1589,2081,1024,260,256,0,1840,773]

theorem envBound6016 : H12AffineFastState.Bounded env6016 := by
  intro p hp
  have h : env6016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6015_6016 : H12AffineEnvironment.transform 6 41 env6015 = env6016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6015 == env6016) = true)

theorem identity6016 : scanCanonicalize (H12AffineFastState.compose env6016 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2839) := by decide +kernel

theorem selectedBound6016 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env6017 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,2839,1840,2586,2877,1588,2341,1024,2586,1840,293,17,295,2871,16,2048,1840,1589,2081,1024,260,256,0,1840,773]

theorem envBound6017 : H12AffineFastState.Bounded env6017 := by
  intro p hp
  have h : env6017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6016_6017 : H12AffineEnvironment.transform 12 2839 env6016 = env6017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2839 env6016 == env6017) = true)

theorem identity6017 : scanCanonicalize (H12AffineFastState.compose env6017 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound6017 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env6018 : List Nat := [2,4,8,16,32,16,41,20,512,1024,2048,1572,2563,1572,2586,2601,1588,2097,1024,2586,1572,49,17,51,2595,16,2048,1572,1589,2081,1024,16,20,0,1572,529]

theorem envBound6018 : H12AffineFastState.Bounded env6018 := by
  intro p hp
  have h : env6018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6017_6018 : H12AffineEnvironment.transform 7 20 env6017 = env6018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env6017 == env6018) = true)

theorem identity6018 : scanCanonicalize (H12AffineFastState.compose env6018 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6018 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env6019 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,1572,2563,1572,2571,2601,1573,2080,1024,2571,1572,32,0,34,2595,1,2048,1572,1572,2081,1024,1,5,0,1572,512]

theorem envBound6019 : H12AffineFastState.Bounded env6019 := by
  intro p hp
  have h : env6019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6018_6019 : H12AffineEnvironment.transform 3 1 env6018 = env6019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6018 == env6019) = true)

theorem identity6019 : scanCanonicalize (H12AffineFastState.compose env6019 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6019 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6020 : List Nat := [2,4,3,1,32,1,34,5,512,1024,2048,1572,2563,1572,2560,2594,1573,2080,1024,2560,1572,32,0,34,2595,1,2048,1572,1572,2081,1024,1,5,0,1572,512]

theorem envBound6020 : H12AffineFastState.Bounded env6020 := by
  intro p hp
  have h : env6020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6019_6020 : H12AffineEnvironment.transform 2 3 env6019 = env6020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6019 == env6020) = true)

theorem identity6020 : scanCanonicalize (H12AffineFastState.compose env6020 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6020 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env6021 : List Nat := [2,4,3,1,1,1,3,5,512,1024,2048,1541,2563,1541,2560,2563,1540,2049,1024,2560,1541,1,0,3,2562,1,2048,1541,1541,2048,1024,1,5,0,1541,512]

theorem envBound6021 : H12AffineFastState.Bounded env6021 := by
  intro p hp
  have h : env6021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6020_6021 : H12AffineEnvironment.transform 4 1 env6020 = env6021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6020 == env6021) = true)

theorem identity6021 : scanCanonicalize (H12AffineFastState.compose env6021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6022 : List Nat := [2,4,3,1,1,1,3,5,1,1024,2048,1028,2050,1028,2049,2050,1029,2049,1024,2049,1028,1,0,3,2051,1,2048,1028,1028,2048,1024,1,5,0,1028,1]

theorem envBound6022 : H12AffineFastState.Bounded env6022 := by
  intro p hp
  have h : env6022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6021_6022 : H12AffineEnvironment.transform 8 1 env6021 = env6022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6021 == env6022) = true)

theorem identity6022 : scanCanonicalize (H12AffineFastState.compose env6022 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound6022 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6023 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,3,1028,0,3,1029,0,1024,0,1028,1,0,3,2,1,1,1028,1028,1,1024,1,5,0,1028,1]

theorem envBound6023 : H12AffineFastState.Bounded env6023 := by
  intro p hp
  have h : env6023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6022_6023 : H12AffineEnvironment.transform 10 1 env6022 = env6023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env6022 == env6023) = true)

def leafEnv6023 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,3,1028,0,3,1029,0,1024,0,1028,1,0,3,1024,2,1,1,1,1028,1028,1,1024,1,5,0,4,3,1028,1,1,1029,0]

def active6023 : List Nat := [0,1,9]

def tree6023 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6023 : H12WitnessSearch.Good tree6023 := H12GlobalWitnessIndex.good

theorem leafIdentity6023 : H12AffineFastState.composeSystem env6023 rootObs = leafEnv6023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6023 rootObs == leafEnv6023) = true)

theorem terminalChecked6023 : H12PackedTerminal.terminalCheckFast leafEnv6023 active6023 tree6023 = true := by decide +kernel

def env6024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,73875,41002,8329,73875,323712,16384,16813,22560,74794,4313518,256,20481,4239489,74543]

theorem envBound6024 : H12AffineFastState.Bounded env6024 := by
  intro p hp
  have h : env6024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5971_6024 : H12AffineEnvironment.transform 5 17 env5971 = env6024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5971 == env6024) = true)

theorem identity6024 : scanCanonicalize (H12AffineFastState.compose env6024 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6024 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,444,41002,8329,444,323712,16384,16813,22560,1285,4255873,256,20481,4239489,512]

theorem envBound6025 : H12AffineFastState.Bounded env6025 := by
  intro p hp
  have h : env6025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6024_6025 : H12AffineEnvironment.transform 15 8495 env6024 = env6025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6024 == env6025) = true)

theorem identity6025 : scanCanonicalize (H12AffineFastState.compose env6025 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6025 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6026 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,41348,444,41002,8329,444,323712,16384,16813,22560,1285,20741,256,20481,4357,512]

theorem envBound6026 : H12AffineFastState.Bounded env6026 := by
  intro p hp
  have h : env6026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6025_6026 : H12AffineEnvironment.transform 21 41348 env6025 = env6026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6025 == env6026) = true)

theorem identity6026 : scanCanonicalize (H12AffineFastState.compose env6026 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6026 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6027 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1024,26261,4096,18193,444,18111,8329,444,267797,16384,16813,22560,1285,20741,256,20481,4357,512]

theorem envBound6027 : H12AffineFastState.Bounded env6027 := by
  intro p hp
  have h : env6027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6026_6027 : H12AffineEnvironment.transform 14 26261 env6026 = env6027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6026 == env6027) = true)

theorem identity6027 : scanCanonicalize (H12AffineFastState.compose env6027 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound6027 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6028 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,262144,1024,14137,4096,5821,444,5907,8329,444,267797,4524,4097,2444,1285,169,256,429,4357,512]

theorem envBound6028 : H12AffineFastState.Bounded env6028 := by
  intro p hp
  have h : env6028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6027_6028 : H12AffineEnvironment.transform 13 4524 env6027 = env6028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env6027 == env6028) = true)

theorem identity6028 : scanCanonicalize (H12AffineFastState.compose env6028 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6028 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6029 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,2185,1024,14137,4096,5821,444,5907,8329,444,7836,4524,4097,2444,1285,169,256,429,4357,512]

theorem envBound6029 : H12AffineFastState.Bounded env6029 := by
  intro p hp
  have h : env6029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6028_6029 : H12AffineEnvironment.transform 17 2185 env6028 = env6029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6028 == env6029) = true)

theorem identity6029 : scanCanonicalize (H12AffineFastState.compose env6029 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6029 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6030 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,13972,8322,4097,2185,1024,13972,4096,5821,17,5822,8329,17,7836,4097,4097,2081,1192,169,173,0,4264,512]

theorem envBound6030 : H12AffineFastState.Bounded env6030 := by
  intro p hp
  have h : env6030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6029_6030 : H12AffineEnvironment.transform 7 173 env6029 = env6030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6029 == env6030) = true)

theorem identity6030 : scanCanonicalize (H12AffineFastState.compose env6030 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound6030 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6031 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,4096,8192,4097,13972,8322,4097,554,1024,13972,4096,5821,17,5822,8329,17,5183,4097,4097,642,1192,169,173,0,4264,512]

theorem envBound6031 : H12AffineFastState.Bounded env6031 := by
  intro p hp
  have h : env6031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6030_6031 : H12AffineEnvironment.transform 10 675 env6030 = env6031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env6030 == env6031) = true)

theorem identity6031 : scanCanonicalize (H12AffineFastState.compose env6031 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6031 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6032 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,8192,1692,8201,8322,1692,554,1024,8201,1693,32,17,35,8329,17,674,1692,1692,642,1192,169,173,0,1589,512]

theorem envBound6032 : H12AffineFastState.Bounded env6032 := by
  intro p hp
  have h : env6032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6031_6032 : H12AffineEnvironment.transform 11 1693 env6031 = env6032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6031 == env6032) = true)

theorem identity6032 : scanCanonicalize (H12AffineFastState.compose env6032 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6032 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6033 : List Nat := [2,4,8,16,32,17,40,5,512,1024,523,1589,8192,1588,8201,8234,1588,554,1024,8201,1589,32,17,35,8225,17,522,1588,1588,554,1024,1,5,0,1589,512]

theorem envBound6033 : H12AffineFastState.Bounded env6033 := by
  intro p hp
  have h : env6033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6032_6033 : H12AffineEnvironment.transform 6 40 env6032 = env6033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6032 == env6033) = true)

theorem identity6033 : scanCanonicalize (H12AffineFastState.compose env6033 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound6033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6034 : List Nat := [2,4,8,16,32,17,40,5,512,1024,523,1589,51,1588,58,25,1588,554,1024,58,1589,32,17,35,18,17,522,1588,1588,554,1024,1,5,0,1589,512]

theorem envBound6034 : H12AffineFastState.Bounded env6034 := by
  intro p hp
  have h : env6034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6033_6034 : H12AffineEnvironment.transform 12 51 env6033 = env6034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env6033 == env6034) = true)

theorem identity6034 : scanCanonicalize (H12AffineFastState.compose env6034 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6034 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6035 : List Nat := [2,4,8,16,16,17,24,5,512,1024,523,1541,3,1540,10,25,1540,538,1024,10,1541,16,17,19,18,17,522,1540,1540,538,1024,1,5,0,1541,512]

theorem envBound6035 : H12AffineFastState.Bounded env6035 := by
  intro p hp
  have h : env6035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6034_6035 : H12AffineEnvironment.transform 4 16 env6034 = env6035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6034 == env6035) = true)

theorem identity6035 : scanCanonicalize (H12AffineFastState.compose env6035 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6035 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6036 : List Nat := [2,4,8,1,1,0,9,5,512,1024,523,1541,3,1540,10,8,1540,523,1024,10,1541,1,0,2,3,0,522,1540,1540,523,1024,1,5,0,1541,512]

theorem envBound6036 : H12AffineFastState.Bounded env6036 := by
  intro p hp
  have h : env6036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6035_6036 : H12AffineEnvironment.transform 3 1 env6035 = env6036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6035 == env6036) = true)

theorem identity6036 : scanCanonicalize (H12AffineFastState.compose env6036 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6037 : List Nat := [2,4,8,1,1,0,9,5,11,1024,0,1038,3,1039,10,8,1039,0,1024,10,1038,1,0,2,3,0,1,1039,1039,0,1024,1,5,0,1038,11]

theorem envBound6037 : H12AffineFastState.Bounded env6037 := by
  intro p hp
  have h : env6037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6036_6037 : H12AffineEnvironment.transform 8 11 env6036 = env6037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6036 == env6037) = true)

theorem identity6037 : scanCanonicalize (H12AffineFastState.compose env6037 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6037 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6038 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,3,1029,0,2,1029,0,1024,0,1028,1,0,2,3,0,1,1029,1029,0,1024,1,5,0,1028,1]

theorem envBound6038 : H12AffineFastState.Bounded env6038 := by
  intro p hp
  have h : env6038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6037_6038 : H12AffineEnvironment.transform 2 2 env6037 = env6038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6037 == env6038) = true)

def leafEnv6038 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,3,1029,0,2,1029,0,1024,0,1028,1,0,2,1024,3,1,0,1,1029,1029,0,1024,1,5,0,4,3,1028,1,1,1028,0]

def active6038 : List Nat := [0,1,9]

def tree6038 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6038 : H12WitnessSearch.Good tree6038 := H12GlobalWitnessIndex.good

theorem leafIdentity6038 : H12AffineFastState.composeSystem env6038 rootObs = leafEnv6038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6038 rootObs == leafEnv6038) = true)

theorem terminalChecked6038 : H12PackedTerminal.terminalCheckFast leafEnv6038 active6038 tree6038 = true := by decide +kernel

def env6039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,12644669,257,20561,4239489,8389612]

theorem envBound6039 : H12AffineFastState.Bounded env6039 := by
  intro p hp
  have h : env6039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5969_6039 : H12AffineEnvironment.transform 18 1025 env5969 = env6039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5969 == env6039) = true)

theorem identity6039 : scanCanonicalize (H12AffineFastState.compose env6039 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound6039 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,26051,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16892,22640,16872,12644669,257,20561,4239489,8389612]

theorem envBound6040 : H12AffineFastState.Bounded env6040 := by
  intro p hp
  have h : env6040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6039_6040 : H12AffineEnvironment.transform 15 26051 env6039 = env6040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env6039 == env6040) = true)

def env6041 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,8388608,41002,8329,8388608,323712,16384,16812,22560,16824,12644669,257,20481,4239489,8389564]

theorem envBound6041 : H12AffineFastState.Bounded env6041 := by
  intro p hp
  have h : env6041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6040_6041 : H12AffineEnvironment.transform 5 16 env6040 = env6041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6040 == env6041) = true)

theorem identity6041 : scanCanonicalize (H12AffineFastState.compose env6041 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6041 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6042 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,444,41002,8329,444,323712,16384,16812,22560,16824,4255873,257,20481,4239489,512]

theorem envBound6042 : H12AffineFastState.Bounded env6042 := by
  intro p hp
  have h : env6042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6041_6042 : H12AffineEnvironment.transform 22 444 env6041 = env6042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6041 == env6042) = true)

theorem identity6042 : scanCanonicalize (H12AffineFastState.compose env6042 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6042 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6043 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,41349,444,41002,8329,444,323712,16384,16812,22560,16824,20740,257,20481,4356,512]

theorem envBound6043 : H12AffineFastState.Bounded env6043 := by
  intro p hp
  have h : env6043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6042_6043 : H12AffineEnvironment.transform 21 41349 env6042 = env6043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6042 == env6043) = true)

theorem identity6043 : scanCanonicalize (H12AffineFastState.compose env6043 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6043 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6044 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26003,4525,262144,1025,26260,4096,18193,444,18110,8329,444,267796,16384,16812,22560,16824,20740,257,20481,4356,512]

theorem envBound6044 : H12AffineFastState.Bounded env6044 := by
  intro p hp
  have h : env6044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6043_6044 : H12AffineEnvironment.transform 14 26260 env6043 = env6044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6043 == env6044) = true)

theorem identity6044 : scanCanonicalize (H12AffineFastState.compose env6044 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6044 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6045 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,262144,1025,26260,1296,18193,444,18110,8329,444,262916,16384,16812,19760,16824,17428,257,17681,1044,512]

theorem envBound6045 : H12AffineFastState.Bounded env6045 := by
  intro p hp
  have h : env6045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6044_6045 : H12AffineEnvironment.transform 11 1296 env6044 = env6045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6044 == env6045) = true)

theorem identity6045 : scanCanonicalize (H12AffineFastState.compose env6045 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6045 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6046 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,2341,1025,26260,1296,18193,444,18110,8329,444,2593,16384,16812,19760,16824,17428,257,17681,1044,512]

theorem envBound6046 : H12AffineFastState.Bounded env6046 := by
  intro p hp
  have h : env6046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6045_6046 : H12AffineEnvironment.transform 17 2341 env6045 = env6046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6045 == env6046) = true)

def env6047 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,8388608,41002,8329,8388609,323713,16384,16813,22561,16825,12644669,257,20480,4239489,8389565]

theorem envBound6047 : H12AffineFastState.Bounded env6047 := by
  intro p hp
  have h : env6047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6040_6047 : H12AffineEnvironment.transform 5 17 env6040 = env6047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6040 == env6047) = true)

def env6048 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,4240696,41002,8329,4240697,323713,16384,16813,22561,16825,17413,257,20480,4239489,4241029]

theorem envBound6048 : H12AffineFastState.Bounded env6048 := by
  intro p hp
  have h : env6048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6047_6048 : H12AffineEnvironment.transform 22 4240696 env6047 = env6048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240696 env6047 == env6048) = true)

theorem identity6048 : scanCanonicalize (H12AffineFastState.compose env6048 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13492) := by decide +kernel

theorem selectedBound6048 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6049 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13492,26002,4524,262144,1025,13492,4096,4194304,4194700,5278,8329,4194701,279605,16384,16813,22561,16825,17413,257,20480,4195381,4194865]

theorem envBound6049 : H12AffineFastState.Bounded env6049 := by
  intro p hp
  have h : env6049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6048_6049 : H12AffineEnvironment.transform 14 13492 env6048 = env6049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13492 env6048 == env6049) = true)

def env6050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8476,26002,1028,262144,1025,8476,1448,4194304,4194700,310,8329,4194701,279605,16384,16813,19849,16825,17413,257,17832,4195381,4194865]

theorem envBound6050 : H12AffineFastState.Bounded env6050 := by
  intro p hp
  have h : env6050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6049_6050 : H12AffineEnvironment.transform 11 1448 env6049 = env6050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env6049 == env6050) = true)

theorem identity6050 : scanCanonicalize (H12AffineFastState.compose env6050 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2461) := by decide +kernel

theorem selectedBound6050 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8476,26002,1028,2461,1025,8476,1448,4194304,4194700,310,8329,4194701,19880,16384,16813,19849,16825,17413,257,17832,4195381,4194865]

theorem envBound6051 : H12AffineFastState.Bounded env6051 := by
  intro p hp
  have h : env6051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6050_6051 : H12AffineEnvironment.transform 17 2461 env6050 = env6051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2461 env6050 == env6051) = true)

theorem identity6051 : scanCanonicalize (H12AffineFastState.compose env6051 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6051 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env6052 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,8192,16384,8476,25915,1028,2356,1025,8476,1281,4194304,4194597,310,8224,4194596,19713,16384,16644,19744,16656,17413,257,17665,4195381,4194865]

theorem envBound6052 : H12AffineFastState.Bounded env6052 := by
  intro p hp
  have h : env6052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6051_6052 : H12AffineEnvironment.transform 6 41 env6051 = env6052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6051 == env6052) = true)

theorem identity6052 : scanCanonicalize (H12AffineFastState.compose env6052 (packedSelected [2,6,7,9,10,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 17713) := by decide +kernel

theorem selectedBound6052 : packedSelected [2,6,7,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6053 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,8192,16384,8476,25915,1028,2356,1025,8476,1281,17713,17428,310,8224,17429,19713,16384,16644,19744,16656,17413,257,17665,16644,18176]

theorem envBound6053 : H12AffineFastState.Bounded env6053 := by
  intro p hp
  have h : env6053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6052_6053 : H12AffineEnvironment.transform 21 17713 env6052 = env6053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17713 env6052 == env6053) = true)

theorem identity6053 : scanCanonicalize (H12AffineFastState.compose env6053 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1565) := by decide +kernel

theorem selectedBound6053 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env6054 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,1565,16384,1793,17190,1028,2356,1025,1793,1281,17713,17428,310,1597,17429,19713,16384,16644,19744,16656,17413,257,17665,16644,18176]

theorem envBound6054 : H12AffineFastState.Bounded env6054 := by
  intro p hp
  have h : env6054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6053_6054 : H12AffineEnvironment.transform 12 1565 env6053 = env6054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1565 env6053 == env6054) = true)

theorem identity6054 : scanCanonicalize (H12AffineFastState.compose env6054 (packedSelected [0,1,3,4,6,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6054 : packedSelected [0,1,3,4,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env6055 : List Nat := [2,4,8,16,27,17,18,256,512,1024,2048,1281,1565,16384,1793,17181,1028,2319,1025,1793,1281,17674,17428,269,1542,17429,19713,16384,16644,19739,16656,17413,257,17665,16644,18176]

theorem envBound6055 : H12AffineFastState.Bounded env6055 := by
  intro p hp
  have h : env6055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6054_6055 : H12AffineEnvironment.transform 4 27 env6054 = env6055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6054 == env6055) = true)

theorem identity6055 : scanCanonicalize (H12AffineFastState.compose env6055 (packedSelected [1,2,4,5,7,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 1819) := by decide +kernel

theorem selectedBound6055 : packedSelected [1,2,4,5,7,10,17] rootPS < 2^1333 := by decide +kernel

def env6056 : List Nat := [2,4,8,16,27,17,18,256,512,1024,2048,1281,1565,1819,1793,1030,1028,2319,1025,1793,1281,529,783,269,1542,782,2586,1819,1567,2560,1547,798,257,538,1567,27]

theorem envBound6056 : H12AffineFastState.Bounded env6056 := by
  intro p hp
  have h : env6056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6055_6056 : H12AffineEnvironment.transform 13 1819 env6055 = env6056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1819 env6055 == env6056) = true)

theorem identity6056 : scanCanonicalize (H12AffineFastState.compose env6056 (packedSelected [2,3,8,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound6056 : packedSelected [2,3,8,10,20] rootPS < 2^1333 := by decide +kernel

def env6057 : List Nat := [2,4,8,16,27,17,18,21,512,1024,2048,1044,1565,1550,1556,1030,1028,2074,1025,1556,1044,529,538,24,1542,539,2586,1550,1567,2560,1547,523,20,538,1567,27]

theorem envBound6057 : H12AffineFastState.Bounded env6057 := by
  intro p hp
  have h : env6057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6056_6057 : H12AffineEnvironment.transform 7 21 env6056 = env6057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env6056 == env6057) = true)

theorem identity6057 : scanCanonicalize (H12AffineFastState.compose env6057 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound6057 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6058 : List Nat := [2,4,8,16,27,17,18,21,512,1024,1055,1044,1565,1550,1556,1030,1028,1029,1025,1556,1044,529,538,24,1542,539,1541,1550,1567,1567,1547,523,20,538,1567,27]

theorem envBound6058 : H12AffineFastState.Bounded env6058 := by
  intro p hp
  have h : env6058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6057_6058 : H12AffineEnvironment.transform 10 1055 env6057 = env6058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env6057 == env6058) = true)

theorem identity6058 : scanCanonicalize (H12AffineFastState.compose env6058 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6058 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env6059 : List Nat := [2,4,8,16,27,17,18,21,0,1024,1055,1044,1053,1038,1044,1030,1028,1029,1025,1044,1044,17,26,24,1030,27,1029,1038,1055,1055,1035,11,20,26,1055,27]

theorem envBound6059 : H12AffineFastState.Bounded env6059 := by
  intro p hp
  have h : env6059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6058_6059 : H12AffineEnvironment.transform 8 0 env6058 = env6059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6058 == env6059) = true)

theorem identity6059 : scanCanonicalize (H12AffineFastState.compose env6059 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6060 : List Nat := [2,4,8,11,0,10,9,14,0,1024,1028,1039,1030,1038,1039,1030,1028,1029,1025,1039,1039,10,1,3,1030,0,1029,1038,1028,1028,1035,11,15,1,1028,0]

theorem envBound6060 : H12AffineFastState.Bounded env6060 := by
  intro p hp
  have h : env6060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6059_6060 : H12AffineEnvironment.transform 3 11 env6059 = env6060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6059 == env6060) = true)

theorem identity6060 : scanCanonicalize (H12AffineFastState.compose env6060 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6061 : List Nat := [2,4,8,11,0,10,9,14,0,14,10,1,8,0,1,8,10,11,15,1,1,10,1,3,8,0,11,0,10,10,5,11,15,1,10,0]

theorem envBound6061 : H12AffineFastState.Bounded env6061 := by
  intro p hp
  have h : env6061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6060_6061 : H12AffineEnvironment.transform 9 14 env6060 = env6061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6060 == env6061) = true)

theorem identity6061 : scanCanonicalize (H12AffineFastState.compose env6061 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6061 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6062 : List Nat := [2,4,2,1,0,0,3,4,0,4,0,1,2,0,1,2,0,1,5,1,1,0,1,3,2,0,1,0,0,0,5,1,5,1,0,0]

theorem envBound6062 : H12AffineFastState.Bounded env6062 := by
  intro p hp
  have h : env6062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6061_6062 : H12AffineEnvironment.transform 2 2 env6061 = env6062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6061 == env6062) = true)

def env6063 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1449,8192,16384,8477,26002,1029,262144,1025,8477,1449,4194304,4194700,311,8329,4194701,279605,16384,16813,19848,16825,17413,257,17833,4195381,4194865]

theorem envBound6063 : H12AffineFastState.Bounded env6063 := by
  intro p hp
  have h : env6063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6049_6063 : H12AffineEnvironment.transform 11 1449 env6049 = env6063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env6049 == env6063) = true)

theorem identity6063 : scanCanonicalize (H12AffineFastState.compose env6063 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6063 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6064 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1029,8192,16384,8369,25662,1029,262144,1025,8369,1029,4194304,4194336,155,8329,4194337,279605,16384,16385,19492,16405,17413,173,17413,4195381,4194865]

theorem envBound6064 : H12AffineFastState.Bounded env6064 := by
  intro p hp
  have h : env6064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6063_6064 : H12AffineEnvironment.transform 7 172 env6063 = env6064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6063 == env6064) = true)

theorem identity6064 : scanCanonicalize (H12AffineFastState.compose env6064 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6064 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6065 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8216,25662,1029,262144,1025,8216,1029,4194304,4194336,50,8224,4194337,279605,16384,16385,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6065 : H12AffineFastState.Bounded env6065 := by
  intro p hp
  have h : env6065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6064_6065 : H12AffineEnvironment.transform 6 41 env6064 = env6065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6064 == env6065) = true)

theorem identity6065 : scanCanonicalize (H12AffineFastState.compose env6065 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound6065 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6066 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8216,25662,1029,19508,1025,8216,1029,4194304,4194336,50,8224,4194337,2049,16384,16385,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6066 : H12AffineFastState.Bounded env6066 := by
  intro p hp
  have h : env6066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6065_6066 : H12AffineEnvironment.transform 17 19508 env6065 = env6066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env6065 == env6066) = true)

theorem identity6066 : scanCanonicalize (H12AffineFastState.compose env6066 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 24601) := by decide +kernel

theorem selectedBound6066 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env6067 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8216,25662,1029,19508,1025,8216,1029,24601,24633,50,8224,24632,2049,16384,16385,19492,16405,17413,4,17413,25644,25128]

theorem envBound6067 : H12AffineFastState.Bounded env6067 := by
  intro p hp
  have h : env6067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6066_6067 : H12AffineEnvironment.transform 21 24601 env6066 = env6067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 24601 env6066 == env6067) = true)

theorem identity6067 : scanCanonicalize (H12AffineFastState.compose env6067 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 1590) := by decide +kernel

theorem selectedBound6067 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env6068 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,1590,16384,1582,16904,1029,19508,1025,1582,1029,17967,17935,50,1558,17934,2049,16384,16385,19492,16405,17413,4,17413,16922,17438]

theorem envBound6068 : H12AffineFastState.Bounded env6068 := by
  intro p hp
  have h : env6068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6067_6068 : H12AffineEnvironment.transform 12 1590 env6067 = env6068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1590 env6067 == env6068) = true)

theorem identity6068 : scanCanonicalize (H12AffineFastState.compose env6068 (packedSelected [0,2,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound6068 : packedSelected [0,2,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env6069 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,1590,1029,1582,1549,1029,2097,1025,1582,1029,554,522,50,1558,523,2049,1029,1028,2081,1040,0,4,0,1567,27]

theorem envBound6069 : H12AffineFastState.Bounded env6069 := by
  intro p hp
  have h : env6069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6068_6069 : H12AffineEnvironment.transform 13 1029 env6068 = env6069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env6068 == env6069) = true)

theorem identity6069 : scanCanonicalize (H12AffineFastState.compose env6069 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound6069 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6070 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1540,1029,1590,1029,1582,1549,1029,1589,1025,1582,1029,554,522,50,1558,523,1541,1029,1028,1573,1040,0,4,0,1567,27]

theorem envBound6070 : H12AffineFastState.Bounded env6070 := by
  intro p hp
  have h : env6070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6069_6070 : H12AffineEnvironment.transform 10 1540 env6069 = env6070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env6069 == env6070) = true)

theorem identity6070 : scanCanonicalize (H12AffineFastState.compose env6070 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6070 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6071 : List Nat := [2,4,8,16,32,17,41,5,33,1024,1061,1029,1047,1029,1039,1068,1029,1044,1025,1039,1029,11,43,50,1079,42,1060,1029,1028,1028,1040,0,4,0,1086,27]

theorem envBound6071 : H12AffineFastState.Bounded env6071 := by
  intro p hp
  have h : env6071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6070_6071 : H12AffineEnvironment.transform 8 33 env6070 = env6071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6070 == env6071) = true)

theorem identity6071 : scanCanonicalize (H12AffineFastState.compose env6071 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6071 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6072 : List Nat := [2,4,8,1,32,0,41,5,33,1024,1061,1029,1030,1029,1039,1068,1029,1029,1025,1039,1029,11,43,35,1062,42,1060,1029,1028,1028,1025,0,4,0,1071,10]

theorem envBound6072 : H12AffineFastState.Bounded env6072 := by
  intro p hp
  have h : env6072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6071_6072 : H12AffineEnvironment.transform 3 1 env6071 = env6072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6071 == env6072) = true)

theorem identity6072 : scanCanonicalize (H12AffineFastState.compose env6072 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6073 : List Nat := [2,4,8,1,1,0,8,5,0,1024,1028,1029,1030,1029,1039,1037,1029,1029,1025,1039,1029,11,10,2,1031,11,1029,1029,1028,1028,1025,0,4,0,1038,10]

theorem envBound6073 : H12AffineFastState.Bounded env6073 := by
  intro p hp
  have h : env6073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6072_6073 : H12AffineEnvironment.transform 4 1 env6072 = env6073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6072 == env6073) = true)

theorem identity6073 : scanCanonicalize (H12AffineFastState.compose env6073 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6074 : List Nat := [2,4,8,1,1,0,8,5,0,14,10,11,8,11,1,3,11,11,15,1,11,11,10,2,9,11,11,11,10,10,15,0,4,0,0,10]

theorem envBound6074 : H12AffineFastState.Bounded env6074 := by
  intro p hp
  have h : env6074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6073_6074 : H12AffineEnvironment.transform 9 14 env6073 = env6074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6073 == env6074) = true)

theorem identity6074 : scanCanonicalize (H12AffineFastState.compose env6074 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6074 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6075 : List Nat := [2,4,2,1,1,0,2,5,0,4,0,1,2,1,1,3,1,1,5,1,1,1,0,2,3,1,1,1,0,0,5,0,4,0,0,0]

theorem envBound6075 : H12AffineFastState.Bounded env6075 := by
  intro p hp
  have h : env6075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6074_6075 : H12AffineEnvironment.transform 2 2 env6074 = env6075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6074 == env6075) = true)

def env6076 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,4240697,41002,8329,4240696,323713,16384,16813,22561,16825,17412,257,20480,4239489,4241028]

theorem envBound6076 : H12AffineFastState.Bounded env6076 := by
  intro p hp
  have h : env6076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6047_6076 : H12AffineEnvironment.transform 22 4240697 env6047 = env6076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240697 env6047 == env6076) = true)

theorem identity6076 : scanCanonicalize (H12AffineFastState.compose env6076 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13576) := by decide +kernel

theorem selectedBound6076 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6077 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13576,26002,4524,262144,1025,13576,4096,4194304,4194353,5410,8329,4194352,279945,16384,16813,22561,16825,17412,257,20480,4195721,4195212]

theorem envBound6077 : H12AffineFastState.Bounded env6077 := by
  intro p hp
  have h : env6077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6076_6077 : H12AffineEnvironment.transform 14 13576 env6076 = env6077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13576 env6076 == env6077) = true)

def env6078 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4524,262144,1025,13576,4096,4194304,4194337,5410,8329,4194336,279945,16384,16813,22561,16809,17412,257,20480,4195721,4195212]

theorem envBound6078 : H12AffineFastState.Bounded env6078 := by
  intro p hp
  have h : env6078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6077_6078 : H12AffineEnvironment.transform 3 0 env6077 = env6078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6077 == env6078) = true)

def env6079 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4524,262144,1025,13576,4096,32,1,5410,8329,0,279945,16384,16813,22561,16809,17412,257,20480,1449,940]

theorem envBound6079 : H12AffineFastState.Bounded env6079 := by
  intro p hp
  have h : env6079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6078_6079 : H12AffineEnvironment.transform 21 32 env6078 = env6079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env6078 == env6079) = true)

theorem identity6079 : scanCanonicalize (H12AffineFastState.compose env6079 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6079 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6080 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1028,8192,16384,8460,25986,1448,262144,1025,8460,1028,32,1,294,8329,0,279945,16384,16813,19493,16809,17412,257,17412,1449,940]

theorem envBound6080 : H12AffineFastState.Bounded env6080 := by
  intro p hp
  have h : env6080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6079_6080 : H12AffineEnvironment.transform 11 1028 env6079 = env6080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env6079 == env6080) = true)

theorem identity6080 : scanCanonicalize (H12AffineFastState.compose env6080 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19597) := by decide +kernel

theorem selectedBound6080 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6081 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1028,8192,16384,8460,25986,1448,19597,1025,8460,1028,32,1,294,8329,0,2308,16384,16813,19493,16809,17412,257,17412,1449,940]

theorem envBound6081 : H12AffineFastState.Bounded env6081 := by
  intro p hp
  have h : env6081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6080_6081 : H12AffineEnvironment.transform 17 19597 env6080 = env6081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19597 env6080 == env6081) = true)

theorem identity6081 : scanCanonicalize (H12AffineFastState.compose env6081 (packedSelected [0,1,2,3,5,6,7,8,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound6081 : packedSelected [0,1,2,3,5,6,7,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6082 : List Nat := [2,4,8,0,32,1,128,256,512,1024,675,1028,8192,16384,8460,25986,1448,17966,1025,8460,1028,32,1,294,8329,0,935,16384,16813,18054,16809,17412,257,17412,1449,940]

theorem envBound6082 : H12AffineFastState.Bounded env6082 := by
  intro p hp
  have h : env6082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6081_6082 : H12AffineEnvironment.transform 10 675 env6081 = env6082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env6081 == env6082) = true)

theorem identity6082 : scanCanonicalize (H12AffineFastState.compose env6082 (packedSelected [0,1,3,4,5,6,7,8,9,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 8493) := by decide +kernel

theorem selectedBound6082 : packedSelected [0,1,3,4,5,6,7,8,9,13,20] rootPS < 2^1333 := by decide +kernel

def env6083 : List Nat := [2,4,8,0,32,1,128,256,512,1024,675,1028,8192,8493,8460,1199,1448,9987,1025,8460,1028,32,1,294,8329,0,935,8493,8320,10155,8324,9513,257,9513,1449,940]

theorem envBound6083 : H12AffineFastState.Bounded env6083 := by
  intro p hp
  have h : env6083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6082_6083 : H12AffineEnvironment.transform 13 8493 env6082 = env6083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8493 env6082 == env6083) = true)

theorem identity6083 : scanCanonicalize (H12AffineFastState.compose env6083 (packedSelected [2,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6083 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env6084 : List Nat := [2,4,8,0,32,1,128,256,33,1024,130,1028,8192,8493,8460,1199,1448,9506,1025,8460,1028,32,1,294,8329,0,390,8493,8320,9610,8324,9513,257,9513,1449,397]

theorem envBound6084 : H12AffineFastState.Bounded env6084 := by
  intro p hp
  have h : env6084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6083_6084 : H12AffineEnvironment.transform 8 33 env6083 = env6084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6083 == env6084) = true)

theorem identity6084 : scanCanonicalize (H12AffineFastState.compose env6084 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1408) := by decide +kernel

theorem selectedBound6084 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6085 : List Nat := [2,4,8,0,32,1,128,256,33,1024,130,1028,1408,1197,1164,1199,1448,162,1025,1164,1028,32,1,294,1289,0,390,1197,1280,10,1284,169,257,169,1449,397]

theorem envBound6085 : H12AffineFastState.Bounded env6085 := by
  intro p hp
  have h : env6085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6084_6085 : H12AffineEnvironment.transform 12 1408 env6084 = env6085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env6084 == env6085) = true)

theorem identity6085 : scanCanonicalize (H12AffineFastState.compose env6085 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6085 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6086 : List Nat := [2,4,8,0,32,1,41,256,33,1024,43,1028,1321,1028,1061,1030,1281,11,1025,1061,1028,32,1,294,1289,0,303,1028,1280,10,1284,0,257,0,1280,292]

theorem envBound6086 : H12AffineFastState.Bounded env6086 := by
  intro p hp
  have h : env6086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6085_6086 : H12AffineEnvironment.transform 6 41 env6085 = env6086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6085 == env6086) = true)

theorem identity6086 : scanCanonicalize (H12AffineFastState.compose env6086 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6086 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6087 : List Nat := [2,4,2,0,32,1,35,256,33,1024,33,1028,1315,1028,1061,1030,1281,1,1025,1061,1028,32,1,294,1283,0,293,1028,1280,0,1284,0,257,0,1280,292]

theorem envBound6087 : H12AffineFastState.Bounded env6087 := by
  intro p hp
  have h : env6087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6086_6087 : H12AffineEnvironment.transform 2 2 env6086 = env6087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6086 == env6087) = true)

theorem identity6087 : scanCanonicalize (H12AffineFastState.compose env6087 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6087 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6088 : List Nat := [2,4,2,0,32,1,35,4,33,1024,33,1028,1063,1028,1061,1030,1029,1,1025,1061,1028,32,1,34,1031,0,33,1028,1028,0,1024,0,5,0,1028,32]

theorem envBound6088 : H12AffineFastState.Bounded env6088 := by
  intro p hp
  have h : env6088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6087_6088 : H12AffineEnvironment.transform 7 4 env6087 = env6088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6087 == env6088) = true)

theorem identity6088 : scanCanonicalize (H12AffineFastState.compose env6088 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6089 : List Nat := [2,1,2,0,32,1,35,1,33,1024,33,1025,1058,1025,1056,1027,1024,1,1025,1056,1025,32,1,34,1026,0,33,1025,1025,0,1024,0,0,0,1025,32]

theorem envBound6089 : H12AffineFastState.Bounded env6089 := by
  intro p hp
  have h : env6089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6088_6089 : H12AffineEnvironment.transform 1 1 env6088 = env6089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6088 == env6089) = true)

theorem identity6089 : scanCanonicalize (H12AffineFastState.compose env6089 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6089 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6090 : List Nat := [2,1,2,0,0,1,3,1,1,1024,1,1025,1026,1025,1024,1027,1024,1,1025,1024,1025,0,1,2,1026,0,1,1025,1025,0,1024,0,0,0,1025,0]

theorem envBound6090 : H12AffineFastState.Bounded env6090 := by
  intro p hp
  have h : env6090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6089_6090 : H12AffineEnvironment.transform 4 0 env6089 = env6090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6089 == env6090) = true)

theorem identity6090 : scanCanonicalize (H12AffineFastState.compose env6090 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound6090 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6091 : List Nat := [2,1,2,0,0,1,3,1,1,1,1,0,3,0,1,2,1,1,0,1,0,0,1,2,3,0,1,0,0,0,1,0,0,0,0,0]

theorem envBound6091 : H12AffineFastState.Bounded env6091 := by
  intro p hp
  have h : env6091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6090_6091 : H12AffineEnvironment.transform 9 1 env6090 = env6091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env6090 == env6091) = true)

def env6092 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13576,25986,4524,262144,1025,13576,4096,33,0,5410,8329,1,279945,16384,16813,22561,16809,17412,257,20480,1448,941]

theorem envBound6092 : H12AffineFastState.Bounded env6092 := by
  intro p hp
  have h : env6092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6078_6092 : H12AffineEnvironment.transform 21 33 env6078 = env6092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env6078 == env6092) = true)

theorem identity6092 : scanCanonicalize (H12AffineFastState.compose env6092 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6092 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6093 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25646,4096,262144,1025,13476,4096,33,0,5262,8329,1,279589,16384,16385,22561,16389,17412,173,20480,1028,513]

theorem envBound6093 : H12AffineFastState.Bounded env6093 := by
  intro p hp
  have h : env6093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6092_6093 : H12AffineEnvironment.transform 7 172 env6092 = env6093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6092 == env6093) = true)

theorem identity6093 : scanCanonicalize (H12AffineFastState.compose env6093 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1191) := by decide +kernel

theorem selectedBound6093 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6094 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13476,25646,4096,1191,1025,13476,4096,33,0,5262,8329,1,16514,16384,16385,22561,16389,17412,173,20480,1028,513]

theorem envBound6094 : H12AffineFastState.Bounded env6094 := by
  intro p hp
  have h : env6094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6093_6094 : H12AffineEnvironment.transform 17 1191 env6093 = env6094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1191 env6093 == env6094) = true)

theorem identity6094 : scanCanonicalize (H12AffineFastState.compose env6094 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound6094 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6095 : List Nat := [2,4,8,0,32,1,128,172,137,1024,2048,4096,8192,16384,13476,25646,4096,1191,1025,13476,4096,33,0,5262,8329,1,16514,16384,16385,22561,16389,17412,173,20480,1028,136]

theorem envBound6095 : H12AffineFastState.Bounded env6095 := by
  intro p hp
  have h : env6095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6094_6095 : H12AffineEnvironment.transform 8 137 env6094 = env6095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env6094 == env6095) = true)

theorem identity6095 : scanCanonicalize (H12AffineFastState.compose env6095 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6095 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env6096 : List Nat := [2,4,8,0,32,1,41,5,32,1024,2048,4096,8192,16384,13325,25646,4096,1038,1025,13325,4096,33,0,5159,8224,1,16427,16384,16385,22561,16389,17412,4,20480,1028,33]

theorem envBound6096 : H12AffineFastState.Bounded env6096 := by
  intro p hp
  have h : env6096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6095_6096 : H12AffineEnvironment.transform 6 41 env6095 = env6096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6095 == env6096) = true)

theorem identity6096 : scanCanonicalize (H12AffineFastState.compose env6096 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6096 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env6097 : List Nat := [2,4,8,0,32,1,41,5,32,1024,1038,4096,8192,16384,13325,25646,4096,1038,1025,13325,4096,33,0,5159,8224,1,16427,16384,16385,21551,16389,17412,4,20480,1028,33]

theorem envBound6097 : H12AffineFastState.Bounded env6097 := by
  intro p hp
  have h : env6097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6096_6097 : H12AffineEnvironment.transform 10 1038 env6096 = env6097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env6096 == env6097) = true)

theorem identity6097 : scanCanonicalize (H12AffineFastState.compose env6097 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 4141) := by decide +kernel

theorem selectedBound6097 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env6098 : List Nat := [2,4,8,0,32,1,41,5,32,1024,1038,4096,4141,16384,1056,21507,4096,1038,1025,1056,4096,33,0,5159,4109,1,16427,16384,16385,21551,16389,17412,4,20480,1028,33]

theorem envBound6098 : H12AffineFastState.Bounded env6098 := by
  intro p hp
  have h : env6098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6097_6098 : H12AffineEnvironment.transform 12 4141 env6097 = env6098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4141 env6097 == env6098) = true)

theorem identity6098 : scanCanonicalize (H12AffineFastState.compose env6098 (packedSelected [1,4,9,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 1034) := by decide +kernel

theorem selectedBound6098 : packedSelected [1,4,9,12,13] rootPS < 2^1333 := by decide +kernel

def env6099 : List Nat := [2,4,8,0,32,1,41,5,32,1024,1038,4096,4141,1034,1056,4105,4096,1038,1025,1056,4096,33,0,5159,4109,1,1057,1034,1035,4133,1039,14,4,5130,1028,33]

theorem envBound6099 : H12AffineFastState.Bounded env6099 := by
  intro p hp
  have h : env6099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6098_6099 : H12AffineEnvironment.transform 13 1034 env6098 = env6099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1034 env6098 == env6099) = true)

theorem identity6099 : scanCanonicalize (H12AffineFastState.compose env6099 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound6099 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6100 : List Nat := [2,4,8,0,32,1,41,5,32,1024,1038,43,6,1034,1056,34,43,1038,1025,1056,43,33,0,1036,38,1,1057,1034,1035,14,1039,14,4,1057,1028,33]

theorem envBound6100 : H12AffineFastState.Bounded env6100 := by
  intro p hp
  have h : env6100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6099_6100 : H12AffineEnvironment.transform 11 43 env6099 = env6100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env6099 == env6100) = true)

theorem identity6100 : scanCanonicalize (H12AffineFastState.compose env6100 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 42) := by decide +kernel

theorem selectedBound6100 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6101 : List Nat := [2,4,8,0,32,1,41,5,32,42,36,43,6,32,10,34,43,36,43,10,43,33,0,38,38,1,11,32,33,14,37,14,4,11,46,33]

theorem envBound6101 : H12AffineFastState.Bounded env6101 := by
  intro p hp
  have h : env6101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6100_6101 : H12AffineEnvironment.transform 9 42 env6100 = env6101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 42 env6100 == env6101) = true)

theorem identity6101 : scanCanonicalize (H12AffineFastState.compose env6101 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6101 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6102 : List Nat := [2,4,8,0,10,1,3,5,10,0,14,1,6,10,10,8,1,14,1,10,1,11,0,12,12,1,11,10,11,14,15,14,4,11,4,11]

theorem envBound6102 : H12AffineFastState.Bounded env6102 := by
  intro p hp
  have h : env6102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6101_6102 : H12AffineEnvironment.transform 4 10 env6101 = env6102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6101 == env6102) = true)

theorem identity6102 : scanCanonicalize (H12AffineFastState.compose env6102 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6103 : List Nat := [2,0,8,0,10,1,3,1,10,0,10,1,2,10,10,8,1,10,1,10,1,11,0,8,8,1,11,10,11,10,11,10,0,11,0,11]

theorem envBound6103 : H12AffineFastState.Bounded env6103 := by
  intro p hp
  have h : env6103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6102_6103 : H12AffineEnvironment.transform 1 0 env6102 = env6103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6102 == env6103) = true)

def env6104 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13576,25987,4524,262144,1025,13576,4096,4194304,4194336,5410,8329,4194337,279945,16384,16813,22561,16808,17412,257,20480,4195721,4195212]

theorem envBound6104 : H12AffineFastState.Bounded env6104 := by
  intro p hp
  have h : env6104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6077_6104 : H12AffineEnvironment.transform 3 1 env6077 = env6104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6077 == env6104) = true)

theorem identity6104 : scanCanonicalize (H12AffineFastState.compose env6104 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6104 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6105 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1028,8192,16384,8460,25987,1448,262144,1025,8460,1028,4194304,4194336,294,8329,4194337,279945,16384,16813,19493,16808,17412,257,17412,4195721,4195212]

theorem envBound6105 : H12AffineFastState.Bounded env6105 := by
  intro p hp
  have h : env6105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6104_6105 : H12AffineEnvironment.transform 11 1028 env6104 = env6105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env6104 == env6105) = true)

theorem identity6105 : scanCanonicalize (H12AffineFastState.compose env6105 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6105 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6106 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8201,25734,1197,262144,1025,8201,1028,4194304,4194336,35,8329,4194337,279692,16384,16552,19493,16557,17412,4,17412,4195468,4194953]

theorem envBound6106 : H12AffineFastState.Bounded env6106 := by
  intro p hp
  have h : env6106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6105_6106 : H12AffineEnvironment.transform 7 5 env6105 = env6106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6105 == env6106) = true)

theorem identity6106 : scanCanonicalize (H12AffineFastState.compose env6106 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6106 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6107 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8201,25734,1197,2185,1025,8201,1028,4194304,4194336,35,8329,4194337,19461,16384,16552,19493,16557,17412,4,17412,4195468,4194953]

theorem envBound6107 : H12AffineFastState.Bounded env6107 := by
  intro p hp
  have h : env6107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6106_6107 : H12AffineEnvironment.transform 17 2185 env6106 = env6107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6106 == env6107) = true)

theorem identity6107 : scanCanonicalize (H12AffineFastState.compose env6107 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6107 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6108 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8201,25734,1165,2185,1025,8201,1028,4194304,4194304,3,8329,4194305,19461,16384,16520,19461,16525,17412,4,17412,4195468,4194953]

theorem envBound6108 : H12AffineFastState.Bounded env6108 := by
  intro p hp
  have h : env6108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6107_6108 : H12AffineEnvironment.transform 4 0 env6107 = env6108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6107 == env6108) = true)

theorem identity6108 : scanCanonicalize (H12AffineFastState.compose env6108 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 27655) := by decide +kernel

theorem selectedBound6108 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6109 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8201,25734,1165,2185,1025,8201,1028,27655,27655,3,8329,27654,19461,16384,16520,19461,16525,17412,4,17412,26763,28302]

theorem envBound6109 : H12AffineFastState.Bounded env6109 := by
  intro p hp
  have h : env6109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6108_6109 : H12AffineEnvironment.transform 21 27655 env6108 = env6109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27655 env6108 == env6109) = true)

theorem identity6109 : scanCanonicalize (H12AffineFastState.compose env6109 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 11276) := by decide +kernel

theorem selectedBound6109 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6110 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,11276,8201,2186,1165,2185,1025,8201,1028,11,11,3,8329,10,8201,11276,11396,8201,11393,10248,4,10248,1159,642]

theorem envBound6110 : H12AffineFastState.Bounded env6110 := by
  intro p hp
  have h : env6110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6109_6110 : H12AffineEnvironment.transform 13 11276 env6109 = env6110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11276 env6109 == env6110) = true)

theorem identity6110 : scanCanonicalize (H12AffineFastState.compose env6110 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound6110 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env6111 : List Nat := [2,4,8,1,0,0,128,5,512,1024,513,1028,8192,9741,8201,651,1165,648,1025,8201,1028,11,11,3,8329,10,8201,9741,9861,8201,9856,8713,4,8713,1159,642]

theorem envBound6111 : H12AffineFastState.Bounded env6111 := by
  intro p hp
  have h : env6111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6110_6111 : H12AffineEnvironment.transform 10 513 env6110 = env6111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env6110 == env6111) = true)

theorem identity6111 : scanCanonicalize (H12AffineFastState.compose env6111 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 640) := by decide +kernel

theorem selectedBound6111 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env6112 : List Nat := [2,4,8,1,0,0,128,5,512,1024,513,1028,640,1165,649,651,1165,648,1025,649,1028,11,11,3,521,10,649,1165,1029,649,1024,137,4,137,1159,642]

theorem envBound6112 : H12AffineFastState.Bounded env6112 := by
  intro p hp
  have h : env6112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6111_6112 : H12AffineEnvironment.transform 12 640 env6111 = env6112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env6111 == env6112) = true)

theorem identity6112 : scanCanonicalize (H12AffineFastState.compose env6112 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6112 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env6113 : List Nat := [2,4,8,1,0,0,128,5,1,1024,0,1028,129,1165,136,138,1165,137,1025,136,1028,11,11,3,8,10,136,1165,1029,136,1024,137,4,137,1159,131]

theorem envBound6113 : H12AffineFastState.Bounded env6113 := by
  intro p hp
  have h : env6113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6112_6113 : H12AffineEnvironment.transform 8 1 env6112 = env6113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6112 == env6113) = true)

theorem identity6113 : scanCanonicalize (H12AffineFastState.compose env6113 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound6113 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env6114 : List Nat := [2,4,8,1,0,0,128,5,1,140,0,136,129,1,136,138,1,137,141,136,136,11,11,3,8,10,136,1,137,136,140,137,4,137,11,131]

theorem envBound6114 : H12AffineFastState.Bounded env6114 := by
  intro p hp
  have h : env6114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6113_6114 : H12AffineEnvironment.transform 9 140 env6113 = env6114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env6113 == env6114) = true)

theorem identity6114 : scanCanonicalize (H12AffineFastState.compose env6114 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound6114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6115 : List Nat := [2,4,8,1,0,0,3,5,1,15,0,11,2,1,11,9,1,10,14,11,11,11,11,3,8,10,11,1,10,11,15,10,4,10,11,0]

theorem envBound6115 : H12AffineFastState.Bounded env6115 := by
  intro p hp
  have h : env6115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6114_6115 : H12AffineEnvironment.transform 6 3 env6114 = env6115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env6114 == env6115) = true)

theorem identity6115 : scanCanonicalize (H12AffineFastState.compose env6115 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6115 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6116 : List Nat := [2,4,2,1,0,0,3,5,1,5,0,1,2,1,1,3,1,0,4,1,1,1,1,3,2,0,1,1,0,1,5,0,4,0,1,0]

theorem envBound6116 : H12AffineFastState.Bounded env6116 := by
  intro p hp
  have h : env6116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6115_6116 : H12AffineEnvironment.transform 2 2 env6115 = env6116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6115 == env6116) = true)

theorem identity6116 : scanCanonicalize (H12AffineFastState.compose env6116 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6117 : List Nat := [2,0,2,1,0,0,3,1,1,1,0,1,2,1,1,3,1,0,0,1,1,1,1,3,2,0,1,1,0,1,1,0,0,0,1,0]

theorem envBound6117 : H12AffineFastState.Bounded env6117 := by
  intro p hp
  have h : env6117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6116_6117 : H12AffineEnvironment.transform 1 0 env6116 = env6117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6116 == env6117) = true)

def env6118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849104,16384,16892,547952,598058,12644668,525568,545873,4239488,8914925]

theorem envBound6118 : H12AffineFastState.Bounded env6118 := by
  intro p hp
  have h : env6118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5968_6118 : H12AffineEnvironment.transform 20 4097 env5968 = env6118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5968 == env6118) = true)

def env6119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,12644668,256,20561,4239488,8389613]

theorem envBound6119 : H12AffineFastState.Bounded env6119 := by
  intro p hp
  have h : env6119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6118_6119 : H12AffineEnvironment.transform 18 1024 env6118 = env6119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6118 == env6119) = true)

theorem identity6119 : scanCanonicalize (H12AffineFastState.compose env6119 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98386) := by decide +kernel

theorem selectedBound6119 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,98386,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,8483182,256,20561,78034,8389613]

theorem envBound6120 : H12AffineFastState.Bounded env6120 := by
  intro p hp
  have h : env6120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6119_6120 : H12AffineEnvironment.transform 21 98386 env6119 = env6120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98386 env6119 == env6120) = true)

def env6121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98306,8388608,41002,8329,8388609,323712,16384,16812,22560,74794,8483134,256,20481,77954,8389565]

theorem envBound6121 : H12AffineFastState.Bounded env6121 := by
  intro p hp
  have h : env6121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6120_6121 : H12AffineEnvironment.transform 5 16 env6120 = env6121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6120 == env6121) = true)

theorem identity6121 : scanCanonicalize (H12AffineFastState.compose env6121 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6121 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98306,445,41002,8329,444,323712,16384,16812,22560,74794,94339,256,20481,77954,512]

theorem envBound6122 : H12AffineFastState.Bounded env6122 := by
  intro p hp
  have h : env6122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6121_6122 : H12AffineEnvironment.transform 22 445 env6121 = env6122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6121 == env6122) = true)

theorem identity6122 : scanCanonicalize (H12AffineFastState.compose env6122 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound6122 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1024,32768,4097,41349,445,41002,8329,444,323712,16384,16812,22560,1453,20740,256,20481,4357,512]

theorem envBound6123 : H12AffineFastState.Bounded env6123 := by
  intro p hp
  have h : env6123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6122_6123 : H12AffineEnvironment.transform 15 8583 env6122 = env6123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env6122 == env6123) = true)

theorem identity6123 : scanCanonicalize (H12AffineFastState.compose env6123 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6123 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8583,4525,262144,1024,26260,4097,18193,445,18110,8329,444,267796,16384,16812,22560,1453,20740,256,20481,4357,512]

theorem envBound6124 : H12AffineFastState.Bounded env6124 := by
  intro p hp
  have h : env6124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6123_6124 : H12AffineEnvironment.transform 14 26260 env6123 = env6124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6123 == env6124) = true)

theorem identity6124 : scanCanonicalize (H12AffineFastState.compose env6124 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound6124 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6125 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,14224,8583,4525,262144,1024,14224,4097,5653,445,6074,8329,444,267796,4356,4264,2340,1453,0,256,261,4357,512]

theorem envBound6125 : H12AffineFastState.Bounded env6125 := by
  intro p hp
  have h : env6125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6124_6125 : H12AffineEnvironment.transform 13 4356 env6124 = env6125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env6124 == env6125) = true)

def env6126 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,98307,8388608,41002,8329,8388608,323713,16384,16813,22561,74794,8483135,256,20480,77955,8389564]

theorem envBound6126 : H12AffineFastState.Bounded env6126 := by
  intro p hp
  have h : env6126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6120_6126 : H12AffineEnvironment.transform 5 17 env6120 = env6126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6120 == env6126) = true)

def env6127 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4097,98307,8388608,41002,8225,8388608,323625,16384,16645,22561,74794,8483135,256,20480,77867,8389396]

theorem envBound6127 : H12AffineFastState.Bounded env6127 := by
  intro p hp
  have h : env6127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6126_6127 : H12AffineEnvironment.transform 6 40 env6126 = env6127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6126 == env6127) = true)

theorem identity6127 : scanCanonicalize (H12AffineFastState.compose env6127 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 284981) := by decide +kernel

theorem selectedBound6127 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6128 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4097,98307,284981,41002,8225,284981,323625,16384,16645,22561,74794,337930,256,20480,77867,285217]

theorem envBound6128 : H12AffineFastState.Bounded env6128 := by
  intro p hp
  have h : env6128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6127_6128 : H12AffineEnvironment.transform 22 284981 env6127 = env6128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284981 env6127 == env6128) = true)

theorem identity6128 : scanCanonicalize (H12AffineFastState.compose env6128 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6128 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env6129 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,2080,1024,32768,4097,98307,20757,41002,8225,20757,63497,16384,16645,22561,74794,73770,256,20480,77867,20993]

theorem envBound6129 : H12AffineFastState.Bounded env6129 := by
  intro p hp
  have h : env6129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6128_6129 : H12AffineEnvironment.transform 17 2080 env6128 = env6129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6128 == env6129) = true)

theorem identity6129 : scanCanonicalize (H12AffineFastState.compose env6129 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound6129 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6130 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8461,65536,4356,2080,1024,8461,4097,73998,20757,295,8225,20757,22788,16384,16645,22561,74794,73770,256,20480,77867,20993]

theorem envBound6130 : H12AffineFastState.Bounded env6130 := by
  intro p hp
  have h : env6130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6129_6130 : H12AffineEnvironment.transform 14 8461 env6129 = env6130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env6129 == env6130) = true)

theorem identity6130 : scanCanonicalize (H12AffineFastState.compose env6130 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound6130 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6131 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,11545,8461,65536,4356,2080,1024,8461,4097,73998,15372,295,8225,15372,13341,11545,11292,13624,74794,73770,256,15641,77867,16152]

theorem envBound6131 : H12AffineFastState.Bounded env6131 := by
  intro p hp
  have h : env6131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6130_6131 : H12AffineEnvironment.transform 13 11545 env6130 = env6131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env6130 == env6131) = true)

theorem identity6131 : scanCanonicalize (H12AffineFastState.compose env6131 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7709) := by decide +kernel

theorem selectedBound6131 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env6132 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,7709,4868,7952,65536,4356,2080,1024,7952,4097,73491,529,295,7740,529,2560,4868,4609,2853,72247,73271,256,772,69174,261]

theorem envBound6132 : H12AffineFastState.Bounded env6132 := by
  intro p hp
  have h : env6132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6131_6132 : H12AffineEnvironment.transform 12 7709 env6131 = env6132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7709 env6131 == env6132) = true)

theorem identity6132 : scanCanonicalize (H12AffineFastState.compose env6132 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound6132 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env6133 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1588,2089,1328,2340,65536,1840,2080,1024,2340,1589,67879,529,295,2056,529,2560,1328,1077,2853,68611,67587,256,772,69174,261]

theorem envBound6133 : H12AffineFastState.Bounded env6133 := by
  intro p hp
  have h : env6133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6132_6133 : H12AffineEnvironment.transform 11 1588 env6132 = env6133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env6132 == env6133) = true)

theorem identity6133 : scanCanonicalize (H12AffineFastState.compose env6133 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 2562) := by decide +kernel

theorem selectedBound6133 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env6134 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1588,2089,1328,2340,2562,1840,2080,1024,2340,1589,805,529,295,2056,529,2560,1328,1077,2853,1537,513,256,772,1076,261]

theorem envBound6134 : H12AffineFastState.Bounded env6134 := by
  intro p hp
  have h : env6134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6133_6134 : H12AffineEnvironment.transform 15 2562 env6133 = env6134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2562 env6133 == env6134) = true)

theorem identity6134 : scanCanonicalize (H12AffineFastState.compose env6134 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound6134 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6135 : List Nat := [2,4,8,16,32,17,40,256,512,1024,33,1588,8,1328,261,547,1840,1,1024,261,1589,805,529,295,41,529,545,1328,1077,772,1537,513,256,772,1076,261]

theorem envBound6135 : H12AffineFastState.Bounded env6135 := by
  intro p hp
  have h : env6135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6134_6135 : H12AffineEnvironment.transform 10 33 env6134 = env6135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env6134 == env6135) = true)

theorem identity6135 : scanCanonicalize (H12AffineFastState.compose env6135 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 287) := by decide +kernel

theorem selectedBound6135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6136 : List Nat := [2,4,8,16,32,17,40,256,287,1024,33,1323,8,1328,261,316,1071,1,1024,261,1322,58,270,295,41,270,318,1328,1077,27,1310,286,256,27,1076,261]

theorem envBound6136 : H12AffineFastState.Bounded env6136 := by
  intro p hp
  have h : env6136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6135_6136 : H12AffineEnvironment.transform 8 287 env6135 = env6136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 287 env6135 == env6136) = true)

theorem identity6136 : scanCanonicalize (H12AffineFastState.compose env6136 (packedSelected [4,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6136 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env6137 : List Nat := [2,4,8,16,32,17,40,5,26,1024,33,1070,8,1077,0,57,1071,1,1024,0,1071,58,11,34,41,11,59,1077,1077,27,1051,27,5,27,1076,0]

theorem envBound6137 : H12AffineFastState.Bounded env6137 := by
  intro p hp
  have h : env6137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6136_6137 : H12AffineEnvironment.transform 7 5 env6136 = env6137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6136 == env6137) = true)

theorem identity6137 : scanCanonicalize (H12AffineFastState.compose env6137 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound6137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6138 : List Nat := [2,4,8,16,32,17,40,5,26,46,33,0,8,27,0,57,1,1,46,0,1,58,11,34,41,11,59,27,27,27,53,27,5,27,26,0]

theorem envBound6138 : H12AffineFastState.Bounded env6138 := by
  intro p hp
  have h : env6138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6137_6138 : H12AffineEnvironment.transform 9 46 env6137 = env6138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env6137 == env6138) = true)

def env6139 : List Nat := [2,4,8,4,32,5,40,5,14,46,33,0,8,15,0,45,1,1,46,0,1,46,11,34,41,11,47,15,15,15,33,15,5,15,14,0]

theorem envBound6139 : H12AffineFastState.Bounded env6139 := by
  intro p hp
  have h : env6139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6138_6139 : H12AffineEnvironment.transform 3 4 env6138 = env6139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6138 == env6139) = true)

def env6140 : List Nat := [2,4,8,5,32,4,40,5,15,46,33,0,8,14,0,44,1,1,46,0,1,47,11,34,41,11,46,14,14,14,32,14,5,14,15,0]

theorem envBound6140 : H12AffineFastState.Bounded env6140 := by
  intro p hp
  have h : env6140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6138_6140 : H12AffineEnvironment.transform 3 5 env6138 = env6140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6138 == env6140) = true)

theorem identity6140 : scanCanonicalize (H12AffineFastState.compose env6140 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6141 : List Nat := [2,4,6,5,32,4,38,5,1,32,33,0,6,0,0,34,1,1,32,0,1,33,5,34,39,5,32,0,0,0,32,0,5,0,1,0]

theorem envBound6141 : H12AffineFastState.Bounded env6141 := by
  intro p hp
  have h : env6141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6140_6141 : H12AffineEnvironment.transform 2 6 env6140 = env6141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6140 == env6141) = true)

theorem identity6141 : scanCanonicalize (H12AffineFastState.compose env6141 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6141 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6142 : List Nat := [2,0,2,1,32,0,34,1,1,32,33,0,2,0,0,34,1,1,32,0,1,33,1,34,35,1,32,0,0,0,32,0,1,0,1,0]

theorem envBound6142 : H12AffineFastState.Bounded env6142 := by
  intro p hp
  have h : env6142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6141_6142 : H12AffineEnvironment.transform 1 0 env6141 = env6142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6141 == env6142) = true)

def leafEnv6142 : List Nat := [2,0,2,1,32,0,34,1,1,32,33,0,2,0,0,34,1,1,32,0,1,33,1,34,32,35,1,1,32,0,0,0,32,0,1,0,0,3,1,0,1,0,0]

def active6142 : List Nat := [0,4]

def tree6142 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6142 : H12WitnessSearch.Good tree6142 := H12GlobalWitnessIndex.good

theorem leafIdentity6142 : H12AffineFastState.composeSystem env6142 rootObs = leafEnv6142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6142 rootObs == leafEnv6142) = true)

theorem terminalChecked6142 : H12PackedTerminal.terminalCheckFast leafEnv6142 active6142 tree6142 = true := by decide +kernel

def env6143 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,98307,8388608,41002,8224,8388608,323624,16384,16644,22561,74794,8483135,256,20480,77866,8389397]

theorem envBound6143 : H12AffineFastState.Bounded env6143 := by
  intro p hp
  have h : env6143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6126_6143 : H12AffineEnvironment.transform 6 41 env6126 = env6143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6126 == env6143) = true)

theorem identity6143 : scanCanonicalize (H12AffineFastState.compose env6143 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 96266) := by decide +kernel

theorem selectedBound6143 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6144 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,96266,1024,32768,4097,98307,8388608,41002,8224,8388608,100386,16384,16644,22561,74794,8483135,256,20480,77866,8389397]

theorem envBound6144 : H12AffineFastState.Bounded env6144 := by
  intro p hp
  have h : env6144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6143_6144 : H12AffineEnvironment.transform 17 96266 env6143 = env6144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96266 env6143 == env6144) = true)

theorem identity6144 : scanCanonicalize (H12AffineFastState.compose env6144 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound6144 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6145 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,53283,4357,43049,1024,32768,4097,20512,8388608,41002,8224,8388608,22529,16384,16644,22561,62473,8429852,256,20480,57353,8389397]

theorem envBound6145 : H12AffineFastState.Bounded env6145 := by
  intro p hp
  have h : env6145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6144_6145 : H12AffineEnvironment.transform 15 53283 env6144 = env6145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env6144 == env6145) = true)

theorem identity6145 : scanCanonicalize (H12AffineFastState.compose env6145 (packedSelected [0,1,7,8,9,10,12,13,17,18,22] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound6145 : packedSelected [0,1,7,8,9,10,12,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env6146 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1589,8192,16384,32768,50710,1840,43049,1024,32768,1588,17941,8388608,41002,8224,8388608,20020,16384,16644,19988,57916,8429852,256,17973,57353,8389397]

theorem envBound6146 : H12AffineFastState.Bounded env6146 := by
  intro p hp
  have h : env6146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6145_6146 : H12AffineEnvironment.transform 11 1589 env6145 = env6146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env6145 == env6146) = true)

theorem identity6146 : scanCanonicalize (H12AffineFastState.compose env6146 (packedSelected [5,10,12,17,18,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6146 : packedSelected [5,10,12,17,18,20,21,24] rootPS < 2^1333 := by decide +kernel

def env6147 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1589,8192,16384,8201,26143,1840,2080,1024,8201,1588,17941,8388608,35,8224,8388608,20020,16384,16644,19988,16949,8388885,256,17973,16384,8389397]

theorem envBound6147 : H12AffineFastState.Bounded env6147 := by
  intro p hp
  have h : env6147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6146_6147 : H12AffineEnvironment.transform 14 8201 env6146 = env6147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6146 == env6147) = true)

theorem identity6147 : scanCanonicalize (H12AffineFastState.compose env6147 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 18208) := by decide +kernel

theorem selectedBound6147 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6148 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1589,8192,16384,8201,26143,1840,2080,1024,8201,1588,17941,18208,35,8224,18208,20020,16384,16644,19988,16949,17973,256,17973,16384,17461]

theorem envBound6148 : H12AffineFastState.Bounded env6148 := by
  intro p hp
  have h : env6148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6147_6148 : H12AffineEnvironment.transform 22 18208 env6147 = env6148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 18208 env6147 == env6148) = true)

theorem identity6148 : scanCanonicalize (H12AffineFastState.compose env6148 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6149 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1589,8192,2341,8201,12090,1840,2080,1024,8201,1588,3888,3589,35,8224,3589,1809,2341,2081,1841,2832,3856,256,3856,2341,3344]

theorem envBound6149 : H12AffineFastState.Bounded env6149 := by
  intro p hp
  have h : env6149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6148_6149 : H12AffineEnvironment.transform 13 2341 env6148 = env6149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env6148 == env6149) = true)

theorem identity6149 : scanCanonicalize (H12AffineFastState.compose env6149 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 2838) := by decide +kernel

theorem selectedBound6149 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6150 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1589,2838,2341,2847,1068,1840,2080,1024,2847,1588,3888,3589,35,2870,3589,1809,2341,2081,1841,2832,3856,256,3856,2341,3344]

theorem envBound6150 : H12AffineFastState.Bounded env6150 := by
  intro p hp
  have h : env6150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6149_6150 : H12AffineEnvironment.transform 12 2838 env6149 = env6150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2838 env6149 == env6150) = true)

theorem identity6150 : scanCanonicalize (H12AffineFastState.compose env6150 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound6150 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env6151 : List Nat := [2,4,8,16,32,17,41,31,512,1024,2048,1589,2569,2106,2560,1068,1583,2080,1024,2560,1588,3631,3589,35,2601,3589,1550,2106,2081,1582,2575,3599,31,3599,2106,3087]

theorem envBound6151 : H12AffineFastState.Bounded env6151 := by
  intro p hp
  have h : env6151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6150_6151 : H12AffineEnvironment.transform 7 31 env6150 = env6151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env6150 == env6151) = true)

theorem identity6151 : scanCanonicalize (H12AffineFastState.compose env6151 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6151 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6152 : List Nat := [2,4,8,10,32,11,41,5,512,1024,2048,1583,2569,2080,2560,1068,1583,2080,1024,2560,1582,3631,3589,35,2601,3589,1550,2080,2081,1582,2575,3599,5,3599,2080,3087]

theorem envBound6152 : H12AffineFastState.Bounded env6152 := by
  intro p hp
  have h : env6152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6151_6152 : H12AffineEnvironment.transform 3 10 env6151 = env6152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6151 == env6152) = true)

theorem identity6152 : scanCanonicalize (H12AffineFastState.compose env6152 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6152 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6153 : List Nat := [2,4,8,10,32,11,41,5,512,1024,1550,1583,1031,1582,1038,1068,1583,1582,1024,1038,1582,33,11,35,1063,11,1550,1582,1583,1582,1025,1,5,1,1582,513]

theorem envBound6153 : H12AffineFastState.Bounded env6153 := by
  intro p hp
  have h : env6153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6152_6153 : H12AffineEnvironment.transform 10 1550 env6152 = env6153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6152 == env6153) = true)

theorem identity6153 : scanCanonicalize (H12AffineFastState.compose env6153 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound6153 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6154 : List Nat := [2,4,8,10,32,11,41,5,47,1024,1057,1024,1031,1025,1038,1068,1024,1025,1024,1038,1025,33,11,35,1063,11,1057,1025,1024,1025,1025,1,5,1,1025,46]

theorem envBound6154 : H12AffineFastState.Bounded env6154 := by
  intro p hp
  have h : env6154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6153_6154 : H12AffineEnvironment.transform 8 47 env6153 = env6154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env6153 == env6154) = true)

def env6155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323793,16384,16892,22641,74795,12644668,257,20560,4239488,8389612]

theorem envBound6155 : H12AffineFastState.Bounded env6155 := by
  intro p hp
  have h : env6155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6118_6155 : H12AffineEnvironment.transform 18 1025 env6118 = env6155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6118 == env6155) = true)

theorem identity6155 : scanCanonicalize (H12AffineFastState.compose env6155 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310354) := by decide +kernel

theorem selectedBound6155 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4310354,41002,8329,4310274,323793,16384,16892,22641,74795,78958,257,20560,4239488,4310718]

theorem envBound6156 : H12AffineFastState.Bounded env6156 := by
  intro p hp
  have h : env6156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6155_6156 : H12AffineEnvironment.transform 22 4310354 env6155 = env6156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310354 env6155 == env6156) = true)

def env6157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4310274,41002,8329,4310274,323713,16384,16812,22561,74795,78910,257,20480,4239488,4310718]

theorem envBound6157 : H12AffineFastState.Bounded env6157 := by
  intro p hp
  have h : env6157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6156_6157 : H12AffineEnvironment.transform 5 16 env6156 = env6157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6156 == env6157) = true)

def env6158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,65536,1029,262144,1025,32768,1449,4194304,4310274,41002,8329,4310274,320809,16384,16812,19849,74795,74134,257,17832,4236584,4310718]

theorem envBound6158 : H12AffineFastState.Bounded env6158 := by
  intro p hp
  have h : env6158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6157_6158 : H12AffineEnvironment.transform 11 1448 env6157 = env6158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env6157 == env6158) = true)

theorem identity6158 : scanCanonicalize (H12AffineFastState.compose env6158 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50319) := by decide +kernel

theorem selectedBound6158 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16384,16812,19849,57508,58649,257,17832,4236584,4194865]

theorem envBound6159 : H12AffineFastState.Bounded env6159 := by
  intro p hp
  have h : env6159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6158_6159 : H12AffineEnvironment.transform 15 50319 env6158 = env6159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50319 env6158 == env6159) = true)

def env6160 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16384,16812,19849,57508,58633,257,17832,4236584,4194849]

theorem envBound6160 : H12AffineFastState.Bounded env6160 := by
  intro p hp
  have h : env6160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6159_6160 : H12AffineEnvironment.transform 3 0 env6159 = env6160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6159 == env6160) = true)

theorem identity6160 : scanCanonicalize (H12AffineFastState.compose env6160 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6160 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6161 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8201,25734,1029,262144,1025,8201,1449,4194304,4194701,35,8329,4194701,279840,16384,16812,19849,16557,17664,257,17832,4195617,4194849]

theorem envBound6161 : H12AffineFastState.Bounded env6161 := by
  intro p hp
  have h : env6161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6160_6161 : H12AffineEnvironment.transform 14 8201 env6160 = env6161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6160 == env6161) = true)

theorem identity6161 : scanCanonicalize (H12AffineFastState.compose env6161 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound6161 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6162 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8201,25734,1029,262144,1025,8201,1449,32,429,35,8329,429,279840,16384,16812,19849,16557,17664,257,17832,1281,513]

theorem envBound6162 : H12AffineFastState.Bounded env6162 := by
  intro p hp
  have h : env6162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6161_6162 : H12AffineEnvironment.transform 21 32 env6161 = env6162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env6161 == env6162) = true)

theorem identity6162 : scanCanonicalize (H12AffineFastState.compose env6162 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound6162 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6163 : List Nat := [2,4,8,0,32,0,128,256,396,1024,2048,1448,8192,16384,8201,25734,1029,262144,1025,8201,1449,32,429,35,8329,429,279840,16384,16812,19849,16557,17664,257,17832,1281,397]

theorem envBound6163 : H12AffineFastState.Bounded env6163 := by
  intro p hp
  have h : env6163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6162_6163 : H12AffineEnvironment.transform 8 396 env6162 = env6163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env6162 == env6163) = true)

theorem identity6163 : scanCanonicalize (H12AffineFastState.compose env6163 (packedSelected [1,3,12,13,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound6163 : packedSelected [1,3,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env6164 : List Nat := [2,4,8,0,32,0,128,256,396,1024,2048,1448,8192,16384,8201,25734,1029,2445,1025,8201,1449,32,429,35,8329,429,19629,16384,16812,19849,16557,17664,257,17832,1281,397]

theorem envBound6164 : H12AffineFastState.Bounded env6164 := by
  intro p hp
  have h : env6164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6163_6164 : H12AffineEnvironment.transform 17 2445 env6163 = env6164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env6163 == env6164) = true)

theorem identity6164 : scanCanonicalize (H12AffineFastState.compose env6164 (packedSelected [1,3,6,7,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 2436) := by decide +kernel

theorem selectedBound6164 : packedSelected [1,3,6,7,9,15] rootPS < 2^1333 := by decide +kernel

def env6165 : List Nat := [2,4,8,0,32,0,128,256,396,1024,2048,1448,2436,16384,2445,19714,1029,2445,1025,2445,1449,32,429,35,2317,429,19629,16384,16812,19849,16557,17664,257,17832,1281,397]

theorem envBound6165 : H12AffineFastState.Bounded env6165 := by
  intro p hp
  have h : env6165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6164_6165 : H12AffineEnvironment.transform 12 2436 env6164 = env6165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2436 env6164 == env6165) = true)

theorem identity6165 : scanCanonicalize (H12AffineFastState.compose env6165 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 1060) := by decide +kernel

theorem selectedBound6165 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6166 : List Nat := [2,4,8,0,32,0,128,256,396,1024,2048,1448,2436,1060,2445,2342,1029,2445,1025,2445,1449,32,429,35,2317,429,2185,1060,1416,2477,1161,292,257,396,1281,397]

theorem envBound6166 : H12AffineFastState.Bounded env6166 := by
  intro p hp
  have h : env6166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6165_6166 : H12AffineEnvironment.transform 13 1060 env6165 = env6166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1060 env6165 == env6166) = true)

theorem identity6166 : scanCanonicalize (H12AffineFastState.compose env6166 (packedSelected [0,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound6166 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env6167 : List Nat := [2,4,8,0,32,0,128,256,396,1024,429,1448,41,1060,32,139,1029,32,1025,32,1449,32,429,35,160,429,292,1060,1416,0,1161,292,257,396,1281,397]

theorem envBound6167 : H12AffineFastState.Bounded env6167 := by
  intro p hp
  have h : env6167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6166_6167 : H12AffineEnvironment.transform 10 429 env6166 = env6167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env6166 == env6167) = true)

theorem identity6167 : scanCanonicalize (H12AffineFastState.compose env6167 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 162) := by decide +kernel

theorem selectedBound6167 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env6168 : List Nat := [2,4,8,0,32,0,128,162,46,1024,15,1034,41,1060,32,139,1029,32,1025,32,1035,32,15,35,160,15,134,1060,1066,0,1161,134,163,46,1187,47]

theorem envBound6168 : H12AffineFastState.Bounded env6168 := by
  intro p hp
  have h : env6168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6167_6168 : H12AffineEnvironment.transform 7 162 env6167 = env6168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 162 env6167 == env6168) = true)

theorem identity6168 : scanCanonicalize (H12AffineFastState.compose env6168 (packedSelected [0,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound6168 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env6169 : List Nat := [2,4,8,0,5,0,128,135,11,1024,15,1034,12,1025,5,139,1029,5,1025,5,1035,5,15,6,133,15,134,1025,1039,0,1161,134,134,11,1158,10]

theorem envBound6169 : H12AffineFastState.Bounded env6169 := by
  intro p hp
  have h : env6169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6168_6169 : H12AffineEnvironment.transform 4 5 env6168 = env6169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env6168 == env6169) = true)

theorem identity6169 : scanCanonicalize (H12AffineFastState.compose env6169 (packedSelected [1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6169 : packedSelected [1,3,9] rootPS < 2^1333 := by decide +kernel

def env6170 : List Nat := [2,4,8,0,5,0,128,135,11,14,15,4,12,15,5,139,11,5,15,5,5,5,15,6,133,15,134,15,1,0,135,134,134,11,136,10]

theorem envBound6170 : H12AffineFastState.Bounded env6170 := by
  intro p hp
  have h : env6170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6169_6170 : H12AffineEnvironment.transform 9 14 env6169 = env6170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6169 == env6170) = true)

theorem identity6170 : scanCanonicalize (H12AffineFastState.compose env6170 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6170 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env6171 : List Nat := [2,4,6,0,5,0,128,135,5,0,1,4,2,1,5,133,5,5,1,5,5,5,1,6,133,1,134,1,1,0,135,134,134,5,134,4]

theorem envBound6171 : H12AffineFastState.Bounded env6171 := by
  intro p hp
  have h : env6171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6170_6171 : H12AffineEnvironment.transform 2 6 env6170 = env6171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6170 == env6171) = true)

theorem identity6171 : scanCanonicalize (H12AffineFastState.compose env6171 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound6171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6172 : List Nat := [2,4,6,0,5,0,3,4,5,0,1,4,2,1,5,6,5,5,1,5,5,5,1,6,6,1,5,1,1,0,4,5,5,5,5,4]

theorem envBound6172 : H12AffineFastState.Bounded env6172 := by
  intro p hp
  have h : env6172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6171_6172 : H12AffineEnvironment.transform 6 3 env6171 = env6172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env6171 == env6172) = true)

def leafEnv6172 : List Nat := [2,4,6,0,5,0,3,4,5,0,1,4,2,1,5,6,5,5,1,5,5,5,1,6,4,6,1,1,5,1,1,0,4,5,5,5,4,3,5,4,1,0,0]

def active6172 : List Nat := [0,1]

def tree6172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6172 : H12WitnessSearch.Good tree6172 := H12GlobalWitnessIndex.good

theorem leafIdentity6172 : H12AffineFastState.composeSystem env6172 rootObs = leafEnv6172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6172 rootObs == leafEnv6172) = true)

theorem terminalChecked6172 : H12PackedTerminal.terminalCheckFast leafEnv6172 active6172 tree6172 = true := by decide +kernel

def env6173 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50319,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16384,16812,19849,57508,58632,257,17832,4236584,4194848]

theorem envBound6173 : H12AffineFastState.Bounded env6173 := by
  intro p hp
  have h : env6173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6159_6173 : H12AffineEnvironment.transform 3 1 env6159 = env6173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6159 == env6173) = true)

theorem identity6173 : scanCanonicalize (H12AffineFastState.compose env6173 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6173 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6174 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50319,1029,262144,1025,32768,1196,4194304,4194440,41002,8329,4194440,320556,16384,16553,19596,57508,58381,4,17581,4236333,4194848]

theorem envBound6174 : H12AffineFastState.Bounded env6174 := by
  intro p hp
  have h : env6174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6173_6174 : H12AffineEnvironment.transform 7 5 env6173 = env6174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6173 == env6174) = true)

theorem identity6174 : scanCanonicalize (H12AffineFastState.compose env6174 (packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6174 : packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env6175 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50319,1029,2081,1025,32768,1196,4194304,4194440,41002,8329,4194440,60429,16384,16553,19596,57508,58381,4,17581,4236333,4194848]

theorem envBound6175 : H12AffineFastState.Bounded env6175 := by
  intro p hp
  have h : env6175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6174_6175 : H12AffineEnvironment.transform 17 2081 env6174 = env6175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6174 == env6175) = true)

theorem identity6175 : scanCanonicalize (H12AffineFastState.compose env6175 (packedSelected [1,4,6,8,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 59907) := by decide +kernel

theorem selectedBound6175 : packedSelected [1,4,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env6176 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50319,1029,2081,1025,32768,1196,59907,60043,41002,8329,60043,60429,16384,16553,19596,57508,58381,4,17581,20014,59427]

theorem envBound6176 : H12AffineFastState.Bounded env6176 := by
  intro p hp
  have h : env6176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6175_6176 : H12AffineEnvironment.transform 21 59907 env6175 = env6176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 59907 env6175 == env6176) = true)

theorem identity6176 : scanCanonicalize (H12AffineFastState.compose env6176 (packedSelected [13,18,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6176 : packedSelected [13,18,21,23] rootPS < 2^1333 := by decide +kernel

def env6177 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,8200,25735,1029,2081,1025,8200,1196,18955,19075,34,8329,19075,19461,16384,16553,19596,16556,17413,4,17581,20014,18475]

theorem envBound6177 : H12AffineFastState.Bounded env6177 := by
  intro p hp
  have h : env6177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6176_6177 : H12AffineEnvironment.transform 14 8200 env6176 = env6177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6176 == env6177) = true)

theorem identity6177 : scanCanonicalize (H12AffineFastState.compose env6177 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1670) := by decide +kernel

theorem selectedBound6177 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6178 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1670,1197,8192,16384,8200,25735,1029,1703,1025,8200,1196,17549,17413,34,8329,17413,17027,16384,16553,16906,16556,17413,4,17581,16552,18093]

theorem envBound6178 : H12AffineFastState.Bounded env6178 := by
  intro p hp
  have h : env6178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6177_6178 : H12AffineEnvironment.transform 10 1670 env6177 = env6178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1670 env6177 == env6178) = true)

theorem identity6178 : scanCanonicalize (H12AffineFastState.compose env6178 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 8843) := by decide +kernel

theorem selectedBound6178 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env6179 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1670,1197,8192,8843,8200,1548,1029,1703,1025,8200,1196,9734,9870,34,8329,9870,8200,8843,8738,8321,8743,9870,4,9766,8739,9254]

theorem envBound6179 : H12AffineFastState.Bounded env6179 := by
  intro p hp
  have h : env6179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6178_6179 : H12AffineEnvironment.transform 13 8843 env6178 = env6179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8843 env6178 == env6179) = true)

theorem identity6179 : scanCanonicalize (H12AffineFastState.compose env6179 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1700) := by decide +kernel

theorem selectedBound6179 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6180 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1670,1197,1700,1071,1708,1548,1029,1703,1025,1708,1196,162,42,34,1581,42,1708,1071,1158,1573,1155,42,4,130,1159,642]

theorem envBound6180 : H12AffineFastState.Bounded env6180 := by
  intro p hp
  have h : env6180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6179_6180 : H12AffineEnvironment.transform 12 1700 env6179 = env6180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1700 env6179 == env6180) = true)

theorem identity6180 : scanCanonicalize (H12AffineFastState.compose env6180 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound6180 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6181 : List Nat := [2,4,8,1,32,1,128,5,512,166,544,11,514,137,522,682,163,513,167,522,10,162,42,34,651,42,522,137,32,643,37,42,4,130,33,642]

theorem envBound6181 : H12AffineFastState.Bounded env6181 := by
  intro p hp
  have h : env6181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6180_6181 : H12AffineEnvironment.transform 9 166 env6180 = env6181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env6180 == env6181) = true)

theorem identity6181 : scanCanonicalize (H12AffineFastState.compose env6181 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6181 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env6182 : List Nat := [2,4,8,1,10,1,128,5,512,140,522,11,514,137,522,640,137,513,141,522,10,136,0,8,651,0,522,137,10,643,15,0,4,130,11,642]

theorem envBound6182 : H12AffineFastState.Bounded env6182 := by
  intro p hp
  have h : env6182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6181_6182 : H12AffineEnvironment.transform 4 10 env6181 = env6182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6181 == env6182) = true)

theorem identity6182 : scanCanonicalize (H12AffineFastState.compose env6182 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound6182 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6183 : List Nat := [2,4,8,1,10,1,9,5,512,5,522,11,514,0,522,521,0,513,4,522,10,1,0,8,514,0,522,0,10,522,15,0,4,11,11,523]

theorem envBound6183 : H12AffineFastState.Bounded env6183 := by
  intro p hp
  have h : env6183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6182_6183 : H12AffineEnvironment.transform 6 9 env6182 = env6183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env6182 == env6183) = true)

theorem identity6183 : scanCanonicalize (H12AffineFastState.compose env6183 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6184 : List Nat := [2,4,2,1,0,1,3,5,512,5,512,1,514,0,512,515,0,513,4,512,0,1,0,2,514,0,512,0,0,512,5,0,4,1,1,513]

theorem envBound6184 : H12AffineFastState.Bounded env6184 := by
  intro p hp
  have h : env6184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6183_6184 : H12AffineEnvironment.transform 2 2 env6183 = env6184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6183 == env6184) = true)

theorem identity6184 : scanCanonicalize (H12AffineFastState.compose env6184 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6185 : List Nat := [2,1,2,1,0,1,3,0,512,0,512,1,514,0,512,515,0,513,1,512,0,1,0,2,514,0,512,0,0,512,0,0,1,1,1,513]

theorem envBound6185 : H12AffineFastState.Bounded env6185 := by
  intro p hp
  have h : env6185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6184_6185 : H12AffineEnvironment.transform 1 1 env6184 = env6185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6184 == env6185) = true)

theorem identity6185 : scanCanonicalize (H12AffineFastState.compose env6185 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6185 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6186 : List Nat := [2,1,2,1,0,1,3,0,1,0,1,1,3,0,1,2,0,0,1,1,0,1,0,2,3,0,1,0,0,1,0,0,1,1,1,0]

theorem envBound6186 : H12AffineFastState.Bounded env6186 := by
  intro p hp
  have h : env6186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6185_6186 : H12AffineEnvironment.transform 8 1 env6185 = env6186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6185 == env6186) = true)

def env6187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,65536,1028,262144,1025,32768,1448,4194304,4310274,41002,8329,4310274,320808,16384,16812,19848,74795,74135,257,17833,4236585,4310718]

theorem envBound6187 : H12AffineFastState.Bounded env6187 := by
  intro p hp
  have h : env6187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6157_6187 : H12AffineEnvironment.transform 11 1449 env6157 = env6187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env6157 == env6187) = true)

theorem identity6187 : scanCanonicalize (H12AffineFastState.compose env6187 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50483) := by decide +kernel

theorem selectedBound6187 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,50483,1028,262144,1025,32768,1448,4194304,4194353,41002,8329,4194353,320808,16384,16812,19848,57624,58532,257,17833,4236585,4195213]

theorem envBound6188 : H12AffineFastState.Bounded env6188 := by
  intro p hp
  have h : env6188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6187_6188 : H12AffineEnvironment.transform 15 50483 env6187 = env6188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50483 env6187 == env6188) = true)

def env6189 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50467,1028,262144,1025,32768,1448,4194304,4194337,41002,8329,4194337,320808,16384,16812,19848,57608,58532,257,17833,4236585,4195213]

theorem envBound6189 : H12AffineFastState.Bounded env6189 := by
  intro p hp
  have h : env6189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6188_6189 : H12AffineEnvironment.transform 3 0 env6188 = env6189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6188 == env6189) = true)

def env6190 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50467,1028,262144,1025,32768,1448,41088,41121,41002,8329,41121,320808,16384,16812,19848,57608,58532,257,17833,1449,41741]

theorem envBound6190 : H12AffineFastState.Bounded env6190 := by
  intro p hp
  have h : env6190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6189_6190 : H12AffineEnvironment.transform 21 41088 env6189 = env6190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6189 == env6190) = true)

theorem identity6190 : scanCanonicalize (H12AffineFastState.compose env6190 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6190 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6191 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,16384,32768,50215,1028,262144,1025,32768,1196,41088,41121,41002,8329,41121,320556,16384,16552,19596,57356,58532,5,17581,1197,41481]

theorem envBound6191 : H12AffineFastState.Bounded env6191 := by
  intro p hp
  have h : env6191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6190_6191 : H12AffineEnvironment.transform 7 4 env6190 = env6191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6190 == env6191) = true)

theorem identity6191 : scanCanonicalize (H12AffineFastState.compose env6191 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound6191 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6192 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1677,32768,33450,1028,262144,1025,32768,1196,41088,41121,41002,8329,41121,303777,1677,1573,2561,42625,41513,5,544,1197,41481]

theorem envBound6192 : H12AffineFastState.Bounded env6192 := by
  intro p hp
  have h : env6192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6191_6192 : H12AffineEnvironment.transform 13 1677 env6191 = env6192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env6191 == env6192) = true)

theorem identity6192 : scanCanonicalize (H12AffineFastState.compose env6192 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8832) := by decide +kernel

theorem selectedBound6192 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env6193 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1677,8832,8234,1028,262144,1025,8832,1196,512,545,682,8329,545,262177,1677,1573,2561,1025,169,5,544,1197,137]

theorem envBound6193 : H12AffineFastState.Bounded env6193 := by
  intro p hp
  have h : env6193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6192_6193 : H12AffineEnvironment.transform 14 8832 env6192 = env6193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env6192 == env6193) = true)

end H12CloudChart0