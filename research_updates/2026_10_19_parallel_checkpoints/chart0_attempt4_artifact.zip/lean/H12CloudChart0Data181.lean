import H12CloudChart0Data180

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity45841 : scanCanonicalize (H12AffineFastState.compose env45841 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound45841 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45842 : List Nat := [2,4,8,16,32,64,9,36,512,37,80,64,41,64,1,115,1,0,37,0,0,33,17,2,40,64,0,81,64,81,85,112,36,32,65,593]

theorem envBound45842 : H12AffineFastState.Bounded env45842 := by
  intro p hp
  have h : env45842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45841_45842 : H12AffineEnvironment.transform 11 64 env45841 = env45842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env45841 == env45842) = true)

theorem identity45842 : scanCanonicalize (H12AffineFastState.compose env45842 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45842 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45843 : List Nat := [2,4,8,16,32,17,9,36,512,37,1,17,41,17,1,34,1,0,37,0,0,33,17,2,40,17,0,0,17,0,4,33,36,32,16,512]

theorem envBound45843 : H12AffineFastState.Bounded env45843 := by
  intro p hp
  have h : env45843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45842_45843 : H12AffineEnvironment.transform 5 17 env45842 = env45843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45842 == env45843) = true)

theorem identity45843 : scanCanonicalize (H12AffineFastState.compose env45843 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45844 : List Nat := [2,4,8,16,1,17,9,5,512,4,1,17,8,17,1,3,1,0,4,0,0,0,17,2,9,17,0,0,17,0,4,0,5,1,16,512]

theorem envBound45844 : H12AffineFastState.Bounded env45844 := by
  intro p hp
  have h : env45844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45843_45844 : H12AffineEnvironment.transform 4 1 env45843 = env45844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45843 == env45844) = true)

theorem identity45844 : scanCanonicalize (H12AffineFastState.compose env45844 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound45844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45845 : List Nat := [2,4,8,16,1,17,9,5,4,4,1,17,8,17,1,3,1,0,4,0,0,0,17,2,9,17,0,0,17,0,4,0,5,1,16,4]

theorem envBound45845 : H12AffineFastState.Bounded env45845 := by
  intro p hp
  have h : env45845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45844_45845 : H12AffineEnvironment.transform 8 4 env45844 = env45845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env45844 == env45845) = true)

theorem identity45845 : scanCanonicalize (H12AffineFastState.compose env45845 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45845 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45846 : List Nat := [2,4,8,10,1,11,9,5,4,4,1,11,8,11,1,3,1,0,4,0,0,0,11,2,9,11,0,0,11,0,4,0,5,1,10,4]

theorem envBound45846 : H12AffineFastState.Bounded env45846 := by
  intro p hp
  have h : env45846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45845_45846 : H12AffineEnvironment.transform 3 10 env45845 = env45846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45845 == env45846) = true)

theorem identity45846 : scanCanonicalize (H12AffineFastState.compose env45846 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45846 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45847 : List Nat := [2,4,3,1,1,0,2,5,4,4,1,0,3,0,1,3,1,0,4,0,0,0,0,2,2,0,0,0,0,0,4,0,5,1,1,4]

theorem envBound45847 : H12AffineFastState.Bounded env45847 := by
  intro p hp
  have h : env45847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45846_45847 : H12AffineEnvironment.transform 2 3 env45846 = env45847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45846 == env45847) = true)

theorem identity45847 : scanCanonicalize (H12AffineFastState.compose env45847 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45848 : List Nat := [2,3,3,1,1,0,2,2,3,3,1,0,3,0,1,3,1,0,3,0,0,0,0,2,2,0,0,0,0,0,3,0,2,1,1,3]

theorem envBound45848 : H12AffineFastState.Bounded env45848 := by
  intro p hp
  have h : env45848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45847_45848 : H12AffineEnvironment.transform 1 3 env45847 = env45848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45847 == env45848) = true)

def env45849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21913,98644,8328,64,410093,16536,17800,431513,20700,62709,256,21793,46213,96010]

theorem envBound45849 : H12AffineFastState.Bounded env45849 := by
  intro p hp
  have h : env45849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45830_45849 : H12AffineEnvironment.transform 21 21793 env45830 = env45849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env45830 == env45849) = true)

theorem identity45849 : scanCanonicalize (H12AffineFastState.compose env45849 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound45849 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,17729,21793,21913,138,8328,64,410093,16536,17800,431513,20700,62709,256,21793,46213,63188]

theorem envBound45850 : H12AffineFastState.Bounded env45850 := by
  intro p hp
  have h : env45850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45849_45850 : H12AffineEnvironment.transform 15 33246 env45849 = env45850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env45849 == env45850) = true)

def env45851 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33030,131072,262144,1024,32769,17729,21793,21825,82,8272,64,409909,16448,17744,431425,20484,62509,256,21793,46173,62988]

theorem envBound45851 : H12AffineFastState.Bounded env45851 := by
  intro p hp
  have h : env45851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45850_45851 : H12AffineEnvironment.transform 6 88 env45850 = env45851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45850 == env45851) = true)

theorem identity45851 : scanCanonicalize (H12AffineFastState.compose env45851 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound45851 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env45852 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33030,131072,146744,1024,32769,17729,21793,21825,82,8272,64,31757,16448,17744,43129,20484,62509,256,21793,46173,62988]

theorem envBound45852 : H12AffineFastState.Bounded env45852 := by
  intro p hp
  have h : env45852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45851_45852 : H12AffineEnvironment.transform 17 146744 env45851 = env45852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env45851 == env45852) = true)

theorem identity45852 : scanCanonicalize (H12AffineFastState.compose env45852 (packedSelected [0,9,21,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45852 : packedSelected [0,9,21,22,27] rootPS < 2^1333 := by decide +kernel

def env45853 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,8540,8282,131072,146744,1024,8541,17729,21793,21825,82,8272,64,31757,16448,17744,2341,20484,21873,256,21793,5377,22352]

theorem envBound45853 : H12AffineFastState.Bounded env45853 := by
  intro p hp
  have h : env45853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45852_45853 : H12AffineEnvironment.transform 14 8540 env45852 = env45853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45852 == env45853) = true)

theorem identity45853 : scanCanonicalize (H12AffineFastState.compose env45853 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45853 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env45854 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8540,8282,131072,146744,1024,8541,4112,112,16,82,8272,64,10588,5393,4097,2341,1365,32,256,112,5377,513]

theorem envBound45854 : H12AffineFastState.Bounded env45854 := by
  intro p hp
  have h : env45854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45853_45854 : H12AffineEnvironment.transform 13 5457 env45853 = env45854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45853 == env45854) = true)

theorem identity45854 : scanCanonicalize (H12AffineFastState.compose env45854 (packedSelected [0,2,6,7,9,14,20,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45854 : packedSelected [0,2,6,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env45855 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8202,131072,146744,1024,8461,4112,32,16,2,8192,16,10508,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound45855 : H12AffineFastState.Bounded env45855 := by
  intro p hp
  have h : env45855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45854_45855 : H12AffineEnvironment.transform 5 16 env45854 = env45855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45854 == env45855) = true)

theorem identity45855 : scanCanonicalize (H12AffineFastState.compose env45855 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound45855 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45856 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8202,5392,10280,1024,8461,4112,32,16,2,8192,16,10508,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound45856 : H12AffineFastState.Bounded env45856 := by
  intro p hp
  have h : env45856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45855_45856 : H12AffineEnvironment.transform 16 5392 env45855 = env45856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env45855 == env45856) = true)

theorem identity45856 : scanCanonicalize (H12AffineFastState.compose env45856 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound45856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45857 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8,5377,260,2,5392,2080,1024,261,4112,32,16,2,8,16,2308,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound45857 : H12AffineFastState.Bounded env45857 := by
  intro p hp
  have h : env45857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45856_45857 : H12AffineEnvironment.transform 12 8 env45856 = env45857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env45856 == env45857) = true)

theorem identity45857 : scanCanonicalize (H12AffineFastState.compose env45857 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45857 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45858 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8,4405,260,2,4388,2080,52,261,4112,32,16,2,8,16,2308,4389,4097,2341,305,32,256,32,4405,513]

theorem envBound45858 : H12AffineFastState.Bounded env45858 := by
  intro p hp
  have h : env45858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45857_45858 : H12AffineEnvironment.transform 9 52 env45857 = env45858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45857 == env45858) = true)

theorem identity45858 : scanCanonicalize (H12AffineFastState.compose env45858 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound45858 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env45859 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2064,8,2341,260,2,2356,2080,52,261,2048,32,16,2,8,16,2308,2357,2065,2341,305,32,256,32,2341,513]

theorem envBound45859 : H12AffineFastState.Bounded env45859 := by
  intro p hp
  have h : env45859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45858_45859 : H12AffineEnvironment.transform 11 2064 env45858 = env45859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env45858 == env45859) = true)

theorem identity45859 : scanCanonicalize (H12AffineFastState.compose env45859 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound45859 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45860 : List Nat := [2,4,8,16,32,16,8,256,512,52,528,512,8,821,260,2,804,560,52,261,528,32,16,2,8,16,788,805,513,821,305,32,256,32,821,513]

theorem envBound45860 : H12AffineFastState.Bounded env45860 := by
  intro p hp
  have h : env45860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45859_45860 : H12AffineEnvironment.transform 10 528 env45859 = env45860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env45859 == env45860) = true)

theorem identity45860 : scanCanonicalize (H12AffineFastState.compose env45860 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45860 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env45861 : List Nat := [2,4,8,16,32,16,8,36,512,52,528,512,8,529,32,2,512,560,52,33,528,32,16,2,8,16,560,513,513,529,21,32,36,32,529,513]

theorem envBound45861 : H12AffineFastState.Bounded env45861 := by
  intro p hp
  have h : env45861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45860_45861 : H12AffineEnvironment.transform 7 36 env45860 = env45861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45860 == env45861) = true)

theorem identity45861 : scanCanonicalize (H12AffineFastState.compose env45861 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45862 : List Nat := [2,4,8,16,32,16,8,36,17,52,1,17,8,0,32,2,17,33,52,33,1,32,16,2,8,16,33,16,16,0,21,32,36,32,0,16]

theorem envBound45862 : H12AffineFastState.Bounded env45862 := by
  intro p hp
  have h : env45862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45861_45862 : H12AffineEnvironment.transform 8 17 env45861 = env45862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45861 == env45862) = true)

theorem identity45862 : scanCanonicalize (H12AffineFastState.compose env45862 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45862 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45863 : List Nat := [2,4,8,0,32,0,8,36,1,36,1,1,8,0,32,2,1,33,36,33,1,32,0,2,8,0,33,0,0,0,5,32,36,32,0,0]

theorem envBound45863 : H12AffineFastState.Bounded env45863 := by
  intro p hp
  have h : env45863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45862_45863 : H12AffineEnvironment.transform 3 0 env45862 = env45863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45862 == env45863) = true)

theorem identity45863 : scanCanonicalize (H12AffineFastState.compose env45863 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45863 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45864 : List Nat := [2,4,8,0,1,0,8,5,1,5,1,1,8,0,1,2,1,0,5,0,1,1,0,2,8,0,0,0,0,0,5,1,5,1,0,0]

theorem envBound45864 : H12AffineFastState.Bounded env45864 := by
  intro p hp
  have h : env45864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45863_45864 : H12AffineEnvironment.transform 4 1 env45863 = env45864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45863 == env45864) = true)

def env45865 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33031,131072,262144,1024,32769,17729,21793,21824,83,8273,64,409908,16449,17745,431424,20485,62508,256,21793,46172,62989]

theorem envBound45865 : H12AffineFastState.Bounded env45865 := by
  intro p hp
  have h : env45865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45850_45865 : H12AffineEnvironment.transform 6 89 env45850 = env45865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45850 == env45865) = true)

theorem identity45865 : scanCanonicalize (H12AffineFastState.compose env45865 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound45865 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env45866 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33031,131072,171060,1024,32769,17729,21793,21824,83,8273,64,56576,16449,17745,2420,20485,62508,256,21793,46172,62989]

theorem envBound45866 : H12AffineFastState.Bounded env45866 := by
  intro p hp
  have h : env45866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45865_45866 : H12AffineEnvironment.transform 17 171060 env45865 = env45866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env45865 == env45866) = true)

theorem identity45866 : scanCanonicalize (H12AffineFastState.compose env45866 (packedSelected [3,4,5,7,8,9,10,16,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound45866 : packedSelected [3,4,5,7,8,9,10,16,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45867 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,29963,131072,157752,1024,29709,17729,21793,21824,83,8273,64,10508,16449,17745,2420,20485,32,256,21793,16464,513]

theorem envBound45867 : H12AffineFastState.Bounded env45867 := by
  intro p hp
  have h : env45867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45866_45867 : H12AffineEnvironment.transform 14 29708 env45866 = env45867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env45866 == env45867) = true)

def env45868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound45868 : H12AffineFastState.Bounded env45868 := by
  intro p hp
  have h : env45868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45687_45868 : H12AffineEnvironment.transform 18 1025 env45687 = env45868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45687 == env45868) = true)

theorem identity45868 : scanCanonicalize (H12AffineFastState.compose env45868 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237589) := by decide +kernel

theorem selectedBound45868 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,16777216,8328,64,23454869,18973836,160197,2417812,19112068,23160257,257,17031225,16974236,19040083]

theorem envBound45869 : H12AffineFastState.Bounded env45869 := by
  intro p hp
  have h : env45869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45868_45869 : H12AffineEnvironment.transform 22 2237589 env45868 = env45869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237589 env45868 == env45869) = true)

def env45870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,242968,8328,64,6705549,2240916,160197,2417812,2102684,6475993,257,21793,46212,2175563]

theorem envBound45870 : H12AffineFastState.Bounded env45870 := by
  intro p hp
  have h : env45870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45869_45870 : H12AffineEnvironment.transform 23 242968 env45869 = env45870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env45869 == env45870) = true)

def env45871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237589,242968,8328,64,2144541,2240916,160197,2417812,2102684,2373705,257,21793,46212,2175563]

theorem envBound45871 : H12AffineFastState.Bounded env45871 := by
  intro p hp
  have h : env45871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45870_45871 : H12AffineEnvironment.transform 21 452752 env45870 = env45871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env45870 == env45871) = true)

def env45872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144597,242968,8328,64,43357,139732,160197,324820,1500,272393,257,21793,46212,74251]

theorem envBound45872 : H12AffineFastState.Bounded env45872 := by
  intro p hp
  have h : env45872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45871_45872 : H12AffineEnvironment.transform 20 4160 env45871 = env45872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45871 == env45872) = true)

def env45873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180408,144597,242968,8328,64,43357,139732,160197,56572,1500,33,257,21793,46212,74251]

theorem envBound45873 : H12AffineFastState.Bounded env45873 := by
  intro p hp
  have h : env45873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45872_45873 : H12AffineEnvironment.transform 17 10280 env45872 = env45873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45872 == env45873) = true)

def env45874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,21928,41413,73736,8328,64,43357,46276,58581,56572,1500,33,257,21793,46212,74251]

theorem envBound45874 : H12AffineFastState.Bounded env45874 := by
  intro p hp
  have h : env45874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45873_45874 : H12AffineEnvironment.transform 16 38160 env45873 = env45874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env45873 == env45874) = true)

theorem identity45874 : scanCanonicalize (H12AffineFastState.compose env45874 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45874 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13389,10280,1025,8540,4160,21928,152,73736,8328,64,2048,5529,17800,32161,1500,33,257,21793,5593,74251]

theorem envBound45875 : H12AffineFastState.Bounded env45875 := by
  intro p hp
  have h : env45875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45874_45875 : H12AffineEnvironment.transform 14 8541 env45874 = env45875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45874 == env45875) = true)

theorem identity45875 : scanCanonicalize (H12AffineFastState.compose env45875 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45875 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env45876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,65536,5392,2421,1025,1,4160,21928,152,65877,469,64,2048,5529,17800,23804,1500,33,257,21793,5593,66390]

theorem envBound45876 : H12AffineFastState.Bounded env45876 := by
  intro p hp
  have h : env45876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45875_45876 : H12AffineEnvironment.transform 12 349 env45875 = env45876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45875 == env45876) = true)

theorem identity45876 : scanCanonicalize (H12AffineFastState.compose env45876 (packedSelected [5,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45876 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env45877 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,16384,0,65536,4096,2421,273,1,4160,20664,152,65877,469,64,2048,4233,16536,23020,204,33,257,20529,4297,66390]

theorem envBound45877 : H12AffineFastState.Bounded env45877 := by
  intro p hp
  have h : env45877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45876_45877 : H12AffineEnvironment.transform 9 272 env45876 = env45877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45876 == env45877) = true)

theorem identity45877 : scanCanonicalize (H12AffineFastState.compose env45877 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound45877 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env45878 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4405,0,65536,4096,2421,273,1,4160,397,152,65877,469,64,2048,4233,4525,2265,204,33,257,260,4297,66390]

theorem envBound45878 : H12AffineFastState.Bounded env45878 := by
  intro p hp
  have h : env45878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45877_45878 : H12AffineEnvironment.transform 13 4405 env45877 = env45878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env45877 == env45878) = true)

theorem identity45878 : scanCanonicalize (H12AffineFastState.compose env45878 (packedSelected [2,3,5,6,9,10,11,14,16,18,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound45878 : packedSelected [2,3,5,6,9,10,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env45879 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,161,4297,0,65536,4096,2185,237,1,4160,113,152,65705,41,64,2048,4233,4177,2265,204,33,253,248,4297,66218]

theorem envBound45879 : H12AffineFastState.Bounded env45879 := by
  intro p hp
  have h : env45879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45878_45879 : H12AffineEnvironment.transform 7 252 env45878 = env45879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env45878 == env45879) = true)

theorem identity45879 : scanCanonicalize (H12AffineFastState.compose env45879 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound45879 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45880 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,161,4297,0,34,4096,2185,237,1,4160,113,152,139,41,64,2048,4233,4177,2265,204,33,253,248,4297,648]

theorem envBound45880 : H12AffineFastState.Bounded env45880 := by
  intro p hp
  have h : env45880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45879_45880 : H12AffineEnvironment.transform 15 34 env45879 = env45880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env45879 == env45880) = true)

theorem identity45880 : scanCanonicalize (H12AffineFastState.compose env45880 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound45880 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45881 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,2201,161,2128,0,34,2201,2185,237,1,2265,113,152,139,41,64,2048,2064,2248,2265,204,33,253,248,2128,648]

theorem envBound45881 : H12AffineFastState.Bounded env45881 := by
  intro p hp
  have h : env45881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45880_45881 : H12AffineEnvironment.transform 11 2201 env45880 = env45881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env45880 == env45881) = true)

theorem identity45881 : scanCanonicalize (H12AffineFastState.compose env45881 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45881 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45882 : List Nat := [2,4,8,16,32,16,128,172,512,188,2048,2201,161,2048,0,34,2201,2185,189,1,2185,33,152,139,41,16,2048,2064,2200,2185,156,33,173,168,2048,648]

theorem envBound45882 : H12AffineFastState.Bounded env45882 := by
  intro p hp
  have h : env45882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45881_45882 : H12AffineEnvironment.transform 5 16 env45881 = env45882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45881 == env45882) = true)

theorem identity45882 : scanCanonicalize (H12AffineFastState.compose env45882 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound45882 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45883 : List Nat := [2,4,8,16,32,16,128,172,512,188,544,697,161,544,0,34,697,681,189,1,681,33,152,139,41,16,544,560,696,681,156,33,173,168,544,648]

theorem envBound45883 : H12AffineFastState.Bounded env45883 := by
  intro p hp
  have h : env45883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45882_45883 : H12AffineEnvironment.transform 10 544 env45882 = env45883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env45882 == env45883) = true)

theorem identity45883 : scanCanonicalize (H12AffineFastState.compose env45883 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound45883 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45884 : List Nat := [2,4,8,16,32,16,24,52,512,36,544,545,57,544,0,34,545,561,37,1,561,33,0,19,41,16,544,560,544,561,4,33,53,48,544,528]

theorem envBound45884 : H12AffineFastState.Bounded env45884 := by
  intro p hp
  have h : env45884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45883_45884 : H12AffineEnvironment.transform 6 24 env45883 = env45884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env45883 == env45884) = true)

theorem identity45884 : scanCanonicalize (H12AffineFastState.compose env45884 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45884 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45885 : List Nat := [2,4,8,16,0,16,24,20,512,4,512,513,25,512,0,2,513,529,5,1,529,1,0,19,9,16,512,528,512,529,4,1,21,16,512,528]

theorem envBound45885 : H12AffineFastState.Bounded env45885 := by
  intro p hp
  have h : env45885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45884_45885 : H12AffineEnvironment.transform 4 0 env45884 = env45885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45884 == env45885) = true)

theorem identity45885 : scanCanonicalize (H12AffineFastState.compose env45885 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45886 : List Nat := [2,4,8,1,0,1,9,5,512,4,512,513,8,512,0,2,513,512,5,1,512,1,0,2,9,1,512,513,512,512,4,1,4,1,512,513]

theorem envBound45886 : H12AffineFastState.Bounded env45886 := by
  intro p hp
  have h : env45886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45885_45886 : H12AffineEnvironment.transform 3 1 env45885 = env45886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45885 == env45886) = true)

theorem identity45886 : scanCanonicalize (H12AffineFastState.compose env45886 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound45886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45887 : List Nat := [2,4,8,1,0,1,9,5,5,4,5,4,8,5,0,2,4,5,5,1,5,1,0,2,9,1,5,4,5,5,4,1,4,1,5,4]

theorem envBound45887 : H12AffineFastState.Bounded env45887 := by
  intro p hp
  have h : env45887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45886_45887 : H12AffineEnvironment.transform 8 5 env45886 = env45887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env45886 == env45887) = true)

theorem identity45887 : scanCanonicalize (H12AffineFastState.compose env45887 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45888 : List Nat := [2,4,4,1,0,1,5,5,5,4,5,4,4,5,0,2,4,5,5,1,5,1,0,2,5,1,5,4,5,5,4,1,4,1,5,4]

theorem envBound45888 : H12AffineFastState.Bounded env45888 := by
  intro p hp
  have h : env45888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45887_45888 : H12AffineEnvironment.transform 2 4 env45887 = env45888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45887 == env45888) = true)

theorem identity45888 : scanCanonicalize (H12AffineFastState.compose env45888 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45888 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45889 : List Nat := [1,4,4,1,0,1,5,5,5,4,5,4,4,5,0,1,4,5,5,1,5,1,0,1,5,1,5,4,5,5,4,1,4,1,5,4]

theorem envBound45889 : H12AffineFastState.Bounded env45889 := by
  intro p hp
  have h : env45889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45888_45889 : H12AffineEnvironment.transform 0 1 env45888 = env45889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45888 == env45889) = true)

theorem identity45889 : scanCanonicalize (H12AffineFastState.compose env45889 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45889 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45890 : List Nat := [1,0,0,1,0,1,1,1,1,0,1,0,0,1,0,1,0,1,1,1,1,1,0,1,1,1,1,0,1,1,0,1,0,1,1,0]

theorem envBound45890 : H12AffineFastState.Bounded env45890 := by
  intro p hp
  have h : env45890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45889_45890 : H12AffineEnvironment.transform 1 0 env45889 = env45890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45889 == env45890) = true)

def env45891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,21929,41412,73737,8328,64,43357,46277,58580,56572,1500,33,257,21793,46212,74251]

theorem envBound45891 : H12AffineFastState.Bounded env45891 := by
  intro p hp
  have h : env45891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45873_45891 : H12AffineEnvironment.transform 16 38161 env45873 = env45891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env45873 == env45891) = true)

theorem identity45891 : scanCanonicalize (H12AffineFastState.compose env45891 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound45891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13509,10280,1025,8661,4160,21929,16,73737,8328,64,2185,5393,17664,32040,1500,33,257,21793,5456,74251]

theorem envBound45892 : H12AffineFastState.Bounded env45892 := by
  intro p hp
  have h : env45892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45891_45892 : H12AffineEnvironment.transform 14 8660 env45891 = env45892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env45891 == env45892) = true)

theorem identity45892 : scanCanonicalize (H12AffineFastState.compose env45892 (packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 20578) := by decide +kernel

theorem selectedBound45892 : packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS < 2^1333 := by decide +kernel

def env45893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,20578,13509,10280,1025,8661,4160,21929,16,28779,8328,64,2185,5393,17664,32040,1500,33,257,21793,5456,29289]

theorem envBound45893 : H12AffineFastState.Bounded env45893 := by
  intro p hp
  have h : env45893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45892_45893 : H12AffineEnvironment.transform 15 20578 env45892 = env45893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20578 env45892 == env45893) = true)

theorem identity45893 : scanCanonicalize (H12AffineFastState.compose env45893 (packedSelected [2,3,6,7,9,10,12,15,19,20,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound45893 : packedSelected [2,3,6,7,9,10,12,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env45894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8660,1046,13509,10280,1025,8661,4160,477,16,9247,8328,64,2185,5393,4468,10588,1500,33,257,341,5456,9757]

theorem envBound45894 : H12AffineFastState.Bounded env45894 := by
  intro p hp
  have h : env45894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45893_45894 : H12AffineEnvironment.transform 13 5236 env45893 = env45894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env45893 == env45894) = true)

theorem identity45894 : scanCanonicalize (H12AffineFastState.compose env45894 (packedSelected [2,4,6,18,20,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45894 : packedSelected [2,4,6,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env45895 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5156,8580,1046,13461,10280,1025,8581,4112,397,16,9247,8328,16,2185,5393,4388,10508,1420,33,257,261,5376,9757]

theorem envBound45895 : H12AffineFastState.Bounded env45895 := by
  intro p hp
  have h : env45895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45894_45895 : H12AffineEnvironment.transform 5 16 env45894 = env45895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45894 == env45895) = true)

theorem identity45895 : scanCanonicalize (H12AffineFastState.compose env45895 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound45895 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env45896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1052,5156,1432,1046,4233,3124,1025,1433,4112,397,16,3,1172,16,2185,5393,4388,3344,1420,33,257,261,5376,513]

theorem envBound45896 : H12AffineFastState.Bounded env45896 := by
  intro p hp
  have h : env45896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45895_45896 : H12AffineEnvironment.transform 12 1052 env45895 = env45896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env45895 == env45896) = true)

theorem identity45896 : scanCanonicalize (H12AffineFastState.compose env45896 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound45896 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45897 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,161,4249,293,171,4233,2185,188,292,4112,397,16,3,41,16,2185,4524,4388,2477,305,33,257,261,4541,513]

theorem envBound45897 : H12AffineFastState.Bounded env45897 := by
  intro p hp
  have h : env45897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45896_45897 : H12AffineEnvironment.transform 9 189 env45896 = env45897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env45896 == env45897) = true)

theorem identity45897 : scanCanonicalize (H12AffineFastState.compose env45897 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound45897 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45898 : List Nat := [2,4,8,16,32,16,128,256,131,189,2048,4096,161,4249,293,171,4233,2185,188,292,4112,397,16,3,41,16,2185,4524,4388,2477,305,33,257,261,4541,130]

theorem envBound45898 : H12AffineFastState.Bounded env45898 := by
  intro p hp
  have h : env45898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45897_45898 : H12AffineEnvironment.transform 8 131 env45897 = env45898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env45897 == env45898) = true)

theorem identity45898 : scanCanonicalize (H12AffineFastState.compose env45898 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound45898 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45899 : List Nat := [2,4,8,16,32,16,128,256,131,189,2048,444,161,293,293,171,309,2185,188,292,428,397,16,3,41,16,2185,16,152,2477,305,33,257,261,1,130]

theorem envBound45899 : H12AffineFastState.Bounded env45899 := by
  intro p hp
  have h : env45899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45898_45899 : H12AffineEnvironment.transform 11 444 env45898 = env45899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env45898 == env45899) = true)

theorem identity45899 : scanCanonicalize (H12AffineFastState.compose env45899 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound45899 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env45900 : List Nat := [2,4,8,16,32,16,128,256,131,189,137,444,161,293,293,171,309,0,188,292,428,397,16,3,41,16,0,16,152,292,305,33,257,261,1,130]

theorem envBound45900 : H12AffineFastState.Bounded env45900 := by
  intro p hp
  have h : env45900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45899_45900 : H12AffineEnvironment.transform 10 137 env45899 = env45900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env45899 == env45900) = true)

theorem identity45900 : scanCanonicalize (H12AffineFastState.compose env45900 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45900 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env45901 : List Nat := [2,4,8,16,32,16,128,37,131,189,137,153,161,0,0,171,16,0,188,1,137,168,16,3,41,16,0,16,152,1,20,33,36,32,1,130]

theorem envBound45901 : H12AffineFastState.Bounded env45901 := by
  intro p hp
  have h : env45901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45900_45901 : H12AffineEnvironment.transform 7 37 env45900 = env45901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45900 == env45901) = true)

theorem identity45901 : scanCanonicalize (H12AffineFastState.compose env45901 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45902 : List Nat := [2,4,8,16,1,16,128,4,131,156,137,153,128,0,0,138,16,0,157,1,137,137,16,3,8,16,0,16,152,1,20,0,5,1,1,130]

theorem envBound45902 : H12AffineFastState.Bounded env45902 := by
  intro p hp
  have h : env45902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45901_45902 : H12AffineEnvironment.transform 4 1 env45901 = env45902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45901 == env45902) = true)

theorem identity45902 : scanCanonicalize (H12AffineFastState.compose env45902 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45902 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45903 : List Nat := [2,4,3,16,1,16,128,4,131,151,130,146,128,0,0,129,16,0,150,1,130,130,16,3,3,16,0,16,147,1,20,0,5,1,1,130]

theorem envBound45903 : H12AffineFastState.Bounded env45903 := by
  intro p hp
  have h : env45903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45902_45903 : H12AffineEnvironment.transform 2 3 env45902 = env45903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45902 == env45903) = true)

theorem identity45903 : scanCanonicalize (H12AffineFastState.compose env45903 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 22) := by decide +kernel

theorem selectedBound45903 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45904 : List Nat := [2,4,3,16,1,16,22,4,21,1,20,4,22,0,0,23,16,0,0,1,20,20,16,3,3,16,0,16,5,1,20,0,5,1,1,20]

theorem envBound45904 : H12AffineFastState.Bounded env45904 := by
  intro p hp
  have h : env45904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45903_45904 : H12AffineEnvironment.transform 6 22 env45903 = env45904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 22 env45903 == env45904) = true)

theorem identity45904 : scanCanonicalize (H12AffineFastState.compose env45904 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45904 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45905 : List Nat := [2,1,3,16,1,16,19,1,16,1,17,1,19,0,0,18,16,0,0,1,17,17,16,3,3,16,0,16,0,1,17,0,0,1,1,17]

theorem envBound45905 : H12AffineFastState.Bounded env45905 := by
  intro p hp
  have h : env45905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45904_45905 : H12AffineEnvironment.transform 1 1 env45904 = env45905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45904 == env45905) = true)

theorem identity45905 : scanCanonicalize (H12AffineFastState.compose env45905 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound45905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45906 : List Nat := [2,1,3,2,1,2,1,1,2,1,3,1,1,0,0,0,2,0,0,1,3,3,2,3,3,2,0,2,0,1,3,0,0,1,1,3]

theorem envBound45906 : H12AffineFastState.Bounded env45906 := by
  intro p hp
  have h : env45906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45905_45906 : H12AffineEnvironment.transform 3 2 env45905 = env45906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env45905 == env45906) = true)

def env45907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180409,144597,242968,8328,64,43357,139732,160197,56573,1500,32,257,21793,46212,74251]

theorem envBound45907 : H12AffineFastState.Bounded env45907 := by
  intro p hp
  have h : env45907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45872_45907 : H12AffineEnvironment.transform 17 10281 env45872 = env45907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45872 == env45907) = true)

def env45908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,21929,41413,73736,8328,64,43357,46276,58581,56573,1500,32,257,21793,46212,74251]

theorem envBound45908 : H12AffineFastState.Bounded env45908 := by
  intro p hp
  have h : env45908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45907_45908 : H12AffineEnvironment.transform 16 38160 env45907 = env45908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env45907 == env45908) = true)

theorem identity45908 : scanCanonicalize (H12AffineFastState.compose env45908 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,21793,41293,73736,8192,64,43357,46156,58461,56437,1364,32,257,21793,46092,74251]

theorem envBound45909 : H12AffineFastState.Bounded env45909 := by
  intro p hp
  have h : env45909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45908_45909 : H12AffineEnvironment.transform 6 8 env45908 = env45909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45908 == env45909) = true)

theorem identity45909 : scanCanonicalize (H12AffineFastState.compose env45909 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound45909 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,38160,10281,1025,32769,4160,21793,41293,32771,8192,64,43357,46156,58461,56437,1364,32,257,21793,46092,33280]

theorem envBound45910 : H12AffineFastState.Bounded env45910 := by
  intro p hp
  have h : env45910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45909_45910 : H12AffineEnvironment.transform 15 40971 env45909 = env45910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env45909 == env45910) = true)

theorem identity45910 : scanCanonicalize (H12AffineFastState.compose env45910 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound45910 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,5393,10281,1025,0,4160,21793,8524,2,8192,64,10588,13389,25692,23668,1364,32,257,21793,13325,513]

theorem envBound45911 : H12AffineFastState.Bounded env45911 := by
  intro p hp
  have h : env45911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45910_45911 : H12AffineEnvironment.transform 14 1 env45910 = env45911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env45910 == env45911) = true)

theorem identity45911 : scanCanonicalize (H12AffineFastState.compose env45911 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound45911 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env45912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,5393,10281,1025,0,4160,8572,8524,2,8192,64,10588,13389,4097,10281,1364,32,257,8572,13325,513]

theorem envBound45912 : H12AffineFastState.Bounded env45912 := by
  intro p hp
  have h : env45912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45911_45912 : H12AffineEnvironment.transform 13 13405 env45911 = env45912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env45911 == env45912) = true)

theorem identity45912 : scanCanonicalize (H12AffineFastState.compose env45912 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45912 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env45913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,1,263,5393,2340,1025,0,4160,113,65,2,269,64,2129,5440,4097,2340,1364,32,257,113,5376,513]

theorem envBound45913 : H12AffineFastState.Bounded env45913 := by
  intro p hp
  have h : env45913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45912_45913 : H12AffineEnvironment.transform 12 269 env45912 = env45913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45912 == env45913) = true)

theorem identity45913 : scanCanonicalize (H12AffineFastState.compose env45913 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45913 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45914 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,263,5393,2340,1025,0,4112,33,17,2,269,16,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound45914 : H12AffineFastState.Bounded env45914 := by
  intro p hp
  have h : env45914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45913_45914 : H12AffineEnvironment.transform 5 16 env45913 = env45914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45913 == env45914) = true)

theorem identity45914 : scanCanonicalize (H12AffineFastState.compose env45914 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound45914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45915 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,269,1045,1,263,1028,2340,1025,0,261,33,17,2,269,16,2049,1029,276,2340,1284,32,257,33,1045,513]

theorem envBound45915 : H12AffineFastState.Bounded env45915 := by
  intro p hp
  have h : env45915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45914_45915 : H12AffineEnvironment.transform 11 277 env45914 = env45915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env45914 == env45915) = true)

theorem identity45915 : scanCanonicalize (H12AffineFastState.compose env45915 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45915 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45916 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,277,269,1,1,263,16,2340,21,0,261,33,17,2,269,16,2049,17,276,2340,272,32,257,33,1,513]

theorem envBound45916 : H12AffineFastState.Bounded env45916 := by
  intro p hp
  have h : env45916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45915_45916 : H12AffineEnvironment.transform 9 20 env45915 = env45916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45915 == env45916) = true)

theorem identity45916 : scanCanonicalize (H12AffineFastState.compose env45916 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound45916 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45917 : List Nat := [2,4,8,16,32,16,8,256,261,20,2048,277,269,1,1,263,16,2340,21,0,261,33,17,2,269,16,2049,17,276,2340,272,32,257,33,1,260]

theorem envBound45917 : H12AffineFastState.Bounded env45917 := by
  intro p hp
  have h : env45917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45916_45917 : H12AffineEnvironment.transform 8 261 env45916 = env45917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env45916 == env45917) = true)

theorem identity45917 : scanCanonicalize (H12AffineFastState.compose env45917 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound45917 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45918 : List Nat := [2,4,8,16,32,16,8,256,261,20,49,277,269,1,1,263,16,277,21,0,261,33,17,2,269,16,48,17,276,277,272,32,257,33,1,260]

theorem envBound45918 : H12AffineFastState.Bounded env45918 := by
  intro p hp
  have h : env45918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45917_45918 : H12AffineEnvironment.transform 10 49 env45917 = env45918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env45917 == env45918) = true)

theorem identity45918 : scanCanonicalize (H12AffineFastState.compose env45918 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45918 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45919 : List Nat := [2,4,8,16,16,16,8,256,261,20,1,277,269,1,1,263,16,277,21,0,261,17,17,2,269,16,0,17,276,277,272,16,257,17,1,260]

theorem envBound45919 : H12AffineFastState.Bounded env45919 := by
  intro p hp
  have h : env45919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45918_45919 : H12AffineEnvironment.transform 4 16 env45918 = env45919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45918 == env45919) = true)

theorem identity45919 : scanCanonicalize (H12AffineFastState.compose env45919 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45919 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env45920 : List Nat := [2,4,8,16,16,16,8,5,0,20,1,16,8,1,1,2,16,16,21,0,0,17,17,2,8,16,0,17,17,16,21,16,4,17,1,1]

theorem envBound45920 : H12AffineFastState.Bounded env45920 := by
  intro p hp
  have h : env45920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45919_45920 : H12AffineEnvironment.transform 7 5 env45919 = env45920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45919 == env45920) = true)

theorem identity45920 : scanCanonicalize (H12AffineFastState.compose env45920 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45921 : List Nat := [2,4,8,1,1,1,8,5,0,5,1,1,8,1,1,2,1,1,4,0,0,0,0,2,8,1,0,0,0,1,4,1,4,0,1,1]

theorem envBound45921 : H12AffineFastState.Bounded env45921 := by
  intro p hp
  have h : env45921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45920_45921 : H12AffineEnvironment.transform 3 1 env45920 = env45921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45920 == env45921) = true)

def env45922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,21928,41412,73737,8328,64,43357,46277,58580,56573,1500,32,257,21793,46212,74251]

theorem envBound45922 : H12AffineFastState.Bounded env45922 := by
  intro p hp
  have h : env45922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45907_45922 : H12AffineEnvironment.transform 16 38161 env45907 = env45922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env45907 == env45922) = true)

def env45923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,65536,38161,10281,1025,32769,4160,8572,41412,73737,8328,64,43357,46277,36864,43049,1500,32,257,8693,46212,74251]

theorem envBound45923 : H12AffineFastState.Bounded env45923 := by
  intro p hp
  have h : env45923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45922_45923 : H12AffineEnvironment.transform 13 13524 env45922 = env45923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env45922 == env45923) = true)

theorem identity45923 : scanCanonicalize (H12AffineFastState.compose env45923 (packedSelected [3,4,5,7,9,10,14,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound45923 : packedSelected [3,4,5,7,9,10,14,27,35] rootPS < 2^1333 := by decide +kernel

def env45924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,41090,38161,10281,1025,32769,4160,8572,41412,32907,8328,64,43357,46277,36864,43049,1500,32,257,8693,46212,33417]

theorem envBound45924 : H12AffineFastState.Bounded env45924 := by
  intro p hp
  have h : env45924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45923_45924 : H12AffineEnvironment.transform 15 41090 env45923 = env45924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env45923 == env45924) = true)

theorem identity45924 : scanCanonicalize (H12AffineFastState.compose env45924 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45924 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env45925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,32768,33247,38161,2420,1025,32769,4160,33,32921,32907,469,64,34816,38296,36864,35188,1500,32,257,168,38361,33417]

theorem envBound45925 : H12AffineFastState.Bounded env45925 := by
  intro p hp
  have h : env45925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45924_45925 : H12AffineEnvironment.transform 12 349 env45924 = env45925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45924 == env45925) = true)

theorem identity45925 : scanCanonicalize (H12AffineFastState.compose env45925 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound45925 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,478,5392,2420,1025,0,4160,33,152,138,469,64,2049,5529,4097,2421,1500,32,257,168,5592,648]

theorem envBound45926 : H12AffineFastState.Bounded env45926 := by
  intro p hp
  have h : env45926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45925_45926 : H12AffineEnvironment.transform 14 1 env45925 = env45926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env45925 == env45926) = true)

def env45927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38161,10281,1025,32769,4160,8573,41412,73737,8328,64,43357,46277,36865,43048,1500,32,257,8692,46212,74251]

theorem envBound45927 : H12AffineFastState.Bounded env45927 := by
  intro p hp
  have h : env45927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45922_45927 : H12AffineEnvironment.transform 13 13525 env45922 = env45927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env45922 == env45927) = true)

theorem identity45927 : scanCanonicalize (H12AffineFastState.compose env45927 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45927 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,38161,10281,1025,32769,4160,8573,41412,3,8328,64,43357,46277,36865,43048,1500,32,257,8692,46212,513]

theorem envBound45928 : H12AffineFastState.Bounded env45928 := by
  intro p hp
  have h : env45928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45927_45928 : H12AffineEnvironment.transform 15 8202 env45927 = env45928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45927 == env45928) = true)

theorem identity45928 : scanCanonicalize (H12AffineFastState.compose env45928 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound45928 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8661,8202,13508,10281,1025,8660,4160,8573,17,3,8328,64,2184,5392,12756,2557,1500,32,257,8692,5457,513]

theorem envBound45929 : H12AffineFastState.Bounded env45929 := by
  intro p hp
  have h : env45929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45928_45929 : H12AffineEnvironment.transform 14 8661 env45928 = env45929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env45928 == env45929) = true)

theorem identity45929 : scanCanonicalize (H12AffineFastState.compose env45929 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45929 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env45930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,137,342,5528,2421,1025,136,4160,33,17,3,468,64,2184,5392,4232,2557,1500,32,257,168,5457,513]

theorem envBound45930 : H12AffineFastState.Bounded env45930 := by
  intro p hp
  have h : env45930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45929_45930 : H12AffineEnvironment.transform 12 348 env45929 = env45930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45929 == env45930) = true)

theorem identity45930 : scanCanonicalize (H12AffineFastState.compose env45930 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45930 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1025,1,4160,33,17,3,349,64,2049,5392,4097,2420,1365,32,257,33,5457,513]

theorem envBound45931 : H12AffineFastState.Bounded env45931 := by
  intro p hp
  have h : env45931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45930_45931 : H12AffineEnvironment.transform 6 9 env45930 = env45931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45930 == env45931) = true)

theorem identity45931 : scanCanonicalize (H12AffineFastState.compose env45931 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound45931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45932 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4161,0,342,4176,2421,320,1,4160,33,17,3,349,64,2049,4177,4097,2420,20,32,257,33,4112,513]

theorem envBound45932 : H12AffineFastState.Bounded env45932 := by
  intro p hp
  have h : env45932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45931_45932 : H12AffineEnvironment.transform 9 321 env45931 = env45932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45931 == env45932) = true)

theorem identity45932 : scanCanonicalize (H12AffineFastState.compose env45932 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound45932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45933 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,309,348,372,0,342,357,2421,320,1,373,33,17,3,349,64,2049,356,308,2420,20,32,257,33,293,513]

theorem envBound45933 : H12AffineFastState.Bounded env45933 := by
  intro p hp
  have h : env45933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45932_45933 : H12AffineEnvironment.transform 11 309 env45932 = env45933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env45932 == env45933) = true)

theorem identity45933 : scanCanonicalize (H12AffineFastState.compose env45933 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45933 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45934 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,65,40,0,0,34,17,2049,52,1,1,33,17,3,41,64,2049,16,64,2048,20,32,117,33,81,513]

theorem envBound45934 : H12AffineFastState.Bounded env45934 := by
  intro p hp
  have h : env45934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45933_45934 : H12AffineEnvironment.transform 7 116 env45933 = env45934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45933 == env45934) = true)

theorem identity45934 : scanCanonicalize (H12AffineFastState.compose env45934 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45934 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45935 : List Nat := [2,4,8,16,32,64,9,116,512,53,0,65,40,0,0,34,17,1,52,1,1,33,17,3,41,64,1,16,64,0,20,32,117,33,81,513]

theorem envBound45935 : H12AffineFastState.Bounded env45935 := by
  intro p hp
  have h : env45935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45934_45935 : H12AffineEnvironment.transform 10 0 env45934 = env45935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45934 == env45935) = true)

def env45936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144596,242968,8328,64,43356,139733,160197,324821,1501,272392,257,21793,46212,74250]

theorem envBound45936 : H12AffineFastState.Bounded env45936 := by
  intro p hp
  have h : env45936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45871_45936 : H12AffineEnvironment.transform 20 4161 env45871 = env45936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45871 == env45936) = true)

theorem identity45936 : scanCanonicalize (H12AffineFastState.compose env45936 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound45936 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272512,62660,95496,8328,64,43356,57797,45525,324821,1501,272392,257,21793,46212,74250]

theorem envBound45937 : H12AffineFastState.Bounded env45937 := by
  intro p hp
  have h : env45937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45936_45937 : H12AffineEnvironment.transform 16 49168 env45936 = env45937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45936 == env45937) = true)

theorem identity45937 : scanCanonicalize (H12AffineFastState.compose env45937 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45937 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,4161,272512,62660,21763,8328,64,43356,57797,45525,324821,1501,272392,257,21793,46212,513]

theorem envBound45938 : H12AffineFastState.Bounded env45938 := by
  intro p hp
  have h : env45938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45937_45938 : H12AffineEnvironment.transform 15 8203 env45937 = env45938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45937 == env45938) = true)

theorem identity45938 : scanCanonicalize (H12AffineFastState.compose env45938 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound45938 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,56572,1025,32769,4161,62588,62660,21763,8328,64,43356,57797,45525,10281,1501,62708,257,21793,46212,513]

theorem envBound45939 : H12AffineFastState.Bounded env45939 := by
  intro p hp
  have h : env45939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45938_45939 : H12AffineEnvironment.transform 17 56572 env45938 = env45939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env45938 == env45939) = true)

theorem identity45939 : scanCanonicalize (H12AffineFastState.compose env45939 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound45939 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env45940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,13341,10481,1025,29708,4161,113,201,21763,8328,64,23889,5576,17880,10281,1501,249,257,21793,16521,513]

theorem envBound45940 : H12AffineFastState.Bounded env45940 := by
  intro p hp
  have h : env45940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45939_45940 : H12AffineEnvironment.transform 14 29709 env45939 = env45940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env45939 == env45940) = true)

theorem identity45940 : scanCanonicalize (H12AffineFastState.compose env45940 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45940 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,13341,10361,1025,29708,4161,113,65,21763,8192,64,23889,5440,17744,10281,1365,113,257,21793,16385,513]

theorem envBound45941 : H12AffineFastState.Bounded env45941 := by
  intro p hp
  have h : env45941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45940_45941 : H12AffineEnvironment.transform 6 8 env45940 = env45941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45940 == env45941) = true)

theorem identity45941 : scanCanonicalize (H12AffineFastState.compose env45941 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45941 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45942 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,13341,10281,1025,29708,4113,33,17,21763,8192,16,23809,5392,17664,10281,1285,33,257,21793,16385,513]

theorem envBound45942 : H12AffineFastState.Bounded env45942 := by
  intro p hp
  have h : env45942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45941_45942 : H12AffineEnvironment.transform 5 16 env45941 = env45942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45941 == env45942) = true)

theorem identity45942 : scanCanonicalize (H12AffineFastState.compose env45942 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45942 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45943 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,8203,13341,10281,1025,0,4113,33,17,8463,8192,16,10509,5392,12556,10281,1285,33,257,8493,13325,513]

theorem envBound45943 : H12AffineFastState.Bounded env45943 := by
  intro p hp
  have h : env45943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45942_45943 : H12AffineEnvironment.transform 13 13324 env45942 = env45943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45942 == env45943) = true)

theorem identity45943 : scanCanonicalize (H12AffineFastState.compose env45943 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45943 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45944 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8192,13324,1,8203,13341,10281,1025,0,4113,33,17,8202,8192,16,10248,5141,12297,10281,1024,33,4,8232,13325,513]

theorem envBound45944 : H12AffineFastState.Bounded env45944 := by
  intro p hp
  have h : env45944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45943_45944 : H12AffineEnvironment.transform 7 5 env45943 = env45944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45943 == env45944) = true)

theorem identity45944 : scanCanonicalize (H12AffineFastState.compose env45944 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound45944 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45945 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8,5124,1,3,5141,2081,1025,0,4113,33,17,2,8,16,2048,5141,4097,2081,1024,33,4,32,5125,513]

theorem envBound45945 : H12AffineFastState.Bounded env45945 := by
  intro p hp
  have h : env45945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45944_45945 : H12AffineEnvironment.transform 12 8 env45944 = env45945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env45944 == env45945) = true)

theorem identity45945 : scanCanonicalize (H12AffineFastState.compose env45945 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45946 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5124,1,3,5141,2048,1025,0,4113,0,17,2,8,16,2048,5141,4097,2048,1024,0,4,1,5125,513]

theorem envBound45946 : H12AffineFastState.Bounded env45946 := by
  intro p hp
  have h : env45946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45945_45946 : H12AffineEnvironment.transform 4 1 env45945 = env45946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45945 == env45946) = true)

theorem identity45946 : scanCanonicalize (H12AffineFastState.compose env45946 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound45946 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45947 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,4096,8,5124,1,3,5141,523,1025,0,4113,0,17,2,8,16,523,5141,4097,523,1024,0,4,1,5125,513]

theorem envBound45947 : H12AffineFastState.Bounded env45947 := by
  intro p hp
  have h : env45947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45946_45947 : H12AffineEnvironment.transform 10 523 env45946 = env45947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env45946 == env45947) = true)

def env45948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237589,242968,8328,64,2144540,2240916,160197,2417812,2102684,2373704,257,21793,46212,2175563]

theorem envBound45948 : H12AffineFastState.Bounded env45948 := by
  intro p hp
  have h : env45948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45870_45948 : H12AffineEnvironment.transform 21 452753 env45870 = env45948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env45870 == env45948) = true)

def env45949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144597,242968,8328,64,43356,139732,160197,324820,1500,272392,257,21793,46212,74251]

theorem envBound45949 : H12AffineFastState.Bounded env45949 := by
  intro p hp
  have h : env45949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45948_45949 : H12AffineEnvironment.transform 20 4160 env45948 = env45949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45948 == env45949) = true)

theorem identity45949 : scanCanonicalize (H12AffineFastState.compose env45949 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound45949 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,318549,17,98780,8328,64,43356,5392,17665,324820,1500,272392,257,21793,46212,74251]

theorem envBound45950 : H12AffineFastState.Bounded env45950 := by
  intro p hp
  have h : env45950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45949_45950 : H12AffineEnvironment.transform 16 13508 env45949 = env45950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env45949 == env45950) = true)

def env45951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,17,98644,8192,64,43356,5392,17665,324700,1364,272392,257,21793,46092,74251]

theorem envBound45951 : H12AffineFastState.Bounded env45951 := by
  intro p hp
  have h : env45951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45950_45951 : H12AffineEnvironment.transform 6 8 env45950 = env45951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45950 == env45951) = true)

theorem identity45951 : scanCanonicalize (H12AffineFastState.compose env45951 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45951 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1025,32769,4160,62588,17,98644,8192,64,43356,5392,17665,56437,1364,33,257,21793,46092,74251]

theorem envBound45952 : H12AffineFastState.Bounded env45952 := by
  intro p hp
  have h : env45952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45951_45952 : H12AffineEnvironment.transform 17 10281 env45951 = env45952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45951 == env45952) = true)

theorem identity45952 : scanCanonicalize (H12AffineFastState.compose env45952 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45952 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1025,29788,4160,33,17,95497,8192,64,23809,5392,17665,10280,1364,33,257,21793,16465,74251]

theorem envBound45953 : H12AffineFastState.Bounded env45953 := by
  intro p hp
  have h : env45953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45952_45953 : H12AffineEnvironment.transform 14 29789 env45952 = env45953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45952 == env45953) = true)

theorem identity45953 : scanCanonicalize (H12AffineFastState.compose env45953 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound45953 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21591,13388,10281,1025,29788,4160,33,17,8542,8192,64,23809,5392,17665,10280,1364,33,257,21793,16465,30300]

theorem envBound45954 : H12AffineFastState.Bounded env45954 := by
  intro p hp
  have h : env45954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45953_45954 : H12AffineEnvironment.transform 15 21591 env45953 = env45954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env45953 == env45954) = true)

theorem identity45954 : scanCanonicalize (H12AffineFastState.compose env45954 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound45954 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13388,10281,1025,1,4160,33,17,8542,8192,64,10588,5392,12636,10280,1364,33,257,8572,13324,513]

theorem envBound45955 : H12AffineFastState.Bounded env45955 := by
  intro p hp
  have h : env45955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45954_45955 : H12AffineEnvironment.transform 13 13405 env45954 = env45955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env45954 == env45955) = true)

theorem identity45955 : scanCanonicalize (H12AffineFastState.compose env45955 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45955 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2420,1025,1,4160,33,17,3,349,64,2049,5392,4097,2421,1364,33,257,33,5457,513]

theorem envBound45956 : H12AffineFastState.Bounded env45956 := by
  intro p hp
  have h : env45956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45955_45956 : H12AffineEnvironment.transform 12 349 env45955 = env45956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45955 == env45956) = true)

theorem identity45956 : scanCanonicalize (H12AffineFastState.compose env45956 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45956 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45957 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4113,33,17,3,268,17,2049,5392,4097,2340,1285,33,257,33,5376,513]

theorem envBound45957 : H12AffineFastState.Bounded env45957 := by
  intro p hp
  have h : env45957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45956_45957 : H12AffineEnvironment.transform 5 17 env45956 = env45957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45956 == env45957) = true)

theorem identity45957 : scanCanonicalize (H12AffineFastState.compose env45957 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound45957 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45958 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1313,268,33,0,262,48,2341,1025,1,1328,33,17,3,268,17,2049,49,1312,2340,1285,33,257,33,33,513]

theorem envBound45958 : H12AffineFastState.Bounded env45958 := by
  intro p hp
  have h : env45958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45957_45958 : H12AffineEnvironment.transform 11 1313 env45957 = env45958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env45957 == env45958) = true)

theorem identity45958 : scanCanonicalize (H12AffineFastState.compose env45958 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound45958 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45959 : List Nat := [2,4,8,16,32,17,8,256,512,1024,805,1313,268,33,0,262,48,512,1025,1,1328,33,17,3,268,17,804,49,1312,513,1285,33,257,33,33,513]

theorem envBound45959 : H12AffineFastState.Bounded env45959 := by
  intro p hp
  have h : env45959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45958_45959 : H12AffineEnvironment.transform 10 805 env45958 = env45959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env45958 == env45959) = true)

theorem identity45959 : scanCanonicalize (H12AffineFastState.compose env45959 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound45959 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45960 : List Nat := [2,4,8,16,32,17,8,256,512,768,805,545,268,33,0,262,48,512,769,1,560,33,17,3,268,17,804,49,544,513,517,33,257,33,33,513]

theorem envBound45960 : H12AffineFastState.Bounded env45960 := by
  intro p hp
  have h : env45960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45959_45960 : H12AffineEnvironment.transform 9 768 env45959 = env45960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env45959 == env45960) = true)

theorem identity45960 : scanCanonicalize (H12AffineFastState.compose env45960 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45960 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45961 : List Nat := [2,4,8,16,32,17,8,256,17,273,308,48,268,33,0,262,48,17,272,1,33,33,17,3,268,17,309,49,49,16,20,33,257,33,33,16]

theorem envBound45961 : H12AffineFastState.Bounded env45961 := by
  intro p hp
  have h : env45961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45960_45961 : H12AffineEnvironment.transform 8 17 env45960 = env45961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45960 == env45961) = true)

theorem identity45961 : scanCanonicalize (H12AffineFastState.compose env45961 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45962 : List Nat := [2,4,8,16,32,17,8,37,17,52,17,48,41,33,0,35,48,17,53,1,33,33,17,3,41,17,16,49,49,16,20,33,36,33,33,16]

theorem envBound45962 : H12AffineFastState.Bounded env45962 := by
  intro p hp
  have h : env45962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45961_45962 : H12AffineEnvironment.transform 7 37 env45961 = env45962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45961 == env45962) = true)

def env45963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4160,318549,17,98645,8193,64,43356,5392,17665,324701,1365,272392,257,21793,46093,74251]

theorem envBound45963 : H12AffineFastState.Bounded env45963 := by
  intro p hp
  have h : env45963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45950_45963 : H12AffineEnvironment.transform 6 9 env45950 = env45963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45950 == env45963) = true)

theorem identity45963 : scanCanonicalize (H12AffineFastState.compose env45963 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45963 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35189,1025,32769,4160,21792,17,98645,8193,64,43356,5392,17665,32040,1365,41341,257,21793,46093,74251]

theorem envBound45964 : H12AffineFastState.Bounded env45964 := by
  intro p hp
  have h : env45964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45963_45964 : H12AffineEnvironment.transform 17 35189 env45963 = env45964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45963 == env45964) = true)

theorem identity45964 : scanCanonicalize (H12AffineFastState.compose env45964 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound45964 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62810,13389,35189,1025,32769,4160,21792,17,29711,8193,64,43356,5392,17665,32040,1365,41341,257,21793,46093,55121]

theorem envBound45965 : H12AffineFastState.Bounded env45965 := by
  intro p hp
  have h : env45965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45964_45965 : H12AffineEnvironment.transform 15 62810 env45964 = env45965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env45964 == env45965) = true)

theorem identity45965 : scanCanonicalize (H12AffineFastState.compose env45965 (packedSelected [3,4,5,9,10,12,14,15,16,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound45965 : packedSelected [3,4,5,9,10,12,14,15,16,19,26] rootPS < 2^1333 := by decide +kernel

def env45966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,29742,13389,2049,1025,373,4160,21792,17,29711,8193,64,10280,5392,17665,32040,1365,8201,257,21793,13689,22053]

theorem envBound45966 : H12AffineFastState.Bounded env45966 := by
  intro p hp
  have h : env45966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45965_45966 : H12AffineEnvironment.transform 14 372 env45965 = env45966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env45965 == env45966) = true)

theorem identity45966 : scanCanonicalize (H12AffineFastState.compose env45966 (packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45966 : packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS < 2^1333 := by decide +kernel

def env45967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,372,8575,13389,2049,1025,373,4160,113,17,8542,8193,64,10280,5392,4176,10361,1365,8201,257,112,13689,884]

theorem envBound45967 : H12AffineFastState.Bounded env45967 := by
  intro p hp
  have h : env45967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45966_45967 : H12AffineEnvironment.transform 13 5457 env45966 = env45967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45966 == env45967) = true)

theorem identity45967 : scanCanonicalize (H12AffineFastState.compose env45967 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45967 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,372,35,5393,2049,1025,373,4160,113,17,2,349,64,2420,5392,4176,2341,1365,341,257,112,5157,884]

theorem envBound45968 : H12AffineFastState.Bounded env45968 := by
  intro p hp
  have h : env45968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45967_45968 : H12AffineEnvironment.transform 12 348 env45967 = env45968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45967 == env45968) = true)

theorem identity45968 : scanCanonicalize (H12AffineFastState.compose env45968 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45968 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45969 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5236,81,35,5172,2049,1025,80,4160,113,17,2,120,64,2129,5173,4176,2048,1136,112,36,112,5157,593]

theorem envBound45969 : H12AffineFastState.Bounded env45969 := by
  intro p hp
  have h : env45969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45968_45969 : H12AffineEnvironment.transform 7 37 env45968 = env45969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45968 == env45969) = true)

theorem identity45969 : scanCanonicalize (H12AffineFastState.compose env45969 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound45969 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45970 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,9,5124,33,35,5172,2049,1025,32,4144,1,17,2,8,48,2081,5173,4128,2048,1024,0,36,0,5157,545]

theorem envBound45970 : H12AffineFastState.Bounded env45970 := by
  intro p hp
  have h : env45970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45969_45970 : H12AffineEnvironment.transform 5 48 env45969 = env45970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env45969 == env45970) = true)

theorem identity45970 : scanCanonicalize (H12AffineFastState.compose env45970 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45970 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45971 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,1,3,5140,2049,1025,0,4112,1,17,2,8,16,2049,5141,4096,2048,1024,0,4,0,5125,513]

theorem envBound45971 : H12AffineFastState.Bounded env45971 := by
  intro p hp
  have h : env45971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45970_45971 : H12AffineEnvironment.transform 4 0 env45970 = env45971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45970 == env45971) = true)

theorem identity45971 : scanCanonicalize (H12AffineFastState.compose env45971 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45971 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45972 : List Nat := [2,4,8,1,0,1,9,5,512,1024,2048,4096,9,5124,1,3,5125,2049,1025,0,4097,1,0,2,8,1,2049,5124,4096,2048,1024,0,4,0,5125,513]

theorem envBound45972 : H12AffineFastState.Bounded env45972 := by
  intro p hp
  have h : env45972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45971_45972 : H12AffineEnvironment.transform 3 1 env45971 = env45972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45971 == env45972) = true)

theorem identity45972 : scanCanonicalize (H12AffineFastState.compose env45972 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound45972 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45973 : List Nat := [2,4,8,1,0,1,9,5,512,1024,1039,4096,9,5124,1,3,5125,1038,1025,0,4097,1,0,2,8,1,1038,5124,4096,1039,1024,0,4,0,5125,513]

theorem envBound45973 : H12AffineFastState.Bounded env45973 := by
  intro p hp
  have h : env45973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45972_45973 : H12AffineEnvironment.transform 10 1039 env45972 = env45973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env45972 == env45973) = true)

theorem identity45973 : scanCanonicalize (H12AffineFastState.compose env45973 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45973 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45974 : List Nat := [2,4,8,1,0,1,9,5,11,1024,1039,4096,9,5124,1,3,5125,1038,1025,0,4097,1,0,2,8,1,1038,5124,4096,1039,1024,0,4,0,5125,10]

theorem envBound45974 : H12AffineFastState.Bounded env45974 := by
  intro p hp
  have h : env45974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45973_45974 : H12AffineEnvironment.transform 8 11 env45973 = env45974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45973 == env45974) = true)

theorem identity45974 : scanCanonicalize (H12AffineFastState.compose env45974 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45975 : List Nat := [0,4,8,1,0,1,9,5,9,1024,1037,4096,9,5124,1,1,5125,1036,1025,0,4097,1,0,0,8,1,1036,5124,4096,1037,1024,0,4,0,5125,8]

theorem envBound45975 : H12AffineFastState.Bounded env45975 := by
  intro p hp
  have h : env45975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45974_45975 : H12AffineEnvironment.transform 0 0 env45974 = env45975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45974 == env45975) = true)

theorem identity45975 : scanCanonicalize (H12AffineFastState.compose env45975 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound45975 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45976 : List Nat := [0,4,0,1,0,1,1,5,1,1024,1029,4096,1,5124,1,1,5125,1028,1025,0,4097,1,0,0,0,1,1028,5124,4096,1029,1024,0,4,0,5125,0]

theorem envBound45976 : H12AffineFastState.Bounded env45976 := by
  intro p hp
  have h : env45976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45975_45976 : H12AffineEnvironment.transform 2 0 env45975 = env45976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env45975 == env45976) = true)

theorem identity45976 : scanCanonicalize (H12AffineFastState.compose env45976 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound45976 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45977 : List Nat := [0,4,0,1,0,1,1,5,1,1024,1029,1029,1,1,1,1,0,1028,1025,0,1028,1,0,0,0,1,1028,1,1029,1029,1024,0,4,0,0,0]

theorem envBound45977 : H12AffineFastState.Bounded env45977 := by
  intro p hp
  have h : env45977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45976_45977 : H12AffineEnvironment.transform 11 1029 env45976 = env45977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env45976 == env45977) = true)

theorem identity45977 : scanCanonicalize (H12AffineFastState.compose env45977 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45978 : List Nat := [0,1,0,1,0,1,1,0,1,1024,1024,1024,1,1,1,1,0,1025,1025,0,1025,1,0,0,0,1,1025,1,1024,1024,1024,0,1,0,0,0]

theorem envBound45978 : H12AffineFastState.Bounded env45978 := by
  intro p hp
  have h : env45978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45977_45978 : H12AffineEnvironment.transform 1 1 env45977 = env45978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45977 == env45978) = true)

theorem identity45978 : scanCanonicalize (H12AffineFastState.compose env45978 (packedSelected [8] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound45978 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env45979 : List Nat := [0,1,0,1,0,1,1,0,1,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,0,1,1,1,1,0,1,0,0,0]

theorem envBound45979 : H12AffineFastState.Bounded env45979 := by
  intro p hp
  have h : env45979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45978_45979 : H12AffineEnvironment.transform 9 1 env45978 = env45979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env45978 == env45979) = true)

def env45980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144596,242968,8328,64,43357,139733,160197,324821,1501,272393,257,21793,46212,74250]

theorem envBound45980 : H12AffineFastState.Bounded env45980 := by
  intro p hp
  have h : env45980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45948_45980 : H12AffineEnvironment.transform 20 4161 env45948 = env45980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45948 == env45980) = true)

theorem identity45980 : scanCanonicalize (H12AffineFastState.compose env45980 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound45980 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,400452,144596,213453,8328,64,23944,139733,160197,262144,1501,272393,257,21793,16465,74250]

theorem envBound45981 : H12AffineFastState.Bounded env45981 := by
  intro p hp
  have h : env45981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45980_45981 : H12AffineEnvironment.transform 14 29909 env45980 = env45981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env45980 == env45981) = true)

def env45982 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,400404,144516,213405,8328,16,23944,139653,160149,262144,1421,272393,257,21793,16385,74250]

theorem envBound45982 : H12AffineFastState.Bounded env45982 := by
  intro p hp
  have h : env45982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45981_45982 : H12AffineEnvironment.transform 5 16 env45981 = env45982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45981 == env45982) = true)

theorem identity45982 : scanCanonicalize (H12AffineFastState.compose env45982 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound45982 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45983 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,262144,1025,29828,4113,338190,65950,29831,8328,16,23944,70815,83087,262144,1421,272393,257,21793,16385,74250]

theorem envBound45983 : H12AffineFastState.Bounded env45983 := by
  intro p hp
  have h : env45983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45982_45983 : H12AffineEnvironment.transform 16 79130 env45982 = env45983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env45982 == env45983) = true)

theorem identity45983 : scanCanonicalize (H12AffineFastState.compose env45983 (packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45983 : packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env45984 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,262144,1025,29828,4113,264588,8476,29831,8328,16,23944,13341,25613,262144,1421,272393,257,21793,16385,648]

theorem envBound45984 : H12AffineFastState.Bounded env45984 := by
  intro p hp
  have h : env45984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45983_45984 : H12AffineEnvironment.transform 15 8322 env45983 = env45984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45983 == env45984) = true)

theorem identity45984 : scanCanonicalize (H12AffineFastState.compose env45984 (packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 3481) := by decide +kernel

theorem selectedBound45984 : packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env45985 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,3481,1025,29828,4113,1045,8476,29831,8328,16,23944,13341,25613,3481,1421,9616,257,21793,16385,648]

theorem envBound45985 : H12AffineFastState.Bounded env45985 := by
  intro p hp
  have h : env45985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45984_45985 : H12AffineEnvironment.transform 17 3481 env45984 = env45985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3481 env45984 == env45985) = true)

theorem identity45985 : scanCanonicalize (H12AffineFastState.compose env45985 (packedSelected [1,2,3,4,5,6,8,10,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound45985 : packedSelected [1,2,3,4,5,6,8,10,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env45986 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13608,429,8322,5528,3481,1025,428,4113,1045,8476,431,8328,16,10400,13341,4389,3481,1421,9616,257,8201,13609,648]

theorem envBound45986 : H12AffineFastState.Bounded env45986 := by
  intro p hp
  have h : env45986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45985_45986 : H12AffineEnvironment.transform 13 13608 env45985 = env45986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env45985 == env45986) = true)

theorem identity45986 : scanCanonicalize (H12AffineFastState.compose env45986 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45986 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45987 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13608,292,8203,5393,3344,1025,293,4113,1045,8476,294,8193,16,10281,13341,4389,3344,1284,9497,257,8201,13609,513]

theorem envBound45987 : H12AffineFastState.Bounded env45987 := by
  intro p hp
  have h : env45987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45986_45987 : H12AffineEnvironment.transform 6 9 env45986 = env45987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45986 == env45987) = true)

theorem identity45987 : scanCanonicalize (H12AffineFastState.compose env45987 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45987 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45988 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,1,8203,5172,3125,1025,0,4113,1045,8249,3,8193,16,10281,13341,4096,3125,1057,9276,36,8201,13324,513]

theorem envBound45988 : H12AffineFastState.Bounded env45988 := by
  intro p hp
  have h : env45988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45987_45988 : H12AffineEnvironment.transform 7 37 env45987 = env45988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45987 == env45988) = true)

def env45989 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,400405,144517,213404,8328,17,23944,139652,160148,262144,1420,272393,257,21793,16384,74250]

theorem envBound45989 : H12AffineFastState.Bounded env45989 := by
  intro p hp
  have h : env45989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45981_45989 : H12AffineEnvironment.transform 5 17 env45981 = env45989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45981 == env45989) = true)

theorem identity45989 : scanCanonicalize (H12AffineFastState.compose env45989 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound45989 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45990 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79251,262144,1025,29829,4112,338310,65814,29711,8328,17,23944,70679,82951,262144,1420,272393,257,21793,16384,74250]

theorem envBound45990 : H12AffineFastState.Bounded env45990 := by
  intro p hp
  have h : env45990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45989_45990 : H12AffineEnvironment.transform 16 79251 env45989 = env45990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env45989 == env45990) = true)

theorem identity45990 : scanCanonicalize (H12AffineFastState.compose env45990 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound45990 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env45991 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79251,67754,1025,29829,4112,8492,65814,29711,8328,17,23944,70679,82951,67754,1420,73891,257,21793,16384,74250]

theorem envBound45991 : H12AffineFastState.Bounded env45991 := by
  intro p hp
  have h : env45991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45990_45991 : H12AffineEnvironment.transform 17 67754 env45990 = env45991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env45990 == env45991) = true)

theorem identity45991 : scanCanonicalize (H12AffineFastState.compose env45991 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45991 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env45992 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,65536,79251,67754,1025,8581,4112,8492,65814,8463,8328,17,2184,70679,69895,67754,1420,73891,257,33,5376,74250]

theorem envBound45992 : H12AffineFastState.Bounded env45992 := by
  intro p hp
  have h : env45992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45991_45992 : H12AffineEnvironment.transform 13 5376 env45991 = env45992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45991 == env45992) = true)

theorem identity45992 : scanCanonicalize (H12AffineFastState.compose env45992 (packedSelected [0,2,4,6,7,9,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound45992 : packedSelected [0,2,4,6,7,9,12,16] rootPS < 2^1333 := by decide +kernel

def env45993 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,65536,70678,67754,1025,0,4112,169,65814,138,269,17,2184,70679,69895,67754,1420,65830,257,33,5376,66447]

theorem envBound45993 : H12AffineFastState.Bounded env45993 := by
  intro p hp
  have h : env45993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45992_45993 : H12AffineEnvironment.transform 12 389 env45992 = env45993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env45992 == env45993) = true)

theorem identity45993 : scanCanonicalize (H12AffineFastState.compose env45993 (packedSelected [3,4,5,9,10,12,17] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound45993 : packedSelected [3,4,5,9,10,12,17] rootPS < 2^1333 := by decide +kernel

def env45994 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,398,5528,2340,1025,0,4112,169,152,138,269,17,2184,5529,4233,2340,1420,168,257,33,5376,513]

theorem envBound45994 : H12AffineFastState.Bounded env45994 := by
  intro p hp
  have h : env45994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45993_45994 : H12AffineEnvironment.transform 15 398 env45993 = env45994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env45993 == env45994) = true)

theorem identity45994 : scanCanonicalize (H12AffineFastState.compose env45994 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45994 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env45995 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,5156,1,170,5308,2048,1025,0,4112,169,152,138,41,17,2184,5309,4233,2048,1192,168,37,33,5156,513]

theorem envBound45995 : H12AffineFastState.Bounded env45995 := by
  intro p hp
  have h : env45995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45994_45995 : H12AffineEnvironment.transform 7 36 env45994 = env45995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45994 == env45995) = true)

theorem identity45995 : scanCanonicalize (H12AffineFastState.compose env45995 (packedSelected [0,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45995 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env45996 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,1,34,5172,2048,1025,0,4112,33,16,2,41,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound45996 : H12AffineFastState.Bounded env45996 := by
  intro p hp
  have h : env45996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45995_45996 : H12AffineEnvironment.transform 6 8 env45995 = env45996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45995 == env45996) = true)

def env45997 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1044,1,34,1028,2048,1025,0,32,33,16,2,41,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound45997 : H12AffineFastState.Bounded env45997 := by
  intro p hp
  have h : env45997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45996_45997 : H12AffineEnvironment.transform 11 48 env45996 = env45997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45996 == env45997) = true)

theorem identity45997 : scanCanonicalize (H12AffineFastState.compose env45997 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45998 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,41,1044,1,34,1028,0,1025,0,32,33,16,2,41,17,0,1029,49,0,1056,32,37,33,1044,513]

theorem envBound45998 : H12AffineFastState.Bounded env45998 := by
  intro p hp
  have h : env45998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45997_45998 : H12AffineEnvironment.transform 10 0 env45997 = env45998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45997 == env45998) = true)

def env45999 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,41,32,1,34,48,0,53,0,32,33,16,2,41,17,0,49,49,0,20,32,37,33,32,513]

theorem envBound45999 : H12AffineFastState.Bounded env45999 := by
  intro p hp
  have h : env45999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45998_45999 : H12AffineEnvironment.transform 9 52 env45998 = env45999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45998 == env45999) = true)

theorem identity45999 : scanCanonicalize (H12AffineFastState.compose env45999 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound45999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46000 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,41,32,1,34,48,0,53,0,32,33,16,2,41,17,0,49,49,0,20,32,37,33,32,11]

theorem envBound46000 : H12AffineFastState.Bounded env46000 := by
  intro p hp
  have h : env46000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45999_46000 : H12AffineEnvironment.transform 8 10 env45999 = env46000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env45999 == env46000) = true)

def leafEnv46000 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,41,32,1,34,48,0,53,0,32,33,16,2,21,41,1,17,0,49,49,0,20,32,37,33,5,34,32,11,1,32,0]

def active46000 : List Nat := [0,1,2,3,4]

def tree46000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46000 : H12WitnessSearch.Good tree46000 := H12GlobalWitnessIndex.good

theorem leafIdentity46000 : H12AffineFastState.composeSystem env46000 rootObs = leafEnv46000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46000 rootObs == leafEnv46000) = true)

theorem terminalChecked46000 : H12PackedTerminal.terminalCheckFast leafEnv46000 active46000 tree46000 = true := by decide +kernel

def env46001 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,33,1,34,49,0,52,0,32,33,16,2,41,17,0,48,49,0,21,32,37,33,33,513]

theorem envBound46001 : H12AffineFastState.Bounded env46001 := by
  intro p hp
  have h : env46001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45998_46001 : H12AffineEnvironment.transform 9 53 env45998 = env46001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45998 == env46001) = true)

theorem identity46001 : scanCanonicalize (H12AffineFastState.compose env46001 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46002 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,8,0,1,3,16,0,21,0,1,0,16,2,8,17,0,17,16,0,21,1,4,0,0,513]

theorem envBound46002 : H12AffineFastState.Bounded env46002 := by
  intro p hp
  have h : env46002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46001_46002 : H12AffineEnvironment.transform 4 1 env46001 = env46002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46001 == env46002) = true)

def leafEnv46002 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,8,0,1,3,16,0,21,0,1,0,16,2,20,8,1,17,0,17,16,0,21,1,4,0,5,3,0,513,1,1,0]

def active46002 : List Nat := [0,1,2,3,8]

def tree46002 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46002 : H12WitnessSearch.Good tree46002 := H12GlobalWitnessIndex.good

theorem leafIdentity46002 : H12AffineFastState.composeSystem env46002 rootObs = leafEnv46002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46002 rootObs == leafEnv46002) = true)

theorem terminalChecked46002 : H12PackedTerminal.terminalCheckFast leafEnv46002 active46002 tree46002 = true := by decide +kernel

def env46003 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1045,1,34,1029,2048,1025,0,33,33,16,2,41,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound46003 : H12AffineFastState.Bounded env46003 := by
  intro p hp
  have h : env46003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45996_46003 : H12AffineEnvironment.transform 11 49 env45996 = env46003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45996 == env46003) = true)

theorem identity46003 : scanCanonicalize (H12AffineFastState.compose env46003 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound46003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46004 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,41,1045,1,34,1029,1076,1025,0,33,33,16,2,41,17,1076,1028,48,1076,1056,32,37,33,1045,513]

theorem envBound46004 : H12AffineFastState.Bounded env46004 := by
  intro p hp
  have h : env46004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46003_46004 : H12AffineEnvironment.transform 10 1076 env46003 = env46004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env46003 == env46004) = true)

def env46005 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,33,1,34,49,0,53,0,33,33,16,2,41,17,0,48,48,0,20,32,37,33,33,513]

theorem envBound46005 : H12AffineFastState.Bounded env46005 := by
  intro p hp
  have h : env46005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46004_46005 : H12AffineEnvironment.transform 9 52 env46004 = env46005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46004 == env46005) = true)

theorem identity46005 : scanCanonicalize (H12AffineFastState.compose env46005 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46006 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,41,33,1,34,49,0,53,0,33,33,16,2,41,17,0,48,48,0,20,32,37,33,33,11]

theorem envBound46006 : H12AffineFastState.Bounded env46006 := by
  intro p hp
  have h : env46006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46005_46006 : H12AffineEnvironment.transform 8 10 env46005 = env46006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46005 == env46006) = true)

def leafEnv46006 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,41,33,1,34,49,0,53,0,33,33,16,2,21,41,1,17,0,48,48,0,20,32,37,33,5,34,33,11,1,33,0]

def active46006 : List Nat := [0,1,2,3,4]

def tree46006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46006 : H12WitnessSearch.Good tree46006 := H12GlobalWitnessIndex.good

theorem leafIdentity46006 : H12AffineFastState.composeSystem env46006 rootObs = leafEnv46006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46006 rootObs == leafEnv46006) = true)

theorem terminalChecked46006 : H12PackedTerminal.terminalCheckFast leafEnv46006 active46006 tree46006 = true := by decide +kernel

def env46007 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,41,32,1,34,48,1,52,0,33,33,16,2,41,17,1,49,48,1,21,32,37,33,32,513]

theorem envBound46007 : H12AffineFastState.Bounded env46007 := by
  intro p hp
  have h : env46007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46004_46007 : H12AffineEnvironment.transform 9 53 env46004 = env46007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46004 == env46007) = true)

theorem identity46007 : scanCanonicalize (H12AffineFastState.compose env46007 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46007 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46008 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,8,1,1,3,17,1,21,0,0,0,16,2,8,17,1,16,17,1,21,1,4,0,1,513]

theorem envBound46008 : H12AffineFastState.Bounded env46008 := by
  intro p hp
  have h : env46008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46007_46008 : H12AffineEnvironment.transform 4 1 env46007 = env46008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46007 == env46008) = true)

def leafEnv46008 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,8,1,1,3,17,1,21,0,0,0,16,2,20,8,1,17,1,16,17,1,21,1,4,0,5,3,1,513,1,0,0]

def active46008 : List Nat := [0,1,2,3,8]

def tree46008 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46008 : H12WitnessSearch.Good tree46008 := H12GlobalWitnessIndex.good

theorem leafIdentity46008 : H12AffineFastState.composeSystem env46008 rootObs = leafEnv46008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46008 rootObs == leafEnv46008) = true)

theorem terminalChecked46008 : H12PackedTerminal.terminalCheckFast leafEnv46008 active46008 tree46008 = true := by decide +kernel

def env46009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,242969,8328,64,6705548,2240917,160197,2417812,2102685,6475992,257,21792,46213,2175562]

theorem envBound46009 : H12AffineFastState.Bounded env46009 := by
  intro p hp
  have h : env46009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45869_46009 : H12AffineEnvironment.transform 23 242969 env45869 = env46009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env45869 == env46009) = true)

def env46010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237589,242969,8328,64,2144540,2240917,160197,2417812,2102685,2373704,257,21792,46213,2175562]

theorem envBound46010 : H12AffineFastState.Bounded env46010 := by
  intro p hp
  have h : env46010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46009_46010 : H12AffineEnvironment.transform 21 452752 env46009 = env46010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env46009 == env46010) = true)

def env46011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144597,242969,8328,64,43356,139733,160197,324820,1501,272392,257,21792,46213,74250]

theorem envBound46011 : H12AffineFastState.Bounded env46011 := by
  intro p hp
  have h : env46011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46010_46011 : H12AffineEnvironment.transform 20 4160 env46010 = env46011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46010 == env46011) = true)

theorem identity46011 : scanCanonicalize (H12AffineFastState.compose env46011 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound46011 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329867,120014,21762,8328,64,43356,115150,102878,324820,1501,272392,257,21792,46213,74250]

theorem envBound46012 : H12AffineFastState.Bounded env46012 := by
  intro p hp
  have h : env46012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46011_46012 : H12AffineEnvironment.transform 16 122907 env46011 = env46012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env46011 == env46012) = true)

def env46013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10400,1025,32769,4160,73771,120014,21762,8328,64,43356,115150,102878,56436,1501,168,257,21792,46213,74250]

theorem envBound46013 : H12AffineFastState.Bounded env46013 := by
  intro p hp
  have h : env46013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46012_46013 : H12AffineEnvironment.transform 17 10400 env46012 = env46013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46012 == env46013) = true)

theorem identity46013 : scanCanonicalize (H12AffineFastState.compose env46013 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound46013 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21590,46157,10400,1025,32769,4160,29821,32920,21762,8328,64,43356,38296,50568,56436,1501,168,257,21792,46213,30300]

theorem envBound46014 : H12AffineFastState.Bounded env46014 := by
  intro p hp
  have h : env46014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46013_46014 : H12AffineEnvironment.transform 15 21590 env46013 = env46014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env46013 == env46014) = true)

theorem identity46014 : scanCanonicalize (H12AffineFastState.compose env46014 (packedSelected [2,3,4,5,6,7,10,12,14,17,22,23,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound46014 : packedSelected [2,3,4,5,6,7,10,12,14,17,22,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env46015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29993,21590,16740,10400,1025,29992,4160,29821,30129,21762,8328,64,23669,24753,12449,10589,1501,168,257,21792,16812,30300]

theorem envBound46015 : H12AffineFastState.Bounded env46015 := by
  intro p hp
  have h : env46015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46014_46015 : H12AffineEnvironment.transform 14 29993 env46014 = env46015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env46014 == env46015) = true)

theorem identity46015 : scanCanonicalize (H12AffineFastState.compose env46015 (packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound46015 : packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env46016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,137,8694,13508,10400,1025,136,4160,477,17,8354,8328,64,10709,5393,12449,10589,1501,168,257,8320,13324,1020]

theorem envBound46016 : H12AffineFastState.Bounded env46016 := by
  intro p hp
  have h : env46016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46015_46016 : H12AffineEnvironment.transform 13 13728 env46015 = env46016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env46015 == env46016) = true)

theorem identity46016 : scanCanonicalize (H12AffineFastState.compose env46016 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound46016 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46017 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13405,137,8203,13508,10400,1025,136,4160,32,17,8354,8328,64,10280,5356,12449,10400,1056,168,252,8320,13324,513]

theorem envBound46017 : H12AffineFastState.Bounded env46017 := by
  intro p hp
  have h : env46017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46016_46017 : H12AffineEnvironment.transform 7 253 env46016 = env46017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env46016 == env46017) = true)

theorem identity46017 : scanCanonicalize (H12AffineFastState.compose env46017 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound46017 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46018 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,241,5292,137,250,5173,2129,1025,136,4160,32,17,83,121,64,2265,5356,4176,2129,1056,168,252,113,5373,513]

theorem envBound46018 : H12AffineFastState.Bounded env46018 := by
  intro p hp
  have h : env46018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46017_46018 : H12AffineEnvironment.transform 12 241 env46017 = env46018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env46017 == env46018) = true)

theorem identity46018 : scanCanonicalize (H12AffineFastState.compose env46018 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46018 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46019 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,4096,41,5236,81,34,5173,2129,1025,80,4160,32,17,83,121,64,2049,5172,4176,2129,1056,112,36,113,5157,513]

theorem envBound46019 : H12AffineFastState.Bounded env46019 := by
  intro p hp
  have h : env46019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46018_46019 : H12AffineEnvironment.transform 6 88 env46018 = env46019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46018 == env46019) = true)

theorem identity46019 : scanCanonicalize (H12AffineFastState.compose env46019 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound46019 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46020 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,3109,41,2129,81,34,2064,2129,1025,80,3173,32,17,83,121,64,2049,2065,3189,2129,1056,112,36,113,2048,513]

theorem envBound46020 : H12AffineFastState.Bounded env46020 := by
  intro p hp
  have h : env46020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46019_46020 : H12AffineEnvironment.transform 11 3109 env46019 = env46020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env46019 == env46020) = true)

theorem identity46020 : scanCanonicalize (H12AffineFastState.compose env46020 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound46020 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46021 : List Nat := [2,4,8,16,32,64,88,37,512,1024,80,1141,41,1,81,34,64,1,1025,80,1077,32,17,83,121,64,81,65,1061,1,1056,112,36,113,80,513]

theorem envBound46021 : H12AffineFastState.Bounded env46021 := by
  intro p hp
  have h : env46021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46020_46021 : H12AffineEnvironment.transform 10 80 env46020 = env46021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env46020 == env46021) = true)

theorem identity46021 : scanCanonicalize (H12AffineFastState.compose env46021 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound46021 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env46022 : List Nat := [2,4,8,16,32,64,88,37,512,101,80,16,41,1,81,34,64,1,100,80,80,32,17,83,121,64,81,65,64,1,69,112,36,113,80,513]

theorem envBound46022 : H12AffineFastState.Bounded env46022 := by
  intro p hp
  have h : env46022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46021_46022 : H12AffineEnvironment.transform 9 101 env46021 = env46022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env46021 == env46022) = true)

theorem identity46022 : scanCanonicalize (H12AffineFastState.compose env46022 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46022 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env46023 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,41,1,1,34,16,1,52,0,0,32,17,3,41,16,1,17,16,1,21,32,36,33,0,513]

theorem envBound46023 : H12AffineFastState.Bounded env46023 := by
  intro p hp
  have h : env46023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46022_46023 : H12AffineEnvironment.transform 5 16 env46022 = env46023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46022 == env46023) = true)

theorem identity46023 : scanCanonicalize (H12AffineFastState.compose env46023 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound46023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46024 : List Nat := [2,4,8,16,5,16,8,0,512,16,0,16,12,1,1,7,16,1,17,0,0,5,17,3,12,16,1,17,16,1,21,5,1,4,0,513]

theorem envBound46024 : H12AffineFastState.Bounded env46024 := by
  intro p hp
  have h : env46024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46023_46024 : H12AffineEnvironment.transform 4 5 env46023 = env46024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env46023 == env46024) = true)

theorem identity46024 : scanCanonicalize (H12AffineFastState.compose env46024 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound46024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46025 : List Nat := [2,4,8,16,5,16,8,0,25,16,0,16,12,1,1,7,16,1,17,0,0,5,17,3,12,16,1,17,16,1,21,5,1,4,0,24]

theorem envBound46025 : H12AffineFastState.Bounded env46025 := by
  intro p hp
  have h : env46025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46024_46025 : H12AffineEnvironment.transform 8 25 env46024 = env46025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env46024 == env46025) = true)

theorem identity46025 : scanCanonicalize (H12AffineFastState.compose env46025 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound46025 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46026 : List Nat := [2,4,8,2,5,2,8,0,11,2,0,2,12,1,1,7,2,1,3,0,0,5,3,3,12,2,1,3,2,1,7,5,1,4,0,10]

theorem envBound46026 : H12AffineFastState.Bounded env46026 := by
  intro p hp
  have h : env46026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46025_46026 : H12AffineEnvironment.transform 3 2 env46025 = env46026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env46025 == env46026) = true)

theorem identity46026 : scanCanonicalize (H12AffineFastState.compose env46026 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46026 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46027 : List Nat := [2,0,8,2,1,2,8,0,11,2,0,2,8,1,1,3,2,1,3,0,0,1,3,3,8,2,1,3,2,1,3,1,1,0,0,10]

theorem envBound46027 : H12AffineFastState.Bounded env46027 := by
  intro p hp
  have h : env46027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46026_46027 : H12AffineEnvironment.transform 1 0 env46026 = env46027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46026 == env46027) = true)

def env46028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10401,1025,32769,4160,73770,120014,21762,8328,64,43356,115150,102878,56437,1501,169,257,21792,46213,74250]

theorem envBound46028 : H12AffineFastState.Bounded env46028 := by
  intro p hp
  have h : env46028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46012_46028 : H12AffineEnvironment.transform 17 10401 env46012 = env46028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46012 == env46028) = true)

theorem identity46028 : scanCanonicalize (H12AffineFastState.compose env46028 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46028 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,70727,10401,1025,29789,4160,73770,73874,21762,8328,64,23808,79250,91522,10281,1501,169,257,21792,16601,74250]

theorem envBound46029 : H12AffineFastState.Bounded env46029 := by
  intro p hp
  have h : env46029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46028_46029 : H12AffineEnvironment.transform 14 29788 env46028 = env46029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46028 == env46029) = true)

theorem identity46029 : scanCanonicalize (H12AffineFastState.compose env46029 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46029 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8203,13388,10401,1025,29789,4160,33,153,21762,8328,64,23808,5529,17801,10281,1501,169,257,21792,16601,513]

theorem envBound46030 : H12AffineFastState.Bounded env46030 := by
  intro p hp
  have h : env46030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46029_46030 : H12AffineEnvironment.transform 15 8203 env46029 = env46030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46029 == env46030) = true)

theorem identity46030 : scanCanonicalize (H12AffineFastState.compose env46030 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound46030 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env46031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21897,478,5529,2420,1025,21896,4160,33,153,21762,349,64,23808,5529,17801,2556,1501,169,257,21792,16601,513]

theorem envBound46031 : H12AffineFastState.Bounded env46031 := by
  intro p hp
  have h : env46031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46030_46031 : H12AffineEnvironment.transform 12 469 env46030 = env46031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env46030 == env46031) = true)

theorem identity46031 : scanCanonicalize (H12AffineFastState.compose env46031 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46031 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env46032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,5393,2420,1025,21760,4160,33,17,21762,349,64,23808,5393,17665,2420,1365,33,257,21792,16465,513]

theorem envBound46032 : H12AffineFastState.Bounded env46032 := by
  intro p hp
  have h : env46032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46031_46032 : H12AffineEnvironment.transform 6 8 env46031 = env46032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46031 == env46032) = true)

theorem identity46032 : scanCanonicalize (H12AffineFastState.compose env46032 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46032 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,342,5393,2420,1025,80,4160,33,17,82,349,64,2128,5393,4177,2420,1365,33,257,112,5377,513]

theorem envBound46033 : H12AffineFastState.Bounded env46033 := by
  intro p hp
  have h : env46033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46032_46033 : H12AffineEnvironment.transform 13 5456 env46032 = env46033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46032 == env46033) = true)

theorem identity46033 : scanCanonicalize (H12AffineFastState.compose env46033 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46033 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46034 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,262,5393,2340,1025,0,4112,33,17,2,269,16,2048,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound46034 : H12AffineFastState.Bounded env46034 := by
  intro p hp
  have h : env46034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46033_46034 : H12AffineEnvironment.transform 5 16 env46033 = env46034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46033 == env46034) = true)

theorem identity46034 : scanCanonicalize (H12AffineFastState.compose env46034 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46035 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1025,0,4112,33,17,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound46035 : H12AffineFastState.Bounded env46035 := by
  intro p hp
  have h : env46035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46034_46035 : H12AffineEnvironment.transform 7 36 env46034 = env46035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46034 == env46035) = true)

theorem identity46035 : scanCanonicalize (H12AffineFastState.compose env46035 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46035 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46036 : List Nat := [2,4,8,16,32,16,8,36,512,1024,522,4096,41,5156,1,34,5173,522,1025,0,4112,33,17,2,41,16,522,5173,4097,522,1057,33,37,32,5157,513]

theorem envBound46036 : H12AffineFastState.Bounded env46036 := by
  intro p hp
  have h : env46036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46035_46036 : H12AffineEnvironment.transform 10 522 env46035 = env46036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46035 == env46036) = true)

theorem identity46036 : scanCanonicalize (H12AffineFastState.compose env46036 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46036 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46037 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,4096,9,5124,1,2,5141,522,1025,0,4112,1,17,2,9,16,522,5141,4097,522,1025,1,5,0,5125,513]

theorem envBound46037 : H12AffineFastState.Bounded env46037 := by
  intro p hp
  have h : env46037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46036_46037 : H12AffineEnvironment.transform 4 0 env46036 = env46037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46036 == env46037) = true)

def env46038 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,16,9,1044,1,2,1029,522,1025,0,0,1,17,2,9,16,522,1029,17,522,1025,1,5,0,1045,513]

theorem envBound46038 : H12AffineFastState.Bounded env46038 := by
  intro p hp
  have h : env46038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46037_46038 : H12AffineEnvironment.transform 11 16 env46037 = env46038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env46037 == env46038) = true)

theorem identity46038 : scanCanonicalize (H12AffineFastState.compose env46038 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound46038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46039 : List Nat := [2,4,8,16,0,16,8,4,31,1024,21,16,9,1044,1,2,1029,21,1025,0,0,1,17,2,9,16,21,1029,17,21,1025,1,5,0,1045,30]

theorem envBound46039 : H12AffineFastState.Bounded env46039 := by
  intro p hp
  have h : env46039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46038_46039 : H12AffineEnvironment.transform 8 31 env46038 = env46039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env46038 == env46039) = true)

def env46040 : List Nat := [2,4,8,16,0,16,8,4,31,0,21,16,9,20,1,2,5,21,1,0,0,1,17,2,9,16,21,5,17,21,1,1,5,0,21,30]

theorem envBound46040 : H12AffineFastState.Bounded env46040 := by
  intro p hp
  have h : env46040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46039_46040 : H12AffineEnvironment.transform 9 0 env46039 = env46040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env46039 == env46040) = true)

theorem identity46040 : scanCanonicalize (H12AffineFastState.compose env46040 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46041 : List Nat := [0,4,8,16,0,16,8,4,29,0,21,16,9,20,1,0,5,21,1,0,0,1,17,0,9,16,21,5,17,21,1,1,5,0,21,28]

theorem envBound46041 : H12AffineFastState.Bounded env46041 := by
  intro p hp
  have h : env46041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46040_46041 : H12AffineEnvironment.transform 0 0 env46040 = env46041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46040 == env46041) = true)

def leafEnv46041 : List Nat := [0,4,8,16,0,16,8,4,29,0,21,16,9,20,1,0,5,21,1,0,0,1,17,0,1,9,1,16,21,5,17,21,1,1,5,0,4,0,21,28,1,1,0]

def active46041 : List Nat := [1,2,3]

def tree46041 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46041 : H12WitnessSearch.Good tree46041 := H12GlobalWitnessIndex.good

theorem leafIdentity46041 : H12AffineFastState.composeSystem env46041 rootObs = leafEnv46041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46041 rootObs == leafEnv46041) = true)

theorem terminalChecked46041 : H12PackedTerminal.terminalCheckFast leafEnv46041 active46041 tree46041 = true := by decide +kernel

def env46042 : List Nat := [2,4,8,16,0,16,8,4,31,1,21,16,9,21,1,2,4,21,0,0,0,1,17,2,9,16,21,4,17,21,0,1,5,0,20,30]

theorem envBound46042 : H12AffineFastState.Bounded env46042 := by
  intro p hp
  have h : env46042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46039_46042 : H12AffineEnvironment.transform 9 1 env46039 = env46042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env46039 == env46042) = true)

theorem identity46042 : scanCanonicalize (H12AffineFastState.compose env46042 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46043 : List Nat := [2,4,8,6,0,6,8,4,9,1,3,6,9,3,1,2,4,3,0,0,0,1,7,2,9,6,3,4,7,3,0,1,5,0,2,8]

theorem envBound46043 : H12AffineFastState.Bounded env46043 := by
  intro p hp
  have h : env46043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46042_46043 : H12AffineEnvironment.transform 3 6 env46042 = env46043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46042 == env46043) = true)

def leafEnv46043 : List Nat := [2,4,8,6,0,6,8,4,9,1,3,6,9,3,1,2,4,3,0,0,0,1,7,2,0,9,1,6,3,4,7,3,0,1,5,0,4,2,2,8,1,1,0]

def active46043 : List Nat := [0,1,2]

def tree46043 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46043 : H12WitnessSearch.Good tree46043 := H12GlobalWitnessIndex.good

theorem leafIdentity46043 : H12AffineFastState.composeSystem env46043 rootObs = leafEnv46043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46043 rootObs == leafEnv46043) = true)

theorem terminalChecked46043 : H12PackedTerminal.terminalCheckFast leafEnv46043 active46043 tree46043 = true := by decide +kernel

def env46044 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,17,9,1045,1,2,1028,522,1025,0,1,1,17,2,9,16,522,1028,16,522,1025,1,5,0,1044,513]

theorem envBound46044 : H12AffineFastState.Bounded env46044 := by
  intro p hp
  have h : env46044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46037_46044 : H12AffineEnvironment.transform 11 17 env46037 = env46044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env46037 == env46044) = true)

theorem identity46044 : scanCanonicalize (H12AffineFastState.compose env46044 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound46044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46045 : List Nat := [2,4,8,16,0,16,8,4,512,523,522,17,9,542,1,2,527,522,522,0,1,1,17,2,9,16,522,527,16,522,522,1,5,0,543,513]

theorem envBound46045 : H12AffineFastState.Bounded env46045 := by
  intro p hp
  have h : env46045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46044_46045 : H12AffineEnvironment.transform 9 523 env46044 = env46045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env46044 == env46045) = true)

def env46046 : List Nat := [2,4,8,4,0,4,8,4,512,523,522,5,9,522,1,2,527,522,522,0,1,1,5,2,9,4,522,527,4,522,522,1,5,0,523,513]

theorem envBound46046 : H12AffineFastState.Bounded env46046 := by
  intro p hp
  have h : env46046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46046 : H12AffineEnvironment.transform 3 4 env46045 = env46046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env46045 == env46046) = true)

theorem identity46046 : scanCanonicalize (H12AffineFastState.compose env46046 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46047 : List Nat := [0,4,8,4,0,4,8,4,512,521,520,5,9,520,1,0,525,520,520,0,1,1,5,0,9,4,520,525,4,520,520,1,5,0,521,513]

theorem envBound46047 : H12AffineFastState.Bounded env46047 := by
  intro p hp
  have h : env46047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46046_46047 : H12AffineEnvironment.transform 0 0 env46046 = env46047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46046 == env46047) = true)

def leafEnv46047 : List Nat := [0,4,8,4,0,4,8,4,512,521,520,5,9,520,1,0,525,520,520,0,1,1,5,0,520,9,1,4,520,525,4,520,520,1,5,0,4,0,521,513,1,0,0]

def active46047 : List Nat := [1,2,8]

def tree46047 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46047 : H12WitnessSearch.Good tree46047 := H12GlobalWitnessIndex.good

theorem leafIdentity46047 : H12AffineFastState.composeSystem env46047 rootObs = leafEnv46047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46047 rootObs == leafEnv46047) = true)

theorem terminalChecked46047 : H12PackedTerminal.terminalCheckFast leafEnv46047 active46047 tree46047 = true := by decide +kernel

def env46048 : List Nat := [2,4,8,5,0,5,8,4,512,523,522,4,9,523,1,2,527,522,522,0,1,1,4,2,9,5,522,527,5,522,522,1,5,0,522,513]

theorem envBound46048 : H12AffineFastState.Bounded env46048 := by
  intro p hp
  have h : env46048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46048 : H12AffineEnvironment.transform 3 5 env46045 = env46048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env46045 == env46048) = true)

theorem identity46048 : scanCanonicalize (H12AffineFastState.compose env46048 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound46048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46049 : List Nat := [2,4,8,5,0,5,8,4,9,2,3,4,9,2,1,2,6,3,3,0,1,1,4,2,9,5,3,6,5,3,3,1,5,0,3,8]

theorem envBound46049 : H12AffineFastState.Bounded env46049 := by
  intro p hp
  have h : env46049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46048_46049 : H12AffineEnvironment.transform 8 9 env46048 = env46049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env46048 == env46049) = true)

def leafEnv46049 : List Nat := [2,4,8,5,0,5,8,4,9,2,3,4,9,2,1,2,6,3,3,0,1,1,4,2,3,9,1,5,3,6,5,3,3,1,5,0,4,2,3,8,1,0,0]

def active46049 : List Nat := [0,1,2]

def tree46049 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46049 : H12WitnessSearch.Good tree46049 := H12GlobalWitnessIndex.good

theorem leafIdentity46049 : H12AffineFastState.composeSystem env46049 rootObs = leafEnv46049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46049 rootObs == leafEnv46049) = true)

theorem terminalChecked46049 : H12PackedTerminal.terminalCheckFast leafEnv46049 active46049 tree46049 = true := by decide +kernel

def env46050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144596,242969,8328,64,43357,139732,160197,324821,1500,272393,257,21792,46213,74251]

theorem envBound46050 : H12AffineFastState.Bounded env46050 := by
  intro p hp
  have h : env46050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46010_46050 : H12AffineEnvironment.transform 20 4161 env46010 = env46050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46010 == env46050) = true)

theorem identity46050 : scanCanonicalize (H12AffineFastState.compose env46050 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46050 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452752,144596,169235,8328,64,43357,139732,160197,324821,1500,272393,257,21792,46213,513]

theorem envBound46051 : H12AffineFastState.Bounded env46051 := by
  intro p hp
  have h : env46051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46050_46051 : H12AffineEnvironment.transform 15 8202 env46050 = env46051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46050 == env46051) = true)

def env46052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,305280,29892,54531,8328,64,43357,25028,12757,324821,1500,272393,257,21792,46213,513]

theorem envBound46052 : H12AffineFastState.Bounded env46052 := by
  intro p hp
  have h : env46052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46051_46052 : H12AffineEnvironment.transform 16 16400 env46051 = env46052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46051 == env46052) = true)

theorem identity46052 : scanCanonicalize (H12AffineFastState.compose env46052 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound46052 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13509,262144,1025,32769,4161,305280,17,41430,8328,64,43357,5393,12757,294912,1500,272393,257,8693,46213,513]

theorem envBound46053 : H12AffineFastState.Bounded env46053 := by
  intro p hp
  have h : env46053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46052_46053 : H12AffineEnvironment.transform 13 13525 env46052 = env46053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env46052 == env46053) = true)

theorem identity46053 : scanCanonicalize (H12AffineFastState.compose env46053 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound46053 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13509,43048,1025,32769,4161,168,17,41430,8328,64,43357,5393,12757,10280,1500,32801,257,8693,46213,513]

theorem envBound46054 : H12AffineFastState.Bounded env46054 := by
  intro p hp
  have h : env46054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46053_46054 : H12AffineEnvironment.transform 17 43048 env46053 = env46054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env46053 == env46054) = true)

theorem identity46054 : scanCanonicalize (H12AffineFastState.compose env46054 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46054 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env46055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,13389,43048,1025,32769,4161,32,17,41310,8192,64,43357,5393,12637,10280,1364,32801,257,8573,46093,513]

theorem envBound46055 : H12AffineFastState.Bounded env46055 := by
  intro p hp
  have h : env46055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46054_46055 : H12AffineEnvironment.transform 6 8 env46054 = env46055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46054 == env46055) = true)

theorem identity46055 : scanCanonicalize (H12AffineFastState.compose env46055 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound46055 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13389,10281,1025,0,4161,32,17,8543,8192,64,10588,5393,12637,10280,1364,32,257,8573,13324,513]

theorem envBound46056 : H12AffineFastState.Bounded env46056 := by
  intro p hp
  have h : env46056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46055_46056 : H12AffineEnvironment.transform 14 1 env46055 = env46056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46055 == env46056) = true)

theorem identity46056 : scanCanonicalize (H12AffineFastState.compose env46056 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46056 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2420,1025,0,4161,32,17,2,349,64,2049,5393,4096,2421,1364,32,257,32,5457,513]

theorem envBound46057 : H12AffineFastState.Bounded env46057 := by
  intro p hp
  have h : env46057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46056_46057 : H12AffineEnvironment.transform 12 349 env46056 = env46057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46056 == env46057) = true)

theorem identity46057 : scanCanonicalize (H12AffineFastState.compose env46057 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound46057 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,303,4096,349,5376,1,343,5392,91,1025,0,4161,32,17,2,349,64,302,5393,4096,90,1364,32,257,32,5457,513]

theorem envBound46058 : H12AffineFastState.Bounded env46058 := by
  intro p hp
  have h : env46058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46057_46058 : H12AffineEnvironment.transform 10 303 env46057 = env46058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env46057 == env46058) = true)

theorem identity46058 : scanCanonicalize (H12AffineFastState.compose env46058 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound46058 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,303,0,349,1280,1,343,1296,91,1025,0,65,32,17,2,349,64,302,1297,0,90,1364,32,257,32,1361,513]

theorem envBound46059 : H12AffineFastState.Bounded env46059 := by
  intro p hp
  have h : env46059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46058_46059 : H12AffineEnvironment.transform 11 0 env46058 = env46059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46058 == env46059) = true)

theorem identity46059 : scanCanonicalize (H12AffineFastState.compose env46059 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46059 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46060 : List Nat := [2,4,8,16,32,64,8,116,512,1024,91,0,41,1140,1,35,1124,91,1025,0,65,32,17,2,41,64,90,1125,0,90,1056,32,117,32,1061,513]

theorem envBound46060 : H12AffineFastState.Bounded env46060 := by
  intro p hp
  have h : env46060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46059_46060 : H12AffineEnvironment.transform 7 116 env46059 = env46060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46059 == env46060) = true)

theorem identity46060 : scanCanonicalize (H12AffineFastState.compose env46060 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound46060 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46061 : List Nat := [2,4,8,16,32,64,8,116,512,63,91,0,41,75,1,35,91,91,62,0,65,32,17,2,41,64,90,90,0,90,31,32,117,32,26,513]

theorem envBound46061 : H12AffineFastState.Bounded env46061 := by
  intro p hp
  have h : env46061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46060_46061 : H12AffineEnvironment.transform 9 63 env46060 = env46061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env46060 == env46061) = true)

theorem identity46061 : scanCanonicalize (H12AffineFastState.compose env46061 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46061 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46062 : List Nat := [2,4,8,16,32,48,8,4,512,63,43,0,41,59,1,35,43,43,62,0,49,32,17,2,41,48,42,42,0,42,31,32,5,32,26,513]

theorem envBound46062 : H12AffineFastState.Bounded env46062 := by
  intro p hp
  have h : env46062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46061_46062 : H12AffineEnvironment.transform 5 48 env46061 = env46062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46061 == env46062) = true)

def env46063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305281,29893,54530,8328,64,43357,25029,12756,324821,1500,272393,257,21792,46213,513]

theorem envBound46063 : H12AffineFastState.Bounded env46063 := by
  intro p hp
  have h : env46063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46051_46063 : H12AffineEnvironment.transform 16 16401 env46051 = env46063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46051 == env46063) = true)

def env46064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305161,29773,54530,8192,64,43357,24909,12636,324701,1364,272393,257,21792,46093,513]

theorem envBound46064 : H12AffineFastState.Bounded env46064 := by
  intro p hp
  have h : env46064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46063_46064 : H12AffineEnvironment.transform 6 8 env46063 = env46064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46063 == env46064) = true)

def env46065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305160,29772,54530,8193,64,43357,24908,12637,324700,1365,272393,257,21792,46092,513]

theorem envBound46065 : H12AffineFastState.Bounded env46065 := by
  intro p hp
  have h : env46065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46063_46065 : H12AffineEnvironment.transform 6 9 env46063 = env46065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46063 == env46065) = true)

theorem identity46065 : scanCanonicalize (H12AffineFastState.compose env46065 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound46065 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env46066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16401,262144,1025,32769,4161,298053,20481,54530,1100,64,36112,17665,5392,315409,1365,265284,257,21792,36929,513]

theorem envBound46066 : H12AffineFastState.Bounded env46066 := by
  intro p hp
  have h : env46066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46065_46066 : H12AffineEnvironment.transform 12 1101 env46065 = env46066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env46065 == env46066) = true)

theorem identity46066 : scanCanonicalize (H12AffineFastState.compose env46066 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound46066 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env46067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20496,1095,16401,262144,1025,20497,4161,285781,20481,1298,1100,64,23808,17665,5392,262145,1365,265284,257,21792,16465,513]

theorem envBound46067 : H12AffineFastState.Bounded env46067 := by
  intro p hp
  have h : env46067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46066_46067 : H12AffineEnvironment.transform 14 20496 env46066 = env46067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env46066 == env46067) = true)

theorem identity46067 : scanCanonicalize (H12AffineFastState.compose env46067 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound46067 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20496,1095,16401,3173,1025,20497,4161,20528,20481,1298,1100,64,23808,17665,5392,3172,1365,33,257,21792,16465,513]

theorem envBound46068 : H12AffineFastState.Bounded env46068 := by
  intro p hp
  have h : env46068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46067_46068 : H12AffineEnvironment.transform 17 3173 env46067 = env46068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env46067 == env46068) = true)

theorem identity46068 : scanCanonicalize (H12AffineFastState.compose env46068 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound46068 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,2340,6452,1095,2357,3173,1025,6453,4161,6420,6437,1298,1100,64,5156,3109,5392,3172,1365,33,257,7172,2421,513]

theorem envBound46069 : H12AffineFastState.Bounded env46069 := by
  intro p hp
  have h : env46069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46068_46069 : H12AffineEnvironment.transform 13 2340 env46068 = env46069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env46068 == env46069) = true)

theorem identity46069 : scanCanonicalize (H12AffineFastState.compose env46069 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46069 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env46070 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,268,2340,6452,262,2357,2340,320,6453,4161,6420,6437,83,269,64,4453,2404,4177,2341,20,33,257,6469,2421,513]

theorem envBound46070 : H12AffineFastState.Bounded env46070 := by
  intro p hp
  have h : env46070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46069_46070 : H12AffineEnvironment.transform 9 321 env46069 = env46070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46069 == env46070) = true)

theorem identity46070 : scanCanonicalize (H12AffineFastState.compose env46070 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound46070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46071 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2404,268,2340,80,262,2357,2340,320,81,2341,112,65,83,269,64,2049,2404,2357,2341,20,33,257,33,2421,513]

theorem envBound46071 : H12AffineFastState.Bounded env46071 := by
  intro p hp
  have h : env46071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46070_46071 : H12AffineEnvironment.transform 11 2404 env46070 = env46071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env46070 == env46071) = true)

theorem identity46071 : scanCanonicalize (H12AffineFastState.compose env46071 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46071 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46072 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2113,41,2049,80,35,2064,2049,101,81,2048,112,65,83,40,64,2049,2113,2064,2048,20,33,36,33,2128,513]

theorem envBound46072 : H12AffineFastState.Bounded env46072 := by
  intro p hp
  have h : env46072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46071_46072 : H12AffineEnvironment.transform 7 37 env46071 = env46072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46071 == env46072) = true)

theorem identity46072 : scanCanonicalize (H12AffineFastState.compose env46072 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound46072 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env46073 : List Nat := [2,4,8,16,32,64,9,37,512,100,592,529,41,593,80,35,576,593,101,81,592,112,65,83,40,64,593,529,576,592,20,33,36,33,512,513]

theorem envBound46073 : H12AffineFastState.Bounded env46073 := by
  intro p hp
  have h : env46073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46072_46073 : H12AffineEnvironment.transform 10 592 env46072 = env46073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env46072 == env46073) = true)

theorem identity46073 : scanCanonicalize (H12AffineFastState.compose env46073 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46073 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env46074 : List Nat := [2,4,8,16,32,16,9,37,512,52,512,529,41,513,0,35,528,513,53,1,512,32,17,3,40,16,513,529,528,512,20,33,36,33,512,513]

theorem envBound46074 : H12AffineFastState.Bounded env46074 := by
  intro p hp
  have h : env46074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46073_46074 : H12AffineEnvironment.transform 5 16 env46073 = env46074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46073 == env46074) = true)

theorem identity46074 : scanCanonicalize (H12AffineFastState.compose env46074 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46075 : List Nat := [2,4,8,10,32,10,9,37,512,46,512,523,41,513,0,35,522,513,47,1,512,32,11,3,40,10,513,523,522,512,14,33,36,33,512,513]

theorem envBound46075 : H12AffineFastState.Bounded env46075 := by
  intro p hp
  have h : env46075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46074_46075 : H12AffineEnvironment.transform 3 10 env46074 = env46075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46074 == env46075) = true)

theorem identity46075 : scanCanonicalize (H12AffineFastState.compose env46075 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46076 : List Nat := [2,4,8,10,32,10,9,37,1,46,1,10,41,0,0,35,11,0,47,1,1,32,11,3,40,10,0,10,11,1,14,33,36,33,1,0]

theorem envBound46076 : H12AffineFastState.Bounded env46076 := by
  intro p hp
  have h : env46076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46075_46076 : H12AffineEnvironment.transform 8 1 env46075 = env46076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46075 == env46076) = true)

def env46077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237589,242969,8328,64,2144541,2240917,160197,2417812,2102685,2373705,257,21792,46213,2175562]

theorem envBound46077 : H12AffineFastState.Bounded env46077 := by
  intro p hp
  have h : env46077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46009_46077 : H12AffineEnvironment.transform 21 452753 env46009 = env46077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env46009 == env46077) = true)

def env46078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144597,242969,8328,64,43357,139733,160197,324820,1501,272393,257,21792,46213,74250]

theorem envBound46078 : H12AffineFastState.Bounded env46078 := by
  intro p hp
  have h : env46078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46077_46078 : H12AffineEnvironment.transform 20 4160 env46077 = env46078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46077 == env46078) = true)

theorem identity46078 : scanCanonicalize (H12AffineFastState.compose env46078 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound46078 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,452753,144597,156102,8328,64,43357,139733,160197,324820,1501,272393,257,21792,46213,63189]

theorem envBound46079 : H12AffineFastState.Bounded env46079 := by
  intro p hp
  have h : env46079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46078_46079 : H12AffineEnvironment.transform 15 54495 env46078 = env46079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env46078 == env46079) = true)

def env46080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1025,32769,4160,305361,29845,8582,8328,64,43357,24981,12677,324820,1501,272393,257,21792,46213,63189]

theorem envBound46080 : H12AffineFastState.Bounded env46080 := by
  intro p hp
  have h : env46080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46079_46080 : H12AffineEnvironment.transform 16 16448 env46079 = env46080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env46079 == env46080) = true)

theorem identity46080 : scanCanonicalize (H12AffineFastState.compose env46080 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound46080 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29963,16448,262144,1025,8661,4160,264453,29845,8582,8328,64,2185,24981,12677,283904,1501,272393,257,21792,5457,22273]

theorem envBound46081 : H12AffineFastState.Bounded env46081 := by
  intro p hp
  have h : env46081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46080_46081 : H12AffineEnvironment.transform 14 8660 env46080 = env46081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env46080 == env46081) = true)

theorem identity46081 : scanCanonicalize (H12AffineFastState.compose env46081 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46081 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env46082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29963,16448,10281,1025,8661,4160,8492,29845,8582,8328,64,2185,24981,12677,32041,1501,32,257,21792,5457,22273]

theorem envBound46082 : H12AffineFastState.Bounded env46082 := by
  intro p hp
  have h : env46082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46081_46082 : H12AffineEnvironment.transform 17 10281 env46081 = env46082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46081 == env46082) = true)

theorem identity46082 : scanCanonicalize (H12AffineFastState.compose env46082 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46082 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env46083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,16448,10281,1025,8541,4160,8492,29725,8462,8192,64,2049,24861,12557,32041,1365,32,257,21792,5457,22273]

theorem envBound46083 : H12AffineFastState.Bounded env46083 := by
  intro p hp
  have h : env46083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46082_46083 : H12AffineEnvironment.transform 6 8 env46082 = env46083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46082 == env46083) = true)

theorem identity46083 : scanCanonicalize (H12AffineFastState.compose env46083 (packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46083 : packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env46084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5441,10281,1025,8541,4160,8492,8476,8462,8192,64,2049,13340,12557,10280,1365,32,257,33,5457,512]

theorem envBound46084 : H12AffineFastState.Bounded env46084 := by
  intro p hp
  have h : env46084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46083_46084 : H12AffineEnvironment.transform 13 5377 env46083 = env46084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46083 == env46084) = true)

theorem identity46084 : scanCanonicalize (H12AffineFastState.compose env46084 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46085 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5441,10248,1025,8541,4160,8461,8476,8462,8192,64,2049,13340,12557,10249,1365,1,257,0,5457,512]

theorem envBound46085 : H12AffineFastState.Bounded env46085 := by
  intro p hp
  have h : env46085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46084_46085 : H12AffineEnvironment.transform 4 1 env46084 = env46085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46084 == env46085) = true)

theorem identity46085 : scanCanonicalize (H12AffineFastState.compose env46085 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46085 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46086 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5377,1,343,5441,2389,1025,0,4160,80,65,83,349,64,2049,5441,4176,2388,1365,1,257,0,5457,512]

theorem envBound46086 : H12AffineFastState.Bounded env46086 := by
  intro p hp
  have h : env46086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46085_46086 : H12AffineEnvironment.transform 12 349 env46085 = env46086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46085 == env46086) = true)

theorem identity46086 : scanCanonicalize (H12AffineFastState.compose env46086 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound46086 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46087 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,16,349,1297,1,343,1361,2389,1025,0,80,80,65,83,349,64,2049,1361,64,2388,1365,1,257,0,1345,512]

theorem envBound46087 : H12AffineFastState.Bounded env46087 := by
  intro p hp
  have h : env46087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46086_46087 : H12AffineEnvironment.transform 11 16 env46086 = env46087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env46086 == env46087) = true)

theorem identity46087 : scanCanonicalize (H12AffineFastState.compose env46087 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46087 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env46088 : List Nat := [2,4,8,16,1,64,8,256,512,321,2048,16,349,80,1,343,16,2389,320,0,80,80,65,83,349,64,2049,16,64,2388,20,1,257,0,0,512]

theorem envBound46088 : H12AffineFastState.Bounded env46088 := by
  intro p hp
  have h : env46088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46087_46088 : H12AffineEnvironment.transform 9 321 env46087 = env46088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46087 == env46088) = true)

theorem identity46088 : scanCanonicalize (H12AffineFastState.compose env46088 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound46088 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46089 : List Nat := [2,4,8,16,1,64,8,256,512,321,260,16,349,80,1,343,16,81,320,0,80,80,65,83,349,64,261,16,64,80,20,1,257,0,0,512]

theorem envBound46089 : H12AffineFastState.Bounded env46089 := by
  intro p hp
  have h : env46089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46088_46089 : H12AffineEnvironment.transform 10 260 env46088 = env46089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env46088 == env46089) = true)

theorem identity46089 : scanCanonicalize (H12AffineFastState.compose env46089 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound46089 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env46090 : List Nat := [2,4,8,16,1,64,8,84,512,21,80,16,9,80,1,3,16,81,20,0,80,80,65,83,9,64,81,16,64,80,20,1,85,0,0,512]

theorem envBound46090 : H12AffineFastState.Bounded env46090 := by
  intro p hp
  have h : env46090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46089_46090 : H12AffineEnvironment.transform 7 84 env46089 = env46090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env46089 == env46090) = true)

theorem identity46090 : scanCanonicalize (H12AffineFastState.compose env46090 (packedSelected [15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46090 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env46091 : List Nat := [2,4,8,16,1,16,8,4,512,21,0,16,9,0,1,3,16,1,20,0,0,0,17,3,9,16,1,16,16,0,20,1,5,0,0,512]

end H12CloudChart0