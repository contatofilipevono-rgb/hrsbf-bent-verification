import H12CloudChart0Data093

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env23776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642569,8328,64,4464648,10642565,10507600,8830977,156696,14845384,257,2237605,2278657,213967]

theorem envBound23776 : H12AffineFastState.Bounded env23776 := by
  intro p hp
  have h : env23776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23775_23776 : H12AffineEnvironment.transform 23 8642569 env23775 = env23776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642569 env23775 == env23776) = true)

def env23777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,8388608,8642569,8328,64,4464648,8393985,8529108,8830977,156696,12645452,257,21793,46213,213967]

theorem envBound23777 : H12AffineFastState.Bounded env23777 := by
  intro p hp
  have h : env23777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23776_23777 : H12AffineEnvironment.transform 20 160132 env23776 = env23777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160132 env23776 == env23777) = true)

def env23778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169216,95497,8328,64,4464648,163841,45524,283905,156696,4350284,257,21793,46213,213967]

theorem envBound23778 : H12AffineFastState.Bounded env23778 := by
  intro p hp
  have h : env23778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23777_23778 : H12AffineEnvironment.transform 22 169216 env23777 = env23778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env23777 == env23778) = true)

def env23779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169216,95497,8328,64,2184,163841,45524,283905,156696,412108,257,21793,46213,213967]

theorem envBound23779 : H12AffineFastState.Bounded env23779 := by
  intro p hp
  have h : env23779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23778_23779 : H12AffineEnvironment.transform 21 272512 env23778 = env23779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23778 == env23779) = true)

theorem identity23779 : scanCanonicalize (H12AffineFastState.compose env23779 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound23779 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,77898,272512,120014,95497,8328,64,2184,115151,45524,283905,75222,329730,257,21793,46213,513]

theorem envBound23780 : H12AffineFastState.Bounded env23780 := by
  intro p hp
  have h : env23780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23779_23780 : H12AffineEnvironment.transform 16 82382 env23779 = env23780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env23779 == env23780) = true)

def env23781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272392,119878,95497,8192,64,2048,115015,45404,283905,75102,329730,257,21793,46093,513]

theorem envBound23781 : H12AffineFastState.Bounded env23781 := by
  intro p hp
  have h : env23781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23780_23781 : H12AffineEnvironment.transform 6 8 env23780 = env23781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23780 == env23781) = true)

theorem identity23781 : scanCanonicalize (H12AffineFastState.compose env23781 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23781 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,262144,1025,32769,69911,264533,119878,87124,349,64,2048,115015,36865,283905,66563,329730,257,21793,38224,513]

theorem envBound23782 : H12AffineFastState.Bounded env23782 := by
  intro p hp
  have h : env23782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23781_23782 : H12AffineEnvironment.transform 12 349 env23781 = env23782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23781 == env23782) = true)

theorem identity23782 : scanCanonicalize (H12AffineFastState.compose env23782 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound23782 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env23783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,56356,1025,32769,69911,54641,119878,87124,349,64,2048,115015,36865,35109,66563,119846,257,21793,38224,513]

theorem envBound23783 : H12AffineFastState.Bounded env23783 := by
  intro p hp
  have h : env23783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23782_23783 : H12AffineEnvironment.transform 17 56356 env23782 = env23783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env23782 == env23783) = true)

theorem identity23783 : scanCanonicalize (H12AffineFastState.compose env23783 (packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound23783 : packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env23784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,114,16692,56356,1025,32769,4453,54641,54324,21542,349,64,2048,49461,36865,35109,1137,54356,257,21793,38224,513]

theorem envBound23784 : H12AffineFastState.Bounded env23784 := by
  intro p hp
  have h : env23784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23783_23784 : H12AffineEnvironment.transform 15 114 env23783 = env23784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env23783 == env23784) = true)

theorem identity23784 : scanCanonicalize (H12AffineFastState.compose env23784 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23784 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env23785 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,34,16692,56356,1025,32769,4405,54561,54324,21542,269,16,2048,49461,36865,35109,1057,54276,257,21793,38144,513]

theorem envBound23785 : H12AffineFastState.Bounded env23785 := by
  intro p hp
  have h : env23785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23784_23785 : H12AffineEnvironment.transform 5 16 env23784 = env23785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23784 == env23785) = true)

theorem identity23785 : scanCanonicalize (H12AffineFastState.compose env23785 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23785 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env23786 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,16384,32768,34,16692,55604,273,32769,4405,53297,53540,20790,269,16,2048,49461,36865,35109,305,53524,257,20529,36880,513]

theorem envBound23786 : H12AffineFastState.Bounded env23786 := by
  intro p hp
  have h : env23786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23785_23786 : H12AffineEnvironment.transform 9 272 env23785 = env23786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23785 == env23786) = true)

theorem identity23786 : scanCanonicalize (H12AffineFastState.compose env23786 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound23786 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23787 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4404,32768,34,4096,34816,273,32769,4405,33029,32784,2,269,16,2048,36865,36865,35109,305,32800,257,261,36880,513]

theorem envBound23787 : H12AffineFastState.Bounded env23787 := by
  intro p hp
  have h : env23787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23786_23787 : H12AffineEnvironment.transform 13 4404 env23786 = env23787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env23786 == env23787) = true)

theorem identity23787 : scanCanonicalize (H12AffineFastState.compose env23787 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23788 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,32768,34,4096,34816,53,32769,4113,32801,32784,2,41,16,2048,36865,36865,34817,21,32800,37,33,36880,513]

theorem envBound23788 : H12AffineFastState.Bounded env23788 := by
  intro p hp
  have h : env23788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23787_23788 : H12AffineEnvironment.transform 7 36 env23787 = env23788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23787 == env23788) = true)

theorem identity23788 : scanCanonicalize (H12AffineFastState.compose env23788 (packedSelected [0,2,7] rootPS)) = affineNative (2^(14+1) ^^^ 6192) := by decide +kernel

theorem selectedBound23788 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23789 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,6192,34,4096,4144,53,6193,4113,6161,6176,2,41,16,2048,2097,2097,4145,21,6160,37,33,2080,513]

theorem envBound23789 : H12AffineFastState.Bounded env23789 := by
  intro p hp
  have h : env23789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23788_23789 : H12AffineEnvironment.transform 14 6192 env23788 = env23789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6192 env23788 == env23789) = true)

theorem identity23789 : scanCanonicalize (H12AffineFastState.compose env23789 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23789 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env23790 : List Nat := [2,4,8,16,32,16,8,36,0,52,2048,4096,41,4112,6192,34,4096,4144,53,6193,4113,6161,6176,2,41,16,2048,2097,2097,4145,21,6160,37,33,2080,1]

theorem envBound23790 : H12AffineFastState.Bounded env23790 := by
  intro p hp
  have h : env23790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23789_23790 : H12AffineEnvironment.transform 8 0 env23789 = env23790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23789 == env23790) = true)

theorem identity23790 : scanCanonicalize (H12AffineFastState.compose env23790 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23790 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23791 : List Nat := [2,4,8,16,32,16,8,36,0,52,2048,17,41,1,2081,34,17,33,53,2080,0,2048,2097,2,41,16,2048,2097,2097,32,21,2049,37,33,2080,1]

theorem envBound23791 : H12AffineFastState.Bounded env23791 := by
  intro p hp
  have h : env23791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23790_23791 : H12AffineEnvironment.transform 11 17 env23790 = env23791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23790 == env23791) = true)

theorem identity23791 : scanCanonicalize (H12AffineFastState.compose env23791 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23791 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23792 : List Nat := [2,4,8,16,32,16,8,36,0,52,1,17,41,1,32,34,17,33,53,33,0,1,48,2,41,16,1,48,48,32,21,0,37,33,33,1]

theorem envBound23792 : H12AffineFastState.Bounded env23792 := by
  intro p hp
  have h : env23792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23791_23792 : H12AffineEnvironment.transform 10 1 env23791 = env23792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23791 == env23792) = true)

theorem identity23792 : scanCanonicalize (H12AffineFastState.compose env23792 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23792 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23793 : List Nat := [2,4,8,16,17,16,8,21,0,5,1,17,24,1,17,19,17,16,4,16,0,1,1,2,24,16,1,1,1,17,21,0,20,16,16,1]

theorem envBound23793 : H12AffineFastState.Bounded env23793 := by
  intro p hp
  have h : env23793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23792_23793 : H12AffineEnvironment.transform 4 17 env23792 = env23793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23792 == env23793) = true)

theorem identity23793 : scanCanonicalize (H12AffineFastState.compose env23793 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23794 : List Nat := [2,4,8,1,0,1,8,4,0,5,1,0,9,1,0,2,0,1,4,1,0,1,1,2,9,1,1,1,1,0,4,0,5,1,1,1]

theorem envBound23794 : H12AffineFastState.Bounded env23794 := by
  intro p hp
  have h : env23794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23793_23794 : H12AffineEnvironment.transform 3 1 env23793 = env23794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23793 == env23794) = true)

theorem identity23794 : scanCanonicalize (H12AffineFastState.compose env23794 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23795 : List Nat := [2,4,2,1,0,1,2,4,0,5,1,0,3,1,0,2,0,1,4,1,0,1,1,2,3,1,1,1,1,0,4,0,5,1,1,1]

theorem envBound23795 : H12AffineFastState.Bounded env23795 := by
  intro p hp
  have h : env23795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23794_23795 : H12AffineEnvironment.transform 2 2 env23794 = env23795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23794 == env23795) = true)

def env23796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,119879,95497,8193,64,2049,115014,45405,283905,75103,329730,257,21793,46092,513]

theorem envBound23796 : H12AffineFastState.Bounded env23796 := by
  intro p hp
  have h : env23796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23780_23796 : H12AffineEnvironment.transform 6 9 env23780 = env23796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23780 == env23796) = true)

def env23797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,77898,33,119879,95497,8193,64,2049,115014,45405,32041,75103,73770,257,21793,46092,513]

theorem envBound23797 : H12AffineFastState.Bounded env23797 := by
  intro p hp
  have h : env23797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23796_23797 : H12AffineEnvironment.transform 17 10280 env23796 = env23797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23796 == env23797) = true)

theorem identity23797 : scanCanonicalize (H12AffineFastState.compose env23797 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound23797 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env23798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,5393,10280,1025,32769,25628,33,32785,8543,8193,64,2049,38160,45405,32041,28937,29820,257,21793,46092,513]

theorem envBound23798 : H12AffineFastState.Bounded env23798 := by
  intro p hp
  have h : env23798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23797_23798 : H12AffineEnvironment.transform 15 21590 env23797 = env23798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env23797 == env23798) = true)

theorem identity23798 : scanCanonicalize (H12AffineFastState.compose env23798 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23798 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env23799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,5393,10280,1025,0,25628,33,16,8543,8193,64,2049,5393,12636,32041,28937,29820,257,21793,13325,513]

theorem envBound23799 : H12AffineFastState.Bounded env23799 := by
  intro p hp
  have h : env23799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23798_23799 : H12AffineEnvironment.transform 14 1 env23798 = env23799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23798 == env23799) = true)

theorem identity23799 : scanCanonicalize (H12AffineFastState.compose env23799 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23799 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env23800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,21590,5393,2341,1025,0,17681,33,16,82,268,64,2049,5393,4177,23588,20484,21873,257,21793,5376,513]

theorem envBound23800 : H12AffineFastState.Bounded env23800 := by
  intro p hp
  have h : env23800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23799_23800 : H12AffineEnvironment.transform 12 269 env23799 = env23800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23799 == env23800) = true)

theorem identity23800 : scanCanonicalize (H12AffineFastState.compose env23800 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23800 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23801 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,343,5393,2341,1025,0,4112,33,16,82,268,64,2049,5393,4177,2341,1285,112,257,32,5376,513]

theorem envBound23801 : H12AffineFastState.Bounded env23801 := by
  intro p hp
  have h : env23801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23800_23801 : H12AffineEnvironment.transform 13 5377 env23800 = env23801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23800 == env23801) = true)

def env23802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,77898,32,119879,95497,8193,64,2049,115014,45405,32040,75103,73771,257,21793,46092,513]

theorem envBound23802 : H12AffineFastState.Bounded env23802 := by
  intro p hp
  have h : env23802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23796_23802 : H12AffineEnvironment.transform 17 10281 env23796 = env23802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23796 == env23802) = true)

theorem identity23802 : scanCanonicalize (H12AffineFastState.compose env23802 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound23802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10281,1025,32769,58397,32,16,41310,8193,64,2049,5393,45405,32040,61704,62588,257,21793,46092,513]

theorem envBound23803 : H12AffineFastState.Bounded env23803 := by
  intro p hp
  have h : env23803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23802_23803 : H12AffineEnvironment.transform 15 54359 env23802 = env23803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env23802 == env23803) = true)

theorem identity23803 : scanCanonicalize (H12AffineFastState.compose env23803 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound23803 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env23804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2049,32768,40022,38160,10281,1025,32769,44060,32,16,41310,8193,64,2049,5393,45405,13609,47369,48253,257,7456,46092,513]

theorem envBound23804 : H12AffineFastState.Bounded env23804 := by
  intro p hp
  have h : env23804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23803_23804 : H12AffineEnvironment.transform 13 2049 env23803 = env23804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env23803 == env23804) = true)

theorem identity23804 : scanCanonicalize (H12AffineFastState.compose env23804 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23804 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,2049,32768,40022,38160,2421,1025,32769,36160,32,16,32770,349,64,2049,5393,36865,5237,38997,40225,257,7456,38224,513]

theorem envBound23805 : H12AffineFastState.Bounded env23805 := by
  intro p hp
  have h : env23805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23804_23805 : H12AffineEnvironment.transform 12 348 env23804 = env23805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23804 == env23805) = true)

theorem identity23805 : scanCanonicalize (H12AffineFastState.compose env23805 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound23805 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,1297,32768,37190,38160,1125,1025,32769,32848,32,16,32770,349,64,1297,5393,36865,5237,38213,36913,257,4144,38224,513]

theorem envBound23806 : H12AffineFastState.Bounded env23806 := by
  intro p hp
  have h : env23806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23805_23806 : H12AffineEnvironment.transform 10 1296 env23805 = env23806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env23805 == env23806) = true)

theorem identity23806 : scanCanonicalize (H12AffineFastState.compose env23806 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23806 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23807 : List Nat := [2,4,8,16,32,64,9,256,512,273,1,4096,348,0,32768,37190,36865,372,272,32769,32848,32,16,32770,349,64,0,4096,36865,4452,36948,36913,257,4144,36929,513]

theorem envBound23807 : H12AffineFastState.Bounded env23807 := by
  intro p hp
  have h : env23807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23806_23807 : H12AffineEnvironment.transform 9 273 env23806 = env23807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23806 == env23807) = true)

theorem identity23807 : scanCanonicalize (H12AffineFastState.compose env23807 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23807 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23808 : List Nat := [2,4,8,16,32,64,9,117,512,100,1,4096,41,0,32768,36915,36865,1,101,32769,32848,32,16,32770,40,64,0,4096,36865,4113,36948,36913,116,4144,36929,513]

theorem envBound23808 : H12AffineFastState.Bounded env23808 := by
  intro p hp
  have h : env23808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23807_23808 : H12AffineEnvironment.transform 7 117 env23807 = env23808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23807 == env23808) = true)

theorem identity23808 : scanCanonicalize (H12AffineFastState.compose env23808 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23808 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env23809 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,41,0,32768,36915,36865,1,52,32769,32769,32,16,32770,40,17,0,4096,36865,4113,36869,36913,37,4144,36880,513]

theorem envBound23809 : H12AffineFastState.Bounded env23809 := by
  intro p hp
  have h : env23809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23808_23809 : H12AffineEnvironment.transform 5 17 env23808 = env23809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23808 == env23809) = true)

theorem identity23809 : scanCanonicalize (H12AffineFastState.compose env23809 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23809 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env23810 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,41,0,4112,35,17,1,52,4113,4113,32,16,4114,40,17,0,4096,17,4113,21,33,37,4144,0,513]

theorem envBound23810 : H12AffineFastState.Bounded env23810 := by
  intro p hp
  have h : env23810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23809_23810 : H12AffineEnvironment.transform 14 4112 env23809 = env23810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env23809 == env23810) = true)

theorem identity23810 : scanCanonicalize (H12AffineFastState.compose env23810 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23811 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,41,0,1,35,17,1,52,0,0,32,16,3,40,17,0,17,17,0,21,33,37,33,0,513]

theorem envBound23811 : H12AffineFastState.Bounded env23811 := by
  intro p hp
  have h : env23811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23810_23811 : H12AffineEnvironment.transform 11 17 env23810 = env23811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23810 == env23811) = true)

theorem identity23811 : scanCanonicalize (H12AffineFastState.compose env23811 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23812 : List Nat := [2,4,8,0,32,1,9,36,512,37,1,1,41,0,1,35,1,1,36,0,0,32,0,3,40,1,0,1,1,0,5,33,37,33,0,513]

theorem envBound23812 : H12AffineFastState.Bounded env23812 := by
  intro p hp
  have h : env23812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23811_23812 : H12AffineEnvironment.transform 3 0 env23811 = env23812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23811 == env23812) = true)

theorem identity23812 : scanCanonicalize (H12AffineFastState.compose env23812 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound23812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23813 : List Nat := [2,4,8,0,32,1,9,36,42,37,1,1,41,0,1,35,1,1,36,0,0,32,0,3,40,1,0,1,1,0,5,33,37,33,0,43]

theorem envBound23813 : H12AffineFastState.Bounded env23813 := by
  intro p hp
  have h : env23813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23812_23813 : H12AffineEnvironment.transform 8 42 env23812 = env23813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env23812 == env23813) = true)

def env23814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169216,95497,8328,64,2185,163841,45524,283905,156696,412109,257,21793,46213,213967]

theorem envBound23814 : H12AffineFastState.Bounded env23814 := by
  intro p hp
  have h : env23814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23778_23814 : H12AffineEnvironment.transform 21 272513 env23778 = env23814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23778 == env23814) = true)

theorem identity23814 : scanCanonicalize (H12AffineFastState.compose env23814 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23814 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,160132,272513,169216,41430,8328,64,2185,163841,45524,283905,156696,412109,257,21793,46213,169744]

theorem envBound23815 : H12AffineFastState.Bounded env23815 := by
  intro p hp
  have h : env23815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23814_23815 : H12AffineEnvironment.transform 15 54495 env23814 = env23815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23814 == env23815) = true)

def env23816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160012,272393,169216,41310,8192,64,2049,163841,45404,283905,156696,411973,257,21793,46093,169744]

theorem envBound23816 : H12AffineFastState.Bounded env23816 := by
  intro p hp
  have h : env23816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23815_23816 : H12AffineEnvironment.transform 6 8 env23815 = env23816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23815 == env23816) = true)

theorem identity23816 : scanCanonicalize (H12AffineFastState.compose env23816 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound23816 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env23817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8574,131072,262144,1025,29992,160012,272393,155689,21623,8192,64,2049,161064,17525,283905,156696,411973,257,21793,16676,156217]

theorem envBound23817 : H12AffineFastState.Bounded env23817 := by
  intro p hp
  have h : env23817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23816_23817 : H12AffineEnvironment.transform 14 29993 env23816 = env23817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env23816 == env23817) = true)

theorem identity23817 : scanCanonicalize (H12AffineFastState.compose env23817 (packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound23817 : packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env23818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8574,13625,262144,1025,29992,17461,272393,21776,21623,8192,64,2049,16401,17525,283905,20769,294012,257,21793,16676,22272]

theorem envBound23818 : H12AffineFastState.Bounded env23818 := by
  intro p hp
  have h : env23818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23817_23818 : H12AffineEnvironment.transform 16 13625 env23817 = env23818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env23817 == env23818) = true)

theorem identity23818 : scanCanonicalize (H12AffineFastState.compose env23818 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23818 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env23819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8574,13625,10280,1025,29992,17461,33,21776,21623,8192,64,2049,16401,17525,32041,20769,21588,257,21793,16676,22272]

theorem envBound23819 : H12AffineFastState.Bounded env23819 := by
  intro p hp
  have h : env23819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23818_23819 : H12AffineEnvironment.transform 17 10280 env23818 = env23819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23818 == env23819) = true)

theorem identity23819 : scanCanonicalize (H12AffineFastState.compose env23819 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound23819 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8574,13625,10280,1025,8541,4160,33,357,2,8192,64,2049,5220,4096,10588,1364,33,257,340,5457,885]

theorem envBound23820 : H12AffineFastState.Bounded env23820 := by
  intro p hp
  have h : env23820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23819_23820 : H12AffineEnvironment.transform 13 5237 env23819 = env23820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env23819 == env23820) = true)

theorem identity23820 : scanCanonicalize (H12AffineFastState.compose env23820 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23820 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env23821 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,8192,5237,8280,8314,13373,10280,1025,8281,4160,33,97,2,8192,64,2049,5220,4096,10328,1104,33,5,80,5205,625]

theorem envBound23821 : H12AffineFastState.Bounded env23821 := by
  intro p hp
  have h : env23821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23820_23821 : H12AffineEnvironment.transform 7 4 env23820 = env23821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23820 == env23821) = true)

theorem identity23821 : scanCanonicalize (H12AffineFastState.compose env23821 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound23821 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23822 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,88,5237,0,34,5221,2160,1025,1,4160,33,97,2,88,64,2049,5220,4096,2048,1104,33,5,80,5205,625]

theorem envBound23822 : H12AffineFastState.Bounded env23822 := by
  intro p hp
  have h : env23822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23821_23822 : H12AffineEnvironment.transform 12 88 env23821 = env23822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env23821 == env23822) = true)

theorem identity23822 : scanCanonicalize (H12AffineFastState.compose env23822 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound23822 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env23823 : List Nat := [2,4,8,16,32,64,8,4,512,1024,33,4096,88,5237,0,34,5221,81,1025,1,4160,33,97,2,88,64,32,5220,4096,33,1104,33,5,80,5205,625]

theorem envBound23823 : H12AffineFastState.Bounded env23823 := by
  intro p hp
  have h : env23823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23822_23823 : H12AffineEnvironment.transform 10 33 env23822 = env23823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env23822 == env23823) = true)

theorem identity23823 : scanCanonicalize (H12AffineFastState.compose env23823 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound23823 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23824 : List Nat := [2,4,8,16,32,64,8,4,512,575,33,4096,88,4682,0,34,4698,81,574,1,4160,33,97,2,88,64,32,4699,4096,33,623,33,5,80,4714,625]

theorem envBound23824 : H12AffineFastState.Bounded env23824 := by
  intro p hp
  have h : env23824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23823_23824 : H12AffineEnvironment.transform 9 575 env23823 = env23824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env23823 == env23824) = true)

theorem identity23824 : scanCanonicalize (H12AffineFastState.compose env23824 (packedSelected [1,2,3,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23824 : packedSelected [1,2,3,6,12] rootPS < 2^1333 := by decide +kernel

def env23825 : List Nat := [2,4,8,16,32,17,8,4,512,575,33,4096,9,4635,0,34,4619,0,574,1,4113,33,48,2,9,17,32,4618,4096,33,574,33,5,1,4667,544]

theorem envBound23825 : H12AffineFastState.Bounded env23825 := by
  intro p hp
  have h : env23825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23824_23825 : H12AffineEnvironment.transform 5 17 env23824 = env23825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23824 == env23825) = true)

theorem identity23825 : scanCanonicalize (H12AffineFastState.compose env23825 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound23825 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23826 : List Nat := [2,4,8,16,32,17,8,4,512,575,33,539,9,0,0,34,16,0,574,1,522,33,48,2,9,17,32,17,539,33,574,33,5,1,32,544]

theorem envBound23826 : H12AffineFastState.Bounded env23826 := by
  intro p hp
  have h : env23826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23825_23826 : H12AffineEnvironment.transform 11 539 env23825 = env23826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env23825 == env23826) = true)

theorem identity23826 : scanCanonicalize (H12AffineFastState.compose env23826 (packedSelected [1,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23826 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env23827 : List Nat := [2,1,8,16,32,17,8,1,512,570,33,539,9,0,0,34,16,0,571,1,522,33,48,2,9,17,32,17,539,33,571,33,0,1,32,544]

theorem envBound23827 : H12AffineFastState.Bounded env23827 := by
  intro p hp
  have h : env23827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23826_23827 : H12AffineEnvironment.transform 1 1 env23826 = env23827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23826 == env23827) = true)

theorem identity23827 : scanCanonicalize (H12AffineFastState.compose env23827 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound23827 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env23828 : List Nat := [2,1,8,16,32,17,8,1,2,56,33,25,9,0,0,34,16,0,57,1,8,33,48,2,9,17,32,17,25,33,57,33,0,1,32,34]

theorem envBound23828 : H12AffineFastState.Bounded env23828 := by
  intro p hp
  have h : env23828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23827_23828 : H12AffineEnvironment.transform 8 2 env23827 = env23828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env23827 == env23828) = true)

theorem identity23828 : scanCanonicalize (H12AffineFastState.compose env23828 (packedSelected [0,1,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23828 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env23829 : List Nat := [2,1,8,16,1,17,8,1,2,25,0,25,9,0,0,3,16,0,24,1,8,0,17,2,9,17,1,17,25,0,24,0,0,1,1,3]

theorem envBound23829 : H12AffineFastState.Bounded env23829 := by
  intro p hp
  have h : env23829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23828_23829 : H12AffineEnvironment.transform 4 1 env23828 = env23829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23828 == env23829) = true)

theorem identity23829 : scanCanonicalize (H12AffineFastState.compose env23829 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound23829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23830 : List Nat := [2,1,8,3,1,2,8,1,2,10,0,10,9,0,0,3,3,0,11,1,8,0,2,2,9,2,1,2,10,0,11,0,0,1,1,3]

theorem envBound23830 : H12AffineFastState.Bounded env23830 := by
  intro p hp
  have h : env23830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23829_23830 : H12AffineEnvironment.transform 3 3 env23829 = env23830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env23829 == env23830) = true)

theorem identity23830 : scanCanonicalize (H12AffineFastState.compose env23830 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound23830 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23831 : List Nat := [2,1,0,3,1,2,0,1,2,2,0,2,1,0,0,3,3,0,3,1,0,0,2,2,1,2,1,2,2,0,3,0,0,1,1,3]

theorem envBound23831 : H12AffineFastState.Bounded env23831 := by
  intro p hp
  have h : env23831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23830_23831 : H12AffineEnvironment.transform 2 0 env23830 = env23831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env23830 == env23831) = true)

theorem identity23831 : scanCanonicalize (H12AffineFastState.compose env23831 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23831 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23832 : List Nat := [1,1,0,0,1,1,0,1,1,1,0,1,1,0,0,0,0,0,0,1,0,0,1,1,1,1,1,1,1,0,0,0,0,1,1,0]

theorem envBound23832 : H12AffineFastState.Bounded env23832 := by
  intro p hp
  have h : env23832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23831_23832 : H12AffineEnvironment.transform 0 1 env23831 = env23832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23831 == env23832) = true)

def env23833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272392,169216,41311,8193,64,2048,163841,45405,283905,156696,411972,257,21793,46092,169744]

theorem envBound23833 : H12AffineFastState.Bounded env23833 := by
  intro p hp
  have h : env23833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23815_23833 : H12AffineEnvironment.transform 6 9 env23815 = env23833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23815 == env23833) = true)

theorem identity23833 : scanCanonicalize (H12AffineFastState.compose env23833 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound23833 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env23834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138340,1025,32769,160013,144492,169216,41311,8193,64,2048,163841,45405,149861,156696,21792,257,21793,46092,169744]

theorem envBound23834 : H12AffineFastState.Bounded env23834 := by
  intro p hp
  have h : env23834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23833_23834 : H12AffineEnvironment.transform 17 138340 env23833 = env23834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env23833 == env23834) = true)

theorem identity23834 : scanCanonicalize (H12AffineFastState.compose env23834 (packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound23834 : packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env23835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,32041,1025,32769,4160,21793,62541,41311,8193,64,2048,57676,45405,10280,1365,21792,257,21793,46092,63069]

theorem envBound23835 : H12AffineFastState.Bounded env23835 := by
  intro p hp
  have h : env23835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23834_23835 : H12AffineEnvironment.transform 16 24909 env23834 = env23835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env23834 == env23835) = true)

theorem identity23835 : scanCanonicalize (H12AffineFastState.compose env23835 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound23835 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env23836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8492,30074,24909,32041,1025,8493,4160,21793,21857,115,8193,64,2048,16480,4209,10280,1365,21792,257,21793,5408,22385]

theorem envBound23836 : H12AffineFastState.Bounded env23836 := by
  intro p hp
  have h : env23836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23835_23836 : H12AffineEnvironment.transform 14 8492 env23835 = env23836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env23835 == env23836) = true)

theorem identity23836 : scanCanonicalize (H12AffineFastState.compose env23836 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound23836 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env23837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13356,8492,342,5473,2309,1025,8493,4160,8461,8525,115,8193,64,2048,13388,4209,10280,1365,8460,257,8461,5408,9053]

theorem envBound23837 : H12AffineFastState.Bounded env23837 := by
  intro p hp
  have h : env23837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23836_23837 : H12AffineEnvironment.transform 13 13356 env23836 = env23837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env23836 == env23837) = true)

theorem identity23837 : scanCanonicalize (H12AffineFastState.compose env23837 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23837 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,112,342,5473,2309,1025,113,4160,81,17,115,349,64,2048,5392,4209,2420,1365,80,257,81,5408,513]

theorem envBound23838 : H12AffineFastState.Bounded env23838 := by
  intro p hp
  have h : env23838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23837_23838 : H12AffineEnvironment.transform 12 348 env23837 = env23838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23837 == env23838) = true)

theorem identity23838 : scanCanonicalize (H12AffineFastState.compose env23838 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23838 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23839 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5409,33,263,5424,2309,1025,32,4113,0,17,34,268,17,2048,5392,4128,2341,1284,1,257,0,5408,513]

theorem envBound23839 : H12AffineFastState.Bounded env23839 := by
  intro p hp
  have h : env23839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23838_23839 : H12AffineEnvironment.transform 5 17 env23838 = env23839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23838 == env23839) = true)

theorem identity23839 : scanCanonicalize (H12AffineFastState.compose env23839 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound23839 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23840 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,4096,269,5409,33,263,5424,1044,1025,32,4113,0,17,34,268,17,1297,5392,4128,1076,1284,1,257,0,5408,513]

theorem envBound23840 : H12AffineFastState.Bounded env23840 := by
  intro p hp
  have h : env23840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23839_23840 : H12AffineEnvironment.transform 10 1297 env23839 = env23840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env23839 == env23840) = true)

theorem identity23840 : scanCanonicalize (H12AffineFastState.compose env23840 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound23840 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23841 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1540,269,805,33,263,820,1044,1025,32,1557,0,17,34,268,17,1297,788,1572,1076,1284,1,257,0,804,513]

theorem envBound23841 : H12AffineFastState.Bounded env23841 := by
  intro p hp
  have h : env23841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23840_23841 : H12AffineEnvironment.transform 11 1540 env23840 = env23841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env23840 == env23841) = true)

theorem identity23841 : scanCanonicalize (H12AffineFastState.compose env23841 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound23841 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23842 : List Nat := [2,4,8,16,32,17,9,256,512,801,560,293,269,805,33,263,820,821,800,32,308,0,17,34,268,17,560,788,261,789,549,1,257,0,804,513]

theorem envBound23842 : H12AffineFastState.Bounded env23842 := by
  intro p hp
  have h : env23842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23841_23842 : H12AffineEnvironment.transform 9 801 env23841 = env23842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env23841 == env23842) = true)

theorem identity23842 : scanCanonicalize (H12AffineFastState.compose env23842 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23842 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env23843 : List Nat := [2,4,8,16,17,17,9,256,512,784,513,276,269,788,16,263,773,772,785,17,261,0,17,19,268,17,513,788,261,789,532,1,257,0,789,513]

theorem envBound23843 : H12AffineFastState.Bounded env23843 := by
  intro p hp
  have h : env23843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23842_23843 : H12AffineEnvironment.transform 4 17 env23842 = env23843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23842 == env23843) = true)

theorem identity23843 : scanCanonicalize (H12AffineFastState.compose env23843 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound23843 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env23844 : List Nat := [2,4,8,16,17,17,9,256,260,20,261,276,269,16,16,263,1,0,21,17,261,0,17,19,268,17,261,16,261,17,272,1,257,0,17,261]

theorem envBound23844 : H12AffineFastState.Bounded env23844 := by
  intro p hp
  have h : env23844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23843_23844 : H12AffineEnvironment.transform 8 260 env23843 = env23844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env23843 == env23844) = true)

theorem identity23844 : scanCanonicalize (H12AffineFastState.compose env23844 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23844 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23845 : List Nat := [2,4,8,1,0,0,9,256,260,5,261,261,269,1,1,263,1,0,4,0,261,0,0,2,268,0,261,1,261,0,257,1,257,0,0,261]

theorem envBound23845 : H12AffineFastState.Bounded env23845 := by
  intro p hp
  have h : env23845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23844_23845 : H12AffineEnvironment.transform 3 1 env23844 = env23845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23844 == env23845) = true)

def env23846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169217,95496,8328,64,4464648,163840,45525,283904,156696,4350285,257,21793,46213,213967]

theorem envBound23846 : H12AffineFastState.Bounded env23846 := by
  intro p hp
  have h : env23846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23777_23846 : H12AffineEnvironment.transform 22 169217 env23777 = env23846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env23777 == env23846) = true)

def env23847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169217,95496,8328,64,2184,163840,45525,283904,156696,412109,257,21793,46213,213967]

theorem envBound23847 : H12AffineFastState.Bounded env23847 := by
  intro p hp
  have h : env23847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23846_23847 : H12AffineEnvironment.transform 21 272512 env23846 = env23847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23846 == env23847) = true)

theorem identity23847 : scanCanonicalize (H12AffineFastState.compose env23847 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound23847 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,115871,272512,73754,95496,8328,64,2184,79131,45525,283904,119043,392406,257,21793,46213,63188]

theorem envBound23848 : H12AffineFastState.Bounded env23848 := by
  intro p hp
  have h : env23848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23847_23848 : H12AffineEnvironment.transform 16 111899 env23847 = env23848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env23847 == env23848) = true)

def env23849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,115871,32,73754,95496,8328,64,2184,79131,45525,32160,119043,119926,257,21793,46213,63188]

theorem envBound23849 : H12AffineFastState.Bounded env23849 := by
  intro p hp
  have h : env23849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23848_23849 : H12AffineEnvironment.transform 17 10400 env23848 = env23849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env23848 == env23849) = true)

theorem identity23849 : scanCanonicalize (H12AffineFastState.compose env23849 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23849 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,13388,10400,1025,32769,17864,32,41293,62559,8328,64,2184,46156,45525,32160,20564,21793,257,21793,46213,63188]

theorem envBound23850 : H12AffineFastState.Bounded env23850 := by
  intro p hp
  have h : env23850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23849_23850 : H12AffineEnvironment.transform 15 33111 env23849 = env23850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23849 == env23850) = true)

theorem identity23850 : scanCanonicalize (H12AffineFastState.compose env23850 (packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound23850 : packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env23851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,33111,13388,10400,1025,32769,4404,32,41293,41123,8328,64,2184,46156,45525,10588,1192,477,257,477,46213,41512]

theorem envBound23851 : H12AffineFastState.Bounded env23851 := by
  intro p hp
  have h : env23851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23850_23851 : H12AffineEnvironment.transform 13 5372 env23850 = env23851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env23850 == env23851) = true)

theorem identity23851 : scanCanonicalize (H12AffineFastState.compose env23851 (packedSelected [1,3,8,10,12,15,17,18,19,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23851 : packedSelected [1,3,8,10,12,15,17,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23852 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,32768,32802,13388,10400,1025,32769,4161,32,41016,41123,8328,64,2184,46156,45216,10281,1192,168,116,168,46213,41512]

theorem envBound23852 : H12AffineFastState.Bounded env23852 := by
  intro p hp
  have h : env23852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23851_23852 : H12AffineEnvironment.transform 7 117 env23851 = env23852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23851 == env23852) = true)

theorem identity23852 : scanCanonicalize (H12AffineFastState.compose env23852 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound23852 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23853 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8233,8203,13388,10400,1025,8232,4161,32,17,138,8328,64,2184,5221,4233,10281,1192,168,116,168,5292,513]

theorem envBound23853 : H12AffineFastState.Bounded env23853 := by
  intro p hp
  have h : env23853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23852_23853 : H12AffineEnvironment.transform 14 8233 env23852 = env23853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env23852 == env23853) = true)

theorem identity23853 : scanCanonicalize (H12AffineFastState.compose env23853 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23853 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23854 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,8192,5204,8233,8203,13388,10248,1025,8232,4161,32,17,34,8224,64,2080,5221,4129,10281,1024,0,116,0,5124,513]

theorem envBound23854 : H12AffineFastState.Bounded env23854 := by
  intro p hp
  have h : env23854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23853_23854 : H12AffineEnvironment.transform 6 40 env23853 = env23854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23853 == env23854) = true)

theorem identity23854 : scanCanonicalize (H12AffineFastState.compose env23854 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound23854 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env23855 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,1133,5204,1092,1126,4129,3173,1025,1093,4161,32,17,34,1101,64,2080,5221,4129,3140,1024,0,116,0,5124,513]

theorem envBound23855 : H12AffineFastState.Bounded env23855 := by
  intro p hp
  have h : env23855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23854_23855 : H12AffineEnvironment.transform 12 1133 env23854 = env23855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env23854 == env23855) = true)

theorem identity23855 : scanCanonicalize (H12AffineFastState.compose env23855 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound23855 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23856 : List Nat := [2,4,8,16,32,64,40,117,512,69,2048,4096,40,4113,1,35,4129,2080,68,0,4161,32,17,34,8,64,2080,4128,4129,2049,69,0,116,0,4161,513]

theorem envBound23856 : H12AffineFastState.Bounded env23856 := by
  intro p hp
  have h : env23856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23855_23856 : H12AffineEnvironment.transform 9 69 env23855 = env23856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env23855 == env23856) = true)

theorem identity23856 : scanCanonicalize (H12AffineFastState.compose env23856 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23856 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23857 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,4096,8,4113,1,3,4097,2048,68,0,4161,0,17,2,8,64,2048,4096,4097,2049,69,0,84,0,4161,513]

theorem envBound23857 : H12AffineFastState.Bounded env23857 := by
  intro p hp
  have h : env23857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23856_23857 : H12AffineEnvironment.transform 4 0 env23856 = env23857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23856 == env23857) = true)

theorem identity23857 : scanCanonicalize (H12AffineFastState.compose env23857 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound23857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23858 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,65,8,80,1,3,64,2048,68,0,0,0,17,2,8,64,2048,65,64,2049,69,0,84,0,0,513]

theorem envBound23858 : H12AffineFastState.Bounded env23858 := by
  intro p hp
  have h : env23858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23857_23858 : H12AffineEnvironment.transform 11 65 env23857 = env23858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env23857 == env23858) = true)

theorem identity23858 : scanCanonicalize (H12AffineFastState.compose env23858 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound23858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23859 : List Nat := [2,4,8,16,0,1,8,20,512,4,2048,0,8,17,1,3,1,2048,5,0,0,0,17,2,8,1,2048,0,1,2049,4,0,21,0,0,513]

theorem envBound23859 : H12AffineFastState.Bounded env23859 := by
  intro p hp
  have h : env23859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23858_23859 : H12AffineEnvironment.transform 5 1 env23858 = env23859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env23858 == env23859) = true)

theorem identity23859 : scanCanonicalize (H12AffineFastState.compose env23859 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23859 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23860 : List Nat := [2,4,8,0,0,1,8,4,512,4,2048,0,8,1,1,3,1,2048,5,0,0,0,1,2,8,1,2048,0,1,2049,4,0,5,0,0,513]

theorem envBound23860 : H12AffineFastState.Bounded env23860 := by
  intro p hp
  have h : env23860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23859_23860 : H12AffineEnvironment.transform 3 0 env23859 = env23860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23859 == env23860) = true)

theorem identity23860 : scanCanonicalize (H12AffineFastState.compose env23860 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23861 : List Nat := [2,4,3,0,0,1,3,4,512,4,2048,0,3,1,1,3,1,2048,5,0,0,0,1,2,3,1,2048,0,1,2049,4,0,5,0,0,513]

theorem envBound23861 : H12AffineFastState.Bounded env23861 := by
  intro p hp
  have h : env23861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23860_23861 : H12AffineEnvironment.transform 2 3 env23860 = env23861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23860 == env23861) = true)

theorem identity23861 : scanCanonicalize (H12AffineFastState.compose env23861 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound23861 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23862 : List Nat := [2,4,3,0,0,1,3,4,512,4,513,0,3,1,1,3,1,513,5,0,0,0,1,2,3,1,513,0,1,512,4,0,5,0,0,513]

theorem envBound23862 : H12AffineFastState.Bounded env23862 := by
  intro p hp
  have h : env23862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23861_23862 : H12AffineEnvironment.transform 10 513 env23861 = env23862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env23861 == env23862) = true)

theorem identity23862 : scanCanonicalize (H12AffineFastState.compose env23862 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23862 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23863 : List Nat := [2,4,3,0,0,1,3,4,1,4,0,0,3,1,1,3,1,0,5,0,0,0,1,2,3,1,0,0,1,1,4,0,5,0,0,0]

theorem envBound23863 : H12AffineFastState.Bounded env23863 := by
  intro p hp
  have h : env23863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23862_23863 : H12AffineEnvironment.transform 8 1 env23862 = env23863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23862 == env23863) = true)

def env23864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,115871,33,73754,95496,8328,64,2184,79131,45525,32161,119043,119927,257,21793,46213,63188]

theorem envBound23864 : H12AffineFastState.Bounded env23864 := by
  intro p hp
  have h : env23864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23848_23864 : H12AffineEnvironment.transform 17 10401 env23848 = env23864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env23848 == env23864) = true)

theorem identity23864 : scanCanonicalize (H12AffineFastState.compose env23864 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23864 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10401,1025,32769,58516,33,17,21763,8328,64,2184,5392,45525,32161,61704,62588,257,21793,46213,63188]

theorem envBound23865 : H12AffineFastState.Bounded env23865 := by
  intro p hp
  have h : env23865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23864_23865 : H12AffineEnvironment.transform 15 8203 env23864 = env23865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23864 == env23865) = true)

theorem identity23865 : scanCanonicalize (H12AffineFastState.compose env23865 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23865 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env23866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10280,1025,32769,58397,33,17,21763,8193,64,2049,5392,45404,32040,61704,62588,257,21793,46092,63069]

theorem envBound23866 : H12AffineFastState.Bounded env23866 := by
  intro p hp
  have h : env23866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23865_23866 : H12AffineEnvironment.transform 6 9 env23865 = env23866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23865 == env23866) = true)

theorem identity23866 : scanCanonicalize (H12AffineFastState.compose env23866 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23866 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24908,10280,1025,29789,4161,33,17,21763,8193,64,2049,5392,17664,32040,1364,32,257,21793,16464,513]

theorem envBound23867 : H12AffineFastState.Bounded env23867 := by
  intro p hp
  have h : env23867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23866_23867 : H12AffineEnvironment.transform 14 29788 env23866 = env23867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23866 == env23867) = true)

theorem identity23867 : scanCanonicalize (H12AffineFastState.compose env23867 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23867 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,263,16448,2340,1025,21841,4161,33,17,21763,269,64,2049,5392,17664,23588,1364,32,257,21793,16464,513]

theorem envBound23868 : H12AffineFastState.Bounded env23868 := by
  intro p hp
  have h : env23868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23867_23868 : H12AffineEnvironment.transform 12 268 env23867 = env23868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23867 == env23868) = true)

def env23869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169217,95496,8328,64,2185,163840,45525,283904,156696,412108,257,21793,46213,213967]

theorem envBound23869 : H12AffineFastState.Bounded env23869 := by
  intro p hp
  have h : env23869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23846_23869 : H12AffineEnvironment.transform 21 272513 env23846 = env23869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23846 == env23869) = true)

theorem identity23869 : scanCanonicalize (H12AffineFastState.compose env23869 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23869 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160132,272513,169217,21763,8328,64,2185,163840,45525,283904,156696,412108,257,21793,46213,156612]

theorem envBound23870 : H12AffineFastState.Bounded env23870 := by
  intro p hp
  have h : env23870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23869_23870 : H12AffineEnvironment.transform 15 8203 env23869 = env23870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23869 == env23870) = true)

def env23871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160012,272393,169217,21763,8192,64,2049,163840,45405,283904,156696,411972,257,21793,46093,156492]

theorem envBound23871 : H12AffineFastState.Bounded env23871 := by
  intro p hp
  have h : env23871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23870_23871 : H12AffineEnvironment.transform 6 8 env23870 = env23871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23870 == env23871) = true)

theorem identity23871 : scanCanonicalize (H12AffineFastState.compose env23871 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound23871 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env23872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8203,131072,262144,1025,29993,160012,272393,155689,21763,8192,64,2049,161064,17525,283904,156696,411972,257,21793,16677,156492]

theorem envBound23872 : H12AffineFastState.Bounded env23872 := by
  intro p hp
  have h : env23872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23871_23872 : H12AffineEnvironment.transform 14 29992 env23871 = env23872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env23871 == env23872) = true)

theorem identity23872 : scanCanonicalize (H12AffineFastState.compose env23872 (packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound23872 : packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env23873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8203,5221,262144,1025,29993,25961,272393,29772,21763,8192,64,2049,24909,17525,283904,28797,285985,257,21793,16677,30505]

theorem envBound23873 : H12AffineFastState.Bounded env23873 := by
  intro p hp
  have h : env23873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23872_23873 : H12AffineEnvironment.transform 16 5221 env23872 = env23873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env23872 == env23873) = true)

theorem identity23873 : scanCanonicalize (H12AffineFastState.compose env23873 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23873 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env23874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8232,8203,5221,262144,1025,8233,12393,272393,8524,3,8192,64,2049,13389,4469,262144,9597,264225,257,33,5157,8745]

theorem envBound23874 : H12AffineFastState.Bounded env23874 := by
  intro p hp
  have h : env23874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23873_23874 : H12AffineEnvironment.transform 13 5376 env23873 = env23874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23873 == env23874) = true)

theorem identity23874 : scanCanonicalize (H12AffineFastState.compose env23874 (packedSelected [2,6,16] rootPS)) = affineNative (2^(17+1) ^^^ 9292) := by decide +kernel

theorem selectedBound23874 : packedSelected [2,6,16] rootPS < 2^1333 := by decide +kernel

def env23875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8232,8203,5221,9292,1025,8233,12393,3141,8524,3,8192,64,2049,13389,4469,9292,9597,11373,257,33,5157,8745]

theorem envBound23875 : H12AffineFastState.Bounded env23875 := by
  intro p hp
  have h : env23875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23874_23875 : H12AffineEnvironment.transform 17 9292 env23874 = env23875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9292 env23874 == env23875) = true)

theorem identity23875 : scanCanonicalize (H12AffineFastState.compose env23875 (packedSelected [4,6,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23875 : packedSelected [4,6,9,11,18] rootPS < 2^1333 := by decide +kernel

def env23876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,372,343,5221,1296,1025,373,4405,3141,16,3,348,64,2049,5393,4469,1296,1057,3377,257,33,5157,885]

theorem envBound23876 : H12AffineFastState.Bounded env23876 := by
  intro p hp
  have h : env23876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23875_23876 : H12AffineEnvironment.transform 12 348 env23875 = env23876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23875 == env23876) = true)

theorem identity23876 : scanCanonicalize (H12AffineFastState.compose env23876 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound23876 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env23877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1376,4096,348,5376,372,343,5221,1296,1025,373,4405,293,16,3,348,64,1377,5393,4469,1296,1057,81,257,33,5157,885]

theorem envBound23877 : H12AffineFastState.Bounded env23877 := by
  intro p hp
  have h : env23877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23876_23877 : H12AffineEnvironment.transform 10 1376 env23876 = env23877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env23876 == env23877) = true)

theorem identity23877 : scanCanonicalize (H12AffineFastState.compose env23877 (packedSelected [0,1,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1882) := by decide +kernel

theorem selectedBound23877 : packedSelected [0,1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1376,1882,348,602,372,343,831,1296,1025,373,1647,293,16,3,348,64,1377,587,1583,1296,1057,81,257,33,895,885]

theorem envBound23878 : H12AffineFastState.Bounded env23878 := by
  intro p hp
  have h : env23878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23877_23878 : H12AffineEnvironment.transform 11 1882 env23877 = env23878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1882 env23877 == env23878) = true)

theorem identity23878 : scanCanonicalize (H12AffineFastState.compose env23878 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23878 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env23879 : List Nat := [2,4,8,16,32,64,8,5,512,1024,1125,1631,89,602,113,82,570,1045,1025,112,1647,32,16,3,89,64,1124,587,1583,1045,1057,81,4,33,634,624]

theorem envBound23879 : H12AffineFastState.Bounded env23879 := by
  intro p hp
  have h : env23879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23878_23879 : H12AffineEnvironment.transform 7 5 env23878 = env23879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23878 == env23879) = true)

theorem identity23879 : scanCanonicalize (H12AffineFastState.compose env23879 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23880 : List Nat := [2,4,8,16,32,48,8,5,512,1024,1045,1583,41,554,1,34,570,1045,1025,0,1567,32,16,3,41,48,1044,571,1583,1045,1057,33,4,33,522,512]

theorem envBound23880 : H12AffineFastState.Bounded env23880 := by
  intro p hp
  have h : env23880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23879_23880 : H12AffineEnvironment.transform 5 48 env23879 = env23880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23879 == env23880) = true)

theorem identity23880 : scanCanonicalize (H12AffineFastState.compose env23880 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound23880 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env23881 : List Nat := [2,4,8,16,32,48,8,5,34,1024,1045,1037,41,8,1,34,24,1045,1025,0,1085,32,16,3,41,48,1044,25,1037,1045,1057,33,4,33,40,34]

theorem envBound23881 : H12AffineFastState.Bounded env23881 := by
  intro p hp
  have h : env23881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23880_23881 : H12AffineEnvironment.transform 8 34 env23880 = env23881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env23880 == env23881) = true)

theorem identity23881 : scanCanonicalize (H12AffineFastState.compose env23881 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 29) := by decide +kernel

theorem selectedBound23881 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env23882 : List Nat := [2,4,8,16,32,48,8,5,34,29,8,16,41,8,1,34,24,8,28,0,32,32,16,3,41,48,9,25,16,8,60,33,4,33,40,34]

theorem envBound23882 : H12AffineFastState.Bounded env23882 := by
  intro p hp
  have h : env23882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23881_23882 : H12AffineEnvironment.transform 9 29 env23881 = env23882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 29 env23881 == env23882) = true)

theorem identity23882 : scanCanonicalize (H12AffineFastState.compose env23882 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound23882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23883 : List Nat := [2,4,8,16,15,31,8,5,13,29,8,16,6,8,1,13,24,8,28,0,15,15,16,3,6,31,9,25,16,8,19,14,4,14,7,13]

theorem envBound23883 : H12AffineFastState.Bounded env23883 := by
  intro p hp
  have h : env23883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23882_23883 : H12AffineEnvironment.transform 4 15 env23882 = env23883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env23882 == env23883) = true)

def env23884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160013,272392,169217,21763,8193,64,2048,163840,45404,283904,156696,411973,257,21793,46092,156493]

theorem envBound23884 : H12AffineFastState.Bounded env23884 := by
  intro p hp
  have h : env23884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23870_23884 : H12AffineEnvironment.transform 6 9 env23870 = env23884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23870 == env23884) = true)

theorem identity23884 : scanCanonicalize (H12AffineFastState.compose env23884 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound23884 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env23885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,157753,1025,32769,160013,147505,169217,21763,8193,64,2048,163840,45404,146745,156696,8572,257,21793,46092,156493]

theorem envBound23885 : H12AffineFastState.Bounded env23885 := by
  intro p hp
  have h : env23885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23884_23885 : H12AffineEnvironment.transform 17 157753 env23884 = env23885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env23884 == env23885) = true)

theorem identity23885 : scanCanonicalize (H12AffineFastState.compose env23885 (packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound23885 : packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57677,35188,1025,32769,36928,41340,29772,21763,8193,64,2048,24909,45404,56436,34133,8572,257,21793,46092,33280]

theorem envBound23886 : H12AffineFastState.Bounded env23886 := by
  intro p hp
  have h : env23886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23885_23886 : H12AffineEnvironment.transform 16 57677 env23885 = env23886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env23885 == env23886) = true)

theorem identity23886 : scanCanonicalize (H12AffineFastState.compose env23886 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound23886 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env23887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,13388,23669,1025,21760,17729,29821,29772,21763,8193,64,2048,24909,25693,2421,20564,8572,257,21793,24845,22273]

theorem envBound23887 : H12AffineFastState.Bounded env23887 := by
  intro p hp
  have h : env23887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23886_23887 : H12AffineEnvironment.transform 14 21761 env23886 = env23887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env23886 == env23887) = true)

theorem identity23887 : scanCanonicalize (H12AffineFastState.compose env23887 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23887 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23888 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,21620,8203,13388,23669,1025,21621,17460,29821,29772,21622,8193,64,2048,24632,25693,2048,20564,8201,116,21588,24696,22132]

theorem envBound23888 : H12AffineFastState.Bounded env23888 := by
  intro p hp
  have h : env23888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23887_23888 : H12AffineEnvironment.transform 7 117 env23887 = env23888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23887 == env23888) = true)

theorem identity23888 : scanCanonicalize (H12AffineFastState.compose env23888 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound23888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23889 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,1,8203,13388,2048,1025,0,4161,8200,8249,3,8193,64,2048,13389,12328,2048,1057,8201,116,33,13325,513]

theorem envBound23889 : H12AffineFastState.Bounded env23889 := by
  intro p hp
  have h : env23889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23888_23889 : H12AffineEnvironment.transform 13 5237 env23888 = env23889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env23888 == env23889) = true)

theorem identity23889 : scanCanonicalize (H12AffineFastState.compose env23889 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5196) := by decide +kernel

theorem selectedBound23889 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env23890 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,5196,5237,1,5191,0,2048,1025,0,4161,5188,5237,3,5197,64,2048,1,1124,2048,1057,5189,116,33,65,513]

theorem envBound23890 : H12AffineFastState.Bounded env23890 := by
  intro p hp
  have h : env23890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23889_23890 : H12AffineEnvironment.transform 12 5196 env23889 = env23890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5196 env23889 == env23890) = true)

theorem identity23890 : scanCanonicalize (H12AffineFastState.compose env23890 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23890 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env23891 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,5196,5237,1,5191,0,0,1025,0,4161,5188,5237,3,5197,64,0,1,1124,0,1057,5189,116,33,65,513]

theorem envBound23891 : H12AffineFastState.Bounded env23891 := by
  intro p hp
  have h : env23891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23890_23891 : H12AffineEnvironment.transform 10 0 env23890 = env23891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23890 == env23891) = true)

theorem identity23891 : scanCanonicalize (H12AffineFastState.compose env23891 (packedSelected [6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound23891 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env23892 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,1076,120,65,1,115,0,0,1025,0,1141,112,65,3,121,64,0,1,1124,0,1057,113,116,33,65,513]

theorem envBound23892 : H12AffineFastState.Bounded env23892 := by
  intro p hp
  have h : env23892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23891_23892 : H12AffineEnvironment.transform 11 1076 env23891 = env23892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env23891 == env23892) = true)

theorem identity23892 : scanCanonicalize (H12AffineFastState.compose env23892 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound23892 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env23893 : List Nat := [2,4,8,16,32,64,9,117,512,117,0,65,120,65,1,115,0,0,116,0,0,112,65,3,121,64,0,1,17,0,84,113,116,33,65,513]

theorem envBound23893 : H12AffineFastState.Bounded env23893 := by
  intro p hp
  have h : env23893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23892_23893 : H12AffineEnvironment.transform 9 117 env23892 = env23893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env23892 == env23893) = true)

def env23894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,8388608,8642569,8328,64,4464648,8393984,8529109,8830977,156696,12645453,257,21792,46212,213967]

theorem envBound23894 : H12AffineFastState.Bounded env23894 := by
  intro p hp
  have h : env23894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23776_23894 : H12AffineEnvironment.transform 20 160133 env23776 = env23894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160133 env23776 == env23894) = true)

def env23895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169216,95497,8328,64,4464648,163840,45525,283905,156696,4350285,257,21792,46212,213967]

theorem envBound23895 : H12AffineFastState.Bounded env23895 := by
  intro p hp
  have h : env23895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23894_23895 : H12AffineEnvironment.transform 22 169216 env23894 = env23895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env23894 == env23895) = true)

def env23896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169216,95497,8328,64,2184,163840,45525,283905,156696,412109,257,21792,46212,213967]

theorem envBound23896 : H12AffineFastState.Bounded env23896 := by
  intro p hp
  have h : env23896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23895_23896 : H12AffineEnvironment.transform 21 272512 env23895 = env23896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23895 == env23896) = true)

theorem identity23896 : scanCanonicalize (H12AffineFastState.compose env23896 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound23896 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160133,272512,156116,95497,8328,64,2184,160980,17665,283905,156696,412109,257,21792,16464,213967]

theorem envBound23897 : H12AffineFastState.Bounded env23897 := by
  intro p hp
  have h : env23897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23896_23897 : H12AffineEnvironment.transform 14 29908 env23896 = env23897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env23896 == env23897) = true)

def env23898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272392,155996,95497,8192,64,2048,160860,17665,283905,156696,411973,257,21792,16464,213831]

theorem envBound23898 : H12AffineFastState.Bounded env23898 := by
  intro p hp
  have h : env23898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23897_23898 : H12AffineEnvironment.transform 6 8 env23897 = env23898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23897 == env23898) = true)

theorem identity23898 : scanCanonicalize (H12AffineFastState.compose env23898 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound23898 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env23899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,23668,1025,29789,160013,29820,155996,95497,8192,64,2048,160860,17665,2421,156696,136497,257,21792,16464,213831]

theorem envBound23899 : H12AffineFastState.Bounded env23899 := by
  intro p hp
  have h : env23899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23898_23899 : H12AffineEnvironment.transform 17 23668 env23898 = env23899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env23898 == env23899) = true)

theorem identity23899 : scanCanonicalize (H12AffineFastState.compose env23899 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23899 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,131072,23668,1025,21760,151632,21793,147457,87124,349,64,2048,152833,17665,2421,148805,136497,257,21792,16464,213831]

theorem envBound23900 : H12AffineFastState.Bounded env23900 := by
  intro p hp
  have h : env23900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23899_23900 : H12AffineEnvironment.transform 12 349 env23899 = env23900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23899 == env23900) = true)

theorem identity23900 : scanCanonicalize (H12AffineFastState.compose env23900 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 81971) := by decide +kernel

theorem selectedBound23900 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,81971,23668,1025,21760,69731,21793,65586,87124,349,64,2048,70962,17665,2421,66934,87298,257,21792,16464,884]

theorem envBound23901 : H12AffineFastState.Bounded env23901 := by
  intro p hp
  have h : env23901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23900_23901 : H12AffineEnvironment.transform 16 81971 env23900 = env23901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 81971 env23900 == env23901) = true)

theorem identity23901 : scanCanonicalize (H12AffineFastState.compose env23901 (packedSelected [0,1,4,7,8,12,15,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23901 : packedSelected [0,1,4,7,8,12,15,19,22] rootPS < 2^1333 := by decide +kernel

def env23902 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21620,65536,81971,23668,1025,21621,69731,21588,65586,87124,40,64,2048,70727,17524,2048,66563,87159,116,21589,16464,513]

theorem envBound23902 : H12AffineFastState.Bounded env23902 := by
  intro p hp
  have h : env23902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23901_23902 : H12AffineEnvironment.transform 7 117 env23901 = env23902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23901 == env23902) = true)

theorem identity23902 : scanCanonicalize (H12AffineFastState.compose env23902 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound23902 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23903 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,65536,70727,2048,1025,1,69731,32,65586,65568,40,64,2048,70727,4096,2048,66563,65539,116,33,5156,513]

theorem envBound23903 : H12AffineFastState.Bounded env23903 := by
  intro p hp
  have h : env23903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23902_23903 : H12AffineEnvironment.transform 13 5236 env23902 = env23903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env23902 == env23903) = true)

theorem identity23903 : scanCanonicalize (H12AffineFastState.compose env23903 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 5127) := by decide +kernel

theorem selectedBound23903 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env23904 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,5127,64,2048,1025,1,1124,32,5173,5159,40,64,2048,64,4096,2048,4100,5124,116,33,5156,513]

theorem envBound23904 : H12AffineFastState.Bounded env23904 := by
  intro p hp
  have h : env23904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23903_23904 : H12AffineEnvironment.transform 15 5127 env23903 = env23904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5127 env23903 == env23904) = true)

theorem identity23904 : scanCanonicalize (H12AffineFastState.compose env23904 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23904 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env23905 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,40,5236,0,5127,64,0,1025,1,1124,32,5173,5159,40,64,0,64,4096,0,4100,5124,116,33,5156,513]

theorem envBound23905 : H12AffineFastState.Bounded env23905 := by
  intro p hp
  have h : env23905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23904_23905 : H12AffineEnvironment.transform 10 0 env23904 = env23905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23904 == env23905) = true)

theorem identity23905 : scanCanonicalize (H12AffineFastState.compose env23905 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound23905 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23906 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,64,40,1076,0,1095,64,0,1025,1,1124,32,1141,1127,40,64,0,64,64,0,68,1092,116,33,1124,513]

theorem envBound23906 : H12AffineFastState.Bounded env23906 := by
  intro p hp
  have h : env23906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23905_23906 : H12AffineEnvironment.transform 11 64 env23905 = env23906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env23905 == env23906) = true)

theorem identity23906 : scanCanonicalize (H12AffineFastState.compose env23906 (packedSelected [1,2,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23906 : packedSelected [1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env23907 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,16,40,1076,0,1047,16,0,1025,1,1076,32,1061,1079,40,16,0,16,16,0,20,1044,36,33,1076,513]

theorem envBound23907 : H12AffineFastState.Bounded env23907 := by
  intro p hp
  have h : env23907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23906_23907 : H12AffineEnvironment.transform 5 16 env23906 = env23907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23906 == env23907) = true)

theorem identity23907 : scanCanonicalize (H12AffineFastState.compose env23907 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23907 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env23908 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,40,0,0,35,16,0,53,1,0,32,17,3,40,16,0,16,16,0,20,32,36,33,0,513]

theorem envBound23908 : H12AffineFastState.Bounded env23908 := by
  intro p hp
  have h : env23908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23907_23908 : H12AffineEnvironment.transform 9 52 env23907 = env23908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23907 == env23908) = true)

theorem identity23908 : scanCanonicalize (H12AffineFastState.compose env23908 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23908 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23909 : List Nat := [2,4,8,16,16,16,8,21,512,4,0,16,24,0,0,19,16,0,5,1,0,16,17,3,24,16,0,16,16,0,20,16,20,17,0,513]

theorem envBound23909 : H12AffineFastState.Bounded env23909 := by
  intro p hp
  have h : env23909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23908_23909 : H12AffineEnvironment.transform 4 16 env23908 = env23909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23908 == env23909) = true)

def env23910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160012,272393,155997,95497,8193,64,2049,160861,17665,283905,156696,411972,257,21792,16464,213830]

theorem envBound23910 : H12AffineFastState.Bounded env23910 := by
  intro p hp
  have h : env23910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23897_23910 : H12AffineEnvironment.transform 6 9 env23897 = env23910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23897 == env23910) = true)

theorem identity23910 : scanCanonicalize (H12AffineFastState.compose env23910 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound23910 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env23911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67619,1025,29788,160012,73770,155997,95497,8193,64,2049,160861,17665,89378,156696,213351,257,21792,16464,213830]

theorem envBound23911 : H12AffineFastState.Bounded env23911 := by
  intro p hp
  have h : env23911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23910_23911 : H12AffineEnvironment.transform 17 67619 env23910 = env23911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env23910 == env23911) = true)

theorem identity23911 : scanCanonicalize (H12AffineFastState.compose env23911 (packedSelected [5,8,16,20,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound23911 : packedSelected [5,8,16,20,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82247,67619,1025,29788,77899,73770,73754,95497,8193,64,2049,79130,17665,89378,75103,32,257,21792,16464,513]

theorem envBound23912 : H12AffineFastState.Bounded env23912 := by
  intro p hp
  have h : env23912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23911_23912 : H12AffineEnvironment.transform 16 82247 env23911 = env23912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env23911 == env23912) = true)

theorem identity23912 : scanCanonicalize (H12AffineFastState.compose env23912 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23912 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,82247,67619,1025,21761,69910,65911,65863,87124,348,64,2049,70727,17665,89378,66562,32,257,21792,16464,513]

theorem envBound23913 : H12AffineFastState.Bounded env23913 := by
  intro p hp
  have h : env23913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23912_23913 : H12AffineEnvironment.transform 12 349 env23912 = env23913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23912 == env23913) = true)

theorem identity23913 : scanCanonicalize (H12AffineFastState.compose env23913 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound23913 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env23914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16401,2421,1025,21761,4160,33,17,21762,348,64,2049,5393,17665,23668,1364,32,257,21792,16464,513]

theorem envBound23914 : H12AffineFastState.Bounded env23914 := by
  intro p hp
  have h : env23914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23913_23914 : H12AffineEnvironment.transform 15 342 env23913 = env23914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env23913 == env23914) = true)

theorem identity23914 : scanCanonicalize (H12AffineFastState.compose env23914 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2421,1025,1,4160,33,17,2,348,64,2049,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound23915 : H12AffineFastState.Bounded env23915 := by
  intro p hp
  have h : env23915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23914_23915 : H12AffineEnvironment.transform 13 5376 env23914 = env23915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23914 == env23915) = true)

theorem identity23915 : scanCanonicalize (H12AffineFastState.compose env23915 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound23915 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,4096,349,5376,0,342,5393,302,1025,1,4160,33,17,2,348,64,90,5393,4097,303,1364,32,257,32,5456,513]

theorem envBound23916 : H12AffineFastState.Bounded env23916 := by
  intro p hp
  have h : env23916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23915_23916 : H12AffineEnvironment.transform 10 91 env23915 = env23916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env23915 == env23916) = true)

theorem identity23916 : scanCanonicalize (H12AffineFastState.compose env23916 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound23916 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,0,349,1280,0,342,1297,302,1025,1,64,33,17,2,348,64,90,1297,1,303,1364,32,257,32,1360,513]

theorem envBound23917 : H12AffineFastState.Bounded env23917 := by
  intro p hp
  have h : env23917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23916_23917 : H12AffineEnvironment.transform 11 0 env23916 = env23917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env23916 == env23917) = true)

theorem identity23917 : scanCanonicalize (H12AffineFastState.compose env23917 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23917 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23918 : List Nat := [2,4,8,16,32,64,9,84,512,1024,91,0,9,1108,0,2,1093,122,1025,1,64,33,17,2,8,64,90,1093,1,123,1024,32,85,32,1028,513]

theorem envBound23918 : H12AffineFastState.Bounded env23918 := by
  intro p hp
  have h : env23918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23917_23918 : H12AffineEnvironment.transform 7 84 env23917 = env23918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23917 == env23918) = true)

def env23919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169216,95497,8328,64,2185,163840,45525,283905,156696,412108,257,21792,46212,213967]

theorem envBound23919 : H12AffineFastState.Bounded env23919 := by
  intro p hp
  have h : env23919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23895_23919 : H12AffineEnvironment.transform 21 272513 env23895 = env23919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23895 == env23919) = true)

theorem identity23919 : scanCanonicalize (H12AffineFastState.compose env23919 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound23919 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,272513,62661,95497,8328,64,2185,57797,45525,283905,1501,272393,257,21792,46212,74250]

theorem envBound23920 : H12AffineFastState.Bounded env23920 := by
  intro p hp
  have h : env23920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23919_23920 : H12AffineEnvironment.transform 16 25029 env23919 = env23920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env23919 == env23920) = true)

theorem identity23920 : scanCanonicalize (H12AffineFastState.compose env23920 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23920 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,4160,272513,62661,21762,8328,64,2185,57797,45525,283905,1501,272393,257,21792,46212,513]

theorem envBound23921 : H12AffineFastState.Bounded env23921 := by
  intro p hp
  have h : env23921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23920_23921 : H12AffineEnvironment.transform 15 8203 env23920 = env23921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23920 == env23921) = true)

theorem identity23921 : scanCanonicalize (H12AffineFastState.compose env23921 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23921 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env23922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,5529,262144,1025,32769,4160,272513,32921,8542,8328,64,2185,38297,45525,270685,1501,272393,257,8572,46212,513]

theorem envBound23922 : H12AffineFastState.Bounded env23922 := by
  intro p hp
  have h : env23922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23921_23922 : H12AffineEnvironment.transform 13 13404 env23921 = env23922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23921 == env23922) = true)

theorem identity23922 : scanCanonicalize (H12AffineFastState.compose env23922 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound23922 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env23923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,5529,2421,1025,32769,4160,8692,32921,8542,8328,64,2185,38297,45525,10280,1501,8572,257,8572,46212,513]

theorem envBound23923 : H12AffineFastState.Bounded env23923 := by
  intro p hp
  have h : env23923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23922_23923 : H12AffineEnvironment.transform 17 2421 env23922 = env23923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env23922 == env23923) = true)

theorem identity23923 : scanCanonicalize (H12AffineFastState.compose env23923 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound23923 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env23924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,509,8203,5529,2421,1025,508,4160,8692,356,8542,8328,64,2185,5220,12328,10280,1501,8572,257,8572,13689,513]

theorem envBound23924 : H12AffineFastState.Bounded env23924 := by
  intro p hp
  have h : env23924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23923_23924 : H12AffineEnvironment.transform 14 509 env23923 = env23924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env23923 == env23924) = true)

theorem identity23924 : scanCanonicalize (H12AffineFastState.compose env23924 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23924 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env23925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,509,35,5529,2421,1025,508,4160,476,356,374,160,64,2185,5220,4096,2048,1501,340,257,340,5457,513]

theorem envBound23925 : H12AffineFastState.Bounded env23925 := by
  intro p hp
  have h : env23925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23924_23925 : H12AffineEnvironment.transform 12 40 env23924 = env23925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23924 == env23925) = true)

theorem identity23925 : scanCanonicalize (H12AffineFastState.compose env23925 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23925 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,372,35,5392,2421,1025,373,4160,341,356,374,41,64,2048,5220,4096,2048,1364,340,257,340,5457,513]

theorem envBound23926 : H12AffineFastState.Bounded env23926 := by
  intro p hp
  have h : env23926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23925_23926 : H12AffineEnvironment.transform 6 9 env23925 = env23926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23925 == env23926) = true)

theorem identity23926 : scanCanonicalize (H12AffineFastState.compose env23926 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound23926 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env23927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1077,40,65,372,35,293,2421,1025,373,1141,341,356,374,41,64,2048,81,1077,2048,1364,340,257,340,356,513]

theorem envBound23927 : H12AffineFastState.Bounded env23927 := by
  intro p hp
  have h : env23927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23926_23927 : H12AffineEnvironment.transform 11 1077 env23926 = env23927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env23926 == env23927) = true)

theorem identity23927 : scanCanonicalize (H12AffineFastState.compose env23927 (packedSelected [2,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23927 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env23928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1077,40,65,372,35,293,373,1025,373,1141,341,356,374,41,64,0,81,1077,0,1364,340,257,340,356,513]

theorem envBound23928 : H12AffineFastState.Bounded env23928 := by
  intro p hp
  have h : env23928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23927_23928 : H12AffineEnvironment.transform 10 0 env23927 = env23928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23927 == env23928) = true)

theorem identity23928 : scanCanonicalize (H12AffineFastState.compose env23928 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23928 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env23929 : List Nat := [2,4,8,16,32,64,9,37,512,1024,0,1077,40,65,81,35,0,80,1025,80,1141,112,65,83,41,64,0,81,1077,0,1137,113,36,113,65,513]

theorem envBound23929 : H12AffineFastState.Bounded env23929 := by
  intro p hp
  have h : env23929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23928_23929 : H12AffineEnvironment.transform 7 37 env23928 = env23929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23928 == env23929) = true)

theorem identity23929 : scanCanonicalize (H12AffineFastState.compose env23929 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound23929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23930 : List Nat := [2,4,8,16,32,64,9,37,512,36,0,17,40,65,81,35,0,80,37,80,81,112,65,83,41,64,0,81,17,0,85,113,36,113,65,513]

theorem envBound23930 : H12AffineFastState.Bounded env23930 := by
  intro p hp
  have h : env23930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23929_23930 : H12AffineEnvironment.transform 9 36 env23929 = env23930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env23929 == env23930) = true)

theorem identity23930 : scanCanonicalize (H12AffineFastState.compose env23930 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23930 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env23931 : List Nat := [2,4,8,16,32,16,9,37,512,36,0,17,40,17,1,35,0,0,37,0,1,32,17,3,41,16,0,1,17,0,5,33,36,33,17,513]

theorem envBound23931 : H12AffineFastState.Bounded env23931 := by
  intro p hp
  have h : env23931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23930_23931 : H12AffineEnvironment.transform 5 16 env23930 = env23931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23930 == env23931) = true)

theorem identity23931 : scanCanonicalize (H12AffineFastState.compose env23931 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23932 : List Nat := [2,4,8,10,32,10,9,37,512,36,0,11,40,11,1,35,0,0,37,0,1,32,11,3,41,10,0,1,11,0,5,33,36,33,11,513]

theorem envBound23932 : H12AffineFastState.Bounded env23932 := by
  intro p hp
  have h : env23932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23931_23932 : H12AffineEnvironment.transform 3 10 env23931 = env23932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23931 == env23932) = true)

theorem identity23932 : scanCanonicalize (H12AffineFastState.compose env23932 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound23932 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23933 : List Nat := [2,4,8,10,10,10,9,15,512,14,0,11,2,11,1,9,0,0,15,0,1,10,11,3,3,10,0,1,11,0,5,11,14,11,11,513]

theorem envBound23933 : H12AffineFastState.Bounded env23933 := by
  intro p hp
  have h : env23933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23932_23933 : H12AffineEnvironment.transform 4 10 env23932 = env23933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env23932 == env23933) = true)

theorem identity23933 : scanCanonicalize (H12AffineFastState.compose env23933 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound23933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23934 : List Nat := [2,4,8,10,10,10,9,15,5,14,0,11,2,11,1,9,0,0,15,0,1,10,11,3,3,10,0,1,11,0,5,11,14,11,11,4]

theorem envBound23934 : H12AffineFastState.Bounded env23934 := by
  intro p hp
  have h : env23934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23933_23934 : H12AffineEnvironment.transform 8 5 env23933 = env23934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env23933 == env23934) = true)

def env23935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169217,95496,8328,64,4464648,163841,45524,283904,156696,4350284,257,21792,46212,213967]

theorem envBound23935 : H12AffineFastState.Bounded env23935 := by
  intro p hp
  have h : env23935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23894_23935 : H12AffineEnvironment.transform 22 169217 env23894 = env23935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env23894 == env23935) = true)

def env23936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169217,95496,8328,64,2184,163841,45524,283904,156696,412108,257,21792,46212,213967]

theorem envBound23936 : H12AffineFastState.Bounded env23936 := by
  intro p hp
  have h : env23936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23935_23936 : H12AffineEnvironment.transform 21 272512 env23935 = env23936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23935 == env23936) = true)

def env23937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272392,169217,95496,8192,64,2048,163841,45404,283904,156696,411972,257,21792,46092,213831]

theorem envBound23937 : H12AffineFastState.Bounded env23937 := by
  intro p hp
  have h : env23937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23936_23937 : H12AffineEnvironment.transform 6 8 env23936 = env23937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23936 == env23937) = true)

def env23938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272392,17,95496,8192,64,2048,5393,45404,283904,61704,318548,257,21792,46092,120407]

theorem envBound23938 : H12AffineFastState.Bounded env23938 := by
  intro p hp
  have h : env23938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23937_23938 : H12AffineEnvironment.transform 16 38160 env23937 = env23938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23937 == env23938) = true)

theorem identity23938 : scanCanonicalize (H12AffineFastState.compose env23938 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound23938 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89378,1025,32769,58397,95530,17,95496,8192,64,2048,5393,45404,67618,61704,98678,257,21792,46092,120407]

theorem envBound23939 : H12AffineFastState.Bounded env23939 := by
  intro p hp
  have h : env23939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23938_23939 : H12AffineEnvironment.transform 17 89378 env23938 = env23939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env23938 == env23939) = true)

theorem identity23939 : scanCanonicalize (H12AffineFastState.compose env23939 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 62511) := by decide +kernel

theorem selectedBound23939 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env23940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62511,38160,43277,1025,32769,58397,33029,17,33063,8192,64,2048,5393,45404,64525,61704,30041,257,21792,46092,8824]

theorem envBound23940 : H12AffineFastState.Bounded env23940 := by
  intro p hp
  have h : env23940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23939_23940 : H12AffineEnvironment.transform 15 62511 env23939 = env23940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62511 env23939 == env23940) = true)

theorem identity23940 : scanCanonicalize (H12AffineFastState.compose env23940 (packedSelected [1,2,3,5,6,8,9,10,11,14,16,18,20,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound23940 : packedSelected [1,2,3,5,6,8,9,10,11,14,16,18,20,22,26] rootPS < 2^1333 := by decide +kernel

def env23941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,41342,38160,43277,1025,32769,45388,33029,17,33063,8192,64,2048,5393,45404,43356,42073,8200,257,113,46092,8824]

theorem envBound23941 : H12AffineFastState.Bounded env23941 := by
  intro p hp
  have h : env23941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23940_23941 : H12AffineEnvironment.transform 13 5457 env23940 = env23941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env23940 == env23941) = true)

theorem identity23941 : scanCanonicalize (H12AffineFastState.compose env23941 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23941 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23942 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,32768,40970,37988,43129,1025,32769,45112,32881,17,32851,8192,64,2048,5221,45096,43048,42073,8200,117,113,46092,8824]

theorem envBound23942 : H12AffineFastState.Bounded env23942 := by
  intro p hp
  have h : env23942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23941_23942 : H12AffineEnvironment.transform 7 116 env23941 = env23942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23941 == env23942) = true)

theorem identity23942 : scanCanonicalize (H12AffineFastState.compose env23942 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23942 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23943 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5157,32768,32883,37988,34816,1025,32769,36929,32881,17,32851,121,64,2048,5221,36945,34897,33824,113,117,113,38005,513]

theorem envBound23943 : H12AffineFastState.Bounded env23943 := by
  intro p hp
  have h : env23943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23942_23943 : H12AffineEnvironment.transform 12 121 env23942 = env23943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23942 == env23943) = true)

theorem identity23943 : scanCanonicalize (H12AffineFastState.compose env23943 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 7205) := by decide +kernel

theorem selectedBound23943 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23944 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5157,7205,7254,2113,5157,1025,7204,3172,7252,17,7286,121,64,2048,5221,3188,5236,6149,113,117,113,2128,513]

theorem envBound23944 : H12AffineFastState.Bounded env23944 := by
  intro p hp
  have h : env23944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23943_23944 : H12AffineEnvironment.transform 14 7205 env23943 = env23944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7205 env23943 == env23944) = true)

theorem identity23944 : scanCanonicalize (H12AffineFastState.compose env23944 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23944 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23945 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,7205,7174,2065,5157,1025,7204,3124,7172,17,7206,41,16,2048,5173,3108,5156,6149,33,37,33,2048,513]

theorem envBound23945 : H12AffineFastState.Bounded env23945 := by
  intro p hp
  have h : env23945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23944_23945 : H12AffineEnvironment.transform 5 16 env23944 = env23945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23944 == env23945) = true)

theorem identity23945 : scanCanonicalize (H12AffineFastState.compose env23945 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound23945 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env23946 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,4096,41,4097,6145,6178,2065,4097,37,6144,2064,6176,17,6146,41,16,2048,4113,2048,4096,6149,33,37,33,2048,513]

theorem envBound23946 : H12AffineFastState.Bounded env23946 := by
  intro p hp
  have h : env23946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23945_23946 : H12AffineEnvironment.transform 9 36 env23945 = env23946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env23945 == env23946) = true)

theorem identity23946 : scanCanonicalize (H12AffineFastState.compose env23946 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound23946 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env23947 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,2561,41,2560,512,547,2065,2560,37,513,2064,545,17,515,41,16,2048,2576,2048,2561,516,33,37,33,2048,513]

theorem envBound23947 : H12AffineFastState.Bounded env23947 := by
  intro p hp
  have h : env23947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23946_23947 : H12AffineEnvironment.transform 11 2561 env23946 = env23947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env23946 == env23947) = true)

theorem identity23947 : scanCanonicalize (H12AffineFastState.compose env23947 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound23947 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23948 : List Nat := [2,4,8,16,32,16,8,36,512,36,16,529,41,528,512,547,1,528,37,513,0,545,17,515,41,16,16,512,16,529,516,33,37,33,16,513]

theorem envBound23948 : H12AffineFastState.Bounded env23948 := by
  intro p hp
  have h : env23948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23947_23948 : H12AffineEnvironment.transform 10 16 env23947 = env23948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env23947 == env23948) = true)

theorem identity23948 : scanCanonicalize (H12AffineFastState.compose env23948 (packedSelected [1,3,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23948 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env23949 : List Nat := [2,4,8,1,32,1,8,36,512,36,1,512,41,513,512,547,1,513,37,513,0,545,0,515,41,1,1,512,1,512,516,33,37,33,1,513]

theorem envBound23949 : H12AffineFastState.Bounded env23949 := by
  intro p hp
  have h : env23949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23948_23949 : H12AffineEnvironment.transform 3 1 env23948 = env23949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23948 == env23949) = true)

theorem identity23949 : scanCanonicalize (H12AffineFastState.compose env23949 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23949 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23950 : List Nat := [2,4,8,1,32,1,8,36,1,36,1,1,41,0,1,34,1,0,37,0,0,32,0,2,41,1,1,1,1,1,5,33,37,33,1,0]

theorem envBound23950 : H12AffineFastState.Bounded env23950 := by
  intro p hp
  have h : env23950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23949_23950 : H12AffineEnvironment.transform 8 1 env23949 = env23950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23949 == env23950) = true)

theorem identity23950 : scanCanonicalize (H12AffineFastState.compose env23950 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23951 : List Nat := [2,4,8,1,0,1,8,4,1,4,1,1,9,0,1,2,1,0,5,0,0,0,0,2,9,1,1,1,1,1,5,1,5,1,1,0]

theorem envBound23951 : H12AffineFastState.Bounded env23951 := by
  intro p hp
  have h : env23951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23950_23951 : H12AffineEnvironment.transform 4 0 env23950 = env23951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23950 == env23951) = true)

def env23952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272392,16,95496,8192,64,2048,5392,45404,283904,61705,318549,257,21792,46092,120406]

theorem envBound23952 : H12AffineFastState.Bounded env23952 := by
  intro p hp
  have h : env23952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23937_23952 : H12AffineEnvironment.transform 16 38161 env23937 = env23952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23937 == env23952) = true)

theorem identity23952 : scanCanonicalize (H12AffineFastState.compose env23952 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound23952 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,38161,262144,1025,32769,58396,272392,16,2,8192,64,2048,5392,45404,283904,61705,318549,257,21792,46092,41820]

theorem envBound23953 : H12AffineFastState.Bounded env23953 := by
  intro p hp
  have h : env23953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23952_23953 : H12AffineEnvironment.transform 15 29962 env23952 = env23953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env23952 == env23953) = true)

theorem identity23953 : scanCanonicalize (H12AffineFastState.compose env23953 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23953 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env23954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21591,38161,262144,1025,32769,50497,264533,16,2,349,64,2048,5392,36865,283904,53332,318549,257,21792,38225,33281]

theorem envBound23954 : H12AffineFastState.Bounded env23954 := by
  intro p hp
  have h : env23954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23953_23954 : H12AffineEnvironment.transform 12 349 env23953 = env23954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23953 == env23954) = true)

theorem identity23954 : scanCanonicalize (H12AffineFastState.compose env23954 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound23954 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env23955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21591,38161,56437,1025,32769,50497,54560,16,2,349,64,2048,5392,36865,35189,53332,32,257,21792,38225,33281]

theorem envBound23955 : H12AffineFastState.Bounded env23955 := by
  intro p hp
  have h : env23955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23954_23955 : H12AffineEnvironment.transform 17 56437 env23954 = env23955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env23954 == env23955) = true)

theorem identity23955 : scanCanonicalize (H12AffineFastState.compose env23955 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23955 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21591,5393,23669,1025,1,17729,21792,16,2,349,64,2048,5392,4097,2421,20564,32,257,21792,5457,513]

theorem envBound23956 : H12AffineFastState.Bounded env23956 := by
  intro p hp
  have h : env23956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23955_23956 : H12AffineEnvironment.transform 14 0 env23955 = env23956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23955 == env23956) = true)

theorem identity23956 : scanCanonicalize (H12AffineFastState.compose env23956 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23956 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,0,1095,5393,3173,1025,1,5457,1328,16,2,349,64,2048,5392,4097,2421,68,32,257,1328,5457,513]

theorem envBound23957 : H12AffineFastState.Bounded env23957 := by
  intro p hp
  have h : env23957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23956_23957 : H12AffineEnvironment.transform 13 4112 env23956 = env23957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env23956 == env23957) = true)

theorem identity23957 : scanCanonicalize (H12AffineFastState.compose env23957 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23957 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23958 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4112,0,342,4096,2420,272,1,4160,33,16,2,349,64,2048,4097,4097,2421,68,32,257,33,4160,513]

theorem envBound23958 : H12AffineFastState.Bounded env23958 := by
  intro p hp
  have h : env23958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23957_23958 : H12AffineEnvironment.transform 9 273 env23957 = env23958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23957 == env23958) = true)

theorem identity23958 : scanCanonicalize (H12AffineFastState.compose env23958 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound23958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23959 : List Nat := [2,4,8,16,32,32,8,256,512,273,2048,4096,317,4112,0,310,4096,2324,272,1,4128,33,16,2,317,32,2048,4097,4097,2325,36,32,257,33,4128,513]

theorem envBound23959 : H12AffineFastState.Bounded env23959 := by
  intro p hp
  have h : env23959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23958_23959 : H12AffineEnvironment.transform 5 32 env23958 = env23959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env23958 == env23959) = true)

theorem identity23959 : scanCanonicalize (H12AffineFastState.compose env23959 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound23959 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23960 : List Nat := [2,4,8,16,32,32,8,256,512,273,2048,772,317,788,0,310,772,2324,272,1,804,33,16,2,317,32,2048,773,773,2325,36,32,257,33,804,513]

theorem envBound23960 : H12AffineFastState.Bounded env23960 := by
  intro p hp
  have h : env23960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23959_23960 : H12AffineEnvironment.transform 11 772 env23959 = env23960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env23959 == env23960) = true)

theorem identity23960 : scanCanonicalize (H12AffineFastState.compose env23960 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23960 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23961 : List Nat := [2,4,8,16,16,16,8,256,512,273,2048,772,269,788,0,262,772,2324,272,1,788,17,16,2,269,16,2048,773,773,2325,20,16,257,17,788,513]

theorem envBound23961 : H12AffineFastState.Bounded env23961 := by
  intro p hp
  have h : env23961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23960_23961 : H12AffineEnvironment.transform 4 16 env23960 = env23961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23960 == env23961) = true)

theorem identity23961 : scanCanonicalize (H12AffineFastState.compose env23961 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound23961 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23962 : List Nat := [2,4,8,16,16,16,8,256,512,273,788,772,269,788,0,262,772,512,272,1,788,17,16,2,269,16,788,773,773,513,20,16,257,17,788,513]

theorem envBound23962 : H12AffineFastState.Bounded env23962 := by
  intro p hp
  have h : env23962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23961_23962 : H12AffineEnvironment.transform 10 788 env23961 = env23962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env23961 == env23962) = true)

theorem identity23962 : scanCanonicalize (H12AffineFastState.compose env23962 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound23962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23963 : List Nat := [2,4,8,16,16,16,8,256,261,273,17,1,269,17,0,262,1,261,272,1,17,17,16,2,269,16,17,0,0,260,20,16,257,17,17,260]

theorem envBound23963 : H12AffineFastState.Bounded env23963 := by
  intro p hp
  have h : env23963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23962_23963 : H12AffineEnvironment.transform 8 261 env23962 = env23963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env23962 == env23963) = true)

theorem identity23963 : scanCanonicalize (H12AffineFastState.compose env23963 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23963 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23964 : List Nat := [2,4,8,16,16,16,8,4,1,21,17,1,9,17,0,2,1,1,20,1,17,17,16,2,9,16,17,0,0,0,20,16,5,17,17,0]

theorem envBound23964 : H12AffineFastState.Bounded env23964 := by
  intro p hp
  have h : env23964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23963_23964 : H12AffineEnvironment.transform 7 4 env23963 = env23964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23963 == env23964) = true)

theorem identity23964 : scanCanonicalize (H12AffineFastState.compose env23964 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound23964 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23965 : List Nat := [2,4,8,11,11,11,8,4,1,14,10,1,9,10,0,2,1,1,15,1,10,10,11,2,9,11,10,0,0,0,15,11,5,10,10,0]

theorem envBound23965 : H12AffineFastState.Bounded env23965 := by
  intro p hp
  have h : env23965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23964_23965 : H12AffineEnvironment.transform 3 11 env23964 = env23965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env23964 == env23965) = true)

def env23966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169217,95496,8193,64,2049,163841,45405,283904,156696,411973,257,21792,46093,213830]

theorem envBound23966 : H12AffineFastState.Bounded env23966 := by
  intro p hp
  have h : env23966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23936_23966 : H12AffineEnvironment.transform 6 9 env23936 = env23966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23936 == env23966) = true)

def env23967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95496,8193,64,2049,5393,45405,283904,61704,318549,257,21792,46093,120406]

theorem envBound23967 : H12AffineFastState.Bounded env23967 := by
  intro p hp
  have h : env23967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23966_23967 : H12AffineEnvironment.transform 16 38160 env23966 = env23967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23966 == env23967) = true)

theorem identity23967 : scanCanonicalize (H12AffineFastState.compose env23967 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound23967 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1025,32769,58396,119926,17,95496,8193,64,2049,5393,45405,108927,61704,73770,257,21792,46093,120406]

theorem envBound23968 : H12AffineFastState.Bounded env23968 := by
  intro p hp
  have h : env23968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23967_23968 : H12AffineEnvironment.transform 17 130175 env23967 = env23968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env23967 == env23968) = true)

theorem identity23968 : scanCanonicalize (H12AffineFastState.compose env23968 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound23968 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env23969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21510,38160,43129,1025,32769,58396,32880,17,8462,8193,64,2049,5393,45405,64889,61704,29740,257,21792,46093,33360]

theorem envBound23969 : H12AffineFastState.Bounded env23969 := by
  intro p hp
  have h : env23969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23968_23969 : H12AffineEnvironment.transform 15 21510 env23968 = env23969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env23968 == env23969) = true)

theorem identity23969 : scanCanonicalize (H12AffineFastState.compose env23969 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23969 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env23970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,342,38160,43129,1025,32769,45388,32880,17,8462,8193,64,2049,5393,45405,43049,42072,8572,257,112,46093,33360]

theorem envBound23970 : H12AffineFastState.Bounded env23970 := by
  intro p hp
  have h : env23970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23969_23970 : H12AffineEnvironment.transform 13 5456 env23969 = env23970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23969 == env23970) = true)

theorem identity23970 : scanCanonicalize (H12AffineFastState.compose env23970 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23970 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env23971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,342,38160,35109,1025,32769,36880,32880,17,82,349,64,2049,5393,36865,35189,34052,32,257,112,38225,33360]

theorem envBound23971 : H12AffineFastState.Bounded env23971 := by
  intro p hp
  have h : env23971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23970_23971 : H12AffineEnvironment.transform 12 348 env23970 = env23971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23970 == env23971) = true)

theorem identity23971 : scanCanonicalize (H12AffineFastState.compose env23971 (packedSelected [0,1,2,4,5,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 8017) := by decide +kernel

theorem selectedBound23971 : packedSelected [0,1,2,4,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env23972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,8017,342,2625,5748,1025,8016,3905,7969,17,82,349,64,2049,5393,3920,5668,6741,32,257,112,2560,7425]

theorem envBound23972 : H12AffineFastState.Bounded env23972 := by
  intro p hp
  have h : env23972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23971_23972 : H12AffineEnvironment.transform 14 8017 env23971 = env23972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8017 env23971 == env23972) = true)

theorem identity23972 : scanCanonicalize (H12AffineFastState.compose env23972 (packedSelected [4,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound23972 : packedSelected [4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env23973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1076,348,356,2917,342,2625,576,1025,2916,3905,2837,17,82,349,64,2049,293,3920,528,3681,32,257,112,2560,2357]

theorem envBound23973 : H12AffineFastState.Bounded env23973 := by
  intro p hp
  have h : env23973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23972_23973 : H12AffineEnvironment.transform 11 1076 env23972 = env23973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env23972 == env23973) = true)

theorem identity23973 : scanCanonicalize (H12AffineFastState.compose env23973 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 868) := by decide +kernel

theorem selectedBound23973 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env23974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,868,1076,348,356,1,342,293,576,1025,0,1061,113,17,82,349,64,869,293,1076,528,1285,32,257,112,356,593]

theorem envBound23974 : H12AffineFastState.Bounded env23974 := by
  intro p hp
  have h : env23974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23973_23974 : H12AffineEnvironment.transform 10 868 env23973 = env23974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 868 env23973 == env23974) = true)

theorem identity23974 : scanCanonicalize (H12AffineFastState.compose env23974 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound23974 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env23975 : List Nat := [2,4,8,16,32,64,9,256,512,785,868,805,348,356,1,342,293,576,784,0,820,113,17,82,349,64,869,293,805,528,532,32,257,112,356,593]

theorem envBound23975 : H12AffineFastState.Bounded env23975 := by
  intro p hp
  have h : env23975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23974_23975 : H12AffineEnvironment.transform 9 785 env23974 = env23975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env23974 == env23975) = true)

theorem identity23975 : scanCanonicalize (H12AffineFastState.compose env23975 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23975 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env23976 : List Nat := [2,4,8,16,32,64,9,116,512,613,528,593,40,16,1,34,81,576,612,0,576,113,17,82,41,64,529,81,593,528,532,32,117,112,16,593]

theorem envBound23976 : H12AffineFastState.Bounded env23976 := by
  intro p hp
  have h : env23976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23975_23976 : H12AffineEnvironment.transform 7 116 env23975 = env23976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23975 == env23976) = true)

theorem identity23976 : scanCanonicalize (H12AffineFastState.compose env23976 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23976 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env23977 : List Nat := [2,4,8,16,32,17,9,37,512,564,528,512,40,16,1,34,0,529,565,0,529,32,17,3,41,17,529,0,512,528,532,32,36,33,16,512]

theorem envBound23977 : H12AffineFastState.Bounded env23977 := by
  intro p hp
  have h : env23977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23976_23977 : H12AffineEnvironment.transform 5 17 env23976 = env23977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23976 == env23977) = true)

theorem identity23977 : scanCanonicalize (H12AffineFastState.compose env23977 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23978 : List Nat := [2,4,8,16,0,17,9,5,512,532,528,512,8,16,1,2,0,529,533,0,529,0,17,3,9,17,529,0,512,528,532,0,4,1,16,512]

theorem envBound23978 : H12AffineFastState.Bounded env23978 := by
  intro p hp
  have h : env23978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23977_23978 : H12AffineEnvironment.transform 4 0 env23977 = env23978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23977 == env23978) = true)

theorem identity23978 : scanCanonicalize (H12AffineFastState.compose env23978 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23978 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23979 : List Nat := [2,4,8,16,0,17,9,5,0,20,16,0,8,16,1,2,0,17,21,0,17,0,17,3,9,17,17,0,0,16,20,0,4,1,16,0]

theorem envBound23979 : H12AffineFastState.Bounded env23979 := by
  intro p hp
  have h : env23979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23978_23979 : H12AffineEnvironment.transform 8 0 env23978 = env23979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23978 == env23979) = true)

theorem identity23979 : scanCanonicalize (H12AffineFastState.compose env23979 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23979 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23980 : List Nat := [2,0,8,16,0,17,9,1,0,16,16,0,8,16,1,2,0,17,17,0,17,0,17,3,9,17,17,0,0,16,16,0,0,1,16,0]

theorem envBound23980 : H12AffineFastState.Bounded env23980 := by
  intro p hp
  have h : env23980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23979_23980 : H12AffineEnvironment.transform 1 0 env23979 = env23980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23979 == env23980) = true)

def env23981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,16,95496,8193,64,2049,5392,45405,283904,61705,318548,257,21792,46093,120407]

theorem envBound23981 : H12AffineFastState.Bounded env23981 := by
  intro p hp
  have h : env23981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23966_23981 : H12AffineEnvironment.transform 16 38161 env23966 = env23981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23966 == env23981) = true)

theorem identity23981 : scanCanonicalize (H12AffineFastState.compose env23981 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,58397,272393,16,41310,8193,64,2049,5392,45405,283904,61705,318548,257,21792,46093,513]

theorem envBound23982 : H12AffineFastState.Bounded env23982 := by
  intro p hp
  have h : env23982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23981_23982 : H12AffineEnvironment.transform 15 54358 env23981 = env23982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23981 == env23982) = true)

theorem identity23982 : scanCanonicalize (H12AffineFastState.compose env23982 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23982 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,38161,262144,1025,32769,50497,264533,16,32770,349,64,2049,5392,36865,283904,53333,318548,257,21792,38225,513]

theorem envBound23983 : H12AffineFastState.Bounded env23983 := by
  intro p hp
  have h : env23983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23982_23983 : H12AffineEnvironment.transform 12 348 env23982 = env23983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23982 == env23983) = true)

theorem identity23983 : scanCanonicalize (H12AffineFastState.compose env23983 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23983 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33111,38161,262144,1025,32769,36928,264533,16,32770,349,64,2049,5392,36865,262145,34132,297301,257,33,38225,513]

theorem envBound23984 : H12AffineFastState.Bounded env23984 := by
  intro p hp
  have h : env23984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23983_23984 : H12AffineEnvironment.transform 13 5377 env23983 = env23984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23983 == env23984) = true)

theorem identity23984 : scanCanonicalize (H12AffineFastState.compose env23984 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound23984 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33111,38161,2421,1025,32769,36928,32,16,32770,349,64,2049,5392,36865,2420,34132,32800,257,33,38225,513]

theorem envBound23985 : H12AffineFastState.Bounded env23985 := by
  intro p hp
  have h : env23985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23984_23985 : H12AffineEnvironment.transform 17 2421 env23984 = env23985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env23984 == env23985) = true)

theorem identity23985 : scanCanonicalize (H12AffineFastState.compose env23985 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23985 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23986 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,32768,33111,36865,2421,273,32769,36928,32,16,32770,349,64,2049,4096,36865,2420,32836,32800,257,33,36929,513]

theorem envBound23986 : H12AffineFastState.Bounded env23986 := by
  intro p hp
  have h : env23986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23985_23986 : H12AffineEnvironment.transform 9 272 env23985 = env23986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23985 == env23986) = true)

theorem identity23986 : scanCanonicalize (H12AffineFastState.compose env23986 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2128) := by decide +kernel

theorem selectedBound23986 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23987 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,2128,2311,6225,2421,273,2129,6160,32,16,2130,349,64,2049,4096,6225,2420,2068,2160,257,33,6161,513]

theorem envBound23987 : H12AffineFastState.Bounded env23987 := by
  intro p hp
  have h : env23987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23986_23987 : H12AffineEnvironment.transform 14 2128 env23986 = env23987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2128 env23986 == env23987) = true)

theorem identity23987 : scanCanonicalize (H12AffineFastState.compose env23987 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound23987 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env23988 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2112,348,2129,2128,2311,17,2421,273,2129,80,32,16,2130,349,64,2049,2112,17,2420,2068,2160,257,33,81,513]

theorem envBound23988 : H12AffineFastState.Bounded env23988 := by
  intro p hp
  have h : env23988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23987_23988 : H12AffineEnvironment.transform 11 2112 env23987 = env23988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env23987 == env23988) = true)

theorem identity23988 : scanCanonicalize (H12AffineFastState.compose env23988 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound23988 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23989 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,357,348,372,373,34,17,80,273,372,80,32,16,375,349,64,292,357,17,81,305,341,257,33,81,513]

theorem envBound23989 : H12AffineFastState.Bounded env23989 := by
  intro p hp
  have h : env23989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23988_23989 : H12AffineEnvironment.transform 10 293 env23988 = env23989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env23988 == env23989) = true)

theorem identity23989 : scanCanonicalize (H12AffineFastState.compose env23989 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound23989 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23990 : List Nat := [2,4,8,16,32,64,9,256,80,272,293,357,348,372,373,34,17,80,273,372,80,32,16,375,349,64,292,357,17,81,305,341,257,33,81,81]

theorem envBound23990 : H12AffineFastState.Bounded env23990 := by
  intro p hp
  have h : env23990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23989_23990 : H12AffineEnvironment.transform 8 80 env23989 = env23990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env23989 == env23990) = true)

theorem identity23990 : scanCanonicalize (H12AffineFastState.compose env23990 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23990 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env23991 : List Nat := [2,4,8,16,32,64,9,37,80,53,0,64,121,81,80,34,17,80,52,81,80,32,16,82,120,64,1,64,17,81,20,112,36,33,81,81]

theorem envBound23991 : H12AffineFastState.Bounded env23991 := by
  intro p hp
  have h : env23991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23990_23991 : H12AffineEnvironment.transform 7 37 env23990 = env23991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23990 == env23991) = true)

theorem identity23991 : scanCanonicalize (H12AffineFastState.compose env23991 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23992 : List Nat := [2,4,8,16,32,17,9,37,1,53,0,17,40,0,1,34,17,1,52,0,1,32,16,3,41,17,1,17,17,0,20,33,36,33,0,0]

theorem envBound23992 : H12AffineFastState.Bounded env23992 := by
  intro p hp
  have h : env23992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23991_23992 : H12AffineEnvironment.transform 5 17 env23991 = env23992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23991 == env23992) = true)

theorem identity23992 : scanCanonicalize (H12AffineFastState.compose env23992 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound23992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23993 : List Nat := [2,4,8,16,26,17,9,31,1,15,0,17,18,0,1,24,17,1,14,0,1,26,16,3,19,17,1,17,17,0,20,27,30,27,0,0]

theorem envBound23993 : H12AffineFastState.Bounded env23993 := by
  intro p hp
  have h : env23993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23992_23993 : H12AffineEnvironment.transform 4 26 env23992 = env23993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env23992 == env23993) = true)

def env23994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169217,95496,8328,64,2185,163841,45524,283904,156696,412109,257,21792,46212,213967]

theorem envBound23994 : H12AffineFastState.Bounded env23994 := by
  intro p hp
  have h : env23994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23935_23994 : H12AffineEnvironment.transform 21 272513 env23935 = env23994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23935 == env23994) = true)

theorem identity23994 : scanCanonicalize (H12AffineFastState.compose env23994 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound23994 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58517,272513,17,95496,8328,64,2185,5393,45524,283904,61704,318685,257,21792,46212,120543]

theorem envBound23995 : H12AffineFastState.Bounded env23995 := by
  intro p hp
  have h : env23995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23994_23995 : H12AffineEnvironment.transform 16 38160 env23994 = env23995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23994 == env23995) = true)

def env23996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272393,17,95496,8192,64,2049,5393,45404,283904,61704,318549,257,21792,46092,120407]

theorem envBound23996 : H12AffineFastState.Bounded env23996 := by
  intro p hp
  have h : env23996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23995_23996 : H12AffineEnvironment.transform 6 8 env23995 = env23996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23995 == env23996) = true)

theorem identity23996 : scanCanonicalize (H12AffineFastState.compose env23996 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound23996 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89378,1025,32769,58397,95531,17,95496,8192,64,2049,5393,45404,67618,61704,98679,257,21792,46092,120407]

theorem envBound23997 : H12AffineFastState.Bounded env23997 := by
  intro p hp
  have h : env23997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23996_23997 : H12AffineEnvironment.transform 17 89378 env23996 = env23997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env23996 == env23997) = true)

theorem identity23997 : scanCanonicalize (H12AffineFastState.compose env23997 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound23997 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env23998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,65536,5221,89378,1025,372,25960,95531,17,95496,8192,64,2049,5393,12329,67618,28797,65538,257,21792,13689,87842]

theorem envBound23998 : H12AffineFastState.Bounded env23998 := by
  intro p hp
  have h : env23998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23997_23998 : H12AffineEnvironment.transform 14 373 env23997 = env23998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env23997 == env23998) = true)

theorem identity23998 : scanCanonicalize (H12AffineFastState.compose env23998 (packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound23998 : packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env23999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,343,5221,23669,1025,372,25960,29820,17,29791,8192,64,2049,5393,12329,2421,28797,341,257,21792,13689,22133]

theorem envBound23999 : H12AffineFastState.Bounded env23999 := by
  intro p hp
  have h : env23999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23998_23999 : H12AffineEnvironment.transform 15 343 env23998 = env23999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env23998 == env23999) = true)

theorem identity23999 : scanCanonicalize (H12AffineFastState.compose env23999 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound23999 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env24000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,373,343,5221,10588,1025,372,4161,341,17,374,8192,64,2049,5393,12329,2421,1364,341,257,8201,13689,9052]

theorem envBound24000 : H12AffineFastState.Bounded env24000 := by
  intro p hp
  have h : env24000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23999_24000 : H12AffineEnvironment.transform 13 13609 env23999 = env24000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env23999 == env24000) = true)

theorem identity24000 : scanCanonicalize (H12AffineFastState.compose env24000 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound24000 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5408,373,343,5221,2389,1025,372,4161,341,17,374,9,64,2049,5393,4128,2421,1364,341,257,0,5488,853]

theorem envBound24001 : H12AffineFastState.Bounded env24001 := by
  intro p hp
  have h : env24001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24000_24001 : H12AffineEnvironment.transform 12 9 env24000 = env24001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24000 == env24001) = true)

theorem identity24001 : scanCanonicalize (H12AffineFastState.compose env24001 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24001 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24002 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5236,33,3,5221,2049,1025,32,4161,1,17,34,9,64,2049,5189,4128,2081,1024,1,85,0,5156,513]

theorem envBound24002 : H12AffineFastState.Bounded env24002 := by
  intro p hp
  have h : env24002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24001_24002 : H12AffineEnvironment.transform 7 84 env24001 = env24002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24001 == env24002) = true)

theorem identity24002 : scanCanonicalize (H12AffineFastState.compose env24002 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24003 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,9,5125,33,3,5140,2049,1025,32,4144,1,17,34,9,49,2049,5172,4128,2081,1024,1,36,0,5156,513]

theorem envBound24003 : H12AffineFastState.Bounded env24003 := by
  intro p hp
  have h : env24003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24002_24003 : H12AffineEnvironment.transform 5 49 env24002 = env24003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24002 == env24003) = true)

theorem identity24003 : scanCanonicalize (H12AffineFastState.compose env24003 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24004 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,1076,9,49,33,3,32,2049,1025,32,1028,1,17,34,9,49,2049,0,1044,2081,1024,1,36,0,16,513]

theorem envBound24004 : H12AffineFastState.Bounded env24004 := by
  intro p hp
  have h : env24004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24003_24004 : H12AffineEnvironment.transform 11 1076 env24003 = env24004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env24003 == env24004) = true)

theorem identity24004 : scanCanonicalize (H12AffineFastState.compose env24004 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound24004 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24005 : List Nat := [2,4,8,16,32,49,8,37,512,1024,1061,1076,9,49,33,3,32,1060,1025,32,1028,1,17,34,9,49,1060,0,1044,1028,1024,1,36,0,16,513]

theorem envBound24005 : H12AffineFastState.Bounded env24005 := by
  intro p hp
  have h : env24005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24004_24005 : H12AffineEnvironment.transform 10 1061 env24004 = env24005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env24004 == env24005) = true)

theorem identity24005 : scanCanonicalize (H12AffineFastState.compose env24005 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound24005 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24006 : List Nat := [2,4,8,16,32,49,8,37,49,1024,1061,1076,9,49,33,3,32,1060,1025,32,1028,1,17,34,9,49,1060,0,1044,1028,1024,1,36,0,16,48]

theorem envBound24006 : H12AffineFastState.Bounded env24006 := by
  intro p hp
  have h : env24006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24005_24006 : H12AffineEnvironment.transform 8 49 env24005 = env24006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env24005 == env24006) = true)

theorem identity24006 : scanCanonicalize (H12AffineFastState.compose env24006 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound24006 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24007 : List Nat := [2,4,8,16,32,49,8,37,49,5,32,49,9,49,33,3,32,33,4,32,1,1,17,34,9,49,33,0,17,1,5,1,36,0,16,48]

theorem envBound24007 : H12AffineFastState.Bounded env24007 := by
  intro p hp
  have h : env24007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24006_24007 : H12AffineEnvironment.transform 9 5 env24006 = env24007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env24006 == env24007) = true)

def env24008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95496,8193,64,2048,5393,45405,283904,61704,318548,257,21792,46093,120406]

theorem envBound24008 : H12AffineFastState.Bounded env24008 := by
  intro p hp
  have h : env24008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23995_24008 : H12AffineEnvironment.transform 6 9 env23995 = env24008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23995 == env24008) = true)

theorem identity24008 : scanCanonicalize (H12AffineFastState.compose env24008 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound24008 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1025,32769,58396,119927,17,95496,8193,64,2048,5393,45405,108927,61704,73771,257,21792,46093,120406]

theorem envBound24009 : H12AffineFastState.Bounded env24009 := by
  intro p hp
  have h : env24009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24008_24009 : H12AffineEnvironment.transform 17 130175 env24008 = env24009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env24008 == env24009) = true)

theorem identity24009 : scanCanonicalize (H12AffineFastState.compose env24009 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound24009 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env24010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,38160,43049,1025,32769,58396,32801,17,8542,8193,64,2048,5393,45405,64809,61704,29821,257,21792,46093,33280]

theorem envBound24010 : H12AffineFastState.Bounded env24010 := by
  intro p hp
  have h : env24010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24009_24010 : H12AffineEnvironment.transform 15 21590 env24009 = env24010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env24009 == env24010) = true)

theorem identity24010 : scanCanonicalize (H12AffineFastState.compose env24010 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24010 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env24011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,342,38160,43049,1025,32769,45340,32801,17,8542,8193,64,2048,5393,45405,43049,41992,8573,257,32,46093,33280]

theorem envBound24011 : H12AffineFastState.Bounded env24011 := by
  intro p hp
  have h : env24011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24010_24011 : H12AffineEnvironment.transform 13 5376 env24010 = env24011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24010 == env24011) = true)

theorem identity24011 : scanCanonicalize (H12AffineFastState.compose env24011 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24011 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env24012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,342,13388,2421,1025,8541,4160,8573,17,8542,8193,64,2048,5393,4097,2421,1364,8573,257,32,5457,9052]

theorem envBound24012 : H12AffineFastState.Bounded env24012 := by
  intro p hp
  have h : env24012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24011_24012 : H12AffineEnvironment.transform 14 8540 env24011 = env24012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24011 == env24012) = true)

theorem identity24012 : scanCanonicalize (H12AffineFastState.compose env24012 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound24012 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5432,5376,5220,342,372,2421,1025,5221,4160,5189,17,5222,5433,64,2048,5393,4097,2421,1364,5189,257,32,5457,5732]

theorem envBound24013 : H12AffineFastState.Bounded env24013 := by
  intro p hp
  have h : env24013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24012_24013 : H12AffineEnvironment.transform 12 5432 env24012 = env24013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env24012 == env24013) = true)

theorem identity24013 : scanCanonicalize (H12AffineFastState.compose env24013 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24013 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24014 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,5196,5236,5220,34,0,2049,1025,5221,4160,5189,17,5222,5197,64,2048,5221,4097,2049,1056,5189,117,32,5157,5732]

theorem envBound24014 : H12AffineFastState.Bounded env24014 := by
  intro p hp
  have h : env24014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24013_24014 : H12AffineEnvironment.transform 7 116 env24013 = env24014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24013 == env24014) = true)

theorem identity24014 : scanCanonicalize (H12AffineFastState.compose env24014 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24014 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24015 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1124,40,16,0,34,0,2049,1025,1,1060,33,17,2,41,64,2048,1,1125,2049,1056,33,117,32,65,512]

theorem envBound24015 : H12AffineFastState.Bounded env24015 := by
  intro p hp
  have h : env24015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24014_24015 : H12AffineEnvironment.transform 11 1124 env24014 = env24015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env24014 == env24015) = true)

theorem identity24015 : scanCanonicalize (H12AffineFastState.compose env24015 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound24015 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24016 : List Nat := [2,4,8,16,32,64,9,116,113,1024,2048,1124,40,16,0,34,0,2049,1025,1,1060,33,17,2,41,64,2048,1,1125,2049,1056,33,117,32,65,113]

theorem envBound24016 : H12AffineFastState.Bounded env24016 := by
  intro p hp
  have h : env24016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24015_24016 : H12AffineEnvironment.transform 8 113 env24015 = env24016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env24015 == env24016) = true)

theorem identity24016 : scanCanonicalize (H12AffineFastState.compose env24016 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24016 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24017 : List Nat := [2,4,8,16,32,48,9,4,1,1024,2048,1044,40,16,0,34,0,2049,1025,1,1060,33,17,2,41,48,2048,1,1045,2049,1056,33,5,32,49,1]

theorem envBound24017 : H12AffineFastState.Bounded env24017 := by
  intro p hp
  have h : env24017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24016_24017 : H12AffineEnvironment.transform 5 48 env24016 = env24017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24016 == env24017) = true)

theorem identity24017 : scanCanonicalize (H12AffineFastState.compose env24017 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24017 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env24018 : List Nat := [2,4,8,16,32,48,9,4,1,20,2048,0,40,16,0,34,0,2049,21,1,48,33,17,2,41,48,2048,1,1,2049,52,33,5,32,49,1]

theorem envBound24018 : H12AffineFastState.Bounded env24018 := by
  intro p hp
  have h : env24018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24017_24018 : H12AffineEnvironment.transform 9 20 env24017 = env24018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24017 == env24018) = true)

theorem identity24018 : scanCanonicalize (H12AffineFastState.compose env24018 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound24018 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24019 : List Nat := [2,4,8,16,32,48,9,4,1,20,49,0,40,16,0,34,0,48,21,1,48,33,17,2,41,48,49,1,1,48,52,33,5,32,49,1]

theorem envBound24019 : H12AffineFastState.Bounded env24019 := by
  intro p hp
  have h : env24019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24018_24019 : H12AffineEnvironment.transform 10 49 env24018 = env24019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env24018 == env24019) = true)

theorem identity24019 : scanCanonicalize (H12AffineFastState.compose env24019 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound24019 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24020 : List Nat := [2,4,8,16,21,5,9,4,1,20,4,0,29,16,0,23,0,5,21,1,5,20,17,2,28,5,4,1,1,5,1,20,5,21,4,1]

theorem envBound24020 : H12AffineFastState.Bounded env24020 := by
  intro p hp
  have h : env24020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24019_24020 : H12AffineEnvironment.transform 4 21 env24019 = env24020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env24019 == env24020) = true)

theorem identity24020 : scanCanonicalize (H12AffineFastState.compose env24020 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound24020 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24021 : List Nat := [2,4,8,5,0,5,9,4,1,1,4,0,8,5,0,2,0,5,0,1,5,1,4,2,9,5,4,1,1,5,1,1,5,0,4,1]

theorem envBound24021 : H12AffineFastState.Bounded env24021 := by
  intro p hp
  have h : env24021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24020_24021 : H12AffineEnvironment.transform 3 5 env24020 = env24021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env24020 == env24021) = true)

def env24022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound24022 : H12AffineFastState.Bounded env24022 := by
  intro p hp
  have h : env24022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23708_24022 : H12AffineEnvironment.transform 26 30393345 env23708 = env24022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env23708 == env24022) = true)

def env24023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound24023 : H12AffineFastState.Bounded env24023 := by
  intro p hp
  have h : env24023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24022_24023 : H12AffineEnvironment.transform 18 1024 env24022 = env24023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24022 == env24023) = true)

theorem identity24023 : scanCanonicalize (H12AffineFastState.compose env24023 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound24023 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188616,8328,64,15115593,57797,10507600,8830977,10543449,4194440,256,8430052,8405056,10602127]

theorem envBound24024 : H12AffineFastState.Bounded env24024 := by
  intro p hp
  have h : env24024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24023_24024 : H12AffineEnvironment.transform 23 2188616 env24023 = env24024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env24023 == env24024) = true)

def env24025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62660,2188616,8328,64,6705549,57797,2138516,406725,2102685,4194440,256,21792,46212,2175563]

theorem envBound24025 : H12AffineFastState.Bounded env24025 := by
  intro p hp
  have h : env24025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24024_24025 : H12AffineEnvironment.transform 22 62660 env24024 = env24025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env24024 == env24025) = true)

def env24026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62660,2188616,8328,64,158029,57797,2138516,406725,2102685,2373704,256,21792,46212,2175563]

theorem envBound24026 : H12AffineFastState.Bounded env24026 := by
  intro p hp
  have h : env24026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24025_24026 : H12AffineEnvironment.transform 21 2373824 env24025 = env24026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env24025 == env24026) = true)

theorem identity24026 : scanCanonicalize (H12AffineFastState.compose env24026 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound24026 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329866,62660,21762,8328,64,158029,57797,102878,406725,75223,329730,256,21792,46212,513]

theorem envBound24027 : H12AffineFastState.Bounded env24027 := by
  intro p hp
  have h : env24027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24026_24027 : H12AffineEnvironment.transform 20 77898 env24026 = env24027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env24026 == env24027) = true)

def env24028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329730,62540,21762,8192,64,158029,57677,102742,406605,75103,329730,256,21792,46092,513]

theorem envBound24028 : H12AffineFastState.Bounded env24028 := by
  intro p hp
  have h : env24028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24027_24028 : H12AffineEnvironment.transform 6 8 env24027 = env24028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24027 == env24028) = true)

theorem identity24028 : scanCanonicalize (H12AffineFastState.compose env24028 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24028 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,77898,329730,62540,21762,8192,64,67926,57677,102742,349270,75103,329730,256,21792,46092,513]

theorem envBound24029 : H12AffineFastState.Bounded env24029 := by
  intro p hp
  have h : env24029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24028_24029 : H12AffineEnvironment.transform 16 90139 env24028 = env24029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24028 == env24029) = true)

def env24030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77898,73770,62540,21762,8192,64,67926,57677,102742,97406,75103,73770,256,21792,46092,513]

theorem envBound24030 : H12AffineFastState.Bounded env24030 := by
  intro p hp
  have h : env24030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24029_24030 : H12AffineEnvironment.transform 17 10280 env24029 = env24030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24029 == env24030) = true)

theorem identity24030 : scanCanonicalize (H12AffineFastState.compose env24030 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24030 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1024,29789,77898,73770,16,21762,8192,64,67926,5393,91402,97406,75103,73770,256,21792,16464,513]

theorem envBound24031 : H12AffineFastState.Bounded env24031 := by
  intro p hp
  have h : env24031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24030_24031 : H12AffineEnvironment.transform 14 29788 env24030 = env24031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24030 == env24031) = true)

theorem identity24031 : scanCanonicalize (H12AffineFastState.compose env24031 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31790) := by decide +kernel

theorem selectedBound24031 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0