import H12CloudChart0Data094

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,31790,7221,10280,1024,29789,19556,23556,16,21762,8192,64,30072,5393,6436,80,22897,23556,256,21792,16464,513]

theorem envBound24032 : H12AffineFastState.Bounded env24032 := by
  intro p hp
  have h : env24032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24031_24032 : H12AffineEnvironment.transform 15 31790 env24031 = env24032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31790 env24031 == env24032) = true)

theorem identity24032 : scanCanonicalize (H12AffineFastState.compose env24032 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24032 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,10542,7221,10280,1024,8541,6500,2308,16,2,8192,64,8312,5393,6436,80,3185,2308,256,32,5456,513]

theorem envBound24033 : H12AffineFastState.Bounded env24033 := by
  intro p hp
  have h : env24033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24032_24033 : H12AffineEnvironment.transform 13 5376 env24032 = env24033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24032 == env24033) = true)

theorem identity24033 : scanCanonicalize (H12AffineFastState.compose env24033 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 3433) := by decide +kernel

theorem selectedBound24033 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3433,5376,3125,1095,7221,1345,1024,3124,6500,2308,16,2,3433,64,3345,5393,6436,80,3185,2308,256,32,5456,513]

theorem envBound24034 : H12AffineFastState.Bounded env24034 := by
  intro p hp
  have h : env24034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24033_24034 : H12AffineEnvironment.transform 12 3433 env24033 = env24034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3433 env24033 == env24034) = true)

theorem identity24034 : scanCanonicalize (H12AffineFastState.compose env24034 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound24034 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env24035 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,2316,4453,2128,34,6224,292,101,2129,6500,2308,16,2,2316,64,2420,4468,6436,80,2068,2308,256,32,4405,513]

theorem envBound24035 : H12AffineFastState.Bounded env24035 := by
  intro p hp
  have h : env24035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24034_24035 : H12AffineEnvironment.transform 9 101 env24034 = env24035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env24034 == env24035) = true)

theorem identity24035 : scanCanonicalize (H12AffineFastState.compose env24035 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound24035 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24036 : List Nat := [2,4,8,16,32,64,8,256,512,101,292,4096,40,4453,372,34,4468,292,101,373,4160,32,16,2,40,64,80,4468,4096,80,304,32,256,32,4405,513]

theorem envBound24036 : H12AffineFastState.Bounded env24036 := by
  intro p hp
  have h : env24036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24035_24036 : H12AffineEnvironment.transform 10 292 env24035 = env24036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env24035 == env24036) = true)

def env24037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,77898,73771,62540,21762,8192,64,67926,57677,102742,97407,75103,73771,256,21792,46092,513]

theorem envBound24037 : H12AffineFastState.Bounded env24037 := by
  intro p hp
  have h : env24037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24029_24037 : H12AffineEnvironment.transform 17 10281 env24029 = env24037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24029 == env24037) = true)

theorem identity24037 : scanCanonicalize (H12AffineFastState.compose env24037 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound24037 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28699,4096,10281,1024,32769,16465,20528,62540,21762,8192,64,31053,57677,57677,3172,21828,20528,256,21792,46092,513]

theorem envBound24038 : H12AffineFastState.Bounded env24038 := by
  intro p hp
  have h : env24038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24037_24038 : H12AffineEnvironment.transform 15 28699 env24037 = env24038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env24037 == env24038) = true)

theorem identity24038 : scanCanonicalize (H12AffineFastState.compose env24038 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24038 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10281,1024,8541,16465,20528,21776,21762,8192,64,31053,16401,16401,3172,21828,20528,256,21792,5456,513]

theorem envBound24039 : H12AffineFastState.Bounded env24039 := by
  intro p hp
  have h : env24039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24038_24039 : H12AffineEnvironment.transform 14 8540 env24038 = env24039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24038 == env24039) = true)

theorem identity24039 : scanCanonicalize (H12AffineFastState.compose env24039 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound24039 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,1345,21510,4096,3124,1024,1344,16465,20528,21776,21762,1053,64,23888,16401,16401,3172,21828,20528,256,21792,5456,513]

theorem envBound24040 : H12AffineFastState.Bounded env24040 := by
  intro p hp
  have h : env24040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24039_24040 : H12AffineEnvironment.transform 12 1053 env24039 = env24040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env24039 == env24040) = true)

theorem identity24040 : scanCanonicalize (H12AffineFastState.compose env24040 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24040 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24041 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,16384,1076,21510,4096,3124,1024,1077,16465,20528,21605,21623,1053,64,23589,16401,16401,3172,21553,20528,117,21589,5157,513]

theorem envBound24041 : H12AffineFastState.Bounded env24041 := by
  intro p hp
  have h : env24041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24040_24041 : H12AffineEnvironment.transform 7 117 env24040 = env24041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24040 == env24041) = true)

theorem identity24041 : scanCanonicalize (H12AffineFastState.compose env24041 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound24041 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env24042 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,3173,1076,6243,4096,3124,1024,1077,3124,7253,6144,6162,1053,64,4160,3188,3188,3172,6228,7253,117,6192,5157,513]

theorem envBound24042 : H12AffineFastState.Bounded env24042 := by
  intro p hp
  have h : env24042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24041_24042 : H12AffineEnvironment.transform 13 3173 env24041 = env24042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env24041 == env24042) = true)

theorem identity24042 : scanCanonicalize (H12AffineFastState.compose env24042 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound24042 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24043 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2112,1053,3173,1076,35,2112,3124,1024,1077,3124,1045,64,82,1053,64,2048,3188,3188,3172,20,1045,117,112,3173,513]

theorem envBound24043 : H12AffineFastState.Bounded env24043 := by
  intro p hp
  have h : env24043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24042_24043 : H12AffineEnvironment.transform 11 2112 env24042 = env24043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env24042 == env24043) = true)

theorem identity24043 : scanCanonicalize (H12AffineFastState.compose env24043 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24043 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24044 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2064,1053,3125,1076,35,2064,3124,1024,1077,3124,1045,16,2,1053,16,2048,3108,3108,3124,20,1045,37,32,3125,513]

theorem envBound24044 : H12AffineFastState.Bounded env24044 := by
  intro p hp
  have h : env24044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24043_24044 : H12AffineEnvironment.transform 5 16 env24043 = env24044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24043 == env24044) = true)

theorem identity24044 : scanCanonicalize (H12AffineFastState.compose env24044 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound24044 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24045 : List Nat := [2,4,8,16,32,16,8,37,512,1024,512,528,1053,1589,1076,35,528,1588,1024,1077,1588,1045,16,2,1053,16,512,1572,1572,1588,20,1045,37,32,1589,513]

theorem envBound24045 : H12AffineFastState.Bounded env24045 := by
  intro p hp
  have h : env24045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24044_24045 : H12AffineEnvironment.transform 10 512 env24044 = env24045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env24044 == env24045) = true)

theorem identity24045 : scanCanonicalize (H12AffineFastState.compose env24045 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound24045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24046 : List Nat := [2,4,8,16,32,16,8,37,48,1024,48,32,1053,1029,1076,35,32,1028,1024,1077,1028,1045,16,2,1053,16,48,1044,1044,1028,20,1045,37,32,1029,49]

theorem envBound24046 : H12AffineFastState.Bounded env24046 := by
  intro p hp
  have h : env24046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24045_24046 : H12AffineEnvironment.transform 8 48 env24045 = env24046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env24045 == env24046) = true)

theorem identity24046 : scanCanonicalize (H12AffineFastState.compose env24046 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24046 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24047 : List Nat := [2,4,8,16,32,16,8,37,48,53,48,32,40,48,1,35,32,49,53,0,49,32,16,2,40,16,48,33,33,49,20,32,37,32,48,49]

theorem envBound24047 : H12AffineFastState.Bounded env24047 := by
  intro p hp
  have h : env24047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24046_24047 : H12AffineEnvironment.transform 9 53 env24046 = env24047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24046 == env24047) = true)

theorem identity24047 : scanCanonicalize (H12AffineFastState.compose env24047 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24047 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24048 : List Nat := [2,4,8,0,32,0,8,37,32,37,32,32,40,32,1,35,32,33,37,0,33,32,0,2,40,0,32,33,33,33,4,32,37,32,32,33]

theorem envBound24048 : H12AffineFastState.Bounded env24048 := by
  intro p hp
  have h : env24048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24047_24048 : H12AffineEnvironment.transform 3 0 env24047 = env24048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24047 == env24048) = true)

theorem identity24048 : scanCanonicalize (H12AffineFastState.compose env24048 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24048 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24049 : List Nat := [2,4,8,0,0,0,8,5,0,5,0,0,8,0,1,3,0,1,5,0,1,0,0,2,8,0,0,1,1,1,4,0,5,0,0,1]

theorem envBound24049 : H12AffineFastState.Bounded env24049 := by
  intro p hp
  have h : env24049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24048_24049 : H12AffineEnvironment.transform 4 0 env24048 = env24049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24048 == env24049) = true)

def env24050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329731,62541,21762,8193,64,158029,57676,102743,406604,75102,329730,256,21792,46093,513]

theorem envBound24050 : H12AffineFastState.Bounded env24050 := by
  intro p hp
  have h : env24050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24027_24050 : H12AffineEnvironment.transform 6 9 env24027 = env24050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24027 == env24050) = true)

def env24051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77898,73771,62541,21762,8193,64,158029,57676,102743,138340,75102,73770,256,21792,46093,513]

theorem envBound24051 : H12AffineFastState.Bounded env24051 := by
  intro p hp
  have h : env24051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24050_24051 : H12AffineEnvironment.transform 17 10280 env24050 = env24051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24050 == env24051) = true)

def env24052 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62493,21762,8193,16,157981,57628,102663,138292,75022,73770,256,21792,46093,513]

theorem envBound24052 : H12AffineFastState.Bounded env24052 := by
  intro p hp
  have h : env24052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24051_24052 : H12AffineEnvironment.transform 5 16 env24051 = env24052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24051 == env24052) = true)

theorem identity24052 : scanCanonicalize (H12AffineFastState.compose env24052 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound24052 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env24053 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,65536,131072,10280,1024,32769,77850,73771,32784,8463,8193,16,138512,38161,102663,138292,75022,73770,256,8493,46093,513]

theorem envBound24053 : H12AffineFastState.Bounded env24053 := by
  intro p hp
  have h : env24053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24052_24053 : H12AffineEnvironment.transform 13 13325 env24052 = env24053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env24052 == env24053) = true)

theorem identity24053 : scanCanonicalize (H12AffineFastState.compose env24053 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24053 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env24054 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,65536,131072,2341,1024,32769,69911,65830,32784,2,268,16,138512,38161,102663,138292,66563,65831,256,32,38144,513]

theorem envBound24054 : H12AffineFastState.Bounded env24054 := by
  intro p hp
  have h : env24054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24053_24054 : H12AffineEnvironment.transform 12 269 env24053 = env24054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24053 == env24054) = true)

theorem identity24054 : scanCanonicalize (H12AffineFastState.compose env24054 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound24054 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24055 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,65536,103446,2341,1024,32769,69911,65830,32784,2,268,16,100614,38161,102663,100386,66563,65831,256,32,38144,513]

theorem envBound24055 : H12AffineFastState.Bounded env24055 := by
  intro p hp
  have h : env24055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24054_24055 : H12AffineEnvironment.transform 16 103446 env24054 = env24055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env24054 == env24055) = true)

theorem identity24055 : scanCanonicalize (H12AffineFastState.compose env24055 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound24055 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24056 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,262,38160,2341,1024,32769,4113,32,32784,2,268,16,34816,38161,36865,35108,1285,33,256,32,38144,513]

theorem envBound24056 : H12AffineFastState.Bounded env24056 := by
  intro p hp
  have h : env24056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24055_24056 : H12AffineEnvironment.transform 15 262 env24055 = env24056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env24055 == env24056) = true)

theorem identity24056 : scanCanonicalize (H12AffineFastState.compose env24056 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound24056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24057 : List Nat := [2,4,8,16,32,16,9,256,512,36,2048,4096,269,4388,32768,262,37172,2341,36,32769,4113,32,32784,2,268,16,34816,37173,36865,35108,289,33,256,32,37156,513]

theorem envBound24057 : H12AffineFastState.Bounded env24057 := by
  intro p hp
  have h : env24057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24056_24057 : H12AffineEnvironment.transform 9 36 env24056 = env24057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env24056 == env24057) = true)

theorem identity24057 : scanCanonicalize (H12AffineFastState.compose env24057 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24057 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24058 : List Nat := [2,4,8,16,32,16,9,256,512,36,2048,4096,269,4388,1,262,4405,2341,36,0,4113,32,17,2,268,16,2049,4404,4096,2341,289,33,256,32,4389,513]

theorem envBound24058 : H12AffineFastState.Bounded env24058 := by
  intro p hp
  have h : env24058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24057_24058 : H12AffineEnvironment.transform 14 1 env24057 = env24058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24057 == env24058) = true)

theorem identity24058 : scanCanonicalize (H12AffineFastState.compose env24058 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound24058 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24059 : List Nat := [2,4,8,16,32,16,9,256,512,36,2048,2058,269,2350,1,262,2367,2341,36,0,2075,32,17,2,268,16,2049,2366,2058,2341,289,33,256,32,2351,513]

theorem envBound24059 : H12AffineFastState.Bounded env24059 := by
  intro p hp
  have h : env24059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24058_24059 : H12AffineEnvironment.transform 11 2058 env24058 = env24059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env24058 == env24059) = true)

theorem identity24059 : scanCanonicalize (H12AffineFastState.compose env24059 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24059 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24060 : List Nat := [2,4,8,16,16,16,9,256,512,20,2048,2058,269,2334,1,262,2319,2325,20,0,2075,16,17,2,268,16,2049,2318,2058,2325,273,17,256,16,2335,513]

theorem envBound24060 : H12AffineFastState.Bounded env24060 := by
  intro p hp
  have h : env24060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24059_24060 : H12AffineEnvironment.transform 4 16 env24059 = env24060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24059 == env24060) = true)

theorem identity24060 : scanCanonicalize (H12AffineFastState.compose env24060 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound24060 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24061 : List Nat := [2,4,8,16,16,16,9,31,512,20,2048,2058,18,2049,1,25,2064,2058,20,0,2075,16,17,2,19,16,2049,2065,2058,2058,14,17,31,16,2048,513]

theorem envBound24061 : H12AffineFastState.Bounded env24061 := by
  intro p hp
  have h : env24061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24060_24061 : H12AffineEnvironment.transform 7 31 env24060 = env24061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env24060 == env24061) = true)

theorem identity24061 : scanCanonicalize (H12AffineFastState.compose env24061 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24061 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24062 : List Nat := [2,4,3,16,16,16,2,20,512,20,2048,2049,18,2049,1,18,2064,2049,20,0,2064,16,17,2,19,16,2049,2065,2049,2049,5,17,20,16,2048,513]

theorem envBound24062 : H12AffineFastState.Bounded env24062 := by
  intro p hp
  have h : env24062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24061_24062 : H12AffineEnvironment.transform 2 3 env24061 = env24062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24061 == env24062) = true)

def env24063 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62492,21762,8193,17,157980,57629,102662,138293,75023,73770,256,21792,46093,513]

theorem envBound24063 : H12AffineFastState.Bounded env24063 := by
  intro p hp
  have h : env24063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24051_24063 : H12AffineEnvironment.transform 5 17 env24051 = env24063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24051 == env24063) = true)

theorem identity24063 : scanCanonicalize (H12AffineFastState.compose env24063 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound24063 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env24064 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,103446,10280,1024,32769,77851,73771,62492,21762,8193,17,130314,57629,102662,100387,75023,73770,256,21792,46093,513]

theorem envBound24064 : H12AffineFastState.Bounded env24064 := by
  intro p hp
  have h : env24064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24063_24064 : H12AffineEnvironment.transform 16 103446 env24063 = env24064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env24063 == env24064) = true)

theorem identity24064 : scanCanonicalize (H12AffineFastState.compose env24064 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24064 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env24065 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,65536,70679,10280,1024,0,77851,73771,29725,21762,8193,17,97547,24860,69895,67618,75023,73770,256,21792,13324,513]

theorem envBound24065 : H12AffineFastState.Bounded env24065 := by
  intro p hp
  have h : env24065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24064_24065 : H12AffineEnvironment.transform 14 1 env24064 = env24065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24064 == env24065) = true)

theorem identity24065 : scanCanonicalize (H12AffineFastState.compose env24065 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24065 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24066 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,263,5392,10280,1024,0,12572,8492,29725,21762,8193,17,31756,24860,4096,2341,9224,8493,256,21792,13324,513]

theorem envBound24066 : H12AffineFastState.Bounded env24066 := by
  intro p hp
  have h : env24066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24065_24066 : H12AffineEnvironment.transform 15 263 env24065 = env24066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24065 == env24066) = true)

theorem identity24066 : scanCanonicalize (H12AffineFastState.compose env24066 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24066 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24067 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,5392,2341,1024,0,4113,33,21776,21762,268,17,23809,16401,4096,2341,1285,32,256,21792,5377,513]

theorem envBound24067 : H12AffineFastState.Bounded env24067 := by
  intro p hp
  have h : env24067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24066_24067 : H12AffineEnvironment.transform 12 269 env24066 = env24067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24066 == env24067) = true)

theorem identity24067 : scanCanonicalize (H12AffineFastState.compose env24067 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24067 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24068 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5392,2341,1024,0,4113,33,16,2,268,17,2049,5393,4096,2341,1285,32,256,32,5377,513]

theorem envBound24068 : H12AffineFastState.Bounded env24068 := by
  intro p hp
  have h : env24068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24067_24068 : H12AffineEnvironment.transform 13 5376 env24067 = env24068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24067 == env24068) = true)

theorem identity24068 : scanCanonicalize (H12AffineFastState.compose env24068 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound24068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24069 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1297,269,17,1,263,1,2341,1024,0,1280,33,16,2,268,17,2049,0,1297,2341,1285,32,256,32,16,513]

theorem envBound24069 : H12AffineFastState.Bounded env24069 := by
  intro p hp
  have h : env24069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24068_24069 : H12AffineEnvironment.transform 11 1297 env24068 = env24069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24068 == env24069) = true)

theorem identity24069 : scanCanonicalize (H12AffineFastState.compose env24069 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1291) := by decide +kernel

theorem selectedBound24069 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24070 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1291,1297,269,17,1,263,1,1070,1024,0,1280,33,16,2,268,17,1290,0,1297,1070,1285,32,256,32,16,513]

theorem envBound24070 : H12AffineFastState.Bounded env24070 := by
  intro p hp
  have h : env24070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24069_24070 : H12AffineEnvironment.transform 10 1291 env24069 = env24070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1291 env24069 == env24070) = true)

theorem identity24070 : scanCanonicalize (H12AffineFastState.compose env24070 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24070 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24071 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1039,1045,9,17,1,3,1,1070,1024,0,1028,33,16,2,8,17,1038,0,1045,1070,1025,32,4,32,16,513]

theorem envBound24071 : H12AffineFastState.Bounded env24071 := by
  intro p hp
  have h : env24071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24070_24071 : H12AffineEnvironment.transform 7 4 env24070 = env24071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24070 == env24071) = true)

theorem identity24071 : scanCanonicalize (H12AffineFastState.compose env24071 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24071 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24072 : List Nat := [2,4,8,0,32,1,9,4,512,1024,1039,1029,9,1,1,3,1,1070,1024,0,1028,33,0,2,8,1,1038,0,1029,1070,1025,32,4,32,0,513]

theorem envBound24072 : H12AffineFastState.Bounded env24072 := by
  intro p hp
  have h : env24072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24071_24072 : H12AffineEnvironment.transform 3 0 env24071 = env24072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24071 == env24072) = true)

theorem identity24072 : scanCanonicalize (H12AffineFastState.compose env24072 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24072 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24073 : List Nat := [2,4,2,0,32,1,3,4,512,1024,1029,1029,3,1,1,3,1,1060,1024,0,1028,33,0,2,2,1,1028,0,1029,1060,1025,32,4,32,0,513]

theorem envBound24073 : H12AffineFastState.Bounded env24073 := by
  intro p hp
  have h : env24073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24072_24073 : H12AffineEnvironment.transform 2 2 env24072 = env24073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24072 == env24073) = true)

theorem identity24073 : scanCanonicalize (H12AffineFastState.compose env24073 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24073 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24074 : List Nat := [2,4,2,0,1,1,3,4,512,1024,1029,1029,3,1,1,3,1,1029,1024,0,1028,0,0,2,2,1,1028,0,1029,1029,1025,1,4,1,0,513]

theorem envBound24074 : H12AffineFastState.Bounded env24074 := by
  intro p hp
  have h : env24074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24073_24074 : H12AffineEnvironment.transform 4 1 env24073 = env24074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24073 == env24074) = true)

theorem identity24074 : scanCanonicalize (H12AffineFastState.compose env24074 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24075 : List Nat := [2,0,2,0,1,1,3,0,512,1024,1025,1025,3,1,1,3,1,1025,1024,0,1024,0,0,2,2,1,1024,0,1025,1025,1025,1,0,1,0,513]

theorem envBound24075 : H12AffineFastState.Bounded env24075 := by
  intro p hp
  have h : env24075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24074_24075 : H12AffineEnvironment.transform 1 0 env24074 = env24075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24074 == env24075) = true)

def env24076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77898,73770,62541,21762,8193,64,158029,57676,102743,138341,75102,73771,256,21792,46093,513]

theorem envBound24076 : H12AffineFastState.Bounded env24076 := by
  intro p hp
  have h : env24076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24050_24076 : H12AffineEnvironment.transform 17 10281 env24050 = env24076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24050 == env24076) = true)

theorem identity24076 : scanCanonicalize (H12AffineFastState.compose env24076 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24076 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,77898,73770,16,21762,8193,64,158029,5393,91402,138341,75102,73771,256,21792,16464,513]

theorem envBound24077 : H12AffineFastState.Bounded env24077 := by
  intro p hp
  have h : env24077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24076_24077 : H12AffineEnvironment.transform 14 29789 env24076 = env24077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24076 == env24077) = true)

theorem identity24077 : scanCanonicalize (H12AffineFastState.compose env24077 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24077 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10281,1024,29788,77898,73770,16,21762,8193,64,67926,5393,91402,97406,75102,73771,256,21792,16464,513]

theorem envBound24078 : H12AffineFastState.Bounded env24078 := by
  intro p hp
  have h : env24078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24077_24078 : H12AffineEnvironment.transform 16 90139 env24077 = env24078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24077 == env24078) = true)

theorem identity24078 : scanCanonicalize (H12AffineFastState.compose env24078 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound24078 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,28699,4096,10281,1024,29788,16465,20529,16,21762,8193,64,31053,5393,5393,3173,21829,20528,256,21792,16464,513]

theorem envBound24079 : H12AffineFastState.Bounded env24079 := by
  intro p hp
  have h : env24079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24078_24079 : H12AffineEnvironment.transform 15 28699 env24078 = env24079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env24078 == env24079) = true)

theorem identity24079 : scanCanonicalize (H12AffineFastState.compose env24079 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound24079 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16464,17430,4096,7204,1024,16465,16465,20529,16,21762,5132,64,19776,5393,5393,3173,21829,20528,256,21792,16464,513]

theorem envBound24080 : H12AffineFastState.Bounded env24080 := by
  intro p hp
  have h : env24080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24079_24080 : H12AffineEnvironment.transform 12 5133 env24079 = env24080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env24079 == env24080) = true)

theorem identity24080 : scanCanonicalize (H12AffineFastState.compose env24080 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24080 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env24081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,1077,1125,35,4096,7204,1024,1124,1124,5124,16,4407,5132,64,2421,5393,5393,3173,4464,5125,256,4373,1125,513]

theorem envBound24081 : H12AffineFastState.Bounded env24081 := by
  intro p hp
  have h : env24081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24080_24081 : H12AffineEnvironment.transform 13 1077 env24080 = env24081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env24080 == env24081) = true)

theorem identity24081 : scanCanonicalize (H12AffineFastState.compose env24081 (packedSelected [0,1,2,3,5,7,8,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24081 : packedSelected [0,1,2,3,5,7,8,15,18] rootPS < 2^1333 := by decide +kernel

def env24082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,5133,1077,1125,35,4096,4160,1024,1124,1124,5124,16,4407,5132,64,1297,5393,5393,1,4464,5125,256,4373,1125,513]

theorem envBound24082 : H12AffineFastState.Bounded env24082 := by
  intro p hp
  have h : env24082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24081_24082 : H12AffineEnvironment.transform 10 1124 env24081 = env24082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env24081 == env24082) = true)

theorem identity24082 : scanCanonicalize (H12AffineFastState.compose env24082 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound24082 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,65,1100,1077,1125,35,65,1,1024,1124,1124,1093,16,374,1101,64,1297,1360,1360,1,305,1092,256,340,1125,513]

theorem envBound24083 : H12AffineFastState.Bounded env24083 := by
  intro p hp
  have h : env24083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24082_24083 : H12AffineEnvironment.transform 11 65 env24082 = env24083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env24082 == env24083) = true)

theorem identity24083 : scanCanonicalize (H12AffineFastState.compose env24083 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound24083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24084 : List Nat := [2,4,8,16,32,64,9,256,512,101,1,65,41,80,0,35,65,1,101,1,1,32,16,374,40,64,372,309,309,1,305,33,256,340,0,513]

theorem envBound24084 : H12AffineFastState.Bounded env24084 := by
  intro p hp
  have h : env24084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24083_24084 : H12AffineEnvironment.transform 9 101 env24083 = env24084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env24083 == env24084) = true)

def env24085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62660,2188616,8328,64,158028,57797,2138516,406725,2102685,2373705,256,21792,46212,2175563]

theorem envBound24085 : H12AffineFastState.Bounded env24085 := by
  intro p hp
  have h : env24085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24025_24085 : H12AffineEnvironment.transform 21 2373825 env24025 = env24085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env24025 == env24085) = true)

theorem identity24085 : scanCanonicalize (H12AffineFastState.compose env24085 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound24085 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,392287,62660,41430,8328,64,158028,57797,91402,406725,119043,392407,256,21792,46212,63189]

theorem envBound24086 : H12AffineFastState.Bounded env24086 := by
  intro p hp
  have h : env24086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24085_24086 : H12AffineEnvironment.transform 20 115870 env24085 = env24086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env24085 == env24086) = true)

def env24087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115870,119927,62660,41430,8328,64,158028,57797,91402,138477,119043,120063,256,21792,46212,63189]

theorem envBound24087 : H12AffineFastState.Bounded env24087 := by
  intro p hp
  have h : env24087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24086_24087 : H12AffineEnvironment.transform 17 10280 env24086 = env24087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24086 == env24087) = true)

def env24088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102814,98679,41412,41430,8328,64,146508,46277,77834,138477,99331,98815,256,32,46212,41941]

theorem envBound24088 : H12AffineFastState.Bounded env24088 := by
  intro p hp
  have h : env24088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24087_24088 : H12AffineEnvironment.transform 13 5376 env24087 = env24088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24087 == env24088) = true)

theorem identity24088 : scanCanonicalize (H12AffineFastState.compose env24088 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound24088 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10280,1024,8661,77898,73891,16,2,8328,64,146508,5393,77834,138477,75223,73771,256,32,5456,513]

theorem envBound24089 : H12AffineFastState.Bounded env24089 := by
  intro p hp
  have h : env24089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24088_24089 : H12AffineEnvironment.transform 14 8660 env24088 = env24089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env24088 == env24089) = true)

theorem identity24089 : scanCanonicalize (H12AffineFastState.compose env24089 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound24089 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env24090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70862,10280,1024,8661,77898,73891,16,2,8328,64,75906,5393,77834,67619,75223,73771,256,32,5456,513]

theorem envBound24090 : H12AffineFastState.Bounded env24090 := by
  intro p hp
  have h : env24090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24089_24090 : H12AffineEnvironment.transform 16 70862 env24089 = env24090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env24089 == env24090) = true)

theorem identity24090 : scanCanonicalize (H12AffineFastState.compose env24090 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound24090 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,65536,70862,2557,1024,0,70047,65910,16,2,349,64,67927,5393,70111,67619,66562,66046,256,32,5456,513]

theorem envBound24091 : H12AffineFastState.Bounded env24091 := by
  intro p hp
  have h : env24091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24090_24091 : H12AffineEnvironment.transform 12 469 env24090 = env24091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env24090 == env24091) = true)

def env24092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102815,98678,41413,41430,8328,64,146509,46276,77835,138477,99330,98814,256,33,46212,41940]

theorem envBound24092 : H12AffineFastState.Bounded env24092 := by
  intro p hp
  have h : env24092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24087_24092 : H12AffineEnvironment.transform 13 5377 env24087 = env24092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24087 == env24092) = true)

theorem identity24092 : scanCanonicalize (H12AffineFastState.compose env24092 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24092 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1024,8541,78019,73770,153,138,8328,64,146509,5528,77835,138477,75102,73890,256,33,5592,648]

theorem envBound24093 : H12AffineFastState.Bounded env24093 := by
  intro p hp
  have h : env24093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24092_24093 : H12AffineEnvironment.transform 14 8540 env24092 = env24093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24092 == env24093) = true)

theorem identity24093 : scanCanonicalize (H12AffineFastState.compose env24093 (packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound24093 : packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env24094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,79298,10280,1024,8541,78019,73770,153,138,8328,64,67983,5528,77835,76079,75102,73890,256,33,5592,648]

theorem envBound24094 : H12AffineFastState.Bounded env24094 := by
  intro p hp
  have h : env24094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24093_24094 : H12AffineEnvironment.transform 16 79298 env24093 = env24094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env24093 == env24094) = true)

theorem identity24094 : scanCanonicalize (H12AffineFastState.compose env24094 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8402) := by decide +kernel

theorem selectedBound24094 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env24095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8402,5392,10280,1024,8541,4113,248,153,138,8328,64,10589,5528,4313,2557,1420,112,256,33,5592,648]

theorem envBound24095 : H12AffineFastState.Bounded env24095 := by
  intro p hp
  have h : env24095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24094_24095 : H12AffineEnvironment.transform 15 8402 env24094 = env24095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8402 env24094 == env24095) = true)

theorem identity24095 : scanCanonicalize (H12AffineFastState.compose env24095 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24095 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,80,478,5392,2340,1024,81,4113,248,153,138,388,64,2129,5528,4313,2557,1420,112,256,33,5592,648]

theorem envBound24096 : H12AffineFastState.Bounded env24096 := by
  intro p hp
  have h : env24096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24095_24096 : H12AffineEnvironment.transform 12 268 env24095 = env24096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24095 == env24096) = true)

theorem identity24096 : scanCanonicalize (H12AffineFastState.compose env24096 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24096 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,342,5392,2340,1024,81,4113,112,17,2,268,64,2129,5392,4177,2421,1284,112,256,33,5456,512]

theorem envBound24097 : H12AffineFastState.Bounded env24097 := by
  intro p hp
  have h : env24097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24096_24097 : H12AffineEnvironment.transform 6 8 env24096 = env24097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24096 == env24097) = true)

theorem identity24097 : scanCanonicalize (H12AffineFastState.compose env24097 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24097 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24098 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5377,80,342,5392,2309,1024,81,4113,81,17,2,268,64,2129,5392,4177,2388,1284,81,256,0,5456,512]

theorem envBound24098 : H12AffineFastState.Bounded env24098 := by
  intro p hp
  have h : env24098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24097_24098 : H12AffineEnvironment.transform 4 1 env24097 = env24098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24097 == env24098) = true)

theorem identity24098 : scanCanonicalize (H12AffineFastState.compose env24098 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24098 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env24099 : List Nat := [2,4,8,16,1,64,8,5,512,1024,2048,4096,9,5124,80,83,5141,2048,1024,81,4113,81,17,2,9,64,2129,5141,4177,2129,1025,81,5,0,5205,512]

theorem envBound24099 : H12AffineFastState.Bounded env24099 := by
  intro p hp
  have h : env24099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24098_24099 : H12AffineEnvironment.transform 7 5 env24098 = env24099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24098 == env24099) = true)

def env24100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115870,119926,62660,41430,8328,64,158028,57797,91402,138476,119043,120062,256,21792,46212,63189]

theorem envBound24100 : H12AffineFastState.Bounded env24100 := by
  intro p hp
  have h : env24100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24086_24100 : H12AffineEnvironment.transform 17 10281 env24086 = env24100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24086 == env24100) = true)

def env24101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102814,98678,41412,41430,8328,64,146508,46277,77834,138476,99331,98814,256,32,46212,41941]

theorem envBound24101 : H12AffineFastState.Bounded env24101 := by
  intro p hp
  have h : env24101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24100_24101 : H12AffineEnvironment.transform 13 5376 env24100 = env24101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24100 == env24101) = true)

theorem identity24101 : scanCanonicalize (H12AffineFastState.compose env24101 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound24101 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env24102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,79131,10281,1024,32769,102814,98678,41412,41430,8328,64,67927,46277,77834,76279,99331,98814,256,32,46212,41941]

theorem envBound24102 : H12AffineFastState.Bounded env24102 := by
  intro p hp
  have h : env24102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24101_24102 : H12AffineEnvironment.transform 16 79131 env24101 = env24102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env24101 == env24102) = true)

theorem identity24102 : scanCanonicalize (H12AffineFastState.compose env24102 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24102 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env24103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1124,65536,79131,10281,1024,1125,71162,66834,9632,9650,8328,64,67927,12449,77834,76279,65639,66970,256,32,12512,10161]

theorem envBound24103 : H12AffineFastState.Bounded env24103 := by
  intro p hp
  have h : env24103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24102_24103 : H12AffineEnvironment.transform 14 1124 env24102 = env24103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env24102 == env24103) = true)

theorem identity24103 : scanCanonicalize (H12AffineFastState.compose env24103 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,19,20,32] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound24103 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,19,20,32] rootPS < 2^1333 := by decide +kernel

def env24104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1124,8494,5173,10281,1024,1125,13524,9276,9632,9650,8328,64,10361,12449,4388,2265,8521,9396,256,32,12512,10161]

theorem envBound24104 : H12AffineFastState.Bounded env24104 := by
  intro p hp
  have h : env24104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24103_24104 : H12AffineEnvironment.transform 15 8494 env24103 = env24104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env24103 == env24104) = true)

theorem identity24104 : scanCanonicalize (H12AffineFastState.compose env24104 (packedSelected [3,4,5,6,9,10,11,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 440) := by decide +kernel

theorem selectedBound24104 : packedSelected [3,4,5,6,9,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env24105 : List Nat := [2,4,8,16,32,64,128,256,512,440,2048,4096,8192,4280,476,8494,4493,10281,440,477,12652,8580,8216,8202,8328,64,10361,12449,4388,2265,8521,8460,256,32,12512,8713]

theorem envBound24105 : H12AffineFastState.Bounded env24105 := by
  intro p hp
  have h : env24105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24104_24105 : H12AffineEnvironment.transform 9 440 env24104 = env24105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 440 env24104 == env24105) = true)

theorem identity24105 : scanCanonicalize (H12AffineFastState.compose env24105 (packedSelected [0,3,5,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound24105 : packedSelected [0,3,5,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env24106 : List Nat := [2,4,8,16,32,64,128,256,512,440,2048,4096,128,4280,476,430,4493,2217,440,477,4588,260,152,138,8,64,2297,4129,4388,2265,457,396,256,32,4192,649]

theorem envBound24106 : H12AffineFastState.Bounded env24106 := by
  intro p hp
  have h : env24106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24105_24106 : H12AffineEnvironment.transform 12 128 env24105 = env24106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env24105 == env24106) = true)

theorem identity24106 : scanCanonicalize (H12AffineFastState.compose env24106 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24106 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env24107 : List Nat := [2,4,8,16,0,64,128,256,512,408,2048,4096,128,4248,476,398,4493,2185,408,477,4556,260,152,138,8,64,2265,4097,4356,2265,457,396,256,0,4160,649]

theorem envBound24107 : H12AffineFastState.Bounded env24107 := by
  intro p hp
  have h : env24107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24106_24107 : H12AffineEnvironment.transform 4 0 env24106 = env24107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24106 == env24107) = true)

theorem identity24107 : scanCanonicalize (H12AffineFastState.compose env24107 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound24107 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24108 : List Nat := [2,4,8,16,0,64,128,256,512,408,2048,2249,128,2129,476,398,2372,2185,408,477,2309,260,152,138,8,64,2265,2248,2509,2265,457,396,256,0,2185,649]

theorem envBound24108 : H12AffineFastState.Bounded env24108 := by
  intro p hp
  have h : env24108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24107_24108 : H12AffineEnvironment.transform 11 2249 env24107 = env24108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env24107 == env24108) = true)

theorem identity24108 : scanCanonicalize (H12AffineFastState.compose env24108 (packedSelected [0,6,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24108 : packedSelected [0,6,7,12] rootPS < 2^1333 := by decide +kernel

def env24109 : List Nat := [2,4,8,16,0,16,128,256,512,408,2048,2201,128,2049,396,398,2324,2185,408,397,2309,260,152,138,8,16,2185,2200,2461,2185,409,396,256,0,2185,649]

theorem envBound24109 : H12AffineFastState.Bounded env24109 := by
  intro p hp
  have h : env24109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24108_24109 : H12AffineEnvironment.transform 5 16 env24108 = env24109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24108 == env24109) = true)

theorem identity24109 : scanCanonicalize (H12AffineFastState.compose env24109 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound24109 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env24110 : List Nat := [2,4,8,16,0,16,128,141,512,21,2048,2201,128,2049,1,3,2201,2185,21,0,2184,137,152,138,8,16,2185,2200,2064,2185,20,1,141,0,2185,649]

theorem envBound24110 : H12AffineFastState.Bounded env24110 := by
  intro p hp
  have h : env24110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24109_24110 : H12AffineEnvironment.transform 7 141 env24109 = env24110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env24109 == env24110) = true)

theorem identity24110 : scanCanonicalize (H12AffineFastState.compose env24110 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24110 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24111 : List Nat := [2,4,8,16,0,16,128,141,512,21,0,153,128,1,1,3,153,137,21,0,136,137,152,138,8,16,137,152,16,137,20,1,141,0,137,649]

theorem envBound24111 : H12AffineFastState.Bounded env24111 := by
  intro p hp
  have h : env24111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24110_24111 : H12AffineEnvironment.transform 10 0 env24110 = env24111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24110 == env24111) = true)

theorem identity24111 : scanCanonicalize (H12AffineFastState.compose env24111 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24111 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24112 : List Nat := [2,4,8,16,0,16,8,5,512,21,0,17,8,1,1,3,17,1,21,0,0,1,16,2,8,16,1,16,16,1,20,1,5,0,1,513]

theorem envBound24112 : H12AffineFastState.Bounded env24112 := by
  intro p hp
  have h : env24112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24111_24112 : H12AffineEnvironment.transform 6 8 env24111 = env24112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24111 == env24112) = true)

def env24113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102815,98679,41413,41430,8328,64,146509,46276,77835,138476,99330,98815,256,33,46212,41940]

theorem envBound24113 : H12AffineFastState.Bounded env24113 := by
  intro p hp
  have h : env24113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24100_24113 : H12AffineEnvironment.transform 13 5377 env24100 = env24113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24100 == env24113) = true)

theorem identity24113 : scanCanonicalize (H12AffineFastState.compose env24113 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24113 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,98679,41292,41311,8193,64,146509,46157,77835,138341,99330,98678,256,33,46093,41821]

theorem envBound24114 : H12AffineFastState.Bounded env24114 := by
  intro p hp
  have h : env24114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24113_24114 : H12AffineEnvironment.transform 6 9 env24113 = env24114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24113 == env24114) = true)

theorem identity24114 : scanCanonicalize (H12AffineFastState.compose env24114 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound24114 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103494,10281,1024,32769,102678,98679,41292,41311,8193,64,108555,46157,77835,100387,99330,98678,256,33,46093,41821]

theorem envBound24115 : H12AffineFastState.Bounded env24115 := by
  intro p hp
  have h : env24115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24114_24115 : H12AffineEnvironment.transform 16 103494 env24114 = env24115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env24114 == env24115) = true)

theorem identity24115 : scanCanonicalize (H12AffineFastState.compose env24115 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24115 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5392,10281,1024,32769,4160,33,41292,41311,8193,64,10589,46157,45405,2421,1364,32,256,33,46093,41821]

theorem envBound24116 : H12AffineFastState.Bounded env24116 := by
  intro p hp
  have h : env24116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24115_24116 : H12AffineEnvironment.transform 15 33110 env24115 = env24116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24115 == env24116) = true)

theorem identity24116 : scanCanonicalize (H12AffineFastState.compose env24116 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24116 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24117 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,32768,33110,4096,10281,272,32769,4160,33,41292,41311,8193,64,10589,45405,45405,2421,68,32,256,33,45341,41821]

theorem envBound24117 : H12AffineFastState.Bounded env24117 := by
  intro p hp
  have h : env24117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24116_24117 : H12AffineEnvironment.transform 9 272 env24116 = env24117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24116 == env24117) = true)

theorem identity24117 : scanCanonicalize (H12AffineFastState.compose env24117 (packedSelected [4,6,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound24117 : packedSelected [4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env24118 : List Nat := [2,4,8,16,32,64,9,256,512,272,113,4096,8192,4113,32768,33110,4096,8280,272,32769,4160,33,41292,41311,8193,64,8492,45405,45405,260,68,32,256,33,45341,41821]

theorem envBound24118 : H12AffineFastState.Bounded env24118 := by
  intro p hp
  have h : env24118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24117_24118 : H12AffineEnvironment.transform 10 113 env24117 = env24118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env24117 == env24118) = true)

theorem identity24118 : scanCanonicalize (H12AffineFastState.compose env24118 (packedSelected [1,2,3,5,8,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 12361) := by decide +kernel

theorem selectedBound24118 : packedSelected [1,2,3,5,8,12,14] rootPS < 2^1333 := by decide +kernel

def env24119 : List Nat := [2,4,8,16,32,64,9,256,512,272,113,4096,8192,4113,12361,12575,4096,8280,272,12360,4160,33,4357,4374,8193,64,8492,276,276,260,68,32,256,33,340,4884]

theorem envBound24119 : H12AffineFastState.Bounded env24119 := by
  intro p hp
  have h : env24119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24118_24119 : H12AffineEnvironment.transform 14 12361 env24118 = env24119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12361 env24118 == env24119) = true)

theorem identity24119 : scanCanonicalize (H12AffineFastState.compose env24119 (packedSelected [0,1,3,5,6,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound24119 : packedSelected [0,1,3,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env24120 : List Nat := [2,4,8,16,32,64,9,256,512,272,113,4096,380,4113,4405,4195,4096,292,272,4404,4160,33,4357,4374,381,64,80,276,276,260,68,32,256,33,340,4884]

theorem envBound24120 : H12AffineFastState.Bounded env24120 := by
  intro p hp
  have h : env24120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24119_24120 : H12AffineEnvironment.transform 12 380 env24119 = env24120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env24119 == env24120) = true)

theorem identity24120 : scanCanonicalize (H12AffineFastState.compose env24120 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound24120 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24121 : List Nat := [2,4,8,16,32,64,9,256,512,272,113,324,380,341,113,295,324,292,272,112,260,33,65,82,381,64,80,276,276,260,68,32,256,33,340,592]

theorem envBound24121 : H12AffineFastState.Bounded env24121 := by
  intro p hp
  have h : env24121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24120_24121 : H12AffineEnvironment.transform 11 324 env24120 = env24121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env24120 == env24121) = true)

theorem identity24121 : scanCanonicalize (H12AffineFastState.compose env24121 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24121 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24122 : List Nat := [2,4,8,16,32,48,9,256,512,272,1,308,268,293,1,295,308,292,272,0,260,33,49,34,269,48,32,276,276,260,52,32,256,33,292,544]

theorem envBound24122 : H12AffineFastState.Bounded env24122 := by
  intro p hp
  have h : env24122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24121_24122 : H12AffineEnvironment.transform 5 48 env24121 = env24122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24121 == env24122) = true)

def env24123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62661,2188616,8328,64,6705548,57797,2138517,406724,2102684,4194440,256,21793,46213,2175562]

theorem envBound24123 : H12AffineFastState.Bounded env24123 := by
  intro p hp
  have h : env24123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24024_24123 : H12AffineEnvironment.transform 22 62661 env24024 = env24123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env24024 == env24123) = true)

def env24124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62661,2188616,8328,64,158028,57797,2138517,406724,2102684,2373704,256,21793,46213,2175562]

theorem envBound24124 : H12AffineFastState.Bounded env24124 := by
  intro p hp
  have h : env24124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24123_24124 : H12AffineEnvironment.transform 21 2373824 env24123 = env24124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env24123 == env24124) = true)

theorem identity24124 : scanCanonicalize (H12AffineFastState.compose env24124 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24124 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,2373824,16,2188616,8328,64,158028,5392,2118976,406724,2102684,2373704,256,21793,16464,2175562]

theorem envBound24125 : H12AffineFastState.Bounded env24125 := by
  intro p hp
  have h : env24125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24124_24125 : H12AffineEnvironment.transform 14 29909 env24124 = env24125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24124 == env24125) = true)

def env24126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,2373824,16,2175048,8328,64,146508,5392,2097216,406724,2102684,2373704,256,33,5456,2175562]

theorem envBound24126 : H12AffineFastState.Bounded env24126 := by
  intro p hp
  have h : env24126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24125_24126 : H12AffineEnvironment.transform 13 5376 env24125 = env24126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24125 == env24126) = true)

theorem identity24126 : scanCanonicalize (H12AffineFastState.compose env24126 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound24126 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,78018,329730,16,138,8328,64,146508,5392,77954,406724,75102,329866,256,33,5456,648]

theorem envBound24127 : H12AffineFastState.Bounded env24127 := by
  intro p hp
  have h : env24127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24126_24127 : H12AffineEnvironment.transform 20 78018 env24126 = env24127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env24126 == env24127) = true)

theorem identity24127 : scanCanonicalize (H12AffineFastState.compose env24127 (packedSelected [2,6,7,9,11,18,20,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound24127 : packedSelected [2,6,7,9,11,18,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env24128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,67618,1024,8660,78018,32,16,138,8328,64,146508,5392,77954,212198,75102,168,256,33,5456,648]

theorem envBound24128 : H12AffineFastState.Bounded env24128 := by
  intro p hp
  have h : env24128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24127_24128 : H12AffineEnvironment.transform 17 67618 env24127 = env24128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env24127 == env24128) = true)

theorem identity24128 : scanCanonicalize (H12AffineFastState.compose env24128 (packedSelected [3,4,5,6,7,8,9,10,11,14,16,18,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5325) := by decide +kernel

theorem selectedBound24128 : packedSelected [3,4,5,6,7,8,9,10,11,14,16,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env24129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5325,67618,1024,8660,78018,32,16,138,8328,64,10369,5392,77954,75819,75102,168,256,33,5456,648]

theorem envBound24129 : H12AffineFastState.Bounded env24129 := by
  intro p hp
  have h : env24129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24128_24129 : H12AffineEnvironment.transform 16 5325 env24128 = env24129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5325 env24128 == env24129) = true)

theorem identity24129 : scanCanonicalize (H12AffineFastState.compose env24129 (packedSelected [0,1,3,5,6,8,10,11,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound24129 : packedSelected [0,1,3,5,6,8,10,11,18,19,27] rootPS < 2^1333 := by decide +kernel

def env24130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8662,5325,10740,1024,8660,4372,32,16,138,8328,64,10369,5392,4436,2557,1160,168,256,33,5456,648]

theorem envBound24130 : H12AffineFastState.Bounded env24130 := by
  intro p hp
  have h : env24130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24129_24130 : H12AffineEnvironment.transform 15 8662 env24129 = env24130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env24129 == env24130) = true)

theorem identity24130 : scanCanonicalize (H12AffineFastState.compose env24130 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24130 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8543,5188,10621,1024,8541,4372,32,16,3,8193,64,10248,5392,4436,2420,1025,33,256,33,5456,513]

theorem envBound24131 : H12AffineFastState.Bounded env24131 := by
  intro p hp
  have h : env24131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24130_24131 : H12AffineEnvironment.transform 6 9 env24130 = env24131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24130 == env24131) = true)

theorem identity24131 : scanCanonicalize (H12AffineFastState.compose env24131 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24131 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24132 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5205,8201,8202,5188,10280,1024,8200,4161,32,16,3,8193,64,10248,5189,4097,2081,1025,33,85,33,5125,513]

theorem envBound24132 : H12AffineFastState.Bounded env24132 := by
  intro p hp
  have h : env24132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24131_24132 : H12AffineEnvironment.transform 7 85 env24131 = env24132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24131 == env24132) = true)

theorem identity24132 : scanCanonicalize (H12AffineFastState.compose env24132 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24132 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24133 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8201,8202,5141,10280,1024,8200,4112,32,16,3,8193,17,10248,5140,4097,2081,1025,33,4,33,5125,513]

theorem envBound24133 : H12AffineFastState.Bounded env24133 := by
  intro p hp
  have h : env24133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24132_24133 : H12AffineEnvironment.transform 5 17 env24132 = env24133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24132 == env24133) = true)

theorem identity24133 : scanCanonicalize (H12AffineFastState.compose env24133 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24133 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24134 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5124,32,35,5141,2049,1024,33,4112,32,16,3,40,17,2081,5140,4097,2081,1025,33,4,33,5125,513]

theorem envBound24134 : H12AffineFastState.Bounded env24134 := by
  intro p hp
  have h : env24134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24133_24134 : H12AffineEnvironment.transform 12 41 env24133 = env24134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24133 == env24134) = true)

theorem identity24134 : scanCanonicalize (H12AffineFastState.compose env24134 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24134 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24135 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1045,4096,41,5124,32,35,5141,1044,1024,33,4112,32,16,3,40,17,1076,5140,4097,1076,1025,33,4,33,5125,513]

theorem envBound24135 : H12AffineFastState.Bounded env24135 := by
  intro p hp
  have h : env24135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24134_24135 : H12AffineEnvironment.transform 10 1045 env24134 = env24135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env24134 == env24135) = true)

theorem identity24135 : scanCanonicalize (H12AffineFastState.compose env24135 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound24135 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24136 : List Nat := [2,4,8,16,32,17,9,4,32,1024,1045,4096,41,5124,32,35,5141,1044,1024,33,4112,32,16,3,40,17,1076,5140,4097,1076,1025,33,4,33,5125,33]

theorem envBound24136 : H12AffineFastState.Bounded env24136 := by
  intro p hp
  have h : env24136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24135_24136 : H12AffineEnvironment.transform 8 32 env24135 = env24136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env24135 == env24136) = true)

def env24137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,2373824,16,2175049,8328,64,146509,5392,2097217,406724,2102684,2373704,256,32,5457,2175562]

theorem envBound24137 : H12AffineFastState.Bounded env24137 := by
  intro p hp
  have h : env24137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24125_24137 : H12AffineEnvironment.transform 13 5377 env24125 = env24137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24125 == env24137) = true)

theorem identity24137 : scanCanonicalize (H12AffineFastState.compose env24137 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound24137 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,77899,329867,16,2,8328,64,146509,5392,77834,406724,75223,329731,256,32,5457,513]

theorem envBound24138 : H12AffineFastState.Bounded env24138 := by
  intro p hp
  have h : env24138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24137_24138 : H12AffineEnvironment.transform 20 77899 env24137 = env24138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env24137 == env24138) = true)

def env24139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,329731,16,2,8192,64,146509,5392,77834,406604,75103,329731,256,32,5457,513]

theorem envBound24139 : H12AffineFastState.Bounded env24139 := by
  intro p hp
  have h : env24139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24138_24139 : H12AffineEnvironment.transform 6 8 env24138 = env24139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24138 == env24139) = true)

theorem identity24139 : scanCanonicalize (H12AffineFastState.compose env24139 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound24139 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,131072,262144,1024,8541,5457,273689,16,2,8192,64,146509,5392,5392,406604,69,273689,256,32,5457,513]

theorem envBound24140 : H12AffineFastState.Bounded env24140 := by
  intro p hp
  have h : env24140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24139_24140 : H12AffineEnvironment.transform 15 9498 env24139 = env24140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env24139 == env24140) = true)

theorem identity24140 : scanCanonicalize (H12AffineFastState.compose env24140 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound24140 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env24141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,4096,262144,1024,8541,5457,273689,16,2,8192,64,11341,5392,5392,271436,69,273689,256,32,5457,513]

theorem envBound24141 : H12AffineFastState.Bounded env24141 := by
  intro p hp
  have h : env24141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24140_24141 : H12AffineEnvironment.transform 16 4096 env24140 = env24141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env24140 == env24141) = true)

theorem identity24141 : scanCanonicalize (H12AffineFastState.compose env24141 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound24141 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,4096,11576,1024,8541,5457,33,16,2,8192,64,11341,5392,5392,2420,69,33,256,32,5457,513]

theorem envBound24142 : H12AffineFastState.Bounded env24142 := by
  intro p hp
  have h : env24142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24141_24142 : H12AffineEnvironment.transform 17 11576 env24141 = env24142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env24141 == env24142) = true)

theorem identity24142 : scanCanonicalize (H12AffineFastState.compose env24142 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound24142 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env24143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1125,35,4096,2049,1024,1124,5457,33,16,2,1337,64,2420,5392,5392,2420,69,33,256,32,5457,513]

theorem envBound24143 : H12AffineFastState.Bounded env24143 := by
  intro p hp
  have h : env24143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24142_24143 : H12AffineEnvironment.transform 12 1337 env24142 = env24143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env24142 == env24143) = true)

theorem identity24143 : scanCanonicalize (H12AffineFastState.compose env24143 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24143 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env24144 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,1132,5204,1125,35,4096,2049,1024,1124,5124,33,16,2,1132,64,2081,5189,5189,2081,69,33,85,32,5124,513]

theorem envBound24144 : H12AffineFastState.Bounded env24144 := by
  intro p hp
  have h : env24144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24143_24144 : H12AffineEnvironment.transform 7 85 env24143 = env24144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24143 == env24144) = true)

theorem identity24144 : scanCanonicalize (H12AffineFastState.compose env24144 (packedSelected [1,2,3,4,5,6,8,9,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24144 : packedSelected [1,2,3,4,5,6,8,9,18] rootPS < 2^1333 := by decide +kernel

def env24145 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,1101,5204,1092,2,4096,2049,1024,1093,5124,0,16,2,1101,64,2048,5189,5189,2048,69,0,85,1,5124,513]

theorem envBound24145 : H12AffineFastState.Bounded env24145 := by
  intro p hp
  have h : env24145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24144_24145 : H12AffineEnvironment.transform 4 1 env24144 = env24145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24144 == env24145) = true)

def env24146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,329730,16,2,8193,64,146509,5392,77834,406605,75102,329731,256,32,5457,513]

theorem envBound24146 : H12AffineFastState.Bounded env24146 := by
  intro p hp
  have h : env24146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24138_24146 : H12AffineEnvironment.transform 6 9 env24138 = env24146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24138 == env24146) = true)

theorem identity24146 : scanCanonicalize (H12AffineFastState.compose env24146 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound24146 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env24147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70726,262144,1024,8540,77899,329730,16,2,8193,64,75787,5392,77834,335883,75102,329731,256,32,5457,513]

theorem envBound24147 : H12AffineFastState.Bounded env24147 := by
  intro p hp
  have h : env24147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24146_24147 : H12AffineEnvironment.transform 16 70726 env24146 = env24147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env24146 == env24147) = true)

theorem identity24147 : scanCanonicalize (H12AffineFastState.compose env24147 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound24147 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70726,10281,1024,8540,77899,73771,16,2,8193,64,75787,5392,77834,67618,75102,73770,256,32,5457,513]

theorem envBound24148 : H12AffineFastState.Bounded env24148 := by
  intro p hp
  have h : env24148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24147_24148 : H12AffineEnvironment.transform 17 10281 env24147 = env24148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24147 == env24148) = true)

theorem identity24148 : scanCanonicalize (H12AffineFastState.compose env24148 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound24148 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,1094,4096,10281,1024,8540,13325,9325,16,2,8193,64,11341,5392,13388,3172,8472,9324,256,32,5457,513]

theorem envBound24149 : H12AffineFastState.Bounded env24149 := by
  intro p hp
  have h : env24149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24148_24149 : H12AffineEnvironment.transform 15 1094 env24148 = env24149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env24148 == env24149) = true)

theorem identity24149 : scanCanonicalize (H12AffineFastState.compose env24149 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound24149 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6476,5377,6161,1094,4096,4453,1024,6160,3393,7457,16,2,6477,64,5377,5392,3328,3172,6228,7456,256,32,5457,513]

theorem envBound24150 : H12AffineFastState.Bounded env24150 := by
  intro p hp
  have h : env24150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24149_24150 : H12AffineEnvironment.transform 12 6476 env24149 = env24150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env24149 == env24150) = true)

theorem identity24150 : scanCanonicalize (H12AffineFastState.compose env24150 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound24150 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env24151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,3149,0,3344,1094,1281,1124,1024,3345,3393,2080,16,2,3148,64,0,17,3328,3172,3413,2081,256,32,80,513]

theorem envBound24151 : H12AffineFastState.Bounded env24151 := by
  intro p hp
  have h : env24151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24150_24151 : H12AffineEnvironment.transform 11 1281 env24150 = env24151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env24150 == env24151) = true)

theorem identity24151 : scanCanonicalize (H12AffineFastState.compose env24151 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound24151 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24152 : List Nat := [2,4,8,16,32,64,9,256,512,769,2048,512,2892,0,2577,839,512,869,769,2576,2624,2080,16,2,2893,64,0,17,2561,2917,2644,2081,256,32,80,513]

theorem envBound24152 : H12AffineFastState.Bounded env24152 := by
  intro p hp
  have h : env24152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24151_24152 : H12AffineEnvironment.transform 9 769 env24151 = env24152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env24151 == env24152) = true)

theorem identity24152 : scanCanonicalize (H12AffineFastState.compose env24152 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound24152 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env24153 : List Nat := [2,4,8,16,32,64,9,256,512,769,81,512,797,0,576,839,512,869,769,577,529,113,16,2,796,64,0,17,592,820,517,112,256,32,80,513]

theorem envBound24153 : H12AffineFastState.Bounded env24153 := by
  intro p hp
  have h : env24153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24152_24153 : H12AffineEnvironment.transform 10 81 env24152 = env24153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24152 == env24153) = true)

theorem identity24153 : scanCanonicalize (H12AffineFastState.compose env24153 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24153 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24154 : List Nat := [2,4,8,16,32,64,9,4,512,517,81,512,537,0,576,579,512,609,517,577,529,113,16,2,536,64,0,17,592,560,517,112,4,32,80,513]

theorem envBound24154 : H12AffineFastState.Bounded env24154 := by
  intro p hp
  have h : env24154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24153_24154 : H12AffineEnvironment.transform 7 4 env24153 = env24154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24153 == env24154) = true)

theorem identity24154 : scanCanonicalize (H12AffineFastState.compose env24154 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24154 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24155 : List Nat := [2,4,8,1,32,64,9,4,512,517,64,512,520,0,576,579,512,609,517,577,512,96,1,2,521,64,0,0,577,545,517,97,4,32,65,513]

theorem envBound24155 : H12AffineFastState.Bounded env24155 := by
  intro p hp
  have h : env24155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24154_24155 : H12AffineEnvironment.transform 3 1 env24154 = env24155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24154 == env24155) = true)

theorem identity24155 : scanCanonicalize (H12AffineFastState.compose env24155 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound24155 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env24156 : List Nat := [2,4,8,1,32,64,9,4,65,68,64,65,73,0,1,2,65,32,68,0,65,96,1,2,72,64,0,0,0,96,68,97,4,32,65,64]

theorem envBound24156 : H12AffineFastState.Bounded env24156 := by
  intro p hp
  have h : env24156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24155_24156 : H12AffineEnvironment.transform 8 65 env24155 = env24156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env24155 == env24156) = true)

theorem identity24156 : scanCanonicalize (H12AffineFastState.compose env24156 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound24156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24157 : List Nat := [2,4,8,1,32,0,9,4,1,4,0,1,9,0,1,2,1,32,4,0,1,32,1,2,8,0,0,0,0,32,4,33,4,32,1,0]

theorem envBound24157 : H12AffineFastState.Bounded env24157 := by
  intro p hp
  have h : env24157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24156_24157 : H12AffineEnvironment.transform 5 0 env24156 = env24157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env24156 == env24157) = true)

def env24158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62661,2188616,8328,64,158029,57797,2138517,406724,2102684,2373705,256,21793,46213,2175562]

theorem envBound24158 : H12AffineFastState.Bounded env24158 := by
  intro p hp
  have h : env24158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24123_24158 : H12AffineEnvironment.transform 21 2373825 env24123 = env24158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env24123 == env24158) = true)

theorem identity24158 : scanCanonicalize (H12AffineFastState.compose env24158 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound24158 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329866,62661,21763,8328,64,158029,57797,102878,406724,75223,329730,256,21793,46213,513]

theorem envBound24159 : H12AffineFastState.Bounded env24159 := by
  intro p hp
  have h : env24159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24158_24159 : H12AffineEnvironment.transform 20 77899 env24158 = env24159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env24158 == env24159) = true)

def env24160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329730,62541,21763,8192,64,158029,57677,102742,406604,75103,329730,256,21793,46093,513]

theorem envBound24160 : H12AffineFastState.Bounded env24160 := by
  intro p hp
  have h : env24160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24159_24160 : H12AffineEnvironment.transform 6 8 env24159 = env24160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24159 == env24160) = true)

theorem identity24160 : scanCanonicalize (H12AffineFastState.compose env24160 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24160 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,77899,329730,62541,21763,8192,64,67926,57677,102742,349271,75103,329730,256,21793,46093,513]

theorem envBound24161 : H12AffineFastState.Bounded env24161 := by
  intro p hp
  have h : env24161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24160_24161 : H12AffineEnvironment.transform 16 90139 env24160 = env24161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24160 == env24161) = true)

def env24162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77899,73770,62541,21763,8192,64,67926,57677,102742,97407,75103,73770,256,21793,46093,513]

theorem envBound24162 : H12AffineFastState.Bounded env24162 := by
  intro p hp
  have h : env24162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24161_24162 : H12AffineEnvironment.transform 17 10280 env24161 = env24162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24161 == env24162) = true)

theorem identity24162 : scanCanonicalize (H12AffineFastState.compose env24162 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24162 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1024,29788,77899,73770,16,21763,8192,64,67926,5392,91403,97407,75103,73770,256,21793,16464,513]

theorem envBound24163 : H12AffineFastState.Bounded env24163 := by
  intro p hp
  have h : env24163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24162_24163 : H12AffineEnvironment.transform 14 29789 env24162 = env24163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24162 == env24163) = true)

theorem identity24163 : scanCanonicalize (H12AffineFastState.compose env24163 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31791) := by decide +kernel

theorem selectedBound24163 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,31791,7220,10280,1024,29788,19556,23557,16,21763,8192,64,30073,5392,6436,80,22896,23557,256,21793,16464,513]

theorem envBound24164 : H12AffineFastState.Bounded env24164 := by
  intro p hp
  have h : env24164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24163_24164 : H12AffineEnvironment.transform 15 31791 env24163 = env24164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31791 env24163 == env24164) = true)

theorem identity24164 : scanCanonicalize (H12AffineFastState.compose env24164 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24164 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,10542,7220,10280,1024,8541,6501,2308,16,2,8192,64,8312,5392,6436,80,3185,2308,256,32,5457,513]

theorem envBound24165 : H12AffineFastState.Bounded env24165 := by
  intro p hp
  have h : env24165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24164_24165 : H12AffineEnvironment.transform 13 5377 env24164 = env24165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24164 == env24165) = true)

theorem identity24165 : scanCanonicalize (H12AffineFastState.compose env24165 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 3432) := by decide +kernel

theorem selectedBound24165 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3432,5377,3124,1094,7220,1344,1024,3125,6501,2308,16,2,3432,64,3344,5392,6436,80,3185,2308,256,32,5457,513]

theorem envBound24166 : H12AffineFastState.Bounded env24166 := by
  intro p hp
  have h : env24166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24165_24166 : H12AffineEnvironment.transform 12 3432 env24165 = env24166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3432 env24165 == env24166) = true)

theorem identity24166 : scanCanonicalize (H12AffineFastState.compose env24166 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound24166 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env24167 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,2316,4453,2128,34,6224,292,100,2129,6501,2308,16,2,2316,64,2420,4468,6436,80,2069,2308,256,32,4405,513]

theorem envBound24167 : H12AffineFastState.Bounded env24167 := by
  intro p hp
  have h : env24167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24166_24167 : H12AffineEnvironment.transform 9 100 env24166 = env24167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env24166 == env24167) = true)

theorem identity24167 : scanCanonicalize (H12AffineFastState.compose env24167 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound24167 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24168 : List Nat := [2,4,8,16,32,64,8,256,512,100,80,4096,348,4453,0,34,4096,292,100,1,4405,340,16,2,348,64,292,4468,4468,80,69,340,256,32,4405,513]

theorem envBound24168 : H12AffineFastState.Bounded env24168 := by
  intro p hp
  have h : env24168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24167_24168 : H12AffineEnvironment.transform 10 80 env24167 = env24168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24167 == env24168) = true)

theorem identity24168 : scanCanonicalize (H12AffineFastState.compose env24168 (packedSelected [3,4] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound24168 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env24169 : List Nat := [2,4,8,16,32,64,8,256,512,100,80,373,348,16,0,34,373,292,100,1,64,340,16,2,348,64,292,1,1,80,69,340,256,32,64,513]

theorem envBound24169 : H12AffineFastState.Bounded env24169 := by
  intro p hp
  have h : env24169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24168_24169 : H12AffineEnvironment.transform 11 373 env24168 = env24169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env24168 == env24169) = true)

theorem identity24169 : scanCanonicalize (H12AffineFastState.compose env24169 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24169 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24170 : List Nat := [2,4,8,16,32,16,8,256,512,52,0,293,268,16,0,34,293,292,52,1,16,260,16,2,268,16,292,1,1,0,21,260,256,32,16,513]

theorem envBound24170 : H12AffineFastState.Bounded env24170 := by
  intro p hp
  have h : env24170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24169_24170 : H12AffineEnvironment.transform 5 16 env24169 = env24170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24169 == env24170) = true)

theorem identity24170 : scanCanonicalize (H12AffineFastState.compose env24170 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24170 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24171 : List Nat := [2,4,8,16,1,16,8,256,512,21,0,260,268,16,0,3,260,261,21,1,16,260,16,2,268,16,261,1,1,0,21,260,256,1,16,513]

theorem envBound24171 : H12AffineFastState.Bounded env24171 := by
  intro p hp
  have h : env24171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24170_24171 : H12AffineEnvironment.transform 4 1 env24170 = env24171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24170 == env24171) = true)

theorem identity24171 : scanCanonicalize (H12AffineFastState.compose env24171 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24171 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env24172 : List Nat := [2,4,8,16,1,16,8,5,512,21,0,1,9,16,0,3,1,0,21,1,16,1,16,2,9,16,0,1,1,0,21,1,5,1,16,513]

theorem envBound24172 : H12AffineFastState.Bounded env24172 := by
  intro p hp
  have h : env24172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24171_24172 : H12AffineEnvironment.transform 7 5 env24171 = env24172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24171 == env24172) = true)

def env24173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,77899,73771,62541,21763,8192,64,67926,57677,102742,97406,75103,73771,256,21793,46093,513]

theorem envBound24173 : H12AffineFastState.Bounded env24173 := by
  intro p hp
  have h : env24173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24161_24173 : H12AffineEnvironment.transform 17 10281 env24161 = env24173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24161 == env24173) = true)

theorem identity24173 : scanCanonicalize (H12AffineFastState.compose env24173 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound24173 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28699,4096,10281,1024,32769,16464,20528,62541,21763,8192,64,31053,57677,57677,3173,21828,20528,256,21793,46093,513]

theorem envBound24174 : H12AffineFastState.Bounded env24174 := by
  intro p hp
  have h : env24174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24173_24174 : H12AffineEnvironment.transform 15 28699 env24173 = env24174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env24173 == env24174) = true)

theorem identity24174 : scanCanonicalize (H12AffineFastState.compose env24174 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24174 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10281,1024,8541,16464,20528,21777,21763,8192,64,31053,16401,16401,3173,21828,20528,256,21793,5457,513]

theorem envBound24175 : H12AffineFastState.Bounded env24175 := by
  intro p hp
  have h : env24175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24174_24175 : H12AffineEnvironment.transform 14 8540 env24174 = env24175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24174 == env24175) = true)

theorem identity24175 : scanCanonicalize (H12AffineFastState.compose env24175 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound24175 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,1344,21511,4096,3125,1024,1345,16464,20528,21777,21763,1052,64,23889,16401,16401,3173,21828,20528,256,21793,5457,513]

theorem envBound24176 : H12AffineFastState.Bounded env24176 := by
  intro p hp
  have h : env24176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24175_24176 : H12AffineEnvironment.transform 12 1052 env24175 = env24176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env24175 == env24176) = true)

theorem identity24176 : scanCanonicalize (H12AffineFastState.compose env24176 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24176 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24177 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1052,16384,1076,21511,4096,3125,1024,1077,16464,20528,21605,21623,1052,64,23589,16401,16401,3173,21552,20528,116,21589,5157,513]

theorem envBound24177 : H12AffineFastState.Bounded env24177 := by
  intro p hp
  have h : env24177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24176_24177 : H12AffineEnvironment.transform 7 116 env24176 = env24177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24176 == env24177) = true)

theorem identity24177 : scanCanonicalize (H12AffineFastState.compose env24177 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound24177 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env24178 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2064,1052,16384,1076,19479,2064,3125,1024,1077,16464,18464,19573,19559,1052,64,17461,16401,16401,3173,19488,18464,116,19525,3125,513]

theorem envBound24178 : H12AffineFastState.Bounded env24178 := by
  intro p hp
  have h : env24178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24177_24178 : H12AffineEnvironment.transform 11 2064 env24177 = env24178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env24177 == env24178) = true)

theorem identity24178 : scanCanonicalize (H12AffineFastState.compose env24178 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24178 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24179 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2064,1052,16384,1076,19479,2064,3125,1024,1077,16384,18464,19493,19511,1052,16,17461,16401,16401,3125,19488,18464,36,19477,3125,513]

theorem envBound24179 : H12AffineFastState.Bounded env24179 := by
  intro p hp
  have h : env24179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24178_24179 : H12AffineEnvironment.transform 5 16 env24178 = env24179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24178 == env24179) = true)

def env24180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329731,62540,21763,8193,64,158029,57676,102743,406605,75102,329730,256,21793,46092,513]

theorem envBound24180 : H12AffineFastState.Bounded env24180 := by
  intro p hp
  have h : env24180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24159_24180 : H12AffineEnvironment.transform 6 9 env24159 = env24180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24159 == env24180) = true)

def env24181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,73771,62540,21763,8193,64,158029,57676,102743,138341,75102,73770,256,21793,46092,513]

theorem envBound24181 : H12AffineFastState.Bounded env24181 := by
  intro p hp
  have h : env24181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24180_24181 : H12AffineEnvironment.transform 17 10280 env24180 = env24181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24180 == env24181) = true)

def env24182 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62492,21763,8193,16,157981,57628,102663,138293,75022,73770,256,21793,46092,513]

theorem envBound24182 : H12AffineFastState.Bounded env24182 := by
  intro p hp
  have h : env24182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24181_24182 : H12AffineEnvironment.transform 5 16 env24181 = env24182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24181 == env24182) = true)

theorem identity24182 : scanCanonicalize (H12AffineFastState.compose env24182 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound24182 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env24183 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,65536,131072,10280,1024,32769,77851,73771,32784,8463,8193,16,138513,38160,102663,138293,75022,73770,256,8493,46092,513]

theorem envBound24183 : H12AffineFastState.Bounded env24183 := by
  intro p hp
  have h : env24183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24182_24183 : H12AffineEnvironment.transform 13 13324 env24182 = env24183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env24182 == env24183) = true)

theorem identity24183 : scanCanonicalize (H12AffineFastState.compose env24183 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24183 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env24184 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,65536,131072,2341,1024,32769,69910,65830,32784,2,268,16,138513,38160,102663,138293,66563,65831,256,32,38145,513]

theorem envBound24184 : H12AffineFastState.Bounded env24184 := by
  intro p hp
  have h : env24184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24183_24184 : H12AffineEnvironment.transform 12 269 env24183 = env24184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24183 == env24184) = true)

theorem identity24184 : scanCanonicalize (H12AffineFastState.compose env24184 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound24184 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24185 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,65536,103447,2341,1024,32769,69910,65830,32784,2,268,16,100614,38160,102663,100386,66563,65831,256,32,38145,513]

theorem envBound24185 : H12AffineFastState.Bounded env24185 := by
  intro p hp
  have h : env24185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24184_24185 : H12AffineEnvironment.transform 16 103447 env24184 = env24185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env24184 == env24185) = true)

theorem identity24185 : scanCanonicalize (H12AffineFastState.compose env24185 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound24185 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24186 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,262,38161,2341,1024,32769,4112,32,32784,2,268,16,34816,38160,36865,35108,1285,33,256,32,38145,513]

theorem envBound24186 : H12AffineFastState.Bounded env24186 := by
  intro p hp
  have h : env24186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24185_24186 : H12AffineEnvironment.transform 15 262 env24185 = env24186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env24185 == env24186) = true)

theorem identity24186 : scanCanonicalize (H12AffineFastState.compose env24186 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound24186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24187 : List Nat := [2,4,8,16,32,16,9,256,512,37,2048,4096,269,4388,32768,262,37172,2341,37,32769,4112,32,32784,2,268,16,34816,37173,36865,35108,288,33,256,32,37156,513]

theorem envBound24187 : H12AffineFastState.Bounded env24187 := by
  intro p hp
  have h : env24187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24186_24187 : H12AffineEnvironment.transform 9 37 env24186 = env24187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env24186 == env24187) = true)

theorem identity24187 : scanCanonicalize (H12AffineFastState.compose env24187 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24187 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24188 : List Nat := [2,4,8,16,32,16,9,256,512,37,2048,4096,269,4388,0,262,4404,2341,37,1,4112,32,16,2,268,16,2048,4405,4097,2340,288,33,256,32,4388,513]

theorem envBound24188 : H12AffineFastState.Bounded env24188 := by
  intro p hp
  have h : env24188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24187_24188 : H12AffineEnvironment.transform 14 0 env24187 = env24188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24187 == env24188) = true)

theorem identity24188 : scanCanonicalize (H12AffineFastState.compose env24188 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound24188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24189 : List Nat := [2,4,8,16,32,16,9,256,512,37,2048,821,269,529,0,262,513,2341,37,1,805,32,16,2,268,16,2048,512,820,2340,288,33,256,32,529,513]

theorem envBound24189 : H12AffineFastState.Bounded env24189 := by
  intro p hp
  have h : env24189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24188_24189 : H12AffineEnvironment.transform 11 821 env24188 = env24189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env24188 == env24189) = true)

theorem identity24189 : scanCanonicalize (H12AffineFastState.compose env24189 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound24189 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24190 : List Nat := [2,4,8,16,32,16,9,256,512,37,309,821,269,529,0,262,513,16,37,1,805,32,16,2,268,16,309,512,820,17,288,33,256,32,529,513]

theorem envBound24190 : H12AffineFastState.Bounded env24190 := by
  intro p hp
  have h : env24190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24189_24190 : H12AffineEnvironment.transform 10 309 env24189 = env24190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env24189 == env24190) = true)

def env24191 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62493,21763,8193,17,157980,57629,102662,138292,75023,73770,256,21793,46092,513]

theorem envBound24191 : H12AffineFastState.Bounded env24191 := by
  intro p hp
  have h : env24191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24181_24191 : H12AffineEnvironment.transform 5 17 env24181 = env24191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24181 == env24191) = true)

theorem identity24191 : scanCanonicalize (H12AffineFastState.compose env24191 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound24191 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env24192 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,103447,10280,1024,32769,77850,73771,62493,21763,8193,17,130315,57629,102662,100387,75023,73770,256,21793,46092,513]

theorem envBound24192 : H12AffineFastState.Bounded env24192 := by
  intro p hp
  have h : env24192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24191_24192 : H12AffineEnvironment.transform 16 103447 env24191 = env24192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env24191 == env24192) = true)

theorem identity24192 : scanCanonicalize (H12AffineFastState.compose env24192 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24192 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env24193 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,65536,70678,10280,1024,0,77850,73771,29724,21763,8193,17,97546,24860,69895,67618,75023,73770,256,21793,13325,513]

theorem envBound24193 : H12AffineFastState.Bounded env24193 := by
  intro p hp
  have h : env24193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24192_24193 : H12AffineEnvironment.transform 14 1 env24192 = env24193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24192 == env24193) = true)

theorem identity24193 : scanCanonicalize (H12AffineFastState.compose env24193 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24193 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24194 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,263,5393,10280,1024,0,12573,8492,29724,21763,8193,17,31757,24860,4096,2341,9224,8493,256,21793,13325,513]

theorem envBound24194 : H12AffineFastState.Bounded env24194 := by
  intro p hp
  have h : env24194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24193_24194 : H12AffineEnvironment.transform 15 263 env24193 = env24194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24193 == env24194) = true)

theorem identity24194 : scanCanonicalize (H12AffineFastState.compose env24194 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24194 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24195 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,5393,2341,1024,0,4112,33,21777,21763,268,17,23808,16401,4096,2341,1285,32,256,21793,5376,513]

theorem envBound24195 : H12AffineFastState.Bounded env24195 := by
  intro p hp
  have h : env24195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24194_24195 : H12AffineEnvironment.transform 12 269 env24194 = env24195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24194 == env24195) = true)

theorem identity24195 : scanCanonicalize (H12AffineFastState.compose env24195 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24195 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24196 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4112,33,16,2,268,17,2049,5392,4096,2341,1285,32,256,32,5376,513]

theorem envBound24196 : H12AffineFastState.Bounded env24196 := by
  intro p hp
  have h : env24196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24195_24196 : H12AffineEnvironment.transform 13 5377 env24195 = env24196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24195 == env24196) = true)

theorem identity24196 : scanCanonicalize (H12AffineFastState.compose env24196 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound24196 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24197 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1297,269,16,1,263,0,2341,1024,0,1281,33,16,2,268,17,2049,1,1297,2341,1285,32,256,32,17,513]

theorem envBound24197 : H12AffineFastState.Bounded env24197 := by
  intro p hp
  have h : env24197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24196_24197 : H12AffineEnvironment.transform 11 1297 env24196 = env24197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24196 == env24197) = true)

theorem identity24197 : scanCanonicalize (H12AffineFastState.compose env24197 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1291) := by decide +kernel

theorem selectedBound24197 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24198 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1291,1297,269,16,1,263,0,1070,1024,0,1281,33,16,2,268,17,1290,1,1297,1070,1285,32,256,32,17,513]

theorem envBound24198 : H12AffineFastState.Bounded env24198 := by
  intro p hp
  have h : env24198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24197_24198 : H12AffineEnvironment.transform 10 1291 env24197 = env24198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1291 env24197 == env24198) = true)

theorem identity24198 : scanCanonicalize (H12AffineFastState.compose env24198 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24198 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24199 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1038,1044,8,16,1,2,0,1070,1024,0,1028,33,16,2,9,17,1039,1,1044,1070,1024,32,5,32,17,513]

theorem envBound24199 : H12AffineFastState.Bounded env24199 := by
  intro p hp
  have h : env24199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24198_24199 : H12AffineEnvironment.transform 7 5 env24198 = env24199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24198 == env24199) = true)

theorem identity24199 : scanCanonicalize (H12AffineFastState.compose env24199 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24199 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24200 : List Nat := [2,4,8,1,32,0,9,5,512,1024,1038,1029,8,1,1,2,0,1070,1024,0,1028,33,1,2,9,0,1039,1,1029,1070,1024,32,5,32,0,513]

theorem envBound24200 : H12AffineFastState.Bounded env24200 := by
  intro p hp
  have h : env24200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24199_24200 : H12AffineEnvironment.transform 3 1 env24199 = env24200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24199 == env24200) = true)

theorem identity24200 : scanCanonicalize (H12AffineFastState.compose env24200 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24200 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24201 : List Nat := [2,4,2,1,32,0,3,5,512,1024,1028,1029,2,1,1,2,0,1060,1024,0,1028,33,1,2,3,0,1029,1,1029,1060,1024,32,5,32,0,513]

theorem envBound24201 : H12AffineFastState.Bounded env24201 := by
  intro p hp
  have h : env24201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24200_24201 : H12AffineEnvironment.transform 2 2 env24200 = env24201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24200 == env24201) = true)

theorem identity24201 : scanCanonicalize (H12AffineFastState.compose env24201 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24201 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24202 : List Nat := [2,4,2,1,1,0,3,5,512,1024,1028,1029,2,1,1,2,0,1029,1024,0,1028,0,1,2,3,0,1029,1,1029,1029,1024,1,5,1,0,513]

theorem envBound24202 : H12AffineFastState.Bounded env24202 := by
  intro p hp
  have h : env24202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24201_24202 : H12AffineEnvironment.transform 4 1 env24201 = env24202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24201 == env24202) = true)

theorem identity24202 : scanCanonicalize (H12AffineFastState.compose env24202 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound24202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24203 : List Nat := [2,4,2,1,1,0,3,5,4,1024,1028,1029,2,1,1,2,0,1029,1024,0,1028,0,1,2,3,0,1029,1,1029,1029,1024,1,5,1,0,5]

theorem envBound24203 : H12AffineFastState.Bounded env24203 := by
  intro p hp
  have h : env24203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24202_24203 : H12AffineEnvironment.transform 8 4 env24202 = env24203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env24202 == env24203) = true)

def env24204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,73770,62540,21763,8193,64,158029,57676,102743,138340,75102,73771,256,21793,46092,513]

theorem envBound24204 : H12AffineFastState.Bounded env24204 := by
  intro p hp
  have h : env24204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24180_24204 : H12AffineEnvironment.transform 17 10281 env24180 = env24204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24180 == env24204) = true)

theorem identity24204 : scanCanonicalize (H12AffineFastState.compose env24204 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24204 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,77899,73770,16,21763,8193,64,158029,5392,91403,138340,75102,73771,256,21793,16464,513]

theorem envBound24205 : H12AffineFastState.Bounded env24205 := by
  intro p hp
  have h : env24205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24204_24205 : H12AffineEnvironment.transform 14 29788 env24204 = env24205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24204 == env24205) = true)

theorem identity24205 : scanCanonicalize (H12AffineFastState.compose env24205 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24205 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10281,1024,29789,77899,73770,16,21763,8193,64,67926,5392,91403,97407,75102,73771,256,21793,16464,513]

theorem envBound24206 : H12AffineFastState.Bounded env24206 := by
  intro p hp
  have h : env24206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24205_24206 : H12AffineEnvironment.transform 16 90139 env24205 = env24206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24205 == env24206) = true)

theorem identity24206 : scanCanonicalize (H12AffineFastState.compose env24206 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound24206 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,28699,4096,10281,1024,29789,16464,20529,16,21763,8193,64,31053,5392,5392,3172,21829,20528,256,21793,16464,513]

theorem envBound24207 : H12AffineFastState.Bounded env24207 := by
  intro p hp
  have h : env24207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24206_24207 : H12AffineEnvironment.transform 15 28699 env24206 = env24207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env24206 == env24207) = true)

theorem identity24207 : scanCanonicalize (H12AffineFastState.compose env24207 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound24207 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16465,17430,4096,7204,1024,16464,16464,20529,16,21763,5132,64,19776,5392,5392,3172,21829,20528,256,21793,16464,513]

theorem envBound24208 : H12AffineFastState.Bounded env24208 := by
  intro p hp
  have h : env24208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24207_24208 : H12AffineEnvironment.transform 12 5133 env24207 = env24208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env24207 == env24208) = true)

theorem identity24208 : scanCanonicalize (H12AffineFastState.compose env24208 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24208 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env24209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,1077,1124,35,4096,7204,1024,1125,1125,5124,16,4406,5132,64,2421,5392,5392,3172,4464,5125,256,4372,1125,513]

theorem envBound24209 : H12AffineFastState.Bounded env24209 := by
  intro p hp
  have h : env24209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24208_24209 : H12AffineEnvironment.transform 13 1077 env24208 = env24209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env24208 == env24209) = true)

theorem identity24209 : scanCanonicalize (H12AffineFastState.compose env24209 (packedSelected [0,1,2,3,5,7,8,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound24209 : packedSelected [0,1,2,3,5,7,8,15,18] rootPS < 2^1333 := by decide +kernel

def env24210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,4096,5133,1077,1124,35,4096,5456,1024,1125,1125,5124,16,4406,5132,64,1,5392,5392,1296,4464,5125,256,4372,1125,513]

theorem envBound24210 : H12AffineFastState.Bounded env24210 := by
  intro p hp
  have h : env24210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24209_24210 : H12AffineEnvironment.transform 10 372 env24209 = env24210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env24209 == env24210) = true)

theorem identity24210 : scanCanonicalize (H12AffineFastState.compose env24210 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound24210 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,1141,120,1077,1124,35,1141,293,1024,1125,1125,113,16,1347,121,64,1,357,357,1296,1285,112,256,1377,1125,513]

theorem envBound24211 : H12AffineFastState.Bounded env24211 := by
  intro p hp
  have h : env24211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24210_24211 : H12AffineEnvironment.transform 11 1141 env24210 = env24211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env24210 == env24211) = true)

theorem identity24211 : scanCanonicalize (H12AffineFastState.compose env24211 (packedSelected [2,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24211 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env24212 : List Nat := [2,4,8,16,32,64,9,256,512,273,372,356,120,292,373,35,356,293,273,372,372,113,16,82,121,64,1,357,357,1,20,112,256,112,372,513]

theorem envBound24212 : H12AffineFastState.Bounded env24212 := by
  intro p hp
  have h : env24212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24211_24212 : H12AffineEnvironment.transform 9 273 env24211 = env24212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24211 == env24212) = true)

theorem identity24212 : scanCanonicalize (H12AffineFastState.compose env24212 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24213 : List Nat := [2,4,8,16,32,64,9,37,512,52,81,65,120,1,80,35,65,0,52,81,81,113,16,82,121,64,1,64,64,1,20,112,37,112,81,513]

theorem envBound24213 : H12AffineFastState.Bounded env24213 := by
  intro p hp
  have h : env24213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24212_24213 : H12AffineEnvironment.transform 7 37 env24212 = env24213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24212 == env24213) = true)

theorem identity24213 : scanCanonicalize (H12AffineFastState.compose env24213 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound24213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24214 : List Nat := [2,4,8,16,32,32,9,37,512,52,49,33,24,1,48,35,33,0,52,49,49,17,16,50,25,32,1,32,32,1,20,16,37,16,49,513]

theorem envBound24214 : H12AffineFastState.Bounded env24214 := by
  intro p hp
  have h : env24214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24213_24214 : H12AffineEnvironment.transform 5 32 env24213 = env24214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env24213 == env24214) = true)

theorem identity24214 : scanCanonicalize (H12AffineFastState.compose env24214 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24214 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env24215 : List Nat := [2,4,8,16,0,0,9,5,512,20,17,1,24,1,16,3,1,0,20,17,17,17,16,18,25,0,1,0,0,1,20,16,5,16,17,513]

theorem envBound24215 : H12AffineFastState.Bounded env24215 := by
  intro p hp
  have h : env24215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24214_24215 : H12AffineEnvironment.transform 4 0 env24214 = env24215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24214 == env24215) = true)

def env24216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound24216 : H12AffineFastState.Bounded env24216 := by
  intro p hp
  have h : env24216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24022_24216 : H12AffineEnvironment.transform 18 1025 env24022 = env24216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24022 == env24216) = true)

theorem identity24216 : scanCanonicalize (H12AffineFastState.compose env24216 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262472) := by decide +kernel

theorem selectedBound24216 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,16777216,8328,64,23414216,18973836,184472,2377160,19071449,23160256,257,16990565,17014976,19015182]

theorem envBound24217 : H12AffineFastState.Bounded env24217 := by
  intro p hp
  have h : env24217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24216_24217 : H12AffineEnvironment.transform 22 2262472 env24216 = env24217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262472 env24216 == env24217) = true)

def env24218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,201796,8328,64,6705548,2265288,184472,2377160,2102685,6451588,257,21793,46212,2175562]

theorem envBound24218 : H12AffineFastState.Bounded env24218 := by
  intro p hp
  have h : env24218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24217_24218 : H12AffineEnvironment.transform 23 201796 env24217 = env24218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201796 env24217 == env24218) = true)

def env24219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603796,2098512,17664,2377160,2102685,6349852,257,21793,46212,2175562]

theorem envBound24219 : H12AffineFastState.Bounded env24219 := by
  intro p hp
  have h : env24219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24218_24219 : H12AffineEnvironment.transform 16 38296 env24218 = env24219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env24218 == env24219) = true)

def env24220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157716,2098512,17664,2377160,2102685,2411676,257,21793,46212,2175562]

theorem envBound24220 : H12AffineFastState.Bounded env24220 := by
  intro p hp
  have h : env24220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24219_24220 : H12AffineEnvironment.transform 21 272512 env24219 = env24220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24219 == env24220) = true)

theorem identity24220 : scanCanonicalize (H12AffineFastState.compose env24220 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24220 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,2097152,272512,2101328,41430,8328,64,2157716,2098512,17664,2377160,2102685,2411676,257,21793,46212,2101824]

theorem envBound24221 : H12AffineFastState.Bounded env24221 := by
  intro p hp
  have h : env24221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24220_24221 : H12AffineEnvironment.transform 15 8202 env24220 = env24221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24220 == env24221) = true)

def env24222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,2097152,272392,2101328,41310,8192,64,2157596,2098512,17664,2377024,2102549,2411540,257,21793,46092,2101824]

theorem envBound24222 : H12AffineFastState.Bounded env24222 := by
  intro p hp
  have h : env24222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24221_24222 : H12AffineEnvironment.transform 6 8 env24221 = env24222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24221 == env24222) = true)

theorem identity24222 : scanCanonicalize (H12AffineFastState.compose env24222 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound24222 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env24223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,276584,272392,272440,41310,8192,64,316532,277816,17664,32040,273789,62588,257,21793,46092,272936]

theorem envBound24223 : H12AffineFastState.Bounded env24223 := by
  intro p hp
  have h : env24223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24222_24223 : H12AffineEnvironment.transform 20 276584 env24222 = env24223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env24222 == env24223) = true)

def env24224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,2097152,272393,2101328,41311,8193,64,2157597,2098512,17664,2377025,2102548,2411541,257,21793,46093,2101824]

theorem envBound24224 : H12AffineFastState.Bounded env24224 := by
  intro p hp
  have h : env24224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24221_24224 : H12AffineEnvironment.transform 6 9 env24221 = env24224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24221 == env24224) = true)

theorem identity24224 : scanCanonicalize (H12AffineFastState.compose env24224 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound24224 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env24225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,301364,272393,297316,41311,8193,64,292137,302180,17664,56437,298016,21793,257,21793,46093,297844]

theorem envBound24225 : H12AffineFastState.Bounded env24225 := by
  intro p hp
  have h : env24225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24224_24225 : H12AffineEnvironment.transform 20 301364 env24224 = env24225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env24224 == env24225) = true)

theorem identity24225 : scanCanonicalize (H12AffineFastState.compose env24225 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound24225 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,8202,38161,262144,1025,32769,301364,272393,297316,41311,8193,64,270684,302180,4469,34816,298016,340,257,340,46093,297844]

theorem envBound24226 : H12AffineFastState.Bounded env24226 := by
  intro p hp
  have h : env24226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24225_24226 : H12AffineEnvironment.transform 13 5237 env24225 = env24226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env24225 == env24226) = true)

theorem identity24226 : scanCanonicalize (H12AffineFastState.compose env24226 (packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound24226 : packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env24227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,8202,38161,35189,1025,32769,4161,41340,17,41311,8193,64,43049,5393,4469,34816,1365,340,257,340,46093,513]

theorem envBound24227 : H12AffineFastState.Bounded env24227 := by
  intro p hp
  have h : env24227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24226_24227 : H12AffineEnvironment.transform 17 35189 env24226 = env24227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env24226 == env24227) = true)

theorem identity24227 : scanCanonicalize (H12AffineFastState.compose env24227 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound24227 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,1297,8202,4096,3172,1025,1296,4161,9325,17,9294,8193,64,11576,5393,4469,3345,1365,340,257,340,12572,513]

theorem envBound24228 : H12AffineFastState.Bounded env24228 := by
  intro p hp
  have h : env24228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24227_24228 : H12AffineEnvironment.transform 14 1297 env24227 = env24228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env24227 == env24228) = true)

theorem identity24228 : scanCanonicalize (H12AffineFastState.compose env24228 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound24228 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5237,1297,1330,4096,3172,1025,1296,4161,341,17,374,1337,64,2048,5393,4469,3345,1365,340,257,340,5156,513]

theorem envBound24229 : H12AffineFastState.Bounded env24229 := by
  intro p hp
  have h : env24229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24228_24229 : H12AffineEnvironment.transform 12 1336 env24228 = env24229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env24228 == env24229) = true)

def env24230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157717,2098512,17664,2377160,2102685,2411677,257,21793,46212,2175562]

theorem envBound24230 : H12AffineFastState.Bounded env24230 := by
  intro p hp
  have h : env24230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24219_24230 : H12AffineEnvironment.transform 21 272513 env24219 = env24230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24219 == env24230) = true)

theorem identity24230 : scanCanonicalize (H12AffineFastState.compose env24230 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound24230 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,77899,272513,73755,98780,8328,64,122078,79131,17664,357763,75222,392406,257,21793,46212,513]

theorem envBound24231 : H12AffineFastState.Bounded env24231 := by
  intro p hp
  have h : env24231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24230_24231 : H12AffineEnvironment.transform 20 77899 env24230 = env24231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env24230 == env24231) = true)

def env24232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77899,272393,73755,98644,8192,64,121942,79131,17664,357643,75102,392286,257,21793,46092,513]

theorem envBound24232 : H12AffineFastState.Bounded env24232 := by
  intro p hp
  have h : env24232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24231_24232 : H12AffineEnvironment.transform 6 8 env24231 = env24232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24231 == env24232) = true)

def env24233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,77899,33,73755,98644,8192,64,121942,79131,17664,89379,75102,119926,257,21793,46092,513]

theorem envBound24233 : H12AffineFastState.Bounded env24233 := by
  intro p hp
  have h : env24233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24232_24233 : H12AffineEnvironment.transform 17 10280 env24232 = env24233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24232 == env24233) = true)

theorem identity24233 : scanCanonicalize (H12AffineFastState.compose env24233 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24233 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env24234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,38160,2420,1025,32769,69911,33,65863,98644,348,64,121942,70727,17664,89379,66562,119926,257,21793,38224,513]

theorem envBound24234 : H12AffineFastState.Bounded env24234 := by
  intro p hp
  have h : env24234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24233_24234 : H12AffineEnvironment.transform 12 348 env24233 = env24234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24233 == env24234) = true)

theorem identity24234 : scanCanonicalize (H12AffineFastState.compose env24234 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound24234 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,16400,2420,1025,21761,69911,33,65863,87124,348,64,67926,70727,17664,89379,66562,65910,257,21793,16464,513]

theorem envBound24235 : H12AffineFastState.Bounded env24235 := by
  intro p hp
  have h : env24235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24234_24235 : H12AffineEnvironment.transform 14 21760 env24234 = env24235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env24234 == env24235) = true)

theorem identity24235 : scanCanonicalize (H12AffineFastState.compose env24235 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24235 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,5392,2420,1025,1,69911,33,65863,65876,348,64,67926,70727,4096,67619,66562,65910,257,33,5456,513]

theorem envBound24236 : H12AffineFastState.Bounded env24236 := by
  intro p hp
  have h : env24236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24235_24236 : H12AffineEnvironment.transform 13 5376 env24235 = env24236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24235 == env24236) = true)

theorem identity24236 : scanCanonicalize (H12AffineFastState.compose env24236 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound24236 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2420,1025,1,4161,33,17,2,348,64,2048,5393,4096,2421,1364,32,257,33,5456,513]

theorem envBound24237 : H12AffineFastState.Bounded env24237 := by
  intro p hp
  have h : env24237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24236_24237 : H12AffineEnvironment.transform 15 342 env24236 = env24237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env24236 == env24237) = true)

theorem identity24237 : scanCanonicalize (H12AffineFastState.compose env24237 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound24237 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2415,348,3183,0,342,3199,2420,1025,1,2350,33,17,2,348,64,2048,3198,2415,2421,1364,32,257,33,3135,513]

theorem envBound24238 : H12AffineFastState.Bounded env24238 := by
  intro p hp
  have h : env24238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24237_24238 : H12AffineEnvironment.transform 11 2415 env24237 = env24238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env24237 == env24238) = true)

theorem identity24238 : scanCanonicalize (H12AffineFastState.compose env24238 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound24238 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24239 : List Nat := [2,4,8,16,32,64,8,256,512,267,2048,2415,348,2404,0,342,2420,2420,266,1,2350,33,17,2,348,64,2048,2421,2415,2421,95,32,257,33,2356,513]

theorem envBound24239 : H12AffineFastState.Bounded env24239 := by
  intro p hp
  have h : env24239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24238_24239 : H12AffineEnvironment.transform 9 267 env24238 = env24239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env24238 == env24239) = true)

theorem identity24239 : scanCanonicalize (H12AffineFastState.compose env24239 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24239 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24240 : List Nat := [2,4,8,16,1,64,8,256,512,267,2048,2382,348,2373,0,342,2389,2389,266,1,2319,0,17,2,348,64,2048,2388,2382,2388,95,1,257,0,2325,513]

theorem envBound24240 : H12AffineFastState.Bounded env24240 := by
  intro p hp
  have h : env24240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24239_24240 : H12AffineEnvironment.transform 4 1 env24239 = env24240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24239 == env24240) = true)

theorem identity24240 : scanCanonicalize (H12AffineFastState.compose env24240 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24240 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env24241 : List Nat := [2,4,8,16,1,16,8,256,512,267,2048,2334,268,2325,0,262,2309,2309,266,1,2319,0,17,2,268,16,2048,2308,2334,2308,15,1,257,0,2325,513]

theorem envBound24241 : H12AffineFastState.Bounded env24241 := by
  intro p hp
  have h : env24241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24240_24241 : H12AffineEnvironment.transform 5 16 env24240 = env24241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24240 == env24241) = true)

theorem identity24241 : scanCanonicalize (H12AffineFastState.compose env24241 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound24241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24242 : List Nat := [2,4,8,16,1,16,8,15,512,4,2048,2065,3,2074,0,9,2058,2058,5,1,2048,0,17,2,3,16,2048,2059,2065,2059,15,1,14,0,2074,513]

theorem envBound24242 : H12AffineFastState.Bounded env24242 := by
  intro p hp
  have h : env24242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24241_24242 : H12AffineEnvironment.transform 7 15 env24241 = env24242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env24241 == env24242) = true)

theorem identity24242 : scanCanonicalize (H12AffineFastState.compose env24242 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24242 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24243 : List Nat := [2,4,8,16,1,16,8,15,16,4,2048,2065,3,2074,0,9,2058,2058,5,1,2048,0,17,2,3,16,2048,2059,2065,2059,15,1,14,0,2074,17]

theorem envBound24243 : H12AffineFastState.Bounded env24243 := by
  intro p hp
  have h : env24243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24242_24243 : H12AffineEnvironment.transform 8 16 env24242 = env24243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24242 == env24243) = true)

theorem identity24243 : scanCanonicalize (H12AffineFastState.compose env24243 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound24243 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24244 : List Nat := [2,4,8,16,1,16,8,15,16,4,27,10,3,1,0,9,17,17,5,1,27,0,17,2,3,16,27,16,10,16,15,1,14,0,1,17]

theorem envBound24244 : H12AffineFastState.Bounded env24244 := by
  intro p hp
  have h : env24244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24243_24244 : H12AffineEnvironment.transform 10 27 env24243 = env24244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env24243 == env24244) = true)

theorem identity24244 : scanCanonicalize (H12AffineFastState.compose env24244 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound24244 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24245 : List Nat := [2,3,8,16,1,16,8,8,16,3,27,10,3,1,0,9,17,17,2,1,27,0,17,2,3,16,27,16,10,16,8,1,9,0,1,17]

theorem envBound24245 : H12AffineFastState.Bounded env24245 := by
  intro p hp
  have h : env24245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24244_24245 : H12AffineEnvironment.transform 1 3 env24244 = env24245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env24244 == env24245) = true)

theorem identity24245 : scanCanonicalize (H12AffineFastState.compose env24245 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24245 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env24246 : List Nat := [2,3,8,10,1,10,8,8,10,3,1,10,3,1,0,9,11,11,2,1,1,0,11,2,3,10,1,10,10,10,8,1,9,0,1,11]

theorem envBound24246 : H12AffineFastState.Bounded env24246 := by
  intro p hp
  have h : env24246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24245_24246 : H12AffineEnvironment.transform 3 10 env24245 = env24246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24245 == env24246) = true)

theorem identity24246 : scanCanonicalize (H12AffineFastState.compose env24246 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound24246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24247 : List Nat := [2,3,0,2,1,2,0,0,2,3,1,2,3,1,0,1,3,3,2,1,1,0,3,2,3,2,1,2,2,2,0,1,1,0,1,3]

theorem envBound24247 : H12AffineFastState.Bounded env24247 := by
  intro p hp
  have h : env24247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24246_24247 : H12AffineEnvironment.transform 2 0 env24246 = env24247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env24246 == env24247) = true)

def env24248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77899,32,73755,98644,8192,64,121942,79131,17664,89378,75102,119927,257,21793,46092,513]

theorem envBound24248 : H12AffineFastState.Bounded env24248 := by
  intro p hp
  have h : env24248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24232_24248 : H12AffineEnvironment.transform 17 10281 env24232 = env24248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24232 == env24248) = true)

theorem identity24248 : scanCanonicalize (H12AffineFastState.compose env24248 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4160,32,16,41311,8192,64,64605,5392,17664,32041,1365,62588,257,21793,46092,513]

theorem envBound24249 : H12AffineFastState.Bounded env24249 := by
  intro p hp
  have h : env24249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24248_24249 : H12AffineEnvironment.transform 15 8203 env24248 = env24249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24248 == env24249) = true)

theorem identity24249 : scanCanonicalize (H12AffineFastState.compose env24249 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound24249 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,32768,3143,38160,1125,1025,32769,4160,32,16,36115,3148,64,53265,5392,17664,20837,1365,55344,257,21793,38976,513]

theorem envBound24250 : H12AffineFastState.Bounded env24250 := by
  intro p hp
  have h : env24250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24249_24250 : H12AffineEnvironment.transform 12 3148 env24249 = env24250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env24249 == env24250) = true)

theorem identity24250 : scanCanonicalize (H12AffineFastState.compose env24250 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound24250 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,21760,3143,16400,1125,1025,21761,4160,32,16,22547,3148,64,1297,5392,17664,20837,1365,3376,257,21793,19776,513]

theorem envBound24251 : H12AffineFastState.Bounded env24251 := by
  intro p hp
  have h : env24251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24250_24251 : H12AffineEnvironment.transform 14 21760 env24250 = env24251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env24250 == env24251) = true)

theorem identity24251 : scanCanonicalize (H12AffineFastState.compose env24251 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound24251 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,348,16384,21760,343,16400,1125,1025,21761,4160,32,16,21763,348,64,1297,5392,17664,20837,1365,32,257,21793,16464,513]

theorem envBound24252 : H12AffineFastState.Bounded env24252 := by
  intro p hp
  have h : env24252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24251_24252 : H12AffineEnvironment.transform 10 1296 env24251 = env24252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env24251 == env24252) = true)

theorem identity24252 : scanCanonicalize (H12AffineFastState.compose env24252 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound24252 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24253 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,4096,348,16384,20544,343,16400,293,321,20545,4160,32,16,20547,348,64,81,4176,16448,20837,21,32,257,20577,16464,513]

theorem envBound24253 : H12AffineFastState.Bounded env24253 := by
  intro p hp
  have h : env24253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24252_24253 : H12AffineEnvironment.transform 9 320 env24252 = env24253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env24252 == env24253) = true)

theorem identity24253 : scanCanonicalize (H12AffineFastState.compose env24253 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound24253 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24254 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,64,348,16384,16384,343,16400,293,321,16385,0,32,16,16387,348,64,81,16,16448,16677,21,32,257,16417,16464,513]

theorem envBound24254 : H12AffineFastState.Bounded env24254 := by
  intro p hp
  have h : env24254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24253_24254 : H12AffineEnvironment.transform 11 64 env24253 = env24254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env24253 == env24254) = true)

theorem identity24254 : scanCanonicalize (H12AffineFastState.compose env24254 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24254 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24255 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,64,120,16384,16384,115,16400,1,101,16385,0,32,16,16387,120,64,81,16,16448,16385,21,32,37,16417,16464,513]

theorem envBound24255 : H12AffineFastState.Bounded env24255 := by
  intro p hp
  have h : env24255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24254_24255 : H12AffineEnvironment.transform 7 36 env24254 = env24255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24254 == env24255) = true)

theorem identity24255 : scanCanonicalize (H12AffineFastState.compose env24255 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24255 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24256 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,16384,16384,34,16400,1,52,16385,0,32,16,16387,41,17,0,16,16401,16385,21,32,37,16417,16385,513]

theorem envBound24256 : H12AffineFastState.Bounded env24256 := by
  intro p hp
  have h : env24256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24255_24256 : H12AffineEnvironment.transform 5 17 env24255 = env24256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24255 == env24256) = true)

theorem identity24256 : scanCanonicalize (H12AffineFastState.compose env24256 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound24256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24257 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,1,1,34,17,1,52,0,0,32,16,2,41,17,0,16,16,0,21,32,37,32,0,513]

theorem envBound24257 : H12AffineFastState.Bounded env24257 := by
  intro p hp
  have h : env24257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24256_24257 : H12AffineEnvironment.transform 13 1 env24256 = env24257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env24256 == env24257) = true)

theorem identity24257 : scanCanonicalize (H12AffineFastState.compose env24257 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24258 : List Nat := [2,4,8,16,32,17,8,36,16,53,1,17,41,1,1,34,17,1,52,0,0,32,16,2,41,17,0,16,16,0,21,32,37,32,0,17]

theorem envBound24258 : H12AffineFastState.Bounded env24258 := by
  intro p hp
  have h : env24258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24257_24258 : H12AffineEnvironment.transform 8 16 env24257 = env24258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24257 == env24258) = true)

theorem identity24258 : scanCanonicalize (H12AffineFastState.compose env24258 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24259 : List Nat := [2,4,2,16,32,17,2,36,16,53,1,17,35,1,1,34,17,1,52,0,0,32,16,2,35,17,0,16,16,0,21,32,37,32,0,17]

theorem envBound24259 : H12AffineFastState.Bounded env24259 := by
  intro p hp
  have h : env24259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24258_24259 : H12AffineEnvironment.transform 2 2 env24258 = env24259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24258 == env24259) = true)

def env24260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77899,272392,73755,98645,8193,64,121943,79131,17664,357642,75103,392287,257,21793,46093,513]

theorem envBound24260 : H12AffineFastState.Bounded env24260 := by
  intro p hp
  have h : env24260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24231_24260 : H12AffineEnvironment.transform 6 9 env24231 = env24260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24231 == env24260) = true)

theorem identity24260 : scanCanonicalize (H12AffineFastState.compose env24260 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound24260 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,50497,272392,54545,29791,8193,64,10589,49169,17664,294912,53333,264533,257,21793,46093,513]

theorem envBound24261 : H12AffineFastState.Bounded env24261 := by
  intro p hp
  have h : env24261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24260_24261 : H12AffineEnvironment.transform 15 62730 env24260 = env24261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env24260 == env24261) = true)

theorem identity24261 : scanCanonicalize (H12AffineFastState.compose env24261 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound24261 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env24262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,2048,1025,32769,50497,8200,54545,29791,8193,64,10589,49169,17664,34816,53333,341,257,21793,46093,513]

theorem envBound24262 : H12AffineFastState.Bounded env24262 := by
  intro p hp
  have h : env24262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24261_24262 : H12AffineEnvironment.transform 17 2048 env24261 = env24262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env24261 == env24262) = true)

theorem identity24262 : scanCanonicalize (H12AffineFastState.compose env24262 (packedSelected [0,2,4,6,9,20,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24262 : packedSelected [0,2,4,6,9,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env24263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29963,5392,2048,1025,0,17728,8200,21776,29791,8193,64,10589,16400,17664,2049,20564,341,257,21793,13324,513]

theorem envBound24263 : H12AffineFastState.Bounded env24263 := by
  intro p hp
  have h : env24263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24262_24263 : H12AffineEnvironment.transform 14 1 env24262 = env24263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24262 == env24263) = true)

theorem identity24263 : scanCanonicalize (H12AffineFastState.compose env24263 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound24263 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24264 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,16384,1,29038,4469,2048,100,0,16677,8200,20853,28730,8193,64,10589,16400,16741,2049,20564,341,257,20804,12393,513]

theorem envBound24264 : H12AffineFastState.Bounded env24264 := by
  intro p hp
  have h : env24264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24263_24264 : H12AffineEnvironment.transform 9 101 env24263 = env24264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env24263 == env24264) = true)

theorem identity24264 : scanCanonicalize (H12AffineFastState.compose env24264 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24264 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24265 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,16384,1,20807,4469,2048,100,0,16677,33,20853,20499,40,64,2420,16400,16741,2049,20564,341,257,20804,4160,513]

theorem envBound24265 : H12AffineFastState.Bounded env24265 := by
  intro p hp
  have h : env24265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24264_24265 : H12AffineEnvironment.transform 12 41 env24264 = env24265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24264 == env24265) = true)

theorem identity24265 : scanCanonicalize (H12AffineFastState.compose env24265 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound24265 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env24266 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,2049,1,6470,4469,2048,100,0,2340,33,6516,6162,40,64,2420,2065,2404,2049,6229,341,257,6469,4160,513]

theorem envBound24266 : H12AffineFastState.Bounded env24266 := by
  intro p hp
  have h : env24266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24265_24266 : H12AffineEnvironment.transform 13 2049 env24265 = env24266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env24265 == env24266) = true)

theorem identity24266 : scanCanonicalize (H12AffineFastState.compose env24266 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound24266 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env24267 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2112,41,2049,1,262,2357,2048,100,0,2340,33,308,82,40,64,2420,2065,2404,2049,21,341,257,261,2048,513]

theorem envBound24267 : H12AffineFastState.Bounded env24267 := by
  intro p hp
  have h : env24267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24266_24267 : H12AffineEnvironment.transform 11 2112 env24266 = env24267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env24266 == env24267) = true)

theorem identity24267 : scanCanonicalize (H12AffineFastState.compose env24267 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24267 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24268 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2065,41,2049,1,262,2357,2048,53,0,2340,33,308,3,40,17,2341,2065,2357,2049,21,260,257,261,2048,513]

theorem envBound24268 : H12AffineFastState.Bounded env24268 := by
  intro p hp
  have h : env24268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24267_24268 : H12AffineEnvironment.transform 5 17 env24267 = env24268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24267 == env24268) = true)

theorem identity24268 : scanCanonicalize (H12AffineFastState.compose env24268 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24268 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env24269 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,2049,1,35,2064,2048,53,0,2049,33,17,3,40,17,2048,2065,2064,2049,21,33,36,32,2048,513]

theorem envBound24269 : H12AffineFastState.Bounded env24269 := by
  intro p hp
  have h : env24269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24268_24269 : H12AffineEnvironment.transform 7 37 env24268 = env24269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24268 == env24269) = true)

theorem identity24269 : scanCanonicalize (H12AffineFastState.compose env24269 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound24269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24270 : List Nat := [2,4,8,16,32,17,9,37,512,52,512,529,41,513,1,35,528,512,53,0,513,33,17,3,40,17,512,529,528,513,21,33,36,32,512,513]

theorem envBound24270 : H12AffineFastState.Bounded env24270 := by
  intro p hp
  have h : env24270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24269_24270 : H12AffineEnvironment.transform 10 512 env24269 = env24270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env24269 == env24270) = true)

theorem identity24270 : scanCanonicalize (H12AffineFastState.compose env24270 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24271 : List Nat := [2,4,3,16,32,17,2,37,512,52,512,529,34,513,1,35,528,512,53,0,513,33,17,3,35,17,512,529,528,513,21,33,36,32,512,513]

theorem envBound24271 : H12AffineFastState.Bounded env24271 := by
  intro p hp
  have h : env24271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24270_24271 : H12AffineEnvironment.transform 2 3 env24270 = env24271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24270 == env24271) = true)

theorem identity24271 : scanCanonicalize (H12AffineFastState.compose env24271 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound24271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24272 : List Nat := [2,4,3,16,32,17,2,37,33,52,33,48,34,32,1,35,49,33,53,0,32,33,17,3,35,17,33,48,49,32,21,33,36,32,33,32]

theorem envBound24272 : H12AffineFastState.Bounded env24272 := by
  intro p hp
  have h : env24272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24271_24272 : H12AffineEnvironment.transform 8 33 env24271 = env24272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env24271 == env24272) = true)

theorem identity24272 : scanCanonicalize (H12AffineFastState.compose env24272 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24272 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24273 : List Nat := [2,4,3,16,1,17,2,4,0,21,0,17,3,1,1,2,16,0,20,0,1,0,17,3,2,17,0,17,16,1,21,0,5,1,0,1]

theorem envBound24273 : H12AffineFastState.Bounded env24273 := by
  intro p hp
  have h : env24273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24272_24273 : H12AffineEnvironment.transform 4 1 env24272 = env24273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24272 == env24273) = true)

theorem identity24273 : scanCanonicalize (H12AffineFastState.compose env24273 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24273 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24274 : List Nat := [2,4,3,1,1,0,2,4,0,4,0,0,3,1,1,2,1,0,5,0,1,0,0,3,2,0,0,0,1,1,4,0,5,1,0,1]

theorem envBound24274 : H12AffineFastState.Bounded env24274 := by
  intro p hp
  have h : env24274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24273_24274 : H12AffineEnvironment.transform 3 1 env24273 = env24274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24273 == env24274) = true)

def env24275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603797,2098513,17665,2377160,2102685,6349853,257,21793,46212,2175562]

theorem envBound24275 : H12AffineFastState.Bounded env24275 := by
  intro p hp
  have h : env24275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24218_24275 : H12AffineEnvironment.transform 16 38297 env24218 = env24275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env24218 == env24275) = true)

def env24276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157717,2098513,17665,2377160,2102685,2411677,257,21793,46212,2175562]

theorem envBound24276 : H12AffineFastState.Bounded env24276 := by
  intro p hp
  have h : env24276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24275_24276 : H12AffineEnvironment.transform 21 272512 env24275 = env24276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24275 == env24276) = true)

theorem identity24276 : scanCanonicalize (H12AffineFastState.compose env24276 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound24276 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38297,262144,1025,32769,2097152,272512,2101329,21763,8328,64,2157717,2098513,17665,2377160,2102685,2411677,257,21793,46212,2156180]

theorem envBound24277 : H12AffineFastState.Bounded env24277 := by
  intro p hp
  have h : env24277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24276_24277 : H12AffineEnvironment.transform 15 54494 env24276 = env24277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env24276 == env24277) = true)

def env24278 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,262144,1025,32769,2097152,272512,2101249,21763,8328,16,2157717,2098433,17665,2377112,2102685,2411677,257,21793,46212,2156180]

theorem envBound24278 : H12AffineFastState.Bounded env24278 := by
  intro p hp
  have h : env24278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24277_24278 : H12AffineEnvironment.transform 5 16 env24277 = env24278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24277 == env24278) = true)

theorem identity24278 : scanCanonicalize (H12AffineFastState.compose env24278 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24278 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24279 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1025,32769,2097152,272392,2101249,21763,8192,16,2157597,2098433,17665,2376976,2102549,2411541,257,21793,46092,2156060]

theorem envBound24279 : H12AffineFastState.Bounded env24279 := by
  intro p hp
  have h : env24279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24278_24279 : H12AffineEnvironment.transform 6 8 env24278 = env24279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24278 == env24279) = true)

theorem identity24279 : scanCanonicalize (H12AffineFastState.compose env24279 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound24279 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env24280 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1025,32769,17681,272392,21776,21763,8192,16,43276,16400,17665,262145,20484,297220,257,21793,46092,41741]

theorem envBound24280 : H12AffineFastState.Bounded env24280 := by
  intro p hp
  have h : env24280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24279_24280 : H12AffineEnvironment.transform 20 17681 env24279 = env24280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env24279 == env24280) = true)

theorem identity24280 : scanCanonicalize (H12AffineFastState.compose env24280 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound24280 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24281 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,32040,1025,32769,17681,21792,21776,21763,8192,16,43276,16400,17665,32041,20484,62508,257,21793,46092,41741]

theorem envBound24281 : H12AffineFastState.Bounded env24281 := by
  intro p hp
  have h : env24281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24280_24281 : H12AffineEnvironment.transform 17 32040 env24280 = env24281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env24280 == env24281) = true)

theorem identity24281 : scanCanonicalize (H12AffineFastState.compose env24281 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound24281 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24282 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8202,24861,32040,1025,29709,17681,21792,21776,21763,8192,16,23808,16400,17665,32041,20484,32,257,21793,16384,22273]

theorem envBound24282 : H12AffineFastState.Bounded env24282 := by
  intro p hp
  have h : env24282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24281_24282 : H12AffineEnvironment.transform 14 29708 env24281 = env24282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env24281 == env24282) = true)

theorem identity24282 : scanCanonicalize (H12AffineFastState.compose env24282 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound24282 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env24283 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,16384,20497,1047,17664,22837,1025,20496,17681,21792,21776,21763,1053,16,23808,16400,17665,22836,20484,32,257,21793,16384,22273]

theorem envBound24283 : H12AffineFastState.Bounded env24283 := by
  intro p hp
  have h : env24283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24282_24283 : H12AffineEnvironment.transform 12 1053 env24282 = env24283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env24282 == env24283) = true)

def env24284 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,2097152,272512,2101248,21763,8328,17,2157717,2098432,17665,2377113,2102685,2411677,257,21793,46212,2156180]

theorem envBound24284 : H12AffineFastState.Bounded env24284 := by
  intro p hp
  have h : env24284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24277_24284 : H12AffineEnvironment.transform 5 17 env24277 = env24284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24277 == env24284) = true)

theorem identity24284 : scanCanonicalize (H12AffineFastState.compose env24284 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound24284 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24285 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,58517,272512,62613,21763,8328,17,2048,57749,17665,303372,61704,272392,257,21793,46212,513]

theorem envBound24285 : H12AffineFastState.Bounded env24285 := by
  intro p hp
  have h : env24285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24284_24285 : H12AffineEnvironment.transform 20 58517 env24284 = env24285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env24284 == env24285) = true)

theorem identity24285 : scanCanonicalize (H12AffineFastState.compose env24285 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound24285 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env24286 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,23589,1025,32769,58517,29861,62613,21763,8328,17,2048,57749,17665,64809,61704,29741,257,21793,46212,513]

theorem envBound24286 : H12AffineFastState.Bounded env24286 := by
  intro p hp
  have h : env24286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24285_24286 : H12AffineEnvironment.transform 17 23589 env24285 = env24286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env24285 == env24286) = true)

theorem identity24286 : scanCanonicalize (H12AffineFastState.compose env24286 (packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound24286 : packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24287 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,21510,5392,23589,1025,136,25628,29861,29724,21763,8328,17,2048,24860,17665,32160,29057,29741,257,21793,13325,513]

theorem envBound24287 : H12AffineFastState.Bounded env24287 := by
  intro p hp
  have h : env24287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24286_24287 : H12AffineEnvironment.transform 14 137 env24286 = env24287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env24286 == env24287) = true)

def env24288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157716,2098513,17665,2377160,2102685,2411676,257,21793,46212,2175562]

theorem envBound24288 : H12AffineFastState.Bounded env24288 := by
  intro p hp
  have h : env24288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24275_24288 : H12AffineEnvironment.transform 21 272513 env24275 = env24288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24275 == env24288) = true)

theorem identity24288 : scanCanonicalize (H12AffineFastState.compose env24288 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound24288 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,115870,272513,120015,98781,8328,64,75786,115151,17665,360790,119043,329730,257,21793,46212,63188]

theorem envBound24289 : H12AffineFastState.Bounded env24289 := by
  intro p hp
  have h : env24289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24288_24289 : H12AffineEnvironment.transform 20 115870 env24288 = env24289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env24288 == env24289) = true)

end H12CloudChart0