import H12CloudChart0Data178

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound45337 : H12AffineFastState.Bounded env45337 := by
  intro p hp
  have h : env45337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45336_45337 : H12AffineEnvironment.transform 11 1061 env45336 = env45337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env45336 == env45337) = true)

theorem identity45337 : scanCanonicalize (H12AffineFastState.compose env45337 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound45337 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env45338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,3101,1076,2129,2310,1060,292,1025,2128,1124,33,16,3,3100,65,81,309,308,2421,1364,33,257,1329,1125,1808]

theorem envBound45338 : H12AffineFastState.Bounded env45338 := by
  intro p hp
  have h : env45338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45337_45338 : H12AffineEnvironment.transform 13 1076 env45337 = env45338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env45337 == env45338) = true)

def env45339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433956,8393985,10507601,8568105,2102685,12645452,257,21793,46212,2175563]

theorem envBound45339 : H12AffineFastState.Bounded env45339 := by
  intro p hp
  have h : env45339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45231_45339 : H12AffineEnvironment.transform 17 32041 env45231 = env45339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env45231 == env45339) = true)

def env45340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101328,98781,8328,65,6433956,2098513,17665,2272633,2102685,6349852,257,21793,46212,2175563]

theorem envBound45340 : H12AffineFastState.Bounded env45340 := by
  intro p hp
  have h : env45340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45339_45340 : H12AffineEnvironment.transform 22 2101328 env45339 = env45340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env45339 == env45340) = true)

def env45341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,16,98781,8328,65,4340964,5393,17665,179513,1501,4256860,257,21793,46212,74251]

theorem envBound45341 : H12AffineFastState.Bounded env45341 := by
  intro p hp
  have h : env45341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45340_45341 : H12AffineEnvironment.transform 20 4160 env45340 = env45341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45340 == env45341) = true)

theorem identity45341 : scanCanonicalize (H12AffineFastState.compose env45341 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21929) := by decide +kernel

theorem selectedBound45341 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21929,16,98781,8328,65,158029,5393,17665,179513,1501,41461,257,21793,46212,74251]

theorem envBound45342 : H12AffineFastState.Bounded env45342 := by
  intro p hp
  have h : env45342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45341_45342 : H12AffineEnvironment.transform 21 21929 env45341 = env45342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21929 env45341 == env45342) = true)

theorem identity45342 : scanCanonicalize (H12AffineFastState.compose env45342 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45342 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,21929,16,41431,8328,65,158029,5393,17665,179513,1501,41461,257,21793,46212,513]

theorem envBound45343 : H12AffineFastState.Bounded env45343 := by
  intro p hp
  have h : env45343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45342_45343 : H12AffineEnvironment.transform 15 8202 env45342 = env45343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45342 == env45343) = true)

theorem identity45343 : scanCanonicalize (H12AffineFastState.compose env45343 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound45343 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,4160,21929,16,41431,8328,65,10589,5393,17665,64809,1501,41461,257,21793,46212,513]

theorem envBound45344 : H12AffineFastState.Bounded env45344 := by
  intro p hp
  have h : env45344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45343_45344 : H12AffineEnvironment.transform 16 16400 env45343 = env45344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45343 == env45344) = true)

def env45345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98781,8328,65,4340965,5392,17665,179512,1500,4256861,257,21793,46212,74250]

theorem envBound45345 : H12AffineFastState.Bounded env45345 := by
  intro p hp
  have h : env45345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45340_45345 : H12AffineEnvironment.transform 20 4161 env45340 = env45345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45340 == env45345) = true)

def env45346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98645,8192,65,4340845,5392,17665,179512,1364,4256861,257,21793,46092,74250]

theorem envBound45346 : H12AffineFastState.Bounded env45346 := by
  intro p hp
  have h : env45346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45345_45346 : H12AffineEnvironment.transform 6 8 env45345 = env45346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45345 == env45346) = true)

theorem identity45346 : scanCanonicalize (H12AffineFastState.compose env45346 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45346 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41310,8192,65,4340845,5392,17665,179512,1364,4256861,257,21793,46092,513]

theorem envBound45347 : H12AffineFastState.Bounded env45347 := by
  intro p hp
  have h : env45347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45346_45347 : H12AffineEnvironment.transform 15 8203 env45346 = env45347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45346 == env45347) = true)

theorem identity45347 : scanCanonicalize (H12AffineFastState.compose env45347 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45347 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env45348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,4194304,17,21763,8192,65,4340845,5392,17665,149861,1364,4194304,257,21793,16465,513]

theorem envBound45348 : H12AffineFastState.Bounded env45348 := by
  intro p hp
  have h : env45348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45347_45348 : H12AffineEnvironment.transform 14 29789 env45347 = env45348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45347 == env45348) = true)

theorem identity45348 : scanCanonicalize (H12AffineFastState.compose env45348 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound45348 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env45349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,21873,17,21763,8192,65,157980,5392,17665,149861,1364,21873,257,21793,16465,513]

theorem envBound45349 : H12AffineFastState.Bounded env45349 := by
  intro p hp
  have h : env45349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45348_45349 : H12AffineEnvironment.transform 21 21873 env45348 = env45349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env45348 == env45349) = true)

theorem identity45349 : scanCanonicalize (H12AffineFastState.compose env45349 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45349 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env45350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8203,131072,10361,1025,8460,4161,33,17,83,8192,65,146508,5392,4177,138293,1364,33,257,113,5377,513]

theorem envBound45350 : H12AffineFastState.Bounded env45350 := by
  intro p hp
  have h : env45350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45349_45350 : H12AffineEnvironment.transform 13 5456 env45349 = env45350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45349 == env45350) = true)

theorem identity45350 : scanCanonicalize (H12AffineFastState.compose env45350 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound45350 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env45351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8203,13388,10361,1025,8460,4161,33,17,83,8192,65,2048,5392,4177,10361,1364,33,257,113,5377,513]

theorem envBound45351 : H12AffineFastState.Bounded env45351 := by
  intro p hp
  have h : env45351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45350_45351 : H12AffineEnvironment.transform 16 13388 env45350 = env45351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env45350 == env45351) = true)

theorem identity45351 : scanCanonicalize (H12AffineFastState.compose env45351 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45351 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env45352 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,13341,10280,1025,8460,4112,33,17,2,8192,16,2048,5392,4096,10280,1285,33,257,32,5377,513]

theorem envBound45352 : H12AffineFastState.Bounded env45352 := by
  intro p hp
  have h : env45352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45351_45352 : H12AffineEnvironment.transform 5 17 env45351 = env45352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45351 == env45352) = true)

theorem identity45352 : scanCanonicalize (H12AffineFastState.compose env45352 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45352 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45353 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2341,1025,1,4112,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5377,513]

theorem envBound45353 : H12AffineFastState.Bounded env45353 := by
  intro p hp
  have h : env45353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45352_45353 : H12AffineEnvironment.transform 12 269 env45352 = env45353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45352 == env45353) = true)

theorem identity45353 : scanCanonicalize (H12AffineFastState.compose env45353 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45354 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,35,5173,2048,1025,1,4112,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound45354 : H12AffineFastState.Bounded env45354 := by
  intro p hp
  have h : env45354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45353_45354 : H12AffineEnvironment.transform 7 37 env45353 = env45354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45353 == env45354) = true)

def env45355 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,0,35,1029,2048,1025,1,32,33,17,2,40,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound45355 : H12AffineFastState.Bounded env45355 := by
  intro p hp
  have h : env45355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45354_45355 : H12AffineEnvironment.transform 11 48 env45354 = env45355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45354 == env45355) = true)

theorem identity45355 : scanCanonicalize (H12AffineFastState.compose env45355 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound45355 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45356 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,40,1044,0,35,1029,32,1025,1,32,33,17,2,40,16,32,1029,48,32,1056,33,36,32,1044,513]

theorem envBound45356 : H12AffineFastState.Bounded env45356 := by
  intro p hp
  have h : env45356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45355_45356 : H12AffineEnvironment.transform 10 32 env45355 = env45356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env45355 == env45356) = true)

def env45357 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,32,0,35,49,32,53,1,32,33,17,2,40,16,32,49,48,32,20,33,36,32,32,513]

theorem envBound45357 : H12AffineFastState.Bounded env45357 := by
  intro p hp
  have h : env45357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45356_45357 : H12AffineEnvironment.transform 9 52 env45356 = env45357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45356 == env45357) = true)

theorem identity45357 : scanCanonicalize (H12AffineFastState.compose env45357 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45357 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45358 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,40,32,0,35,49,32,53,1,32,33,17,2,40,16,32,49,48,32,20,33,36,32,32,10]

theorem envBound45358 : H12AffineFastState.Bounded env45358 := by
  intro p hp
  have h : env45358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45357_45358 : H12AffineEnvironment.transform 8 11 env45357 = env45358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45357 == env45358) = true)

def leafEnv45358 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,40,32,0,35,49,32,53,1,32,33,17,2,21,40,1,16,32,49,48,32,20,33,36,32,5,35,32,10,1,32,0]

def active45358 : List Nat := [0,1,2,3,4]

def tree45358 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45358 : H12WitnessSearch.Good tree45358 := H12GlobalWitnessIndex.good

theorem leafIdentity45358 : H12AffineFastState.composeSystem env45358 rootObs = leafEnv45358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45358 rootObs == leafEnv45358) = true)

theorem terminalChecked45358 : H12PackedTerminal.terminalCheckFast leafEnv45358 active45358 tree45358 = true := by decide +kernel

def env45359 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,40,33,0,35,48,32,52,1,32,33,17,2,40,16,32,48,48,32,21,33,36,32,33,513]

theorem envBound45359 : H12AffineFastState.Bounded env45359 := by
  intro p hp
  have h : env45359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45356_45359 : H12AffineEnvironment.transform 9 53 env45356 = env45359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45356 == env45359) = true)

theorem identity45359 : scanCanonicalize (H12AffineFastState.compose env45359 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45360 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,0,3,16,0,20,1,0,1,17,2,8,16,0,16,16,0,21,1,4,0,1,513]

theorem envBound45360 : H12AffineFastState.Bounded env45360 := by
  intro p hp
  have h : env45360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45359_45360 : H12AffineEnvironment.transform 4 0 env45359 = env45360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45359 == env45360) = true)

def leafEnv45360 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,0,3,16,0,20,1,0,1,17,2,20,8,1,16,0,16,16,0,21,1,4,0,5,3,1,513,1,0,0]

def active45360 : List Nat := [0,1,2,3,8]

def tree45360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45360 : H12WitnessSearch.Good tree45360 := H12GlobalWitnessIndex.good

theorem leafIdentity45360 : H12AffineFastState.composeSystem env45360 rootObs = leafEnv45360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45360 rootObs == leafEnv45360) = true)

theorem terminalChecked45360 : H12PackedTerminal.terminalCheckFast leafEnv45360 active45360 tree45360 = true := by decide +kernel

def env45361 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,0,35,1028,2048,1025,1,33,33,17,2,40,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound45361 : H12AffineFastState.Bounded env45361 := by
  intro p hp
  have h : env45361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45354_45361 : H12AffineEnvironment.transform 11 49 env45354 = env45361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45354 == env45361) = true)

theorem identity45361 : scanCanonicalize (H12AffineFastState.compose env45361 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound45361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45362 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,40,1045,0,35,1028,1045,1025,1,33,33,17,2,40,16,1045,1028,49,1045,1056,33,36,32,1045,513]

theorem envBound45362 : H12AffineFastState.Bounded env45362 := by
  intro p hp
  have h : env45362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45361_45362 : H12AffineEnvironment.transform 10 1045 env45361 = env45362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env45361 == env45362) = true)

def env45363 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,40,33,0,35,48,33,53,1,33,33,17,2,40,16,33,48,49,33,20,33,36,32,33,513]

theorem envBound45363 : H12AffineFastState.Bounded env45363 := by
  intro p hp
  have h : env45363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45362_45363 : H12AffineEnvironment.transform 9 52 env45362 = env45363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45362 == env45363) = true)

theorem identity45363 : scanCanonicalize (H12AffineFastState.compose env45363 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound45363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45364 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,40,33,0,35,48,33,53,1,33,33,17,2,40,16,33,48,49,33,20,33,36,32,33,11]

theorem envBound45364 : H12AffineFastState.Bounded env45364 := by
  intro p hp
  have h : env45364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45363_45364 : H12AffineEnvironment.transform 8 10 env45363 = env45364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env45363 == env45364) = true)

def leafEnv45364 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,40,33,0,35,48,33,53,1,33,33,17,2,21,40,1,16,33,48,49,33,20,33,36,32,5,35,33,11,1,33,0]

def active45364 : List Nat := [0,1,2,3,4]

def tree45364 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45364 : H12WitnessSearch.Good tree45364 := H12GlobalWitnessIndex.good

theorem leafIdentity45364 : H12AffineFastState.composeSystem env45364 rootObs = leafEnv45364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45364 rootObs == leafEnv45364) = true)

theorem terminalChecked45364 : H12PackedTerminal.terminalCheckFast leafEnv45364 active45364 tree45364 = true := by decide +kernel

def env45365 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,32,0,35,49,32,52,1,33,33,17,2,40,16,32,49,49,32,21,33,36,32,32,513]

theorem envBound45365 : H12AffineFastState.Bounded env45365 := by
  intro p hp
  have h : env45365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45362_45365 : H12AffineEnvironment.transform 9 53 env45362 = env45365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45362 == env45365) = true)

theorem identity45365 : scanCanonicalize (H12AffineFastState.compose env45365 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45365 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45366 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,0,3,17,0,20,1,1,1,17,2,8,16,0,17,17,0,21,1,4,0,0,513]

theorem envBound45366 : H12AffineFastState.Bounded env45366 := by
  intro p hp
  have h : env45366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45365_45366 : H12AffineEnvironment.transform 4 0 env45365 = env45366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45365 == env45366) = true)

def leafEnv45366 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,0,3,17,0,20,1,1,1,17,2,20,8,1,16,0,17,17,0,21,1,4,0,5,3,0,513,1,1,0]

def active45366 : List Nat := [0,1,2,3,8]

def tree45366 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45366 : H12WitnessSearch.Good tree45366 := H12GlobalWitnessIndex.good

theorem leafIdentity45366 : H12AffineFastState.composeSystem env45366 rootObs = leafEnv45366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45366 rootObs == leafEnv45366) = true)

theorem terminalChecked45366 : H12PackedTerminal.terminalCheckFast leafEnv45366 active45366 tree45366 = true := by decide +kernel

def env45367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98644,8193,65,4340844,5392,17665,179512,1365,4256861,257,21793,46093,74250]

theorem envBound45367 : H12AffineFastState.Bounded env45367 := by
  intro p hp
  have h : env45367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45345_45367 : H12AffineEnvironment.transform 6 9 env45345 = env45367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45345 == env45367) = true)

theorem identity45367 : scanCanonicalize (H12AffineFastState.compose env45367 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45367 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32041,1025,8541,4161,4194304,17,73736,8193,65,4340844,5392,17665,138340,1365,4216065,257,21793,5457,74250]

theorem envBound45368 : H12AffineFastState.Bounded env45368 := by
  intro p hp
  have h : env45368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45367_45368 : H12AffineEnvironment.transform 14 8540 env45367 = env45368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45367 == env45368) = true)

theorem identity45368 : scanCanonicalize (H12AffineFastState.compose env45368 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound45368 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32041,1025,8541,4161,136496,17,73736,8193,65,10588,5392,17665,138340,1365,147505,257,21793,5457,74250]

theorem envBound45369 : H12AffineFastState.Bounded env45369 := by
  intro p hp
  have h : env45369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45368_45369 : H12AffineEnvironment.transform 21 136496 env45368 = env45369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env45368 == env45369) = true)

def env45370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,32041,1025,8541,4161,21792,17,73736,8193,65,10588,5392,17665,23668,1365,33,257,21793,5457,74250]

theorem envBound45370 : H12AffineFastState.Bounded env45370 := by
  intro p hp
  have h : env45370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45369_45370 : H12AffineEnvironment.transform 16 16400 env45369 = env45370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45369 == env45370) = true)

theorem identity45370 : scanCanonicalize (H12AffineFastState.compose env45370 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound45370 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env45371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,32,65536,16400,23637,1025,33,4161,21792,17,65908,381,65,2080,5392,17665,23668,1365,33,257,21793,5457,66422]

theorem envBound45371 : H12AffineFastState.Bounded env45371 := by
  intro p hp
  have h : env45371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45370_45371 : H12AffineEnvironment.transform 12 380 env45370 = env45371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env45370 == env45371) = true)

def env45372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,32041,1025,8541,4161,21793,17,73736,8193,65,10588,5392,17665,23669,1365,32,257,21793,5457,74250]

theorem envBound45372 : H12AffineFastState.Bounded env45372 := by
  intro p hp
  have h : env45372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45369_45372 : H12AffineEnvironment.transform 16 16401 env45369 = env45372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45369 == env45372) = true)

theorem identity45372 : scanCanonicalize (H12AffineFastState.compose env45372 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45372 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env45373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,373,65536,16401,23808,1025,372,4161,21793,17,65569,40,65,2421,5392,17665,23669,1365,32,257,21793,5457,66083]

theorem envBound45373 : H12AffineFastState.Bounded env45373 := by
  intro p hp
  have h : env45373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45372_45373 : H12AffineEnvironment.transform 12 41 env45372 = env45373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45372 == env45373) = true)

theorem identity45373 : scanCanonicalize (H12AffineFastState.compose env45373 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound45373 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,373,65536,5221,2420,1025,372,4161,341,17,65569,40,65,2421,5392,4469,2049,1365,32,257,341,5457,66083]

theorem envBound45374 : H12AffineFastState.Bounded env45374 := by
  intro p hp
  have h : env45374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45373_45374 : H12AffineEnvironment.transform 13 5236 env45373 = env45374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env45373 == env45374) = true)

theorem identity45374 : scanCanonicalize (H12AffineFastState.compose env45374 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound45374 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env45375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,373,34,5221,2420,1025,372,4161,341,17,3,40,65,2421,5392,4469,2049,1365,32,257,341,5457,513]

theorem envBound45375 : H12AffineFastState.Bounded env45375 := by
  intro p hp
  have h : env45375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45374_45375 : H12AffineEnvironment.transform 15 34 env45374 = env45375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env45374 == env45375) = true)

theorem identity45375 : scanCanonicalize (H12AffineFastState.compose env45375 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45375 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45376 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5236,81,34,5221,2128,1025,80,4161,113,17,3,40,65,2129,5172,4177,2049,1137,32,37,113,5237,513]

theorem envBound45376 : H12AffineFastState.Bounded env45376 := by
  intro p hp
  have h : env45376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45375_45376 : H12AffineEnvironment.transform 7 36 env45375 = env45376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45375 == env45376) = true)

theorem identity45376 : scanCanonicalize (H12AffineFastState.compose env45376 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45377 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,41,4161,81,34,4176,2128,52,80,4161,113,17,3,40,65,2129,4097,4177,2049,68,32,37,113,4160,513]

theorem envBound45377 : H12AffineFastState.Bounded env45377 := by
  intro p hp
  have h : env45377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45376_45377 : H12AffineEnvironment.transform 9 53 env45376 = env45377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45376 == env45377) = true)

def env45378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101329,98780,8328,65,6433956,2098512,17664,2272632,2102685,6349853,257,21793,46212,2175563]

theorem envBound45378 : H12AffineFastState.Bounded env45378 := by
  intro p hp
  have h : env45378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45339_45378 : H12AffineEnvironment.transform 22 2101329 env45339 = env45378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env45339 == env45378) = true)

def env45379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98780,8328,65,4340964,5392,17664,179512,1501,4256861,257,21793,46212,74251]

theorem envBound45379 : H12AffineFastState.Bounded env45379 := by
  intro p hp
  have h : env45379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45378_45379 : H12AffineEnvironment.transform 20 4160 env45378 = env45379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45378 == env45379) = true)

theorem identity45379 : scanCanonicalize (H12AffineFastState.compose env45379 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound45379 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32041,1025,29908,4160,4194304,17,95497,8328,65,4340964,5392,17664,149997,1501,4194440,257,21793,16465,74251]

theorem envBound45380 : H12AffineFastState.Bounded env45380 := by
  intro p hp
  have h : env45380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45379_45380 : H12AffineEnvironment.transform 14 29909 env45379 = env45380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env45379 == env45380) = true)

def env45381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1025,8660,4160,4194304,17,73737,8328,65,4340964,5392,4096,138477,1501,4194440,257,33,5457,74251]

theorem envBound45381 : H12AffineFastState.Bounded env45381 := by
  intro p hp
  have h : env45381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45380_45381 : H12AffineEnvironment.transform 13 5376 env45380 = env45381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45380 == env45381) = true)

theorem identity45381 : scanCanonicalize (H12AffineFastState.compose env45381 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound45381 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env45382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,10281,1025,8660,4160,4194304,17,73737,8328,65,4205044,5392,4096,2557,1501,4194440,257,33,5457,74251]

theorem envBound45382 : H12AffineFastState.Bounded env45382 := by
  intro p hp
  have h : env45382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45381_45382 : H12AffineEnvironment.transform 16 5392 env45381 = env45382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env45381 == env45382) = true)

theorem identity45382 : scanCanonicalize (H12AffineFastState.compose env45382 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 1464) := by decide +kernel

theorem selectedBound45382 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env45383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,10281,1025,8660,4160,1464,17,73737,8328,65,11340,5392,4096,2557,1501,1328,257,33,5457,74251]

theorem envBound45383 : H12AffineFastState.Bounded env45383 := by
  intro p hp
  have h : env45383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45382_45383 : H12AffineEnvironment.transform 21 1464 env45382 = env45383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1464 env45382 == env45383) = true)

theorem identity45383 : scanCanonicalize (H12AffineFastState.compose env45383 (packedSelected [0,1,2,4,5,6,9,10,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound45383 : packedSelected [0,1,2,4,5,6,9,10,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env45384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,81,65536,5392,2477,1025,80,4160,1464,17,65933,268,65,3528,5392,4096,2557,1501,1328,257,33,5457,66447]

theorem envBound45384 : H12AffineFastState.Bounded env45384 := by
  intro p hp
  have h : env45384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45383_45384 : H12AffineEnvironment.transform 12 388 env45383 = env45384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env45383 == env45384) = true)

theorem identity45384 : scanCanonicalize (H12AffineFastState.compose env45384 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45384 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env45385 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,81,65536,5308,2049,1025,80,4160,1044,17,65569,160,65,3172,5308,4096,2129,1137,1180,173,33,5373,66083]

theorem envBound45385 : H12AffineFastState.Bounded env45385 := by
  intro p hp
  have h : env45385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45384_45385 : H12AffineEnvironment.transform 7 172 env45384 = env45385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45384 == env45385) = true)

theorem identity45385 : scanCanonicalize (H12AffineFastState.compose env45385 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound45385 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env45386 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,81,35,5308,2049,1025,80,4160,1044,17,2,160,65,3172,5308,4096,2129,1137,1180,173,33,5373,512]

theorem envBound45386 : H12AffineFastState.Bounded env45386 := by
  intro p hp
  have h : env45386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45385_45386 : H12AffineEnvironment.transform 15 35 env45385 = env45386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env45385 == env45386) = true)

theorem identity45386 : scanCanonicalize (H12AffineFastState.compose env45386 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45386 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45387 : List Nat := [2,4,8,16,32,64,128,172,512,21,2048,4096,40,4281,81,35,4265,2049,20,80,4160,1,17,2,160,65,2161,4265,4096,2129,100,137,173,33,4328,512]

theorem envBound45387 : H12AffineFastState.Bounded env45387 := by
  intro p hp
  have h : env45387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45386_45387 : H12AffineEnvironment.transform 9 21 env45386 = env45387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45386 == env45387) = true)

theorem identity45387 : scanCanonicalize (H12AffineFastState.compose env45387 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45387 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45388 : List Nat := [2,4,8,16,1,64,128,141,512,21,2048,4096,9,4248,81,2,4232,2049,20,80,4160,1,17,2,129,65,2128,4232,4096,2129,69,137,140,0,4297,512]

theorem envBound45388 : H12AffineFastState.Bounded env45388 := by
  intro p hp
  have h : env45388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45387_45388 : H12AffineEnvironment.transform 4 1 env45387 = env45388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45387 == env45388) = true)

theorem identity45388 : scanCanonicalize (H12AffineFastState.compose env45388 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45389 : List Nat := [2,4,8,16,1,16,128,141,512,21,2048,4096,9,4248,1,2,4232,2049,20,0,4112,1,17,2,129,17,2048,4232,4096,2049,21,137,140,0,4249,512]

theorem envBound45389 : H12AffineFastState.Bounded env45389 := by
  intro p hp
  have h : env45389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45388_45389 : H12AffineEnvironment.transform 5 16 env45388 = env45389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45388 == env45389) = true)

theorem identity45389 : scanCanonicalize (H12AffineFastState.compose env45389 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45389 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45390 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,4096,9,4112,1,2,4096,2049,20,0,4112,1,17,2,9,17,2048,4096,4096,2049,21,1,4,0,4113,512]

theorem envBound45390 : H12AffineFastState.Bounded env45390 := by
  intro p hp
  have h : env45390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45389_45390 : H12AffineEnvironment.transform 6 8 env45389 = env45390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45389 == env45390) = true)

theorem identity45390 : scanCanonicalize (H12AffineFastState.compose env45390 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45391 : List Nat := [2,4,8,16,1,16,8,5,1,21,2048,4096,9,4112,1,2,4096,2049,20,0,4112,1,17,2,9,17,2048,4096,4096,2049,21,1,4,0,4113,1]

theorem envBound45391 : H12AffineFastState.Bounded env45391 := by
  intro p hp
  have h : env45391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45390_45391 : H12AffineEnvironment.transform 8 1 env45390 = env45391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45390 == env45391) = true)

theorem identity45391 : scanCanonicalize (H12AffineFastState.compose env45391 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound45391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45392 : List Nat := [2,4,8,4,1,4,8,5,1,1,2048,4096,9,4100,1,2,4096,2049,0,0,4100,1,5,2,9,5,2048,4096,4096,2049,1,1,4,0,4101,1]

theorem envBound45392 : H12AffineFastState.Bounded env45392 := by
  intro p hp
  have h : env45392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45391_45392 : H12AffineEnvironment.transform 3 4 env45391 = env45392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env45391 == env45392) = true)

theorem identity45392 : scanCanonicalize (H12AffineFastState.compose env45392 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 2053) := by decide +kernel

theorem selectedBound45392 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45393 : List Nat := [2,4,8,4,1,4,8,5,1,1,2048,2053,9,2049,1,2,2053,2049,0,0,2049,1,5,2,9,5,2048,2053,2053,2049,1,1,4,0,2048,1]

theorem envBound45393 : H12AffineFastState.Bounded env45393 := by
  intro p hp
  have h : env45393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45392_45393 : H12AffineEnvironment.transform 11 2053 env45392 = env45393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2053 env45392 == env45393) = true)

def leafEnv45393 : List Nat := [2,4,8,4,1,4,8,5,1,1,2048,2053,9,2049,1,2,2053,2049,0,0,2049,1,5,2,0,9,1,5,2048,2053,2053,2049,1,1,4,0,5,2,2048,1,1,2048,0]

def active45393 : List Nat := [0,1,2,10]

def tree45393 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45393 : H12WitnessSearch.Good tree45393 := H12GlobalWitnessIndex.good

theorem leafIdentity45393 : H12AffineFastState.composeSystem env45393 rootObs = leafEnv45393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45393 rootObs == leafEnv45393) = true)

theorem terminalChecked45393 : H12PackedTerminal.terminalCheckFast leafEnv45393 active45393 tree45393 = true := by decide +kernel

def env45394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10280,1025,8661,4160,4194304,17,73736,8328,65,4340964,5392,4097,138476,1501,4194440,257,32,5456,74251]

theorem envBound45394 : H12AffineFastState.Bounded env45394 := by
  intro p hp
  have h : env45394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45380_45394 : H12AffineEnvironment.transform 13 5377 env45380 = env45394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45380 == env45394) = true)

theorem identity45394 : scanCanonicalize (H12AffineFastState.compose env45394 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45394 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,4160,4194304,17,73736,8192,65,4340844,5392,4097,138340,1365,4194304,257,32,5456,74251]

theorem envBound45395 : H12AffineFastState.Bounded env45395 := by
  intro p hp
  have h : env45395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45394_45395 : H12AffineEnvironment.transform 6 8 env45394 = env45395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45394 == env45395) = true)

theorem identity45395 : scanCanonicalize (H12AffineFastState.compose env45395 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210235) := by decide +kernel

theorem selectedBound45395 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env45396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,4160,210235,17,73736,8192,65,67927,5392,4097,138340,1365,210235,257,32,5456,74251]

theorem envBound45396 : H12AffineFastState.Bounded env45396 := by
  intro p hp
  have h : env45396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45395_45396 : H12AffineEnvironment.transform 21 210235 env45395 = env45396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210235 env45395 == env45396) = true)

def env45397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,16,98780,8328,65,4340965,5393,17664,179513,1500,4256860,257,21793,46212,74250]

theorem envBound45397 : H12AffineFastState.Bounded env45397 := by
  intro p hp
  have h : env45397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45378_45397 : H12AffineEnvironment.transform 20 4161 env45378 = env45397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45378 == env45397) = true)

theorem identity45397 : scanCanonicalize (H12AffineFastState.compose env45397 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound45397 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,41340,16,98780,8328,65,171417,5393,17664,179513,1500,21792,257,21793,46212,74250]

theorem envBound45398 : H12AffineFastState.Bounded env45398 := by
  intro p hp
  have h : env45398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45397_45398 : H12AffineEnvironment.transform 21 41340 env45397 = env45398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env45397 == env45398) = true)

theorem identity45398 : scanCanonicalize (H12AffineFastState.compose env45398 (packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound45398 : packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env45399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,65536,131072,2476,1025,32769,4161,41340,16,98780,8328,65,171417,5393,12677,179513,1500,8613,257,8612,46212,74250]

theorem envBound45399 : H12AffineFastState.Bounded env45399 := by
  intro p hp
  have h : env45399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45398_45399 : H12AffineEnvironment.transform 13 13445 env45398 = env45399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env45398 == env45399) = true)

theorem identity45399 : scanCanonicalize (H12AffineFastState.compose env45399 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound45399 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,263,131072,2476,1025,32769,4161,41340,16,32987,8328,65,171417,5393,12677,179513,1500,8613,257,8612,46212,8973]

theorem envBound45400 : H12AffineFastState.Bounded env45400 := by
  intro p hp
  have h : env45400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45399_45400 : H12AffineEnvironment.transform 15 263 env45399 = env45400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env45399 == env45400) = true)

theorem identity45400 : scanCanonicalize (H12AffineFastState.compose env45400 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound45400 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env45401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,263,46276,2476,1025,32769,4161,41340,16,32987,8328,65,10589,5393,12677,2557,1500,8613,257,8612,46212,8973]

theorem envBound45401 : H12AffineFastState.Bounded env45401 := by
  intro p hp
  have h : env45401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45400_45401 : H12AffineEnvironment.transform 16 46276 env45400 = env45401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env45400 == env45401) = true)

theorem identity45401 : scanCanonicalize (H12AffineFastState.compose env45401 (packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45401 : packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env45402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,263,38344,2476,1025,32769,4161,32880,16,32987,388,65,2129,5393,4233,2557,1500,169,257,168,38280,513]

theorem envBound45402 : H12AffineFastState.Bounded env45402 := by
  intro p hp
  have h : env45402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45401_45402 : H12AffineEnvironment.transform 12 268 env45401 = env45402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45401 == env45402) = true)

theorem identity45402 : scanCanonicalize (H12AffineFastState.compose env45402 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound45402 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,263,5528,2476,1025,81,4161,32,16,139,388,65,2129,5393,4233,2557,1500,169,257,168,5592,513]

theorem envBound45403 : H12AffineFastState.Bounded env45403 := by
  intro p hp
  have h : env45403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45402_45403 : H12AffineEnvironment.transform 14 80 env45402 = env45403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env45402 == env45403) = true)

theorem identity45403 : scanCanonicalize (H12AffineFastState.compose env45403 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45403 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45404 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,80,263,5441,2421,1025,81,4161,32,16,82,349,65,2129,5393,4176,2340,1285,112,257,113,5377,513]

theorem envBound45404 : H12AffineFastState.Bounded env45404 := by
  intro p hp
  have h : env45404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45403_45404 : H12AffineEnvironment.transform 6 89 env45403 = env45404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45403 == env45404) = true)

theorem identity45404 : scanCanonicalize (H12AffineFastState.compose env45404 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound45404 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45405 : List Nat := [2,4,8,16,32,64,89,256,33,1024,2048,4096,268,5456,80,263,5441,2421,1025,81,4161,32,16,82,349,65,2129,5393,4176,2340,1285,112,257,113,5377,32]

theorem envBound45405 : H12AffineFastState.Bounded env45405 := by
  intro p hp
  have h : env45405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45404_45405 : H12AffineEnvironment.transform 8 33 env45404 = env45405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env45404 == env45405) = true)

theorem identity45405 : scanCanonicalize (H12AffineFastState.compose env45405 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound45405 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env45406 : List Nat := [2,4,8,16,32,64,89,256,33,1024,2048,1045,268,325,80,263,340,2421,1025,81,1108,32,16,82,349,65,2129,260,1093,2340,1285,112,257,113,276,32]

theorem envBound45406 : H12AffineFastState.Bounded env45406 := by
  intro p hp
  have h : env45406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45405_45406 : H12AffineEnvironment.transform 11 1045 env45405 = env45406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env45405 == env45406) = true)

def env45407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound45407 : H12AffineFastState.Bounded env45407 := by
  intro p hp
  have h : env45407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43995_45407 : H12AffineEnvironment.transform 29 155254785 env43995 = env45407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env43995 == env45407) = true)

def env45408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound45408 : H12AffineFastState.Bounded env45408 := by
  intro p hp
  have h : env45408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45407_45408 : H12AffineEnvironment.transform 25 64 env45407 = env45408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env45407 == env45408) = true)

def env45409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound45409 : H12AffineFastState.Bounded env45409 := by
  intro p hp
  have h : env45409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45408_45409 : H12AffineEnvironment.transform 26 30393344 env45408 = env45409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env45408 == env45409) = true)

def env45410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound45410 : H12AffineFastState.Bounded env45410 := by
  intro p hp
  have h : env45410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45409_45410 : H12AffineEnvironment.transform 18 1024 env45409 = env45410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45409 == env45410) = true)

theorem identity45410 : scanCanonicalize (H12AffineFastState.compose env45410 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound45410 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,8388608,16777216,8328,64,29843924,18949465,10507600,8806869,25241029,23160256,256,27354488,27337993,25166355]

theorem envBound45411 : H12AffineFastState.Bounded env45411 := by
  intro p hp
  have h : env45411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45410_45411 : H12AffineEnvironment.transform 14 8660 env45410 = env45411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env45410 == env45411) = true)

def env45412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147456,16777216,8328,64,21307860,18949465,2233680,270805,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound45412 : H12AffineFastState.Bounded env45412 := by
  intro p hp
  have h : env45412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45411_45412 : H12AffineEnvironment.transform 22 147456 env45411 = env45412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env45411 == env45412) = true)

theorem identity45412 : scanCanonicalize (H12AffineFastState.compose env45412 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147474) := by decide +kernel

theorem selectedBound45412 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147456,147474,8328,64,4678086,2319691,2233680,270805,75223,6497746,256,2188650,2172187,513]

theorem envBound45413 : H12AffineFastState.Bounded env45413 := by
  intro p hp
  have h : env45413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45412_45413 : H12AffineEnvironment.transform 23 147474 env45412 = env45413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147474 env45412 == env45413) = true)

def env45414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1024,8661,2097152,4194304,147456,147474,8328,64,4409702,2319691,2233680,2421,75223,6497746,256,2188650,2172187,513]

theorem envBound45414 : H12AffineFastState.Bounded env45414 := by
  intro p hp
  have h : env45414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45413_45414 : H12AffineEnvironment.transform 17 10400 env45413 = env45414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45413 == env45414) = true)

theorem identity45414 : scanCanonicalize (H12AffineFastState.compose env45414 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound45414 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16536,10400,1024,8661,2097152,4194304,152,138,8328,64,4262398,2172371,2119112,2421,75223,6382922,256,2188650,2172187,513]

theorem envBound45415 : H12AffineFastState.Bounded env45415 := by
  intro p hp
  have h : env45415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45414_45415 : H12AffineEnvironment.transform 16 16536 env45414 = env45415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env45414 == env45415) = true)

theorem identity45415 : scanCanonicalize (H12AffineFastState.compose env45415 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound45415 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,16536,10400,1024,8661,2097152,4194304,152,138,8328,64,4204925,2098512,2119112,2421,1364,6309321,256,2115049,2098584,513]

theorem envBound45416 : H12AffineFastState.Bounded env45416 := by
  intro p hp
  have h : env45416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45415_45416 : H12AffineEnvironment.transform 15 8323 env45415 = env45416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env45415 == env45416) = true)

theorem identity45416 : scanCanonicalize (H12AffineFastState.compose env45416 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound45416 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env45417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,16536,10400,1024,8661,5593,4194304,152,138,8328,64,4204925,4233,16401,2421,1364,4214800,256,20528,4161,513]

theorem envBound45417 : H12AffineFastState.Bounded env45417 := by
  intro p hp
  have h : env45417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45416_45417 : H12AffineEnvironment.transform 20 5593 env45416 = env45417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env45416 == env45417) = true)

theorem identity45417 : scanCanonicalize (H12AffineFastState.compose env45417 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound45417 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env45418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8660,8323,4232,10400,1024,8661,5593,4194304,152,138,8328,64,4204925,4233,4097,2421,1364,4194304,256,32,4161,513]

theorem envBound45418 : H12AffineFastState.Bounded env45418 := by
  intro p hp
  have h : env45418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45417_45418 : H12AffineEnvironment.transform 13 4112 env45417 = env45418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env45417 == env45418) = true)

theorem identity45418 : scanCanonicalize (H12AffineFastState.compose env45418 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45418 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45419 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4112,8580,8323,4232,10400,1024,8581,5513,4194304,152,138,8328,16,4204845,4233,4097,2341,1284,4194304,256,32,4113,513]

theorem envBound45419 : H12AffineFastState.Bounded env45419 := by
  intro p hp
  have h : env45419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45418_45419 : H12AffineEnvironment.transform 5 16 env45418 = env45419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45418 == env45419) = true)

theorem identity45419 : scanCanonicalize (H12AffineFastState.compose env45419 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound45419 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45420 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,2048,8580,8323,2200,10400,1024,8581,3481,4194304,152,138,8328,16,4204845,2201,2065,2341,1284,4194304,256,32,2049,513]

theorem envBound45420 : H12AffineFastState.Bounded env45420 := by
  intro p hp
  have h : env45420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45419_45420 : H12AffineEnvironment.transform 11 2064 env45419 = env45420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env45419 == env45420) = true)

theorem identity45420 : scanCanonicalize (H12AffineFastState.compose env45420 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 2080) := by decide +kernel

theorem selectedBound45420 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45421 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,2048,8580,8323,2200,10400,1024,8581,3481,2080,152,138,8328,16,8461,2201,2065,2341,1284,2080,256,32,2049,513]

theorem envBound45421 : H12AffineFastState.Bounded env45421 := by
  intro p hp
  have h : env45421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45420_45421 : H12AffineEnvironment.transform 21 2080 env45420 = env45421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2080 env45420 == env45421) = true)

theorem identity45421 : scanCanonicalize (H12AffineFastState.compose env45421 (packedSelected [0,1,2,3,5,6,7,8,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound45421 : packedSelected [0,1,2,3,5,6,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env45422 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,3384,2048,3260,3515,2200,1432,1024,3261,3481,2080,152,138,3504,16,3125,2201,2065,2341,1284,2080,256,32,2049,513]

theorem envBound45422 : H12AffineFastState.Bounded env45422 := by
  intro p hp
  have h : env45422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45421_45422 : H12AffineEnvironment.transform 12 3384 env45421 = env45422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env45421 == env45422) = true)

theorem identity45422 : scanCanonicalize (H12AffineFastState.compose env45422 (packedSelected [2,4,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound45422 : packedSelected [2,4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env45423 : List Nat := [2,4,8,16,32,16,128,256,512,1024,293,309,1053,293,1433,1182,445,1432,1024,1432,1212,261,152,138,1173,16,1296,444,308,0,1284,261,256,32,292,513]

theorem envBound45423 : H12AffineFastState.Bounded env45423 := by
  intro p hp
  have h : env45423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45422_45423 : H12AffineEnvironment.transform 10 293 env45422 = env45423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env45422 == env45423) = true)

theorem identity45423 : scanCanonicalize (H12AffineFastState.compose env45423 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45423 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,309,1053,293,1296,1047,308,1297,1024,1297,1077,261,17,3,1052,16,1296,309,308,0,1284,261,256,32,292,513]

theorem envBound45424 : H12AffineFastState.Bounded env45424 := by
  intro p hp
  have h : env45424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45423_45424 : H12AffineEnvironment.transform 6 9 env45423 = env45424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45423 == env45424) = true)

theorem identity45424 : scanCanonicalize (H12AffineFastState.compose env45424 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45424 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45425 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1,17,1053,1,1076,1047,16,1077,1024,1077,1077,33,17,3,1052,16,1076,17,16,0,1056,33,36,32,0,513]

theorem envBound45425 : H12AffineFastState.Bounded env45425 := by
  intro p hp
  have h : env45425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45424_45425 : H12AffineEnvironment.transform 7 36 env45424 = env45425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45424 == env45425) = true)

theorem identity45425 : scanCanonicalize (H12AffineFastState.compose env45425 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45426 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,1,1,34,16,0,53,0,0,33,17,3,41,16,1,17,16,0,21,33,36,32,0,513]

theorem envBound45426 : H12AffineFastState.Bounded env45426 := by
  intro p hp
  have h : env45426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45425_45426 : H12AffineEnvironment.transform 9 53 env45425 = env45426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45425 == env45426) = true)

theorem identity45426 : scanCanonicalize (H12AffineFastState.compose env45426 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45427 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,17,9,1,1,3,16,0,20,0,0,0,17,3,8,16,1,17,16,0,21,0,5,1,0,513]

theorem envBound45427 : H12AffineFastState.Bounded env45427 := by
  intro p hp
  have h : env45427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45426_45427 : H12AffineEnvironment.transform 4 1 env45426 = env45427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45426 == env45427) = true)

theorem identity45427 : scanCanonicalize (H12AffineFastState.compose env45427 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45428 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,17,9,1,1,3,16,0,20,0,0,0,17,3,8,16,1,17,16,0,21,0,5,1,0,0]

theorem envBound45428 : H12AffineFastState.Bounded env45428 := by
  intro p hp
  have h : env45428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45427_45428 : H12AffineEnvironment.transform 8 1 env45427 = env45428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45427 == env45428) = true)

def env45429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1024,8661,2097152,4194304,147456,147474,8328,64,4409703,2319691,2233680,2420,75223,6497746,256,2188650,2172187,513]

theorem envBound45429 : H12AffineFastState.Bounded env45429 := by
  intro p hp
  have h : env45429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45413_45429 : H12AffineEnvironment.transform 17 10401 env45413 = env45429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45413 == env45429) = true)

theorem identity45429 : scanCanonicalize (H12AffineFastState.compose env45429 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45429 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147474,8192,64,4409703,2319691,2233680,2420,75103,6497626,256,2188650,2172187,513]

theorem envBound45430 : H12AffineFastState.Bounded env45430 := by
  intro p hp
  have h : env45430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45429_45430 : H12AffineEnvironment.transform 6 8 env45429 = env45430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45429 == env45430) = true)

theorem identity45430 : scanCanonicalize (H12AffineFastState.compose env45430 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound45430 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env45431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,91466,4194304,147456,147474,8192,64,4409703,131073,225306,2420,75103,4341776,256,32,16465,513]

theorem envBound45431 : H12AffineFastState.Bounded env45431 := by
  intro p hp
  have h : env45431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45430_45431 : H12AffineEnvironment.transform 20 91466 env45430 = env45431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env45430 == env45431) = true)

theorem identity45431 : scanCanonicalize (H12AffineFastState.compose env45431 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound45431 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,91466,4194304,16,2,8192,64,4262263,16401,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound45432 : H12AffineFastState.Bounded env45432 := by
  intro p hp
  have h : env45432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45431_45432 : H12AffineEnvironment.transform 16 16400 env45431 = env45432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45431 == env45432) = true)

theorem identity45432 : scanCanonicalize (H12AffineFastState.compose env45432 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound45432 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,91466,73770,16,2,8192,64,10589,16401,77834,2420,75103,73770,256,32,16465,513]

theorem envBound45433 : H12AffineFastState.Bounded env45433 := by
  intro p hp
  have h : env45433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45432_45433 : H12AffineEnvironment.transform 21 73770 env45432 = env45433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env45432 == env45433) = true)

theorem identity45433 : scanCanonicalize (H12AffineFastState.compose env45433 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound45433 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env45434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8282,16400,10281,1024,8541,17680,112,16,2,8192,64,10589,16401,4176,2420,1285,112,256,32,16465,513]

theorem envBound45434 : H12AffineFastState.Bounded env45434 := by
  intro p hp
  have h : env45434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45433_45434 : H12AffineEnvironment.transform 15 8282 env45433 = env45434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env45433 == env45434) = true)

theorem identity45434 : scanCanonicalize (H12AffineFastState.compose env45434 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45434 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,263,16400,2420,1024,0,17680,112,16,2,349,64,2048,16401,4176,2420,1285,112,256,32,16465,513]

theorem envBound45435 : H12AffineFastState.Bounded env45435 := by
  intro p hp
  have h : env45435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45434_45435 : H12AffineEnvironment.transform 12 349 env45434 = env45435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45434 == env45435) = true)

theorem identity45435 : scanCanonicalize (H12AffineFastState.compose env45435 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound45435 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,1,263,5220,2420,1024,0,4452,112,16,2,349,64,2048,5221,4176,2420,1285,112,256,32,5157,513]

theorem envBound45436 : H12AffineFastState.Bounded env45436 := by
  intro p hp
  have h : env45436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45435_45436 : H12AffineEnvironment.transform 13 5236 env45435 = env45436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env45435 == env45436) = true)

theorem identity45436 : scanCanonicalize (H12AffineFastState.compose env45436 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45436 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45437 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,1,263,5173,2341,1024,0,4405,33,16,2,268,17,2048,5172,4097,2341,1285,33,256,32,5157,513]

theorem envBound45437 : H12AffineFastState.Bounded env45437 := by
  intro p hp
  have h : env45437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45436_45437 : H12AffineEnvironment.transform 5 17 env45436 = env45437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45436 == env45437) = true)

def env45438 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2837,1,263,2821,2341,1024,0,3589,33,16,2,268,17,2048,2820,3889,2341,1285,33,256,32,2837,513]

theorem envBound45438 : H12AffineFastState.Bounded env45438 := by
  intro p hp
  have h : env45438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45437_45438 : H12AffineEnvironment.transform 11 3888 env45437 = env45438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env45437 == env45438) = true)

def env45439 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1045,1,263,1029,1573,1024,0,261,33,16,2,268,17,1792,1028,49,1573,1285,33,256,32,1045,513]

theorem envBound45439 : H12AffineFastState.Bounded env45439 := by
  intro p hp
  have h : env45439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45438_45439 : H12AffineEnvironment.transform 10 1792 env45438 = env45439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env45438 == env45439) = true)

theorem identity45439 : scanCanonicalize (H12AffineFastState.compose env45439 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound45439 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45440 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,48,268,789,1,263,773,293,768,0,261,33,16,2,268,17,0,772,49,293,517,33,256,32,789,513]

theorem envBound45440 : H12AffineFastState.Bounded env45440 := by
  intro p hp
  have h : env45440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45439_45440 : H12AffineEnvironment.transform 9 768 env45439 = env45440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env45439 == env45440) = true)

def env45441 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,48,268,33,1,263,49,293,52,0,261,33,16,2,268,17,0,48,49,293,305,33,256,32,33,309]

theorem envBound45441 : H12AffineFastState.Bounded env45441 := by
  intro p hp
  have h : env45441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45440_45441 : H12AffineEnvironment.transform 8 308 env45440 = env45441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env45440 == env45441) = true)

theorem identity45441 : scanCanonicalize (H12AffineFastState.compose env45441 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45441 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45442 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,268,33,1,263,42,293,47,0,261,33,11,2,268,10,0,43,42,293,298,33,256,32,33,302]

theorem envBound45442 : H12AffineFastState.Bounded env45442 := by
  intro p hp
  have h : env45442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45441_45442 : H12AffineEnvironment.transform 3 11 env45441 = env45442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45441 == env45442) = true)

def leafEnv45442 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,268,33,1,263,42,293,47,0,261,33,11,2,298,268,1,10,0,43,42,293,298,33,256,32,4,263,33,302,1,261,0]

def active45442 : List Nat := [0,1,2,4,7]

def tree45442 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45442 : H12WitnessSearch.Good tree45442 := H12GlobalWitnessIndex.good

theorem leafIdentity45442 : H12AffineFastState.composeSystem env45442 rootObs = leafEnv45442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45442 rootObs == leafEnv45442) = true)

theorem terminalChecked45442 : H12PackedTerminal.terminalCheckFast leafEnv45442 active45442 tree45442 = true := by decide +kernel

def env45443 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,268,32,1,263,48,293,53,0,261,33,16,2,268,17,0,49,49,293,304,33,256,32,32,308]

theorem envBound45443 : H12AffineFastState.Bounded env45443 := by
  intro p hp
  have h : env45443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45440_45443 : H12AffineEnvironment.transform 8 309 env45440 = env45443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env45440 == env45443) = true)

theorem identity45443 : scanCanonicalize (H12AffineFastState.compose env45443 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45443 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45444 : List Nat := [2,4,8,16,1,17,8,256,276,20,0,17,268,1,1,263,17,260,20,0,261,0,16,2,268,17,0,16,16,260,273,0,256,1,1,277]

theorem envBound45444 : H12AffineFastState.Bounded env45444 := by
  intro p hp
  have h : env45444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45443_45444 : H12AffineEnvironment.transform 4 1 env45443 = env45444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45443 == env45444) = true)

def leafEnv45444 : List Nat := [2,4,8,16,1,17,8,256,276,20,0,17,268,1,1,263,17,260,20,0,261,0,16,2,273,268,1,17,0,16,16,260,273,0,256,1,4,263,1,277,1,261,0]

def active45444 : List Nat := [0,1,2,3,7]

def tree45444 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45444 : H12WitnessSearch.Good tree45444 := H12GlobalWitnessIndex.good

theorem leafIdentity45444 : H12AffineFastState.composeSystem env45444 rootObs = leafEnv45444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45444 rootObs == leafEnv45444) = true)

theorem terminalChecked45444 : H12PackedTerminal.terminalCheckFast leafEnv45444 active45444 tree45444 = true := by decide +kernel

def env45445 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1044,1,263,1028,1572,1024,0,260,33,16,2,268,17,1793,1029,48,1572,1285,33,256,32,1044,513]

theorem envBound45445 : H12AffineFastState.Bounded env45445 := by
  intro p hp
  have h : env45445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45438_45445 : H12AffineEnvironment.transform 10 1793 env45438 = env45445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env45438 == env45445) = true)

theorem identity45445 : scanCanonicalize (H12AffineFastState.compose env45445 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45446 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1297,49,268,1044,1,263,1028,1076,1024,0,260,33,16,2,268,17,1297,1029,48,1076,1285,33,256,32,1044,17]

theorem envBound45446 : H12AffineFastState.Bounded env45446 := by
  intro p hp
  have h : env45446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45445_45446 : H12AffineEnvironment.transform 8 16 env45445 = env45446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45445 == env45446) = true)

def env45447 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,268,32,1,263,48,0,52,0,260,33,16,2,268,17,293,49,48,0,305,33,256,32,32,17]

theorem envBound45447 : H12AffineFastState.Bounded env45447 := by
  intro p hp
  have h : env45447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45446_45447 : H12AffineEnvironment.transform 9 52 env45446 = env45447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45446 == env45447) = true)

theorem identity45447 : scanCanonicalize (H12AffineFastState.compose env45447 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45448 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,268,32,1,263,42,0,46,0,260,33,10,2,268,11,293,43,42,0,299,33,256,32,32,11]

theorem envBound45448 : H12AffineFastState.Bounded env45448 := by
  intro p hp
  have h : env45448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45447_45448 : H12AffineEnvironment.transform 3 10 env45447 = env45448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45447 == env45448) = true)

def leafEnv45448 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,268,32,1,263,42,0,46,0,260,33,10,2,299,268,1,11,293,43,42,0,299,33,256,32,4,263,32,11,1,260,0]

def active45448 : List Nat := [0,1,2,4,7]

def tree45448 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45448 : H12WitnessSearch.Good tree45448 := H12GlobalWitnessIndex.good

theorem leafIdentity45448 : H12AffineFastState.composeSystem env45448 rootObs = leafEnv45448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45448 rootObs == leafEnv45448) = true)

theorem terminalChecked45448 : H12PackedTerminal.terminalCheckFast leafEnv45448 active45448 tree45448 = true := by decide +kernel

def env45449 : List Nat := [2,4,8,16,32,17,8,256,16,53,292,49,268,33,1,263,49,1,53,0,260,33,16,2,268,17,292,48,48,1,304,33,256,32,33,17]

theorem envBound45449 : H12AffineFastState.Bounded env45449 := by
  intro p hp
  have h : env45449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45446_45449 : H12AffineEnvironment.transform 9 53 env45446 = env45449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45446 == env45449) = true)

theorem identity45449 : scanCanonicalize (H12AffineFastState.compose env45449 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45450 : List Nat := [2,4,8,16,32,17,8,4,16,53,32,49,8,33,1,3,49,1,53,0,0,33,16,2,8,17,32,48,48,1,52,33,4,32,33,17]

theorem envBound45450 : H12AffineFastState.Bounded env45450 := by
  intro p hp
  have h : env45450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45449_45450 : H12AffineEnvironment.transform 7 4 env45449 = env45450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45449 == env45450) = true)

def leafEnv45450 : List Nat := [2,4,8,16,32,17,8,4,16,53,32,49,8,33,1,3,49,1,53,0,0,33,16,2,52,8,1,17,32,48,48,1,52,33,4,32,4,3,33,17,1,0,0]

def active45450 : List Nat := [0,1,2,3,4]

def tree45450 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45450 : H12WitnessSearch.Good tree45450 := H12GlobalWitnessIndex.good

theorem leafIdentity45450 : H12AffineFastState.composeSystem env45450 rootObs = leafEnv45450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45450 rootObs == leafEnv45450) = true)

theorem terminalChecked45450 : H12PackedTerminal.terminalCheckFast leafEnv45450 active45450 tree45450 = true := by decide +kernel

def env45451 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2836,1,263,2820,2341,1024,0,3588,33,16,2,268,17,2048,2821,3888,2341,1285,33,256,32,2836,513]

theorem envBound45451 : H12AffineFastState.Bounded env45451 := by
  intro p hp
  have h : env45451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45437_45451 : H12AffineEnvironment.transform 11 3889 env45437 = env45451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env45437 == env45451) = true)

def env45452 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1044,1,263,1028,1573,1024,0,260,33,16,2,268,17,1792,1029,48,1573,1285,33,256,32,1044,513]

theorem envBound45452 : H12AffineFastState.Bounded env45452 := by
  intro p hp
  have h : env45452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45451_45452 : H12AffineEnvironment.transform 10 1792 env45451 = env45452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env45451 == env45452) = true)

theorem identity45452 : scanCanonicalize (H12AffineFastState.compose env45452 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound45452 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45453 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1076,49,268,1044,1,263,1028,1297,1024,0,260,33,16,2,268,17,1076,1029,48,1297,1285,33,256,32,1044,309]

theorem envBound45453 : H12AffineFastState.Bounded env45453 := by
  intro p hp
  have h : env45453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45452_45453 : H12AffineEnvironment.transform 8 308 env45452 = env45453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env45452 == env45453) = true)

def env45454 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,268,32,1,263,48,293,52,0,260,33,16,2,268,17,0,49,48,293,305,33,256,32,32,309]

theorem envBound45454 : H12AffineFastState.Bounded env45454 := by
  intro p hp
  have h : env45454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45453_45454 : H12AffineEnvironment.transform 9 52 env45453 = env45454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45453 == env45454) = true)

theorem identity45454 : scanCanonicalize (H12AffineFastState.compose env45454 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45455 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,268,32,1,263,43,293,47,0,260,33,11,2,268,10,0,42,43,293,298,33,256,32,32,302]

theorem envBound45455 : H12AffineFastState.Bounded env45455 := by
  intro p hp
  have h : env45455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45454_45455 : H12AffineEnvironment.transform 3 11 env45454 = env45455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45454 == env45455) = true)

def leafEnv45455 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,268,32,1,263,43,293,47,0,260,33,11,2,298,268,1,10,0,42,43,293,298,33,256,32,4,263,32,302,1,260,0]

def active45455 : List Nat := [0,1,2,4,7]

def tree45455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45455 : H12WitnessSearch.Good tree45455 := H12GlobalWitnessIndex.good

theorem leafIdentity45455 : H12AffineFastState.composeSystem env45455 rootObs = leafEnv45455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45455 rootObs == leafEnv45455) = true)

theorem terminalChecked45455 : H12PackedTerminal.terminalCheckFast leafEnv45455 active45455 tree45455 = true := by decide +kernel

def env45456 : List Nat := [2,4,8,16,32,17,8,256,308,53,1,49,268,33,1,263,49,292,53,0,260,33,16,2,268,17,1,48,48,292,304,33,256,32,33,309]

theorem envBound45456 : H12AffineFastState.Bounded env45456 := by
  intro p hp
  have h : env45456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45453_45456 : H12AffineEnvironment.transform 9 53 env45453 = env45456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45453 == env45456) = true)

theorem identity45456 : scanCanonicalize (H12AffineFastState.compose env45456 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45457 : List Nat := [2,4,8,16,1,17,8,256,277,20,1,16,268,0,1,263,16,261,20,0,260,0,16,2,268,17,1,17,17,261,273,0,256,1,0,276]

theorem envBound45457 : H12AffineFastState.Bounded env45457 := by
  intro p hp
  have h : env45457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45456_45457 : H12AffineEnvironment.transform 4 1 env45456 = env45457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45456 == env45457) = true)

def leafEnv45457 : List Nat := [2,4,8,16,1,17,8,256,277,20,1,16,268,0,1,263,16,261,20,0,260,0,16,2,273,268,1,17,1,17,17,261,273,0,256,1,4,263,0,276,1,260,0]

def active45457 : List Nat := [0,1,2,3,7]

def tree45457 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45457 : H12WitnessSearch.Good tree45457 := H12GlobalWitnessIndex.good

theorem leafIdentity45457 : H12AffineFastState.composeSystem env45457 rootObs = leafEnv45457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45457 rootObs == leafEnv45457) = true)

theorem terminalChecked45457 : H12PackedTerminal.terminalCheckFast leafEnv45457 active45457 tree45457 = true := by decide +kernel

def env45458 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1045,1,263,1029,1572,1024,0,261,33,16,2,268,17,1793,1028,49,1572,1285,33,256,32,1045,513]

theorem envBound45458 : H12AffineFastState.Bounded env45458 := by
  intro p hp
  have h : env45458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45451_45458 : H12AffineEnvironment.transform 10 1793 env45451 = env45458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env45451 == env45458) = true)

theorem identity45458 : scanCanonicalize (H12AffineFastState.compose env45458 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound45458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45459 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,48,268,561,1,263,545,0,548,0,261,33,16,2,268,17,293,544,49,0,801,33,256,32,561,513]

theorem envBound45459 : H12AffineFastState.Bounded env45459 := by
  intro p hp
  have h : env45459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45458_45459 : H12AffineEnvironment.transform 9 548 env45458 = env45459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env45458 == env45459) = true)

def env45460 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,48,268,33,1,263,49,0,52,0,261,33,16,2,268,17,293,48,49,0,305,33,256,32,33,17]

theorem envBound45460 : H12AffineFastState.Bounded env45460 := by
  intro p hp
  have h : env45460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45459_45460 : H12AffineEnvironment.transform 8 16 env45459 = env45460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45459 == env45460) = true)

theorem identity45460 : scanCanonicalize (H12AffineFastState.compose env45460 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45461 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,268,33,1,263,43,0,46,0,261,33,10,2,268,11,293,42,43,0,299,33,256,32,33,11]

theorem envBound45461 : H12AffineFastState.Bounded env45461 := by
  intro p hp
  have h : env45461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45460_45461 : H12AffineEnvironment.transform 3 10 env45460 = env45461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45460 == env45461) = true)

def leafEnv45461 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,268,33,1,263,43,0,46,0,261,33,10,2,299,268,1,11,293,42,43,0,299,33,256,32,4,263,33,11,1,261,0]

def active45461 : List Nat := [0,1,2,4,7]

def tree45461 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45461 : H12WitnessSearch.Good tree45461 := H12GlobalWitnessIndex.good

theorem leafIdentity45461 : H12AffineFastState.composeSystem env45461 rootObs = leafEnv45461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45461 rootObs == leafEnv45461) = true)

theorem terminalChecked45461 : H12PackedTerminal.terminalCheckFast leafEnv45461 active45461 tree45461 = true := by decide +kernel

def env45462 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,268,32,1,263,48,0,53,0,261,33,16,2,268,17,293,49,49,0,304,33,256,32,32,16]

theorem envBound45462 : H12AffineFastState.Bounded env45462 := by
  intro p hp
  have h : env45462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45459_45462 : H12AffineEnvironment.transform 8 17 env45459 = env45462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45459 == env45462) = true)

theorem identity45462 : scanCanonicalize (H12AffineFastState.compose env45462 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45463 : List Nat := [2,4,8,16,32,17,8,4,17,53,33,48,8,32,1,3,48,0,53,0,1,33,16,2,8,17,33,49,49,0,52,33,4,32,32,16]

theorem envBound45463 : H12AffineFastState.Bounded env45463 := by
  intro p hp
  have h : env45463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45462_45463 : H12AffineEnvironment.transform 7 4 env45462 = env45463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45462 == env45463) = true)

def leafEnv45463 : List Nat := [2,4,8,16,32,17,8,4,17,53,33,48,8,32,1,3,48,0,53,0,1,33,16,2,52,8,1,17,33,49,49,0,52,33,4,32,4,3,32,16,1,1,0]

def active45463 : List Nat := [0,1,2,3,4]

def tree45463 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45463 : H12WitnessSearch.Good tree45463 := H12GlobalWitnessIndex.good

theorem leafIdentity45463 : H12AffineFastState.composeSystem env45463 rootObs = leafEnv45463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45463 rootObs == leafEnv45463) = true)

theorem terminalChecked45463 : H12PackedTerminal.terminalCheckFast leafEnv45463 active45463 tree45463 = true := by decide +kernel

def env45464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147457,16777216,8328,64,21307861,18949465,2233681,270804,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound45464 : H12AffineFastState.Bounded env45464 := by
  intro p hp
  have h : env45464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45411_45464 : H12AffineEnvironment.transform 22 147457 env45411 = env45464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env45411 == env45464) = true)

def env45465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1024,8661,2097152,4194304,147457,16777216,8328,64,21039477,18949465,2233681,2420,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound45465 : H12AffineFastState.Bounded env45465 := by
  intro p hp
  have h : env45465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45464_45465 : H12AffineEnvironment.transform 17 10400 env45464 = env45465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45464 == env45465) = true)

theorem identity45465 : scanCanonicalize (H12AffineFastState.compose env45465 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound45465 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1024,8661,2097152,4194304,152,16777216,8328,64,21039477,18949465,2119112,2420,16852317,23160256,256,18965984,18949521,16777867]

theorem envBound45466 : H12AffineFastState.Bounded env45466 := by
  intro p hp
  have h : env45466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45465_45466 : H12AffineEnvironment.transform 16 16537 env45465 = env45466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env45465 == env45466) = true)

theorem identity45466 : scanCanonicalize (H12AffineFastState.compose env45466 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 73736) := by decide +kernel

theorem selectedBound45466 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env45467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1024,8661,2097152,4194304,152,73736,8328,64,4204925,2098513,2119112,2420,1365,6309320,256,2115048,2098585,74371]

theorem envBound45467 : H12AffineFastState.Bounded env45467 := by
  intro p hp
  have h : env45467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45466_45467 : H12AffineEnvironment.transform 23 73736 env45466 = env45467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73736 env45466 == env45467) = true)

theorem identity45467 : scanCanonicalize (H12AffineFastState.compose env45467 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound45467 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1024,8661,2097152,73890,152,73736,8328,64,68063,2098513,2119112,2420,1365,2188650,256,2115048,2098585,74371]

theorem envBound45468 : H12AffineFastState.Bounded env45468 := by
  intro p hp
  have h : env45468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45467_45468 : H12AffineEnvironment.transform 21 73890 env45467 = env45468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env45467 == env45468) = true)

theorem identity45468 : scanCanonicalize (H12AffineFastState.compose env45468 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 83015) := by decide +kernel

theorem selectedBound45468 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env45469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1024,8661,83015,73890,152,73736,8328,64,68063,82198,70031,2420,1365,8493,256,65967,82398,74371]

theorem envBound45469 : H12AffineFastState.Bounded env45469 := by
  intro p hp
  have h : env45469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45468_45469 : H12AffineEnvironment.transform 20 83015 env45468 = env45469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83015 env45468 == env45469) = true)

theorem identity45469 : scanCanonicalize (H12AffineFastState.compose env45469 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13808) := by decide +kernel

theorem selectedBound45469 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env45470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,8660,65536,13673,10400,1024,8661,78263,73890,152,73736,8328,64,68063,79078,70031,2420,1365,8493,256,65967,78894,74371]

theorem envBound45470 : H12AffineFastState.Bounded env45470 := by
  intro p hp
  have h : env45470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45469_45470 : H12AffineEnvironment.transform 13 13808 env45469 = env45470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13808 env45469 == env45470) = true)

theorem identity45470 : scanCanonicalize (H12AffineFastState.compose env45470 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45470 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env45471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,8660,8322,13673,10400,1024,8661,4405,32,152,138,8328,64,10589,5220,12557,2420,1365,8493,256,8493,5292,513]

theorem envBound45471 : H12AffineFastState.Bounded env45471 := by
  intro p hp
  have h : env45471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45470_45471 : H12AffineEnvironment.transform 15 8322 env45470 = env45471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45470 == env45471) = true)

theorem identity45471 : scanCanonicalize (H12AffineFastState.compose env45471 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound45471 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45472 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13608,8460,8282,13673,10360,1024,8461,4405,32,64,82,8272,64,10589,5220,12557,2420,1365,8493,256,8493,5236,513]

theorem envBound45472 : H12AffineFastState.Bounded env45472 := by
  intro p hp
  have h : env45472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45471_45472 : H12AffineEnvironment.transform 6 88 env45471 = env45472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45471 == env45472) = true)

theorem identity45472 : scanCanonicalize (H12AffineFastState.compose env45472 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1808) := by decide +kernel

theorem selectedBound45472 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env45473 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1808,8192,8760,8460,8282,8825,10360,1024,8461,1573,32,64,82,8272,64,10589,884,9757,2420,1365,8493,256,8493,868,513]

theorem envBound45473 : H12AffineFastState.Bounded env45473 := by
  intro p hp
  have h : env45473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45472_45473 : H12AffineEnvironment.transform 11 1808 env45472 = env45473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1808 env45472 == env45473) = true)

theorem identity45473 : scanCanonicalize (H12AffineFastState.compose env45473 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound45473 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env45474 : List Nat := [2,4,8,16,32,64,88,256,512,1024,529,1808,8192,8760,8460,8282,8825,8809,1024,8461,1573,32,64,82,8272,64,9036,884,9757,869,1365,8493,256,8493,868,513]

theorem envBound45474 : H12AffineFastState.Bounded env45474 := by
  intro p hp
  have h : env45474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45473_45474 : H12AffineEnvironment.transform 10 529 env45473 = env45474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env45473 == env45474) = true)

theorem identity45474 : scanCanonicalize (H12AffineFastState.compose env45474 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 568) := by decide +kernel

theorem selectedBound45474 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env45475 : List Nat := [2,4,8,16,32,64,88,256,512,1024,529,1808,568,0,820,610,65,81,1024,821,1573,32,64,82,616,64,372,884,1061,869,1365,789,256,789,868,513]

theorem envBound45475 : H12AffineFastState.Bounded env45475 := by
  intro p hp
  have h : env45475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45474_45475 : H12AffineEnvironment.transform 12 568 env45474 = env45475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 568 env45474 == env45475) = true)

theorem identity45475 : scanCanonicalize (H12AffineFastState.compose env45475 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound45475 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env45476 : List Nat := [2,4,8,16,32,64,88,256,512,613,529,373,568,0,820,610,65,81,613,821,64,32,64,82,616,64,372,884,576,869,816,789,256,789,868,513]

theorem envBound45476 : H12AffineFastState.Bounded env45476 := by
  intro p hp
  have h : env45476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45475_45476 : H12AffineEnvironment.transform 9 613 env45475 = env45476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env45475 == env45476) = true)

theorem identity45476 : scanCanonicalize (H12AffineFastState.compose env45476 (packedSelected [1,2,3,6,14] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound45476 : packedSelected [1,2,3,6,14] rootPS < 2^1333 := by decide +kernel

def env45477 : List Nat := [2,4,8,16,32,64,88,256,80,53,65,373,104,0,356,50,65,81,53,357,64,32,64,82,56,64,372,292,16,309,352,325,256,325,308,81]

theorem envBound45477 : H12AffineFastState.Bounded env45477 := by
  intro p hp
  have h : env45477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45476_45477 : H12AffineEnvironment.transform 8 80 env45476 = env45477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env45476 == env45477) = true)

theorem identity45477 : scanCanonicalize (H12AffineFastState.compose env45477 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45477 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env45478 : List Nat := [2,4,8,0,32,64,72,256,64,37,65,357,104,0,356,34,65,65,37,357,64,32,64,66,40,64,356,292,0,293,352,325,256,325,292,65]

theorem envBound45478 : H12AffineFastState.Bounded env45478 := by
  intro p hp
  have h : env45478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45477_45478 : H12AffineEnvironment.transform 3 0 env45477 = env45478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45477 == env45478) = true)

theorem identity45478 : scanCanonicalize (H12AffineFastState.compose env45478 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound45478 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45479 : List Nat := [2,4,8,0,32,64,72,100,64,37,65,1,104,0,0,34,65,65,37,1,64,32,64,66,40,64,0,64,0,65,4,33,100,33,64,65]

theorem envBound45479 : H12AffineFastState.Bounded env45479 := by
  intro p hp
  have h : env45479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45478_45479 : H12AffineEnvironment.transform 7 100 env45478 = env45479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env45478 == env45479) = true)

theorem identity45479 : scanCanonicalize (H12AffineFastState.compose env45479 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound45479 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45480 : List Nat := [2,4,8,0,32,33,41,5,33,37,32,1,9,0,0,34,32,32,37,1,33,32,33,35,40,33,0,33,0,32,4,33,5,33,33,32]

theorem envBound45480 : H12AffineFastState.Bounded env45480 := by
  intro p hp
  have h : env45480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45479_45480 : H12AffineEnvironment.transform 5 33 env45479 = env45480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env45479 == env45480) = true)

theorem identity45480 : scanCanonicalize (H12AffineFastState.compose env45480 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45480 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45481 : List Nat := [2,4,8,0,1,0,8,5,0,4,1,1,9,0,0,3,1,1,4,1,0,1,0,2,9,0,0,0,0,1,4,0,5,0,0,1]

theorem envBound45481 : H12AffineFastState.Bounded env45481 := by
  intro p hp
  have h : env45481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45480_45481 : H12AffineEnvironment.transform 4 1 env45480 = env45481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45480 == env45481) = true)

def env45482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1024,8661,2097152,4194304,147457,16777216,8328,64,21039476,18949465,2233681,2421,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound45482 : H12AffineFastState.Bounded env45482 := by
  intro p hp
  have h : env45482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45464_45482 : H12AffineEnvironment.transform 17 10401 env45464 = env45482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45464 == env45482) = true)

theorem identity45482 : scanCanonicalize (H12AffineFastState.compose env45482 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45482 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,16777216,8192,64,21039476,18949465,2233681,2421,16999756,23160136,256,19080569,19096840,16925202]

theorem envBound45483 : H12AffineFastState.Bounded env45483 := by
  intro p hp
  have h : env45483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45482_45483 : H12AffineEnvironment.transform 6 8 env45482 = env45483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45482 == env45483) = true)

def env45484 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,4096,8192,16384,8540,65536,131072,10281,68,8541,2097152,4194304,147457,16777216,8192,64,21039476,18948381,2232597,2421,16998664,23159052,256,19079485,19095884,16925202]

theorem envBound45484 : H12AffineFastState.Bounded env45484 := by
  intro p hp
  have h : env45484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45483_45484 : H12AffineEnvironment.transform 9 68 env45483 = env45484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env45483 == env45484) = true)

def env45485 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,4194304,147457,16777216,8192,16,21039396,18948381,2232597,2341,16998664,23159052,256,19079485,19095836,16925202]

theorem envBound45485 : H12AffineFastState.Bounded env45485 := by
  intro p hp
  have h : env45485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45484_45485 : H12AffineEnvironment.transform 5 16 env45484 = env45485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45484 == env45485) = true)

theorem identity45485 : scanCanonicalize (H12AffineFastState.compose env45485 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(23+1) ^^^ 4341810) := by decide +kernel

theorem selectedBound45485 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45486 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,4194304,147457,4341810,8192,16,215318,6512943,2232597,2341,4268346,2302270,256,6381839,6365486,4194848]

theorem envBound45486 : H12AffineFastState.Bounded env45486 := by
  intro p hp
  have h : env45486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45485_45486 : H12AffineEnvironment.transform 23 4341810 env45485 = env45486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4341810 env45485 == env45486) = true)

theorem identity45486 : scanCanonicalize (H12AffineFastState.compose env45486 (packedSelected [1,2,3,5,6,7,11,14,16,18,26,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2113829) := by decide +kernel

theorem selectedBound45486 : packedSelected [1,2,3,5,6,7,11,14,16,18,26,27,28] rootPS < 2^1333 := by decide +kernel

def env45487 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,2113829,147457,2228503,8192,16,215318,204810,2232597,2341,2187295,2302270,256,73770,90123,2114309]

theorem envBound45487 : H12AffineFastState.Bounded env45487 := by
  intro p hp
  have h : env45487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45486_45487 : H12AffineEnvironment.transform 21 2113829 env45486 = env45487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113829 env45486 == env45487) = true)

theorem identity45487 : scanCanonicalize (H12AffineFastState.compose env45487 (packedSelected [0,1,2,5,6,7,8,9,11,14,16,18,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 16644) := by decide +kernel

theorem selectedBound45487 : packedSelected [0,1,2,5,6,7,8,9,11,14,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env45488 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,16644,33,147457,147475,8192,16,215318,204810,151569,2341,74011,221242,256,73770,90123,513]

theorem envBound45488 : H12AffineFastState.Bounded env45488 := by
  intro p hp
  have h : env45488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45487_45488 : H12AffineEnvironment.transform 20 16644 env45487 = env45488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16644 env45487 == env45488) = true)

theorem identity45488 : scanCanonicalize (H12AffineFastState.compose env45488 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45488 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45489 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,269,16384,1,65536,131072,2340,20,0,16644,33,147457,147475,269,16,215318,196871,151569,2341,65558,213303,256,65831,82182,513]

theorem envBound45489 : H12AffineFastState.Bounded env45489 := by
  intro p hp
  have h : env45489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45488_45489 : H12AffineEnvironment.transform 12 269 env45488 = env45489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45488 == env45489) = true)

theorem identity45489 : scanCanonicalize (H12AffineFastState.compose env45489 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound45489 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45490 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,269,16384,1,65536,82199,2340,20,0,16644,33,65814,65796,269,16,2049,16400,69894,2341,65558,32,256,65831,82182,513]

theorem envBound45490 : H12AffineFastState.Bounded env45490 := by
  intro p hp
  have h : env45490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45489_45490 : H12AffineEnvironment.transform 16 82199 env45489 = env45490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env45489 == env45490) = true)

def env45491 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,4194304,147457,16777216,8192,17,21039397,18948381,2232597,2340,16998664,23159052,256,19079485,19095837,16925202]

theorem envBound45491 : H12AffineFastState.Bounded env45491 := by
  intro p hp
  have h : env45491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45484_45491 : H12AffineEnvironment.transform 5 17 env45484 = env45491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45484 == env45491) = true)

theorem identity45491 : scanCanonicalize (H12AffineFastState.compose env45491 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound45491 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45492 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,73771,147457,16777216,8192,17,16787726,18948381,2232597,2340,16998664,18891047,256,19079485,19095837,16925202]

theorem envBound45492 : H12AffineFastState.Bounded env45492 := by
  intro p hp
  have h : env45492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45491_45492 : H12AffineEnvironment.transform 21 73771 env45491 = env45492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env45491 == env45492) = true)

theorem identity45492 : scanCanonicalize (H12AffineFastState.compose env45492 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound45492 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45493 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,73771,147457,147475,8192,17,157981,2318606,2232597,2340,74011,2228532,256,2187566,2171150,513]

theorem envBound45493 : H12AffineFastState.Bounded env45493 := by
  intro p hp
  have h : env45493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45492_45493 : H12AffineEnvironment.transform 23 147475 env45492 = env45493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env45492 == env45493) = true)

theorem identity45493 : scanCanonicalize (H12AffineFastState.compose env45493 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound45493 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45494 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8461,65536,90138,10281,21,8460,2097152,73771,73755,73737,8192,17,67847,2097428,2191631,2340,74011,2187566,256,2187566,2171150,513]

theorem envBound45494 : H12AffineFastState.Bounded env45494 := by
  intro p hp
  have h : env45494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45493_45494 : H12AffineEnvironment.transform 16 90138 env45493 = env45494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env45493 == env45494) = true)

theorem identity45494 : scanCanonicalize (H12AffineFastState.compose env45494 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45494 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45495 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,269,16384,0,65536,82199,2340,21,1,2097152,65830,65814,65796,269,17,67847,2097428,2183170,2340,65558,2179107,256,2179107,2162691,513]

theorem envBound45495 : H12AffineFastState.Bounded env45495 := by
  intro p hp
  have h : env45495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45494_45495 : H12AffineEnvironment.transform 12 269 env45494 = env45495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45494 == env45495) = true)

def env45496 : List Nat := [2,4,8,16,32,64,8,256,512,69,2048,4096,8192,16384,8540,65536,131072,10281,69,8541,2097152,4194304,147457,16777216,8192,64,21039476,18948380,2232596,2421,16998665,23159053,256,19079484,19095885,16925202]

theorem envBound45496 : H12AffineFastState.Bounded env45496 := by
  intro p hp
  have h : env45496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45483_45496 : H12AffineEnvironment.transform 9 69 env45483 = env45496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env45483 == env45496) = true)

def env45497 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,4194304,147457,16777216,8192,16,21039396,18948380,2232596,2341,16998665,23159053,256,19079484,19095837,16925202]

theorem envBound45497 : H12AffineFastState.Bounded env45497 := by
  intro p hp
  have h : env45497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45496_45497 : H12AffineEnvironment.transform 5 16 env45496 = env45497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45496 == env45497) = true)

theorem identity45497 : scanCanonicalize (H12AffineFastState.compose env45497 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound45497 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45498 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,33,147457,16777216,8192,16,16845061,18948380,2232596,2341,16998665,18964780,256,19079484,19095837,16925202]

theorem envBound45498 : H12AffineFastState.Bounded env45498 := by
  intro p hp
  have h : env45498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45497_45498 : H12AffineEnvironment.transform 21 33 env45497 = env45498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45497 == env45498) = true)

theorem identity45498 : scanCanonicalize (H12AffineFastState.compose env45498 (packedSelected [1,2,6,8,11,12,15,17,18,19] rootPS)) = affineNative (2^(23+1) ^^^ 2121738) := by decide +kernel

theorem selectedBound45498 : packedSelected [1,2,6,8,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env45499 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,33,147457,2121738,8192,16,2189583,82198,2232596,2341,2294019,65830,256,213302,196887,2236952]

theorem envBound45499 : H12AffineFastState.Bounded env45499 := by
  intro p hp
  have h : env45499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45498_45499 : H12AffineEnvironment.transform 23 2121738 env45498 = env45499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2121738 env45498 == env45499) = true)

theorem identity45499 : scanCanonicalize (H12AffineFastState.compose env45499 (packedSelected [4,9,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 16644) := by decide +kernel

theorem selectedBound45499 : packedSelected [4,9,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env45500 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,16644,33,147457,8462,8192,16,75787,82198,151568,2341,212999,65830,256,213302,196887,156444]

theorem envBound45500 : H12AffineFastState.Bounded env45500 := by
  intro p hp
  have h : env45500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45499_45500 : H12AffineEnvironment.transform 20 16644 env45499 = env45500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16644 env45499 == env45500) = true)

theorem identity45500 : scanCanonicalize (H12AffineFastState.compose env45500 (packedSelected [2,4,6,9,11,14,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound45500 : packedSelected [2,4,6,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env45501 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8460,65536,16401,10281,21,8461,16644,33,16,8462,8192,16,75787,82198,4097,2341,65558,65830,256,65831,82182,8973]

theorem envBound45501 : H12AffineFastState.Bounded env45501 := by
  intro p hp
  have h : env45501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45500_45501 : H12AffineEnvironment.transform 16 16401 env45500 = env45501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45500 == env45501) = true)

theorem identity45501 : scanCanonicalize (H12AffineFastState.compose env45501 (packedSelected [11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45501 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env45502 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,8192,16384,8460,65536,16401,10249,21,8461,16644,1,16,8462,8192,16,75787,82198,4097,2309,65558,65798,256,65799,82182,8973]

theorem envBound45502 : H12AffineFastState.Bounded env45502 := by
  intro p hp
  have h : env45502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45501_45502 : H12AffineEnvironment.transform 4 0 env45501 = env45502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45501 == env45502) = true)

theorem identity45502 : scanCanonicalize (H12AffineFastState.compose env45502 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 12313) := by decide +kernel

theorem selectedBound45502 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env45503 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,8192,12313,8460,65536,12296,10249,21,8461,12573,1,16,8462,8192,16,75787,78095,4097,2309,65558,65798,256,65799,78111,8973]

theorem envBound45503 : H12AffineFastState.Bounded env45503 := by
  intro p hp
  have h : env45503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45502_45503 : H12AffineEnvironment.transform 13 12313 env45502 = env45503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12313 env45502 == env45503) = true)

def env45504 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,4194304,147457,16777216,8192,17,21039397,18948380,2232596,2340,16998665,23159053,256,19079484,19095836,16925202]

theorem envBound45504 : H12AffineFastState.Bounded env45504 := by
  intro p hp
  have h : env45504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45496_45504 : H12AffineEnvironment.transform 5 17 env45496 = env45504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45496 == env45504) = true)

theorem identity45504 : scanCanonicalize (H12AffineFastState.compose env45504 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(23+1) ^^^ 4415544) := by decide +kernel

theorem selectedBound45504 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45505 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,4194304,147457,4415544,8192,17,157981,6439204,2232596,2340,4194609,2228533,256,6308100,6291748,4268586]

theorem envBound45505 : H12AffineFastState.Bounded env45505 := by
  intro p hp
  have h : env45505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45504_45505 : H12AffineEnvironment.transform 23 4415544 env45504 = env45505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4415544 env45504 == env45505) = true)

theorem identity45505 : scanCanonicalize (H12AffineFastState.compose env45505 (packedSelected [0,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2113828) := by decide +kernel

theorem selectedBound45505 : packedSelected [0,14,17,27] rootPS < 2^1333 := by decide +kernel

def env45506 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,2113828,147457,2302236,8192,17,157981,131072,2232596,2340,2113557,2228533,256,32,16384,2188046]

theorem envBound45506 : H12AffineFastState.Bounded env45506 := by
  intro p hp
  have h : env45506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45505_45506 : H12AffineEnvironment.transform 21 2113828 env45505 = env45506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113828 env45505 == env45506) = true)

theorem identity45506 : scanCanonicalize (H12AffineFastState.compose env45506 (packedSelected [1,2,3,5,6,8,10,11,12,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound45506 : packedSelected [1,2,3,5,6,8,10,11,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env45507 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,65536,24860,10281,20,8460,2097152,2113828,8477,2179072,8192,17,2049,24860,2125832,2340,2113557,2121769,256,32,16384,2188046]

theorem envBound45507 : H12AffineFastState.Bounded env45507 := by
  intro p hp
  have h : env45507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45506_45507 : H12AffineEnvironment.transform 16 24860 env45506 = env45507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env45506 == env45507) = true)

theorem identity45507 : scanCanonicalize (H12AffineFastState.compose env45507 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 24584) := by decide +kernel

theorem selectedBound45507 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env45508 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,65536,24860,10281,20,8460,24584,8492,8477,73736,8192,17,2049,24860,4096,2340,8221,33,256,32,16384,66310]

theorem envBound45508 : H12AffineFastState.Bounded env45508 := by
  intro p hp
  have h : env45508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45507_45508 : H12AffineEnvironment.transform 20 24584 env45507 = env45508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24584 env45507 == env45508) = true)

theorem identity45508 : scanCanonicalize (H12AffineFastState.compose env45508 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 10250) := by decide +kernel

theorem selectedBound45508 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env45509 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8461,10250,24860,10281,20,8460,24584,8492,8477,2050,8192,17,2049,24860,4096,2340,8221,33,256,32,16384,11020]

theorem envBound45509 : H12AffineFastState.Bounded env45509 := by
  intro p hp
  have h : env45509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45508_45509 : H12AffineEnvironment.transform 15 10250 env45508 = env45509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10250 env45508 == env45509) = true)

theorem identity45509 : scanCanonicalize (H12AffineFastState.compose env45509 (packedSelected [1,2,3,6,7,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound45509 : packedSelected [1,2,3,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45510 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,8192,16384,8461,10250,24860,10281,20,8460,24584,8492,8477,2050,8192,17,2049,24860,49,2340,8221,33,256,32,16384,11020]

theorem envBound45510 : H12AffineFastState.Bounded env45510 := by
  intro p hp
  have h : env45510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45509_45510 : H12AffineEnvironment.transform 11 49 env45509 = env45510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45509 == env45510) = true)

theorem identity45510 : scanCanonicalize (H12AffineFastState.compose env45510 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45510 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env45511 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,269,16384,0,2311,16401,2340,20,1,16645,33,16,2050,269,17,2049,16401,49,2340,272,33,256,32,16384,2561]

theorem envBound45511 : H12AffineFastState.Bounded env45511 := by
  intro p hp
  have h : env45511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45510_45511 : H12AffineEnvironment.transform 12 269 env45510 = env45511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45510 == env45511) = true)

theorem identity45511 : scanCanonicalize (H12AffineFastState.compose env45511 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound45511 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45512 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,269,2340,0,2311,2357,2340,20,1,2081,33,16,2050,269,17,2049,2357,49,2340,272,33,256,32,2340,2561]

theorem envBound45512 : H12AffineFastState.Bounded env45512 := by
  intro p hp
  have h : env45512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45511_45512 : H12AffineEnvironment.transform 13 2340 env45511 = env45512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env45511 == env45512) = true)

theorem identity45512 : scanCanonicalize (H12AffineFastState.compose env45512 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound45512 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env45513 : List Nat := [2,4,8,16,32,17,8,256,512,20,32,49,269,260,0,295,277,260,20,1,1,33,16,34,269,17,33,277,49,260,272,33,256,32,260,545]

theorem envBound45513 : H12AffineFastState.Bounded env45513 := by
  intro p hp
  have h : env45513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45512_45513 : H12AffineEnvironment.transform 10 32 env45512 = env45513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env45512 == env45513) = true)

def env45514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound45514 : H12AffineFastState.Bounded env45514 := by
  intro p hp
  have h : env45514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45409_45514 : H12AffineEnvironment.transform 18 1025 env45409 = env45514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45409 == env45514) = true)

theorem identity45514 : scanCanonicalize (H12AffineFastState.compose env45514 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8601941) := by decide +kernel

theorem selectedBound45514 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8601941,8328,64,4489556,10667481,10507600,8830976,181572,14820501,257,2262520,2253916,254611]

theorem envBound45515 : H12AffineFastState.Bounded env45515 := by
  intro p hp
  have h : env45515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45514_45515 : H12AffineEnvironment.transform 23 8601941 env45514 = env45515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8601941 env45514 == env45515) = true)

def env45516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,8388608,8601941,8328,64,4489556,8393985,8553864,8830976,181572,12645453,257,21792,46212,254611]

theorem envBound45516 : H12AffineFastState.Bounded env45516 := by
  intro p hp
  have h : env45516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45515_45516 : H12AffineEnvironment.transform 20 184536 env45515 = env45516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env45515 == env45516) = true)

def env45517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,98781,8328,64,4489556,185737,17664,262280,181572,4338885,257,21792,46212,254611]

theorem envBound45517 : H12AffineFastState.Bounded env45517 := by
  intro p hp
  have h : env45517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45516_45517 : H12AffineEnvironment.transform 22 180360 env45516 = env45517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env45516 == env45517) = true)

def env45518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,98781,8328,64,43476,185737,17664,262280,181572,400453,257,21792,46212,254611]

theorem envBound45518 : H12AffineFastState.Bounded env45518 := by
  intro p hp
  have h : env45518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45517_45518 : H12AffineEnvironment.transform 21 272512 env45517 = env45518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45517 == env45518) = true)

theorem identity45518 : scanCanonicalize (H12AffineFastState.compose env45518 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45518 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184536,272512,180360,41430,8328,64,43476,185737,17664,262280,181572,400453,257,21792,46212,180888]

theorem envBound45519 : H12AffineFastState.Bounded env45519 := by
  intro p hp
  have h : env45519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45518_45519 : H12AffineEnvironment.transform 15 8203 env45518 = env45519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45518 == env45519) = true)

theorem identity45519 : scanCanonicalize (H12AffineFastState.compose env45519 (packedSelected [4,7,9,12,15,27,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound45519 : packedSelected [4,7,9,12,15,27,38,41] rootPS < 2^1333 := by decide +kernel

def env45520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,37064,272512,32920,41430,8328,64,43476,38297,17664,262280,34132,285781,257,21792,46212,33416]

theorem envBound45520 : H12AffineFastState.Bounded env45520 := by
  intro p hp
  have h : env45520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45519_45520 : H12AffineEnvironment.transform 16 16400 env45519 = env45520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45519 == env45520) = true)

theorem identity45520 : scanCanonicalize (H12AffineFastState.compose env45520 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64888) := by decide +kernel

theorem selectedBound45520 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env45521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64888,1025,32769,37064,54776,32920,41430,8328,64,43476,38297,17664,65008,34132,41261,257,21792,46212,33416]

theorem envBound45521 : H12AffineFastState.Bounded env45521 := by
  intro p hp
  have h : env45521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45520_45521 : H12AffineEnvironment.transform 17 64888 env45520 = env45521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64888 env45520 == env45521) = true)

theorem identity45521 : scanCanonicalize (H12AffineFastState.compose env45521 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound45521 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env45522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21841,8203,16400,10281,1025,21840,17817,169,21961,29831,8328,64,31877,16584,17664,10401,20485,29820,257,21792,25045,22489]

theorem envBound45522 : H12AffineFastState.Bounded env45522 := by
  intro p hp
  have h : env45522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45521_45522 : H12AffineEnvironment.transform 14 21841 env45521 = env45522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env45521 == env45522) = true)

def env45523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,98781,8328,64,43477,185737,17664,262280,181572,400452,257,21792,46212,254611]

theorem envBound45523 : H12AffineFastState.Bounded env45523 := by
  intro p hp
  have h : env45523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45517_45523 : H12AffineEnvironment.transform 21 272513 env45517 = env45523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45517 == env45523) = true)

theorem identity45523 : scanCanonicalize (H12AffineFastState.compose env45523 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound45523 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77898,272513,73754,98781,8328,64,43477,79131,17664,262280,75222,392406,257,21792,46212,513]

theorem envBound45524 : H12AffineFastState.Bounded env45524 := by
  intro p hp
  have h : env45524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45523_45524 : H12AffineEnvironment.transform 16 123026 env45523 = env45524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env45523 == env45524) = true)

def env45525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90258,262144,1025,1,77898,272513,73754,66013,8328,64,10709,79131,17664,262280,75222,359638,257,21792,13444,513]

theorem envBound45525 : H12AffineFastState.Bounded env45525 := by
  intro p hp
  have h : env45525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45524_45525 : H12AffineEnvironment.transform 14 0 env45524 = env45525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45524 == env45525) = true)

theorem identity45525 : scanCanonicalize (H12AffineFastState.compose env45525 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45525 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,262144,1025,1,77898,272392,73754,65876,8193,64,10588,79131,17664,262145,75103,359519,257,21792,13325,513]

theorem envBound45526 : H12AffineFastState.Bounded env45526 := by
  intro p hp
  have h : env45526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45525_45526 : H12AffineEnvironment.transform 6 9 env45525 = env45526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45525 == env45526) = true)

theorem identity45526 : scanCanonicalize (H12AffineFastState.compose env45526 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound45526 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env45527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,67618,1025,1,77898,73770,73754,65876,8193,64,10588,79131,17664,67619,75103,29821,257,21792,13325,513]

theorem envBound45527 : H12AffineFastState.Bounded env45527 := by
  intro p hp
  have h : env45527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45526_45527 : H12AffineEnvironment.transform 17 67618 env45526 = env45527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env45526 == env45527) = true)

def env45528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90259,262144,1025,0,77898,272513,73754,66012,8328,64,10708,79131,17664,262280,75222,359639,257,21792,13445,513]

theorem envBound45528 : H12AffineFastState.Bounded env45528 := by
  intro p hp
  have h : env45528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45524_45528 : H12AffineEnvironment.transform 14 1 env45524 = env45528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env45524 == env45528) = true)

theorem identity45528 : scanCanonicalize (H12AffineFastState.compose env45528 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45528 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env45529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16401,262144,1025,0,4296,272513,152,8542,8328,64,10708,5529,17664,262280,1364,285781,257,21792,13445,513]

theorem envBound45529 : H12AffineFastState.Bounded env45529 := by
  intro p hp
  have h : env45529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45528_45529 : H12AffineEnvironment.transform 15 8322 env45528 = env45529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45528 == env45529) = true)

theorem identity45529 : scanCanonicalize (H12AffineFastState.compose env45529 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45529 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16401,10281,1025,0,4296,168,152,8542,8328,64,10708,5529,17664,10401,1364,29820,257,21792,13445,513]

theorem envBound45530 : H12AffineFastState.Bounded env45530 := by
  intro p hp
  have h : env45530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45529_45530 : H12AffineEnvironment.transform 17 10281 env45529 = env45530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45529 == env45530) = true)

theorem identity45530 : scanCanonicalize (H12AffineFastState.compose env45530 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45530 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env45531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,1,8322,5392,10281,1025,0,4296,168,152,8542,8328,64,10708,5529,4097,10401,1364,8573,257,33,13445,513]

theorem envBound45531 : H12AffineFastState.Bounded env45531 := by
  intro p hp
  have h : env45531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45530_45531 : H12AffineEnvironment.transform 13 5377 env45530 = env45531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45530 == env45531) = true)

theorem identity45531 : scanCanonicalize (H12AffineFastState.compose env45531 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45531 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,1,479,5392,2420,1025,0,4296,168,152,3,469,64,2185,5529,4097,2556,1364,32,257,33,5592,513]

theorem envBound45532 : H12AffineFastState.Bounded env45532 := by
  intro p hp
  have h : env45532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45531_45532 : H12AffineEnvironment.transform 12 349 env45531 = env45532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45531 == env45532) = true)

theorem identity45532 : scanCanonicalize (H12AffineFastState.compose env45532 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45532 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2420,1025,0,4161,33,17,3,348,64,2048,5392,4097,2421,1364,32,257,33,5457,513]

theorem envBound45533 : H12AffineFastState.Bounded env45533 := by
  intro p hp
  have h : env45533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45532_45533 : H12AffineEnvironment.transform 6 9 env45532 = env45533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45532 == env45533) = true)

theorem identity45533 : scanCanonicalize (H12AffineFastState.compose env45533 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound45533 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2075,349,3354,1,342,3339,2420,1025,0,2138,33,17,3,348,64,2048,3339,2074,2421,1364,32,257,33,3402,513]

theorem envBound45534 : H12AffineFastState.Bounded env45534 := by
  intro p hp
  have h : env45534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45533_45534 : H12AffineEnvironment.transform 11 2075 env45533 = env45534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env45533 == env45534) = true)

theorem identity45534 : scanCanonicalize (H12AffineFastState.compose env45534 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound45534 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45535 : List Nat := [2,4,8,16,32,64,9,111,512,1024,2048,2075,50,3189,1,57,3172,2075,1025,0,2138,33,17,3,51,64,2048,3172,2074,2074,1083,32,110,33,3109,513]

theorem envBound45535 : H12AffineFastState.Bounded env45535 := by
  intro p hp
  have h : env45535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45534_45535 : H12AffineEnvironment.transform 7 111 env45534 = env45535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env45534 == env45535) = true)

theorem identity45535 : scanCanonicalize (H12AffineFastState.compose env45535 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45535 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env45536 : List Nat := [2,4,8,16,0,64,9,79,512,1024,2048,2075,18,3157,1,25,3140,2075,1025,0,2138,1,17,3,19,64,2048,3140,2074,2074,1051,0,78,1,3077,513]

theorem envBound45536 : H12AffineFastState.Bounded env45536 := by
  intro p hp
  have h : env45536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45535_45536 : H12AffineEnvironment.transform 4 0 env45535 = env45536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45535 == env45536) = true)

def env45537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,98780,8328,64,4489556,185736,17665,262281,181572,4338884,257,21792,46212,254611]

theorem envBound45537 : H12AffineFastState.Bounded env45537 := by
  intro p hp
  have h : env45537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45516_45537 : H12AffineEnvironment.transform 22 180361 env45516 = env45537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env45516 == env45537) = true)

def env45538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,98780,8328,64,43476,185736,17665,262281,181572,400452,257,21792,46212,254611]

theorem envBound45538 : H12AffineFastState.Bounded env45538 := by
  intro p hp
  have h : env45538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45537_45538 : H12AffineEnvironment.transform 21 272512 env45537 = env45538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45537 == env45538) = true)

theorem identity45538 : scanCanonicalize (H12AffineFastState.compose env45538 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound45538 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184536,272512,180361,21762,8328,64,43476,185736,17665,262281,181572,400452,257,21792,46212,144973]

theorem envBound45539 : H12AffineFastState.Bounded env45539 := by
  intro p hp
  have h : env45539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45538_45539 : H12AffineEnvironment.transform 15 54494 env45538 = env45539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env45538 == env45539) = true)

def env45540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,184400,272392,180225,21762,8192,64,43356,185600,17665,262145,181572,400452,257,21792,46092,144973]

theorem envBound45540 : H12AffineFastState.Bounded env45540 := by
  intro p hp
  have h : env45540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45539_45540 : H12AffineEnvironment.transform 6 8 env45539 = env45540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45539 == env45540) = true)

theorem identity45540 : scanCanonicalize (H12AffineFastState.compose env45540 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(16+1) ^^^ 49509) := by decide +kernel

theorem selectedBound45540 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env45541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49509,262144,1025,32769,4405,272392,356,21762,8192,64,43356,5221,17665,262145,1057,318753,257,21792,46092,63272]

theorem envBound45541 : H12AffineFastState.Bounded env45541 := by
  intro p hp
  have h : env45541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45540_45541 : H12AffineEnvironment.transform 16 49509 env45540 = env45541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49509 env45540 == env45541) = true)

theorem identity45541 : scanCanonicalize (H12AffineFastState.compose env45541 (packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound45541 : packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env45542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49509,23669,1025,32769,4405,29821,356,21762,8192,64,43356,5221,17665,23668,1057,33108,257,21792,46092,63272]

theorem envBound45542 : H12AffineFastState.Bounded env45542 := by
  intro p hp
  have h : env45542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45541_45542 : H12AffineEnvironment.transform 17 23669 env45541 = env45542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env45541 == env45542) = true)

theorem identity45542 : scanCanonicalize (H12AffineFastState.compose env45542 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45542 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env45543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,49509,23669,1025,32769,4405,21793,356,21762,348,64,34816,5221,17665,23668,1057,33108,257,21792,38224,54900]

theorem envBound45543 : H12AffineFastState.Bounded env45543 := by
  intro p hp
  have h : env45543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45542_45543 : H12AffineEnvironment.transform 12 348 env45542 = env45543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45542 == env45543) = true)

theorem identity45543 : scanCanonicalize (H12AffineFastState.compose env45543 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound45543 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21590,16741,23669,1025,1,4405,21793,356,21762,348,64,2048,5221,17665,23668,1057,340,257,21792,5456,22132]

theorem envBound45544 : H12AffineFastState.Bounded env45544 := by
  intro p hp
  have h : env45544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45543_45544 : H12AffineEnvironment.transform 14 0 env45543 = env45544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45543 == env45544) = true)

theorem identity45544 : scanCanonicalize (H12AffineFastState.compose env45544 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45544 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5221,2421,1025,1,4405,33,356,2,348,64,2048,5221,4097,2420,1057,340,257,32,5456,884]

theorem envBound45545 : H12AffineFastState.Bounded env45545 := by
  intro p hp
  have h : env45545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45544_45545 : H12AffineEnvironment.transform 13 5376 env45544 = env45545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45544 == env45545) = true)

theorem identity45545 : scanCanonicalize (H12AffineFastState.compose env45545 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45545 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45546 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,89,5125,0,83,5221,2160,1025,1,4144,33,97,2,89,64,2048,5221,4097,2161,1057,81,4,32,5205,625]

theorem envBound45546 : H12AffineFastState.Bounded env45546 := by
  intro p hp
  have h : env45546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45545_45546 : H12AffineEnvironment.transform 7 5 env45545 = env45546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45545 == env45546) = true)

theorem identity45546 : scanCanonicalize (H12AffineFastState.compose env45546 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45547 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,9,5125,0,3,5173,2080,1025,1,4144,33,49,2,9,16,2048,5173,4097,2081,1057,1,4,32,5125,545]

theorem envBound45547 : H12AffineFastState.Bounded env45547 := by
  intro p hp
  have h : env45547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45546_45547 : H12AffineEnvironment.transform 5 16 env45546 = env45547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45546 == env45547) = true)

theorem identity45547 : scanCanonicalize (H12AffineFastState.compose env45547 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound45547 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45548 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,2065,9,3092,0,3,3108,2080,1025,1,2081,33,49,2,9,16,2048,3108,2064,2081,1057,1,4,32,3092,545]

theorem envBound45548 : H12AffineFastState.Bounded env45548 := by
  intro p hp
  have h : env45548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45547_45548 : H12AffineEnvironment.transform 11 2065 env45547 = env45548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env45547 == env45548) = true)

theorem identity45548 : scanCanonicalize (H12AffineFastState.compose env45548 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45548 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45549 : List Nat := [2,4,8,16,32,16,8,5,17,1024,2048,2065,9,3092,0,3,3108,2080,1025,1,2081,33,49,2,9,16,2048,3108,2064,2081,1057,1,4,32,3092,48]

theorem envBound45549 : H12AffineFastState.Bounded env45549 := by
  intro p hp
  have h : env45549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45548_45549 : H12AffineEnvironment.transform 8 17 env45548 = env45549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45548 == env45549) = true)

theorem identity45549 : scanCanonicalize (H12AffineFastState.compose env45549 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound45549 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45550 : List Nat := [2,4,8,16,32,16,8,5,17,63,2048,2065,9,2091,0,3,2075,2080,62,1,2081,33,49,2,9,16,2048,2075,2064,2081,30,1,4,32,2091,48]

theorem envBound45550 : H12AffineFastState.Bounded env45550 := by
  intro p hp
  have h : env45550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45549_45550 : H12AffineEnvironment.transform 9 63 env45549 = env45550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env45549 == env45550) = true)

theorem identity45550 : scanCanonicalize (H12AffineFastState.compose env45550 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45550 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env45551 : List Nat := [2,4,8,16,0,16,8,5,17,31,2048,2065,9,2059,0,3,2075,2048,30,1,2049,1,17,2,9,16,2048,2075,2064,2049,30,1,4,0,2059,16]

theorem envBound45551 : H12AffineFastState.Bounded env45551 := by
  intro p hp
  have h : env45551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45550_45551 : H12AffineEnvironment.transform 4 0 env45550 = env45551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45550 == env45551) = true)

theorem identity45551 : scanCanonicalize (H12AffineFastState.compose env45551 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45552 : List Nat := [2,4,3,16,0,16,3,5,17,20,2048,2065,2,2048,0,3,2064,2048,21,1,2049,1,17,2,2,16,2048,2064,2064,2049,21,1,4,0,2048,16]

theorem envBound45552 : H12AffineFastState.Bounded env45552 := by
  intro p hp
  have h : env45552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45551_45552 : H12AffineEnvironment.transform 2 3 env45551 = env45552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45551 == env45552) = true)

theorem identity45552 : scanCanonicalize (H12AffineFastState.compose env45552 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound45552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45553 : List Nat := [2,4,3,16,0,16,3,5,17,20,4,21,2,4,0,3,20,4,21,1,5,1,17,2,2,16,4,20,20,5,21,1,4,0,4,16]

theorem envBound45553 : H12AffineFastState.Bounded env45553 := by
  intro p hp
  have h : env45553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45552_45553 : H12AffineEnvironment.transform 10 4 env45552 = env45553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env45552 == env45553) = true)

theorem identity45553 : scanCanonicalize (H12AffineFastState.compose env45553 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45553 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45554 : List Nat := [1,4,0,16,0,16,0,5,17,20,4,21,1,4,0,0,20,4,21,1,5,1,17,1,1,16,4,20,20,5,21,1,4,0,4,16]

theorem envBound45554 : H12AffineFastState.Bounded env45554 := by
  intro p hp
  have h : env45554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45553_45554 : H12AffineEnvironment.transform 0 1 env45553 = env45554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45553 == env45554) = true)

theorem identity45554 : scanCanonicalize (H12AffineFastState.compose env45554 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45554 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45555 : List Nat := [1,4,0,0,0,0,0,5,1,4,4,5,1,4,0,0,4,4,5,1,5,1,1,1,1,0,4,4,4,5,5,1,4,0,4,0]

theorem envBound45555 : H12AffineFastState.Bounded env45555 := by
  intro p hp
  have h : env45555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45554_45555 : H12AffineEnvironment.transform 3 0 env45554 = env45555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45554 == env45555) = true)

theorem identity45555 : scanCanonicalize (H12AffineFastState.compose env45555 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45555 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env45556 : List Nat := [1,0,0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0]

theorem envBound45556 : H12AffineFastState.Bounded env45556 := by
  intro p hp
  have h : env45556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45555_45556 : H12AffineEnvironment.transform 1 0 env45555 = env45556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45555 == env45556) = true)

def env45557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,184401,272393,180224,21762,8193,64,43357,185601,17665,262144,181572,400452,257,21792,46093,144973]

theorem envBound45557 : H12AffineFastState.Bounded env45557 := by
  intro p hp
  have h : env45557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45539_45557 : H12AffineEnvironment.transform 6 9 env45539 = env45557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45539 == env45557) = true)

theorem identity45557 : scanCanonicalize (H12AffineFastState.compose env45557 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound45557 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env45558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1025,32769,184401,169264,180224,21762,8193,64,43357,185601,17665,179513,181572,41341,257,21792,46093,144973]

theorem envBound45558 : H12AffineFastState.Bounded env45558 := by
  intro p hp
  have h : env45558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45557_45558 : H12AffineEnvironment.transform 17 179513 env45557 = env45558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env45557 == env45558) = true)

theorem identity45558 : scanCanonicalize (H12AffineFastState.compose env45558 (packedSelected [3,5,7,10,12,14,15,16,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound45558 : packedSelected [3,5,7,10,12,14,15,16,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,131072,138293,1025,8461,160093,144444,155916,21762,8193,64,2129,160781,17665,138293,156744,113,257,21792,5377,144973]

theorem envBound45559 : H12AffineFastState.Bounded env45559 := by
  intro p hp
  have h : env45559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45558_45559 : H12AffineEnvironment.transform 14 8460 env45558 = env45559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env45558 == env45559) = true)

theorem identity45559 : scanCanonicalize (H12AffineFastState.compose env45559 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45559 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env45560 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,29963,131072,138293,1025,8461,160013,144444,155916,21762,8193,16,2049,160781,17665,138293,156696,33,257,21792,5377,144925]

theorem envBound45560 : H12AffineFastState.Bounded env45560 := by
  intro p hp
  have h : env45560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45559_45560 : H12AffineEnvironment.transform 5 16 env45559 = env45560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45559 == env45560) = true)

theorem identity45560 : scanCanonicalize (H12AffineFastState.compose env45560 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45560 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env45561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,138293,1025,8461,140300,144444,144397,3,8193,16,2049,139532,4096,138293,143641,33,257,33,5377,144925]

theorem envBound45561 : H12AffineFastState.Bounded env45561 := by
  intro p hp
  have h : env45561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45560_45561 : H12AffineEnvironment.transform 13 5377 env45560 = env45561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45560 == env45561) = true)

theorem identity45561 : scanCanonicalize (H12AffineFastState.compose env45561 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 10557) := by decide +kernel

theorem selectedBound45561 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env45562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,10557,13576,1025,8461,3377,7425,7472,3,8193,16,2049,2097,4096,13576,6180,33,257,33,5377,7968]

theorem envBound45562 : H12AffineFastState.Bounded env45562 := by
  intro p hp
  have h : env45562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45561_45562 : H12AffineEnvironment.transform 16 10557 env45561 = env45562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10557 env45561 == env45562) = true)

theorem identity45562 : scanCanonicalize (H12AffineFastState.compose env45562 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound45562 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env45563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,5377,4112,4374,6177,1044,1025,4113,3377,7425,7472,3,4381,16,2049,2097,4096,1044,6180,33,257,33,5377,7968]

theorem envBound45563 : H12AffineFastState.Bounded env45563 := by
  intro p hp
  have h : env45563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45562_45563 : H12AffineEnvironment.transform 12 4380 env45562 = env45563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env45562 == env45563) = true)

theorem identity45563 : scanCanonicalize (H12AffineFastState.compose env45563 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound45563 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45564 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,17,269,1296,1,263,2096,1044,1025,0,3377,3344,3361,3,268,16,2049,2097,17,1044,2101,33,257,33,1296,3889]

theorem envBound45564 : H12AffineFastState.Bounded env45564 := by
  intro p hp
  have h : env45564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45563_45564 : H12AffineEnvironment.transform 11 17 env45563 = env45564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45563 == env45564) = true)

theorem identity45564 : scanCanonicalize (H12AffineFastState.compose env45564 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound45564 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env45565 : List Nat := [2,4,8,16,32,16,9,256,512,256,2048,17,269,16,1,263,2096,276,257,0,2097,2064,2081,3,268,16,2049,2097,17,276,2101,33,257,33,16,2609]

theorem envBound45565 : H12AffineFastState.Bounded env45565 := by
  intro p hp
  have h : env45565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45564_45565 : H12AffineEnvironment.transform 9 256 env45564 = env45565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env45564 == env45565) = true)

theorem identity45565 : scanCanonicalize (H12AffineFastState.compose env45565 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45565 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env45566 : List Nat := [2,4,8,16,32,16,9,256,512,256,0,17,269,16,1,263,48,276,257,0,49,16,33,3,268,16,1,49,17,276,53,33,257,33,16,561]

theorem envBound45566 : H12AffineFastState.Bounded env45566 := by
  intro p hp
  have h : env45566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45565_45566 : H12AffineEnvironment.transform 10 0 env45565 = env45566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45565 == env45566) = true)

def env45567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,98780,8328,64,43477,185736,17665,262281,181572,400453,257,21792,46212,254611]

theorem envBound45567 : H12AffineFastState.Bounded env45567 := by
  intro p hp
  have h : env45567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45537_45567 : H12AffineEnvironment.transform 21 272513 env45537 = env45567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45537 == env45567) = true)

theorem identity45567 : scanCanonicalize (H12AffineFastState.compose env45567 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound45567 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,115870,272513,120015,98780,8328,64,43477,115150,17665,262281,119042,329731,257,21792,46212,63189]

theorem envBound45568 : H12AffineFastState.Bounded env45568 := by
  intro p hp
  have h : env45568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45567_45568 : H12AffineEnvironment.transform 16 70726 env45567 = env45568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env45567 == env45568) = true)

def env45569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,115870,33,120015,98780,8328,64,43477,115150,17665,10281,119042,73891,257,21792,46212,63189]

theorem envBound45569 : H12AffineFastState.Bounded env45569 := by
  intro p hp
  have h : env45569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45568_45569 : H12AffineEnvironment.transform 17 10400 env45568 = env45569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45568 == env45569) = true)

theorem identity45569 : scanCanonicalize (H12AffineFastState.compose env45569 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound45569 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env45570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,70726,10400,1025,32769,110786,33,106643,98780,8328,64,43477,112018,12637,10281,107870,73891,257,8572,46212,33417]

theorem envBound45570 : H12AffineFastState.Bounded env45570 := by
  intro p hp
  have h : env45570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45569_45570 : H12AffineEnvironment.transform 13 13404 env45569 = env45570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env45569 == env45570) = true)

theorem identity45570 : scanCanonicalize (H12AffineFastState.compose env45570 (packedSelected [0,1,5,8,9,16,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound45570 : packedSelected [0,1,5,8,9,16,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env45571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,343,5393,10400,1025,32769,45461,33,41412,32907,8328,64,43477,46277,12637,10281,41993,8692,257,8572,46212,33417]

theorem envBound45571 : H12AffineFastState.Bounded env45571 := by
  intro p hp
  have h : env45571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45570_45571 : H12AffineEnvironment.transform 15 343 env45570 = env45571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env45570 == env45571) = true)

theorem identity45571 : scanCanonicalize (H12AffineFastState.compose env45571 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45571 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,343,5393,10281,1025,32769,45340,33,41293,32770,8193,64,43356,46156,12637,10281,41993,8573,257,8572,46093,33280]

theorem envBound45572 : H12AffineFastState.Bounded env45572 := by
  intro p hp
  have h : env45572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45571_45572 : H12AffineEnvironment.transform 6 9 env45571 = env45572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45571 == env45572) = true)

theorem identity45572 : scanCanonicalize (H12AffineFastState.compose env45572 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45572 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,343,5393,10281,1025,8541,4160,33,17,8542,8193,64,2048,5392,12637,10281,1365,8573,257,8572,5457,9052]

theorem envBound45573 : H12AffineFastState.Bounded env45573 := by
  intro p hp
  have h : env45573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45572_45573 : H12AffineEnvironment.transform 14 8540 env45572 = env45573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45572 == env45573) = true)

theorem identity45573 : scanCanonicalize (H12AffineFastState.compose env45573 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45573 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,372,343,5393,2049,1025,373,4160,33,17,374,41,64,2048,5392,4469,2049,1365,341,257,340,5457,884]

theorem envBound45574 : H12AffineFastState.Bounded env45574 := by
  intro p hp
  have h : env45574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45573_45574 : H12AffineEnvironment.transform 12 40 env45573 = env45574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45573 == env45574) = true)

theorem identity45574 : scanCanonicalize (H12AffineFastState.compose env45574 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45574 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env45575 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,1,34,5220,2049,1025,0,4160,33,17,3,41,64,2048,5221,4096,2049,1056,32,116,33,5156,513]

theorem envBound45575 : H12AffineFastState.Bounded env45575 := by
  intro p hp
  have h : env45575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45574_45575 : H12AffineEnvironment.transform 7 117 env45574 = env45575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45574 == env45575) = true)

theorem identity45575 : scanCanonicalize (H12AffineFastState.compose env45575 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45575 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45576 : List Nat := [2,4,8,16,32,64,9,117,512,1024,522,4096,40,5236,1,34,5220,523,1025,0,4160,33,17,3,41,64,522,5221,4096,523,1056,32,116,33,5156,513]

theorem envBound45576 : H12AffineFastState.Bounded env45576 := by
  intro p hp
  have h : env45576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45575_45576 : H12AffineEnvironment.transform 10 522 env45575 = env45576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45575 == env45576) = true)

theorem identity45576 : scanCanonicalize (H12AffineFastState.compose env45576 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45577 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5157,1,34,5173,523,1025,0,4113,33,17,3,41,17,522,5172,4096,523,1056,32,37,33,5156,513]

theorem envBound45577 : H12AffineFastState.Bounded env45577 := by
  intro p hp
  have h : env45577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45576_45577 : H12AffineEnvironment.transform 5 17 env45576 = env45577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45576 == env45577) = true)

theorem identity45577 : scanCanonicalize (H12AffineFastState.compose env45577 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45577 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45578 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,9,5124,1,3,5140,523,1025,0,4113,0,17,3,8,17,522,5141,4096,523,1025,1,4,0,5125,513]

theorem envBound45578 : H12AffineFastState.Bounded env45578 := by
  intro p hp
  have h : env45578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45577_45578 : H12AffineEnvironment.transform 4 1 env45577 = env45578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45577 == env45578) = true)

def env45579 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,16,9,1044,1,3,1028,523,1025,0,1,0,17,3,8,17,522,1029,16,523,1025,1,4,0,1045,513]

theorem envBound45579 : H12AffineFastState.Bounded env45579 := by
  intro p hp
  have h : env45579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45578_45579 : H12AffineEnvironment.transform 11 16 env45578 = env45579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45578 == env45579) = true)

theorem identity45579 : scanCanonicalize (H12AffineFastState.compose env45579 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound45579 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45580 : List Nat := [2,4,8,16,1,17,9,5,512,1,522,16,9,21,1,3,5,523,0,0,1,0,17,3,8,17,522,4,16,523,0,1,4,0,20,513]

theorem envBound45580 : H12AffineFastState.Bounded env45580 := by
  intro p hp
  have h : env45580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45579_45580 : H12AffineEnvironment.transform 9 1 env45579 = env45580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env45579 == env45580) = true)

def env45581 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,4,9,1,1,3,5,523,0,0,1,0,5,3,8,5,522,4,4,523,0,1,4,0,0,513]

theorem envBound45581 : H12AffineFastState.Bounded env45581 := by
  intro p hp
  have h : env45581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45580_45581 : H12AffineEnvironment.transform 3 4 env45580 = env45581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env45580 == env45581) = true)

theorem identity45581 : scanCanonicalize (H12AffineFastState.compose env45581 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound45581 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45582 : List Nat := [2,4,8,4,1,5,9,5,9,1,3,4,9,1,1,3,5,2,0,0,1,0,5,3,8,5,3,4,4,2,0,1,4,0,0,8]

theorem envBound45582 : H12AffineFastState.Bounded env45582 := by
  intro p hp
  have h : env45582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45581_45582 : H12AffineEnvironment.transform 8 9 env45581 = env45582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env45581 == env45582) = true)

def leafEnv45582 : List Nat := [2,4,8,4,1,5,9,5,9,1,3,4,9,1,1,3,5,2,0,0,1,0,5,3,0,8,1,5,3,4,4,2,0,1,4,0,4,2,0,8,1,0,0]

def active45582 : List Nat := [0,1,2]

def tree45582 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45582 : H12WitnessSearch.Good tree45582 := H12GlobalWitnessIndex.good

theorem leafIdentity45582 : H12AffineFastState.composeSystem env45582 rootObs = leafEnv45582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45582 rootObs == leafEnv45582) = true)

theorem terminalChecked45582 : H12PackedTerminal.terminalCheckFast leafEnv45582 active45582 tree45582 = true := by decide +kernel

def env45583 : List Nat := [2,4,8,5,1,4,9,5,512,1,522,5,9,0,1,3,5,523,0,0,1,0,4,3,8,4,522,4,5,523,0,1,4,0,1,513]

theorem envBound45583 : H12AffineFastState.Bounded env45583 := by
  intro p hp
  have h : env45583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45580_45583 : H12AffineEnvironment.transform 3 5 env45580 = env45583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env45580 == env45583) = true)

theorem identity45583 : scanCanonicalize (H12AffineFastState.compose env45583 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45584 : List Nat := [0,4,8,5,1,4,9,5,512,1,520,5,9,0,1,1,5,521,0,0,1,0,4,1,8,4,520,4,5,521,0,1,4,0,1,513]

theorem envBound45584 : H12AffineFastState.Bounded env45584 := by
  intro p hp
  have h : env45584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45583_45584 : H12AffineEnvironment.transform 0 0 env45583 = env45584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45583 == env45584) = true)

def leafEnv45584 : List Nat := [0,4,8,5,1,4,9,5,512,1,520,5,9,0,1,1,5,521,0,0,1,0,4,1,0,8,1,4,520,4,5,521,0,1,4,0,4,0,1,513,1,0,0]

def active45584 : List Nat := [1,2,8]

def tree45584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45584 : H12WitnessSearch.Good tree45584 := H12GlobalWitnessIndex.good

theorem leafIdentity45584 : H12AffineFastState.composeSystem env45584 rootObs = leafEnv45584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45584 rootObs == leafEnv45584) = true)

theorem terminalChecked45584 : H12PackedTerminal.terminalCheckFast leafEnv45584 active45584 tree45584 = true := by decide +kernel

def env45585 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,17,9,1045,1,3,1029,523,1025,0,0,0,17,3,8,17,522,1028,17,523,1025,1,4,0,1044,513]

theorem envBound45585 : H12AffineFastState.Bounded env45585 := by
  intro p hp
  have h : env45585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45578_45585 : H12AffineEnvironment.transform 11 17 env45578 = env45585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45578 == env45585) = true)

end H12CloudChart0