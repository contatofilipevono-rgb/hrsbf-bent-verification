import H12CloudChart0Data130

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans33245_33246 : H12AffineEnvironment.transform 6 8 env33245 = env33246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33245 == env33246) = true)

theorem identity33246 : scanCanonicalize (H12AffineFastState.compose env33246 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound33246 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env33247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,17664,32040,1025,32769,77899,21793,73755,98644,8192,65,68678,79130,17665,120883,75103,98679,257,21792,46093,513]

theorem envBound33247 : H12AffineFastState.Bounded env33247 := by
  intro p hp
  have h : env33247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33246_33247 : H12AffineEnvironment.transform 16 17664 env33246 = env33247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env33246 == env33247) = true)

theorem identity33247 : scanCanonicalize (H12AffineFastState.compose env33247 (packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound33247 : packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env33248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,9499,17664,32040,1025,32769,5456,21793,1280,42063,8192,65,10589,4097,17665,64808,68,42092,257,21792,46093,513]

theorem envBound33248 : H12AffineFastState.Bounded env33248 := by
  intro p hp
  have h : env33248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33247_33248 : H12AffineEnvironment.transform 15 9499 env33247 = env33248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env33247 == env33248) = true)

theorem identity33248 : scanCanonicalize (H12AffineFastState.compose env33248 (packedSelected [3,5,10,12,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33248 : packedSelected [3,5,10,12,38] rootPS < 2^1333 := by decide +kernel

def env33249 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,9326,17525,31837,1025,32769,5157,21588,1141,42063,8192,65,10280,4097,17524,64605,68,42092,116,21589,46093,513]

theorem envBound33249 : H12AffineFastState.Bounded env33249 := by
  intro p hp
  have h : env33249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33248_33249 : H12AffineEnvironment.transform 7 117 env33248 = env33249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33248 == env33249) = true)

theorem identity33249 : scanCanonicalize (H12AffineFastState.compose env33249 (packedSelected [3,4,5,7,9,10,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33249 : packedSelected [3,4,5,7,9,10,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env33250 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,1076,9326,17525,31837,1025,1077,5157,21588,1141,8315,8192,65,10280,4097,17524,30825,68,8280,116,21589,12345,513]

theorem envBound33250 : H12AffineFastState.Bounded env33250 := by
  intro p hp
  have h : env33250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33249_33250 : H12AffineEnvironment.transform 14 1076 env33249 = env33250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env33249 == env33250) = true)

theorem identity33250 : scanCanonicalize (H12AffineFastState.compose env33250 (packedSelected [2,6,11,12,15,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33250 : packedSelected [2,6,11,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env33251 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,1076,9326,4097,10281,1025,1077,5157,32,1141,8315,8192,65,10280,4097,4096,11293,68,8280,116,33,12345,513]

theorem envBound33251 : H12AffineFastState.Bounded env33251 := by
  intro p hp
  have h : env33251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33250_33251 : H12AffineEnvironment.transform 13 5236 env33250 = env33251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33250 == env33251) = true)

theorem identity33251 : scanCanonicalize (H12AffineFastState.compose env33251 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33251 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env33252 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,4112,80,8202,4097,10281,101,81,4161,32,17,8315,8192,65,10280,4097,4096,10361,68,8280,116,33,12345,513]

theorem envBound33252 : H12AffineFastState.Bounded env33252 := by
  intro p hp
  have h : env33252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33251_33252 : H12AffineEnvironment.transform 9 100 env33251 = env33252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33251 == env33252) = true)

theorem identity33252 : scanCanonicalize (H12AffineFastState.compose env33252 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound33252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33253 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8,4112,80,2,4097,2081,101,81,4161,32,17,115,8,65,2080,4097,4096,2161,68,80,116,33,4145,513]

theorem envBound33253 : H12AffineFastState.Bounded env33253 := by
  intro p hp
  have h : env33253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33252_33253 : H12AffineEnvironment.transform 12 8 env33252 = env33253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env33252 == env33253) = true)

theorem identity33253 : scanCanonicalize (H12AffineFastState.compose env33253 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound33253 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33254 : List Nat := [2,4,8,16,32,64,8,117,512,100,609,4096,8,4112,80,2,4097,576,101,81,4161,32,17,115,8,65,577,4097,4096,528,68,80,116,33,4145,513]

theorem envBound33254 : H12AffineFastState.Bounded env33254 := by
  intro p hp
  have h : env33254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33253_33254 : H12AffineEnvironment.transform 10 609 env33253 = env33254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env33253 == env33254) = true)

theorem identity33254 : scanCanonicalize (H12AffineFastState.compose env33254 (packedSelected [5,6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33254 : packedSelected [5,6] rootPS < 2^1333 := by decide +kernel

def env33255 : List Nat := [2,4,8,16,10,64,8,95,512,78,587,4096,8,4112,80,2,4097,576,79,81,4161,10,17,89,8,65,577,4097,4096,528,68,80,94,11,4123,513]

theorem envBound33255 : H12AffineFastState.Bounded env33255 := by
  intro p hp
  have h : env33255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33254_33255 : H12AffineEnvironment.transform 4 10 env33254 = env33255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33254 == env33255) = true)

theorem identity33255 : scanCanonicalize (H12AffineFastState.compose env33255 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33255 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env33256 : List Nat := [2,4,8,16,10,17,8,14,512,31,538,4096,8,4112,1,2,4097,529,30,0,4112,10,17,8,8,16,528,4097,4096,528,21,1,15,11,4123,513]

theorem envBound33256 : H12AffineFastState.Bounded env33256 := by
  intro p hp
  have h : env33256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33255_33256 : H12AffineEnvironment.transform 5 17 env33255 = env33256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33255 == env33256) = true)

theorem identity33256 : scanCanonicalize (H12AffineFastState.compose env33256 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound33256 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33257 : List Nat := [2,4,8,16,10,17,8,14,27,31,1,4096,8,4112,1,2,4097,10,30,0,4112,10,17,8,8,16,11,4097,4096,11,21,1,15,11,4123,26]

theorem envBound33257 : H12AffineFastState.Bounded env33257 := by
  intro p hp
  have h : env33257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33256_33257 : H12AffineEnvironment.transform 8 27 env33256 = env33257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env33256 == env33257) = true)

theorem identity33257 : scanCanonicalize (H12AffineFastState.compose env33257 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33258 : List Nat := [2,4,8,11,10,10,8,14,0,4,1,4096,8,4107,1,2,4097,10,5,0,4107,10,10,8,8,11,11,4097,4096,11,14,1,15,11,4096,1]

theorem envBound33258 : H12AffineFastState.Bounded env33258 := by
  intro p hp
  have h : env33258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33257_33258 : H12AffineEnvironment.transform 3 11 env33257 = env33258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33257 == env33258) = true)

theorem identity33258 : scanCanonicalize (H12AffineFastState.compose env33258 (packedSelected [3,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33258 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env33259 : List Nat := [2,4,3,0,1,1,3,5,0,4,1,4096,3,4096,1,2,4097,1,5,0,4096,1,1,3,3,0,0,4097,4096,0,5,1,4,0,4096,1]

theorem envBound33259 : H12AffineFastState.Bounded env33259 := by
  intro p hp
  have h : env33259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33258_33259 : H12AffineEnvironment.transform 2 3 env33258 = env33259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33258 == env33259) = true)

def env33260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77899,21793,73755,98645,8193,65,215366,79130,17665,236850,75102,98679,257,21792,46092,513]

theorem envBound33260 : H12AffineFastState.Bounded env33260 := by
  intro p hp
  have h : env33260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33245_33260 : H12AffineEnvironment.transform 6 9 env33245 = env33260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33245 == env33260) = true)

theorem identity33260 : scanCanonicalize (H12AffineFastState.compose env33260 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33260 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env33261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1025,29788,77899,21793,73755,95496,8193,65,215366,79130,17665,223599,75102,95530,257,21792,16465,513]

theorem envBound33261 : H12AffineFastState.Bounded env33261 := by
  intro p hp
  have h : env33261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33260_33261 : H12AffineEnvironment.transform 14 29789 env33260 = env33261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33260 == env33261) = true)

theorem identity33261 : scanCanonicalize (H12AffineFastState.compose env33261 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound33261 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env33262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,131072,32041,1025,29788,17728,21793,21776,3,8193,65,146509,16401,17665,138340,20565,33,257,21792,16465,513]

theorem envBound33262 : H12AffineFastState.Bounded env33262 := by
  intro p hp
  have h : env33262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33261_33262 : H12AffineEnvironment.transform 15 29963 env33261 = env33262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env33261 == env33262) = true)

theorem identity33262 : scanCanonicalize (H12AffineFastState.compose env33262 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound33262 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,8283,131072,10361,1025,8460,4112,113,64,3,8193,65,146509,5441,4177,138340,1285,33,257,112,5377,513]

theorem envBound33263 : H12AffineFastState.Bounded env33263 := by
  intro p hp
  have h : env33263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33262_33263 : H12AffineEnvironment.transform 13 5456 env33262 = env33263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env33262 == env33263) = true)

theorem identity33263 : scanCanonicalize (H12AffineFastState.compose env33263 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33263 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33264 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10280,1025,8460,4112,32,17,3,8193,16,146460,5392,4096,138293,1285,33,257,33,5377,513]

theorem envBound33264 : H12AffineFastState.Bounded env33264 := by
  intro p hp
  have h : env33264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33263_33264 : H12AffineEnvironment.transform 5 17 env33263 = env33264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33263 == env33264) = true)

theorem identity33264 : scanCanonicalize (H12AffineFastState.compose env33264 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound33264 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33265 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,260,3,131072,2081,1025,261,4112,32,17,3,8,16,138261,5392,4096,138293,1285,33,257,33,5377,513]

theorem envBound33265 : H12AffineFastState.Bounded env33265 := by
  intro p hp
  have h : env33265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33264_33265 : H12AffineEnvironment.transform 12 9 env33264 = env33265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env33264 == env33265) = true)

theorem identity33265 : scanCanonicalize (H12AffineFastState.compose env33265 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound33265 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33266 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,260,3,5140,2081,1025,261,4112,32,17,3,8,16,2049,5392,4096,2081,1285,33,257,33,5377,513]

theorem envBound33266 : H12AffineFastState.Bounded env33266 := by
  intro p hp
  have h : env33266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33265_33266 : H12AffineEnvironment.transform 16 5140 env33265 = env33266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env33265 == env33266) = true)

theorem identity33266 : scanCanonicalize (H12AffineFastState.compose env33266 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound33266 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33267 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,4096,9,5377,260,3,5140,261,1025,261,4112,32,17,3,8,16,293,5392,4096,261,1285,33,257,33,5377,513]

theorem envBound33267 : H12AffineFastState.Bounded env33267 := by
  intro p hp
  have h : env33267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33266_33267 : H12AffineEnvironment.transform 10 292 env33266 = env33267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env33266 == env33267) = true)

theorem identity33267 : scanCanonicalize (H12AffineFastState.compose env33267 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound33267 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33268 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,276,9,1045,260,3,1280,261,1025,261,260,32,17,3,8,16,293,1028,276,261,1285,33,257,33,1045,513]

theorem envBound33268 : H12AffineFastState.Bounded env33268 := by
  intro p hp
  have h : env33268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33267_33268 : H12AffineEnvironment.transform 11 276 env33267 = env33268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env33267 == env33268) = true)

theorem identity33268 : scanCanonicalize (H12AffineFastState.compose env33268 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33268 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33269 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,16,9,1045,0,3,1028,1,1025,1,0,32,17,3,8,16,33,1028,16,1,1025,33,5,33,1045,513]

theorem envBound33269 : H12AffineFastState.Bounded env33269 := by
  intro p hp
  have h : env33269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33268_33269 : H12AffineEnvironment.transform 7 4 env33268 = env33269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33268 == env33269) = true)

theorem identity33269 : scanCanonicalize (H12AffineFastState.compose env33269 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33270 : List Nat := [2,4,8,16,0,17,9,4,512,1024,0,16,9,1045,0,3,1028,1,1025,1,0,0,17,3,8,16,1,1028,16,1,1025,1,5,1,1045,513]

theorem envBound33270 : H12AffineFastState.Bounded env33270 := by
  intro p hp
  have h : env33270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33269_33270 : H12AffineEnvironment.transform 4 0 env33269 = env33270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33269 == env33270) = true)

theorem identity33270 : scanCanonicalize (H12AffineFastState.compose env33270 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound33270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33271 : List Nat := [2,4,8,16,0,17,9,4,512,532,0,16,9,513,0,3,528,1,533,1,0,0,17,3,8,16,1,528,16,1,533,1,5,1,513,513]

theorem envBound33271 : H12AffineFastState.Bounded env33271 := by
  intro p hp
  have h : env33271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33270_33271 : H12AffineEnvironment.transform 9 532 env33270 = env33271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env33270 == env33271) = true)

theorem identity33271 : scanCanonicalize (H12AffineFastState.compose env33271 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33271 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33272 : List Nat := [2,4,8,16,0,17,9,4,0,20,0,16,9,1,0,3,16,1,21,1,0,0,17,3,8,16,1,16,16,1,21,1,5,1,1,1]

theorem envBound33272 : H12AffineFastState.Bounded env33272 := by
  intro p hp
  have h : env33272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33271_33272 : H12AffineEnvironment.transform 8 0 env33271 = env33272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33271 == env33272) = true)

theorem identity33272 : scanCanonicalize (H12AffineFastState.compose env33272 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33272 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33273 : List Nat := [2,4,8,0,0,1,9,4,0,4,0,0,9,1,0,3,0,1,5,1,0,0,1,3,8,0,1,0,0,1,5,1,5,1,1,1]

theorem envBound33273 : H12AffineFastState.Bounded env33273 := by
  intro p hp
  have h : env33273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33272_33273 : H12AffineEnvironment.transform 3 0 env33272 = env33273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33272 == env33273) = true)

def env33274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98781,8328,65,12729468,79130,8480027,8568225,8390093,4314198,257,8484155,8492190,8462875]

theorem envBound33274 : H12AffineFastState.Bounded env33274 := by
  intro p hp
  have h : env33274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33210_33274 : H12AffineEnvironment.transform 17 32161 env33210 = env33274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env33210 == env33274) = true)

def env33275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98781,8328,65,8546652,79130,8480027,8568225,8390093,98678,257,8484155,8492190,8462875]

theorem envBound33275 : H12AffineFastState.Bounded env33275 := by
  intro p hp
  have h : env33275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33274_33275 : H12AffineEnvironment.transform 21 21792 env33274 = env33275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env33274 == env33275) = true)

theorem identity33275 : scanCanonicalize (H12AffineFastState.compose env33275 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound33275 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,120015,98781,8328,65,245139,79130,45524,223598,119042,98678,257,41460,16465,63188]

theorem envBound33276 : H12AffineFastState.Bounded env33276 := by
  intro p hp
  have h : env33276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33275_33276 : H12AffineEnvironment.transform 22 120015 env33275 = env33276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env33275 == env33276) = true)

def env33277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1025,32769,77898,32,98767,98781,8328,65,245139,79130,45524,212078,99330,98678,257,41460,5457,41940]

theorem envBound33277 : H12AffineFastState.Bounded env33277 := by
  intro p hp
  have h : env33277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33276_33277 : H12AffineEnvironment.transform 13 5376 env33276 = env33277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33276 == env33277) = true)

theorem identity33277 : scanCanonicalize (H12AffineFastState.compose env33277 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33277 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,77898,32,98630,98644,8193,65,245018,79130,45405,212078,99330,98678,257,41341,5457,41821]

theorem envBound33278 : H12AffineFastState.Bounded env33278 := by
  intro p hp
  have h : env33278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33277_33278 : H12AffineEnvironment.transform 6 9 env33277 = env33278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33277 == env33278) = true)

theorem identity33278 : scanCanonicalize (H12AffineFastState.compose env33278 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33278 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env33279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10280,1025,32769,4160,32,41292,41310,8193,65,171280,5392,45405,138340,41992,41340,257,41341,5457,41821]

theorem envBound33279 : H12AffineFastState.Bounded env33279 := by
  intro p hp
  have h : env33279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33278_33279 : H12AffineEnvironment.transform 15 8202 env33278 = env33279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33278 == env33279) = true)

theorem identity33279 : scanCanonicalize (H12AffineFastState.compose env33279 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound33279 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env33280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5425,10280,1025,32769,4160,32,41292,41310,8193,65,34849,5392,45405,2389,41992,41340,257,41341,5457,41821]

theorem envBound33280 : H12AffineFastState.Bounded env33280 := by
  intro p hp
  have h : env33280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33279_33280 : H12AffineEnvironment.transform 16 5425 env33279 = env33280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env33279 == env33280) = true)

theorem identity33280 : scanCanonicalize (H12AffineFastState.compose env33280 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8572) := by decide +kernel

theorem selectedBound33280 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8572,8202,5425,10280,1025,8573,4160,32,48,34,8193,65,10589,5392,4129,2389,1396,0,257,1,5457,545]

theorem envBound33281 : H12AffineFastState.Bounded env33281 := by
  intro p hp
  have h : env33281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33280_33281 : H12AffineEnvironment.transform 14 8572 env33280 = env33281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8572 env33280 == env33281) = true)

theorem identity33281 : scanCanonicalize (H12AffineFastState.compose env33281 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33281 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33282 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5392,10249,1025,8540,4160,1,17,3,8193,65,10589,5392,4096,2389,1365,0,257,1,5457,512]

theorem envBound33282 : H12AffineFastState.Bounded env33282 := by
  intro p hp
  have h : env33282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33281_33282 : H12AffineEnvironment.transform 4 1 env33281 = env33282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33281 == env33282) = true)

theorem identity33282 : scanCanonicalize (H12AffineFastState.compose env33282 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33282 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33283 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,5392,10249,1025,8460,4112,1,17,3,8193,17,10509,5392,4096,2309,1285,0,257,1,5377,512]

theorem envBound33283 : H12AffineFastState.Bounded env33283 := by
  intro p hp
  have h : env33283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33282_33283 : H12AffineEnvironment.transform 5 16 env33282 = env33283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33282 == env33283) = true)

theorem identity33283 : scanCanonicalize (H12AffineFastState.compose env33283 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33284 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5376,0,263,5392,2308,1025,1,4112,1,17,3,268,17,2048,5392,4096,2309,1285,0,257,1,5377,512]

theorem envBound33284 : H12AffineFastState.Bounded env33284 := by
  intro p hp
  have h : env33284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33283_33284 : H12AffineEnvironment.transform 12 269 env33283 = env33284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33283 == env33284) = true)

theorem identity33284 : scanCanonicalize (H12AffineFastState.compose env33284 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound33284 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33285 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1028,269,260,0,263,276,2308,1025,1,1044,1,17,3,268,17,2048,276,1028,2309,1285,0,257,1,261,512]

theorem envBound33285 : H12AffineFastState.Bounded env33285 := by
  intro p hp
  have h : env33285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33284_33285 : H12AffineEnvironment.transform 11 1028 env33284 = env33285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env33284 == env33285) = true)

theorem identity33285 : scanCanonicalize (H12AffineFastState.compose env33285 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound33285 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33286 : List Nat := [2,4,8,16,1,16,9,256,261,1024,2048,1028,269,260,0,263,276,2308,1025,1,1044,1,17,3,268,17,2048,276,1028,2309,1285,0,257,1,261,261]

theorem envBound33286 : H12AffineFastState.Bounded env33286 := by
  intro p hp
  have h : env33286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33285_33286 : H12AffineEnvironment.transform 8 261 env33285 = env33286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env33285 == env33286) = true)

theorem identity33286 : scanCanonicalize (H12AffineFastState.compose env33286 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound33286 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33287 : List Nat := [2,4,8,16,1,16,9,256,261,1024,1029,1028,269,260,0,263,276,1281,1025,1,1044,1,17,3,268,17,1029,276,1028,1280,1285,0,257,1,261,261]

theorem envBound33287 : H12AffineFastState.Bounded env33287 := by
  intro p hp
  have h : env33287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33286_33287 : H12AffineEnvironment.transform 10 1029 env33286 = env33287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env33286 == env33287) = true)

theorem identity33287 : scanCanonicalize (H12AffineFastState.compose env33287 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33287 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33288 : List Nat := [2,4,8,1,1,1,9,256,261,1024,1029,1028,269,260,0,263,261,1281,1025,1,1029,1,0,3,268,0,1029,261,1028,1280,1285,0,257,1,261,261]

theorem envBound33288 : H12AffineFastState.Bounded env33288 := by
  intro p hp
  have h : env33288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33287_33288 : H12AffineEnvironment.transform 3 1 env33287 = env33288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33287 == env33288) = true)

theorem identity33288 : scanCanonicalize (H12AffineFastState.compose env33288 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound33288 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33289 : List Nat := [2,4,8,1,1,1,9,256,261,257,260,261,269,260,0,263,261,0,256,1,260,1,0,3,268,0,260,261,261,1,4,0,257,1,261,261]

theorem envBound33289 : H12AffineFastState.Bounded env33289 := by
  intro p hp
  have h : env33289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33288_33289 : H12AffineEnvironment.transform 9 257 env33288 = env33289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env33288 == env33289) = true)

theorem identity33289 : scanCanonicalize (H12AffineFastState.compose env33289 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33290 : List Nat := [2,4,8,1,1,1,9,5,0,4,1,0,8,1,0,2,0,0,5,1,1,1,0,3,9,0,1,0,0,1,4,0,4,1,0,0]

theorem envBound33290 : H12AffineFastState.Bounded env33290 := by
  intro p hp
  have h : env33290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33289_33290 : H12AffineEnvironment.transform 7 5 env33289 = env33290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33289 == env33290) = true)

theorem identity33290 : scanCanonicalize (H12AffineFastState.compose env33290 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33290 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33291 : List Nat := [2,1,8,1,1,1,9,0,0,1,1,0,8,1,0,2,0,0,0,1,1,1,0,3,9,0,1,0,0,1,1,0,1,1,0,0]

theorem envBound33291 : H12AffineFastState.Bounded env33291 := by
  intro p hp
  have h : env33291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33290_33291 : H12AffineEnvironment.transform 1 1 env33290 = env33291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33290 == env33291) = true)

def env33292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1025,32769,77898,33,98766,98781,8328,65,245139,79130,45524,212079,99331,98678,257,41460,5456,41941]

theorem envBound33292 : H12AffineFastState.Bounded env33292 := by
  intro p hp
  have h : env33292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33276_33292 : H12AffineEnvironment.transform 13 5377 env33276 = env33292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33276 == env33292) = true)

theorem identity33292 : scanCanonicalize (H12AffineFastState.compose env33292 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound33292 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,46277,10400,1025,32769,77898,33,98766,98781,8328,65,67926,79130,45524,100522,99331,98678,257,41460,5456,41941]

theorem envBound33293 : H12AffineFastState.Bounded env33293 := by
  intro p hp
  have h : env33293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33292_33293 : H12AffineEnvironment.transform 16 46277 env33292 = env33293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env33292 == env33293) = true)

theorem identity33293 : scanCanonicalize (H12AffineFastState.compose env33293 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33293 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env33294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,46277,10400,1025,32769,4161,33,41413,41430,8328,65,10589,5393,45524,43169,41992,41341,257,41460,5456,41941]

theorem envBound33294 : H12AffineFastState.Bounded env33294 := by
  intro p hp
  have h : env33294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33293_33294 : H12AffineEnvironment.transform 15 8203 env33293 = env33294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33293 == env33294) = true)

theorem identity33294 : scanCanonicalize (H12AffineFastState.compose env33294 (packedSelected [0,6,17,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33294 : packedSelected [0,6,17,27] rootPS < 2^1333 := by decide +kernel

def env33295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,5529,10400,1025,8541,4161,33,153,138,8328,65,10589,5393,4232,2557,1364,33,257,168,5456,649]

theorem envBound33295 : H12AffineFastState.Bounded env33295 := by
  intro p hp
  have h : env33295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33294_33295 : H12AffineEnvironment.transform 14 8540 env33294 = env33295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33294 == env33295) = true)

theorem identity33295 : scanCanonicalize (H12AffineFastState.compose env33295 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound33295 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,137,478,5529,2421,1025,136,4161,33,153,138,349,65,2184,5393,4232,2557,1364,33,257,168,5456,649]

theorem envBound33296 : H12AffineFastState.Bounded env33296 := by
  intro p hp
  have h : env33296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33295_33296 : H12AffineEnvironment.transform 12 469 env33295 = env33296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env33295 == env33296) = true)

theorem identity33296 : scanCanonicalize (H12AffineFastState.compose env33296 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33296 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33297 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,469,4453,137,478,4605,2421,101,136,4161,33,153,138,349,65,2184,4469,4232,2557,304,33,257,168,4404,649]

theorem envBound33297 : H12AffineFastState.Bounded env33297 := by
  intro p hp
  have h : env33297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33296_33297 : H12AffineEnvironment.transform 9 100 env33296 = env33297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33296 == env33297) = true)

theorem identity33297 : scanCanonicalize (H12AffineFastState.compose env33297 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound33297 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env33298 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2248,469,2477,137,478,2357,2421,101,136,2185,33,153,138,349,65,2184,2493,2112,2557,304,33,257,168,2556,649]

theorem envBound33298 : H12AffineFastState.Bounded env33298 := by
  intro p hp
  have h : env33298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33297_33298 : H12AffineEnvironment.transform 11 2248 env33297 = env33298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env33297 == env33298) = true)

theorem identity33298 : scanCanonicalize (H12AffineFastState.compose env33298 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound33298 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env33299 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,2248,121,2049,137,114,2201,2265,101,136,2185,33,153,138,241,65,2184,2065,2112,2129,156,33,173,168,2128,649]

theorem envBound33299 : H12AffineFastState.Bounded env33299 := by
  intro p hp
  have h : env33299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33298_33299 : H12AffineEnvironment.transform 7 172 env33298 = env33299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33298 == env33299) = true)

theorem identity33299 : scanCanonicalize (H12AffineFastState.compose env33299 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound33299 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33300 : List Nat := [2,4,8,16,32,64,128,172,512,100,137,65,121,136,137,114,16,80,101,136,0,33,153,138,241,65,1,152,201,216,156,33,173,168,217,649]

theorem envBound33300 : H12AffineFastState.Bounded env33300 := by
  intro p hp
  have h : env33300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33299_33300 : H12AffineEnvironment.transform 10 137 env33299 = env33300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env33299 == env33300) = true)

theorem identity33300 : scanCanonicalize (H12AffineFastState.compose env33300 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33300 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33301 : List Nat := [2,4,8,16,32,16,128,172,512,52,137,17,41,136,137,34,16,0,53,136,0,33,153,138,161,17,1,152,153,136,156,33,173,168,137,649]

theorem envBound33301 : H12AffineFastState.Bounded env33301 := by
  intro p hp
  have h : env33301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33300_33301 : H12AffineEnvironment.transform 5 16 env33300 = env33301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33300 == env33301) = true)

theorem identity33301 : scanCanonicalize (H12AffineFastState.compose env33301 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33301 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env33302 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,0,1,34,16,0,53,0,0,33,17,2,41,17,1,16,17,0,20,33,37,32,1,513]

theorem envBound33302 : H12AffineFastState.Bounded env33302 := by
  intro p hp
  have h : env33302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33301_33302 : H12AffineEnvironment.transform 6 8 env33301 = env33302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33301 == env33302) = true)

theorem identity33302 : scanCanonicalize (H12AffineFastState.compose env33302 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33303 : List Nat := [2,4,8,16,32,16,8,36,16,52,1,17,41,0,1,34,16,0,53,0,0,33,17,2,41,17,1,16,17,0,20,33,37,32,1,17]

theorem envBound33303 : H12AffineFastState.Bounded env33303 := by
  intro p hp
  have h : env33303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33302_33303 : H12AffineEnvironment.transform 8 16 env33302 = env33303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33302 == env33303) = true)

theorem identity33303 : scanCanonicalize (H12AffineFastState.compose env33303 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33304 : List Nat := [2,4,8,16,10,16,8,14,16,30,1,17,3,0,1,8,16,0,31,0,0,11,17,2,3,17,1,16,17,0,20,11,15,10,1,17]

theorem envBound33304 : H12AffineFastState.Bounded env33304 := by
  intro p hp
  have h : env33304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33303_33304 : H12AffineEnvironment.transform 4 10 env33303 = env33304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33303 == env33304) = true)

theorem identity33304 : scanCanonicalize (H12AffineFastState.compose env33304 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33305 : List Nat := [2,4,8,1,10,1,8,14,1,15,1,0,3,0,1,8,1,0,14,0,0,11,0,2,3,0,1,1,0,0,5,11,15,10,1,0]

theorem envBound33305 : H12AffineFastState.Bounded env33305 := by
  intro p hp
  have h : env33305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33304_33305 : H12AffineEnvironment.transform 3 1 env33304 = env33305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33304 == env33305) = true)

def env33306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98781,8328,65,8546653,79130,8480027,8568225,8390093,98679,257,8484155,8492190,8462875]

theorem envBound33306 : H12AffineFastState.Bounded env33306 := by
  intro p hp
  have h : env33306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33274_33306 : H12AffineEnvironment.transform 21 21793 env33274 = env33306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env33274 == env33306) = true)

theorem identity33306 : scanCanonicalize (H12AffineFastState.compose env33306 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound33306 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32161,1025,32769,58516,21793,8388608,21763,8328,65,8546653,57796,8434117,8568225,8390093,21929,257,8430053,8405056,8451781]

theorem envBound33307 : H12AffineFastState.Bounded env33307 := by
  intro p hp
  have h : env33307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33306_33307 : H12AffineEnvironment.transform 15 54494 env33306 = env33307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env33306 == env33307) = true)

def env33308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58396,21793,8388608,21763,8192,65,8546653,57676,8433997,8568105,8389957,21793,257,8429933,8405056,8451661]

theorem envBound33308 : H12AffineFastState.Bounded env33308 := by
  intro p hp
  have h : env33308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33307_33308 : H12AffineEnvironment.transform 6 8 env33307 = env33308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33307 == env33308) = true)

theorem identity33308 : scanCanonicalize (H12AffineFastState.compose env33308 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 147457) := by decide +kernel

theorem selectedBound33308 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58396,21793,147457,21763,8192,65,10588,57676,192844,64808,148804,21793,257,188780,131137,177740]

theorem envBound33309 : H12AffineFastState.Bounded env33309 := by
  intro p hp
  have h : env33309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33308_33309 : H12AffineEnvironment.transform 22 147457 env33308 = env33309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env33308 == env33309) = true)

theorem identity33309 : scanCanonicalize (H12AffineFastState.compose env33309 (packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33309 : packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env33310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,32041,1025,8540,17729,21793,147457,21763,8192,65,10588,16401,151569,23669,148804,21793,257,147505,131137,136977]

theorem envBound33310 : H12AffineFastState.Bounded env33310 := by
  intro p hp
  have h : env33310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33309_33310 : H12AffineEnvironment.transform 14 8541 env33309 = env33310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33309 == env33310) = true)

theorem identity33310 : scanCanonicalize (H12AffineFastState.compose env33310 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33310 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,5392,32041,1025,8540,17729,21793,21777,21763,8192,65,10588,16401,17665,23669,20564,21793,257,21793,5457,513]

theorem envBound33311 : H12AffineFastState.Bounded env33311 := by
  intro p hp
  have h : env33311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33310_33311 : H12AffineEnvironment.transform 16 5392 env33310 = env33311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33310 == env33311) = true)

theorem identity33311 : scanCanonicalize (H12AffineFastState.compose env33311 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound33311 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1296,20806,5392,22884,1025,1297,17729,21793,21777,21763,1101,65,3345,16401,17665,23669,20564,21793,257,21793,5457,513]

theorem envBound33312 : H12AffineFastState.Bounded env33312 := by
  intro p hp
  have h : env33312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33311_33312 : H12AffineEnvironment.transform 12 1101 env33311 = env33312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env33311 == env33312) = true)

theorem identity33312 : scanCanonicalize (H12AffineFastState.compose env33312 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33312 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1296,1094,5392,3172,1025,1297,4161,33,17,3,1101,65,3345,5393,4097,2421,1364,33,257,33,5457,513]

theorem envBound33313 : H12AffineFastState.Bounded env33313 := by
  intro p hp
  have h : env33313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33312_33313 : H12AffineEnvironment.transform 13 5376 env33312 = env33313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33312 == env33313) = true)

theorem identity33313 : scanCanonicalize (H12AffineFastState.compose env33313 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound33313 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33314 : List Nat := [2,4,8,16,32,64,8,256,512,800,2048,4096,877,4640,560,870,4656,2884,801,561,4161,33,17,3,877,65,2609,4657,4097,2421,628,33,257,33,4721,513]

theorem envBound33314 : H12AffineFastState.Bounded env33314 := by
  intro p hp
  have h : env33314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33313_33314 : H12AffineEnvironment.transform 9 800 env33313 = env33314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env33313 == env33314) = true)

theorem identity33314 : scanCanonicalize (H12AffineFastState.compose env33314 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound33314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33315 : List Nat := [2,4,8,16,32,64,8,256,48,272,2048,4096,349,4112,0,342,4096,2420,273,1,4161,33,17,3,349,65,2049,4097,4097,2421,68,33,257,33,4161,49]

theorem envBound33315 : H12AffineFastState.Bounded env33315 := by
  intro p hp
  have h : env33315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33314_33315 : H12AffineEnvironment.transform 8 48 env33314 = env33315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33314 == env33315) = true)

theorem identity33315 : scanCanonicalize (H12AffineFastState.compose env33315 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33316 : List Nat := [2,4,8,16,32,64,8,20,48,4,2048,4096,73,4112,0,66,4096,2144,5,1,4161,33,17,3,73,65,2049,4097,4097,2145,68,33,21,33,4161,49]

theorem envBound33316 : H12AffineFastState.Bounded env33316 := by
  intro p hp
  have h : env33316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33315_33316 : H12AffineEnvironment.transform 7 20 env33315 = env33316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33315 == env33316) = true)

theorem identity33316 : scanCanonicalize (H12AffineFastState.compose env33316 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound33316 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33317 : List Nat := [2,4,8,16,32,64,8,20,48,4,2048,1,73,17,0,66,1,2144,5,1,64,33,17,3,73,65,2049,0,0,2145,68,33,21,33,64,49]

theorem envBound33317 : H12AffineFastState.Bounded env33317 := by
  intro p hp
  have h : env33317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33316_33317 : H12AffineEnvironment.transform 11 1 env33316 = env33317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33316 == env33317) = true)

theorem identity33317 : scanCanonicalize (H12AffineFastState.compose env33317 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33317 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env33318 : List Nat := [2,4,8,16,1,64,8,20,17,4,2048,1,73,17,0,66,1,2113,5,1,64,0,17,3,73,65,2049,0,0,2112,68,0,21,0,64,16]

theorem envBound33318 : H12AffineFastState.Bounded env33318 := by
  intro p hp
  have h : env33318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33317_33318 : H12AffineEnvironment.transform 4 1 env33317 = env33318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33317 == env33318) = true)

theorem identity33318 : scanCanonicalize (H12AffineFastState.compose env33318 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33318 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env33319 : List Nat := [2,4,8,16,1,17,8,20,17,4,2048,1,24,17,0,19,1,2064,5,1,17,0,17,3,24,16,2049,0,0,2065,21,0,21,0,17,16]

theorem envBound33319 : H12AffineFastState.Bounded env33319 := by
  intro p hp
  have h : env33319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33318_33319 : H12AffineEnvironment.transform 5 17 env33318 = env33319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33318 == env33319) = true)

theorem identity33319 : scanCanonicalize (H12AffineFastState.compose env33319 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33320 : List Nat := [2,4,8,0,1,1,8,4,1,4,2048,1,8,1,0,3,1,2048,5,1,1,0,1,3,8,0,2049,0,0,2049,5,0,5,0,1,0]

theorem envBound33320 : H12AffineFastState.Bounded env33320 := by
  intro p hp
  have h : env33320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33319_33320 : H12AffineEnvironment.transform 3 0 env33319 = env33320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33319 == env33320) = true)

theorem identity33320 : scanCanonicalize (H12AffineFastState.compose env33320 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33320 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33321 : List Nat := [2,4,8,0,1,1,8,4,1,4,0,1,8,1,0,3,1,0,5,1,1,0,1,3,8,0,1,0,0,1,5,0,5,0,1,0]

theorem envBound33321 : H12AffineFastState.Bounded env33321 := by
  intro p hp
  have h : env33321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33320_33321 : H12AffineEnvironment.transform 10 0 env33320 = env33321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33320 == env33321) = true)

def env33322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58397,21793,8388608,21763,8193,65,8546653,57677,8433996,8568104,8389956,21792,257,8429932,8405056,8451660]

theorem envBound33322 : H12AffineFastState.Bounded env33322 := by
  intro p hp
  have h : env33322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33307_33322 : H12AffineEnvironment.transform 6 9 env33307 = env33322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33307 == env33322) = true)

theorem identity33322 : scanCanonicalize (H12AffineFastState.compose env33322 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 62541) := by decide +kernel

theorem selectedBound33322 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58397,21793,62541,21763,8193,65,171280,57677,17665,149861,61705,21792,257,21793,46093,513]

theorem envBound33323 : H12AffineFastState.Bounded env33323 := by
  intro p hp
  have h : env33323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33322_33323 : H12AffineEnvironment.transform 22 62541 env33322 = env33323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env33322 == env33323) = true)

theorem identity33323 : scanCanonicalize (H12AffineFastState.compose env33323 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33323 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env33324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,5392,32040,1025,32769,58397,21793,62541,21763,8193,65,34816,57677,17665,23669,61705,21792,257,21793,46093,513]

theorem envBound33324 : H12AffineFastState.Bounded env33324 := by
  intro p hp
  have h : env33324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33323_33324 : H12AffineEnvironment.transform 16 5392 env33323 = env33324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33323 == env33324) = true)

theorem identity33324 : scanCanonicalize (H12AffineFastState.compose env33324 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33324 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env33325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,5392,32040,1025,29789,4161,21793,17,21763,8193,65,31836,5393,17665,23669,1365,21792,257,21793,16465,513]

theorem envBound33325 : H12AffineFastState.Bounded env33325 := by
  intro p hp
  have h : env33325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33324_33325 : H12AffineEnvironment.transform 14 29788 env33324 = env33325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33324 == env33325) = true)

theorem identity33325 : scanCanonicalize (H12AffineFastState.compose env33325 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33325 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1025,8540,4161,32,17,2,8193,65,10589,5393,4096,2420,1365,33,257,32,5456,513]

theorem envBound33326 : H12AffineFastState.Bounded env33326 := by
  intro p hp
  have h : env33326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33325_33326 : H12AffineEnvironment.transform 13 5377 env33325 = env33326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33325 == env33326) = true)

theorem identity33326 : scanCanonicalize (H12AffineFastState.compose env33326 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33326 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2420,1025,1,4161,32,17,2,348,65,2048,5393,4096,2420,1365,33,257,32,5456,513]

theorem envBound33327 : H12AffineFastState.Bounded env33327 := by
  intro p hp
  have h : env33327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33326_33327 : H12AffineEnvironment.transform 12 349 env33326 = env33327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33326 == env33327) = true)

theorem identity33327 : scanCanonicalize (H12AffineFastState.compose env33327 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound33327 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1819,4096,349,5377,0,342,5392,1647,1025,1,4161,32,17,2,348,65,1819,5393,4096,1647,1365,33,257,32,5456,513]

theorem envBound33328 : H12AffineFastState.Bounded env33328 := by
  intro p hp
  have h : env33328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33327_33328 : H12AffineEnvironment.transform 10 1819 env33327 = env33328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env33327 == env33328) = true)

theorem identity33328 : scanCanonicalize (H12AffineFastState.compose env33328 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound33328 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33329 : List Nat := [2,4,8,16,32,64,9,256,512,101,894,4096,349,4452,0,342,4469,522,100,1,4161,32,17,2,348,65,894,4468,4096,522,304,33,257,32,4405,513]

theorem envBound33329 : H12AffineFastState.Bounded env33329 := by
  intro p hp
  have h : env33329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33328_33329 : H12AffineEnvironment.transform 9 101 env33328 = env33329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env33328 == env33329) = true)

theorem identity33329 : scanCanonicalize (H12AffineFastState.compose env33329 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 619) := by decide +kernel

theorem selectedBound33329 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env33330 : List Nat := [2,4,8,16,32,64,9,256,512,101,894,619,349,783,0,342,798,522,100,1,554,32,17,2,348,65,894,799,619,522,304,33,257,32,862,513]

theorem envBound33330 : H12AffineFastState.Bounded env33330 := by
  intro p hp
  have h : env33330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33329_33330 : H12AffineEnvironment.transform 11 619 env33329 = env33330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 619 env33329 == env33330) = true)

theorem identity33330 : scanCanonicalize (H12AffineFastState.compose env33330 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound33330 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33331 : List Nat := [2,4,8,16,32,64,9,84,512,101,554,619,9,603,0,2,586,522,100,1,554,32,17,2,8,65,554,587,619,522,100,33,85,32,522,513]

theorem envBound33331 : H12AffineFastState.Bounded env33331 := by
  intro p hp
  have h : env33331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33330_33331 : H12AffineEnvironment.transform 7 84 env33330 = env33331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env33330 == env33331) = true)

theorem identity33331 : scanCanonicalize (H12AffineFastState.compose env33331 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound33331 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33332 : List Nat := [2,4,8,16,32,42,9,62,512,15,554,513,9,561,0,2,544,522,14,1,554,32,17,2,8,43,554,545,513,522,14,33,63,32,522,513]

theorem envBound33332 : H12AffineFastState.Bounded env33332 := by
  intro p hp
  have h : env33332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33331_33332 : H12AffineEnvironment.transform 5 42 env33331 = env33332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env33331 == env33332) = true)

theorem identity33332 : scanCanonicalize (H12AffineFastState.compose env33332 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33332 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33333 : List Nat := [2,4,8,7,32,42,9,41,512,15,554,513,9,550,0,2,544,522,14,1,554,32,6,2,8,43,554,545,513,522,14,33,40,32,522,513]

theorem envBound33333 : H12AffineFastState.Bounded env33333 := by
  intro p hp
  have h : env33333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33332_33333 : H12AffineEnvironment.transform 3 7 env33332 = env33333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33332 == env33333) = true)

theorem identity33333 : scanCanonicalize (H12AffineFastState.compose env33333 (packedSelected [1,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33333 : packedSelected [1,4,10] rootPS < 2^1333 := by decide +kernel

def env33334 : List Nat := [2,4,8,7,1,11,9,8,512,15,523,513,9,519,0,2,513,522,14,1,523,1,6,2,8,10,523,512,513,522,14,0,9,1,522,513]

theorem envBound33334 : H12AffineFastState.Bounded env33334 := by
  intro p hp
  have h : env33334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33333_33334 : H12AffineEnvironment.transform 4 1 env33333 = env33334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33333 == env33334) = true)

theorem identity33334 : scanCanonicalize (H12AffineFastState.compose env33334 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound33334 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33335 : List Nat := [2,4,8,7,1,11,9,8,7,15,12,6,9,0,0,2,6,13,14,1,12,1,6,2,8,10,12,7,6,13,14,0,9,1,13,6]

theorem envBound33335 : H12AffineFastState.Bounded env33335 := by
  intro p hp
  have h : env33335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33334_33335 : H12AffineEnvironment.transform 8 7 env33334 = env33335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env33334 == env33335) = true)

theorem identity33335 : scanCanonicalize (H12AffineFastState.compose env33335 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33336 : List Nat := [2,4,1,7,1,2,0,1,7,6,5,6,0,0,0,2,6,4,7,1,5,1,6,2,1,3,5,7,6,4,7,0,0,1,4,6]

theorem envBound33336 : H12AffineFastState.Bounded env33336 := by
  intro p hp
  have h : env33336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33335_33336 : H12AffineEnvironment.transform 2 1 env33335 = env33336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33335 == env33336) = true)

theorem identity33336 : scanCanonicalize (H12AffineFastState.compose env33336 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33336 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33337 : List Nat := [1,4,1,4,1,1,0,1,4,5,5,5,0,0,0,1,5,4,4,1,5,1,5,1,1,0,5,4,5,4,4,0,0,1,4,5]

theorem envBound33337 : H12AffineFastState.Bounded env33337 := by
  intro p hp
  have h : env33337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33336_33337 : H12AffineEnvironment.transform 0 1 env33336 = env33337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33336 == env33337) = true)

def env33338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392317,8328,65,12729469,79131,8722618,8830976,8681581,4314199,257,8484154,8492191,8740795]

theorem envBound33338 : H12AffineFastState.Bounded env33338 := by
  intro p hp
  have h : env33338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33209_33338 : H12AffineEnvironment.transform 23 392317 env33209 = env33338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392317 env33209 == env33338) = true)

def env33339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98781,8328,65,12729469,79131,8480026,8568224,8390093,4314199,257,8484154,8492191,8462875]

theorem envBound33339 : H12AffineFastState.Bounded env33339 := by
  intro p hp
  have h : env33339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33338_33339 : H12AffineEnvironment.transform 17 32160 env33338 = env33339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env33338 == env33339) = true)

def env33340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98781,8328,65,8546653,79131,8480026,8568224,8390093,98679,257,8484154,8492191,8462875]

theorem envBound33340 : H12AffineFastState.Bounded env33340 := by
  intro p hp
  have h : env33340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33339_33340 : H12AffineEnvironment.transform 21 21792 env33339 = env33340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env33339 == env33340) = true)

theorem identity33340 : scanCanonicalize (H12AffineFastState.compose env33340 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound33340 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,62661,98781,8328,65,171416,79131,102879,149861,61704,98679,257,98815,90202,120542]

theorem envBound33341 : H12AffineFastState.Bounded env33341 := by
  intro p hp
  have h : env33341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33340_33341 : H12AffineEnvironment.transform 22 62661 env33340 = env33341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env33340 == env33341) = true)

def env33342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10280,1025,32769,77899,168,41293,98781,8328,65,171416,79131,102879,138477,42112,98679,257,98815,79314,99158]

theorem envBound33342 : H12AffineFastState.Bounded env33342 := by
  intro p hp
  have h : env33342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33341_33342 : H12AffineEnvironment.transform 13 5512 env33341 = env33342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env33341 == env33342) = true)

def env33343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,46276,10280,1025,32769,77899,168,41293,98781,8328,65,10588,79131,102879,43049,42112,98679,257,98815,79314,99158]

theorem envBound33343 : H12AffineFastState.Bounded env33343 := by
  intro p hp
  have h : env33343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33342_33343 : H12AffineEnvironment.transform 16 46276 env33342 = env33343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env33342 == env33343) = true)

theorem identity33343 : scanCanonicalize (H12AffineFastState.compose env33343 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33343 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,5528,10280,1025,8541,77899,168,17,73857,8328,65,10588,79131,77955,2421,1500,73771,257,73891,79314,74250]

theorem envBound33344 : H12AffineFastState.Bounded env33344 := by
  intro p hp
  have h : env33344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33343_33344 : H12AffineEnvironment.transform 14 8540 env33343 = env33344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33343 == env33344) = true)

theorem identity33344 : scanCanonicalize (H12AffineFastState.compose env33344 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33344 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,5392,10280,1025,8541,77899,32,17,73737,8192,65,10588,79131,77835,2421,1364,73771,257,73771,79194,74250]

theorem envBound33345 : H12AffineFastState.Bounded env33345 := by
  intro p hp
  have h : env33345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33344_33345 : H12AffineEnvironment.transform 6 8 env33344 = env33345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33344 == env33345) = true)

theorem identity33345 : scanCanonicalize (H12AffineFastState.compose env33345 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound33345 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,2,5392,10280,1025,8541,12361,32,17,8203,8192,65,10588,13593,12297,2421,1364,8233,257,8233,13656,8712]

theorem envBound33346 : H12AffineFastState.Bounded env33346 := by
  intro p hp
  have h : env33346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33345_33346 : H12AffineEnvironment.transform 15 2 env33345 = env33346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env33345 == env33346) = true)

theorem identity33346 : scanCanonicalize (H12AffineFastState.compose env33346 (packedSelected [0,7,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33346 : packedSelected [0,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env33347 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8312,2,5172,10280,1025,8313,12361,32,17,8203,8192,65,10360,13373,12297,2129,1136,8233,37,8233,13436,8712]

theorem envBound33347 : H12AffineFastState.Bounded env33347 := by
  intro p hp
  have h : env33347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33346_33347 : H12AffineEnvironment.transform 7 36 env33346 = env33347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33346 == env33347) = true)

theorem identity33347 : scanCanonicalize (H12AffineFastState.compose env33347 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound33347 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33348 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8,5156,112,2,5172,2080,1025,113,4161,32,17,3,8,65,2160,5173,4097,2129,1136,33,37,33,5236,512]

theorem envBound33348 : H12AffineFastState.Bounded env33348 := by
  intro p hp
  have h : env33348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33347_33348 : H12AffineEnvironment.transform 12 8 env33347 = env33348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env33347 == env33348) = true)

theorem identity33348 : scanCanonicalize (H12AffineFastState.compose env33348 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33348 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33349 : List Nat := [2,4,8,16,32,64,8,36,512,21,2048,4096,8,4145,112,2,4129,2080,20,113,4161,32,17,3,8,65,2160,4128,4097,2129,101,33,37,33,4193,512]

theorem envBound33349 : H12AffineFastState.Bounded env33349 := by
  intro p hp
  have h : env33349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33348_33349 : H12AffineEnvironment.transform 9 21 env33348 = env33349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33348 == env33349) = true)

theorem identity33349 : scanCanonicalize (H12AffineFastState.compose env33349 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound33349 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33350 : List Nat := [2,4,8,16,32,64,8,36,512,21,2048,16,8,33,112,2,49,2080,20,113,81,32,17,3,8,65,2160,48,17,2129,101,33,37,33,113,512]

theorem envBound33350 : H12AffineFastState.Bounded env33350 := by
  intro p hp
  have h : env33350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33349_33350 : H12AffineEnvironment.transform 11 16 env33349 = env33350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33349 == env33350) = true)

theorem identity33350 : scanCanonicalize (H12AffineFastState.compose env33350 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound33350 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33351 : List Nat := [2,4,8,16,32,64,8,36,512,21,32,16,8,33,112,2,49,0,20,113,81,32,17,3,8,65,80,48,17,113,101,33,37,33,113,512]

theorem envBound33351 : H12AffineFastState.Bounded env33351 := by
  intro p hp
  have h : env33351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33350_33351 : H12AffineEnvironment.transform 10 32 env33350 = env33351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env33350 == env33351) = true)

theorem identity33351 : scanCanonicalize (H12AffineFastState.compose env33351 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33351 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env33352 : List Nat := [2,4,8,16,32,16,8,36,512,21,32,16,8,33,32,2,49,0,20,33,1,32,17,3,8,17,0,48,17,33,53,33,37,33,33,512]

theorem envBound33352 : H12AffineFastState.Bounded env33352 := by
  intro p hp
  have h : env33352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33351_33352 : H12AffineEnvironment.transform 5 16 env33351 = env33352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33351 == env33352) = true)

def env33353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,46277,10280,1025,32769,77899,168,41293,98781,8328,65,10589,79131,102879,43048,42112,98679,257,98815,79314,99158]

theorem envBound33353 : H12AffineFastState.Bounded env33353 := by
  intro p hp
  have h : env33353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33342_33353 : H12AffineEnvironment.transform 16 46277 env33342 = env33353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env33342 == env33353) = true)

theorem identity33353 : scanCanonicalize (H12AffineFastState.compose env33353 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound33353 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,137,65536,13388,10280,1025,136,77899,168,8644,65876,8328,65,10589,79131,69974,10401,9225,66046,257,65910,79314,66527]

theorem envBound33354 : H12AffineFastState.Bounded env33354 := by
  intro p hp
  have h : env33354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33353_33354 : H12AffineEnvironment.transform 14 137 env33353 = env33354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env33353 == env33354) = true)

theorem identity33354 : scanCanonicalize (H12AffineFastState.compose env33354 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33354 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,65536,13388,10280,1025,1,77899,33,8525,65876,8193,65,10589,79131,69974,10280,9225,65911,257,65910,79195,66390]

theorem envBound33355 : H12AffineFastState.Bounded env33355 := by
  intro p hp
  have h : env33355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33354_33355 : H12AffineEnvironment.transform 6 9 env33354 = env33355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33354 == env33355) = true)

theorem identity33355 : scanCanonicalize (H12AffineFastState.compose env33355 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound33355 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env33356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,343,13388,10280,1025,1,12572,33,8525,3,8193,65,10589,13388,4097,10280,9225,32,257,33,13324,513]

theorem envBound33356 : H12AffineFastState.Bounded env33356 := by
  intro p hp
  have h : env33356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33355_33356 : H12AffineEnvironment.transform 15 343 env33355 = env33356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env33355 == env33356) = true)

theorem identity33356 : scanCanonicalize (H12AffineFastState.compose env33356 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33356 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5393,2421,1025,1,4161,33,16,3,348,65,2048,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound33357 : H12AffineFastState.Bounded env33357 := by
  intro p hp
  have h : env33357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33356_33357 : H12AffineEnvironment.transform 12 349 env33356 = env33357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33356 == env33357) = true)

theorem identity33357 : scanCanonicalize (H12AffineFastState.compose env33357 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound33357 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,522,4096,349,5377,0,343,5393,895,1025,1,4161,33,16,3,348,65,522,5393,4097,895,1364,32,257,33,5457,513]

theorem envBound33358 : H12AffineFastState.Bounded env33358 := by
  intro p hp
  have h : env33358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33357_33358 : H12AffineEnvironment.transform 10 522 env33357 = env33358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env33357 == env33358) = true)

theorem identity33358 : scanCanonicalize (H12AffineFastState.compose env33358 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33358 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33359 : List Nat := [2,4,8,16,32,64,9,37,512,1024,522,4096,120,5156,0,114,5172,602,1025,1,4161,33,16,3,121,65,522,5172,4097,602,1137,32,36,33,5236,513]

theorem envBound33359 : H12AffineFastState.Bounded env33359 := by
  intro p hp
  have h : env33359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33358_33359 : H12AffineEnvironment.transform 7 37 env33358 = env33359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33358 == env33359) = true)

theorem identity33359 : scanCanonicalize (H12AffineFastState.compose env33359 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33359 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33360 : List Nat := [2,4,8,16,32,17,9,37,512,1024,522,4096,41,5156,0,35,5172,523,1025,1,4112,33,16,3,40,16,522,5172,4097,523,1056,32,36,33,5157,513]

theorem envBound33360 : H12AffineFastState.Bounded env33360 := by
  intro p hp
  have h : env33360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33359_33360 : H12AffineEnvironment.transform 5 17 env33359 = env33360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33359 == env33360) = true)

def env33361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10281,1025,32769,77899,169,41292,98781,8328,65,171416,79131,102879,138476,42113,98679,257,98815,79315,99159]

theorem envBound33361 : H12AffineFastState.Bounded env33361 := by
  intro p hp
  have h : env33361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33341_33361 : H12AffineEnvironment.transform 13 5513 env33341 = env33361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env33341 == env33361) = true)

theorem identity33361 : scanCanonicalize (H12AffineFastState.compose env33361 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound33361 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,65536,131072,10281,1025,8661,77899,169,152,73737,8328,65,146508,79131,77835,138476,1365,73891,257,73771,79315,74371]

theorem envBound33362 : H12AffineFastState.Bounded env33362 := by
  intro p hp
  have h : env33362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33361_33362 : H12AffineEnvironment.transform 14 8660 env33361 = env33362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env33361 == env33362) = true)

theorem identity33362 : scanCanonicalize (H12AffineFastState.compose env33362 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33362 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,65536,5392,10281,1025,8661,77899,169,152,73737,8328,65,10588,79131,77835,2556,1365,73891,257,73771,79315,74371]

theorem envBound33363 : H12AffineFastState.Bounded env33363 := by
  intro p hp
  have h : env33363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33362_33363 : H12AffineEnvironment.transform 16 5392 env33362 = env33363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33362 == env33363) = true)

theorem identity33363 : scanCanonicalize (H12AffineFastState.compose env33363 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33363 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33364 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4249,8660,65536,4096,10281,273,8661,77899,169,152,73737,8328,65,10588,77835,77835,2556,69,73891,257,73771,78019,74371]

theorem envBound33364 : H12AffineFastState.Bounded env33364 := by
  intro p hp
  have h : env33364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33363_33364 : H12AffineEnvironment.transform 9 272 env33363 = env33364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33363 == env33364) = true)

theorem identity33364 : scanCanonicalize (H12AffineFastState.compose env33364 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound33364 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env33365 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4249,8660,479,4096,10281,273,8661,12692,169,152,8662,8328,65,10588,12756,12756,2556,69,8572,257,8692,12572,9052]

theorem envBound33365 : H12AffineFastState.Bounded env33365 := by
  intro p hp
  have h : env33365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33364_33365 : H12AffineEnvironment.transform 15 479 env33364 = env33365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env33364 == env33365) = true)

theorem identity33365 : scanCanonicalize (H12AffineFastState.compose env33365 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33365 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env33366 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,348,4249,136,479,4096,2421,273,137,4296,169,152,138,468,65,2048,4232,4232,2556,69,32,257,168,4160,512]

theorem envBound33366 : H12AffineFastState.Bounded env33366 := by
  intro p hp
  have h : env33366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33365_33366 : H12AffineEnvironment.transform 12 348 env33365 = env33366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33365 == env33366) = true)

theorem identity33366 : scanCanonicalize (H12AffineFastState.compose env33366 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound33366 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33367 : List Nat := [2,4,8,16,32,64,120,256,512,272,2048,4096,348,4193,112,295,4096,2421,273,113,4144,81,96,114,300,65,2048,4208,4208,2308,69,32,257,80,4160,512]

theorem envBound33367 : H12AffineFastState.Bounded env33367 := by
  intro p hp
  have h : env33367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33366_33367 : H12AffineEnvironment.transform 6 120 env33366 = env33367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env33366 == env33367) = true)

theorem identity33367 : scanCanonicalize (H12AffineFastState.compose env33367 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33367 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33368 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,300,4113,0,295,4096,2309,273,1,4144,33,16,2,300,49,2048,4096,4096,2308,53,32,257,32,4144,512]

theorem envBound33368 : H12AffineFastState.Bounded env33368 := by
  intro p hp
  have h : env33368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33367_33368 : H12AffineEnvironment.transform 5 48 env33367 = env33368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33367 == env33368) = true)

theorem identity33368 : scanCanonicalize (H12AffineFastState.compose env33368 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound33368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33369 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,48,300,33,0,295,48,2309,273,1,0,33,16,2,300,49,2048,48,48,2308,53,32,257,32,0,512]

theorem envBound33369 : H12AffineFastState.Bounded env33369 := by
  intro p hp
  have h : env33369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33368_33369 : H12AffineEnvironment.transform 11 48 env33368 = env33369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33368 == env33369) = true)

theorem identity33369 : scanCanonicalize (H12AffineFastState.compose env33369 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33369 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33370 : List Nat := [2,4,8,16,1,17,8,256,512,272,2048,17,269,0,0,262,17,2309,273,1,0,0,16,2,269,16,2048,17,17,2308,20,1,257,1,0,512]

theorem envBound33370 : H12AffineFastState.Bounded env33370 := by
  intro p hp
  have h : env33370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33369_33370 : H12AffineEnvironment.transform 4 1 env33369 = env33370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33369 == env33370) = true)

theorem identity33370 : scanCanonicalize (H12AffineFastState.compose env33370 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound33370 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33371 : List Nat := [2,4,8,16,1,17,8,256,260,272,2048,17,269,0,0,262,17,2309,273,1,0,0,16,2,269,16,2048,17,17,2308,20,1,257,1,0,260]

theorem envBound33371 : H12AffineFastState.Bounded env33371 := by
  intro p hp
  have h : env33371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33370_33371 : H12AffineEnvironment.transform 8 260 env33370 = env33371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env33370 == env33371) = true)

theorem identity33371 : scanCanonicalize (H12AffineFastState.compose env33371 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound33371 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33372 : List Nat := [2,4,8,16,1,17,8,256,260,272,16,17,269,0,0,262,17,277,273,1,0,0,16,2,269,16,16,17,17,276,20,1,257,1,0,260]

theorem envBound33372 : H12AffineFastState.Bounded env33372 := by
  intro p hp
  have h : env33372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33371_33372 : H12AffineEnvironment.transform 10 16 env33371 = env33372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env33371 == env33372) = true)

theorem identity33372 : scanCanonicalize (H12AffineFastState.compose env33372 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 26) := by decide +kernel

theorem selectedBound33372 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33373 : List Nat := [2,4,8,16,1,17,8,26,30,10,16,17,23,0,0,28,17,15,11,1,0,0,16,2,23,16,16,17,17,14,20,1,27,1,0,30]

theorem envBound33373 : H12AffineFastState.Bounded env33373 := by
  intro p hp
  have h : env33373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33372_33373 : H12AffineEnvironment.transform 7 26 env33372 = env33373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 26 env33372 == env33373) = true)

theorem identity33373 : scanCanonicalize (H12AffineFastState.compose env33373 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33374 : List Nat := [2,4,6,16,1,17,6,20,16,4,16,17,23,0,0,18,17,1,5,1,0,0,16,2,23,16,16,17,17,0,20,1,21,1,0,16]

theorem envBound33374 : H12AffineFastState.Bounded env33374 := by
  intro p hp
  have h : env33374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33373_33374 : H12AffineEnvironment.transform 2 6 env33373 = env33374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33373 == env33374) = true)

theorem identity33374 : scanCanonicalize (H12AffineFastState.compose env33374 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33375 : List Nat := [2,4,6,1,1,0,6,5,1,4,1,0,6,0,0,3,0,1,5,1,0,0,1,2,6,1,1,0,0,0,5,1,4,1,0,1]

theorem envBound33375 : H12AffineFastState.Bounded env33375 := by
  intro p hp
  have h : env33375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33374_33375 : H12AffineEnvironment.transform 3 1 env33374 = env33375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33374 == env33375) = true)

def env33376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98781,8328,65,8546652,79131,8480026,8568224,8390093,98678,257,8484154,8492191,8462875]

theorem envBound33376 : H12AffineFastState.Bounded env33376 := by
  intro p hp
  have h : env33376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33339_33376 : H12AffineEnvironment.transform 21 21793 env33339 = env33376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env33339 == env33376) = true)

theorem identity33376 : scanCanonicalize (H12AffineFastState.compose env33376 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound33376 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32160,1025,29909,77899,21793,8388608,95497,8328,65,8546652,79131,8480026,8538484,8390093,95650,257,8484154,8478795,8462875]

theorem envBound33377 : H12AffineFastState.Bounded env33377 := by
  intro p hp
  have h : env33377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33376_33377 : H12AffineEnvironment.transform 14 29908 env33376 = env33377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env33376 == env33377) = true)

def env33378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,77899,33,8388608,73737,8328,65,8535132,79131,8466458,8526964,8390093,73890,257,8462394,8467787,8462875]

theorem envBound33378 : H12AffineFastState.Bounded env33378 := by
  intro p hp
  have h : env33378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33377_33378 : H12AffineEnvironment.transform 13 5376 env33377 = env33378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33377 == env33378) = true)

theorem identity33378 : scanCanonicalize (H12AffineFastState.compose env33378 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound33378 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,77899,33,17,73737,8328,65,146509,79131,77835,138341,1500,73890,257,73771,79194,74250]

theorem envBound33379 : H12AffineFastState.Bounded env33379 := by
  intro p hp
  have h : env33379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33378_33379 : H12AffineEnvironment.transform 22 17 env33378 = env33379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env33378 == env33379) = true)

theorem identity33379 : scanCanonicalize (H12AffineFastState.compose env33379 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound33379 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,478,131072,10400,1025,8661,12693,33,17,8663,8328,65,146509,13509,12757,138341,1500,8572,257,8693,13444,9172]

theorem envBound33380 : H12AffineFastState.Bounded env33380 := by
  intro p hp
  have h : env33380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33379_33380 : H12AffineEnvironment.transform 15 478 env33379 = env33380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env33379 == env33380) = true)

theorem identity33380 : scanCanonicalize (H12AffineFastState.compose env33380 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33380 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,478,5392,10400,1025,8661,12693,33,17,8663,8328,65,10589,13509,12757,2421,1500,8572,257,8693,13444,9172]

theorem envBound33381 : H12AffineFastState.Bounded env33381 := by
  intro p hp
  have h : env33381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33380_33381 : H12AffineEnvironment.transform 16 5392 env33380 = env33381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33380 == env33381) = true)

def env33382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1025,8660,77899,32,8388608,73736,8328,65,8535133,79131,8466459,8526965,8390093,73891,257,8462395,8467786,8462875]

theorem envBound33382 : H12AffineFastState.Bounded env33382 := by
  intro p hp
  have h : env33382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33377_33382 : H12AffineEnvironment.transform 13 5377 env33377 = env33382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33377 == env33382) = true)

theorem identity33382 : scanCanonicalize (H12AffineFastState.compose env33382 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,77899,32,8388608,73736,8193,65,8535133,79131,8466459,8526965,8389956,73770,257,8462395,8467786,8462875]

theorem envBound33383 : H12AffineFastState.Bounded env33383 := by
  intro p hp
  have h : env33383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33382_33383 : H12AffineEnvironment.transform 6 9 env33382 = env33383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33382 == env33383) = true)

theorem identity33383 : scanCanonicalize (H12AffineFastState.compose env33383 (packedSelected [16,20] rootPS)) = affineNative (2^(22+1) ^^^ 65862) := by decide +kernel

theorem selectedBound33383 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,77899,32,65862,73736,8193,65,212251,79131,12637,204083,66562,73770,257,8573,13324,9053]

theorem envBound33384 : H12AffineFastState.Bounded env33384 := by
  intro p hp
  have h : env33384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33383_33384 : H12AffineEnvironment.transform 22 65862 env33383 = env33384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65862 env33383 == env33384) = true)

theorem identity33384 : scanCanonicalize (H12AffineFastState.compose env33384 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33384 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env33385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10280,1025,8541,4160,32,8525,3,8193,65,138512,5392,12637,146744,9225,33,257,8573,13324,9053]

theorem envBound33385 : H12AffineFastState.Bounded env33385 := by
  intro p hp
  have h : env33385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33384_33385 : H12AffineEnvironment.transform 15 8203 env33384 = env33385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33384 == env33385) = true)

theorem identity33385 : scanCanonicalize (H12AffineFastState.compose env33385 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound33385 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env33386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5221,10280,1025,8541,4160,32,8525,3,8193,65,2421,5392,12637,10589,9225,33,257,8573,13324,9053]

theorem envBound33386 : H12AffineFastState.Bounded env33386 := by
  intro p hp
  have h : env33386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33385_33386 : H12AffineEnvironment.transform 16 5221 env33385 = env33386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env33385 == env33386) = true)

theorem identity33386 : scanCanonicalize (H12AffineFastState.compose env33386 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33386 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33387 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8233,8203,5221,10280,1025,8232,4160,32,8248,3,8193,65,2048,5221,12328,10280,9225,33,116,8200,13324,8744]

theorem envBound33387 : H12AffineFastState.Bounded env33387 := by
  intro p hp
  have h : env33387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33386_33387 : H12AffineEnvironment.transform 7 117 env33386 = env33387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33386 == env33387) = true)

theorem identity33387 : scanCanonicalize (H12AffineFastState.compose env33387 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33387 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env33388 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,0,34,5221,2049,1025,1,4160,32,17,3,40,65,2048,5221,4097,2049,1056,33,116,33,5157,513]

theorem envBound33388 : H12AffineFastState.Bounded env33388 := by
  intro p hp
  have h : env33388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33387_33388 : H12AffineEnvironment.transform 12 41 env33387 = env33388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33387 == env33388) = true)

theorem identity33388 : scanCanonicalize (H12AffineFastState.compose env33388 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound33388 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33389 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1647,4096,41,5236,0,34,5221,1646,1025,1,4160,32,17,3,40,65,1647,5221,4097,1646,1056,33,116,33,5157,513]

theorem envBound33389 : H12AffineFastState.Bounded env33389 := by
  intro p hp
  have h : env33389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33388_33389 : H12AffineEnvironment.transform 10 1647 env33388 = env33389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env33388 == env33389) = true)

theorem identity33389 : scanCanonicalize (H12AffineFastState.compose env33389 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound33389 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33390 : List Nat := [2,4,8,16,32,64,9,117,512,575,80,4096,41,4683,0,34,4698,81,574,1,4160,32,17,3,40,65,80,4698,4097,81,543,33,116,33,4634,513]

theorem envBound33390 : H12AffineFastState.Bounded env33390 := by
  intro p hp
  have h : env33390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33389_33390 : H12AffineEnvironment.transform 9 575 env33389 = env33390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env33389 == env33390) = true)

theorem identity33390 : scanCanonicalize (H12AffineFastState.compose env33390 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33390 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33391 : List Nat := [2,4,8,16,32,64,9,117,42,21,80,4096,41,4193,0,34,4208,81,20,1,4160,32,17,3,40,65,80,4208,4097,81,53,33,116,33,4144,43]

theorem envBound33391 : H12AffineFastState.Bounded env33391 := by
  intro p hp
  have h : env33391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33390_33391 : H12AffineEnvironment.transform 8 42 env33390 = env33391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33390 == env33391) = true)

theorem identity33391 : scanCanonicalize (H12AffineFastState.compose env33391 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound33391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33392 : List Nat := [2,4,8,16,32,9,9,60,42,21,25,4096,41,4136,0,34,4153,24,20,1,4105,32,17,3,40,8,25,4153,4097,24,53,33,61,33,4144,43]

theorem envBound33392 : H12AffineFastState.Bounded env33392 := by
  intro p hp
  have h : env33392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33391_33392 : H12AffineEnvironment.transform 5 9 env33391 = env33392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env33391 == env33392) = true)

def env33393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98780,8328,65,12729469,79131,8480027,8568225,8390092,4314199,257,8484154,8492191,8462874]

theorem envBound33393 : H12AffineFastState.Bounded env33393 := by
  intro p hp
  have h : env33393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33338_33393 : H12AffineEnvironment.transform 17 32161 env33338 = env33393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env33338 == env33393) = true)

def env33394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98780,8328,65,8546653,79131,8480027,8568225,8390092,98679,257,8484154,8492191,8462874]

theorem envBound33394 : H12AffineFastState.Bounded env33394 := by
  intro p hp
  have h : env33394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33393_33394 : H12AffineEnvironment.transform 21 21792 env33393 = env33394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env33393 == env33394) = true)

def env33395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21792,8388608,98644,8192,65,8546653,79131,8480027,8568105,8389956,98679,257,8484154,8492055,8462874]

theorem envBound33395 : H12AffineFastState.Bounded env33395 := by
  intro p hp
  have h : env33395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33394_33395 : H12AffineEnvironment.transform 6 8 env33394 = env33395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33394 == env33395) = true)

theorem identity33395 : scanCanonicalize (H12AffineFastState.compose env33395 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound33395 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,32041,1025,32769,77898,21792,8388608,98644,8192,65,8399181,79131,8480027,8453433,8389956,98679,257,8484154,8492055,8462874]

theorem envBound33396 : H12AffineFastState.Bounded env33396 := by
  intro p hp
  have h : env33396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33395_33396 : H12AffineEnvironment.transform 16 16400 env33395 = env33396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env33395 == env33396) = true)

def env33397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10281,1025,32769,77898,32,8388608,98644,8192,65,8399181,79131,8466459,8431673,8389956,98679,257,8462394,8492055,8462874]

theorem envBound33397 : H12AffineFastState.Bounded env33397 := by
  intro p hp
  have h : env33397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33396_33397 : H12AffineEnvironment.transform 13 5376 env33396 = env33397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33396 == env33397) = true)

theorem identity33397 : scanCanonicalize (H12AffineFastState.compose env33397 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33397 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,5392,10281,1025,8541,77898,32,8388608,73736,8192,65,8399181,79131,8466459,8391013,8389956,73771,257,8462394,8467787,8462874]

theorem envBound33398 : H12AffineFastState.Bounded env33398 := by
  intro p hp
  have h : env33398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33397_33398 : H12AffineEnvironment.transform 14 8540 env33397 = env33398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33397 == env33398) = true)

theorem identity33398 : scanCanonicalize (H12AffineFastState.compose env33398 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33398 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5392,10281,1025,8541,4160,32,8388608,2,8192,65,8399181,5393,8392721,8391013,8389956,33,257,8388656,8394049,8389136]

theorem envBound33399 : H12AffineFastState.Bounded env33399 := by
  intro p hp
  have h : env33399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33398_33399 : H12AffineEnvironment.transform 15 8202 env33398 = env33399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33398 == env33399) = true)

theorem identity33399 : scanCanonicalize (H12AffineFastState.compose env33399 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(22+1) ^^^ 1028) := by decide +kernel

theorem selectedBound33399 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env33400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5392,10281,1025,8541,4160,32,1028,2,8192,65,11593,5393,5141,3425,320,33,257,1076,4421,1556]

theorem envBound33400 : H12AffineFastState.Bounded env33400 := by
  intro p hp
  have h : env33400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33399_33400 : H12AffineEnvironment.transform 22 1028 env33399 = env33400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1028 env33399 == env33400) = true)

theorem identity33400 : scanCanonicalize (H12AffineFastState.compose env33400 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound33400 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env33401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5376,113,295,5392,2308,1025,112,4160,32,1028,2,301,65,3172,5393,5141,3425,320,33,257,1076,4421,1556]

theorem envBound33401 : H12AffineFastState.Bounded env33401 := by
  intro p hp
  have h : env33401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33400_33401 : H12AffineEnvironment.transform 12 301 env33400 = env33401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env33400 == env33401) = true)

theorem identity33401 : scanCanonicalize (H12AffineFastState.compose env33401 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound33401 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33402 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,4096,301,4145,113,295,4129,2308,304,112,4160,32,309,2,301,65,2389,4128,4388,2128,320,33,257,261,4421,805]

theorem envBound33402 : H12AffineFastState.Bounded env33402 := by
  intro p hp
  have h : env33402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33401_33402 : H12AffineEnvironment.transform 9 305 env33401 = env33402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env33401 == env33402) = true)

theorem identity33402 : scanCanonicalize (H12AffineFastState.compose env33402 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound33402 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33403 : List Nat := [2,4,8,16,32,64,8,256,512,305,293,4096,301,4145,113,295,4129,33,304,112,4160,32,309,2,301,65,112,4128,4388,373,320,33,257,261,4421,805]

theorem envBound33403 : H12AffineFastState.Bounded env33403 := by
  intro p hp
  have h : env33403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33402_33403 : H12AffineEnvironment.transform 10 293 env33402 = env33403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env33402 == env33403) = true)

theorem identity33403 : scanCanonicalize (H12AffineFastState.compose env33403 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound33403 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env33404 : List Nat := [2,4,8,16,32,64,8,256,512,305,293,276,301,293,113,295,309,33,304,112,340,32,309,2,301,65,112,308,48,373,320,33,257,261,81,805]

theorem envBound33404 : H12AffineFastState.Bounded env33404 := by
  intro p hp
  have h : env33404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33403_33404 : H12AffineEnvironment.transform 11 276 env33403 = env33404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env33403 == env33404) = true)

theorem identity33404 : scanCanonicalize (H12AffineFastState.compose env33404 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound33404 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env33405 : List Nat := [2,4,8,16,32,64,8,256,372,305,293,276,301,293,113,295,309,33,304,112,340,32,309,2,301,65,112,308,48,373,320,33,257,261,81,81]

theorem envBound33405 : H12AffineFastState.Bounded env33405 := by
  intro p hp
  have h : env33405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33404_33405 : H12AffineEnvironment.transform 8 372 env33404 = env33405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env33404 == env33405) = true)

theorem identity33405 : scanCanonicalize (H12AffineFastState.compose env33405 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33405 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33406 : List Nat := [2,4,8,16,1,64,8,256,341,272,260,276,268,260,80,262,276,0,273,81,340,1,276,2,268,65,81,277,17,340,320,0,257,261,81,81]

theorem envBound33406 : H12AffineFastState.Bounded env33406 := by
  intro p hp
  have h : env33406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33405_33406 : H12AffineEnvironment.transform 4 1 env33405 = env33406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33405 == env33406) = true)

theorem identity33406 : scanCanonicalize (H12AffineFastState.compose env33406 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound33406 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33407 : List Nat := [2,4,8,16,1,64,8,84,1,68,80,64,88,80,80,82,64,0,69,81,0,1,64,2,88,65,81,65,17,0,20,0,85,81,81,81]

theorem envBound33407 : H12AffineFastState.Bounded env33407 := by
  intro p hp
  have h : env33407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33406_33407 : H12AffineEnvironment.transform 7 84 env33406 = env33407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env33406 == env33407) = true)

theorem identity33407 : scanCanonicalize (H12AffineFastState.compose env33407 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33407 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33408 : List Nat := [2,4,8,16,1,0,8,20,1,4,16,0,24,16,16,18,0,0,5,17,0,1,0,2,24,1,17,1,17,0,20,0,21,17,17,17]

theorem envBound33408 : H12AffineFastState.Bounded env33408 := by
  intro p hp
  have h : env33408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33407_33408 : H12AffineEnvironment.transform 5 0 env33407 = env33408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33407 == env33408) = true)

theorem identity33408 : scanCanonicalize (H12AffineFastState.compose env33408 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33408 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env33409 : List Nat := [2,4,8,1,1,0,8,5,1,4,1,0,9,1,1,3,0,0,5,0,0,1,0,2,9,1,0,1,0,0,5,0,4,0,0,0]

theorem envBound33409 : H12AffineFastState.Bounded env33409 := by
  intro p hp
  have h : env33409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33408_33409 : H12AffineEnvironment.transform 3 1 env33408 = env33409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33408 == env33409) = true)

theorem identity33409 : scanCanonicalize (H12AffineFastState.compose env33409 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33410 : List Nat := [2,0,8,1,1,0,8,1,1,0,1,0,9,1,1,3,0,0,1,0,0,1,0,2,9,1,0,1,0,0,1,0,0,0,0,0]

theorem envBound33410 : H12AffineFastState.Bounded env33410 := by
  intro p hp
  have h : env33410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33409_33410 : H12AffineEnvironment.transform 1 0 env33409 = env33410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33409 == env33410) = true)

theorem identity33410 : scanCanonicalize (H12AffineFastState.compose env33410 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33411 : List Nat := [2,0,1,1,1,0,1,1,1,0,1,0,0,1,1,3,0,0,1,0,0,1,0,2,0,1,0,1,0,0,1,0,0,0,0,0]

theorem envBound33411 : H12AffineFastState.Bounded env33411 := by
  intro p hp
  have h : env33411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33410_33411 : H12AffineEnvironment.transform 2 1 env33410 = env33411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33410 == env33411) = true)

theorem identity33411 : scanCanonicalize (H12AffineFastState.compose env33411 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33411 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33412 : List Nat := [1,0,1,1,1,0,1,1,1,0,1,0,0,1,1,0,0,0,1,0,0,1,0,1,0,1,0,1,0,0,1,0,0,0,0,0]

theorem envBound33412 : H12AffineFastState.Bounded env33412 := by
  intro p hp
  have h : env33412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33411_33412 : H12AffineEnvironment.transform 0 1 env33411 = env33412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33411 == env33412) = true)

def env33413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1025,32769,77898,33,8388608,98644,8192,65,8399181,79131,8466458,8431672,8389956,98679,257,8462395,8492055,8462874]

theorem envBound33413 : H12AffineFastState.Bounded env33413 := by
  intro p hp
  have h : env33413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33396_33413 : H12AffineEnvironment.transform 13 5377 env33396 = env33413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33396 == env33413) = true)

theorem identity33413 : scanCanonicalize (H12AffineFastState.compose env33413 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound33413 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1025,32769,77898,33,41293,98644,8192,65,34816,79131,102743,2421,41993,98679,257,98678,79194,99159]

theorem envBound33414 : H12AffineFastState.Bounded env33414 := by
  intro p hp
  have h : env33414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33413_33414 : H12AffineEnvironment.transform 22 41293 env33413 = env33414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env33413 == env33414) = true)

theorem identity33414 : scanCanonicalize (H12AffineFastState.compose env33414 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound33414 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env33415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40971,5393,10280,1025,32769,36929,33,41293,8543,8192,65,34816,38160,12636,2421,41993,8572,257,8573,38225,9052]

theorem envBound33415 : H12AffineFastState.Bounded env33415 := by
  intro p hp
  have h : env33415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33414_33415 : H12AffineEnvironment.transform 15 40971 env33414 = env33415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env33414 == env33415) = true)

theorem identity33415 : scanCanonicalize (H12AffineFastState.compose env33415 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33415 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env33416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,5393,10280,1025,0,4160,33,8524,8543,8192,65,2049,5393,12636,2421,9224,8572,257,8573,5456,9052]

theorem envBound33416 : H12AffineFastState.Bounded env33416 := by
  intro p hp
  have h : env33416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33415_33416 : H12AffineEnvironment.transform 14 1 env33415 = env33416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33415 == env33416) = true)

theorem identity33416 : scanCanonicalize (H12AffineFastState.compose env33416 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound33416 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,1,294,5393,2308,1025,0,4160,33,96,115,300,65,2049,5393,4208,2421,1316,80,257,81,5456,624]

theorem envBound33417 : H12AffineFastState.Bounded env33417 := by
  intro p hp
  have h : env33417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33416_33417 : H12AffineEnvironment.transform 12 300 env33416 = env33417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env33416 == env33417) = true)

theorem identity33417 : scanCanonicalize (H12AffineFastState.compose env33417 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33417 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33418 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5377,1,263,5393,2308,1025,0,4160,0,65,82,269,65,2049,5393,4177,2388,1285,80,257,81,5456,593]

theorem envBound33418 : H12AffineFastState.Bounded env33418 := by
  intro p hp
  have h : env33418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33417_33418 : H12AffineEnvironment.transform 4 1 env33417 = env33418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33417 == env33418) = true)

theorem identity33418 : scanCanonicalize (H12AffineFastState.compose env33418 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound33418 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env33419 : List Nat := [2,4,8,16,1,64,8,256,512,784,2048,4096,269,4625,1,263,4609,2308,785,0,4160,0,65,82,269,65,2049,4609,4177,2388,533,80,257,81,4672,593]

theorem envBound33419 : H12AffineFastState.Bounded env33419 := by
  intro p hp
  have h : env33419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33418_33419 : H12AffineEnvironment.transform 9 784 env33418 = env33419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env33418 == env33419) = true)

theorem identity33419 : scanCanonicalize (H12AffineFastState.compose env33419 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33419 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33420 : List Nat := [2,4,8,16,1,16,8,256,512,784,2048,4096,269,4625,1,263,4609,2308,785,0,4112,0,17,2,269,17,2049,4609,4097,2308,533,0,257,1,4624,513]

theorem envBound33420 : H12AffineFastState.Bounded env33420 := by
  intro p hp
  have h : env33420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33419_33420 : H12AffineEnvironment.transform 5 16 env33419 = env33420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33419 == env33420) = true)

theorem identity33420 : scanCanonicalize (H12AffineFastState.compose env33420 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound33420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33421 : List Nat := [2,4,8,16,1,16,8,256,512,784,2048,772,269,277,1,263,261,2308,785,0,788,0,17,2,269,17,2049,261,773,2308,533,0,257,1,276,513]

theorem envBound33421 : H12AffineFastState.Bounded env33421 := by
  intro p hp
  have h : env33421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33420_33421 : H12AffineEnvironment.transform 11 772 env33420 = env33421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env33420 == env33421) = true)

theorem identity33421 : scanCanonicalize (H12AffineFastState.compose env33421 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound33421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33422 : List Nat := [2,4,8,16,1,16,8,256,512,784,27,772,269,277,1,263,261,287,785,0,788,0,17,2,269,17,26,261,773,287,533,0,257,1,276,513]

theorem envBound33422 : H12AffineFastState.Bounded env33422 := by
  intro p hp
  have h : env33422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33421_33422 : H12AffineEnvironment.transform 10 27 env33421 = env33422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env33421 == env33422) = true)

theorem identity33422 : scanCanonicalize (H12AffineFastState.compose env33422 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33423 : List Nat := [2,4,8,16,1,16,8,4,512,532,27,512,9,17,1,3,1,27,533,0,528,0,17,2,9,17,26,1,513,27,533,0,5,1,16,513]

theorem envBound33423 : H12AffineFastState.Bounded env33423 := by
  intro p hp
  have h : env33423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33422_33423 : H12AffineEnvironment.transform 7 4 env33422 = env33423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33422 == env33423) = true)

theorem identity33423 : scanCanonicalize (H12AffineFastState.compose env33423 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33423 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33424 : List Nat := [2,4,8,16,1,16,8,4,17,5,27,17,9,17,1,3,1,27,4,0,1,0,17,2,9,17,26,1,16,27,4,0,5,1,16,16]

theorem envBound33424 : H12AffineFastState.Bounded env33424 := by
  intro p hp
  have h : env33424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33423_33424 : H12AffineEnvironment.transform 8 17 env33423 = env33424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33423 == env33424) = true)

theorem identity33424 : scanCanonicalize (H12AffineFastState.compose env33424 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33425 : List Nat := [2,4,6,16,1,16,6,4,17,5,21,17,7,17,1,3,1,21,4,0,1,0,17,2,7,17,20,1,16,21,4,0,5,1,16,16]

theorem envBound33425 : H12AffineFastState.Bounded env33425 := by
  intro p hp
  have h : env33425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33424_33425 : H12AffineEnvironment.transform 2 6 env33424 = env33425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33424 == env33425) = true)

theorem identity33425 : scanCanonicalize (H12AffineFastState.compose env33425 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33425 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env33426 : List Nat := [2,0,2,16,1,16,2,0,17,1,17,17,3,17,1,3,1,17,0,0,1,0,17,2,3,17,16,1,16,17,0,0,1,1,16,16]

theorem envBound33426 : H12AffineFastState.Bounded env33426 := by
  intro p hp
  have h : env33426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33425_33426 : H12AffineEnvironment.transform 1 0 env33425 = env33426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33425 == env33426) = true)

theorem identity33426 : scanCanonicalize (H12AffineFastState.compose env33426 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound33426 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33427 : List Nat := [2,0,2,2,1,2,2,0,3,1,3,3,3,3,1,3,1,3,0,0,1,0,3,2,3,3,2,1,2,3,0,0,1,1,2,2]

theorem envBound33427 : H12AffineFastState.Bounded env33427 := by
  intro p hp
  have h : env33427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33426_33427 : H12AffineEnvironment.transform 3 2 env33426 = env33427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env33426 == env33427) = true)

theorem identity33427 : scanCanonicalize (H12AffineFastState.compose env33427 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33427 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env33428 : List Nat := [1,0,1,1,1,1,1,0,0,1,0,0,0,0,1,0,1,0,0,0,1,0,0,1,0,0,1,1,1,0,0,0,1,1,1,1]

theorem envBound33428 : H12AffineFastState.Bounded env33428 := by
  intro p hp
  have h : env33428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33427_33428 : H12AffineEnvironment.transform 0 1 env33427 = env33428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33427 == env33428) = true)

def env33429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,8388608,98645,8193,65,8546653,79131,8480027,8568104,8389957,98679,257,8484154,8492054,8462874]

theorem envBound33429 : H12AffineFastState.Bounded env33429 := by
  intro p hp
  have h : env33429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33394_33429 : H12AffineEnvironment.transform 6 9 env33394 = env33429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33394 == env33429) = true)

theorem identity33429 : scanCanonicalize (H12AffineFastState.compose env33429 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound33429 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,73755,98645,8193,65,215366,79131,17664,236851,75102,98679,257,21793,46093,513]

theorem envBound33430 : H12AffineFastState.Bounded env33430 := by
  intro p hp
  have h : env33430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33429_33430 : H12AffineEnvironment.transform 22 73755 env33429 = env33430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env33429 == env33430) = true)

theorem identity33430 : scanCanonicalize (H12AffineFastState.compose env33430 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33430 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env33431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,77898,21792,73755,95497,8193,65,215366,79131,17664,223599,75102,95531,257,21793,16465,513]

theorem envBound33431 : H12AffineFastState.Bounded env33431 := by
  intro p hp
  have h : env33431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33430_33431 : H12AffineEnvironment.transform 14 29788 env33430 = env33431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33430 == env33431) = true)

theorem identity33431 : scanCanonicalize (H12AffineFastState.compose env33431 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound33431 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env33432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,32040,1025,29789,17728,21792,21777,3,8193,65,146508,16401,17664,138341,20564,33,257,21793,16465,513]

theorem envBound33432 : H12AffineFastState.Bounded env33432 := by
  intro p hp
  have h : env33432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33431_33432 : H12AffineEnvironment.transform 15 29962 env33431 = env33432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env33431 == env33432) = true)

theorem identity33432 : scanCanonicalize (H12AffineFastState.compose env33432 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound33432 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8461,8283,131072,10361,1025,8460,4113,113,64,3,8193,65,146508,5440,4177,138341,1285,33,257,112,5376,513]

theorem envBound33433 : H12AffineFastState.Bounded env33433 := by
  intro p hp
  have h : env33433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33432_33433 : H12AffineEnvironment.transform 13 5457 env33432 = env33433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env33432 == env33433) = true)

theorem identity33433 : scanCanonicalize (H12AffineFastState.compose env33433 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33434 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10280,1025,8460,4113,32,17,3,8193,16,146461,5393,4096,138292,1285,33,257,33,5376,513]

theorem envBound33434 : H12AffineFastState.Bounded env33434 := by
  intro p hp
  have h : env33434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33433_33434 : H12AffineEnvironment.transform 5 17 env33433 = env33434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33433 == env33434) = true)

theorem identity33434 : scanCanonicalize (H12AffineFastState.compose env33434 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13592) := by decide +kernel

theorem selectedBound33434 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33435 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,13592,10280,1025,8460,4113,32,17,3,8193,16,2309,5393,4096,10540,1285,33,257,33,5376,513]

theorem envBound33435 : H12AffineFastState.Bounded env33435 := by
  intro p hp
  have h : env33435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33434_33435 : H12AffineEnvironment.transform 16 13592 env33434 = env33435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13592 env33434 == env33435) = true)

theorem identity33435 : scanCanonicalize (H12AffineFastState.compose env33435 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33435 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33436 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8201,8202,13340,10280,1025,8200,4113,32,17,3,8193,16,2049,5141,4096,10280,1025,33,5,33,5124,513]

theorem envBound33436 : H12AffineFastState.Bounded env33436 := by
  intro p hp
  have h : env33436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33435_33436 : H12AffineEnvironment.transform 7 4 env33435 = env33436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33435 == env33436) = true)

theorem identity33436 : scanCanonicalize (H12AffineFastState.compose env33436 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound33436 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33437 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,4096,8192,5124,8201,8202,13340,8200,1025,8200,4113,32,17,3,8193,16,33,5141,4096,8200,1025,33,5,33,5124,513]

theorem envBound33437 : H12AffineFastState.Bounded env33437 := by
  intro p hp
  have h : env33437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33436_33437 : H12AffineEnvironment.transform 10 32 env33436 = env33437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env33436 == env33437) = true)

theorem identity33437 : scanCanonicalize (H12AffineFastState.compose env33437 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound33437 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33438 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,4096,4120,5124,4113,4114,1028,4112,1025,4112,4113,32,17,3,4121,16,33,5141,4096,4112,1025,33,5,33,5124,513]

theorem envBound33438 : H12AffineFastState.Bounded env33438 := by
  intro p hp
  have h : env33438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33437_33438 : H12AffineEnvironment.transform 12 4120 env33437 = env33438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env33437 == env33438) = true)

theorem identity33438 : scanCanonicalize (H12AffineFastState.compose env33438 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound33438 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33439 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,17,9,1045,0,3,1028,1,1025,1,0,32,17,3,8,16,33,1028,17,1,1025,33,5,33,1045,513]

theorem envBound33439 : H12AffineFastState.Bounded env33439 := by
  intro p hp
  have h : env33439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33438_33439 : H12AffineEnvironment.transform 11 17 env33438 = env33439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33438 == env33439) = true)

theorem identity33439 : scanCanonicalize (H12AffineFastState.compose env33439 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33440 : List Nat := [2,4,8,16,0,17,9,4,512,1024,0,17,9,1045,0,3,1028,1,1025,1,0,0,17,3,8,16,1,1028,17,1,1025,1,5,1,1045,513]

theorem envBound33440 : H12AffineFastState.Bounded env33440 := by
  intro p hp
  have h : env33440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33439_33440 : H12AffineEnvironment.transform 4 0 env33439 = env33440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33439 == env33440) = true)

theorem identity33440 : scanCanonicalize (H12AffineFastState.compose env33440 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33441 : List Nat := [2,4,8,16,0,17,9,4,17,1024,0,17,9,1045,0,3,1028,1,1025,1,0,0,17,3,8,16,1,1028,17,1,1025,1,5,1,1045,16]

theorem envBound33441 : H12AffineFastState.Bounded env33441 := by
  intro p hp
  have h : env33441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33440_33441 : H12AffineEnvironment.transform 8 17 env33440 = env33441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33440 == env33441) = true)

def env33442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98780,8328,65,8546652,79131,8480027,8568225,8390092,98678,257,8484154,8492191,8462874]

theorem envBound33442 : H12AffineFastState.Bounded env33442 := by
  intro p hp
  have h : env33442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33393_33442 : H12AffineEnvironment.transform 21 21793 env33393 = env33442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env33393 == env33442) = true)

theorem identity33442 : scanCanonicalize (H12AffineFastState.compose env33442 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound33442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,17,98780,8328,65,158029,79131,91402,179632,1501,98678,257,95531,103566,74251]

theorem envBound33443 : H12AffineFastState.Bounded env33443 := by
  intro p hp
  have h : env33443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33442_33443 : H12AffineEnvironment.transform 22 17 env33442 = env33443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env33442 == env33443) = true)

theorem identity33443 : scanCanonicalize (H12AffineFastState.compose env33443 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33443 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,17,41430,8328,65,158029,5393,17664,179632,1501,41340,257,21793,46212,513]

theorem envBound33444 : H12AffineFastState.Bounded env33444 := by
  intro p hp
  have h : env33444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33443_33444 : H12AffineEnvironment.transform 15 8202 env33443 = env33444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33443 == env33444) = true)

theorem identity33444 : scanCanonicalize (H12AffineFastState.compose env33444 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 49353) := by decide +kernel

theorem selectedBound33444 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env33445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49353,32161,1025,32769,4160,21793,17,41430,8328,65,43396,5393,17664,32121,1501,41340,257,21793,46212,513]

theorem envBound33445 : H12AffineFastState.Bounded env33445 := by
  intro p hp
  have h : env33445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33444_33445 : H12AffineEnvironment.transform 16 49353 env33444 = env33445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49353 env33444 == env33445) = true)

theorem identity33445 : scanCanonicalize (H12AffineFastState.compose env33445 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound33445 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,13508,32161,1025,29708,4160,21793,17,21979,8328,65,23945,5393,17664,32121,1501,21873,257,21793,16521,513]

theorem envBound33446 : H12AffineFastState.Bounded env33446 := by
  intro p hp
  have h : env33446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33445_33446 : H12AffineEnvironment.transform 14 29709 env33445 = env33446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env33445 == env33446) = true)

theorem identity33446 : scanCanonicalize (H12AffineFastState.compose env33446 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound33446 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8540,8202,13508,10480,1025,8541,4160,112,17,138,8328,65,2264,5393,4177,10280,1501,32,257,112,5592,513]

theorem envBound33447 : H12AffineFastState.Bounded env33447 := by
  intro p hp
  have h : env33447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33446_33447 : H12AffineEnvironment.transform 13 5457 env33446 = env33447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env33446 == env33447) = true)

theorem identity33447 : scanCanonicalize (H12AffineFastState.compose env33447 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33447 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env33448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,216,398,5440,2420,1025,217,4160,112,17,138,268,65,2264,5393,4177,2476,1501,32,257,112,5592,513]

theorem envBound33448 : H12AffineFastState.Bounded env33448 := by
  intro p hp
  have h : env33448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33447_33448 : H12AffineEnvironment.transform 12 388 env33447 = env33448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33447 == env33448) = true)

theorem identity33448 : scanCanonicalize (H12AffineFastState.compose env33448 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33448 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,81,263,5440,2420,1025,80,4160,112,17,3,268,65,2129,5393,4177,2341,1364,32,257,112,5457,513]

theorem envBound33449 : H12AffineFastState.Bounded env33449 := by
  intro p hp
  have h : env33449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33448_33449 : H12AffineEnvironment.transform 6 9 env33448 = env33449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33448 == env33449) = true)

theorem identity33449 : scanCanonicalize (H12AffineFastState.compose env33449 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33450 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5237,81,35,5220,2128,1025,80,4160,112,17,3,40,65,2129,5173,4177,2049,1136,32,37,112,5237,513]

theorem envBound33450 : H12AffineFastState.Bounded env33450 := by
  intro p hp
  have h : env33450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33449_33450 : H12AffineEnvironment.transform 7 36 env33449 = env33450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33449 == env33450) = true)

theorem identity33450 : scanCanonicalize (H12AffineFastState.compose env33450 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33450 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33451 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4113,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound33451 : H12AffineFastState.Bounded env33451 := by
  intro p hp
  have h : env33451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33450_33451 : H12AffineEnvironment.transform 5 17 env33450 = env33451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33450 == env33451) = true)

def env33452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound33452 : H12AffineFastState.Bounded env33452 := by
  intro p hp
  have h : env33452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31848_33452 : H12AffineEnvironment.transform 29 155254785 env31848 = env33452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env31848 == env33452) = true)

def env33453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound33453 : H12AffineFastState.Bounded env33453 := by
  intro p hp
  have h : env33453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33452_33453 : H12AffineEnvironment.transform 25 64 env33452 = env33453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env33452 == env33453) = true)

def env33454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound33454 : H12AffineFastState.Bounded env33454 := by
  intro p hp
  have h : env33454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33453_33454 : H12AffineEnvironment.transform 26 30393344 env33453 = env33454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env33453 == env33454) = true)

def env33455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound33455 : H12AffineFastState.Bounded env33455 := by
  intro p hp
  have h : env33455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33454_33455 : H12AffineEnvironment.transform 18 1024 env33454 = env33455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env33454 == env33455) = true)

theorem identity33455 : scanCanonicalize (H12AffineFastState.compose env33455 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388762) := by decide +kernel

theorem selectedBound33455 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388762,8328,64,4702362,10585110,10507600,8830977,99467,14771546,256,2212918,2172307,41821]

theorem envBound33456 : H12AffineFastState.Bounded env33456 := by
  intro p hp
  have h : env33456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33455_33456 : H12AffineEnvironment.transform 23 8388762 env33455 = env33456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388762 env33455 == env33456) = true)

def env33457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147474,8328,64,4702362,2344094,2233816,295049,99467,6497746,256,2212918,2172307,41821]

theorem envBound33457 : H12AffineFastState.Bounded env33457 := by
  intro p hp
  have h : env33457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33456_33457 : H12AffineEnvironment.transform 22 147592 env33456 = env33457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env33456 == env33457) = true)

def env33458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147474,8328,64,4450362,2344094,2233816,43049,99467,6497746,256,2212918,2172307,41821]

theorem envBound33458 : H12AffineFastState.Bounded env33458 := by
  intro p hp
  have h : env33458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33457_33458 : H12AffineEnvironment.transform 17 10400 env33457 = env33458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33457 == env33458) = true)

def env33459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,4194304,147456,147474,8192,64,4450362,2343958,2233680,43049,99331,6497626,256,2212918,2172187,41821]

theorem envBound33459 : H12AffineFastState.Bounded env33459 := by
  intro p hp
  have h : env33459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33458_33459 : H12AffineEnvironment.transform 6 8 env33458 = env33459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33458 == env33459) = true)

theorem identity33459 : scanCanonicalize (H12AffineFastState.compose env33459 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33459 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env33460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,2097152,4194304,147456,147474,8192,64,4409702,2319690,2233680,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound33460 : H12AffineFastState.Bounded env33460 := by
  intro p hp
  have h : env33460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33459_33460 : H12AffineEnvironment.transform 14 8540 env33459 = env33460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33459 == env33460) = true)

theorem identity33460 : scanCanonicalize (H12AffineFastState.compose env33460 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33460 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env33461 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,2097152,4194304,73754,73736,8192,64,4204924,2098512,2192714,2421,75103,6309184,256,2188650,2172187,513]

theorem envBound33461 : H12AffineFastState.Bounded env33461 := by
  intro p hp
  have h : env33461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33460_33461 : H12AffineEnvironment.transform 16 90138 env33460 = env33461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33460 == env33461) = true)

theorem identity33461 : scanCanonicalize (H12AffineFastState.compose env33461 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound33461 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env33462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10280,1024,8541,2097152,4194304,20480,20498,8192,64,4204924,2098512,2098512,2421,21829,6309184,256,2102640,2118913,513]

theorem envBound33462 : H12AffineFastState.Bounded env33462 := by
  intro p hp
  have h : env33462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33461_33462 : H12AffineEnvironment.transform 15 28698 env33461 = env33462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env33461 == env33462) = true)

theorem identity33462 : scanCanonicalize (H12AffineFastState.compose env33462 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7252) := by decide +kernel

theorem selectedBound33462 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env33463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10280,1024,8541,2097152,7252,20480,20498,8192,64,13608,2098512,2098512,2421,21829,2119956,256,2102640,2118913,513]

theorem envBound33463 : H12AffineFastState.Bounded env33463 := by
  intro p hp
  have h : env33463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33462_33463 : H12AffineEnvironment.transform 21 7252 env33462 = env33463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7252 env33462 == env33463) = true)

theorem identity33463 : scanCanonicalize (H12AffineFastState.compose env33463 (packedSelected [11,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33463 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env33464 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8540,28698,4096,10280,100,8541,2097152,6192,20480,20498,8192,64,12620,2097460,2097460,2421,20769,2119956,256,2101524,2117989,513]

theorem envBound33464 : H12AffineFastState.Bounded env33464 := by
  intro p hp
  have h : env33464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33463_33464 : H12AffineEnvironment.transform 9 100 env33463 = env33464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33463 == env33464) = true)

theorem identity33464 : scanCanonicalize (H12AffineFastState.compose env33464 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 2341) := by decide +kernel

theorem selectedBound33464 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env33465 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8540,28698,4096,10280,100,8541,2341,6192,20480,20498,8192,64,12620,2065,2065,2421,20769,20529,256,6193,22592,513]

theorem envBound33465 : H12AffineFastState.Bounded env33465 := by
  intro p hp
  have h : env33465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33464_33465 : H12AffineEnvironment.transform 20 2341 env33464 = env33465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2341 env33464 == env33465) = true)

theorem identity33465 : scanCanonicalize (H12AffineFastState.compose env33465 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33465 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33466 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8540,8202,4096,10280,100,8541,2341,6192,16,2,8192,64,12620,2065,2065,2421,305,33,256,6193,2128,513]

theorem envBound33466 : H12AffineFastState.Bounded env33466 := by
  intro p hp
  have h : env33466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33465_33466 : H12AffineEnvironment.transform 13 4112 env33465 = env33466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33465 == env33466) = true)

theorem identity33466 : scanCanonicalize (H12AffineFastState.compose env33466 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33466 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33467 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4112,8460,8202,4096,10280,52,8461,2341,6192,16,2,8192,16,12572,2065,2065,2341,305,33,256,6193,2048,513]

theorem envBound33467 : H12AffineFastState.Bounded env33467 := by
  intro p hp
  have h : env33467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33466_33467 : H12AffineEnvironment.transform 5 16 env33466 = env33467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33466 == env33467) = true)

theorem identity33467 : scanCanonicalize (H12AffineFastState.compose env33467 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound33467 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env33468 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2065,8192,2049,8460,8202,2065,10280,52,8461,2341,33,16,2,8192,16,10509,2065,2065,2341,305,33,256,32,2048,513]

theorem envBound33468 : H12AffineFastState.Bounded env33468 := by
  intro p hp
  have h : env33468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33467_33468 : H12AffineEnvironment.transform 11 2065 env33467 = env33468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env33467 == env33468) = true)

theorem identity33468 : scanCanonicalize (H12AffineFastState.compose env33468 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33468 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33469 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2065,8192,2049,8233,8202,2065,10280,52,8232,2048,33,16,2,8192,16,10280,2065,2065,2048,20,33,37,32,2048,513]

theorem envBound33469 : H12AffineFastState.Bounded env33469 := by
  intro p hp
  have h : env33469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33468_33469 : H12AffineEnvironment.transform 7 37 env33468 = env33469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33468 == env33469) = true)

theorem identity33469 : scanCanonicalize (H12AffineFastState.compose env33469 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33470 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,8192,48,8233,8202,32,8217,52,8232,49,33,16,2,8192,16,8217,32,32,49,20,33,37,32,49,513]

theorem envBound33470 : H12AffineFastState.Bounded env33470 := by
  intro p hp
  have h : env33470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33469_33470 : H12AffineEnvironment.transform 10 49 env33469 = env33470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33469 == env33470) = true)

theorem identity33470 : scanCanonicalize (H12AffineFastState.compose env33470 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33470 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33471 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,41,48,0,35,32,48,52,1,49,33,16,2,41,16,48,32,32,49,20,33,37,32,49,513]

theorem envBound33471 : H12AffineFastState.Bounded env33471 := by
  intro p hp
  have h : env33471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33470_33471 : H12AffineEnvironment.transform 12 41 env33470 = env33471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33470 == env33471) = true)

def leafEnv33471 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,41,48,0,35,32,48,52,1,49,33,16,2,20,41,1,16,48,32,32,49,20,33,37,32,4,35,49,513,1,48,0]

def active33471 : List Nat := [0,1,2,3,4,8]

def tree33471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33471 : H12WitnessSearch.Good tree33471 := H12GlobalWitnessIndex.good

theorem leafIdentity33471 : H12AffineFastState.composeSystem env33471 rootObs = leafEnv33471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33471 rootObs == leafEnv33471) = true)

theorem terminalChecked33471 : H12PackedTerminal.terminalCheckFast leafEnv33471 active33471 tree33471 = true := by decide +kernel

def env33472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147457,147474,8193,64,4450362,2343959,2233681,43049,99330,6497627,256,2212918,2172186,41821]

theorem envBound33472 : H12AffineFastState.Bounded env33472 := by
  intro p hp
  have h : env33472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33458_33472 : H12AffineEnvironment.transform 6 9 env33458 = env33472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33458 == env33472) = true)

theorem identity33472 : scanCanonicalize (H12AffineFastState.compose env33472 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33472 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env33473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,147474,8193,64,4409702,2319691,2233681,2421,75102,6497627,256,2188650,2172186,513]

theorem envBound33473 : H12AffineFastState.Bounded env33473 := by
  intro p hp
  have h : env33473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33472_33473 : H12AffineEnvironment.transform 14 8540 env33472 = env33473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33472 == env33473) = true)

theorem identity33473 : scanCanonicalize (H12AffineFastState.compose env33473 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33473 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env33474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,131072,10281,1024,8541,2097152,4194304,147457,147474,8193,64,4343856,2253853,2233681,2421,9224,6431757,256,2122812,2106444,513]

theorem envBound33474 : H12AffineFastState.Bounded env33474 := by
  intro p hp
  have h : env33474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33473_33474 : H12AffineEnvironment.transform 15 342 env33473 = env33474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33473 == env33474) = true)

theorem identity33474 : scanCanonicalize (H12AffineFastState.compose env33474 (packedSelected [1,4,8,9,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound33474 : packedSelected [1,4,8,9,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env33475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,131072,10281,1024,8541,25629,4194304,147457,147474,8193,64,4343856,131072,160076,2421,9224,4341776,256,33,16465,513]

theorem envBound33475 : H12AffineFastState.Bounded env33475 := by
  intro p hp
  have h : env33475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33474_33475 : H12AffineEnvironment.transform 20 25629 env33474 = env33475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env33474 == env33475) = true)

theorem identity33475 : scanCanonicalize (H12AffineFastState.compose env33475 (packedSelected [1,3,5,8,11,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound33475 : packedSelected [1,3,5,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,131072,10281,1024,8541,25629,8493,147457,147474,8193,64,157981,131072,160076,2421,9224,155965,256,33,16465,513]

theorem envBound33476 : H12AffineFastState.Bounded env33476 := by
  intro p hp
  have h : env33476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33475_33476 : H12AffineEnvironment.transform 21 8493 env33475 = env33476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env33475 == env33476) = true)

theorem identity33476 : scanCanonicalize (H12AffineFastState.compose env33476 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33476 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33477 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,262,131072,10281,1024,8461,25629,8493,147457,147474,8193,16,157981,131072,160028,2341,9224,155965,256,33,16385,513]

theorem envBound33477 : H12AffineFastState.Bounded env33477 := by
  intro p hp
  have h : env33477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33476_33477 : H12AffineEnvironment.transform 5 16 env33476 = env33477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33476 == env33477) = true)

theorem identity33477 : scanCanonicalize (H12AffineFastState.compose env33477 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33477 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33478 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,131072,2340,1024,0,17680,32,147457,147474,268,16,149520,131072,151569,2341,1285,147504,256,33,16385,513]

theorem envBound33478 : H12AffineFastState.Bounded env33478 := by
  intro p hp
  have h : env33478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33477_33478 : H12AffineEnvironment.transform 12 269 env33477 = env33478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33477 == env33478) = true)

theorem identity33478 : scanCanonicalize (H12AffineFastState.compose env33478 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(16+1) ^^^ 3109) := by decide +kernel

theorem selectedBound33478 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env33479 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,3109,2340,1024,0,17680,32,19492,19511,268,16,17461,3109,23604,2341,1285,19477,256,33,16385,513]

theorem envBound33479 : H12AffineFastState.Bounded env33479 := by
  intro p hp
  have h : env33479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33478_33479 : H12AffineEnvironment.transform 16 3109 env33478 = env33479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3109 env33478 == env33479) = true)

theorem identity33479 : scanCanonicalize (H12AffineFastState.compose env33479 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33479 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env33480 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,16384,1,262,2064,2340,53,0,16677,32,18449,18434,268,16,16384,2064,22529,2341,304,18464,256,33,16385,513]

theorem envBound33480 : H12AffineFastState.Bounded env33480 := by
  intro p hp
  have h : env33480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33479_33480 : H12AffineEnvironment.transform 9 53 env33479 = env33480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33479 == env33480) = true)

theorem identity33480 : scanCanonicalize (H12AffineFastState.compose env33480 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound33480 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env33481 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,2048,1,262,2064,2340,53,0,2341,32,17,2,268,16,2048,2064,4097,2341,304,32,256,33,2049,513]

theorem envBound33481 : H12AffineFastState.Bounded env33481 := by
  intro p hp
  have h : env33481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33480_33481 : H12AffineEnvironment.transform 13 2048 env33480 = env33481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env33480 == env33481) = true)

theorem identity33481 : scanCanonicalize (H12AffineFastState.compose env33481 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound33481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33482 : List Nat := [2,4,8,16,32,16,9,52,512,53,2048,4096,57,2048,1,50,2064,2064,53,0,2065,32,17,2,56,16,2048,2064,4097,2065,4,32,52,33,2049,513]

theorem envBound33482 : H12AffineFastState.Bounded env33482 := by
  intro p hp
  have h : env33482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33481_33482 : H12AffineEnvironment.transform 7 52 env33481 = env33482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env33481 == env33482) = true)

theorem identity33482 : scanCanonicalize (H12AffineFastState.compose env33482 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33482 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33483 : List Nat := [2,4,8,10,32,10,9,46,512,47,2048,4096,35,2048,1,40,2058,2058,47,0,2059,32,11,2,34,10,2048,2058,4097,2059,4,32,46,33,2049,513]

theorem envBound33483 : H12AffineFastState.Bounded env33483 := by
  intro p hp
  have h : env33483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33482_33483 : H12AffineEnvironment.transform 3 10 env33482 = env33483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33482 == env33483) = true)

theorem identity33483 : scanCanonicalize (H12AffineFastState.compose env33483 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound33483 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33484 : List Nat := [2,4,8,10,32,10,9,46,512,47,42,4096,35,42,1,40,32,32,47,0,33,32,11,2,34,10,42,32,4097,33,4,32,46,33,43,513]

theorem envBound33484 : H12AffineFastState.Bounded env33484 := by
  intro p hp
  have h : env33484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33483_33484 : H12AffineEnvironment.transform 10 42 env33483 = env33484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env33483 == env33484) = true)

theorem identity33484 : scanCanonicalize (H12AffineFastState.compose env33484 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound33484 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33485 : List Nat := [2,4,8,10,32,10,9,46,512,47,42,43,35,42,1,40,32,32,47,0,33,32,11,2,34,10,42,32,42,33,4,32,46,33,43,513]

theorem envBound33485 : H12AffineFastState.Bounded env33485 := by
  intro p hp
  have h : env33485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33484_33485 : H12AffineEnvironment.transform 11 43 env33484 = env33485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env33484 == env33485) = true)

theorem identity33485 : scanCanonicalize (H12AffineFastState.compose env33485 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33485 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33486 : List Nat := [2,4,5,7,32,7,4,35,512,34,39,38,35,39,1,37,32,32,34,0,33,32,6,2,34,7,39,32,39,33,4,32,35,33,38,513]

theorem envBound33486 : H12AffineFastState.Bounded env33486 := by
  intro p hp
  have h : env33486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33485_33486 : H12AffineEnvironment.transform 2 5 env33485 = env33486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33485 == env33486) = true)

def env33487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147474,8328,64,4450363,2344094,2233816,43048,99467,6497746,256,2212918,2172307,41821]

theorem envBound33487 : H12AffineFastState.Bounded env33487 := by
  intro p hp
  have h : env33487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33457_33487 : H12AffineEnvironment.transform 17 10401 env33457 = env33487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33457 == env33487) = true)

theorem identity33487 : scanCanonicalize (H12AffineFastState.compose env33487 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound33487 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4303011,2196486,2118976,43048,99467,6382922,256,2212918,2172307,41821]

theorem envBound33488 : H12AffineFastState.Bounded env33488 := by
  intro p hp
  have h : env33488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33487_33488 : H12AffineEnvironment.transform 16 16536 env33487 = env33488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env33487 == env33488) = true)

theorem identity33488 : scanCanonicalize (H12AffineFastState.compose env33488 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound33488 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env33489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4204925,2098648,2118976,43048,1365,6349972,256,2115048,2139213,41821]

theorem envBound33489 : H12AffineFastState.Bounded env33489 := by
  intro p hp
  have h : env33489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33488_33489 : H12AffineEnvironment.transform 15 33246 env33488 = env33489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env33488 == env33489) = true)

theorem identity33489 : scanCanonicalize (H12AffineFastState.compose env33489 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound33489 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,2097152,32,16,138,8328,64,10589,2098648,2118976,43048,1365,2155700,256,2115048,2139213,41821]

theorem envBound33490 : H12AffineFastState.Bounded env33490 := by
  intro p hp
  have h : env33490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33489_33490 : H12AffineEnvironment.transform 21 32 env33489 = env33490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env33489 == env33490) = true)

theorem identity33490 : scanCanonicalize (H12AffineFastState.compose env33490 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound33490 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env33491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,50449,32,16,138,8328,64,10589,49353,36945,43048,1365,8613,256,33017,24924,41821]

theorem envBound33491 : H12AffineFastState.Bounded env33491 := by
  intro p hp
  have h : env33491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33490_33491 : H12AffineEnvironment.transform 20 50449 env33490 = env33491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env33490 == env33491) = true)

theorem identity33491 : scanCanonicalize (H12AffineFastState.compose env33491 (packedSelected [4,9,10,11,12,15,17,18,19,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound33491 : packedSelected [4,9,10,11,12,15,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env33492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16536,10401,1024,8661,25797,32,16,138,8328,64,10589,24861,12677,2556,1365,8613,256,8493,24924,649]

theorem envBound33492 : H12AffineFastState.Bounded env33492 := by
  intro p hp
  have h : env33492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33491_33492 : H12AffineEnvironment.transform 14 8660 env33491 = env33492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env33491 == env33492) = true)

theorem identity33492 : scanCanonicalize (H12AffineFastState.compose env33492 (packedSelected [4,5,6,7,8,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound33492 : packedSelected [4,5,6,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,1212,1378,16536,3529,1024,1213,16813,32,16,138,1504,64,3125,17525,5357,2556,1365,1229,256,1093,17460,649]

theorem envBound33493 : H12AffineFastState.Bounded env33493 := by
  intro p hp
  have h : env33493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33492_33493 : H12AffineEnvironment.transform 12 1384 env33492 = env33493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env33492 == env33493) = true)

theorem identity33493 : scanCanonicalize (H12AffineFastState.compose env33493 (packedSelected [0,2,3,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33493 : packedSelected [0,2,3,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env33494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,5236,1212,1378,5356,3529,1024,1213,5593,32,16,138,1504,64,3125,4097,5357,2556,1365,1229,256,1093,4160,649]

theorem envBound33494 : H12AffineFastState.Bounded env33494 := by
  intro p hp
  have h : env33494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33493_33494 : H12AffineEnvironment.transform 13 5236 env33493 = env33494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33493 == env33494) = true)

theorem identity33494 : scanCanonicalize (H12AffineFastState.compose env33494 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33494 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33495 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,120,4452,428,114,4604,2265,272,429,4297,32,16,138,240,64,2341,4097,4605,2556,69,477,256,341,4160,649]

theorem envBound33495 : H12AffineFastState.Bounded env33495 := by
  intro p hp
  have h : env33495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33494_33495 : H12AffineEnvironment.transform 9 272 env33494 = env33495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33494 == env33495) = true)

theorem identity33495 : scanCanonicalize (H12AffineFastState.compose env33495 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33495 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env33496 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,4096,120,4113,217,114,4233,2265,101,216,4297,32,16,138,240,64,2128,4097,4232,2185,69,168,117,32,4160,649]

theorem envBound33496 : H12AffineFastState.Bounded env33496 := by
  intro p hp
  have h : env33496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33495_33496 : H12AffineEnvironment.transform 7 117 env33495 = env33496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33495 == env33496) = true)

theorem identity33496 : scanCanonicalize (H12AffineFastState.compose env33496 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound33496 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env33497 : List Nat := [2,4,8,16,32,64,89,117,512,101,2048,4096,120,4113,0,114,4176,2048,101,1,4112,32,16,83,41,64,2128,4097,4177,2128,69,113,117,32,4160,592]

theorem envBound33497 : H12AffineFastState.Bounded env33497 := by
  intro p hp
  have h : env33497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33496_33497 : H12AffineEnvironment.transform 6 89 env33496 = env33497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env33496 == env33497) = true)

theorem identity33497 : scanCanonicalize (H12AffineFastState.compose env33497 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33497 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33498 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,34,4096,2048,53,1,4112,32,16,3,41,16,2048,4097,4097,2048,21,33,37,32,4112,512]

theorem envBound33498 : H12AffineFastState.Bounded env33498 := by
  intro p hp
  have h : env33498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33497_33498 : H12AffineEnvironment.transform 5 16 env33497 = env33498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33497 == env33498) = true)

theorem identity33498 : scanCanonicalize (H12AffineFastState.compose env33498 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

end H12CloudChart0