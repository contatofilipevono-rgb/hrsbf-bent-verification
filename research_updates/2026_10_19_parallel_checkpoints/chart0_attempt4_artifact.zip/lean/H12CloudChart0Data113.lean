import H12CloudChart0Data112

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound28652 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env28653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91198,65538,17,374,8192,65,2049,16740,78207,2420,75103,65538,257,340,16464,513]

theorem envBound28653 : H12AffineFastState.Bounded env28653 := by
  intro p hp
  have h : env28653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28652_28653 : H12AffineEnvironment.transform 21 65538 env28652 = env28653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env28652 == env28653) = true)

theorem identity28653 : scanCanonicalize (H12AffineFastState.compose env28653 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound28653 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16400,10589,1025,8233,25628,32,17,374,8192,65,2049,16740,12637,2420,9597,32,257,340,16464,513]

theorem envBound28654 : H12AffineFastState.Bounded env28654 := by
  intro p hp
  have h : env28654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28653_28654 : H12AffineEnvironment.transform 15 34 env28653 = env28654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env28653 == env28654) = true)

theorem identity28654 : scanCanonicalize (H12AffineFastState.compose env28654 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound28654 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env28655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,80,34,16400,2341,1025,81,17508,32,17,374,120,65,2049,16740,4389,2420,1285,32,257,340,16464,513]

theorem envBound28655 : H12AffineFastState.Bounded env28655 := by
  intro p hp
  have h : env28655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28654_28655 : H12AffineEnvironment.transform 12 120 env28654 = env28655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env28654 == env28655) = true)

theorem identity28655 : scanCanonicalize (H12AffineFastState.compose env28655 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28655 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env28656 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,16384,80,34,16400,2129,1025,81,17508,32,17,2,120,65,2049,16400,4177,2048,1137,32,117,32,16464,513]

theorem envBound28656 : H12AffineFastState.Bounded env28656 := by
  intro p hp
  have h : env28656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28655_28656 : H12AffineEnvironment.transform 7 116 env28655 = env28656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28655 == env28656) = true)

def env28657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91199,4194304,17,375,8192,65,4261890,16741,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound28657 : H12AffineFastState.Bounded env28657 := by
  intro p hp
  have h : env28657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28651_28657 : H12AffineEnvironment.transform 14 8233 env28651 = env28657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env28651 == env28657) = true)

theorem identity28657 : scanCanonicalize (H12AffineFastState.compose env28657 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound28657 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env28658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91199,65910,17,375,8192,65,2420,16741,78206,2420,75103,65910,257,341,16464,513]

theorem envBound28658 : H12AffineFastState.Bounded env28658 := by
  intro p hp
  have h : env28658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28657_28658 : H12AffineEnvironment.transform 21 65910 env28657 = env28658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env28657 == env28658) = true)

theorem identity28658 : scanCanonicalize (H12AffineFastState.compose env28658 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound28658 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env28659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,342,16400,10588,1025,8232,25961,32,17,375,8192,65,2420,16741,12328,2420,9225,32,257,341,16464,513]

theorem envBound28659 : H12AffineFastState.Bounded env28659 := by
  intro p hp
  have h : env28659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28658_28659 : H12AffineEnvironment.transform 15 342 env28658 = env28659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env28658 == env28659) = true)

theorem identity28659 : scanCanonicalize (H12AffineFastState.compose env28659 (packedSelected [0,1,2,3,4,6,7,9,14,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28659 : packedSelected [0,1,2,3,4,6,7,9,14,24,28] rootPS < 2^1333 := by decide +kernel

def env28660 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25629,32,17,3,8192,65,2048,16401,12328,2048,9225,32,117,33,16464,513]

theorem envBound28660 : H12AffineFastState.Bounded env28660 := by
  intro p hp
  have h : env28660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28659_28660 : H12AffineEnvironment.transform 7 116 env28659 = env28660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28659 == env28660) = true)

theorem identity28660 : scanCanonicalize (H12AffineFastState.compose env28660 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound28660 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28661 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,12345,8233,34,12329,10280,1025,8232,5156,32,17,3,8192,65,2048,12328,12328,2048,9225,32,117,33,12393,513]

theorem envBound28661 : H12AffineFastState.Bounded env28661 := by
  intro p hp
  have h : env28661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28660_28661 : H12AffineEnvironment.transform 13 12345 env28660 = env28661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env28660 == env28661) = true)

theorem identity28661 : scanCanonicalize (H12AffineFastState.compose env28661 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound28661 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28662 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,4096,8192,12345,8233,34,12329,8312,1025,8232,5156,32,17,3,8192,65,80,12328,12328,80,9225,32,117,33,12393,513]

theorem envBound28662 : H12AffineFastState.Bounded env28662 := by
  intro p hp
  have h : env28662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28661_28662 : H12AffineEnvironment.transform 10 80 env28661 = env28662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env28661 == env28662) = true)

theorem identity28662 : scanCanonicalize (H12AffineFastState.compose env28662 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28662 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env28663 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,4096,8192,12345,8233,34,12329,8312,100,8232,4161,32,17,3,8192,65,80,12328,12328,80,8300,32,117,33,12393,513]

theorem envBound28663 : H12AffineFastState.Bounded env28663 := by
  intro p hp
  have h : env28663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28662_28663 : H12AffineEnvironment.transform 9 101 env28662 = env28663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28662 == env28663) = true)

theorem identity28663 : scanCanonicalize (H12AffineFastState.compose env28663 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 4152) := by decide +kernel

theorem selectedBound28663 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env28664 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,4096,4152,1,4113,34,17,4160,100,4112,4161,32,17,3,4152,65,80,16,16,80,4180,32,117,33,81,513]

theorem envBound28664 : H12AffineFastState.Bounded env28664 := by
  intro p hp
  have h : env28664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28663_28664 : H12AffineEnvironment.transform 12 4152 env28663 = env28664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env28663 == env28664) = true)

theorem identity28664 : scanCanonicalize (H12AffineFastState.compose env28664 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28664 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env28665 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,4096,4152,1,4113,34,17,4113,53,4112,4112,32,17,3,4152,16,1,16,16,1,4101,32,36,33,0,513]

theorem envBound28665 : H12AffineFastState.Bounded env28665 := by
  intro p hp
  have h : env28665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28664_28665 : H12AffineEnvironment.transform 5 17 env28664 = env28665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28664 == env28665) = true)

theorem identity28665 : scanCanonicalize (H12AffineFastState.compose env28665 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound28665 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28666 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,16,40,1,1,34,17,1,53,0,0,32,17,3,40,16,1,16,16,1,21,32,36,33,0,513]

theorem envBound28666 : H12AffineFastState.Bounded env28666 := by
  intro p hp
  have h : env28666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28665_28666 : H12AffineEnvironment.transform 11 16 env28665 = env28666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28665 == env28666) = true)

theorem identity28666 : scanCanonicalize (H12AffineFastState.compose env28666 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound28666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28667 : List Nat := [2,4,8,4,32,5,8,37,512,32,1,4,40,1,1,34,5,1,33,0,0,32,5,3,40,4,1,4,4,1,1,32,36,33,0,513]

theorem envBound28667 : H12AffineFastState.Bounded env28667 := by
  intro p hp
  have h : env28667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28666_28667 : H12AffineEnvironment.transform 3 4 env28666 = env28667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env28666 == env28667) = true)

theorem identity28667 : scanCanonicalize (H12AffineFastState.compose env28667 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28668 : List Nat := [2,2,8,2,32,3,8,35,512,32,1,2,40,1,1,34,3,1,33,0,0,32,3,3,40,2,1,2,2,1,1,32,34,33,0,513]

theorem envBound28668 : H12AffineFastState.Bounded env28668 := by
  intro p hp
  have h : env28668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28667_28668 : H12AffineEnvironment.transform 1 2 env28667 = env28668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28667 == env28668) = true)

theorem identity28668 : scanCanonicalize (H12AffineFastState.compose env28668 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28669 : List Nat := [2,2,8,2,1,3,8,2,512,1,1,2,9,1,1,3,3,1,0,0,0,1,3,3,9,2,1,2,2,1,1,1,3,0,0,513]

theorem envBound28669 : H12AffineFastState.Bounded env28669 := by
  intro p hp
  have h : env28669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28668_28669 : H12AffineEnvironment.transform 4 1 env28668 = env28669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28668 == env28669) = true)

theorem identity28669 : scanCanonicalize (H12AffineFastState.compose env28669 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound28669 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28670 : List Nat := [2,2,8,2,1,3,8,2,11,1,1,2,9,1,1,3,3,1,0,0,0,1,3,3,9,2,1,2,2,1,1,1,3,0,0,10]

theorem envBound28670 : H12AffineFastState.Bounded env28670 := by
  intro p hp
  have h : env28670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28669_28670 : H12AffineEnvironment.transform 8 11 env28669 = env28670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env28669 == env28670) = true)

theorem identity28670 : scanCanonicalize (H12AffineFastState.compose env28670 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28670 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28671 : List Nat := [2,2,2,2,1,3,2,2,1,1,1,2,3,1,1,3,3,1,0,0,0,1,3,3,3,2,1,2,2,1,1,1,3,0,0,0]

theorem envBound28671 : H12AffineFastState.Bounded env28671 := by
  intro p hp
  have h : env28671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28670_28671 : H12AffineEnvironment.transform 2 2 env28670 = env28671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28670 == env28671) = true)

theorem identity28671 : scanCanonicalize (H12AffineFastState.compose env28671 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28671 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28672 : List Nat := [0,0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,1,1,0,0,0,1,1,1,1,0,1,0,0,1,1,1,1,0,0,0]

theorem envBound28672 : H12AffineFastState.Bounded env28672 := by
  intro p hp
  have h : env28672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28671_28672 : H12AffineEnvironment.transform 0 0 env28671 = env28672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28671 == env28672) = true)

def env28673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172251,2118976,2420,75103,6407191,257,2188650,2196550,513]

theorem envBound28673 : H12AffineFastState.Bounded env28673 := by
  intro p hp
  have h : env28673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28649_28673 : H12AffineEnvironment.transform 16 16401 env28649 = env28673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28649 == env28673) = true)

theorem identity28673 : scanCanonicalize (H12AffineFastState.compose env28673 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28673 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2098513,2118976,2420,1365,6349853,257,2114912,2139212,513]

theorem envBound28674 : H12AffineFastState.Bounded env28674 := by
  intro p hp
  have h : env28674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28673_28674 : H12AffineEnvironment.transform 15 8202 env28673 = env28674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28673 == env28674) = true)

theorem identity28674 : scanCanonicalize (H12AffineFastState.compose env28674 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,2097152,32,16,41311,8192,65,34816,2098513,2118976,2420,1365,2155581,257,2114912,2139212,513]

theorem envBound28675 : H12AffineFastState.Bounded env28675 := by
  intro p hp
  have h : env28675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28674_28675 : H12AffineEnvironment.transform 21 32 env28674 = env28675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28674 == env28675) = true)

theorem identity28675 : scanCanonicalize (H12AffineFastState.compose env28675 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28675 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,2097152,32,16,2,8192,65,10589,2098513,2118976,2420,1365,2114912,257,2114912,2098449,513]

theorem envBound28676 : H12AffineFastState.Bounded env28676 := by
  intro p hp
  have h : env28676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28675_28676 : H12AffineEnvironment.transform 14 8541 env28675 = env28676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28675 == env28676) = true)

theorem identity28676 : scanCanonicalize (H12AffineFastState.compose env28676 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28676 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28677 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8202,16401,10280,1025,8460,2097152,32,16,2,8192,17,10509,2098433,2118928,2340,1285,2114864,257,2114864,2098449,513]

theorem envBound28677 : H12AffineFastState.Bounded env28677 := by
  intro p hp
  have h : env28677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28676_28677 : H12AffineEnvironment.transform 5 16 env28676 = env28677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28676 == env28677) = true)

theorem identity28677 : scanCanonicalize (H12AffineFastState.compose env28677 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound28677 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28678 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,3345,3094,16401,1076,1025,3344,2097152,32,16,2,3100,17,1297,2098433,2118928,2340,1285,2114864,257,2114864,2098449,513]

theorem envBound28678 : H12AffineFastState.Bounded env28678 := by
  intro p hp
  have h : env28678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28677_28678 : H12AffineEnvironment.transform 12 3100 env28677 = env28678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env28677 == env28678) = true)

theorem identity28678 : scanCanonicalize (H12AffineFastState.compose env28678 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 7456) := by decide +kernel

theorem selectedBound28678 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28679 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,3345,3094,16401,1076,1025,3344,7456,32,16,2,3100,17,1297,6177,18480,2340,1285,22544,257,22544,6193,513]

theorem envBound28679 : H12AffineFastState.Bounded env28679 := by
  intro p hp
  have h : env28679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28678_28679 : H12AffineEnvironment.transform 20 7456 env28678 = env28679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 7456 env28678 == env28679) = true)

theorem identity28679 : scanCanonicalize (H12AffineFastState.compose env28679 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound28679 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28680 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,4112,3345,3094,4097,1076,1025,3344,7456,32,16,2,3100,17,1297,6177,6176,2340,1285,2048,257,2048,6193,513]

theorem envBound28680 : H12AffineFastState.Bounded env28680 := by
  intro p hp
  have h : env28680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28679_28680 : H12AffineEnvironment.transform 13 4112 env28679 = env28680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env28679 == env28680) = true)

theorem identity28680 : scanCanonicalize (H12AffineFastState.compose env28680 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound28680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28681 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,3100,293,3345,3094,308,1076,1025,3344,3093,32,16,2,3100,17,1297,2324,2325,2340,1285,2048,257,2048,2308,513]

theorem envBound28681 : H12AffineFastState.Bounded env28681 := by
  intro p hp
  have h : env28681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28680_28681 : H12AffineEnvironment.transform 11 309 env28680 = env28681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env28680 == env28681) = true)

theorem identity28681 : scanCanonicalize (H12AffineFastState.compose env28681 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1824) := by decide +kernel

theorem selectedBound28681 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env28682 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1824,309,828,293,561,822,308,1076,1025,560,821,32,16,2,828,17,1297,1588,1589,1540,1285,1824,257,1824,1572,513]

theorem envBound28682 : H12AffineFastState.Bounded env28682 := by
  intro p hp
  have h : env28682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28681_28682 : H12AffineEnvironment.transform 10 1824 env28681 = env28682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1824 env28681 == env28682) = true)

theorem identity28682 : scanCanonicalize (H12AffineFastState.compose env28682 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound28682 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env28683 : List Nat := [2,4,8,16,32,16,8,256,17,1024,1329,309,301,293,32,295,308,1076,1025,33,292,32,16,2,301,17,1297,1061,1060,1045,1285,1329,257,1329,1077,16]

theorem envBound28683 : H12AffineFastState.Bounded env28683 := by
  intro p hp
  have h : env28683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28682_28683 : H12AffineEnvironment.transform 8 17 env28682 = env28683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env28682 == env28683) = true)

theorem identity28683 : scanCanonicalize (H12AffineFastState.compose env28683 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28683 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env28684 : List Nat := [2,4,8,16,32,16,8,256,17,272,33,309,301,293,32,295,308,292,273,33,292,32,16,2,301,17,1,309,308,261,21,33,257,33,293,16]

theorem envBound28684 : H12AffineFastState.Bounded env28684 := by
  intro p hp
  have h : env28684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28683_28684 : H12AffineEnvironment.transform 9 272 env28683 = env28684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28683 == env28684) = true)

theorem identity28684 : scanCanonicalize (H12AffineFastState.compose env28684 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28684 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28685 : List Nat := [2,4,8,16,32,16,8,37,17,53,33,16,8,0,32,2,17,1,52,33,1,32,16,2,8,17,1,16,17,32,21,33,36,33,0,16]

theorem envBound28685 : H12AffineFastState.Bounded env28685 := by
  intro p hp
  have h : env28685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28684_28685 : H12AffineEnvironment.transform 7 37 env28684 = env28685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28684 == env28685) = true)

theorem identity28685 : scanCanonicalize (H12AffineFastState.compose env28685 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28686 : List Nat := [2,4,8,16,16,16,8,21,17,5,17,16,8,0,16,2,17,1,4,17,1,16,16,2,8,17,1,16,17,16,21,17,20,17,0,16]

theorem envBound28686 : H12AffineFastState.Bounded env28686 := by
  intro p hp
  have h : env28686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28685_28686 : H12AffineEnvironment.transform 4 16 env28685 = env28686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28685 == env28686) = true)

theorem identity28686 : scanCanonicalize (H12AffineFastState.compose env28686 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28686 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env28687 : List Nat := [2,4,8,1,1,1,8,4,0,5,0,1,8,0,1,2,0,1,4,0,1,1,1,2,8,0,1,1,0,1,4,0,5,0,0,1]

theorem envBound28687 : H12AffineFastState.Bounded env28687 := by
  intro p hp
  have h : env28687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28686_28687 : H12AffineEnvironment.transform 3 1 env28686 = env28687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28686 == env28687) = true)

def env28688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575541,18973701,10507600,8538484,25265168,23160137,257,27378724,27337993,25207631]

theorem envBound28688 : H12AffineFastState.Bounded env28688 := by
  intro p hp
  have h : env28688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28621_28688 : H12AffineEnvironment.transform 6 9 env28621 = env28688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28621 == env28688) = true)

theorem identity28688 : scanCanonicalize (H12AffineFastState.compose env28688 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8634709) := by decide +kernel

theorem selectedBound28688 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env28689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8634709,8193,65,4229152,10634576,10507600,8538484,148805,14853148,257,2229617,2286684,221722]

theorem envBound28689 : H12AffineFastState.Bounded env28689 := by
  intro p hp
  have h : env28689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28688_28689 : H12AffineEnvironment.transform 23 8634709 env28688 = env28689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8634709 env28688 == env28689) = true)

def env28690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,98645,8193,65,4229152,2098512,2233680,2420,148805,6349852,257,2229617,2286684,221722]

theorem envBound28690 : H12AffineFastState.Bounded env28690 := by
  intro p hp
  have h : env28690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28689_28690 : H12AffineEnvironment.transform 22 147456 env28689 = env28690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env28689 == env28690) = true)

def env28691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,98645,8193,65,4229152,2098512,2118976,2420,1365,6349852,257,2114913,2139212,74250]

theorem envBound28691 : H12AffineFastState.Bounded env28691 := by
  intro p hp
  have h : env28691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28690_28691 : H12AffineEnvironment.transform 16 16400 env28690 = env28691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28690 == env28691) = true)

theorem identity28691 : scanCanonicalize (H12AffineFastState.compose env28691 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28691 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2098512,2118976,2420,1365,6349852,257,2114913,2139212,513]

theorem envBound28692 : H12AffineFastState.Bounded env28692 := by
  intro p hp
  have h : env28692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28691_28692 : H12AffineEnvironment.transform 15 8203 env28691 = env28692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28691 == env28692) = true)

theorem identity28692 : scanCanonicalize (H12AffineFastState.compose env28692 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound28692 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,2114912,16,41310,8193,65,2149696,2098512,2118976,2420,1365,41340,257,2114913,2139212,513]

theorem envBound28693 : H12AffineFastState.Bounded env28693 := by
  intro p hp
  have h : env28693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28692_28693 : H12AffineEnvironment.transform 21 2114912 env28692 = env28693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env28692 == env28693) = true)

theorem identity28693 : scanCanonicalize (H12AffineFastState.compose env28693 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound28693 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30776,1025,29005,2097152,2114912,16,20498,8193,65,2112524,2098512,2118976,2420,1365,20528,257,2114913,2118912,513]

theorem envBound28694 : H12AffineFastState.Bounded env28694 := by
  intro p hp
  have h : env28694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28693_28694 : H12AffineEnvironment.transform 14 29004 env28693 = env28694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env28693 == env28694) = true)

theorem identity28694 : scanCanonicalize (H12AffineFastState.compose env28694 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28694 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env28695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30776,1025,29005,5457,20529,16,20498,8193,65,10589,4097,16401,2420,1365,20528,257,20528,16465,513]

theorem envBound28695 : H12AffineFastState.Bounded env28695 := by
  intro p hp
  have h : env28695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28694_28695 : H12AffineEnvironment.transform 20 5457 env28694 = env28695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env28694 == env28695) = true)

theorem identity28695 : scanCanonicalize (H12AffineFastState.compose env28695 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound28695 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10280,1025,8541,5457,33,16,2,8193,65,10589,4097,4097,2420,1365,32,257,32,4161,513]

theorem envBound28696 : H12AffineFastState.Bounded env28696 := by
  intro p hp
  have h : env28696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28695_28696 : H12AffineEnvironment.transform 13 4112 env28695 = env28696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env28695 == env28696) = true)

theorem identity28696 : scanCanonicalize (H12AffineFastState.compose env28696 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28696 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,0,343,4096,2420,1025,1,5457,33,16,2,349,65,2049,4097,4097,2420,1365,32,257,32,4161,513]

theorem envBound28697 : H12AffineFastState.Bounded env28697 := by
  intro p hp
  have h : env28697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28696_28697 : H12AffineEnvironment.transform 12 348 env28696 = env28697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28696 == env28697) = true)

theorem identity28697 : scanCanonicalize (H12AffineFastState.compose env28697 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound28697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,577,348,593,0,343,577,2420,1025,1,1808,33,16,2,349,65,2049,576,576,2420,1365,32,257,32,512,513]

theorem envBound28698 : H12AffineFastState.Bounded env28698 := by
  intro p hp
  have h : env28698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28697_28698 : H12AffineEnvironment.transform 11 577 env28697 = env28698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env28697 == env28698) = true)

theorem identity28698 : scanCanonicalize (H12AffineFastState.compose env28698 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound28698 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,528,577,348,593,0,343,577,868,1025,1,1808,33,16,2,349,65,529,576,576,868,1365,32,257,32,512,513]

theorem envBound28699 : H12AffineFastState.Bounded env28699 := by
  intro p hp
  have h : env28699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28698_28699 : H12AffineEnvironment.transform 10 528 env28698 = env28699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env28698 == env28699) = true)

theorem identity28699 : scanCanonicalize (H12AffineFastState.compose env28699 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound28699 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env28700 : List Nat := [2,4,8,16,32,64,9,256,512,543,528,577,348,593,0,343,577,868,542,1,271,33,16,2,349,65,529,576,576,868,842,32,257,32,512,513]

theorem envBound28700 : H12AffineFastState.Bounded env28700 := by
  intro p hp
  have h : env28700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28699_28700 : H12AffineEnvironment.transform 9 543 env28699 = env28700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env28699 == env28700) = true)

theorem identity28700 : scanCanonicalize (H12AffineFastState.compose env28700 (packedSelected [2,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound28700 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28701 : List Nat := [2,4,8,16,32,64,9,256,351,320,335,286,348,270,0,343,286,59,321,1,271,33,16,2,349,65,334,287,287,59,21,32,257,32,351,350]

theorem envBound28701 : H12AffineFastState.Bounded env28701 := by
  intro p hp
  have h : env28701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28700_28701 : H12AffineEnvironment.transform 8 351 env28700 = env28701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env28700 == env28701) = true)

theorem identity28701 : scanCanonicalize (H12AffineFastState.compose env28701 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound28701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28702 : List Nat := [2,4,8,16,32,42,9,256,309,298,293,286,310,270,0,317,286,59,299,1,271,33,16,2,311,43,292,287,287,59,21,32,257,32,309,308]

theorem envBound28702 : H12AffineFastState.Bounded env28702 := by
  intro p hp
  have h : env28702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28701_28702 : H12AffineEnvironment.transform 5 42 env28701 = env28702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env28701 == env28702) = true)

theorem identity28702 : scanCanonicalize (H12AffineFastState.compose env28702 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28702 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28703 : List Nat := [2,4,8,16,32,42,9,36,17,14,1,58,18,42,0,25,58,59,15,1,43,33,16,2,19,43,0,59,59,59,21,32,37,32,17,16]

theorem envBound28703 : H12AffineFastState.Bounded env28703 := by
  intro p hp
  have h : env28703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28702_28703 : H12AffineEnvironment.transform 7 36 env28702 = env28703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28702 == env28703) = true)

def env28704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,98645,8193,65,4229152,2098512,2118977,2420,1364,6349852,257,2114912,2139213,74251]

theorem envBound28704 : H12AffineFastState.Bounded env28704 := by
  intro p hp
  have h : env28704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28690_28704 : H12AffineEnvironment.transform 16 16401 env28690 = env28704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28690 == env28704) = true)

theorem identity28704 : scanCanonicalize (H12AffineFastState.compose env28704 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28704 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,2097152,4194304,17,3,8193,65,4229152,2098512,2118977,2420,1364,6349852,257,2114912,2139213,41821]

theorem envBound28705 : H12AffineFastState.Bounded env28705 := by
  intro p hp
  have h : env28705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28704_28705 : H12AffineEnvironment.transform 15 33110 env28704 = env28705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28704 == env28705) = true)

theorem identity28705 : scanCanonicalize (H12AffineFastState.compose env28705 (packedSelected [1,4,8,9,11,14,17,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound28705 : packedSelected [1,4,8,9,11,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env28706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,12392,4194304,17,3,8193,65,4229152,13624,25897,2420,1364,4248692,257,29960,37925,41821]

theorem envBound28706 : H12AffineFastState.Bounded env28706 := by
  intro p hp
  have h : env28706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28705_28706 : H12AffineEnvironment.transform 20 12392 env28705 = env28706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env28705 == env28706) = true)

theorem identity28706 : scanCanonicalize (H12AffineFastState.compose env28706 (packedSelected [0,7,9,14,16,17,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound28706 : packedSelected [0,7,9,14,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env28707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,12392,21508,17,3,8193,65,56356,13624,25897,2420,1364,32880,257,29960,37925,41821]

theorem envBound28707 : H12AffineFastState.Bounded env28707 := by
  intro p hp
  have h : env28707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28706_28707 : H12AffineEnvironment.transform 21 21508 env28706 = env28707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env28706 == env28707) = true)

theorem identity28707 : scanCanonicalize (H12AffineFastState.compose env28707 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28707 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env28708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,12392,21508,17,3,8193,65,32121,13624,25897,2420,1364,8493,257,29960,13688,512]

theorem envBound28708 : H12AffineFastState.Bounded env28708 := by
  intro p hp
  have h : env28708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28707_28708 : H12AffineEnvironment.transform 14 8541 env28707 = env28708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28707 == env28708) = true)

theorem identity28708 : scanCanonicalize (H12AffineFastState.compose env28708 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28708 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10281,1025,8540,12392,260,17,3,8193,65,10361,13624,12329,2420,1364,8493,257,8200,13688,512]

theorem envBound28709 : H12AffineFastState.Bounded env28709 := by
  intro p hp
  have h : env28709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28708_28709 : H12AffineEnvironment.transform 13 5376 env28708 = env28709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28708 == env28709) = true)

theorem identity28709 : scanCanonicalize (H12AffineFastState.compose env28709 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound28709 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5376,341,3,5393,2081,1025,340,4192,260,17,3,9,65,2161,5424,4129,2420,1364,293,257,0,5488,512]

theorem envBound28710 : H12AffineFastState.Bounded env28710 := by
  intro p hp
  have h : env28710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28709_28710 : H12AffineEnvironment.transform 12 8 env28709 = env28710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env28709 == env28710) = true)

theorem identity28710 : scanCanonicalize (H12AffineFastState.compose env28710 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound28710 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28711 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,1,3,5189,2081,1025,0,4192,80,17,3,9,65,2161,5220,4129,2080,1024,113,85,0,5156,512]

theorem envBound28711 : H12AffineFastState.Bounded env28711 := by
  intro p hp
  have h : env28711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28710_28711 : H12AffineEnvironment.transform 7 84 env28710 = env28711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env28710 == env28711) = true)

theorem identity28711 : scanCanonicalize (H12AffineFastState.compose env28711 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28711 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28712 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8,5125,1,3,5140,2081,1025,0,4145,1,17,3,9,16,2080,5173,4129,2080,1024,32,4,0,5156,512]

theorem envBound28712 : H12AffineFastState.Bounded env28712 := by
  intro p hp
  have h : env28712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28711_28712 : H12AffineEnvironment.transform 5 17 env28711 = env28712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28711 == env28712) = true)

theorem identity28712 : scanCanonicalize (H12AffineFastState.compose env28712 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28712 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28713 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,1,3,5140,2048,1025,0,4112,1,17,3,9,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound28713 : H12AffineFastState.Bounded env28713 := by
  intro p hp
  have h : env28713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28712_28713 : H12AffineEnvironment.transform 4 1 env28712 = env28713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28712 == env28713) = true)

def env28714 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,1,3,1028,2048,1025,0,0,1,17,3,9,16,2049,1028,16,2049,1024,1,4,0,1045,512]

theorem envBound28714 : H12AffineFastState.Bounded env28714 := by
  intro p hp
  have h : env28714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28713_28714 : H12AffineEnvironment.transform 11 16 env28713 = env28714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28713 == env28714) = true)

theorem identity28714 : scanCanonicalize (H12AffineFastState.compose env28714 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound28714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28715 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,1,1,3,16,2048,21,0,0,1,17,3,9,16,2049,16,16,2049,20,1,4,0,1,512]

theorem envBound28715 : H12AffineFastState.Bounded env28715 := by
  intro p hp
  have h : env28715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28714_28715 : H12AffineEnvironment.transform 9 20 env28714 = env28715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28714 == env28715) = true)

theorem identity28715 : scanCanonicalize (H12AffineFastState.compose env28715 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound28715 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28716 : List Nat := [2,4,8,16,1,17,9,5,512,20,20,16,8,1,1,3,16,20,21,0,0,1,17,3,9,16,21,16,16,21,20,1,4,0,1,512]

theorem envBound28716 : H12AffineFastState.Bounded env28716 := by
  intro p hp
  have h : env28716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28715_28716 : H12AffineEnvironment.transform 10 20 env28715 = env28716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env28715 == env28716) = true)

def leafEnv28716 : List Nat := [2,4,8,16,1,17,9,5,512,20,20,16,8,1,1,3,16,20,21,0,0,1,17,3,21,9,1,16,21,16,16,21,20,1,4,0,5,2,1,512,1,0,0]

def active28716 : List Nat := [0,1,2,3,8]

def tree28716 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28716 : H12WitnessSearch.Good tree28716 := H12GlobalWitnessIndex.good

theorem leafIdentity28716 : H12AffineFastState.composeSystem env28716 rootObs = leafEnv28716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28716 rootObs == leafEnv28716) = true)

theorem terminalChecked28716 : H12PackedTerminal.terminalCheckFast leafEnv28716 active28716 tree28716 = true := by decide +kernel

def env28717 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1044,1,3,1029,2048,1025,0,1,1,17,3,9,16,2049,1029,17,2049,1024,1,4,0,1044,512]

theorem envBound28717 : H12AffineFastState.Bounded env28717 := by
  intro p hp
  have h : env28717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28713_28717 : H12AffineEnvironment.transform 11 17 env28713 = env28717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28713 == env28717) = true)

def env28718 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,1,3,17,2048,21,0,1,1,17,3,9,16,2049,17,17,2049,20,1,4,0,0,512]

theorem envBound28718 : H12AffineFastState.Bounded env28718 := by
  intro p hp
  have h : env28718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28717_28718 : H12AffineEnvironment.transform 9 20 env28717 = env28718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28717 == env28718) = true)

theorem identity28718 : scanCanonicalize (H12AffineFastState.compose env28718 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound28718 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28719 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,17,8,0,1,3,17,21,21,0,1,1,17,3,9,16,20,17,17,20,20,1,4,0,0,512]

theorem envBound28719 : H12AffineFastState.Bounded env28719 := by
  intro p hp
  have h : env28719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28718_28719 : H12AffineEnvironment.transform 10 21 env28718 = env28719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env28718 == env28719) = true)

def leafEnv28719 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,17,8,0,1,3,17,21,21,0,1,1,17,3,21,9,1,16,20,17,17,20,20,1,4,0,5,2,0,512,1,1,0]

def active28719 : List Nat := [0,1,2,3,8]

def tree28719 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28719 : H12WitnessSearch.Good tree28719 := H12GlobalWitnessIndex.good

theorem leafIdentity28719 : H12AffineFastState.composeSystem env28719 rootObs = leafEnv28719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28719 rootObs == leafEnv28719) = true)

theorem terminalChecked28719 : H12PackedTerminal.terminalCheckFast leafEnv28719 active28719 tree28719 = true := by decide +kernel

def env28720 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,1,1,3,16,2048,20,0,1,1,17,3,9,16,2049,16,17,2049,21,1,4,0,1,512]

theorem envBound28720 : H12AffineFastState.Bounded env28720 := by
  intro p hp
  have h : env28720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28717_28720 : H12AffineEnvironment.transform 9 21 env28717 = env28720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env28717 == env28720) = true)

theorem identity28720 : scanCanonicalize (H12AffineFastState.compose env28720 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound28720 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28721 : List Nat := [2,4,8,16,1,17,9,5,512,21,542,17,8,1,1,3,16,542,20,0,1,1,17,3,9,16,543,16,17,543,21,1,4,0,1,512]

theorem envBound28721 : H12AffineFastState.Bounded env28721 := by
  intro p hp
  have h : env28721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28720_28721 : H12AffineEnvironment.transform 10 542 env28720 = env28721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env28720 == env28721) = true)

def leafEnv28721 : List Nat := [2,4,8,16,1,17,9,5,512,21,542,17,8,1,1,3,16,542,20,0,1,1,17,3,20,9,1,16,543,16,17,543,21,1,4,0,5,2,1,512,1,1,0]

def active28721 : List Nat := [0,1,2,3,8]

def tree28721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28721 : H12WitnessSearch.Good tree28721 := H12GlobalWitnessIndex.good

theorem leafIdentity28721 : H12AffineFastState.composeSystem env28721 rootObs = leafEnv28721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28721 rootObs == leafEnv28721) = true)

theorem terminalChecked28721 : H12PackedTerminal.terminalCheckFast leafEnv28721 active28721 tree28721 = true := by decide +kernel

def env28722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,98644,8193,65,4229152,2098513,2233681,2421,148805,6349853,257,2229617,2286684,221722]

theorem envBound28722 : H12AffineFastState.Bounded env28722 := by
  intro p hp
  have h : env28722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28689_28722 : H12AffineEnvironment.transform 22 147457 env28689 = env28722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env28689 == env28722) = true)

theorem identity28722 : scanCanonicalize (H12AffineFastState.compose env28722 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound28722 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env28723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,73754,98644,8193,65,4229152,2098513,2192714,2421,75102,6349853,257,2188650,2196551,513]

theorem envBound28723 : H12AffineFastState.Bounded env28723 := by
  intro p hp
  have h : env28723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28722_28723 : H12AffineEnvironment.transform 16 90139 env28722 = env28723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env28722 == env28723) = true)

theorem identity28723 : scanCanonicalize (H12AffineFastState.compose env28723 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound28723 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env28724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,98678,73754,98644,8193,65,67926,2098513,2192714,2421,75102,2188651,257,2188650,2196551,513]

theorem envBound28724 : H12AffineFastState.Bounded env28724 := by
  intro p hp
  have h : env28724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28723_28724 : H12AffineEnvironment.transform 21 98678 env28723 = env28724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env28723 == env28724) = true)

theorem identity28724 : scanCanonicalize (H12AffineFastState.compose env28724 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound28724 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env28725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,38144,98678,73754,98644,8193,65,67926,36945,122954,2421,75102,127083,257,127082,69959,513]

theorem envBound28725 : H12AffineFastState.Bounded env28725 := by
  intro p hp
  have h : env28725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28724_28725 : H12AffineEnvironment.transform 20 38144 env28724 = env28725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env28724 == env28725) = true)

theorem identity28725 : scanCanonicalize (H12AffineFastState.compose env28725 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28725 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env28726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10280,1025,8541,13404,73770,73754,73736,8193,65,67926,12557,82198,2421,75102,86327,257,86326,69959,513]

theorem envBound28726 : H12AffineFastState.Bounded env28726 := by
  intro p hp
  have h : env28726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28725_28726 : H12AffineEnvironment.transform 14 8540 env28725 = env28726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28725 == env28726) = true)

theorem identity28726 : scanCanonicalize (H12AffineFastState.compose env28726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound28726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,263,24860,10280,1025,8541,13404,8493,8477,8463,8193,65,2129,12557,16401,2421,9305,20528,257,20529,4160,513]

theorem envBound28727 : H12AffineFastState.Bounded env28727 := by
  intro p hp
  have h : env28727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28726_28727 : H12AffineEnvironment.transform 15 263 env28726 = env28727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env28726 == env28727) = true)

theorem identity28727 : scanCanonicalize (H12AffineFastState.compose env28727 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound28727 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env28728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,263,13672,10280,1025,8541,13404,8493,8477,8463,8193,65,2129,12557,5221,2421,9305,1092,257,1093,4160,513]

theorem envBound28728 : H12AffineFastState.Bounded env28728 := by
  intro p hp
  have h : env28728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28727_28728 : H12AffineEnvironment.transform 13 5236 env28727 = env28728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env28727 == env28728) = true)

theorem identity28728 : scanCanonicalize (H12AffineFastState.compose env28728 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound28728 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env28729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7544,5236,7204,263,2064,5456,1025,7205,2340,7253,7269,7287,7545,65,2129,3189,5221,2421,6433,1092,257,1093,4160,513]

theorem envBound28729 : H12AffineFastState.Bounded env28729 := by
  intro p hp
  have h : env28729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28728_28729 : H12AffineEnvironment.transform 12 7544 env28728 = env28729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env28728 == env28729) = true)

theorem identity28729 : scanCanonicalize (H12AffineFastState.compose env28729 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound28729 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env28730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,268,2048,80,263,2064,2340,1025,81,2340,33,17,3,269,65,2129,3189,2065,2421,1365,1092,257,1093,3124,513]

theorem envBound28730 : H12AffineFastState.Bounded env28730 := by
  intro p hp
  have h : env28730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28729_28730 : H12AffineEnvironment.transform 11 3188 env28729 = env28730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env28729 == env28730) = true)

theorem identity28730 : scanCanonicalize (H12AffineFastState.compose env28730 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28730 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28731 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,268,2048,0,263,2064,2340,1025,1,2340,33,17,3,269,17,2049,3109,2065,2341,1285,1044,257,1045,3124,513]

theorem envBound28731 : H12AffineFastState.Bounded env28731 := by
  intro p hp
  have h : env28731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28730_28731 : H12AffineEnvironment.transform 5 16 env28730 = env28731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28730 == env28731) = true)

def env28732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound28732 : H12AffineFastState.Bounded env28732 := by
  intro p hp
  have h : env28732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28459_28732 : H12AffineEnvironment.transform 26 30393345 env28459 = env28732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env28459 == env28732) = true)

def env28733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound28733 : H12AffineFastState.Bounded env28733 := by
  intro p hp
  have h : env28733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28732_28733 : H12AffineEnvironment.transform 18 1024 env28732 = env28733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28732 == env28733) = true)

theorem identity28733 : scanCanonicalize (H12AffineFastState.compose env28733 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493629) := by decide +kernel

theorem selectedBound28733 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,16777216,8328,65,23186620,18973837,416237,2149565,19368109,23160257,256,17287184,17246644,19312506]

theorem envBound28734 : H12AffineFastState.Bounded env28734 := by
  intro p hp
  have h : env28734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28733_28734 : H12AffineEnvironment.transform 22 2493629 env28733 = env28734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493629 env28733 == env28734) = true)

def env28735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,498992,8328,65,6705548,2496957,416237,2149565,2102685,6748401,256,21792,46212,2175562]

theorem envBound28735 : H12AffineFastState.Bounded env28735 := by
  intro p hp
  have h : env28735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28734_28735 : H12AffineEnvironment.transform 23 498992 env28734 = env28735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env28734 == env28735) = true)

def env28736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493629,498992,8328,65,2396468,2496957,416237,2149565,2102685,2373705,256,21792,46212,2175562]

theorem envBound28736 : H12AffineFastState.Bounded env28736 := by
  intro p hp
  have h : env28736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28735_28736 : H12AffineEnvironment.transform 21 180408 env28735 = env28736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env28735 == env28736) = true)

def env28737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400637,498992,8328,65,295284,395773,416237,56573,1501,272393,256,21792,46212,74250]

theorem envBound28737 : H12AffineFastState.Bounded env28737 := by
  intro p hp
  have h : env28737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28736_28737 : H12AffineEnvironment.transform 20 4160 env28736 = env28737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28736 == env28737) = true)

theorem identity28737 : scanCanonicalize (H12AffineFastState.compose env28737 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound28737 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,180408,400637,412143,8328,65,295284,395773,416237,56573,1501,272393,256,21792,46212,63189]

theorem envBound28738 : H12AffineFastState.Bounded env28738 := by
  intro p hp
  have h : env28738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28737_28738 : H12AffineEnvironment.transform 15 54495 env28737 = env28738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env28737 == env28738) = true)

def env28739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180272,400501,412007,8192,65,295284,395637,416101,56437,1365,272393,256,21792,46092,63069]

theorem envBound28739 : H12AffineFastState.Bounded env28739 := by
  intro p hp
  have h : env28739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28738_28739 : H12AffineEnvironment.transform 6 8 env28738 = env28739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28738 == env28739) = true)

theorem identity28739 : scanCanonicalize (H12AffineFastState.compose env28739 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound28739 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env28740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,23589,1024,32769,4160,180272,147536,136514,8192,65,56657,152912,132416,56437,1365,29740,256,21792,46092,63069]

theorem envBound28740 : H12AffineFastState.Bounded env28740 := by
  intro p hp
  have h : env28740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28739_28740 : H12AffineEnvironment.transform 17 23589 env28739 = env28740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env28739 == env28740) = true)

theorem identity28740 : scanCanonicalize (H12AffineFastState.compose env28740 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound28740 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env28741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,57676,23589,1024,32769,4160,8572,41244,62478,8192,65,56657,46108,58380,56437,1365,29740,256,21792,46092,63069]

theorem envBound28741 : H12AffineFastState.Bounded env28741 := by
  intro p hp
  have h : env28741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28740_28741 : H12AffineEnvironment.transform 16 57676 env28740 = env28741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env28740 == env28741) = true)

theorem identity28741 : scanCanonicalize (H12AffineFastState.compose env28741 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28741 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,38161,10360,1024,32769,4160,8572,41244,32851,8192,65,43276,46108,36945,43048,1365,113,256,8573,46092,33280]

theorem envBound28742 : H12AffineFastState.Bounded env28742 := by
  intro p hp
  have h : env28742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28741_28742 : H12AffineEnvironment.transform 13 13405 env28741 = env28742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28741 == env28742) = true)

theorem identity28742 : scanCanonicalize (H12AffineFastState.compose env28742 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28742 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env28743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,5393,10360,1024,1,4160,8572,8476,83,8192,65,10508,13340,4177,10280,1365,113,256,8573,13324,512]

theorem envBound28743 : H12AffineFastState.Bounded env28743 := by
  intro p hp
  have h : env28743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28742_28743 : H12AffineEnvironment.transform 14 0 env28742 = env28743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28742 == env28743) = true)

theorem identity28743 : scanCanonicalize (H12AffineFastState.compose env28743 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28744 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13405,0,8202,5393,10329,1024,1,4160,8541,8476,83,8192,65,10508,13340,4177,10249,1365,80,256,8540,13324,512]

theorem envBound28744 : H12AffineFastState.Bounded env28744 := by
  intro p hp
  have h : env28744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28743_28744 : H12AffineEnvironment.transform 4 1 env28743 = env28744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28743 == env28744) = true)

theorem identity28744 : scanCanonicalize (H12AffineFastState.compose env28744 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound28744 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28745 : List Nat := [2,4,8,16,1,64,8,256,512,20,2048,4096,8192,12361,0,8202,4357,10329,20,1,4160,8541,8476,83,8192,65,10508,12296,4177,10249,321,80,256,8540,12312,512]

theorem envBound28745 : H12AffineFastState.Bounded env28745 := by
  intro p hp
  have h : env28745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28744_28745 : H12AffineEnvironment.transform 9 20 env28744 = env28745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28744 == env28745) = true)

theorem identity28745 : scanCanonicalize (H12AffineFastState.compose env28745 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28745 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env28746 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,4096,8192,12313,0,8202,4357,10249,20,1,4112,8461,8476,3,8192,17,10508,12296,4097,10249,273,0,256,8460,12312,512]

theorem envBound28746 : H12AffineFastState.Bounded env28746 := by
  intro p hp
  have h : env28746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28745_28746 : H12AffineEnvironment.transform 5 16 env28745 = env28746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28745 == env28746) = true)

theorem identity28746 : scanCanonicalize (H12AffineFastState.compose env28746 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound28746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28747 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,4096,4380,261,0,4374,4357,6421,20,1,4112,4113,4096,3,4380,17,6160,276,4097,6421,273,0,256,4112,260,512]

theorem envBound28747 : H12AffineFastState.Bounded env28747 := by
  intro p hp
  have h : env28747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28746_28747 : H12AffineEnvironment.transform 12 4380 env28746 = env28747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env28746 == env28747) = true)

theorem identity28747 : scanCanonicalize (H12AffineFastState.compose env28747 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound28747 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28748 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,2325,2057,261,0,2051,2064,0,20,1,2309,2308,2325,3,2057,17,261,276,2324,0,273,0,256,2309,260,512]

theorem envBound28748 : H12AffineFastState.Bounded env28748 := by
  intro p hp
  have h : env28748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28747_28748 : H12AffineEnvironment.transform 11 2325 env28747 = env28748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env28747 == env28748) = true)

def env28749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180273,400500,412006,8193,65,295284,395636,416100,56436,1364,272393,256,21792,46093,63068]

theorem envBound28749 : H12AffineFastState.Bounded env28749 := by
  intro p hp
  have h : env28749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28738_28749 : H12AffineEnvironment.transform 6 9 env28738 = env28749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28738 == env28749) = true)

theorem identity28749 : scanCanonicalize (H12AffineFastState.compose env28749 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182288) := by decide +kernel

theorem selectedBound28749 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env28750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,182288,1024,32769,4160,180273,54372,33142,8193,65,149860,49508,37236,56436,1364,188441,256,21792,46093,63068]

theorem envBound28750 : H12AffineFastState.Bounded env28750 := by
  intro p hp
  have h : env28750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28749_28750 : H12AffineEnvironment.transform 17 182288 env28749 = env28750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182288 env28749 == env28750) = true)

theorem identity28750 : scanCanonicalize (H12AffineFastState.compose env28750 (packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound28750 : packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env28751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,5393,56577,1024,32769,4160,54560,54372,33142,8193,65,23669,49508,37236,56436,1364,62728,256,21792,46093,63068]

theorem envBound28751 : H12AffineFastState.Bounded env28751 := by
  intro p hp
  have h : env28751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28750_28751 : H12AffineEnvironment.transform 16 5393 env28750 = env28751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env28750 == env28751) = true)

theorem identity28751 : scanCanonicalize (H12AffineFastState.compose env28751 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound28751 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env28752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32803,5393,35188,1024,32769,4160,33109,32785,33142,8193,65,2048,38161,37236,34817,1364,41341,256,341,46093,41513]

theorem envBound28752 : H12AffineFastState.Bounded env28752 := by
  intro p hp
  have h : env28752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28751_28752 : H12AffineEnvironment.transform 13 5237 env28751 = env28752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env28751 == env28752) = true)

theorem identity28752 : scanCanonicalize (H12AffineFastState.compose env28752 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28752 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env28753 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,32768,32803,5173,34896,1024,32769,4160,32881,32785,32850,8193,65,2048,37941,36944,34817,1136,41049,36,113,46093,41513]

theorem envBound28753 : H12AffineFastState.Bounded env28753 := by
  intro p hp
  have h : env28753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28752_28753 : H12AffineEnvironment.transform 7 36 env28752 = env28753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28752 == env28753) = true)

theorem identity28753 : scanCanonicalize (H12AffineFastState.compose env28753 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound28753 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28754 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,8312,8283,5173,10280,1024,8313,4160,8201,8297,8234,8193,65,2048,13389,12328,10361,1136,33,36,113,5237,593]

theorem envBound28754 : H12AffineFastState.Bounded env28754 := by
  intro p hp
  have h : env28754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28753_28754 : H12AffineEnvironment.transform 14 8312 env28753 = env28754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env28753 == env28754) = true)

theorem identity28754 : scanCanonicalize (H12AffineFastState.compose env28754 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound28754 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28755 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,6201,5237,6209,6242,5173,4113,1024,6208,4160,6192,6224,6163,6200,65,2048,3188,2065,4160,1136,33,36,113,5237,593]

theorem envBound28755 : H12AffineFastState.Bounded env28755 := by
  intro p hp
  have h : env28755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28754_28755 : H12AffineEnvironment.transform 12 6201 env28754 = env28755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env28754 == env28755) = true)

theorem identity28755 : scanCanonicalize (H12AffineFastState.compose env28755 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound28755 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28756 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,1052,2128,1124,1095,2064,3124,1024,1125,3173,1045,1141,1078,1053,65,2048,3188,2065,3173,1136,33,36,113,2128,593]

theorem envBound28756 : H12AffineFastState.Bounded env28756 := by
  intro p hp
  have h : env28756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28755_28756 : H12AffineEnvironment.transform 11 3109 env28755 = env28756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env28755 == env28756) = true)

theorem identity28756 : scanCanonicalize (H12AffineFastState.compose env28756 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound28756 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env28757 : List Nat := [2,4,8,16,32,64,9,36,512,1024,81,1140,1052,1,1124,1095,65,1125,1024,1125,1076,1045,1141,1078,1053,65,81,1061,64,1076,1136,33,36,113,1,593]

theorem envBound28757 : H12AffineFastState.Bounded env28757 := by
  intro p hp
  have h : env28757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28756_28757 : H12AffineEnvironment.transform 10 81 env28756 = env28757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env28756 == env28757) = true)

theorem identity28757 : scanCanonicalize (H12AffineFastState.compose env28757 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28757 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28758 : List Nat := [2,4,8,16,32,64,9,36,512,100,81,16,120,1,0,35,65,1,100,1,80,113,17,82,121,65,81,65,64,80,20,33,36,113,1,593]

theorem envBound28758 : H12AffineFastState.Bounded env28758 := by
  intro p hp
  have h : env28758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28757_28758 : H12AffineEnvironment.transform 9 100 env28757 = env28758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28757 == env28758) = true)

theorem identity28758 : scanCanonicalize (H12AffineFastState.compose env28758 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28758 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28759 : List Nat := [2,4,8,16,32,17,9,36,512,53,0,16,41,1,0,35,16,1,53,1,1,32,17,3,40,16,0,16,17,1,20,33,36,32,1,512]

theorem envBound28759 : H12AffineFastState.Bounded env28759 := by
  intro p hp
  have h : env28759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28758_28759 : H12AffineEnvironment.transform 5 17 env28758 = env28759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28758 == env28759) = true)

theorem identity28759 : scanCanonicalize (H12AffineFastState.compose env28759 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28760 : List Nat := [2,1,8,16,32,17,9,33,512,48,0,16,41,1,0,35,16,1,48,1,1,32,17,3,40,16,0,16,17,1,17,33,33,32,1,512]

theorem envBound28760 : H12AffineFastState.Bounded env28760 := by
  intro p hp
  have h : env28760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28759_28760 : H12AffineEnvironment.transform 1 1 env28759 = env28760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28759 == env28760) = true)

theorem identity28760 : scanCanonicalize (H12AffineFastState.compose env28760 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound28760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28761 : List Nat := [2,1,8,16,32,17,9,33,3,48,0,16,41,1,0,35,16,1,48,1,1,32,17,3,40,16,0,16,17,1,17,33,33,32,1,3]

theorem envBound28761 : H12AffineFastState.Bounded env28761 := by
  intro p hp
  have h : env28761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28760_28761 : H12AffineEnvironment.transform 8 3 env28760 = env28761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env28760 == env28761) = true)

theorem identity28761 : scanCanonicalize (H12AffineFastState.compose env28761 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28761 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28762 : List Nat := [2,1,8,16,0,17,9,1,3,16,0,16,9,1,0,3,16,1,16,1,1,0,17,3,8,16,0,16,17,1,17,1,1,0,1,3]

theorem envBound28762 : H12AffineFastState.Bounded env28762 := by
  intro p hp
  have h : env28762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28761_28762 : H12AffineEnvironment.transform 4 0 env28761 = env28762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28761 == env28762) = true)

theorem identity28762 : scanCanonicalize (H12AffineFastState.compose env28762 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28762 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28763 : List Nat := [2,1,1,16,0,17,0,1,3,16,0,16,0,1,0,3,16,1,16,1,1,0,17,3,1,16,0,16,17,1,17,1,1,0,1,3]

theorem envBound28763 : H12AffineFastState.Bounded env28763 := by
  intro p hp
  have h : env28763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28762_28763 : H12AffineEnvironment.transform 2 1 env28762 = env28763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28762 == env28763) = true)

def env28764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400636,498992,8328,65,295285,395772,416237,56572,1500,272392,256,21792,46212,74251]

theorem envBound28764 : H12AffineFastState.Bounded env28764 := by
  intro p hp
  have h : env28764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28736_28764 : H12AffineEnvironment.transform 20 4161 env28736 = env28764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28736 == env28764) = true)

theorem identity28764 : scanCanonicalize (H12AffineFastState.compose env28764 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound28764 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4161,180408,73754,41430,8328,65,245139,79130,91403,56572,1500,201966,256,21792,46212,74251]

theorem envBound28765 : H12AffineFastState.Bounded env28765 := by
  intro p hp
  have h : env28765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28764_28765 : H12AffineEnvironment.transform 17 212198 env28764 = env28765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env28764 == env28765) = true)

def env28766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67754,1024,32769,4161,62708,73754,41430,8328,65,100831,79130,91403,56572,1500,73890,256,21792,46212,74251]

theorem envBound28766 : H12AffineFastState.Bounded env28766 := by
  intro p hp
  have h : env28766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28765_28766 : H12AffineEnvironment.transform 16 13388 env28765 = env28766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env28765 == env28766) = true)

theorem identity28766 : scanCanonicalize (H12AffineFastState.compose env28766 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 34147) := by decide +kernel

theorem selectedBound28766 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env28767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,34147,13388,36297,1024,32769,4161,62708,42361,41430,8328,65,3260,45177,57448,56572,1500,42433,256,21792,46212,42856]

theorem envBound28767 : H12AffineFastState.Bounded env28767 := by
  intro p hp
  have h : env28767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28766_28767 : H12AffineEnvironment.transform 15 34147 env28766 = env28767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34147 env28766 == env28767) = true)

theorem identity28767 : scanCanonicalize (H12AffineFastState.compose env28767 (packedSelected [1,8,9,10,15,16,18,19,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 3261) := by decide +kernel

theorem selectedBound28767 : packedSelected [1,8,9,10,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env28768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,3261,32768,34147,13388,36297,1024,32769,4161,47177,42361,41430,8328,65,3260,45177,44245,36929,1500,42433,256,6557,46212,42856]

theorem envBound28768 : H12AffineFastState.Bounded env28768 := by
  intro p hp
  have h : env28768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28767_28768 : H12AffineEnvironment.transform 13 3261 env28767 = env28768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3261 env28767 == env28768) = true)

theorem identity28768 : scanCanonicalize (H12AffineFastState.compose env28768 (packedSelected [5,8,15,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28768 : packedSelected [5,8,15,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,3261,5513,4330,13388,6208,1024,5512,4161,11712,12528,13407,8328,65,3260,9712,14684,1480,1500,12360,256,6557,8461,13025]

theorem envBound28769 : H12AffineFastState.Bounded env28769 := by
  intro p hp
  have h : env28769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28768_28769 : H12AffineEnvironment.transform 14 5513 env28768 = env28769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5513 env28768 == env28769) = true)

theorem identity28769 : scanCanonicalize (H12AffineFastState.compose env28769 (packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28769 : packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env28770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,3261,5513,4330,5441,6208,1024,5512,4161,3277,4605,5458,389,65,3260,1277,6225,1480,1500,4421,256,6557,0,5100]

theorem envBound28770 : H12AffineFastState.Bounded env28770 := by
  intro p hp
  have h : env28770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28769_28770 : H12AffineEnvironment.transform 12 269 env28769 = env28770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28769 == env28770) = true)

theorem identity28770 : scanCanonicalize (H12AffineFastState.compose env28770 (packedSelected [0,2,6,7,9,10,11,12,16,19,20,22] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound28770 : packedSelected [0,2,6,7,9,10,11,12,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,4096,269,292,5513,4330,5441,5593,1024,5512,4161,340,4605,5458,389,65,293,1277,5576,1480,1500,4421,256,5124,0,5100]

theorem envBound28771 : H12AffineFastState.Bounded env28771 := by
  intro p hp
  have h : env28771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28770_28771 : H12AffineEnvironment.transform 10 1433 env28770 = env28771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env28770 == env28771) = true)

theorem identity28771 : scanCanonicalize (H12AffineFastState.compose env28771 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound28771 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,493,269,292,1124,263,1196,1076,1024,1125,428,340,16,1215,389,65,293,1277,1061,1480,1500,168,256,1513,0,513]

theorem envBound28772 : H12AffineFastState.Bounded env28772 := by
  intro p hp
  have h : env28772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28771_28772 : H12AffineEnvironment.transform 11 493 env28771 = env28772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env28771 == env28772) = true)

theorem identity28772 : scanCanonicalize (H12AffineFastState.compose env28772 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28772 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env28773 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1345,309,269,292,1124,263,1140,1076,1024,1125,372,340,16,1127,349,65,293,1061,1061,1296,1284,112,256,1329,0,513]

theorem envBound28773 : H12AffineFastState.Bounded env28773 := by
  intro p hp
  have h : env28773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28772_28773 : H12AffineEnvironment.transform 6 88 env28772 = env28773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28772 == env28773) = true)

theorem identity28773 : scanCanonicalize (H12AffineFastState.compose env28773 (packedSelected [2,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound28773 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env28774 : List Nat := [2,4,8,16,32,64,88,256,512,321,0,309,269,292,293,263,309,373,321,292,372,340,16,294,349,65,293,356,356,81,69,112,256,112,0,513]

theorem envBound28774 : H12AffineFastState.Bounded env28774 := by
  intro p hp
  have h : env28774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28773_28774 : H12AffineEnvironment.transform 9 321 env28773 = env28774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env28773 == env28774) = true)

theorem identity28774 : scanCanonicalize (H12AffineFastState.compose env28774 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28774 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28775 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,309,269,292,293,263,309,293,273,292,292,260,16,294,269,17,293,308,308,1,21,32,256,32,0,513]

theorem envBound28775 : H12AffineFastState.Bounded env28775 := by
  intro p hp
  have h : env28775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28774_28775 : H12AffineEnvironment.transform 5 16 env28774 = env28775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28774 == env28775) = true)

theorem identity28775 : scanCanonicalize (H12AffineFastState.compose env28775 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28776 : List Nat := [2,4,8,16,32,16,8,4,512,21,0,49,9,32,33,3,49,33,21,32,32,0,16,34,9,17,33,48,48,1,21,32,4,32,0,513]

theorem envBound28776 : H12AffineFastState.Bounded env28776 := by
  intro p hp
  have h : env28776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28775_28776 : H12AffineEnvironment.transform 7 4 env28775 = env28776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28775 == env28776) = true)

theorem identity28776 : scanCanonicalize (H12AffineFastState.compose env28776 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28776 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env28777 : List Nat := [2,4,8,16,1,16,8,4,512,21,0,16,9,1,0,3,16,0,21,1,1,0,16,3,9,17,0,17,17,1,21,1,4,1,0,513]

theorem envBound28777 : H12AffineFastState.Bounded env28777 := by
  intro p hp
  have h : env28777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28776_28777 : H12AffineEnvironment.transform 4 1 env28776 = env28777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28776 == env28777) = true)

def env28778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,67755,1024,32769,4161,62709,73754,41430,8328,65,100830,79130,91403,56572,1500,73891,256,21792,46212,74251]

theorem envBound28778 : H12AffineFastState.Bounded env28778 := by
  intro p hp
  have h : env28778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28765_28778 : H12AffineEnvironment.transform 16 13389 env28765 = env28778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env28765 == env28778) = true)

theorem identity28778 : scanCanonicalize (H12AffineFastState.compose env28778 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28778 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env28779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,13389,67755,1024,1,4161,29941,73754,8662,8328,65,68062,79130,91403,23804,1500,73891,256,21792,13444,74251]

theorem envBound28779 : H12AffineFastState.Bounded env28779 := by
  intro p hp
  have h : env28779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28778_28779 : H12AffineEnvironment.transform 14 0 env28778 = env28779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28778 == env28779) = true)

theorem identity28779 : scanCanonicalize (H12AffineFastState.compose env28779 (packedSelected [0,1,2,5,6,7,8,9,10,11,15,16,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound28779 : packedSelected [0,1,2,5,6,7,8,9,10,11,15,16,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env28780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,29962,13389,32161,1024,1,4161,29941,21776,8662,8328,65,31956,16400,4097,23804,1500,21929,256,21792,13444,22273]

theorem envBound28780 : H12AffineFastState.Bounded env28780 := by
  intro p hp
  have h : env28780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28779_28780 : H12AffineEnvironment.transform 15 29962 env28779 = env28780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env28779 == env28780) = true)

theorem identity28780 : scanCanonicalize (H12AffineFastState.compose env28780 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28780 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env28781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,0,8322,13389,10281,1024,1,4161,8573,152,8662,8328,65,10588,5528,4097,2420,1500,33,256,168,13444,649]

theorem envBound28781 : H12AffineFastState.Bounded env28781 := by
  intro p hp
  have h : env28781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28780_28781 : H12AffineEnvironment.transform 13 5512 env28780 = env28781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28780 == env28781) = true)

theorem identity28781 : scanCanonicalize (H12AffineFastState.compose env28781 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28781 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env28782 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5456,0,8282,13389,10281,1024,1,4161,8573,64,8462,8272,65,10588,5440,4097,2420,1284,33,256,112,13404,593]

theorem envBound28782 : H12AffineFastState.Bounded env28782 := by
  intro p hp
  have h : env28782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28781_28782 : H12AffineEnvironment.transform 6 88 env28781 = env28782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28781 == env28782) = true)

theorem identity28782 : scanCanonicalize (H12AffineFastState.compose env28782 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28782 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28783 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,0,343,5440,2340,1024,1,4161,112,64,3,349,65,2129,5440,4097,2420,1284,33,256,112,5457,593]

theorem envBound28783 : H12AffineFastState.Bounded env28783 := by
  intro p hp
  have h : env28783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28782_28783 : H12AffineEnvironment.transform 12 269 env28782 = env28783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28782 == env28783) = true)

theorem identity28783 : scanCanonicalize (H12AffineFastState.compose env28783 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound28783 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28784 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2049,269,3409,0,343,3393,2340,1024,1,2112,112,64,3,349,65,2129,3393,2048,2420,1284,33,256,112,3408,593]

theorem envBound28784 : H12AffineFastState.Bounded env28784 := by
  intro p hp
  have h : env28784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28783_28784 : H12AffineEnvironment.transform 11 2049 env28783 = env28784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env28783 == env28784) = true)

theorem identity28784 : scanCanonicalize (H12AffineFastState.compose env28784 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28784 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28785 : List Nat := [2,4,8,16,32,32,56,256,512,1024,2048,2049,269,3377,0,311,3361,2340,1024,1,2080,16,32,3,317,33,2097,3361,2048,2324,1284,33,256,16,3376,561]

theorem envBound28785 : H12AffineFastState.Bounded env28785 := by
  intro p hp
  have h : env28785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28784_28785 : H12AffineEnvironment.transform 5 32 env28784 = env28785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28784 == env28785) = true)

theorem identity28785 : scanCanonicalize (H12AffineFastState.compose env28785 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound28785 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env28786 : List Nat := [2,4,8,16,32,32,56,256,512,266,2048,2049,269,2107,0,311,2091,2340,266,1,2080,16,32,3,317,33,2097,2091,2048,2324,14,33,256,16,2106,561]

theorem envBound28786 : H12AffineFastState.Bounded env28786 := by
  intro p hp
  have h : env28786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28785_28786 : H12AffineEnvironment.transform 9 266 env28785 = env28786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env28785 == env28786) = true)

theorem identity28786 : scanCanonicalize (H12AffineFastState.compose env28786 (packedSelected [6,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28786 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env28787 : List Nat := [2,4,8,16,17,17,9,256,512,266,2048,2049,269,2058,0,262,2074,2325,266,1,2065,16,17,3,268,16,2048,2074,2048,2324,14,16,256,16,2059,512]

theorem envBound28787 : H12AffineFastState.Bounded env28787 := by
  intro p hp
  have h : env28787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28786_28787 : H12AffineEnvironment.transform 4 17 env28786 = env28787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28786 == env28787) = true)

theorem identity28787 : scanCanonicalize (H12AffineFastState.compose env28787 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound28787 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28788 : List Nat := [2,4,8,16,17,17,9,256,512,266,270,271,269,260,0,262,276,27,266,1,287,16,17,3,268,16,270,276,270,26,14,16,256,16,261,512]

theorem envBound28788 : H12AffineFastState.Bounded env28788 := by
  intro p hp
  have h : env28788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28787_28788 : H12AffineEnvironment.transform 10 270 env28787 = env28788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env28787 == env28788) = true)

theorem identity28788 : scanCanonicalize (H12AffineFastState.compose env28788 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28788 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28789 : List Nat := [2,4,2,16,17,17,3,256,512,256,260,261,263,260,0,262,276,17,256,1,277,16,17,3,262,16,260,276,260,16,4,16,256,16,261,512]

theorem envBound28789 : H12AffineFastState.Bounded env28789 := by
  intro p hp
  have h : env28789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28788_28789 : H12AffineEnvironment.transform 2 2 env28788 = env28789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28788 == env28789) = true)

theorem identity28789 : scanCanonicalize (H12AffineFastState.compose env28789 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound28789 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28790 : List Nat := [2,4,2,16,17,17,3,256,277,256,260,261,263,260,0,262,276,17,256,1,277,16,17,3,262,16,260,276,260,16,4,16,256,16,261,277]

theorem envBound28790 : H12AffineFastState.Bounded env28790 := by
  intro p hp
  have h : env28790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28789_28790 : H12AffineEnvironment.transform 8 277 env28789 = env28790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env28789 == env28790) = true)

theorem identity28790 : scanCanonicalize (H12AffineFastState.compose env28790 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound28790 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28791 : List Nat := [2,4,2,16,17,17,3,3,22,3,7,6,4,7,0,5,23,17,3,1,22,16,17,3,5,16,7,23,7,16,4,16,3,16,6,22]

theorem envBound28791 : H12AffineFastState.Bounded env28791 := by
  intro p hp
  have h : env28791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28790_28791 : H12AffineEnvironment.transform 7 3 env28790 = env28791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env28790 == env28791) = true)

theorem identity28791 : scanCanonicalize (H12AffineFastState.compose env28791 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28791 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28792 : List Nat := [2,4,2,1,0,0,3,3,7,3,7,6,4,7,0,5,6,0,3,1,7,1,0,3,5,1,7,6,7,1,4,1,3,1,6,7]

theorem envBound28792 : H12AffineFastState.Bounded env28792 := by
  intro p hp
  have h : env28792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28791_28792 : H12AffineEnvironment.transform 3 1 env28791 = env28792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28791 == env28792) = true)

theorem identity28792 : scanCanonicalize (H12AffineFastState.compose env28792 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28793 : List Nat := [1,4,1,1,0,0,0,0,4,0,4,5,4,4,0,5,5,0,0,1,4,1,0,0,5,1,4,5,4,1,4,1,0,1,5,4]

theorem envBound28793 : H12AffineFastState.Bounded env28793 := by
  intro p hp
  have h : env28793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28792_28793 : H12AffineEnvironment.transform 0 1 env28792 = env28793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28792 == env28793) = true)

theorem identity28793 : scanCanonicalize (H12AffineFastState.compose env28793 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28793 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28794 : List Nat := [1,1,1,1,0,0,0,0,1,0,1,0,1,1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,1,1,1,1,0,1,0,1]

theorem envBound28794 : H12AffineFastState.Bounded env28794 := by
  intro p hp
  have h : env28794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28793_28794 : H12AffineEnvironment.transform 1 1 env28793 = env28794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28793 == env28794) = true)

def env28795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493629,498992,8328,65,2396469,2496957,416237,2149565,2102685,2373704,256,21792,46212,2175562]

theorem envBound28795 : H12AffineFastState.Bounded env28795 := by
  intro p hp
  have h : env28795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28735_28795 : H12AffineEnvironment.transform 21 180409 env28735 = env28795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env28735 == env28795) = true)

def env28796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400637,498992,8328,65,295285,395773,416237,56573,1501,272392,256,21792,46212,74250]

theorem envBound28796 : H12AffineFastState.Bounded env28796 := by
  intro p hp
  have h : env28796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28795_28796 : H12AffineEnvironment.transform 20 4160 env28795 = env28796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28795 == env28796) = true)

theorem identity28796 : scanCanonicalize (H12AffineFastState.compose env28796 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound28796 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180409,120015,21762,8328,65,215367,115151,102879,56573,1501,254010,256,21792,46212,74250]

theorem envBound28797 : H12AffineFastState.Bounded env28797 := by
  intro p hp
  have h : env28797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28796_28797 : H12AffineEnvironment.transform 17 247858 env28796 = env28797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env28796 == env28797) = true)

def env28798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4160,62709,120015,21762,8328,65,97547,115151,102879,56573,1501,119926,256,21792,46212,74250]

theorem envBound28798 : H12AffineFastState.Bounded env28798 := by
  intro p hp
  have h : env28798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28797_28798 : H12AffineEnvironment.transform 16 13388 env28797 = env28798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env28797 == env28798) = true)

theorem identity28798 : scanCanonicalize (H12AffineFastState.compose env28798 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28798 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env28799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13388,56436,1024,32769,4160,62709,62661,21762,8328,65,23809,57797,45525,56573,1501,62588,256,21792,46212,512]

theorem envBound28799 : H12AffineFastState.Bounded env28799 := by
  intro p hp
  have h : env28799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28798_28799 : H12AffineEnvironment.transform 15 8202 env28798 = env28799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28798 == env28799) = true)

theorem identity28799 : scanCanonicalize (H12AffineFastState.compose env28799 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound28799 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28800 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,8202,13388,56436,1024,32769,4160,62709,62661,21759,8328,65,23804,57400,45096,56573,1056,62588,253,21725,46212,512]

theorem envBound28800 : H12AffineFastState.Bounded env28800 := by
  intro p hp
  have h : env28800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28799_28800 : H12AffineEnvironment.transform 7 253 env28799 = env28800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env28799 == env28800) = true)

theorem identity28800 : scanCanonicalize (H12AffineFastState.compose env28800 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28800 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env28801 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8202,13388,56436,1024,32769,4160,62589,62541,21623,8192,65,23668,57400,45096,56437,1056,62588,117,21589,46092,512]

theorem envBound28801 : H12AffineFastState.Bounded env28801 := by
  intro p hp
  have h : env28801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28800_28801 : H12AffineEnvironment.transform 6 8 env28800 = env28801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28800 == env28801) = true)

theorem identity28801 : scanCanonicalize (H12AffineFastState.compose env28801 (packedSelected [4,6,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound28801 : packedSelected [4,6,9,16] rootPS < 2^1333 := by decide +kernel

def env28802 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,12312,32768,8202,13388,44140,1024,32769,4160,33893,33877,9327,8192,65,11372,36896,45096,44141,1056,33892,117,9293,46092,512]

theorem envBound28802 : H12AffineFastState.Bounded env28802 := by
  intro p hp
  have h : env28802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28801_28802 : H12AffineEnvironment.transform 13 12312 env28801 = env28802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env28801 == env28802) = true)

def env28803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4160,62708,120015,21762,8328,65,97546,115151,102879,56573,1501,119927,256,21792,46212,74250]

theorem envBound28803 : H12AffineFastState.Bounded env28803 := by
  intro p hp
  have h : env28803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28797_28803 : H12AffineEnvironment.transform 16 13389 env28797 = env28803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env28797 == env28803) = true)

def env28804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400636,498992,8328,65,295284,395772,416237,56572,1500,272393,256,21792,46212,74251]

theorem envBound28804 : H12AffineFastState.Bounded env28804 := by
  intro p hp
  have h : env28804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28795_28804 : H12AffineEnvironment.transform 20 4161 env28795 = env28804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28795 == env28804) = true)

theorem identity28804 : scanCanonicalize (H12AffineFastState.compose env28804 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28804 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,180409,400636,441658,8328,65,295284,395772,416237,56572,1500,272393,256,21792,46212,513]

theorem envBound28805 : H12AffineFastState.Bounded env28805 := by
  intro p hp
  have h : env28805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28804_28805 : H12AffineEnvironment.transform 15 8202 env28804 = env28805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28804 == env28805) = true)

def env28806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4161,32937,285932,326954,8328,65,295284,281068,268797,56572,1500,272393,256,21792,46212,513]

theorem envBound28806 : H12AffineFastState.Bounded env28806 := by
  intro p hp
  have h : env28806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28805_28806 : H12AffineEnvironment.transform 16 16400 env28805 = env28806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28805 == env28806) = true)

theorem identity28806 : scanCanonicalize (H12AffineFastState.compose env28806 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23804) := by decide +kernel

theorem selectedBound28806 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,23804,1024,32769,4161,32937,16,41430,8328,65,56712,5392,17665,56572,1500,29941,256,21792,46212,513]

theorem envBound28807 : H12AffineFastState.Bounded env28807 := by
  intro p hp
  have h : env28807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28806_28807 : H12AffineEnvironment.transform 17 23804 env28806 = env28807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23804 env28806 == env28807) = true)

theorem identity28807 : scanCanonicalize (H12AffineFastState.compose env28807 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28807 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16400,23804,1024,0,4161,168,16,8663,8328,65,23945,5392,17665,23805,1500,29941,256,21792,13445,513]

theorem envBound28808 : H12AffineFastState.Bounded env28808 := by
  intro p hp
  have h : env28808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28807_28808 : H12AffineEnvironment.transform 14 1 env28807 = env28808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28807 == env28808) = true)

theorem identity28808 : scanCanonicalize (H12AffineFastState.compose env28808 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28808 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env28809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,1,8202,13389,10401,1024,0,4161,168,16,8663,8328,65,10708,5392,12636,10400,1500,168,256,8573,13445,513]

theorem envBound28809 : H12AffineFastState.Bounded env28809 := by
  intro p hp
  have h : env28809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28808_28809 : H12AffineEnvironment.transform 13 13405 env28808 = env28809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28808 == env28809) = true)

theorem identity28809 : scanCanonicalize (H12AffineFastState.compose env28809 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28809 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env28810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,1,343,5392,2556,1024,0,4161,168,16,138,469,65,2185,5392,4097,2557,1500,168,256,32,5592,513]

theorem envBound28810 : H12AffineFastState.Bounded env28810 := by
  intro p hp
  have h : env28810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28809_28810 : H12AffineEnvironment.transform 12 349 env28809 = env28810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28809 == env28810) = true)

theorem identity28810 : scanCanonicalize (H12AffineFastState.compose env28810 (packedSelected [0,1,4,5,7,9,10,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3522) := by decide +kernel

theorem selectedBound28810 : packedSelected [0,1,4,5,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3522,349,2242,1,343,2258,2556,1024,0,3459,168,16,138,469,65,2185,2258,3523,2557,1500,168,256,32,2074,513]

theorem envBound28811 : H12AffineFastState.Bounded env28811 := by
  intro p hp
  have h : env28811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28810_28811 : H12AffineEnvironment.transform 11 3522 env28810 = env28811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3522 env28810 == env28811) = true)

theorem identity28811 : scanCanonicalize (H12AffineFastState.compose env28811 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28811 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3402,349,2122,1,343,2138,2420,1024,0,3339,32,16,2,349,65,2049,2138,3403,2421,1364,32,256,32,2074,513]

theorem envBound28812 : H12AffineFastState.Bounded env28812 := by
  intro p hp
  have h : env28812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28811_28812 : H12AffineEnvironment.transform 6 8 env28811 = env28812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28811 == env28812) = true)

theorem identity28812 : scanCanonicalize (H12AffineFastState.compose env28812 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound28812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,1296,349,16,1,343,0,302,1024,0,1361,32,16,2,349,65,91,0,1297,303,1364,32,256,32,64,513]

theorem envBound28813 : H12AffineFastState.Bounded env28813 := by
  intro p hp
  have h : env28813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28812_28813 : H12AffineEnvironment.transform 10 90 env28812 = env28813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env28812 == env28813) = true)

theorem identity28813 : scanCanonicalize (H12AffineFastState.compose env28813 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28813 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28814 : List Nat := [2,4,8,16,32,64,8,117,512,1024,90,1125,40,16,1,34,0,91,1024,0,1060,32,16,2,40,65,91,0,1124,90,1057,32,117,32,64,513]

theorem envBound28814 : H12AffineFastState.Bounded env28814 := by
  intro p hp
  have h : env28814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28813_28814 : H12AffineEnvironment.transform 7 117 env28813 = env28814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28813 == env28814) = true)

theorem identity28814 : scanCanonicalize (H12AffineFastState.compose env28814 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound28814 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28815 : List Nat := [2,4,8,16,32,64,8,117,512,110,90,11,40,16,1,34,0,91,110,0,74,32,16,2,40,65,91,0,10,90,79,32,117,32,64,513]

theorem envBound28815 : H12AffineFastState.Bounded env28815 := by
  intro p hp
  have h : env28815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28814_28815 : H12AffineEnvironment.transform 9 110 env28814 = env28815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env28814 == env28815) = true)

theorem identity28815 : scanCanonicalize (H12AffineFastState.compose env28815 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28815 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28816 : List Nat := [2,4,8,16,1,64,8,84,512,79,90,11,9,16,1,3,0,91,79,0,74,1,16,2,9,65,91,0,10,90,79,1,84,1,64,513]

theorem envBound28816 : H12AffineFastState.Bounded env28816 := by
  intro p hp
  have h : env28816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28815_28816 : H12AffineEnvironment.transform 4 1 env28815 = env28816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28815 == env28816) = true)

def env28817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32936,285933,326955,8328,65,295284,281069,268796,56572,1500,272393,256,21792,46212,513]

theorem envBound28817 : H12AffineFastState.Bounded env28817 := by
  intro p hp
  have h : env28817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28805_28817 : H12AffineEnvironment.transform 16 16401 env28805 = env28817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28805 == env28817) = true)

def env28818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32800,285797,326955,8192,65,295284,280933,268660,56436,1364,272393,256,21792,46092,513]

theorem envBound28818 : H12AffineFastState.Bounded env28818 := by
  intro p hp
  have h : env28818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28817_28818 : H12AffineEnvironment.transform 6 8 env28817 = env28818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28817 == env28818) = true)

def env28819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32801,285796,326955,8193,65,295284,280932,268661,56437,1365,272393,256,21792,46093,513]

theorem envBound28819 : H12AffineFastState.Bounded env28819 := by
  intro p hp
  have h : env28819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28817_28819 : H12AffineEnvironment.transform 6 9 env28817 = env28819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28817 == env28819) = true)

theorem identity28819 : scanCanonicalize (H12AffineFastState.compose env28819 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound28819 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env28820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,3172,1024,32769,4161,32801,20480,61775,8193,65,36112,17664,5393,56437,1365,9325,256,21792,46093,513]

theorem envBound28820 : H12AffineFastState.Bounded env28820 := by
  intro p hp
  have h : env28820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28819_28820 : H12AffineEnvironment.transform 17 3172 env28819 = env28820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env28819 == env28820) = true)

theorem identity28820 : scanCanonicalize (H12AffineFastState.compose env28820 (packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound28820 : packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env28821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,32768,1094,16401,3172,1024,32769,4161,32801,20480,54531,1101,65,36112,17664,5393,56437,1365,33,256,21792,36929,513]

theorem envBound28821 : H12AffineFastState.Bounded env28821 := by
  intro p hp
  have h : env28821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28820_28821 : H12AffineEnvironment.transform 12 1100 env28820 = env28821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env28820 == env28821) = true)

theorem identity28821 : scanCanonicalize (H12AffineFastState.compose env28821 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 7205) := by decide +kernel

theorem selectedBound28821 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,7205,1094,16401,3172,1024,7204,4161,7172,20480,18726,1101,65,4405,17664,5393,16464,1365,33,256,21792,3172,513]

theorem envBound28822 : H12AffineFastState.Bounded env28822 := by
  intro p hp
  have h : env28822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28821_28822 : H12AffineEnvironment.transform 14 7205 env28821 = env28822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7205 env28821 == env28822) = true)

theorem identity28822 : scanCanonicalize (H12AffineFastState.compose env28822 (packedSelected [17] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound28822 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,16384,1297,1094,16401,3172,1024,1296,2421,1328,18740,18726,1101,65,2049,17664,3109,16464,1365,33,256,19476,3172,513]

theorem envBound28823 : H12AffineFastState.Bounded env28823 := by
  intro p hp
  have h : env28823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28822_28823 : H12AffineEnvironment.transform 11 2356 env28822 = env28823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env28822 == env28823) = true)

theorem identity28823 : scanCanonicalize (H12AffineFastState.compose env28823 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound28823 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,2048,1297,1094,2065,3172,1024,1296,2421,1328,308,294,1101,65,2049,3328,3109,2128,1365,33,256,1044,3172,513]

theorem envBound28824 : H12AffineFastState.Bounded env28824 := by
  intro p hp
  have h : env28824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28823_28824 : H12AffineEnvironment.transform 13 2048 env28823 = env28824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env28823 == env28824) = true)

theorem identity28824 : scanCanonicalize (H12AffineFastState.compose env28824 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28824 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env28825 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,1100,2048,1125,1094,2065,3172,1024,1124,2049,1092,64,82,1101,65,2049,3188,3109,2128,1057,33,116,1044,3172,513]

theorem envBound28825 : H12AffineFastState.Bounded env28825 := by
  intro p hp
  have h : env28825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28824_28825 : H12AffineEnvironment.transform 7 116 env28824 = env28825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28824 == env28825) = true)

theorem identity28825 : scanCanonicalize (H12AffineFastState.compose env28825 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28825 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28826 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2064,1052,2048,1077,1046,2065,3124,1024,1076,2049,1044,16,2,1053,17,2049,3108,3109,2048,1057,33,36,1044,3124,513]

theorem envBound28826 : H12AffineFastState.Bounded env28826 := by
  intro p hp
  have h : env28826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28825_28826 : H12AffineEnvironment.transform 5 16 env28825 = env28826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28825 == env28826) = true)

theorem identity28826 : scanCanonicalize (H12AffineFastState.compose env28826 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound28826 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28827 : List Nat := [2,4,8,16,32,16,9,36,512,1024,27,11,1052,27,1077,1046,10,1071,1024,1076,26,1044,16,2,1053,17,26,1087,1086,27,1057,33,36,1044,1071,513]

theorem envBound28827 : H12AffineFastState.Bounded env28827 := by
  intro p hp
  have h : env28827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28826_28827 : H12AffineEnvironment.transform 10 27 env28826 = env28827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env28826 == env28827) = true)

theorem identity28827 : scanCanonicalize (H12AffineFastState.compose env28827 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28827 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env28828 : List Nat := [2,4,8,10,32,10,9,36,512,1024,1,11,1030,1,1071,1036,10,1071,1024,1070,0,1038,10,2,1031,11,0,1061,1060,1,1057,33,36,1038,1071,513]

theorem envBound28828 : H12AffineFastState.Bounded env28828 := by
  intro p hp
  have h : env28828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28827_28828 : H12AffineEnvironment.transform 3 10 env28827 = env28828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28827 == env28828) = true)

theorem identity28828 : scanCanonicalize (H12AffineFastState.compose env28828 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound28828 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28829 : List Nat := [2,4,8,10,32,10,9,36,512,46,1,11,40,1,1,34,10,1,46,0,0,32,10,2,41,11,0,11,10,1,15,33,36,32,1,513]

theorem envBound28829 : H12AffineFastState.Bounded env28829 := by
  intro p hp
  have h : env28829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28828_28829 : H12AffineEnvironment.transform 9 46 env28828 = env28829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env28828 == env28829) = true)

def env28830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,498993,8328,65,6705549,2496956,416237,2149565,2102684,6748400,256,21793,46213,2175563]

theorem envBound28830 : H12AffineFastState.Bounded env28830 := by
  intro p hp
  have h : env28830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28734_28830 : H12AffineEnvironment.transform 23 498993 env28734 = env28830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env28734 == env28830) = true)

def env28831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493629,498993,8328,65,2396469,2496956,416237,2149565,2102684,2373704,256,21793,46213,2175563]

theorem envBound28831 : H12AffineFastState.Bounded env28831 := by
  intro p hp
  have h : env28831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28830_28831 : H12AffineEnvironment.transform 21 180408 env28830 = env28831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env28830 == env28831) = true)

def env28832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400637,498993,8328,65,295285,395772,416237,56573,1500,272392,256,21793,46213,74251]

theorem envBound28832 : H12AffineFastState.Bounded env28832 := by
  intro p hp
  have h : env28832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28831_28832 : H12AffineEnvironment.transform 20 4160 env28831 = env28832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28831 == env28832) = true)

theorem identity28832 : scanCanonicalize (H12AffineFastState.compose env28832 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound28832 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,4160,180408,16,98780,8328,65,171416,5393,17664,56573,1500,144613,256,21793,46213,74251]

theorem envBound28833 : H12AffineFastState.Bounded env28833 := by
  intro p hp
  have h : env28833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28832_28833 : H12AffineEnvironment.transform 17 138477 env28832 = env28833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env28832 == env28833) = true)

def env28834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180272,16,98644,8192,65,171280,5393,17664,56437,1364,144493,256,21793,46093,74251]

theorem envBound28834 : H12AffineFastState.Bounded env28834 := by
  intro p hp
  have h : env28834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28833_28834 : H12AffineEnvironment.transform 6 8 env28833 = env28834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28833 == env28834) = true)

theorem identity28834 : scanCanonicalize (H12AffineFastState.compose env28834 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound28834 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,67619,1024,32769,4160,119926,16,98644,8192,65,100694,5393,17664,56437,1364,73771,256,21793,46093,74251]

theorem envBound28835 : H12AffineFastState.Bounded env28835 := by
  intro p hp
  have h : env28835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28834_28835 : H12AffineEnvironment.transform 16 70726 env28834 = env28835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env28834 == env28835) = true)

theorem identity28835 : scanCanonicalize (H12AffineFastState.compose env28835 (packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28835 : packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env28836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,67619,1024,32769,4160,106539,16,98644,8192,65,100694,5393,12637,43048,1364,73771,256,8572,46093,74251]

theorem envBound28836 : H12AffineFastState.Bounded env28836 := by
  intro p hp
  have h : env28836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28835_28836 : H12AffineEnvironment.transform 13 13405 env28835 = env28836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28835 == env28836) = true)

theorem identity28836 : scanCanonicalize (H12AffineFastState.compose env28836 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28836 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env28837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,65536,70726,67619,1024,32769,4160,98679,16,98644,348,65,100694,5393,4097,35188,1364,65911,256,32,38225,66391]

theorem envBound28837 : H12AffineFastState.Bounded env28837 := by
  intro p hp
  have h : env28837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28836_28837 : H12AffineEnvironment.transform 12 348 env28836 = env28837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28836 == env28837) = true)

theorem identity28837 : scanCanonicalize (H12AffineFastState.compose env28837 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28837 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env28838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,70726,67619,1024,1,4160,65911,16,65876,348,65,67926,5393,4097,2420,1364,65911,256,32,5457,66391]

theorem envBound28838 : H12AffineFastState.Bounded env28838 := by
  intro p hp
  have h : env28838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28837_28838 : H12AffineEnvironment.transform 14 0 env28837 = env28838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28837 == env28838) = true)

theorem identity28838 : scanCanonicalize (H12AffineFastState.compose env28838 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28838 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28839 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5377,0,65536,70726,67586,1024,1,4160,65878,16,65876,348,65,67926,5393,4097,2389,1364,65878,256,1,5457,66391]

theorem envBound28839 : H12AffineFastState.Bounded env28839 := by
  intro p hp
  have h : env28839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28838_28839 : H12AffineEnvironment.transform 4 1 env28838 = env28839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28838 == env28839) = true)

theorem identity28839 : scanCanonicalize (H12AffineFastState.compose env28839 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound28839 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28840 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1093,4096,348,5377,0,65536,70726,66631,1024,1,4160,65878,16,65876,348,65,66835,5393,4097,1296,1364,65878,256,1,5457,66391]

theorem envBound28840 : H12AffineFastState.Bounded env28840 := by
  intro p hp
  have h : env28840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28839_28840 : H12AffineEnvironment.transform 10 1093 env28839 = env28840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env28839 == env28840) = true)

def env28841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180273,16,98645,8193,65,171281,5393,17664,56436,1365,144492,256,21793,46092,74251]

theorem envBound28841 : H12AffineFastState.Bounded env28841 := by
  intro p hp
  have h : env28841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28833_28841 : H12AffineEnvironment.transform 6 9 env28833 = env28841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28833 == env28841) = true)

theorem identity28841 : scanCanonicalize (H12AffineFastState.compose env28841 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound28841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,108927,1024,32769,4160,95530,16,98645,8193,65,75786,5393,17664,56436,1365,98679,256,21793,46092,74251]

theorem envBound28842 : H12AffineFastState.Bounded env28842 := by
  intro p hp
  have h : env28842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28841_28842 : H12AffineEnvironment.transform 16 111899 env28841 = env28842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env28841 == env28842) = true)

theorem identity28842 : scanCanonicalize (H12AffineFastState.compose env28842 (packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound28842 : packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env28843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49216,56356,1024,32769,4160,113,16,62478,8193,65,23889,5393,17664,56436,1365,62508,256,21793,46092,22352]

theorem envBound28843 : H12AffineFastState.Bounded env28843 := by
  intro p hp
  have h : env28843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28842_28843 : H12AffineEnvironment.transform 15 30043 env28842 = env28843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env28842 == env28843) = true)

theorem identity28843 : scanCanonicalize (H12AffineFastState.compose env28843 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28843 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env28844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,21590,49216,56356,1024,32769,4160,113,16,54531,268,65,23889,5393,17664,56436,1365,54561,256,21793,38145,22352]

theorem envBound28844 : H12AffineFastState.Bounded env28844 := by
  intro p hp
  have h : env28844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28843_28844 : H12AffineEnvironment.transform 12 269 env28843 = env28844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28843 == env28844) = true)

theorem identity28844 : scanCanonicalize (H12AffineFastState.compose env28844 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound28844 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env28845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21541,21590,5221,2049,1024,21540,4160,113,16,294,268,65,23889,5393,17664,2129,1365,260,256,21793,16676,22352]

theorem envBound28845 : H12AffineFastState.Bounded env28845 := by
  intro p hp
  have h : env28845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28844_28845 : H12AffineEnvironment.transform 14 21541 env28844 = env28845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env28844 == env28845) = true)

theorem identity28845 : scanCanonicalize (H12AffineFastState.compose env28845 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28845 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env28846 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,21541,21590,5221,2049,1024,21540,4160,113,16,3,41,65,23668,5172,17445,2129,1136,33,37,21508,16385,22133]

theorem envBound28846 : H12AffineFastState.Bounded env28846 := by
  intro p hp
  have h : env28846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28845_28846 : H12AffineEnvironment.transform 7 37 env28845 = env28846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28845 == env28846) = true)

theorem identity28846 : scanCanonicalize (H12AffineFastState.compose env28846 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound28846 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env28847 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,1,114,5221,2049,1024,0,4160,113,16,3,41,65,2128,5172,4097,2129,1136,33,37,32,5157,593]

theorem envBound28847 : H12AffineFastState.Bounded env28847 := by
  intro p hp
  have h : env28847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28846_28847 : H12AffineEnvironment.transform 13 5156 env28846 = env28847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env28846 == env28847) = true)

theorem identity28847 : scanCanonicalize (H12AffineFastState.compose env28847 (packedSelected [0,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28847 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env28848 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,1,35,5172,2049,1024,0,4113,32,16,3,41,16,2049,5172,4097,2048,1057,33,37,32,5157,512]

theorem envBound28848 : H12AffineFastState.Bounded env28848 := by
  intro p hp
  have h : env28848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28847_28848 : H12AffineEnvironment.transform 5 17 env28847 = env28848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28847 == env28848) = true)

theorem identity28848 : scanCanonicalize (H12AffineFastState.compose env28848 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28848 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28849 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5124,1,3,5140,2049,1024,0,4113,0,16,3,9,16,2049,5140,4097,2048,1025,1,5,0,5125,512]

theorem envBound28849 : H12AffineFastState.Bounded env28849 := by
  intro p hp
  have h : env28849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28848_28849 : H12AffineEnvironment.transform 4 0 env28848 = env28849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28848 == env28849) = true)

theorem identity28849 : scanCanonicalize (H12AffineFastState.compose env28849 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound28849 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28850 : List Nat := [2,4,8,16,0,17,9,5,512,1024,522,4096,8,5124,1,3,5140,523,1024,0,4113,0,16,3,9,16,523,5140,4097,522,1025,1,5,0,5125,512]

theorem envBound28850 : H12AffineFastState.Bounded env28850 := by
  intro p hp
  have h : env28850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28849_28850 : H12AffineEnvironment.transform 10 522 env28849 = env28850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env28849 == env28850) = true)

def env28851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400636,498993,8328,65,295284,395773,416237,56572,1501,272393,256,21793,46213,74250]

theorem envBound28851 : H12AffineFastState.Bounded env28851 := by
  intro p hp
  have h : env28851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28831_28851 : H12AffineEnvironment.transform 20 4161 env28831 = env28851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28831 == env28851) = true)

theorem identity28851 : scanCanonicalize (H12AffineFastState.compose env28851 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound28851 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,144493,400636,485860,8328,65,292257,395773,416237,10281,1501,272393,256,21793,16464,74250]

theorem envBound28852 : H12AffineFastState.Bounded env28852 := by
  intro p hp
  have h : env28852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28851_28852 : H12AffineEnvironment.transform 14 29909 env28851 = env28852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env28851 == env28852) = true)

def env28853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,400500,485740,8192,65,292137,395637,416101,10281,1365,272393,256,21793,16464,74250]

theorem envBound28853 : H12AffineFastState.Bounded env28853 := by
  intro p hp
  have h : env28853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28852_28853 : H12AffineEnvironment.transform 6 8 env28852 = env28853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28852 == env28853) = true)

theorem identity28853 : scanCanonicalize (H12AffineFastState.compose env28853 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound28853 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5440,262144,1024,29788,4161,8493,264500,359468,8192,65,292137,269365,281637,10281,1365,272393,256,21793,16464,74250]

theorem envBound28854 : H12AffineFastState.Bounded env28854 := by
  intro p hp
  have h : env28854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28853_28854 : H12AffineEnvironment.transform 16 5440 env28853 = env28854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env28853 == env28854) = true)

theorem identity28854 : scanCanonicalize (H12AffineFastState.compose env28854 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound28854 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,5440,262144,1024,29788,4161,8493,264500,272506,8192,65,292137,269365,281637,10281,1365,272393,256,21793,16464,30300]

theorem envBound28855 : H12AffineFastState.Bounded env28855 := by
  intro p hp
  have h : env28855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28854_28855 : H12AffineEnvironment.transform 15 21590 env28854 = env28855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env28854 == env28855) = true)

theorem identity28855 : scanCanonicalize (H12AffineFastState.compose env28855 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound28855 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env28856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,5440,10360,1024,29788,4161,8493,8524,2,8192,65,23889,13389,25693,10281,1365,113,256,21793,16464,30300]

theorem envBound28856 : H12AffineFastState.Bounded env28856 := by
  intro p hp
  have h : env28856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28855_28856 : H12AffineEnvironment.transform 17 10360 env28855 = env28856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env28855 == env28856) = true)

theorem identity28856 : scanCanonicalize (H12AffineFastState.compose env28856 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound28856 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8283,5440,10360,1024,81,4161,8493,8524,2,8192,65,10588,13389,4176,10281,1365,113,256,8492,13405,593]

theorem envBound28857 : H12AffineFastState.Bounded env28857 := by
  intro p hp
  have h : env28857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28856_28857 : H12AffineEnvironment.transform 13 13325 env28856 = env28857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env28856 == env28857) = true)

theorem identity28857 : scanCanonicalize (H12AffineFastState.compose env28857 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound28857 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,3345,80,6471,5440,4452,1024,81,4161,6193,6224,2,6428,65,4160,3409,4176,4405,1365,113,256,6192,3393,593]

theorem envBound28858 : H12AffineFastState.Bounded env28858 := by
  intro p hp
  have h : env28858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28857_28858 : H12AffineEnvironment.transform 12 6428 env28857 = env28858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env28857 == env28858) = true)

theorem identity28858 : scanCanonicalize (H12AffineFastState.compose env28858 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound28858 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,5133,0,80,5206,5440,4452,1024,81,4161,5408,5441,2,5133,65,4160,64,4176,4405,1365,113,256,5409,80,593]

theorem envBound28859 : H12AffineFastState.Bounded env28859 := by
  intro p hp
  have h : env28859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28858_28859 : H12AffineEnvironment.transform 10 1297 env28858 = env28859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env28858 == env28859) = true)

theorem identity28859 : scanCanonicalize (H12AffineFastState.compose env28859 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28859 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env28860 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,4096,4381,0,80,4422,4176,4452,272,81,4161,4144,4177,2,4381,65,4160,64,4176,4405,69,113,256,4145,80,593]

theorem envBound28860 : H12AffineFastState.Bounded env28860 := by
  intro p hp
  have h : env28860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28859_28860 : H12AffineEnvironment.transform 9 272 env28859 = env28860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28859 == env28860) = true)

theorem identity28860 : scanCanonicalize (H12AffineFastState.compose env28860 (packedSelected [12,17] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound28860 : packedSelected [12,17] rootPS < 2^1333 := by decide +kernel

def env28861 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,64,349,0,80,262,16,292,272,81,1,112,17,2,349,65,0,64,16,373,69,113,256,113,80,593]

theorem envBound28861 : H12AffineFastState.Bounded env28861 := by
  intro p hp
  have h : env28861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28860_28861 : H12AffineEnvironment.transform 11 64 env28860 = env28861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env28860 == env28861) = true)

theorem identity28861 : scanCanonicalize (H12AffineFastState.compose env28861 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28861 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28862 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,17,268,0,1,262,16,292,272,0,1,33,17,2,268,16,0,17,16,292,20,32,256,32,1,512]

theorem envBound28862 : H12AffineFastState.Bounded env28862 := by
  intro p hp
  have h : env28862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28861_28862 : H12AffineEnvironment.transform 5 17 env28861 = env28862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28861 == env28862) = true)

theorem identity28862 : scanCanonicalize (H12AffineFastState.compose env28862 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound28862 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28863 : List Nat := [2,4,8,16,32,17,8,53,512,37,1,17,57,0,1,51,16,17,37,0,1,33,17,2,57,16,0,17,16,17,20,32,53,32,1,512]

theorem envBound28863 : H12AffineFastState.Bounded env28863 := by
  intro p hp
  have h : env28863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28862_28863 : H12AffineEnvironment.transform 7 53 env28862 = env28863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env28862 == env28863) = true)

theorem identity28863 : scanCanonicalize (H12AffineFastState.compose env28863 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound28863 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28864 : List Nat := [2,4,8,16,32,17,8,53,4,37,1,17,57,0,1,51,16,17,37,0,1,33,17,2,57,16,0,17,16,17,20,32,53,32,1,4]

theorem envBound28864 : H12AffineFastState.Bounded env28864 := by
  intro p hp
  have h : env28864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28863_28864 : H12AffineEnvironment.transform 8 4 env28863 = env28864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env28863 == env28864) = true)

theorem identity28864 : scanCanonicalize (H12AffineFastState.compose env28864 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound28864 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28865 : List Nat := [2,4,8,16,5,17,8,16,4,0,1,17,28,0,1,22,16,17,0,0,1,4,17,2,28,16,0,17,16,17,20,5,16,5,1,4]

theorem envBound28865 : H12AffineFastState.Bounded env28865 := by
  intro p hp
  have h : env28865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28864_28865 : H12AffineEnvironment.transform 4 5 env28864 = env28865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env28864 == env28865) = true)

theorem identity28865 : scanCanonicalize (H12AffineFastState.compose env28865 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28865 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28866 : List Nat := [2,1,8,16,0,17,8,16,1,0,1,17,25,0,1,19,16,17,0,0,1,1,17,2,25,16,0,17,16,17,17,0,16,0,1,1]

theorem envBound28866 : H12AffineFastState.Bounded env28866 := by
  intro p hp
  have h : env28866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28865_28866 : H12AffineEnvironment.transform 1 1 env28865 = env28866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28865 == env28866) = true)

theorem identity28866 : scanCanonicalize (H12AffineFastState.compose env28866 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28867 : List Nat := [2,1,8,0,0,1,8,0,1,0,1,1,9,0,1,3,0,1,0,0,1,1,1,2,9,0,0,1,0,1,1,0,0,0,1,1]

theorem envBound28867 : H12AffineFastState.Bounded env28867 := by
  intro p hp
  have h : env28867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28866_28867 : H12AffineEnvironment.transform 3 0 env28866 = env28867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28866 == env28867) = true)

def env28868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,400501,485741,8193,65,292136,395636,416100,10281,1364,272393,256,21793,16464,74250]

theorem envBound28868 : H12AffineFastState.Bounded env28868 := by
  intro p hp
  have h : env28868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28852_28868 : H12AffineEnvironment.transform 6 9 env28852 = env28868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28852 == env28868) = true)

theorem identity28868 : scanCanonicalize (H12AffineFastState.compose env28868 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound28868 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,79130,262144,1024,29789,4161,65911,338287,285815,8193,65,292136,343150,355454,10281,1364,272393,256,21793,16464,74250]

theorem envBound28869 : H12AffineFastState.Bounded env28869 := by
  intro p hp
  have h : env28869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28868_28869 : H12AffineEnvironment.transform 16 79130 env28868 = env28869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env28868 == env28869) = true)

theorem identity28869 : scanCanonicalize (H12AffineFastState.compose env28869 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28869 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env28870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,262144,1024,8540,4161,65911,338287,264566,8193,65,270377,343150,342399,10281,1364,272393,256,32,5457,74250]

theorem envBound28870 : H12AffineFastState.Bounded env28870 := by
  intro p hp
  have h : env28870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28869_28870 : H12AffineEnvironment.transform 13 5377 env28869 = env28870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28869 == env28870) = true)

theorem identity28870 : scanCanonicalize (H12AffineFastState.compose env28870 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound28870 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,2421,1024,8540,4161,65911,73754,3,8193,65,10588,79131,77834,10281,1364,8572,256,32,5457,74250]

theorem envBound28871 : H12AffineFastState.Bounded env28871 := by
  intro p hp
  have h : env28871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28870_28871 : H12AffineEnvironment.transform 17 2421 env28870 = env28871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env28870 == env28871) = true)

theorem identity28871 : scanCanonicalize (H12AffineFastState.compose env28871 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28871 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5393,2421,1024,8540,4161,8572,17,3,8193,65,10588,5392,4097,10281,1364,8572,256,32,5457,513]

theorem envBound28872 : H12AffineFastState.Bounded env28872 := by
  intro p hp
  have h : env28872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28871_28872 : H12AffineEnvironment.transform 15 8203 env28871 = env28872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28871 == env28872) = true)

theorem identity28872 : scanCanonicalize (H12AffineFastState.compose env28872 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5393,2421,1024,0,4161,32,17,3,349,65,2048,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound28873 : H12AffineFastState.Bounded env28873 := by
  intro p hp
  have h : env28873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28872_28873 : H12AffineEnvironment.transform 12 348 env28872 = env28873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28872 == env28873) = true)

theorem identity28873 : scanCanonicalize (H12AffineFastState.compose env28873 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28873 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28874 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,348,4452,1,343,4468,2421,101,0,4161,32,17,3,349,65,2048,4469,4097,2421,305,32,256,32,4404,513]

theorem envBound28874 : H12AffineFastState.Bounded env28874 := by
  intro p hp
  have h : env28874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28873_28874 : H12AffineEnvironment.transform 9 101 env28873 = env28874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28873 == env28874) = true)

theorem identity28874 : scanCanonicalize (H12AffineFastState.compose env28874 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28874 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28875 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,1,262,4389,2340,52,0,4112,32,17,3,268,16,2048,4388,4097,2340,305,32,256,32,4404,513]

theorem envBound28875 : H12AffineFastState.Bounded env28875 := by
  intro p hp
  have h : env28875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28874_28875 : H12AffineEnvironment.transform 5 17 env28874 = env28875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28874 == env28875) = true)

theorem identity28875 : scanCanonicalize (H12AffineFastState.compose env28875 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound28875 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28876 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,16,269,293,1,262,309,2340,52,0,0,32,17,3,268,16,2048,308,17,2340,305,32,256,32,292,513]

theorem envBound28876 : H12AffineFastState.Bounded env28876 := by
  intro p hp
  have h : env28876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28875_28876 : H12AffineEnvironment.transform 11 16 env28875 = env28876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28875 == env28876) = true)

theorem identity28876 : scanCanonicalize (H12AffineFastState.compose env28876 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound28876 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28877 : List Nat := [2,4,8,16,32,17,9,256,512,52,292,16,269,293,1,262,309,0,52,0,0,32,17,3,268,16,292,308,17,0,305,32,256,32,292,513]

theorem envBound28877 : H12AffineFastState.Bounded env28877 := by
  intro p hp
  have h : env28877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28876_28877 : H12AffineEnvironment.transform 10 292 env28876 = env28877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env28876 == env28877) = true)

theorem identity28877 : scanCanonicalize (H12AffineFastState.compose env28877 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28877 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28878 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,16,41,1,1,34,17,0,52,0,0,32,17,3,40,16,0,16,17,0,21,32,36,32,0,513]

theorem envBound28878 : H12AffineFastState.Bounded env28878 := by
  intro p hp
  have h : env28878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28877_28878 : H12AffineEnvironment.transform 7 36 env28877 = env28878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28877 == env28878) = true)

theorem identity28878 : scanCanonicalize (H12AffineFastState.compose env28878 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound28878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28879 : List Nat := [2,4,8,16,32,17,9,36,33,52,0,16,41,1,1,34,17,0,52,0,0,32,17,3,40,16,0,16,17,0,21,32,36,32,0,32]

theorem envBound28879 : H12AffineFastState.Bounded env28879 := by
  intro p hp
  have h : env28879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28878_28879 : H12AffineEnvironment.transform 8 33 env28878 = env28879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env28878 == env28879) = true)

def env28880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493629,498993,8328,65,2396468,2496956,416237,2149565,2102684,2373705,256,21793,46213,2175563]

theorem envBound28880 : H12AffineFastState.Bounded env28880 := by
  intro p hp
  have h : env28880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28830_28880 : H12AffineEnvironment.transform 21 180409 env28830 = env28880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env28830 == env28880) = true)

def env28881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400637,498993,8328,65,295284,395772,416237,56573,1500,272393,256,21793,46213,74251]

theorem envBound28881 : H12AffineFastState.Bounded env28881 := by
  intro p hp
  have h : env28881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28880_28881 : H12AffineEnvironment.transform 20 4160 env28880 = env28881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28880 == env28881) = true)

def env28882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180409,144597,242969,8328,65,43356,139732,160197,56573,1500,33,256,21793,46213,74251]

theorem envBound28882 : H12AffineFastState.Bounded env28882 := by
  intro p hp
  have h : env28882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28881_28882 : H12AffineEnvironment.transform 17 10280 env28881 = env28882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env28881 == env28882) = true)

def env28883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,21929,41413,73737,8328,65,43356,46276,58581,56573,1500,33,256,21793,46213,74251]

theorem envBound28883 : H12AffineFastState.Bounded env28883 := by
  intro p hp
  have h : env28883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28882_28883 : H12AffineEnvironment.transform 16 38160 env28882 = env28883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28882 == env28883) = true)

theorem identity28883 : scanCanonicalize (H12AffineFastState.compose env28883 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound28883 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,38160,10280,1024,32769,4160,21929,41413,41431,8328,65,43356,46276,58581,56573,1500,33,256,21793,46213,41941]

theorem envBound28884 : H12AffineFastState.Bounded env28884 := by
  intro p hp
  have h : env28884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28883_28884 : H12AffineEnvironment.transform 15 33246 env28883 = env28884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env28883 == env28884) = true)

theorem identity28884 : scanCanonicalize (H12AffineFastState.compose env28884 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound28884 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28885 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,38124,10280,1024,32769,4160,21589,41017,41003,8328,65,43168,46276,58581,56573,1056,33,252,21725,46213,41513]

theorem envBound28885 : H12AffineFastState.Bounded env28885 := by
  intro p hp
  have h : env28885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28884_28885 : H12AffineEnvironment.transform 7 252 env28884 = env28885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env28884 == env28885) = true)

theorem identity28885 : scanCanonicalize (H12AffineFastState.compose env28885 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound28885 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env28886 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,12345,32768,32802,38124,10280,1024,32769,4160,9324,41017,41003,8328,65,43168,46276,38124,44228,1056,33,252,9444,46213,41513]

theorem envBound28886 : H12AffineFastState.Bounded env28886 := by
  intro p hp
  have h : env28886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28885_28886 : H12AffineEnvironment.transform 13 12345 env28885 = env28886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env28885 == env28886) = true)

theorem identity28886 : scanCanonicalize (H12AffineFastState.compose env28886 (packedSelected [3,10,12,15,18,19,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound28886 : packedSelected [3,10,12,15,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env28887 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,8192,12345,32768,32802,36945,10280,189,32769,4160,8401,41017,41003,8328,65,43168,45177,36945,43129,157,33,252,8281,45112,41513]

theorem envBound28887 : H12AffineFastState.Bounded env28887 := by
  intro p hp
  have h : env28887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28886_28887 : H12AffineEnvironment.transform 9 189 env28886 = env28887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env28886 == env28887) = true)

theorem identity28887 : scanCanonicalize (H12AffineFastState.compose env28887 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound28887 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28888 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,8192,12345,137,171,4312,10280,189,136,4160,8401,8368,8354,8328,65,10281,12528,4312,10480,157,33,252,8281,12465,8864]

theorem envBound28888 : H12AffineFastState.Bounded env28888 := by
  intro p hp
  have h : env28888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28887_28888 : H12AffineEnvironment.transform 14 137 env28887 = env28888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env28887 == env28888) = true)

theorem identity28888 : scanCanonicalize (H12AffineFastState.compose env28888 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound28888 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28889 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,160,4249,137,171,4312,2184,189,136,4160,113,16,2,40,65,2185,4176,4312,2128,157,33,252,249,4113,512]

theorem envBound28889 : H12AffineFastState.Bounded env28889 := by
  intro p hp
  have h : env28889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28888_28889 : H12AffineEnvironment.transform 12 160 env28888 = env28889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env28888 == env28889) = true)

theorem identity28889 : scanCanonicalize (H12AffineFastState.compose env28889 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound28889 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28890 : List Nat := [2,4,8,16,32,64,40,84,512,21,2048,4096,8,4145,33,3,4208,2080,21,32,4160,113,16,2,40,65,2081,4176,4208,2128,53,33,84,81,4113,512]

theorem envBound28890 : H12AffineFastState.Bounded env28890 := by
  intro p hp
  have h : env28890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28889_28890 : H12AffineEnvironment.transform 6 40 env28889 = env28890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env28889 == env28890) = true)

theorem identity28890 : scanCanonicalize (H12AffineFastState.compose env28890 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28890 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28891 : List Nat := [2,4,8,16,32,17,40,5,512,21,2048,4096,8,4145,33,3,4129,2080,21,32,4113,32,16,2,40,16,2081,4097,4129,2049,53,33,5,0,4113,512]

theorem envBound28891 : H12AffineFastState.Bounded env28891 := by
  intro p hp
  have h : env28891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28890_28891 : H12AffineEnvironment.transform 5 17 env28890 = env28891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28890 == env28891) = true)

def env28892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,21928,41412,73736,8328,65,43356,46277,58580,56573,1500,33,256,21793,46213,74251]

theorem envBound28892 : H12AffineFastState.Bounded env28892 := by
  intro p hp
  have h : env28892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28882_28892 : H12AffineEnvironment.transform 16 38161 env28882 = env28892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28882 == env28892) = true)

theorem identity28892 : scanCanonicalize (H12AffineFastState.compose env28892 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound28892 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,38161,10280,1024,32769,4160,21928,41412,41311,8328,65,43356,46277,58580,56573,1500,33,256,21793,46213,41820]

theorem envBound28893 : H12AffineFastState.Bounded env28893 := by
  intro p hp
  have h : env28893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28892_28893 : H12AffineEnvironment.transform 15 33111 env28892 = env28893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env28892 == env28893) = true)

theorem identity28893 : scanCanonicalize (H12AffineFastState.compose env28893 (packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9413) := by decide +kernel

theorem selectedBound28893 : packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9413,9618,12756,10280,1024,9412,4160,21928,1281,1434,8328,65,3481,4096,16401,30776,1500,33,256,21793,4160,1945]

theorem envBound28894 : H12AffineFastState.Bounded env28894 := by
  intro p hp
  have h : env28894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28893_28894 : H12AffineEnvironment.transform 14 9413 env28893 = env28894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9413 env28893 == env28894) = true)

theorem identity28894 : scanCanonicalize (H12AffineFastState.compose env28894 (packedSelected [0,1,2,3,4,5,6,9,11,16,18,19,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound28894 : packedSelected [0,1,2,3,4,5,6,9,11,16,18,19,27,28] rootPS < 2^1333 := by decide +kernel

def env28895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,16384,292,115,5173,3529,1024,293,4160,21928,1281,1434,1385,65,3481,4096,16401,24025,1500,33,256,21793,4160,1945]

theorem envBound28895 : H12AffineFastState.Bounded env28895 := by
  intro p hp
  have h : env28895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28894_28895 : H12AffineEnvironment.transform 12 1505 env28894 = env28895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env28894 == env28895) = true)

theorem identity28895 : scanCanonicalize (H12AffineFastState.compose env28895 (packedSelected [0,2,3,4,6,7,9,10,12,14,15,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound28895 : packedSelected [0,2,3,4,6,7,9,10,12,14,15,19,24] rootPS < 2^1333 := by decide +kernel

def env28896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5593,292,115,5173,3529,1024,293,4160,113,1281,1434,1385,65,3481,4096,5576,2048,1500,33,256,248,4160,1945]

theorem envBound28896 : H12AffineFastState.Bounded env28896 := by
  intro p hp
  have h : env28896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28895_28896 : H12AffineEnvironment.transform 13 5593 env28895 = env28896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env28895 == env28896) = true)

theorem identity28896 : scanCanonicalize (H12AffineFastState.compose env28896 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound28896 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28897 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,40,4112,292,115,4604,2048,457,293,4160,113,200,83,160,65,2128,4096,4097,2048,21,33,256,248,4160,592]

theorem envBound28897 : H12AffineFastState.Bounded env28897 := by
  intro p hp
  have h : env28897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28896_28897 : H12AffineEnvironment.transform 9 457 env28896 = env28897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env28896 == env28897) = true)

theorem identity28897 : scanCanonicalize (H12AffineFastState.compose env28897 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound28897 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env28898 : List Nat := [2,4,8,16,32,64,128,252,512,53,2048,4096,40,4112,216,115,4096,2048,53,217,4160,113,200,83,160,65,2128,4096,4097,2048,21,33,252,248,4160,592]

theorem envBound28898 : H12AffineFastState.Bounded env28898 := by
  intro p hp
  have h : env28898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28897_28898 : H12AffineEnvironment.transform 7 252 env28897 = env28898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env28897 == env28898) = true)

theorem identity28898 : scanCanonicalize (H12AffineFastState.compose env28898 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2178) := by decide +kernel

theorem selectedBound28898 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28899 : List Nat := [2,4,8,16,32,64,128,252,512,53,2048,2178,40,2194,216,115,2178,2048,53,217,2242,113,200,83,160,65,2128,2178,2179,2048,21,33,252,248,2242,592]

theorem envBound28899 : H12AffineFastState.Bounded env28899 := by
  intro p hp
  have h : env28899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28898_28899 : H12AffineEnvironment.transform 11 2178 env28898 = env28899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2178 env28898 == env28899) = true)

theorem identity28899 : scanCanonicalize (H12AffineFastState.compose env28899 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28899 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env28900 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2058,40,2074,80,115,2058,2048,53,81,2122,113,64,83,40,65,2128,2058,2059,2048,21,33,116,112,2122,592]

theorem envBound28900 : H12AffineFastState.Bounded env28900 := by
  intro p hp
  have h : env28900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28899_28900 : H12AffineEnvironment.transform 6 8 env28899 = env28900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28899 == env28900) = true)

theorem identity28900 : scanCanonicalize (H12AffineFastState.compose env28900 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound28900 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28901 : List Nat := [2,4,8,16,32,64,8,116,512,53,554,544,40,560,80,115,544,554,53,81,608,113,64,83,40,65,634,544,545,554,21,33,116,112,608,592]

theorem envBound28901 : H12AffineFastState.Bounded env28901 := by
  intro p hp
  have h : env28901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28900_28901 : H12AffineEnvironment.transform 10 554 env28900 = env28901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env28900 == env28901) = true)

theorem identity28901 : scanCanonicalize (H12AffineFastState.compose env28901 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound28901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28902 : List Nat := [2,4,8,16,32,64,8,116,14,53,36,46,40,62,80,115,46,36,53,81,110,113,64,83,40,65,116,46,47,36,21,33,116,112,110,94]

theorem envBound28902 : H12AffineFastState.Bounded env28902 := by
  intro p hp
  have h : env28902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28901_28902 : H12AffineEnvironment.transform 8 14 env28901 = env28902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env28901 == env28902) = true)

theorem identity28902 : scanCanonicalize (H12AffineFastState.compose env28902 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound28902 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28903 : List Nat := [2,4,8,16,32,4,8,48,14,53,36,46,40,62,20,55,46,36,53,21,42,53,4,23,40,5,48,46,47,36,21,33,48,52,42,26]

theorem envBound28903 : H12AffineFastState.Bounded env28903 := by
  intro p hp
  have h : env28903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28902_28903 : H12AffineEnvironment.transform 5 4 env28902 = env28903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env28902 == env28903) = true)

theorem identity28903 : scanCanonicalize (H12AffineFastState.compose env28903 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound28903 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28904 : List Nat := [2,4,8,16,24,4,8,8,14,13,28,22,16,6,20,15,22,28,13,21,18,13,4,23,16,5,8,22,23,28,21,25,8,12,18,26]

theorem envBound28904 : H12AffineFastState.Bounded env28904 := by
  intro p hp
  have h : env28904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28903_28904 : H12AffineEnvironment.transform 4 24 env28903 = env28904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env28903 == env28904) = true)

def env28905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180409,144596,242968,8328,65,43357,139733,160196,56573,1500,32,256,21793,46213,74251]

theorem envBound28905 : H12AffineFastState.Bounded env28905 := by
  intro p hp
  have h : env28905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28881_28905 : H12AffineEnvironment.transform 17 10281 env28881 = env28905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28881 == env28905) = true)

def env28906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,21929,41412,73736,8328,65,43357,46277,58580,56573,1500,32,256,21793,46213,74251]

theorem envBound28906 : H12AffineFastState.Bounded env28906 := by
  intro p hp
  have h : env28906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28905_28906 : H12AffineEnvironment.transform 16 38160 env28905 = env28906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28905 == env28906) = true)

theorem identity28906 : scanCanonicalize (H12AffineFastState.compose env28906 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound28906 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1024,32769,4160,21929,41412,138,8328,65,43357,46277,58580,56573,1500,32,256,21793,46213,649]

end H12CloudChart0