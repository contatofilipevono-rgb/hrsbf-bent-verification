import H12CloudChart0Data214

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity54437 : scanCanonicalize (H12AffineFastState.compose env54437 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound54437 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env54438 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,5132,5124,5205,5126,65,7172,1024,5204,4160,1,17,3,5133,65,2049,5140,4096,7173,1105,1,5,1,5205,512]

theorem envBound54438 : H12AffineFastState.Bounded env54438 := by
  intro p hp
  have h : env54438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54437_54438 : H12AffineEnvironment.transform 12 5132 env54437 = env54438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env54437 == env54438) = true)

theorem identity54438 : scanCanonicalize (H12AffineFastState.compose env54438 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound54438 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env54439 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,1109,89,81,0,83,65,2129,1024,1,1045,1,17,3,88,65,2049,65,1109,2128,1105,1,5,1,0,512]

theorem envBound54439 : H12AffineFastState.Bounded env54439 := by
  intro p hp
  have h : env54439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54438_54439 : H12AffineEnvironment.transform 11 1109 env54438 = env54439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env54438 == env54439) = true)

theorem identity54439 : scanCanonicalize (H12AffineFastState.compose env54439 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound54439 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54440 : List Nat := [2,4,8,16,0,64,9,5,512,68,2048,17,89,81,0,83,65,2129,68,1,81,1,17,3,88,65,2049,65,17,2128,21,1,5,1,0,512]

theorem envBound54440 : H12AffineFastState.Bounded env54440 := by
  intro p hp
  have h : env54440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54439_54440 : H12AffineEnvironment.transform 9 68 env54439 = env54440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env54439 == env54440) = true)

theorem identity54440 : scanCanonicalize (H12AffineFastState.compose env54440 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound54440 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env54441 : List Nat := [2,4,8,16,0,64,9,5,512,68,81,17,89,81,0,83,65,0,68,1,81,1,17,3,88,65,80,65,17,1,21,1,5,1,0,512]

theorem envBound54441 : H12AffineFastState.Bounded env54441 := by
  intro p hp
  have h : env54441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54440_54441 : H12AffineEnvironment.transform 10 81 env54440 = env54441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env54440 == env54441) = true)

def env54442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441640,95496,8328,65,270497,436264,45525,32040,412720,156133,256,21792,46213,486375]

theorem envBound54442 : H12AffineFastState.Bounded env54442 := by
  intro p hp
  have h : env54442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54390_54442 : H12AffineEnvironment.transform 21 272513 env54390 = env54442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54390 == env54442) = true)

theorem identity54442 : scanCanonicalize (H12AffineFastState.compose env54442 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound54442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58517,169401,16,95496,8328,65,171417,5392,45525,32040,61704,156133,256,21792,46213,120543]

theorem envBound54443 : H12AffineFastState.Bounded env54443 := by
  intro p hp
  have h : env54443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54442_54443 : H12AffineEnvironment.transform 17 179512 env54442 = env54443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env54442 == env54443) = true)

def env54444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58397,169265,16,95496,8192,65,171281,5392,45405,32040,61704,156013,256,21792,46093,120407]

theorem envBound54444 : H12AffineFastState.Bounded env54444 := by
  intro p hp
  have h : env54444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54443_54444 : H12AffineEnvironment.transform 6 8 env54443 = env54444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54443 == env54444) = true)

theorem identity54444 : scanCanonicalize (H12AffineFastState.compose env54444 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound54444 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35188,1024,32769,58397,41341,16,95496,8192,65,43357,5392,45405,32040,61704,21793,256,21792,46093,120407]

theorem envBound54445 : H12AffineFastState.Bounded env54445 := by
  intro p hp
  have h : env54445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54444_54445 : H12AffineEnvironment.transform 16 13388 env54444 = env54445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env54444 == env54445) = true)

theorem identity54445 : scanCanonicalize (H12AffineFastState.compose env54445 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54445 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env54446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,35188,1024,32769,45340,41341,16,73737,8192,65,43357,5392,45405,10281,41993,32,256,33,46093,99158]

theorem envBound54446 : H12AffineFastState.Bounded env54446 := by
  intro p hp
  have h : env54446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54445_54446 : H12AffineEnvironment.transform 13 5377 env54445 = env54446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54445 == env54446) = true)

theorem identity54446 : scanCanonicalize (H12AffineFastState.compose env54446 (packedSelected [4,5,9,12,14,15,18,20,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound54446 : packedSelected [4,5,9,12,14,15,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,115,13388,35188,1024,32769,45340,41341,16,8314,8192,65,43357,5392,45405,10281,41993,32,256,33,46093,33573]

theorem envBound54447 : H12AffineFastState.Bounded env54447 := by
  intro p hp
  have h : env54447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54446_54447 : H12AffineEnvironment.transform 15 115 env54446 = env54447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env54446 == env54447) = true)

def env54448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169264,16,95496,8193,65,171280,5392,45404,32040,61704,156012,256,21792,46092,120406]

theorem envBound54448 : H12AffineFastState.Bounded env54448 := by
  intro p hp
  have h : env54448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54443_54448 : H12AffineEnvironment.transform 6 9 env54443 = env54448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54443 == env54448) = true)

theorem identity54448 : scanCanonicalize (H12AffineFastState.compose env54448 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound54448 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,58396,32,16,95496,8193,65,2048,5392,45404,32040,61704,62588,256,21792,46092,120406]

theorem envBound54449 : H12AffineFastState.Bounded env54449 := by
  intro p hp
  have h : env54449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54448_54449 : H12AffineEnvironment.transform 16 38160 env54448 = env54449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54448 == env54449) = true)

theorem identity54449 : scanCanonicalize (H12AffineFastState.compose env54449 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound54449 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,38160,10280,1024,32769,58396,32,16,8543,8193,65,2048,5392,45404,32040,61704,62588,256,21792,46092,33281]

theorem envBound54450 : H12AffineFastState.Bounded env54450 := by
  intro p hp
  have h : env54450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54449_54450 : H12AffineEnvironment.transform 15 21591 env54449 = env54450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env54449 == env54450) = true)

theorem identity54450 : scanCanonicalize (H12AffineFastState.compose env54450 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54450 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,342,38160,10280,1024,32769,45341,32,16,8543,8193,65,2048,5392,45404,10281,41993,41341,256,33,46092,33281]

theorem envBound54451 : H12AffineFastState.Bounded env54451 := by
  intro p hp
  have h : env54451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54450_54451 : H12AffineEnvironment.transform 13 5377 env54450 = env54451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54450 == env54451) = true)

theorem identity54451 : scanCanonicalize (H12AffineFastState.compose env54451 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54451 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env54452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,342,38160,2340,1024,32769,36881,32,16,83,269,65,2048,5392,36944,2341,34053,32881,256,33,38144,33281]

theorem envBound54452 : H12AffineFastState.Bounded env54452 := by
  intro p hp
  have h : env54452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54451_54452 : H12AffineEnvironment.transform 12 268 env54451 = env54452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54451 == env54452) = true)

theorem identity54452 : scanCanonicalize (H12AffineFastState.compose env54452 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound54452 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,342,5440,2340,1024,81,4161,32,16,83,269,65,2048,5392,4096,2341,1365,33,256,33,5456,593]

theorem envBound54453 : H12AffineFastState.Bounded env54453 := by
  intro p hp
  have h : env54453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54452_54453 : H12AffineEnvironment.transform 14 80 env54452 = env54453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env54452 == env54453) = true)

theorem identity54453 : scanCanonicalize (H12AffineFastState.compose env54453 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound54453 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2421,268,3188,80,342,3125,2340,1024,81,2356,32,16,83,269,65,2048,3173,2421,2341,1365,33,256,33,3109,593]

theorem envBound54454 : H12AffineFastState.Bounded env54454 := by
  intro p hp
  have h : env54454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54453_54454 : H12AffineEnvironment.transform 11 2421 env54453 = env54454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env54453 == env54454) = true)

theorem identity54454 : scanCanonicalize (H12AffineFastState.compose env54454 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound54454 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env54455 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,2081,88,3188,80,2,3125,2160,1024,81,2144,32,16,83,89,65,2048,3173,2081,2161,1025,33,84,33,3109,593]

theorem envBound54455 : H12AffineFastState.Bounded env54455 := by
  intro p hp
  have h : env54455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54454_54455 : H12AffineEnvironment.transform 7 84 env54454 = env54455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env54454 == env54455) = true)

theorem identity54455 : scanCanonicalize (H12AffineFastState.compose env54455 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound54455 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54456 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1093,1124,88,49,80,2,112,1077,1024,81,1061,32,16,83,89,65,1093,32,1124,1076,1025,33,84,33,96,593]

theorem envBound54456 : H12AffineFastState.Bounded env54456 := by
  intro p hp
  have h : env54456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54455_54456 : H12AffineEnvironment.transform 10 1093 env54455 = env54456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env54455 == env54456) = true)

theorem identity54456 : scanCanonicalize (H12AffineFastState.compose env54456 (packedSelected [1,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound54456 : packedSelected [1,6,8,11] rootPS < 2^1333 := by decide +kernel

def env54457 : List Nat := [2,4,8,16,32,64,9,84,512,84,17,48,88,49,80,2,112,97,84,81,113,32,16,83,89,65,17,32,48,96,85,33,84,33,96,593]

theorem envBound54457 : H12AffineFastState.Bounded env54457 := by
  intro p hp
  have h : env54457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54456_54457 : H12AffineEnvironment.transform 9 84 env54456 = env54457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env54456 == env54457) = true)

theorem identity54457 : scanCanonicalize (H12AffineFastState.compose env54457 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54458 : List Nat := [2,4,8,0,32,64,9,68,512,68,1,32,72,33,64,2,96,97,68,65,97,32,0,67,73,65,1,32,32,96,69,33,68,33,96,577]

theorem envBound54458 : H12AffineFastState.Bounded env54458 := by
  intro p hp
  have h : env54458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54457_54458 : H12AffineEnvironment.transform 3 0 env54457 = env54458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54457 == env54458) = true)

def env54459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441641,95497,8328,65,4196384,436265,45524,32041,412720,4606309,256,21792,46213,486375]

theorem envBound54459 : H12AffineFastState.Bounded env54459 := by
  intro p hp
  have h : env54459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54389_54459 : H12AffineEnvironment.transform 22 441641 env54389 = env54459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env54389 == env54459) = true)

def env54460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441641,95497,8328,65,270496,436265,45524,32041,412720,156133,256,21792,46213,486375]

theorem envBound54460 : H12AffineFastState.Bounded env54460 := by
  intro p hp
  have h : env54460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54459_54460 : H12AffineEnvironment.transform 21 272512 env54459 = env54460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54459 == env54460) = true)

theorem identity54460 : scanCanonicalize (H12AffineFastState.compose env54460 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound54460 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416173,272512,412157,95497,8328,65,270496,417021,17664,32041,412720,156133,256,21792,16465,486375]

theorem envBound54461 : H12AffineFastState.Bounded env54461 := by
  intro p hp
  have h : env54461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54460_54461 : H12AffineEnvironment.transform 14 29908 env54460 = env54461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env54460 == env54461) = true)

def env54462 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272512,412077,95497,8328,17,270496,416941,17664,32041,412720,156085,256,21792,16385,486327]

theorem envBound54462 : H12AffineFastState.Bounded env54462 := by
  intro p hp
  have h : env54462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54461_54462 : H12AffineEnvironment.transform 5 16 env54461 = env54462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54461 == env54462) = true)

theorem identity54462 : scanCanonicalize (H12AffineFastState.compose env54462 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound54462 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env54463 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,131072,262144,1024,29829,416173,272512,412077,2,8328,17,270496,416941,17664,32041,412720,156085,256,21792,16385,401084]

theorem envBound54463 : H12AffineFastState.Bounded env54463 := by
  intro p hp
  have h : env54463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54462_54463 : H12AffineEnvironment.transform 15 29963 env54462 = env54463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env54462 == env54463) = true)

theorem identity54463 : scanCanonicalize (H12AffineFastState.compose env54463 (packedSelected [1,4,7,9,14,17,18,19,23,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound54463 : packedSelected [1,4,7,9,14,17,18,19,23,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54464 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,16537,262144,1024,29829,268596,272512,264500,2,8328,17,270496,269364,17664,32041,265385,8492,256,21792,16385,286245]

theorem envBound54464 : H12AffineFastState.Bounded env54464 := by
  intro p hp
  have h : env54464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54463_54464 : H12AffineEnvironment.transform 16 16537 env54463 = env54464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env54463 == env54464) = true)

theorem identity54464 : scanCanonicalize (H12AffineFastState.compose env54464 (packedSelected [0,3,9,10,18,19,22,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound54464 : packedSelected [0,3,9,10,18,19,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env54465 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,16537,23588,1024,29829,17680,29860,21776,2,8328,17,31876,16400,17664,32041,20621,8492,256,21792,16385,513]

theorem envBound54465 : H12AffineFastState.Bounded env54465 := by
  intro p hp
  have h : env54465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54464_54465 : H12AffineEnvironment.transform 17 23588 env54464 = env54465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env54464 == env54465) = true)

theorem identity54465 : scanCanonicalize (H12AffineFastState.compose env54465 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound54465 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env54466 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,8322,5392,2477,1024,8460,4249,8493,153,2,8328,17,10509,5529,4233,10400,1284,8492,256,169,5512,513]

theorem envBound54466 : H12AffineFastState.Bounded env54466 := by
  intro p hp
  have h : env54466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54465_54466 : H12AffineEnvironment.transform 13 5513 env54465 = env54466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env54465 == env54466) = true)

theorem identity54466 : scanCanonicalize (H12AffineFastState.compose env54466 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54466 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54467 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,5293,8233,8322,5172,2185,1024,8232,4249,8201,153,2,8328,17,10281,5309,4233,10400,1056,8200,36,169,5292,513]

theorem envBound54467 : H12AffineFastState.Bounded env54467 := by
  intro p hp
  have h : env54467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54466_54467 : H12AffineEnvironment.transform 7 36 env54466 = env54467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54466 == env54467) = true)

theorem identity54467 : scanCanonicalize (H12AffineFastState.compose env54467 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound54467 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env54468 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,1173,5293,1212,1047,5172,2185,1024,1213,4249,1180,153,2,1053,17,3260,5309,4233,3125,1056,1181,36,169,5292,513]

theorem envBound54468 : H12AffineFastState.Bounded env54468 := by
  intro p hp
  have h : env54468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54467_54468 : H12AffineEnvironment.transform 12 1173 env54467 = env54468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env54467 == env54468) = true)

theorem identity54468 : scanCanonicalize (H12AffineFastState.compose env54468 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound54468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54469 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,40,4112,1,170,4233,2185,189,0,4249,33,153,2,160,17,2049,4096,4233,2184,157,32,36,169,4113,513]

theorem envBound54469 : H12AffineFastState.Bounded env54469 := by
  intro p hp
  have h : env54469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54468_54469 : H12AffineEnvironment.transform 9 189 env54468 = env54469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env54468 == env54469) = true)

theorem identity54469 : scanCanonicalize (H12AffineFastState.compose env54469 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54469 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54470 : List Nat := [2,4,8,1,32,1,128,36,512,172,2048,4096,40,4097,1,170,4233,2185,172,0,4232,33,136,2,160,0,2049,4096,4233,2184,140,32,36,169,4096,513]

theorem envBound54470 : H12AffineFastState.Bounded env54470 := by
  intro p hp
  have h : env54470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54469_54470 : H12AffineEnvironment.transform 3 1 env54469 = env54470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54469 == env54470) = true)

theorem identity54470 : scanCanonicalize (H12AffineFastState.compose env54470 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54470 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54471 : List Nat := [2,4,8,1,32,1,9,36,512,37,2048,4096,40,4097,1,35,4096,2048,37,0,4097,33,1,2,41,0,2049,4096,4096,2049,5,32,36,32,4096,513]

theorem envBound54471 : H12AffineFastState.Bounded env54471 := by
  intro p hp
  have h : env54471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54470_54471 : H12AffineEnvironment.transform 6 9 env54470 = env54471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54470 == env54471) = true)

theorem identity54471 : scanCanonicalize (H12AffineFastState.compose env54471 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54472 : List Nat := [2,4,8,1,32,1,9,36,512,37,2048,33,40,32,1,35,33,2048,37,0,32,33,1,2,41,0,2049,33,33,2049,5,32,36,32,33,513]

theorem envBound54472 : H12AffineFastState.Bounded env54472 := by
  intro p hp
  have h : env54472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54471_54472 : H12AffineEnvironment.transform 11 33 env54471 = env54472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54471 == env54472) = true)

theorem identity54472 : scanCanonicalize (H12AffineFastState.compose env54472 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound54472 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54473 : List Nat := [2,4,8,1,32,1,9,36,512,37,545,33,40,32,1,35,33,545,37,0,32,33,1,2,41,0,544,33,33,544,5,32,36,32,33,513]

theorem envBound54473 : H12AffineFastState.Bounded env54473 := by
  intro p hp
  have h : env54473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54472_54473 : H12AffineEnvironment.transform 10 545 env54472 = env54473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env54472 == env54473) = true)

theorem identity54473 : scanCanonicalize (H12AffineFastState.compose env54473 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound54473 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env54474 : List Nat := [2,4,8,1,32,1,9,36,32,37,1,33,40,32,1,35,33,1,37,0,32,33,1,2,41,0,0,33,33,0,5,32,36,32,33,33]

theorem envBound54474 : H12AffineFastState.Bounded env54474 := by
  intro p hp
  have h : env54474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54473_54474 : H12AffineEnvironment.transform 8 32 env54473 = env54474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env54473 == env54474) = true)

theorem identity54474 : scanCanonicalize (H12AffineFastState.compose env54474 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54474 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env54475 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,1,8,0,1,3,1,1,5,0,0,1,1,2,9,0,0,1,1,0,5,0,4,0,1,1]

theorem envBound54475 : H12AffineFastState.Bounded env54475 := by
  intro p hp
  have h : env54475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54474_54475 : H12AffineEnvironment.transform 4 0 env54474 = env54475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54474 == env54475) = true)

def env54476 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272512,412076,95497,8328,16,270496,416940,17664,32041,412720,156084,256,21792,16384,486326]

theorem envBound54476 : H12AffineFastState.Bounded env54476 := by
  intro p hp
  have h : env54476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54461_54476 : H12AffineEnvironment.transform 5 17 env54461 = env54476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54461 == env54476) = true)

theorem identity54476 : scanCanonicalize (H12AffineFastState.compose env54476 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound54476 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env54477 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,10400,1024,29828,160013,32,155916,95497,8328,16,2048,160780,17664,32041,156816,156084,256,21792,16384,213782]

theorem envBound54477 : H12AffineFastState.Bounded env54477 := by
  intro p hp
  have h : env54477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54476_54477 : H12AffineEnvironment.transform 17 10400 env54476 = env54477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env54476 == env54477) = true)

theorem identity54477 : scanCanonicalize (H12AffineFastState.compose env54477 (packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,19,20,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24752) := by decide +kernel

theorem selectedBound54477 : packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env54478 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24752,10400,1024,29828,4541,32,444,95497,8328,16,2048,5308,17664,32041,1056,260,256,21792,16384,74662]

theorem envBound54478 : H12AffineFastState.Bounded env54478 := by
  intro p hp
  have h : env54478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54477_54478 : H12AffineEnvironment.transform 16 24752 env54477 = env54478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24752 env54477 == env54478) = true)

theorem identity54478 : scanCanonicalize (H12AffineFastState.compose env54478 (packedSelected [2,5,6,9,10,11,12,14,15,16,19,20,22,23,24,31] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound54478 : packedSelected [2,5,6,9,10,11,12,14,15,16,19,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env54479 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,65536,16693,2341,1024,21761,4541,32,444,87180,269,16,2048,5308,17664,23724,1056,260,256,21792,16384,66083]

theorem envBound54479 : H12AffineFastState.Bounded env54479 := by
  intro p hp
  have h : env54479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54478_54479 : H12AffineEnvironment.transform 12 389 env54478 = env54479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env54478 == env54479) = true)

theorem identity54479 : scanCanonicalize (H12AffineFastState.compose env54479 (packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound54479 : packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env54480 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,21795,16693,2341,1024,21761,4541,32,444,431,269,16,2048,5308,17664,23724,1056,260,256,21792,16384,22272]

theorem envBound54480 : H12AffineFastState.Bounded env54480 := by
  intro p hp
  have h : env54480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54479_54480 : H12AffineEnvironment.transform 15 21795 env54479 = env54480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env54479 == env54480) = true)

theorem identity54480 : scanCanonicalize (H12AffineFastState.compose env54480 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound54480 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54481 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5513,137,170,5308,2341,1024,136,4541,32,444,431,269,16,2048,5308,4233,2341,1056,260,256,169,5513,649]

theorem envBound54481 : H12AffineFastState.Bounded env54481 := by
  intro p hp
  have h : env54481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54480_54481 : H12AffineEnvironment.transform 13 5513 env54480 = env54481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env54480 == env54481) = true)

theorem identity54481 : scanCanonicalize (H12AffineFastState.compose env54481 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound54481 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54482 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5157,137,170,5308,2185,1024,136,4113,32,16,3,161,16,2048,5308,4233,2185,1056,168,172,169,5157,649]

theorem envBound54482 : H12AffineFastState.Bounded env54482 := by
  intro p hp
  have h : env54482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54481_54482 : H12AffineEnvironment.transform 7 172 env54481 = env54482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54481 == env54482) = true)

theorem identity54482 : scanCanonicalize (H12AffineFastState.compose env54482 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54483 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1212,41,153,137,170,0,2185,1024,136,1197,32,16,3,161,16,2048,0,1077,2185,1056,168,172,169,153,649]

theorem envBound54483 : H12AffineFastState.Bounded env54483 := by
  intro p hp
  have h : env54483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54482_54483 : H12AffineEnvironment.transform 11 1212 env54482 = env54483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env54482 == env54483) = true)

theorem identity54483 : scanCanonicalize (H12AffineFastState.compose env54483 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound54483 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env54484 : List Nat := [2,4,8,16,32,17,128,172,512,36,2048,152,41,153,137,170,0,2185,36,136,137,32,16,3,161,16,2048,0,17,2185,4,168,172,169,153,649]

theorem envBound54484 : H12AffineFastState.Bounded env54484 := by
  intro p hp
  have h : env54484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54483_54484 : H12AffineEnvironment.transform 9 36 env54483 = env54484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env54483 == env54484) = true)

theorem identity54484 : scanCanonicalize (H12AffineFastState.compose env54484 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54484 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env54485 : List Nat := [2,4,8,16,0,17,128,140,512,4,2048,152,9,153,137,138,0,2185,4,136,137,0,16,3,129,16,2048,0,17,2185,4,136,140,137,153,649]

theorem envBound54485 : H12AffineFastState.Bounded env54485 := by
  intro p hp
  have h : env54485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54484_54485 : H12AffineEnvironment.transform 4 0 env54484 = env54485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54484 == env54485) = true)

theorem identity54485 : scanCanonicalize (H12AffineFastState.compose env54485 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54485 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54486 : List Nat := [2,4,8,16,0,17,9,5,512,4,2048,17,9,16,0,3,0,2048,4,1,0,0,16,3,8,16,2048,0,17,2048,4,1,5,0,16,512]

theorem envBound54486 : H12AffineFastState.Bounded env54486 := by
  intro p hp
  have h : env54486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54485_54486 : H12AffineEnvironment.transform 6 9 env54485 = env54486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54485 == env54486) = true)

theorem identity54486 : scanCanonicalize (H12AffineFastState.compose env54486 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound54486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54487 : List Nat := [2,4,8,16,0,17,9,5,512,4,529,17,9,16,0,3,0,529,4,1,0,0,16,3,8,16,529,0,17,529,4,1,5,0,16,512]

theorem envBound54487 : H12AffineFastState.Bounded env54487 := by
  intro p hp
  have h : env54487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54486_54487 : H12AffineEnvironment.transform 10 529 env54486 = env54487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env54486 == env54487) = true)

theorem identity54487 : scanCanonicalize (H12AffineFastState.compose env54487 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54488 : List Nat := [2,4,8,0,0,1,9,5,512,4,513,1,9,0,0,3,0,513,4,1,0,0,0,3,8,0,513,0,1,513,4,1,5,0,0,512]

theorem envBound54488 : H12AffineFastState.Bounded env54488 := by
  intro p hp
  have h : env54488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54487_54488 : H12AffineEnvironment.transform 3 0 env54487 = env54488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54487 == env54488) = true)

theorem identity54488 : scanCanonicalize (H12AffineFastState.compose env54488 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound54488 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54489 : List Nat := [2,4,8,0,0,1,9,5,14,4,15,1,9,0,0,3,0,15,4,1,0,0,0,3,8,0,15,0,1,15,4,1,5,0,0,14]

theorem envBound54489 : H12AffineFastState.Bounded env54489 := by
  intro p hp
  have h : env54489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54488_54489 : H12AffineEnvironment.transform 8 14 env54488 = env54489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env54488 == env54489) = true)

theorem identity54489 : scanCanonicalize (H12AffineFastState.compose env54489 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound54489 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54490 : List Nat := [2,4,6,0,0,1,7,5,0,4,1,1,7,0,0,3,0,1,4,1,0,0,0,3,6,0,1,0,1,1,4,1,5,0,0,0]

theorem envBound54490 : H12AffineFastState.Bounded env54490 := by
  intro p hp
  have h : env54490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54489_54490 : H12AffineEnvironment.transform 2 6 env54489 = env54490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env54489 == env54490) = true)

def env54491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441641,95497,8328,65,270497,436265,45524,32041,412720,156132,256,21792,46213,486375]

theorem envBound54491 : H12AffineFastState.Bounded env54491 := by
  intro p hp
  have h : env54491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54459_54491 : H12AffineEnvironment.transform 21 272513 env54459 = env54491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54459 == env54491) = true)

theorem identity54491 : scanCanonicalize (H12AffineFastState.compose env54491 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound54491 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,156012,62660,95497,8328,65,158028,57796,45524,32041,1501,156132,256,21792,46213,74250]

theorem envBound54492 : H12AffineFastState.Bounded env54492 := by
  intro p hp
  have h : env54492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54491_54492 : H12AffineEnvironment.transform 17 149997 env54491 = env54492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env54491 == env54492) = true)

theorem identity54492 : scanCanonicalize (H12AffineFastState.compose env54492 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54492 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4160,156012,62660,21762,8328,65,158028,57796,45524,32041,1501,156132,256,21792,46213,513]

theorem envBound54493 : H12AffineFastState.Bounded env54493 := by
  intro p hp
  have h : env54493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54492_54493 : H12AffineEnvironment.transform 15 8203 env54492 = env54493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54492 == env54493) = true)

theorem identity54493 : scanCanonicalize (H12AffineFastState.compose env54493 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound54493 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env54494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,131072,146744,1024,32769,4160,136633,32785,8663,8328,65,138649,38161,45524,2556,1501,136497,256,8693,46213,513]

theorem envBound54494 : H12AffineFastState.Bounded env54494 := by
  intro p hp
  have h : env54494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54493_54494 : H12AffineEnvironment.transform 13 13525 env54493 = env54494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env54493 == env54494) = true)

theorem identity54494 : scanCanonicalize (H12AffineFastState.compose env54494 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound54494 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env54495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,5529,10401,1024,32769,4160,32,32785,8663,8328,65,2048,38161,45524,2556,1501,168,256,8693,46213,513]

theorem envBound54495 : H12AffineFastState.Bounded env54495 := by
  intro p hp
  have h : env54495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54494_54495 : H12AffineEnvironment.transform 16 5529 env54494 = env54495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env54494 == env54495) = true)

theorem identity54495 : scanCanonicalize (H12AffineFastState.compose env54495 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound54495 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env54496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8461,8203,5529,10401,1024,8460,4160,32,8476,8663,8328,65,2048,13340,4313,2556,1501,168,256,8693,5512,513]

theorem envBound54496 : H12AffineFastState.Bounded env54496 := by
  intro p hp
  have h : env54496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54495_54496 : H12AffineEnvironment.transform 14 8461 env54495 = env54496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env54495 == env54496) = true)

theorem identity54496 : scanCanonicalize (H12AffineFastState.compose env54496 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound54496 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,137,399,5529,2341,1024,136,4160,32,152,83,268,65,2048,5528,4313,2556,1501,168,256,113,5512,513]

theorem envBound54497 : H12AffineFastState.Bounded env54497 := by
  intro p hp
  have h : env54497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54496_54497 : H12AffineEnvironment.transform 12 388 env54496 = env54497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env54496 == env54497) = true)

theorem identity54497 : scanCanonicalize (H12AffineFastState.compose env54497 (packedSelected [0,1,2,3,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound54497 : packedSelected [0,1,2,3,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54498 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,80,342,5440,2341,1024,81,4160,32,65,83,268,65,2048,5441,4096,2341,1284,113,256,113,5457,513]

theorem envBound54498 : H12AffineFastState.Bounded env54498 := by
  intro p hp
  have h : env54498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54497_54498 : H12AffineEnvironment.transform 6 89 env54497 = env54498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54497 == env54498) = true)

theorem identity54498 : scanCanonicalize (H12AffineFastState.compose env54498 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound54498 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54499 : List Nat := [2,4,8,16,32,64,89,256,512,305,2048,4096,349,4192,80,342,4209,2341,305,81,4160,32,65,83,268,65,2048,4208,4096,2341,53,113,256,113,4192,513]

theorem envBound54499 : H12AffineFastState.Bounded env54499 := by
  intro p hp
  have h : env54499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54498_54499 : H12AffineEnvironment.transform 9 305 env54498 = env54499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env54498 == env54499) = true)

def env54500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound54500 : H12AffineFastState.Bounded env54500 := by
  intro p hp
  have h : env54500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54273_54500 : H12AffineEnvironment.transform 18 1025 env54273 = env54500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env54273 == env54500) = true)

theorem identity54500 : scanCanonicalize (H12AffineFastState.compose env54500 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound54500 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616289,18973836,10507600,8579233,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound54501 : H12AffineFastState.Bounded env54501 := by
  intro p hp
  have h : env54501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54500_54501 : H12AffineEnvironment.transform 17 10400 env54500 = env54501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env54500 == env54501) = true)

def env54502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616169,18973700,10507600,8579113,25265168,23160137,257,27378724,27337992,25207630]

theorem envBound54502 : H12AffineFastState.Bounded env54502 := by
  intro p hp
  have h : env54502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54501_54502 : H12AffineEnvironment.transform 6 8 env54501 = env54502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54501 == env54502) = true)

def env54503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,16777216,8192,65,21080105,18973700,2233680,43049,17024016,23160137,257,19104804,19096840,16966478]

theorem envBound54503 : H12AffineFastState.Bounded env54503 := by
  intro p hp
  have h : env54503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54502_54503 : H12AffineEnvironment.transform 22 147456 env54502 = env54503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env54502 == env54503) = true)

def env54504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,2347268,8192,65,6453549,152832,2233680,43049,2102548,4371533,257,21792,46092,2175562]

theorem envBound54504 : H12AffineFastState.Bounded env54504 := by
  intro p hp
  have h : env54504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54503_54504 : H12AffineEnvironment.transform 23 2347268 env54503 = env54504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347268 env54503 == env54504) = true)

def env54505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147456,98644,8192,65,4204925,152832,17664,43049,148804,4371533,257,21792,46092,221722]

theorem envBound54505 : H12AffineFastState.Bounded env54505 := by
  intro p hp
  have h : env54505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54504_54505 : H12AffineEnvironment.transform 20 151632 env54504 = env54505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env54504 == env54505) = true)

theorem identity54505 : scanCanonicalize (H12AffineFastState.compose env54505 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54505 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env54506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77899,4194304,73755,98644,8192,65,4204925,79131,17664,43049,75103,4314198,257,21792,46092,513]

theorem envBound54506 : H12AffineFastState.Bounded env54506 := by
  intro p hp
  have h : env54506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54505_54506 : H12AffineEnvironment.transform 16 90139 env54505 = env54506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54505 == env54506) = true)

theorem identity54506 : scanCanonicalize (H12AffineFastState.compose env54506 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound54506 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env54507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,4194304,73755,95496,8192,65,4204925,79131,17664,23669,75103,4268042,257,21792,16464,513]

theorem envBound54507 : H12AffineFastState.Bounded env54507 := by
  intro p hp
  have h : env54507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54506_54507 : H12AffineEnvironment.transform 14 29788 env54506 = env54507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env54506 == env54507) = true)

def env54508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,32,73755,95496,8192,65,10589,79131,17664,23669,75103,73770,257,21792,16464,513]

theorem envBound54508 : H12AffineFastState.Bounded env54508 := by
  intro p hp
  have h : env54508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54507_54508 : H12AffineEnvironment.transform 21 32 env54507 = env54508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54507 == env54508) = true)

theorem identity54508 : scanCanonicalize (H12AffineFastState.compose env54508 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound54508 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env54509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8282,16449,10280,1025,29789,4113,32,65,21842,8192,65,10589,5441,17664,23669,1285,112,257,21792,16464,513]

theorem envBound54509 : H12AffineFastState.Bounded env54509 := by
  intro p hp
  have h : env54509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54508_54509 : H12AffineEnvironment.transform 15 8282 env54508 = env54509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env54508 == env54509) = true)

theorem identity54509 : scanCanonicalize (H12AffineFastState.compose env54509 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54509 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,343,16449,2341,1025,21840,4113,32,65,21842,269,65,2128,5441,17664,23669,1285,112,257,21792,16464,513]

theorem envBound54510 : H12AffineFastState.Bounded env54510 := by
  intro p hp
  have h : env54510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54509_54510 : H12AffineEnvironment.transform 12 269 env54509 = env54510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54509 == env54510) = true)

theorem identity54510 : scanCanonicalize (H12AffineFastState.compose env54510 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54510 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,0,343,5392,2341,1025,1,4113,32,65,3,269,65,2128,5441,4177,2340,1285,112,257,113,5377,513]

theorem envBound54511 : H12AffineFastState.Bounded env54511 := by
  intro p hp
  have h : env54511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54510_54511 : H12AffineEnvironment.transform 13 5457 env54510 = env54511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54510 == env54511) = true)

theorem identity54511 : scanCanonicalize (H12AffineFastState.compose env54511 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound54511 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,512,269,1873,0,343,1808,2341,1025,1,529,32,65,3,269,65,2128,1857,593,2340,1285,112,257,113,1793,513]

theorem envBound54512 : H12AffineFastState.Bounded env54512 := by
  intro p hp
  have h : env54512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54511_54512 : H12AffineEnvironment.transform 11 512 env54511 = env54512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env54511 == env54512) = true)

def env54513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,33,73755,95496,8192,65,10588,79131,17664,23669,75103,73771,257,21792,16464,513]

theorem envBound54513 : H12AffineFastState.Bounded env54513 := by
  intro p hp
  have h : env54513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54507_54513 : H12AffineEnvironment.transform 21 33 env54507 = env54513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54507 == env54513) = true)

theorem identity54513 : scanCanonicalize (H12AffineFastState.compose env54513 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound54513 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env54514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21511,13340,10280,1025,29789,25676,33,29724,8463,8192,65,10588,24860,17664,23669,29016,29740,257,21792,16464,513]

theorem envBound54514 : H12AffineFastState.Bounded env54514 := by
  intro p hp
  have h : env54514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54513_54514 : H12AffineEnvironment.transform 15 21511 env54513 = env54514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env54513 == env54514) = true)

theorem identity54514 : scanCanonicalize (H12AffineFastState.compose env54514 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound54514 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8202,13340,10280,1025,80,4161,33,17,8463,8192,65,10588,5393,12557,10360,1365,33,257,8493,13405,513]

theorem envBound54515 : H12AffineFastState.Bounded env54515 := by
  intro p hp
  have h : env54515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54514_54515 : H12AffineEnvironment.transform 13 13325 env54514 = env54515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env54514 == env54515) = true)

theorem identity54515 : scanCanonicalize (H12AffineFastState.compose env54515 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54515 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,343,5441,2421,1025,80,4161,33,17,82,349,65,2049,5393,4176,2341,1365,33,257,112,5376,513]

theorem envBound54516 : H12AffineFastState.Bounded env54516 := by
  intro p hp
  have h : env54516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54515_54516 : H12AffineEnvironment.transform 12 349 env54515 = env54516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54515 == env54516) = true)

theorem identity54516 : scanCanonicalize (H12AffineFastState.compose env54516 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54516 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54517 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1025,1,4112,33,17,3,268,16,2049,5393,4097,2341,1284,33,257,33,5376,513]

theorem envBound54517 : H12AffineFastState.Bounded env54517 := by
  intro p hp
  have h : env54517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54516_54517 : H12AffineEnvironment.transform 5 17 env54516 = env54517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54516 == env54517) = true)

theorem identity54517 : scanCanonicalize (H12AffineFastState.compose env54517 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound54517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54518 : List Nat := [2,4,8,16,32,17,8,256,512,288,2048,4096,268,4129,0,262,4144,2340,289,1,4112,33,17,3,268,16,2049,4145,4097,2341,36,33,257,33,4128,513]

theorem envBound54518 : H12AffineFastState.Bounded env54518 := by
  intro p hp
  have h : env54518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54517_54518 : H12AffineEnvironment.transform 9 288 env54517 = env54518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env54517 == env54518) = true)

theorem identity54518 : scanCanonicalize (H12AffineFastState.compose env54518 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound54518 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54519 : List Nat := [2,4,8,16,32,17,8,256,292,288,2048,4096,268,4129,0,262,4144,2340,289,1,4112,33,17,3,268,16,2049,4145,4097,2341,36,33,257,33,4128,293]

theorem envBound54519 : H12AffineFastState.Bounded env54519 := by
  intro p hp
  have h : env54519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54518_54519 : H12AffineEnvironment.transform 8 292 env54518 = env54519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env54518 == env54519) = true)

theorem identity54519 : scanCanonicalize (H12AffineFastState.compose env54519 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound54519 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54520 : List Nat := [2,4,8,16,32,17,8,256,292,288,2048,2080,268,2049,0,262,2064,2340,289,1,2096,33,17,3,268,16,2049,2065,2081,2341,36,33,257,33,2048,293]

theorem envBound54520 : H12AffineFastState.Bounded env54520 := by
  intro p hp
  have h : env54520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54519_54520 : H12AffineEnvironment.transform 11 2080 env54519 = env54520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env54519 == env54520) = true)

theorem identity54520 : scanCanonicalize (H12AffineFastState.compose env54520 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54520 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54521 : List Nat := [2,4,8,16,0,17,8,256,260,256,2048,2048,268,2049,0,262,2064,2308,257,1,2064,1,17,3,268,16,2049,2065,2049,2309,4,1,257,1,2048,261]

theorem envBound54521 : H12AffineFastState.Bounded env54521 := by
  intro p hp
  have h : env54521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54520_54521 : H12AffineEnvironment.transform 4 0 env54520 = env54521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54520 == env54521) = true)

theorem identity54521 : scanCanonicalize (H12AffineFastState.compose env54521 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound54521 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54522 : List Nat := [2,4,8,16,0,17,8,256,260,256,17,17,268,16,0,262,1,277,257,1,1,1,17,3,268,16,16,0,16,276,4,1,257,1,17,261]

theorem envBound54522 : H12AffineFastState.Bounded env54522 := by
  intro p hp
  have h : env54522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54521_54522 : H12AffineEnvironment.transform 10 17 env54521 = env54522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env54521 == env54522) = true)

theorem identity54522 : scanCanonicalize (H12AffineFastState.compose env54522 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54523 : List Nat := [2,4,8,16,0,17,8,21,17,21,17,17,25,16,0,19,1,0,20,1,1,1,17,3,25,16,16,0,16,1,4,1,20,1,17,16]

theorem envBound54523 : H12AffineFastState.Bounded env54523 := by
  intro p hp
  have h : env54523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54522_54523 : H12AffineEnvironment.transform 7 21 env54522 = env54523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54522 == env54523) = true)

def env54524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147456,98645,8192,65,4204924,152832,17665,43049,148805,4371533,257,21792,46092,221723]

theorem envBound54524 : H12AffineFastState.Bounded env54524 := by
  intro p hp
  have h : env54524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54504_54524 : H12AffineEnvironment.transform 20 151633 env54504 = env54524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env54504 == env54524) = true)

def env54525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,32,147456,98645,8192,65,10588,152832,17665,43049,148805,177261,257,21792,46092,221723]

theorem envBound54525 : H12AffineFastState.Bounded env54525 := by
  intro p hp
  have h : env54525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54524_54525 : H12AffineEnvironment.transform 21 32 env54524 = env54525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54524 == env54525) = true)

theorem identity54525 : scanCanonicalize (H12AffineFastState.compose env54525 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound54525 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77899,32,73754,98645,8192,65,10588,79130,17665,43049,75103,119927,257,21792,46092,513]

theorem envBound54526 : H12AffineFastState.Bounded env54526 := by
  intro p hp
  have h : env54526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54525_54526 : H12AffineEnvironment.transform 16 90138 env54525 = env54526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env54525 == env54526) = true)

theorem identity54526 : scanCanonicalize (H12AffineFastState.compose env54526 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54526 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4160,32,17,41310,8192,65,10588,5393,17665,43049,1364,62588,257,21792,46092,513]

theorem envBound54527 : H12AffineFastState.Bounded env54527 := by
  intro p hp
  have h : env54527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54526_54527 : H12AffineEnvironment.transform 15 8203 env54526 = env54527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54526 == env54527) = true)

theorem identity54527 : scanCanonicalize (H12AffineFastState.compose env54527 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54527 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2341,1025,32769,4160,32,17,32851,269,65,2129,5393,17665,35108,1364,54641,257,21792,38145,513]

theorem envBound54528 : H12AffineFastState.Bounded env54528 := by
  intro p hp
  have h : env54528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54527_54528 : H12AffineEnvironment.transform 12 269 env54527 = env54528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54527 == env54528) = true)

theorem identity54528 : scanCanonicalize (H12AffineFastState.compose env54528 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound54528 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,262,16401,2341,1025,21841,4160,32,17,21763,269,65,2129,5393,17665,23668,1364,33,257,21792,16465,513]

theorem envBound54529 : H12AffineFastState.Bounded env54529 := by
  intro p hp
  have h : env54529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54528_54529 : H12AffineEnvironment.transform 14 21840 env54528 = env54529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env54528 == env54529) = true)

theorem identity54529 : scanCanonicalize (H12AffineFastState.compose env54529 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54529 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,0,262,5441,2341,1025,1,4160,32,17,83,269,65,2129,5393,4177,2340,1364,33,257,112,5377,513]

theorem envBound54530 : H12AffineFastState.Bounded env54530 := by
  intro p hp
  have h : env54530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54529_54530 : H12AffineEnvironment.transform 13 5456 env54529 = env54530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54529 == env54530) = true)

theorem identity54530 : scanCanonicalize (H12AffineFastState.compose env54530 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound54530 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54531 : List Nat := [2,4,8,16,32,64,8,256,350,1024,2048,4096,269,5456,0,262,5441,2341,1025,1,4160,32,17,83,269,65,2129,5393,4177,2340,1364,33,257,112,5377,351]

theorem envBound54531 : H12AffineFastState.Bounded env54531 := by
  intro p hp
  have h : env54531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54530_54531 : H12AffineEnvironment.transform 8 350 env54530 = env54531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env54530 == env54531) = true)

theorem identity54531 : scanCanonicalize (H12AffineFastState.compose env54531 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54531 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54532 : List Nat := [2,4,8,16,32,17,8,256,271,1024,2048,4096,269,5377,0,262,5392,2341,1025,1,4113,32,17,2,269,16,2048,5393,4096,2340,1285,33,257,33,5377,270]

theorem envBound54532 : H12AffineFastState.Bounded env54532 := by
  intro p hp
  have h : env54532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54531_54532 : H12AffineEnvironment.transform 5 17 env54531 = env54532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54531 == env54532) = true)

theorem identity54532 : scanCanonicalize (H12AffineFastState.compose env54532 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54533 : List Nat := [2,4,8,16,32,17,8,256,271,1024,2048,33,269,1312,0,262,1329,2341,1025,1,48,32,17,2,269,16,2048,1328,33,2340,1285,33,257,33,1312,270]

theorem envBound54533 : H12AffineFastState.Bounded env54533 := by
  intro p hp
  have h : env54533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54532_54533 : H12AffineEnvironment.transform 11 33 env54532 = env54533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54532 == env54533) = true)

theorem identity54533 : scanCanonicalize (H12AffineFastState.compose env54533 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound54533 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54534 : List Nat := [2,4,8,16,32,17,8,256,271,1024,1323,33,269,1312,0,262,1329,1038,1025,1,48,32,17,2,269,16,1323,1328,33,1039,1285,33,257,33,1312,270]

theorem envBound54534 : H12AffineFastState.Bounded env54534 := by
  intro p hp
  have h : env54534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54533_54534 : H12AffineEnvironment.transform 10 1323 env54533 = env54534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env54533 == env54534) = true)

theorem identity54534 : scanCanonicalize (H12AffineFastState.compose env54534 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound54534 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54535 : List Nat := [2,4,8,16,32,17,8,31,16,1024,1076,33,18,1087,0,25,1070,1038,1025,1,48,32,17,2,18,16,1076,1071,33,1039,1050,33,30,33,1087,17]

theorem envBound54535 : H12AffineFastState.Bounded env54535 := by
  intro p hp
  have h : env54535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54534_54535 : H12AffineEnvironment.transform 7 31 env54534 = env54535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env54534 == env54535) = true)

theorem identity54535 : scanCanonicalize (H12AffineFastState.compose env54535 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound54535 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54536 : List Nat := [2,4,8,16,32,17,8,31,16,46,26,33,18,17,0,25,0,32,47,1,48,32,17,2,18,16,26,1,33,33,52,33,30,33,17,17]

theorem envBound54536 : H12AffineFastState.Bounded env54536 := by
  intro p hp
  have h : env54536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54535_54536 : H12AffineEnvironment.transform 9 46 env54535 = env54536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env54535 == env54536) = true)

theorem identity54536 : scanCanonicalize (H12AffineFastState.compose env54536 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54536 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54537 : List Nat := [2,4,8,0,32,1,8,15,0,46,10,33,2,1,0,9,0,32,47,1,32,32,1,2,2,0,10,1,33,33,36,33,14,33,1,1]

theorem envBound54537 : H12AffineFastState.Bounded env54537 := by
  intro p hp
  have h : env54537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54536_54537 : H12AffineEnvironment.transform 3 0 env54536 = env54537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54536 == env54537) = true)

theorem identity54537 : scanCanonicalize (H12AffineFastState.compose env54537 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound54537 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54538 : List Nat := [2,4,8,0,5,1,8,15,0,11,10,4,2,1,0,9,0,5,10,1,5,5,1,2,2,0,10,1,4,4,1,4,14,4,1,1]

theorem envBound54538 : H12AffineFastState.Bounded env54538 := by
  intro p hp
  have h : env54538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54537_54538 : H12AffineEnvironment.transform 4 5 env54537 = env54538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env54537 == env54538) = true)

theorem identity54538 : scanCanonicalize (H12AffineFastState.compose env54538 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54538 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env54539 : List Nat := [2,4,2,0,5,1,2,5,0,1,0,4,2,1,0,3,0,5,0,1,5,5,1,2,2,0,0,1,4,4,1,4,4,4,1,1]

theorem envBound54539 : H12AffineFastState.Bounded env54539 := by
  intro p hp
  have h : env54539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54538_54539 : H12AffineEnvironment.transform 2 2 env54538 = env54539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54538 == env54539) = true)

theorem identity54539 : scanCanonicalize (H12AffineFastState.compose env54539 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54539 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54540 : List Nat := [2,2,2,0,3,1,2,3,0,1,0,2,2,1,0,3,0,3,0,1,3,3,1,2,2,0,0,1,2,2,1,2,2,2,1,1]

theorem envBound54540 : H12AffineFastState.Bounded env54540 := by
  intro p hp
  have h : env54540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54539_54540 : H12AffineEnvironment.transform 1 2 env54539 = env54540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54539 == env54540) = true)

def env54541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,33,147456,98645,8192,65,10589,152832,17665,43049,148805,177260,257,21792,46092,221723]

theorem envBound54541 : H12AffineFastState.Bounded env54541 := by
  intro p hp
  have h : env54541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54524_54541 : H12AffineEnvironment.transform 21 33 env54524 = env54541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54524 == env54541) = true)

theorem identity54541 : scanCanonicalize (H12AffineFastState.compose env54541 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54541 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,151633,33,147456,41310,8192,65,10589,152832,17665,43049,148805,177260,257,21792,46092,147984]

theorem envBound54542 : H12AffineFastState.Bounded env54542 := by
  intro p hp
  have h : env54542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54541_54542 : H12AffineEnvironment.transform 15 8203 env54541 = env54542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54541 == env54542) = true)

theorem identity54542 : scanCanonicalize (H12AffineFastState.compose env54542 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54542 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env54543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,131072,2340,1025,32769,151633,33,147456,32850,268,65,2129,152832,17665,35109,148805,169312,257,21792,38144,147984]

theorem envBound54543 : H12AffineFastState.Bounded env54543 := by
  intro p hp
  have h : env54543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54542_54543 : H12AffineEnvironment.transform 12 268 env54542 = env54543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54542 == env54543) = true)

theorem identity54543 : scanCanonicalize (H12AffineFastState.compose env54543 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound54543 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,263,131072,2340,1025,81,151633,33,147456,2,268,65,2129,152832,17665,2421,148805,136496,257,21792,5456,147984]

theorem envBound54544 : H12AffineFastState.Bounded env54544 := by
  intro p hp
  have h : env54544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54543_54544 : H12AffineEnvironment.transform 14 80 env54543 = env54544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env54543 == env54544) = true)

theorem identity54544 : scanCanonicalize (H12AffineFastState.compose env54544 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54544 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env54545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,131072,2340,1025,81,132432,33,136449,2,268,65,2129,131073,4096,2421,135236,136496,257,33,5456,136977]

theorem envBound54545 : H12AffineFastState.Bounded env54545 := by
  intro p hp
  have h : env54545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54544_54545 : H12AffineEnvironment.transform 13 5377 env54544 = env54545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54544 == env54545) = true)

theorem identity54545 : scanCanonicalize (H12AffineFastState.compose env54545 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54545 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,131072,2340,1025,1,132352,33,136449,2,268,17,2049,131073,4096,2341,135188,136496,257,33,5376,136977]

theorem envBound54546 : H12AffineFastState.Bounded env54546 := by
  intro p hp
  have h : env54546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54545_54546 : H12AffineEnvironment.transform 5 16 env54545 = env54546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54545 == env54546) = true)

theorem identity54546 : scanCanonicalize (H12AffineFastState.compose env54546 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound54546 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env54547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5392,2340,1025,1,4112,33,17,2,268,17,2049,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound54547 : H12AffineFastState.Bounded env54547 := by
  intro p hp
  have h : env54547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54546_54547 : H12AffineEnvironment.transform 16 5392 env54546 = env54547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env54546 == env54547) = true)

theorem identity54547 : scanCanonicalize (H12AffineFastState.compose env54547 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound54547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54548 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1076,268,309,0,263,292,2340,1025,1,1060,33,17,2,268,17,2049,293,1076,2341,1284,32,257,33,308,513]

theorem envBound54548 : H12AffineFastState.Bounded env54548 := by
  intro p hp
  have h : env54548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54547_54548 : H12AffineEnvironment.transform 11 1076 env54547 = env54548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env54547 == env54548) = true)

theorem identity54548 : scanCanonicalize (H12AffineFastState.compose env54548 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1306) := by decide +kernel

theorem selectedBound54548 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54549 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1306,1076,268,309,0,263,292,1086,1025,1,1060,33,17,2,268,17,1307,293,1076,1087,1284,32,257,33,308,513]

theorem envBound54549 : H12AffineFastState.Bounded env54549 := by
  intro p hp
  have h : env54549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54548_54549 : H12AffineEnvironment.transform 10 1306 env54548 = env54549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1306 env54548 == env54549) = true)

theorem identity54549 : scanCanonicalize (H12AffineFastState.compose env54549 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 315) := by decide +kernel

theorem selectedBound54549 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54550 : List Nat := [2,4,8,16,32,16,8,256,512,315,33,271,268,309,0,263,292,261,314,1,287,33,17,2,268,17,32,293,271,260,63,32,257,33,308,513]

theorem envBound54550 : H12AffineFastState.Bounded env54550 := by
  intro p hp
  have h : env54550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54549_54550 : H12AffineEnvironment.transform 9 315 env54549 = env54550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 315 env54549 == env54550) = true)

theorem identity54550 : scanCanonicalize (H12AffineFastState.compose env54550 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54550 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54551 : List Nat := [2,4,8,16,16,16,8,256,512,267,17,271,268,261,0,263,276,261,266,1,287,17,17,2,268,17,16,277,271,260,15,16,257,17,260,513]

theorem envBound54551 : H12AffineFastState.Bounded env54551 := by
  intro p hp
  have h : env54551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54550_54551 : H12AffineEnvironment.transform 4 16 env54550 = env54551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54550 == env54551) = true)

theorem identity54551 : scanCanonicalize (H12AffineFastState.compose env54551 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound54551 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54552 : List Nat := [2,4,8,16,16,16,8,15,512,4,17,0,3,10,0,8,27,10,5,1,16,17,17,2,3,17,16,26,0,11,15,16,14,17,11,513]

theorem envBound54552 : H12AffineFastState.Bounded env54552 := by
  intro p hp
  have h : env54552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54551_54552 : H12AffineEnvironment.transform 7 15 env54551 = env54552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env54551 == env54552) = true)

theorem identity54552 : scanCanonicalize (H12AffineFastState.compose env54552 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54552 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54553 : List Nat := [2,4,8,7,7,7,8,15,512,4,6,0,3,10,0,8,12,10,5,1,7,6,6,2,3,6,7,13,0,11,15,7,14,6,11,513]

theorem envBound54553 : H12AffineFastState.Bounded env54553 := by
  intro p hp
  have h : env54553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54552_54553 : H12AffineEnvironment.transform 3 7 env54552 = env54553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54552 == env54553) = true)

def env54554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,2347269,8192,65,6453548,152833,2233680,43049,2102549,4371532,257,21793,46093,2175563]

theorem envBound54554 : H12AffineFastState.Bounded env54554 := by
  intro p hp
  have h : env54554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54503_54554 : H12AffineEnvironment.transform 23 2347269 env54503 = env54554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347269 env54503 == env54554) = true)

def env54555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147456,98645,8192,65,4204924,152833,17664,43049,148805,4371532,257,21793,46093,221723]

theorem envBound54555 : H12AffineFastState.Bounded env54555 := by
  intro p hp
  have h : env54555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54554_54555 : H12AffineEnvironment.transform 20 151632 env54554 = env54555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env54554 == env54555) = true)

def env54556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,32,147456,98645,8192,65,10588,152833,17664,43049,148805,177260,257,21793,46093,221723]

theorem envBound54556 : H12AffineFastState.Bounded env54556 := by
  intro p hp
  have h : env54556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54555_54556 : H12AffineEnvironment.transform 21 32 env54555 = env54556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54555 == env54556) = true)

theorem identity54556 : scanCanonicalize (H12AffineFastState.compose env54556 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound54556 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,32,73754,98645,8192,65,10588,79131,17664,43049,75103,119926,257,21793,46093,513]

theorem envBound54557 : H12AffineFastState.Bounded env54557 := by
  intro p hp
  have h : env54557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54556_54557 : H12AffineEnvironment.transform 16 90138 env54556 = env54557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env54556 == env54557) = true)

theorem identity54557 : scanCanonicalize (H12AffineFastState.compose env54557 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54557 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4161,32,17,41310,8192,65,10588,5392,17664,43049,1364,62589,257,21793,46093,513]

theorem envBound54558 : H12AffineFastState.Bounded env54558 := by
  intro p hp
  have h : env54558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54557_54558 : H12AffineEnvironment.transform 15 8203 env54557 = env54558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54557 == env54558) = true)

theorem identity54558 : scanCanonicalize (H12AffineFastState.compose env54558 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54558 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2341,1025,32769,4161,32,17,32851,269,65,2129,5392,17664,35108,1364,54640,257,21793,38144,513]

theorem envBound54559 : H12AffineFastState.Bounded env54559 := by
  intro p hp
  have h : env54559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54558_54559 : H12AffineEnvironment.transform 12 269 env54558 = env54559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54558 == env54559) = true)

theorem identity54559 : scanCanonicalize (H12AffineFastState.compose env54559 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound54559 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,262,16401,2341,1025,21840,4161,32,17,21762,269,65,2129,5392,17664,23669,1364,33,257,21793,16465,513]

theorem envBound54560 : H12AffineFastState.Bounded env54560 := by
  intro p hp
  have h : env54560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54559_54560 : H12AffineEnvironment.transform 14 21841 env54559 = env54560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env54559 == env54560) = true)

theorem identity54560 : scanCanonicalize (H12AffineFastState.compose env54560 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54560 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,0,262,5440,2341,1025,1,4161,32,17,83,269,65,2129,5392,4177,2340,1364,33,257,112,5376,513]

theorem envBound54561 : H12AffineFastState.Bounded env54561 := by
  intro p hp
  have h : env54561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54560_54561 : H12AffineEnvironment.transform 13 5457 env54560 = env54561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54560 == env54561) = true)

theorem identity54561 : scanCanonicalize (H12AffineFastState.compose env54561 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound54561 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54562 : List Nat := [2,4,8,16,32,64,8,256,270,1024,2048,4096,269,5457,0,262,5440,2341,1025,1,4161,32,17,83,269,65,2129,5392,4177,2340,1364,33,257,112,5376,271]

theorem envBound54562 : H12AffineFastState.Bounded env54562 := by
  intro p hp
  have h : env54562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54561_54562 : H12AffineEnvironment.transform 8 270 env54561 = env54562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env54561 == env54562) = true)

theorem identity54562 : scanCanonicalize (H12AffineFastState.compose env54562 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54562 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54563 : List Nat := [2,4,8,16,32,17,8,256,270,1024,2048,4096,269,5376,0,262,5393,2341,1025,1,4112,32,17,2,269,16,2048,5392,4096,2340,1285,33,257,33,5376,271]

theorem envBound54563 : H12AffineFastState.Bounded env54563 := by
  intro p hp
  have h : env54563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54562_54563 : H12AffineEnvironment.transform 5 17 env54562 = env54563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54562 == env54563) = true)

theorem identity54563 : scanCanonicalize (H12AffineFastState.compose env54563 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54563 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54564 : List Nat := [2,4,8,16,32,17,8,256,270,1024,2048,33,269,1313,0,262,1328,2341,1025,1,49,32,17,2,269,16,2048,1329,33,2340,1285,33,257,33,1313,271]

theorem envBound54564 : H12AffineFastState.Bounded env54564 := by
  intro p hp
  have h : env54564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54563_54564 : H12AffineEnvironment.transform 11 33 env54563 = env54564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54563 == env54564) = true)

theorem identity54564 : scanCanonicalize (H12AffineFastState.compose env54564 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound54564 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54565 : List Nat := [2,4,8,16,32,17,8,256,270,1024,1323,33,269,1313,0,262,1328,1038,1025,1,49,32,17,2,269,16,1323,1329,33,1039,1285,33,257,33,1313,271]

theorem envBound54565 : H12AffineFastState.Bounded env54565 := by
  intro p hp
  have h : env54565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54564_54565 : H12AffineEnvironment.transform 10 1323 env54564 = env54565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env54564 == env54565) = true)

theorem identity54565 : scanCanonicalize (H12AffineFastState.compose env54565 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound54565 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54566 : List Nat := [2,4,8,16,32,17,8,30,16,1024,1077,33,19,1087,0,24,1070,1038,1025,1,49,32,17,2,19,16,1077,1071,33,1039,1051,33,31,33,1087,17]

theorem envBound54566 : H12AffineFastState.Bounded env54566 := by
  intro p hp
  have h : env54566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54565_54566 : H12AffineEnvironment.transform 7 30 env54565 = env54566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env54565 == env54566) = true)

theorem identity54566 : scanCanonicalize (H12AffineFastState.compose env54566 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound54566 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54567 : List Nat := [2,4,8,16,32,17,8,30,16,47,26,33,19,16,0,24,1,33,46,1,49,32,17,2,19,16,26,0,33,32,52,33,31,33,16,17]

theorem envBound54567 : H12AffineFastState.Bounded env54567 := by
  intro p hp
  have h : env54567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54566_54567 : H12AffineEnvironment.transform 9 47 env54566 = env54567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env54566 == env54567) = true)

theorem identity54567 : scanCanonicalize (H12AffineFastState.compose env54567 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54567 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54568 : List Nat := [2,4,8,1,32,0,8,15,1,47,11,33,2,1,0,9,1,33,46,1,32,32,0,2,2,1,11,0,33,32,37,33,14,33,1,0]

theorem envBound54568 : H12AffineFastState.Bounded env54568 := by
  intro p hp
  have h : env54568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54567_54568 : H12AffineEnvironment.transform 3 1 env54567 = env54568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54567 == env54568) = true)

theorem identity54568 : scanCanonicalize (H12AffineFastState.compose env54568 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound54568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54569 : List Nat := [2,4,8,1,14,0,8,15,1,1,11,15,2,1,0,9,1,15,0,1,14,14,0,2,2,1,11,0,15,14,11,15,14,15,1,0]

theorem envBound54569 : H12AffineFastState.Bounded env54569 := by
  intro p hp
  have h : env54569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54568_54569 : H12AffineEnvironment.transform 4 14 env54568 = env54569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env54568 == env54569) = true)

theorem identity54569 : scanCanonicalize (H12AffineFastState.compose env54569 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54569 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env54570 : List Nat := [2,4,3,1,5,0,3,4,1,1,0,4,2,1,0,2,1,4,0,1,5,5,0,2,2,1,0,0,4,5,0,4,5,4,1,0]

theorem envBound54570 : H12AffineFastState.Bounded env54570 := by
  intro p hp
  have h : env54570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54569_54570 : H12AffineEnvironment.transform 2 3 env54569 = env54570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54569 == env54570) = true)

theorem identity54570 : scanCanonicalize (H12AffineFastState.compose env54570 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54571 : List Nat := [2,2,3,1,3,0,3,2,1,1,0,2,2,1,0,2,1,2,0,1,3,3,0,2,2,1,0,0,2,3,0,2,3,2,1,0]

theorem envBound54571 : H12AffineFastState.Bounded env54571 := by
  intro p hp
  have h : env54571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54570_54571 : H12AffineEnvironment.transform 1 2 env54570 = env54571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54570 == env54571) = true)

def env54572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,33,147456,98645,8192,65,10589,152833,17664,43049,148805,177261,257,21793,46093,221723]

theorem envBound54572 : H12AffineFastState.Bounded env54572 := by
  intro p hp
  have h : env54572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54555_54572 : H12AffineEnvironment.transform 21 33 env54555 = env54572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54555 == env54572) = true)

theorem identity54572 : scanCanonicalize (H12AffineFastState.compose env54572 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound54572 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,33,17,98645,8192,65,10589,5392,17664,43049,1364,62588,257,21793,46093,74250]

theorem envBound54573 : H12AffineFastState.Bounded env54573 := by
  intro p hp
  have h : env54573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54572_54573 : H12AffineEnvironment.transform 16 16401 env54572 = env54573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env54572 == env54573) = true)

theorem identity54573 : scanCanonicalize (H12AffineFastState.compose env54573 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound54573 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,16401,10280,1025,32769,4161,33,17,21842,8192,65,10589,5392,17664,43049,1364,62588,257,21793,46093,62989]

theorem envBound54574 : H12AffineFastState.Bounded env54574 := by
  intro p hp
  have h : env54574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54573_54574 : H12AffineEnvironment.transform 15 54279 env54573 = env54574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env54573 == env54574) = true)

theorem identity54574 : scanCanonicalize (H12AffineFastState.compose env54574 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54574 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env54575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54279,16401,2421,1025,32769,4161,33,17,21842,349,65,2048,5392,17664,35188,1364,54561,257,21793,38224,55120]

theorem envBound54575 : H12AffineFastState.Bounded env54575 := by
  intro p hp
  have h : env54575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54574_54575 : H12AffineEnvironment.transform 12 349 env54574 = env54575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54574 == env54575) = true)

theorem identity54575 : scanCanonicalize (H12AffineFastState.compose env54575 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54575 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env54576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21511,16401,2421,1025,1,4161,33,17,21842,349,65,2048,5392,17664,2420,1364,21793,257,21793,5456,22352]

theorem envBound54576 : H12AffineFastState.Bounded env54576 := by
  intro p hp
  have h : env54576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54575_54576 : H12AffineEnvironment.transform 14 0 env54575 = env54576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54575 == env54576) = true)

theorem identity54576 : scanCanonicalize (H12AffineFastState.compose env54576 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3182) := by decide +kernel

theorem selectedBound54576 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env54577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3182,349,16384,0,18537,16401,2421,1025,1,3119,33,17,18748,349,65,2048,2430,17664,2420,1364,18767,257,18767,2366,19262]

theorem envBound54577 : H12AffineFastState.Bounded env54577 := by
  intro p hp
  have h : env54577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54576_54577 : H12AffineEnvironment.transform 11 3182 env54576 = env54577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3182 env54576 == env54577) = true)

theorem identity54577 : scanCanonicalize (H12AffineFastState.compose env54577 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54577 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env54578 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3182,41,16384,0,18537,16401,2049,1025,1,3119,33,17,18504,41,65,2048,2058,17524,2048,1056,18491,117,18491,2122,19018]

theorem envBound54578 : H12AffineFastState.Bounded env54578 := by
  intro p hp
  have h : env54578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54577_54578 : H12AffineEnvironment.transform 7 116 env54577 = env54578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54577 == env54578) = true)

theorem identity54578 : scanCanonicalize (H12AffineFastState.compose env54578 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound54578 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54579 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3182,41,1028,0,3181,1045,2049,1025,1,3119,33,17,3148,41,65,2048,2058,112,2048,1056,3135,117,3135,2122,3662]

theorem envBound54579 : H12AffineFastState.Bounded env54579 := by
  intro p hp
  have h : env54579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54578_54579 : H12AffineEnvironment.transform 13 1028 env54578 = env54579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env54578 == env54579) = true)

theorem identity54579 : scanCanonicalize (H12AffineFastState.compose env54579 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound54579 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env54580 : List Nat := [2,4,8,16,32,27,8,47,512,1024,2048,3125,41,1028,0,3126,1045,2049,1025,1,3119,33,17,3095,41,26,2048,2058,43,2048,1056,3135,46,3135,2065,3605]

theorem envBound54580 : H12AffineFastState.Bounded env54580 := by
  intro p hp
  have h : env54580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54579_54580 : H12AffineEnvironment.transform 5 27 env54579 = env54580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env54579 == env54580) = true)

theorem identity54580 : scanCanonicalize (H12AffineFastState.compose env54580 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound54580 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env54581 : List Nat := [2,4,8,16,32,27,8,47,512,1024,1038,59,41,1028,0,56,1045,1039,1025,1,33,33,17,25,41,26,1038,1028,43,1038,1056,49,46,49,1055,539]

theorem envBound54581 : H12AffineFastState.Bounded env54581 := by
  intro p hp
  have h : env54581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54580_54581 : H12AffineEnvironment.transform 10 1038 env54580 = env54581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env54580 == env54581) = true)

theorem identity54581 : scanCanonicalize (H12AffineFastState.compose env54581 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 529) := by decide +kernel

theorem selectedBound54581 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env54582 : List Nat := [2,4,8,16,32,27,8,47,512,529,543,59,41,533,0,56,516,542,528,1,33,33,17,25,41,26,543,533,43,543,561,49,46,49,526,539]

theorem envBound54582 : H12AffineFastState.Bounded env54582 := by
  intro p hp
  have h : env54582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54581_54582 : H12AffineEnvironment.transform 9 529 env54581 = env54582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 529 env54581 == env54582) = true)

theorem identity54582 : scanCanonicalize (H12AffineFastState.compose env54582 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54582 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env54583 : List Nat := [2,4,8,16,16,27,8,31,512,529,543,11,25,533,0,8,516,542,528,1,17,17,17,25,25,26,543,533,27,543,513,1,30,1,526,539]

theorem envBound54583 : H12AffineFastState.Bounded env54583 := by
  intro p hp
  have h : env54583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54582_54583 : H12AffineEnvironment.transform 4 16 env54582 = env54583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54582 == env54583) = true)

theorem identity54583 : scanCanonicalize (H12AffineFastState.compose env54583 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54583 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54584 : List Nat := [2,4,8,0,0,11,8,15,512,513,527,11,9,517,0,8,516,526,512,1,1,1,1,9,9,10,527,517,11,527,513,1,14,1,526,523]

theorem envBound54584 : H12AffineFastState.Bounded env54584 := by
  intro p hp
  have h : env54584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54583_54584 : H12AffineEnvironment.transform 3 0 env54583 = env54584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54583 == env54584) = true)

def env54585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147456,98644,8192,65,4204925,152833,17665,43049,148804,4371532,257,21793,46093,221722]

theorem envBound54585 : H12AffineFastState.Bounded env54585 := by
  intro p hp
  have h : env54585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54554_54585 : H12AffineEnvironment.transform 20 151633 env54554 = env54585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env54554 == env54585) = true)

theorem identity54585 : scanCanonicalize (H12AffineFastState.compose env54585 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54585 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env54586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,73755,98644,8192,65,4204925,79130,17665,43049,75103,4314199,257,21793,46093,513]

theorem envBound54586 : H12AffineFastState.Bounded env54586 := by
  intro p hp
  have h : env54586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54585_54586 : H12AffineEnvironment.transform 16 90139 env54585 = env54586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54585 == env54586) = true)

theorem identity54586 : scanCanonicalize (H12AffineFastState.compose env54586 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound54586 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env54587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,4194304,73755,95497,8192,65,4204925,79130,17665,23668,75103,4268042,257,21793,16464,513]

theorem envBound54587 : H12AffineFastState.Bounded env54587 := by
  intro p hp
  have h : env54587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54586_54587 : H12AffineEnvironment.transform 14 29789 env54586 = env54587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env54586 == env54587) = true)

def env54588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,32,73755,95497,8192,65,10589,79130,17665,23668,75103,73770,257,21793,16464,513]

theorem envBound54588 : H12AffineFastState.Bounded env54588 := by
  intro p hp
  have h : env54588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54587_54588 : H12AffineEnvironment.transform 21 32 env54587 = env54588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54587 == env54588) = true)

theorem identity54588 : scanCanonicalize (H12AffineFastState.compose env54588 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound54588 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env54589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8282,16449,10280,1025,29788,4112,32,65,21843,8192,65,10589,5440,17665,23668,1285,112,257,21793,16464,513]

theorem envBound54589 : H12AffineFastState.Bounded env54589 := by
  intro p hp
  have h : env54589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54588_54589 : H12AffineEnvironment.transform 15 8282 env54588 = env54589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env54588 == env54589) = true)

theorem identity54589 : scanCanonicalize (H12AffineFastState.compose env54589 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54589 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,343,16449,2341,1025,21841,4112,32,65,21843,269,65,2128,5440,17665,23668,1285,112,257,21793,16464,513]

theorem envBound54590 : H12AffineFastState.Bounded env54590 := by
  intro p hp
  have h : env54590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54589_54590 : H12AffineEnvironment.transform 12 269 env54589 = env54590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54589 == env54590) = true)

theorem identity54590 : scanCanonicalize (H12AffineFastState.compose env54590 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54590 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,0,343,5393,2341,1025,1,4112,32,65,3,269,65,2128,5440,4177,2340,1285,112,257,113,5376,513]

theorem envBound54591 : H12AffineFastState.Bounded env54591 := by
  intro p hp
  have h : env54591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54590_54591 : H12AffineEnvironment.transform 13 5456 env54590 = env54591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54590 == env54591) = true)

theorem identity54591 : scanCanonicalize (H12AffineFastState.compose env54591 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound54591 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,512,269,1872,0,343,1809,2341,1025,1,528,32,65,3,269,65,2128,1856,593,2340,1285,112,257,113,1792,513]

theorem envBound54592 : H12AffineFastState.Bounded env54592 := by
  intro p hp
  have h : env54592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54591_54592 : H12AffineEnvironment.transform 11 512 env54591 = env54592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env54591 == env54592) = true)

def env54593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,33,73755,95497,8192,65,10588,79130,17665,23668,75103,73771,257,21793,16464,513]

theorem envBound54593 : H12AffineFastState.Bounded env54593 := by
  intro p hp
  have h : env54593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54587_54593 : H12AffineEnvironment.transform 21 33 env54587 = env54593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54587 == env54593) = true)

theorem identity54593 : scanCanonicalize (H12AffineFastState.compose env54593 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound54593 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env54594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21510,13341,10280,1025,29788,25676,33,29725,8463,8192,65,10588,24860,17665,23668,29017,29741,257,21793,16464,513]

theorem envBound54594 : H12AffineFastState.Bounded env54594 := by
  intro p hp
  have h : env54594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54593_54594 : H12AffineEnvironment.transform 15 21510 env54593 = env54594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env54593 == env54594) = true)

theorem identity54594 : scanCanonicalize (H12AffineFastState.compose env54594 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54594 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,8202,13341,10280,1025,80,4160,33,17,8463,8192,65,10588,5392,12557,10360,1365,33,257,8493,13404,513]

theorem envBound54595 : H12AffineFastState.Bounded env54595 := by
  intro p hp
  have h : env54595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54594_54595 : H12AffineEnvironment.transform 13 13324 env54594 = env54595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54594 == env54595) = true)

theorem identity54595 : scanCanonicalize (H12AffineFastState.compose env54595 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54595 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,81,343,5440,2421,1025,80,4160,33,17,82,349,65,2049,5392,4176,2341,1365,33,257,112,5377,513]

theorem envBound54596 : H12AffineFastState.Bounded env54596 := by
  intro p hp
  have h : env54596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54595_54596 : H12AffineEnvironment.transform 12 349 env54595 = env54596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54595 == env54596) = true)

theorem identity54596 : scanCanonicalize (H12AffineFastState.compose env54596 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54596 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54597 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1025,1,4113,33,17,3,268,16,2049,5392,4097,2341,1284,33,257,33,5377,513]

theorem envBound54597 : H12AffineFastState.Bounded env54597 := by
  intro p hp
  have h : env54597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54596_54597 : H12AffineEnvironment.transform 5 17 env54596 = env54597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54596 == env54597) = true)

theorem identity54597 : scanCanonicalize (H12AffineFastState.compose env54597 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound54597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54598 : List Nat := [2,4,8,16,32,17,8,256,512,289,2048,4096,268,4129,0,262,4144,2340,288,1,4113,33,17,3,268,16,2049,4145,4097,2341,37,33,257,33,4128,513]

theorem envBound54598 : H12AffineFastState.Bounded env54598 := by
  intro p hp
  have h : env54598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54597_54598 : H12AffineEnvironment.transform 9 289 env54597 = env54598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env54597 == env54598) = true)

theorem identity54598 : scanCanonicalize (H12AffineFastState.compose env54598 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound54598 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54599 : List Nat := [2,4,8,16,32,17,8,256,292,289,2048,4096,268,4129,0,262,4144,2340,288,1,4113,33,17,3,268,16,2049,4145,4097,2341,37,33,257,33,4128,293]

theorem envBound54599 : H12AffineFastState.Bounded env54599 := by
  intro p hp
  have h : env54599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54598_54599 : H12AffineEnvironment.transform 8 292 env54598 = env54599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env54598 == env54599) = true)

theorem identity54599 : scanCanonicalize (H12AffineFastState.compose env54599 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound54599 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54600 : List Nat := [2,4,8,16,32,17,8,256,292,289,2048,2081,268,2048,0,262,2065,2340,288,1,2096,33,17,3,268,16,2049,2064,2080,2341,37,33,257,33,2049,293]

theorem envBound54600 : H12AffineFastState.Bounded env54600 := by
  intro p hp
  have h : env54600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54599_54600 : H12AffineEnvironment.transform 11 2081 env54599 = env54600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env54599 == env54600) = true)

theorem identity54600 : scanCanonicalize (H12AffineFastState.compose env54600 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54600 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54601 : List Nat := [2,4,8,16,0,17,8,256,260,257,2048,2049,268,2048,0,262,2065,2308,256,1,2064,1,17,3,268,16,2049,2064,2048,2309,5,1,257,1,2049,261]

theorem envBound54601 : H12AffineFastState.Bounded env54601 := by
  intro p hp
  have h : env54601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54600_54601 : H12AffineEnvironment.transform 4 0 env54600 = env54601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54600 == env54601) = true)

theorem identity54601 : scanCanonicalize (H12AffineFastState.compose env54601 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound54601 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54602 : List Nat := [2,4,8,16,0,17,8,256,260,257,17,16,268,17,0,262,0,277,256,1,1,1,17,3,268,16,16,1,17,276,5,1,257,1,16,261]

theorem envBound54602 : H12AffineFastState.Bounded env54602 := by
  intro p hp
  have h : env54602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54601_54602 : H12AffineEnvironment.transform 10 17 env54601 = env54602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env54601 == env54602) = true)

theorem identity54602 : scanCanonicalize (H12AffineFastState.compose env54602 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54603 : List Nat := [2,4,8,16,0,17,8,21,17,20,17,16,25,17,0,19,0,0,21,1,1,1,17,3,25,16,16,1,17,1,5,1,20,1,16,16]

theorem envBound54603 : H12AffineFastState.Bounded env54603 := by
  intro p hp
  have h : env54603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54602_54603 : H12AffineEnvironment.transform 7 21 env54602 = env54603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54602 == env54603) = true)

theorem identity54603 : scanCanonicalize (H12AffineFastState.compose env54603 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54603 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env54604 : List Nat := [2,4,8,0,0,1,8,5,1,4,1,0,9,1,0,3,0,0,5,1,1,1,1,3,9,0,0,1,1,1,5,1,4,1,0,0]

theorem envBound54604 : H12AffineFastState.Bounded env54604 := by
  intro p hp
  have h : env54604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54603_54604 : H12AffineEnvironment.transform 3 0 env54603 = env54604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54603 == env54604) = true)

def env54605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,16777216,8192,65,21080104,18973700,2233681,43048,17024017,23160137,257,19104805,19096841,16966479]

theorem envBound54605 : H12AffineFastState.Bounded env54605 := by
  intro p hp
  have h : env54605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54502_54605 : H12AffineEnvironment.transform 22 147457 env54502 = env54605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env54502 == env54605) = true)

theorem identity54605 : scanCanonicalize (H12AffineFastState.compose env54605 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound54605 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188750,8192,65,4409702,2319690,2233681,43048,75103,6521863,257,2188651,2196551,513]

theorem envBound54606 : H12AffineFastState.Bounded env54606 := by
  intro p hp
  have h : env54606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54605_54606 : H12AffineEnvironment.transform 23 188750 env54605 = env54606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env54605 == env54606) = true)

def env54607 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188702,8192,17,4409654,2319642,2233601,43048,75023,6521863,257,2188603,2196503,513]

theorem envBound54607 : H12AffineFastState.Bounded env54607 := by
  intro p hp
  have h : env54607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54606_54607 : H12AffineEnvironment.transform 5 16 env54606 = env54607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54606 == env54607) = true)

theorem identity54607 : scanCanonicalize (H12AffineFastState.compose env54607 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound54607 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env54608 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,4194304,147457,188702,8192,17,4409654,172301,250134,43048,75023,4341776,257,41260,16384,513]

theorem envBound54608 : H12AffineFastState.Bounded env54608 := by
  intro p hp
  have h : env54608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54607_54608 : H12AffineEnvironment.transform 20 115735 env54607 = env54608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env54607 == env54608) = true)

theorem identity54608 : scanCanonicalize (H12AffineFastState.compose env54608 (packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54608 : packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env54609 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115735,4194304,147457,180242,268,17,4409654,163841,250134,35108,66563,4341776,257,32800,16384,513]

theorem envBound54609 : H12AffineFastState.Bounded env54609 := by
  intro p hp
  have h : env54609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54608_54609 : H12AffineEnvironment.transform 12 268 env54608 = env54609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54608 == env54609) = true)

theorem identity54609 : scanCanonicalize (H12AffineFastState.compose env54609 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound54609 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env54610 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115735,32801,147457,180242,268,17,248087,163841,250134,35108,66563,180273,257,32800,16384,513]

theorem envBound54610 : H12AffineFastState.Bounded env54610 := by
  intro p hp
  have h : env54610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54609_54610 : H12AffineEnvironment.transform 21 32801 env54609 = env54610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env54609 == env54610) = true)

theorem identity54610 : scanCanonicalize (H12AffineFastState.compose env54610 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound54610 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54611 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,82199,2340,1025,32769,115735,32801,65814,98565,268,17,34816,114966,36865,35108,66563,98598,257,32800,16384,513]

theorem envBound54611 : H12AffineFastState.Bounded env54611 := by
  intro p hp
  have h : env54611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54610_54611 : H12AffineEnvironment.transform 16 82199 env54610 = env54611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env54610 == env54611) = true)

theorem identity54611 : scanCanonicalize (H12AffineFastState.compose env54611 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54611 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54612 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2340,1025,32769,50448,32801,17,32770,268,17,34816,49169,36865,35108,1284,32801,257,32800,16384,513]

theorem envBound54612 : H12AffineFastState.Bounded env54612 := by
  intro p hp
  have h : env54612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54611_54612 : H12AffineEnvironment.transform 15 263 env54611 = env54612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54611 == env54612) = true)

theorem identity54612 : scanCanonicalize (H12AffineFastState.compose env54612 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54612 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env54613 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16400,2340,1025,1,17680,33,17,2,268,17,2048,16401,4097,2340,1284,33,257,32,16384,513]

theorem envBound54613 : H12AffineFastState.Bounded env54613 := by
  intro p hp
  have h : env54613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54612_54613 : H12AffineEnvironment.transform 14 0 env54612 = env54613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54612 == env54613) = true)

theorem identity54613 : scanCanonicalize (H12AffineFastState.compose env54613 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54613 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54614 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5157,0,263,5173,2340,1025,1,4405,33,17,2,268,17,2048,5172,4097,2340,1284,33,257,32,5157,513]

theorem envBound54614 : H12AffineFastState.Bounded env54614 := by
  intro p hp
  have h : env54614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54613_54614 : H12AffineEnvironment.transform 13 5157 env54613 = env54614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54613 == env54614) = true)

def env54615 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,268,2837,0,263,2821,2340,1025,1,3589,33,17,2,268,17,2048,2820,3889,2340,1284,33,257,32,2837,513]

theorem envBound54615 : H12AffineFastState.Bounded env54615 := by
  intro p hp
  have h : env54615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54614_54615 : H12AffineEnvironment.transform 11 3888 env54614 = env54615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env54614 == env54615) = true)

def env54616 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,268,1045,0,263,1029,1572,1025,1,261,33,17,2,268,17,1792,1028,49,1572,1284,33,257,32,1045,513]

theorem envBound54616 : H12AffineFastState.Bounded env54616 := by
  intro p hp
  have h : env54616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54615_54616 : H12AffineEnvironment.transform 10 1792 env54615 = env54616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env54615 == env54616) = true)

theorem identity54616 : scanCanonicalize (H12AffineFastState.compose env54616 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound54616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54617 : List Nat := [2,4,8,16,32,16,8,256,512,516,260,48,268,529,0,263,513,32,517,1,261,33,17,2,268,17,260,512,49,32,768,33,257,32,529,513]

theorem envBound54617 : H12AffineFastState.Bounded env54617 := by
  intro p hp
  have h : env54617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54616_54617 : H12AffineEnvironment.transform 9 516 env54616 = env54617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env54616 == env54617) = true)

def env54618 : List Nat := [2,4,8,16,32,16,8,256,48,52,260,48,268,33,0,263,49,32,53,1,261,33,17,2,268,17,260,48,49,32,304,33,257,32,33,49]

theorem envBound54618 : H12AffineFastState.Bounded env54618 := by
  intro p hp
  have h : env54618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54617_54618 : H12AffineEnvironment.transform 8 48 env54617 = env54618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54617 == env54618) = true)

theorem identity54618 : scanCanonicalize (H12AffineFastState.compose env54618 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound54618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54619 : List Nat := [2,4,8,16,32,16,8,62,48,52,58,48,50,33,0,57,49,32,53,1,59,33,17,2,50,17,58,48,49,32,14,33,63,32,33,49]

theorem envBound54619 : H12AffineFastState.Bounded env54619 := by
  intro p hp
  have h : env54619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54618_54619 : H12AffineEnvironment.transform 7 62 env54618 = env54619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env54618 == env54619) = true)

def leafEnv54619 : List Nat := [2,4,8,16,32,16,8,62,48,52,58,48,50,33,0,57,49,32,53,1,59,33,17,2,15,50,1,17,58,48,49,32,14,33,63,32,5,57,33,49,1,59,0]

def active54619 : List Nat := [0,1,2,3,4]

def tree54619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54619 : H12WitnessSearch.Good tree54619 := H12GlobalWitnessIndex.good

theorem leafIdentity54619 : H12AffineFastState.composeSystem env54619 rootObs = leafEnv54619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54619 rootObs == leafEnv54619) = true)

theorem terminalChecked54619 : H12PackedTerminal.terminalCheckFast leafEnv54619 active54619 tree54619 = true := by decide +kernel

def env54620 : List Nat := [2,4,8,16,32,16,8,256,49,53,260,48,268,32,0,263,48,32,52,1,261,33,17,2,268,17,260,49,49,32,305,33,257,32,32,48]

theorem envBound54620 : H12AffineFastState.Bounded env54620 := by
  intro p hp
  have h : env54620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54617_54620 : H12AffineEnvironment.transform 8 49 env54617 = env54620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54617 == env54620) = true)

def env54621 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,268,1044,0,263,1028,1573,1025,1,260,33,17,2,268,17,1793,1029,48,1573,1284,33,257,32,1044,513]

theorem envBound54621 : H12AffineFastState.Bounded env54621 := by
  intro p hp
  have h : env54621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54615_54621 : H12AffineEnvironment.transform 10 1793 env54615 = env54621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env54615 == env54621) = true)

theorem identity54621 : scanCanonicalize (H12AffineFastState.compose env54621 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound54621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54622 : List Nat := [2,4,8,16,32,16,8,256,276,1024,1045,49,268,1044,0,263,1028,1329,1025,1,260,33,17,2,268,17,1045,1029,48,1329,1284,33,257,32,1044,277]

theorem envBound54622 : H12AffineFastState.Bounded env54622 := by
  intro p hp
  have h : env54622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54621_54622 : H12AffineEnvironment.transform 8 276 env54621 = env54622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54621 == env54622) = true)

def env54623 : List Nat := [2,4,8,16,32,16,8,256,276,52,33,49,268,32,0,263,48,261,53,1,260,33,17,2,268,17,33,49,48,261,304,33,257,32,32,277]

theorem envBound54623 : H12AffineFastState.Bounded env54623 := by
  intro p hp
  have h : env54623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54622_54623 : H12AffineEnvironment.transform 9 52 env54622 = env54623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54622 == env54623) = true)

theorem identity54623 : scanCanonicalize (H12AffineFastState.compose env54623 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54624 : List Nat := [2,4,8,11,32,11,8,256,271,47,33,42,268,32,0,263,43,261,46,1,260,33,10,2,268,10,33,42,43,261,299,33,257,32,32,270]

theorem envBound54624 : H12AffineFastState.Bounded env54624 := by
  intro p hp
  have h : env54624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54623_54624 : H12AffineEnvironment.transform 3 11 env54623 = env54624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54623 == env54624) = true)

def leafEnv54624 : List Nat := [2,4,8,11,32,11,8,256,271,47,33,42,268,32,0,263,43,261,46,1,260,33,10,2,298,268,1,10,33,42,43,261,299,33,257,32,5,263,32,270,1,260,0]

def active54624 : List Nat := [0,1,2,4,7]

def tree54624 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54624 : H12WitnessSearch.Good tree54624 := H12GlobalWitnessIndex.good

theorem leafIdentity54624 : H12AffineFastState.composeSystem env54624 rootObs = leafEnv54624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54624 rootObs == leafEnv54624) = true)

theorem terminalChecked54624 : H12PackedTerminal.terminalCheckFast leafEnv54624 active54624 tree54624 = true := by decide +kernel

def env54625 : List Nat := [2,4,8,16,32,16,8,256,276,53,32,49,268,33,0,263,49,260,52,1,260,33,17,2,268,17,32,48,48,260,305,33,257,32,33,277]

theorem envBound54625 : H12AffineFastState.Bounded env54625 := by
  intro p hp
  have h : env54625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54622_54625 : H12AffineEnvironment.transform 9 53 env54622 = env54625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54622 == env54625) = true)

def env54626 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,268,2836,0,263,2820,2340,1025,1,3588,33,17,2,268,17,2048,2821,3888,2340,1284,33,257,32,2836,513]

theorem envBound54626 : H12AffineFastState.Bounded env54626 := by
  intro p hp
  have h : env54626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54614_54626 : H12AffineEnvironment.transform 11 3889 env54614 = env54626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env54614 == env54626) = true)

def env54627 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,268,1044,0,263,1028,1572,1025,1,260,33,17,2,268,17,1792,1029,48,1572,1284,33,257,32,1044,513]

theorem envBound54627 : H12AffineFastState.Bounded env54627 := by
  intro p hp
  have h : env54627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54626_54627 : H12AffineEnvironment.transform 10 1792 env54626 = env54627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env54626 == env54627) = true)

theorem identity54627 : scanCanonicalize (H12AffineFastState.compose env54627 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound54627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54628 : List Nat := [2,4,8,16,32,16,8,256,49,1024,1329,49,268,1044,0,263,1028,1045,1025,1,260,33,17,2,268,17,1329,1029,48,1045,1284,33,257,32,1044,48]

theorem envBound54628 : H12AffineFastState.Bounded env54628 := by
  intro p hp
  have h : env54628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54627_54628 : H12AffineEnvironment.transform 8 49 env54627 = env54628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54627 == env54628) = true)

def env54629 : List Nat := [2,4,8,16,32,16,8,256,49,52,261,49,268,32,0,263,48,33,53,1,260,33,17,2,268,17,261,49,48,33,304,33,257,32,32,48]

theorem envBound54629 : H12AffineFastState.Bounded env54629 := by
  intro p hp
  have h : env54629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54628_54629 : H12AffineEnvironment.transform 9 52 env54628 = env54629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54628 == env54629) = true)

theorem identity54629 : scanCanonicalize (H12AffineFastState.compose env54629 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound54629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54630 : List Nat := [2,4,8,16,32,16,8,62,49,52,59,49,50,32,0,57,48,33,53,1,58,33,17,2,50,17,59,49,48,33,14,33,63,32,32,48]

theorem envBound54630 : H12AffineFastState.Bounded env54630 := by
  intro p hp
  have h : env54630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54629_54630 : H12AffineEnvironment.transform 7 62 env54629 = env54630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env54629 == env54630) = true)

def leafEnv54630 : List Nat := [2,4,8,16,32,16,8,62,49,52,59,49,50,32,0,57,48,33,53,1,58,33,17,2,15,50,1,17,59,49,48,33,14,33,63,32,5,57,32,48,1,58,0]

def active54630 : List Nat := [0,1,2,3,4]

def tree54630 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54630 : H12WitnessSearch.Good tree54630 := H12GlobalWitnessIndex.good

theorem leafIdentity54630 : H12AffineFastState.composeSystem env54630 rootObs = leafEnv54630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54630 rootObs == leafEnv54630) = true)

theorem terminalChecked54630 : H12PackedTerminal.terminalCheckFast leafEnv54630 active54630 tree54630 = true := by decide +kernel

def env54631 : List Nat := [2,4,8,16,32,16,8,256,49,53,260,49,268,33,0,263,49,32,52,1,260,33,17,2,268,17,260,48,48,32,305,33,257,32,33,48]

theorem envBound54631 : H12AffineFastState.Bounded env54631 := by
  intro p hp
  have h : env54631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54628_54631 : H12AffineEnvironment.transform 9 53 env54628 = env54631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54628 == env54631) = true)

def env54632 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,268,1045,0,263,1029,1573,1025,1,261,33,17,2,268,17,1793,1028,49,1573,1284,33,257,32,1045,513]

theorem envBound54632 : H12AffineFastState.Bounded env54632 := by
  intro p hp
  have h : env54632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54626_54632 : H12AffineEnvironment.transform 10 1793 env54626 = env54632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env54626 == env54632) = true)

theorem identity54632 : scanCanonicalize (H12AffineFastState.compose env54632 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound54632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54633 : List Nat := [2,4,8,16,32,16,8,256,512,801,32,48,268,820,0,263,804,260,800,1,261,33,17,2,268,17,32,805,49,260,549,33,257,32,820,513]

theorem envBound54633 : H12AffineFastState.Bounded env54633 := by
  intro p hp
  have h : env54633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54632_54633 : H12AffineEnvironment.transform 9 801 env54632 = env54633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env54632 == env54633) = true)

def env54634 : List Nat := [2,4,8,16,32,16,8,256,276,53,32,48,268,32,0,263,48,260,52,1,261,33,17,2,268,17,32,49,49,260,305,33,257,32,32,277]

theorem envBound54634 : H12AffineFastState.Bounded env54634 := by
  intro p hp
  have h : env54634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54633_54634 : H12AffineEnvironment.transform 8 276 env54633 = env54634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54633 == env54634) = true)

def env54635 : List Nat := [2,4,8,16,32,16,8,256,277,52,32,48,268,33,0,263,49,260,53,1,261,33,17,2,268,17,32,48,49,260,304,33,257,32,33,276]

theorem envBound54635 : H12AffineFastState.Bounded env54635 := by
  intro p hp
  have h : env54635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54633_54635 : H12AffineEnvironment.transform 8 277 env54633 = env54635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54633 == env54635) = true)

theorem identity54635 : scanCanonicalize (H12AffineFastState.compose env54635 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54636 : List Nat := [2,4,8,11,32,11,8,256,270,47,32,43,268,33,0,263,42,260,46,1,261,33,10,2,268,10,32,43,42,260,299,33,257,32,33,271]

theorem envBound54636 : H12AffineFastState.Bounded env54636 := by
  intro p hp
  have h : env54636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54635_54636 : H12AffineEnvironment.transform 3 11 env54635 = env54636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54635 == env54636) = true)

def leafEnv54636 : List Nat := [2,4,8,11,32,11,8,256,270,47,32,43,268,33,0,263,42,260,46,1,261,33,10,2,298,268,1,10,32,43,42,260,299,33,257,32,5,263,33,271,1,261,0]

def active54636 : List Nat := [0,1,2,4,7]

def tree54636 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54636 : H12WitnessSearch.Good tree54636 := H12GlobalWitnessIndex.good

theorem leafIdentity54636 : H12AffineFastState.composeSystem env54636 rootObs = leafEnv54636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54636 rootObs == leafEnv54636) = true)

theorem terminalChecked54636 : H12PackedTerminal.terminalCheckFast leafEnv54636 active54636 tree54636 = true := by decide +kernel

def env54637 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188703,8192,16,4409655,2319643,2233600,43048,75022,6521863,257,2188602,2196502,513]

theorem envBound54637 : H12AffineFastState.Bounded env54637 := by
  intro p hp
  have h : env54637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54606_54637 : H12AffineEnvironment.transform 5 17 env54606 = env54637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54606 == env54637) = true)

theorem identity54637 : scanCanonicalize (H12AffineFastState.compose env54637 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 2270252) := by decide +kernel

theorem selectedBound54637 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env54638 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2270252,147457,188703,8192,16,2223387,2319643,2233600,43048,75022,73771,257,2188602,2196502,513]

theorem envBound54638 : H12AffineFastState.Bounded env54638 := by
  intro p hp
  have h : env54638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54637_54638 : H12AffineEnvironment.transform 21 2270252 env54637 = env54638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2270252 env54637 == env54638) = true)

theorem identity54638 : scanCanonicalize (H12AffineFastState.compose env54638 (packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound54638 : packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54639 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,221242,147457,188703,8192,16,10509,172301,250134,43048,75022,73771,257,41260,16384,513]

theorem envBound54639 : H12AffineFastState.Bounded env54639 := by
  intro p hp
  have h : env54639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54638_54639 : H12AffineEnvironment.transform 20 115734 env54638 = env54639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env54638 == env54639) = true)

theorem identity54639 : scanCanonicalize (H12AffineFastState.compose env54639 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound54639 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env54640 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10280,1025,8461,91418,221242,147457,147475,8192,16,10509,131073,225306,2340,75022,73771,257,32,16384,513]

theorem envBound54640 : H12AffineFastState.Bounded env54640 := by
  intro p hp
  have h : env54640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54639_54640 : H12AffineEnvironment.transform 14 8460 env54639 = env54640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env54639 == env54640) = true)

theorem identity54640 : scanCanonicalize (H12AffineFastState.compose env54640 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound54640 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54641 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,90138,10280,1025,8461,91418,32,73755,73737,8192,16,10509,90139,4096,2340,75022,73771,257,32,16384,513]

theorem envBound54641 : H12AffineFastState.Bounded env54641 := by
  intro p hp
  have h : env54641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54640_54641 : H12AffineEnvironment.transform 16 90138 env54640 = env54641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env54640 == env54641) = true)

theorem identity54641 : scanCanonicalize (H12AffineFastState.compose env54641 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound54641 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54642 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,262,24860,10280,1025,8461,25628,32,8477,8463,8192,16,10509,24861,4096,2340,9224,8493,257,32,16384,513]

theorem envBound54642 : H12AffineFastState.Bounded env54642 := by
  intro p hp
  have h : env54642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54641_54642 : H12AffineEnvironment.transform 15 262 env54641 = env54642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env54641 == env54642) = true)

theorem identity54642 : scanCanonicalize (H12AffineFastState.compose env54642 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54643 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1025,0,17681,32,16,2,269,16,2048,16400,4096,2340,1285,32,257,32,16384,513]

theorem envBound54643 : H12AffineFastState.Bounded env54643 := by
  intro p hp
  have h : env54643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54642_54643 : H12AffineEnvironment.transform 12 269 env54642 = env54643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54642 == env54643) = true)

theorem identity54643 : scanCanonicalize (H12AffineFastState.compose env54643 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound54643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54644 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,4144,1,262,4129,2341,1025,0,5409,32,16,2,269,16,2048,4128,4096,2340,1285,32,257,32,4144,513]

theorem envBound54644 : H12AffineFastState.Bounded env54644 := by
  intro p hp
  have h : env54644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54643_54644 : H12AffineEnvironment.transform 13 4144 env54643 = env54644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env54643 == env54644) = true)

theorem identity54644 : scanCanonicalize (H12AffineFastState.compose env54644 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3630) := by decide +kernel

theorem selectedBound54644 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54645 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3630,269,3614,1,262,3599,2341,1025,0,2831,32,16,2,269,16,2048,3598,3630,2340,1285,32,257,32,3614,513]

theorem envBound54645 : H12AffineFastState.Bounded env54645 := by
  intro p hp
  have h : env54645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54644_54645 : H12AffineEnvironment.transform 11 3630 env54644 = env54645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3630 env54644 == env54645) = true)

theorem identity54645 : scanCanonicalize (H12AffineFastState.compose env54645 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54645 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54646 : List Nat := [2,4,8,16,10,17,8,256,512,1024,2048,3588,269,3614,1,262,3599,2319,1025,0,2831,10,16,2,269,16,2048,3598,3588,2318,1285,10,257,10,3614,513]

theorem envBound54646 : H12AffineFastState.Bounded env54646 := by
  intro p hp
  have h : env54646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54645_54646 : H12AffineEnvironment.transform 4 10 env54645 = env54646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54645 == env54646) = true)

theorem identity54646 : scanCanonicalize (H12AffineFastState.compose env54646 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound54646 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54647 : List Nat := [2,4,8,16,10,17,8,256,512,517,2048,2049,269,2075,1,262,2058,2319,516,0,2831,10,16,2,269,16,2048,2059,2049,2318,768,10,257,10,2075,513]

theorem envBound54647 : H12AffineFastState.Bounded env54647 := by
  intro p hp
  have h : env54647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54646_54647 : H12AffineEnvironment.transform 9 517 env54646 = env54647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env54646 == env54647) = true)

theorem identity54647 : scanCanonicalize (H12AffineFastState.compose env54647 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound54647 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54648 : List Nat := [2,4,8,16,10,17,8,256,512,517,270,271,269,277,1,262,260,1,516,0,513,10,16,2,269,16,270,261,271,0,768,10,257,10,277,513]

theorem envBound54648 : H12AffineFastState.Bounded env54648 := by
  intro p hp
  have h : env54648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54647_54648 : H12AffineEnvironment.transform 10 270 env54647 = env54648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env54647 == env54648) = true)

theorem identity54648 : scanCanonicalize (H12AffineFastState.compose env54648 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54648 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54649 : List Nat := [2,4,8,16,10,17,8,21,512,517,27,26,24,0,1,19,17,1,516,0,513,10,16,2,24,16,27,16,26,0,533,10,20,10,0,513]

theorem envBound54649 : H12AffineFastState.Bounded env54649 := by
  intro p hp
  have h : env54649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54648_54649 : H12AffineEnvironment.transform 7 21 env54648 = env54649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54648 == env54649) = true)

theorem identity54649 : scanCanonicalize (H12AffineFastState.compose env54649 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54649 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env54650 : List Nat := [2,4,8,1,10,0,8,4,512,517,10,11,9,0,1,2,0,1,516,0,513,10,1,2,9,1,10,1,11,0,516,10,5,10,0,513]

theorem envBound54650 : H12AffineFastState.Bounded env54650 := by
  intro p hp
  have h : env54650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54649_54650 : H12AffineEnvironment.transform 3 1 env54649 = env54650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54649 == env54650) = true)

theorem identity54650 : scanCanonicalize (H12AffineFastState.compose env54650 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54650 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54651 : List Nat := [2,3,8,1,10,0,8,3,512,514,10,11,9,0,1,2,0,1,515,0,513,10,1,2,9,1,10,1,11,0,515,10,2,10,0,513]

theorem envBound54651 : H12AffineFastState.Bounded env54651 := by
  intro p hp
  have h : env54651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54650_54651 : H12AffineEnvironment.transform 1 3 env54650 = env54651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54650 == env54651) = true)

def env54652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616168,18973701,10507600,8579112,25265168,23160136,257,27378725,27337992,25207631]

theorem envBound54652 : H12AffineFastState.Bounded env54652 := by
  intro p hp
  have h : env54652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54501_54652 : H12AffineEnvironment.transform 6 9 env54501 = env54652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54501 == env54652) = true)

theorem identity54652 : scanCanonicalize (H12AffineFastState.compose env54652 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54652 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env54653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,4194304,8388608,16777216,8193,65,29575540,18949465,10507600,8538484,25240908,23160136,257,27354489,27337992,25166355]

theorem envBound54653 : H12AffineFastState.Bounded env54653 := by
  intro p hp
  have h : env54653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54652_54653 : H12AffineEnvironment.transform 14 8540 env54652 = env54653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54652 == env54653) = true)

theorem identity54653 : scanCanonicalize (H12AffineFastState.compose env54653 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8609801) := by decide +kernel

theorem selectedBound54653 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,4194304,8388608,8609801,8193,65,4204925,10634576,10507600,8538484,148805,14812481,257,2229616,2245889,221722]

theorem envBound54654 : H12AffineFastState.Bounded env54654 := by
  intro p hp
  have h : env54654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54653_54654 : H12AffineEnvironment.transform 23 8609801 env54653 = env54654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8609801 env54653 == env54654) = true)

theorem identity54654 : scanCanonicalize (H12AffineFastState.compose env54654 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4415531) := by decide +kernel

theorem selectedBound54654 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env54655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,4194304,4415531,4194338,8193,65,4204925,6366587,6501755,4270431,148805,2188650,257,2229616,2245889,221722]

theorem envBound54655 : H12AffineFastState.Bounded env54655 := by
  intro p hp
  have h : env54655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54654_54655 : H12AffineEnvironment.transform 22 4415531 env54654 = env54655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415531 env54654 == env54655) = true)

theorem identity54655 : scanCanonicalize (H12AffineFastState.compose env54655 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54655 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10281,1025,8541,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6313312,4270431,75102,2188650,257,2188651,2172186,513]

theorem envBound54656 : H12AffineFastState.Bounded env54656 := by
  intro p hp
  have h : env54656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54655_54656 : H12AffineEnvironment.transform 16 90139 env54655 = env54656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54655 == env54656) = true)

theorem identity54656 : scanCanonicalize (H12AffineFastState.compose env54656 (packedSelected [2,4,6,9,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound54656 : packedSelected [2,4,6,9,17,18] rootPS < 2^1333 := by decide +kernel

def env54657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8540,65536,76926,10281,1025,8541,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6297861,4270431,75102,2173199,257,2173198,2172186,513]

theorem envBound54657 : H12AffineFastState.Bounded env54657 := by
  intro p hp
  have h : env54657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54656_54657 : H12AffineEnvironment.transform 13 3173 env54656 = env54657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env54656 == env54657) = true)

theorem identity54657 : scanCanonicalize (H12AffineFastState.compose env54657 (packedSelected [3,5,10,11,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 79194) := by decide +kernel

theorem selectedBound54657 : packedSelected [3,5,10,11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8540,65536,76926,10281,1025,8541,79194,4194304,4194352,4194338,8193,65,4204925,4198433,4271199,4270431,75102,7253,257,7252,4160,513]

theorem envBound54658 : H12AffineFastState.Bounded env54658 := by
  intro p hp
  have h : env54658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54657_54658 : H12AffineEnvironment.transform 20 79194 env54657 = env54658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79194 env54657 == env54658) = true)

theorem identity54658 : scanCanonicalize (H12AffineFastState.compose env54658 (packedSelected [2,6,7,17,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 15704) := by decide +kernel

theorem selectedBound54658 : packedSelected [2,6,7,17,23,27] rootPS < 2^1333 := by decide +kernel

def env54659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8540,65536,76926,10281,1025,8541,79194,15704,15720,15738,8193,65,5157,11641,69895,70663,75102,7253,257,7252,4160,513]

theorem envBound54659 : H12AffineFastState.Bounded env54659 := by
  intro p hp
  have h : env54659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54658_54659 : H12AffineEnvironment.transform 21 15704 env54658 = env54659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 15704 env54658 == env54659) = true)

theorem identity54659 : scanCanonicalize (H12AffineFastState.compose env54659 (packedSelected [5,7,8,9,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound54659 : packedSelected [5,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env54660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8540,7538,12556,10281,1025,8541,10280,15704,15720,15738,8193,65,5157,11641,3189,2421,14380,7253,257,7252,4160,513]

theorem envBound54660 : H12AffineFastState.Bounded env54660 := by
  intro p hp
  have h : env54660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54659_54660 : H12AffineEnvironment.transform 15 7538 env54659 = env54660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env54659 == env54660) = true)

theorem identity54660 : scanCanonicalize (H12AffineFastState.compose env54660 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54660 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,3173,80,7538,4096,2341,1025,81,2340,7252,7268,7286,269,65,5157,3189,3189,2421,6432,7253,257,7252,4160,513]

theorem envBound54661 : H12AffineFastState.Bounded env54661 := by
  intro p hp
  have h : env54661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54660_54661 : H12AffineEnvironment.transform 12 268 env54660 = env54661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54660 == env54661) = true)

theorem identity54661 : scanCanonicalize (H12AffineFastState.compose env54661 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound54661 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env54662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,268,3173,80,1379,2065,2341,1025,81,2340,1093,1141,1127,269,65,3124,3189,3189,2421,305,1092,257,1093,2129,513]

theorem envBound54662 : H12AffineFastState.Bounded env54662 := by
  intro p hp
  have h : env54662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54661_54662 : H12AffineEnvironment.transform 11 2065 env54661 = env54662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env54661 == env54662) = true)

theorem identity54662 : scanCanonicalize (H12AffineFastState.compose env54662 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54662 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54663 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,268,3124,1,1330,2065,2341,1025,0,2340,1044,1060,1078,269,16,3124,3108,3108,2340,305,1045,257,1044,2048,513]

theorem envBound54663 : H12AffineFastState.Bounded env54663 := by
  intro p hp
  have h : env54663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54662_54663 : H12AffineEnvironment.transform 5 17 env54662 = env54663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54662 == env54663) = true)

theorem identity54663 : scanCanonicalize (H12AffineFastState.compose env54663 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54663 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54664 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2065,268,2049,1,263,2065,2341,52,0,2340,33,17,3,269,16,2049,2065,2065,2340,305,32,257,33,2048,513]

theorem envBound54664 : H12AffineFastState.Bounded env54664 := by
  intro p hp
  have h : env54664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54663_54664 : H12AffineEnvironment.transform 9 53 env54663 = env54664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54663 == env54664) = true)

theorem identity54664 : scanCanonicalize (H12AffineFastState.compose env54664 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54664 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54665 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2065,41,2049,1,34,2065,2048,52,0,2049,33,17,3,40,16,2049,2065,2065,2049,20,32,36,33,2048,513]

theorem envBound54665 : H12AffineFastState.Bounded env54665 := by
  intro p hp
  have h : env54665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54664_54665 : H12AffineEnvironment.transform 7 37 env54664 = env54665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54664 == env54665) = true)

theorem identity54665 : scanCanonicalize (H12AffineFastState.compose env54665 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54666 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,41,49,1,34,33,48,52,0,49,33,17,3,40,16,49,33,33,49,20,32,36,33,48,513]

theorem envBound54666 : H12AffineFastState.Bounded env54666 := by
  intro p hp
  have h : env54666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54665_54666 : H12AffineEnvironment.transform 10 48 env54665 = env54666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54665 == env54666) = true)

def leafEnv54666 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,41,49,1,34,33,48,52,0,49,33,17,3,21,40,1,16,49,33,33,49,20,32,36,33,5,35,48,513,1,48,0]

def active54666 : List Nat := [0,1,2,3,4,8]

def tree54666 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54666 : H12WitnessSearch.Good tree54666 := H12GlobalWitnessIndex.good

theorem leafIdentity54666 : H12AffineFastState.composeSystem env54666 rootObs = leafEnv54666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54666 rootObs == leafEnv54666) = true)

theorem terminalChecked54666 : H12PackedTerminal.terminalCheckFast leafEnv54666 active54666 tree54666 = true := by decide +kernel

def env54667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound54667 : H12AffineFastState.Bounded env54667 := by
  intro p hp
  have h : env54667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54272_54667 : H12AffineEnvironment.transform 26 30393345 env54272 = env54667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env54272 == env54667) = true)

def env54668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound54668 : H12AffineFastState.Bounded env54668 := by
  intro p hp
  have h : env54668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54667_54668 : H12AffineEnvironment.transform 18 1024 env54667 = env54668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env54667 == env54668) = true)

theorem identity54668 : scanCanonicalize (H12AffineFastState.compose env54668 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534881) := by decide +kernel

theorem selectedBound54668 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,16777216,8328,65,23162336,18973837,456881,2125280,19343857,23160256,256,17262925,17271017,19271206]

theorem envBound54669 : H12AffineFastState.Bounded env54669 := by
  intro p hp
  have h : env54669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54668_54669 : H12AffineEnvironment.transform 22 2534881 env54668 = env54669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534881 env54668 == env54669) = true)

def env54670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,474220,8328,65,6705548,2537697,456881,2125280,2102685,6707628,256,21793,46213,2175562]

theorem envBound54670 : H12AffineFastState.Bounded env54670 := by
  intro p hp
  have h : env54670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54669_54670 : H12AffineEnvironment.transform 23 474220 env54669 = env54670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474220 env54669 == env54670) = true)

def env54671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101329,98780,8328,65,6351932,2098513,17665,2125280,2102685,6349852,256,21793,46213,2175562]

theorem envBound54671 : H12AffineFastState.Bounded env54671 := by
  intro p hp
  have h : env54671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54670_54671 : H12AffineEnvironment.transform 17 179632 env54670 = env54671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env54670 == env54671) = true)

def env54672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,17,98780,8328,65,4258940,5393,17665,32160,1501,4256860,256,21793,46213,74250]

theorem envBound54672 : H12AffineFastState.Bounded env54672 := by
  intro p hp
  have h : env54672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54671_54672 : H12AffineEnvironment.transform 20 4160 env54671 = env54672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54671 == env54672) = true)

theorem identity54672 : scanCanonicalize (H12AffineFastState.compose env54672 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound54672 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,243002,17,98780,8328,65,215366,5393,17665,32160,1501,213350,256,21793,46213,74250]

theorem envBound54673 : H12AffineFastState.Bounded env54673 := by
  intro p hp
  have h : env54673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54672_54673 : H12AffineEnvironment.transform 21 243002 env54672 = env54673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env54672 == env54673) = true)

def env54674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,243002,17,98644,8192,65,215366,5393,17665,32040,1365,213350,256,21793,46093,74250]

theorem envBound54674 : H12AffineFastState.Bounded env54674 := by
  intro p hp
  have h : env54674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54673_54674 : H12AffineEnvironment.transform 6 8 env54673 = env54674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54673 == env54674) = true)

theorem identity54674 : scanCanonicalize (H12AffineFastState.compose env54674 (packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound54674 : packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS < 2^1333 := by decide +kernel

def env54675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,114966,97326,1024,32769,4160,29740,17,98644,8192,65,34896,5393,17665,32040,1365,32880,256,21793,46093,74250]

theorem envBound54675 : H12AffineFastState.Bounded env54675 := by
  intro p hp
  have h : env54675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54674_54675 : H12AffineEnvironment.transform 16 114966 env54674 = env54675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env54674 == env54675) = true)

theorem identity54675 : scanCanonicalize (H12AffineFastState.compose env54675 (packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54675 : packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS < 2^1333 := by decide +kernel

def env54676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,57629,23589,1024,32769,4160,29740,17,41311,8192,65,34896,5393,17665,32040,1365,32880,256,21793,46093,513]

theorem envBound54676 : H12AffineFastState.Bounded env54676 := by
  intro p hp
  have h : env54676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54675_54676 : H12AffineEnvironment.transform 15 8203 env54675 = env54676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54675 == env54676) = true)

theorem identity54676 : scanCanonicalize (H12AffineFastState.compose env54676 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound54676 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,8203,16400,23589,1024,8460,4160,29740,17,82,8192,65,10589,5393,17665,32040,1365,8573,256,21793,5376,513]

theorem envBound54677 : H12AffineFastState.Bounded env54677 := by
  intro p hp
  have h : env54677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54676_54677 : H12AffineEnvironment.transform 14 8461 env54676 = env54677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env54676 == env54677) = true)

theorem identity54677 : scanCanonicalize (H12AffineFastState.compose env54677 (packedSelected [0,2,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54677 : packedSelected [0,2,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env54678 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8313,8203,16400,23589,1024,8312,4160,29740,17,82,8192,65,10281,5221,17525,31836,1057,8201,116,21589,5236,513]

theorem envBound54678 : H12AffineFastState.Bounded env54678 := by
  intro p hp
  have h : env54678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54677_54678 : H12AffineEnvironment.transform 7 116 env54677 = env54678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54677 == env54678) = true)

theorem identity54678 : scanCanonicalize (H12AffineFastState.compose env54678 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54678 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54679 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,80,34,16400,23589,1024,81,4160,21509,17,82,41,65,2048,5221,17525,23669,1057,32,116,21589,5236,513]

theorem envBound54679 : H12AffineFastState.Bounded env54679 := by
  intro p hp
  have h : env54679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54678_54679 : H12AffineEnvironment.transform 12 41 env54678 = env54679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54678 == env54679) = true)

theorem identity54679 : scanCanonicalize (H12AffineFastState.compose env54679 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound54679 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env54680 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5156,80,34,5172,2049,1024,81,4160,33,17,82,41,65,2048,5221,4177,2129,1057,32,116,113,5236,513]

theorem envBound54680 : H12AffineFastState.Bounded env54680 := by
  intro p hp
  have h : env54680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54679_54680 : H12AffineEnvironment.transform 13 5156 env54679 = env54680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env54679 == env54680) = true)

theorem identity54680 : scanCanonicalize (H12AffineFastState.compose env54680 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54681 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5172,2049,1024,1,4112,33,17,2,41,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound54681 : H12AffineFastState.Bounded env54681 := by
  intro p hp
  have h : env54681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54680_54681 : H12AffineEnvironment.transform 5 16 env54680 = env54681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54680 == env54681) = true)

def env54682 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,0,34,1028,2049,1024,1,32,33,17,2,41,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound54682 : H12AffineFastState.Bounded env54682 := by
  intro p hp
  have h : env54682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54681_54682 : H12AffineEnvironment.transform 11 48 env54681 = env54682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54681 == env54682) = true)

theorem identity54682 : scanCanonicalize (H12AffineFastState.compose env54682 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound54682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54683 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,48,41,529,0,34,513,2049,517,1,32,33,17,2,41,17,2048,512,49,2049,548,32,36,33,529,513]

theorem envBound54683 : H12AffineFastState.Bounded env54683 := by
  intro p hp
  have h : env54683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54682_54683 : H12AffineEnvironment.transform 9 517 env54682 = env54683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env54682 == env54683) = true)

def env54684 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,41,33,0,34,49,2049,53,1,32,33,17,2,41,17,2048,48,49,2049,20,32,36,33,33,49]

theorem envBound54684 : H12AffineFastState.Bounded env54684 := by
  intro p hp
  have h : env54684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54683_54684 : H12AffineEnvironment.transform 8 48 env54683 = env54684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54683 == env54684) = true)

def env54685 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,41,32,0,34,48,2049,52,1,32,33,17,2,41,17,2048,49,49,2049,21,32,36,33,32,48]

theorem envBound54685 : H12AffineFastState.Bounded env54685 := by
  intro p hp
  have h : env54685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54683_54685 : H12AffineEnvironment.transform 8 49 env54683 = env54685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54683 == env54685) = true)

theorem identity54685 : scanCanonicalize (H12AffineFastState.compose env54685 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54686 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,42,41,32,0,34,42,2049,46,1,32,33,11,2,41,11,2048,43,43,2049,15,32,36,33,32,42]

theorem envBound54686 : H12AffineFastState.Bounded env54686 := by
  intro p hp
  have h : env54686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54685_54686 : H12AffineEnvironment.transform 3 10 env54685 = env54686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54685 == env54686) = true)

def leafEnv54686 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,42,41,32,0,34,42,2049,46,1,32,33,11,2,15,41,1,11,2048,43,43,2049,15,32,36,33,4,34,32,42,1,32,0]

def active54686 : List Nat := [0,1,2,4,10]

def tree54686 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54686 : H12WitnessSearch.Good tree54686 := H12GlobalWitnessIndex.good

theorem leafIdentity54686 : H12AffineFastState.composeSystem env54686 rootObs = leafEnv54686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54686 rootObs == leafEnv54686) = true)

theorem terminalChecked54686 : H12PackedTerminal.terminalCheckFast leafEnv54686 active54686 tree54686 = true := by decide +kernel

def env54687 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,0,34,1029,2049,1024,1,33,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound54687 : H12AffineFastState.Bounded env54687 := by
  intro p hp
  have h : env54687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54681_54687 : H12AffineEnvironment.transform 11 49 env54681 = env54687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54681 == env54687) = true)

theorem identity54687 : scanCanonicalize (H12AffineFastState.compose env54687 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54688 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,49,41,1045,0,34,1029,2049,1024,1,33,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,49]

theorem envBound54688 : H12AffineFastState.Bounded env54688 := by
  intro p hp
  have h : env54688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54687_54688 : H12AffineEnvironment.transform 8 48 env54687 = env54688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54687 == env54688) = true)

def env54689 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,41,33,0,34,49,2049,52,1,33,33,17,2,41,17,2048,48,48,2049,21,32,36,33,33,49]

theorem envBound54689 : H12AffineFastState.Bounded env54689 := by
  intro p hp
  have h : env54689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54688_54689 : H12AffineEnvironment.transform 9 52 env54688 = env54689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54688 == env54689) = true)

theorem identity54689 : scanCanonicalize (H12AffineFastState.compose env54689 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54690 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,43,41,33,0,34,43,2049,46,1,33,33,11,2,41,11,2048,42,42,2049,15,32,36,33,33,43]

theorem envBound54690 : H12AffineFastState.Bounded env54690 := by
  intro p hp
  have h : env54690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54689_54690 : H12AffineEnvironment.transform 3 10 env54689 = env54690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54689 == env54690) = true)

def leafEnv54690 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,43,41,33,0,34,43,2049,46,1,33,33,11,2,15,41,1,11,2048,42,42,2049,15,32,36,33,4,34,33,43,1,33,0]

def active54690 : List Nat := [0,1,2,4,10]

def tree54690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54690 : H12WitnessSearch.Good tree54690 := H12GlobalWitnessIndex.good

theorem leafIdentity54690 : H12AffineFastState.composeSystem env54690 rootObs = leafEnv54690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54690 rootObs == leafEnv54690) = true)

theorem terminalChecked54690 : H12PackedTerminal.terminalCheckFast leafEnv54690 active54690 tree54690 = true := by decide +kernel

def env54691 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,41,32,0,34,48,2049,53,1,33,33,17,2,41,17,2048,49,48,2049,20,32,36,33,32,49]

end H12CloudChart0