import H12CloudChart0Data119

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env30440 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,309,348,81,373,343,65,292,321,372,0,341,16,374,348,65,293,16,356,81,20,113,257,112,292,513]

theorem envBound30440 : H12AffineFastState.Bounded env30440 := by
  intro p hp
  have h : env30440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30439_30440 : H12AffineEnvironment.transform 12 348 env30439 = env30440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30439 == env30440) = true)

def env30441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302891,2172250,2118977,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound30441 : H12AffineFastState.Bounded env30441 := by
  intro p hp
  have h : env30441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30430_30441 : H12AffineEnvironment.transform 6 9 env30430 = env30441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30430 == env30441) = true)

theorem identity30441 : scanCanonicalize (H12AffineFastState.compose env30441 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound30441 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env30442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115735,4194304,17,41311,8193,65,4302891,57677,102742,2420,75102,4194305,257,41341,16464,513]

theorem envBound30442 : H12AffineFastState.Bounded env30442 := by
  intro p hp
  have h : env30442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30441_30442 : H12AffineEnvironment.transform 20 115735 env30441 = env30442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env30441 == env30442) = true)

def env30443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91199,4194304,17,375,8193,65,4261891,16741,78206,2420,75102,4194305,257,341,16464,513]

theorem envBound30443 : H12AffineFastState.Bounded env30443 := by
  intro p hp
  have h : env30443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30442_30443 : H12AffineEnvironment.transform 14 8232 env30442 = env30443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env30442 == env30443) = true)

theorem identity30443 : scanCanonicalize (H12AffineFastState.compose env30443 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30443 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env30444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,65536,16401,2421,1025,0,82966,4194304,17,375,40,65,4261891,16741,69975,2420,66935,4194305,257,341,16464,513]

theorem envBound30444 : H12AffineFastState.Bounded env30444 := by
  intro p hp
  have h : env30444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30443_30444 : H12AffineEnvironment.transform 12 41 env30443 = env30444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30443 == env30444) = true)

theorem identity30444 : scanCanonicalize (H12AffineFastState.compose env30444 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30444 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,65536,16401,2421,1025,0,82966,32,17,375,40,65,67619,16741,69975,2420,66935,33,257,341,16464,513]

theorem envBound30445 : H12AffineFastState.Bounded env30445 := by
  intro p hp
  have h : env30445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30444_30445 : H12AffineEnvironment.transform 21 32 env30444 = env30445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30444 == env30445) = true)

theorem identity30445 : scanCanonicalize (H12AffineFastState.compose env30445 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30445 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env30446 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,65536,16401,2341,1025,0,82966,32,17,295,40,17,67619,16693,69895,2340,66855,33,257,261,16384,513]

theorem envBound30446 : H12AffineFastState.Bounded env30446 := by
  intro p hp
  have h : env30446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30445_30446 : H12AffineEnvironment.transform 5 16 env30445 = env30446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30445 == env30446) = true)

theorem identity30446 : scanCanonicalize (H12AffineFastState.compose env30446 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound30446 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,262,16401,2341,1025,0,17680,32,17,295,40,17,2341,16693,4097,2340,1057,33,257,261,16384,513]

theorem envBound30447 : H12AffineFastState.Bounded env30447 := by
  intro p hp
  have h : env30447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30446_30447 : H12AffineEnvironment.transform 15 262 env30446 = env30447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env30446 == env30447) = true)

theorem identity30447 : scanCanonicalize (H12AffineFastState.compose env30447 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound30447 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30448 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,6161,1,262,6144,2341,1025,0,7425,32,17,295,40,17,2341,6436,4097,2340,1057,33,257,261,6161,513]

theorem envBound30448 : H12AffineFastState.Bounded env30448 := by
  intro p hp
  have h : env30448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30447_30448 : H12AffineEnvironment.transform 13 6161 env30447 = env30448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env30447 == env30448) = true)

theorem identity30448 : scanCanonicalize (H12AffineFastState.compose env30448 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound30448 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30449 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,41,293,1,262,308,2341,1025,0,1077,32,17,295,40,17,2341,16,2357,2340,1057,33,257,261,293,513]

theorem envBound30449 : H12AffineFastState.Bounded env30449 := by
  intro p hp
  have h : env30449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30448_30449 : H12AffineEnvironment.transform 11 2356 env30448 = env30449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env30448 == env30449) = true)

theorem identity30449 : scanCanonicalize (H12AffineFastState.compose env30449 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30449 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30450 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2356,41,293,1,262,308,2341,273,0,293,32,17,295,40,17,2341,16,2357,2340,305,33,257,261,293,513]

theorem envBound30450 : H12AffineFastState.Bounded env30450 := by
  intro p hp
  have h : env30450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30449_30450 : H12AffineEnvironment.transform 9 272 env30449 = env30450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30449 == env30450) = true)

theorem identity30450 : scanCanonicalize (H12AffineFastState.compose env30450 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30450 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30451 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,308,41,293,1,262,308,293,273,0,293,32,17,295,40,17,293,16,309,292,305,33,257,261,293,513]

theorem envBound30451 : H12AffineFastState.Bounded env30451 := by
  intro p hp
  have h : env30451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30450_30451 : H12AffineEnvironment.transform 10 0 env30450 = env30451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30450 == env30451) = true)

def env30452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91198,4194304,17,374,8193,65,4261890,16740,78207,2420,75102,4194305,257,340,16464,513]

theorem envBound30452 : H12AffineFastState.Bounded env30452 := by
  intro p hp
  have h : env30452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30442_30452 : H12AffineEnvironment.transform 14 8233 env30442 = env30452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env30442 == env30452) = true)

theorem identity30452 : scanCanonicalize (H12AffineFastState.compose env30452 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30452 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env30453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,372,65536,16401,2048,1025,373,83299,4194304,17,374,348,65,4261890,16740,69666,2420,66563,4194305,257,340,16464,513]

theorem envBound30453 : H12AffineFastState.Bounded env30453 := by
  intro p hp
  have h : env30453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30452_30453 : H12AffineEnvironment.transform 12 349 env30452 = env30453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30452 == env30453) = true)

theorem identity30453 : scanCanonicalize (H12AffineFastState.compose env30453 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30453 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env30454 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,65536,16401,2048,1025,0,82966,4194304,17,3,41,65,4261890,16401,69666,2049,66563,4194305,116,33,16464,513]

theorem envBound30454 : H12AffineFastState.Bounded env30454 := by
  intro p hp
  have h : env30454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30453_30454 : H12AffineEnvironment.transform 7 117 env30453 = env30454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30453 == env30454) = true)

theorem identity30454 : scanCanonicalize (H12AffineFastState.compose env30454 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound30454 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30455 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,34,16401,2048,1025,0,17460,4194304,17,3,41,65,4196384,16401,4096,2049,1057,4194305,116,33,16464,513]

theorem envBound30455 : H12AffineFastState.Bounded env30455 := by
  intro p hp
  have h : env30455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30454_30455 : H12AffineEnvironment.transform 15 34 env30454 = env30455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env30454 == env30455) = true)

theorem identity30455 : scanCanonicalize (H12AffineFastState.compose env30455 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30455 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30456 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,16384,1,34,16401,2048,1025,0,17460,4194304,17,3,41,16,4196384,16401,4096,2049,1057,4194305,37,33,16385,513]

theorem envBound30456 : H12AffineFastState.Bounded env30456 := by
  intro p hp
  have h : env30456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30455_30456 : H12AffineEnvironment.transform 5 17 env30455 = env30456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30455 == env30456) = true)

theorem identity30456 : scanCanonicalize (H12AffineFastState.compose env30456 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound30456 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30457 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2048,1025,0,4113,4194304,17,3,41,16,4196384,5172,4096,2049,1057,4194305,37,33,5156,513]

theorem envBound30457 : H12AffineFastState.Bounded env30457 := by
  intro p hp
  have h : env30457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30456_30457 : H12AffineEnvironment.transform 13 5157 env30456 = env30457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env30456 == env30457) = true)

theorem identity30457 : scanCanonicalize (H12AffineFastState.compose env30457 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30457 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30458 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2048,1025,0,4113,32,17,3,41,16,2048,5172,4096,2049,1057,33,37,33,5156,513]

theorem envBound30458 : H12AffineFastState.Bounded env30458 := by
  intro p hp
  have h : env30458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30457_30458 : H12AffineEnvironment.transform 21 32 env30457 = env30458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30457 == env30458) = true)

theorem identity30458 : scanCanonicalize (H12AffineFastState.compose env30458 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30459 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5125,1,2,5140,2048,1025,0,4113,0,17,3,9,16,2048,5140,4096,2049,1025,1,5,1,5124,513]

theorem envBound30459 : H12AffineFastState.Bounded env30459 := by
  intro p hp
  have h : env30459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30458_30459 : H12AffineEnvironment.transform 4 0 env30458 = env30459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30458 == env30459) = true)

theorem identity30459 : scanCanonicalize (H12AffineFastState.compose env30459 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound30459 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30460 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1028,8,1,1,2,16,2048,1025,0,1045,0,17,3,9,16,2048,16,1028,2049,1025,1,5,1,0,513]

theorem envBound30460 : H12AffineFastState.Bounded env30460 := by
  intro p hp
  have h : env30460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30459_30460 : H12AffineEnvironment.transform 11 1028 env30459 = env30460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env30459 == env30460) = true)

theorem identity30460 : scanCanonicalize (H12AffineFastState.compose env30460 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound30460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30461 : List Nat := [2,4,8,16,0,17,9,4,512,516,2048,512,8,1,1,2,16,2048,517,0,529,0,17,3,9,16,2048,16,512,2049,517,1,5,1,0,513]

theorem envBound30461 : H12AffineFastState.Bounded env30461 := by
  intro p hp
  have h : env30461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30460_30461 : H12AffineEnvironment.transform 9 516 env30460 = env30461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env30460 == env30461) = true)

theorem identity30461 : scanCanonicalize (H12AffineFastState.compose env30461 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound30461 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30462 : List Nat := [2,4,8,16,0,17,9,4,512,516,16,512,8,1,1,2,16,16,517,0,529,0,17,3,9,16,16,16,512,17,517,1,5,1,0,513]

theorem envBound30462 : H12AffineFastState.Bounded env30462 := by
  intro p hp
  have h : env30462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30461_30462 : H12AffineEnvironment.transform 10 16 env30461 = env30462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env30461 == env30462) = true)

def env30463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35324,1025,32769,2097152,4194304,153,41310,8328,65,4303010,2172370,2119113,2556,75223,6407326,257,2188650,2196686,513]

theorem envBound30463 : H12AffineFastState.Bounded env30463 := by
  intro p hp
  have h : env30463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30429_30463 : H12AffineEnvironment.transform 16 16537 env30429 = env30463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env30429 == env30463) = true)

theorem identity30463 : scanCanonicalize (H12AffineFastState.compose env30463 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound30463 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10280,1025,8661,2097152,4194304,153,138,8328,65,4262262,2172370,2119113,2556,75223,6382922,257,2188650,2172186,513]

theorem envBound30464 : H12AffineFastState.Bounded env30464 := by
  intro p hp
  have h : env30464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30463_30464 : H12AffineEnvironment.transform 14 8660 env30463 = env30464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env30463 == env30464) = true)

theorem identity30464 : scanCanonicalize (H12AffineFastState.compose env30464 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30464 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env30465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16537,10280,1025,8661,2097152,4194304,153,138,8328,65,4205044,2098512,2119113,2556,1365,6309320,257,2115048,2098584,513]

theorem envBound30465 : H12AffineFastState.Bounded env30465 := by
  intro p hp
  have h : env30465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30464_30465 : H12AffineEnvironment.transform 15 8322 env30464 = env30465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30464 == env30465) = true)

theorem identity30465 : scanCanonicalize (H12AffineFastState.compose env30465 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound30465 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env30466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16537,10280,1025,8661,2097152,168,153,138,8328,65,10588,2098512,2119113,2556,1365,2114912,257,2115048,2098584,513]

theorem envBound30466 : H12AffineFastState.Bounded env30466 := by
  intro p hp
  have h : env30466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30465_30466 : H12AffineEnvironment.transform 21 168 env30465 = env30466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env30465 == env30466) = true)

theorem identity30466 : scanCanonicalize (H12AffineFastState.compose env30466 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound30466 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16537,10280,1025,8661,17816,168,153,138,8328,65,10588,16584,4177,2556,1365,248,257,112,16384,513]

theorem envBound30467 : H12AffineFastState.Bounded env30467 := by
  intro p hp
  have h : env30467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30466_30467 : H12AffineEnvironment.transform 20 17816 env30466 = env30467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env30466 == env30467) = true)

theorem identity30467 : scanCanonicalize (H12AffineFastState.compose env30467 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30467 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1025,8541,17680,32,17,2,8192,65,10588,16448,4177,2420,1365,112,257,112,16384,513]

theorem envBound30468 : H12AffineFastState.Bounded env30468 := by
  intro p hp
  have h : env30468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30467_30468 : H12AffineEnvironment.transform 6 8 env30467 = env30468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30467 == env30468) = true)

theorem identity30468 : scanCanonicalize (H12AffineFastState.compose env30468 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound30468 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,8202,13673,10280,1025,8541,12392,32,17,2,8192,65,10588,13624,4177,2420,1365,112,257,112,13688,513]

theorem envBound30469 : H12AffineFastState.Bounded env30469 := by
  intro p hp
  have h : env30469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30468_30469 : H12AffineEnvironment.transform 13 13688 env30468 = env30469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env30468 == env30469) = true)

theorem identity30469 : scanCanonicalize (H12AffineFastState.compose env30469 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30469 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30470 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13608,8460,8202,13625,10280,1025,8461,12344,32,17,2,8192,17,10508,13624,4097,2340,1285,32,257,32,13608,513]

theorem envBound30470 : H12AffineFastState.Bounded env30470 := by
  intro p hp
  have h : env30470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30469_30470 : H12AffineEnvironment.transform 5 16 env30469 = env30470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30469 == env30470) = true)

theorem identity30470 : scanCanonicalize (H12AffineFastState.compose env30470 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound30470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30471 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,4113,1077,1331,4096,3345,1025,1076,5377,32,17,2,1337,17,3125,4097,4097,2340,1285,32,257,32,4113,513]

theorem envBound30471 : H12AffineFastState.Bounded env30471 := by
  intro p hp
  have h : env30471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30470_30471 : H12AffineEnvironment.transform 12 1337 env30470 = env30471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env30470 == env30471) = true)

theorem identity30471 : scanCanonicalize (H12AffineFastState.compose env30471 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound30471 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env30472 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4113,1,263,4096,2341,53,0,4405,32,17,2,269,17,2049,4097,4097,2340,305,32,257,32,4113,513]

theorem envBound30472 : H12AffineFastState.Bounded env30472 := by
  intro p hp
  have h : env30472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30471_30472 : H12AffineEnvironment.transform 9 52 env30471 = env30472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env30471 == env30472) = true)

theorem identity30472 : scanCanonicalize (H12AffineFastState.compose env30472 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound30472 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30473 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2609,269,2592,1,263,2609,2341,53,0,2820,32,17,2,269,17,2049,2608,2608,2340,305,32,257,32,2592,513]

theorem envBound30473 : H12AffineFastState.Bounded env30473 := by
  intro p hp
  have h : env30473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30472_30473 : H12AffineEnvironment.transform 11 2609 env30472 = env30473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env30472 == env30473) = true)

theorem identity30473 : scanCanonicalize (H12AffineFastState.compose env30473 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30473 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30474 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2609,40,2592,1,34,2609,2048,53,0,2593,32,17,2,40,17,2049,2608,2608,2049,20,32,36,32,2592,513]

theorem envBound30474 : H12AffineFastState.Bounded env30474 := by
  intro p hp
  have h : env30474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30473_30474 : H12AffineEnvironment.transform 7 37 env30473 = env30474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30473 == env30474) = true)

theorem identity30474 : scanCanonicalize (H12AffineFastState.compose env30474 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30475 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,560,40,545,1,34,560,1,53,0,544,32,17,2,40,17,0,561,561,0,20,32,36,32,545,513]

theorem envBound30475 : H12AffineFastState.Bounded env30475 := by
  intro p hp
  have h : env30475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30474_30475 : H12AffineEnvironment.transform 10 1 env30474 = env30475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30474 == env30475) = true)

def env30476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound30476 : H12AffineFastState.Bounded env30476 := by
  intro p hp
  have h : env30476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29144_30476 : H12AffineEnvironment.transform 29 155254785 env29144 = env30476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env29144 == env30476) = true)

def env30477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound30477 : H12AffineFastState.Bounded env30477 := by
  intro p hp
  have h : env30477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30476_30477 : H12AffineEnvironment.transform 25 64 env30476 = env30477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env30476 == env30477) = true)

def env30478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound30478 : H12AffineFastState.Bounded env30478 := by
  intro p hp
  have h : env30478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30477_30478 : H12AffineEnvironment.transform 26 30393344 env30477 = env30478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env30477 == env30478) = true)

def env30479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound30479 : H12AffineFastState.Bounded env30479 := by
  intro p hp
  have h : env30479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30478_30479 : H12AffineEnvironment.transform 18 1024 env30478 = env30479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env30478 == env30479) = true)

theorem identity30479 : scanCanonicalize (H12AffineFastState.compose env30479 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound30479 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2212885,8328,64,15074325,16536,10507601,8830977,10502148,4235732,256,8388792,8446236,10577874]

theorem envBound30480 : H12AffineFastState.Bounded env30480 := by
  intro p hp
  have h : env30480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30479_30480 : H12AffineEnvironment.transform 23 2212885 env30479 = env30480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env30479 == env30480) = true)

def env30481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21912,2212885,8328,64,6705549,16536,2097353,431513,2102684,4235732,256,21792,46212,2175562]

theorem envBound30481 : H12AffineFastState.Bounded env30481 := by
  intro p hp
  have h : env30481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30480_30481 : H12AffineEnvironment.transform 22 21912 env30480 = env30481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21912 env30480 == env30481) = true)

def env30482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21912,98645,8328,64,4592845,16536,17801,431513,20700,4235732,256,21792,46212,96010]

theorem envBound30482 : H12AffineFastState.Bounded env30482 := by
  intro p hp
  have h : env30482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30481_30482 : H12AffineEnvironment.transform 20 17728 env30481 = env30482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env30481 == env30482) = true)

def env30483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21912,98645,8328,64,410093,16536,17801,431513,20700,62708,256,21792,46212,96010]

theorem envBound30483 : H12AffineFastState.Bounded env30483 := by
  intro p hp
  have h : env30483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30482_30483 : H12AffineEnvironment.transform 21 21792 env30482 = env30483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env30482 == env30483) = true)

def env30484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21776,98645,8192,64,409957,16400,17665,431377,20564,62588,256,21792,46092,96010]

theorem envBound30484 : H12AffineFastState.Bounded env30484 := by
  intro p hp
  have h : env30484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30483_30484 : H12AffineEnvironment.transform 6 8 env30483 = env30484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30483 == env30484) = true)

def env30485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398437,5392,4097,431377,1364,41340,256,32,46092,74250]

theorem envBound30485 : H12AffineFastState.Bounded env30485 := by
  intro p hp
  have h : env30485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30484_30485 : H12AffineEnvironment.transform 13 5376 env30484 = env30485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30484 == env30485) = true)

theorem identity30485 : scanCanonicalize (H12AffineFastState.compose env30485 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30485 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,32,16,2,8192,64,398437,5392,4097,431377,1364,41340,256,32,46092,41821]

theorem envBound30486 : H12AffineFastState.Bounded env30486 := by
  intro p hp
  have h : env30486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30485_30486 : H12AffineEnvironment.transform 15 33111 env30485 = env30486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30485 == env30486) = true)

theorem identity30486 : scanCanonicalize (H12AffineFastState.compose env30486 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30486 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,262144,1024,32769,4160,32,16,2,8192,64,262516,5392,4097,294912,1364,41340,256,32,46092,41821]

theorem envBound30487 : H12AffineFastState.Bounded env30487 := by
  intro p hp
  have h : env30487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30486_30487 : H12AffineEnvironment.transform 16 5393 env30486 = env30487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30486 == env30487) = true)

theorem identity30487 : scanCanonicalize (H12AffineFastState.compose env30487 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound30487 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env30488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,43356,1024,32769,4160,32,16,2,8192,64,43048,5392,4097,10588,1364,41340,256,32,46092,41821]

theorem envBound30488 : H12AffineFastState.Bounded env30488 := by
  intro p hp
  have h : env30488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30487_30488 : H12AffineEnvironment.transform 17 43356 env30487 = env30488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env30487 == env30488) = true)

theorem identity30488 : scanCanonicalize (H12AffineFastState.compose env30488 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound30488 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env30489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8312,8495,5393,2340,1024,8313,4160,32,16,2,8192,64,2128,5392,4097,10588,1364,260,256,32,5236,805]

theorem envBound30489 : H12AffineFastState.Bounded env30489 := by
  intro p hp
  have h : env30489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30488_30489 : H12AffineEnvironment.transform 14 8312 env30488 = env30489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env30488 == env30489) = true)

theorem identity30489 : scanCanonicalize (H12AffineFastState.compose env30489 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30489 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30490 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8233,8495,5393,2340,1024,8232,4113,32,16,2,8192,17,2049,5392,4097,10509,1285,260,256,32,5157,805]

theorem envBound30490 : H12AffineFastState.Bounded env30490 := by
  intro p hp
  have h : env30490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30489_30490 : H12AffineEnvironment.transform 5 17 env30489 = env30490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30489 == env30490) = true)

theorem identity30490 : scanCanonicalize (H12AffineFastState.compose env30490 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30490 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env30491 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,8233,8202,5172,2049,1024,8232,4113,32,16,2,8192,17,2049,5173,4097,10280,1056,33,37,32,5157,512]

theorem envBound30491 : H12AffineFastState.Bounded env30491 := by
  intro p hp
  have h : env30491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30490_30491 : H12AffineEnvironment.transform 7 37 env30490 = env30491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30490 == env30491) = true)

theorem identity30491 : scanCanonicalize (H12AffineFastState.compose env30491 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30492 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8192,5125,8201,8202,5140,2049,1024,8200,4113,0,16,2,8192,17,2049,5141,4097,10248,1024,1,5,0,5125,512]

theorem envBound30492 : H12AffineFastState.Bounded env30492 := by
  intro p hp
  have h : env30492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30491_30492 : H12AffineEnvironment.transform 4 0 env30491 = env30492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30491 == env30492) = true)

theorem identity30492 : scanCanonicalize (H12AffineFastState.compose env30492 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound30492 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30493 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,1,2,5140,2049,1024,0,4113,0,16,2,8,17,2049,5141,4097,2048,1024,1,5,0,5125,512]

theorem envBound30493 : H12AffineFastState.Bounded env30493 := by
  intro p hp
  have h : env30493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30492_30493 : H12AffineEnvironment.transform 12 8 env30492 = env30493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env30492 == env30493) = true)

def env30494 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1045,1,2,1028,2049,1024,0,1,0,16,2,8,17,2049,1029,17,2048,1024,1,5,0,1045,512]

theorem envBound30494 : H12AffineFastState.Bounded env30494 := by
  intro p hp
  have h : env30494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30493_30494 : H12AffineEnvironment.transform 11 16 env30493 = env30494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30493 == env30494) = true)

theorem identity30494 : scanCanonicalize (H12AffineFastState.compose env30494 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound30494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30495 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,16,8,1045,1,2,1028,1044,1024,0,1,0,16,2,8,17,1044,1029,17,1045,1024,1,5,0,1045,512]

theorem envBound30495 : H12AffineFastState.Bounded env30495 := by
  intro p hp
  have h : env30495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30494_30495 : H12AffineEnvironment.transform 10 1045 env30494 = env30495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env30494 == env30495) = true)

def env30496 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,16,8,1,1,2,16,0,20,0,1,0,16,2,8,17,0,17,17,1,20,1,5,0,1,512]

theorem envBound30496 : H12AffineFastState.Bounded env30496 := by
  intro p hp
  have h : env30496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30495_30496 : H12AffineEnvironment.transform 9 20 env30495 = env30496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30495 == env30496) = true)

theorem identity30496 : scanCanonicalize (H12AffineFastState.compose env30496 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30497 : List Nat := [2,4,8,4,0,5,8,5,512,0,1,4,8,1,1,2,4,0,0,0,1,0,4,2,8,5,0,5,5,1,0,1,5,0,1,512]

theorem envBound30497 : H12AffineFastState.Bounded env30497 := by
  intro p hp
  have h : env30497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30496_30497 : H12AffineEnvironment.transform 3 4 env30496 = env30497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30496 == env30497) = true)

def leafEnv30497 : List Nat := [2,4,8,4,0,5,8,5,512,0,1,4,8,1,1,2,4,0,0,0,1,0,4,2,0,8,1,5,0,5,5,1,0,1,5,0,4,2,1,512,1,1,0]

def active30497 : List Nat := [0,1,2,8]

def tree30497 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30497 : H12WitnessSearch.Good tree30497 := H12GlobalWitnessIndex.good

theorem leafIdentity30497 : H12AffineFastState.composeSystem env30497 rootObs = leafEnv30497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30497 rootObs == leafEnv30497) = true)

theorem terminalChecked30497 : H12PackedTerminal.terminalCheckFast leafEnv30497 active30497 tree30497 = true := by decide +kernel

def env30498 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,0,1,2,17,1,21,0,1,0,16,2,8,17,1,16,17,0,21,1,5,0,0,512]

theorem envBound30498 : H12AffineFastState.Bounded env30498 := by
  intro p hp
  have h : env30498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30495_30498 : H12AffineEnvironment.transform 9 21 env30495 = env30498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30495 == env30498) = true)

theorem identity30498 : scanCanonicalize (H12AffineFastState.compose env30498 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound30498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30499 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,16,8,0,1,2,17,1,21,0,1,0,16,2,8,17,1,16,17,0,21,1,5,0,0,31]

theorem envBound30499 : H12AffineFastState.Bounded env30499 := by
  intro p hp
  have h : env30499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30498_30499 : H12AffineEnvironment.transform 8 31 env30498 = env30499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env30498 == env30499) = true)

def leafEnv30499 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,16,8,0,1,2,17,1,21,0,1,0,16,2,21,8,1,17,1,16,17,0,21,1,5,0,4,2,0,31,1,1,0]

def active30499 : List Nat := [0,1,2,3]

def tree30499 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30499 : H12WitnessSearch.Good tree30499 := H12GlobalWitnessIndex.good

theorem leafIdentity30499 : H12AffineFastState.composeSystem env30499 rootObs = leafEnv30499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30499 rootObs == leafEnv30499) = true)

theorem terminalChecked30499 : H12PackedTerminal.terminalCheckFast leafEnv30499 active30499 tree30499 = true := by decide +kernel

def env30500 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1044,1,2,1029,2049,1024,0,0,0,16,2,8,17,2049,1028,16,2048,1024,1,5,0,1044,512]

theorem envBound30500 : H12AffineFastState.Bounded env30500 := by
  intro p hp
  have h : env30500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30493_30500 : H12AffineEnvironment.transform 11 17 env30493 = env30500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30493 == env30500) = true)

theorem identity30500 : scanCanonicalize (H12AffineFastState.compose env30500 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30501 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,8,1044,1,2,1029,1,1024,0,0,0,16,2,8,17,1,1028,16,0,1024,1,5,0,1044,512]

theorem envBound30501 : H12AffineFastState.Bounded env30501 := by
  intro p hp
  have h : env30501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30500_30501 : H12AffineEnvironment.transform 10 0 env30500 = env30501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30500 == env30501) = true)

def env30502 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,1,2,17,1,20,0,0,0,16,2,8,17,1,16,16,0,20,1,5,0,0,512]

theorem envBound30502 : H12AffineFastState.Bounded env30502 := by
  intro p hp
  have h : env30502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30501_30502 : H12AffineEnvironment.transform 9 20 env30501 = env30502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30501 == env30502) = true)

theorem identity30502 : scanCanonicalize (H12AffineFastState.compose env30502 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30503 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,1,2,5,1,0,0,0,0,4,2,8,5,1,4,4,0,0,1,5,0,0,512]

theorem envBound30503 : H12AffineFastState.Bounded env30503 := by
  intro p hp
  have h : env30503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30502_30503 : H12AffineEnvironment.transform 3 4 env30502 = env30503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30502 == env30503) = true)

def leafEnv30503 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,1,2,5,1,0,0,0,0,4,2,0,8,1,5,1,4,4,0,0,1,5,0,4,2,0,512,1,0,0]

def active30503 : List Nat := [0,1,2,8]

def tree30503 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30503 : H12WitnessSearch.Good tree30503 := H12GlobalWitnessIndex.good

theorem leafIdentity30503 : H12AffineFastState.composeSystem env30503 rootObs = leafEnv30503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30503 rootObs == leafEnv30503) = true)

theorem terminalChecked30503 : H12PackedTerminal.terminalCheckFast leafEnv30503 active30503 tree30503 = true := by decide +kernel

def env30504 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,1,1,2,16,1,21,0,0,0,16,2,8,17,1,17,16,0,21,1,5,0,1,512]

theorem envBound30504 : H12AffineFastState.Bounded env30504 := by
  intro p hp
  have h : env30504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30501_30504 : H12AffineEnvironment.transform 9 21 env30501 = env30504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30501 == env30504) = true)

theorem identity30504 : scanCanonicalize (H12AffineFastState.compose env30504 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound30504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30505 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,8,1,1,2,16,1,21,0,0,0,16,2,8,17,1,17,16,0,21,1,5,0,1,31]

theorem envBound30505 : H12AffineFastState.Bounded env30505 := by
  intro p hp
  have h : env30505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30504_30505 : H12AffineEnvironment.transform 8 31 env30504 = env30505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env30504 == env30505) = true)

def leafEnv30505 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,8,1,1,2,16,1,21,0,0,0,16,2,21,8,1,17,1,17,16,0,21,1,5,0,4,2,1,31,1,0,0]

def active30505 : List Nat := [0,1,2,3]

def tree30505 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30505 : H12WitnessSearch.Good tree30505 := H12GlobalWitnessIndex.good

theorem leafIdentity30505 : H12AffineFastState.composeSystem env30505 rootObs = leafEnv30505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30505 rootObs == leafEnv30505) = true)

theorem terminalChecked30505 : H12PackedTerminal.terminalCheckFast leafEnv30505 active30505 tree30505 = true := by decide +kernel

def env30506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,17,98645,8192,64,398436,5393,4096,431377,1365,41341,256,33,46092,74251]

theorem envBound30506 : H12AffineFastState.Bounded env30506 := by
  intro p hp
  have h : env30506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30484_30506 : H12AffineEnvironment.transform 13 5377 env30484 = env30506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30484 == env30506) = true)

theorem identity30506 : scanCanonicalize (H12AffineFastState.compose env30506 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound30506 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,4161,33,17,98645,8192,64,245018,5393,4096,212079,1365,41341,256,33,46092,74251]

theorem envBound30507 : H12AffineFastState.Bounded env30507 := by
  intro p hp
  have h : env30507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30506_30507 : H12AffineEnvironment.transform 17 108926 env30506 = env30507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env30506 == env30507) = true)

theorem identity30507 : scanCanonicalize (H12AffineFastState.compose env30507 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30507 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,108926,1024,32769,4161,33,17,98645,8192,64,108555,5393,4096,76158,1365,41341,256,33,46092,74251]

theorem envBound30508 : H12AffineFastState.Bounded env30508 := by
  intro p hp
  have h : env30508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30507_30508 : H12AffineEnvironment.transform 16 5393 env30507 = env30508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30507 == env30508) = true)

theorem identity30508 : scanCanonicalize (H12AffineFastState.compose env30508 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30508 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,5393,35188,1024,32769,4161,33,17,41311,8192,64,34817,5393,4096,2420,1365,41341,256,33,46092,513]

theorem envBound30509 : H12AffineFastState.Bounded env30509 := by
  intro p hp
  have h : env30509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30508_30509 : H12AffineEnvironment.transform 15 8202 env30508 = env30509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30508 == env30509) = true)

theorem identity30509 : scanCanonicalize (H12AffineFastState.compose env30509 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound30509 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9292,8202,5393,11576,1024,9293,4161,33,17,1299,8192,64,11341,5393,4096,2420,1365,1329,256,33,4160,513]

theorem envBound30510 : H12AffineFastState.Bounded env30510 := by
  intro p hp
  have h : env30510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30509_30510 : H12AffineEnvironment.transform 14 9292 env30509 = env30510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env30509 == env30510) = true)

theorem identity30510 : scanCanonicalize (H12AffineFastState.compose env30510 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound30510 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,293,8192,1060,9292,8202,1076,11576,1024,9293,356,33,17,1299,8192,64,11341,1076,293,2420,1365,1329,256,33,357,513]

theorem envBound30511 : H12AffineFastState.Bounded env30511 := by
  intro p hp
  have h : env30511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30510_30511 : H12AffineEnvironment.transform 11 293 env30510 = env30511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env30510 == env30511) = true)

def env30512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21777,98645,8193,64,409956,16401,17664,431376,20565,62589,256,21792,46093,96010]

theorem envBound30512 : H12AffineFastState.Bounded env30512 := by
  intro p hp
  have h : env30512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30483_30512 : H12AffineEnvironment.transform 6 9 env30483 = env30512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30483 == env30512) = true)

def env30513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398436,5393,4096,431376,1365,41341,256,32,46093,74250]

theorem envBound30513 : H12AffineFastState.Bounded env30513 := by
  intro p hp
  have h : env30513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30512_30513 : H12AffineEnvironment.transform 13 5376 env30512 = env30513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30512 == env30513) = true)

theorem identity30513 : scanCanonicalize (H12AffineFastState.compose env30513 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound30513 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4160,32,17,98645,8193,64,203846,5393,4096,236850,1365,41341,256,32,46093,74250]

theorem envBound30514 : H12AffineFastState.Bounded env30514 := by
  intro p hp
  have h : env30514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30513_30514 : H12AffineEnvironment.transform 17 67618 env30513 = env30514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env30513 == env30514) = true)

theorem identity30514 : scanCanonicalize (H12AffineFastState.compose env30514 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound30514 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,131072,67618,1024,0,4160,32,17,65876,8193,64,203846,5393,4096,204083,1365,8572,256,32,13324,74250]

theorem envBound30515 : H12AffineFastState.Bounded env30515 := by
  intro p hp
  have h : env30515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30514_30515 : H12AffineEnvironment.transform 14 1 env30514 = env30515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env30514 == env30515) = true)

theorem identity30515 : scanCanonicalize (H12AffineFastState.compose env30515 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound30515 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,70726,67618,1024,0,4160,32,17,65876,8193,64,2048,5393,4096,2421,1365,8572,256,32,13324,74250]

theorem envBound30516 : H12AffineFastState.Bounded env30516 := by
  intro p hp
  have h : env30516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30515_30516 : H12AffineEnvironment.transform 16 70726 env30515 = env30516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env30515 == env30516) = true)

theorem identity30516 : scanCanonicalize (H12AffineFastState.compose env30516 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound30516 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,263,5441,2341,1024,0,4160,32,17,83,8193,64,2048,5393,4096,2421,1365,8572,256,32,13324,8973]

theorem envBound30517 : H12AffineFastState.Bounded env30517 := by
  intro p hp
  have h : env30517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30516_30517 : H12AffineEnvironment.transform 15 263 env30516 = env30517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env30516 == env30517) = true)

theorem identity30517 : scanCanonicalize (H12AffineFastState.compose env30517 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound30517 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30518 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,4161,1,263,4096,2341,321,0,4160,32,17,83,8193,64,2048,4176,4096,2421,20,8572,256,32,12621,8973]

theorem envBound30518 : H12AffineFastState.Bounded env30518 := by
  intro p hp
  have h : env30518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30517_30518 : H12AffineEnvironment.transform 9 321 env30517 = env30518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env30517 == env30518) = true)

theorem identity30518 : scanCanonicalize (H12AffineFastState.compose env30518 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30518 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30519 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,268,4161,1,263,4096,2341,321,0,4160,32,17,83,269,64,2048,4176,4096,2421,20,112,256,32,4161,513]

theorem envBound30519 : H12AffineFastState.Bounded env30519 := by
  intro p hp
  have h : env30519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30518_30519 : H12AffineEnvironment.transform 12 268 env30518 = env30519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30518 == env30519) = true)

theorem identity30519 : scanCanonicalize (H12AffineFastState.compose env30519 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30519 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30520 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,4112,1,263,4096,2341,272,0,4113,32,17,2,269,17,2048,4097,4096,2340,20,33,256,32,4112,513]

theorem envBound30520 : H12AffineFastState.Bounded env30520 := by
  intro p hp
  have h : env30520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30519_30520 : H12AffineEnvironment.transform 5 17 env30519 = env30520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30519 == env30520) = true)

theorem identity30520 : scanCanonicalize (H12AffineFastState.compose env30520 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound30520 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30521 : List Nat := [2,4,8,16,32,17,9,53,512,37,2048,4096,57,4112,1,50,4096,2064,37,0,4113,32,17,2,56,17,2048,4097,4096,2065,20,33,53,32,4112,513]

theorem envBound30521 : H12AffineFastState.Bounded env30521 := by
  intro p hp
  have h : env30521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30520_30521 : H12AffineEnvironment.transform 7 53 env30520 = env30521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env30520 == env30521) = true)

theorem identity30521 : scanCanonicalize (H12AffineFastState.compose env30521 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2051) := by decide +kernel

theorem selectedBound30521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30522 : List Nat := [2,4,8,16,32,17,9,53,512,37,2048,2051,57,2067,1,50,2051,2064,37,0,2066,32,17,2,56,17,2048,2050,2051,2065,20,33,53,32,2067,513]

theorem envBound30522 : H12AffineFastState.Bounded env30522 := by
  intro p hp
  have h : env30522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30521_30522 : H12AffineEnvironment.transform 11 2051 env30521 = env30522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2051 env30521 == env30522) = true)

theorem identity30522 : scanCanonicalize (H12AffineFastState.compose env30522 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30522 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30523 : List Nat := [2,4,1,16,32,17,0,53,512,37,2048,2051,48,2067,1,50,2051,2064,37,0,2066,32,17,2,49,17,2048,2050,2051,2065,20,33,53,32,2067,513]

theorem envBound30523 : H12AffineFastState.Bounded env30523 := by
  intro p hp
  have h : env30523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30522_30523 : H12AffineEnvironment.transform 2 1 env30522 = env30523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30522 == env30523) = true)

theorem identity30523 : scanCanonicalize (H12AffineFastState.compose env30523 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound30523 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30524 : List Nat := [2,4,1,16,2,17,0,23,512,7,2048,2051,18,2067,1,16,2051,2064,7,0,2066,2,17,2,19,17,2048,2050,2051,2065,20,3,23,2,2067,513]

theorem envBound30524 : H12AffineFastState.Bounded env30524 := by
  intro p hp
  have h : env30524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30523_30524 : H12AffineEnvironment.transform 4 2 env30523 = env30524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env30523 == env30524) = true)

theorem identity30524 : scanCanonicalize (H12AffineFastState.compose env30524 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound30524 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30525 : List Nat := [2,4,1,2,2,3,0,5,512,7,2048,2051,0,2049,1,2,2051,2050,7,0,2048,2,3,2,1,3,2048,2050,2051,2051,6,3,5,2,2049,513]

theorem envBound30525 : H12AffineFastState.Bounded env30525 := by
  intro p hp
  have h : env30525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30524_30525 : H12AffineEnvironment.transform 3 2 env30524 = env30525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env30524 == env30525) = true)

def env30526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98645,8193,64,398437,5392,4097,431376,1364,41340,256,33,46093,74251]

theorem envBound30526 : H12AffineFastState.Bounded env30526 := by
  intro p hp
  have h : env30526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30512_30526 : H12AffineEnvironment.transform 13 5377 env30512 = env30526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30512 == env30526) = true)

theorem identity30526 : scanCanonicalize (H12AffineFastState.compose env30526 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30526 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398437,5392,4097,431376,1364,41340,256,33,46093,513]

theorem envBound30527 : H12AffineFastState.Bounded env30527 := by
  intro p hp
  have h : env30527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30526_30527 : H12AffineEnvironment.transform 15 8202 env30526 = env30527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30526 == env30527) = true)

theorem identity30527 : scanCanonicalize (H12AffineFastState.compose env30527 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30527 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env30528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398437,5392,4097,406604,1364,32,256,33,5457,513]

theorem envBound30528 : H12AffineFastState.Bounded env30528 := by
  intro p hp
  have h : env30528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30527_30528 : H12AffineEnvironment.transform 14 8540 env30527 = env30528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30527 == env30528) = true)

theorem identity30528 : scanCanonicalize (H12AffineFastState.compose env30528 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound30528 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,262144,1024,8541,4161,33,16,3,8193,64,262437,5392,4097,270604,1364,32,256,33,5457,513]

theorem envBound30529 : H12AffineFastState.Bounded env30529 := by
  intro p hp
  have h : env30529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30528_30529 : H12AffineEnvironment.transform 16 5440 env30528 = env30529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env30528 == env30529) = true)

theorem identity30529 : scanCanonicalize (H12AffineFastState.compose env30529 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound30529 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env30530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,2421,1024,8541,4161,33,16,3,8193,64,2128,5392,4097,10361,1364,32,256,33,5457,513]

theorem envBound30530 : H12AffineFastState.Bounded env30530 := by
  intro p hp
  have h : env30530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30529_30530 : H12AffineEnvironment.transform 17 2421 env30529 = env30530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env30529 == env30530) = true)

theorem identity30530 : scanCanonicalize (H12AffineFastState.compose env30530 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30530 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30531 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,5393,2340,1024,8460,4112,33,16,3,8193,17,2049,5392,4097,10280,1285,32,256,33,5376,513]

theorem envBound30531 : H12AffineFastState.Bounded env30531 := by
  intro p hp
  have h : env30531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30530_30531 : H12AffineEnvironment.transform 5 17 env30530 = env30531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30530 == env30531) = true)

theorem identity30531 : scanCanonicalize (H12AffineFastState.compose env30531 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30531 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30532 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1024,0,4112,33,16,3,269,17,2049,5392,4097,2340,1285,32,256,33,5376,513]

theorem envBound30532 : H12AffineFastState.Bounded env30532 := by
  intro p hp
  have h : env30532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30531_30532 : H12AffineEnvironment.transform 12 268 env30531 = env30532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30531 == env30532) = true)

theorem identity30532 : scanCanonicalize (H12AffineFastState.compose env30532 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30533 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5377,1,262,5393,2308,1024,0,4112,1,16,3,269,17,2049,5392,4097,2308,1285,0,256,1,5376,513]

theorem envBound30533 : H12AffineFastState.Bounded env30533 := by
  intro p hp
  have h : env30533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30532_30533 : H12AffineEnvironment.transform 4 0 env30532 = env30533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30532 == env30533) = true)

theorem identity30533 : scanCanonicalize (H12AffineFastState.compose env30533 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound30533 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30534 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,277,268,1044,1,262,1028,2308,1024,0,261,1,16,3,269,17,2049,1029,276,2308,1285,0,256,1,1045,513]

theorem envBound30534 : H12AffineFastState.Bounded env30534 := by
  intro p hp
  have h : env30534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30533_30534 : H12AffineEnvironment.transform 11 277 env30533 = env30534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env30533 == env30534) = true)

theorem identity30534 : scanCanonicalize (H12AffineFastState.compose env30534 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30534 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30535 : List Nat := [2,4,8,16,0,17,9,256,1,1024,2048,277,268,1044,1,262,1028,2308,1024,0,261,1,16,3,269,17,2049,1029,276,2308,1285,0,256,1,1045,0]

theorem envBound30535 : H12AffineFastState.Bounded env30535 := by
  intro p hp
  have h : env30535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30534_30535 : H12AffineEnvironment.transform 8 1 env30534 = env30535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30534 == env30535) = true)

theorem identity30535 : scanCanonicalize (H12AffineFastState.compose env30535 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound30535 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30536 : List Nat := [2,4,8,16,0,17,9,256,1,1024,1028,277,268,1044,1,262,1028,1280,1024,0,261,1,16,3,269,17,1029,1029,276,1280,1285,0,256,1,1045,0]

theorem envBound30536 : H12AffineFastState.Bounded env30536 := by
  intro p hp
  have h : env30536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30535_30536 : H12AffineEnvironment.transform 10 1028 env30535 = env30536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env30535 == env30536) = true)

theorem identity30536 : scanCanonicalize (H12AffineFastState.compose env30536 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30536 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30537 : List Nat := [2,4,8,16,0,17,9,21,1,1024,1028,0,25,1044,1,19,1028,1045,1024,0,16,1,16,3,24,17,1029,1029,1,1045,1040,0,21,1,1045,0]

theorem envBound30537 : H12AffineFastState.Bounded env30537 := by
  intro p hp
  have h : env30537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30536_30537 : H12AffineEnvironment.transform 7 21 env30536 = env30537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30536 == env30537) = true)

theorem identity30537 : scanCanonicalize (H12AffineFastState.compose env30537 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30537 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env30538 : List Nat := [2,4,8,0,0,1,9,5,1,1024,1028,0,9,1028,1,3,1028,1029,1024,0,0,1,0,3,8,1,1029,1029,1,1029,1024,0,5,1,1029,0]

theorem envBound30538 : H12AffineFastState.Bounded env30538 := by
  intro p hp
  have h : env30538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30537_30538 : H12AffineEnvironment.transform 3 0 env30537 = env30538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30537 == env30538) = true)

theorem identity30538 : scanCanonicalize (H12AffineFastState.compose env30538 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30538 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30539 : List Nat := [2,4,8,0,0,1,9,5,1,4,0,0,9,0,1,3,0,1,4,0,0,1,0,3,8,1,1,1,1,1,4,0,5,1,1,0]

theorem envBound30539 : H12AffineFastState.Bounded env30539 := by
  intro p hp
  have h : env30539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30538_30539 : H12AffineEnvironment.transform 9 4 env30538 = env30539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30538 == env30539) = true)

def env30540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21912,98645,8328,64,410092,16536,17801,431513,20700,62709,256,21792,46212,96010]

theorem envBound30540 : H12AffineFastState.Bounded env30540 := by
  intro p hp
  have h : env30540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30482_30540 : H12AffineEnvironment.transform 21 21793 env30482 = env30540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env30482 == env30540) = true)

theorem identity30540 : scanCanonicalize (H12AffineFastState.compose env30540 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound30540 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,169,16,98645,8328,64,398436,5392,4097,431513,1364,41341,256,168,46212,74370]

theorem envBound30541 : H12AffineFastState.Bounded env30541 := by
  intro p hp
  have h : env30541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30540_30541 : H12AffineEnvironment.transform 13 5512 env30540 = env30541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env30540 == env30541) = true)

def env30542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398436,5392,4097,431377,1364,41341,256,32,46092,74250]

theorem envBound30542 : H12AffineFastState.Bounded env30542 := by
  intro p hp
  have h : env30542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30541_30542 : H12AffineEnvironment.transform 6 8 env30541 = env30542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30541 == env30542) = true)

theorem identity30542 : scanCanonicalize (H12AffineFastState.compose env30542 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30542 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,33,16,2,8192,64,398436,5392,4097,431377,1364,41341,256,32,46092,41821]

theorem envBound30543 : H12AffineFastState.Bounded env30543 := by
  intro p hp
  have h : env30543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30542_30543 : H12AffineEnvironment.transform 15 33111 env30542 = env30543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30542 == env30543) = true)

theorem identity30543 : scanCanonicalize (H12AffineFastState.compose env30543 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound30543 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,262144,1024,32769,4160,33,16,2,8192,64,303145,5392,4097,270684,1364,41341,256,32,46092,41821]

theorem envBound30544 : H12AffineFastState.Bounded env30544 := by
  intro p hp
  have h : env30544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30543_30544 : H12AffineEnvironment.transform 16 46157 env30543 = env30544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env30543 == env30544) = true)

theorem identity30544 : scanCanonicalize (H12AffineFastState.compose env30544 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30544 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,262144,1024,8541,4160,33,16,2,8192,64,262517,5392,4097,270684,1364,33,256,32,5456,513]

theorem envBound30545 : H12AffineFastState.Bounded env30545 := by
  intro p hp
  have h : env30545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30544_30545 : H12AffineEnvironment.transform 14 8540 env30544 = env30545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30544 == env30545) = true)

theorem identity30545 : scanCanonicalize (H12AffineFastState.compose env30545 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound30545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10280,1024,8541,4160,33,16,2,8192,64,10589,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound30546 : H12AffineFastState.Bounded env30546 := by
  intro p hp
  have h : env30546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30545_30546 : H12AffineEnvironment.transform 17 10280 env30545 = env30546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30545 == env30546) = true)

theorem identity30546 : scanCanonicalize (H12AffineFastState.compose env30546 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound30546 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,340,3,5393,2080,1024,341,4160,33,16,2,8,64,2389,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound30547 : H12AffineFastState.Bounded env30547 := by
  intro p hp
  have h : env30547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30546_30547 : H12AffineEnvironment.transform 12 8 env30546 = env30547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env30546 == env30547) = true)

theorem identity30547 : scanCanonicalize (H12AffineFastState.compose env30547 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30547 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30548 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4113,340,3,4096,2080,273,341,4160,33,16,2,8,64,2389,4097,4097,2420,69,33,256,32,4161,513]

theorem envBound30548 : H12AffineFastState.Bounded env30548 := by
  intro p hp
  have h : env30548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30547_30548 : H12AffineEnvironment.transform 9 273 env30547 = env30548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30547 == env30548) = true)

theorem identity30548 : scanCanonicalize (H12AffineFastState.compose env30548 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound30548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30549 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,4096,8,4113,49,3,4096,2080,116,48,4160,33,16,2,8,64,2096,4097,4097,2065,69,33,101,32,4161,513]

theorem envBound30549 : H12AffineFastState.Bounded env30549 := by
  intro p hp
  have h : env30549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30548_30549 : H12AffineEnvironment.transform 7 101 env30548 = env30549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env30548 == env30549) = true)

theorem identity30549 : scanCanonicalize (H12AffineFastState.compose env30549 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound30549 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30550 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,528,8,513,49,3,528,2080,116,48,592,33,16,2,8,64,2096,529,529,2065,69,33,101,32,593,513]

theorem envBound30550 : H12AffineFastState.Bounded env30550 := by
  intro p hp
  have h : env30550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30549_30550 : H12AffineEnvironment.transform 11 528 env30549 = env30550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env30549 == env30550) = true)

theorem identity30550 : scanCanonicalize (H12AffineFastState.compose env30550 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound30550 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env30551 : List Nat := [2,4,8,16,32,64,8,101,512,116,593,528,8,513,49,3,528,625,116,48,592,33,16,2,8,64,609,529,529,576,69,33,101,32,593,513]

theorem envBound30551 : H12AffineFastState.Bounded env30551 := by
  intro p hp
  have h : env30551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30550_30551 : H12AffineEnvironment.transform 10 593 env30550 = env30551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env30550 == env30551) = true)

theorem identity30551 : scanCanonicalize (H12AffineFastState.compose env30551 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30551 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env30552 : List Nat := [2,4,8,16,32,48,8,21,512,4,545,528,8,513,49,3,528,513,4,48,544,33,16,2,8,48,529,529,529,560,53,33,21,32,545,513]

theorem envBound30552 : H12AffineFastState.Bounded env30552 := by
  intro p hp
  have h : env30552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30551_30552 : H12AffineEnvironment.transform 5 48 env30551 = env30552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30551 == env30552) = true)

theorem identity30552 : scanCanonicalize (H12AffineFastState.compose env30552 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30552 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env30553 : List Nat := [2,4,8,16,16,0,8,21,512,4,529,528,8,513,1,3,528,513,4,0,528,17,16,2,8,0,529,529,529,512,5,17,21,16,529,513]

theorem envBound30553 : H12AffineFastState.Bounded env30553 := by
  intro p hp
  have h : env30553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30552_30553 : H12AffineEnvironment.transform 4 16 env30552 = env30553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30552 == env30553) = true)

theorem identity30553 : scanCanonicalize (H12AffineFastState.compose env30553 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30553 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30554 : List Nat := [2,4,8,0,0,0,8,5,512,4,513,512,8,513,1,3,512,513,4,0,512,1,0,2,8,0,513,513,513,512,5,1,5,0,513,513]

theorem envBound30554 : H12AffineFastState.Bounded env30554 := by
  intro p hp
  have h : env30554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30553_30554 : H12AffineEnvironment.transform 3 0 env30553 = env30554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30553 == env30554) = true)

def env30555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98645,8193,64,398436,5392,4097,431376,1364,41341,256,33,46093,74251]

theorem envBound30555 : H12AffineFastState.Bounded env30555 := by
  intro p hp
  have h : env30555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30541_30555 : H12AffineEnvironment.transform 6 9 env30541 = env30555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30541 == env30555) = true)

theorem identity30555 : scanCanonicalize (H12AffineFastState.compose env30555 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30555 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398436,5392,4097,431376,1364,41341,256,33,46093,513]

theorem envBound30556 : H12AffineFastState.Bounded env30556 := by
  intro p hp
  have h : env30556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30555_30556 : H12AffineEnvironment.transform 15 8202 env30555 = env30556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30555 == env30556) = true)

theorem identity30556 : scanCanonicalize (H12AffineFastState.compose env30556 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30556 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env30557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398436,5392,4097,406604,1364,33,256,33,5457,513]

theorem envBound30557 : H12AffineFastState.Bounded env30557 := by
  intro p hp
  have h : env30557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30556_30557 : H12AffineEnvironment.transform 14 8540 env30556 = env30557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30556 == env30557) = true)

theorem identity30557 : scanCanonicalize (H12AffineFastState.compose env30557 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound30557 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,262144,1024,8541,4161,32,16,3,8193,64,262436,5392,4097,270604,1364,33,256,33,5457,513]

theorem envBound30558 : H12AffineFastState.Bounded env30558 := by
  intro p hp
  have h : env30558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30557_30558 : H12AffineEnvironment.transform 16 5440 env30557 = env30558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env30557 == env30558) = true)

theorem identity30558 : scanCanonicalize (H12AffineFastState.compose env30558 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound30558 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env30559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5440,10360,1024,8541,4161,32,16,3,8193,64,10588,5392,4097,2420,1364,33,256,33,5457,513]

theorem envBound30559 : H12AffineFastState.Bounded env30559 := by
  intro p hp
  have h : env30559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30558_30559 : H12AffineEnvironment.transform 17 10360 env30558 = env30559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env30558 == env30559) = true)

theorem identity30559 : scanCanonicalize (H12AffineFastState.compose env30559 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30559 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30560 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,5392,10280,1024,8461,4113,32,16,3,8193,16,10508,5392,4097,2340,1284,33,256,33,5377,513]

theorem envBound30560 : H12AffineFastState.Bounded env30560 := by
  intro p hp
  have h : env30560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30559_30560 : H12AffineEnvironment.transform 5 16 env30559 = env30560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30559 == env30560) = true)

theorem identity30560 : scanCanonicalize (H12AffineFastState.compose env30560 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,8192,309,8460,8202,292,10280,1024,8461,1061,32,16,3,8193,16,10508,292,1077,2340,1284,33,256,33,309,513]

theorem envBound30561 : H12AffineFastState.Bounded env30561 := by
  intro p hp
  have h : env30561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30560_30561 : H12AffineEnvironment.transform 11 1076 env30560 = env30561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env30560 == env30561) = true)

theorem identity30561 : scanCanonicalize (H12AffineFastState.compose env30561 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound30561 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,2083,309,2351,2089,292,11,1024,2350,1061,32,16,3,2082,16,303,292,1077,2340,1284,33,256,33,309,513]

theorem envBound30562 : H12AffineFastState.Bounded env30562 := by
  intro p hp
  have h : env30562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30561_30562 : H12AffineEnvironment.transform 12 2083 env30561 = env30562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env30561 == env30562) = true)

theorem identity30562 : scanCanonicalize (H12AffineFastState.compose env30562 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound30562 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,302,1076,269,309,1,263,292,11,1024,0,1061,32,16,3,268,16,303,292,1077,10,1284,33,256,33,309,513]

theorem envBound30563 : H12AffineFastState.Bounded env30563 := by
  intro p hp
  have h : env30563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30562_30563 : H12AffineEnvironment.transform 10 302 env30562 = env30563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env30562 == env30563) = true)

theorem identity30563 : scanCanonicalize (H12AffineFastState.compose env30563 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30563 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30564 : List Nat := [2,4,8,16,32,16,9,256,512,273,302,293,269,309,1,263,292,11,273,0,308,32,16,3,268,16,303,292,292,10,21,33,256,33,309,513]

theorem envBound30564 : H12AffineFastState.Bounded env30564 := by
  intro p hp
  have h : env30564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30563_30564 : H12AffineEnvironment.transform 9 273 env30563 = env30564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30563 == env30564) = true)

theorem identity30564 : scanCanonicalize (H12AffineFastState.compose env30564 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound30564 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30565 : List Nat := [2,4,8,16,32,16,9,30,512,15,48,59,19,43,1,25,58,11,15,0,42,32,16,3,18,16,49,58,58,10,21,33,30,33,43,513]

theorem envBound30565 : H12AffineFastState.Bounded env30565 := by
  intro p hp
  have h : env30565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30564_30565 : H12AffineEnvironment.transform 7 30 env30564 = env30565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env30564 == env30565) = true)

theorem identity30565 : scanCanonicalize (H12AffineFastState.compose env30565 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound30565 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30566 : List Nat := [2,4,8,16,27,16,9,30,512,15,11,0,19,16,1,25,1,11,15,0,17,27,16,3,18,16,10,1,1,10,21,26,30,26,16,513]

theorem envBound30566 : H12AffineFastState.Bounded env30566 := by
  intro p hp
  have h : env30566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30565_30566 : H12AffineEnvironment.transform 4 27 env30565 = env30566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env30565 == env30566) = true)

theorem identity30566 : scanCanonicalize (H12AffineFastState.compose env30566 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30567 : List Nat := [2,1,8,16,27,16,9,27,512,10,11,0,19,16,1,25,1,11,10,0,17,27,16,3,18,16,10,1,1,10,16,26,27,26,16,513]

theorem envBound30567 : H12AffineFastState.Bounded env30567 := by
  intro p hp
  have h : env30567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30566_30567 : H12AffineEnvironment.transform 1 1 env30566 = env30567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30566 == env30567) = true)

theorem identity30567 : scanCanonicalize (H12AffineFastState.compose env30567 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound30567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30568 : List Nat := [2,1,8,16,27,16,9,27,2,10,11,0,19,16,1,25,1,11,10,0,17,27,16,3,18,16,10,1,1,10,16,26,27,26,16,3]

theorem envBound30568 : H12AffineFastState.Bounded env30568 := by
  intro p hp
  have h : env30568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30567_30568 : H12AffineEnvironment.transform 8 2 env30567 = env30568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env30567 == env30568) = true)

def env30569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21912,98644,8328,64,4592844,16536,17800,431513,20701,4235732,256,21792,46212,96011]

theorem envBound30569 : H12AffineFastState.Bounded env30569 := by
  intro p hp
  have h : env30569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30481_30569 : H12AffineEnvironment.transform 20 17729 env30481 = env30569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env30481 == env30569) = true)

def env30570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21912,98644,8328,64,410092,16536,17800,431513,20701,62708,256,21792,46212,96011]

theorem envBound30570 : H12AffineFastState.Bounded env30570 := by
  intro p hp
  have h : env30570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30570 : H12AffineEnvironment.transform 21 21792 env30569 = env30570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env30569 == env30570) = true)

theorem identity30570 : scanCanonicalize (H12AffineFastState.compose env30570 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30570 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,17729,21792,21912,95616,8328,64,410092,16536,17800,418125,20701,32,256,21792,16464,96011]

theorem envBound30571 : H12AffineFastState.Bounded env30571 := by
  intro p hp
  have h : env30571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30570_30571 : H12AffineEnvironment.transform 14 29908 env30570 = env30571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30570 == env30571) = true)

def env30572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32160,1024,29909,17729,21792,21912,95616,8328,64,146508,16536,17800,138477,20701,32,256,21792,16464,96011]

theorem envBound30572 : H12AffineFastState.Bounded env30572 := by
  intro p hp
  have h : env30572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30571_30572 : H12AffineEnvironment.transform 17 32160 env30571 = env30572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env30571 == env30572) = true)

theorem identity30572 : scanCanonicalize (H12AffineFastState.compose env30572 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound30572 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29962,131072,32160,1024,29909,17729,21792,21912,138,8328,64,146508,16536,17800,138477,20701,32,256,21792,16464,513]

theorem envBound30573 : H12AffineFastState.Bounded env30573 := by
  intro p hp
  have h : env30573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30572_30573 : H12AffineEnvironment.transform 15 29962 env30572 = env30573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env30572 == env30573) = true)

theorem identity30573 : scanCanonicalize (H12AffineFastState.compose env30573 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound30573 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29962,5392,32160,1024,29909,17729,21792,21912,138,8328,64,10588,16536,17800,2557,20701,32,256,21792,16464,513]

theorem envBound30574 : H12AffineFastState.Bounded env30574 := by
  intro p hp
  have h : env30574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30573_30574 : H12AffineEnvironment.transform 16 5392 env30573 = env30574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env30573 == env30574) = true)

theorem identity30574 : scanCanonicalize (H12AffineFastState.compose env30574 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30574 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,5392,10401,1024,8660,4160,33,153,138,8328,64,10588,5529,4233,2557,1500,32,256,33,5457,513]

theorem envBound30575 : H12AffineFastState.Bounded env30575 := by
  intro p hp
  have h : env30575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30574_30575 : H12AffineEnvironment.transform 13 5377 env30574 = env30575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30574 == env30575) = true)

theorem identity30575 : scanCanonicalize (H12AffineFastState.compose env30575 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound30575 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,5377,1297,1231,5392,3173,1024,1296,4160,33,153,138,1100,64,3480,5529,4233,2557,1500,32,256,33,5457,513]

theorem envBound30576 : H12AffineFastState.Bounded env30576 := by
  intro p hp
  have h : env30576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30575_30576 : H12AffineEnvironment.transform 12 1220 env30575 = env30576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env30575 == env30576) = true)

theorem identity30576 : scanCanonicalize (H12AffineFastState.compose env30576 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound30576 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2405,1220,3172,1297,1231,3189,3173,1024,1296,2341,33,153,138,1100,64,3480,3324,2540,2557,1500,32,256,33,3124,513]

theorem envBound30577 : H12AffineFastState.Bounded env30577 := by
  intro p hp
  have h : env30577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30576_30577 : H12AffineEnvironment.transform 11 2405 env30576 = env30577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env30576 == env30577) = true)

theorem identity30577 : scanCanonicalize (H12AffineFastState.compose env30577 (packedSelected [0,1,2,6,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound30577 : packedSelected [0,1,2,6,8,9] rootPS < 2^1333 := by decide +kernel

def env30578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,80,309,1220,1076,1297,1231,1061,1077,1024,1296,373,33,153,138,1100,64,1480,1196,444,429,1500,32,256,33,1124,513]

theorem envBound30578 : H12AffineFastState.Bounded env30578 := by
  intro p hp
  have h : env30578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30577_30578 : H12AffineEnvironment.transform 10 80 env30577 = env30578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env30577 == env30578) = true)

theorem identity30578 : scanCanonicalize (H12AffineFastState.compose env30578 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound30578 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env30579 : List Nat := [2,4,8,16,32,64,128,173,512,1024,80,152,1220,1076,1212,1231,1061,1077,1024,1213,216,33,153,138,1100,64,1125,1196,17,0,1137,32,173,33,1124,513]

theorem envBound30579 : H12AffineFastState.Bounded env30579 := by
  intro p hp
  have h : env30579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30578_30579 : H12AffineEnvironment.transform 7 173 env30578 = env30579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env30578 == env30579) = true)

theorem identity30579 : scanCanonicalize (H12AffineFastState.compose env30579 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound30579 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30580 : List Nat := [2,4,8,16,32,64,88,117,512,1024,80,64,1052,1076,1124,1047,1061,1077,1024,1125,0,33,65,82,1100,64,1125,1140,17,0,1137,32,117,33,1124,513]

theorem envBound30580 : H12AffineFastState.Bounded env30580 := by
  intro p hp
  have h : env30580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30579_30580 : H12AffineEnvironment.transform 6 88 env30579 = env30580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env30579 == env30580) = true)

theorem identity30580 : scanCanonicalize (H12AffineFastState.compose env30580 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30581 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,17,1052,1076,1077,1047,1061,1077,1024,1076,0,33,16,3,1053,17,1076,1061,17,0,1056,32,36,33,1077,513]

theorem envBound30581 : H12AffineFastState.Bounded env30581 := by
  intro p hp
  have h : env30581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30580_30581 : H12AffineEnvironment.transform 5 17 env30580 = env30581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30580 == env30581) = true)

theorem identity30581 : scanCanonicalize (H12AffineFastState.compose env30581 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound30581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30582 : List Nat := [2,4,8,16,32,17,9,36,512,36,1,17,56,16,17,51,1,17,36,16,0,33,16,3,57,17,16,1,17,0,4,32,36,33,17,513]

theorem envBound30582 : H12AffineFastState.Bounded env30582 := by
  intro p hp
  have h : env30582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30581_30582 : H12AffineEnvironment.transform 9 36 env30581 = env30582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env30581 == env30582) = true)

theorem identity30582 : scanCanonicalize (H12AffineFastState.compose env30582 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30582 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30583 : List Nat := [2,4,8,16,32,17,9,36,1,36,1,17,56,16,17,51,1,17,36,16,0,33,16,3,57,17,16,1,17,0,4,32,36,33,17,0]

theorem envBound30583 : H12AffineFastState.Bounded env30583 := by
  intro p hp
  have h : env30583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30582_30583 : H12AffineEnvironment.transform 8 1 env30582 = env30583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30582 == env30583) = true)

theorem identity30583 : scanCanonicalize (H12AffineFastState.compose env30583 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30583 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30584 : List Nat := [2,4,8,1,32,0,9,36,1,36,1,0,41,1,0,34,1,0,36,1,0,33,1,3,40,0,1,1,0,0,4,32,36,33,0,0]

theorem envBound30584 : H12AffineFastState.Bounded env30584 := by
  intro p hp
  have h : env30584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30583_30584 : H12AffineEnvironment.transform 3 1 env30583 = env30584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30583 == env30584) = true)

theorem identity30584 : scanCanonicalize (H12AffineFastState.compose env30584 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30585 : List Nat := [2,4,3,1,32,0,2,36,1,36,1,0,34,1,0,34,1,0,36,1,0,33,1,3,35,0,1,1,0,0,4,32,36,33,0,0]

theorem envBound30585 : H12AffineFastState.Bounded env30585 := by
  intro p hp
  have h : env30585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30584_30585 : H12AffineEnvironment.transform 2 3 env30584 = env30585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30584 == env30585) = true)

def env30586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32161,1024,29909,17729,21792,21912,95616,8328,64,146509,16536,17800,138476,20701,32,256,21792,16464,96011]

theorem envBound30586 : H12AffineFastState.Bounded env30586 := by
  intro p hp
  have h : env30586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30571_30586 : H12AffineEnvironment.transform 17 32161 env30571 = env30586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env30571 == env30586) = true)

theorem identity30586 : scanCanonicalize (H12AffineFastState.compose env30586 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30586 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8322,131072,32161,1024,29909,17729,21792,21912,21762,8328,64,146509,16536,17800,138476,20701,32,256,21792,16464,22409]

theorem envBound30587 : H12AffineFastState.Bounded env30587 := by
  intro p hp
  have h : env30587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30586_30587 : H12AffineEnvironment.transform 15 8322 env30586 = env30587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30586 == env30587) = true)

theorem identity30587 : scanCanonicalize (H12AffineFastState.compose env30587 (packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound30587 : packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env30588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,216,8322,131072,2477,1024,217,12621,8492,8596,8462,8328,64,146509,13460,12676,138476,9425,32,256,8492,13404,9093]

theorem envBound30588 : H12AffineFastState.Bounded env30588 := by
  intro p hp
  have h : env30588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30587_30588 : H12AffineEnvironment.transform 13 13324 env30587 = env30588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env30587 == env30588) = true)

theorem identity30588 : scanCanonicalize (H12AffineFastState.compose env30588 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30588 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env30589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,216,8322,13388,2477,1024,217,12621,8492,8596,8462,8328,64,2049,13460,12676,10400,9425,32,256,8492,13404,9093]

theorem envBound30589 : H12AffineFastState.Bounded env30589 := by
  intro p hp
  have h : env30589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30588_30589 : H12AffineEnvironment.transform 16 13388 env30588 = env30589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30588 == env30589) = true)

theorem identity30589 : scanCanonicalize (H12AffineFastState.compose env30589 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound30589 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env30590 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13324,0,8282,13388,2421,1024,1,12621,8492,8524,8462,8272,64,2049,13388,12636,10360,9225,32,256,8492,13404,9053]

theorem envBound30590 : H12AffineFastState.Bounded env30590 := by
  intro p hp
  have h : env30590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30589_30590 : H12AffineEnvironment.transform 6 88 env30589 = env30590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env30589 == env30590) = true)

theorem identity30590 : scanCanonicalize (H12AffineFastState.compose env30590 (packedSelected [0,4,7,9,10,11,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30590 : packedSelected [0,4,7,9,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env30591 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5376,0,342,5440,2421,1024,1,4161,32,64,2,348,64,2049,5440,4176,2420,1285,32,256,32,5456,593]

theorem envBound30591 : H12AffineFastState.Bounded env30591 := by
  intro p hp
  have h : env30591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30590_30591 : H12AffineEnvironment.transform 12 268 env30590 = env30591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30590 == env30591) = true)

theorem identity30591 : scanCanonicalize (H12AffineFastState.compose env30591 (packedSelected [0,1,2,3,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound30591 : packedSelected [0,1,2,3,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30592 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,16,268,1296,0,342,1360,2421,1024,1,81,32,64,2,348,64,2049,1360,64,2420,1285,32,256,32,1344,593]

theorem envBound30592 : H12AffineFastState.Bounded env30592 := by
  intro p hp
  have h : env30592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30591_30592 : H12AffineEnvironment.transform 11 16 env30591 = env30592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30591 == env30592) = true)

theorem identity30592 : scanCanonicalize (H12AffineFastState.compose env30592 (packedSelected [1,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30592 : packedSelected [1,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env30593 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,16,268,1296,0,262,1280,2341,1024,1,1,32,16,2,268,16,2049,1280,16,2340,1285,32,256,32,1296,513]

theorem envBound30593 : H12AffineFastState.Bounded env30593 := by
  intro p hp
  have h : env30593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30592_30593 : H12AffineEnvironment.transform 5 16 env30592 = env30593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30592 == env30593) = true)

theorem identity30593 : scanCanonicalize (H12AffineFastState.compose env30593 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30594 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,16,268,1,0,262,17,2341,273,1,1,32,16,2,268,16,2049,17,16,2340,20,32,256,32,1,513]

theorem envBound30594 : H12AffineFastState.Bounded env30594 := by
  intro p hp
  have h : env30594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30593_30594 : H12AffineEnvironment.transform 9 273 env30593 = env30594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30593 == env30594) = true)

def env30595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21912,98644,8328,64,410093,16536,17800,431513,20701,62709,256,21792,46212,96011]

theorem envBound30595 : H12AffineFastState.Bounded env30595 := by
  intro p hp
  have h : env30595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30595 : H12AffineEnvironment.transform 21 21793 env30569 = env30595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env30569 == env30595) = true)

theorem identity30595 : scanCanonicalize (H12AffineFastState.compose env30595 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30595 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,17729,21793,21912,73736,8328,64,410093,16536,17800,406725,20701,21929,256,21792,5592,96011]

theorem envBound30596 : H12AffineFastState.Bounded env30596 := by
  intro p hp
  have h : env30596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30595_30596 : H12AffineEnvironment.transform 14 8540 env30595 = env30596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30595 == env30596) = true)

def env30597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,17729,21793,21912,73736,8328,64,158029,16536,17800,138341,20701,21929,256,21792,5592,96011]

theorem envBound30597 : H12AffineFastState.Bounded env30597 := by
  intro p hp
  have h : env30597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30596_30597 : H12AffineEnvironment.transform 17 10400 env30596 = env30597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30596 == env30597) = true)

theorem identity30597 : scanCanonicalize (H12AffineFastState.compose env30597 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound30597 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10400,1024,8541,17729,21793,21912,21762,8328,64,158029,16536,17800,138341,20701,21929,256,21792,5592,513]

theorem envBound30598 : H12AffineFastState.Bounded env30598 := by
  intro p hp
  have h : env30598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30597_30598 : H12AffineEnvironment.transform 15 29962 env30597 = env30598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env30597 == env30598) = true)

theorem identity30598 : scanCanonicalize (H12AffineFastState.compose env30598 (packedSelected [2,3,5,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 24680) := by decide +kernel

theorem selectedBound30598 : packedSelected [2,3,5,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env30599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,24680,10400,1024,8541,17729,21793,21912,21762,8328,64,2341,16536,17800,31757,20701,21929,256,21792,5592,513]

theorem envBound30599 : H12AffineFastState.Bounded env30599 := by
  intro p hp
  have h : env30599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30598_30599 : H12AffineEnvironment.transform 16 24680 env30598 = env30599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24680 env30598 == env30599) = true)

theorem identity30599 : scanCanonicalize (H12AffineFastState.compose env30599 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound30599 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,216,21646,16876,2340,1024,217,17729,21793,21912,21762,268,64,2341,16536,17800,23945,20701,21929,256,21792,5592,513]

theorem envBound30600 : H12AffineFastState.Bounded env30600 := by
  intro p hp
  have h : env30600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30599_30600 : H12AffineEnvironment.transform 12 388 env30599 = env30600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env30599 == env30600) = true)

def env30601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,17729,21793,21912,73736,8328,64,158028,16536,17800,138340,20701,21929,256,21792,5592,96011]

theorem envBound30601 : H12AffineFastState.Bounded env30601 := by
  intro p hp
  have h : env30601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30596_30601 : H12AffineEnvironment.transform 17 10401 env30596 = env30601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30596 == env30601) = true)

theorem identity30601 : scanCanonicalize (H12AffineFastState.compose env30601 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30601 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,131072,10401,1024,8541,17729,21793,21912,138,8328,64,158028,16536,17800,138340,20701,21929,256,21792,5592,22409]

theorem envBound30602 : H12AffineFastState.Bounded env30602 := by
  intro p hp
  have h : env30602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30601_30602 : H12AffineEnvironment.transform 15 8322 env30601 = env30602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30601 == env30602) = true)

theorem identity30602 : scanCanonicalize (H12AffineFastState.compose env30602 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound30602 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8322,5577,10401,1024,8541,17729,21793,21912,138,8328,64,31877,16536,17800,2477,20701,21929,256,21792,5592,22409]

theorem envBound30603 : H12AffineFastState.Bounded env30603 := by
  intro p hp
  have h : env30603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30602_30603 : H12AffineEnvironment.transform 16 5577 env30602 = env30603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env30602 == env30603) = true)

theorem identity30603 : scanCanonicalize (H12AffineFastState.compose env30603 (packedSelected [2,9,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound30603 : packedSelected [2,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,8540,8322,5577,10401,1024,8541,12725,8661,8556,138,8328,64,2161,13420,12668,2477,9257,8541,256,8660,5592,9085]

theorem envBound30604 : H12AffineFastState.Bounded env30604 := by
  intro p hp
  have h : env30604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30603_30604 : H12AffineEnvironment.transform 13 13556 env30603 = env30604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env30603 == env30604) = true)

theorem identity30604 : scanCanonicalize (H12AffineFastState.compose env30604 (packedSelected [0,2,3,4,7,9,10,18,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound30604 : packedSelected [0,2,3,4,7,9,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env30605 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,8192,13324,8540,8314,5425,10329,1024,8541,12621,8493,8556,114,8304,64,2161,13420,12668,2389,9257,8541,256,8492,5408,9085]

theorem envBound30605 : H12AffineFastState.Bounded env30605 := by
  intro p hp
  have h : env30605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30604_30605 : H12AffineEnvironment.transform 6 120 env30604 = env30605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env30604 == env30605) = true)

theorem identity30605 : scanCanonicalize (H12AffineFastState.compose env30605 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30605 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env30606 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,120,5236,292,2,5425,2081,1024,293,4405,341,276,114,8,64,2161,5140,4356,2389,1105,293,256,340,5408,773]

theorem envBound30606 : H12AffineFastState.Bounded env30606 := by
  intro p hp
  have h : env30606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30605_30606 : H12AffineEnvironment.transform 12 120 env30605 = env30606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30605 == env30606) = true)

theorem identity30606 : scanCanonicalize (H12AffineFastState.compose env30606 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30606 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30607 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,120,5236,33,2,5172,2081,1024,32,4144,80,17,114,8,64,2161,5140,4097,2128,1105,32,5,81,5157,512]

theorem envBound30607 : H12AffineFastState.Bounded env30607 := by
  intro p hp
  have h : env30607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30606_30607 : H12AffineEnvironment.transform 7 5 env30606 = env30607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30606 == env30607) = true)

theorem identity30607 : scanCanonicalize (H12AffineFastState.compose env30607 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30607 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30608 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,8,5124,33,2,5172,2081,1024,32,4144,32,17,2,8,48,2049,5140,4097,2080,1057,32,5,33,5157,512]

theorem envBound30608 : H12AffineFastState.Bounded env30608 := by
  intro p hp
  have h : env30608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30607_30608 : H12AffineEnvironment.transform 5 48 env30607 = env30608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30607 == env30608) = true)

def env30609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21913,2212885,8328,64,6705548,16536,2097352,431512,2102685,4235732,256,21793,46213,2175563]

theorem envBound30609 : H12AffineFastState.Bounded env30609 := by
  intro p hp
  have h : env30609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30480_30609 : H12AffineEnvironment.transform 22 21913 env30480 = env30609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21913 env30480 == env30609) = true)

def env30610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21913,98645,8328,64,4592844,16536,17800,431512,20701,4235732,256,21793,46213,96011]

theorem envBound30610 : H12AffineFastState.Bounded env30610 := by
  intro p hp
  have h : env30610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30609_30610 : H12AffineEnvironment.transform 20 17728 env30609 = env30610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env30609 == env30610) = true)

def env30611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21913,98645,8328,64,410092,16536,17800,431512,20701,62708,256,21793,46213,96011]

theorem envBound30611 : H12AffineFastState.Bounded env30611 := by
  intro p hp
  have h : env30611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30611 : H12AffineEnvironment.transform 21 21792 env30610 = env30611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env30610 == env30611) = true)

theorem identity30611 : scanCanonicalize (H12AffineFastState.compose env30611 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound30611 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,262144,1024,32769,17728,21792,21913,41430,8328,64,410092,16536,17800,431512,20701,62708,256,21793,46213,22408]

theorem envBound30612 : H12AffineFastState.Bounded env30612 := by
  intro p hp
  have h : env30612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30611_30612 : H12AffineEnvironment.transform 15 8323 env30611 = env30612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env30611 == env30612) = true)

def env30613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,262144,1024,32769,17728,21792,21913,41430,8328,64,283820,16536,17800,295128,20701,62708,256,21793,46213,22408]

theorem envBound30613 : H12AffineFastState.Bounded env30613 := by
  intro p hp
  have h : env30613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30612_30613 : H12AffineEnvironment.transform 16 5440 env30612 = env30613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env30612 == env30613) = true)

theorem identity30613 : scanCanonicalize (H12AffineFastState.compose env30613 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56493) := by decide +kernel

theorem selectedBound30613 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,56493,1024,32769,17728,21792,21913,41430,8328,64,34817,16536,17800,23669,20701,62708,256,21793,46213,22408]

theorem envBound30614 : H12AffineFastState.Bounded env30614 := by
  intro p hp
  have h : env30614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30613_30614 : H12AffineEnvironment.transform 17 56493 env30613 = env30614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56493 env30613 == env30614) = true)

theorem identity30614 : scanCanonicalize (H12AffineFastState.compose env30614 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound30614 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,5440,35108,1024,32769,4297,169,16,41430,8328,64,34817,5393,4097,2556,1364,41341,256,168,46213,513]

theorem envBound30615 : H12AffineFastState.Bounded env30615 := by
  intro p hp
  have h : env30615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30614_30615 : H12AffineEnvironment.transform 13 5513 env30614 = env30615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env30614 == env30615) = true)

theorem identity30615 : scanCanonicalize (H12AffineFastState.compose env30615 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,20,21,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound30615 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,20,21,22,26] rootPS < 2^1333 := by decide +kernel

def env30616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8580,8323,5440,10400,1024,8581,4297,169,16,82,8328,64,10629,5393,4097,2556,1364,249,256,168,5377,513]

theorem envBound30616 : H12AffineFastState.Bounded env30616 := by
  intro p hp
  have h : env30616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30615_30616 : H12AffineEnvironment.transform 14 8580 env30615 = env30616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env30615 == env30616) = true)

theorem identity30616 : scanCanonicalize (H12AffineFastState.compose env30616 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30616 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env30617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8580,8323,5393,10400,1024,8581,4248,169,16,3,8328,17,10629,5393,4097,2477,1285,168,256,168,5377,513]

theorem envBound30617 : H12AffineFastState.Bounded env30617 := by
  intro p hp
  have h : env30617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30616_30617 : H12AffineEnvironment.transform 5 17 env30616 = env30617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30616 == env30617) = true)

theorem identity30617 : scanCanonicalize (H12AffineFastState.compose env30617 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound30617 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,128,5513,260,3,5393,2080,1024,261,4248,169,16,3,8,17,2309,5393,4097,2477,1285,168,256,168,5377,513]

theorem envBound30618 : H12AffineFastState.Bounded env30618 := by
  intro p hp
  have h : env30618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30617_30618 : H12AffineEnvironment.transform 12 128 env30617 = env30618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env30617 == env30618) = true)

theorem identity30618 : scanCanonicalize (H12AffineFastState.compose env30618 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30618 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30619 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,128,5260,1,3,5140,2080,1024,0,4248,169,16,3,8,17,2048,5140,4097,2216,1024,168,5,168,5124,513]

theorem envBound30619 : H12AffineFastState.Bounded env30619 := by
  intro p hp
  have h : env30619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30618_30619 : H12AffineEnvironment.transform 7 5 env30618 = env30619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30618 == env30619) = true)

theorem identity30619 : scanCanonicalize (H12AffineFastState.compose env30619 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30619 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30620 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,8,5124,1,3,5140,2080,1024,0,4112,33,16,3,8,17,2048,5140,4097,2080,1024,32,5,32,5124,513]

theorem envBound30620 : H12AffineFastState.Bounded env30620 := by
  intro p hp
  have h : env30620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30619_30620 : H12AffineEnvironment.transform 6 8 env30619 = env30620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30619 == env30620) = true)

theorem identity30620 : scanCanonicalize (H12AffineFastState.compose env30620 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound30620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30621 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,1028,8,0,1,3,16,2080,1024,0,1044,33,16,3,8,17,2048,16,1029,2080,1024,32,5,32,0,513]

theorem envBound30621 : H12AffineFastState.Bounded env30621 := by
  intro p hp
  have h : env30621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30620_30621 : H12AffineEnvironment.transform 11 1028 env30620 = env30621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env30620 == env30621) = true)

theorem identity30621 : scanCanonicalize (H12AffineFastState.compose env30621 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound30621 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30622 : List Nat := [2,4,8,16,32,17,8,5,512,1024,555,1028,8,0,1,3,16,523,1024,0,1044,33,16,3,8,17,555,16,1029,523,1024,32,5,32,0,513]

theorem envBound30622 : H12AffineFastState.Bounded env30622 := by
  intro p hp
  have h : env30622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30621_30622 : H12AffineEnvironment.transform 10 555 env30621 = env30622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env30621 == env30622) = true)

theorem identity30622 : scanCanonicalize (H12AffineFastState.compose env30622 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30622 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30623 : List Nat := [2,4,8,16,32,17,8,5,1,1024,42,1028,8,0,1,3,16,10,1024,0,1044,33,16,3,8,17,42,16,1029,10,1024,32,5,32,0,0]

theorem envBound30623 : H12AffineFastState.Bounded env30623 := by
  intro p hp
  have h : env30623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30622_30623 : H12AffineEnvironment.transform 8 1 env30622 = env30623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30622 == env30623) = true)

theorem identity30623 : scanCanonicalize (H12AffineFastState.compose env30623 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound30623 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30624 : List Nat := [2,4,8,16,32,17,8,5,1,37,42,33,8,0,1,3,16,10,37,0,49,33,16,3,8,17,42,16,32,10,37,32,5,32,0,0]

theorem envBound30624 : H12AffineFastState.Bounded env30624 := by
  intro p hp
  have h : env30624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30623_30624 : H12AffineEnvironment.transform 9 37 env30623 = env30624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env30623 == env30624) = true)

theorem identity30624 : scanCanonicalize (H12AffineFastState.compose env30624 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30624 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30625 : List Nat := [2,4,8,16,1,17,8,5,1,4,11,0,8,0,1,3,16,10,4,0,16,0,16,3,8,17,11,16,1,10,4,1,5,1,0,0]

theorem envBound30625 : H12AffineFastState.Bounded env30625 := by
  intro p hp
  have h : env30625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30624_30625 : H12AffineEnvironment.transform 4 1 env30624 = env30625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30624 == env30625) = true)

theorem identity30625 : scanCanonicalize (H12AffineFastState.compose env30625 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30626 : List Nat := [2,4,8,4,1,5,8,5,1,4,11,0,8,0,1,3,4,10,4,0,4,0,4,3,8,5,11,4,1,10,4,1,5,1,0,0]

theorem envBound30626 : H12AffineFastState.Bounded env30626 := by
  intro p hp
  have h : env30626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30625_30626 : H12AffineEnvironment.transform 3 4 env30625 = env30626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30625 == env30626) = true)

theorem identity30626 : scanCanonicalize (H12AffineFastState.compose env30626 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound30626 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30627 : List Nat := [2,4,6,4,1,5,6,5,1,4,5,0,6,0,1,3,4,4,4,0,4,0,4,3,6,5,5,4,1,4,4,1,5,1,0,0]

theorem envBound30627 : H12AffineFastState.Bounded env30627 := by
  intro p hp
  have h : env30627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30626_30627 : H12AffineEnvironment.transform 2 6 env30626 = env30627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env30626 == env30627) = true)

theorem identity30627 : scanCanonicalize (H12AffineFastState.compose env30627 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30627 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30628 : List Nat := [2,2,0,2,1,3,0,3,1,2,3,0,0,0,1,3,2,2,2,0,2,0,2,3,0,3,3,2,1,2,2,1,3,1,0,0]

theorem envBound30628 : H12AffineFastState.Bounded env30628 := by
  intro p hp
  have h : env30628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30627_30628 : H12AffineEnvironment.transform 1 2 env30627 = env30628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30627 == env30628) = true)

theorem identity30628 : scanCanonicalize (H12AffineFastState.compose env30628 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30628 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env30629 : List Nat := [1,1,0,1,1,0,0,0,1,1,0,0,0,0,1,0,1,1,1,0,1,0,1,0,0,0,0,1,1,1,1,1,0,1,0,0]

theorem envBound30629 : H12AffineFastState.Bounded env30629 := by
  intro p hp
  have h : env30629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30628_30629 : H12AffineEnvironment.transform 0 1 env30628 = env30629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30628 == env30629) = true)

def env30630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,262144,1024,32769,17728,21792,21913,41430,8328,64,283821,16536,17800,295129,20701,62708,256,21793,46213,22408]

theorem envBound30630 : H12AffineFastState.Bounded env30630 := by
  intro p hp
  have h : env30630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30612_30630 : H12AffineEnvironment.transform 16 5441 env30612 = env30630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env30612 == env30630) = true)

theorem identity30630 : scanCanonicalize (H12AffineFastState.compose env30630 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound30630 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,56356,1024,32769,17728,21792,21913,41430,8328,64,34953,16536,17800,23805,20701,62708,256,21793,46213,22408]

theorem envBound30631 : H12AffineFastState.Bounded env30631 := by
  intro p hp
  have h : env30631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30630_30631 : H12AffineEnvironment.transform 17 56356 env30630 = env30631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env30630 == env30631) = true)

theorem identity30631 : scanCanonicalize (H12AffineFastState.compose env30631 (packedSelected [0,3,4,7,10,11,16,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30631 : packedSelected [0,3,4,7,10,11,16,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env30632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8323,5441,10481,1024,29908,17728,21792,21913,21763,8328,64,31836,16536,17800,23805,20701,33,256,21793,16464,22408]

theorem envBound30632 : H12AffineFastState.Bounded env30632 := by
  intro p hp
  have h : env30632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30631_30632 : H12AffineEnvironment.transform 14 29909 env30631 = env30632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30631 == env30632) = true)

theorem identity30632 : scanCanonicalize (H12AffineFastState.compose env30632 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30632 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env30633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8323,5392,10400,1024,29829,17681,21792,21913,21763,8328,17,31757,16536,17800,23724,20620,33,256,21793,16385,22408]

theorem envBound30633 : H12AffineFastState.Bounded env30633 := by
  intro p hp
  have h : env30633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30632_30633 : H12AffineEnvironment.transform 5 17 env30632 = env30633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30632 == env30633) = true)

theorem identity30633 : scanCanonicalize (H12AffineFastState.compose env30633 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound30633 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30634 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8461,8323,5392,10400,1024,8460,4248,169,16,138,8328,17,10628,5393,4097,2341,1285,33,256,168,5512,513]

theorem envBound30634 : H12AffineFastState.Bounded env30634 := by
  intro p hp
  have h : env30634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30633_30634 : H12AffineEnvironment.transform 13 5513 env30633 = env30634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env30633 == env30634) = true)

theorem identity30634 : scanCanonicalize (H12AffineFastState.compose env30634 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound30634 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30635 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8,5513,261,139,5392,2216,1024,260,4248,169,16,138,128,17,2444,5393,4097,2341,1285,33,256,168,5512,513]

theorem envBound30635 : H12AffineFastState.Bounded env30635 := by
  intro p hp
  have h : env30635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30634_30635 : H12AffineEnvironment.transform 12 8 env30634 = env30635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env30634 == env30635) = true)

theorem identity30635 : scanCanonicalize (H12AffineFastState.compose env30635 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30635 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env30636 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8,5377,261,3,5392,2080,1024,260,4112,33,16,2,8,17,2308,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound30636 : H12AffineFastState.Bounded env30636 := by
  intro p hp
  have h : env30636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30635_30636 : H12AffineEnvironment.transform 6 8 env30635 = env30636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30635 == env30636) = true)

theorem identity30636 : scanCanonicalize (H12AffineFastState.compose env30636 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound30636 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30637 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,8,4389,261,3,4404,2080,36,260,4112,33,16,2,8,17,2308,4405,4097,2341,289,33,256,32,4388,513]

theorem envBound30637 : H12AffineFastState.Bounded env30637 := by
  intro p hp
  have h : env30637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30636_30637 : H12AffineEnvironment.transform 9 36 env30636 = env30637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env30636 == env30637) = true)

theorem identity30637 : scanCanonicalize (H12AffineFastState.compose env30637 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound30637 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30638 : List Nat := [2,4,8,16,32,17,8,256,512,36,773,4096,8,4389,261,3,4404,805,36,260,4112,33,16,2,8,17,513,4405,4097,544,289,33,256,32,4388,513]

theorem envBound30638 : H12AffineFastState.Bounded env30638 := by
  intro p hp
  have h : env30638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30637_30638 : H12AffineEnvironment.transform 10 773 env30637 = env30638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env30637 == env30638) = true)

theorem identity30638 : scanCanonicalize (H12AffineFastState.compose env30638 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound30638 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30639 : List Nat := [2,4,8,16,32,17,8,52,512,36,561,4096,8,4113,49,3,4096,529,36,48,4112,33,16,2,8,17,513,4097,4097,544,21,33,52,32,4112,513]

theorem envBound30639 : H12AffineFastState.Bounded env30639 := by
  intro p hp
  have h : env30639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30638_30639 : H12AffineEnvironment.transform 7 52 env30638 = env30639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env30638 == env30639) = true)

theorem identity30639 : scanCanonicalize (H12AffineFastState.compose env30639 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound30639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30640 : List Nat := [2,4,8,16,32,17,8,52,512,36,561,17,8,0,49,3,17,529,36,48,1,33,16,2,8,17,513,16,16,544,21,33,52,32,1,513]

theorem envBound30640 : H12AffineFastState.Bounded env30640 := by
  intro p hp
  have h : env30640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30639_30640 : H12AffineEnvironment.transform 11 17 env30639 = env30640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30639 == env30640) = true)

theorem identity30640 : scanCanonicalize (H12AffineFastState.compose env30640 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30640 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30641 : List Nat := [2,4,8,16,0,17,8,20,512,4,529,17,8,0,17,3,17,529,4,16,1,1,16,2,8,17,513,16,16,512,21,1,20,0,1,513]

theorem envBound30641 : H12AffineFastState.Bounded env30641 := by
  intro p hp
  have h : env30641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30640_30641 : H12AffineEnvironment.transform 4 0 env30640 = env30641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30640 == env30641) = true)

theorem identity30641 : scanCanonicalize (H12AffineFastState.compose env30641 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30641 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30642 : List Nat := [2,4,8,16,0,17,8,20,17,4,0,17,8,0,17,3,17,0,4,16,1,1,16,2,8,17,16,16,16,17,21,1,20,0,1,16]

theorem envBound30642 : H12AffineFastState.Bounded env30642 := by
  intro p hp
  have h : env30642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30641_30642 : H12AffineEnvironment.transform 8 17 env30641 = env30642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30641 == env30642) = true)

theorem identity30642 : scanCanonicalize (H12AffineFastState.compose env30642 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30642 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30643 : List Nat := [2,4,8,1,0,0,8,5,0,4,0,0,8,0,0,3,0,0,4,1,1,1,1,2,8,0,1,1,1,0,4,1,5,0,1,1]

theorem envBound30643 : H12AffineFastState.Bounded env30643 := by
  intro p hp
  have h : env30643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30642_30643 : H12AffineEnvironment.transform 3 1 env30642 = env30643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30642 == env30643) = true)

def env30644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21913,98645,8328,64,410093,16536,17800,431512,20701,62709,256,21793,46213,96011]

theorem envBound30644 : H12AffineFastState.Bounded env30644 := by
  intro p hp
  have h : env30644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30644 : H12AffineEnvironment.transform 21 21793 env30610 = env30644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env30610 == env30644) = true)

theorem identity30644 : scanCanonicalize (H12AffineFastState.compose env30644 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound30644 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21913,62559,8328,64,410093,16536,17800,431512,20701,62709,256,21793,46213,513]

theorem envBound30645 : H12AffineFastState.Bounded env30645 := by
  intro p hp
  have h : env30645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30644_30645 : H12AffineEnvironment.transform 15 29962 env30644 = env30645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env30644 == env30645) = true)

theorem identity30645 : scanCanonicalize (H12AffineFastState.compose env30645 (packedSelected [12,15,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30645 : packedSelected [12,15,21,38,41] rootPS < 2^1333 := by decide +kernel

def env30646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21776,62559,8193,64,409956,16401,17665,431377,20564,62588,256,21793,46092,513]

theorem envBound30646 : H12AffineFastState.Bounded env30646 := by
  intro p hp
  have h : env30646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30645_30646 : H12AffineEnvironment.transform 6 9 env30645 = env30646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30645 == env30646) = true)

theorem identity30646 : scanCanonicalize (H12AffineFastState.compose env30646 (packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30646 : packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env30647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,17728,21793,21776,3,8193,64,409956,16401,17665,418125,20564,32,256,21793,16464,513]

theorem envBound30647 : H12AffineFastState.Bounded env30647 := by
  intro p hp
  have h : env30647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30646_30647 : H12AffineEnvironment.transform 14 29788 env30646 = env30647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30646 == env30647) = true)

theorem identity30647 : scanCanonicalize (H12AffineFastState.compose env30647 (packedSelected [2,4,6,9,14,16,21] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound30647 : packedSelected [2,4,6,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env30648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5441,262144,1024,29789,17728,21793,21776,3,8193,64,283685,16401,17665,291852,20564,32,256,21793,16464,513]

theorem envBound30648 : H12AffineFastState.Bounded env30648 := by
  intro p hp
  have h : env30648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30647_30648 : H12AffineEnvironment.transform 16 5441 env30647 = env30648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env30647 == env30648) = true)

theorem identity30648 : scanCanonicalize (H12AffineFastState.compose env30648 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound30648 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env30649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5441,23669,1024,29789,17728,21793,21776,3,8193,64,2128,16401,17665,10361,20564,32,256,21793,16464,513]

theorem envBound30649 : H12AffineFastState.Bounded env30649 := by
  intro p hp
  have h : env30649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30648_30649 : H12AffineEnvironment.transform 17 23669 env30648 = env30649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env30648 == env30649) = true)

theorem identity30649 : scanCanonicalize (H12AffineFastState.compose env30649 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30649 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,8282,5441,2341,1024,8461,4112,113,64,3,8193,64,2128,5441,4177,10361,1284,32,256,113,5376,513]

theorem envBound30650 : H12AffineFastState.Bounded env30650 := by
  intro p hp
  have h : env30650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30649_30650 : H12AffineEnvironment.transform 13 5456 env30649 = env30650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30649 == env30650) = true)

theorem identity30650 : scanCanonicalize (H12AffineFastState.compose env30650 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30650 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,80,262,5441,2341,1024,81,4112,113,64,3,349,64,2128,5441,4177,2341,1284,32,256,113,5376,513]

theorem envBound30651 : H12AffineFastState.Bounded env30651 := by
  intro p hp
  have h : env30651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30650_30651 : H12AffineEnvironment.transform 12 348 env30650 = env30651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30650 == env30651) = true)

theorem identity30651 : scanCanonicalize (H12AffineFastState.compose env30651 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30651 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30652 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1024,1,4112,33,16,3,269,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound30652 : H12AffineFastState.Bounded env30652 := by
  intro p hp
  have h : env30652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30651_30652 : H12AffineEnvironment.transform 5 16 env30651 = env30652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30651 == env30652) = true)

theorem identity30652 : scanCanonicalize (H12AffineFastState.compose env30652 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30653 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,268,309,0,262,292,2341,1024,1,1061,33,16,3,269,16,2048,292,1076,2341,1284,32,256,33,309,513]

theorem envBound30653 : H12AffineFastState.Bounded env30653 := by
  intro p hp
  have h : env30653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30652_30653 : H12AffineEnvironment.transform 11 1077 env30652 = env30653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env30652 == env30653) = true)

theorem identity30653 : scanCanonicalize (H12AffineFastState.compose env30653 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound30653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30654 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1077,268,309,0,262,292,10,1024,1,1061,33,16,3,269,16,303,292,1076,10,1284,32,256,33,309,513]

theorem envBound30654 : H12AffineFastState.Bounded env30654 := by
  intro p hp
  have h : env30654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30653_30654 : H12AffineEnvironment.transform 10 303 env30653 = env30654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env30653 == env30654) = true)

theorem identity30654 : scanCanonicalize (H12AffineFastState.compose env30654 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30654 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30655 : List Nat := [2,4,8,16,32,16,9,256,512,5,303,48,268,309,0,262,292,10,5,1,32,33,16,3,269,16,303,292,49,10,257,32,256,33,309,513]

theorem envBound30655 : H12AffineFastState.Bounded env30655 := by
  intro p hp
  have h : env30655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30654_30655 : H12AffineEnvironment.transform 9 5 env30654 = env30655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30654 == env30655) = true)

theorem identity30655 : scanCanonicalize (H12AffineFastState.compose env30655 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound30655 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30656 : List Nat := [2,4,8,16,32,16,9,15,512,5,32,48,3,58,0,9,43,10,5,1,32,33,16,3,2,16,32,43,49,10,14,32,15,33,58,513]

theorem envBound30656 : H12AffineFastState.Bounded env30656 := by
  intro p hp
  have h : env30656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30655_30656 : H12AffineEnvironment.transform 7 15 env30655 = env30656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env30655 == env30656) = true)

def env30657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21913,98644,8328,64,4592845,16536,17801,431512,20700,4235732,256,21793,46213,96010]

theorem envBound30657 : H12AffineFastState.Bounded env30657 := by
  intro p hp
  have h : env30657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30609_30657 : H12AffineEnvironment.transform 20 17729 env30609 = env30657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env30609 == env30657) = true)

def env30658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21913,98644,8328,64,410093,16536,17801,431512,20700,62708,256,21793,46213,96010]

theorem envBound30658 : H12AffineFastState.Bounded env30658 := by
  intro p hp
  have h : env30658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30657_30658 : H12AffineEnvironment.transform 21 21792 env30657 = env30658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env30657 == env30658) = true)

theorem identity30658 : scanCanonicalize (H12AffineFastState.compose env30658 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound30658 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,17729,21792,21913,21763,8328,64,410093,16536,17801,431512,20700,62708,256,21793,46213,41821]

theorem envBound30659 : H12AffineFastState.Bounded env30659 := by
  intro p hp
  have h : env30659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30658_30659 : H12AffineEnvironment.transform 15 54359 env30658 = env30659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env30658 == env30659) = true)

theorem identity30659 : scanCanonicalize (H12AffineFastState.compose env30659 (packedSelected [3,10,12,15,21,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound30659 : packedSelected [3,10,12,15,21,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env30660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35324,1024,32769,17729,21792,21913,21763,8328,64,182289,16536,17801,138340,20700,62708,256,21793,46213,41821]

theorem envBound30660 : H12AffineFastState.Bounded env30660 := by
  intro p hp
  have h : env30660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30659_30660 : H12AffineEnvironment.transform 17 35324 env30659 = env30660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env30659 == env30660) = true)

theorem identity30660 : scanCanonicalize (H12AffineFastState.compose env30660 (packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound30660 : packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,5220,35324,1024,32769,17729,21792,21913,21763,8328,64,56437,16536,17801,2048,20700,62708,256,21793,46213,41821]

theorem envBound30661 : H12AffineFastState.Bounded env30661 := by
  intro p hp
  have h : env30661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30660_30661 : H12AffineEnvironment.transform 16 5220 env30660 = env30661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env30660 == env30661) = true)

theorem identity30661 : scanCanonicalize (H12AffineFastState.compose env30661 (packedSelected [0,2,3,4,7,10,11,14,16,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound30661 : packedSelected [0,2,3,4,7,10,11,14,16,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29993,8574,5220,31957,1024,29992,17729,21792,21913,21763,8328,64,10588,16536,17801,2048,20700,477,256,21793,16812,22132]

theorem envBound30662 : H12AffineFastState.Bounded env30662 := by
  intro p hp
  have h : env30662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30661_30662 : H12AffineEnvironment.transform 14 29993 env30661 = env30662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env30661 == env30662) = true)

theorem identity30662 : scanCanonicalize (H12AffineFastState.compose env30662 (packedSelected [2,4,9,11,16,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30662 : packedSelected [2,4,9,11,16,18,21] rootPS < 2^1333 := by decide +kernel

def env30663 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,29788,8203,5220,31957,1024,29789,17460,21589,21740,21622,8328,64,10281,16536,17660,2048,20700,168,117,21588,16601,22132]

theorem envBound30663 : H12AffineFastState.Bounded env30663 := by
  intro p hp
  have h : env30663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30662_30663 : H12AffineEnvironment.transform 7 117 env30662 = env30663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30662 == env30663) = true)

theorem identity30663 : scanCanonicalize (H12AffineFastState.compose env30663 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound30663 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env30664 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8352,8203,5220,10281,1024,8353,4296,169,16,138,8328,64,10281,5220,4096,2048,1056,168,117,168,5157,648]

theorem envBound30664 : H12AffineFastState.Bounded env30664 := by
  intro p hp
  have h : env30664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30663_30664 : H12AffineEnvironment.transform 13 5372 env30663 = env30664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env30663 == env30664) = true)

theorem identity30664 : scanCanonicalize (H12AffineFastState.compose env30664 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 3661) := by decide +kernel

theorem selectedBound30664 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env30665 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,3661,5372,3821,3654,5220,1636,1024,3820,4296,169,16,138,3781,64,1636,5220,4096,2048,1056,168,117,168,5157,648]

theorem envBound30665 : H12AffineFastState.Bounded env30665 := by
  intro p hp
  have h : env30665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30664_30665 : H12AffineEnvironment.transform 12 3661 env30664 = env30665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3661 env30664 == env30665) = true)

theorem identity30665 : scanCanonicalize (H12AffineFastState.compose env30665 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1636) := by decide +kernel

theorem selectedBound30665 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30666 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1636,4096,41,5372,137,34,5220,1636,1024,136,4296,169,16,138,161,64,1636,5220,4096,1636,1056,168,117,168,5157,648]

theorem envBound30666 : H12AffineFastState.Bounded env30666 := by
  intro p hp
  have h : env30666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30665_30666 : H12AffineEnvironment.transform 10 1636 env30665 = env30666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1636 env30665 == env30666) = true)

theorem identity30666 : scanCanonicalize (H12AffineFastState.compose env30666 (packedSelected [1,3,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound30666 : packedSelected [1,3,6,11] rootPS < 2^1333 := by decide +kernel

def env30667 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1636,649,41,1653,137,34,1773,1636,1024,136,577,169,16,138,161,64,1636,1773,649,1636,1056,168,117,168,1708,648]

theorem envBound30667 : H12AffineFastState.Bounded env30667 := by
  intro p hp
  have h : env30667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30666_30667 : H12AffineEnvironment.transform 11 649 env30666 = env30667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env30666 == env30667) = true)

theorem identity30667 : scanCanonicalize (H12AffineFastState.compose env30667 (packedSelected [1,2,3,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30667 : packedSelected [1,2,3,6,12] rootPS < 2^1333 := by decide +kernel

def env30668 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1588,649,41,1573,137,34,1725,1588,1024,136,529,169,16,138,161,16,1588,1725,649,1588,1056,168,37,168,1708,648]

theorem envBound30668 : H12AffineFastState.Bounded env30668 := by
  intro p hp
  have h : env30668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30667_30668 : H12AffineEnvironment.transform 5 16 env30667 = env30668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30667 == env30668) = true)

theorem identity30668 : scanCanonicalize (H12AffineFastState.compose env30668 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound30668 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env30669 : List Nat := [2,4,8,16,32,16,128,37,512,188,648,649,41,665,137,34,513,648,188,136,529,169,16,138,161,16,648,513,649,648,156,168,37,168,528,648]

theorem envBound30669 : H12AffineFastState.Bounded env30669 := by
  intro p hp
  have h : env30669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30668_30669 : H12AffineEnvironment.transform 9 188 env30668 = env30669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env30668 == env30669) = true)

theorem identity30669 : scanCanonicalize (H12AffineFastState.compose env30669 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30669 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30670 : List Nat := [2,4,8,16,32,16,128,37,16,188,152,153,41,137,137,34,17,152,188,136,1,169,16,138,161,16,152,17,153,152,156,168,37,168,0,152]

theorem envBound30670 : H12AffineFastState.Bounded env30670 := by
  intro p hp
  have h : env30670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30669_30670 : H12AffineEnvironment.transform 8 16 env30669 = env30670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30669 == env30670) = true)

def env30671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21913,98644,8328,64,410092,16536,17801,431512,20700,62709,256,21793,46213,96010]

theorem envBound30671 : H12AffineFastState.Bounded env30671 := by
  intro p hp
  have h : env30671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30657_30671 : H12AffineEnvironment.transform 21 21793 env30657 = env30671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env30657 == env30671) = true)

theorem identity30671 : scanCanonicalize (H12AffineFastState.compose env30671 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound30671 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,17729,21793,21913,138,8328,64,410092,16536,17801,431512,20700,62709,256,21793,46213,63188]

theorem envBound30672 : H12AffineFastState.Bounded env30672 := by
  intro p hp
  have h : env30672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30671_30672 : H12AffineEnvironment.transform 15 33246 env30671 = env30672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env30671 == env30672) = true)

def env30673 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33030,131072,262144,1024,32769,17729,21793,21825,82,8272,64,409908,16448,17745,431424,20484,62509,256,21793,46173,62988]

theorem envBound30673 : H12AffineFastState.Bounded env30673 := by
  intro p hp
  have h : env30673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30672_30673 : H12AffineEnvironment.transform 6 88 env30672 = env30673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env30672 == env30673) = true)

theorem identity30673 : scanCanonicalize (H12AffineFastState.compose env30673 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound30673 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env30674 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33030,131072,146793,1024,32769,17729,21793,21825,82,8272,64,31837,16448,17745,43049,20484,62509,256,21793,46173,62988]

theorem envBound30674 : H12AffineFastState.Bounded env30674 := by
  intro p hp
  have h : env30674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30673_30674 : H12AffineEnvironment.transform 17 146793 env30673 = env30674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env30673 == env30674) = true)

theorem identity30674 : scanCanonicalize (H12AffineFastState.compose env30674 (packedSelected [0,1,4,7,11,16,18,19,20,21,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30674 : packedSelected [0,1,4,7,11,16,18,19,20,21,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env30675 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29788,30042,131072,146793,1024,29789,17729,21793,21825,82,8272,64,31837,16448,17745,23669,20484,113,256,21793,16385,592]

theorem envBound30675 : H12AffineFastState.Bounded env30675 := by
  intro p hp
  have h : env30675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30674_30675 : H12AffineEnvironment.transform 14 29788 env30674 = env30675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30674 == env30675) = true)

def env30676 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33031,131072,262144,1024,32769,17729,21793,21824,83,8273,64,409909,16449,17744,431425,20485,62508,256,21793,46172,62989]

theorem envBound30676 : H12AffineFastState.Bounded env30676 := by
  intro p hp
  have h : env30676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30672_30676 : H12AffineEnvironment.transform 6 89 env30672 = env30676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30672 == env30676) = true)

theorem identity30676 : scanCanonicalize (H12AffineFastState.compose env30676 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound30676 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env30677 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33031,131072,171108,1024,32769,17729,21793,21824,83,8273,64,56657,16449,17744,2341,20485,62508,256,21793,46172,62989]

theorem envBound30677 : H12AffineFastState.Bounded env30677 := by
  intro p hp
  have h : env30677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30676_30677 : H12AffineEnvironment.transform 17 171108 env30676 = env30677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env30676 == env30677) = true)

theorem identity30677 : scanCanonicalize (H12AffineFastState.compose env30677 (packedSelected [0,9,21,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30677 : packedSelected [0,9,21,22,27] rootPS < 2^1333 := by decide +kernel

def env30678 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8540,8283,131072,146744,1024,8541,17729,21793,21824,83,8273,64,31757,16449,17744,2341,20485,21872,256,21793,5376,22353]

theorem envBound30678 : H12AffineFastState.Bounded env30678 := by
  intro p hp
  have h : env30678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30677_30678 : H12AffineEnvironment.transform 14 8540 env30677 = env30678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30677 == env30678) = true)

theorem identity30678 : scanCanonicalize (H12AffineFastState.compose env30678 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30678 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30679 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,8283,131072,146744,1024,8541,4113,113,16,83,8273,64,10589,5393,4096,2341,1365,32,256,113,5376,513]

theorem envBound30679 : H12AffineFastState.Bounded env30679 := by
  intro p hp
  have h : env30679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30678_30679 : H12AffineEnvironment.transform 13 5456 env30678 = env30679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30678 == env30679) = true)

theorem identity30679 : scanCanonicalize (H12AffineFastState.compose env30679 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30679 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30680 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,8283,5393,10281,1024,8541,4113,113,16,83,8273,64,10589,5393,4096,2341,1365,32,256,113,5376,513]

theorem envBound30680 : H12AffineFastState.Bounded env30680 := by
  intro p hp
  have h : env30680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30679_30680 : H12AffineEnvironment.transform 16 5393 env30679 = env30680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30679 == env30680) = true)

theorem identity30680 : scanCanonicalize (H12AffineFastState.compose env30680 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30680 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30681 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,5393,10281,1024,8460,4113,32,16,2,8192,17,10508,5393,4096,2341,1284,32,256,32,5376,513]

theorem envBound30681 : H12AffineFastState.Bounded env30681 := by
  intro p hp
  have h : env30681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30680_30681 : H12AffineEnvironment.transform 5 17 env30680 = env30681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30680 == env30681) = true)

def env30682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound30682 : H12AffineFastState.Bounded env30682 := by
  intro p hp
  have h : env30682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30478_30682 : H12AffineEnvironment.transform 18 1025 env30478 = env30682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env30478 == env30682) = true)

theorem identity30682 : scanCanonicalize (H12AffineFastState.compose env30682 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237588) := by decide +kernel

theorem selectedBound30682 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,16777216,8328,64,23454869,18973836,160197,2417812,19112069,23160257,257,17031224,16974237,19040082]

theorem envBound30683 : H12AffineFastState.Bounded env30683 := by
  intro p hp
  have h : env30683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30682_30683 : H12AffineEnvironment.transform 22 2237588 env30682 = env30683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237588 env30682 == env30683) = true)

def env30684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,242968,8328,64,6705549,2240916,160197,2417812,2102685,6475993,257,21792,46213,2175562]

theorem envBound30684 : H12AffineFastState.Bounded env30684 := by
  intro p hp
  have h : env30684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30683_30684 : H12AffineEnvironment.transform 23 242968 env30683 = env30684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env30683 == env30684) = true)

def env30685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237588,242968,8328,64,2144541,2240916,160197,2417812,2102685,2373705,257,21792,46213,2175562]

theorem envBound30685 : H12AffineFastState.Bounded env30685 := by
  intro p hp
  have h : env30685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30684_30685 : H12AffineEnvironment.transform 21 452752 env30684 = env30685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env30684 == env30685) = true)

def env30686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144596,242968,8328,64,43357,139732,160197,324820,1501,272393,257,21792,46213,74250]

theorem envBound30686 : H12AffineFastState.Bounded env30686 := by
  intro p hp
  have h : env30686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30685_30686 : H12AffineEnvironment.transform 20 4160 env30685 = env30686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30685 == env30686) = true)

theorem identity30686 : scanCanonicalize (H12AffineFastState.compose env30686 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30686 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,400452,144596,213452,8328,64,23945,139732,160197,262144,1501,272393,257,21792,16465,74250]

theorem envBound30687 : H12AffineFastState.Bounded env30687 := by
  intro p hp
  have h : env30687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30686_30687 : H12AffineEnvironment.transform 14 29908 env30686 = env30687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30686 == env30687) = true)

def env30688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,400404,144516,213404,8328,16,23945,139652,160149,262144,1421,272393,257,21792,16385,74250]

theorem envBound30688 : H12AffineFastState.Bounded env30688 := by
  intro p hp
  have h : env30688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30687_30688 : H12AffineEnvironment.transform 5 16 env30687 = env30688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30687 == env30688) = true)

theorem identity30688 : scanCanonicalize (H12AffineFastState.compose env30688 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound30688 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30689 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,262144,1025,29829,4112,338190,65950,29830,8328,16,23945,70814,83087,262144,1421,272393,257,21792,16385,74250]

theorem envBound30689 : H12AffineFastState.Bounded env30689 := by
  intro p hp
  have h : env30689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30688_30689 : H12AffineEnvironment.transform 16 79130 env30688 = env30689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env30688 == env30689) = true)

theorem identity30689 : scanCanonicalize (H12AffineFastState.compose env30689 (packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30689 : packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env30690 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,262144,1025,29829,4112,264588,8476,29830,8328,16,23945,13340,25613,262144,1421,272393,257,21792,16385,648]

theorem envBound30690 : H12AffineFastState.Bounded env30690 := by
  intro p hp
  have h : env30690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30689_30690 : H12AffineEnvironment.transform 15 8322 env30689 = env30690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30689 == env30690) = true)

theorem identity30690 : scanCanonicalize (H12AffineFastState.compose env30690 (packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 31005) := by decide +kernel

theorem selectedBound30690 : packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env30691 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,31005,1025,29829,4112,28817,8476,29830,8328,16,23945,13340,25613,31005,1421,20756,257,21792,16385,648]

theorem envBound30691 : H12AffineFastState.Bounded env30691 := by
  intro p hp
  have h : env30691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30690_30691 : H12AffineEnvironment.transform 17 31005 env30690 = env30691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31005 env30690 == env30691) = true)

theorem identity30691 : scanCanonicalize (H12AffineFastState.compose env30691 (packedSelected [2,3,4,5,6,10,11,16,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30691 : packedSelected [2,3,4,5,6,10,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env30692 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8202,5392,31005,1025,29709,4112,28697,8476,29710,8192,16,23809,13340,25613,31005,1285,20756,257,21792,16385,512]

theorem envBound30692 : H12AffineFastState.Bounded env30692 := by
  intro p hp
  have h : env30692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30691_30692 : H12AffineEnvironment.transform 6 8 env30691 = env30692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30691 == env30692) = true)

theorem identity30692 : scanCanonicalize (H12AffineFastState.compose env30692 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound30692 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30693 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,16384,20497,1047,5392,23808,1025,20496,4112,21508,1281,20499,1053,16,23809,4097,16400,23808,1285,20756,257,21792,16385,512]

theorem envBound30693 : H12AffineFastState.Bounded env30693 := by
  intro p hp
  have h : env30693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30692_30693 : H12AffineEnvironment.transform 12 1053 env30692 = env30693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env30692 == env30693) = true)

theorem identity30693 : scanCanonicalize (H12AffineFastState.compose env30693 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound30693 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env30694 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,4373,260,1047,5392,3093,1025,261,4112,1297,1281,262,1053,16,3092,4097,4357,3093,1285,1,257,1077,4372,512]

theorem envBound30694 : H12AffineFastState.Bounded env30694 := by
  intro p hp
  have h : env30694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30693_30694 : H12AffineEnvironment.transform 13 4373 env30693 = env30694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env30693 == env30694) = true)

theorem identity30694 : scanCanonicalize (H12AffineFastState.compose env30694 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

end H12CloudChart0